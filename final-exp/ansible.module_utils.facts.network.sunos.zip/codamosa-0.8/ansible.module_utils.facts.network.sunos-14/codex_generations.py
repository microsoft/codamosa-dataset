

# Generated at 2022-06-11 03:35:52.676840
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = NetworkCollector()
    assert len(module.get_facts()) > 0

# Generated at 2022-06-11 03:35:54.604585
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    NetworkCollector.platform = 'SunOS'
    collector = SunOSNetworkCollector()
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'

# Generated at 2022-06-11 03:36:01.040972
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.common import get_ifconfig_path
    from ansible_collections.notstdlib.moveitallout.tests.unit.plugins.modules.utils import set_module_args
    module = NetworkCollector()
    ifconfig_path = get_ifconfig_path(module)
    if ifconfig_path:
        set_module_args(dict(gather_subset=['!all']))
        obj = SunOSNetwork(module)
        interfaces, ips = obj.get_interfaces_info(ifconfig_path)
        assert type(interfaces) is dict, interfaces
        assert type(ips) is dict, ips

# Generated at 2022-06-11 03:36:10.552155
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeModule()
    collector = SunOSNetworkCollector(module)
    # If a test fails, please update these facts to match the output of
    # '/sbin/ifconfig -a' on your platform.

# Generated at 2022-06-11 03:36:13.532801
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    assert net_collector is not None
    assert net_collector._fact_class == SunOSNetwork
    assert net_collector._platform == 'SunOS'

# Generated at 2022-06-11 03:36:23.729731
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    import pprint

    # Create test data

# Generated at 2022-06-11 03:36:27.157415
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module_mock = type('module', (), {})()
    facts_obj = SunOSNetworkCollector(module_mock)
    assert facts_obj.platform == 'SunOS'
    assert facts_obj.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:36:38.648549
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:36:50.355381
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-11 03:36:53.342206
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector(None)
    assert network_collector._fact_class == SunOSNetwork
    assert network_collector._platform == 'SunOS'



# Generated at 2022-06-11 03:37:05.305144
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['!all', '!min'])})

    obj = SunOSNetwork()
    interfaces, ips = obj.get_interfaces_info(ifconfig_path='tests/unit/module_utils/facts/network/utils/fake_ifconfig')

    keys = interfaces.keys()
    keys.sort()
    module.exit_json(ansible_facts={'ansible_interfaces': keys, 'ansible_all_ipv4_addresses': ips['all_ipv4_addresses'],
                                    'ansible_all_ipv6_addresses': ips['all_ipv6_addresses']})


# Generated at 2022-06-11 03:37:17.631394
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.utils import FactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    # Create a fake SunOS system
    fake_interfaces = 'tests/unit/module_utils/facts/network/devices/SunOS/actual'
    fake_interfaces_output = get_file_lines(fake_interfaces)

    # Create a fake module
    module = FakeAnsibleModule()

    # Set the facts collector
    fact_collector = FactCollector(module=module)
    fact_collector.collect_device_facts = MagicMock(return_value=fake_interfaces_output)
    fact_collector.collect_platform_facts = MagicMock(return_value='SunOS')

    # Run method get_interfaces_info

# Generated at 2022-06-11 03:37:20.490282
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    assert net_collector._fact_class == SunOSNetwork
    assert net_collector._platform == 'SunOS'



# Generated at 2022-06-11 03:37:22.384551
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    c = SunOSNetworkCollector()
    assert isinstance(c, SunOSNetworkCollector)

# Generated at 2022-06-11 03:37:31.492391
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockModule()

# Generated at 2022-06-11 03:37:41.817502
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:37:51.616822
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    SunOS output of 'ifconfig -a'
    """
    # Sample ifconfig -a output trimmed to show one interface with IPv4 and one with IPv6 only

# Generated at 2022-06-11 03:37:56.917979
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    network = SunOSNetwork()
    network.module.run_command = run_command
    network.module.warn = no_warn
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert len(interfaces['lo0']['ipv4']) == 1
    assert '127.0.0.1' in ips['all_ipv4_addresses']



# Generated at 2022-06-11 03:38:00.687026
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    assert collector.__class__.__name__ == 'SunOSNetworkCollector'
    assert collector._fact_class.__name__ == 'SunOSNetwork'
    assert collector._platform == 'SunOS'

# Generated at 2022-06-11 03:38:02.017038
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == SunOSNetwork.platform

# Generated at 2022-06-11 03:38:12.569534
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    nc = SunOSNetworkCollector()
    assert nc.platform == 'SunOS'
    assert nc.fact_class == nc._fact_class
    assert nc.fact_class.platform == nc.platform

# Generated at 2022-06-11 03:38:14.459208
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    klass = SunOSNetworkCollector(None)
    assert isinstance(klass._fact_class, SunOSNetwork)
    assert klass._platform == 'SunOS'


# Generated at 2022-06-11 03:38:24.674575
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:38:35.657878
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    ifconfig_path = '/sbin/ifconfig'
    # Testing with an ifconfig -a output of a Solaris 11.3 server with 7 interfaces

# Generated at 2022-06-11 03:38:45.888049
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollector()
    module.params = dict(gather_subset='!all,!min')
    module.run_command = MagicMock(return_value=(0, '/sbin/ifconfig -a\n', ''))

# Generated at 2022-06-11 03:38:56.614440
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    network = SunOSNetwork()

    # Test with current_if = None
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = None
    current_if = network.parse_interface_line(words, current_if, {})
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL']
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if['ipv6'] == []

# Generated at 2022-06-11 03:39:08.326702
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    facts = SunOSNetwork()
    interfaces, ips = facts.get_interfaces_info(ifconfig_path='/sbin/ifconfig')

    assert 'lo0' in interfaces
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces

    assert 'lo0' in interfaces['lo0']
    assert 'ipv4' in interfaces['lo0']

    assert 'flags' in interfaces['lo0']['ipv4'][0]
    assert 'mtu' in interfaces['lo0']['ipv4'][0]
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4']

# Generated at 2022-06-11 03:39:11.560237
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    '''Test the constructor of SunOSNetworkCollector'''

    # Just test that it instantiates and doesn't error out
    SunOSNetworkCollector()


# Unit test of method get_interfaces_info() of class SunOSNetworkCollector

# Generated at 2022-06-11 03:39:22.648592
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-11 03:39:26.767337
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec=dict())
    collectors = [SunOSNetworkCollector]
    network_collector = NetworkCollector(module=module, collectors=collectors)

    assert network_collector.get_collectors() == [SunOSNetworkCollector]

# Generated at 2022-06-11 03:39:51.789472
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:39:56.354760
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    network_collector = SunOSNetworkCollector()
    assert type(network_collector._fact_class) == type(GenericBsdIfconfigNetwork)
    assert hasattr(network_collector._fact_class, 'platform')

# Generated at 2022-06-11 03:40:00.004888
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module)
    network_collector.collect()
    assert network_collector.network is not None
    assert network_collector.network._platform == 'SunOS'


# Generated at 2022-06-11 03:40:01.270078
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test SunOSNetwork constructor"""
    SunOSNetworkCollector()


# Generated at 2022-06-11 03:40:10.764307
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Create an instance of SunOSNetwork
    test_class = SunOSNetwork()

    # Create a test case of output from 'ifconfig -a' command
    line = 'lo0:\n'

    # Create a second test case of output from 'ifconfig -a' command
    line2 = 'aggr0: flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4> mtu 1500 index 2\n'

    # Create test dictionaries
    interfaces = {}
    current_if = {}
    current_if = test_class.parse_interface_line(line.split(), current_if, interfaces)
    current_if = test_class.parse_interface_line(line2.split(), current_if, interfaces)


# Generated at 2022-06-11 03:40:21.788812
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """SunOSNetwork: Test get_interfaces_info"""

    test_module = type('', (object, ), {'run_command': run_command})()
    test_module.params = {'gather_network_resources': 'all'}

    # Fake 'ifconfig -a' on Solaris 10
    os_release = 'Solaris 10 8/07 s10s_u5wos_05 SPARC'

# Generated at 2022-06-11 03:40:24.623244
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test class SunOSNetworkCollector"""
    network_collector_ins = SunOSNetworkCollector()
    assert network_collector_ins._fact_class is SunOSNetwork

# Generated at 2022-06-11 03:40:34.643670
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    mock = NetworkCollector.get_network_collector_mock('SunOS')
    mock['module'] = NetworkCollector.get_mock_module_helper()
    mock['module'].run_command.return_value = (1, '', '')
    mock['module'].run_command.return_value = (0,
'''lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000 vhid 1 advskew 0
        inet6 ::1/128
        nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>
''', '')


# Generated at 2022-06-11 03:40:42.494364
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # This import is needed since ansible.module_utils.facts.network.sunos will be
    # imported inside of SunOSNetwork.__init__().
    # Python will complain about this import if the test below is not present.
    import ansible.module_utils.facts.network.sunos
    # This fake_module is needed since ansible.module_utils.facts.network.sunos will be
    # imported inside of SunOSNetwork.__init__().
    # Python will complain about this import if the test below is not present.
    fake_module = ansible.module_utils.facts.network.sunos
    sn = SunOSNetwork()
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    interfaces = {}
    current_if = {}


# Generated at 2022-06-11 03:40:45.430960
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:41:28.728408
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    '''
    Test SunOSNetwork.get_interfaces_info()
    '''
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    ifconfig_path = 'test/modules/test_facts/unit/files/ifconfig'
    sunosnet = SunOSNetwork(dict(), dict())

    interfaces, ips = sunosnet.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-11 03:41:38.750926
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from collections import namedtuple

    # Set up fake module and network class to use for testing.
    module = namedtuple('module', ('run_command',))  # Helper class
    class fake_SunOSNetwork:
        platform = "SunOS"
        module = module
        def __init__(self):
            self.facts = dict(interface_ip={'lo0': ['127.0.0.1'], 'bge0': ['10.2.2.1', 'fe80::21a:4eff:fe10:4e05']})
            self.module = module

        def get_interfaces_info(self, ifconfig_path):
            # Function under test
            self.interfaces, self.ips = self.facts['interfaces'], self.facts['ips']
            return self.interfaces, self.ips



# Generated at 2022-06-11 03:41:40.006998
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:41:49.133010
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-11 03:41:56.673464
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    ip_path = '/usr/sbin/ifconfig'
    test_sunos = SunOSNetwork(module)


# Generated at 2022-06-11 03:42:02.838975
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class SunOSNetwork
    """
    device = "vni0"
    family = "ipv4"
    ipv4_interfaces = [{'dstaddr': 'default', 'broadcast': '172.16.130.255', 'destination': '172.16.130.0', 'flags': {'BROADCAST', 'MULTICAST', 'RUNNING'}, 'mask': '255.255.255.0'}]
    ipv4_addresses = ['172.16.130.88']
    ipv6_interfaces = [{'addr': 'fe80::250:56ff:fea4:6ea4/10', 'scopeid': '0', 'flags': {'TEMPORARY'}}]

# Generated at 2022-06-11 03:42:12.848543
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    words = line.split()
    current_if = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    assert isinstance(current_if, dict)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'][0] == 'UP'
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if['type'] == 'loopback'


# Generated at 2022-06-11 03:42:15.287475
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockModule()
    network_module = SunOSNetwork(module=module)
    network_module.get_interfaces_info('/sbin/ifconfig')


# Generated at 2022-06-11 03:42:16.446656
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'


# Generated at 2022-06-11 03:42:18.687702
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:43:30.328250
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:43:31.262341
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-11 03:43:33.759455
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    nc = SunOSNetworkCollector()
    assert nc._platform == 'SunOS'
    assert nc._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:43:37.302899
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    # Create instance of SunOSNetworkCollector
    SunOSNetworkCollector(module)

# Generated at 2022-06-11 03:43:46.539780
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockModule()
    obj = SunOSNetwork(module)
    ifconfig_path = '/usr/sbin/ifconfig'
    interfaces, ips = obj.get_interfaces_info(ifconfig_path)

    assert len(interfaces) == 3
    for iface in interfaces:
        if iface == 'lo0':
            assert interfaces[iface]['mtu'] == '8232'
            assert interfaces[iface]['type'] == 'loopback'
            assert interfaces[iface]['macaddress'] == '00:00:00:00:00:00'
            assert interfaces[iface]['ipv4'][0]['address'] == '127.0.0.1'
            assert interfaces[iface]['ipv4'][0]['netmask'] == '255.0.0.0'

# Generated at 2022-06-11 03:43:49.890923
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    for key in ('_platform', '_fact_class'):
        assert hasattr(collector, key)


# Generated at 2022-06-11 03:43:59.322432
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = None
    ifconfig = collector = None

    # Dummy module and ifconfig output
    #
    # The output if 'ifconfig -a' has one interface printed twice, once for IPv4 and
    # again for IPv6.
    #
    # IPv4:
    #   interface name
    #   inet address
    #   netmask
    #
    # IPv6:
    #   interface name
    #   inet6 address
    #   prefixlen
    #   scope
    #
    # Each record uses 4 lines of output, so each interface uses 8 lines.
    #
    # The test output contains IPv4 and IPv6 records for two interfaces, so 32 lines.
    #

# Generated at 2022-06-11 03:44:02.178976
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector._fact_class == SunOSNetwork
    assert network_collector._platform == 'SunOS'

# Generated at 2022-06-11 03:44:09.614697
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector
    assert collector.platform == 'SunOS'
    assert collector._platform == 'SunOS'
    assert collector._fact_class.platform == 'SunOS'
    assert collector._fact_class == SunOSNetwork
    assert collector._fact_class().platform == 'SunOS'
    assert collector._fact_class()._platform == 'SunOS'
    assert issubclass(collector._fact_class, GenericBsdIfconfigNetwork)
    assert collector._fact_class().get_interfaces_info.__module__ == 'ansible.module_utils.facts.network.sunos.SunOSNetwork'


# Generated at 2022-06-11 03:44:19.839355
# Unit test for method get_interfaces_info of class SunOSNetwork