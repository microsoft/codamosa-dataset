

# Generated at 2022-06-11 03:35:58.630321
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunos_network = SunOSNetwork()
    interfaces = {}
    current_if = {}
    current_if = sunos_network.parse_interface_line(['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232'], current_if, interfaces)
    interfaces[current_if['device']] = current_if
    assert interfaces == {'lo0': {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL'], 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}}
    current

# Generated at 2022-06-11 03:36:02.446816
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    # Test the constructor.
    e = SunOSNetworkCollector()
    assert (e.platform == 'SunOS')
    assert (e.fact_class == SunOSNetwork)
    assert (e.fact_class.platform == 'SunOS')
    assert (e.fact_class.get_interfaces_info.__doc__.startswith('Solaris'))

# Generated at 2022-06-11 03:36:03.590948
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    x = SunOSNetworkCollector()
    assert x._platform == 'SunOS'

# Generated at 2022-06-11 03:36:07.472448
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork
    assert obj._fact_class.platform == 'SunOS'
    assert obj.platform == obj._fact_class.platform

# Generated at 2022-06-11 03:36:09.090703
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test SunOSNetworkCollector instantiation"""

    oc = SunOSNetworkCollector()
    assert oc != None

# Generated at 2022-06-11 03:36:10.414350
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test SunOSNetworkCollector class
    """
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:36:14.577843
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    ifc = SunOSNetworkCollector()
    assert 'ansible.module_utils.facts.network.sunos.SunOSNetwork' == ifc._fact_class.__module__ + '.' + ifc._fact_class.__name__
    assert 'SunOS' == ifc._platform



# Generated at 2022-06-11 03:36:20.643383
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ''' Unit test for method get_interfaces_info of class SunOSNetwork

    Unit Tests are defined in tests/unit/module_utils/facts/network/test_network.py
    under NetworkCollectorTests.test_get_interfaces_info

    Arguments:
        :param None
    Return:
        :return None
    '''
    SunOSNetwork.get_interfaces_info(None)

# Generated at 2022-06-11 03:36:29.844760
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class SunOSNetwork"""
    # test data for this method

# Generated at 2022-06-11 03:36:31.489137
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:36:37.361267
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:36:49.099017
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    collector = SunOSNetworkCollector()
    network = SunOSNetwork(collector)
    current_if = {}
    interfaces = {}
    words = ['ilb0:', 'flags=2004841<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232']
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == words[0][0:-1]
    assert 'LOOPBACK' in current_if['ipv4'][0]['flags']

# Generated at 2022-06-11 03:36:50.248287
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector

# Generated at 2022-06-11 03:37:00.119981
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockModule()
    facts_obj = SunOSNetwork(module)
    options = dict(
        config_file=dict(default="/tmp/fake-interfaces.cfg")
    )
    facts_obj.update_options(options)
    interfaces, ips = facts_obj.get_interfaces_info(facts_obj.module.params['config_file'])
    print(interfaces)
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'

# Generated at 2022-06-11 03:37:02.838550
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector._platform == "SunOS"
    assert collector._fact_class.__name__ == "SunOSNetwork"
    assert collector.platform == "SunOS"


# Generated at 2022-06-11 03:37:07.521182
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test SunOSNetworkCollector - constructor
    """

    sunos_fact_collector = SunOSNetworkCollector()

    assert sunos_fact_collector.platform == 'SunOS'
    assert sunos_fact_collector.fact_class == SunOSNetwork
    assert sunos_fact_collector.config == None

# Generated at 2022-06-11 03:37:08.635980
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:37:20.699510
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockNetworkModule()
    module.params = {'gather_subset': [], 'gather_network_resources': 'all', 'gather_timeout': 10}
    cmds = dict(
        cmd1='/sbin/ifconfig -a',
        cmd2='/sbin/ifconfig -a',
    )
    _ansible_module_mock = module
    _ansible_module_mock.run_command = Mock(side_effect=create_side_effect(cmds))
    fact = SunOSNetwork('SunOS')
    interfaces, ips = fact.get_interfaces_info(ifconfig_path='/sbin/ifconfig')

# Generated at 2022-06-11 03:37:24.328750
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_facts = SunOSNetworkCollector()
    assert sunos_facts.platform == 'SunOS'
    assert sunos_facts._fact_class == SunOSNetwork
    assert sunos_facts._platform == 'SunOS'

# Generated at 2022-06-11 03:37:32.528917
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('', (), {'run_command': run_command})()
    ifconfig_path = '/sbin/ifconfig'
    sunos_network = SunOSNetwork()
    (interfaces, ips) = sunos_network.get_interfaces_info(ifconfig_path)
    assert interfaces['lo0']['type'] == 'loopback'
    assert interfaces['lo0']['macaddress'] == '02:01:02:03:04:05'
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1/128'
    assert interfaces['igb0']['type'] == 'ether'

# Generated at 2022-06-11 03:37:46.180634
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = SunOSNetwork()
    current_if = {}
    interfaces = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

# Generated at 2022-06-11 03:37:55.655908
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:38:04.842082
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # set up a dummy module
    module = type('', (), {'run_command': test_SunOSNetwork_run_command})

# Generated at 2022-06-11 03:38:07.533224
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    '''
    Unit test constructor of class SunOSNetworkCollector
    '''
    sunos_network = SunOSNetworkCollector()
    assert sunos_network is not None

# Generated at 2022-06-11 03:38:08.902721
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun = SunOSNetworkCollector()
    assert sun.platform == 'SunOS'

# Generated at 2022-06-11 03:38:09.857347
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:38:18.756328
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # mock module
    module = type('', (), {'run_command': mock_run_command})
    module.run_command.return_value = (0, sunos_ifconfig_all_output, '')

    # Create instance of SunOSNetwork and set platform to 'SunOS'
    # so that get_interfaces_info is called.
    fact_class = SunOSNetwork()
    fact_class.platform = 'SunOS'

    # Set module instance of SunOSNetwork so that it can be called by get_interfaces_info
    fact_class.module = module

    interfaces, ips = fact_class.get_interfaces_info('ifconfig')
    assert 'lo0' in interfaces
    assert 'igb0' in interfaces
    assert 'igb1' in interfaces


# Generated at 2022-06-11 03:38:29.751566
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
        Test get_interfaces_info() in class SunOSNetwork
    """

    ifconfig_path = '/sbin/ifconfig'

    # Assign fixture data
    fixture_file = 'sunos_ifconfig_output.txt'
    fixture_data = []
    with open(fixture_file, 'r') as ff:
        for line in ff.readlines():
            fixture_data.append(line)

    # Assign expected data
    expected_file = 'sunos_ifconfig_expected.py'
    with open(expected_file, 'r') as ef:
        expected_data = eval(ef.read())

    # Create instance of class SunOSNetwork
    sn = SunOSNetwork()
    # call method get_interfaces_info to get interfaces info

# Generated at 2022-06-11 03:38:33.434433
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollector()
    parsed_facts = {}
    if_path = 'tests/unit/module_utils/facts/network/test_data/sunos/ifconfig'
    SunOSNetwork().get_interfaces_info(if_path)

# Generated at 2022-06-11 03:38:43.449186
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = '/usr/sbin/ifconfig'

# Generated at 2022-06-11 03:38:54.125026
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:38:56.068710
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    my_SunOS = SunOSNetworkCollector()
    assert my_SunOS._platform == 'SunOS'

# Generated at 2022-06-11 03:38:59.132970
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector._fact_class == SunOSNetwork
    assert network_collector._platform == 'SunOS'

# Generated at 2022-06-11 03:39:10.414321
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_object = SunOSNetwork()

    mock_module = MagicMock()

# Generated at 2022-06-11 03:39:13.906113
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()

    # Check class var
    assert obj._platform == 'SunOS'

    # Check private var
    assert obj._fact_class.__name__ == 'SunOSNetwork'



# Generated at 2022-06-11 03:39:22.457983
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    fact_class = SunOSNetwork()
    interfaces, ips = fact_class.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'flags' in interfaces['lo0']['ipv4'][0]
    assert 'mtu' in interfaces['lo0']['ipv4'][0]
    assert 'ipv4' in interfaces['lo0']
    assert 'ipv6' in interfaces['lo0']

    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips

# Generated at 2022-06-11 03:39:25.272319
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.fact_class._platform == 'SunOS'
    assert obj._platform == 'SunOS'


# Generated at 2022-06-11 03:39:28.607508
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'

# Generated at 2022-06-11 03:39:39.013742
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModuleMock()

# Generated at 2022-06-11 03:39:48.105538
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('', (object,), dict(params={}, fail_json=lambda x, **y: None))
    # 'ifconfig -a' output from OpenIndiana Hipster

# Generated at 2022-06-11 03:40:12.017665
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class SunOSNetwork."""
    module = type('FakeModule', (object,), {})
    module.run_command = lambda command: (0, '', '')
    network = SunOSNetwork(module=module)

    ifconfig_path = '/usr/sbin/ifconfig'
    test = network.get_interfaces_info(ifconfig_path)

    assert test

# Generated at 2022-06-11 03:40:23.304537
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:40:33.598222
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModuleMock()
    obj = SunOSNetwork(module)
    ifconfig_path = obj.module.get_bin_path('ifconfig')


# Generated at 2022-06-11 03:40:42.044045
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_module = FakeAnsibleModule({
        'ansible_facts': {},
        'ansible_module_args': {},
    })
    test_network = SunOSNetwork(test_module)

    # Method get_interfaces_info returns a tuple
    # we test the contents of the first item (interfaces) in this unit test
    interfaces, _ = test_network.get_interfaces_info(
        '/sbin/ifconfig')

    assert interfaces['lo0']['type'] == 'loopback'
    assert interfaces['lo0']['macaddress'] == 'unknown'
    # Solaris has different FLAGS and MTU for IPv4 and IPv6
    assert len(interfaces['lo0']['ipv4']) == 1
    assert len(interfaces['lo0']['ipv6'])

# Generated at 2022-06-11 03:40:46.449777
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.__class__.__name__ == 'SunOSNetworkCollector'
    assert obj._fact_class.__name__ == 'SunOSNetwork'
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:40:57.274236
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # We pretend the 'ifconfig -a' command returns:
    ifconfig_path = 'ifconfig'

# Generated at 2022-06-11 03:41:08.322256
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    method get_interfaces_info of class SunOSNetwork
    """
    # input data
    # Solaris 10 'ifconfig -a' output
    ifconfig_path = 'bin/unittest_data/sunos/s10_ifconfig_a'
    # expected output
    expected_interfaces = 'bin/unittest_data/sunos/s10_interfaces.json'
    expected_ip = 'bin/unittest_data/sunos/s10_ip.json'

    # run test
    test_obj = SunOSNetwork()
    interfaces, ip = test_obj.get_interfaces_info(ifconfig_path)

    # compare values
    assert interfaces == test_obj.sanitize_interfaces(interfaces)

# Generated at 2022-06-11 03:41:19.161057
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = object()
    setattr(module, 'run_command', fake_get_interfaces_info_run_command)
    sunos_network = SunOSNetwork(module)
    interfaces, ips = sunos_network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0'] == {'device': 'lo0',
                                 'ipv4': [{'mtu': '8232',
                                           'flags': {'IPv4', 'LOOPBACK'}}],
                                 'ipv6': [{'mtu': '8252',
                                           'flags': {'IPv6', 'LOOPBACK'}}],
                                 'type': 'loopback',
                                 'macaddress': '00:00:00:00:00:00'}

# Generated at 2022-06-11 03:41:22.644645
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Constructor of class SunOSNetworkCollector should create variable _fact_class
    # containing reference to class SunOSNetwork
    fact_class = SunOSNetworkCollector()._fact_class
    assert fact_class == SunOSNetwork

# Generated at 2022-06-11 03:41:26.885817
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = dict()
    interfaces = dict()
    ips = dict()
    expected_facts={'interfaces':interfaces,
                    'all_ipv4_addresses':[]
                    }
    collector = SunOSNetworkCollector(facts, 'SunOS')
    assert collector.facts == expected_facts

# Generated at 2022-06-11 03:42:00.797776
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-11 03:42:10.179716
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeAnsibleModule()

# Generated at 2022-06-11 03:42:15.406429
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    set_module_args(dict(gather_subset='!all,!min'))

    my_obj = SunOSNetwork(module)
    interfaces = my_obj.get_interfaces_info('/sbin/ifconfig')

    print('The value of interfaces is:')
    pprint(interfaces)

# Generated at 2022-06-11 03:42:17.294456
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net = SunOSNetworkCollector()
    assert net.facts == 'SunOSNetwork'
    assert net.platform == 'SunOS'

# Generated at 2022-06-11 03:42:22.423258
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    my_sunos = SunOSNetworkCollector()
    assert isinstance(my_sunos, SunOSNetworkCollector)
    assert my_sunos._platform == "SunOS"
    assert ("ansible.module_utils.facts.network.sunos.SunOSNetwork"
            == my_sunos._fact_class.__module__ + "."
            + my_sunos._fact_class.__name__)


# Generated at 2022-06-11 03:42:25.652181
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = MockModule()
    collector = SunOSNetworkCollector(module)
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork
    assert collector.fact_subclass == SunOSNetwork


# Generated at 2022-06-11 03:42:35.506506
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:42:38.729549
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.__class__.__name__ == 'SunOSNetworkCollector'
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:42:48.568776
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # create a dummy module
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    module = GenericBsdNetwork()

    # create a dummy network collector
    net = SunOSNetwork(module)

    # get a properly formatted output of ifconfig
    rc, out, err = module.run_command(['ifconfig', '-a'])

    # get a properly formatted output of netstat
    rc, netstat_out, err = module.run_command(['netstat', '-rn'])

    # test get_interfaces_info output
    interfaces, ips = net.get_interfaces_info('ifconfig')

    # check if the output is properly formatted
    if 'lo0' in interfaces:
        assert 'ipv4' in interfaces['lo0']
        assert 'ipv6'

# Generated at 2022-06-11 03:42:57.819987
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeModule()
    obj = SunOSNetwork()
    interfaces, ips = obj.get_interfaces_info(obj.module.get_bin_path('ifconfig', True))
    assert interfaces['lo0']['macaddress'] == '02:00:00:7f:ff:fa'
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'

# Generated at 2022-06-11 03:44:04.115096
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert isinstance(obj, SunOSNetworkCollector)
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:44:13.512321
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """ If configuring a Solaris system to have different flags and MTU for IPv4/IPv6,
        the facts for interfaces with this dual config should be represented by two
        facts in the 'ipv4' and 'ipv6' lists, but looks messy and hard to read.
        This test configures a system with two NICs, one that has different
        IPv4/IPv6 settings and one which has the same settings.
        It then makes sure that the ipv4/ipv6 facts look good in the output.
    """
    ifplatform = 'SunOS'
    modules_path = '/tmp/ansible_net_tools_testing/'
    ifconfig_path = modules_path + 'fake_ifconfig'
    eth0_path = modules_path + 'eth0.txt'

# Generated at 2022-06-11 03:44:24.080904
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:44:26.114890
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector().fact_class, SunOSNetwork)
    assert SunOSNetworkCollector().fact_class.platform == 'SunOS'

# Generated at 2022-06-11 03:44:35.528814
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:44:40.429931
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos.sunos import SunOSNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    sunos = SunOSNetworkCollector()
    assert type(sunos) is SunOSNetworkCollector
    assert isinstance(sunos, NetworkCollector)
    assert sunos._platform == 'SunOS'

# Generated at 2022-06-11 03:44:42.968494
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.__class__.__name__ == 'SunOSNetworkCollector'



# Generated at 2022-06-11 03:44:44.919533
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert isinstance(obj, SunOSNetworkCollector)

# Generated at 2022-06-11 03:44:54.762567
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:45:04.368621
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    class FakeModule():
      def __init__(self):
        self.params = {}
      def fail_json(self, *args, **kwargs):
        pass
      def run_command(self, cmd):
        if cmd[0] == '/sbin/ifconfig':
            if out == '1':
                return (0, SunOSifconfig_single_interface, '')
            else:
                return (0, SunOSifconfig_many_interfaces, '')
        elif cmd[0] == '/sbin/ipadm':
            return (0, SunOSipadm_many_interfaces, '')
        elif cmd[0] == '/sbin/dladm':
            return (0, SunOSdladm_many_interfaces, '')
        else:
            raise Exception("unexpected command")

