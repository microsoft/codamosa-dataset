

# Generated at 2022-06-11 03:35:59.583735
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Check if SunOSNetworkCollector class is defined
    assert 'SunOSNetworkCollector' in globals()

    # Create an instance of SunOSNetworkCollector class
    sunos_network_collector = SunOSNetworkCollector()

    # Check if instance created successfully
    assert sunos_network_collector is not None

    # Check for the type of instance created.
    assert isinstance(sunos_network_collector, SunOSNetworkCollector)



# Generated at 2022-06-11 03:36:00.681137
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    m = SunOSNetworkCollector()
    assert m.platform == 'SunOS'

# Generated at 2022-06-11 03:36:10.095785
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.sunos import SunOSNetwork
    import json
    import os
    this_dir, this_filename = os.path.split(__file__)
    sample_data_path = os.path.join(this_dir, "sample_data")
    sample_file_name = "sample_SunOS_ifconfig.txt"
    input_path = os.path.join(sample_data_path, sample_file_name)
    file_handle = open(input_path, "r")
    content = file_handle.read()
    file_handle.close()
    sample_data = json.loads(content)
    net = SunOSNetwork()
    net.module = AnsibleModule

# Generated at 2022-06-11 03:36:12.657764
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector._platform == 'SunOS'
    assert network_collector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:36:16.809950
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    ''' Unit test for constructor of class SunOSNetworkCollector '''
    sunos = SunOSNetworkCollector('test')
    assert sunos._fact_class == SunOSNetwork
    assert sunos._platform == 'SunOS'


# Generated at 2022-06-11 03:36:25.555328
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:36:31.730737
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    This is a unit test of testing the constructor of class SunOSNetworkCollector.
    It will create an object of SunOSNetworkCollector and checks if it is created correctly.

    Returns
    -------
    True if the object of SunOSNetworkCollector is created correctly
    """
    collector = SunOSNetworkCollector()
    if collector.platform == 'SunOS':
        return True
    else:
        return False


# Generated at 2022-06-11 03:36:43.859911
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Test data
    test_module = type('TestModule', (object,), dict(run_command=run_command_mock))

    test_module.params = {}

    ifconfig_path = '/sbin/ifconfig'


# Generated at 2022-06-11 03:36:54.457881
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, Mock, MagicMock
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.sunos import SunOSNetwork

    # Tests:
    # - nd6, status, lladdr and media lines
    # - IPv6 interfaces
    # - 'options=' lines (feature-flags, tunnel parameters)
    # - '<device>' lines (vlan, logical interfaces)
    #
    # Not tested:
    # - lines not covered by above
    # - tunnels (iptun, ip.tun0, sit0, gre)
    # - virtual interfaces

# Generated at 2022-06-11 03:36:55.506239
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:37:01.054134
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    inst = SunOSNetworkCollector()
    assert inst.platform == 'SunOS'

# Generated at 2022-06-11 03:37:03.890524
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector._platform == 'SunOS'
    assert network_collector.__class__.__name__ == 'SunOSNetworkCollector'
    assert network_collector.__class__.__bases__ == \
        (NetworkCollector,)

# Generated at 2022-06-11 03:37:16.152783
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:37:26.989222
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MagicMock()

# Generated at 2022-06-11 03:37:36.065399
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})

    ifconfig_path = '/sbin/ifconfig'


# Generated at 2022-06-11 03:37:46.193738
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create a fake module
    module = AnsibleModule(argument_spec={})

    # Create a fake file in the cache dir containing the output of 'ifconfig -a'
    test_file = 'ifconfig_a_SunOS'

# Generated at 2022-06-11 03:37:48.385661
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:37:50.248698
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net = SunOSNetworkCollector()
    assert isinstance(net, SunOSNetworkCollector)


# Generated at 2022-06-11 03:37:51.956844
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:37:55.274406
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test SunOSNetworkCollector"""
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    assert collector.platform == 'SunOS'
    assert collector.fact_class.platform == 'SunOS'


# Generated at 2022-06-11 03:38:03.303917
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector.__doc__



# Generated at 2022-06-11 03:38:13.403051
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:38:23.581013
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Create SunOSNetwork object
    obj = SunOSNetwork()
    # Declare variables
    interfaces = {}
    current_if = {}
    line = 'e1000g0: flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4> mtu 1500 index 2'
    words = line.split()
    # Call function
    current_if = obj.parse_interface_line(words, current_if, interfaces)
    # Assertions
    assert current_if['device'] == 'e1000g0'
    assert current_if['ipv4'][0]['flags'][0] == 'IPv4'
    assert current_if['ipv4'][0]['mtu'] == '1500'

# Generated at 2022-06-11 03:38:26.891152
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.__class__.__name__ == 'SunOSNetworkCollector'
    assert network_collector.platform == 'SunOS'


# Generated at 2022-06-11 03:38:37.493327
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig', True)

# Generated at 2022-06-11 03:38:39.728435
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork

# Generated at 2022-06-11 03:38:49.880547
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    # This is output from 'ifconfig -a' on Solaris 11.4

# Generated at 2022-06-11 03:39:01.379266
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    sun_net = SunOSNetwork()
    ifc_dict = {}
    ifc_name = 'lo0'
    ifc_ipv4_mtu = '1500'
    ifc_ipv4_flags = 'UP,'
    ifc_ipv6_mtu = '1501'
    ifc_ipv6_flags = 'UP,'

# Generated at 2022-06-11 03:39:12.380789
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})

    m_run_command = Mock()

# Generated at 2022-06-11 03:39:14.330300
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Unit test for constructor of class SunOSNetworkCollector"""
    sunos_net = SunOSNetworkCollector()

# Generated at 2022-06-11 03:39:25.011659
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    test_SunOSNetworkCollector_Success(net_collector)
    test_SunOSNetworkCollector_Failure(net_collector)


# Generated at 2022-06-11 03:39:28.766078
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module)
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork
    assert collector.fact_class._platform == 'SunOS'

# Generated at 2022-06-11 03:39:30.139139
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'

# Generated at 2022-06-11 03:39:40.023973
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    class MockModule():
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'min']
            self.run_command = Mock(return_value=(0, SUNOS_IFCONFIG_ALL, ""))

    class Mock(object):
        def __init__(self, *args, **kwargs):
            pass

        def __call__(self, *args, **kwargs):
            return Mock()

        @classmethod
        def __getattr__(cls, name):
            if name in ('__file__', '__path__'):
                return '/dev/null'
            elif name[0] == name[0].upper():
                mockType = type

# Generated at 2022-06-11 03:39:49.078224
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:39:51.120230
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    s = SunOSNetworkCollector()
    assert s.get_facts() == dict()
    assert s.platform == 'SunOS'


# Generated at 2022-06-11 03:40:01.100550
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class SunOSNetwork
    """
    test = "Unit test for method get_interfaces_info of class SunOSNetwork"

# Generated at 2022-06-11 03:40:10.596285
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    # Test output of ifconfig command for Solaris 11.4
    # (one interface with IPv4 and IPv6 addresses)

# Generated at 2022-06-11 03:40:13.545853
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collectors = ('SunOSNetworkCollector',)
    for collector in collectors:
        c = SunOSNetworkCollector()
        assert c.__class__.__name__ == collector


# Generated at 2022-06-11 03:40:24.821079
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class SunOSNetwork"""
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.six import StringIO


# Generated at 2022-06-11 03:40:42.769561
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:40:51.247372
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    This test does 2 things:
    1) Create a SunOSNetwork object
    2) Call get_interfaces_info()
    """
    # This is the test data
    test_data = test_data_SunOS_ifconfig_all

    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    test_obj = SunOSNetwork()
    test_obj.get_interfaces_info('/sbin/ifconfig')


if __name__ == '__main__':
    test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-11 03:41:02.084481
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifc = SunOSNetwork()
    with open('./tests/network/unix/data/interfaces.solaris', 'r') as f:
        out = f.read()
    ifaces, ips = ifc.get_interfaces_info('/sbin/ifconfig')

# Generated at 2022-06-11 03:41:07.035835
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    f = GenericBsdIfconfigNetwork()
    lines = f.test_get_output()
    f.get_interfaces_info(lines)



# Generated at 2022-06-11 03:41:17.932747
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'

# Generated at 2022-06-11 03:41:23.182612
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = {
        "ansible_architecture": "x86_64",
        "ansible_distribution": "SmartOS",
        "ansible_distribution_version": "20170609T183044Z",
    }

    network_facts = SunOSNetworkCollector(facts)
    assert network_facts._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 03:41:31.807933
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunos_net = SunOSNetwork()

    current_if = {}
    interfaces = {}
    words = "lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1".split()

    current_if = sunos_net.parse_interface_line(words, current_if, interfaces)

    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == 'UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL'
    assert current_if['ipv4'][0]['mtu'] == '8232'

# Generated at 2022-06-11 03:41:42.163736
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:41:50.853397
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('ansible.module_utils.facts.network.sunos.SunOSNetwork', (object,), dict(run_command=run_command))()
    module.run_command = run_command

    platform_facts = dict(
        distribution=dict(
            platform='SunOS'
        )
    )

    ifconfig_path = '/sbin/ifconfig'
    if_path = 'ansible/module_utils/facts/network/sunos/ifconfig-a.out'


# Generated at 2022-06-11 03:41:54.178346
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Test for class SunOSNetworkCollector
    module = AnsibleModule(argument_spec=dict())
    actual = SunOSNetworkCollector.get_network_collector(module)
    assert actual.__class__.__name__ == 'SunOSNetworkCollector'
    assert actual._platform == 'SunOS'


# Generated at 2022-06-11 03:42:31.484265
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_collector = SunOSNetworkCollector()
    assert sunos_collector._fact_class == SunOSNetwork
    assert sunos_collector._platform == 'SunOS'

# Generated at 2022-06-11 03:42:34.041859
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == "SunOS"

    collector = SunOSNetworkCollector()
    assert collector.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:42:36.077301
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:42:38.592901
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector._fact_class is SunOSNetwork
    assert collector._platform is 'SunOS'

# Generated at 2022-06-11 03:42:39.995665
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = {}
    SunOSNetworkCollector(facts, None)

# Generated at 2022-06-11 03:42:49.966897
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    ifconfig = SunOSNetwork()
    ifconfig._module = module
    ifconfig.get_interfaces_info('./sunos_ifconfig_output_1.txt')
    interfaces = module.params['ansible_interfaces']
    ips = module.params['ansible_all_ipv4_addresses']
    assert interfaces['lo0']['ipv4'] == [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8232'}]
    assert interfaces['lo0']['ipv6'] == [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8252'}]
    assert interfaces['lo0']['type'] == 'loopback'

# Generated at 2022-06-11 03:42:54.186831
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:42:55.733224
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test to make sure that the test for SunOSNetworkCollector is
    constructed correctly.
    """
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:43:03.572855
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    import json
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    # This is a variant of test_GenericBsdNetwork_get_interfaces_info
    # with the interface 'lo0' from Solaris 10. This is used to test refactoring
    # which makes processing different for Solaris and BSDs.

# Generated at 2022-06-11 03:43:06.953680
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    class FakeModule:
        def __init__(self, params):
            self.params = params
        def fail_json(self, *args, **kwargs):
            pass
    _ansible_module = FakeModule({})
    _network_collector = SunOSNetworkCollector(_ansible_module, ['/sbin/ifconfig'])
    assert isinstance(_network_collector._network, SunOSNetwork)


# Generated at 2022-06-11 03:44:19.708408
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Test 1
    content = '''lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        lo0:1: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 1500 index 1
        inet 172.17.0.1 netmask ffffff00 broadcast 172.17.0.255
        ether 0:1:2:3:4:5
        --
        '''
    m = SunOSNetwork()
    rc, out, err = m.module.run_command(['/bin/true'])

# Generated at 2022-06-11 03:44:29.657085
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from io import BytesIO
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    sunos_obj = SunOSNetwork()
    # If aa option is enabled, the ifconfig will be displayed in aa format.
    sunos_obj.get_formatted_ifconfig = GenericBsdIfconfigNetwork.get_formatted_ifconfig_aa

# Generated at 2022-06-11 03:44:30.954574
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = NetworkCollector()
    assert module.collect() is not None

# Generated at 2022-06-11 03:44:40.561553
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.network.common.utils import get_config

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(
                default=['all'],
                choices=['all', 'interfaces'],
                type='list',
            )
        )
    )

    if not module.get_bin_path('ifconfig'):
        module.fail_json(msg='ifconfig command not found')

    pc = SunOSNetworkCollector(module)
    # Get interfaces info
    interfaces_info, ips = pc.get_interfaces_info('/sbin/ifconfig')


# Generated at 2022-06-11 03:44:50.494764
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = dict(
        ansible_net_interfaces=dict(
            eth0=dict(
                device='eth0',
                ipv4=[
                    dict(ipv4_address='1.2.3.4', ipv4_netmask='255.255.255.0', ipv4_broadcast='1.2.3.255')
                ]
            )
        )
    )

    collector = SunOSNetworkCollector(None, facts)

    # test 'custom_parse_ifconfig_line'
    interfaces, ips = collector.get_interfaces_info('fake')

    assert interfaces['eth0']['device'] == 'eth0'
    assert isinstance(interfaces, dict)

    # test 'custom_parse_ifconfig_line'

# Generated at 2022-06-11 03:44:54.994880
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector().collect()
    assert facts['all_ipv4_addresses']
    assert facts['all_ipv6_addresses']
    assert facts['interfaces']
    assert facts['default_gateway_ipv4']
    assert facts['default_gateway_ipv6']


# Generated at 2022-06-11 03:44:57.809220
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    result = SunOSNetworkCollector.get_network_facts(module)
    assert 'interfaces' in result.keys()


# Generated at 2022-06-11 03:45:01.286650
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts_dict = NetworkCollector.get_network_facts()
    assert isinstance(facts_dict, dict)
    assert isinstance(facts_dict.get('default_ipv4'), dict)
    assert isinstance(facts_dict.get('interfaces'), dict)



# Generated at 2022-06-11 03:45:10.625042
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('', (object,), dict(run_command=lambda self, cmd: (0, '', '')))()
    module.run_command = lambda self, cmd: (0, open('./unit/ansible/module_utils/facts/network/fixtures/SunOS/ifconfig-a').read(), '')
    module.params = dict()
    network = SunOSNetwork(module)
    interfaces, _ = network.get_interfaces_info('/sbin/ifconfig')
    assert "lo0" in interfaces.keys()
    assert "lo0" in interfaces.keys()
    assert "igb0" in interfaces.keys()
    assert "igb1" in interfaces.keys()
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
   

# Generated at 2022-06-11 03:45:11.817472
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._platform == 'SunOS'