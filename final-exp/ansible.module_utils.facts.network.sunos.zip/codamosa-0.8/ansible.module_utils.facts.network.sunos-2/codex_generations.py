

# Generated at 2022-06-11 03:35:50.624201
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(), NetworkCollector)


# Generated at 2022-06-11 03:35:52.366020
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    nc = SunOSNetworkCollector()
    assert nc.platform == 'SunOS'
    assert nc._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:35:59.872335
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.sunos.test.test_SunOSNetwork import get_test_data

    test_data = get_test_data()
    test = SunOSNetwork()
    test_interfaces_info = test.get_interfaces_info("ifconfig")
    interfaces_info = test.get_interfaces_info("ifconfig")

    assert interfaces_info[0]['test0']['ipv4'][0]['address'] == u'10.10.75.102'
    assert interfaces_info[0]['test0']['ipv4'][0]['broadcast'] == u'10.10.75.255'

# Generated at 2022-06-11 03:36:01.265327
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == 'SunOS'

# Generated at 2022-06-11 03:36:10.827608
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-11 03:36:13.438965
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == 'SunOS'
    assert network_collector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:36:23.692660
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    ifc = SunOSNetwork()
    current_if = {}

# Generated at 2022-06-11 03:36:24.264587
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    pass

# Generated at 2022-06-11 03:36:34.982168
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    iface1 = dict(
        device='lo0',
        ipv4=[{'flags': ['LOOPBACK', 'RUNNING', 'MULTICAST'], 'mtu': 8232}, {'flags': ['UP', 'IPv6'], 'mtu': 0}],
        ipv6=[],
        type='loopback',
        macaddress='02:00:00:00:00:00',
    )


# Generated at 2022-06-11 03:36:46.978701
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True,
    )
    # Read ifconfig sample from 'ifconfig_path' file
    ifconfig_path = 'ifconfig_aix'
    ifconfig_file = open(os.path.join(fixture_path, ifconfig_path), 'r')
    interfaces_info, ips = SunOSNetwork(module).get_interfaces_info(ifconfig_file)
    assert len(interfaces_info) == 4
    # Check loopback
    lo0 = interfaces_info.get('lo0')

# Generated at 2022-06-11 03:36:55.237398
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructor of SunOSNetworkCollector should return an object of class SunOSNetworkCollector
    """

    obj = SunOSNetworkCollector

    assert isinstance(obj, SunOSNetworkCollector)

# Generated at 2022-06-11 03:37:03.515216
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    mock_module = MockModule()
    mock_module.run_command.return_value = 1, '', ''

    fact_class_test_obj = SunOSNetwork(mock_module)
    interfaces_info = fact_class_test_obj.get_interfaces_info('path')

    assert 'lo0' in interfaces_info[0]
    assert len(interfaces_info[0]['lo0']['ipv4']) == 2
    assert interfaces_info[0]['lo0']['macaddress'] == '02:00:00:00:00:00'
    assert interfaces_info[0]['lo0']['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-11 03:37:15.790467
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Test SunOSNetwork.get_interfaces_info"""

# Generated at 2022-06-11 03:37:17.372785
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    f = SunOSNetworkCollector()
    assert f.get_facts() == {}

# Generated at 2022-06-11 03:37:28.013973
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Unit test for get_interfaces_info method of SunOSNetwork class."""
    testobj = SunOSNetwork()
    testobj.module.run_command = return_ls_run_command_results

    testobj.get_interfaces_info('/usr/sbin/ifconfig')

    # Note the ipv4 and ipv6 lists of dictionaries each contain two items
    # which need combining. See get_interfaces_info method.

# Generated at 2022-06-11 03:37:28.515518
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    pass

# Generated at 2022-06-11 03:37:30.004117
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:37:39.911336
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.sunos.facts import SunOSNetwork

    # create fake raw output of ifconfig command
    ifconfig_path = '/sbin/ifconfig'

# Generated at 2022-06-11 03:37:42.420634
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:37:52.203219
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = DummyAnsibleModule()

    # test for 'lo0' interface
    lo0 = {
        'device': 'lo0',
        'ipv4': [{'flags': 'UP,LOOPBACK,RUNNING,MULTICAST', 'mtu': '8232'},
                 {'flags': 'UP,LOOPBACK,RUNNING,MULTICAST', 'mtu': '8232'}],
        'ipv6': [],
        'type': 'loopback',
        'macaddress': 'unknown'
        }

    # test for 'igb0' interface

# Generated at 2022-06-11 03:38:04.293044
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Create a SunOSNetworkCollector object
    """
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:38:14.325271
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    module = AnsibleModuleMock(params=dict())
    test_SunOSNetworkInstance = SunOSNetwork(module)

    ifconfig_path = '/sbin/ifconfig'
    test_file = './unit/ansible_module_facts/network/sunos_get_interfaces_info.txt'
    test_file_handle = open(test_file, 'r')
    test_file_content = test_file_handle.read()
    test_file_handle.close()
    rc, out, err = 0, test_file_content, ''

    interfaces, ips = test_SunOSNetworkInstance.get_interfaces_info(ifconfig_path)


# Generated at 2022-06-11 03:38:24.665144
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_network = SunOSNetwork(dict(module=dict(run_command=dict(return_value=1))))
    # When ifconfig -a output line is empty, parse_interface_line should return
    # an empty dictionary.
    assert test_network.parse_interface_line([], {}) == {}
    # When ifconfig -a output line is interface name, parse_interface_line should
    # return a dictionary with the interface name and ipv4/ipv6 lists
    assert test_network.parse_interface_line(['lo0:'], {}) == {'device': 'lo0', 'type': 'unknown', 'ipv4': [], 'ipv6': []}
    # When ifconfig -a output line is interface name, flags, mtu and media,
    # parse_interface_line should return a dictionary with the interface name, ip

# Generated at 2022-06-11 03:38:35.658399
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    kwargs = dict(
        module=dict(
            get_bin_path=lambda x: '/sbin/ifconfig',
            params=dict(gather_subset=['!all', '!min']),
        ),
        executor=dict(
            module_name=__name__,
            module_args=dict(),
        ),
    )
    sunosnetwork = SunOSNetwork(**kwargs)

# Generated at 2022-06-11 03:38:45.888051
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = mock.Mock()
    module.run_command.return_value = (0, SUNOS_IFCONFIG_A, '')
    sunos = SunOSNetwork(module=module)
    interfaces, ips = sunos.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1/128'

# Generated at 2022-06-11 03:38:56.614606
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = 'tests/unit/module_utils/facts/network/SunOS/ifconfig_SunOS'

# Generated at 2022-06-11 03:39:08.328133
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = None
    current_if = {}
    interfaces = {}

    # test interface with IPv4
    words = ['e1000g0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = SunOSNetwork.parse_interface_line(module, words, current_if, interfaces)
    assert current_if['device'] == 'e1000g0'
    assert current_if['type'] == 'unknown'
    assert current_if['ipv4'][0]['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4']
    assert current_if['ipv4'][0]['mtu'] == '1500'

    # test interface with IPv6
    words

# Generated at 2022-06-11 03:39:13.624768
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:39:15.717490
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetwork = SunOSNetworkCollector()
    assert SunOSNetwork._platform == "SunOS"

# Generated at 2022-06-11 03:39:19.399834
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    c = SunOSNetworkCollector()
    assert c.platform == 'SunOS'
    assert c._fact_class.platform == 'SunOS'
    assert issubclass(type(c._fact_class), NetworkCollector)



# Generated at 2022-06-11 03:39:39.094498
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    network = SunOSNetwork()
    current_if = {}
    interfaces = {}
    words = ['e1000g0:', 'flags=201000843', 'mtu', '1500']
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'e1000g0'
    assert current_if['ipv4'][0]['mtu'] == '1500'
    assert current_if['ipv4'][0]['flags'] == '201000843'
    assert current_if['ipv4'][0]['flags'] == '201000843'
    assert len(current_if['ipv6']) == 0
    assert current_if['type'] == 'unknown'
    current_if = {}

# Generated at 2022-06-11 03:39:48.191590
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:39:50.180387
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    s = SunOSNetworkCollector()
    assert isinstance(s._fact_class, SunOSNetwork)
    assert s._platform == 'SunOS'

# Generated at 2022-06-11 03:39:54.510561
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    '''
    Unit test for constructor of class SunOSNetworkCollector
    '''

    facts = SunOSNetworkCollector(None, None, None, None, None).get_facts()
    assert isinstance(facts, dict)
    assert 'SunOSNetworkCollector' in facts['network']


# Generated at 2022-06-11 03:40:03.831867
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork as GenericNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    module = LinuxNetwork.ifconfig_module()
    out = None
    with open('/usr/share/ansible/facts/files/network/sunos_network_output.txt') as fobj:
        out = fobj.read()
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info(ifconfig_path='/sbin/ifconfig')

# Generated at 2022-06-11 03:40:06.921745
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(), NetworkCollector)
    assert SunOSNetworkCollector().platform == 'SunOS'
    assert SunOSNetworkCollector()._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:40:17.128900
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    collector = SunOSNetworkCollector({}, None)
    network = SunOSNetwork({}, collector)

    # some interface tests
    iface = {}
    iface = network.parse_interface_line(['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232'], iface, None)
    assert iface['device'] == 'lo0'
    assert iface['type'] == 'loopback'
    assert iface['ipv4'] == [{'flags': '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu': '8232'}]
    assert iface['ipv6'] == []
    iface = network

# Generated at 2022-06-11 03:40:27.829590
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_SunOSNetwork = SunOSNetwork()
    current_if = None
    test_interfaces = {}
    test_interfaces_result = {
        'lo0': {'device': 'lo0', 'ipv4': [{'mtu': '1500', 'flags': {'UP', 'LOOPBACK'}}],
                'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}
    }

    # Test with IPv4 interface
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = test_SunOSNetwork.parse_interface_line(words, current_if, test_interfaces)
    test_interfaces['lo0'] = current_

# Generated at 2022-06-11 03:40:30.171561
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    result = SunOSNetworkCollector()
    assert result._platform == 'SunOS'
    assert result._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:40:31.608467
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # _get_interfaces_info() is tested in generic_bsd.py
    pass

# Generated at 2022-06-11 03:41:01.218674
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    expected = dict(
        ipv4=[{
            'address': 'fe80::8026:b8ff:fe12:af11',
            'broadcast': 'fe80::ffff:ffff:ffff:ffff',
            'netmask': 'ffff:ffff:ffff:ffff::',
            'prefixlen': '64',
            'scope': 'link'
        }],
        ipv6=[{
            'address': 'fe80::8026:b8ff:fe12:af11',
            'broadcast': 'fe80::ffff:ffff:ffff:ffff',
            'netmask': 'ffff:ffff:ffff:ffff::',
            'prefixlen': '64',
            'scope': 'link'
        }],
        macaddress='none',
        mtu='0',
        type='unknown'
    )

# Generated at 2022-06-11 03:41:12.209955
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:41:21.150559
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    # test data
    line = 'lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1'
    current_if = {}
    interfaces = {}

    # test
    network = SunOSNetwork()
    current_if = network.parse_interface_line(line.split(), current_if, interfaces)

    # verify
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if['type'] == 'loopback'
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-11 03:41:30.580129
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    fixtures = {
        'ifconfig_path': '/sbin/ifconfig',
    }

# Generated at 2022-06-11 03:41:40.935020
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:41:49.912314
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_module = FakeAnsibleModule()
    test_utilities = FakeUtilities()
    test_SunOSNetwork = SunOSNetwork(test_module)

    test_SunOSNetwork.get_interfaces_info(test_module, test_module.run_command, test_utilities.fake_file_exists)

# Generated at 2022-06-11 03:41:56.408543
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    testobj = SunOSNetwork(dict(module=None))
    # testobj.module.run_command returns a tuple with three elements
    # the returncode, stdout and stderr.  The SunOS ifconfig command outputs
    # to stdout so we fill in the third element of the tuple with an empty
    # string.
    testobj.module.run_command = lambda x: (0, x[1], '')
    # Test out/err
    x = testobj.get_interfaces_info('')
    assert len(x) == 2
    # Test out/err with single interface
    test_interfaces = dict(module=None)

# Generated at 2022-06-11 03:42:02.659217
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class SunOSNetwork.
    """
    # Skip if it is not SunOS
    if SunOSNetwork.platform != 'SunOS':
        return


# Generated at 2022-06-11 03:42:03.839018
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    m = SunOSNetworkCollector(None)
    assert m.platform == 'SunOS'

# Generated at 2022-06-11 03:42:04.627197
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:42:54.624589
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    # create an instance of SunOSNetwork class
    network_collector = SunOSNetwork(module)

    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-11 03:42:56.956734
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    os_collector = SunOSNetworkCollector()
    assert os_collector.platform == 'SunOS'
    assert os_collector.fact_class == SunOSNetwork
    assert issubclass(os_collector.fact_class, NetworkCollector)

# Generated at 2022-06-11 03:42:58.848401
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    n = SunOSNetworkCollector()
    assert n._fact_class is SunOSNetwork
    assert n._platform == 'SunOS'

# Generated at 2022-06-11 03:43:07.532484
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ansible_module = AnsibleModule(argument_spec={})
    facts_module = SunOSNetwork(ansible_module)
    facts_module.module.exit_json = lambda x: x

    rc, out, err = ansible_module.run_command(['/sbin/ifconfig', '-a'])
    interfaces_info = facts_module.get_interfaces_info('/sbin/ifconfig')

    assert interfaces_info[0]['lo0']['device'] == 'lo0'
    assert interfaces_info[0]['lo0']['type'] == 'loopback'
    assert interfaces_info[0]['lo0']['ipv4'][0]['mtu'] == '8232'

# Generated at 2022-06-11 03:43:17.202378
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    m = SunOSNetwork()

    # Sample output of 'ifconfig -a' for Solaris 10.
    # Note: Single digit octets in MAC addresses e.g. 0:1:2:d:e:f
    #       and different FLAGS and MTU for IPv4 and IPv6 on the same interface

# Generated at 2022-06-11 03:43:26.779946
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    line = "en0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2"
    words = line.split()
    current_if = {}
    interfaces = {}
    subject = SunOSNetwork()
    subject.parse_interface_line(words, current_if, interfaces)
    assert(current_if == {'device': 'en0', 'ipv4': [{'flags': 'UP,BROADCAST,RUNNING,MULTICAST,IPv4', 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown'})

    line = "en1: flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv6> mtu 1500 index 4"

# Generated at 2022-06-11 03:43:35.496177
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    testobj = SunOSNetwork(None)
    ifconfig_path = 'test/unit/module_utils/network/SunOS/ifconfig'
    interfaces, ips = testobj.get_interfaces_info(ifconfig_path)

    # test number of interfaces
    assert (len(interfaces)) == 2

    # test interface lo0
    iface = interfaces['lo0']

    # test lo0 type is loopback
    assert (iface['type'] == 'loopback')

    # test lo0 number of ipv4 facts is 1
    assert (len(iface['ipv4']) == 1)

    # test lo0 ipv4 fields
    ipv4 = iface['ipv4'][0]
    assert (ipv4['address'] == '127.0.0.1')

# Generated at 2022-06-11 03:43:43.968558
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # create a faked module
    module = type('module', (), dict(exit_json=exit_json))()
    # create a faked class
    sunosnet = type('SunOSNetwork', (), dict(module=module))
    # create a faked run_command, ifconfig -a

# Generated at 2022-06-11 03:43:46.497943
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class.platform == 'SunOS'


# Generated at 2022-06-11 03:43:56.153683
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    for interface in [
        'lo0',
        'net0',
        'net1',
        'net2',
        'net3',
        'net0:1',
        'net2:2',
        'net255:0',
        'net255:1',
        'net255:2',
        'net255:6',
        'net255:7',
        'net255:8',
        'net255:9',
        'net255:10',
        'net255:11',
        'net255:12',
        'net255:13',
        'net255:14',
        'net255:15',
    ]:
        collector = SunOSNetworkCollector()
        iface = SunOSNetworkCollector._fact_class({}, {}, {}, {}, {}, {}, {}, None)

# Generated at 2022-06-11 03:45:22.996725
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = 'sunos/ifconfig.txt'
    with open(ifconfig_path) as f:
        output = f.read()

# Generated at 2022-06-11 03:45:31.482812
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:45:33.127926
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test to see if object is constructed
    """
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-11 03:45:34.117879
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-11 03:45:35.775442
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_inst = SunOSNetworkCollector()
    assert sunos_inst._platform == 'SunOS'


# Generated at 2022-06-11 03:45:43.428084
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # create an empty dictionary
    interfaces = {}
    # create an empty dict for a current interface
    current_if = {}
    # create a dictionary for a single network interface (it will be created)
    words = ['e1000g0:', 'flags=1000842<BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    # test the creation of a network interface with the IPv4 facts only
    current_if = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    iface = current_if['device']
    assert interfaces[iface]['device'] == 'e1000g0'
    assert interfaces[iface]['type'] == 'unknown'
    assert interfaces[iface]['macaddress'] == 'unknown'  # we don't have this fact