

# Generated at 2022-06-11 03:35:59.335372
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    '''
    Constructor test
    '''
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:36:00.990530
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """check if SunOSNetworkCollector class is defined"""
    assert 'SunOSNetworkCollector' in globals()


# Generated at 2022-06-11 03:36:10.464136
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(dict(command='ifconfig -a'))
    sunosifconfig = SunOSNetworkCollector(module=module)
    interfaces, ips = sunosifconfig.get_interfaces_info('/usr/sbin/ifconfig')
    assert set(interfaces.keys()) == set(['lo0', 'net0', 'net1'])
    assert set(ips['all_ipv4_addresses']) == set(['127.0.0.1', '192.168.1.1', '192.168.1.3'])

# Generated at 2022-06-11 03:36:13.819764
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """ test constructor of class SunOSNetworkCollector """
    actual = SunOSNetworkCollector().platform
    assert actual == 'SunOS'
    actual = SunOSNetworkCollector()._fact_class.platform
    assert actual == 'SunOS'


# Generated at 2022-06-11 03:36:23.985135
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos.devices.vi0 import Interface, InterfacesInfo
    # Solaris 10:
    # $ /sbin/ifconfig -a
    # lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
    #   inet 127.0.0.1 netmask ff000000
    # vni0: flags=1100843<UP,BROADCAST,RUNNING,MULTICAST,ROUTER,IPv6> mtu 1500 index 2
    #   inet 10.10.0.20 netmask ffffff00 broadcast 10.10.0.255
    #   inet6 fe80::2a0:a5ff:fef4:4b02%v

# Generated at 2022-06-11 03:36:33.700009
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Creating a class instance
    module = SunOSNetwork()

    # Setting values for testing
    f = open('sample_output/ifconfig_a_Solaris.txt')
    ifconfig_a_output = f.read()
    f.close()

    # Parsing the results
    response = module.get_interfaces_info(ifconfig_a_output)
    interfaces = response['interfaces']
    ips = response['ips']

    # Checking if interfaces is what we expect
    assert isinstance(interfaces, dict)

    # Checking if ips is what we expect
    assert len(ips['all_ipv4_addresses']) == 10
    assert len(ips['all_ipv6_addresses']) == 5

# Generated at 2022-06-11 03:36:45.754507
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ansible_module = mock.MagicMock()
    facts = SunOSNetwork(ansible_module)
    ifconfig_path = facts._module.get_bin_path('ifconfig')
    interfaces, ips = facts.get_interfaces_info(ifconfig_path)
    assert interfaces['hme0']['ipv4'][0]['netmask'] == '192.168.1.0'


if __name__ == '__main__':
    from ansible.module_utils.facts import *
    from ansible.module_utils.facts.network.sunos import *
    from ansible.module_utils.facts.network.sunos import __file__ as sunos_fname
    # Unit test for class SunOSNetwork

# Generated at 2022-06-11 03:36:56.272289
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # 'out' was captured on SunOS 10
    out = """lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        ip6 ::1/128
        ip6 fe80::1:1/10
        ether 8:0:20:2b:a0:6a
        lo0: flags=2002000842<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8252 index 1
        inet6 ::1/128
        ip6 fe80::1:1/10
        ether 8:0:20:2b:a0:6a"""

# Generated at 2022-06-11 03:36:57.941468
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 03:37:07.623444
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test of method parse_interface_line()
    # interface_line is: 'ce1: flags=1100842<BROADCAST,RUNNING,ALLCAST,MULTICAST,NOINET6,NOFAILOVER,IPv4> mtu 1500 index 2'
    interface_line = 'ce1: flags=1100842<BROADCAST,RUNNING,ALLCAST,MULTICAST,NOINET6,NOFAILOVER,IPv4> mtu 1500 index 2'
    words = interface_line.split()
    current_if = {'device': device, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    device = words[0][0:-1]

# Generated at 2022-06-11 03:37:24.531149
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:37:32.660401
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:37:42.993992
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test = SunOSNetwork()

# Generated at 2022-06-11 03:37:52.750033
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Simulate class init
    sunos_network = SunOSNetwork()
    sunos_network.module = type('AnsibleModule', (object,), {'run_command': lambda *a, **kw: (0, '', '')})()

    # Simulate function inputs
    words = ['e1000g1:', 'flags=1000843', 'mtu', '1500']
    current_if = {'device': 'e1000g1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'e1000g1': {'device': 'e1000g1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}

    # Execute function
    sunos_network.parse_interface_line(words, current_if, interfaces)

   

# Generated at 2022-06-11 03:38:01.623876
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    v = 'ipv4'
    current_if = {}
    interfaces = {}
    line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    words = line.split()
    device = words[0][0:-1]
    if device not in interfaces:
        current_if = {'device': device, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    else:
        current_if = interfaces[device]
    flags = '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'
    mtu = '8232'
    current_

# Generated at 2022-06-11 03:38:11.406866
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Make a mock module
    import ansible.module_utils.facts.network.sunos
    import platform

    module = ansible.module_utils.facts.network.sunos.NetworkModule()

    # Set some options
    module.params['gather_subset'] = ['all']

    # Make a mock filesystem
    import os
    import tempfile

    fd, temp_path = tempfile.mkstemp()
    os.close(fd)
    os.remove(temp_path)
    module.tmpdir = temp_path

    # Make a test file
    os.mkdir(temp_path)
    fd, temp_file = tempfile.mkstemp(dir=temp_path, prefix='test_get_interfaces_info_', text=True)

# Generated at 2022-06-11 03:38:14.118022
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert isinstance(collector, SunOSNetworkCollector)
    assert collector.platform == 'SunOS'


# Generated at 2022-06-11 03:38:15.517656
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:38:16.712691
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Test 'platform', 'default_ifconfig_path'
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:38:27.829943
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = FakeModule({})
    sunosnet = SunOSNetwork(module)

    interfaces = {}
    current_if = {}
    current_if = sunosnet.parse_interface_line(['net0:', 'PRIVATE,MULTICAST', 'mtu', '1500'], current_if, interfaces)
    assert current_if.get('device', None) == 'net0'
    assert current_if.get('ipv4', None) == [{'flags': 'PRIVATE,MULTICAST', 'mtu': '1500'}]
    assert current_if.get('ipv6', None) == []
    assert current_if.get('type', None) == 'unknown'
    assert current_if.get('macaddress', None) == 'unknown'

    current_if = sunosnet.parse_interface

# Generated at 2022-06-11 03:38:39.052542
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:38:42.629064
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:38:53.076112
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    test_module = type('module', (object,), {})
    test_module.fail_json = lambda **kwargs: None
    test_module.run_command = lambda **kwargs: ([0, "ifconfig -a output", None])

    test_SunOSNetwork = SunOSNetwork(test_module)

    # Expected output for 'ifconfig -a' command
    # test_ifconfig_a_output
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )


# Generated at 2022-06-11 03:38:55.074310
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector(None, None)._platform == 'SunOS'


# Generated at 2022-06-11 03:38:57.569557
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector()
    assert facts.get_facts() == {}
    assert facts.collect() != {}

# Generated at 2022-06-11 03:39:09.109371
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    class ModuleStub(object):
        def run_command(self, args):
            args = ' '.join(args)
            if args == '/sbin/ifconfig -a':
                return (0, ifconfig_verbose_output, '')
            else:
                raise Exception("'%s' not expected" % args)

    module = ModuleStub()

# Generated at 2022-06-11 03:39:19.763383
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # this test is functional, not unit test
    # TODO: reorganize and extract to test_SunOSNetwork.py
    # TODO: move to more generic place
    # TODO: Parameterize so that it can run on any system, not just mine
    # TODO: Write test to run ifconfig -a with unicode (UTF-8) or non-ascii characters in interface description
    # TODO: Write test to run ifconfig -a with unicode (UTF-8) or non-ascii characters in inet6 address
    # TODO: Write test to run ifconfig -a with long lines (longer than 80 characters)
    # TODO: Write test to run ifconfig -a with long lines (longer than 80 characters)

    from ansible.module_utils.facts.network import SunOSNetwork

# Generated at 2022-06-11 03:39:23.961603
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    ''' ansible.module_utils.facts.network.sunos.SunOSNetworkCollector()'''
    assert (SunOSNetworkCollector(dict(), dict())._platform == 'SunOS'
            ), "Unit test for SunOSNetworkCollector() failed"


# Generated at 2022-06-11 03:39:25.427473
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(),NetworkCollector)


# Generated at 2022-06-11 03:39:36.452296
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils._text import to_bytes
    module = Facts(dict(PATH=[]), None)
    module.run_command = mock_run_command
    ifacenet4 = SunOSNetwork(module, 'SunOS')
    all_interfaces, all_ips = ifacenet4.get_interfaces_info(ifconfig_path='/sbin/ifconfig')
    # All 6 interfaces should be returned.
    assert len(all_interfaces.keys()) == 6
    # Check the 'lo0' interface.
    lo0 = all_interfaces['lo0']
    assert lo0['mtu'] == '2404'

# Generated at 2022-06-11 03:40:08.097717
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:40:10.811119
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:40:15.999225
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    This function is used to unit test method SunOSNetwork.get_interfaces_info()
    """

    # unit tested method input
    ifconfig_path = 'path/to/ifconfig'

    test_SunOSNetwork = SunOSNetwork()

    # unit tested method output
    test_SunOSNetwork.get_interfaces_info(ifconfig_path)



# Generated at 2022-06-11 03:40:17.676198
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = NetworkCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-11 03:40:19.646979
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:40:22.252220
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    words = ['bge0:', 'flags=201000843', 'mtu', '1500', 'index', '4']

    network = SunOSNetwork()
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'bge0'
    assert current_if['ipv4'][0]['mtu'] == '1500'
    assert not current_if['ipv6']

# Generated at 2022-06-11 03:40:25.029441
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sc = SunOSNetworkCollector()
    assert issubclass(sc._fact_class, SunOSNetwork)
    assert sc._platform == 'SunOS'


# Generated at 2022-06-11 03:40:27.123783
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector(None)
    assert obj.__class__.__name__ == 'SunOSNetworkCollector'



# Generated at 2022-06-11 03:40:36.986632
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    import sys
    sys.path.insert(0, 'plugins/modules')
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    facts = SunOSNetwork()
    interfaces, ips = facts.get_interfaces_info('/sbin/ifconfig')

    assert len(interfaces) > 2
    assert len(ips) > 2

    # Tests for the top level facts
    assert 'lo0' in interfaces
    lo0 = interfaces.get('lo0')
    assert lo0.get('device') == 'lo0'
    assert len(lo0.get('ipv4')) == 1
    assert len(lo0.get('ipv6')) == 1
    assert lo0.get('macaddress') == '00:00:00:00:00:00'
    assert lo0.get

# Generated at 2022-06-11 03:40:40.845376
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.facts import collector

    test_obj = SunOSNetworkCollector(None, None, None)
    assert test_obj._fact_class == SunOSNetwork
    assert test_obj._platform == 'SunOS'


# Generated at 2022-06-11 03:41:19.775662
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:41:22.539397
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockModule()
    collector = SunOSNetwork(module=module)
    collector.get_interfaces_info(ifconfig_path='/bin/ifconfig')


# Generated at 2022-06-11 03:41:24.434908
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    my_network = SunOSNetworkCollector()
    assert my_network  # the object should be created


# Generated at 2022-06-11 03:41:26.613430
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collect = SunOSNetworkCollector()
    assert collect.platform == 'SunOS'
    assert collect._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 03:41:33.652231
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:41:42.118386
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    ifcfg = SunOSNetworkCollector(module=module)
    assert ifcfg
    assert isinstance(ifcfg, NetworkCollector)
    assert ifcfg.root_dir is None
    assert ifcfg.files is None
    assert ifcfg.module == module
    assert ifcfg._platform == 'SunOS'
    assert ifcfg.configCache == {}
    assert isinstance(ifcfg._fact_class, SunOSNetwork)


# Generated at 2022-06-11 03:41:45.902263
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    This unit test tests the constructor of the class SunOSNetworkCollector
    """

    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector._fact_class is SunOSNetwork
    assert sunos_network_collector._platform == 'SunOS'


# Generated at 2022-06-11 03:41:48.272893
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    _fact_class = SunOSNetworkCollector()
    assert _fact_class.platform == 'SunOS'
    assert _fact_class.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:41:49.130930
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-11 03:41:55.830522
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:43:16.141758
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    testobj = SunOSNetworkCollector()
    assert testobj._platform == "SunOS"
    assert testobj._fact_class.__name__ == "SunOSNetwork"


# Generated at 2022-06-11 03:43:21.746417
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.facts import Collector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector

    c = Collector()
    n = SunOSNetworkCollector(c)
    assert isinstance(n.get_network_facts(), dict)
    assert isinstance(n._fact_class(), GenericBsdIfconfigNetwork)

# Generated at 2022-06-11 03:43:24.408143
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = FakeAnsibleModule()
    facts = {}
    SunOSNetworkCollector(module, facts)
    assert 'network' in facts


# Generated at 2022-06-11 03:43:30.656868
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos.facts import SunOSNetworkCollector
    from ansible.module_utils.facts.network.sunos.facts import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    SunOSNetworkCollector._fact_class = SunOSNetwork
    SunOSNetworkCollector._platform = 'SunOS'

    object_under_test = SunOSNetworkCollector

    assert object_under_test._fact_class == SunOSNetwork
    assert object_under_test._platform == 'SunOS'
    assert issubclass(object_under_test._fact_class, GenericBsdIfconfigNetwork)

# Generated at 2022-06-11 03:43:34.583101
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert type(collector).__name__ == 'SunOSNetworkCollector'
    assert collector.platform == 'SunOS'
    assert collector.fact_class._platform == 'SunOS'
    assert collector.fact_class.platform == 'SunOS'

# Generated at 2022-06-11 03:43:37.117993
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
	module = get_module_mock()
	n = SunOSNetworkCollector(module)
	assert n.platform == 'SunOS'
	assert n.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:43:38.105793
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-11 03:43:43.802517
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    import os

    class TestModule(object):
        def __init__(self):
            self.run_command_params = None
            self.run_command_rc = 0

# Generated at 2022-06-11 03:43:53.188095
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('FakeModule', (object,), dict(
        params = dict(),
        run_command = lambda self, args: (0, SUNOS_IFCONFIG_OUTPUT, '')
    ))

    interfaces, ips = SunOSNetwork(module).get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0'] == {
        'device': 'lo0',
        'ipv4': [{'flags': 'UP,LOOPBACK,RUNNING', 'mtu': '2048'}],
        'ipv6': [],
        'macaddress': '00:00:00:00:00:00',
        'type': 'loopback'
    }

# Generated at 2022-06-11 03:43:54.389361
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector