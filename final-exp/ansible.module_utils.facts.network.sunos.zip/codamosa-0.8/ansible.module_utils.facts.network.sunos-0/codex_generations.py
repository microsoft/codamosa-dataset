

# Generated at 2022-06-11 03:35:58.556350
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetwork(dict(module_setup=dict(params=dict())))
    current_if = {}

    words = ['ge0:', 'flags=1e080863,c0', '<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'mtu', '1500', 'index']
    current_if = m.parse_interface_line(words, current_if, {})
    assert current_if['device'] == 'ge0'
    assert current_if['type'] == 'unknown'
    assert current_if['ipv4'][0]['mtu'] == '1500'

# Generated at 2022-06-11 03:36:07.601453
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

# Generated at 2022-06-11 03:36:09.223703
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector.fact_class == SunOSNetwork

# Generated at 2022-06-11 03:36:20.005184
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    ifconfig_path = 'module_utils.facts.network.generic_bsd.GenericBsdIfconfigNetwork'
    n = SunOSNetwork(ifconfig_path)
    fake_interfaces = "lo0: flags=200100080149<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1\n"
    fake_interfaces += "     inet 127.0.0.1 netmask ff000000\n"
    fake_interfaces += "e1000g0: flags=2010008010842<UP,RUNNING,SIMPLEX,MULTICAST,IPv4,PHYSRUNNING> mtu 1500 index 2\n"

# Generated at 2022-06-11 03:36:22.569733
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj
    assert isinstance(obj, SunOSNetworkCollector)
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:36:25.934765
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    assert net_collector.__class__.__name__ == 'SunOSNetworkCollector'
    assert net_collector._platform == 'SunOS'
    assert net_collector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:36:26.830924
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:36:29.313404
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    result = SunOSNetworkCollector(module).collect()
    assert result.__class__.__name__ == 'dict'

# Generated at 2022-06-11 03:36:32.592335
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # pylint: disable=protected-access
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-11 03:36:36.495796
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Instantiate class with SunOSNetworkCollector.platform
    sunos_net_clct = SunOSNetworkCollector()
    # Assert the value of _platform
    assert sunos_net_clct._platform == 'SunOS'


# Generated at 2022-06-11 03:36:45.654936
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import TEST_INTERFACES_OUTPUT

    facts = SunOSNetwork().get_interfaces_info(None)
    assert facts == TEST_INTERFACES_OUTPUT

# Generated at 2022-06-11 03:36:47.120987
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)

# Generated at 2022-06-11 03:36:48.954059
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:36:59.188898
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interface = dict()

    net = SunOSNetwork()
    net.parse_interface_line(['lo0', 'UP', 'LOOPBACK', 'IPv6', 'mtu', '8232'], interface, dict())
    assert interface['device'] == 'lo0'
    assert interface['type'] == 'loopback'
    assert interface['ipv4'] == [{'mtu': '8232', 'flags': 'UP LOOPBACK IPv6'}]
    assert interface['ipv6'] == []

    net.parse_interface_line(['lo0', 'UP', 'LOOPBACK', 'IPv6', 'mtu', '8232'], interface, dict())
    assert interface['device'] == 'lo0'
    assert interface['type'] == 'loopback'

# Generated at 2022-06-11 03:37:01.798431
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    '''
    unit test for constructor of class SunOSNetworkCollector
    '''
    my_obj = SunOSNetworkCollector()
    assert isinstance(my_obj, SunOSNetworkCollector) is True

# Generated at 2022-06-11 03:37:13.356646
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:37:20.127154
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from mock import Mock
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector

    module = Mock()
    module.run_command = Mock(return_value=(1, "text", ""))
    snc = SunOSNetworkCollector(module=module)
    assert snc is not None
    assert snc._facter is None
    assert snc._module is module
    assert snc._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:37:30.078774
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # Test with output of ifconfig -a
    print("\n##### Test with output of ifconfig -a #####")

# Generated at 2022-06-11 03:37:32.210195
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector_object = SunOSNetworkCollector()
    assert net_collector_object.platform == 'SunOS'


# Generated at 2022-06-11 03:37:34.093589
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:37:44.824983
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector._fact_class == SunOSNetwork
    assert network_collector._platform == 'SunOS'
    assert network_collector.facts == {}

# Generated at 2022-06-11 03:37:54.411522
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # setup facts
    facts = dict(
        ansible_cmd_line=dict(
            connection='network_cli',
            network_os='SunOS'
        ),
        os=dict(family='Solaris'),
    )

    # setup module
    module = FakeModule()
    module.set_defaults()
    module.params['gather_subset'] = ['']

    # setup /etc/net/interface
    glob = dict(path='/usr/sbin/ifconfig', follow_symlinks='yes')

    # setup /etc/net/interface test output

# Generated at 2022-06-11 03:37:57.114911
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    facts = {}
    network_collector = SunOSNetworkCollector(module)
    result = network_collector.collect(facts, "ifconfig")
    assert result == {'all_ipv4_addresses': [],
                      'all_ipv6_addresses': [],
                      'interfaces': {}}


# Generated at 2022-06-11 03:38:02.400900
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    _SunOSNetworkCollector = SunOSNetworkCollector(dict(), dict())
    assert _SunOSNetworkCollector.facts['network'] == SunOSNetwork
    assert _SunOSNetworkCollector.config == dict()
    assert _SunOSNetworkCollector.facts['default_ipv4']['interface'] == 'eth0'
    assert _SunOSNetworkCollector.facts['default_ipv6']['interface'] == 'eth0'

# Generated at 2022-06-11 03:38:03.630465
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-11 03:38:05.427057
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Unit test to construct a SunOSNetworkCollector object
    """
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:38:15.290193
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class SunOSNetwork"""
    # inputs
    module = MockModule()
    module.run_command = Mock(return_value=(0, sunos_ifconfig_out, None))
    # test the method
    interfaces, ips = SunOSNetwork(module).get_interfaces_info(ifconfig_path='/sbin/ifconfig')
    # results
    assert interfaces == expected_interfaces, 'Expected interfaces is %s, but we got %s' % (expected_interfaces, interfaces)
    assert ips == expected_ips, 'Expected IPs is %s, but we got %s' % (expected_ips, ips)

# input data

# Generated at 2022-06-11 03:38:25.756752
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = None
    path = './utils/network/facts/interfaces'
    obj = SunOSNetworkCollector(module, path)
    interfaces, ips = obj.get_interfaces_info(obj.module, '/sbin/ifconfig')
    for intf, intf_dict in interfaces.items():
        print('%s: %s' % (intf, intf_dict))
        if intf_dict.get('ipv4') and len(intf_dict.get('ipv4')) > 0:
            for ipv4 in intf_dict.get('ipv4'):
                print('\tipv4 %s' % ipv4)

# Generated at 2022-06-11 03:38:30.877409
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Check that constructor works as expected"""

    def my_run_command(self, command):
        """Fake run_command"""
        return 0, '', ''

    module = type('AnsModule', (object,), {
        'run_command': staticmethod(my_run_command)
    })
    SunOSNetworkCollector(module)

# Generated at 2022-06-11 03:38:33.232479
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    assert net_collector.platform == 'SunOS'


# Generated at 2022-06-11 03:39:00.844966
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 03:39:01.484215
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    pass

# Generated at 2022-06-11 03:39:03.033243
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:39:13.441855
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    iface_info = {
        'lo0': {'ether': '0:1:2:3:4:5', 'flags': 'UP,LOOPBACK,RUNNING', 'mtu': '8232',
                'inet': [{'broadcast': '127.255.255.255', 'netmask': '255.0.0.0',
                          'address': '127.0.0.1'}],
                'options': 'options=8000<LOOPBACK,MULTICAST>',
                'type': 'loopback',
                'device': 'lo0'}
    }

# Generated at 2022-06-11 03:39:15.106820
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector
    assert obj._platform == "SunOS"

# Generated at 2022-06-11 03:39:16.615519
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    check = SunOSNetworkCollector()
    assert check.platform == 'SunOS'

# Generated at 2022-06-11 03:39:27.777346
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Arrange
    current_if = {}
    interfaces = {}
    test_words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu 8232', 'index 1']

    # Act
    test_SunOSNetwork = SunOSNetwork()
    current_if = test_SunOSNetwork.parse_interface_line(test_words, current_if, interfaces)

    # Assert
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'

# Generated at 2022-06-11 03:39:38.421003
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:39:47.483463
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test get_interfaces_info of class SunOSNetwork
    """
    net_coll = SunOSNetworkCollector(None)
    sa_net = SunOSNetwork({})
    ifconfig_path = '/sbin/ifconfig'
    interfaces, ips = sa_net.get_interfaces_info(ifconfig_path)

    assert interfaces['lo0']['mtu'] == '8232'
    assert interfaces['lo0']['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'

# Generated at 2022-06-11 03:39:48.438101
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'

# Generated at 2022-06-11 03:40:32.715484
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:40:34.061149
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'


# Generated at 2022-06-11 03:40:35.960275
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact_class = SunOSNetworkCollector(None)

    # Check variables from the base class
    assert fact_class._network_class == SunOSNetwork
    assert fact_class._platform == 'SunOS'

# Generated at 2022-06-11 03:40:36.901073
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:40:37.717373
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()

# Generated at 2022-06-11 03:40:39.308534
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:40:44.319294
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos.plugins.facts.SunOSNetworkCollector import SunOSNetworkCollector
    nc = SunOSNetworkCollector()


# Generated at 2022-06-11 03:40:45.484424
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector().platform == 'SunOS'

# Generated at 2022-06-11 03:40:47.473663
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'


# Generated at 2022-06-11 03:40:48.633697
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:41:57.333896
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollector()
    sunos_network = module.get_network_collector('SunOS', None)
    interfaces, ips = sunos_network.get_interfaces_info('/sbin/ifconfig')
    assert len(interfaces) == 5
    assert len(ips) == 2
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips

# Generated at 2022-06-11 03:42:03.193783
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:42:03.992707
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector(None)

# Generated at 2022-06-11 03:42:14.086924
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    MODULE = 'ansible.module_utils.facts.network.sunos.SunOSNetwork'
    module = type('', (object,), {'run_command': lambda *args, **kwargs: (0, '', '')})
    network = SunOSNetwork(module)
    ifconfig_path = '/sbin/ifconfig'
    interfaces, ips = network.get_interfaces_info(ifconfig_path)

    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert 'UP' in interfaces['lo0']['ipv4'][0]['flags']
    assert 'LOOPBACK' in interfaces['lo0']['ipv4'][0]['flags']

# Generated at 2022-06-11 03:42:17.501839
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:42:21.281033
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = dict()
    assert SunOSNetworkCollector.ignore(facts) == True
    facts['kernel'] = 'FreeBSD'
    assert SunOSNetworkCollector.ignore(facts) == True
    facts['kernel'] = 'SunOS'
    assert SunOSNetworkCollector.ignore(facts) == False


# Generated at 2022-06-11 03:42:30.986284
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = Mock()
    module.run_command = Mock(return_value=(0, ifconfig_a_output, ''))
    SunOSNetwork(module).get_interfaces_info('/sbin/ifconfig')
    expected = [
        call(['/sbin/ifconfig', '-a']),
    ]
    assert module.run_command.call_args_list == expected


# Generated at 2022-06-11 03:42:32.379308
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector()._fact_class(), SunOSNetwork)

# Generated at 2022-06-11 03:42:34.486391
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network = SunOSNetworkCollector()
    assert network.__class__.__name__ == "SunOSNetworkCollector"


# Generated at 2022-06-11 03:42:36.573874
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert issubclass(obj._fact_class, SunOSNetwork)

# Generated at 2022-06-11 03:45:07.011595
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts import collector
    fact_collector = collector.get_collector('SunOSNetwork',None)
    assert(isinstance(fact_collector._fact_class,SunOSNetwork))
    assert(fact_collector._platform == SunOSNetwork._platform)

# Generated at 2022-06-11 03:45:08.408341
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    instance = SunOSNetworkCollector()
    assert instance.platform == 'SunOS'

# Generated at 2022-06-11 03:45:10.343335
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'

# Unit tests for functions in class SunOSNetwork

# Generated at 2022-06-11 03:45:12.958814
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = {}

    fact_class = SunOSNetworkCollector(facts, None, None)
    assert fact_class._fact_class == SunOSNetwork
    assert fact_class._platform == 'SunOS'


# Generated at 2022-06-11 03:45:14.543228
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_network = SunOSNetworkCollector()
    assert sunos_network.platform == 'SunOS'

# Generated at 2022-06-11 03:45:19.302257
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['all']
    module.params['gather_network_resources'] = ['all']
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert len(interfaces) == 5
    assert len(ips) == 2


# Generated at 2022-06-11 03:45:28.289768
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    my_SunOS_Network = SunOSNetwork()
    out = """
lo0: flags=2001000849 mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        inet6 ::1/128
        options=10008 <link,loopback,running,multicast,ipv6>
lo0: flags=2000841<UP,LOOPBACK,RUNNING,MULTICAST,IPv6> mtu 8252 index 1
        options=3<RXCSUM,TXCSUM>
        inet6 ::1/128
        inet 127.0.0.1 netmask ff000000
ether 0:1:2:d:e:f
"""

# Generated at 2022-06-11 03:45:33.266840
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Test for get_interfaces_info
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    ifconfig_path = module.get_bin_path('ifconfig', True)
    nm = SunOSNetwork(module)
    interfaces, ips = nm.get_interfaces_info(ifconfig_path)
    assert 'igb0' in interfaces
    assert 'igb1' in interfaces
    assert len(interfaces) == 2


# Generated at 2022-06-11 03:45:38.215462
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    networkCollector = SunOSNetworkCollector()
    networkCollector.module = AnsibleModule(argument_spec={})
    networkCollector.module.params = {}
    test_line = "lo0:1: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1"
    test_current_if = {}
    test_interfaces = {}
    test_interfaces = networkCollector.facts._fact_class.parse_interface_line(networkCollector.facts, test_line.split(), test_current_if, test_interfaces)
    assert test_interfaces['lo0:1']['device'] == 'lo0:1'

# Generated at 2022-06-11 03:45:39.867527
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'