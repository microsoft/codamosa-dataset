

# Generated at 2022-06-11 03:35:50.021252
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector()
    assert facts._fact_class == SunOSNetwork
    assert facts._platform == 'SunOS'

# Generated at 2022-06-11 03:35:52.239069
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Test with no args - should return None
    assert SunOSNetworkCollector() is None
    # Test with args
    result = SunOSNetworkCollector(None, SunOSNetwork, 'SunOS')
    assert result
    assert result.platform == 'SunOS'

# Generated at 2022-06-11 03:35:53.249500
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(), SunOSNetworkCollector)

# Generated at 2022-06-11 03:35:55.450456
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class.platform == 'SunOS'
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:36:03.158587
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Arrange
    ifconfig_path = 'ifconfig'

# Generated at 2022-06-11 03:36:04.667612
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
  SunOSNetworkCollector()

# Generated at 2022-06-11 03:36:14.317401
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import collector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network import generic_bsd
    test_line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    test_words = test_line.split()
    test_current_if = {'device': 'lo1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

# Generated at 2022-06-11 03:36:18.093437
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)
    c = SunOSNetworkCollector()
    assert c._platform == 'SunOS'
    assert c._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:36:20.008370
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector()
    assert 'SunOSNetwork' == facts._fact_class.platform
    assert 'SunOS' == facts._platform

# Generated at 2022-06-11 03:36:26.106939
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """ Test get_interfaces_info method of SunOSNetwork"""
    sunos_network = SunOSNetwork()

    # ifconfig_path not set.
    interfaces = {}
    ips = {}
    sunos_network.get_interfaces_info('')
    assert interfaces == ips == {}

    # If ifconfig_path is set, then invoke the parent class method get_interfaces_info()
    # because on Solaris this method is not implemented.
    sunos_network.get_interfaces_info('/sbin/ifconfig')

# Generated at 2022-06-11 03:36:33.531021
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'

# Generated at 2022-06-11 03:36:45.590268
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeModule()
    obj = SunOSNetwork(module)
    interfaces, ips = obj.get_interfaces_info('/sbin/ifconfig')
    assert len(interfaces.keys()) == 6
    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['type'] == 'loopback'
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert '127.0.0.1' in interfaces['lo0']['ipv4'][0]['address']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'
    assert interfaces['lo0']['ipv6'][0]['address'] == 'fe80::1%1/10'


# Generated at 2022-06-11 03:36:56.181264
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create a Test Module
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # Set paths to sample ifconfig output.
    ifconfig_path = path.join(test_dir, 'ifconfig_a')
    ifconfig_all_path = path.join(test_dir, 'ifconfig_all')
    ifconfig_em1_path = path.join(test_dir, 'ifconfig_em1')

    # Sample OpenIndiana ifconfig -a output.
    ifconfig_a = open(ifconfig_path, 'r').read()

    # Sample OpenIndiana ifconfig -a output with all interfaces.

# Generated at 2022-06-11 03:36:58.438088
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._platform == 'SunOS'
    assert issubclass(obj._fact_class, SunOSNetwork)
    obj._detect()
    assert obj._facts == {}

# Generated at 2022-06-11 03:37:00.197978
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollector._create_module()
    SunOSNetwork.get_interfaces_info(None, module)



# Generated at 2022-06-11 03:37:02.168104
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork

# Generated at 2022-06-11 03:37:14.050983
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    obj = SunOSNetworkCollector(None)

    # normal output from 'ifconfig -a'

# Generated at 2022-06-11 03:37:17.525807
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_obj = SunOSNetworkCollector()
    assert test_obj
    assert test_obj.platform == 'SunOS'
    assert issubclass(test_obj.network_class, SunOSNetwork)

# Generated at 2022-06-11 03:37:28.149371
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:37:32.981100
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    mod = AnsibleModule(argument_spec={
        'gather_subset': dict(default=[], type='list'),
        'gather_network_resources': dict(default=[], type='list'),
    })
    # run the constructor
    network_collector = SunOSNetworkCollector(mod)
    assert network_collector._platform == 'SunOS'
    assert network_collector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:37:47.790004
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = DummyAnsibleModule()

    ifconfig_path = '/sbin/ifconfig'
    sn = SunOSNetwork(module)
    interfaces, ips = sn.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-11 03:37:48.891061
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:37:57.990437
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:38:07.583530
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Arrange
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['!all'], type='list'),
    })
    # The facts instance should have been created by SunOSNetworkCollector
    # during it's __init__ method.
    facts = module.exit_json.call_args[0][1]['ansible_network_resources']
    # Act
    # Call SunOSNetwork.get_interfaces_info() to populate the
    # 'ansible_network_resources' fact for SunOS.
    facts.populate()
    # Assert
    # Test that get_interfaces_info() produces a sane-looking structure.
    assert 'interfaces' in facts.facts
    assert isinstance(facts.facts['interfaces'], dict)

# Generated at 2022-06-11 03:38:09.991669
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector._fact_class is SunOSNetwork
    assert network_collector._platform is 'SunOS'


# Generated at 2022-06-11 03:38:13.129874
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    results = SunOSNetworkCollector(None, '', {}, [], [], None)
    assert isinstance(results, SunOSNetworkCollector)
    assert isinstance(results.facts, SunOSNetwork)

# Generated at 2022-06-11 03:38:20.602293
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    class Module:
        def run_command(self, cmd):
            return 0, '', ''
    class Facts:
        return_dict = {'ansible_facts': {}}
        def ansible_facts(self):
            return self.return_dict

    module = Module()
    facts = Facts()
    sunos_network = SunOSNetwork(module)
    # Test with IPv4 line
    current_if = {'device': None, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'.split()
    sunos_network.parse_interface_line(words, current_if, {})
    assert current

# Generated at 2022-06-11 03:38:31.744011
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    facter_facts = {}
    facter_facts['kernel'] = 'SunOS'
    facter_facts['kernelrelease'] = '5.11'

    test_module = MockAnsibleModule(facter_facts)

    test_SunOSNetwork = SunOSNetwork(test_module)
    test_SunOSNetwork.get_interfaces_info('/usr/sbin/ifconfig')


# Generated at 2022-06-11 03:38:32.842395
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunCollector = SunOSNetworkCollector()

# Generated at 2022-06-11 03:38:34.264548
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector(None, None, None)


# Generated at 2022-06-11 03:38:44.281679
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    get_interfaces_info_args = dict(
        ifconfig_path='ifconfig',
    )
    network = SunOSNetwork(module=module)
    result = network.get_interfaces_info(**get_interfaces_info_args)
    assert result[0] is not None
    assert result[1] is not None

# Generated at 2022-06-11 03:38:46.495886
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    fc = obj._fact_class
    assert fc._platform == 'SunOS'


# Generated at 2022-06-11 03:38:57.412651
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    interfaces, ips = SunOSNetwork({}, run_command=lambda **kwargs: (0, '', '')).get_interfaces_info(ifconfig_path='/sbin/ifconfig')
    assert len(interfaces.keys()) == 1
    assert interfaces.keys()[0] == 'lo0'
    assert interfaces['lo0']['type'] == 'loopback'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '1280'

# Generated at 2022-06-11 03:39:04.532500
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = 'ansible.module_utils.facts.network.sunos.SunOSNetworkCollector'
    cls = getattr(__import__(module, fromlist=['SunOSNetworkCollector']), 'SunOSNetworkCollector')
    fact_class = getattr(__import__(module, fromlist=['SunOSNetwork']), 'SunOSNetwork')
    fact_collector = cls()
    assert fact_collector._fact_class is fact_class

# Generated at 2022-06-11 03:39:14.830579
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})

# Generated at 2022-06-11 03:39:26.007047
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    ifconfig_path = '/sbin/ifconfig'


# Generated at 2022-06-11 03:39:36.945253
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    import json

    ifconfig_path = 'solaris_ifconfig'
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['!all', 'min'])})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info(ifconfig_path)
    interfaces, facts = network_collector.get_interfaces_facts()


# Generated at 2022-06-11 03:39:45.880844
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollector()
    module.params.update({'gather_subset': ['!all', '!min'], 'gather_network_resources': ['interfaces']})
    ifconfig_path = module.get_bin_path('ifconfig')
    current_if = {}
    interfaces = {}
    with open('./unit/ansible_collections/ansible/community/plugins/module_utils/network/common/fixtures/SunOS/ifconfig_-a') as f:
        for line in f:
            if line.rstrip():
                words = line.rstrip().split()
                if re.match(r'\S', line) and len(words) > 3:
                    current_if = module.parse_interface_line(words, current_if, interfaces)
                    interfaces[current_if['device']]

# Generated at 2022-06-11 03:39:47.568276
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:39:49.554820
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork

# Generated at 2022-06-11 03:40:01.935504
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector().collect()
    assert 'devices' in facts['ansible_net_interfaces']
    assert 'ipv4' in facts['ansible_net_interfaces']
    assert 'ipv6' in facts['ansible_net_interfaces']
    assert 'all_ipv4_addresses' in facts['ansible_all_ipv4_addresses']
    assert 'all_ipv6_addresses' in facts['ansible_all_ipv6_addresses']

# Generated at 2022-06-11 03:40:03.920756
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    a = SunOSNetworkCollector()
    assert a.__class__.__name__ == 'SunOSNetworkCollector'


# Generated at 2022-06-11 03:40:08.479812
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    collector = SunOSNetworkCollector(module=module)
    output = collector.get_interfaces_info('/sbin/ifconfig')
    # Just print the output for now.
    print(output)


# for testing purposes

# Generated at 2022-06-11 03:40:09.821411
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test SunOSNetworkCollector class"""
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:40:11.803050
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:40:23.043590
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # create test data
    ifconfig_path = '/usr/bin/ifconfig'
    interfaces = {}
    current_if = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    # create test object
    test_object = SunOSNetwork(None)
    # call method to test
    current_if = test_object.parse_interface_line(words, current_if, interfaces)
    # check results

# Generated at 2022-06-11 03:40:33.321929
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    lines = list()
    lines.append('lo0:8: mtu 8232 index 1')
    lines.append('    inet 127.0.0.1 netmask ff000000 broadcast 127.255.255.255')
    lines.append('    options=200003<LOOPBACK,MULTICAST,IPv4>')
    lines.append('    status=active')
    words = lines[0].split()
    current_if = {}
    interfaces = dict()
    ips = dict()
    expected_interfaces = dict()

# Generated at 2022-06-11 03:40:41.608456
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Runs the NetworkCollector unit tests
    """
    collector = SunOSNetworkCollector()
    collector.collect()
    facts = collector.get_facts()
    interfaces = facts['interfaces']
    assert 'lo0' in interfaces
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces['lo0']['ipv6'][0]['prefix'] == '128'
    fact_names = facts.keys()
    assert 'all_ipv4_addresses' in fact_names

# Generated at 2022-06-11 03:40:53.481685
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = DummyModule()
    sunos_network = SunOSNetwork(module)

    interfaces = {}
    current_if = sunos_network.parse_interface_line(['bge0:', 'flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS>', 'mtu=1500', 'index=4', 'inet6'], current_if, interfaces)
    assert current_if['device'] == 'bge0'
    assert current_if['ipv4'] == [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4', 'CoS'], 'mtu': '1500'}]
    assert current_if['ipv6'] == []
    assert current_if['type'] == 'unknown'
   

# Generated at 2022-06-11 03:41:04.307939
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})

    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info(network.ifconfig_path)

    # Create expected results
    expected_interfaces = {'lo0': {
        'device': 'lo0',
        'ipv4': [{'broadcast': '127.255.255.255', 'netmask': '255.0.0.0', 'network': '127.0.0.0'}],
        'ipv6': [{'scope': 'host', 'address': '::1'}],
        'macaddress': 'unknown',
        'type': 'loopback'
    }}


# Generated at 2022-06-11 03:41:10.454282
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fc = SunOSNetworkCollector(None)
    assert fc._fact_class is SunOSNetwork

# Generated at 2022-06-11 03:41:15.360995
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test if SunOSNetworkCollector is instantiated correctly.
    """
    fact_class = 'ansible.module_utils.facts.network.sunos.SunOSNetwork'
    network_collector = SunOSNetworkCollector(None, None, None, None)

    assert network_collector._fact_class == fact_class
    assert network_collector._platform == 'SunOS'

# Generated at 2022-06-11 03:41:26.293107
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:41:26.893767
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:41:35.384707
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:41:37.229577
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:41:40.355319
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    assert net_collector._fact_class == SunOSNetwork
    assert net_collector._platform == 'SunOS'

# Generated at 2022-06-11 03:41:43.178607
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    c = SunOSNetworkCollector()
    assert c.platform == 'SunOS'


# Generated at 2022-06-11 03:41:51.649340
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:41:59.194691
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:42:12.717854
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:42:13.963852
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'



# Generated at 2022-06-11 03:42:14.804970
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:42:16.447213
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert(isinstance(obj, NetworkCollector))


# Generated at 2022-06-11 03:42:25.565971
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

# Generated at 2022-06-11 03:42:35.460511
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    net = SunOSNetwork()
    net.module = MagicMock()
    net.module.run_command.return_value = (0, '', '')
    words = ['e1000g0:', 'flags=1000842<BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = {}
    interfaces = {}
    current_if = net.parse_interface_line(words, current_if, interfaces)
    assert current_if['ipv4'] == [dict(flags=['BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4'], mtu='1500')]
    assert current_if['device'] == 'e1000g0'
    assert current_if['ipv6'] == []
    assert not 'ether' in current_

# Generated at 2022-06-11 03:42:45.645655
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:42:53.548203
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    def mock_module_args(version=None):
        return dict(
            gather_subset=[],
            config_file='/whatever',
            load_on_init=False,
        )

    def mock_module_fail_json(failed=False, msg=''):
        pass

    for version in ('6.0', '6.1', '6.2', '6.3', '6.4', '6.5', '6.6'):
        collector = SunOSNetworkCollector(mock_module_args(version),
                                          mock_module_fail_json)
        assert collector.platform == 'SunOS'

# Generated at 2022-06-11 03:42:55.493758
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'


# Generated at 2022-06-11 03:42:59.686127
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = SunOSNetworkCollector._get_module_mock()
    module.params['gather_subset'] = 'all'
    module.run_command.return_value = (1, 'test_out', 'test_err')
    facts = SunOSNetworkCollector._get_facts(module)
    assert facts['all_ipv4_addresses'] == []
    assert facts['all_ipv6_addresses'] == []

# Generated at 2022-06-11 03:43:26.705004
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict(gather_subset=dict(type='list', default=['!all', '!min'])))

    mock_module = MagicMock(return_value=dict(rc=0, stdout=SUNOS_IFCONFIG_ALL_1, stderr=''))
    with patch.dict(sunos_network.__dict__, {'AnsibleModule': mock_module}):
        interfaces, ips = sunos_network.get_interfaces_info('/sbin/ifconfig')


# Generated at 2022-06-11 03:43:28.685276
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert isinstance(obj, NetworkCollector)
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:43:37.517820
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch, MagicMock
    from ansible_collections.ansible.netcommon.plugins.module_utils.facts.facts import FactManager
    from ansible_collections.ansible.netcommon.plugins.module_utils.facts.network.sunos import SunOSNetwork

    class TestSunOSNetwork(unittest.TestCase):

        def setUp(self):
            self.facts = FactManager()
            self.facts['ansible_network_resources'] = {}
            self.network = SunOSNetwork()
            self.network.module = MagicMock()
            self.network.module.get_bin_path = MagicMock

# Generated at 2022-06-11 03:43:39.815439
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    '''
    Unit tests for SunOSNetworkCollector.
    '''
    collector = SunOSNetworkCollector
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'

# Generated at 2022-06-11 03:43:43.049828
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    try:
        collector = SunOSNetworkCollector()
        # test that object is of the SunOSNetworkCollector class
        assert isinstance(collector,SunOSNetworkCollector)
    except Exception:
        assert False


# Generated at 2022-06-11 03:43:52.664246
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """ Unit test for method get_interfaces_info of class SunOSNetwork """
    # check that the output of the ifconfig command is parsed correctly
    # and the result is used to create the expected dictionary
    data = """
lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
lo0: flags=2002000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8252 index 1
        inet6 ::1/128
ether 0:1:2:3:4:5
"""
    module = FakeAnsibleModule()
    network = SunOSNetwork(module=module)
    ifaces, ips

# Generated at 2022-06-11 03:44:02.761339
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos.legacy import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    assert issubclass(SunOSNetwork, GenericBsdIfconfigNetwork)

    net = SunOSNetwork([], {}, {}, [])


# Generated at 2022-06-11 03:44:12.075683
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # set up objects
    testobj = SunOSNetwork()
    # set up module
    testmod = DummyModule()
    # set up facts module
    testfacs = DummyFactsModule()
    # assign module to NetworkCollector object
    testobj.module = testmod
    # assign facts module to NetworkCollector object
    testobj.facts = testfacs
    # define netstat output

# Generated at 2022-06-11 03:44:14.520546
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Create an instance of NetworkCollector
    """
    net_collector = SunOSNetworkCollector()
    assert net_collector.platform == 'SunOS'

# Generated at 2022-06-11 03:44:15.560673
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:44:51.757047
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert NetworkCollector.__subclasshook__(SunOSNetworkCollector) is True


# Generated at 2022-06-11 03:44:55.444848
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = FakeAnsibleModule()
    network_collector = SunOSNetworkCollector(module=module)
    assert network_collector._platform == 'SunOS'
    assert network_collector._fact_class == SunOSNetwork

# Unit tests for the class SunOSNetwork

# Generated at 2022-06-11 03:44:56.769294
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Unit test for constructor of class SunOSNetworkCollector"""
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:45:06.124639
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:45:15.180944
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    We need to define the input and expected output of this method
    because the Solaris ifconfig output is language specific.
    """
    module = {
        'run_command': run_command_mock,
        'fail_json': fail_json_mock,
        'warn': warn_mock
    }
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['net0']['device'] == 'net0'
    assert interfaces['net0']['type'] == 'ether'
    assert interfaces['net0']['mtu'] == 1500
    assert interfaces['net0']['macaddress'] == '01:23:45:67:89:ab'

# Generated at 2022-06-11 03:45:24.316769
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:45:27.587332
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Unit test SunOSNetworkCollector object creation
    """
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork, 'obj._fact_class should be SunOSNetwork'
    assert obj._platform == 'SunOS', 'obj._platform should be SunOS'

# Generated at 2022-06-11 03:45:29.665070
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    nc = SunOSNetworkCollector()
    assert nc.platform == 'SunOS'
    assert nc.module.check_mode is False


# Generated at 2022-06-11 03:45:31.873666
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Create instance of class SunOSNetworkCollector
    my_obj = SunOSNetworkCollector()
    # Check if the created object is an instance of the class NetworkCollector
    assert isinstance(my_obj, NetworkCollector)

# Generated at 2022-06-11 03:45:33.297862
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test1 = SunOSNetworkCollector(None)
    assert test1 is not None
