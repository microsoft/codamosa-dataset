

# Generated at 2022-06-11 03:35:48.915320
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """ Returns a SunOSNetworkCollector object. """

    return NetworkCollector.collector['SunOS']['default']()

# Generated at 2022-06-11 03:35:52.397354
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    with_fact_class = SunOSNetworkCollector(None, None, None, None, None)
    assert with_fact_class._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._platform_options is None

# Generated at 2022-06-11 03:35:54.261835
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Check whether SunOSNetworkCollector instance can be created."""
    net_collector = SunOSNetworkCollector()
    assert net_collector._platform == 'SunOS'



# Generated at 2022-06-11 03:35:57.083414
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructor of SunOSNetworkCollector should create object
    of class SunOSNetworkCollector
    """
    sunos_network_collector = SunOSNetworkCollector()
    assert isinstance(sunos_network_collector, SunOSNetworkCollector)

# Generated at 2022-06-11 03:36:05.794471
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Initialize SunOSNetwork object
    ifconfig_path = '/sbin/ifconfig'
    sun = SunOSNetwork(dict(module=dict(run_command=None)), ifconfig_path)

    # Get sample interfaces output from Solaris 13 (5.11)
    # They differ from Solaris 11 and earlier.
    sample_file = open("SunOSNetwork_get_interfaces_info.sample")
    sample_text = sample_file.read()
    sample_file.close()

    # Execute get_interfaces_info
    interfaces, ips = sun.get_interfaces_info(ifconfig_path)

    # Verify interfaces output

# Generated at 2022-06-11 03:36:16.071486
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    mock_module = MockModule()
    mock_module.run_command.return_value = 1, interface_data, ""
    interfaces = SunOSNetwork(mock_module).get_interfaces_info('/sbin/ifconfig')

    assert interfaces['lo0']['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv4'] == [{'address': '127.0.0.1', 'netmask': '255.0.0.0', 'broadcast': '127.255.255.255'}]
    assert interfaces['lo0']['ipv6'] == [{'address': '::1', 'netmask': 'ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff', 'broadcast': '::1'}]

# Generated at 2022-06-11 03:36:23.910371
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('AnsibleModule', (object,), {})()
    module.run_command = lambda x: (0, '', '')
    obj = SunOSNetwork(module)

    # Test override of the platform.
    obj.platform = 'Solaris'
    assert obj.platform == 'Solaris'     # platform property can be overridden

    # Test get_interfaces_info() method
    ret = obj.get_interfaces_info('')
    assert ret[0] == {}, ret[0]
    assert ret[1] == {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}, ret[1]

# Generated at 2022-06-11 03:36:24.824720
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()


# Generated at 2022-06-11 03:36:35.764090
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    class TestModule(object):
        def run_command(self, command):
            return 0, test_data, ''


# Generated at 2022-06-11 03:36:38.648614
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network = SunOSNetworkCollector()
    assert network._platform == 'SunOS'
    assert network._fact_class == SunOSNetwork
    assert network._config == {}

# Generated at 2022-06-11 03:36:55.132649
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Setup
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module)
    network_collector._detect_os_version = Mock(return_value="5.11")
    network_collector._get_ifconfig_path = Mock(return_value='/sbin/ifconfig')

    # Test
    interfaces, ips = network_collector.get_interfaces_info('/sbin/ifconfig')
    # Check interfaces
    assert_equal(interfaces['lo0']['device'], 'lo0')
    assert_equal(interfaces['lo0']['ipv4'][0]['flags'], ['UP', 'LOOPBACK', 'RUNNING'])

# Generated at 2022-06-11 03:37:00.483966
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    module = AnsibleModule(argument_spec={})

    ifconfig_path = '/sbin/ifconfig'
    MySunOSNetworkTestObject = SunOSNetwork(module)
    MySunOSNetworkTestObject.get_interfaces_info(ifconfig_path)
    result = MySunOSNetworkTestObject.get_interfaces_info(ifconfig_path)

    assert result != None, "Failed to get interfaces_info"


# Generated at 2022-06-11 03:37:11.225675
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

# Generated at 2022-06-11 03:37:15.038142
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_net_facts = SunOSNetworkCollector()
    assert sun_net_facts._fact_class == SunOSNetwork
    assert sun_net_facts._platform == 'SunOS'

# Generated at 2022-06-11 03:37:17.526286
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._platform == "SunOS"
    assert obj._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:37:28.149527
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    '''
    is known to work on OmniOSce r151006 and SmartOS 20161025T021236Z
    '''
    module = AnsibleModuleMock(
        dict(
            ansible_facts=dict(
                ansible_net_interfaces=dict(),
                ansible_net_all_ipv4_addresses=[],
                ansible_net_all_ipv6_addresses=[],
            )
        )
    )
    net = SunOSNetwork(module)

# Generated at 2022-06-11 03:37:37.654690
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})

    # Create instance of SunOSNetwork class
    fact_class = SunOSNetwork(module)

    ''' Unit Tests:
        ifconfig -a output has been tested on Solaris 10 and 11 x86.
        Should work on Sparc as well.
    '''
    ifconfig_path = '/usr/sbin/ifconfig'

# Generated at 2022-06-11 03:37:40.309185
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module)
    assert network_collector.platform == 'SunOS'


# Generated at 2022-06-11 03:37:41.432830
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()


# Generated at 2022-06-11 03:37:51.314655
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    ifconfig_path = '/sbin/ifconfig'

    # Test data

# Generated at 2022-06-11 03:38:06.923155
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector.platform == 'SunOS'
    assert sunos_network_collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 03:38:09.085450
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform is not None
    assert SunOSNetworkCollector._fact_class is not None


# Generated at 2022-06-11 03:38:12.140389
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    assert collector._platform == 'SunOS'
    assert isinstance(collector.get_all_facts(), dict)

# Generated at 2022-06-11 03:38:13.009596
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:38:22.810377
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # Module input parameters
    params = {
        'gather_subset': ['!all', '!min'],
        'gather_network_resources': ['interfaces'],
    }

    testobj = SunOSNetwork(params=params)

    # input for get_interfaces_info
    ifconfig_path = './unit_tests/SunOS/input/ifconfig.txt'

    # output of get_interfaces_info
    (interfaces, ips) = testobj.get_interfaces_info(ifconfig_path)
    assert interfaces['bge0']['ipv4'] == [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST'], 'mtu': '1500'}]

# Generated at 2022-06-11 03:38:34.131933
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['!all', 'network'])})
    network = SunOSNetworkCollector(module=module)
    interfaces, ips = network.get_interfaces_info('/usr/sbin/ifconfig')

    # Test for expected interfaces.
    assert 'net0' in interfaces
    assert 'lo0' in interfaces
    # lo0 should show as a loopback interface
    assert interfaces['lo0']['type'] == 'loopback'

    # Test for expected combined ipv4 and ipv6 attributes.
    assert 'inet' in interfaces['net0']
    assert 'inet6' in interfaces['net0']

    # Test ipv4 flags and mtu and ipv6 flags and mtu

# Generated at 2022-06-11 03:38:36.283558
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:38:46.543265
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = {
    }

    obj = SunOSNetwork()
    obj.module = module
    obj.module.params = {'gather_network_resources': 'all'}
    obj.module.run_command = MagicMock(return_value=(0, sunos_ifconfig_output, ""))

    interfaces, ips = obj.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['macaddress'] == '00:00:00:00:00:00', interfaces['lo0']['macaddress']
    assert interfaces['lo0']['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'

# Generated at 2022-06-11 03:38:57.462586
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)
    network_collector = SunOSNetworkCollector(
        module=module,
        params=dict())
    # 'ifconfig -a' example from SmartOS

# Generated at 2022-06-11 03:39:02.116403
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector()
    # The class SunOSNetworkCollector is an instance of SunOSNetwork
    assert isinstance(facts, SunOSNetwork)
    # The class SunOSNetworkCollector is an instance of NetworkCollector
    assert isinstance(facts, NetworkCollector)


# Generated at 2022-06-11 03:39:32.686088
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test get_interfaces_info method of SunOSNetwork class
    """
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list'),
            'gather_network_resources': dict(default=['all'], type='list')
        },
    )
    base_class_instance = NetworkCollector(module=module)
    subclass_instance = SunOSNetwork(base_class_instance)

# Generated at 2022-06-11 03:39:36.726766
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    '''
    This function is a unit test for the constructor of the class SunOSNetworkCollector.
    '''
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector._fact_class is SunOSNetwork
    assert sunos_network_collector._platform == 'SunOS'

# Generated at 2022-06-11 03:39:40.836719
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = MagicMock()
    module.params = {}
    nc = SunOSNetworkCollector(module)

    assert nc.fact_class._platform == 'SunOS'
    assert nc.fact_class._fact_class == nc.fact_class
    assert nc.fact_class.platform == 'SunOS'

# Generated at 2022-06-11 03:39:45.870828
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MagicMock()
    module.run_command.return_value = (0, OUTPUT_IFCONFIG_A, '')
    ifconfig_path = '/sbin/ifconfig'
    fact_class = SunOSNetwork(module)

    fact_class._get_interfaces_info(ifconfig_path)

    actual_result = module.fail_json.mock_calls

    assert actual_result == []

# Generated at 2022-06-11 03:39:48.655697
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_n = SunOSNetworkCollector(None)
    assert sunos_n.platform == "SunOS"
    assert sunos_n._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:39:49.553982
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    pass



# Generated at 2022-06-11 03:39:51.835410
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact_class = SunOSNetworkCollector
    fact_instance = fact_class()
    assert fact_instance._platform == 'SunOS'

# Generated at 2022-06-11 03:39:54.180651
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.__class__.__name__ == 'SunOSNetworkCollector'

# Generated at 2022-06-11 03:39:57.366646
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    expected = SunOSNetworkCollector()
    result = SunOSNetworkCollector()
    assert type(result) == type(expected)
    assert result._fact_class == expected._fact_class
    assert result._platform == expected._platform

# Generated at 2022-06-11 03:40:06.973691
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_int = SunOSNetwork()
    cmd = ['ifconfig', '-a']
    rc = 0

# Generated at 2022-06-11 03:40:47.003861
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == "SunOS"
    assert obj._fact_class.platform == "SunOS"
    assert obj._fact_class.__name__ == "SunOSNetwork"
    assert obj.get_facts() is None

# Generated at 2022-06-11 03:40:54.928907
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test SunOSNetworkCollector object creation
    """
    # Patch Ansible module object
    module = MockModule()

    # Test normal instantiation
    nc = SunOSNetworkCollector(module=module)
    assert nc.module == module
    assert nc.platform == 'SunOS'

    # Test parent class instantiation
    nc = NetworkCollector(module=module)
    assert nc.module == module
    assert nc.fact_class == None
    assert nc.platform == None

# Unit test class for SunOSNetworkCollector

# Generated at 2022-06-11 03:41:05.863082
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    fake_module = get_fake_module_for_network_module('Solaris')
    fake_module.params['gather_subset'] = ['!all']
    fake_module.params['gather_network_resources'] = ['interfaces']
    module = fake_module


# Generated at 2022-06-11 03:41:16.592519
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    SunOSNetwork._get_interfaces_info = SunOSNetwork.get_interfaces_info
    module = AnsibleModule(argument_spec=dict())
    setattr(module, 'run_command', lambda *_args, **_kwargs: (0, '', ''))
    setattr(module, 'get_bin_path', lambda *_args, **_kwargs: '')
    network_collector = SunOSNetwork(module)

    # test simple output

# Generated at 2022-06-11 03:41:19.442635
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    assert net_collector._fact_class == SunOSNetwork
    assert net_collector._platform == 'SunOS'


# Generated at 2022-06-11 03:41:21.725877
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:41:30.967883
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.facts.network.sunos import SunOSNetwork

    ifconfig_path = 'fake_ifconfig_sunos'
    module = FakeModule(ifconfig_path=ifconfig_path)
    # Create an instance of SunOSNetwork to avoid check of platform.
    sunos_network = SunOSNetwork()
    sunos_network.module = module

    # Expected output of 'ifconfig -a'.

# Generated at 2022-06-11 03:41:32.011709
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()

# Generated at 2022-06-11 03:41:34.107817
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    d = SunOSNetworkCollector()
    assert d.platform == 'SunOS'
    assert d.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:41:44.365173
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # There must be 6 items in words for the test to pass
    words = [str(x) for x in range(0, 6)]
    words[1] = 'Test_flags_1'
    words[3] = 'Test_mtu_1'
    current_if = {'device': 'Test_device_1'}
    interfaces = {'Test_device_1': {'device': 'Test_device_1',
                                    'ipv4': [{'flags': 'Test_flags_1', 'mtu': 'Test_mtu_1'}],
                                    'ipv6': ['Test_ipv6_1'],
                                    'type': 'Test_type_1',
                                    'macaddress': 'Test_macaddress_1'
                                    }}
    sunos_network = SunOSNetwork()
   

# Generated at 2022-06-11 03:43:04.335236
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = get_ansible_module()
    mocker = AnsibleMock(module)
    mocker.mock_module_results(ifconfig_path='/usr/bin/ifconfig')
    test_ifconfig_output = open(os.path.join(os.path.dirname(__file__), 'SunOS_ifconfig_output.txt')).read()
    mocker.mock_command(ifconfig_path='/usr/bin/ifconfig', args=['/usr/bin/ifconfig', '-a'], rc=0, stdout=test_ifconfig_output, stderr='')
    interfaces = SunOSNetwork().get_interfaces_info('/usr/bin/ifconfig')

# Generated at 2022-06-11 03:43:13.587868
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeAnsibleModule()

    # Check with good input

# Generated at 2022-06-11 03:43:23.675662
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    test_case = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu 8232', 'index 1', 'inet 127.0.0.1 netmask ff000000']
    SunOSNetwork().parse_interface_line(test_case, current_if, interfaces)
    assert (current_if == {'device': 'lo0', 'type': 'loopback', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL'], 'mtu': '8232'}], 'ipv6': [], 'macaddress': 'unknown'})

# Generated at 2022-06-11 03:43:30.817556
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.misc.not_a_real_collection.plugins.modules.network.os import SunOSNetwork
    from ansible.module_utils.facts.collector import FactsCollector

    # the raw data returned by the module

# Generated at 2022-06-11 03:43:31.798308
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:43:33.177057
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-11 03:43:34.394028
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = FakeAnsibleModule()
    result = SunOSNetworkCollector.collect(module)
    assert result is not None


# Generated at 2022-06-11 03:43:36.653465
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'
    assert obj._counter == 1

# Generated at 2022-06-11 03:43:40.257351
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleFake({})
    network_collector = SunOSNetworkCollector(module)
    assert network_collector.__class__.__name__ == 'SunOSNetworkCollector'
    assert network_collector._fact_class.__class__.__name__ == 'SunOSNetwork'
    assert network_collector._fact_class.platform == 'SunOS'


# Generated at 2022-06-11 03:43:50.181537
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    This test is not a unit test but is a full test of method get_interfaces_info of class SunOSNetwork
    It uses the interface config file /etc/ifconfig.lo0.2 as input and compares the resulting
    dictionary interfaces with a golden dictionary.
    """

    # Set Input vars
    ifconfig_path = '/bin/ifconfig'
    interface_file = '/etc/ansible/facts/network/SunOS-ifconfig.lo0.2'

    # Set golden vars
    golden_interfaces_file = '/etc/ansible/facts/network/SunOS-interfaces.lo0.2'
    golden_ips_file = '/etc/ansible/facts/network/SunOS-ips.lo0.2'

    # Set collected vars