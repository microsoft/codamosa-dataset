

# Generated at 2022-06-11 03:36:01.191101
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:36:02.018472
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:36:07.061175
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, '', '')
    sunos_network = SunOSNetwork(mock_module)
    sunos_network.get_interfaces_info('ifconfig')
    mock_module.run_command.assert_called_with(['ifconfig', '-a'])


# Generated at 2022-06-11 03:36:17.593267
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    host = {'ansible_facts': {}}
    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list'),
        )
    )
    test_module.params['gather_subset'] = ['all']
    test_module.run_command = MagicMock(return_value=get_ifconfig_json_file_as_string())
    sunos_network = SunOSNetwork()
    sunos_network.get_interfaces_info(ifconfig_path='ifconfig')
    result = test_module.exit_json(ansible_facts=host['ansible_facts'])
    interfaces = result['ansible_facts']['ansible_interfaces']

    # unit test asserts that the value of the first dictionary key (e1000g

# Generated at 2022-06-11 03:36:26.108442
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:36:37.309750
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    em1_dict = dict(
        type='unknown',
        ipv4=[
            dict(flags="UP,BROADCAST,RUNNING,MULTICAST", mtu="1500"),
            dict(flags="UP,BROADCAST,RUNNING,MULTICAST", mtu="1500")
        ],
        ipv6=[
            dict(flags="UP,BROADCAST,RUNNING,MULTICAST,IPv6", mtu="1500"),
            dict(flags="UP,BROADCAST,RUNNING,MULTICAST,IPv6", mtu="1500")
        ],
        macaddress='08:00:20:61:c0:ec',
        device='em1'
    )


# Generated at 2022-06-11 03:36:38.433093
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:36:50.142316
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    fake_module = AnsibleModule(
        argument_spec={'gather_subset': dict(default=[], type='list')},
        supports_check_mode=True)

    path_to_file = os.path.join(os.path.dirname(__file__), 'fixtures', 'sunos_ifconfig_output')

    with open(path_to_file, 'r') as f:
        out = f.read()

    fake_module.run_command = lambda x: (0, out, '')

    net = SunOSNetwork(fake_module)
    interfaces, ips = net.get_interfaces_info('')


# Generated at 2022-06-11 03:36:51.254785
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:36:57.515556
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.facts import Facts

    test_obj = SunOSNetwork(Facts())
    test_obj.module = type('module', (object,), {'run_command': run_command})
    test_obj.get_interfaces_info('/sbin/ifconfig')


# Test data and mocking for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:37:13.512730
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # test with 'ipv4' interface
    words = ['bge0:', 'flags=.....', 'mtu', '150000']
    current_if = {'device': 'bge0:', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    current_if = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    assert current_if['device'] == 'bge0:'
    assert current_if['type'] == 'unknown'
    assert current_if['ipv4'][0]['flags'] == '.....'
    assert current_if['ipv4'][0]['mtu'] == '150000'
    assert current_if['ipv6'] == []

    # test with 'ipv6' interface
   

# Generated at 2022-06-11 03:37:24.890775
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    datadir = os.path.dirname(__file__)
    src_file = os.path.join(datadir, 'mocked_data', 'ifconfig_demo.txt')
    with open(src_file, 'r') as content_file:
        content = content_file.read()

    module = AnsibleModule(
        argument_spec=dict()
    )

    module.run_command = mock.Mock(return_value=(0, content, ''))
    module.get_bin_path = mock.Mock(return_value='/sbin/ifconfig')

    s = SunOSNetwork(module)
    interfaces, ips = s.get_interfaces_info('/sbin/ifconfig')

    # Check the interfaces dict
    assert len(interfaces.keys()) == 6

# Generated at 2022-06-11 03:37:29.574347
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the object creation of class SunOSNetworkCollector
    """
    assert SunOSNetworkCollector._platform == 'SunOS', \
        'Failed to set SunOSNetworkCollector._platform'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork, \
        'Failed to set SunOSNetworkCollector._fact_class'



# Generated at 2022-06-11 03:37:39.338791
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:37:40.965229
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()
    assert True


# Generated at 2022-06-11 03:37:50.938522
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """method parse_interface_line(self, words, current_if, interfaces)"""
    test_object = SunOSNetwork()
    words = ['nxge0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = {'device': 'nxge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'nxge0': {'device': 'nxge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}
    returned_value = test_object.parse_interface_line(words, current_if, interfaces)
    print("\n\n\n")
    print(returned_value)


# Generated at 2022-06-11 03:37:59.843271
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}

    # Test first interface line.
    words = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'.split()
    current_if = SunOSNetwork._parse_interface_line(SunOSNetwork(), words, current_if, interfaces)
    for k in ('device', 'type', 'macaddress', 'ipv4', 'ipv6'):
        assert current_if[k] == {'lo0': 'unknown'}[k]

    assert current_if['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL']

# Generated at 2022-06-11 03:38:09.543806
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    sut = GenericBsdIfconfigNetwork()
    current_if = {}
    interfaces = {}

    sut.parse_interface_line(['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL>', 'mtu', '8232'], current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL>'
    assert current_if['ipv4'][0]['mtu'] == '8232'

# Generated at 2022-06-11 03:38:10.880794
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network = SunOSNetworkCollector()
    assert(network.platform == 'SunOS')

# Generated at 2022-06-11 03:38:19.436415
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # pylint: disable=protected-access
    test1_interfaces = SunOSNetwork._test_sunos_ifconfig_output1.split('\n')
    test1_ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    test1_current_if = {}

    test1_interfaces_info = {}
    for line in test1_interfaces:
        if line:
            words = line.split()
            if re.match(r'^\S', line) and len(words) > 3:
                test1_current_if = SunOSNetwork.parse_interface_line(words, test1_current_if, test1_interfaces_info)
                test1_interfaces_info[test1_current_if['device']]

# Generated at 2022-06-11 03:38:34.455174
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    import os
    import json
    import platform

    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    os_platform = platform.system()
    if os_platform != 'SunOS':
        raise RuntimeError("This test is for SunOS only")


# Generated at 2022-06-11 03:38:44.669782
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test SunOSNetworkCollector class."""

    ansible_facts = {}
    SunOSNetworkCollector(ansible_facts=ansible_facts,
                          module=None)

    # test 'interface' fact

# Generated at 2022-06-11 03:38:55.293416
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    This function tests the method get_interfaces_info
    of class SunOSNetwork for the following conditions:
    """
    this_module = SunOSNetwork

# Generated at 2022-06-11 03:39:00.043328
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock()
    sunos_con = SunOSNetworkCollector(module)
    assert sunos_con.platform == 'SunOS'
    assert sunos_con._fact_class == SunOSNetwork
    assert sunos_con._platform == 'SunOS'


# Generated at 2022-06-11 03:39:11.110439
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    paths = {'ip': 'sbin/ip',
             'ifconfig': 'sbin/ifconfig'}
    facts = SunOSNetwork(dict(module=dict(paths=paths)))
    m = facts.get_interfaces_info('sbin/ifconfig')
    assert 'all_ipv4_addresses' in m[1]
    assert 'all_ipv6_addresses' in m[1]
    assert 'nf0' in m[0]
    assert 'ipv4' in m[0]['nf0']
    assert 'ipv6' in m[0]['nf0']
    assert 'mtu' in m[0]['nf0']['ipv4'][0]
   

# Generated at 2022-06-11 03:39:13.389861
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    x = SunOSNetworkCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class._platform == 'SunOS'

# Generated at 2022-06-11 03:39:24.645358
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']
    current_if = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'

# Generated at 2022-06-11 03:39:27.453416
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_collector = SunOSNetworkCollector()
    assert sunos_collector.platform == 'SunOS'
    assert sunos_collector.fact_class == SunOSNetwork

# Generated at 2022-06-11 03:39:38.177231
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    my_if = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    my_interfaces = {}
    # Solaris can have different FLAGS and MTU for IPv4 and IPv6 on the same interface
    # so these facts have been moved inside the ipv4 and ipv6 lists
    test_words1 = ['net0:', 'flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']

# Generated at 2022-06-11 03:39:42.274611
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockModule()
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info(ifconfig_path='ifconfig_path')
    module.run_command.assert_called_once_with(['ifconfig_path', '-a'])



# Generated at 2022-06-11 03:39:56.199482
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    class TestModule(object):
        def run_command(self, args, check_rc=True):
            out = """ixgbe0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,FIXEDMTU> mtu 1500 index 3
        inet 10.20.30.40 netmask ffffff00 broadcast 10.20.30.255
        ether 0:1:2:3:4:5"""

            err = ''
            rc = 0

            return rc, out, err

    class TestSunOSNetwork(SunOSNetwork):
        _module = TestModule()

    interfaces, ips = TestSunOSNetwork().get_interfaces_info('ifconfig')
    assert interfaces['ixgbe0']['device'] == 'ixgbe0'

# Generated at 2022-06-11 03:40:05.678639
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollector()
    obj = SunOSNetwork(module)

    # run get_interfaces_info
    interfaces, ips = obj.get_interfaces_info('/usr/sbin/ifconfig')

    # manually define current_if to test the parse_interface_line method
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    # test IPv6 interface
    words = "lo0:1:1      IPv6 LOOPBACK,MULTICAST"
    words = words.split()
    current_if = obj.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-11 03:40:15.626684
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    '''
    Sample output of the command `ifconfig -a` in SunOS.
    '''

# Generated at 2022-06-11 03:40:17.277904
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Checks that class can be instantiated
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:40:28.007111
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # create instance of SunOSNetwork
    sunos = SunOSNetwork()

    # set attributes to be tested
    # (ifconfig path, ifconfig command output)
    sunos.module = MagicMock()

# Generated at 2022-06-11 03:40:31.210243
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector(None, None)
    assert isinstance(collector, SunOSNetworkCollector) is True
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork

# Generated at 2022-06-11 03:40:32.945378
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_net_collector = SunOSNetworkCollector()
    assert sunos_net_collector is not None

# Generated at 2022-06-11 03:40:35.301895
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert isinstance(obj, NetworkCollector) is True
    assert isinstance(obj, SunOSNetworkCollector) is True

# Generated at 2022-06-11 03:40:37.606537
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector('module')
    assert network_collector.platform == 'SunOS'
    assert network_collector.interface is None


# Generated at 2022-06-11 03:40:49.542798
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts import collector


# Generated at 2022-06-11 03:41:04.212778
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(type='list', default=['all']),
        'filter': dict(required=False, type='str'),
    })

    # Get a fake ifconfig command as output, for Solaris 'ifconfig -a'
    ifconfig_path = module.get_bin_path('ifconfig', required=True)
    rc, out, err = module.run_command([ifconfig_path, '-a'])

    # Setup the class for unit test
    sunos = SunOSNetwork(module)
    # Call the method 'get_interfaces_info', with the fake ifconfig command as input
    interfaces, ips = sunos.get_interfaces_info(ifconfig_path)

    # Check that the method returns a valid result

# Generated at 2022-06-11 03:41:06.649852
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net = SunOSNetworkCollector()
    assert net._platform == "SunOS"
    assert net._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:41:08.994170
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork



# Generated at 2022-06-11 03:41:10.991601
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:41:12.488568
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector is not None

# Generated at 2022-06-11 03:41:23.172706
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:41:31.810511
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # arrange
    words = ['en0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '8232', 'index', '3', 'inet', '172.16.21.42', 'netmask', '0xffffff00', 'broadcast', '172.16.21.255']
    current_if = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    # act
    result = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    # assert

# Generated at 2022-06-11 03:41:32.683206
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-11 03:41:35.244774
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # class SunOSNetworkCollector exists
    assert hasattr(SunOSNetworkCollector, '_fact_class')
    assert hasattr(SunOSNetworkCollector, '_platform')

# Generated at 2022-06-11 03:41:45.436221
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:42:00.604330
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import NetworkCollector

    # ipv4 device information
    device_1_ipv4_lines = [
        'lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1',
        '        inet 127.0.0.1 netmask ff000000',
    ]
    # ipv6 device information
    device_1_ipv6_lines = [
        'lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6> mtu 8232 index 1',
        '        inet6 ::1/128',
    ]
    # Device information with both ipv4 and ipv6 interfaces

# Generated at 2022-06-11 03:42:02.110214
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_fact_module = SunOSNetworkCollector()
    assert sunos_fact_module.platform == 'SunOS'

# Generated at 2022-06-11 03:42:04.790013
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:42:15.170379
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # all supported facts should be mentioned here
    fact_names = [
        'device', 'ipv4', 'ipv6', 'type', 'macaddress', 'flags', 'mtu',
    ]
    iface_name = 'rge0'

    # prepare ifconfig output
    i_line1 = 'rge0: flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4> mtu 1500 index 4'
    i_line2 = 'rge0: flags=2000841<UP,RUNNING,MULTICAST,IPv6> mtu 1500 index 4'
    out = i_line1 + '\n' + i_line2 + '\n'


# Generated at 2022-06-11 03:42:23.929455
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # initial data
    module = None
    ifconfig_path = '/sbin/ifconfig'
    # ifconfig_path = '../../../ansible/test/units/module_utils/facts/network/ifconfig/sunos_ifconfig_1'
    # ifconfig_path = '../../../ansible/test/units/module_utils/facts/network/ifconfig/sunos_ifconfig_2'
    # ifconfig_path = '../../../ansible/test/units/module_utils/facts/network/ifconfig/sunos_ifconfig_3'

    network = SunOSNetwork(module)

    # test
    interfaces, ips = network.get_interfaces_info(ifconfig_path)
    #print('interfaces:', interfaces)
    #print('ips:', ips)

    # check


# Generated at 2022-06-11 03:42:26.251359
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Fail test if constructor does not create object of SunOSNetworkCollector
    assert isinstance(SunOSNetworkCollector(), SunOSNetworkCollector)

# Generated at 2022-06-11 03:42:27.219680
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()


# Generated at 2022-06-11 03:42:29.390424
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:42:39.571236
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:42:49.403558
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """ test_SunOSNetwork_get_interfaces_info
    This unit test checks that the get_interfaces_info method of the
    SunOSNetwork class returns the correct data structure.
    """


# Generated at 2022-06-11 03:43:12.576075
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('TestModule', (object,), {
        'run_command': lambda *args, **kwargs: (0, '', ''),
    })()
    sn = SunOSNetwork(module)
    interfaces, ips = sn.get_interfaces_info('/sbin/ifconfig')
    assert len(interfaces.keys()) == 1
    assert sorted(interfaces.keys()) == ['lo0']
    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-11 03:43:22.684849
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    ifconfig_path = '/sbin/ifconfig'
    test_obj = SunOSNetwork()

# Generated at 2022-06-11 03:43:30.345169
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockNetworkModule()
    ifconfig_path = '/usr/sbin/ifconfig'

# Generated at 2022-06-11 03:43:32.461565
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:43:40.258080
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:43:41.572596
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    mod = SunOSNetworkCollector(dict(), dict())
    assert mod != None

# Generated at 2022-06-11 03:43:51.361357
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollector.get_module('SunOS')
    if module is None:
        raise Exception('Could not get module')
    module.run_command = lambda *args, **kwargs: (None, load_fixture('ip_interface_sunos'), None)
    result = module.get_interfaces_info('/sbin/ifconfig')

# Generated at 2022-06-11 03:44:01.041838
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts import timeout
    from ansible.module_utils._text import to_text

    TEST_DATA_PATH = os.path.join(os.path.dirname(__file__), 'fixtures', 'SunOS_ifconfig_a.txt')

    with open(TEST_DATA_PATH) as stdin:
        output = std

# Generated at 2022-06-11 03:44:10.167185
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = FakeAnsibleModule()
    sunos = SunOSNetwork(module=module)
    current_if = {}
    interfaces = {}
    line = 'en0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 1'
    words = line.split()
    current_if = sunos.parse_interface_line(words, current_if, interfaces)
    assert current_if == {'device': u'en0', 'ipv4': [{'mtu': u'1500', 'flags': [u'UP', u'BROADCAST', u'RUNNING', u'MULTICAST', u'IPv4']}], 'ipv6': [], 'type': u'unknown'}



# Generated at 2022-06-11 03:44:20.486225
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test case: IPv4 and IPv6 interface
    # Output of 'ifconfig -a' command:
    line1 = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    line2 = '       inet 127.0.0.1 netmask ff000000'
    line3 = 'lo0: flags=2002000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8252 index 1'
    line4 = '       inet6 ::1/128'
    current_if1 = {}
    interfaces1 = {}
    current_if1['ipv4'] = []
    current_if1['ipv6'] = []

# Generated at 2022-06-11 03:44:51.438804
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class is SunOSNetwork


# Generated at 2022-06-11 03:44:53.542107
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    print('Testing SunOSNetworkCollector class')
    collector = SunOSNetwork()
    assert collector
    assert 'SunOS' == collector.platform

# Generated at 2022-06-11 03:45:03.188028
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # pylint: disable=protected-access
    # pylint: disable=no-init
    class TestClass(SunOSNetwork):
        """ Unit test class SunOSNetwork"""
        def get_options(self, value):
            return value

    sunos = TestClass({})
    interfaces = {}
    current_if = {}

# Generated at 2022-06-11 03:45:10.545467
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    network = SunOSNetwork(None)
    ifconfig_path = '/sbin/ifconfig'
    rc, out, err = sunos_run_command([ifconfig_path, '-a'])
    interfaces, ips = network.get_interfaces_info(ifconfig_path)
    assert out == sunos_ifconfig_out()
    assert interfaces == sunos_interfaces_out()
    assert ips == sunos_ips_out()


# This is the output of 'ifconfig -a' on sparc Solaris 11.4

# Generated at 2022-06-11 03:45:13.515576
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructing an instance of `SunOSNetworkCollector` should create an instance
    of `SunOSNetwork`.
    """

    assert isinstance(SunOSNetworkCollector(None, None).fact_class, SunOSNetwork)

# Generated at 2022-06-11 03:45:15.470184
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:45:16.766026
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Constructor should not throw exception
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:45:18.055497
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)


# Generated at 2022-06-11 03:45:27.130471
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Setup data for unit test
    module = {}

# Generated at 2022-06-11 03:45:34.568102
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule({})
    network = SunOSNetwork(module)

    # 'rc', 'out', 'err' are not used.
    # Pylint shows "Unused variable 'rc'".
    # Rc is not needed in this context (see imported methods).
    # This line is intended purely to satisfy pylint and stop it
    # from flagging these variables.
    rc = 0

    # Define a sample of ifconfig -a output.