

# Generated at 2022-06-11 03:36:02.005376
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock({})
    assert isinstance(SunOSNetworkCollector(module), SunOSNetworkCollector)

# Generated at 2022-06-11 03:36:11.794367
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:36:22.343516
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = None
    ifconfig_path = 'ifconfig_path'
    interfaces = {}
    current_if = {}
    line1 = 'lo0: flags=2000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1'
    line2 = 'lo0: flags=2000829<UP,LOOPBACK,RUNNING,MULTICAST,IPv6> mtu 8252 index 1'
    words1 = line1.split()
    words2 = line2.split()
    SunOSNetwork(module, ifconfig_path).parse_interface_line(words1, current_if, interfaces)
    SunOSNetwork(module, ifconfig_path).parse_interface_line(words2, current_if, interfaces)

# Generated at 2022-06-11 03:36:23.876994
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # This is just a sanity test to make sure the constructor works.
    return SunOSNetworkCollector()

# Generated at 2022-06-11 03:36:30.468274
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    mod = get_module()
    mod.run_command = run_command
    en = SunOSNetwork(mod)
    interfaces, ips = en.get_interfaces_info(IFCONFIG_PATH)

# Generated at 2022-06-11 03:36:31.504838
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    mysunos = SunOSNetworkCollector()
    assert mysunos._fact_class == SunOSNetwork
    assert mysunos._platform == 'SunOS'

# Generated at 2022-06-11 03:36:33.049797
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'


# Generated at 2022-06-11 03:36:45.175721
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_obj = SunOSNetwork()

# Generated at 2022-06-11 03:36:55.714120
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_obj = SunOSNetwork()
    test_obj.module = FakeAnsibleModule()
    test_obj.module.run_command = fake_run_command
    test_obj.module.fail_json = fake_fail_json
    test_obj._linux_distribution = lambda: ('SunOS', '5.11', '11.3')

    # Sample ifconfig output

# Generated at 2022-06-11 03:36:59.637854
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Create a network collector for SunOS
    network_collector1 = SunOSNetworkCollector()
    assert isinstance(network_collector1, NetworkCollector)
    assert network_collector1._fact_class is not None
    assert network_collector1._platform == 'SunOS'


# Generated at 2022-06-11 03:37:17.425301
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

# Generated at 2022-06-11 03:37:19.872574
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert issubclass(SunOSNetworkCollector._fact_class, SunOSNetwork)

# Generated at 2022-06-11 03:37:29.891323
# Unit test for constructor of class SunOSNetworkCollector

# Generated at 2022-06-11 03:37:39.756722
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = MockModule()
    fact_class = SunOSNetwork(module)
    interfaces = {'lo0': {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    # Normal IPv4
    words = ['lo0', 'flags=2001000849', '<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu 8232', 'index 2']
    current_if = fact_class.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-11 03:37:43.442210
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:37:53.125748
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list'),
            gather_network_resources=dict(default=['all'], type='list')
        )
    )
    set_module_args(dict(gather_subset=['!all', '!min']))
    obj = SunOSNetwork()
    command = mock.Mock(return_value=(0, open('unit/ansible_collections/ansible/community/tests/unit/modules/network/sunos/ifconfig_SunOS', 'r').read(), ''))

# Generated at 2022-06-11 03:38:02.115009
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:38:04.247530
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:38:14.283216
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    # Test case 1: output from 'ifconfig -a' includes interface 'lo0'
    # for testing 'is_loopback' method
    test_output_1 = '\n'.join((
        'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1',
        '        inet 127.0.0.1 netmask ff000000',
        'lo0: '))
    test_words_1 = test_output_1.split()

    # Test case 2: output from 'ifconfig -a' includes interface
    # 'vni1' for testing 'is_ipv6' method
    test_output_2 = '\n'.join

# Generated at 2022-06-11 03:38:16.142139
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == 'SunOS'


# Generated at 2022-06-11 03:38:27.883196
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class.__name__ == 'SunOSNetwork'


# Generated at 2022-06-11 03:38:38.188260
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    class FakeModule:
        def __init__(self, *args, **kwargs):
            return
        def run_command(self, args, check_rc=True):
            return (0, '', '')
    # fake module object
    fake = FakeModule()
    # fake ifconfig output

# Generated at 2022-06-11 03:38:48.461915
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    '''
    Unit test for method get_interfaces_info of class SunOSNetwork
    '''

    class TestModule:
        def run_command(self, command):

            rc = 0
            err = ''


# Generated at 2022-06-11 03:38:59.671415
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    collector = SunOSNetworkCollector(module=module)

    # Test ethernet interface
    #import pdb; pdb.set_trace()

# Generated at 2022-06-11 03:39:02.061638
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector.fact_class._platform == 'SunOS'

# Generated at 2022-06-11 03:39:05.952546
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ni = SunOSNetwork()
    ni.module = DummyAnsibleModule()
    ni.get_interfaces_info('/sbin/ifconfig')


# Dummy class for unit testing

# Generated at 2022-06-11 03:39:16.245249
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    facts = SunOSNetwork()

    current_if = {}
    interfaces = {}

    # Test parse_interface_line()
    words = 'lo0:'.split()
    current_if = facts.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'unknown'
    assert current_if['ipv4'] == [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'mtu': '8232'}]
    assert current_if['ipv6'] == []
    assert current_if['macaddress'] == 'unknown'


# Generated at 2022-06-11 03:39:27.381964
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    test_ifconfig_path = '/bin/ifconfig'
    test_string1 = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    test_string2 = 'lo0: flags=2002000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8232 index 1'
    test_string3 = 'lo0: flags=2002000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8232'
    test_current_if = {}
    test_words1 = test_string1.split()

# Generated at 2022-06-11 03:39:31.044334
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector()
    assert facts._platform == 'SunOS'
    assert facts._fact_class.__name__ == 'SunOSNetwork'
    assert facts._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 03:39:33.465370
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    platform = 'SunOS'
    SunOSNetworkCollector = SunOSNetworkCollector()
    assert platform in SunOSNetworkCollector._platform


# Generated at 2022-06-11 03:40:02.253599
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:40:09.677929
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    ifconfig_output_file = os.path.join(os.path.dirname(__file__), 'SunOS_ifconfig.txt')
    test_obj = SunOSNetwork(test_module)
    with open(ifconfig_output_file) as f:
        ifconfig_output = f.read()
    output, ips = test_obj.get_interfaces_info("/sbin/ifconfig")
    assert output == {}
    assert ips == {}

# Generated at 2022-06-11 03:40:13.292693
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructor of class SunOSNetworkCollector should set the
    '_fact_class' and '_platform' correct.

    """
    collector = SunOSNetworkCollector()
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'

# Generated at 2022-06-11 03:40:24.554478
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockAnsibleModule()
    ifconfig = SunOSNetworkCollector(module).get_interfaces_info('/sbin/ifconfig')
    assert type(ifconfig) is tuple
    assert type(ifconfig[0]) is dict
    assert type(ifconfig[1]) is dict
    assert 'all_ipv4_addresses' in ifconfig[1]
    assert 'all_ipv6_addresses' in ifconfig[1]
    assert 'lo0' in ifconfig[0]
    assert 'lan0' in ifconfig[0]
    assert 'lan1' in ifconfig[0]
    assert 'lan2' in ifconfig[0]
    assert 'lo0' in ifconfig[0]
    assert 'vlan1' in ifconfig[0]

# Generated at 2022-06-11 03:40:34.600676
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    This test parses the output of ifconfig -a on Solaris.
    The output is taken from Solaris 11.1 which has both IPv4 and IPv6 lines
    for each interface.
    """

# Generated at 2022-06-11 03:40:42.466623
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    ifc = SunOSNetwork()

    # BSD format: Interface, Flags (comma-separated or space-separated), MTU
    # Solaris: print IPv4 and IPv6 info on the same interface
    interfaces = {}
    current_if = {}
    ifc.parse_interface_line(["bge0:", "UP", "LOOPBACK", "RUNNING", "MULTICAST", "MTU:1500", "Metric:1"], current_if, interfaces)
    assert interfaces["bge0"]["ipv4"][0]["mtu"] == "1500"

    # Solaris: print IPv4 and IPv6 info on the same interface
    interfaces = {}
    current_if = {}

# Generated at 2022-06-11 03:40:46.320882
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    c = SunOSNetworkCollector(None)
    assert c.platform == 'SunOS'
    assert c.fact_class == SunOSNetwork

# Unit tests for constructor of class SunOSNetwork

# Generated at 2022-06-11 03:40:56.761966
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig', required=True)
    obj = SunOSNetwork()
    interfaces, ips = obj.get_interfaces_info(ifconfig_path)
    assert 'lo0' in interfaces
    assert 'net0' in interfaces
    assert 'ipv4' in interfaces['net0']
    assert 'ipv6' in interfaces['net0']
    assert 'ipv4' in interfaces['net0']
    assert 'ipv6' in interfaces['net0']
    assert interfaces['net0']['ipv4'][0]['mtu'] == '1500'
    assert interfaces['net0']['ipv6'][0]['mtu'] == '1280'

# Generated at 2022-06-11 03:41:07.751574
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    input_txt = '''
lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        options=3<RXCSUM,TXCSUM>
        inet6 ::1/128
        options=3<RXCSUM,TXCSUM>
        nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>
ip.tun0: flags=801040<UP,POINTOPOINT,MULTICAST> mtu 1480 index 2
        inet 10.0.0.2 --> 10.0.0.1 netmask ffffffff
        options=80000<LINKSTATE>
'''

    output = {}
   

# Generated at 2022-06-11 03:41:18.634252
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork


# Generated at 2022-06-11 03:42:04.838481
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    m = SunOSNetwork(module=module)
    current_if = {}
    interfaces = {}

    words = ['lo0:', 'flags=2001000849', 'mtu']
    current_if = m.parse_interface_line(words, current_if, interfaces)

    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'] == [{'flags': '2001000849', 'mtu': 'mtu'}]
    assert current_if['type'] == 'loopback'

    assert current_if['macaddress'] == 'unknown'

    words = ['lo0:', 'flags=2001000837', 'mtu']
    current_if = m.parse_interface_line(words, current_if, interfaces)

   

# Generated at 2022-06-11 03:42:15.264393
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = './utils/ifconfig_solaris.out'
    with open(ifconfig_path, 'r') as ifconfig_file:
        ifconfig_out = ifconfig_file.read()
    test_ifconfig_out = ifconfig_out.splitlines()
    test_module = type('test_module', (object,), {})()
    test_module.params = {'gather_subset': ['all']}
    test_module.run_command = run_command_mock
    test_SunOSNetwork = SunOSNetwork(test_module)
    test_SunOSNetwork.get_interfaces_info(ifconfig_path)

    test_interfaces, test_ips = test_SunOSNetwork.get_interfaces_info(ifconfig_path)


# Generated at 2022-06-11 03:42:16.766201
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:42:20.266577
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_collector = SunOSNetworkCollector()
    assert sunos_collector._fact_class == SunOSNetwork
    assert sunos_collector._platform == 'SunOS'

# This class is used as a stub for unit testing of class SunOSNetwork

# Generated at 2022-06-11 03:42:29.663564
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    a = {'device': 'lo0',
         'ipv4': [['loopback', True, '127.0.0.1', 'UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'MTU:8232', 'Index:2']],
         'ipv6': [],
         'macaddress': '00:00:00:00:00:00',
         'type': 'loopback'}

# Generated at 2022-06-11 03:42:31.847052
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact = SunOSNetworkCollector()

    assert(fact._fact_class == SunOSNetwork)
    assert(fact._platform == 'SunOS')

# Generated at 2022-06-11 03:42:41.930902
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_class = SunOSNetwork()
    test_dict = {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '1500'}], 'ipv6': [], 'macaddress': 'unknown', 'type': 'loopback'}
    test_word_list = ['lo0:', 'flags=849<UP,LOOPBACK,RUNNING>', 'mtu', '1500']

# Generated at 2022-06-11 03:42:42.944566
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.collect() is not None

# Generated at 2022-06-11 03:42:52.858283
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    import sys
    import os
    import pytest
    from test.units.compat.mock import patch
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    if not os.path.exists("/sbin/ifconfig"):
        pytest.skip("ifconfig not installed")

    my_obj = SunOSNetwork()

    ############################
    sys.path.append(".")
    # Replacing the 'os' module functions 'path.exists' and 'access' with a version that always
    # returns 'False' so that we can test the 'module.fail_json' function in the 'get_interfaces_info'
    # function of the class 'FreeBSDNetwork'

# Generated at 2022-06-11 03:42:55.847963
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock()
    obj = SunOSNetworkCollector(module)
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:44:29.436395
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sys = {'network': {'interfaces': {}, 'all_ipv4_addresses': [], 'all_ipv6_addresses': []}}

# Generated at 2022-06-11 03:44:38.936505
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test SunOSNetwork.get_interfaces_info() (sunos_interfaces.json)
    """
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    SunOSNetworkCollector.collect()
    interfaces_info, ips = SunOSNetwork.get_interfaces_info('/sbin/ifconfig')

# Generated at 2022-06-11 03:44:49.037626
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    # Example from sol12.2
    # Output from "ifconfig -a"

# Generated at 2022-06-11 03:44:52.810900
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:44:58.706383
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # create a fake module
    module = object()
    # assign the current platform to the module
    module.get_platform = lambda: 'SunOS'
    module.run_command = lambda x: (0, '', '')

    # create a instance of SunOSNetwork
    nm = SunOSNetwork(module)

    # check if the get_interfaces_info method will return something for SunOS
    assert isinstance(nm.get_interfaces_info('ifconfig'), tuple)



# Generated at 2022-06-11 03:45:08.076344
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    This is a unit test for the SunOSNetwork class, testing the
    get_interfaces_info method.

    It is designed to take sample output of the Solaris ifconfig -a command and
    assign it to the SunOSNetwork class.
    It then runs the get_interfaces_info method from that class and compares the result
    with a known good result.
    """
    # Run setup for the test
    test_data = SunOS_test_data()
    ifconfig_result = test_data.get_ifconfig_result()
    (interfaces, ips) = SunOSNetwork().get_interfaces_info('/usr/sbin/ifconfig')
    valid_interfaces = test_data.get_interfaces()
    valid_ips = test_data.get_ips()

    assert interfaces == valid_interfaces
   

# Generated at 2022-06-11 03:45:17.002191
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollector()
    module.get_localized_facts = lambda x, y: y
    module.params = {'gather_subset': list()}
    module.run_command = lambda x: (0, '', '')
    ns = SunOSNetwork(module)
    ns.get_localized_facts = lambda params: {}
    # On illumos, ifconfig -a returns the following output for a single interface.  Note that
    # the MTU, FLAGS, and link-level address will differ between IPv4 and IPv6.  Note also that
    # the MAC address is reported in the ether line.

# Generated at 2022-06-11 03:45:18.578763
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    ifconfig_path = '/opt/csw/bin/ifconfig'
    SunOSNetworkCollector(ifconfig_path)

# Generated at 2022-06-11 03:45:19.474080
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()


# Generated at 2022-06-11 03:45:20.073399
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    return