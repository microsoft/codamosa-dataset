

# Generated at 2022-06-11 03:35:51.132838
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # SunOSNetwork class object
    sunos_network = SunOSNetwork()

    # Test parameters
    path = '/sbin/ifconfig'

# Generated at 2022-06-11 03:35:58.445820
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = None
    current_if = {}
    interfaces = {}
    net = SunOSNetwork(module)
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = net.parse_interface_line(words, current_if, interfaces)
    assert current_if == {'device': 'lo0', 'ipv4': [{'flags': 'UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL', 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback'}

# Generated at 2022-06-11 03:36:00.189628
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:36:00.989698
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector



# Generated at 2022-06-11 03:36:03.011013
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert isinstance(obj, NetworkCollector)
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:36:13.107878
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:36:23.424542
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test get_interfaces_info() of SunOSNetwork class
    """
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    f = SunOSNetwork()
    interfaces, ips = f.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces['lo0']['device']
    assert 'flags' in interfaces['lo0']['ipv4'][0]
    assert 'IPv6' in interfaces['lo0']['ipv4'][0]['flags']
    assert 'mtu' in interfaces['lo0']['ipv4'][0]
    assert 'loopback' in interfaces['lo0']['type']
    assert 'lo0' in interfaces

# Generated at 2022-06-11 03:36:24.301956
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # there is no test at this time
    pass

# Generated at 2022-06-11 03:36:30.816339
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:36:42.789412
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    import re
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # Input data
    ifconfig_path = '/sbin/ifconfig'

# Generated at 2022-06-11 03:36:57.743784
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Setup
    module = FakeModule()
    module.run_command = Mock(return_value=(0,'',''))
    ifconfig_path = 'ifconfig'

# Generated at 2022-06-11 03:37:07.284634
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = ""
    facts_collector = SunOSNetwork('SunOS', 'ifconfig', module)
    interfaces_info, ips_info = facts_collector.get_interfaces_info(facts_collector.ifconfig_path)
    assert len(interfaces_info) == 3
    for interface in interfaces_info:
        assert len(interfaces_info[interface]) == 8
        assert 'ipv4' in interfaces_info[interface]
        assert 'ipv6' in interfaces_info[interface]
        assert 'type' in interfaces_info[interface]
        assert 'macaddress' in interfaces_info[interface]
        for v in 'ipv4', 'ipv6':
            assert len(interfaces_info[interface][v]) == 1
            assert 'flags' in interfaces_info[interface][v][0]
           

# Generated at 2022-06-11 03:37:11.364697
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Test with no args
    collector = SunOSNetworkCollector()
    # Returned value should be of type SunOSNetwork
    assert isinstance(collector._fact_class, SunOSNetwork)
    # platform should be SunOS
    assert collector._platform == 'SunOS'

# Generated at 2022-06-11 03:37:12.952440
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector(None)

# Generated at 2022-06-11 03:37:15.842926
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:37:26.800505
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

# Generated at 2022-06-11 03:37:35.760348
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from units.compat.mock import patch
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    with patch.dict(GenericBsdIfconfigNetwork.__dict__,
                    {'ifconfig_path': '/sbin/ifconfig'}):
        m = SunOSNetwork()


# Generated at 2022-06-11 03:37:39.382769
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact_module = SunOSNetworkCollector()
    assert fact_module.platform == 'SunOS'
    assert fact_module._fact_class.platform == 'SunOS'
    assert fact_module._fact_class.__name__ == 'SunOSNetwork'


# Generated at 2022-06-11 03:37:49.473490
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, MagicMock
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic

    mock_module = MagicMock(name='mock_module')
    mock_module.params = {'gather_subset': ['all']}
    mock_module.get_bin_path = MagicMock(return_value='')
    facts = SunOSNetworkCollector(mock_module, '', '').collect()

    assert facts['minor'] == '53'
    assert facts['network']['device']['lo0']['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-11 03:37:52.498355
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector.platforms == ('SunOS',)



# Generated at 2022-06-11 03:38:12.834914
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test method 'get_interfaces_info'
    """

    class TestModule(object):
        def __init__(self, args):
            self.args = args

        def run_command(self, cmd):
            return 0, test_file, None


# Generated at 2022-06-11 03:38:14.151581
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test class constructor of SunOSNetworkCollector"""
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:38:16.017353
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector

    SunOSNetworkCollector(dict())


# Generated at 2022-06-11 03:38:16.950319
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:38:22.656658
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:38:33.918492
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    cmd = '/sbin/ifconfig -a'
    rc = 0
    current_time = 1524141501.493568

# Generated at 2022-06-11 03:38:36.031508
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Instantiate class SunOSNetworkCollector()
    """
    module = None
    SunOSNetworkCollector(module)

# Generated at 2022-06-11 03:38:38.525744
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test SunOSNetworkCollector
    """
    network_collector = SunOSNetworkCollector()
    assert network_collector is not None


# Generated at 2022-06-11 03:38:40.838938
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'

# Generated at 2022-06-11 03:38:42.210472
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-11 03:39:04.114012
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:39:14.436544
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructor test.
    """

# Generated at 2022-06-11 03:39:25.641760
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_module = NetworkCollector()
    sunosnetwork = SunOSNetwork(test_module)
    """
    Test the method get_interfaces_info of class SunOSNetwork.
    """
    # set up test data
    ifconfig_path = '/usr/bin/ifconfig'

# Generated at 2022-06-11 03:39:29.670716
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetwork.platform == 'SunOS'

# Generated at 2022-06-11 03:39:39.575533
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    params = dict(
        module_args=dict(gather_subset='default')
    )
    module = AnsibleModule(**params)
    sunos_network = SunOSNetworkCollector(module)

# Generated at 2022-06-11 03:39:40.574498
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    return SunOSNetworkCollector()

# Generated at 2022-06-11 03:39:42.961780
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock()
    collector = SunOSNetworkCollector(module=module)
    assert collector.platform == 'SunOS'


# Generated at 2022-06-11 03:39:45.160119
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    c = SunOSNetworkCollector()
    assert c.platform == 'SunOS'
    assert isinstance(c.facts, SunOSNetwork)


# Generated at 2022-06-11 03:39:51.204933
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = {}
    SunOSNetworkCollector(facts, None, None)
    assert facts['ansible_net_gather_subset'] == [
        'all', '!min', '!config'
    ]
    assert facts['ansible_net_gather_network_resources'] == [
        'interfaces', 'interfaces_ipv4', 'interfaces_ipv6',
        'neighbors', 'neighbors_ipv4', 'neighbors_ipv6'
    ]


# Generated at 2022-06-11 03:39:54.137779
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector(None)
    assert obj.platform == 'SunOS'
    assert obj._fact_class.platform == 'SunOS'


# Generated at 2022-06-11 03:40:39.714295
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    line = 'lo0: flags=200200084943<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8232'
    words = line.split()
    current_if = {}
    interfaces = {}
    current_if = SunOSNetwork.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'] == []
    assert len(current_if['ipv6']) == 1
    assert current_if['ipv6'][0]['flags'] == '200200084943'
    assert current_if['ipv6'][0]['mtu'] == '8232'

# Generated at 2022-06-11 03:40:52.710223
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:40:53.721601
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()


# Generated at 2022-06-11 03:41:04.589551
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    testmodule = AnsibleModule({})
    testnetwork = SunOSNetwork(testmodule)
    path = '/sbin/ifconfig'

# Generated at 2022-06-11 03:41:06.178535
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(), NetworkCollector)

# Generated at 2022-06-11 03:41:08.944094
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network = SunOSNetworkCollector()
    assert network is not None
    assert network.facts['network'] is not None
    assert network.facts['network']['interfaces'] != {}

# Generated at 2022-06-11 03:41:11.796421
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the SunOSNetworkCollector Constructor
    """
    assert isinstance(SunOSNetworkCollector(), SunOSNetworkCollector)


# Generated at 2022-06-11 03:41:12.826204
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-11 03:41:23.516336
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:41:25.374935
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    assert net_collector._platform == 'SunOS'

# Generated at 2022-06-11 03:42:47.108251
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:42:50.108502
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # instantiate SunOSNetworkCollector
    collector = SunOSNetworkCollector()
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'
    assert collector._options == ''

# Generated at 2022-06-11 03:42:59.094000
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    def run_module():
        module_args = dict(
            gather_subset=['!all', 'network'],
        )
        module = AnsibleModule(
            argument_spec=module_args,
            supports_check_mode=True
        )
        return module.exit_json(ansible_facts=dict(
            ansible_network_resources=SunOSNetwork(module).get_interfaces_info(ifconfig_path)
        ))

    # Add test to list of class tests
    test_case = {}
    test_case['platform'] = 'SunOS'
    test_case['ifconfig_path'] = '/usr/bin/ifconfig'

# Generated at 2022-06-11 03:43:00.934462
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos = SunOSNetworkCollector()
    assert sunos.fact_class == SunOSNetwork
    assert sunos.platform == 'SunOS'

# Generated at 2022-06-11 03:43:02.876570
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:43:11.819924
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    SunOSNetwork.module = FakeModule()
    sunosnetwork = SunOSNetwork()


# Generated at 2022-06-11 03:43:21.969582
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = 'module'
    platform = 'SunOS'
    ifconfig_path = 'ifconfig'

# Generated at 2022-06-11 03:43:30.040849
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    nm = SunOSNetworkCollector(None)
    # Test 1: checking if interface name is correctly set
    if1_info = {}
    if1_info['device'] = 'ipv4'
    if1_info['ipv4'] = []
    if1_info['ipv6'] = []
    if1_info['type'] = 'unknown'
    interfaces = {}
    interfaces['ipv4'] = if1_info
    interfaces['ipv6'] = if1_info

    words1 = ['ipv4:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = {}
    current_if = nm.parse_interface_line(words1, current_if, interfaces)

# Generated at 2022-06-11 03:43:33.641429
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Case 1.1: Instantiate concrete NetworkCollector class
    obj = SunOSNetworkCollector()
    assert obj._platform == "SunOS"
    assert obj._fact_class is SunOSNetwork
    assert isinstance(obj._fact_class(), SunOSNetwork)

# Generated at 2022-06-11 03:43:36.888361
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)
    sunos_network = SunOSNetworkCollector()
    assert sunos_network.platform == "SunOS"
    assert sunos_network.fact_class == SunOSNetwork
