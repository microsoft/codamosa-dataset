

# Generated at 2022-06-11 03:36:03.159329
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    collector = SunOSNetworkCollector()
    collector.module = FakeAnsibleModule()

# Generated at 2022-06-11 03:36:13.297832
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    device = "bge0"
    ipv4 = []
    ipv6 = []
    current_if = {'device': device, 'ipv4': ipv4, 'ipv6': ipv6}
    interfaces = {}
    words = ["bge0:", "flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>", "mtu", "1500"]

    netif = SunOSNetwork()
    netif.parse_interface_line(words, current_if, interfaces)
    assert len(interfaces) == 1
    assert len(current_if) == 4
    assert current_if['device'] == device
    assert len(current_if['ipv4']) == 1
    assert len(current_if['ipv4'][0]) == 2
    assert current

# Generated at 2022-06-11 03:36:19.864380
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Create an object for SunOSNetworkCollector class.
    """
    # Instantiate the class
    sun_net = SunOSNetworkCollector({}, {})
    # obj should be instance of 'NetworkCollector' class
    assert isinstance(sun_net, NetworkCollector)
    # obj should be instance of 'SunOSNetworkCollector' class
    assert isinstance(sun_net, SunOSNetworkCollector)


# Generated at 2022-06-11 03:36:28.792210
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunos_network = SunOSNetwork()
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>',
             'mtu', '8232', 'index', '1']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    assert current_if['type'] == 'loopback'
    assert current_if['device'] == 'lo0'
    assert len(current_if['ipv4']) == 1
    assert len(current_if['ipv6']) == 0

# Generated at 2022-06-11 03:36:40.758752
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """ Check parsing of ifconfig -a output """
    module = AnsibleModule(argument_spec=dict())
    ifconfig_path = module.get_bin_path('ifconfig', required=True)
    nm = SunOSNetwork(module)
    interfaces, ips = nm.get_interfaces_info(ifconfig_path)
    # ips is not used, so don't care what it contains
    assert 'lo0' in interfaces
    lo0 = interfaces['lo0']
    assert lo0['device'] == 'lo0'
    assert lo0['type'] == 'loopback'
    v4 = lo0['ipv4'][0]
    assert v4['address'] == '127.0.0.1'
    assert v4['netmask'] == '255.0.0.0'

# Generated at 2022-06-11 03:36:45.914138
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    module = type('', (), {})()
    module.run_command = lambda x: [0, '', '']
    module.fail_json = lambda x: True
    module.warn = lambda x: True

    network = SunOSNetwork(module)
    network.get_interfaces_info('ifconfig')

# Generated at 2022-06-11 03:36:50.725090
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """ Test the constructor of SunOSNetworkCollector """
    facts_dir = 'facts/facts.d'
    ins = SunOSNetworkCollector(facts_dir=facts_dir)
    assert isinstance(ins, NetworkCollector)
    assert ins._fact_class._platform == 'SunOS'
    assert ins.facts_dir == facts_dir

# Generated at 2022-06-11 03:36:54.559791
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector()
    assert isinstance(facts, NetworkCollector)
    assert isinstance(facts, SunOSNetworkCollector)
    assert facts._fact_class == SunOSNetwork
    assert facts._platform == 'SunOS'


# Generated at 2022-06-11 03:36:57.607268
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    assert collector._platform == 'SunOS'

# Unit tests for methods of class SunOSNetworkCollector

# Generated at 2022-06-11 03:36:59.878465
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructor of the class is not tested as it is inherited from the NetworkCollector
    class and it is abstract
    """
    assert True

# Generated at 2022-06-11 03:37:07.162797
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network = SunOSNetworkCollector()
    assert network._platform == 'SunOS'
    assert network._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:37:09.601769
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:37:21.643637
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # setup
    resp = []
    resp.append("lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1")
    resp.append("    inet 127.0.0.1 netmask ff000000")
    resp.append("bge0: flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4> mtu 1500 index 2")
    resp.append("    options=1b<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING>")
    resp.append("    inet 10.10.10.3 netmask ffffff00 broadcast 10.10.10.255")

# Generated at 2022-06-11 03:37:24.431639
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:37:27.784992
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    my_network_collector = SunOSNetworkCollector(None)
    my_network_collector.collect()
    if my_network_collector.platform is 'SunOS':
        assert True
    else:
        assert False

# Generated at 2022-06-11 03:37:29.694995
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.fact_class._platform == 'SunOS'
    assert collector.platform == 'SunOS'

# Generated at 2022-06-11 03:37:39.547411
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class SunOSNetwork"""

    # Create a SunOSNetwork object
    net = SunOSNetwork()

    # Create a dictionary with compatibles arguments for SunOSNetwork.get_interfaces_info method

# Generated at 2022-06-11 03:37:44.334220
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert issubclass(SunOSNetworkCollector._fact_class, SunOSNetwork)
    sunos_network_fact_class = SunOSNetworkCollector._fact_class(dict(module=dict()), 'ifconfig')
    assert isinstance(sunos_network_fact_class, SunOSNetwork)

# Generated at 2022-06-11 03:37:53.970082
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:38:02.873268
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:38:09.678373
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    _fact_class = SunOSNetwork
    _platform = 'SunOS'
    obj = SunOSNetworkCollector(_fact_class, _platform)

# Generated at 2022-06-11 03:38:18.623926
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:38:29.598544
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetwork({})
    current_if = {}

    # Test with valid data
    words = ['lo0:', 'flags=2001000849', 'mtu', '0']
    interfaces = {'lo0': {'ipv4': [{'mtu': '0', 'flags': '2001000849'}], 'macaddress': 'unknown', 'ipv6': [], 'device': 'lo0', 'type': 'unknown'}}
    current_if = m.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == '2001000849'
    assert current_if['ipv4'][0]['mtu'] == '0'

    # Test when interface already exist

# Generated at 2022-06-11 03:38:39.832996
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollector()
    network = SunOSNetwork()
    network.module = module
    interfaces, ips = network.get_interfaces_info('/usr/sbin/ifconfig')
    # Check type of return values
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    # Test values for a specific interface
    def test_interface_ipv4(dev, facts):
        for fact in facts:
            assert 'mtu' in fact
            assert 'inet' in fact['addresses']
            assert 'broadcast' in fact['addresses']
            assert 'netmask' in fact['addresses']
            assert 'netmask_bits' not in fact
            assert 'scope' not in fact['addresses']
            assert 'prefix' not in fact['addresses']

# Generated at 2022-06-11 03:38:50.021539
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class SunOSNetwork
    """
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    sunos_network = SunOSNetwork()
    sunos_facts, _ = sunos_network.get_interfaces_info('/sbin/ifconfig')

    # Assert 'enp0s8' interface facts
    assert 'enp0s8' in sunos_facts
    assert sunos_facts['enp0s8']['ipv4'][0]['address'] == '192.168.122.10'
    assert sunos_facts['enp0s8']['ipv4'][0]['netmask'] == '255.255.255.0'

# Generated at 2022-06-11 03:39:01.531015
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    set_module_args(dict(gather_subset="!all,!min"))
    current_if = {}
    interfaces = {}
    ips = {}
    collect_subset = ['!all', '!min']
    instance = SunOSNetwork(module)
    test_file = 'utils/network/files/ifconfig_SunOS_bge0_vlan_lo0'
    test_file_path = module.get_fixture_path(test_file)
    with open(test_file_path, 'r') as f:
        cmd_out = f.read()
    rc, out, err = module.run_command(cmd_out)


# Generated at 2022-06-11 03:39:12.516874
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts import details as facts_details
    from ansible.module_utils.facts.network import collector as network_collector
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector

    # Create an instance of SunOSNetworkCollector
    sunos_collector_obj = SunOSNetworkCollector('ansible.module_utils.facts.network.sunos.SunOSNetwork')

    # Check the member variables of the instance
    assert sunos_collector_obj.platform == 'SunOS'
    assert sunos_collector_obj.fact_class == SunOSNetwork
    assert sunos_collector_obj.fact_class_name == 'SunOSNetwork'

# Generated at 2022-06-11 03:39:23.660576
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:39:27.331753
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj1 = SunOSNetworkCollector()
    assert obj1.platform == 'SunOS'
    assert obj1._fact_class.platform == 'SunOS'
    assert obj1.fact_class == SunOSNetwork



# Generated at 2022-06-11 03:39:38.095027
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create a SunOSNetwork object
    module = AnsibleModule(argument_spec={},
                           supports_check_mode=False)
    network = SunOSNetwork(module)
    # Parse test data
    ifconfig_path = '/sbin/ifconfig'

# Generated at 2022-06-11 03:39:44.330459
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:39:45.868944
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructor test for SunOSNetworkCollector class
    """
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:39:55.678642
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:39:58.200634
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == "SunOS"
    assert network_collector.fact_class == SunOSNetwork



# Generated at 2022-06-11 03:40:07.774948
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:40:18.107587
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_module = 'ansible.module_utils.facts.network.sunos.sunos'
    test_class = 'SunOSNetwork'
    test_method = 'get_interfaces_info'
    test_output = """
lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
qfe0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 3
        inet 10.0.2.15 netmask ffffff00 broadcast 10.0.2.255
        ether 8:0:20:e1:7a:50
"""

# Generated at 2022-06-11 03:40:21.840396
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    def ansible_module_mock(*args, **kwargs):
        print(args)

    collector = SunOSNetworkCollector(ansible_module_mock)
    assert collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 03:40:26.624584
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._platform == 'SunOS'
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == 'SunOS'



# Generated at 2022-06-11 03:40:36.515633
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.sunos import SunOSNetwork
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.sunos import SunOSNetworkCollector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.base import NetworkCollector

    class TestGenericBsdIfconfigNetwork(GenericBsdIfconfigNetwork):
        platform = 'SunOS'


# Generated at 2022-06-11 03:40:39.023269
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the SunOSNetworkCollector constructor
    """
    osfacts = SunOSNetworkCollector()
    assert osfacts.platform == 'SunOS'
    assert osfacts._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:40:59.233493
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """ Unit test for method SunOSNetwork.get_interfaces_info """
    # Create a SunOSNetwork class
    sunos_network = SunOSNetwork()

    # Create a list of 'ifconfig -a' entries

# Generated at 2022-06-11 03:41:10.506137
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    SunOS_interfaces = []
    SunOS_interfaces.append("""lo0: flags=2001000849 mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        ip6 ::1/128
        zone local""")
    SunOS_interfaces.append("""bge0: flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4> mtu 1500 index 2
        inet 192.168.1.2 netmask ffffff00 broadcast 192.168.1.255
        ether 0:1:2:d:e:f
        inet6 fe80::201:2ff:fed:eff%bge0/10
        ip6 2001:db8::201:2ff:fed:eff/128
        zone pub""")
   

# Generated at 2022-06-11 03:41:12.872429
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    my_network = SunOSNetwork({'module_name': 'test'})
    my_network.get_interfaces_info('/sbin/ifconfig')

# Generated at 2022-06-11 03:41:15.371967
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector._fact_class == SunOSNetwork
    assert network_collector._platform == 'SunOS'

# Generated at 2022-06-11 03:41:26.336879
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    facts = SunOSNetwork()


# Generated at 2022-06-11 03:41:30.740768
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', elements='str', default=['!all', '!min']),
                                           'gather_network_resources': dict(type='list', elements='str', default=['all'])})
    obj = SunOSNetwork(module)
    obj.get_interfaces_info('/usr/sbin/ifconfig')

# Generated at 2022-06-11 03:41:41.072468
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """ SunOSNetwork: Test get_interfaces_info """


# Generated at 2022-06-11 03:41:44.967845
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # This is a unit test function that verifies the constructor of the
    # class SunOSNetworkCollector
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector._fact_class == SunOSNetwork
    assert sunos_network_collector._platform == 'SunOS'

# Generated at 2022-06-11 03:41:52.974253
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.base import NetworkCollector

    class test(SunOSNetwork):
        def __init__(self):
            self.module = None

    test_obj = test()
    test_obj.module = None
    test_obj.path = 'fake'
    #test_obj.distribution = object()
    test_obj.module = object()
    test_obj.module.run_command = object()


# Generated at 2022-06-11 03:41:55.717847
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructor for class SunOSNetworkCollector must set attribute
    _fact_class to SunOSNetwork
    """
    network_collector = SunOSNetworkCollector()
    assert network_collector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:42:28.381240
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    SunOSNetwork.parse_interface_line(["lo0:", "flags=2001000849", "mtu", "8246"], current_if, interfaces)
    assert interfaces["lo0"]
    assert interfaces["lo0"]["ipv4"]
    assert interfaces["lo0"]["ipv4"][0]["flags"] == "LOOPBACK,IPv4,MULTICAST"
    assert interfaces["lo0"]["ipv4"][0]["mtu"] == "8246"

    SunOSNetwork.parse_interface_line(["lo0:", "flags=2001000849", "mtu", "8246", "index", "3"], current_if, interfaces)
    assert interfaces["lo0"]

# Generated at 2022-06-11 03:42:30.127936
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the constructor for SunOSNetworkCollector.
    """
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:42:32.745299
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test initialization of SunOSNetworkCollector
    """
    info = {'SunOS': {'network': 'SunOSNetwork'}}
    SunOSNetworkCollector(info)

# Generated at 2022-06-11 03:42:42.806614
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """ Unit test for method get_interfaces_info of class SunOSNetwork """
    test_module = type('module', (), {'params': {'gather_network_resources': 'all'}})()
    test_module.run_command = lambda args, check_rc=None: (0, open('test/unit/facts/network/sunos_get_interfaces_info').read(), '')
    sunos_network = SunOSNetwork(test_module)

    interface_info, ips = sunos_network.get_interfaces_info('/sbin/ifconfig')

    # 'parse_interface_line' and 'parse_inet*_line' leave two dicts in the
    # ipv4/ipv6 lists which is ugly and hard to read.
    # This quick hack merges the dictionaries. Purely cosmetic.
   

# Generated at 2022-06-11 03:42:50.061360
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    # Verify that the constructor of class SunOSNetworkCollector initializes
    # the instance correctly
    test_SunOSNetworkCollector = SunOSNetworkCollector()
    assert test_SunOSNetworkCollector._platform == 'SunOS', \
        'Expected _platform to be SunOS, but got %s' % test_SunOSNetworkCollector._platform

    assert test_SunOSNetworkCollector._fact_class == SunOSNetwork, \
        'Expected _fact_class to be SunOSNetwork, but got %s' % test_SunOSNetworkCollector._fact_class


# Generated at 2022-06-11 03:42:59.054233
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollector()
    module.params = {'gather_subset': [], 'gather_network_resources': 'all'}
    setattr(module, '_debug', lambda msg: None)
    setattr(module, 'run_command', lambda *args, **kwargs: (0, ifconfig_out, ''))


# Generated at 2022-06-11 03:43:00.242088
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(), NetworkCollector)

# Generated at 2022-06-11 03:43:01.054254
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:43:10.043702
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_module = type('test_module', (object,), dict(run_command=lambda x: x))
    test_module.fail_json = lambda *args, **kwargs: None

    test_iface = dict(dict(device='eth0', ipv4=[], ipv6=[], type='unknown'))

    test_ipv4_line = ['-eth0', 'flags=1000011', 'mtu', '1500']
    test_ipv6_line = ['-eth0', 'flags=1000011', 'mtu', '1500', 'IPv6']
    test_ipv4_loopback_line = ['-lo0', 'flags=8049', 'mtu', '8232']

    test_SunOSNetwork = SunOSNetwork(test_module)


# Generated at 2022-06-11 03:43:19.962063
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:44:12.299082
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_module = type('test_module', (object, ), {'run_command': mock_run_command})
    test_module.exit_json = mock_exit_json
    test_module.fail_json = mock_fail_json
    test_module.params = PARAMS_GET_INTERFACES_INFO
    test_module.warn = mock_warn
    network_collector = SunOSNetworkCollector(test_module)

    rc, out, err = test_module.run_command([test_module.params['ifconfig_path'], '-a'])

    facts = network_collector.get_interfaces_info(test_module.params['ifconfig_path'])
    assert len(facts) == 2
    assert facts[0] == FACTS_GET_INTERFACES_INFO.get('interfaces')

# Generated at 2022-06-11 03:44:14.013988
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    try:
        SunOSNetworkCollector().collect()
    except NotImplementedError:
        pass


# Generated at 2022-06-11 03:44:24.620663
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    rc, out, err = module.run_command('/bin/cat /usr/src/facts/network/facts/SunOS_ifconfig.txt')

    sunos_network = SunOSNetwork(module=None)
    interfaces, ips = sunos_network.get_interfaces_info(ifconfig_path=None)


# Generated at 2022-06-11 03:44:30.824306
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = dict(ansible_net_interfaces=['lo0', 'igb0', 'igb1', 'igb2', 'igb3', 'igb4', 'igb5'])
    n = SunOSNetworkCollector(None, facts, None)
    assert n._facts['ansible_net_interfaces'] == ['lo0', 'igb0', 'igb1', 'igb2', 'igb3', 'igb4', 'igb5']
    assert n._platform == 'SunOS'

# Generated at 2022-06-11 03:44:35.361337
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()

    # Test getting network facts
    network_collector.get_network_facts()

    # Test getting network facts
    network_collector.get_network_facts()

    # Test getting network facts
    network_collector.get_network_facts()

    # Test getting network facts
    network_collector.get_network_facts()

# Generated at 2022-06-11 03:44:36.375321
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:44:39.330078
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = NetworkCollector(None)
    assert isinstance(module, SunOSNetworkCollector)
    assert isinstance(module._fact_class, SunOSNetwork)
    assert module._platform == 'SunOS'

# Generated at 2022-06-11 03:44:42.027987
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert type(obj._fact_class) == SunOSNetwork
    assert obj._fact_class.platform == 'SunOS'


# Generated at 2022-06-11 03:44:43.799912
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == 'SunOS'

# Generated at 2022-06-11 03:44:44.920110
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()
