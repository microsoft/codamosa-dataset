

# Generated at 2022-06-11 03:35:52.397477
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible_collections.ansible.community.plugins.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.generic_bsd import BsdIfconfigNetworkModule
    from ansible_collections.ansible.community.plugins.module_utils.facts.network.sunos.sunos import SunOSNetworkCollector

    network_collector = SunOSNetworkCollector(BsdIfconfigNetworkModule())

    assert network_collector._fact_class == SunOSNetwork
    assert network_collector._platform == 'SunOS'

# Generated at 2022-06-11 03:35:55.087281
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    assert collector.platform == 'SunOS'
    assert isinstance(collector.fact_class, SunOSNetwork)
    assert collector.fact_class.platform == 'SunOS'

# Generated at 2022-06-11 03:36:01.856704
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunos_network = SunOSNetwork()
    assert sunos_network.parse_interface_line(['vni0:', 'flags=1000801084843<UP,POINTOPOINT,RUNNING,NOARP,MULTICAST,IPv4,VIRTUAL>', 'mtu', '1426'], {}, {}) == {'device': 'vni0', 'ipv4': [{'flags': ['UP', 'POINTOPOINT', 'RUNNING', 'NOARP', 'MULTICAST', 'IPv4', 'VIRTUAL'], 'mtu': '1426'}], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}

# Generated at 2022-06-11 03:36:11.606380
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos.facts import SunOSNetwork
    from types import SimpleNamespace as Namespace
    module = Namespace(run_command=lambda *args, **kwargs: (0, '', ''))
    sunos_nw = SunOSNetwork(module)
    interfaces, ips = sunos_nw.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'

# Generated at 2022-06-11 03:36:19.384121
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
  expected_result = { "SunOS": SunOSNetwork }
  result = SunOSNetworkCollector._platforms
  assert result == expected_result, "SunOSNetworkCollector._platforms should return a dict with a single key of 'SunOS'"
  assert isinstance(result['SunOS'], type), "SunOSNetworkCollector._platforms['SunOS'] should return a class of type 'type'"
  assert result['SunOS'].__name__ == 'SunOSNetwork', "SunOSNetworkCollector._platforms['SunOS'] should return a class named 'SunOSNetwork'"

# Generated at 2022-06-11 03:36:20.626485
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert issubclass(obj.fact_class, NetworkCollector)

# Generated at 2022-06-11 03:36:21.988819
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(), NetworkCollector)


# Generated at 2022-06-11 03:36:25.977789
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Test creation of SunOSNetworkCollector
    sunos_net_obj = SunOSNetworkCollector()
    assert sunos_net_obj
    # Test _fact_class variable
    assert sunos_net_obj._fact_class == SunOSNetwork
    # Test _platform variable
    assert sunos_net_obj._platform == 'SunOS'

# Generated at 2022-06-11 03:36:28.326224
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == 'SunOS'
    assert network_collector.fact_class._platform == 'SunOS'

# Generated at 2022-06-11 03:36:30.353498
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class.platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class.__name__ == 'SunOSNetwork'

# Generated at 2022-06-11 03:36:36.496266
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    o = SunOSNetworkCollector()
    assert o.platform == 'SunOS'


# Generated at 2022-06-11 03:36:48.374304
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetwork({})
    words = ['e1000g0:','flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4>','mtu=1500','index=3']
    current_if = {}
    interfaces = {}
    current_if = m.parse_interface_line(words, current_if, interfaces)
    assert current_if['ipv4'][0]['mtu'] == '1500'

    words = ['e1000g0:','flags=102843<UP,BROADCAST,RUNNING,MULTICAST,DHCP>','mtu=1500','index=3']
    current_if = m.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-11 03:36:58.635314
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.sunos.facts import SunOSNetwork
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork


# Generated at 2022-06-11 03:37:00.472695
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:37:11.227160
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ''' Test method get_interfaces_info of class SunOSNetwork
    '''
    class MySunOSNetwork(SunOSNetwork):
        ''' Test class SunOSNetwork
        '''
        def __init__(self, module):
            self.module = module
            self.log = module.log

    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list'),
        ),
        supports_check_mode=True,
    )

    # Create the class object for class SunOSNetwork
    test_obj = MySunOSNetwork(module=test_module)

    # Test getting interface info from class SunOSNetwork

# Generated at 2022-06-11 03:37:23.360556
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:37:32.017246
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:37:33.900616
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 03:37:36.789535
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock()
    collector = SunOSNetworkCollector(module)
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'


# Generated at 2022-06-11 03:37:40.749074
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Create dummy module
    module = type('AnsibleModule', (object,), dict(
        check_mode=False,
        params=dict()
    ))()

    # Instantiate SunOSNetworkCollector
    SunOSNetworkCollector(module)

# Generated at 2022-06-11 03:37:54.757655
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:37:57.248584
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module)

    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:38:06.786275
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    interface = 'e1000g1'
    interface_line = '%s: flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,DEPRECATED,IPv4> mtu 1500 index 2' % interface
    words = interface_line.split()

    sunos_network = SunOSNetwork()
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)

    assert current_if['type'] == 'unknown'
    assert current_if['ipv4'][0]['mtu'] == '1500'
    assert 'LOOPBACK' not in current_if['ipv4'][0]['flags']
    assert current_if['ipv6'] == []

# Generated at 2022-06-11 03:38:16.382709
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """ Unit test for method SunOSNetwork.get_interfaces_info """
    # empty command output
    out = ''
    obj = SunOSNetwork
    ifs, ips = obj.get_interfaces_info('/bin/ifconfig')
    assert ifs == {}
    assert ips == {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}

    # no interfaces
    out = '''
ifconfig: ioctl (SIOCGIFCONF): Can't get system interface table: no such file or directory
'''
    obj = SunOSNetwork
    ifs, ips = obj.get_interfaces_info('/bin/ifconfig')
    assert ifs == {}

# Generated at 2022-06-11 03:38:17.193331
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()

# Generated at 2022-06-11 03:38:19.786746
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    f = SunOSNetworkCollector()
    assert f.platform == 'SunOS'
    assert SunOSNetworkCollector.__doc__ == NetworkCollector.__doc__

# Generated at 2022-06-11 03:38:30.929901
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    import os
    import tempfile

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)


# Generated at 2022-06-11 03:38:41.078947
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    interfaces, ips = SunOSNetwork().get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'e1000g0' in interfaces
    assert '172.20.10.1' in ips['all_ipv4_addresses']
    assert '172.20.10.1' in interfaces['e1000g0']['ipv4'][0]['address']
    assert 'fe80::a00:27ff:fe02:abd1' in interfaces['e1000g0']['ipv6'][0]['address']
    assert 'ipv4' in interfaces['e1000g0']
    assert 'ipv6' in interfaces['e1000g0']


# Generated at 2022-06-11 03:38:51.216685
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Test data
    module = {"run_command": (0, "", "")}
    filename = "./solaris_ifconfig"
    obj = SunOSNetwork(module)
    interfaces, ips = obj.get_interfaces_info(filename)

# Generated at 2022-06-11 03:39:03.291537
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:39:22.354237
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    '''
    Test parse_interface_line and ensure it creates the correct data structure
    '''
    testing = SunOSNetwork()
    words = 'lo0: flags=2004841<UP,LOOPBACK,RUNNING,MULTICAST,IPv6> mtu 8252 index 1'.split()
    current_if = {}
    interfaces = {}
    current_if = testing.parse_interface_line(words, current_if, interfaces)
    assert(current_if == dict(device='lo0', ipv4=[dict(flags=['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv6'],
                                                         mtu='8252')], ipv6=[], type='loopback'))
    assert(interfaces['lo0'] == current_if)

    current_if = dict

# Generated at 2022-06-11 03:39:33.844058
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork


# Generated at 2022-06-11 03:39:43.092470
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = object()
    class_ = SunOSNetwork(module)
    words = ['e1000g0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4>', 'mtu', '1500']
    current_if = class_.parse_interface_line(words, {}, {})
    assert current_if.get('device') == 'e1000g0'
    assert current_if.get('type') == 'unknown'
    assert current_if.get('macaddress') == 'unknown'
    assert current_if.get('ipv4')[0].get('flags') == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'DHCP', 'IPv4']
    assert current_if.get('ipv4')[0].get

# Generated at 2022-06-11 03:39:45.286720
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.fact_class == SunOSNetwork
    assert network_collector._platform == 'SunOS'

# Generated at 2022-06-11 03:39:55.152233
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork


# Generated at 2022-06-11 03:39:57.578374
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert isinstance(obj, SunOSNetworkCollector)
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:39:59.700126
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network = SunOSNetworkCollector()
    assert network.platform == 'SunOS'
    assert network._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:40:01.974936
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collect_net_obj = SunOSNetworkCollector()
    assert isinstance(collect_net_obj, NetworkCollector)
    assert collect_net_obj.platform == 'SunOS'

# Generated at 2022-06-11 03:40:11.546772
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_lines = '''lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        options=80008<VLAN_MTU,LINKSTATE>
        nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>
        lo0: flags=2002000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8252 index 1
        options=80008<VLAN_MTU,LINKSTATE>
        nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>
        '''
    interfaces = {}
    current_if = {}
    

# Generated at 2022-06-11 03:40:13.395412
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:40:38.467533
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test parsing of Solaris 'ifconfig -a' output.
    Solaris can have different FLAGS and MTU for IPv4 and IPv6 on the same interface
    so these facts have been moved inside the 'ipv4' and 'ipv6' lists.
    """
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.sunos import SunOSNetwork

    module = patch('ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.sunos.SunOSNetwork.module').start()
    module.run_command.return_value = (0, ifconfig_a_output, '')


# Generated at 2022-06-11 03:40:40.844941
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Creation of SunOSNetworkCollector object.
    """
    obj = SunOSNetworkCollector(None, None)
    assert obj

# Generated at 2022-06-11 03:40:47.974064
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    interfaces, ips = SunOSNetwork().get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in interfaces
    assert interfaces['lo0']['ipv4']
    assert interfaces['lo0']['ipv6']

# Generated at 2022-06-11 03:40:51.245871
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == 'SunOS'
    assert network_collector.fact_class.platform == 'SunOS'


# Generated at 2022-06-11 03:41:02.084805
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    v = 'ipv4'
    words = [f'lo0:', 'flags=80049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '8232']
    current_if = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == '80049<UP,LOOPBACK,RUNNING,MULTICAST>'
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if['ipv6'] == []
    assert current_if['type'] == 'loopback'
    assert current_if['macaddress']

# Generated at 2022-06-11 03:41:04.403265
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork

# Generated at 2022-06-11 03:41:07.279623
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    m = module_mock()
    n = SunOSNetwork(m)
    n.get_interfaces_info('/sbin/ifconfig')


# Generated at 2022-06-11 03:41:18.124893
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    try:
        from ansible.module_utils.facts.network.sunos.test_SunOSNetworkFacts import TestSunOSNetworkFacts
    except ImportError:
        print('Could not load SunOSNetworkFacts test class: ' +
            'test_SunOSNetworkFacts.py not found.')
    module = TestSunOSNetworkFacts('test_SunOSNetwork_get_interfaces_info')
    SunOSNetwork().get_interfaces_info(module, '/sbin/ifconfig')

# Generated at 2022-06-11 03:41:19.962570
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == 'SunOS'

# Generated at 2022-06-11 03:41:29.799396
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    interfaces, ips = SunOSNetwork().get_interfaces_info('/usr/sbin/ifconfig')
    assert interfaces['bge0']['ipv4'][0]['address'] == '192.168.0.239'
    assert interfaces['bge0']['ipv4'][0]['broadcast'] == '192.168.0.255'
    assert interfaces['bge0']['ipv6'][0]['address'] == 'fe80::21e:c9ff:fea1:9b0c%bge0'
    assert interfaces['bge0']['ipv6'][0]['broadcast'] == 'ff02::1%2'
    assert interfaces['bge0']['ipv6'][0]['netmask'] == 'ffff:ffff:ffff:ffff::'

# Generated at 2022-06-11 03:42:03.274832
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(), NetworkCollector)


# Generated at 2022-06-11 03:42:04.982600
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collect = SunOSNetworkCollector()
    assert collect._fact_class == SunOSNetwork
    assert collect._platform == 'SunOS'

# Generated at 2022-06-11 03:42:15.371601
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    import os

    # This is a sample ifconfig output of solaris 11.3.
    #
    # $ ifconfig -a
    # lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
    #      inet 127.0.0.1 netmask ff000000
    #
    # nxge0: flags=10008802<BROADCAST,RUNNING,MULTICAST,IPv4> mtu 9000 index 2
    #      ether 0:14:4f:35:4e:b4
    #      media: Ethernet autoselect (1000baseT full-duplex)
    #      status: active
    # lo0: flags=2002000849<UP,LOOPBACK,RUNNING,MULT

# Generated at 2022-06-11 03:42:24.237965
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:42:34.221873
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = None
    ifconfig_path = '/sbin/ifconfig'
    current_if = {}
    interfaces = {}
    words = ['ce1:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = SunOSNetwork.parse_interface_line(module, ifconfig_path, words, current_if, interfaces)
    assert current_if['device'] == 'ce1'
    assert current_if['ipv4'][0]['flags'] == '1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>'
    assert current_if['ipv4'][0]['mtu'] == '1500'
    assert current_if['ipv6'] == []

# Generated at 2022-06-11 03:42:35.943321
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    return SunOSNetwork.get_interfaces_info(None, '/usr/sbin/ifconfig')

# Generated at 2022-06-11 03:42:46.188489
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('', (object,), {})
    m_module = type('', (object,), {
        'run_command': lambda self, args: (0, '', ''),
    })()

    m_module.run_command = lambda self, args: (0, SUNOS_IFCONFIG_ALL, '')

    module.params = {'gather_network_resources': ['all']}
    SunOSNetwork.module = m_module
    SunOSNetwork.platform = 'SunOS'
    ifaces, ips = SunOSNetwork.get_interfaces_info('/sbin/ifconfig')

    assert 'lo0' in ifaces
    assert ifaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-11 03:42:49.920042
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    import string
    import random
    random.seed(string.capwords('SunOSNetwork line'))
    new_if = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '8232', 'index', '2']
    new_if = SunOSNetwork().parse_interface_line(words, new_if, {})

    assert new_if['device'] == 'lo0'
    assert words[1] == new_if['ipv4'][len(new_if['ipv4']) - 1]['flags']

# Generated at 2022-06-11 03:42:52.074561
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform is 'SunOS'
    assert obj.fact_class is SunOSNetwork

# Generated at 2022-06-11 03:43:00.340766
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    this_module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all', '!min'], type='list'))
    )
    ifconfig_path = '/sbin/ifconfig'
    obj = SunOSNetwork()
    interfaces, ips = obj.get_interfaces_info(ifconfig_path)
    for interface in interfaces:
        for v in 'ipv4', 'ipv6':
            for facts in interfaces[interface][v]:
                for key in ['mtu', 'flags']:
                    this_module.assertTrue(key in facts)
        for v in 'ipv4', 'ipv6':
            this_module.assertTrue(len(interfaces[interface][v]) > 0)



# Generated at 2022-06-11 03:44:16.407432
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    '''Unit test for method get_interfaces_info of SunOSNetwork'''
    import os.path
    import sys

    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_file_path = os.path.join(test_dir, 'ifconfig_SunOS_1.txt')

    test_module = dict(
        run_command=lambda args: (0, open(test_file_path, 'rb').read(), ''),
    )

    test_class = SunOSNetwork(test_module)

    (interfaces, ips) = test_class.get_interfaces_info('')
    assert 'lo0' in interfaces.keys()
    assert 'lo0' in interfaces.keys()
    assert interfaces['lo0']['type'] == 'loopback'


# Generated at 2022-06-11 03:44:18.018658
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:44:28.073755
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:44:30.440579
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector._fact_class == SunOSNetwork
    assert network_collector._platform == 'SunOS'



# Generated at 2022-06-11 03:44:31.807984
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector().platform == 'SunOS'



# Generated at 2022-06-11 03:44:34.545873
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = object()
    collector = SunOSNetworkCollector(module)
    assert collector.module is module
    assert collector._fact_class is SunOSNetwork
    assert collector._platform == 'SunOS'

# Generated at 2022-06-11 03:44:36.639805
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == 'SunOS'


# Generated at 2022-06-11 03:44:38.101904
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(), NetworkCollector)



# Generated at 2022-06-11 03:44:48.176323
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    test_module = None

    try:
        import ansible.module_utils.facts.network.sunos
        from ansible.module_utils.facts.network.sunos import SunOSNetwork
    except ImportError:
        module.fail_json(msg="module ansible.module_utils.facts.network.sunos.SunOSNetwork not found")
        assert False

    test_SunOSNetwork = SunOSNetwork(test_module)

    # Test1: Test execution on Solaris returns expected value
    test_words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232' ]
    test_current_if = {}
    test_interfaces = {}

# Generated at 2022-06-11 03:44:57.951560
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test if interface information is parsed correctly.
    """
    data = """
lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        inet6 ::1/128
qfe0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2
        groupname ggg
        ether 0:3:ba:c2:1:80
        priority: 0
        inet 192.168.0.1 netmask ffffff00 broadcast 192.168.0.255
        inet 192.168.0.2 netmask ffffff00 broadcast 192.168.0.255
"""
   