

# Generated at 2022-06-11 03:35:55.814898
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:35:57.532466
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = DummyModule()
    SunOSNetworkCollector(module)
    assert module.get_bin_path.call_count == 1



# Generated at 2022-06-11 03:36:06.377671
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifc_rtn = open('tests/pytest/fixtures/SunOS_ifconfig_a', 'r').read()
    ifc_rtn = ifc_rtn.splitlines()
    ifc_rtn = [x for x in ifc_rtn if len(x) > 0]
    c = SunOSNetwork()
    c.module = MockModule()
    c.module.run_command = Mock(return_value=(0, ifc_rtn, ''))
    (interfaces, ips) = c.get_interfaces_info(1)
    assert len(interfaces) == 8
    bond0 = interfaces['bond0']
    assert bond0['type'] == 'bond'
    assert bond0['ipv4'][0]['mtu'] == '1500'

# Generated at 2022-06-11 03:36:16.812614
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    sut = SunOSNetwork(module=module)

    current_if = {}
    interfaces = {}

    current_if = sut.parse_interface_line(['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232'], current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL']

# Generated at 2022-06-11 03:36:24.731595
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = object()
    module.run_command = lambda cmd: (0, load_fixture('ifconfig_a_SunOS'), '')
    n = SunOSNetwork(module)
    interfaces, ips = n.get_interfaces_info('ifconfig')
    assert interfaces['bge0']['device'] == 'bge0'
    assert interfaces['bge0']['type'] == 'ether'
    assert interfaces['bge0']['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']
    assert interfaces['bge0']['mtu'] == '1500'
    assert interfaces['bge0']['macaddress'] == '00:14:4f:4f:20:04'
    assert interfaces['bge0']['ipv4']['address']

# Generated at 2022-06-11 03:36:31.060899
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test data
    test_words = [
        'lo0:',
        'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>',
        'mtu 8232',
    ]
    test_current_if = {'device': 'lo1', 'ipv4': [], 'ipv6': [], 'type': 'loopback'} # Dummy
    test_interfaces = {'lo1': test_current_if} # Dummy
    # Expected result

# Generated at 2022-06-11 03:36:43.071055
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from collections import OrderedDict
    from ansible.module_utils.facts.network.generic_bsd import Interface

    ifconfig_path = '/sbin/ifconfig'
    ip_path = '/sbin/ip'
    facts = SunOSNetwork(module=None, ifconfig_path=ifconfig_path, ip_path=ip_path)

    # The following output mimics what 'ifconfig -a' prints on a Solaris 10 host.
    # The last two lines are from a Solaris 11.3 host.

# Generated at 2022-06-11 03:36:46.016716
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    expected = SunOSNetworkCollector
    assert isinstance(network_collector, expected)


# Generated at 2022-06-11 03:36:56.544718
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    result = SunOSNetwork()

    # Test 1:
    # Test that a line of:
    # 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    # adds a loopback interface with ipv4 facts
    # and doesn't clobber the previously seen ipv6 facts.

# Generated at 2022-06-11 03:37:04.244062
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec=dict())
    interfaces = {}
    current_if = {}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    words1 = ['lo0:', 'flags=2001000849', 'mtu', '8232']
    words2 = ['lo0:', 'flags=849', 'mtu', '8232']
    words3 = ['lo0:', 'flags=849IPv6', 'mtu', '8232']

# Generated at 2022-06-11 03:37:23.679488
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = MockModule()
    net = SunOSNetwork(module=module)

    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL>', 'mtu', '8232']
    current_if = net.parse_interface_line(words, {}, {})
    assert current_if['device'] == 'lo0'
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'loopback'
    assert len(current_if['ipv4']) == 1
    assert len(current_if['ipv6']) == 1
    assert len(current_if['ipv6'][0].keys()) == 0

# Generated at 2022-06-11 03:37:27.876411
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Check the constructor of class SunOSNetworkCollector"""
    obj = SunOSNetworkCollector()
    assert hasattr(obj, '_platform')
    assert hasattr(obj, '_fact_class')
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:37:32.620527
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._platform == 'SunOS'
    assert obj._fact_class.platform == 'SunOS'
    assert obj._fact_class.__name__ == 'SunOSNetwork'
    assert obj._fact_class.__module__ == 'ansible.module_utils.facts.network.sunos'
    assert isinstance(obj._fact_class(), NetworkCollector)

# Generated at 2022-06-11 03:37:42.951115
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:37:52.669585
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test the method get_interfaces_info of class SunOSNetwork
    """

# Generated at 2022-06-11 03:38:01.531958
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = DummyModule()
    network = SunOSNetwork(module)

    interfaces = dict()
    current_if = dict()
    ips = dict()

    # 4 test cases:
    # line_words_1, line_words_2, interfaces, ips

# Generated at 2022-06-11 03:38:02.442489
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.collect()

# Generated at 2022-06-11 03:38:12.476420
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:38:21.714949
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:38:32.984015
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Unit test for method get_interface_info of class SunOSNetwork
    """
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts import Cache
    from datetime import datetime
    from ansible.module_utils._text import to_bytes

    def fake_module_run_command(self, command, check_rc=True, close_fds=True):
        rc = 0
        out = ''
        err = ''


# Generated at 2022-06-11 03:38:48.415804
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    Test case for the method parse_interface_line of class SunOSNetwork
    """
    sunos_network = SunOSNetwork()
    ifconfig_lines = ['lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1','lo0: flags=2002000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8252 index 1']
    for line in ifconfig_lines:
        words = line.split()
        current_if = { 'device': None, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
        new_current_if = sunos_network.parse_interface_line(words, current_if, {})

# Generated at 2022-06-11 03:38:50.160628
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'


# Generated at 2022-06-11 03:38:54.515036
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Create instance of SunOSNetworkCollector
    Check that facts from Solaris are added to the instance of SunOSNetworkCollector
    """
    network_facts_collector = SunOSNetworkCollector()
    assert network_facts_collector._fact_class._platform == 'SunOS'

# Generated at 2022-06-11 03:38:57.004979
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    m = SunOSNetworkCollector()
    assert type(m._fact_class) == SunOSNetwork
    assert m._platform == 'SunOS'

# Generated at 2022-06-11 03:38:59.939284
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    assert net_collector._fact_class == SunOSNetwork
    assert net_collector._platform == 'SunOS'



# Generated at 2022-06-11 03:39:11.024128
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:39:22.140759
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:39:24.960568
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert isinstance(network_collector._fact_class, SunOSNetwork)
    assert network_collector._platform == 'SunOS'

# Generated at 2022-06-11 03:39:27.330874
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:39:38.095392
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    network = SunOSNetwork(module)

# Generated at 2022-06-11 03:39:51.373031
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.__class__.__name__ == 'SunOSNetworkCollector'

# Generated at 2022-06-11 03:40:01.352233
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    result_dummy = {'device': 'dummy0',
                    'type': 'unknown',
                    'ipv4': [{'flags': ['BROADCAST', 'MULTICAST'],
                              'mtu': '1500'}],
                    'ipv6': []}

    result_lo = {'device': 'lo0',
                 'type': 'loopback',
                 'ipv4': [{'flags': ['UP',
                                     'LOOPBACK',
                                     'RUNNING',
                                     'MULTICAST',
                                     'IPv4'],
                           'mtu': '8232'}],
                 'ipv6': []}

    collector = SunOSNetworkCollector(None, None, None, None)
    # First test
    current_if = {}
    interfaces = {}
   

# Generated at 2022-06-11 03:40:10.854922
# Unit test for constructor of class SunOSNetworkCollector

# Generated at 2022-06-11 03:40:18.412063
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    test_class = SunOSNetwork(module=module)

    result = test_class.get_interfaces_info(ifconfig_path='/usr/sbin/ifconfig')
    assert result[0]['lo0']['ipv4'][0]['flags'] == ["UP", "LOOPBACK", "RUNNING"]
    assert result[0]['lo0']['ipv4'][0]['mtu'] == "8228"


# Unit test class for SunOSNetwork

# Generated at 2022-06-11 03:40:20.811882
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:40:31.354606
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_config_1 = '''en0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2
        inet 10.213.20.53 netmask ffffff00 broadcast 10.213.20.255
        ether 0:1:2:d:e:f
'''
    test_config_2 = '''en1: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv6> mtu 1500 index 2
        options=3<RXCSUM,TXCSUM>
        inet6 fe80::1ff:fe23:4567:890a%en1 prefixlen 64 scopeid 0x2
        ether 00:1f:f3:45:67:89
'''

    test_config_3

# Generated at 2022-06-11 03:40:33.508257
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:40:35.525853
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork

# Generated at 2022-06-11 03:40:36.974834
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector(None, None)
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetworkCollector

# Generated at 2022-06-11 03:40:48.778995
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_class = SunOSNetwork()
    test_class.module = AnsibleModuleMock()

# Generated at 2022-06-11 03:41:10.454292
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:41:13.157329
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    assert net_collector.platform == 'SunOS'
    assert net_collector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:41:23.953665
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from collections import namedtuple
    from unittest import TestCase, TextTestRunner
    from textwrap import dedent

    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    MockModule = namedtuple('MockModule', ['run_command'])

# Generated at 2022-06-11 03:41:24.994158
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector(dict())

# Generated at 2022-06-11 03:41:25.999813
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:41:33.336944
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    if not module.params['gather_subset']:
        module.params['gather_subset'].append('!all')
    # SunOSNetwork.get_interfaces_info() checks for command existence,
    # so use a fake path here
    interfaces, ips = SunOSNetwork(module).get_interfaces_info('/no/ifconfig/path')

    assert 'lo0' in interfaces.keys()
    assert interfaces.get('lo0').get('type') == 'loopback'
    assert 'ipv4' in interfaces.get('lo0').keys()
    assert interfaces.get('lo0').get

# Generated at 2022-06-11 03:41:43.555083
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create an instance of SunOSNetwork class
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    network_module = SunOSNetwork(module=module)

    # Create test output

# Generated at 2022-06-11 03:41:51.943474
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from collections import namedtuple

    FakeArgs = namedtuple('FakeArgs', ['network_debug'])

    class FakeModule:
        def __init__(self):
            self.args = FakeArgs(network_debug=False)

        def get_bin_path(self, arg, default=None):
            return '/usr/sbin/ifconfig'


# Generated at 2022-06-11 03:41:53.219771
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    obj = SunOSNetworkCollector()
    assert isinstance(obj.facts['ansible_network'], SunOSNetwork)

# Generated at 2022-06-11 03:42:00.602483
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:42:26.154476
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    fact = SunOSNetworkCollector()
    assert fact._fact_class is SunOSNetwork

# Generated at 2022-06-11 03:42:28.640226
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    assert net_collector._platform == 'SunOS'
    assert net_collector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:42:33.998524
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    facts = SunOSNetwork()
    facts._module = FakeAnsibleModule
    facts._module.params['gather_subset'] = ['!all', 'min']
    facts._module.exit_json = _exit_json
    facts.get_interfaces_info(ifconfig_path='/sbin/ifconfig')

# Hacky way to make 'ansible-test network-unit SunOS' work.

# Generated at 2022-06-11 03:42:40.958197
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import Mock
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch

    fake_module = Mock()
    fake_module.params = {}
    with patch('ansible.module_utils.facts.network.sunos.SunOSNetwork'):
        result = SunOSNetworkCollector(fake_module)

    assert(result._fact_class is not None)
    assert(result._platform == 'SunOS')

# Generated at 2022-06-11 03:42:45.078651
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    This function instantiates NetworkCollector with
    'SunOSNetworkCollector' class as argument.
    """
    fact_network = SunOSNetworkCollector()
    assert isinstance(fact_network, SunOSNetworkCollector)
    assert isinstance(fact_network._fact_class, SunOSNetwork)

# Generated at 2022-06-11 03:42:54.839310
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_input = [
        # 'interface line with IPv4',
        "e1000g0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2",
        # 'interface line with IPv6',
        "e1000g0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv6> mtu 1500 index 2"
    ]

# Generated at 2022-06-11 03:42:56.106766
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunosnet = SunOSNetworkCollector()
    assert sunosnet.platform == 'SunOS'

# Generated at 2022-06-11 03:43:01.978732
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock()
    n = NetworkCollector.create(module)
    assert isinstance(n, SunOSNetworkCollector)
    # check if class NetworkCollector is subclass of NetworkCollector?
    assert issubclass(n.__class__, NetworkCollector)
    # check if class GenericBsdIfconfigNetwork  is subclass of class Network?
    assert issubclass(n.get_network_instance().__class__, Network)
    assert issubclass(n.get_network_instance().__class__, SunOSNetwork)



# Generated at 2022-06-11 03:43:03.765734
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:43:04.688855
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:43:52.584769
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    result = SunOSNetworkCollector()
    assert result
    assert isinstance(result, NetworkCollector)
    assert isinstance(result.platforms, dict)
    assert 'SunOS' in result.platforms
    assert result.platforms['SunOS']['facts_class'] == SunOSNetwork
    assert isinstance(result.facts_classes, list)
    assert SunOSNetwork in result.facts_classes

# Generated at 2022-06-11 03:43:53.516098
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-11 03:43:55.481266
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    NetworkCollector.clear_module_instances()
    SunOSNetworkCollector().collect()



# Generated at 2022-06-11 03:44:05.252725
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockModule()
    obj = SunOSNetwork(module)
    # The features and capabilities of Solaris ifconfig output makes it very difficult
    # to parse and understand. So, I have used 'ifconfig -a' output from a Solaris
    # system and the corresponding code to create a mock output.
    obj.module.run_command = Mock(return_value=(0, IF_CONFIG_OUTPUT, ''))
    interfaces, ips = obj.get_interfaces_info('/sbin/ifconfig')
    for iface, info in interfaces.items():
        for field in ['device', 'type', 'number', 'ipv4', 'ipv6', 'macaddress']:
            if field not in info:
                print("Field '%s' not present in 'ifconfig -a' output." % field)

# Generated at 2022-06-11 03:44:14.661759
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=[], type='list')})
    if not HAS_NETIFACES:
        module.fail_json(msg=missing_required_lib('netifaces'), exception='is_required')

    # Open the ifconfig output sample file
    ifconfig_path = '/sbin/ifconfig'
    with open('/etc/ansible/facts.d/SUNOS_SAMPLE_ifconfig.txt', 'r') as ifconfig_file:
        ifconfig_file_lines = ifconfig_file.readlines()

    # Create a mock module and class
    mock_module = MagicMock(return_value=module)
    mock_class = MagicMock(return_value=SunOSNetwork())

    # Mock 'run_commands' method of SunOS

# Generated at 2022-06-11 03:44:25.262559
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL']
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert 'ipv6' not in current_if
    assert current_if['type'] == 'loopback'

   

# Generated at 2022-06-11 03:44:34.716937
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)


# Generated at 2022-06-11 03:44:44.775992
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    This unit test checks the correct functioning of get_interfaces_info method
    of class SunOSNetwork.

    Input data comes from a sample of 'ifconfig -a' output of SunOS 11.3.
    """

# Generated at 2022-06-11 03:44:54.599472
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:45:04.182594
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    test_object = SunOSNetwork({},{})
