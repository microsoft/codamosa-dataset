

# Generated at 2022-06-11 03:35:54.535262
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    Collector = SunOSNetworkCollector()

    assert Collector._fact_class == SunOSNetwork
    assert Collector._platform == 'SunOS'


# Generated at 2022-06-11 03:35:55.887100
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector()
    assert isinstance(facts, NetworkCollector)


# Generated at 2022-06-11 03:35:59.727673
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule()
    sunos = SunOSNetwork(module)
    facts = dict()

    facts = sunos.get_interfaces_info("/bin/true")

    assert facts[0] == dict()
    assert facts[1] == dict(all_ipv4_addresses=[], all_ipv6_addresses=[])


# Generated at 2022-06-11 03:36:02.629531
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:36:03.703426
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert(obj._fact_class is not None)

# Generated at 2022-06-11 03:36:10.096372
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = DummyModule()
    netFact = SunOSNetwork(module)
    words = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    netFact.parse_interface_line(words.split(), {}, {})
    assert 'mtu' == netFact._fact.current_if['ipv4'][0].keys()[0]

# Generated at 2022-06-11 03:36:12.658363
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == 'SunOS'
    assert network_collector.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:36:23.036440
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollector()
    SunOSNetwork_getter = SunOSNetwork(module)
    # TODO: Move test data to a file

# Generated at 2022-06-11 03:36:33.267096
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    import platform

    # On SunOS, test data comes from /usr/sbin/ifconfig -a
    if platform.system().lower() != 'sunos':
        content = get_file_content('/usr/sbin/ifconfig', module_name='test.test_sunos_network')
        content = content.splitlines()
    else:
        content = open('/usr/sbin/ifconfig', 'r').readlines()

    # Call the method get_interfaces_info of class SunOSNetwork
    sunOSNetwork = SunOSNetwork()
    sunOS

# Generated at 2022-06-11 03:36:35.356519
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert isinstance(obj._fact_class(obj.module), SunOSNetwork)

# Generated at 2022-06-11 03:36:44.253044
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    assert net_collector._platform == 'SunOS'

# Unit tests for constructor of class SunOSNetwork

# Generated at 2022-06-11 03:36:54.821468
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Test with a real output of the command ifconfig
    filename = 'ansible_module_network_info_output'
    fact_module = SunOSNetwork()
    interfaces, ips = fact_module.get_interfaces_info('/sbin/ifconfig')

# Generated at 2022-06-11 03:36:56.271835
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()

    assert collector.get_facts() is None

# Generated at 2022-06-11 03:37:04.093293
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:37:16.432648
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['!all'], type='list')
    })
    obj = SunOSNetwork(module)

# Generated at 2022-06-11 03:37:18.884144
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock()
    collector = SunOSNetworkCollector(module)
    assert collector != None


# Generated at 2022-06-11 03:37:29.133944
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    fn = SunOSNetwork.get_interfaces_info

    # Test with Solaris 11.2 output

# Generated at 2022-06-11 03:37:31.429520
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()

    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSNetwork

# Unit tests for class SunOSNetwork

# Generated at 2022-06-11 03:37:33.720358
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == "SunOS"
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-11 03:37:43.940430
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    m = SunOSNetwork(dict(module=dict()), dict(), dict())
    path_to_ifconfig = '/path/to/ifconfig'


# Generated at 2022-06-11 03:38:05.527871
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Test function 'get_interfaces_info' of SunOSNetwork class
    # Facts returned from 'ifconfig -a' on Solaris 11.4
    ifconfig_path = 'ifconfig'

# Generated at 2022-06-11 03:38:07.726400
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    NetworkCollector class is abstract
    This method will fail if instantiating abstract class.
    """
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:38:17.119293
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    Module = get_module(dict(gather_subset='!all,network'))
    obj = SunOSNetwork(Module)
    interfaces = obj.get_interfaces_info('/sbin/ifconfig')

    # Test interface 'lo0'
    lo0 = interfaces[0]['lo0']
    assert lo0['device'] == 'lo0'
    assert lo0['ipv4'][0]['address'] == '127.0.0.1'
    assert lo0['ipv4'][0]['netmask'] == '255.0.0.0'
    assert lo0['ipv6'][0]['address'] == '::1/128'
    assert lo0['mtu'] == 8232
    assert lo0['type'] == 'loopback'

# Generated at 2022-06-11 03:38:22.732050
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:38:25.288121
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    nc = SunOSNetworkCollector()
    assert nc._fact_class == SunOSNetwork
    assert nc._platform == 'SunOS'

# Generated at 2022-06-11 03:38:26.776478
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)

# Generated at 2022-06-11 03:38:37.401094
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-11 03:38:39.606699
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert isinstance(obj._fact_class, SunOSNetwork)
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:38:41.819759
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    assert net_collector._fact_class.platform == 'SunOS'


# Generated at 2022-06-11 03:38:52.093419
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:39:14.908314
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    """
    This is the SunOSNetwork Unit test for the method get_interfaces_info
    It tests several scenarios with different kinds of ifconfig output.
    """
    from ansible.module_utils.facts.network.generic_bsd import get_interfaces_info
    from ansible.module_utils.facts.network.sunos import get_interfaces_info as sunos_get_interfaces_info
    platform = 'SunOS'
    key = 'ansible_' + platform
    ifconfig_path = 'fake_path'

    # Test #1: Loopback interface with IPv4 and IPv6 addresses

# Generated at 2022-06-11 03:39:16.904274
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = get_test_module()
    SunOSNetworkCollector.test(module)



# Generated at 2022-06-11 03:39:28.085984
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Arrange
    ifc = SunOSNetwork()
    mock_module = MagicMock(name='module')
    ifc.module = mock_module

# Generated at 2022-06-11 03:39:38.643706
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    fake_module = object()

# Generated at 2022-06-11 03:39:47.704020
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = get_module_mock()
    interfaces = SunOSNetwork.get_interfaces_info(module, '/sbin/ifconfig')
    # pprint(interfaces)
    assert len(interfaces['interfaces']['lo0']['ipv6']) == 1
    assert len(interfaces['interfaces']['lo0']['ipv4']) == 1
    assert len(interfaces['interfaces']['lo0']['ipv4'][0]['address']) == 2
    assert interfaces['interfaces']['lo0']['type'] == 'loopback'
    assert len(interfaces['interfaces']['lo0']['flags']) == 2
    assert interfaces['interfaces']['lo0']['flags'][0].startswith('UP')
    assert interfaces

# Generated at 2022-06-11 03:39:52.948139
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # test for a subclass of NetworkCollector
    assert issubclass(SunOSNetworkCollector, NetworkCollector)

    # constructor test:
    # This override contains no code, just inherits
    # the PlatformCollector constructor, so we just
    # test to make sure it's there and call it.
    c = SunOSNetworkCollector()
    assert c
    c = c.get_facts()
    assert c

# Generated at 2022-06-11 03:40:02.498713
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    o = SunOSNetworkCollector(dict(module=dict()), dict())

    # This is the output of Solaris 10 and 11 ifconfig -a
    # It contains some features not found on older versions of Solaris.

# Generated at 2022-06-11 03:40:04.594000
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj.platform == 'SunOS'

# Generated at 2022-06-11 03:40:14.385025
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = type('module', (), {})()
    module.run_command = lambda args: (0, '', '')
    # test data
    words = ['e1000g0:', 'flags=10000114843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,NOFAILOVER>', 'mtu', '1500']
    current_if = {}
    interfaces = {}
    sunos_network = SunOSNetwork(module)
    # run test
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    # validate result
    assert current_if['device'] == 'e1000g0'
    assert current_if['ipv4'][0]['mtu'] == '1500'

# Generated at 2022-06-11 03:40:21.841551
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    # https://stackoverflow.com/questions/853884/how-should-i-unit-test-python-code-that-uses-os-environ#853911
    import unittest.mock as mock
    with mock.patch.dict('os.environ', {'ANSIBLE_NET_IFACES': '/dev/null'}):
        collector = SunOSNetworkCollector()

    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:41:03.877578
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeModule()
    module.run_command.return_value = [0, '', '']
    sunos = SunOSNetwork(module=module)

    interfaces, ips = sunos.get_interfaces_info('/sbin/ifconfig')

    assert interfaces['lo0']['ipv6'][0].get('ip6') == '::1/128'
    assert interfaces['lo0']['ipv6'][0].get('netmask6') == 'ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff'
    assert interfaces['lo0']['ipv6'][0].get('scope6') == 'Host'
    assert interfaces['lo0']['ipv6'][0]['ipaddr6'] == '::1/128'

# Generated at 2022-06-11 03:41:14.621076
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    interfaces_info = SunOSNetwork().get_interfaces_info('/sbin/ifconfig')
    # The dict 'interfaces_info' returned by SunOSNetwork.get_interfaces_info()
    # is a tuple containing two dicts.
    # One dict has network interface facts, the other contains IP-specific facts.
    # The test below checks the structure of the dict holding network interface facts.
    # The list of keys (device names) in the dict 'interfaces_info' is sorted because
    # the order of device names returned by SunOSNetwork.get_interfaces_info() is
    # not guaranteed.
    interface_keys = sorted(interfaces_info[0])

# Generated at 2022-06-11 03:41:20.147503
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:41:23.328999
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    m = SunOSNetworkCollector()
    assert m.collect()
    assert m.interfaces
    assert m.interfaces_ipv4
    assert m.interfaces_ipv6

# Generated at 2022-06-11 03:41:26.400854
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructor of class SunOSNetworkCollector should create an object of class SunOSNetworkCollector
    """
    obj = SunOSNetworkCollector()
    assert isinstance(obj, SunOSNetworkCollector)

# Generated at 2022-06-11 03:41:34.525605
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollector._create_test_module('SunOS')
    collector = SunOSNetwork(module)

    # Test different Ethernet, VLAN and EoIB interfaces

# Generated at 2022-06-11 03:41:44.764692
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-11 03:41:52.773254
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    network_collector_obj = SunOSNetwork()

    iface_dict = network_collector_obj.get_interfaces_info("/sbin/ifconfig")
    # Sample dict
    # {'lo0': {'ipv4': [{'address': '127.0.0.1', 'netmask': '255.0.0.0', 'broadcast': '127.255.255.255'}],
    #         'ipv6': [{'address': '::1', 'prefix': '0'},
    #                  {'address': 'fe80::1%lo0', 'prefix': '64'}],
    #         'type': 'loopback',
    #         'macaddress': 'unknown'},
    #  'vlan55': {'ipv4': [{'address': '192.168.

# Generated at 2022-06-11 03:42:00.277840
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    network = SunOSNetwork(module)


# Generated at 2022-06-11 03:42:02.726181
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule({})
    collector = SunOSNetworkCollector(module=module)
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:43:10.781485
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # This will create instance of SunOSNetworkCollector
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:43:20.761866
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    iface = 'lo0'
    flags = 'UP,BROADCAST,DEBUG,LOOPBACK,IPv6,RUNNING'
    mtu = '1500'
    current_if = {'device': iface, 'ipv4': [], 'ipv6': []}
    interfaces = {}
    ips = {}

    # IPv4
    words = ['lo0:', flags, 'mtu', mtu]
    network = SunOSNetwork()
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if == {'device': iface, 'ipv4': [{'flags': flags, 'mtu': mtu}], 'ipv6': []}
    interfaces = {iface: current_if}

    # IPv6

# Generated at 2022-06-11 03:43:28.750294
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    result = collector.get_facts()

    # Check that the 'get_facts' function has been called
    assert result

    # Check the version number returned
    assert isinstance(result['ansible_facts']['ansible_net_version'], str)

    # Check the interfaces return
    assert isinstance(result['ansible_facts']['ansible_net_interfaces'], dict)

    # Check the interface IPs return
    assert isinstance(result['ansible_facts']['ansible_net_all_ipv4_addresses'], list)
    assert isinstance(result['ansible_facts']['ansible_net_all_ipv6_addresses'], list)



# Generated at 2022-06-11 03:43:37.586239
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda *args, **kwargs: (0, 'success', '')
    })()

    SunOSNetwork.module = mock_module

    # get_interfaces_info() returns two values
    interfaces, ips = SunOSNetwork.get_interfaces_info('/sbin/ifconfig')

    # verify that each key exists in the returned interfaces dictionary
    for key in ['lo0', 'ce1', 'aggr1', 'aggr2', 'ce3', 'ce4', 'ce5', 'ce6', 'lo1', 'ce0']:
        assert key in interfaces
        assert key in interfaces
        assert len(interfaces[key]['ipv4']) > 0

# Generated at 2022-06-11 03:43:38.708315
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    T = SunOSNetworkCollector()
    assert T != None

# Generated at 2022-06-11 03:43:48.210099
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=[], type='list'),
        'gather_network_resources': dict(default=[], type='list')
    })
    sunos = SunOSNetwork(module=module)
    output = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1\n'
    output += 'inet 127.0.0.1 netmask ff000000\n'
    output += 'lo0: flags=2002000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8252 index 1\n'
    output += 'inet6 ::1/128\n'

# Generated at 2022-06-11 03:43:57.929473
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = 'fake_ansible_module'
    current_if = {}
    interfaces = {}
    networks = SunOSNetwork(module)

    # Solaris 10
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = networks.parse_interface_line(words, current_if, interfaces)
    assert current_if.get('device') == 'lo0'
    assert current_if.get('type') == 'loopback'
    assert current_if.get('ipv4')[0].get('flags') == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'
    assert current_if

# Generated at 2022-06-11 03:44:07.603371
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule({})
    network_collector = SunOSNetworkCollector(module)
    network_util = SunOSNetwork(module)
    current_if = {}

    # The following cases are tested
    # 1. lo0
    # 2. lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
    # 3. lo0:1: flags=2000841<UP,LOOPBACK,RUNNING,MULTICAST,IPv6>  mtu 8252 index 1
    # 4. bge0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2
    # 5. bge0:1: flags=2000841<

# Generated at 2022-06-11 03:44:12.253446
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # This essentially tests that it's object was created properly
    sunos_network_collector = SunOSNetworkCollector()

    assert isinstance(sunos_network_collector, NetworkCollector)
    assert isinstance(sunos_network_collector, SunOSNetworkCollector)
    assert isinstance(sunos_network_collector._fact_class, SunOSNetwork)



# Generated at 2022-06-11 03:44:22.836488
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock()
    facts = SunOSNetworkCollector(module).collect()
    assert SunOSNetworkCollector(module)._platform == 'SunOS'


# class AnsibleModuleMock(object):
#     ''' Mock class for AnsibleModule '''
#
#     class AnisbleModuleFailJson(object):
#         ''' Mock class for AnsibleModule.fail_json '''
#
#         def __init__(self, message):
#             self.message = message
#
#         def __repr__(self):
#             return str(self.message)
#
#     def __init__(self, *args, **kwargs):
#         ''' Constructor for AnsibleModuleMock '''
#         pass
#
#     def fail_json(self, *args, **kw