

# Generated at 2022-06-11 03:35:49.414111
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()


# Generated at 2022-06-11 03:35:56.367025
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    m = SunOSNetwork({})
    ifaces, ips = m.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in ifaces
    # Solaris can have different FLAGS and MTU for IPv4 and IPv6 on the same interface
    # so these facts have been moved inside the 'ipv4' and 'ipv6' lists.
    assert 'flags' in ifaces['lo0']['ipv4'][0]
    assert 'mtu' in ifaces['lo0']['ipv4'][0]
    assert ifaces['lo0']['ipv4'][0]['mtu'] == '0'
    assert 'flags' in ifaces['lo0']['ipv6'][0]

# Generated at 2022-06-11 03:35:57.200529
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-11 03:35:58.592068
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._platform == 'SunOS'


# Generated at 2022-06-11 03:35:59.453682
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector() is not None

# Generated at 2022-06-11 03:36:08.566244
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:36:13.345977
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    '''Unit test for method get_interfaces_info of class SunOSNetwork'''
    module = NetworkCollector._test_module
    collector = SunOSNetworkCollector(module)
    interfaces, ips = collector.get_interfaces_info()
    #print("interfaces = %s" % interfaces)
    #print("ips = %s" % ips)
    assert interfaces != {}

# Generated at 2022-06-11 03:36:23.619427
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    mock_module = patch.multiple(SunOSNetwork,
                                 get_interfaces_info=unittest.mock.DEFAULT,
                                 )
    mock_module.start()

    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.sunos import SunOSNetwork


# Generated at 2022-06-11 03:36:34.125859
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    src = '''lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        ip: flags=20002004841<UP,RUNNING,MULTICAST,DHCP,IPv4,ADDRCONF> mtu 1500 index 2
        inet 10.1.0.112 netmask ffffff00 broadcast 10.1.0.255
        ether 5:0:17:c4:3a:4c
        media: Ethernet autoselect (1000baseT full-duplex) status: active
        '''

# Generated at 2022-06-11 03:36:46.179121
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    intf = SunOSNetwork(module)

# Generated at 2022-06-11 03:37:00.395939
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    FRAMING_OUTPUT = """\
lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        ether 8:0:20:8b:c:18
"""
    frm = SunOSNetwork()
    version, interfaces, ips = frm.get_interfaces_info('')
    assert version['os_version'] == '14.3'
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'

# Generated at 2022-06-11 03:37:05.865510
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'
    iface = 'lo0'

# Generated at 2022-06-11 03:37:18.308533
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    testmodule = MockAnsibleModule(module_arguments={})

# Generated at 2022-06-11 03:37:20.179191
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact_class = SunOSNetworkCollector(None, None, None)
    assert fact_class.platform == 'SunOS'

# Generated at 2022-06-11 03:37:25.894906
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test class SunOSNetworkCollector"""

    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._fact_class._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class.platform == 'SunOS'

# Unit tests for constructor and methods of class SunOSNetwork

# Generated at 2022-06-11 03:37:27.882804
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network = SunOSNetworkCollector()
    assert network._platform == 'SunOS'
    assert network._fact_class == SunOSNetwork
    assert network._config_file == '/etc/net/ticlts/hosts'

# Generated at 2022-06-11 03:37:37.265753
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Dict to hold interface info, populated by method parsing the ifconfig CLI output.
    # Use an empty dict for the current_if argument.
    interfaces = {}
    current_if = {}
    # List containing the line to be parsed by method parse_interface_line
    words = ['bge0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>',
             'mtu=1500', 'index=3', 'inet6', 'fe80::203:baff:fe29:5a5%bge0',
             'prefixlen', '64', 'scopeid', '0x4']
    # Call method parse_interface_line.
    current_if = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    # Check that interface device name

# Generated at 2022-06-11 03:37:41.276667
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    network_facts = SunOSNetworkCollector(module)
    assert network_facts.platform == 'SunOS'
    assert network_facts.module == module
    assert isinstance(network_facts.fact, SunOSNetwork)


# Generated at 2022-06-11 03:37:47.575515
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = 'module'
    net_collector = SunOSNetworkCollector(module)
    assert net_collector._fact_class == SunOSNetwork
    assert net_collector._platform == 'SunOS'
    assert net_collector._module == module

# There is no unit test for collector method collect() as it uses module_utils.facts.network.generic_bsd.GenericBsdIfconfigNetwork.get_interfaces_info()
# which has been tested in test_freebsd_network.py

# Generated at 2022-06-11 03:37:56.918258
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetwork(dict(module=dict()))
    current_if = dict()

    # Test with an IPv4 interface line
    words = ['lo0:', 'flags=2001000849', 'mtu', '8232', 'index', '1']
    interfaces = dict()
    current_if = m.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == m.get_options(words[1])
    assert current_if['ipv4'][0]['mtu'] == words[3]
    # Test with an IPv6 interface line
    words = ['net0:', 'flags=1000841', 'mtu', '1500', 'index', '2']

# Generated at 2022-06-11 03:38:12.140314
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockNetworkModule()
    result = SunOSNetwork.get_interfaces_info(module, 'fake_path')

# Generated at 2022-06-11 03:38:20.061919
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:38:21.527808
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:38:32.842219
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos.interfaces import SunOSNetwork
    import sys

    if sys.version_info.major > 2:
        unicode = str

    # Get interfaces info with two interfaces

# Generated at 2022-06-11 03:38:35.047998
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sc = SunOSNetworkCollector()
    assert sc.platform == 'SunOS'
    assert sc._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:38:45.220686
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    class TestModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    testmodule = TestModule()

    # Sample data from: ifconfig -a on Solaris with IPv4 and IPv6

# Generated at 2022-06-11 03:38:55.821469
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:39:00.633070
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    collector = SunOSNetworkCollector()
    assert collector._fact_class == SunOSNetwork, '_fact_class must be SunOSNetwork'
    assert isinstance(collector._fact_class(), GenericBsdIfconfigNetwork)

# Generated at 2022-06-11 03:39:03.032932
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    nm = SunOSNetworkCollector(None)
    assert nm._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 03:39:07.651554
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    platform = 'SunOS'
    module = AnsibleModule(argument_spec=dict())
    network_module = SunOSNetwork()
    interfaces, ips = network_module.get_interfaces_info(module.get_bin_path('ifconfig', True))
    assert 'lo0' in interfaces
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1/128'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'


# Generated at 2022-06-11 03:39:23.395978
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # ifconfig output for en5 and en6 interfaces on Solaris 11.4
    test_data = ['en6: flags=849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6> mtu 8252 index 1',
                 'en5: flags=843<UP,BROADCAST,RUNNING,MULTICAST,ROUTER> mtu 1500 index 3']
    test_interfaces = {}
    test_ips = []
    test_class = SunOSNetworkCollector()._fact_class()
    for line in test_data:
        words = line.split()
        current_if = {}
        test_interfaces = test_class.parse_interface_line(words, current_if, test_interfaces)
    # 'parse_interface_line' leaves two dicts in the ipv4/

# Generated at 2022-06-11 03:39:25.793898
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class is SunOSNetwork

# Generated at 2022-06-11 03:39:36.814714
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_module = NetworkCollector()
    test_class = SunOSNetwork(test_module)
    current_if = {'device': 'lo0'}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']
    results = test_class.parse_interface_line(words, current_if, interfaces)
    assert 'device' in results
    assert 'lo0' == results['device']
    assert 'type' in results
    assert 'loopback' == results['type']
    assert 'ipv4' in results
    assert 'ipv6' in results
    assert 'mtu' in results['ipv4'][0]
   

# Generated at 2022-06-11 03:39:45.746100
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_object = SunOSNetwork()
    ifconfig_path = 'tests/unit/module_utils/facts/network/bsd/ifconfig_output.txt'
    with open(ifconfig_path) as f:
        test_object.ifconfig_output = f.read()
    iface_list = [
        ('lo0', 'lo0'),
        ('lo1', 'lo1'),
        ('igb0', 'igb0'),
        ('igb1', 'igb1'),
        ('igb2', 'igb2')
    ]
    for idx, iface in enumerate(iface_list):
        assert iface[0] == test_object.get_interfaces_info(ifconfig_path)[0][idx]['device']
        assert iface[1] == test_object.get_

# Generated at 2022-06-11 03:39:48.953678
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    nm = SunOSNetworkCollector(module)
    assert nm.platform == 'SunOS'
    assert nm.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:39:58.864437
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:40:08.392603
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:40:09.717730
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    c = SunOSNetworkCollector()
    assert isinstance(c, NetworkCollector)

# Generated at 2022-06-11 03:40:20.419108
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'

# Generated at 2022-06-11 03:40:31.054155
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    FAKE_IFACE = 'eth0'
    FAKE_MAC = '00:00:de:ad:be:ef'
    FAKE_IPV4_1 = '192.0.2.1'
    FAKE_IPV4_2 = '192.0.2.2'
    FAKE_IPV4_CIDR_1 = '192.0.2.1/24'
    FAKE_IPV4_CIDR_2 = '192.0.2.2/24'
    FAKE_IPV4_NETMASK_1 = '255.255.255.0'
    FAKE_IPV4_NETMASK_2 = '255.255.255.128'
    FAKE_IPV6_1 = '2001:db8:0:1::1'
    FAKE_

# Generated at 2022-06-11 03:40:37.111828
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-11 03:40:43.921357
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # This test is only valid on OpenIndiana (which is based on Solaris 11)
    if SunOSNetwork.platform != 'SunOS':
        return
    ifconfig_path = '/usr/sbin/ifconfig'

    # Set up a test object

# Generated at 2022-06-11 03:40:55.016369
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    test_platform = 'SunOS'

# Generated at 2022-06-11 03:41:05.917301
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    ifconfig_path = 'ifconfig'
    module = MockModule()

    facts = SunOSNetwork(module)
    interfaces, ips = facts.get_interfaces_info(ifconfig_path)

    # hostname
    assert 'hostname' in ips
    assert ips['hostname'] == 'notohostname'

    # interfaces
    assert 'lo0' in interfaces
    # lo0
    assert 'ipv4' in interfaces['lo0']
    assert len(interfaces['lo0']['ipv4']) == 2
    assert 'mtu' in interfaces['lo0']['ipv4'][0]
    assert 'flags' in interfaces['lo0']['ipv4'][0]

# Generated at 2022-06-11 03:41:16.644894
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    network = SunOSNetwork()
    devices = {}
    words = ['nl0:', 'flags=2001000849', 'mtu', '1500']
    current_if = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    network.parse_interface_line(words, current_if, devices)
    assert devices['nl0']['device'] == 'nl0'
    assert devices['nl0']['type'] == 'unknown'
    assert devices['nl0']['ipv4'][0]['flags'] == '2001000849'
    assert devices['nl0']['ipv4'][0]['mtu'] == '1500'
    assert devices['nl0']['ipv6'] == []



# Generated at 2022-06-11 03:41:27.199139
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('', (), {'run_command': ''})
    module.run_command = lambda *args, **kwargs: (0, fake_ifconfig, "")
    m = SunOSNetwork(module)
    d = m.get_interfaces_info('/sbin/ifconfig')[0]

    assert d['igb1']['device'] == 'igb1'
    assert d['igb1']['ipv4'][0]['address'] == '10.0.0.1'
    assert d['igb1']['ipv4'][0]['broadcast'] == '10.0.0.255'
    assert d['igb1']['ipv4'][0]['netmask'] == '255.0.0.0'

# Generated at 2022-06-11 03:41:29.357153
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    assert issubclass(SunOSNetworkCollector, NetworkCollector)

# Generated at 2022-06-11 03:41:39.741246
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Set up test environment
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['!all', 'min'], type='list')
    })
    # Create a simple SunOSNetwork object with fake data to test on
    sunosnetwork = SunOSNetworkCollector.load_platform_subclass(SunOSNetwork, module)

# Generated at 2022-06-11 03:41:48.971043
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = None
    sunos_network_collector = SunOSNetworkCollector(module)

# Generated at 2022-06-11 03:41:56.529726
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetwork()
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = {}
    interfaces = {}
    current_if = m.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-11 03:42:09.612226
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    mc = SunOSNetworkCollector()
    assert isinstance(mc, NetworkCollector)



# Generated at 2022-06-11 03:42:19.117419
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network import SunOSNetwork
    from nose.tools import assert_equal

    network = SunOSNetwork()

    # get_interfaces_info() should return a tuple (interfaces, ips) where
    # interfaces is a dictionary of Solaris interfaces facts and
    # ips is a dictionary of all known IPv4 and IPv6 addresses across all interfaces
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert_equal(type(interfaces), dict)
    assert_equal(type(ips), dict)

    # This test would be a bit more thorough if we knew the system on which it runs
    # has specific interfaces and vlans.

    # network.get_interfaces_info() returns two dictionaries
    # interfaces: facts about every interface
    #     interfaces[

# Generated at 2022-06-11 03:42:28.325132
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:42:31.712931
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector.fact_class == SunOSNetwork
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:42:39.893478
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module_args = dict(
        gather_subset=[],
    )
    module = DummyAnsibleModule(module_args)
    fact = SunOSNetwork(module)
    iface = {}
    flags = 'UP LOOPBACK RUNNING'
    words = ['lo0:', flags, 'mtu', '8232']
    result = fact.parse_interface_line(words, iface, {})
    iface['ipv4'].append({'flags': flags, 'mtu': '8232'})
    result['ipv4'].append({'flags': flags, 'mtu': '8232'})
    assert result == iface

# Generated at 2022-06-11 03:42:49.780405
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-11 03:42:51.154391
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # TODO: write a unit test for method get_interfaces_info
    pass

# Generated at 2022-06-11 03:42:56.470359
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    ifconfig_path = 'tests/unit/module_utils/facts/network/test.data'
    ifconfig_path = 'tests/unit/module_utils/facts/network/test.data.sunos'

    network = SunOSNetwork()

    interfaces, ips = network.get_interfaces_info(ifconfig_path)

    assert len(interfaces.keys()) == 2

    # Remove IPv6 from lo0
    interfaces['lo0']['ipv6'] = []
    interfaces['lo1']['ipv6'] = []


# Generated at 2022-06-11 03:43:04.125585
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    module = NetworkCollector()
    module.stop_collecting = True
    netinfo = SunOSNetwork(module)

    # All interfaces facts should be under their proper lists
    # 'interfaces' and 'all_ipv4_addresses' 'all_ipv6_addresses'
    # under 'default_ipv4' and 'default_ipv6' should be unset

    # Test IPv4
    interfaces, ips = netinfo.get_interfaces_info(netinfo.module.get_bin_path('ifconfig'))

    # Test that the

# Generated at 2022-06-11 03:43:13.344520
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create SunOSNetwork class for class methods to be available for testing
    sunos_network = SunOSNetwork()

    # Create test data for class method get_interfaces_info
    ifconfig_path = 'test_path'

# Generated at 2022-06-11 03:43:36.733191
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """ Tests that the constructor works"""
    tcpdump = SunOSNetworkCollector()
    assert tcpdump
    assert isinstance(tcpdump,SunOSNetworkCollector)
    assert hasattr(tcpdump, 'platform')
    assert hasattr(tcpdump, '_platform')
    assert hasattr(tcpdump, '_fact_class')
    assert tcpdump.platform == 'SunOS'
    assert tcpdump._platform == 'SunOS'
    assert tcpdump._fact_class == SunOSNetwork
    assert tcpdump._fact_class.platform == 'SunOS'


# Generated at 2022-06-11 03:43:46.069751
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test method get_interfaces_info of class SunOSNetwork with mocked data.
    """
    mocked_current_if = {}
    mocked_interfaces = {}
    mocked_ips = {}

# Generated at 2022-06-11 03:43:48.034446
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork


# Generated at 2022-06-11 03:43:57.713244
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    module = {}


# Generated at 2022-06-11 03:44:01.001162
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    c = SunOSNetworkCollector(None)
    assert c.platform == 'SunOS'
    assert c._fact_class == SunOSNetwork
    assert c._interfaces == {}
    assert c._netmask == {}


# Generated at 2022-06-11 03:44:10.505619
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class SunOSNetwork.
    """
    class MockModule:
        def __init__(self, name):
            self.name = name
            self.run_command = lambda a: (0, '', '')

    class MockFacts:
        def __init__(self, interfaces, ipv4_addresses):
            self.interfaces = interfaces
            self.all_ipv4_addresses = ipv4_addresses

    SunOSNetworkCollector.setup(MockModule(''))
    interfaces, ipv4_addresses = SunOSNetworkCollector.get_interfaces_info('')
    assert isinstance(interfaces, dict)
    assert isinstance(ipv4_addresses, dict)

# Generated at 2022-06-11 03:44:12.924977
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock()
    n = SunOSNetworkCollector(module=module)
    assert n._fact_class == SunOSNetwork
    assert n._platform == 'SunOS'

# Generated at 2022-06-11 03:44:23.473526
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_module = NetworkCollector(dict(module_args='', ansible_facts=dict()))
    input_values = dict(
        ifconfig_path='/sbin/ifconfig',
        module=test_module,
    )


# Generated at 2022-06-11 03:44:27.541358
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    my_SunOSNetwork = SunOSNetwork({'ansible_env': {'PATH': '/usr/sbin:/usr/bin:/sbin:/bin'}})
    result = my_SunOSNetwork.get_interfaces_info('/sbin/ifconfig')
    assert result[0] == {}

# Generated at 2022-06-11 03:44:29.611479
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Create an instance of SunOSNetworkCollector
    """

    sunos_network_collector = SunOSNetworkCollector()

# Generated at 2022-06-11 03:45:03.757829
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-11 03:45:06.085032
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_cls = SunOSNetworkCollector()
    assert net_cls._platform == 'SunOS'
    assert net_cls._fact_class == SunOSNetwork

# Generated at 2022-06-11 03:45:15.138145
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    module = AnsibleModule(argument_spec={})
    fact_collector = SunOSNetwork(module=module)
    # Solaris can have different FLAGS and MTU for IPv4 and IPv6 on the same interface
    # so these facts have been moved inside the 'ipv4' and 'ipv6' lists.
    fake_ifconfig_output = """
lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1
    inet 127.0.0.1 netmask ff000000
    ipv6 ::1/128
lo0: flags=2000841<UP,RUNNING,MULTICAST,IPv6> mtu 8252 index 1
    ipv6 ::1/128
"""
    fake_interfaces, fake_ips = fact_

# Generated at 2022-06-11 03:45:17.473012
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = {}
    SunOSNetworkCollector(facts, None)
    assert ['network'] == sorted(facts.keys())

# Unit tests for method parse_interface_line()

# Generated at 2022-06-11 03:45:26.520032
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    collector = SunOSNetworkCollector(module=module)
    interfaces_info = collector.get_interfaces_info(ifconfig_path='/sbin/ifconfig')

    # facts should be a dictionary of dictionaries indexed by interface name
    assert type(interfaces_info) is tuple
    assert len(interfaces_info) == 2
    assert 'lo0' in interfaces_info[0]

    # facts for one interface should contain certain key/value pairs
    assert 'ipv4' in interfaces_info[0]['lo0']
    assert 'ipv6' in interfaces_info[0]['lo0']
    assert 'mtu' in interfaces_info[0]['lo0']['ipv4'][0]

# Generated at 2022-06-11 03:45:34.128890
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('MockModule', (object,), dict(run_command=dict()))

# Generated at 2022-06-11 03:45:37.927083
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class SunOSNetwork
    """
    network = SunOSNetwork()
    interfaces, ips = network.get_interfaces_info(ifconfig_path='/sbin/ifconfig')
    assert interfaces is not None, 'Error getting interfaces'
    assert ips is not None, 'Error getting IP addresses'



# Generated at 2022-06-11 03:45:40.738174
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert hasattr(SunOSNetworkCollector, '_fact_class')
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert hasattr(SunOSNetworkCollector, '_platform')
    assert SunOSNetworkCollector._platform == 'SunOS'


# Generated at 2022-06-11 03:45:47.723163
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Run a basic test on the SunOSNetwork method get_interfaces_info.
    """