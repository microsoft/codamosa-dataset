

# Generated at 2022-06-20 18:20:18.611978
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = AnsibleModule(argument_spec={})
    sunos_network = SunOSNetwork(module)
    current_if = {}
    ips = {}
    sunos_network.parse_ether_line(['ether', '0:1:2:3:4:5'], current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'
    sunos_network.parse_ether_line(['ether', '0:1:2:d:e:f'], current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:20:28.096957
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test get_interfaces_info method of SunOSNetwork class.
    """

# Generated at 2022-06-20 18:20:38.317399
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = type('MockModule', (object,), {})()
    sn = SunOSNetwork(module)
    interface = {}
    ips = {}

    # input line and expected results
    # line, expected_macaddress
    test_cases = [
        ('ether 0:1:2:d:e:f', '00:01:02:0d:0e:0f'),
        ('ether 0:14:d1:37:ec:7c', '00:14:d1:37:ec:7c'),
    ]
    for test_case in test_cases:
        sn.parse_ether_line(test_case[0].split(), interface, ips)
        assert interface['macaddress'] == test_case[1]

# Generated at 2022-06-20 18:20:49.229425
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:20:57.979824
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:21:01.018338
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    sunos_network = SunOSNetwork(module)
    assert sunos_network


# Generated at 2022-06-20 18:21:11.452699
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig')

    fixture = {
        'ipv4': [],
        'ipv6': [{'scope': 'global', 'address': 'fe80::cc1b:aaff:fe80:d6d5'},
                 {'scope': 'site', 'address': 'fe80::cc1b:aaff:fe80:d6d5%zone0'}],
        'macaddress': '0c:1b:a8:80:d6:d5',
        'type': 'ether',
        'device': 'e1000g0'
    }

    ifc = SunOSNetwork()
    ifc.module = module

# Generated at 2022-06-20 18:21:13.847803
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork.platform == 'SunOS'
    assert SunOSNetwork.platforms == ['SunOS', 'Generic']


# Generated at 2022-06-20 18:21:21.075239
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    if SunOSNetwork is None:
        raise Exception('Unable to import SunOS network class')
    if SunOSNetworkCollector is None:
        raise Exception('Unable to import SunOS network collector class')

    # Test constructor of class SunOSNetwork
    net = SunOSNetwork({}, {})
    assert net is not None
    assert net.ipv4_address_key == 'inet'
    assert net.ipv6_address_key == 'inet6'
    assert net.platform == 'SunOS'



# Generated at 2022-06-20 18:21:31.917926
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = None

# Generated at 2022-06-20 18:21:38.180473
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_net = SunOSNetworkCollector()
    assert sunos_net is not None

# Generated at 2022-06-20 18:21:40.852112
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    if SunOSNetworkCollector():
        assert True
    else:
        assert False

# Generated at 2022-06-20 18:21:53.426774
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_SunOSNetwork = SunOSNetwork()
    test_SunOSNetwork.parse_ether_line(['ether', '0:1:2:d:e:f'], {}, {})
    assert test_SunOSNetwork.interfaces['unknown']['macaddress'] == '00:01:02:0d:0e:0f'

    test_SunOSNetwork = SunOSNetwork()
    test_SunOSNetwork.parse_ether_line(['ether', '0:1:2:d:e:f'], {}, {})
    assert test_SunOSNetwork.interfaces['unknown']['macaddress'] == '00:01:02:0d:0e:0f'

    test_SunOSNetwork = SunOSNetwork()

# Generated at 2022-06-20 18:21:59.904634
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    telnet = SunOSNetwork()

    # Test behavior with a simple interface line
    #
    # net0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2
    #     inet 10.0.0.1 netmask ffffff00 broadcast 10.0.0.255
    iface_line = 'net0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2'
    words = iface_line.split()

    current_if = telnet.parse_interface_line(words, {}, {})

    # Test the behavior with a line with an additional parameter
    #
    # net0: flags=1000843<UP,BROADCAST,RUNNING,MULTIC

# Generated at 2022-06-20 18:22:12.621766
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    out = "lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1\n"
    out += "        groupname ip.tun0\n"
    out += "        inet 127.0.0.1 netmask ff000000 \n"
    out += "ether 0:1:2:d:e:f\n"
    words = out.splitlines()[3].split()
    current_if = {'device': None, 'ipv4': [], 'ipv6': [], 'type': None}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    sunos = SunOSNetwork(dict(), words, current_if, ips)


# Generated at 2022-06-20 18:22:21.787316
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MagicMock()
    module.run_command.return_value = 0, utils.get_fixture_content('SunOS/ifconfig.out'), None
    SunOSNetwork = SunOSNetwork(module)
    result = SunOSNetwork.get_interfaces_info('/sbin/ifconfig')
    assert_that(result, is_(not_none()))
    assert_that(len(result), is_(2))
    assert_that(len(result[0]), is_(12))  # twelve interfaces
    assert_that(len(result[1]), is_(3))  # three address lists


# Generated at 2022-06-20 18:22:24.856800
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = None
    SunOSNetworkCollector(module)


# Unit tests for methods of class SunOSNetwork

# Generated at 2022-06-20 18:22:27.357853
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    print(('test_SunOSNetwork: ', SunOSNetwork(dict(module=''))))

# Generated at 2022-06-20 18:22:40.846994
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """ Tests SunOSNetwork class constructor """


# Generated at 2022-06-20 18:22:45.766110
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test for method get_interfaces_info
    """

    net = SunOSNetwork()
    net.get_interfaces_info('path/to/ifconfig')

    # TODO:  Add real test

# Generated at 2022-06-20 18:22:57.553140
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-20 18:23:09.193973
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    for dev, up, mtu, ip, vip in [
            ("fxp0:3", True, 1500, "10.0.0.1", False),
            ("fxp0:4", True, 1500, "10.0.0.2", True),
            ("lo0", True, 8232, "127.0.0.1", False),
            ("vlan0:1", True, 1500, "10.0.0.1", False),
            ("vlan0:2", False, 1500, "10.0.0.2", False),
            ("vlan83", True, 1500, "10.0.0.2", False),
            ("nge0", True, 1500, "10.0.0.2", False),
    ]:
        inter = SunOSNetwork()

# Generated at 2022-06-20 18:23:20.092517
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('test', (object,), {
        'run_command': get_command_mock(),
    })()

    collector = SunOSNetwork(module)
    interfaces, ips = collector.get_interfaces_info('/sbin/ifconfig')

    assert 'system' in interfaces
    assert 'flags' in interfaces['system']

    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips

    assert 'ipv4' in interfaces['system']
    assert 'flags' in interfaces['system']['ipv4']
    assert 'mtu' in interfaces['system']['ipv4']

    assert 'ipv6' in interfaces['system']
    assert 'flags' in interfaces['system']['ipv6']
    assert 'mtu'

# Generated at 2022-06-20 18:23:26.093822
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # Create a SunOSNetwork(module) object
    m = SunOSNetwork(dict())

    assert 'SunOS' == m.platform
    assert 'unknown' == m.interface_alias

    # Test that class variables have the correct values
    assert 'SunOS' == SunOSNetwork.platform
    assert 'unknown' == SunOSNetwork.interface_alias

    assert 'SunOSNetwork' == SunOSNetwork.__name__


# Generated at 2022-06-20 18:23:35.334227
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {'device': 'net0', 'ipv4': [{'flags': 'UP', 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}
    expected_iface = {'device': 'net0', 'ipv4': [{'flags': 'UP', 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown', 'macaddress': '00:01:02:0d:0e:0f'}
    ips = {}
    words = ["ether", "0:1:2:d:e:f"]
    sunos = SunOSNetwork()
    sunos.parse_ether_line(words, iface, ips)
    assert iface == expected_iface

# Generated at 2022-06-20 18:23:39.291631
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector()._fact_class, SunOSNetwork)
    assert SunOSNetworkCollector()._platform == 'SunOS'


# Generated at 2022-06-20 18:23:46.995191
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    output_path = os.path.join(os.path.dirname(__file__), '../../../output/sunos_ifconfig_a.txt')
    output_file = open(output_path)
    output_string = output_file.read()
    result = SunOSNetwork().get_interfaces_info(ifconfig_path=None, output_string=output_string)
    #print('result = ' + pprint.pformat(result))

    assert result[0]['lo0']['type'] == 'loopback'
    assert result[0]['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert result[0]['lo0']['ipv4'][0]['mtu'] == '8232'
    assert result

# Generated at 2022-06-20 18:23:58.102433
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    fact_class = SunOSNetwork(module)
    assert fact_class.platform == 'SunOS'
    assert fact_class._platform == 'SunOS'
    assert fact_class.use_default_ifconfig_path() == '/usr/sbin/ifconfig'
    assert not fact_class.get_interfaces_info(fact_class.ifconfig_path)
    assert not fact_class.get_interfaces()
    assert not fact_class.get_interface_size(None)
    assert not fact_class.get_interface_size('eth0')
    assert not fact_class.get_interface_speed(None)
    assert not fact_class.get_interface_speed('eth0')


# Generated at 2022-06-20 18:24:03.630973
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetwork(module)
    assert collector.platform == 'SunOS'

# Test code to exercise the functionality of SunOSNetwork and
# to ensure new functionality added to the Generic Network Interface
# does not break existing functionality.

# Generated at 2022-06-20 18:24:04.714074
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net = SunOSNetworkCollector()

# Generated at 2022-06-20 18:24:33.949846
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    import pytest
    # Test 1: ether <macaddr>
    words = 'ether 8:0:27:99:0:90'.split()
    test_if = {}
    test_ips = {}
    SunOSNetwork.parse_ether_line(words, test_if, test_ips)
    assert test_if['macaddress'] == '08:00:27:99:00:90'
    # Test 2: no macaddr found, keep unknown
    words = 'ether'.split()
    test_if = {'macaddress': 'unknown'}
    test_ips = {}
    SunOSNetwork.parse_ether_line(words, test_if, test_ips)
    assert test_if['macaddress'] == 'unknown'
    # Test 3: incorrect number of arguments, keep unknown

# Generated at 2022-06-20 18:24:35.836932
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Unit test for constructor of class SunOSNetworkCollector
    """
    SunOSNetworkCollector()

# Generated at 2022-06-20 18:24:40.186917
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Unit test for constructor of class SunOSNetworkCollector"""
    facts = SunOSNetworkCollector()
    assert(facts is not None)

# Can't write unit tests for 'get_interfaces_info()' because it relies on
# 'run_command()' which interacts with the host.
# Ifconfig output is parsed in get_interfaces_info() so maybe I can write
# a test in that class.

# Generated at 2022-06-20 18:24:45.672766
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    words = '0:1:2:3:4:5 a b c'.split()
    iface = {}
    SunOSNetwork.parse_ether_line(words, iface, {})
    assert(iface['macaddress'] == '00:01:02:03:04:05')

# Generated at 2022-06-20 18:24:48.052198
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = FakeModule()
    facts = SunOSNetworkCollector(module=module)
    assert facts


# Generated at 2022-06-20 18:24:49.995883
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    v = SunOSNetwork()
    assert v.platform == 'SunOS'

# Generated at 2022-06-20 18:25:02.593613
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ifconfig_path = 'ifconfig_path'
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    net = SunOSNetwork(dict(module=None, params={}))

    # Test with a line of 'ifconfig -a' output containing 'ether'
    # Solaris displays single digit octets in MAC addresses e.g. 0:1:2:d:e:f
    # Add leading zero to each octet where needed.
    words = ['ether', '0:1:2:d:e:f']
    current_if = net.parse_ether_line(words, current_if, ips)
    assert 'macaddress' in current_if

# Generated at 2022-06-20 18:25:15.238436
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-20 18:25:18.205568
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    ifconfig_path = '/sbin/ifconfig'
    module = None
    s = SunOSNetworkCollector(module, ifconfig_path)
    assert s.fact_class._platform == 'SunOS'



# Generated at 2022-06-20 18:25:20.605045
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == 'SunOS'

# Generated at 2022-06-20 18:26:03.017338
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector.__doc__ is not None



# Generated at 2022-06-20 18:26:15.187607
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Constructor test SunOSNetwork

    To test, create a file: /tmp/ansible_sunos_network

    The file should contain similar lines as the output of `ifconfig -a`
    """
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector

    with open('/tmp/ansible_sunos_network') as f:
        output = f.read()

    facts = {'ansible_facts': {
        'ansible_net_all_ipv4_addresses': [],
        'ansible_net_all_ipv6_addresses': [],
        'ansible_net_interfaces': {},
        'ansible_net_neighbors': {}}}

    network

# Generated at 2022-06-20 18:26:19.272768
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Test that it can identify SunOS and set platform and fact_class."""
    sunos_network = SunOSNetwork({}, {}, {})
    assert sunos_network.platform == 'SunOS'
    assert sunos_network.fact_class == SunOSNetwork


# Generated at 2022-06-20 18:26:29.127855
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class SunOSNetwork"""
    # Pretend to be 'ifconfig' on Solaris

# Generated at 2022-06-20 18:26:39.865696
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:26:49.483468
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = ''
    module = ''
    sunos_network = SunOSNetwork(module)
    interfaces, ips = sunos_network.get_interfaces_info(ifconfig_path)

    assert 'lo0' in interfaces
    assert 'flags' in interfaces['lo0']['ipv4'][0]
    assert 'inet' in interfaces['lo0']['ipv4'][0]
    assert 'inet6' in interfaces['lo0']['ipv4'][0]
    assert 'lladdr' in interfaces['lo0']['ipv4'][0]
    assert 'zone' in interfaces['lo0']['ipv4'][0]
    assert '127.0.0.1' in interfaces['lo0']['ipv4'][0]['inet']

# Generated at 2022-06-20 18:26:53.110754
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector._fact_class is SunOSNetwork
    assert collector._platform is 'SunOS'

# Generated at 2022-06-20 18:26:56.669894
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    imc = SunOSNetwork()
    assert imc.get_option('IPv4') == r'(?:Broadcast|Point-To-Point)\s+Multicast'

# Generated at 2022-06-20 18:26:58.193357
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    SunOSNetwork(module)

# Generated at 2022-06-20 18:27:00.888039
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector()
    assert facts.get_facts() == {}
    assert not 'SunOS' in facts._platforms_to_collect_from


# Generated at 2022-06-20 18:28:30.811022
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunos_network = SunOSNetwork()
    current_if = {}
    interfaces = {}
    # test 1st line of sample output
    words = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'.split()
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    assert interfaces['lo0']['device'] == 'lo0'
    assert 'INET' in interfaces['lo0']['ipv4'][0]['flags']
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert 'LOOPBACK' in interfaces['lo0']['ipv4'][0]['flags']


# Generated at 2022-06-20 18:28:33.755061
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork()
    net.get_interfaces_info('/sbin/ifconfig')
    assert net.facts['default_ipv4']['interface'] == 'net0'

# Generated at 2022-06-20 18:28:43.462987
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = type('module', (object,), {})()
    module.params = {}
    module.params['gather_subset'] = ['all']
    module.run_command = lambda cmd: (0, 'ether 0:1:2:d:e:f', '')
    class_instance = SunOSNetwork(module)
    class_instance.get_interfaces_info('/sbin/ifconfig')

    assert class_instance.interfaces['unknown']['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:28:54.386546
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    interfaces = {}
    current_if = {}


# Generated at 2022-06-20 18:29:03.566684
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:29:11.391422
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:29:21.392238
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    iface = SunOSNetwork()
    iface.module = FakeAnsibleModule()
    iface.module.run_command.return_value = (0, Solaris_ifconfig, '')
    interfaces, ips = iface.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1/128'
    assert interfaces['lo0']['ipv6'][0]['scope'] == 'host'

# Generated at 2022-06-20 18:29:23.375328
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net1 = SunOSNetwork(None)
    assert net1


# Generated at 2022-06-20 18:29:25.966388
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = None
    network = SunOSNetworkCollector(module)
    assert network.platform == 'SunOS'

# Generated at 2022-06-20 18:29:33.995526
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = dict()
    interfaces = dict()
    result = dict()

    # Prepare data for test
    words_1 = ['lo0:', '(flags=849000<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>)', 'mtu', '8232']
    words_2 = ['lo0:', '(flags=849000<UP,LOOPBACK,RUNNING,MULTICAST,IPv6>)', 'mtu', '8232']
    current_if['ipv4'] = []
    current_if['ipv6'] = []
    current_if['device'] = ''
    current_if['type'] = ''

    # Perform test and verify result
    current_if = SunOSNetwork.parse_interface_line(None, words_1, current_if, interfaces)
