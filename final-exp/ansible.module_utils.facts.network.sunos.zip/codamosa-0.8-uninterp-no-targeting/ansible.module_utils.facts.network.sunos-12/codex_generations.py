

# Generated at 2022-06-20 18:20:23.561905
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts = SunOSNetwork()
    fake_lines = []
    fake_words = []
    fake_lines.append('ether 0:1:2:d:e:f')
    for line in fake_lines:
        fake_words = line.split()
        facts.parse_ether_line(fake_words, {}, {})
        assert facts.facts['interfaces']['lo0']['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:20:27.965804
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    s = SunOSNetworkCollector()
    assert s is not None

# Generated at 2022-06-20 18:20:30.688254
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    my_object = SunOSNetwork()
    assert my_object.platform == 'SunOS'
    assert my_object.facts == {}


# Generated at 2022-06-20 18:20:38.520913
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = MockModule()
    obj = SunOSNetwork(module)
    # words = ['ether', '0:1:2:d:e:f', 'GROUP', 'broadcast']
    words = ['ether', '0:1:2:d:e:f']
    current_if = {'device': 'ce0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    obj.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'
    # words = ['ether', '0:0:0:0:0:0

# Generated at 2022-06-20 18:20:50.406569
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    s = SunOSNetwork()

    # The following line would be printed by ifconfig for the bge1 interface
    # in the Solaris case where both IPv4 and IPv6 address are configured.
    words = ['bge1:', 'flags=201008c43<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS>', 'mtu=1500', 'index=5', 'ether', '0:1:2:3:4:5', 'zone', '(0)']
    current_if = {}
    interfaces = {}

    current_if = s.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'bge1'

# Generated at 2022-06-20 18:21:03.129056
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    ifconfig_path = '/usr/sbin/ifconfig'

# Generated at 2022-06-20 18:21:06.450045
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    nc = SunOSNetworkCollector(None)
    assert nc.platform == 'SunOS'
    assert nc.fact_class == SunOSNetwork

# Generated at 2022-06-20 18:21:17.356328
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    SunOSNetwork = SunOSNetwork()
    # This test is not good, we need to test the data structure
    # returned by SunOSNetwork.get_interfaces_info
    assert SunOSNetwork.parse_interface_line(
        ['e1000g0:', 'flags=1000843', 'mtu', '1500'],
        {},
        {}
    ) == {
        'device': 'e1000g0',
        'ipv4': [{'flags': ['BROADCAST', 'MULTICAST', 'IPv4'], 'mtu': '1500'}],
        'ipv6': [],
        'type': 'unknown',
    }

# Generated at 2022-06-20 18:21:18.967942
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork


# Generated at 2022-06-20 18:21:27.639631
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    sun_network = SunOSNetwork({})
    assert sun_network.platform == "SunOS"
    assert sun_network.config_file == "/etc/net/interface"
    assert sun_network.config_file_user == "root"
    assert sun_network.config_file_group == "sys"
    assert sun_network.config_file_mode == "0666"
    assert sun_network.ifconfig_path == "/usr/sbin/ifconfig"

# Generated at 2022-06-20 18:21:38.596844
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # Constructor of class SunOSNetwork should create an object
    sunos = SunOSNetwork()
    # type(sunos) should return an <class 'ansible.module_utils.facts.network.sunos.SunOSNetwork'
    assert type(sunos) is SunOSNetwork

# Generated at 2022-06-20 18:21:39.783935
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork.platform == 'SunOS'
    assert SunOSNetwork().platform == 'SunOS'


# Generated at 2022-06-20 18:21:51.593830
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    expected = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': '00:01:02:0d:0e:0f'}
    SunOSNetwork().parse_ether_line(['ether', '0:1:2:d:e:f'], iface, ips)
    assert expected == iface

# Generated at 2022-06-20 18:22:02.775741
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    Solaris can have different FLAGS and MTU for IPv4 and IPv6 on the same interface
    so these facts have been moved inside the 'ipv4' and 'ipv6' lists.

    Solaris 'ifconfig -a' will print interfaces twice, once for IPv4 and again for IPv6.
    MTU and FLAGS also may differ between IPv4 and IPv6 on the same interface.
    'parse_interface_line()' checks for previously seen interfaces before defining
    'current_if' so that IPv6 facts don't clobber IPv4 facts (or vice versa).
    """
    # command output from 'ifconfig -a' on Solaris 11.4

# Generated at 2022-06-20 18:22:10.565312
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = None  # Not used, but needed to allow function to be called.

    # Arrange
    test_object = SunOSNetwork(module)
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']
    current_if = {}
    interfaces = {}

    # Act
    current_if = test_object.parse_interface_line(words, current_if, interfaces)

    # Assert
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'
   

# Generated at 2022-06-20 18:22:13.741819
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_network = SunOSNetwork({})
    assert sunos_network
    assert sunos_network.platform == 'SunOS'


# Generated at 2022-06-20 18:22:20.550091
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Create some test data
    current_if = {}
    interfaces = {}
    words = ['bge0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    # Run the code
    current_if = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    # Make sure we get what we expect
    assert 'device' in current_if
    assert current_if['device'] == 'bge0'
    assert 'ipv4' in current_if
    assert isinstance(current_if['ipv4'], list)
    assert len(current_if['ipv4']) == 1
    assert isinstance(current_if['ipv4'][0], dict)
    assert 'flags'

# Generated at 2022-06-20 18:22:34.502218
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    instance = SunOSNetwork()

    # IPv4 interface
    words = ['lo0:', 'flags=2001000849', 'mtu', '8232', 'index', '2', 'inet', '127.0.0.1', 'netmask', 'ff000000', 'groups:', 'lo']
    current_if = instance.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if

# Generated at 2022-06-20 18:22:37.175275
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork.platform == 'SunOS'
    assert SunOSNetwork.type == 'generic_bsd'

# Generated at 2022-06-20 18:22:44.700540
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    host_name = 'test_SunOS'
    out = '''lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
    inet 127.0.0.1 netmask ff000000
    e1000g0: flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS> mtu 1500 index 2
    inet 192.168.200.230 netmask ffffff00 broadcast 192.168.200.255
    ether 0:1:2:3:4:5'''

    c = SunOSNetwork(host_name, None)

# Generated at 2022-06-20 18:22:59.611123
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Test SunOSNetwork.get_interfaces_info()"""
    collector = SunOSNetworkCollector(dict())
    test_data = """
lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
lo0: flags=2000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6> mtu 8252 index 1
        options=3<RXCSUM,TXCSUM>
        inet6 ::1/128
        nd6 options=1<PERFORMNUD>
        ether 8:0:20:4c:18:96
        media: Ethernet autoselect (100baseTX full-duplex)
        status: active
"""
    test

# Generated at 2022-06-20 18:23:10.637069
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_network_collector = SunOSNetworkCollector()

# Generated at 2022-06-20 18:23:15.603680
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_SunOSNetwork = SunOSNetwork()
    test_dict = {}
    test_words = ['ether', '0:1:2:d:e:f']
    test_SunOSNetwork.parse_ether_line(test_words, test_dict, {})
    assert test_dict['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:23:24.629249
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {'device': 'e1000g0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = ['ether', '0:1:2:d:e:f']
    ips = {}
    SunOSNetwork().parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == '00:01:02:0D:0E:0F'


# Generated at 2022-06-20 18:23:28.665759
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Unit test of SunOSNetworkCollector class."""
    network = SunOSNetworkCollector()
    assert network.platform == 'SunOS'

# Generated at 2022-06-20 18:23:39.643626
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetwork({})
    interfaces = {}
    current_if = {}
    words = 'lo0:4'.split()
    current_if = m.parse_interface_line(words, current_if, interfaces)
    assert len(current_if.keys()) == 4
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'unknown'
    assert len(current_if['ipv4']) == 1
    assert len(current_if['ipv4'][0]) == 2
    assert current_if['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'MULTICAST']
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert len(current_if['ipv6']) == 0

# Generated at 2022-06-20 18:23:47.096902
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:23:49.110998
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork.platform == 'SunOS'

# Generated at 2022-06-20 18:23:59.655431
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = None
    collected_facts = SunOSNetworkCollector(module).collect()

    assert "ansible_net_interfaces" in collected_facts
    assert "ansible_net_all_ipv4_addresses" in collected_facts
    assert "ansible_net_all_ipv6_addresses" in collected_facts
    assert "ansible_net_meminfo" in collected_facts
    assert "ansible_net_gather_network_resources" in collected_facts
    assert "ansible_net_hostname" in collected_facts
    assert "ansible_net_version" in collected_facts
    assert "ansible_net_system" in collected_facts
    assert "ansible_net_python_version" in collected_facts
    assert "ansible_net_filesystems" in collected_facts

# Generated at 2022-06-20 18:24:11.306896
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    a = dict(device='eth0', ipv4=[], ipv6=[], type='unknown', macaddress='00:01:02:03:04:05')
    b = dict(device='eth0', ipv4=[], ipv6=[], type='unknown', macaddress='unknown')
    c = dict(device='eth0', ipv4=[], ipv6=[], type='unknown', macaddress='00:00:00:00:00:00')
    test = SunOSNetwork({})
    test.parse_ether_line(['ether', '0:1:2:3:4:5'], a, dict())
    test.parse_ether_line(['ether', '0:1:2:3:4:5'], b, dict())

# Generated at 2022-06-20 18:24:23.714425
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-20 18:24:33.393089
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:24:36.822436
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector.platform == 'SunOS'
    assert sunos_network_collector.fact_class.platform == 'SunOS'

# Generated at 2022-06-20 18:24:43.797182
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # 'parse_interface_line()' checks for previously seen interfaces before defining
    # 'current_if' so that IPv6 facts don't clobber IPv4 facts (or vice versa).
    # This is a quick test to illustrate this behavior.

    # Create two interfaces and populate IPv6 facts.
    o = SunOSNetwork()
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL>', 'mtu', '8232', 'index', '1']
    current_if = {}
    interfaces = {}
    current_if = o.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-20 18:24:50.402019
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test = SunOSNetwork(dict(module=None, facts=dict()))
    test_line = ['ether', '0:1:2:d:e:f']
    test_current_if = dict()
    test_ips = dict()
    test.parse_ether_line(test_line, test_current_if, test_ips)
    assert test_current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:24:52.054539
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-20 18:25:03.574622
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Given
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': []}
    interfaces = {'lo0': {'device': 'lo0', 'ipv4': [], 'ipv6': []}}
    net = SunOSNetwork()
    # When
    line1 = "lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1"
    line2 = "lo0: flags=2002000842<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8252 index 1"
    words1 = line1.split()
    words2 = line2.split()
    current_if = net.parse_interface_line

# Generated at 2022-06-20 18:25:15.512397
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    # Line to test
    words = ['ibd0', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '0']
    # Create an instance of SunOSNetwork
    sun = SunOSNetwork()
    # Call method to test
    current_if = sun.parse_interface_line(words, current_if, interfaces)
    # Check results
    assert(interfaces['ibd0']['device'] == 'ibd0')
    assert(interfaces['ibd0']['type'] == 'loopback')

# Generated at 2022-06-20 18:25:23.955073
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock()
    my_obj = SunOSNetworkCollector(module)
    assert my_obj.fact_class is SunOSNetwork
    assert my_obj.platform == 'SunOS'

    module.params = dict()
    module.params['gather_subset'] = ['all']
    module.params['gather_timeout'] = 1
    my_obj = SunOSNetworkCollector(module)
    assert my_obj.gather_subset == {'all'}
    assert my_obj.timeout == 1
    assert my_obj.module == module
    assert my_obj.fact_class is SunOSNetwork
    assert my_obj.platform == 'SunOS'


# Generated at 2022-06-20 18:25:27.485382
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    s = SunOSNetworkCollector()
    assert s.platform == 'SunOS'
    assert s._fact_class == SunOSNetwork

# Generated at 2022-06-20 18:25:56.335553
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    n = SunOSNetwork()
    r = n.parse_interface_line(['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232'],
                               {'ipv4': [], 'ipv6': []}, {})
    assert r == {'device': 'lo0', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4'], 'ipv4': [{'mtu': '8232', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4']}], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}

# Generated at 2022-06-20 18:26:08.367909
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    words = 'bge0: flags=2001000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS> mtu 1500 index 3'.split()

    fact_module = SunOSNetworkCollector({}, {}, {})
    # Verify that the interface bge0 is created.
    current_if = fact_module._fact_class.parse_interface_line(
        words, current_if, interfaces)
    assert current_if['device'] == 'bge0'
    # Verify that the interface bge0 is not re-created.
    current_if = fact_module._fact_class.parse_interface_line(
        words, current_if, interfaces)
    assert current_if['device'] == 'bge0'



# Generated at 2022-06-20 18:26:17.897278
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    M = SunOSNetwork()
    interfaces = {}
    current_if = {}
    if1 = {'device': 'lo0',
           'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': 8232},
                   {'flags': ['UP', 'LOOPBACK', 'RUNNING', 'IPv6'], 'mtu': 8232}],
           'ipv6': [],
           'macaddress': 'unknown',
           'type': 'loopback'}
    if2 = {'device': 'lo1',
           'ipv4': [],
           'ipv6': [],
           'macaddress': 'unknown',
           'type': 'unknown'}

# Generated at 2022-06-20 18:26:20.736901
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    # Test initialization of class SunOSNetworkCollector
    sunos_fact_network = SunOSNetworkCollector()
    assert sunos_fact_network.__class__.__name__ == 'SunOSNetworkCollector'

# Generated at 2022-06-20 18:26:29.855430
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # Unit test for  get_interfaces_info of class SunOSNetwork
    class MockModule(object):
        def run_command(self, args):
            return (0, FAKE_IFCONFIG, '')


# Generated at 2022-06-20 18:26:31.021534
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    RedHatNetworkCollector()

# Generated at 2022-06-20 18:26:38.617682
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Test data
    iface = 'lo0'
    words = ['ether', '0:1:2:d:e:f', 'lo0:']
    current_if = {'device': iface, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    # Perform test:
    SunOSNetwork().parse_ether_line(words, current_if)

    # Check the resulting MAC address
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:26:48.413115
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test get_interfaces_info of SunOSNetwork fact class.
    """
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    ifconfig_path = './ansible/module_utils/facts/network/sunos/fake_sunos_output/ifconfig_out'
    su = SunOSNetwork()
    interfaces, ips = su.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-20 18:27:00.414982
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    interface = {'device': 'lo1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = [ 'ether', 'd:e:a:d:0:1' ]
    current_if = SunOSNetwork().parse_ether_line(words, interface, ips)
    assert current_if['macaddress'] == 'de:ad:01:00:00:00'
    words = [ 'ether', '1:2:3:4:5:6' ]
    current_if = SunOSNetwork().parse_ether_line(words, interface, ips)

# Generated at 2022-06-20 18:27:11.906906
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from .. import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # Create a SunOSNetwork instance and initialize it with test values
    sn = SunOSNetwork(dict(module=dict(run_command=lambda x: test_SunOSNetwork_get_interfaces_info.run_command(x))))
    sn.module = sn.module_class
    sn.module.params = {'gather_network_resources': 'yes'}
    sn.module.run_command = lambda x: test_SunOSNetwork_get_interfaces_info.run_command(x)

    # Create a GenericBsdIfconfigNetwork instance and populate it with
    # default values

# Generated at 2022-06-20 18:27:53.611804
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    '''
    Unit test for method parse_ether_line of class SunOSNetwork
    '''
    current_if = {}
    ifnet_facts = SunOSNetwork()
    line = 'ether 8:0:20:dd:4a:a4'
    ifnet_facts.parse_ether_line(line.split(), current_if, {})
    assert current_if['macaddress'] == '08:00:20:dd:4a:a4'

# Generated at 2022-06-20 18:28:00.200065
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:28:06.682316
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    '''Unit test for constructor'''
    facts = {}
    obj = SunOSNetworkCollector(module=None, facts=facts, condition='sucess', command='ifconfig -a')
    assert obj.facts == facts
    assert obj.condition == 'sucess'
    assert obj.command == 'ifconfig -a'
    obj.collect()
    assert 'network' in obj.facts

# Generated at 2022-06-20 18:28:19.806224
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetwork({})
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232',
             'index', '1', 'inet', '127.0.0.1', 'netmask', 'ffffff00']
    current_if = m.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'

# Generated at 2022-06-20 18:28:29.981768
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():

    class FakeModule(object):
        def __init__(self, ansible_facts):
            self.run_command = lambda args, **kwargs: (0, 'line', '')
            self.ansible_facts = ansible_facts

    class FakeNetwork(SunOSNetwork):
        def __init__(self, module):
            super(FakeNetwork, self).__init__(module)
            self.solaris_fact = {}

    module = FakeModule({})
    network = FakeNetwork(module)
    words = ['ether', '0:1:2:d:e:f']
    network.parse_ether_line(words, {}, {})
    assert network.solaris_fact['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:28:42.257649
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:28:43.148538
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()

# Generated at 2022-06-20 18:28:54.536692
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-20 18:29:03.566721
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """Test case for method SunOSNetwork.parse_interface_line.
    """
    collector = SunOSNetworkCollector
    ins = SunOSNetwork(collector)
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=0x1', '<>']
    current_if = ins.parse_interface_line(words, current_if, interfaces)
    assert current_if == {'device': 'lo0', 'ipv4': [{'mtu': '', 'flags': '0x1'}], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}

# Generated at 2022-06-20 18:29:10.891159
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Unit test for constructor of class SunOSNetwork"""

    module = FakeAnsibleModule()
    ip_module = SunOSNetwork(module)
    assert ip_module.platform == 'SunOS'
    assert ip_module.module == module
    assert ip_module.ifconfig_path == 'ifconfig'
    assert isinstance(ip_module.interfaces, dict)
    assert isinstance(ip_module.ips, dict)
    ip_module.get_interfaces_facts()
    assert 'interface' in ip_module.interfaces
    assert 'inet' in ip_module.ips
    assert 'inet6' in ip_module.ips
    assert ip_module.ips['inet']
    assert ip_module.ips['inet6']
