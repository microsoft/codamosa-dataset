

# Generated at 2022-06-20 18:20:13.121696
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create an instance of SunOSNetwork and run get_interfaces_info()
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    facts = SunOSNetwork()
    facts.get_interfaces_info('/sbin/ifconfig')


# Generated at 2022-06-20 18:20:22.708388
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {}
    words = ['ether', '0:1:2:3:4:5']
    SunOSNetwork.parse_ether_line(SunOSNetwork, words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'


# Generated at 2022-06-20 18:20:28.401074
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """ Test creation of SunOSNetworkCollector Object"""

    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector.platform == "SunOS"



# Generated at 2022-06-20 18:20:37.374725
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork(dict())
    current_if = {}
    ips = dict()
    line = "ether 0:1:2:d:e:f"
    words = line.split()
    current_if = sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'
    line = "ether 0:1:2:3:4:5"
    words = line.split()
    current_if = sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'

# Generated at 2022-06-20 18:20:48.884097
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    facts = SunOSNetwork()
    interfaces = {}
    current_if = {}
    words = 'lo0:2: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'.split(" ")
    current_if = facts.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL']
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if['macaddress'] == 'unknown'


# Generated at 2022-06-20 18:20:52.315377
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    data = {'device': 'unknown', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    input_line = ['ether', '0:1:2:d:e:f']
    data['macaddress'] = '00:01:02:0d:0e:0f'

    SunOSNetwork(None).parse_ether_line(input_line, data, {})
    assert data['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:20:54.920317
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    result = SunOSNetwork()
    assert result.platform == "SunOS"


# Generated at 2022-06-20 18:20:58.832542
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    o = SunOSNetworkCollector()
    assert o.platform == 'SunOS'
    assert o._fact_class is SunOSNetwork

# Generated at 2022-06-20 18:21:10.570735
# Unit test for method parse_ether_line of class SunOSNetwork

# Generated at 2022-06-20 18:21:21.207701
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetworkCollector({'module_utils': 'ansible.module_utils'}, {}, [])
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']
    current_if = m.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-20 18:21:30.596582
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-20 18:21:37.811059
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    interfaces = collector.get_interfaces()
    for interface in interfaces:
        for key in interface.keys():
            assert key in ('ipv4', 'ipv6', 'device', 'mtu')

# Unit test to check whether constructor of generic class is called

# Generated at 2022-06-20 18:21:40.783523
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert isinstance(obj._fact_class, SunOSNetwork)

# Generated at 2022-06-20 18:21:53.389717
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    module = type('', (object,), dict(run_command=lambda self, cmd: (0, ifconfig_data, '')))
    network_module = SunOSNetwork(module)
    interfaces, ips = network_module.get_interfaces_info('/sbin/ifconfig')

    # Test interfaces.
    assert list(interfaces.keys()) == ['lo0', 'net0', 'net1']

    assert interfaces['lo0']['active'] is False
    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['macaddress'] == '06:00:00:00:00:00'
    assert interfaces['lo0']['mtu'] == '8232'
    assert interfaces ['lo0']['type'] == 'loopback'

# Generated at 2022-06-20 18:21:58.816347
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = DummyModule()
    obj = SunOSNetwork(module)
    assert obj._platform == 'SunOS'
    assert isinstance(obj, NetworkCollector)
    assert isinstance(obj, SunOSNetwork)

test_SunOSNetwork()


# Generated at 2022-06-20 18:22:12.213215
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    eth_eth0_em1 = dict(
        device='eth0:1',
        ipv4=[dict(address='10.17.39.132', netmask='255.255.255.0', broadcast='10.17.39.255')],
        ipv6=[],
        type='ether',
        macaddress='00:50:56:8f:64:e8',
    )
    net0 = dict(
        device='net0',
        ipv4=[dict(address='10.17.39.132', netmask='255.255.255.0', broadcast='10.17.39.255')],
        ipv6=[],
        type='ether',
        macaddress='00:50:56:8f:64:e8',
    )

# Generated at 2022-06-20 18:22:14.901049
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_network = SunOSNetwork()
    assert sunos_network.macaddress == 'unknown'


# Generated at 2022-06-20 18:22:25.347040
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos.collector import SunOSNetworkCollector
    from ansible.module_utils.facts.network.sunos.ifconfig import SunOSNetwork
    import re

    ifconfig_path = '/sbin/ifconfig'
    rc, out, err = module.run_command([ifconfig_path, '-a'])
    output = out

    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    for line in output.splitlines():

        if line:
            words = line.split()

            if re.match(r'^\S', line) and len(words) > 3:
                current_if = SunOSNetwork.parse_interface

# Generated at 2022-06-20 18:22:38.432645
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    current_if = {}
    ips = {}
    SunOSNetwork.parse_ether_line(['ether','0:e0:81:c9:89:d0'], current_if, ips)
    assert current_if['device'] == 'e1000g0'
    assert current_if['macaddress'] == '00:e0:81:c9:89:d0'
    SunOSNetwork.parse_ether_line(['ether','0:e0:81:d:e:f'], current_if, ips)
    assert current_if['device'] == 'e1000g0'
    assert current_if['macaddress'] == '00:e0:81:0d:0e:0f'

# Generated at 2022-06-20 18:22:48.122362
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    network = SunOSNetwork()
    iface = {}
    ifconfig_output = {'interfaces': []}
    line = 'e1000g0: flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS> mtu 1500 index 3 inet 10.0.0.1 netmask ffffff00 broadcast 10.0.0.255'
    words = line.split()
    iface = network.parse_interface_line(words, {}, ifconfig_output['interfaces'])
    assert iface['device'] == 'e1000g0'
    assert iface['macaddress'] == 'unknown'
    assert iface['ipv4'][0]['mtu'] == '1500'

# Generated at 2022-06-20 18:22:53.893599
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()


# Generated at 2022-06-20 18:22:58.181090
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    s = SunOSNetwork(dict())
    assert s.platform == SunOSNetwork.platform

if __name__ == '__main__':
    test_SunOSNetwork()

# Generated at 2022-06-20 18:23:09.753539
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test the constructor of SunOSNetworkCollector class"""
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    import tempfile
    import os
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    # Create temporary file
    tmp_file_fd, tmp_file_name = tempfile.mkstemp()
    os.close(tmp_file_fd)

    # Create a SunOSNetworkCollector object
    collector = SunOSNetworkCollector({}, [], tmp_file_name)

    # Check that the object is an instance of SunOSNetworkCollector
    assert isinstance(collector, SunOSNetworkCollector)
    # Check that the object is an instance

# Generated at 2022-06-20 18:23:11.722201
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact_class = SunOSNetworkCollector()
    assert fact_class._platform == 'SunOS'

# Generated at 2022-06-20 18:23:23.261222
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Get an instance of SunOSNetwork
    module = None
    ifconfig_path = "ifconfig"
    sunosnetwork_instance = SunOSNetwork(module, ifconfig_path)

    # First Interface
    # words contains the like "net0: flags=2000843<BROADCAST,RUNNING,SIMPLEX,MULTICAST,IPv4> mtu 1500 index 2"
    words = "net0: flags=2000843<BROADCAST,RUNNING,SIMPLEX,MULTICAST,IPv4> mtu 1500 index 2".split()
    current_if = {}
    interfaces = {}
    current_if = sunosnetwork_instance.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-20 18:23:37.114666
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    # Generate the facts from 'module_utils/facts/network/sunos/facts.py'
    fact_collector = SunOSNetworkCollector('module_utils/facts/network/sunos/facts.py')

    # Parse the dict facts returned by the helper function 'get_interface_facts()'
    network_facts = fact_collector.get_interface_facts()

    # Check that the object has the correct 'platform' string
    assert network_facts.platform == 'SunOS'

    # Check that the object has the correct 'all_ipv4_addresses' list
    assert network_facts.all_ipv4_addresses == ['192.168.0.100']

    # Check that the object has the correct 'all_ipv6_addresses' list

# Generated at 2022-06-20 18:23:46.372757
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    SunOS = SunOSNetwork()
    SunOS.module=AnsibleModule(argument_spec={})
    # Create test data for input to get_interfaces_info()

# Generated at 2022-06-20 18:23:57.770395
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    main_dict = {}
    SunOSNetwork().parse_interface_line(['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232'],
                                        main_dict,
                                        {})
    assert main_dict['device'] == 'lo0'
    assert main_dict['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'
    assert main_dict['ipv4'][0]['mtu'] == '8232'
    assert main_dict['type'] == 'loopback'



# Generated at 2022-06-20 18:24:07.909852
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-20 18:24:10.319976
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork()

    net.get_interfaces_info('/sbin/ifconfig')

# Generated at 2022-06-20 18:24:25.831340
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork()
    current_if = {'device': 'eno1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {}
    words=['ether', '0:1:2:d:e:f']
    sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'


# Generated at 2022-06-20 18:24:39.138342
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # Create a fake SunOSNetwork object
    module = type('AnsibleModule', (object,), {'params': {}})

# Generated at 2022-06-20 18:24:42.612418
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    s = SunOSNetworkCollector()
    assert s._fact_class._platform == 'SunOS'
    assert s._platform == 'SunOS'

# Generated at 2022-06-20 18:24:48.277448
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    # pass empty directory name. Should use the default value '/sbin'
    # This can fail on systems that don't have ifconfig in /sbin.
    sunos_network_facts = SunOSNetwork(module)
    assert sunos_network_facts is not None

# Generated at 2022-06-20 18:24:50.180141
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'

# Generated at 2022-06-20 18:24:57.786645
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {}
    words  = ['ether', '0:1:2:d:e:f']
    current_if, ips = SunOSNetwork.parse_ether_line(iface, words, iface, {})
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:24:59.165229
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork().platform == 'SunOS'

# Generated at 2022-06-20 18:25:00.468295
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector().collect()

# Generated at 2022-06-20 18:25:01.329455
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()

# Generated at 2022-06-20 18:25:14.067273
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('AnsibleModule', (object,), {'run_command': run_command})
    ifconfig_path = 'test/resources/SunOS_ifconfig_a_output.txt'
    collector = SunOSNetwork(module)
    interfaces, ips = collector.get_interfaces_info(ifconfig_path)
    assert len(interfaces) == 3
    assert 'lo0' in interfaces
    assert 'net0' in interfaces
    assert 'net1' in interfaces
    assert len(ips) == 2
    assert ips['all_ipv4_addresses'] == ['192.0.2.1']
    assert ips['all_ipv6_addresses'] == ['2001:db8:beef::2']
    assert 'device' in interfaces['lo0']
    assert 'ipv4' in interfaces

# Generated at 2022-06-20 18:25:44.865119
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():

    class TestSunOSNetwork(SunOSNetwork):

        def __init__(self):
            self.iface = {'ipv4': [{'flags': []}], 'ipv6': [{'flags': []}]}

    test_sunos_network_object = TestSunOSNetwork()
    test_sunos_network_object.parse_ether_line(['ether', '0:1:2:d:e:f'], test_sunos_network_object.iface, {})
    assert test_sunos_network_object.iface['macaddress'] == '00:01:02:0d:0e:0f'

    # MAC address with spaces between octets e.g. 00 1a 2b 3c 4d 5e 6f

# Generated at 2022-06-20 18:25:51.471403
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Test for variable 'platform' for class SunOSNetworkCollector
    global collector_platform
    collector_platform = SunOSNetworkCollector._platform
    assert collector_platform == 'SunOS'
    # Test for variable 'fact_class' for class SunOSNetworkCollector
    global collector_fact_class
    collector_fact_class = SunOSNetworkCollector._fact_class
    assert collector_fact_class == SunOSNetwork
    # Test for variable '_platform' for class SunOSNetwork
    global fact_platform
    fact_platform = SunOSNetwork._platform
    assert fact_platform == 'SunOS'

# Generated at 2022-06-20 18:26:00.307352
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork as TestSunOSNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector as TestSunOSNetworkCollector
    m = TestSunOSNetworkCollector()._get_fact_class()(None, '', '')

# Generated at 2022-06-20 18:26:05.990006
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_n = SunOSNetwork()
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    words = ['ether', '0:1:2:d:e:f']
    sunos_n.parse_ether_line(words, current_if, ips)
    assert 'macaddress' in current_if
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:26:16.298236
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = None
    input = 'test0: flags=2001<UP,RUNNING> mtu 1500 index 2'
    current_if = {'device': 'test0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'test0': current_if}
    sunos_net = SunOSNetwork(module)
    output = sunos_net.parse_interface_line(input.split(), current_if, interfaces)
    assert output['device'] == current_if['device']
    assert output['ipv4'][0]['flags'] == '2001<UP,RUNNING>'
    assert output['ipv4'][0]['mtu'] == '1500'
    assert output['macaddress'] == 'unknown'

# Generated at 2022-06-20 18:26:24.570317
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_obj = SunOSNetwork({})
    current_if = {'macaddress': 'unknown', 'type': 'unknown',
        'ipv4': [{'flags': 'UP,BROADCAST,RUNNING,MULTICAST,IPv4', 'mtu': '1500'}],
        'ipv6': [{'flags': 'UP,RUNNING,MULTICAST,IPv6', 'mtu': '1500'}]}
    words = ['ether', '0:1:2:a:b:c']
    test_obj.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == '00:01:02:0a:0b:0c'

# Generated at 2022-06-20 18:26:26.964425
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    myobj = SunOSNetworkCollector()
    assert isinstance(myobj._fact_class, SunOSNetwork)
    assert myobj._platform == "SunOS"


# Generated at 2022-06-20 18:26:28.851497
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-20 18:26:39.631314
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    net = SunOSNetwork()
    net.parse_ether_line(['ether', '0:1:2:d:e:f'], {}, {})
    assert net.interfaces['device']['macaddress'] == '00:01:02:0d:0e:0f'
    net.parse_ether_line(['ether', '1:2:3:4:5:6'], {}, {})
    assert net.interfaces['device']['macaddress'] == '01:02:03:04:05:06'
    net.parse_ether_line(['ether', 'ffff:ffff:ffff:ffff:ffff:ffff'], {}, {})
    assert net.interfaces['device']['macaddress'] == 'ffff:ffff:ffff:ffff:ffff:ffff'
    net.parse_ether_line

# Generated at 2022-06-20 18:26:49.315979
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'
    module = AnsibleModule(
        argument_spec=dict()
    )

# Generated at 2022-06-20 18:27:33.354733
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Test case 1:
    ifconfig_path = "/usr/sbin/ifconfig"

# Generated at 2022-06-20 18:27:45.527115
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts = SunOSNetwork()
    facts.parse_ether_line(['ether:', '00:00:a:b:c:d'], {}, {})
    assert facts.interfaces['ether']['macaddress'] == '00:00:0a:0b:0c:0d'
    facts.parse_ether_line(['ether:', '0:1:2:d:e:f'], {}, {})
    assert facts.interfaces['ether']['macaddress'] == '00:01:02:0d:0e:0f'


if __name__ == '__main__':
    test_SunOSNetwork_parse_ether_line()

# Generated at 2022-06-20 18:27:57.043814
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sample_interfaces = {}
    sample_ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    current_if = {'device': 'bge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', }
    sample_interfaces['bge0'] = current_if

    test_words = ['ether', '0:1:2:d:e:f']
    iface = SunOSNetwork()
    iface.parse_ether_line(test_words, current_if, sample_ips)
    assert sample_interfaces['bge0']['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:28:08.911381
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    test_SunOSNetwork_get_interfaces_info provides unit tests for testing
    that the method SunOSNetwork.get_interfaces_info works as expected.
    """
    # Create instance of class SunOSNetwork and start test
    sunos_network = SunOSNetwork()
    assert_list_equal, assert_not_equal, assert_equal = sunos_network.assert_list_equal, sunos_network.assert_not_equal, sunos_network.assert_equal
    interfaces, ips = sunos_network.get_interfaces_info('/sbin/ifconfig')

    # Test all interface dictionaries have a macaddress, even the 'lofs' interface
    assert_not_equal(interfaces['net0']['macaddress'], 'unknown')

# Generated at 2022-06-20 18:28:21.987463
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    line = ['ether', '0:1:2:3:4:5']
    current_if = {
        'device': 'lo0',
        'ipv4': [
            {
                'flags': ['IPv4', 'Loopback', 'multicast'],
                'mtu': '9000'
            }
        ],
        'ipv6': [
            {
                'flags': ['IPv6', 'Loopback', 'multicast'],
                'mtu': '9000'
            }
        ],
        'type': 'loopback',
        'macaddress': 'unknown'
    }
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    network = SunOSNetwork()
    network.parse_ether

# Generated at 2022-06-20 18:28:25.692072
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert 'SunOSNetwork' == obj._fact_class.__name__
    assert 'SunOS' == obj._platform

# Generated at 2022-06-20 18:28:38.680741
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}

# Generated at 2022-06-20 18:28:51.863416
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts_network = SunOSNetwork()
    test_iface = dict(device='bge0', macaddress='unknown')
    words = ['ether', '0:1:2:d:e:f', 'txqueuelen', '1000', 'RX', 'bytes', '0', '(0.00', 'B)', 'TX', 'bytes', '0', '(0.00', 'B)']
    expected = dict(device='bge0', macaddress='00:01:02:0d:0e:0f')
    facts_network.parse_ether_line(words, test_iface, dict())
    assert test_iface == expected

# Generated at 2022-06-20 18:29:00.789416
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ifconfig_path='/sbin/ifconfig'
    current_if = {'device': 'net0'}
    words = ['ether', '0:1:2:d:e:f']
    facts = {
        'device': 'net0',
        'macaddress': '00:01:02:0d:0e:0f',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
    }
    SunOSNetwork(None).parse_ether_line(words, current_if, {})
    assert current_if == facts


# Generated at 2022-06-20 18:29:10.697473
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:29:59.477720
# Unit test for method parse_interface_line of class SunOSNetwork