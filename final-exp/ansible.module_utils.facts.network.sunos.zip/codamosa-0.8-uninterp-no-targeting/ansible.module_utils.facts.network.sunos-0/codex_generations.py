

# Generated at 2022-06-20 18:20:15.530735
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    def mock_module(rc=None, out=None, err=None):
        m = Mock()
        m.run_command.return_value = (rc, out, err)
        m.params = dict()
        return m

    ifconfig_path = 'ifconfig'
    interfaces = {}
    t = SunOSNetwork(mock_module())

    # Define a dictionary to compare with later

# Generated at 2022-06-20 18:20:23.562160
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    mac_facts = SunOSNetwork(dict(module_setup=True), 'ifconfig', '', '')

    mac_facts.parse_ether_line('ether 0:1:2:d:e:f'.split(), {}, {})
    assert mac_facts.current_if['macaddress'] == '00:01:02:0D:0E:0F'

# Generated at 2022-06-20 18:20:30.206284
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = MagicMock()
    module.run_command.return_value = (0, '', '')
    module.params = {'gather_subset': 'min'}
    ifconfig_path = '/sbin/ifconfig'
    current_if = {'device': 'lo0', 'macaddress': 'unknown'}
    ips = {}
    macaddress = '00:01:02:0d:0e:0f'

    words = ['ether', macaddress]
    sunos = SunOSNetwork(module)
    sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == macaddress

# Generated at 2022-06-20 18:20:31.448097
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """ Unit test for constructor of class SunOSNetworkCollector """
    SunOSNetworkCollector()

# Generated at 2022-06-20 18:20:43.316762
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    net = SunOSNetwork(dict(module=None))
    # Use different interface names to ensure 'previous' interfaces are checked

# Generated at 2022-06-20 18:20:44.831302
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(), NetworkCollector)


# Generated at 2022-06-20 18:20:56.504752
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts = SunOSNetwork()
    current_if = {}

    current_if = facts.parse_ether_line([None, '1:2:3:4:5:6'], current_if, {})
    assert current_if['macaddress'] == '01:02:03:04:05:06'

    # Test invalid macaddress - should be ignored
    current_if = facts.parse_ether_line([None, '1:2'], current_if, {})
    assert current_if['macaddress'] == '01:02:03:04:05:06'
    current_if = facts.parse_ether_line([None, '1:2:3:4:5'], current_if, {})
    assert current_if['macaddress'] == '01:02:03:04:05:06'
    current_

# Generated at 2022-06-20 18:21:09.667163
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.sunos import SunOSNetworkTestFacts

    facts = SunOSNetworkTestFacts()
    sunosifaces = facts.get_interfaces_info()
    hostvars = {}  # Dict which will contain all interfaces information

    for iface in sunosifaces['interfaces']:

        hostvars[iface] = {}

        hostvars[iface]['device'] = sunosifaces['interfaces'][iface]['device']
        hostvars[iface]['type'] = sunosifaces['interfaces'][iface]['type']
        hostvars[iface]['ipv4'] = sunosifaces['interfaces'][iface]['ipv4'][0]
        hostvars[iface]['ipv6'] = sun

# Generated at 2022-06-20 18:21:12.336511
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-20 18:21:21.659446
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create test object
    testobject = SunOSNetworkCollector(None)
    testobject.module.run_command = run_command_mock

    ifaces, ips = testobject.get_interfaces_info('/sbin/ifconfig')

    assert len(ifaces) == 2
    assert len(ifaces['bge0']['ipv4']) == 1
    assert ifaces['bge0']['ipv4'][0]['address'] == '172.16.30.131'
    assert ifaces['bge0']['ipv4'][0]['netmask'] == '255.255.255.0'
    assert len(ifaces['bge0']['ipv6']) == 1
    assert ifaces['bge0']['ipv6'][0]['address']

# Generated at 2022-06-20 18:21:40.427803
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test a SunOS interface similar to lo0
    module = FakeAnsibleModule()
    sunif = SunOSNetwork(module)
    words = [ 'lo0:',
              'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>',
              'mtu 8232',
              'index 1',
              'inet 127.0.0.1 netmask ff000000',
              'ether 8:0:27:b0:94:1f',
              'nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>',
              'groups: lo',
              'id: 0',
              'enaddr: <NONE>' ]
    current_if = {}
    interfaces = {}

# Generated at 2022-06-20 18:21:53.179332
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_module = type('', (), dict(module=None, run_command=None))
    test_class = type('SunOSNetwork', (SunOSNetwork, ), dict(module=test_module))
    test_ifconfig_path = 'ifconfig'

# Generated at 2022-06-20 18:21:59.757230
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-20 18:22:03.779135
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """ Tests if the SunOSNetworkCollector is instantiable. """
    assert SunOSNetworkCollector

# Generated at 2022-06-20 18:22:13.793055
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # create a test object and a dummy interface
    test_object = SunOSNetwork()
    current_if = {
        'device': 'dummy0',
        'type': 'unknown',
        'macaddress': 'unknown',
        'ipv4': [],
        'ipv6': [],
    }

    # parse interface line
    words = 'dummy0: flags=1<UP,LOOPBACK> mtu 8232 index 1'.split()
    current_if = test_object.parse_interface_line(words, current_if, {})

    # check
    assert current_if['device'] == 'dummy0'
    assert current_if['type'] == 'loopback'
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-20 18:22:15.909166
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Construct SunOSNetwork Class

    Expected result:
        The instance of SunOSNetwork class should be created successfully
    """
    net_collector_obj = SunOSNetworkCollector(None)
    sunos_network_obj = net_collector_obj._fact_class(net_collector_obj._module)
    assert sunos_network_obj.__class__.__name__ == 'SunOSNetwork'

# Generated at 2022-06-20 18:22:25.429080
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    class FakeModule(object):
        def __init__(self):
            self.run_command = lambda x: (0, '', '')
    class FakeSunOSNetwork(SunOSNetwork):
        def __init__(self):
            self.module = FakeModule()
    f = FakeSunOSNetwork()
    c = {'device': 'lan0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    f.parse_ether_line(['ether', '0:1:0:d:e:f'], c, ips)

# Generated at 2022-06-20 18:22:27.925447
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert isinstance(SunOSNetwork(), SunOSNetwork)



# Generated at 2022-06-20 18:22:39.843363
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = 'tests/unit/module_utils/facts/network/sunos.ifconfig'
    sunos_network = SunOSNetwork()
    interfaces, ips = sunos_network.get_interfaces_info(ifconfig_path)

    assert interfaces['lo0']['ipv4'][0]['inet'] == '127.0.0.1'
    assert interfaces['em1']['ipv4'][0]['inet'] == '10.0.0.10'
    assert interfaces['em1']['ipv6'][0]['inet6'] == 'fe80::250:56ff:fe8f:5abd'
    assert interfaces['em1']['ipv6'][0]['prefixlen'] == '64'

# Generated at 2022-06-20 18:22:50.062301
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    ifconfig_path = '/sbin/ifconfig'
    test_obj = SunOSNetwork(dict(module=dict(run_command=test_run_command)))
    current_if = {}
    interfaces = {}

    # Solaris 'ifconfig -a' will print interfaces twice, once for IPv4 and again for IPv6.
    # MTU and FLAGS also may differ between IPv4 and IPv6 on the same interface.
    # 'parse_interface_line()' checks for previously seen interfaces before defining
    # 'current_if' so that IPv6 facts don't clobber IPv4 facts (or vice versa).
    # test interface line, 'device' not seen before
    words = ['bge0:', 'flags=0x40c3', 'mtu', '1500']

# Generated at 2022-06-20 18:23:12.344669
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # test case 1
    ifconfig = SunOSNetwork()
    line = 'ether 0:c:29:7:d:f5'
    words = line.split()
    current_if = {'macaddress': None}
    ifconfig.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == '00:0c:29:07:0d:f5'
    # test case 2
    ifconfig = SunOSNetwork()
    line = 'ether 8:0:27:e7:d8:a1'
    words = line.split()
    current_if = {'macaddress': None}
    ifconfig.parse_ether_line(words, current_if, {})

# Generated at 2022-06-20 18:23:15.355845
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()



# Generated at 2022-06-20 18:23:19.496620
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    f1 = SunOSNetworkCollector()
    assert 'SunOSNetwork' == f1._fact_class.__name__
    assert 'SunOS' == f1._fact_class.platform
    assert 'SunOS' == f1._platform

# Generated at 2022-06-20 18:23:23.061382
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = NetworkCollector._create_module()
    NetworkCollector.populate(module, 'SunOS')
    assert('SunOS' == module.facts['network']['platform'])

# Generated at 2022-06-20 18:23:28.824217
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork

    facts = {}
    ips = {}
    m.parse_ether_line(['ether', '0:a:95:9d:7b:af'], facts, ips)
    assert facts['macaddress'] == '00:a:95:9d:7b:af'

    facts = {}
    ips = {}
    m.parse_ether_line(['ether', 'c:a:95:9d:7b:af'], facts, ips)
    assert facts['macaddress'] == '0c:a:95:9d:7b:af'

    facts = {}
    ips = {}
    m.parse_ether_line(['ether', 'ca:95:9d:7b:af'], facts, ips)

# Generated at 2022-06-20 18:23:31.462010
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facter_collector = SunOSNetworkCollector()
    assert facter_collector._fact_class == SunOSNetwork
    assert facter_collector._platform == 'SunOS'

# Generated at 2022-06-20 18:23:39.062711
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    out = '''
lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
e1000g0: flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4> mtu 1500 index 2
        inet 172.17.0.105 netmask ffffff00 broadcast 172.17.0.255
        ether 0:1:2:3:4:5
        media: Ethernet autoselect (1000baseT full-duplex)
        status: active
        '''
    tester = SunOSNetwork()
    interfaces = {}
    current_if = {}

# Generated at 2022-06-20 18:23:44.172987
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_obj = SunOSNetwork({})
    test_if = {}
    test_ips = {}
    test_words = ['ether', '0:1:2:d:e:f']
    test_obj.parse_ether_line(test_words, test_if, test_ips)
    assert('macaddress' in test_if)
    assert(test_if['macaddress'] == '00:01:02:0d:0e:0f')
    test_words = ['ether', '0:1:2:d:e:fg']
    test_obj.parse_ether_line(test_words, test_if, test_ips)
    assert('macaddress' in test_if)
    assert(test_if['macaddress'] == '00:01:02:0d:0e:fg')
    test_

# Generated at 2022-06-20 18:23:49.858678
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    sunos_network = SunOSNetwork(module)
    assert sunos_network.platform == 'SunOS'



# Generated at 2022-06-20 18:23:56.960024
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork()
    current_if = {'device': 'vnic1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {}
    words = ['ether', '0:1:2:d:e:f']
    sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:24:25.679044
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Setup: Instantiate SunOSNetwork object
    fact_module = SunOSNetwork()

    # Setup: Define data for test
    interface_name = 'lo0'
    interface_flags = 'UP,LOOPBACK'
    interface_mtu = '4294967295'
    interface_line = interface_name + ': flags=' + interface_flags + '<LOOPBACK,UP> mtu ' + interface_mtu

    # Setup: Split line into words
    words = interface_line.split()

    # Setup: Initialize iface, ips and interfaces
    iface = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    interfaces = {}

    # Setup: Call parse_interface_line

# Generated at 2022-06-20 18:24:38.333351
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_line = 'ether 0:1:2:d:e:f'
    test_words = test_line.split()
    test_current_if = {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    test_ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    fact_sunosn = SunOSNetwork()
    fact_sunosn.parse_ether_line(test_words, test_current_if, test_ips)

    assert test_current_if['macaddress'] == '00:01:02:0d:0e:0f'


# Generated at 2022-06-20 18:24:50.917279
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Unit test to validate the output of get_interfaces_info of class SunOSNetwork
    """

# Generated at 2022-06-20 18:25:03.132474
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # globals are ugly but it's the only way to supply the module and the
    # class instance to the facts_module!
    global module
    global SunOSNetwork

    class MockModule(object):
        def __init__(self):
            self.run_command = Mock(return_value=(0, '', ''))
            self.fail_json = Mock(return_value=dict(msg='FAILED'))

        def exit_json(self, **kwargs):
            global interfaces
            interfaces = kwargs.get('ansible_interfaces')

    class MockSunOSNetwork(object):
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-20 18:25:15.312544
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModuleMock()
    sunos_network = SunOSNetwork(module)
    # This is the content of the file 'mocked_output_sunos_ifconfig_a'
    module.run_command.return_value = (1, ifcfg.mocked_output_sunos_ifconfig_a, '')
    interfaces, ips = sunos_network.get_interfaces_info('/sbin/ifconfig')

# Generated at 2022-06-20 18:25:24.458472
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Tests SunOSNetwork.get_interfaces_info()
    """

    module = AnsibleModule(argument_spec=dict())

    def run_command_expect_success_mock(self, command):
        return 1, test_data, ''

    def get_bin_path_mock(self, name):
        return '/bin'

    def assertEqual(self, a, b):
        if a != b:
            raise Exception('got %s, expected %s' % (a, b))


# Generated at 2022-06-20 18:25:31.239018
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_net = SunOSNetwork()
    macaddress = '0:1:2:3:4:5'
    words = ['ether', macaddress]

    current_if = {}
    ips = {}

    sunos_net.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == macaddress


# Generated at 2022-06-20 18:25:44.911718
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    mod = type('AnsibleModule', (object, ), {})
    mod.get_bin_path = lambda x, y: '/sbin/ifconfig'
    setattr(mod, 'run_command', lambda *args, **kwargs: (0, '', ''))
    setattr(mod, '_socket_path', lambda *args, **kwargs: None)
    setattr(mod, 'fail_json', lambda *args, **kwargs: None)
    m = SunOSNetwork(mod)
    assert m.module == mod
    assert m.fact_class == SunOSNetwork

# Unit tests for the SunOSNetwork class methods.
#
# Note: Some of the lines in the output of '/sbin/ifconfig -a'
#       have had the interface name removed because it is used
#       to identify the interface in the output

# Generated at 2022-06-20 18:25:49.853062
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    This tests the code to parse output of command 'ifconfig -a' to get
    interfaces info using Solaris's ifconfig output for 'ifconfig -a'
    """

# Generated at 2022-06-20 18:25:52.305798
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork({})
    assert net.platform == 'SunOS'


# Generated at 2022-06-20 18:26:39.062378
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    This test is for the method get_interfaces_info of class SunOSNetwork.
    This method return a tuple containing interfaces and ips facts
    for the SunOS platform.
    """
    ifconfig_path = '/sbin/ifconfig'
    m_run_command = 'ansible.module_utils.facts.network.sunos.SunOSNetwork.run_command'

    # Mock of the method run_command
    def m_run_command_func(self, cmd):
        m = re.match(r'.*\s(-a)$', cmd[0])

# Generated at 2022-06-20 18:26:48.790171
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModuleMock()

    # Test 1 - 'ifconfig -a' output with only one interface
    rc = 0

# Generated at 2022-06-20 18:27:00.737346
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # create instance of SunOSNetwork
    net_class = SunOSNetwork()
    # ifconfig file for testing
    ifconfig_path = '/root/ansible_fact/facts/files/sunos/ifconfig-2'
    # read content of ifconfig file
    f = open(ifconfig_path, 'r')
    ifconfig_content = f.read()
    f.close()

    # create a run_command mock
    class RunCommandMock(object):
        def __init__(self):
            pass

        def run_command(self, command):
            if command[0] == net_class.module.get_bin_path('ifconfig', False):
                return 0, ifconfig_content, ''
            return 1, '', ''

    old_run_command = net_class.module.run_command
    net

# Generated at 2022-06-20 18:27:12.112986
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:27:21.603872
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    network = SunOSNetwork()
    assert isinstance(network, SunOSNetwork)
    assert isinstance(network, GenericBsdIfconfigNetwork)
    assert isinstance(network, NetworkCollector)
    assert network.platform == 'SunOS'
    assert network.get_interfaces_info == SunOSNetwork.get_interfaces_info
    assert network.parse_interface_line == SunOSNetwork.parse_interface_line
    assert network.parse_ether_line == SunOSNetwork.parse_ether_line

# Generated at 2022-06-20 18:27:31.326444
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts = SunOSNetwork()
    data = dict()

    facts.parse_ether_line(['ether', '0:1:2:d:e:f'], data, dict())
    assert 'macaddress' in data.keys()
    assert data['macaddress'] == '00:01:02:0d:0e:0f'

    facts.parse_ether_line(['ether', 'a:b:c:d:e:f'], data, dict())
    assert 'macaddress' in data.keys()
    assert data['macaddress'] == 'a:b:c:d:e:f'


# Generated at 2022-06-20 18:27:35.372871
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_SunOSNetwork = SunOSNetwork()
    result = test_SunOSNetwork.parse_ether_line(['ether', '0:1:2:d:e:f'], {}, {})
    assert result['macaddress'] == '00:01:02:0d:0e:0f'



# Generated at 2022-06-20 18:27:47.583726
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    parser = SunOSNetwork()
    interface_line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1\n'
    words = interface_line.split()
    current_if = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    result = parser.parse_interface_line(words, current_if, interfaces)
    assert result['device'] == 'lo0'
    assert result['type'] == 'loopback'
    assert len(result['ipv4']) == 1

# Generated at 2022-06-20 18:27:58.178241
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockAnsibleModule()
    module.run_command = Mock(return_value=(0, '', ''))
    test_obj = SunOSNetwork(module)

# Generated at 2022-06-20 18:28:09.466301
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = dict.fromkeys(['device', 'ipv4', 'ipv6', 'type', 'macaddress'])
    iface['type'] = 'unknown'
    iface['macaddress'] = 'unknown'
    ips = dict.fromkeys(['all_ipv4_addresses', 'all_ipv6_addresses'])
    words = ['ether', '0:1:2:d:e:f']
    iface = SunOSNetwork().parse_ether_line(
        words, iface, ips)
    assert iface['macaddress'] == '00:01:02:0d:0e:0f'
    words = ['ether', '3:4:5:6:7:8']

# Generated at 2022-06-20 18:29:13.282947
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    result = SunOSNetwork()
    assert result.platform == 'SunOS'


# Generated at 2022-06-20 18:29:22.108856
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    facts = SunOSNetwork(None)

    # Test 1
    words=['ether', '0:1:2:d:e:f']
    current_if, ips = {}, {}
    facts.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

    # Test 2
    words=['ether', '0:1:2:3:4:5']
    current_if, ips = {}, {}
    facts.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'

    # Test 3
   

# Generated at 2022-06-20 18:29:23.761146
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()


# Generated at 2022-06-20 18:29:25.813016
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector is not None

# Generated at 2022-06-20 18:29:33.934150
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    import sys


# Generated at 2022-06-20 18:29:40.222446
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Arrange
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts import defaults
    facts = Facts({}, {}, {}, {}, {}, {}, {}, {}, {})
    ansible_module = defaults.AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        check_invalid_arguments=False)
    # Act
    collected_facts = SunOSNetworkCollector(ansible_module, facts).collect()
    # Assert
    assert collected_facts
    assert 'sunos' in collected_facts['ansible_network_resources']
    assert 'interfaces' in collected_facts['ansible_network_resources']['sunos']

# Generated at 2022-06-20 18:29:47.524304
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:29:59.573173
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    words = ['e1000g0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    assert len(current_if) == 4
    assert current_if['device'] == 'e1000g0'
    assert len(current_if['ipv4']) == 1
    assert len(current_if['ipv4'][0]) == 2
    assert current_if['ipv4'][0]['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4']