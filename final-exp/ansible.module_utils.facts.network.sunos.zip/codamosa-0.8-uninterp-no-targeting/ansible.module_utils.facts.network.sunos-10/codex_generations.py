

# Generated at 2022-06-20 18:20:14.695656
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork(dict(module=dict()))

# Generated at 2022-06-20 18:20:26.839062
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    fc = SunOSNetwork()

    ifaces = {}
    words = [u'bge0:', u'flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS>', u'mtu', u'1500']
    current_if = fc.parse_interface_line(words, {}, ifaces)
    assert current_if['ipv4'][0]['flags'] == 'UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS'
    assert current_if['ipv4'][0]['mtu'] == '1500'

    ifaces = {}

# Generated at 2022-06-20 18:20:37.487962
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    data = {
        'device': 'net0',
        'ipv4': [
            {'flags': 'UP,BROADCAST,RUNNING,MULTICAST', 'mtu': 1500}
        ],
        'ipv6': [
            {'flags': 'UP,BROADCAST,RUNNING,MULTICAST,IPv6', 'mtu': 1500}
        ],
        'macaddress': 'unknown'
    }
    current_if = data
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['ether', 'a:b:1:c:d:e']
    current_if = SunOSNetwork.parse_ether_line(None, words, current_if, ips)
    assert current

# Generated at 2022-06-20 18:20:49.451321
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:21:02.220846
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # Create and initialize module
    module = AnsibleModule(argument_spec=dict())

    if_args = ['/usr/bin', '-a']
    ifconfig_path = if_args[0]
    args = if_args[1::]

    # Create and initialize collector
    collector = SunOSNetworkCollector(module=module, ifconfig_path=ifconfig_path, args=args)

    # Unit test for method get_interfaces_info
    interfaces, ips = collector.get_interfaces_info(ifconfig_path)

    # Check interfaces
    # We expect lo0, net0 and net1
    assert len(interfaces) == 3

    # Check device lo0
    device = 'lo0'
    lo0 = interfaces[device]
    assert lo0['device'] == device
    assert lo0['type']

# Generated at 2022-06-20 18:21:05.597761
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = DummyModule()
    collector = SunOSNetworkCollector(module)
    assert collector.platform == 'SunOS'


# Generated at 2022-06-20 18:21:10.067269
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    facts = {
        'kernel': 'SunOS',
        'module_setup': True
    }

    net = SunOSNetwork(module=True, facts=facts)

    assert net.platform == 'SunOS'

# Generated at 2022-06-20 18:21:20.610140
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    word_list = ['lo0:', 'flags=1000849', 'mtu', '8232']
    current_if = {}
    interfaces = {}

    current_if = SunOSNetwork.parse_interface_line(None, word_list, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0] == {'flags': '1000849', 'mtu': '8232'}
    assert 'ipv6' not in current_if.keys()

    word_list = ['lo2:', 'flags=1000849', 'mtu', '8232', 'inet', '127.0.0.1', 'netmask', 'ffffff00']
    current_

# Generated at 2022-06-20 18:21:24.816458
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    m = SunOSNetwork(dict(module=dict()))
    assert m.get_file_path() == '/sbin/ifconfig -a'

# Generated at 2022-06-20 18:21:32.270852
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos = SunOSNetwork()
    current_if = {}
    ips = {}
    words = ['ether', '0:1:2:d:e:f']
    sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'
    words = ['ether', '0:1:2:3:4:5']
    sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'

# Generated at 2022-06-20 18:21:43.746964
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    # Setup test data
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']
    current_if = {}
    interfaces = {}

    # Setup test class
    sunos_network = SunOSNetwork()

    # Execute method
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)

    # Assert results
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-20 18:21:54.526021
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    class Module:
        def run_command(self, args):
            return (0, '', '')
        def fail_json(self, *args, **kwargs):
            pass

    test_class = SunOSNetwork(Module())
    test_class.parse_ether_line(['ether', '0:1:2:3:4:5'], {}, {})
    test_class.parse_ether_line(['ether', '0:1:2:d:e:f'], {}, {})
    test_class.parse_ether_line(['ether', '0:1:2:d:e:ff'], {}, {})
    test_class.parse_ether_line(['ether', '0:1:2:d:e:f0'], {}, {})
    test_class.parse_ether_

# Generated at 2022-06-20 18:21:58.438624
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    x = SunOSNetworkCollector()
    assert x._platform == 'SunOS'
    assert x._fact_class == SunOSNetwork
    assert x._config_file == ''

# Generated at 2022-06-20 18:21:59.868827
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    SunOSNetwork(module)



# Generated at 2022-06-20 18:22:12.622195
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunos_network = SunOSNetwork()
    interfaces = {}
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    result_if = {'device': 'lo0', 'ipv4': [{'flags': ['IPv4', 'Loopback', 'UP', 'RUNNING'], 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '5']

# Generated at 2022-06-20 18:22:14.356724
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    # test if the fact_class of the object is generic
    assert net_collector.fact_class == SunOSNetwork

# Generated at 2022-06-20 18:22:22.558751
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    app1 = SunOSNetwork()
    words = ['net0:', 'flags=2001000843', 'mtu', '1424', 'index', '2']
    current_if = app1.parse_interface_line(words, {}, {})
    assert current_if['device'] == 'net0'
    assert current_if['type'] == 'unknown'
    assert current_if['ipv4'][0]['flags'] == ['IPv4', 'broadcast', 'multicast', 'group', 'member']
    assert current_if['ipv4'][0]['mtu'] == '1424'
    assert current_if['macaddress'] == 'unknown'

    app2 = SunOSNetwork()

# Generated at 2022-06-20 18:22:35.722093
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    iface1 = {'device': 'lo0', 'macaddress': '00:00:00:00:00:00', 'type': 'loopback', 'ipv4': [{'mtu': 1500, 'flags': ['UP', 'LOOPBACK', 'RUNNING']}, {'mtu': 1500, 'flags': ['UP', 'LOOPBACK', 'RUNNING']}], 'ipv6': [{'mtu': 1500, 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']}, {'mtu': 1500, 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']}]}


# Generated at 2022-06-20 18:22:41.813196
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module, platform='SunOS')
    network_class_instance = collector.get_network_instance()
    assert isinstance(network_class_instance, SunOSNetwork)


# unit test case for parsing:
#     media: Ethernet autoselect (1000baseT full-duplex)
#     status: active

# Generated at 2022-06-20 18:22:55.342052
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ifacewrapper = SunOSNetwork()
    current_if = {'ipv6': [{'mtu': '1500', 'flags': ['IPv6']}], 'macaddress': 'mac', 'type': 'type',
                  'ipv4': [{'mtu': '1500', 'flags': ['BROADCAST', 'RUNNING', 'MULTICAST']}], 'device': 'device'}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    octets = '0:0:0:d:e:f'.split(':')
    macaddress = ''
    for octet in octets:
        octet = ('0' + octet)[-2:None]
        macaddress += (octet + ':')
    macaddress = macaddress

# Generated at 2022-06-20 18:23:06.913586
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    test_if = {'device': 'lo0', 'ipv4': [], 'ipv6': []}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = SunOSNetwork.parse_interface_line(words, current_if, test_if)
    assert current_if == test_if



# Generated at 2022-06-20 18:23:17.121920
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # no ipv6
    out = """lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        lo0: flags=2002000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8252 index 1
        inet6 ::1/128
        e1000g0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2
        inet 192.168.1.91 netmask ffffff00 broadcast 192.168.1.255
        ether 0:10:20:30:40:11"""

# Generated at 2022-06-20 18:23:18.590247
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-20 18:23:30.378669
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=[], type='list'))
    )

    # SunOSNetwork.get_interfaces_info()
    # test with Solaris 11.3
    # Note: Solaris 11.1 and earlier use a completely different format
    #       for the 'ifconfig -a' output that cannot be parsed by this module.

# Generated at 2022-06-20 18:23:35.572691
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts = SunOSNetwork()
    facts.parse_ether_line(['ether', '0:1:2:d:e:f'], {}, {})
    assert facts.facts['interfaces']['lo0']['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:23:45.761308
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:23:56.959866
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface_facts = dict(
        device='hme0',
        ipv4=[],
        ipv6=[],
        type='unknown',
        macaddress='unknown',
    )
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    network_collector = SunOSNetwork(dict(module=None))
    network_collector.parse_ether_line(['ether', '0:1:2:d:e:f'], iface_facts, ips)
    assert iface_facts['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:24:09.997346
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    for collector in (SunOSNetworkCollector(), NetworkCollector):
        assert collector.get_device_from_ifname('rge0') == 'rge0'
        assert collector.get_device_from_ifname('lo0') == 'lo0'
        assert collector.get_device_from_ifname('lo0:1') == 'lo0'
        assert collector.get_device_from_ifname('svn0:1') == 'svn0'
        assert collector.get_device_from_ifname('svn0:2') == 'svn0'
        assert collector.get_device_from_ifname('svn0:1:2') == 'svn0'

# Generated at 2022-06-20 18:24:18.327906
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    words = ['ether', '0:1:2:d:e:f']
    current_if, ips = {}, ''
    sunos = SunOSNetwork()
    sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

    current_if, ips = {}, ''
    words = ['ether', '0:1:2:3:4:5']
    sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'

# Generated at 2022-06-20 18:24:30.548629
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """
    Unit test function for method parse_ether_line of class SunOSNetwork
    """
    testnet = SunOSNetwork()
    words = ['ether', '0:1:2:d:e:f']
    current_if = {'device': 'lo0'}
    expected_macaddress = '00:01:02:0d:0e:0f'
    testnet.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == expected_macaddress

    words = ['ether', '0:0:0:d:e:f']
    testnet.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == expected_macaddress

    words = ['ether', 'd:e:f']
    testnet.parse_ether

# Generated at 2022-06-20 18:24:35.160668
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(), NetworkCollector)


# Generated at 2022-06-20 18:24:43.303408
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test the get_interfaces_info function of class SunOSNetwork.
    """
    module = {'run_command': lambda *_: (0, '', ''),
              'fail_json': lambda *_: None}

    sunos_network = SunOSNetwork(module)
    interfaces, ips = sunos_network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['bge0']['ipv4'][0]['mtu'] == '1500'
    assert interfaces['bge0']['ipv6'][0]['mtu'] == '1280'
    assert interfaces['bge0']['ipv6'][0]['ether'] == '88:99:aa:bb:cc:dd'

# Generated at 2022-06-20 18:24:52.541552
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork()
    # Test with leading zeros
    words = ['ether', '0:1:2:3:4:5']
    current_if = {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    sunos_network.parse_ether_line(words, current_if, None)
    assert current_if['macaddress'] == '00:01:02:03:04:05'
    # Test without leading zero
    words = ['ether', 'a:b:c:d:e:f']
    current_if = {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

# Generated at 2022-06-20 18:24:54.368901
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact = SunOSNetworkCollector()
    assert fact.platform == 'SunOS'

# Generated at 2022-06-20 18:24:57.475365
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector().collect()
    assert facts['interfaces']['lo0']['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-20 18:25:05.828972
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Subclass SunOSNetwork so that parse_interface_line and parse_inet_line can be seen
    class TestSunOSNetwork(SunOSNetwork):
        pass

    # 6 interfaces, the output from ifconfig -a on a Solaris 11.1 system

# Generated at 2022-06-20 18:25:16.526290
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    import sys
    sys.path.insert(0, '.')
    N = SunOSNetwork()
    facts = {}
    words = ['ether', '0:1:2:d:e:f']
    N.parse_ether_line(words, facts, {})
    assert facts['macaddress'] == '00:01:02:0d:0e:0f'
    words = ['ether', '0:0:0:0:0:0']
    N.parse_ether_line(words, facts, {})
    assert facts['macaddress'] == '00:00:00:00:00:00'
    words = ['ether', '0:0:0:f:f:f']
    N.parse_ether_line(words, facts, {})

# Generated at 2022-06-20 18:25:18.642345
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(NetworkCollector(dict(), 'SunOS'), SunOSNetworkCollector)

# Generated at 2022-06-20 18:25:23.115963
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    words = ['ether', '0:1:2:d:e:f']
    current_if = {}
    ips = {}
    s = SunOSNetwork({})
    s.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:25:25.424625
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    network = SunOSNetwork({}, {})
    assert network.platform == "SunOS"

# Generated at 2022-06-20 18:25:31.961328
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact_collector = SunOSNetworkCollector()
    assert isinstance(fact_collector._fact_class, SunOSNetwork)
    assert fact_collector._platform == 'SunOS'

# Generated at 2022-06-20 18:25:40.055402
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    result = SunOSNetworkCollector()
    assert isinstance(result, SunOSNetworkCollector)
    # is also a subclass of GenericBsdNetworkCollector
    assert isinstance(result, GenericBsdNetworkCollector)


# Generated at 2022-06-20 18:25:49.170318
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {'device': 'e1000g1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['ether', '0:1:2:d:e:f']
    SunOSNetwork().parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0D:0E:0F'
    words = ['ether', '10:11:12:1d:1e:1f']
    SunOSNetwork().parse_ether_line(words, current_if, ips)

# Generated at 2022-06-20 18:25:53.523223
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModuleMock()
    sunos_network = SunOSNetwork(module)
    assert isinstance(sunos_network, SunOSNetwork)
    assert sunos_network.module == module


# Generated at 2022-06-20 18:26:04.374934
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, OPENBSD_IFCONFIG, ""))
    network_module = SunOSNetwork(module)
    interfaces, ips = network_module.get_interfaces_info('/sbin/ifconfig')
    assert "lo1" in interfaces
    assert "igb0" in interfaces
    assert interfaces["igb0"]["type"] == "ether"
    assert interfaces["igb0"]["macaddress"] == "0:4:e:92:b6:c0"
    assert interfaces["igb0"]["mtu"] == "1500"
    assert interfaces["igb0"]["flags"] == "UP BROADCAST RUNNING MULTICAST"

# Generated at 2022-06-20 18:26:15.794562
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = GenericBsdIfconfigNetwork.AnsibleModuleStub()
    sunos = SunOSNetwork(module=module)

    # Test case 1: interface 'lo0': ipv4
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'lo0': {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}

# Generated at 2022-06-20 18:26:18.987022
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._platform == 'SunOS'


# Generated at 2022-06-20 18:26:24.500284
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network = SunOSNetwork()
    interface = {'device': 'lo0'}
    ips = {}
    network.parse_ether_line(['ether', '8:0:20:c5:5e:d'], interface, ips)
    assert interface['macaddress'] == '08:00:20:c5:5e:d'

# Generated at 2022-06-20 18:26:26.237110
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net = SunOSNetworkCollector()
    assert net._platform == 'SunOS'

# Generated at 2022-06-20 18:26:29.757639
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    c = SunOSNetworkCollector()
    assert c._platform == 'SunOS'
    assert c._fact_class == SunOSNetwork

# Generated at 2022-06-20 18:26:39.369097
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunosNetwork = SunOSNetwork()
    assert sunosNetwork.platform == 'SunOS'

# Generated at 2022-06-20 18:26:41.358235
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    d = SunOSNetworkCollector()
    assert d.platform == 'SunOS'
    assert d.fact_class == SunOSNetwork


# Generated at 2022-06-20 18:26:43.943918
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == 'SunOS'

# Generated at 2022-06-20 18:26:50.380441
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = DictModule({})
    generic_bsd_ifconfig_network = SunOSNetwork(module)
    assert generic_bsd_ifconfig_network.parse_ether_line(['ether', '0:1:2:a:b:c'], {}, {}) == {'macaddress': '00:01:02:0a:0b:0c'}
    assert generic_bsd_ifconfig_network.parse_ether_line(['ether', '0:1:2:d:e:f'], {}, {}) == {'macaddress': '00:01:02:0d:0e:0f'}

# Generated at 2022-06-20 18:26:52.331861
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_network = SunOSNetwork({})
    assert sunos_network


# Generated at 2022-06-20 18:26:55.444170
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork(dict(module=dict()), None, None).platform == 'SunOS'

# Generated at 2022-06-20 18:27:07.648459
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    words = ["lo0:", "flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>", "mtu", "8232", "index", "1"]
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'lo0': {'device': 'lo0', 'ipv4': [{'flags': '2001000849', 'mtu': '8232'}], 'ipv6': [], 'type': 'unknown'}}


    SunOSNetwork().parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-20 18:27:11.468015
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # create the instance
    collector = SunOSNetworkCollector()

    # check the attribute
    # SunOSNetworkCollector._fact_class
    assert collector._fact_class == SunOSNetwork
    # SunOSNetworkCollector._platform
    assert collector._platform == 'SunOS'

# Generated at 2022-06-20 18:27:21.367928
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:27:33.352137
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetwork({})
    current_if = {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '15000'}],
                  'ipv6': [], 'type': 'loopback'}
    interfaces = {'lo0': current_if, 'vlan1': {'device': 'vlan1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'},
                  'vlan2': {'device': 'vlan2', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}

# Generated at 2022-06-20 18:28:08.105960
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_module = NetworkCollector()
    test_class = SunOSNetwork(test_module)
    test_class.platform = 'SunOS'

    interfaces = {}
    current_if = {}


# Generated at 2022-06-20 18:28:09.547090
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()

# Generated at 2022-06-20 18:28:23.136612
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    import doctest
    # This is a bit ugly, but the alternative is passing in an open file
    # object.  This way we can pass in a multi-line string with little fuss.

# Generated at 2022-06-20 18:28:33.113781
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    words = ['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>',
             'mtu 8232', 'index 1']
    current_if = SunOSNetwork.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == '1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>'
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if['ipv6'] == []
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-20 18:28:35.071425
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sc = SunOSNetworkCollector()
    assert sc.platform == "SunOS"
    assert sc.fact_class == SunOSNetwork


# Generated at 2022-06-20 18:28:38.153054
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    word_list = ['ether', '0:1:2:d:e:f']
    current_if = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': ''}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    sunos_network = SunOSNetwork()
    sunos_network.parse_ether_line(word_list, current_if, ips)

    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:28:51.453501
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import get_interfaces_info
    from ansible.module_utils.facts.network.generic_bsd import parse_interfaces_info

# Generated at 2022-06-20 18:29:01.318966
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork({})
    iface = {}
    ips = {}

    words = ['ether', '0:1:2:d:e:f']
    iface = m.parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == '00:01:02:0d:0e:0f'
    assert iface == {'ipv4': [], 'ipv6': [], 'macaddress': '00:01:02:0d:0e:0f', 'device': '', 'type': 'unknown'}

    # parse_ether_line() must ignore incomplete MAC addresses and not
    # add a macaddress to the interface.
    words = ['ether', '0:1:2:d:e']

# Generated at 2022-06-20 18:29:10.889995
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    # Create instance of SunOSNetwork class.
    my_test_class = SunOSNetwork()
    assert my_test_class.platform == 'SunOS'

    # Test 'parse_options_line()'.
    words = ['options=3']
    my_test_class.parse_options_line(words, my_test_class, {'all_ipv4_addresses': []})
    assert my_test_class['ipv4'][0]['options'] == '3'

    # Test 'parse_nd6_line()'.
    words = ['nd6 options=29']
    my_test_class.parse_nd6_line(words, my_test_class, {})
    assert my_test_class['ipv6'][0]['nd6_options'] == '29'

    # Test 'parse_ether

# Generated at 2022-06-20 18:29:17.773527
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {}
    current_if = {}
    ips = {}
    network = SunOSNetwork()
    current_if = network.parse_ether_line(['ether', '0:1:2:3:4:5'], current_if, ips)

    interface_macaddress = current_if['macaddress']
    assert interface_macaddress == '00:01:02:03:04:05'

# Generated at 2022-06-20 18:30:05.562177
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_SunOS = SunOSNetwork()
    test_SunOS.parse_ether_line(['ether', 'c:0:ff:ee:b:d'], {}, {})
    assert test_SunOS.interfaces['ether'] == {'macaddress': 'c0:ff:ee:b:d:0'}