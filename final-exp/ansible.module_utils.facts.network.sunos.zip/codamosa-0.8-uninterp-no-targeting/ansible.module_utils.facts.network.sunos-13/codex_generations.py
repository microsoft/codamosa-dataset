

# Generated at 2022-06-20 18:20:18.004853
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetwork({})
    interfaces = {}
    current_if = {}

    words = ['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232']

    current_if = m.parse_interface_line(words, current_if, interfaces)

    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'] == [{'flags': '1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu': '8232'}]

    words = ['lo0:', 'flags=2000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6>', 'mtu', '8232']

    current

# Generated at 2022-06-20 18:20:25.061400
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_obj = SunOSNetwork()
    test_current_if = {'macaddress': 'unknown'}
    test_ips = {}
    test_words = ['ether', '0:1:2:d:e:f']
    test_obj.parse_ether_line(test_words, test_current_if, test_ips)
    assert test_current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:20:28.906104
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert 'SunOS' == SunOSNetwork.platform
    assert 'SunOS' == SunOSNetwork._platform



# Generated at 2022-06-20 18:20:40.398854
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    ifconfig_path = module.get_bin_path('ifconfig')
    snf = SunOSNetwork(module, ifconfig_path)
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['ether', '0:1:2:d:e:f']
    current_if = snf.parse_ether_line(words, current_if, ips)
    expected_mac_address = '00:01:02:0d:0e:0f'
    assert current_if['macaddress'] == expected_mac_address


# Generated at 2022-06-20 18:20:49.854320
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {}
    ips = {}

    # Test with full address
    words = ['ether', '0a:0b:0c:1d:1e:1f']
    SunOSNetwork._parse_ether_line(words, current_if, ips)
    assert "macaddress" in current_if and current_if["macaddress"] == "0a:0b:0c:1d:1e:1f"

    # Test with single digit address
    words = ['ether', '0:1:2:d:e:f']
    SunOSNetwork._parse_ether_line(words, current_if, ips)
    assert "macaddress" in current_if and current_if["macaddress"] == "00:01:02:0d:0e:0f"

# Generated at 2022-06-20 18:20:54.733867
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule({})
    network_collector = SunOSNetwork(module)
    assert network_collector.platform == 'SunOS'
    assert network_collector._ifconfig_path == '/usr/sbin/ifconfig'


# Generated at 2022-06-20 18:21:07.653037
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Preparing data
    data = {'device': 'lo0', 'ipv4': [{'flags': 'UP,LOOPBACK,RUNNING', 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}
    words = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232'.split()

    # Invoking method
    test = SunOSNetwork('/sbin/')
    result = test.parse_interface_line(words, data, None)

    # Verifying
    assert result == data, 'Result does not match'

# Generated at 2022-06-20 18:21:19.569539
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from sys import version_info
    if version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO
    from ansible.module_utils.facts.network.base import NetworkCollector

    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts import FactModule
    from ansible.module_utils.facts.network.base import NetworkCollector

    ifconfig_path = '/bin/ifconfig'
    module = FactModule()
    network_ifc = SunOSNetwork(module)
    network_collector = NetworkCollector({}, network_ifc)

# Generated at 2022-06-20 18:21:30.404323
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import load_platform_subclass
    from ansible.module_utils.facts.network.sunos.test_sunos_sample_data import test_interface_data_solaris
    import warnings

    warnings.filterwarnings(action='ignore', module='.*paramiko.*')
    # Create the object
    network_collector = load_platform_subclass(SunOSNetworkCollector)
    # Call the method
    interfaces_info, _ips = network_collector.get_interfaces_info('/usr/sbin/ifconfig')
    assert interfaces_info == test_interface_data_solaris
    # Cleanup - nothing to do
    pass

# Generated at 2022-06-20 18:21:42.160262
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    SunOSNetwork.parse_interface_line() Test
    """
    test_object = SunOSNetwork()
    test_dict = {}
    words = ['bge0:', 'flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4>', 'mtu', '1500']
    test_dict = test_object.parse_interface_line(words, test_dict, test_dict)

    assert test_dict['device'] == 'bge0'
    assert test_dict['type'] == 'unknown'
    assert test_dict['macaddress'] == 'unknown'
    assert test_dict['ipv4'][0]['flags'] == '1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4>'

# Generated at 2022-06-20 18:21:55.816540
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = type('DummyModule', (object,), dict(run_command=lambda *a, **kw: (0, '', '')))()
    obj = SunOSNetwork(module)
    current_if = {'device': 'testdevice', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    words = ['ether', 'a:b:c:d:e:f']
    obj.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == 'a:b:c:d:e:f'

    words = ['ether', '0:1:2:d:e:f']
    obj

# Generated at 2022-06-20 18:22:03.251200
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    i = SunOSNetwork({})
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849', 'metric', '0', 'mtu', '8232', 'index', '3']
    interfaces, current_if = i.parse_interface_line(words, current_if, interfaces)
    assert interfaces['lo0'] == {'device': 'lo0', 'ipv4': [{'flags': '2001000849', 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback'}
    assert current_if == interfaces['lo0']


# Generated at 2022-06-20 18:22:11.748580
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # GenericBsdIfconfigNetwork: 'parse_interface_line' is an abstract method
    # which should be overridden by a subclass
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    assert getattr(GenericBsdIfconfigNetwork, 'parse_interface_line', None) == None

    # Subclass SunOSNetwork defines 'parse_interface_line'
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    assert getattr(SunOSNetwork, 'parse_interface_line', None) != None

    # Subclass SunOSNetworkCollector defines 'get_interfaces_info'
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector

# Generated at 2022-06-20 18:22:23.234478
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('', (), {'run_command': classmethod(lambda x, args: (0, _sample_output, ''))})()
    fact_class = SunOSNetwork(module)
    interfaces, ips = fact_class.get_interfaces_info('/sbin/ifconfig')
    assert interfaces[u'e1000g0'][u'type'] == u'ether'
    assert interfaces[u'lo0'][u'type'] == u'loopback'
    assert interfaces[u'lo0'][u'macaddress'] == u'unknown'
    assert interfaces[u'lo0'][u'mtu'] == u'8232'
    assert interfaces[u'lo0'][u'flags'] == [u'IPv4', u'IPv6', u'Loopback']

# Generated at 2022-06-20 18:22:31.465816
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # We had to move this import up to here because of the way unittest works
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector

    network_collector = SunOSNetworkCollector(dict())
    assert network_collector is not None
    assert network_collector._fact_class is SunOSNetwork
    assert network_collector._platform == 'SunOS'

# Generated at 2022-06-20 18:22:34.659291
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    c = SunOSNetworkCollector()
    assert c.platform == 'SunOS'
    assert c._fact_class == SunOSNetwork


# Generated at 2022-06-20 18:22:46.038708
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    from ansible_collections.community.network.tests.unit.compat.mock import patch

    with patch("ansible_collections.community.network.plugins.module_utils.network.facts.network.sunos.SunOSNetwork.get_interfaces_info"):
        sunos_network = SunOSNetwork()
        current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
        ips = dict(
            all_ipv4_addresses=[],
            all_ipv6_addresses=[],
        )
        words = ["ether", "8:0:20:d:e:f"]
        sunos_network.parse_ether_line(words, current_if, ips)

# Generated at 2022-06-20 18:22:46.919033
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector()

# Generated at 2022-06-20 18:22:54.716349
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = {'run_command.return_value': ("lladdr 0:1:2:d:e:f", "", "")}
    facts = {
        'module': FakeAnsibleModule(m),
        'interface': 'lo0'
    }
    SunOSNetwork.parse_ether_line([], facts, {})
    assert facts['macaddress'] == '00:01:02:0d:0e:0f'


# Sample ifconfig output from OpenIndiana Hipster 2017.04.

# Generated at 2022-06-20 18:23:04.300375
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Create instance and assign sample data
    data = SunOSNetwork({})
    sample = ['ether', '0:1:2:d:e:f']
    # Set 'macaddress' to 'unknown' to ensure method evaluates data
    data.interfaces['ge49'] = {'device': 'ge49', 'ipv4': [{'mtu': 1500, 'flags': ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'IPv4']}], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}

    # Call the method
    data.parse_ether_line(sample, data.interfaces['ge49'], {})
    # Compare output to expected

# Generated at 2022-06-20 18:23:25.892240
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    network = SunOSNetwork(module)
    current_if = {}
    interfaces = {}

    network.parse_interface_line(['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232'],
                                 current_if, interfaces)
    assert interfaces['lo0']['type'] == 'loopback'
    assert interfaces['lo0']['mtu'] == 8232
    assert interfaces['lo0']['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL']



# Generated at 2022-06-20 18:23:29.935946
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    nc = SunOSNetwork(module)
    assert nc.platform == 'SunOS'

# Generated at 2022-06-20 18:23:40.312759
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    facts = SunOSNetwork()
    facts.module = FakeAnsibleModule()
    iface = {}
    iface_words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    iface = facts.parse_interface_line(iface_words, iface, {})
    assert iface['device'] == 'lo0'
    assert iface['type'] == 'loopback'
    assert iface['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL']
    assert iface['ipv4'][0]['mtu'] == '8232'
    assert iface

# Generated at 2022-06-20 18:23:50.757287
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_platform = 'SunOS'
    module = NetworkCollector.get_network_module(test_platform)
    obj = module.SunOSNetwork()

# Generated at 2022-06-20 18:23:59.530518
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    This function test the get_interfaces_info function from SunOSNetwork class.
    :return:
    """
    from ansible.module_utils.facts.network.sunos.sunos import SunOSNetwork


# Generated at 2022-06-20 18:24:03.179523
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sun_network = SunOSNetwork({})
    assert sun_network.platform == 'SunOS'
    assert sun_network.has_snapshot is False


# Generated at 2022-06-20 18:24:15.171047
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_fixture = {
        'device': 'lo0',
        'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8232'}],
        'ipv6': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8252'}],
        'type': 'loopback',
        'macaddress': 'unknown'
    }
    current_if = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    test_words = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'.split()
    current

# Generated at 2022-06-20 18:24:20.639005
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:24:25.438662
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    mysunosnetworkcollector = SunOSNetworkCollector()
    assert mysunosnetworkcollector._fact_class == SunOSNetwork
    assert mysunosnetworkcollector._platform == 'SunOS'


# Generated at 2022-06-20 18:24:27.282179
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    c=SunOSNetworkCollector()
    assert c._platform == 'SunOS'
    assert c._fact_class == SunOSNetwork


# Generated at 2022-06-20 18:24:54.667106
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = FakeModule()
    ifconfig_path = '/usr/sbin/ifconfig'
    ifc = SunOSNetwork(module)
    interfaces = {}
    current_if = {}

    # Test 1
    # test line:  eri0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 4
    # test line:  eri0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 4
    # test line:  eri6: flags=20008a<BROADCAST,RUNNING,MULTICAST,IPv6> mtu 1500 index 5

# Generated at 2022-06-20 18:24:59.069529
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifos = SunOSNetwork()
    ifos_dict, ips = ifos.get_interfaces_info('/usr/sbin/ifconfig')
    # assert that the dictionary is not empty
    assert ifos_dict



# Generated at 2022-06-20 18:25:12.762519
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    # Arrange
    network = SunOSNetwork()
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>',
             'mtu', '8232', 'index', '1']
    current_if = {}
    interfaces = {}
    # Act
    new_current_if = network.parse_interface_line(words, current_if, interfaces)
    # Assert
    assert new_current_if['device'] == 'lo0'
    assert new_current_if['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL']

# Generated at 2022-06-20 18:25:16.660538
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    This test checks the SunOSNetwork class.
    """

    # Get a SunOSNetwork object
    netinfo = SunOSNetwork(dict(module=dict()), 'fake_data')

# Generated at 2022-06-20 18:25:17.455332
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-20 18:25:25.007788
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Test constructor of SunOSNetwork"""
    facts_module = SunOSNetwork()
    assert facts_module.ipv4_flag_regex == r'((\S,)*(UP|BROADCAST|DEBUG|LOOPBACK|POINTOPOINT|NOTRAILERS|RUNNING|NOARP|PROMISC|ALLMULTI|INTEI|MTU:.+))(,\S)*'

# Generated at 2022-06-20 18:25:36.003737
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    fact_class = SunOSNetwork()
    interfaces = {
        'lo0': {
            'device': 'lo0',
            'ipv4': [{'flags': ['UP', 'LOOPBACK'], 'mtu': '8232'}],
            'ipv6': [{'flags': ['UP', 'LOOPBACK'], 'mtu': '8252'}],
            'type': 'loopback'
        }
    }

    # Solaris shows IPv4 and IPv6 on the same interface.
    words = ['lo0:', 'flags=200100849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232']
    fact_class.parse_interface_line(words, {}, interfaces)

# Generated at 2022-06-20 18:25:47.189080
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ifc = SunOSNetwork()
    ifc.module = MockAnsibleModule()
    words = [
            'ether', '0:1:2:3:4:5', 'loopback',
            'mtu', '4096', 'index', '1', 'flags', '0x1000849',
            'groups:', 'lo0', 'link0'
    ]
    current_if = {'ipv4': [], 'ipv6': [], 'device': 'lo0'}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    ifc.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'
    assert current_

# Generated at 2022-06-20 18:25:57.835505
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    fake_module = dict(
        run_command=lambda *args, **kwargs: (0, '', '')
    )
    fake_interface = {}
    fake_interfaces = {}
    words = ['enp1s0:', 'flags=1000843', 'mtu', '1500']
    fact_class = SunOSNetwork(fake_module)
    result_interface = fact_class.parse_interface_line(words, fake_interface, fake_interfaces)

# Generated at 2022-06-20 18:25:59.672760
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """ Unit test for SunOSNetworkCollector class constructor
    """
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-20 18:26:41.790051
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = dict()
    module['run_command'] = lambda *args, **kwargs: (0, '', '')
    sunos_network_obj = SunOSNetwork(module)
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=1000849', 'mtu', '8232']
    current_if = sunos_network_obj.parse_interface_line(words, current_if, interfaces)
    assert current_if.get('device') == 'lo0'
    assert current_if.get('ipv4')[0].get('flags') == ['1000849']
    assert current_if.get('ipv4')[0].get('mtu') == '8232'
    assert current_if.get('type') == 'loopback'

    current_if = {}


# Generated at 2022-06-20 18:26:44.855951
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    sunos_network_facts = SunOSNetwork(module)


# Generated at 2022-06-20 18:26:56.616429
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunos_module = SunOSNetwork()
    words = ['e1000g0:', 'flags=1000843', 'mtu', '1500']
    current_if = {'device': 'e1000g0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'e1000g0': current_if}
    sunos_module.parse_interface_line(words, current_if, interfaces)
    assert interfaces['e1000g0']['ipv4'] == [{'flags': ['BROADCAST', 'MULTICAST', 'IPv4', 'UP', 'RUNNING'], 'mtu': '1500'}]
    assert interfaces['e1000g0']['ipv6'] == []

# Generated at 2022-06-20 18:27:08.320266
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    This is the test case for constructor of class GenericBsdIfconfigNetwork.
    It tests the generic functions on Solaris.
    """
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    import re
    from ansible.module_utils.six import PY3
    import ansible.module_utils.facts.network.generic_bsd as generic_bsd
    generic_bsd.get_file_content = lambda x: ''
    generic_bsd.get_sysctl = lambda x: ('', '')
    generic_bsd.get_file_lines = lambda x: ''
    generic_bsd.get_func_facts = lambda x, y: {}

    # Test for parsing options line for IPv4

# Generated at 2022-06-20 18:27:10.376661
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    network = SunOSNetwork()
    assert network.platform == 'SunOS'

# Generated at 2022-06-20 18:27:12.030433
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_network = SunOSNetwork()
    assert sunos_network.platform == 'SunOS'

# Generated at 2022-06-20 18:27:17.556290
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Initialize a SunOSNetworkCollector object only for testing purpose.
    # You will not be able to use it as its constructor takes a AnsibleModule object as argument.
    fact_collector = SunOSNetworkCollector(None)
    expected_fact_class = SunOSNetwork
    actual_fact_class = fact_collector._fact_class
    assert (actual_fact_class == expected_fact_class)

# Generated at 2022-06-20 18:27:18.761752
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(), NetworkCollector)

# Generated at 2022-06-20 18:27:26.326026
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    Unit test for method parse_interface_line of class SunOSNetwork.
    """
    # create SunOSNetwork object
    sunos_network_obj = SunOSNetwork()

    # create test variables
    ifconfig_words = ["lo0:", "flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>",
                      "mtu 8232", "index 1", "inet 127.0.0.1", "netmask ff000000"]
    interfaces = {}
    current_if = {}
    sunos_network_obj.parse_interface_line(ifconfig_words, current_if, interfaces)

# Generated at 2022-06-20 18:27:31.708732
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Import at runtime due to nested imports.
    # pylint: disable=import-error
    from ansible.module_utils.facts.network.sunos.test.unit.test_get_interfaces_info import TestSunOSNetwork
    test_SunOSNetwork = TestSunOSNetwork()
    test_SunOSNetwork.test_get_interfaces_info()



# Generated at 2022-06-20 18:28:45.712266
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'


# Generated at 2022-06-20 18:28:50.132707
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    my_sunos_network_collector = SunOSNetworkCollector()
    assert my_sunos_network_collector._fact_class.platform == 'SunOS'

# Generated at 2022-06-20 18:28:59.799193
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    ifconfig_path = '/sbin/ifconfig'
    facts = SunOSNetwork(ifconfig_path)

    # Constructor sets up a lot of class variables but no 'real' facts
    assert facts.system == 'SunOS'
    assert facts.platform == 'SunOS'

    # As expected, no facts have been collected
    assert facts.interfaces == {}
    assert facts.bondings == {}
    assert facts.all_ipv4_addresses == []
    assert facts.all_ipv6_addresses == []



# Generated at 2022-06-20 18:29:10.401586
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # This unit test is for the method parse_interface_line of the class SunOSNetwork.

    module = AnsibleModule(argument_spec={})

    ifconfig_path = '/sbin/ifconfig'
    interfaces = {}
    current_if = {}
    words = 'lo0:1:'.split()

    sunos_network = SunOSNetwork(module)
    sunos_network.get_interfaces_info(ifconfig_path)

    # Test: Find the 1st interface and its type
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['mtu'] == '216'

# Generated at 2022-06-20 18:29:13.284030
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructor test for class 'SunOSNetworkCollector'.
    """
    SunOSNetworkCollector()

# Generated at 2022-06-20 18:29:16.770641
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-20 18:29:19.770633
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    network = SunOSNetwork()
    assert network.platform == 'SunOS'



# Generated at 2022-06-20 18:29:31.207589
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sunos_network = SunOSNetwork(None)

# Generated at 2022-06-20 18:29:32.558731
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-20 18:29:41.907433
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """
    Unit test for method parse_ether_line of class SunOSNetwork
    """
    test_obj = SunOSNetwork()

    current_if = {'device': 'en0'}

    # Test with colon separated MAC address without leading zeros
    words = ['ether', '0:e:c:7:e:28']

    test_obj.parse_ether_line(words, current_if, {})

    assert '0:e:c:7:e:28' == current_if['macaddress']

    # Test with colon separated MAC addres with leading zeros
    words = ['ether', '00:e:c:07:e:28']

    test_obj.parse_ether_line(words, current_if, {})
