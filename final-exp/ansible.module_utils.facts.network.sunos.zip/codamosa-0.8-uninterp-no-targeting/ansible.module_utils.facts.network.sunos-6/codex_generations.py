

# Generated at 2022-06-20 18:20:10.149672
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    assert net_collector.platform == 'SunOS'
    assert net_collector.fact_class == SunOSNetwork

# Generated at 2022-06-20 18:20:13.012355
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facter_collector = SunOSNetworkCollector
    assert facter_collector._fact_class == SunOSNetwork
    assert facter_collector._platform == 'SunOS'

# Generated at 2022-06-20 18:20:26.198961
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # testing with a dictionary that contains physical
    # interfaces only.
    ifconfig_path = '/sbin/ifconfig'
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    nm = SunOSNetwork(module)
    ret_val = nm.get_interfaces_info(ifconfig_path)
    assert ret_val is not None

    (interfaces, ips) = ret_val
    assert len(interfaces) > 0

    assert 'lo0' in interfaces
    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-20 18:20:38.154748
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    # Test data
    words = ['bge0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = {'device': 'bge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'bge0': {'device': 'bge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}

    # Create test object for SunOSNetwork class
    test_obj = SunOSNetwork()

    # Test method parse_interface_line of class SunOSNetwork
    test_obj.parse_interface_line(words, current_if, interfaces)

    # Verify result

# Generated at 2022-06-20 18:20:49.993033
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_line = "lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8232 index 1"
    test_dict = {}
    test_if = {}
    test_class = SunOSNetwork()
    test_words = test_line.split()
    test_if = test_class.parse_interface_line(test_words, test_if, test_dict)

# Generated at 2022-06-20 18:20:54.770820
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector()._platform == 'SunOS'
    assert SunOSNetworkCollector()._fact_class == SunOSNetwork

# Generated at 2022-06-20 18:20:58.152782
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork()
    assert net.platform == 'SunOS'



# Generated at 2022-06-20 18:21:10.204921
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Instantiate a test class object
    test_facts = SunOSNetwork()

    # test with single digit octets
    words = ['ether', '0:4:a:d:e:f']
    expected_macaddress = '00:04:0a:0d:0e:0f'
    current_if = {}
    ips = {}
    test_facts.parse_ether_line(words, current_if, ips)
    assert expected_macaddress == current_if['macaddress']

    # test with double digit octets
    words = ['ether', '04:0a:0d:0e:0f:0f']
    expected_macaddress = '04:0a:0d:0e:0f:0f'
    current_if = {}
    ips = {}
    test_facts.parse

# Generated at 2022-06-20 18:21:20.738171
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    iface = SunOSNetwork()
    iface.module = AnsibleModule(argument_spec={})
    iface.module.params = {'gather_network_resources': 'no'}
    iface.module.run_command = lambda com, check_rc: (0, '', '')
    iface._check_ifconfig_path = lambda: None

    # For Solaris 10, the output of ifconfig -a is:
    #
    # lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
    #        inet 127.0.0.1 netmask ff000000
    #        options=3<RXCSUM,TXCSUM>
    #
    # ce0: flags=1000843<UP,BR

# Generated at 2022-06-20 18:21:24.817068
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    print(SunOSNetworkCollector._platform)
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-20 18:21:42.132329
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
        )

# Generated at 2022-06-20 18:21:45.761982
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = SunOSNetwork(module)
    assert network_facts.platform == 'SunOS'

# Generated at 2022-06-20 18:21:51.046910
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {}
    ips = {}
    words = ['ether', '0:1:2:d:e:f']
    SunOSNetwork().parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'


# Generated at 2022-06-20 18:21:53.667106
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector._fact_class.platform == "SunOS"

# Generated at 2022-06-20 18:21:56.217541
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork({}, {})
    assert net.platform == 'SunOS'


# Generated at 2022-06-20 18:22:00.839823
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec=dict())
    sunos_network = SunOSNetwork(module)
    # test for default path
    if sunos_network_path == network.DEFAULT_INTERFACE_PATH:
        assert sunos_network._path == network.DEFAULT_INTERFACE_PATH

# Generated at 2022-06-20 18:22:12.793134
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    module = type('', (), {})()

# Generated at 2022-06-20 18:22:23.775516
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class SunOSNetwork
    This is a very simple test to check the parsing of the following
    'ifconfig -a' sample.

    Because it uses 'run_command' there is no need to mock anything.
    """
    module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=['!all'], type='list')))

    # Extract the dummy data from the comments at the top of the file.
    import inspect
    test_data = {}

# Generated at 2022-06-20 18:22:36.393622
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = FakeModule()
    network = SunOSNetwork(module=module)

    # First call to 'parse_interface_line()' defines a dict
    # Second call to 'parse_interface_line()' adds values to the dict
    words = [
        'net0:',
        'flags=2001000849<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS>',
        'mtu=1500',
    ]
    current_if = network.parse_interface_line(words, {}, {})
    assert current_if['device'] == words[0][0:-1]
    assert current_if['type'] == 'unknown'
    assert len(current_if['ipv4']) == 1

# Generated at 2022-06-20 18:22:44.457498
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeModule()

# Generated at 2022-06-20 18:22:51.273966
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()


# Generated at 2022-06-20 18:22:58.881850
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector is not None
    assert sunos_network_collector._platform == 'SunOS'
    assert issubclass(sunos_network_collector._fact_class, SunOSNetwork)


# Generated at 2022-06-20 18:23:10.189288
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = FakeAnsibleModule()

    # Should fail because 'ifconfig' doesn't exist.
    s = SunOSNetwork(module)
    assert s.module == module
    assert s.facts == {}
    assert s.commands == {}

    # If 'ifconfig' exists but fails, then no facts should be added.
    s.ifconfig_path = 'ifconfig'
    s.collect()
    assert s.facts == {}

    # If 'ifconfig' exists and succeeds, then facts should be added.

# Generated at 2022-06-20 18:23:11.450905
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork



# Generated at 2022-06-20 18:23:15.408126
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector()
    assert facts.platform == 'SunOS'
    assert facts._fact_class.platform == 'SunOS'
    assert facts._fact_class.__name__ == 'SunOSNetwork'
    assert facts._network_class_map['SunOS'] == 'SunOSNetwork'

# Generated at 2022-06-20 18:23:25.957968
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    ifconfig_path = '/sbin/ifconfig'


# Generated at 2022-06-20 18:23:39.062536
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'

# Generated at 2022-06-20 18:23:49.032675
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # create a mock module
    from ansible.module_utils.basic import AnsibleModule
    mock_module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # create object 'SunOS' to call parse_ether_line()
    sunos = SunOSNetwork(mock_module)

    # create test interfaces
    interfaces = {'e1000g0': {'device': 'e1000g0', 'ipv4': [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'IPv4'], 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}}

    # create test string

# Generated at 2022-06-20 18:23:58.918408
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test the method get_interfaces_info of SunOSNetwork class
    """
    ifconfig_path = '/usr/sbin/ifconfig'

# Generated at 2022-06-20 18:24:10.963063
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module_mock = MockModule()

# Generated at 2022-06-20 18:24:26.273865
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = Fake_AnsibleModule()
    words = ['ether', '0:1:2:d:e:f']
    iface = {}
    ips = {}
    SunOSNetwork(module).parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == '00:01:02:0d:0e:0f'


# Generated at 2022-06-20 18:24:34.812073
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    iface = {}
    current_if = {}
    interfaces = {}
    module = FakeSunOSModule()
    sunos = SunOSNetwork(module)
    rc = 0
    words = ['e1000g0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu=1500', 'index=7']
    current_if = sunos.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'e1000g0'
    assert current_if['ipv4'] == [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4'], 'mtu': '1500'}]
    assert current_if['ipv6'] == []
    assert current_

# Generated at 2022-06-20 18:24:40.809958
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    ansible_module = MockAnsibleModule()
    expected_output = {'interfaces': {}, 'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    network_collector = SunOSNetworkCollector(ansible_module)
    assert isinstance(network_collector._fact_class, SunOSNetwork)
    assert network_collector._platform == 'SunOS'
    assert network_collector.facts == expected_output


# Generated at 2022-06-20 18:24:43.886315
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    nc = SunOSNetworkCollector()
    assert nc._fact_class == SunOSNetwork
    assert nc._platform == 'SunOS'

# Generated at 2022-06-20 18:24:44.614687
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'

# Generated at 2022-06-20 18:24:45.683583
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-20 18:24:54.666052
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {}
    ips = {}
    current_if = {}

# Generated at 2022-06-20 18:24:59.069487
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Constructor test for SunOSNetwork class
    """

    # Create a SunOSNetwork class object
    network_obj = SunOSNetwork()

    # Assert object is of class SunOSNetwork
    assert isinstance(network_obj, SunOSNetwork)

# Generated at 2022-06-20 18:25:12.761578
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    fact_class = SunOSNetwork()
    facts = fact_class.get_interfaces_info('/sbin/ifconfig')
    interfaces_dict = facts[0]
    ips_dict = facts[1]
    assert len(interfaces_dict) != 0
    assert len(ips_dict) != 0

    # test e1000g0 (2 IPv4 addresses, 1 IPv6 addresses)
    e1000g0_dict = interfaces_dict['e1000g0']
    e1000g0_ipv4_addr = e1000g0_dict['ipv4'][0]['address']
    assert e1000g0_ipv4_addr.startswith('fe80::'), 'expected IPv4 link-local address'

# Generated at 2022-06-20 18:25:23.096849
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:25:40.369001
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    SunOSNetwork({}).parse_interface_line(
        ['e1000g0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500'],
        {}, {}
        )

# Generated at 2022-06-20 18:25:48.262799
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    obj = SunOSNetwork()
    line = 'ether 0:1:2:d:e:f'
    words = line.split()
    current_if = {}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    obj.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'
    assert current_if == {'macaddress': '00:01:02:0d:0e:0f'}
    assert ips == {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}

# Generated at 2022-06-20 18:26:01.606755
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork()
    current_if = {}
    words = ['ether0:','0:a:d:e:f','0','10','mb','full','duplex','group:','e1000g','group:','default_pod']
    sunos_network.parse_ether_line(words,current_if,([],[]))
    assert current_if['macaddress'] == '00:0a:0d:0e:0f'
    words = ['ether0:','0:10:11:12:13:14','0','10','mb','full','duplex','group:','e1000g','group:','default_pod']
    sunos_network.parse_ether_line(words,current_if,([],[]))

# Generated at 2022-06-20 18:26:14.597585
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    collector = SunOSNetworkCollector()
    network = SunOSNetwork()
    interfaces = {}
    current_if = {}

    # Test case 1 - physical interface
    ifconfig_line = 'hme0: flags=1000843 mtu 1500 index 2'
    words = ifconfig_line.split()
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if == {'macaddress': 'unknown', 'type': 'physical', 'device': 'hme0', 'ipv4': [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST'], 'mtu': '1500'}], 'ipv6': []}

    # Test case 2 - loopback interface

# Generated at 2022-06-20 18:26:16.033376
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-20 18:26:24.925398
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:26:26.562734
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-20 18:26:38.662018
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    with open('ansible/module_utils/facts/network/tests/sunos/ifconfig_a.out') as f:
        sunos_out = [x for x in f.read().split('\n\n') if x]
    iflist = ['lo0', 'lo1', 'lo2', 'lo3', 'net0', 'net1', 'net2', 'net3', 'net4', 'net5',
              'net6', 'net7', 'net8', 'net9', 'net10', 'net11', 'net12', 'net13', 'net14',
              'net15', 'net16', 'net17', 'net18', 'net19']
    sunos_interfaces = SunOSNetworkCollector(module=None)
    sunos_interfaces.out = sunos_out
    sunos_inter

# Generated at 2022-06-20 18:26:40.236463
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sut = SunOSNetwork(None)
    assert sut is not None


# Generated at 2022-06-20 18:26:49.247184
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = None

# Generated at 2022-06-20 18:27:02.402484
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module, path='/bin/ifconfig')
    assert isinstance(collector, SunOSNetwork) is True

# Unit test parsing the output from 'ifconfig -a'

# Generated at 2022-06-20 18:27:08.367788
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    fn = SunOSNetwork()
    current_if = {}
    words = ['ether', '0:1:2:d:e:f']
    fn.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:27:14.821815
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    result = SunOSNetwork(module)
    assert result._platform == 'SunOS'
    assert result._config_file is None
    assert result._interfaces is None
    assert result._ipaddresses is None
    assert result._interfaces_ipv4 is None
    assert result._interfaces_ipv6 is None



# Generated at 2022-06-20 18:27:17.427656
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # Create a module to test
    module = AnsibleModule(argument_spec={})

    # Call the constructor
    SunOSNetwork(module, ['ifconfig', '-a'])

# Generated at 2022-06-20 18:27:20.065897
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    instance = SunOSNetworkCollector()
    assert instance._fact_class == SunOSNetwork
    assert instance._platform == 'SunOS'

# Generated at 2022-06-20 18:27:26.293571
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class.platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class.__name__ == 'SunOSNetwork'
    assert SunOSNetworkCollector._fact_class.get_interfaces_info.__doc__ == SunOSNetwork.get_interfaces_info.__doc__

# Generated at 2022-06-20 18:27:29.853290
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    network_sunos = SunOSNetwork()
    assert network_sunos.platform == 'SunOS'


if __name__ == '__main__':
    # Unit test for constructor of class SunOSNetworkCollector
    test_SunOSNetwork()

# Generated at 2022-06-20 18:27:31.470526
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    nc = SunOSNetworkCollector()
    assert nc._platform == 'SunOS'

# Generated at 2022-06-20 18:27:40.009176
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    print("Test method parse_interface_line of class SunOSNetwork")

# Generated at 2022-06-20 18:27:48.730866
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetwork({})
    iface = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849', 'mtu', '8232', 'index', '1']
    iface = m.parse_interface_line(words, iface, interfaces)
    assert iface['device'] == 'lo0'
    assert iface['ipv4'][0]['flags'] == '2001000849'
    assert iface['ipv4'][0]['mtu'] == '8232'
    assert iface['ipv6'] == []
    assert iface['type'] == 'loopback'
    words = ['lo0:', 'flags=2001000849', 'inet', '127.0.0.1', 'netmask', 'ffffff00']
    iface = m.parse

# Generated at 2022-06-20 18:28:18.534136
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    tests = [
        {
            'words': ['ether', '0:1:2:d:e:f'],
            'current_if': {'device': 'net0'},
            'ips': {},
            'expected': {'device': 'net0', 'macaddress': '00:01:02:0d:0e:0f'}
        }
    ]
    for test in tests:
        current_if = test['current_if']
        ips = test['ips']
        SunOSNetwork().parse_ether_line(test['words'], current_if, ips)
        assert current_if == test['expected']

# Generated at 2022-06-20 18:28:20.172887
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork


# Generated at 2022-06-20 18:28:23.018642
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    c = SunOSNetworkCollector()
    assert c.platform == 'SunOS'
    assert c.fact_class == SunOSNetwork



# Generated at 2022-06-20 18:28:24.867118
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = SunOSNetwork(None)
    assert module._platform == 'SunOS'

# Generated at 2022-06-20 18:28:28.445295
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    c = SunOSNetworkCollector()
    assert(c.platform == 'SunOS')


# Generated at 2022-06-20 18:28:30.923113
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """This is a test for the constructor of class SunOSNetworkCollector"""
    network = SunOSNetworkCollector()
    assert network._fact_class.platform == 'SunOS'


# Generated at 2022-06-20 18:28:33.561984
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    my_obj = SunOSNetworkCollector()
    assert type(my_obj) == SunOSNetworkCollector
    assert my_obj.platform == 'SunOS'

# Generated at 2022-06-20 18:28:47.334912
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    filename = os.path.join(fixture_path, 'ansible_facts', 'interfaces.SunOS')
    if os.path.isfile(filename):
        interfaces = {}
        current_if = {}
        ips = dict(
            all_ipv4_addresses=[],
            all_ipv6_addresses=[],
        )
        for line in open(filename, 'r').read().splitlines():
            line = line.strip()
            if line:
                words = line.split()

                if re.match(r'^\S', line) and len(words) > 3:
                    current_if = SunOSNetwork().parse_interface_line(words, current_if, interfaces)
                    interfaces[current_if['device']] = current_if

# Generated at 2022-06-20 18:28:56.822971
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=['all'], type='list')))
    result = dict(changed=False, ansible_facts={'ansible_net_gather_subset': ['all']})
    net = SunOSNetwork(module)
    result['ansible_facts']['ansible_net_interfaces'] = net.get_interfaces_info()
    module.exit_json(**result)

# Generated at 2022-06-20 18:29:01.851473
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {}
    ips = {}
    words = ['ether', '0:1:2:d:e:f']
    iface = SunOSNetwork()
    iface.parse_ether_line(words, current_if, ips)
    # just to be sure that test passes for Solaris versions < 11
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:29:41.677153
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # sunos_interface: SunOS_Interface() instance
    sunos_interface = SunOSNetwork()

    # test_interface_output: 'ifconfig -a' output from a Solaris system

# Generated at 2022-06-20 18:29:50.765668
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Test data
    parse_ether_line_test_data = {
        'ether 0:1:2:d:e:f': '00:01:02:0d:0e:0f',
        'ether 0:1:2:3:4:5': '00:01:02:03:04:05',
        'ether 0:0:0:0:0:0': '00:00:00:00:00:00',
    }
    # Test instance of class SunOSNetwork
    tmp = SunOSNetwork({})
    for ether, macaddress in parse_ether_line_test_data.items():
        words = ether.split()
        current_if = {}
        ips = {}
        tmp.parse_ether_line(words, current_if, ips)
        assert current_if['macaddress']

# Generated at 2022-06-20 18:29:52.723410
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(), NetworkCollector)
