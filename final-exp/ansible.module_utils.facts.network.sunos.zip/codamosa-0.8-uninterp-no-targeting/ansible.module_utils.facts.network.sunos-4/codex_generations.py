

# Generated at 2022-06-20 18:20:17.943350
# Unit test for method parse_ether_line of class SunOSNetwork

# Generated at 2022-06-20 18:20:27.860316
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    facts = SunOSNetwork()
    # test case 1
    facts.parse_interface_line(['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232'], {}, {})
    assert {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL'], 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'} == facts.current_if
    # test case 2

# Generated at 2022-06-20 18:20:37.595342
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # Test Case 0
    # Test that 'get_interfaces_info' returns an empty list of interfaces
    # when ifconfig has no output.

    test_case_0_args = {
        'run_command_args': [['/usr/bin/ifconfig', '-a'],
                             {'rc': 0, 'stdout': '', 'stderr': '', 'stdin': ''}]
    }
    test_case_0_output = {
        'ansible_facts': {
            'ansible_interfaces': [],
            'ansible_all_ipv4_addresses': [],
            'ansible_all_ipv6_addresses': []
        }
    }
    test_case_0_net = SunOSNetwork(module_args=test_case_0_args)
    test

# Generated at 2022-06-20 18:20:41.671305
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    device = 'lo0'
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = {}
    interfaces = {}
    sunos_network = SunOSNetwork()

    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == device
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'

# Generated at 2022-06-20 18:20:49.687365
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_network = SunOSNetwork()
    assert 'flags' in sunos_network.parse_interface_line(['le0:', 'flags=0x800001000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,ROUTER,CoS>', 'mtu', '1280', 'index'], {}, {})
    assert 'macaddress' in sunos_network.parse_interface_line(['le0:', 'flags=0x800001000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,ROUTER,CoS>', 'mtu', '1280', 'index'], {}, {})

# Generated at 2022-06-20 18:20:53.104509
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork


# Generated at 2022-06-20 18:20:54.255919
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()


# Generated at 2022-06-20 18:21:05.148905
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    def test_file_contents(file_name):
        file = open(file_name, 'r')
        text = file.read()
        file.close()
        return text

    # Fake data for unit test
    ifconfig_path = '/usr/sbin/ifconfig'
    result_raw = test_file_contents('./unit/ansible/utils/test/facts/network/sunos/ifconfig_-a')
    result_stdout = result_raw.encode('utf-8')
    result_stderr = b''

    module = type('FakeAnsibleModule', (object,), {})()
    module.run_command = type('FakeRunCommand', (object,), {})()
    module.run_command

# Generated at 2022-06-20 18:21:17.271523
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    filename = '../../../../utils/tests/facts/network/files/SunOS/ifconfig_a_output'
    with open(filename, 'r') as f:
        out = f.read()
    module.run_command.return_value = 0, out, ''
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('ifconfig')
    # Test that a particular interface has the correct macaddress
    ether_macaddress = interfaces['ether4']['macaddress']
    assert ether_macaddress == '00:01:02:0d:0e:0f'


# Helper class to mock an AnsibleModule

# Generated at 2022-06-20 18:21:29.795083
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test for 'get_interfaces_info'
    """
    # Create the 'ifconfig' command output

# Generated at 2022-06-20 18:21:39.435859
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = type('module', (object,), {'params': {'gather_subset': ['!all']}})
    obj = SunOSNetwork(module)
    assert obj.platform == 'SunOS'


# Generated at 2022-06-20 18:21:53.146703
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # '_fact_class' is used by NetworkCollector
    fact_class = SunOSNetwork
    # '_platform' is used by NetworkCollector
    platform = 'SunOS'

    # Create an instance of the NetworkCollector.
    #
    if platform == 'SunOS':
        SunOSNetworkCollector._platform = platform
        collector = SunOSNetworkCollector(fact_class)
    else:
        return (False, "Test skipped: unable to create NetworkCollector for '{0}'.".format(platform))

    # Get the path to 'ifconfig' binary.
    #
    ifconfig_path = collector.get_bin_path('ifconfig')
    if ifconfig_path is None:
        return (False, "Test skipped: unable to find 'ifconfig' executable.")

    # Call the method being tested.
    #

# Generated at 2022-06-20 18:22:03.321155
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    obj = SunOSNetwork()

    # Test with incomplete macaddress
    words = ['ether', '0:0:0:f:e:d']
    current_if = {
        'device': 'eth0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'macaddress': 'unknown',
    }
    ips = {}
    obj.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:00:00:0f:0e:0d'

    # Test with complete macaddress
    words = ['ether', '00:01:02:0d:0e:0f']

# Generated at 2022-06-20 18:22:11.886443
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.solaris.solaris_default_network import FakeModule
    module = FakeModule()

    def fake_cmd(*args):
        f = open('/Users/tim/Projects/ansible_facts/test/unit/module_utils/facts/network/solaris.testdata/solaris.cmd.data', 'r')
        out = f.readlines()
        return (0, ''.join(out), '')

    module.run_command = fake_cmd

    net = SunOSNetwork(module)
    ifcs_info = net.get_interfaces_info('/usr/sbin/ifconfig')

# Generated at 2022-06-20 18:22:23.309309
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('module', (object,), dict(run_command=lambda x: (0, '', '')))
    net = SunOSNetwork(module)

# Generated at 2022-06-20 18:22:36.178481
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    This function initiate the class and pass sample output
    to get the result.
    """
    # Initiate class
    obj = SunOSNetwork(None)

    # Sample output

# Generated at 2022-06-20 18:22:47.125480
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    ifconfig_output = """
lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
    inet 127.0.0.1 netmask ff000000
lo0: flags=20002000<LOOPBACK,RUNNING,MULTICAST> mtu 8252 index 1
    inet6 ::1/128
"""
    module = FakeModule()
    network = SunOSNetwork(module)

    current_if = {}
    interfaces = {}

    for line in ifconfig_output.splitlines():
        words = line.split()
        if words:
            current_if = network.parse_interface_line(words, current_if, interfaces)
            interfaces[current_if['device']] = current_if


# Generated at 2022-06-20 18:22:54.812566
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    testobj = SunOSNetwork()
    test_if = {}
    test_interfaces = {}
    test_words = ['hme0:', 'flags=1000843', '<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu=1500']
    expected_test_if = {'device': 'hme0', 'ipv4': [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4'], 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown'}
    test_if = testobj.parse_interface_line(test_words, test_if, test_interfaces)
    assert test_if == expected_test_if

# Generated at 2022-06-20 18:23:02.144913
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network = SunOSNetwork()
    current_if = {}
    network.parse_ether_line(['ether', '0:1:2:d:e:f'], current_if, {})
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'


# Generated at 2022-06-20 18:23:12.357030
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    f = SunOSNetwork()
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['ether', '0:1:2:3:4:5']
    f.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'
    words = ['ether', '0:1:2:d:e:f']
    f.parse_ether_line(words, current_if, ips)

# Generated at 2022-06-20 18:23:24.629301
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunos_network = SunOSNetwork()
    # Check the system is SunOS
    if not sunos_network.is_platform_supported():
        return
    # Test if parsing interface line will not error
    sunos_network.parse_interface_line(['bge0:',
                                        'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>',
                                        'mtu 1500'])



# Generated at 2022-06-20 18:23:29.301110
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module_mock = MockModule()
    obj = SunOSNetworkCollector(module_mock)
    assert obj.network.platform == 'SunOS'


# Generated at 2022-06-20 18:23:39.061939
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_network = SunOSNetworkCollector()
    assert sunos_network._fact_class.platform == 'SunOS'
    assert sunos_network._platform == 'SunOS'
    assert sunos_network._fact_class.__name__ == 'SunOSNetwork'
    assert sunos_network._fact_class.__doc__ == '\n    This is the SunOS Network Class.\n    It uses the GenericBsdIfconfigNetwork.\n\n    Solaris can have different FLAGS and MTU for IPv4 and IPv6 on the same interface\n    so these facts have been moved inside the \'ipv4\' and \'ipv6\' lists.\n    '



# Generated at 2022-06-20 18:23:41.859044
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network = SunOSNetwork({})
    current_if = {}
    ips = {}
    words = ['', '0:1:2:d:e:f']
    network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:23:52.381430
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    mac = '0c:c4:7a:7d:1e:0f'
    ifconfig_path = '/sbin/ifconfig'

# Generated at 2022-06-20 18:23:57.569794
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork(dict(module=None))
    m.parse_ether_line(['ether', '0:1:2:d:e:f'], {}, {})
    m.parse_ether_line(['ether', '01:1:2:d:e:f'], {}, {})
    assert m.interfaces['device']['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:24:00.152265
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert (network_collector._fact_class == SunOSNetwork)
    assert (network_collector._platform == 'SunOS')

# Generated at 2022-06-20 18:24:07.014302
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test SunOSNetworkCollector"""

    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    sun_obj = SunOSNetworkCollector()
    assert sun_obj
    assert sun_obj._fact_class == SunOSNetwork
    assert sun_obj._platform == "SunOS"

# Generated at 2022-06-20 18:24:17.987363
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # create instance of class and run test
    sunos_network = SunOSNetwork()
    devices, ips = sunos_network.get_interfaces_info(ifconfig_path='/sbin/ifconfig')
    # create list of interfaces in data structure
    device_list = list(devices.keys())
    # check number of interfaces returned
    assert len(device_list) == 2
    # check interface names
    assert 'lo0' in device_list
    assert 'e1000g0' in device_list
    # check MAC address
    assert devices['e1000g0']['macaddress'] == '08:00:27:33:c7:6a'
    # check IPv6 addresses
    assert len(devices['e1000g0']['ipv6']) == 2

# Generated at 2022-06-20 18:24:28.494975
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('AnsibleModule', (object,), {'run_command': run_command_stub,
                                               'params': {'gather_network_resources':'all'}})
    module.check_mode = False
    module.debug = False
    module.exit_json = exit_json_stub
    module.fail_json = fail_json_stub

    get_interfaces_info = SunOSNetwork(module).get_interfaces_info('/sbin/ifconfig')
    assert get_interfaces_info == (expected_interfaces_output, expected_ips_output)



# Generated at 2022-06-20 18:24:49.960956
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    obj = SunOSNetwork()
    assert obj.platform == 'SunOS'
    assert obj.interfaces == obj._interfaces
    assert obj.interfaces_ls == obj._interfaces_ls
    assert obj.interfaces_ip == obj._interfaces_ip
    assert obj.interfaces_ipv6 == obj._interfaces_ipv6
    assert obj.all_ipv4_addresses == obj._all_ipv4_addresses
    assert obj.all_ipv6_addresses == obj._all_ipv6_addresses
    assert obj.default_ipv4 == obj._default_ipv4
    assert obj.default_ipv6 == obj._default_ipv6



# Generated at 2022-06-20 18:25:02.569525
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    import json
    from ansible.module_utils.facts.network.sunos.tests.unit.compat.mock import mock_open


# Generated at 2022-06-20 18:25:13.302327
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ifconfig_path = "ifconfig"
    words = ("ether", "0:c:29:ff:f5:5d")
    current_if = {'device': 'e1000g0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    sunos_network = SunOSNetwork()
    sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:0c:29:ff:f5:5d'

# Generated at 2022-06-20 18:25:16.243742
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector._fact_class == SunOSNetwork
    assert network_collector._platform == 'SunOS'

# Generated at 2022-06-20 18:25:19.616847
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    assert net_collector.platform == 'SunOS'
    assert net_collector.fact_class.platform == 'SunOS'


# Generated at 2022-06-20 18:25:33.414730
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {}
    ips = {}
    module = MockModule()
    sunos_network = SunOSNetwork()
    words = ['ether', '0:1:2:d:e:f']
    sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'
    assert ips == {}
    current_if = {}
    ips = {}
    words = ['ether', 'd:e:f:0:1:2']
    sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '0d:0e:0f:00:01:02'
    assert ips == {}
    current_

# Generated at 2022-06-20 18:25:46.034256
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create a test module
    module = AnsibleModule(argument_spec=dict())

    # Create a test ansible_facts
    facts = dict(
        interfaces='',
        default_ipv4=dict(),
        all_ipv4_addresses='',
        ansible_net_all_interfaces='',
        ansible_net_interfaces='',
        ansible_net_ipv4_addresses='',
        ansible_net_ipv6_addresses='',
        ansible_net_macaddress='',
        ansible_net_mtu='',
    )
    module.params['gather_subset'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['provider'] = dict()

    # Prepare the mock output
    mock_out

# Generated at 2022-06-20 18:25:57.170660
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:26:02.282601
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ifc = SunOSNetwork()
    ifc.parse_ether_line(['ether', '0:1:2:d:e:f'], {}, {})
    assert ifc.interfaces['unknown']['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:26:07.761068
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Create test object
    sn = SunOSNetwork()
    # Create test data
    test_if = {'device':'lo0','ipv4':[],'ipv6':[],'type':'unknown'}
    test_if_out = {'device':'lo0','ipv4':[{'flags':['UP','LOOPBACK','RUNNING'], 'mtu':'1234'}],'ipv6':[{'flags':['UP','LOOPBACK','RUNNING'], 'mtu':'67890'}],'type':'loopback'}
    test_words_in = ['lo0:', 'UP', 'LOOPBACK', 'RUNNING', 'MTU:', '1234']
    test_interfaces_in = {}

# Generated at 2022-06-20 18:26:26.150826
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    Test the method parse_interface_line of SunOSNetwork.
    """
    # Change the below values as per your setup.
    test_device = "net0"
    test_flags = "UP,BROADCAST,RUNNING,MULTICAST"
    test_mtu = "1500"
    test_current_if = {'device': test_device, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    test_interfaces = {}
    test_line = test_device + ": " + test_flags + ",MTU=" + test_mtu + " "
    test_words = test_line.split()
    test_obj = SunOSNetwork()

# Generated at 2022-06-20 18:26:38.441523
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = Mock(
        run_command=Mock(return_value=(0, '', '')),
        params=dict()
    )

    network_collector = SunOSNetwork(module)

    current_if = {'ipv4': [], 'ipv6': []}
    interfaces = {}
    words = ['e1000g0:', 'flags=201000843', 'mtu', '1500']
    current_if = network_collector.parse_interface_line(words, current_if, interfaces)
    assert '201000843' in current_if['ipv4'][0]['flags']
    assert current_if['ipv4'][0]['mtu'] == '1500'

    current_if = {'ipv4': [], 'ipv6': []}
    interfaces = {}

# Generated at 2022-06-20 18:26:48.259636
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    this_test = TestSunOSNetwork()

    interface_line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    words = interface_line.split()

    test_interfaces = {}
    test_current_if = {'device': 'lo0', 'ipv4': [{'flags': '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu': '8232'}], 'ipv6': [], 'type': 'unknown'}
    test_interfaces['lo0'] = test_current_if

    current_if = this_test.parse_interface_line(words, {}, {})
    assert current_if

# Generated at 2022-06-20 18:26:51.098505
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    '''Unit test for constructor of class SunOSNetwork'''
    sun = SunOSNetwork(dict())
    assert sun.get_file_path() == '/sbin/ifconfig'



# Generated at 2022-06-20 18:26:51.749654
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()

# Generated at 2022-06-20 18:26:58.758860
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    words = ['ether', '0:1:2:d:e:f']
    current_if = {'macaddress': 'unknown'}
    ips = dict()
    SunOSNetwork().parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'
    assert ips == dict()

# Generated at 2022-06-20 18:27:10.399253
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:27:12.380542
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork({}, {}, {}, {}, {})
    assert net.platform == 'SunOS'


# Generated at 2022-06-20 18:27:14.056973
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork.platform == 'SunOS'


# Generated at 2022-06-20 18:27:24.796346
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # 'ifconfig -a' output contains IPv6 addresses so this test will fail on non-IPv6
    # platforms like Debian.
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    sunos_network = SunOSNetwork()

    # This is a test for parsing the output of ifconfig -a on a Solaris system.
    # Ansible will feed an 'ifconfig path' parameter to the module but since
    # we're not running 'ifconfig' we just supply some test data to the method
    # instead.
    ifconfig_path = '/tmp/test.data'

# Generated at 2022-06-20 18:27:57.249400
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:28:01.773067
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fc = SunOSNetworkCollector()
    assert isinstance(fc, NetworkCollector)
    assert fc.platform == 'SunOS'
    assert fc.fact_class == SunOSNetwork

# Generated at 2022-06-20 18:28:03.473373
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    foo = SunOSNetworkCollector()


# Generated at 2022-06-20 18:28:13.179833
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    ifconfig_path = 'test_SunOSNetwork_parse_interface_line'

    def module_run_command(cmd, check_rc=True, close_fds=True, data=None, binary_data=False):
        out = "lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1\n"
        out += "lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,V6ONLY> mtu 8252 index 1\n"
        return 0, out, ''

    # Monkey patch module_run_command()
    SunOSNetwork.module_run_command = module_run_command

    sunosnet = SunOS

# Generated at 2022-06-20 18:28:16.449012
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_facts = SunOSNetwork()
    # make sure we get a SunOSNetwork instance
    assert isinstance(sunos_facts, SunOSNetwork)

# Generated at 2022-06-20 18:28:21.963779
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    '''
    Constructor
    '''
    collector = SunOSNetworkCollector()
    # Assert that the SunOSNetworkCollector test class is a subclass of NetworkCollector
    assert isinstance(collector, NetworkCollector)
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'

# Generated at 2022-06-20 18:28:28.605587
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    words = ['vni0:', 'flags=2001000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS>', 'mtu', '1450']
    current_if = SunOSNetwork.parse_interface_line(SunOSNetwork(), words, current_if, interfaces)
    assert current_if['device'] == 'vni0'
    assert current_if['macaddress'] == 'unknown'
    assert current_if['ipv4'][0]['flags'] == 'flags=2001000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS>'
    assert current_if['ipv4'][0]['mtu'] == '1450'

# Generated at 2022-06-20 18:28:37.839907
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork({})
    iface = {}
    ips = {}
    m.parse_ether_line(['ether', '0:1:2:d:e:f'], iface, ips)
    assert iface['macaddress'] == '00:01:02:0d:0e:0f'
    iface = {}
    m.parse_ether_line(['ether', '00:a0:c9:14:c8:29'], iface, ips)
    assert iface['macaddress'] == '00:a0:c9:14:c8:29'

# Generated at 2022-06-20 18:28:51.252599
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sunos_network = SunOSNetwork()

# Generated at 2022-06-20 18:28:56.489823
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    This is a unit test for the constructor of the class SunOSNetwork
    """

    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    my_obj = SunOSNetwork()

    assert my_obj


# Generated at 2022-06-20 18:29:38.479692
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    line = 'ether 0:1:2:3:4:5 '
    current_if = {'device': 'e1000', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {}
    words = line.split()
    sunos_network = SunOSNetwork(None)
    sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'
    line = 'ether 0:1:2:d:e:f '
    current_if = {'device': 'e1000', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {}
    words = line.split()

# Generated at 2022-06-20 18:29:50.078822
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    Test method SunOSNetwork.parse_interface_line()
    """
    e = SunOSNetwork()
    device = 'lo0'
    current_if = {}
    interfaces = {device: {'device': device, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}
    # ------------------------------------------------------------------------------------------------------------------
    # Test parsing an IPv4 interface
    words = ('lo0:',
             'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>',
             'mtu',
             '8232',
             'index',
             '2')
    current_if = e.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == device

# Generated at 2022-06-20 18:29:54.388970
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetwork(module)
    assert collector.get_device_resources() == ('link', 'inet', 'inet6')

# Generated at 2022-06-20 18:30:00.949783
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunosnet = SunOSNetwork(dict(), 'ansible_test_invalid_path')
    current_if = {'device': 'test', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['ether', '0:1:2:d:e:f']
    sunosnet.parse_ether_line(words, current_if, ips)
    assert 'macaddress' in current_if
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'