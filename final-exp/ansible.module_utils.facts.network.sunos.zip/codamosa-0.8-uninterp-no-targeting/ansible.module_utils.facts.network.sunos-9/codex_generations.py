

# Generated at 2022-06-20 18:20:09.966625
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector()
    assert facts.platform == 'SunOS'

# Generated at 2022-06-20 18:20:12.902214
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector._fact_class is SunOSNetwork
    assert network_collector._platform == 'SunOS'


# Generated at 2022-06-20 18:20:26.130730
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:20:36.428233
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = None
    facts = {'all_ipv4_addresses': None, 'all_ipv6_addresses': None}
    current_if = {'device': 'hme0', 'ipv4': [], 'ipv6': []}
    words = ['ether', '0:b:a:a:a:a', 'maddr', '0:1:2:d:e:f', 'lladdr', '0:0:0:f:d:e']
    sn = SunOSNetwork(module)
    sn.parse_ether_line(words, current_if, facts)
    assert current_if['macaddress'] == '00:0b:0a:0a:0a:0a'

# Generated at 2022-06-20 18:20:48.456050
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-20 18:20:54.771092
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interface_line = "lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1"
    words = interface_line.split()
    current_if = {}
    interfaces = {}
    sunos_network = SunOSNetwork()
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == "lo0"
    assert current_if['type'] == "loopback"
    assert current_if['ipv4'][0]['mtu'] == "8232"

# Generated at 2022-06-20 18:21:08.777767
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # Create a test object for SunOSNetwork
    test_obj = SunOSNetwork()

    # Create some test data
    test_lines = b"""e1000g0: flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS> mtu 1500 index 2
        inet 10.25.18.113 netmask ffffff00 broadcast 10.25.18.255
        ether 0:1:2:d:e:f
        nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>
        media: Ethernet autoselect (1000baseT <full-duplex>)
        status: active"""

# Generated at 2022-06-20 18:21:20.101269
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_object = SunOSNetwork()

    # Test data for IPv4 interface
    test_args = ['e1000g0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    test_kwargs = {'current_if': {'device': 'e1000g0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'},
                   'interfaces': {'e1000g0': {'device': 'e1000g0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}}

    result = test_object.parse_interface_line(test_args, **test_kwargs)
    # Check result
    assert(result['device'] == 'e1000g0')
   

# Generated at 2022-06-20 18:21:30.040041
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:21:35.791863
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:21:43.143921
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # No arguments:
    obj = SunOSNetwork()

    # Check attributes were initialised correctly:
    assert obj.platform == 'SunOS'

# Generated at 2022-06-20 18:21:49.504365
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test SunOSNetworkCollector Class constructor"""
    # Test with no arguments
    SunOSNetworkCollector()

    # Test with invalid argument
    try:
        SunOSNetworkCollector(1)
    except TypeError:
        pass
    else:
        raise AssertionError("Expected TypeError from SunOSNetworkCollector() constructor with invalid argument")

# Generated at 2022-06-20 18:22:02.417194
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork({})
    ether_line = 'ether 0:1:2:3:4:5'
    sunos_network.parse_ether_line(ether_line.split(), {}, {})
    assert ether_line == 'ether ' + sunos_network.interfaces['0']['macaddress']
    ether_line = 'ether 0:1:2:d:e:f'
    sunos_network.parse_ether_line(ether_line.split(), {}, {})
    assert ether_line == 'ether ' + sunos_network.interfaces['0']['macaddress']
    ether_line = 'ether 0:1:2:3:4:5  '
    sunos_network.parse_ether_line(ether_line.split(), {}, {})
    assert ether_line

# Generated at 2022-06-20 18:22:13.318005
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Construct the test object
    sunos_network = SunOSNetwork('/sbin/ifconfig')
    # Get interfaces info
    interfaces, ips = sunos_network.get_interfaces_info('/sbin/ifconfig')

    # Check interfaces
    assert len(interfaces.keys()) == 4
    for key, value in interfaces.items():
        assert 'device' in value
        assert 'type' in value
        assert value['type'] in ['ethernet', 'loopback', 'unknown']
        assert 'ipv4' in value
        assert 'ipv6' in value
        assert 'macaddress' in value
        if value['type'] == 'ethernet':
            assert 'media' in value
            assert 'status' in value

# Generated at 2022-06-20 18:22:19.620666
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = NetworkCollector()
    network = SunOSNetwork(module)
    current_if = {}
    interfaces = {}

    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['ipv4'] == [{'flags': network.get_options(words[1]), 'mtu': words[3]}]
    assert current_if['ipv6'] == []
    assert current_if['type'] == 'loopback'


# Generated at 2022-06-20 18:22:24.015026
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    obj = SunOSNetwork({}, {})

    assert 'GenericBsdIfconfigNetwork' in str(type(obj))
    assert obj.platform == 'SunOS'

# Generated at 2022-06-20 18:22:26.378999
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    n = SunOSNetworkCollector()
    assert n.platform == 'SunOS'

# Generated at 2022-06-20 18:22:38.886670
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:22:41.055794
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetwork(module)
    assert collector.platform == 'SunOS'

# Generated at 2022-06-20 18:22:54.975817
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunos = SunOSNetwork()
    current_if = {}
    interfaces = {}

    # Test adding IPv4 interface
    words = ['e1000g0:', 'flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4>', 'mtu=1500', 'index=6']
    current_if = sunos.parse_interface_line(words, current_if, interfaces)
    assert interfaces['e1000g0']['device'] == 'e1000g0'
    assert interfaces['e1000g0'] == current_if
    assert interfaces['e1000g0']['ipv4'][0]['flags'] == '1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4>'

# Generated at 2022-06-20 18:23:10.232529
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces_out = '''lo0:1: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        lo0:2: flags=10008c0<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8252 index 2
        inet6 ::1/128
      '''
    ifconfig_path = '/usr/sbin/ifconfig'  # ifconfig path in Solaris

    # initialize SunOSNetwork object
    network_obj = SunOSNetwork(None)
    network_obj.module.run_command = MagicMock()

# Generated at 2022-06-20 18:23:22.175176
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-20 18:23:32.523928
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:23:44.257567
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])

    words = ['ether', '0:1:2:d:e:f']
    SunOSNetwork.parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == '00:01:02:0d:0e:0f'

    words = ['ether', '1:2:3:ab:cd:ef']
    SunOSNetwork.parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == '01:02:03:ab:cd:ef'

# Generated at 2022-06-20 18:23:57.220012
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # create a class to test
    network_test = SunOSNetwork(dict())

    # define raw output data to test

# Generated at 2022-06-20 18:24:07.795783
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test1 = SunOSNetwork()
    words = ['e1000g0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = test1.parse_interface_line(words, {}, {})
    assert current_if == {'ipv4': [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4'], 'mtu': '1500'}],
                          'ipv6': [{}],
                          'device': 'e1000g0',
                          'type': 'unknown'}

# Generated at 2022-06-20 18:24:12.814242
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    s = SunOSNetwork(module)
    assert (s.get_interfaces('/sbin/ifconfig -a') == {})



# Generated at 2022-06-20 18:24:20.131077
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = None
    iface = SunOSNetwork(module)

# Generated at 2022-06-20 18:24:30.328391
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Create an instance of the SunOSNetwork class
    sunos_network_test = SunOSNetwork()
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # Call parse_ether_line() method
    sunos_network_test.parse_ether_line(['ether', 'e:0:a:d:b:e'], current_if, ips)
    # Check the value of macaddress is 'e0:ad:be:ee' in current_if dict
    assert current_if['macaddress'] == 'e0:ad:be:ee'

# Generated at 2022-06-20 18:24:41.650259
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    hostname = 'hostname'
    args = {}
    module = FakeModule(args=args)
    pc = SunOSNetworkCollector(module=module)
    pc.get_interfaces_info(ifconfig_path='/opt/local/sbin/ifconfig')
    interfaces = pc.get_interfaces_info(ifconfig_path='/opt/local/sbin/ifconfig')

    assert interfaces is not None
    assert len(interfaces) == 8
    for iface in interfaces:
        assert interfaces[iface] is not None
        if iface == 'ip4':
            assert interfaces[iface]['device'] == 'ip4'
            assert interfaces[iface]['ipv4'][0]['mtu'] == '9000'

# Generated at 2022-06-20 18:24:54.820767
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    mod = AnsibleModule(argument_spec={})
    net = SunOSNetwork(mod)
    assert net

# Top-level utilities may not be able to import network modules without dependencies,
# so this is wrapped in a 'main' function.

# Generated at 2022-06-20 18:25:01.473027
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_line = 'ether 0:1:2:d:e:f'
    test_current_if = {}
    test_ips = {}
    iface = SunOSNetwork()
    test_current_if = iface.parse_ether_line(test_line.split(), test_current_if, test_ips)
    assert test_current_if == {'macaddress': '00:1:2:0d:0e:0f'}

# Generated at 2022-06-20 18:25:13.840658
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_dict = {}
    test_if = {}
    test_words = 'bge0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2'.split()

    test_obj = SunOSNetwork()
    result_if = test_obj.parse_interface_line(test_words, test_if, test_dict)
    expected_if = {'device': 'bge0', 'ipv4': [{'flags': ['UP', 'BROADCAST', 'RUNNING',
                                               'MULTICAST', 'IPv4'], 'mtu': '1500'}],
                   'ipv6': [], 'type': 'unknown'}

    assert result_if == expected_if

# Generated at 2022-06-20 18:25:23.642870
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule
    sunos_network = SunOSNetwork()
    setattr(sunos_network.module, "run_command", run_command)
    interfaces, ips = sunos_network.get_interfaces_info('/sbin/ifconfig')
    for iface in interfaces:
        for v in 'ipv4', 'ipv6':
            iface_dict = interfaces[iface]
            if not isinstance(iface_dict[v], list):
                raise Exception('{} field of interface {} is not a list.'.format(v, iface))
            if len(iface_dict[v]) != 1:
                raise Exception('{} list of interface {} is not of length 1.'.format(v, iface))
            combined_facts = iface_dict[v][0]

# Generated at 2022-06-20 18:25:35.634665
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    iface_re = r'^ \S.+$'
    iface_re6 = r'^ \S.+IPv6$'

# Generated at 2022-06-20 18:25:47.013227
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'lo0': current_if}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = SunOSNetwork().parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-20 18:25:57.764543
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:26:10.601435
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Testing for issue #55617
    fn = SunOSNetwork.get_interfaces_info
    file_path = './unit/plugins/modules/facts/network/ifconfig_output/SunOS'
    with open(file_path, 'r') as f:
        lines = f.readlines()
    lines = [line.strip() for line in lines]
    rc, out, err = 0, lines, ''
    result = fn(None, None, rc, out, err)

# Generated at 2022-06-20 18:26:23.143637
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_class = SunOSNetwork()
    test_words = ['flags=', 'ether', '0:1:2:d:e:f']
    test_current_if = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    test_ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    test_class.parse_ether_line(test_words, test_current_if, test_ips)
    # Expected result:
    result = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': '00:01:02:0d:0e:0f'}
    assert test_current

# Generated at 2022-06-20 18:26:31.364084
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_class = SunOSNetworkCollector(dict())
    network_obj = test_class._fact_class()
    ret_if = network_obj.parse_interface_line(
        ['lo0:', 'flags=2001000849', 'mtu', '8232'],
        {},
        {},
    )
    assert(ret_if['device'] == 'lo0')
    assert(ret_if['type'] == 'loopback')
    assert(ret_if['ipv4'][0]['flags'] == 'UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL')
    assert(ret_if['ipv4'][0]['mtu'] == '8232')
    assert(ret_if['ipv6'] == [{}])



# Generated at 2022-06-20 18:26:52.549199
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    c_if = {}
    ips = {}
    words = ['ether', '0:1:2:d:e:f']
    SunOSNetwork().parse_ether_line(words, c_if, ips)
    assert c_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:26:59.532536
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    device = SunOSNetwork()
    assert isinstance(device, SunOSNetwork)
    assert isinstance(device, GenericBsdIfconfigNetwork)
    assert device.platform == 'SunOS'


# Generated at 2022-06-20 18:27:11.105247
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    interfaces = {}
    current_if = {}
    words = ['lo0', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232']
    network = SunOSNetwork()
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if == {'device': 'lo0',
                          'ipv4': [{'flags': '1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu': '8232'}],
                          'ipv6': [],
                          'type': 'loopback'}



# Generated at 2022-06-20 18:27:15.004209
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    network = SunOSNetwork({}, {}, {})
    assert network.platform == 'SunOS'
    assert network.get_interfaces_info.__doc__ == SunOSNetworkCollector._fact_class.get_interfaces_info.__doc__

# Generated at 2022-06-20 18:27:17.933603
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    sunos = SunOSNetwork(module)
    assert (sunos.vendor == 'SunOS'), "Unexpected Vendor '{0}'".format(sunos.vendor)
    assert (sunos.platform == 'SunOS'), "Unexpected Platform '{0}'".format(sunos.platform)

# Unit test execution

# Generated at 2022-06-20 18:27:24.555945
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_module = type('', (), {'run_command': (lambda self, args: (0, 'lo0: flags=2001000849 mtui 65536 index 2', ''))})()
    test_SunOSNetwork = SunOSNetwork(test_module)
    assert test_SunOSNetwork.parse_interface_line('lo0: flags=2001000849 mtui 65536 index 2'.split(), {}, {}) == {'device': 'lo0', 'ipv4': [{'mtu': '65536', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']}], 'ipv6': [], 'type': 'loopback'}


# Generated at 2022-06-20 18:27:27.011131
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class is not None
    assert obj._platform == 'SunOS'


# Generated at 2022-06-20 18:27:37.435195
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-20 18:27:48.219716
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {
        'ipv6': [{'flags': {'IPv6', 'UP', 'BROADCAST', 'RUNNING', 'MULTICAST'}, 'mtu': 1500}],
        'type': 'loopback',
        'ipv4': [{'flags': {'BROADCAST', 'SDHCP', 'MULTICAST', 'UP', 'RUNNING', 'LOOPBACK'}, 'mtu': 1500}],
        'device': 'lo0',
        'macaddress': 'unknown'
    }


# Generated at 2022-06-20 18:27:53.690730
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector

    collector = SunOSNetworkCollector(dict(module=None))
    assert isinstance(collector._fact_class(dict(module=None)), SunOSNetwork)

# Generated at 2022-06-20 18:28:39.375114
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = MockModule()
    interfaces = {}
    current_if = None
    m = SunOSNetwork(module=module)
    line = 'lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1'
    current_if = m.parse_interface_line(line.split(), current_if, interfaces)
    line = '  inet 127.0.0.1 netmask ff000000'
    current_if = m.parse_interface_line(line.split(), current_if, interfaces)
    line = 'lo0: flags=2004841<UP,LOOPBACK,RUNNING,MULTICAST,IPv6> mtu 8252 index 1'

# Generated at 2022-06-20 18:28:46.269113
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector().collect()
    facts.pop('all_ipv4_addresses')
    facts.pop('all_ipv6_addresses')

# Generated at 2022-06-20 18:28:57.791679
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_data = {
        "current_if": {},
        "ips": {},
        "words": ["ether", "2:8:20:c:0:12"]
    }
    sunos_network = SunOSNetwork()
    result = sunos_network.parse_ether_line(test_data['words'], test_data['current_if'], test_data['ips'])
    assert result == {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': '02:08:20:0c:00:12'}

# Generated at 2022-06-20 18:29:00.512047
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = NetworkCollector()
    my_sunos_network = SunOSNetwork(module)

    assert my_sunos_network._platform == 'SunOS'
    assert my_sunos_network.platform == 'SunOS'

# Generated at 2022-06-20 18:29:05.104447
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Test the constructor of class SunOSNetwork
    """
    sunos_network_constructor = SunOSNetwork()
    assert sunos_network_constructor.platform == 'SunOS'


# Generated at 2022-06-20 18:29:12.429319
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    module = None
    ipv4_addresses = {'10.0.0.103', '10.0.0.254'}
    ipv6_addresses = {'fe80::250:56ff:fec0:933a',
                      'fe80::2d0:56ff:fe74:5e23%net1',
                      '2001:0db8:85a3:0000:0000:8a2e:0370:7334',
                      '2001:0db8:85a3:0000:0000:8a2e:0370:7335%net1'}

# Generated at 2022-06-20 18:29:17.282151
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = MagicMock()
    nc = SunOSNetworkCollector(module=module)
    assert nc.module == module
    assert nc.platform == 'SunOS'
    assert nc.fact_class == SunOSNetwork

# Unit tests for methods of Class SunOSNetwork

# Generated at 2022-06-20 18:29:23.447564
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    ipv4 = {}
    ipv6 = {'enable_ipv6': True}
    sunos_network = SunOSNetwork(module=module, ipv4=ipv4, ipv6=ipv6)

# Generated at 2022-06-20 18:29:32.864354
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # read sample data from file
    test_ifconfig_path = './unit/modules/network/facts/files/SunOS-ifconfig-a.txt'
    with open(test_ifconfig_path) as f:
        test_ifconfig_a_content = f.read()
    ifconfig_path = '/usr/sbin/ifconfig'

    # instantiate the SunOSNetwork class
    try:
        from ansible.module_utils.facts.network.sunos.sunos import SunOSNetwork
    except ImportError as e:
        raise SkipTest('sunos.py not found, skipping this test')
    iface_facts = SunOSNetwork()

    # create a mocked 'module' object
    import ansible.module_utils.facts.network.sunos.sunos
    iface_facts.module = ansible.module

# Generated at 2022-06-20 18:29:41.997750
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = type('DummyModule', (), {})()
    module.run_command = lambda x: (0, '', '')
    ifconfig_path = 'ifconfig'

    network = SunOSNetwork(module)

    # test IPv4 interface
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', '']
    current_if = {}
    interfaces = {}
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'