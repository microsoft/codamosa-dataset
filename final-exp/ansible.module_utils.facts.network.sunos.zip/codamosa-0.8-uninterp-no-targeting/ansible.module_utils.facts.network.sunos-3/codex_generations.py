

# Generated at 2022-06-20 18:20:08.464694
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork()
    assert net.platform == 'SunOS'

# Generated at 2022-06-20 18:20:17.212988
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-20 18:20:27.642156
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class SunOSNetwork"""


# Generated at 2022-06-20 18:20:33.520299
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    ifconfig_path = '/sbin/ifconfig'
    sunos_network_collector = SunOSNetworkCollector(dict(module=None), ifconfig_path)

    assert sunos_network_collector._platform == 'SunOS'
    assert sunos_network_collector._fact_class == SunOSNetwork

# Generated at 2022-06-20 18:20:47.043115
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = FakeAnsibleModule()
    sunos_network_collector = SunOSNetworkCollector(module)
    sunos_network_collector.platform = 'SunOS'
    sunos_network_fact = SunOSNetwork(module)
    sunos_network_fact.platform = 'SunOS'

    # setup data
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = {'device': 'lo1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

# Generated at 2022-06-20 18:20:57.340644
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    import __main__
    setattr(__main__, 'MODULE_COMPLEX_ARGS', dict(gather_subset='!all,!min'))
    setattr(__main__, 'MODULE_COMPLEX_ARGS_UPDATED', dict(gather_subset='!all,!min'))
    setattr(__main__, 'MODULE_DEFAULT_ARGS', dict())
    module_path = 'ansible.module_utils.facts.network.sunos.SunOSNetwork'
    m = SunOSNetwork(module=None)
    interfaces_info, ips_info = m.get_interfaces_info(ifconfig_path='/sbin/ifconfig')
    assert 'ipv4' in interfaces_info['net10']
    assert 'ipv6' in interfaces_info['net10']


# Generated at 2022-06-20 18:21:00.198164
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test `SunOSNetworkCollector` class constructor"""
    SunOSNetworkCollector(None, None, None)

# Generated at 2022-06-20 18:21:11.135367
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    '''
    Unit test for method parse_interface_line of class SunOSNetwork
    '''
    module = type('FakeModule', (object,), {})

    import ansible.module_utils.facts.network.sunos.sunos_network as sunos_network
    s = sunos_network.SunOSNetwork(module)

    # add local loop interface to dictionary
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'lo0': current_if}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']

# Generated at 2022-06-20 18:21:19.826791
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = AnsibleModule(argument_spec={})

    ifconfig_path = 'ifconfig'
    interfaces = {}
    current_if = {'device': 'e1000g0'}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])

    test_SunOSNetwork = SunOSNetwork(module)

    words = ['ether', '0:0:0:b:e:5']
    test_SunOSNetwork.parse_ether_line(words, current_if, ips)

    assert current_if['macaddress'] == '00:00:00:0b:0e:05'

# Generated at 2022-06-20 18:21:21.665565
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    x = SunOSNetwork()
    assert x.platform == 'SunOS'

# Generated at 2022-06-20 18:21:33.514719
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    import os
    import sys
    import base64
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    if not os.path.exists('/sbin/ifconfig'):
        sys.exit("Skipping SunOSNetwork class tests, /sbin/ifconfig not found")

    # Setup the test_class object
    test_class = SunOSNetworkCollector({})

    # Get the class object associated with the test_class
    obj_class = test_class.collect()[1]

    # Get a test fixture
    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'SunOSNetwork-ifconfig-a.txt')
    with open(fixture_path, 'r') as f:
        fixture = f.read

# Generated at 2022-06-20 18:21:43.206305
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Input values
    words = ['e1000g0:', 'flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = {'device': 'e1000g0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    # Expected values
    expected_current_if = {'device': 'e1000g0', 'ipv4': [{'flags': '201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown'}
    # Test
    sunos_network = SunOSNetwork()
    current_if = sunos_

# Generated at 2022-06-20 18:21:51.143955
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    s = SunOSNetwork()
    w_a = ['ether', '0:1:2:3:4:5']
    w_b = ['ether', '0:10:20:30:40:50']
    if_a = {'device': 'lo0', 'ipv4': [{'flags': 'UP,LOOPBACK,RUNNING', 'mtu': '8232'}],
            'ipv6': [{'flags': 'UP,LOOPBACK,RUNNING', 'mtu': '8252'}],
            'type': 'loopback', 'macaddress': 'unknown'}

# Generated at 2022-06-20 18:22:02.600167
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'
    module = MockAnsibleModule()

# Generated at 2022-06-20 18:22:10.092202
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    module.run_command.return_value = 0, SUNOS_IFCONFIG, None
    fact_class = SunOSNetwork(module)
    interfaces, ips = fact_class.get_interfaces_info('')
    assert interfaces['net0']['type'] == 'ether'
    assert interfaces['net0']['ipv4'][0]['address'] == '192.168.1.101'
    assert interfaces['net0']['ipv4'][0]['subnet'] == '255.255.255.0'
    assert interfaces['net0']['ipv4'][0]['broadcast'] == '192.168.1.255'

# Generated at 2022-06-20 18:22:14.973625
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule
    module = AnsibleModule(argument_spec={})
    sunos_network_collector = SunOSNetworkCollector(module)
    sunos_network_collector.get_interfaces_info('/sbin/ifconfig')

# Generated at 2022-06-20 18:22:16.490187
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()


# Generated at 2022-06-20 18:22:25.505526
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    data = 'e1000g0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 3'
    words = data.split()
    current_if = dict(device="e1000g0", ipv4=[], ipv6=[], type='unknown')
    ifaces = dict(e1000g0=current_if)
    iface = SunOSNetwork().parse_interface_line(words, current_if, ifaces)

    assert ifaces['e1000g0']['type'] == 'unknown'
    assert ifaces['e1000g0']['ipv4'] == [dict(mtu='1500', flags=['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4'])]

# Generated at 2022-06-20 18:22:30.918840
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector.probe_name == 'network_SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-20 18:22:31.821304
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()

# Generated at 2022-06-20 18:22:46.837970
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_data = [
        'lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1',
        'lo0: flags=2000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,V6ONLY> mtu 8232 index 1',
        'lo0: flags=2400849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,V6ONLY> mtu 8232 index 1',
        'lo0: flags=2800849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,V6ONLY,DEFAULT> mtu 8232 index 1',
        ]
    for line in test_data:
        words = line.split(' ')


# Generated at 2022-06-20 18:22:54.675501
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    my_sunos = SunOSNetwork()
    my_sunos.populate()
    interfaces = my_sunos.interfaces
    assert type(interfaces) is dict
    assert type(interfaces['lo0']) is dict
    assert type(interfaces['lo0']['ipv4']) is list
    assert type(interfaces['lo0']['ipv4'][0]) is dict
    assert type(interfaces['lo0']['ipv4'][0]['address']) is str
    assert type(interfaces['lo0']['ipv4'][0]['netmask']) is str
    assert type(interfaces['lo0']['ipv4'][0]['broadcast']) is str
    assert type(interfaces['lo0']['ipv6']) is list
   

# Generated at 2022-06-20 18:23:01.433315
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = type('', (), {'run_command': lambda x, check_rc=True: ('', '', '')})
    sunos = SunOSNetwork(module)

    assert sunos.get_file_path() == '/sbin/ifconfig'
    assert sunos.platform == 'SunOS'

# Generated at 2022-06-20 18:23:06.419935
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Test the constructor of SunOSNetwork
    """
    # test empty constructor
    sunos = SunOSNetwork()
    assert sunos.platform == 'SunOS'
    assert sunos.interfaces == {}
    assert sunos.interfaces_ipv4 == {}
    assert sunos.interfaces_ipv6 == {}


# Generated at 2022-06-20 18:23:15.778228
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetworkCollector()
    iface = {}
    ifaces = {'lo0': iface}

    # test parse_interface_line() with valid data
    line = "lo0:1: flags=200<LOOPBACK,MULTICAST> mtu 8232 index 1"
    words = line.split()
    result = m.parse_interface_line(words, iface, ifaces)
    assert len(result.keys()) == 4
    assert 'device' in result
    assert result['device'] == 'lo0:1'
    assert 'ipv4' in result
    assert 'ipv6' in result
    assert 'type' in result
    assert 'macaddress' in result
    assert result['ipv4'][0]['mtu'] == '8232'

# Generated at 2022-06-20 18:23:24.630407
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test the method get_interfaces_info of the module SunOSNetwork.

    :return:
    """
    import json

    result = dict(SunOSNetwork().get_interfaces_info('/sbin/ifconfig'))
    print(json.dumps(result, indent=4))


if __name__ == '__main__':
    test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-20 18:23:37.923195
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = MagicMock()
    network_fact_obj = SunOSNetwork(module=module)
    network_fact_obj._parse_interfaces_ipv4 = MagicMock()
    network_fact_obj._parse_interfaces_ipv6 = MagicMock()
    words = ['lo0:', 'flags=849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6>', 'metric', '0',
             'mtu', '8232', 'index', '2', 'inet', '127.0.0.1', 'netmask', 'ffffff00', 'groupname',
             'loopback']

# Generated at 2022-06-20 18:23:44.629862
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    SunOS = SunOSNetwork({})
    words = ['ether', '0:1:2:d:e:f', 'txqueuelen', '0', '(Ethernet)']
    current_if = {}
    ips = {}
    SunOS.parse_ether_line(words, current_if, ips)
    assert current_if == {'macaddress': '00:01:02:0d:0e:0f'}


# Generated at 2022-06-20 18:23:53.054914
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()


if __name__ == '__main__':
    platform = SunOSNetwork()
    print('Platform name: {0}'.format(platform.platform))
    print('Platform distribution: {0}'.format(platform.distribution))
    print('Platform version: {0}'.format(platform.version))

# Generated at 2022-06-20 18:23:56.633521
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Test SunOSNetwork constructor"""
    module = AnsibleModule(argument_spec={})
    ifcfg = SunOSNetwork(module)
    assert isinstance(ifcfg, SunOSNetwork)
    assert isinstance(ifcfg, GenericBsdIfconfigNetwork)

# Generated at 2022-06-20 18:24:16.156005
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    net = SunOSNetwork()

    # output from 'ifconfig -a' for en2, which is a vlan child interface.
    # It shows the same interface twice, first for IPv4 and then for IPv6.
    # No need to test every line, but just ensure that these lines are not overwriting
    # interface information with the same interface name.

# Generated at 2022-06-20 18:24:29.998425
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Create test object
    sunos_network = SunOSNetwork()

    # test is the macaddress is parsed properly
    line = 'ether 0:1:2:d:e:f'
    expected_result = '00:01:02:0D:0E:0F'
    current_if = {'device': 'en0', 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    sunos_network.parse_ether_line(line.split(), current_if, ips)
    assert current_if['macaddress'] == expected_result

    # test if the macaddress is parsed properly when there is a longer prefix
    line = 'ether en0 0:1:2:d:e:f'
   

# Generated at 2022-06-20 18:24:37.041617
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    m = dict(
        module_utils='ansible.module_utils.facts.network.bsd.SunOSNetwork',
        module_setup='ansible.module_utils.facts.network.bsd.generic.setup',
    )

    obj = SunOSNetwork(m, '', '')

    assert obj.platform == 'SunOS'

# Generated at 2022-06-20 18:24:50.683676
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """Test parse_interface_line method of SunOSNetwork class"""

    # These are the examples I found in the internet
    # TODO: Add more examples
    # TODO: Test with all 'flags' and 'mtu' possible values

# Generated at 2022-06-20 18:25:02.081271
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # test case 1
    ifconfig_path = './tests/unit/module_utils/facts/network/test_data/SunOS_ifconfig_a.txt'
    m = SunOSNetwork()

    interfaces, ips = m.get_interfaces_info(ifconfig_path)
    
    print("== test_SunOSNetwork_get_interfaces_info() ==")
    print("interfaces=")
    print(interfaces)
    print("ips=")
    print(ips)
    print("= end test_SunOSNetwork_get_interfaces_info() =")

#if __name__ == '__main__':
#    test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-20 18:25:14.644310
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network import generic_bsd
    module = generic_bsd._fake_module('/sbin/ifconfig')
    bsd_net = SunOSNetwork(module)

    # Download empty sample file.
    ifcfg_solaris_sample = 'https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/module_utils/facts/facts.d/ifcfg_solaris_sample'
    contents = test_SunOSNetwork_get_interfaces_info._download_sample(ifcfg_solaris_sample)
    interfaces, ips = bsd_net.get_interfaces_info(contents)

    # pylint: disable=C0103
    #         Invalid constant name "test_SunOSNetwork_get_interfaces_info"
   

# Generated at 2022-06-20 18:25:21.836334
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_iface = SunOSNetwork()
    ether_line_1 = ['ether', '0:1:2:d:e:f']
    sunos_iface.parse_ether_line(ether_line_1, {}, {})
    expected_mac_address = '00:01:02:0d:0e:0f'
    assert sunos_iface.facts['device_links']['macaddress'] == expected_mac_address



# Generated at 2022-06-20 18:25:34.326237
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    # create mock module object and args
    module = MagicMock()
    module.run_command.return_value = (0, '', '')
    words = ['e1000g0:', 'flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4>', 'mtu=1500', 'index=13']
    current_if = {}
    interfaces = {}

    facts = SunOSNetwork()
    result = facts.parse_interface_line(words, current_if, interfaces)

    assert result['device'] == 'e1000g0'
    assert result['macaddress'] == 'unknown'
    assert result['type'] == 'unknown'
    assert len(result['ipv4']) == 1
    assert result['ipv4'][0]['mtu'] == '1500'


# Generated at 2022-06-20 18:25:46.232013
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    fake_module = type('', (), {})()
    fake_module.run_command = run_command_mock
    fake_module.fail_json = fail_json_mock

    # Create SunOSNetwork object
    sunos_network = SunOSNetwork(fake_module)
    # Create current_if and interfaces dicts
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback'}
    interfaces = {'lo0': current_if}

    # Create line with IPv4 interface
    line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 2'
    words = line.split()
    # Call method parse_interface_line

# Generated at 2022-06-20 18:25:48.517329
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector is not None

# Generated at 2022-06-20 18:26:15.121136
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # create an object
    SunOSObject = SunOSNetwork()

    # call parse_interface_line
    line = 'if0: flags=500008<LOOPBACK,RUNNING> mtu 64'
    words = line.split()
    current_if = SunOSObject.parse_interface_line(words, {}, {})

    # check parsed data against expected results
    assert current_if['device'] == 'if0'
    assert current_if['type'] == 'loopback'
    assert dict(current_if['ipv4'][0]) == dict(flags=['500008<LOOPBACK,RUNNING>'], mtu='64')
    assert len(current_if['ipv6']) == 0
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-20 18:26:16.163171
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-20 18:26:26.965453
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec=dict())
    module.params = dict()
    ip = SunOSNetwork(module)

    current_if = {}
    interfaces = {}

    words = ['bge0:', 'flags=20100843<UP,BROADCAST,RUNNING,IPv4,MULTICAST,ROUTER>', 'mtu=1500']
    current_if = ip.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'bge0'
    assert current_if['ipv4'][0]['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'IPv4', 'MULTICAST', 'ROUTER']
    assert current_if['ipv4'][0]['mtu'] == '1500'

# Generated at 2022-06-20 18:26:31.021728
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert isinstance(SunOSNetworkCollector.get_facts(), dict)


# Generated at 2022-06-20 18:26:37.689934
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = type('', (), {})()
    iface = {}
    ips = {}
    fact = SunOSNetwork(module)
    words = ['ether', '1:0:0:0:0:0']
    fact.parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == '01:00:00:00:00:00'
    words = ['ether', '0:f:e:d:c:b']
    fact.parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == '0f:0e:0d:0c:0b:00'

# Generated at 2022-06-20 18:26:47.948620
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    iface = SunOSNetwork(dict(module=dict(run_command=run_command_sunos)))
    info = iface.get_interfaces_info(ifconfig_path='/sbin/ifconfig')

# Generated at 2022-06-20 18:27:00.361895
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_iface = {}
    test_iface['device'] = 'lo0'
    test_iface['ipv4'] = []
    test_iface['ipv6'] = []
    test_iface['type'] = 'unknown'

    sunos_network = SunOSNetwork()
    test_parms={}

    test_words = ['lo0', 'flags=10000114949<UP,LOOPBACK,MULTICAST,IPv4,V6ONLY>', 'mtu', '8232', 'index', '1']

# Generated at 2022-06-20 18:27:02.132637
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-20 18:27:13.208189
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    '''parametrized test for parse_ether_line'''

    # parameters

# Generated at 2022-06-20 18:27:15.693768
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    assert net_collector._fact_class is SunOSNetwork
    assert net_collector._platform == 'SunOS'

# Generated at 2022-06-20 18:27:59.091361
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork()

    current_if = {}
    ips = {}

    # Test1 : Valid MAC address
    sunos_network.parse_ether_line(['ether', '0:1:2:3:4:5'], current_if, ips)

    assert(current_if['macaddress'] == '00:01:02:03:04:05')

    # Test2 : Invalid MAC address
    sunos_network.parse_ether_line(['ether', 'A:1:2:3:4:5'], current_if, ips)

    assert(current_if['macaddress'] == 'unknown')

# Generated at 2022-06-20 18:28:09.846541
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Create a test class object
    sunos_network = SunOSNetwork()

    # Test macaddress is parsed correctly for input containing single digit octets
    test_input = ['ether', '0:1:2:d:e:f']
    test_current_if = {}
    test_ips = {}
    sunos_network.parse_ether_line(test_input, test_current_if, test_ips)
    assert test_current_if['macaddress'] == '00:01:02:0d:0e:0f'

    # Test macaddress is parsed correctly for input containing double digit octets
    test_input = ['ether', '00:11:22:dd:ee:ff']
    test_current_if = {}
    test_ips = {}

# Generated at 2022-06-20 18:28:13.496189
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts import collector
    c = collector.get_network_collector('SunOS', {})
    assert isinstance(c, SunOSNetworkCollector)

# Generated at 2022-06-20 18:28:23.357966
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """SunOSNetwork - constructor test"""

    # Create SunOSNetwork object
    sunos_obj = SunOSNetwork()

    # Compaire multiple variables
    assert sunos_obj.platform == 'SunOS'
    assert sunos_obj.ifconfig_path == '/sbin/ifconfig'
    assert sunos_obj.route_path == '/usr/sbin/route'
    assert sunos_obj.base_command == ['/sbin/ifconfig', '-a']
    assert sunos_obj.default_ipv4_interface_name == 'net0'
    assert sunos_obj.default_ipv6_interface_name == 'net0'



# Generated at 2022-06-20 18:28:33.290274
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Parse a line from the output of 'ifconfig -a' on Solaris.
    words = ['lo0:', 'flags=2001000849', 'mtu', '8232', 'index', '8', 'inet', '127.0.0.1', 'netmask', 'ff000000', 'groupname', 'loopedback', 'zone', 'loopedhostzone']
    current_if = None
    interfaces = {}
    n = SunOSNetwork()
    current_if=n.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if['ipv4'][0]['flags']

# Generated at 2022-06-20 18:28:47.015012
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    from ansible.module_utils.facts.network.sunos import parse_ether_line
    from ansible.module_utils.facts.network.sunos import parse_interface_line
    #from ansible.module_utils.facts.network.sunos import parse_lladdr_line
    from ansible.module_utils.facts.network.sunos import parse_media_line
    from ansible.module_utils.facts.network.sunos import parse_status_line

    if not isinstance(SunOSNetwork, object):
        raise AssertionError('Expected SunOSNetwork to be a class')


# Generated at 2022-06-20 18:29:00.267949
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'
    bytes_regex = '[0-9]+'
    kbs_regex = '[0-9]+\.[0-9]+'
    capabilities_regex = '[A-Z][0-9]'


# Generated at 2022-06-20 18:29:10.498529
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_facts = SunOSNetwork()
    words = ''
    iface = ''
    ips = ''
    test_facts.parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == '02:00:00:00:00:00'
    words = '0:1:2:3:4:5'
    iface = {}
    test_facts.parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == '00:01:02:03:04:05'
    words = '0:0:0:d:e:f'
    iface = {}
    test_facts.parse_ether_line(words, iface, ips)

# Generated at 2022-06-20 18:29:21.089384
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunos_network = SunOSNetwork()
    interfaces = {}
    current_if = {}
    words = ['lo0:', 'flags=2001000849', 'mtu', '8232', 'index', '1']
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'] == [{'flags': ['IPv4', 'Loopback', 'UP', 'RUNNING'], 'mtu': '8232'}]
    assert current_if['ipv6'] == []
    assert current_if['type'] == 'loopback'
    assert current_if['macaddress'] == 'unknown'


# Generated at 2022-06-20 18:29:22.056695
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()