

# Generated at 2022-06-20 18:20:18.514232
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifc_path = '/sbin/ifconfig'

    module = type('AnsibleModule', (object,), dict())

# Generated at 2022-06-20 18:20:28.071683
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    print(current_if)
    assert current_if == {'macaddress': 'unknown', 'device': 'lo0',
                          'type': 'loopback', 'ipv6': [],
                          'ipv4': [{'mtu': '8232',
                                    'flags': '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'}]}


# Generated at 2022-06-20 18:20:37.658323
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_interfaces = []
    test_interfaces.append({'device': "lo0", 'ipv4':
        [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8232'}
        ], 'ipv6': [{'flags': ['UP', 'LOOPBACK', 'MULTICAST', 'IPv6'], 'mtu': '8252'}
        ], 'type': 'loopback'
        })

# Generated at 2022-06-20 18:20:47.755989
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts = SunOSNetwork()
    current_if = {'device': 'net0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    words = ['ether', '0:1:2:d:e:f', 'media:', 'Ethernet', 'autoselect']
    facts.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:20:53.367179
# Unit test for method parse_ether_line of class SunOSNetwork

# Generated at 2022-06-20 18:21:03.510256
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network = SunOSNetwork()
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    macaddress = '0:1:2:d:e:f'
    words = [None, macaddress]
    network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == macaddress
    macaddress = '1:2:3:4:5:6'
    words = [None, macaddress]
    network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == macaddress

# Generated at 2022-06-20 18:21:11.823077
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """Test SunOSNetwork parse_interface_line"""
    interfaces = {}
    current_if = {}
    # This line is a typical output of ifconfig -a
    words = 'bge0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2'.split()
    SunOSNetwork.parse_interface_line(SunOSNetwork, words, current_if, interfaces)
    assert interfaces['bge0']['ipv4'][0]['flags'] == '1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>'
    assert interfaces['bge0']['ipv4'][0]['mtu'] == '1500'



# Generated at 2022-06-20 18:21:14.350759
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = FakeAnsibleModule()
    s = SunOSNetwork(module)
    assert s.get_file_path() == '/sbin/ifconfig'


# Generated at 2022-06-20 18:21:15.941629
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(), NetworkCollector)

# Generated at 2022-06-20 18:21:29.266407
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # dicts of dicts that we'll use to store the results of each call to parse_interface_line.
    # These dicts should be the same (apart from the final entry) in the output of
    # get_interfaces_info() above
    current_if = {}
    interfaces = {}
    # output from ifconfig -a

# Generated at 2022-06-20 18:21:46.152679
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # test constructor with no params
    ifcs = SunOSNetwork()
    assert ifcs.get_interfaces() != {}
    assert ifcs.facts['all_ipv4_addresses'] != []
    assert ifcs.facts['all_ipv6_addresses'] != []

# Unit tests for split_options()

# Generated at 2022-06-20 18:21:51.252513
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    data = '0:1:2:d:e:f'
    words = data.split()
    current_if = {}
    ips = {}
    SunOSNetwork().parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:21:53.869166
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Unit test for constructor of class SunOSNetworkCollector"""
    assert(SunOSNetworkCollector._fact_class == SunOSNetwork)
    assert(SunOSNetworkCollector._platform == 'SunOS')

# Generated at 2022-06-20 18:22:00.157216
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    module = MockAnsibleModule()
    net = SunOSNetwork(module)
    net.get_interfaces_info = GenericBsdIfconfigNetwork.get_interfaces_info
    net.get_interfaces_info(ifconfig_path='/sbin/ifconfig')


# Generated at 2022-06-20 18:22:12.726146
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_SunOS = SunOSNetwork()
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849', 'mtu', '65536',
             'index', '1', 'inet', '127.0.0.1/8',
             'ether', '8:0:27:45:3a:96', 'nd6', 'options=1<PERFORMNUD>',
             'groups:', 'lo']
    expected_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    expected_if['ipv4'].append({'flags': '2001000849', 'mtu': '65536'})
    expected_if['macaddress'] = 'unknown'

# Generated at 2022-06-20 18:22:17.796393
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """ Test the constructor of SunOSNetworkCollector """
    my_network_collector = SunOSNetworkCollector()
    assert my_network_collector._platform == 'SunOS'
    assert my_network_collector._fact_class == SunOSNetwork

# Generated at 2022-06-20 18:22:19.551559
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'


# Generated at 2022-06-20 18:22:23.274911
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSNetwork



# Generated at 2022-06-20 18:22:36.134217
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos = SunOSNetwork({}, {})

    assert sunos.interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert sunos.interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert sunos.interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert sunos.interfaces['lo0']['ipv4'][0]['scope'] == 'host'
    assert sunos.interfaces['lo0']['ipv6'][0]['address'] == '::1'

# Generated at 2022-06-20 18:22:47.084132
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    iface = dict()
    current_if = dict()
    line = 'net0: flags=1e080863,c0&lt;UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN> mtu 8232 index 2\n'
    words = line.split()
    current_if = SunOSNetwork.parse_interface_line(SunOSNetwork, words, current_if, iface)

# Generated at 2022-06-20 18:23:07.119722
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """Test parse_ether_line method of SunOSNetwork class"""
    net = SunOSNetwork()
    current_if = {}
    net.parse_ether_line(['ether', '8:0:20:f7:51:a2'], current_if, {})
    assert current_if['macaddress'] == '08:00:20:f7:51:a2'
    net.parse_ether_line(['ether', '0:1:2:d:e:f'], current_if, {})
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:23:17.475114
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    this_module = SunOSNetwork()
    ifconfig_path = '/usr/sbin/ifconfig'
    iface_name = 'lo0'
    ipv4_dict = {'address': '127.0.0.1',
                 'broadcast': '127.255.255.255',
                 'netmask': '255.0.0.0',
                 'network': '127.0.0.0'}
    ipv6_dict = {'address': '::1',
                 'prefixlen': '128',
                 'scopeid': '0x10',
                 'netmask': 'ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff',
                 'network': '::1'}

# Generated at 2022-06-20 18:23:27.228816
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # GIVEN a SunOSNetwork with macaddress = 'unknown'
    sunosnet = SunOSNetwork()
    sunosnet.current_if = {'macaddress': 'unknown'}

    # WHEN parse_ether_line() is called
    words = ['ether', '0:1:2:d:e:f']
    sunosnet.parse_ether_line(words, sunosnet.current_if, sunosnet.ips)

    # THEN the macaddress has been set correctly
    if 'macaddress' in sunosnet.current_if:
        assert sunosnet.current_if['macaddress'].lower() == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:23:39.101285
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    p1 = r'(.+)'
    p2 = r'(.+)\(.+\)'
    p3 = r'([a-fA-F0-9:]+)'

# Generated at 2022-06-20 18:23:44.285775
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:23:57.223728
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    import os
    import sys
    import doctest
    import inspect
    import unittest
    import ansible.module_utils.facts.network.sunos

    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0, parentdir)

    class test_SunOSNetwork_parse_ether_line(unittest.TestCase):
        def setUp(self):
            # setup for testcase
            self.sunosnetwork = ansible.module_utils.facts.network.sunos.SunOSNetwork(None)
            pass

        def tearDown(self):
            # teardown for testcase
            self.sunosnetwork = None
            pass


# Generated at 2022-06-20 18:24:07.028409
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test for SunOSNetworkCollector
    ----------------------------------
    This test verifies that the constructor creates a SunOSNetworkCollector
    object with the following properties:

        _fact_class => SunOSNetwork
        _platform   => SunOS
    """
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector is not None, 'Test failed: SunOSNetworkCollector is None'
    assert sunos_network_collector.__class__.__name__ == 'SunOSNetworkCollector', \
        'Test failed: SunOSNetworkCollector is not an instance of SunOSNetworkCollector'
    assert sunos_network_collector._fact_class == SunOSNetwork, \
        'Test failed: _fact_class => SunOSNetwork'

# Generated at 2022-06-20 18:24:11.516537
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_line = ['ether', '0:1:2:d:e:f']
    test_if = {}
    test_ips = {}
    SunOSNetwork().parse_ether_line(test_line, test_if, test_ips)
    assert test_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:24:21.768798
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network = SunOSNetwork()
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['ether', '0:1:2:d:e:f']
    current_if = network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'
    words = ['ether', '0:1:2:3:4:5']
    current_if = network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'

# Generated at 2022-06-20 18:24:32.014585
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    network = SunOSNetwork(dict(module=None))

    current_if = {}
    interfaces = {}

    current_if = network.parse_interface_line(['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232'],
        current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['macaddress'] == 'unknown'


# Generated at 2022-06-20 18:24:45.555841
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Unit test for SunOSNetwork"""
    ifconfig_path = '/sbin/ifconfig'
    fclass = SunOSNetwork(None, ifconfig_path, 'unit_test_fixture')
    assert fclass is not None

# Generated at 2022-06-20 18:24:48.326836
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    x = SunOSNetworkCollector()
    assert x._fact_class == SunOSNetwork
    assert x._platform == 'SunOS'


# Generated at 2022-06-20 18:24:54.667327
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector().collect()
    assert 'SunOS' in facts['network']
    assert 'interfaces' in facts['network']['SunOS']
    assert 'lo0' in facts['network']['SunOS']['interfaces']

# Generated at 2022-06-20 18:25:03.085265
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network_module = SunOSNetwork(module)
    interfaces = {}
    current_if = {}
    words = ['net0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu=1500', 'index=3']
    current_if = network_module.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'net0'
    assert current_if['ipv4'][0]['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4']
    assert current_if['ipv4'][0]['mtu'] == '1500'

# Generated at 2022-06-20 18:25:05.319553
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()


# Generated at 2022-06-20 18:25:16.232517
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    line = '/dev/ge1000g0: flags=10000843<UP,BROADCAST,RUNNING,MULTICAST,ROUTER> mtu 1500 index 1'
    words = line.split()
    current_if = {'device': 'ge1000g0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {
        'ge1000g0': {'device': 'ge1000g0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    }
    current_if = SunOSNetwork().parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'ge1000g0'

# Generated at 2022-06-20 18:25:24.685964
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    _data_file = read_file('./utils/ansible/module_utils/facts/network/sunos/sample_output/ifconfig_a')

    _current_if = {'macaddress': 'unknown'}
    _ips = dict(
            all_ipv4_addresses=[],
            all_ipv6_addresses=[],
        )

    _sunosnetwork = SunOSNetwork()

    for _line in _data_file.splitlines():
        if _line:
            _words = _line.split()
            if _words[0] == 'ether':
                _sunosnetwork.parse_ether_line(_words, _current_if, _ips)

    assert _current_if['macaddress'] == '00:01:02:0d:0e:0f'



# Generated at 2022-06-20 18:25:30.662995
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetwork(module)
    assert collector.platform == 'SunOS'
    assert collector.tolerate_missing_command is False
    assert collector.command_paths['ifconfig_path'] == '/sbin/ifconfig'



# Generated at 2022-06-20 18:25:44.422230
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Set up some fake data returned by parse_interfaces_facts()
    fake_ifconfig_path = '/sbin/ifconfig'
    fake_ifconfig_rc = 0

# Generated at 2022-06-20 18:25:56.435031
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test the 'get_interfaces_info' method of the SunOSNetwork class.
    """
    import sys
    import os
    import unittest
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    MODULE_PATH = 'ansible.module_utils.facts.network.sunos'
    module_utils = __import__(MODULE_PATH, globals(), locals(), ['object'], 0)

    from ansible.module_utils import basic

    class TestBasic(unittest.TestCase):

        def setUp(self):
            self.sun_net = module_utils.SunOSNetwork()


# Generated at 2022-06-20 18:26:17.995861
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Test class SunOSNetwork
    """
    module = DummyModule()

    # invoke constructor
    SunOSNetwork(module)

    assert module.params['gather_subset'] == ['!all', '!min']



# Generated at 2022-06-20 18:26:27.578921
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    iface1 = dict(device='lo0', ipv4=[], ipv6=[], type='unknown')
    iface1['ipv4'].append({'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8232'})
    iface1['macaddress'] = 'unknown'
    iface2 = dict(device='lo0', ipv4=[], ipv6=[], type='loopback')
    iface2['ipv6'].append({'flags': ['UP', 'LOOPBACK', 'RUNNING', 'IPv6'], 'mtu': '8252'})
    iface2['macaddress'] = 'unknown'
    iface3 = dict(device='lo0', ipv4=[], ipv6=[], type='loopback')

# Generated at 2022-06-20 18:26:39.143380
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = type('', (object,), {})
    setattr(module, 'fail_json', lambda *args, **kw: None)
    setattr(module, 'run_command', lambda *args, **kw: (0, '', ''))
    iface = SunOSNetwork(module)
    interfaces = {}
    iface_match = {}
    iface_match['device'] = 'net0'
    iface_match['ipv4'] = []
    iface_match['ipv6'] = []
    iface_match['type'] = 'unknown'
    interfaces['net0'] = iface_match
    current_if = {}
    words = ['net0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']


# Generated at 2022-06-20 18:26:48.868697
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = 'tests/unit/module_utils/facts/network/sunos/ifconfig_sample.txt'

# Generated at 2022-06-20 18:26:54.503287
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = '/sbin/ifconfig'
    collector_sunos = SunOSNetwork(module, ifconfig_path=ifconfig_path)
    interfaces = collector_sunos.get_interfaces()
    assert interfaces is not None



# Generated at 2022-06-20 18:26:58.660766
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {}
    words = ['ether', '0:9:c4:1:8:a']
    SunOSNetwork().parse_ether_line(words, iface, {})
    assert iface['macaddress'] == '00:09:c4:01:08:0a'

# Generated at 2022-06-20 18:27:08.847502
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    words = ['net0:', 'flags=2001000843', 'mtu', '1500', 'index', '2']
    expected_iface_facts = {'device': 'net0',
                            'ipv4': [{'flags': '2001000843',
                                      'mtu': '1500'}],
                            'ipv6': [],
                            'type': 'unknown',
                            'macaddress': 'unknown'}
    SunOSNetwork(None).parse_interface_line(words, current_if, interfaces)
    assert interfaces['net0'] == expected_iface_facts


# Generated at 2022-06-20 18:27:16.443141
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Prepare the test data for the first test
    words_test1 = ['ether', '2:8:20:d:2:1d']
    current_if_test1 = {}
    ips_test1 = {}

    # Run the method to test
    SunOSNetwork.parse_ether_line(words_test1, current_if_test1, ips_test1)

    # Verify the results
    assert current_if_test1['macaddress'] == '02:08:20:0d:02:1d'

    # Prepare the test data for the second test
    words_test2 = ['ether', '02:08:20:0d:02:1d']
    current_if_test2 = {}
    ips_test2 = {}

    # Run the method to test
    SunOSNetwork.parse_ether_

# Generated at 2022-06-20 18:27:21.659332
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('AnsibleModule', (), {})()
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.fail_json = lambda *args, **kwargs: None
    base_class = NetworkCollector
    base_class.get_interfaces_info = lambda *args, **kwargs: (None, None)
    SunOSNetwork.get_interfaces_info(module, '')

# Generated at 2022-06-20 18:27:33.494334
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # test case 1:
    ifconfig_path = 'test/files/sunos/ifconfig.1'
    module = type('AnsibleModule', (object,), dict(params=dict()))


# Generated at 2022-06-20 18:28:20.236611
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network = SunOSNetwork()
    words = ['ether:', '0:1:2:d:e:f']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    network.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:28:24.659975
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    '''
    test for constructor
    '''
    facts = SunOSNetworkCollector(None, None, None).get_facts()
    assert facts['network_gather_subset'] == ['default'], 'get_facts should return True'

# Generated at 2022-06-20 18:28:38.226662
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    ifc_pgm, rc, out, err = module.run_command(['./test_SunOSNetwork_data/ifconfig'])
    ifc_info, ips = SunOSNetwork(module).get_interfaces_info(ifc_pgm)

    # ifconfig -a returns network interfaces twice, once for ipv4 and again for ipv6.
    # We are only testing parsing of ipv4 facts here.
    assert ifc_info['bge0']['type'] == 'ether'
    assert ifc_info['bge0']['ipv4'][0] == {'flags': 'UP BROADCAST RUNNING MULTICAST', 'mtu': '1500'}

    assert ifc_info['lo0']['type'] == 'loopback'

# Generated at 2022-06-20 18:28:46.032238
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_if = {}
    test_ips = {}
    words = ['ether', '0:14:4f:4b:aa:f3']
    SunOSNetwork.parse_ether_line(None, words, test_if, test_ips)
    assert test_if['macaddress'] == '00:14:4f:4b:aa:f3'

# Generated at 2022-06-20 18:28:49.169398
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector('ansible.module_utils.facts.network.sunos.SunOSNetworkCollector')

# Generated at 2022-06-20 18:28:58.268892
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModuleMock()
    network_collector = SunOSNetworkCollector(module=module)
    fact_class = network_collector._fact_class(module=module)

    # ipv4 interface
    words = ['e1000g0:', 'flags=201000843', 'mtu', '1500']
    expected = {
        'device': 'e1000g0',
        'ipv4': [{'flags': '201000843', 'mtu': '1500'}],
        'ipv6': [],
        'macaddress': 'unknown',
        'type': 'unknown'
    }
    current_if = fact_class.parse_interface_line(words, {}, {})
    assert current_if == expected

    # ipv6 interface

# Generated at 2022-06-20 18:29:01.217730
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetwork(module)
    assert network_collector.platform == 'SunOS'
    assert network_collector.module == module


# Generated at 2022-06-20 18:29:10.849292
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    add_line = 'add net0: flags=2001000849 mtu 1500 '
    plumb_line = 'plumb lo0: flags=1000849 mtu 8232 index 2'
    options_line = 'options=3<RXCSUM,TXCSUM>'
    nd6_line = 'nd6 options=1<PERFORMNUD>'
    addr_line = '  ether 00:03:ba:26:01:4b'
    media_line = 'media: Ethernet autoselect (none)'
    status_line = 'status: active'
    inet_line = '  inet 127.0.0.1 netmask ffffff00 broadcast 127.255.255.255'

# Generated at 2022-06-20 18:29:16.375748
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class.platform == 'SunOS'
    assert obj._fact_class.get_interfaces_info.__doc__ == 'Generic BSD ifconfig'


# Generated at 2022-06-20 18:29:17.187002
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()