

# Generated at 2022-06-20 18:20:12.294111
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.__class__.__name__ == 'SunOSNetworkCollector'

# Generated at 2022-06-20 18:20:25.883459
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    hostname = 'testhost'
    provider = {"username": "test_username", "password": "test_password"}

    ifconfig_path = '/sbin/ifconfig'
    ifconfig_file = 'network/SunOS/get_interfaces_info'

# Generated at 2022-06-20 18:20:39.473325
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    GenericBsdIfconfigNetwork._platform = 'SunOS'

    # Create a dummy class for testing.
    class SunOSNetwork:
        @staticmethod
        def parse_interface_line(words, current_if, interfaces):
            device = words[0][0:-1]
            if device not in interfaces:
                current_if = {'device': device, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
            else:
                current_if = interfaces[device]
            flags = SunOSNetwork.get_options(words[1])
            v = 'ipv4'
            if 'IPv6' in flags:
                v = 'ipv6'

# Generated at 2022-06-20 18:20:45.275552
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    f = SunOSNetwork()
    current_if = {}
    ips = {}
    f.parse_ether_line(['ether', '0:1:2:d:e:f'], current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:20:48.659170
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector(None, None, None)
    assert isinstance(obj, SunOSNetworkCollector)


# Generated at 2022-06-20 18:20:57.806310
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """Test function parse_interface_line of class SunOSNetwork."""
    class Module():
        def __init__(self):
            self.run_command = lambda x: (0, '', '')
    module = Module()
    net = SunOSNetwork(module)

    # test 1
    iface = 'bond0: flags=201000843 mtu 9000 index 6'
    words = iface.split()
    interfaces = {}
    current_if = {}
    current_if = net.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'bond0'
    assert current_if['ipv6'] == []
    assert current_if['ipv4'] == [{'flags': ['201000843'], 'mtu': '9000'}]

    #

# Generated at 2022-06-20 18:21:10.055539
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = None
    current_if = {'macaddress': 'unknown'}
    ips = {}

    sunos = SunOSNetwork(module=module)
    words = ['ether', '0:1:2:3:4:5']
    result = sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'

    current_if = {'macaddress': 'unknown'}
    words = ['ether', '0:1:2:d:e:f']
    result = sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'


# Generated at 2022-06-20 18:21:12.716673
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork({})
    assert net.platform == 'SunOS'


# Generated at 2022-06-20 18:21:21.795301
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = {}
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    m = SunOSNetwork(module)

    words = ['bge0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = {'device': 'bge0'}
    interfaces = {}

    current_if = m.parse_interface_line(words, current_if, interfaces)

    assert len(current_if['ipv4']) == 1
    assert len(current_if['ipv6']) == 0
    assert current_if['type'] == 'unknown'
    assert current_if['macaddress'] == 'unknown'

    # Test an interface with purely IPv6 flags

# Generated at 2022-06-20 18:21:32.271685
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeAnsibleModule()

# Generated at 2022-06-20 18:21:37.724214
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-20 18:21:51.708337
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = type('Type', (object, ), {})()
    module.run_command = lambda *args, **kwargs: (args, kwargs)
    module.run_command.__module__ = 'module'

    sunos_network_fact_class = SunOSNetwork(module)
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    sunos_network_fact_class.parse_ether_line(
        [
            'ether',
            '0:1:2:3:4:5'
        ],
        current_if,
        ips
    )

    assert current_if['macaddress'] == '00:01:02:03:04:05'

    sunos_network_fact_

# Generated at 2022-06-20 18:22:02.042584
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Create a test object with dummy module
    test_obj = SunOSNetwork(None)
    # Initialize an interface
    current_if = {'device': 'test_device', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    # Test a line with MAC address
    words = ['ether', '0:0:0:d:e:f']
    test_obj.parse_ether_line(words, current_if, None)
    # Check if MAC address is ok
    if current_if['macaddress'] != '00:00:00:0D:0E:0F':
        raise AssertionError("SunOSNetwork parse_ether_line test failed")


# Generated at 2022-06-20 18:22:13.159094
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # should work normally
    test_words = ['ether', '0:1:2:3:4:5']
    test_current_if = {}
    test_ips = {}
    test_SunOSNetwork = SunOSNetwork()
    test_SunOSNetwork.parse_ether_line(test_words, test_current_if, test_ips)
    assert 'macaddress' in test_current_if
    assert test_current_if['macaddress'] == '00:01:02:03:04:05'

    # should add padding
    test_words = ['ether', '0:1:2:d:e:f']
    test_current_if = {}
    test_ips = {}
    test_SunOSNetwork = SunOSNetwork()

# Generated at 2022-06-20 18:22:23.950584
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Input data:
    # $ ifconfig -a
    # lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
    #     inet 127.0.0.1 netmask ff000000
    ifconfig_path = '/sbin/ifconfig'
    line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    words = line.split()
    current_if = {}
    interfaces = {}
    # Expected result:
    # interfaces['lo0']['ipv4'][0]['flags'] = '2001000849<UP,LOOPBACK,RUNNING,MULTICAST

# Generated at 2022-06-20 18:22:36.756411
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # All of these variables are common to all Network classes
    module_processor = 'fake_module_processor'
    module_name = 'fake_module_name'
    module_args = 'fake_module_args'
    module_internal_info = 'fake_module_internal_info'
    add_local_facts = 'fake_add_local_facts'

    # Create class instance and test it
    sunos_network = SunOSNetwork(module_processor, module_name, module_args,
                                 module_internal_info, add_local_facts)
    assert sunos_network.module_processor == module_processor
    assert sunos_network.module_name == module_name
    assert sunos_network.module_args == module_args
    assert sunos_network.module_internal_info == module_internal_info

# Generated at 2022-06-20 18:22:40.879995
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetwork(module=module)
    assert isinstance(collector, NetworkCollector)
    assert isinstance(collector, SunOSNetwork)



# Generated at 2022-06-20 18:22:51.036231
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    # Test data
    input_data = [
        ['e1000g0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500', 'index', '8'],
        ['e1000g0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500', 'index', '8'],
        ['e1000g0:', 'flags=20040<IPv6>', 'mtu', '1500', 'index', '8'],
        ['e1000g0:', 'flags=20040<IPv6>', 'mtu', '1500', 'index', '8'],
    ]


# Generated at 2022-06-20 18:22:51.804127
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-20 18:23:01.565668
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    '''
    Test for method parse_interface_line of class SunOSNetwork.
    '''
    # This test will fail if/when Solaris changes the format of the 'ifconfig -a' output
    # It is commented out because it is not suitable for automated testing.

# Generated at 2022-06-20 18:23:15.135415
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    words = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'.split()
    current_if = SunOSNetwork(dict(module=None)).parse_interface_line(words, current_if, interfaces)
    assert current_if == {'device': 'lo0', 'type': 'loopback', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL'], 'mtu': '8232'}], 'ipv6': [], 'macaddress': 'unknown'}


# Generated at 2022-06-20 18:23:19.291525
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    platform_facts = {'network': {}, 'device_links': {}}
    result = SunOSNetworkCollector.collect(platform_facts, None)
    assert result is None, "Failed to instantiate SunOSNetworkCollector instance with valid parameters."

# Generated at 2022-06-20 18:23:29.058279
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    SunOSNetwork(None).parse_ether_line(['ether', '0:1:2:d:e:f'], iface, ips)

    expected = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown',
                'macaddress': '00:01:02:0d:0e:0f'}
    assert iface == expected

# Generated at 2022-06-20 18:23:33.929314
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    If this unit test fails please check the __init__ of SunOSNetworkCollector class.
    If SunOSNetworkCollector has been changed please update the unit test
    accordingly.
    """
    obj = SunOSNetworkCollector()
    assert('ansible.module_utils.facts.network.sunos.SunOSNetwork' ==
           obj.fact_class)
    assert('SunOS' == obj.platform)

# Generated at 2022-06-20 18:23:37.763343
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'


# Generated at 2022-06-20 18:23:44.864115
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = type('AnsibleModule', (object,), {'params': {}, 'run_command': get_command_output})
    module.fail_json = fail_json
    module.exit_json = exit_json
    fixture = SunOSNetwork(module)
    fixture.populate()
    assert fixture.interfaces['lo0']['type'] == 'loopback'
    assert fixture.interfaces['lo0']['flags'] == ['UP', 'LOOPBACK', 'RUNNING']


# Generated at 2022-06-20 18:23:57.560744
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # This will fail the unit test if run with Python < 2.7.6 or Python > 3.2.6.
    # This is required to simulate the 'run_command' return in the parse_interface_line method.
    # The return value of run_command is a tuple.  It must be converted to a list.
    # If this fails to simulate the run_command return value,
    # then facter will not run correctly under Python 2.7.6 or Python 3.2.6.
    from ansible.module_utils.facts.network.sunos.SunOSNetwork import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import IfconfigNetwork
    from collections import namedtuple

# Generated at 2022-06-20 18:24:07.795986
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    import pytest

    fake_module = type('FakeModule', (object, ), {'run_command': lambda *args, **kwargs: (0, '', '')})
    sunos_network = SunOSNetwork(fake_module)

    test_line = 'ether 0:1:2:d:e:f'
    words = test_line.split()
    current_if = {}
    ips = {}

    sunos_network.parse_ether_line(words, current_if, ips)

    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:24:18.656613
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    current_if = {}
    interfaces = {}
    word = 'lo0:'
    words = [word]

    # lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1
    word = 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>'
    words.append(word)
    word = 'mtu'
    words.append(word)
    word = '8232'
    words.append(word)

    # result of parse_interface_line()
    current_if = SunOSNetwork().parse_interface_line(words, current_if, interfaces)
    # result of get_interfaces_info()

# Generated at 2022-06-20 18:24:30.680299
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # SunOS:
    ifconfig_path = 'ansible/module_utils/facts/network/ifconfig/SunOS/ifconfig'
    module = type('', (), {'run_command': mock_run_command})()
    n = SunOSNetwork(module)
    n.get_interfaces_info(ifconfig_path)
    # All interfaces should run through parse_interface_line() and each interface should
    # be visited twice, once for ipv4 and once for ipv6.
    assert len(n.result) == 14
    assert len(n.result['e1000g2']['ipv4']) == 1
    assert len(n.result['e1000g2']['ipv6']) == 1
    assert len(n.result['e1000g3']['ipv4']) == 1
   

# Generated at 2022-06-20 18:24:44.341186
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    '''
    Unit test for method parse_interface_line of class SunOSNetwork
    '''
    test_class = SunOSNetwork()
    test_interfaces = {}
    test_current_if = {}
    test_ips = dict(all_ipv4_addresses = [], all_ipv6_addresses = [])
    test_words = ['e1000g0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu=1500', 'index=0']
    test_current_if = test_class.parse_interface_line(test_words, test_current_if, test_interfaces)
    assert test_current_if['device'] == 'e1000g0'

# Generated at 2022-06-20 18:24:47.478838
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = dict()
    fact_collector = SunOSNetworkCollector(None, facts, None)
    assert fact_collector
    assert fact_collector.platform == "SunOS"



# Generated at 2022-06-20 18:24:54.122643
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    instance = SunOSNetwork({'ansible_facts': {}})
    assert isinstance(instance.get_interfaces_info('/sbin/ifconfig'), tuple)
    assert isinstance(instance.get_interfaces_def(), list)
    assert isinstance(instance.get_interfaces_ip(), dict)
    assert isinstance(instance.get_interfaces_ipv4(), list)
    assert isinstance(instance.get_interfaces_ipv6(), list)

# Generated at 2022-06-20 18:25:04.560576
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    testobj = SunOSNetwork()

# Generated at 2022-06-20 18:25:06.516420
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sos = SunOSNetwork()
    assert sos._fact_class == SunOSNetwork
    assert sos._platform == 'SunOS'
    assert sos._command == 'ifconfig -a'

# Generated at 2022-06-20 18:25:13.796682
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = type('AnsibleModule', (), {
        'run_command': lambda command: ('', 'ether 8:0:27:f8:5e:24', '')
    })
    sunos_network = SunOSNetwork(module)
    current_if = {}
    ips = {}
    sunos_network.parse_ether_line(['ether', '8:0:27:f8:5e:24'], current_if, ips)
    assert current_if['macaddress'] == '08:00:27:f8:5e:24'



# Generated at 2022-06-20 18:25:23.615479
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:25:27.904452
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Create an instance of NetworkCollector.
    This is just to test the constructor.
    """
    collector = SunOSNetworkCollector()
    assert collector.__doc__ == SunOSNetworkCollector.__doc__
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'

# Generated at 2022-06-20 18:25:32.419746
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    '''
    Unit test for constructor of class SunOSNetwork

    '''

    # Create an object of class SunOSNetwork
    sunos_network = SunOSNetwork()

    # Check if object is instance of class SunOSNetwork
    assert isinstance(sunos_network, SunOSNetwork)



# Generated at 2022-06-20 18:25:45.612014
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Create MockedModule
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    import ansible.module_utils.facts.network.generic_bsd as generic_bsd
    import ansible.module_utils.facts.network.generic_bsd_ifconfig as generic_bsd_ifconfig
    MODULE_ARGS = {}

# Generated at 2022-06-20 18:25:58.365547
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.ansible_facts == {}
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork

# Generated at 2022-06-20 18:26:06.308642
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    iface_output = 'lo0:4       flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1   \nlo0:5       flags=1000841<UP,LOOPBACK,RUNNING,MULTICAST,IPv6> mtu 8252 index 1'
    network = SunOSNetwork()

# Generated at 2022-06-20 18:26:12.299411
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    result = {}
    words = ['ether', '0:1:2:d:e:f']
    SunOSNetwork.parse_ether_line(None, words, result, None)
    assert result == {'macaddress': '00:01:02:0d:0e:0f'}

# Generated at 2022-06-20 18:26:21.276223
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    coll = SunOSNetwork()
    result = {}
    iface = "lo0:0    flags=2001000849<UP,LOOPBACK,RUNNING>"
    words = iface.split()
    result = coll.parse_interface_line(words, result, {})
    result = result['lo0:0']
    assert result == {'device': 'lo0:0', 'ipv4': [{'flags': '2001000849<UP,LOOPBACK,RUNNING>', 'mtu': '1500'}],
                             'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}

# Generated at 2022-06-20 18:26:24.525357
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork
    sunos_instance = SunOSNetwork()
    assert sunos_instance.platform == 'SunOS'


# Generated at 2022-06-20 18:26:31.850406
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """Unit test for method parse_ether_line of class SunOSNetwork

    Assert that the method returns a macaddress with leading zero added to each
    octet where needed.
    """
    input_dict = {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8232'}], 'ipv6': [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'IPv6'], 'mtu': '8252'}, {'flags': ['UP', 'LOOPBACK', 'RUNNING', 'IPv6'], 'mtu': '8252'}], 'type': 'unknown', 'macaddress': 'unknown'}
    words = ["ether", "0:1:2:d:e:f"]
    current

# Generated at 2022-06-20 18:26:40.218563
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from collections import defaultdict
    sunosnet = SunOSNetwork(None)
    interfaces = defaultdict(dict)
    current_if = {}
    interfaces['lo0']['ipv4'] = [{'mtu': '1500', 'flags': ['UP', 'LOOPBACK,', 'RUNNING']}]
    interfaces['lo0']['ipv6'] = [{'mtu': '8252', 'flags': ['UP', 'LOOPBACK,', 'RUNNING']}]
    (current_if, interfaces) = sunosnet.parse_interface_line(['lo1'], current_if, interfaces)

# Generated at 2022-06-20 18:26:42.006141
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    network = SunOSNetwork(module)
    assert network.platform == 'SunOS'

# Generated at 2022-06-20 18:26:50.819636
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    facts = SunOSNetwork({'failed': False, 'changed': False, 'ansible_facts': {}})
    words = ['qfe3:', 'flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS>', 'mtu=1500']
    current_if = {}
    interfaces = {}
    result = {
        'device': 'qfe3',
        'ipv4': [{
            'flags': 'UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS',
            'mtu': '1500',
        }],
        'ipv6': [],
        'type': 'unknown',
        'macaddress': 'unknown',
    }
    result = facts.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-20 18:26:59.939461
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = SunOSNetwork()
    current_if = {}
    iface.parse_ether_line(['ether', '0:1:2:d:e:f'], current_if, {})
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'
    iface.parse_ether_line(['ether', '01:02:03:d:e:f'], current_if, {})
    assert current_if['macaddress'] == '01:02:03:0d:0e:0f'

# Generated at 2022-06-20 18:27:28.445840
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    iface_path = 'test_SunOSNetwork.ifconfig'
    my_obj = SunOSNetwork()

    # Create the input data.

# Generated at 2022-06-20 18:27:34.573949
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # Load the sunos.fact fixture which is a sample output of
    # ifconfig -a command on solaris

    module = AnsibleModule(argument_spec=dict())
    module.params = {}

    obj = SunOSNetwork(module)

    if obj.platform != 'SunOS':
        raise Exception("Platform is not set to SunOS")
    if obj.distribution is not None:
        raise Exception("Distribution should be none")



# Generated at 2022-06-20 18:27:38.751186
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class.platform == 'SunOS'


# Generated at 2022-06-20 18:27:44.400725
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork()
    facts = {}
    words = ['ether', '0:1:2:3:4:5']
    m.parse_ether_line(words, facts, {})
    assert facts['macaddress'] == '00:01:02:03:04:05'

# Generated at 2022-06-20 18:27:57.272933
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    Module = type('Module', (object,), {'params': {'gather_subset': ['all', 'network']}})
    module = Module()
    module.run_command = lambda x, check_rc=False: (0, "", "")
    s = SunOSNetwork(module)

    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232', 'index']
    current_if = s.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-20 18:28:09.002314
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockAnsibleModule()
    iface = SunOSNetwork(module)
    interfaces, ips = iface.get_interfaces_info(ifconfig_path='/sbin/ifconfig')

    # test loopback interface
    assert 'lo0' in interfaces
    assert len(interfaces['lo0']['ipv4']) == 1
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert len(interfaces['lo0']['ipv6']) == 1
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'

# Generated at 2022-06-20 18:28:22.029993
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    facts = SunOSNetworkCollector(module).collect()
    interfaces = facts['interfaces']
    assert 'lo0' in interfaces
    assert 'en0' in interfaces
    assert 'en1' in interfaces
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces['en0']['ipv6'][0]['address'] == 'fe80::21e:cff:fefc:a04e%en0'



# Generated at 2022-06-20 18:28:28.621275
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    import ansible.module_utils.facts.network.sunos
    m = ansible.module_utils.facts.network.sunos.SunOSNetwork()
    # Test a line from 'ifconfig -a' output
    l = ["lo0:", "flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>", "mtu", "8232"]
    d = {'device': 'lo0', 'ipv4': [{}, {}], 'ipv6': [], 'type': 'unknown'}
    d = m.parse_interface_line(l, d, {})
    assert d['device'] == 'lo0'

# Generated at 2022-06-20 18:28:33.973235
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert hasattr(SunOSNetworkCollector(), '_fact_class'), "Class SunOSNetworkCollector does not have '_fact_class' attribute"
    assert hasattr(SunOSNetworkCollector(), '_platform'), "Class SunOSNetworkCollector does not have '_platform' attribute"
    assert SunOSNetworkCollector()._platform == "SunOS", "Class SunOSNetworkCollector '_platform' attribute should be set to 'SunOS'"

# Generated at 2022-06-20 18:28:47.609159
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    iface = {'device': "bge0",
             'ipv4': [{'flags': ['BROADCAST', 'MULTICAST'],
                       'mtu': '1500'}],
             'ipv6': [{'flags': ['BROADCAST', 'MULTICAST', 'IPv6'],
                       'mtu': '1500'}],
             'type': 'unknown'}
    fact_class = SunOSNetwork()
    v4 = iface.copy()
    v4.pop('ipv6')
    v6 = iface.copy()
    v6.pop('ipv4')

# Generated at 2022-06-20 18:29:32.041896
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    MODULE_UTILS_PATH = 'library/module_utils/network/'
    iface_file = 'solaris/ifconfig/ifconfig_a.txt'

# Generated at 2022-06-20 18:29:35.746871
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    ifc = SunOSNetworkCollector()

    facts = ifc.get_facts()
    assert 'SunOS' == facts['ansible_net_platform']

# Generated at 2022-06-20 18:29:40.305184
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ifc = SunOSNetwork()
    ifc.parse_ether_line(['ether', '0:1:2:d:e:f'], {}, {})
    assert ifc.interfaces['eth0']['macaddress'] == '00:01:02:0d:0e:0f'
    assert ifc.interfaces['eth1']['macaddress'] == '01:12:23:34:45:56'

# Generated at 2022-06-20 18:29:44.591236
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    mod1 = NetworkCollector.get_network_collector('SunOS')
    mod2 = SunOSNetworkCollector()

    assert mod1 == mod2


# Generated at 2022-06-20 18:29:51.178471
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Test data
    test_data_1 = '''lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        ether 8:0:20:7d:a1:75
        options=80003<RXCSUM,TXCSUM>
        lo0: flags=2002000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8252 index 1
        inet6 ::1/128
        ether 8:0:20:7d:a1:75
        options=20000003<RXCSUM,TXCSUM> '''

# Generated at 2022-06-20 18:29:58.360969
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # This test fails because __init__() allocates a new module object.
    # Module object is initialized with 'SunOS' platform.
    # Removing the call to __init__ does not break the test.
    # Maybe it is a flaw of the test supprt where platform has already been set
    # to a different value to test 'Generic' module.
    # assert False, "Debug"
    assert SunOSNetworkCollector()._platform == 'SunOS'



# Generated at 2022-06-20 18:30:04.425329
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    sunos_network = SunOSNetwork(module)
    print("input:")