

# Generated at 2022-06-20 18:20:18.745051
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork(module=None)
    assert net.facts['all_ipv4_addresses'] == [], 'Failed SunOSNetwork class test: all_ipv4_addresses'
    assert net.facts['all_ipv6_addresses'] == [], 'Failed SunOSNetwork class test: all_ipv6_addresses'
    assert net.facts['default_ipv4']['address'] == '', 'Failed SunOSNetwork class test: default_ipv4.address'
    assert net.facts['default_ipv4']['gateway'] == '', 'Failed SunOSNetwork class test: default_ipv4.gateway'
    assert net.facts['default_ipv4']['interface'] == '', 'Failed SunOSNetwork class test: default_ipv4.gateway'

# Generated at 2022-06-20 18:20:28.146636
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:20:37.678774
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Unit test of method get_interfaces_info of class SunOSNetwork """

# Generated at 2022-06-20 18:20:38.722367
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()


# Generated at 2022-06-20 18:20:49.402778
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    sn = SunOSNetwork(module=None)
    sn.parse_ether_line(['ether', '0:1:2:d:e:f'], {'ipv4': []}, {})
    sn.parse_ether_line(['ether', '0:10:20:30:40:50'], {'ipv4': []}, {})
    sn.parse_ether_line(['ether', '01:10:20:30:40:50'], {'ipv4': []}, {})
    assert sn.interfaces == sn.get_interfaces_info(GenericBsdIfconfigNetwork.ifconfig_path)[0]



# Generated at 2022-06-20 18:21:02.175697
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = FakeAnsibleModule()
    network = SunOSNetwork(module=module)
    assert network.parse_ether_line(words=["ether", "0:1:2:3:4:5"], current_if={'device': 'foo'}, ips={})['macaddress'] == "00:01:02:03:04:05"
    assert network.parse_ether_line(words=["ether", "0:1:2:d:e:f"], current_if={'device': 'foo'}, ips={})['macaddress'] == "00:01:02:0d:0e:0f"

# Generated at 2022-06-20 18:21:05.552368
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork

# Generated at 2022-06-20 18:21:11.880712
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork({})
    m.parse_ether_line(['ether', '0:d:e:f:1:2'], {}, {})
    assert (m.interfaces['device']['macaddress'] == '00:0d:0e:0f:01:02')

# Generated at 2022-06-20 18:21:24.816857
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    ifconfig_path = '/sbin/ifconfig'
    module = type('AnsibleModule', (object,), dict(
        params={},
        run_command=lambda *args, **kwargs: (0, "", ""),
        exit_json=lambda *args, **kwargs: None,
        fail_json=lambda *args, **kwargs: None,
        check_mode=False,
    ))()
    nc = SunOSNetwork(module)
    interfaces, ips = nc.get_interfaces_info(ifconfig_path)
    assert interfaces is not None
    assert ips is not None
    for val in interfaces.values():
        assert 'ipv4' in val
        assert 'ipv6' in val
        assert 'macaddress' in val

# Generated at 2022-06-20 18:21:33.439731
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create test object
    test_object = SunOSNetwork()
    # Set the path to the mock ifconfig executable
    test_object.module.params['gather_subset'] = ['!all', 'network']
    test_object.module.params['gather_network_resources'] = ['interfaces']
    test_object.module.params['gather_timeout'] = 10
    test_object.module.run_command = run_command

    # Call get_interfaces_info() so we get the output from run_command()
    # which we defined above
    interfaces, ips = test_object.get_interfaces_info('/usr/bin/ifconfig')

    # Verify the first interface of the dictionary interfaces
    # This tests parsing of both the interface line and
    # the 'ether' line

# Generated at 2022-06-20 18:21:51.840492
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    test_iface = {'device': 'e1000g0', 'ipv4': [{'flags': ['IPv4', 'BROADCAST', 'MULTICAST', 'RUNNING'], 'mtu': '1500'}], 'ipv6': [{'flags': ['IPv6', 'RUNNING', 'MULTICAST'], 'mtu': '1500'}], 'type': 'unknown', 'macaddress': 'unknown'}
    test_ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    test_words = ['ether', '00:01:02:0d:0e:0f']

# Generated at 2022-06-20 18:22:02.848925
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_interface = 'lo0:3'
    test_flags = 'LOOPBACK,RUNNING,MULTICAST,IPv6'
    test_mtu = '1500'
    test_words = [test_interface, test_flags, test_mtu]
    test_current_if = {'device': test_interface[0:-2], 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    test_interfaces = {}
    test_interfaces[test_interface[0:-2]] = test_current_if
    test_SunOSNet = SunOSNetwork(dict())
    test_result = test_SunOSNet.parse_interface_line(test_words, test_current_if, test_interfaces)

# Generated at 2022-06-20 18:22:04.257336
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos = SunOSNetwork({'ansible_facter': ''})
    assert sunos.platform == 'SunOS'


# Generated at 2022-06-20 18:22:14.013676
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # mock module
    module = MockANSIBLEModule()

    # mock facts module
    module.facts['ansible_net_gather_network_resources'] = 1

    # mock commands
    module.run_command.return_value = (0, OUTPUT, '')

    # test get_interfaces_info
    network = SunOSNetwork(module)
    network.get_default_interface = Mock(return_value='e1000g0')
    network.get_default_interface_ip = Mock(return_value='192.168.1.1')
    network.get_interfaces_info('ifconfig')

# Generated at 2022-06-20 18:22:18.050481
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    iface = SunOSNetwork()
    interfaces = {}
    current_if = {}

    # default
    words = ['e1000g1:', 'flags=280048<IPv6,BROADCAST,MULTICAST,DHCP,RUNNING>', 'mtu=1500']
    current_if = iface.parse_interface_line(words, current_if, interfaces)
    expected = {'device': 'e1000g1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    assert interfaces == {}
    assert current_if == expected

    # ipv4 interface
    words = ['e1000g0:', 'flags=280048<IPv6,BROADCAST,MULTICAST,DHCP,RUNNING>', 'mtu=1500']

# Generated at 2022-06-20 18:22:19.685597
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_network_example = SunOSNetwork({})


# Generated at 2022-06-20 18:22:33.950547
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test = SunOSNetwork()
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = ['ether', '0:1:2:d:e:f']
    ips = {}
    test.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = ['ether', '1:2:3:a:b:c']
    test.parse_ether_line(words, current_if, ips)

# Generated at 2022-06-20 18:22:37.175526
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.get_interface_details()

# Generated at 2022-06-20 18:22:40.025357
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Unit test for constructor of class SunOSNetwork"""
    module = SunOSNetworkCollector.get_instance()

    assert module is not None

# Generated at 2022-06-20 18:22:42.016736
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts_instance = SunOSNetworkCollector()
    assert facts_instance.__class__.__name__ == 'SunOSNetworkCollector'


# Generated at 2022-06-20 18:22:57.872243
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    modules = dict()
    set_module_args = dict()

    # output from 'ifconfig -a' on Solaris 11.2
    # with IPv4 and IPv6 addresses

# Generated at 2022-06-20 18:23:03.636340
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    result = SunOSNetworkCollector(module).get_device_facts()
    assert result is not None
    assert isinstance(result, dict)
    assert isinstance(result['default_ipv4']['gateway'], str)

from ansible.module_utils.basic import *  # noqa: F403
from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector  # noqa: F401

# Generated at 2022-06-20 18:23:13.351377
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeAnsibleModule()

# Generated at 2022-06-20 18:23:26.990186
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test = {'device': 'lo0',
            'macaddress': 'unknown',
            'type': 'loopback',
            'ipv4': [{'flags': ['IPv4', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'mtu': '8232'}],
            'ipv6': [{'flags': ['IPv6', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'mtu': '8202'}]}
    input_device = 'lo0:'
    input_mtu = '8232'
    input_flags = 'UP'
    current_if = {}
    interfaces = {}
    current_if = SunOSNetwork.parse_interface_line([input_device, input_flags, input_mtu], current_if, interfaces)
    input_flags

# Generated at 2022-06-20 18:23:33.744509
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetwork(module=module)
    interfaces = collector.interfaces()
    ips = collector.all_ip_addresses()

    assert type(collector.interfaces()) is dict
    assert type(collector.all_ip_addresses()) is dict

# Generated at 2022-06-20 18:23:43.850704
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Unit test class constructor.
    """
    fixture_path = os.path.join(os.path.dirname(__file__), "fixtures")
    if not os.path.exists(fixture_path):
        os.makedirs(fixture_path)

    module = AnsibleModule(argument_spec=dict())

    # Create an instance of 'SunOSNetworkCollector'
    nc = SunOSNetworkCollector(module=module, resource_facts=dict())
    assert nc is not None



# Generated at 2022-06-20 18:23:51.155147
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos = SunOSNetwork()
    words = ['ether', '0:1:2:3:4:5']
    current_if = {}
    ips = {}
    sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'

# Generated at 2022-06-20 18:23:57.075393
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_SunOSNetwork = SunOSNetwork()
    test_words = ['ether', '0:1:2:d:e:f']
    test_current_if = {}
    test_ips = {}
    test_SunOSNetwork.parse_ether_line(test_words, test_current_if, test_ips)
    assert test_current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:24:04.403839
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork({})
    words = ['ether', '0:1:2:d:e:f']
    current_if = {}
    ips = {}

    m.parse_ether_line(words, current_if, ips)

    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:24:09.870825
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Unit test for constructor of class SunOSNetwork"""
    module = FakeAnsibleModule()
    sunos_network = SunOSNetwork(module)
    assert sunos_network.get_file_path() == '/sbin/ifconfig'
    assert sunos_network.get_interfaces_info.__name__ == 'get_interfaces_info'


# Generated at 2022-06-20 18:24:23.571839
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeModule()

# Generated at 2022-06-20 18:24:29.342498
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    from ansible.module_utils.facts.network.sunos.facts import SunOSNetwork
    network = SunOSNetwork({})
    current_if = {}
    ips = {}

    # parse an ether line with properly formed MAC addresses
    words = ['ether', '0:1:2:3:4:5']
    network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'

    # parse an ether line with malformed MAC addresses
    current_if = {}
    words = ['ether', '0:1:2:3:4:5:6']
    network.parse_ether_line(words, current_if, ips)

# Generated at 2022-06-20 18:24:33.795372
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ifconfig_path = None
    current_if = {}
    ips = dict()

    sunos = SunOSNetwork(None)

    words = ['ether', '0:1:2:d:e:f']
    sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

    words = ['ether', '0:1:2:3:4:5']
    sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'

# Generated at 2022-06-20 18:24:37.556002
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    instance = SunOSNetworkCollector(_platform='SunOS')
    assert isinstance(instance, SunOSNetworkCollector)


# Generated at 2022-06-20 18:24:50.861527
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('', (), {})()
    module.run_command = lambda *args, **kwargs: (0, "lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1\n    options=600003<RXCSUM,TXCSUM,RXCSUM_IPV6,TXCSUM_IPV6>\n    inet 127.0.0.1 netmask ff000000\n    nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>\n    groups: lo\n    inet6 ::1/0\n", None)
    facter = SunOSNetwork(module=module)

# Generated at 2022-06-20 18:24:54.666823
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    sunos_network = SunOSNetwork(module)
    assert sunos_network


# Generated at 2022-06-20 18:25:03.058837
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    os_ifconfig_path='/sbin/ifconfig'

    # Test ifconfig output from Solaris 11.2

# Generated at 2022-06-20 18:25:05.958986
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    network = SunOSNetwork()
    assert network


# Generated at 2022-06-20 18:25:16.640282
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # data to construct the fake 'ifconfig -a' output
    if_files = {
        '/etc/hostname.em0': '',
        '/etc/hostname.em1': '',
        '/etc/hostname.em2': '',
        '/etc/hostname.nxge0': '',
        '/etc/hostname.lo0': '',
    }

# Generated at 2022-06-20 18:25:20.039752
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    s = SunOSNetwork()
    assert (s.platform == 'SunOS')

if __name__ == '__main__':
    test_SunOSNetwork()

# Generated at 2022-06-20 18:25:33.898094
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = None

    result = SunOSNetworkCollector.collect(module)
    assert 'ansible_facts' in result
    assert 'ansible_net_interfaces' in result['ansible_facts']
    assert 'ansible_net_all_ipv4_addresses' in result['ansible_facts']
    assert 'ansible_net_all_ipv6_addresses' in result['ansible_facts']
    assert 'ansible_net_gather_network_resources' in result['ansible_facts']
    assert 'ansible_net_devices' in result['ansible_facts']['ansible_net_gather_network_resources']
    assert 'ansible_net_neighbors' in result['ansible_facts']['ansible_net_gather_network_resources']

# Generated at 2022-06-20 18:25:41.580154
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    fact_class = SunOSNetwork()
    words = ['ether', '0:1:2:d:e:f']
    current_if = {}
    ips = {}
    result = fact_class.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:25:55.212385
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    ip = SunOSNetwork(module)
    interfaces = {}
    current_if = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL>', 'mtu', '8232', 'index', '12']
    current_if = ip.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-20 18:26:05.903177
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ifconfig_path = '/sbin/ifconfig'
    macaddress = ''
    current_if = {'device': 'bge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = ['ether', 'a:b:c:d:e:f']
    SunOSNetwork.parse_ether_line(ifconfig_path, words, current_if, macaddress)
    assert current_if['macaddress'] == 'a:b:c:d:e:f'
    words = ['ether', '0:1:2:d:e:f']
    SunOSNetwork.parse_ether_line(ifconfig_path, words, current_if, macaddress)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:26:16.542067
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    obj = SunOSNetwork({})

    current_if = {'macaddress': 'unknown', 'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = ['ether', '0:1:2:d:e:f', '(oui)']
    obj.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

    current_if = {'macaddress': 'unknown', 'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = ['ether', 'b:c:d:e:f:0', '(oui)']

# Generated at 2022-06-20 18:26:21.154135
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork
    assert collector.fact_subclass == GenericBsdIfconfigNetwork

# Unit tests for 'get_interfaces_info()'

# Generated at 2022-06-20 18:26:24.525439
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Create network collector object
    obj = SunOSNetworkCollector()
    assert isinstance(obj, NetworkCollector)



# Generated at 2022-06-20 18:26:30.428323
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    line = 'ether 0:1:2:d:e:f        '
    words = line.split()
    facts = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}
    ips = dict(
        ipv4_address='',
        ipv6_address='',
    )
    iface = SunOSNetwork.parse_ether_line(words, facts, ips)
    assert iface['macaddress'] == '00:01:02:0d:0e:0f'


# Generated at 2022-06-20 18:26:32.959709
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector.get_facts() == {}

# Generated at 2022-06-20 18:26:35.857836
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    '''
    Constructor of class SunOSNetworkCollector
    '''
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._platform == 'SunOS'


# Generated at 2022-06-20 18:26:41.719049
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = None
    if module:
        net = SunOSNetwork(module)
        print(net.get_interfaces_info())


# Generated at 2022-06-20 18:26:50.666769
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    'ifconfig -a' from Solaris 11.4
    """

# Generated at 2022-06-20 18:27:02.603955
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    current_if = GenericBsdIfconfigNetwork.GenericBsdIfconfigNetwork()
    current_if['device'] = 'bge0'
    current_if['ipv4'] = []
    current_if['ipv6'] = []
    current_if['type'] = 'unknown'
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}

    current_if = SunOSNetwork.parse_ether_line(current_if, ['ether', '0:1:2:d:e:f'], ips)


# Generated at 2022-06-20 18:27:13.466995
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_SunOSNetwork = SunOSNetwork(dict(module=None))

    # net1 output

# Generated at 2022-06-20 18:27:16.468742
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = SunOSNetwork({})
    assert module.facts['default_ipv4']['address'] == 'unknown'

if __name__ == '__main__':
    test_SunOSNetwork()

# Generated at 2022-06-20 18:27:24.999577
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    net_module = NetworkCollector.plugins['SunOS']()

# Generated at 2022-06-20 18:27:27.011327
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = FakeAnsibleModule()
    obj = SunOSNetwork(module)
    assert obj


# Generated at 2022-06-20 18:27:28.842971
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network = SunOSNetworkCollector()
    assert isinstance(network.get_facts(), dict)

# Generated at 2022-06-20 18:27:38.515156
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = type("AnsibleModule", (object,), dict(params={}))
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = lambda args, **kwargs: (None, "", "")

    network = SunOSNetwork(module)
    interfa = dict()
    interfa['device'] = 'lo0'
    interfa['macaddress'] = '00:0c:29:3a:89:1b'
    interfa['ipv4'] = [{'mtu': '1500', 'prefixlen': '16', 'broadcast': '0.0.0.0', 'netmask': '255.255.255.0', 'address': '192.168.56.105'}]

# Generated at 2022-06-20 18:27:48.577860
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = AnsibleModuleMock()
    sunos = SunOSNetwork(module)
    current_if = dict()
    current_if['macaddress'] = 'unknown'
    ips = dict()
    words = ['ether', '0:1:2:3:4:5']
    sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'
    words = ['ether', '0:1:2:d:e:f']
    sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'
    words = ['ether', '0:01:02:d:e:f']

# Generated at 2022-06-20 18:28:00.220033
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_interfaces = {}
    current_if = {}
    test_words = ['e1000g0:', 'flags=1001000843', 'mtu', '1500', 'index', '2']
    current_if = SunOSNetwork.parse_interface_line(None, test_words, current_if, test_interfaces)
    assert(current_if['device'] == 'e1000g0')
    assert(current_if['type'] == 'unknown')
    assert(current_if['ipv4'][0]['flags'] == {'ipv6', 'broadcast', 'multicast', 'running', 'up'})
    assert(current_if['ipv4'][0]['mtu'] == '1500')
    assert(current_if['ipv6'] == [])

# Generated at 2022-06-20 18:28:13.132597
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():

    def get_current_macaddress(device):
        current_if = {}
        for iface in interfaces:
            current_if = interfaces[iface]
        return current_if['macaddress']

    def parse_ether_line(words, current_if, ips):
        macaddress = ''
        for octet in words[1].split(':'):
            octet = ('0' + octet)[-2:None]
            macaddress += (octet + ':')
        current_if['macaddress'] = macaddress[0:-1]

    def parse_interface_line(words, current_if, interfaces):
        device = words[0][0:-1]

# Generated at 2022-06-20 18:28:19.253715
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos = SunOSNetworkCollector()
    assert sunos.__class__.__name__ == 'SunOSNetwork'
    assert sunos.platform == 'SunOS'
    assert sunos._platform == 'SunOS'
    assert sunos._fact_class.__name__ == 'SunOSNetwork'
    assert sunos._fact_class.platform == 'SunOS'

# Generated at 2022-06-20 18:28:29.710057
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = None
    collector = SunOSNetworkCollector(module, "/sbin/ifconfig")
    network = SunOSNetwork(module)

    # Test LOOPBACK
    words = 'lo0: flags=0x1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1'.split()
    current_if = {}
    interfaces = {}
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'] == [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4'], 'mtu': '8232'}]

# Generated at 2022-06-20 18:28:39.542991
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Mocking module
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    module = ModuleFacts()
    module.params = {'gather_subset': 'all'}
    ifconfig_path = '/sbin/ifconfig'
    netobj = GenericBsdIfconfigNetwork(module)
    current_if = {}
    interfaces = {}
    words = ['lo0:1', 'flags=2001000849', 'mtu', '8232']
    current_if = netobj.parse_interface_line(words, current_if, interfaces)
    assert len(interfaces.keys()) == 1



# Generated at 2022-06-20 18:28:46.334747
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunos_network = SunOSNetwork()
    current_if = {}
    interfaces = {}
    device = 'lo0'
    flags = 'UP LOOPBACK RUNNING MULTICAST'
    mtu = '8232'
    words = [device + ':', flags, 'mtu', mtu]
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == flags
    assert current_if['ipv4'][0]['mtu'] == mtu
    assert 'macaddress' in current_if
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-20 18:29:00.020535
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModuleMock()
    ifconfig_path = '/usr/sbin/ifconfig'

# Generated at 2022-06-20 18:29:10.500224
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-20 18:29:19.184277
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network = SunOSNetwork()
    iface = {}
    ips = {}
    words = ['ether', '0:a:1:b:2:c']
    iface = network.parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == '00:0a:01:0b:02:0c'
    words = ['ether', '0:a:1:b:2']
    iface = network.parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == 'unknown'

# Generated at 2022-06-20 18:29:26.182325
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # We have to have a return value for AnsibleModule.run_command,
    # but all of the actual parsing is tested in the method
    # SunOSNetwork.get_interfaces_info()
    network_module = SunOSNetwork({})
    assert network_module.get_interfaces_info('/sbin/ifconfig') == ({}, {})

# Generated at 2022-06-20 18:29:41.322527
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    # Setup
    test_os = SunOSNetwork()
    interfaces = {}
    current_if = {}

    # Test with words representing line for IPv4
    words = ['lo0:', 'flags=2001000849', 'mtu', '8232', 'index', '1', 'inet', '127.0.0.1', 'netmask', 'ff000000']
    expected_current_if = {'ipv4': [{'flags': '2001000849', 'mtu': '8232'}], 'device': 'lo0', 'ipv6': [], 'type': 'unknown'}
    expected_return_if = {'ipv4': [{'flags': '2001000849', 'mtu': '8232'}], 'device': 'lo0', 'ipv6': [], 'type': 'unknown'}

# Generated at 2022-06-20 18:29:46.836313
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    interface = {}
    SunOSNetwork().parse_ether_line(['ether', '0:1:2:3:4:5'], interface, {})
    assert interface['macaddress'] == '00:01:02:03:04:05'


# Generated at 2022-06-20 18:29:51.793987
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    sunos_obj = SunOSNetwork(module)
    assert sunos_obj.platform == 'SunOS'

# Generated at 2022-06-20 18:30:00.691606
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sunos_ifconfig_output = '''
      lo0: flags=2001000849 mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        options=3<performnud,accept_unicast_rtr>
        inet6 ::1/128
        nd6 options=1<performnud>
        ether 8:0:20:0:6:e
   eri0: flags=1000843 mtu 1500 index 2
        inet 172.16.146.130 netmask ffffff00 broadcast 172.16.146.255
        ether 0:1:2:3:4:5

'''

# Generated at 2022-06-20 18:30:02.047157
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork().platform == 'SunOS'