

# Generated at 2022-06-20 18:20:15.363050
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    words = ['ether', '0:1:2:d:e:f']
    current_if = {}
    ips = {}
    sn = SunOSNetwork()
    current_if = sn.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:20:27.100668
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    test_ifdict = dict(
        ipv4=[
            dict(
                broadcast='172.16.1.255',
                netmask='255.255.255.0',
                address='172.16.1.1',
            )
        ],
    )
    test_ipdict = dict(
        all_ipv4_addresses=['172.16.1.1'],
    )
    test_instance = SunOSNetwork(dict(module=None), test_ifdict, test_ipdict)
    test_result = dict(
        ipv4=dict(
            address="172.16.1.1",
            broadcast="172.16.1.255",
            netmask="255.255.255.0",
        ),
        ipv6=[],
    )

# Generated at 2022-06-20 18:20:33.591078
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = dict()
    SunOSNetworkCollector(facts, dict())
    assert 'ansible_net_interfaces' in facts
    assert 'ansible_net_all_ipv4_addresses' in facts
    assert 'ansible_net_all_ipv6_addresses' in facts
    assert facts['ansible_net_interfaces'] == facts['ansible_interfaces']

# Generated at 2022-06-20 18:20:47.078876
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:20:57.377357
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    "Unit test for method get_interfaces_info of class SunOSNetwork"

    # create the test object
    obj = SunOSNetwork()

    # test data
    ifconfig_path = '\S/usr/sbin/ifconfig'

# Generated at 2022-06-20 18:21:04.487786
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ifconfig_path = 'path/to/ifconfig'
    module = FakeAnsibleModule()
    ifconfig = SunOSNetwork(module, ifconfig_path)
    words = ['ether', '0:1:2:d:e:f']
    current_if = {}
    ips = {}
    ifconfig.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:21:06.900967
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork


# Generated at 2022-06-20 18:21:09.116576
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._fact_class.platform == 'SunOS'

# Generated at 2022-06-20 18:21:20.263258
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    # test 'interface_list' empty
    my_obj = SunOSNetwork({'interface_list': []}, {}, {})
    assert my_obj.interface_list == [], 'test_SunOSNetwork empty interface_list failed!'

    # test 'interface_list' with a value
    my_obj = SunOSNetwork({'interface_list': ['lo0', 'bge0']}, {}, {})
    assert my_obj.interface_list == ['lo0', 'bge0'], 'test_SunOSNetwork set interface_list failed!'

    # test 'exclude_interface_list' empty
    my_obj = SunOSNetwork({'exclude_interface_list': []}, {}, {})
    assert my_obj.exclude_interface_list == [], 'test_SunOSNetwork empty exclude_interface_list failed!'

    #

# Generated at 2022-06-20 18:21:22.758055
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos = SunOSNetwork({'module': None})
    assert isinstance(sunos, SunOSNetwork)

# Generated at 2022-06-20 18:21:38.978450
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork()
    current_if = {'macaddress': 'unknown'}    # will be overwritten later
    sunos_network.parse_ether_line(['ether', '0:1:2:d:e:f'], current_if, {})
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'
    sunos_network.parse_ether_line(['ether', 'a:b:c:d:e:f'], current_if, {})
    assert current_if['macaddress'] == 'a:b:c:d:e:f'

# Generated at 2022-06-20 18:21:48.074192
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    This function will act as a test case for the constructor of class SunOSNetworkCollector
    """
    sunosNetworkCollectorObj = SunOSNetworkCollector()
    print("test_SunOSNetworkCollector: " + str(type(sunosNetworkCollectorObj)))
    assert str(type(sunosNetworkCollectorObj)) == "<class 'ansible.module_utils.facts.network.sunos.SunOSNetworkCollector'>"


# Generated at 2022-06-20 18:21:55.079437
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Implementing test case to verify constructor of class SunOSNetworkCollector """
    net_collector = SunOSNetworkCollector()
    assert isinstance(net_collector, SunOSNetworkCollector)
    assert net_collector._fact_class == SunOSNetwork
    assert net_collector._platform == 'SunOS'

# Generated at 2022-06-20 18:21:59.131766
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Checks the constructor of SunOSNetwork class
    """
    sunos_collector = SunOSNetwork(dict(module=None, params=None))
    assert sunos_collector.platform == 'SunOS'

# Generated at 2022-06-20 18:22:12.400687
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {}
    words = ['ether', '0:1:2:3:4:5']
    ips = {}
    current_if = SunOSNetwork.parse_ether_line(words, iface, ips)
    iface = {'ipv4': [], 'ipv6': [], 'macaddress': current_if['macaddress'], 'device': iface['device']}
    assert iface == current_if
    words = ['ether', '0:1:2:d:e:f']
    ips = {}
    current_if = SunOSNetwork.parse_ether_line(words, iface, ips)
    iface = {'ipv4': [], 'ipv6': [], 'macaddress': current_if['macaddress'], 'device': iface['device']}

# Generated at 2022-06-20 18:22:23.572590
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    import pprint
    module = FakeModule({})
    p = SunOSNetwork(module)
    # 'options=' excluded from flags
    words = [u'net1:', u'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', u'mtu', u'1500']

# Generated at 2022-06-20 18:22:33.519602
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces, ips = process_ifconfig_output(SOLARIS_ifconfig_output)
    assert 'lo0' in interfaces.keys()
    assert 'lo0' in interfaces.keys()
    assert interfaces['lo0']['type'] == 'loopback'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']


# Generated at 2022-06-20 18:22:42.346901
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = MockModule()
    facts = SunOSNetwork(module)

    words = ['ether', '0:4:d:e:f:0']
    current_if = {'device': 'e1000g0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    facts.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:4d:0e:0f:00'



# Generated at 2022-06-20 18:22:55.565570
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    module = dict(run_command=dict())
    command = ["/sbin/ifconfig", "-a"]
    out = """lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
lo0: flags=2000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6> mtu 8252 index 1
        inet6 ::1/128
ether 0:1:2:3:4:5
"""
    module['run_command'] = dict(rc=0, out=out, err='')
    collector = SunOSNetwork(module)

# Generated at 2022-06-20 18:23:08.234775
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {'device': 'hme0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    sunos = SunOSNetwork({})
    # Test 1: single digit octet
    words = ('ether', '0:1:2:d:e:f', 'ipmp')
    sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

    # Test 2: multiple and incomplete octets
    words = ('ether', '0:1:2:d', 'ipmp')
    sunos.parse_ether

# Generated at 2022-06-20 18:23:28.673625
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {'device': 'bge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}

    # Test mac address with single digit octets
    line = 'ether 0:1:2:d:e:f'
    SunOSNetwork().parse_ether_line(line.split(), iface, {})
    assert iface['macaddress'] == '00:01:02:0D:0E:0F'

    # Test mac address with double digit octets
    line = 'ether 0a:0b:0c:0d:0e:0f'
    SunOSNetwork().parse_ether_line(line.split(), iface, {})

# Generated at 2022-06-20 18:23:32.885865
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {}
    ips = {}
    SunOSNetwork.parse_ether_line(['ether', '0:1:2:d:e:f'], current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:23:39.080230
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = MagicMockAnsibleModule()
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    line = 'lo0: flags=2001000849 <UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    words = line.split()
    fact_class = SunOSNetwork(module)
    fact_class.parse_interface_line(words, current_if, {})

# Generated at 2022-06-20 18:23:49.053550
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.base import Network
    network = Network()
    current_if = {}
    interfaces = {}
    words = 'e1000g0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,LARGESEND,CHAIN> mtu 1500 index 3'.split()
    current_if = network.parse_interface_line(words, current_if, interfaces)

    assert current_if['device'] == 'e1000g0'
    assert current_if['ipv4'][0]['flags'] == '1e080863,480'
    assert current_if['ipv4'][0]['mtu'] == '1500'

# Generated at 2022-06-20 18:23:59.668936
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:24:11.361782
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    facts = SunOSNetwork({})
    words = ['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6>', 'mtu', '8232', 'index', '1']
    interface = {}
    interface = facts.parse_interface_line(words, interface, {})
    assert interface['device'] == 'lo0'
    assert interface['type'] == 'loopback'
    assert interface['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv6']
    assert interface['ipv4'][0]['mtu'] == '8232'
    assert interface['macaddress'] == 'unknown'

# Generated at 2022-06-20 18:24:15.117192
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == 'SunOS'
    assert network_collector._fact_class == SunOSNetwork

# Generated at 2022-06-20 18:24:23.725921
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Create object
    obj = SunOSNetwork()

    # Test with correct input
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    (current_if, interfaces) = obj.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-20 18:24:36.365226
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    c = SunOSNetwork()
    out = {'device': 'lo0', 'type': 'loopback', 'macaddress': 'unknown', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8232'}, {'inet': '127.0.0.1', 'netmask': '255.0.0.0', 'broadcast': '127.255.255.255'}], 'ipv6': [{'flags': ['IPv6', 'UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8252'}, {'inet6': '::1'}]}
    words = ['lo0:', 'flags=20049<UP,LOOPBACK,RUNNING>', 'mtu', '8232', 'index', '10']

# Generated at 2022-06-20 18:24:39.475810
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    nm = SunOSNetwork(module)
    assert nm.platform == 'SunOS'
    assert nm.module.get_bin_path('ifconfig') == '/sbin/ifconfig'

# Generated at 2022-06-20 18:24:50.246783
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    pass

# Generated at 2022-06-20 18:24:59.104109
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork()
    current_if = {}
    words = ['ether', '0:1:2:d:e:f', 'media:', 'Ethernet', 'autoselect', '(100baseTX)', 'status:', 'active']
    sunos_network.parse_ether_line(words, current_if)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:25:09.007353
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict()
    )
    collector = SunOSNetworkCollector(module=module)
    facts = collector.collect()
    assert isinstance(facts['ansible_network_resources'], dict)
    assert isinstance(facts['ansible_net_all_ipv4_addresses'], list)
    assert isinstance(facts['ansible_net_all_ipv6_addresses'], list)

# Generated at 2022-06-20 18:25:23.096088
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Construct the test data for method get_interfaces_info
    # Test data was collected on a SPARC computer running Oracle Solaris 11.4
    module = 'ansible_module_foo'
    ifconfig_path = '/usr/sbin/ifconfig'

# Generated at 2022-06-20 18:25:33.332534
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    fact_class = SunOSNetwork()
    current_if = {'device': 'lo0'}
    words = ['ether', '0:1:2:d:e:f']
    fact_class.parse_ether_line(words, current_if, None)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'
    words = ['ether', '00:11:22:dd:ee:ff']
    fact_class.parse_ether_line(words, current_if, None)
    assert current_if['macaddress'] == '00:11:22:dd:ee:ff'

# Generated at 2022-06-20 18:25:45.994755
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-20 18:25:49.632825
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-20 18:25:58.944752
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork()
    current_if = {
        'device': 'bge0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'macaddress': 'unknown'
    }
    ips = {}
    line = 'ether 0:11:22:33:44:55'
    sunos_network.parse_ether_line(line.split(), current_if, ips)
    assert current_if['macaddress'] == '00:11:22:33:44:55'
    assert current_if['type'] == 'unknown'
    line = 'ether 0:0:0:d:e:f'
    sunos_network.parse_ether_line(line.split(), current_if, ips)

# Generated at 2022-06-20 18:26:12.546521
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    obj = SunOSNetwork(module)

    # test case: first interface
    current_if = {}
    interfaces = {}
    current_if = obj.parse_interface_line(['em0:', 'flags=2001000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu=1500'], current_if, interfaces)
    assert current_if['device'] == 'em0'
    assert current_if['type'] == 'unknown'
    assert len(current_if['ipv4']) == 1
    assert current_if['ipv4'][0]['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4']

# Generated at 2022-06-20 18:26:22.266667
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Create an instance of class SunOSNetwork
    sunosnetwork = SunOSNetwork()
    # Create an instance of an interface on which to store the parsed
    # facts about the interface.
    iface = dict(device="lo0", ipv4=[], ipv6=[],
        type="unknown", macaddress="unknown")
    # Create an array of words parsed from a line of the output of
    # 'ifconfig -a'
    words = ["ether", "0:1:2:d:e:f"]
    # Call the method
    sunosnetwork.parse_ether_line(words, iface, dict())
    # Verify the results
    assert iface["macaddress"] == "00:01:02:0d:0e:0f"

# Generated at 2022-06-20 18:26:49.417199
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict()
    )

    net_gen = SunOSNetwork(module=module)
    rc, interfaces, ips = net_gen.get_interfaces_info()
    assert(rc == 0)
    assert('lo0' in interfaces)
    assert('127.0.0.1' in interfaces['lo0']['ipv4'][0]['address'])
    assert('127.0.0.1' in ips['all_ipv4_addresses'])
    assert('fe80::1' in ips['all_ipv6_addresses'])

# Generated at 2022-06-20 18:26:55.388850
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class.platform == 'SunOS'
    assert obj.get_facts() == {}
    assert obj.get_network_facts() == {}


# Generated at 2022-06-20 18:26:58.243627
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-20 18:26:59.413858
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    assert SunOSNetwork(module).platform == 'SunOS'

# Generated at 2022-06-20 18:27:11.013793
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_obj = SunOSNetwork()

    # Test the _parse_ipv4_line method
    testdata = "lo0:1: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1\n"
    expected_result = {'device': 'lo0', 'ipv4': [{'mtu': '8232', 'flags': 'UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL'}], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown', 'is_up': True}
    assert test_obj._parse_ipv4_line(testdata.split()) == expected_result

    # Test the _parse_ipv6_line method
   

# Generated at 2022-06-20 18:27:13.866544
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = None
    iface = SunOSNetwork(module)
    iface.get_interfaces_info('')


# Generated at 2022-06-20 18:27:24.467412
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    only_sys_class = dict(mock_uname=('SunOS 5.11 11.3'))
    not_sys_class = dict(mock_uname=('SunOS'))
    facts = dict(mock_uname=('SunOS mock_kernel 0.1'))
    module = ''

    # Test if sys_class is equal SunOS
    nc_sys_class = SunOSNetworkCollector(module, facts, only_sys_class)
    assert nc_sys_class.platform == 'SunOS'

    # Test if sys_class is not equal SunOS
    nc_not_sys_class = SunOSNetworkCollector(module, facts, not_sys_class)
    assert nc_not_sys_class.platform is None

# Generated at 2022-06-20 18:27:35.172262
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_output = '''
lo0:	flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        inet6 ::1/128
        ipv6 options=200141<ACCEPT_RTADV,PERFORMNUD,NO_PREFER_IFACE>
        groups: lo
net0:	flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2
        inet 10.20.30.40 netmask ffffff00 broadcast 10.20.30.255
        ether 0:1:2:a:b:c'''


# Generated at 2022-06-20 18:27:47.553863
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    SunOSNet = SunOSNetwork({})
    ifconfig_line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'

    current_if = SunOSNet.parse_interface_line(ifconfig_line.split(),
                                               {},
                                               {})
    assert current_if == {
        'device': 'lo0',
        'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL'],
                  'mtu': '8232'}],
        'ipv6': [],
        'type': 'loopback',
        'macaddress': 'unknown'
    }

    ifconfig_

# Generated at 2022-06-20 18:27:51.125660
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert issubclass(SunOSNetworkCollector._fact_class, SunOSNetwork)

# Generated at 2022-06-20 18:28:35.737454
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-20 18:28:43.386730
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_line = "ether 0:1:2:d:e:f"

    iface = {}
    ips = {}

    test_network = SunOSNetwork()
    test_network.parse_ether_line(test_line.split(), iface, ips)

    assert iface['macaddress'] == "00:01:02:0d:0e:0f"

# Generated at 2022-06-20 18:28:53.791376
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    o = SunOSNetwork()
    words = ['rge0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = {}
    interfaces = {}
    current_if = o.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'rge0'
    assert current_if['ipv4'][0] == {'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4'], 'mtu': '1500'}

# Generated at 2022-06-20 18:29:03.335452
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    network = SunOSNetwork()
    current_if = {'device' : 'e1000g0',
                  'ipv4'   : [],
                  'ipv6'   : [],
                  'type'   : 'unknown',
                  'macaddress' : 'unknown'}
    ips = {}
    words = [ 'ether', '0:1:2:3:4:5' ]
    network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'


# Generated at 2022-06-20 18:29:05.865578
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Purpose:
    Check whether SunOSNetworkCollector can be instantiated
    """
    assert SunOSNetworkCollector

# Generated at 2022-06-20 18:29:07.712387
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Unit test for constructor of class SunOSNetwork."""
    SunOSIfconfigNetwork()

# Generated at 2022-06-20 18:29:16.465419
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    word = ['ether', '0:1:2:d:e:f']
    current_if = dict(macaddress='unknown')
    ips = dict()

    the_class = SunOSNetwork()
    the_class.parse_ether_line(word, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'


# Generated at 2022-06-20 18:29:20.638158
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.__class__.__name__ == 'SunOSNetworkCollector'


# Generated at 2022-06-20 18:29:31.664412
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    facts = SunOSNetwork()
    interfaces = {}
    current_if = {}
    # Test first interface
    # parse_interface_line called with:
    #   words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '34']
    #   current_if = {}
    #   interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '34']
    current_if = facts.parse_interface_line(words, current_if, interfaces)
    # Should get back:
    #   current_

# Generated at 2022-06-20 18:29:37.156171
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # Assert for constructor of SunOSNetwork
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module)
    network_facts = network_collector.collect()
    assert network_facts.platform == 'SunOS'

