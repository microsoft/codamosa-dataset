

# Generated at 2022-06-20 18:20:26.747561
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sun = SunOSNetwork()
    iface = {'device': 'e1000g0'}
    ips = {}
    sun.parse_ether_line(['ether', '0:2:65:cf:ae:a0'], iface, ips)
    sun.parse_ether_line(['ether', '0:2:65:cf:ae:a0.712'], iface, ips)
    assert iface['macaddress'] == '00:02:65:cf:ae:a0'
    sun.parse_ether_line(['ether', '0:2:65:cf:ae:a0.712%1'], iface, ips)
    assert iface['macaddress'] == '00:02:65:cf:ae:a0'

# Generated at 2022-06-20 18:20:37.460280
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    This function tests the output of the method
    parse_interface_line of class SunOSNetwork
    """
    ifconfig = SunOSNetwork()
    # Testing output of parse_interface_line
    words = ['lo0:', 'flags=80049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '8232', 'index', '1']
    current_if = {}
    interfaces = {}
    result = {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'mtu': '8232'}], 'ipv6': [], 'macaddress': 'unknown', 'type': 'loopback'}

# Generated at 2022-06-20 18:20:38.969875
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """ Constructor """
    SunOSNetworkCollector()

# Generated at 2022-06-20 18:20:42.604195
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    ''' Unit test for constructor of class SunOSNetwork '''

    facts = SunOSNetwork()
    assert facts._fact_class == 'SunOS'


# Generated at 2022-06-20 18:20:47.681333
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.network.sunos_1 import SunOSNetwork_get_interfaces_info_ans

    ans_results = SunOSNetwork_get_interfaces_info_ans()

    ifc = SunOSNetwork()
    res = ifc.get_interfaces_info('/sbin/ifconfig')

    assert ans_results[0] == res[0]

# Generated at 2022-06-20 18:21:00.432702
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:21:11.226099
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_line = "bge0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2"
    test_current_if = {}
    test_interfaces = {}
    SunOSNet = SunOSNetwork()
    result = SunOSNet.parse_interface_line(test_line.split(), test_current_if, test_interfaces)
    expected_result = {'device': 'bge0', 'ipv4': [{'flags': '1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown'}
    assert result == expected_result

test_SunOSNetwork_parse_interface_line()

# Unit test

# Generated at 2022-06-20 18:21:20.667994
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ifconfig_path = 'test/test_SunOSNetwork/test_SunOSNetwork_parse_ether_line/ifconfig'
    ifc = SunOSNetwork(dict(module=dict(run_command=dict(rc=0, out='', err=''))))

    # Solaris displays single digit octets in MAC addresses e.g. 0:1:2:d:e:f
    # Add leading zero to each octet where needed.
    ifc.parse_ether_line(['ether', '0:1:2:d:e:f'], dict(), dict())
    assert ifc.interface_info['unknown']['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:21:30.104183
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {
        'ipv4': [],
        'ipv6': [],
        'macaddress': 'unknown',
        'type': 'unknown'
    }
    base_line = 'ether 0:1:2:d:e:f '
    for padding in range(0, 10):
        line = base_line[0:-1] + padding * ' ' + ' '
        words = line.split()
        SunOSNetwork().parse_ether_line(words, current_if, {})
        assert current_if['macaddress'] == '00:01:02:0d:0e:0f'



# Generated at 2022-06-20 18:21:42.010158
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # (words, current_if, interfaces)
    test_args = [['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '0'],
                 {},
                 {}]
    expected_returned_value = {'device': 'lo0', 'ipv4': [{'flags': ('2001000849', 'UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL'), 'mtu': '0'}], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}
    returned_value = SunOSNetwork.parse_interface_line(*test_args)

# Generated at 2022-06-20 18:21:53.769886
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test = SunOSNetwork()
    current_if = {'device': 'net0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    test.parse_ether_line(['ether', 'b:c:d:0:0:0'], current_if, ips)
    assert current_if['macaddress'] == '0b:0c:0d:00:00:00'

# Generated at 2022-06-20 18:22:03.487263
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import set_module_args

    module = ansible_mock.Mock(
        params={},
        check_mode=False
    )

    with unittest.TestCase():
        set_module_args(dict(gather_subset='!all'))
        obj = SunOSNetworkCollector(module=module)
        assert obj._platform == 'SunOS'
        assert obj._fact_class is SunOSNetwork
        assert obj._subsets == set(['default', 'interfaces', 'all'])
        assert obj._valid_subsets == set(['default', 'interfaces', 'all'])

# Generated at 2022-06-20 18:22:08.161089
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = NetworkCollector._create_module()
    network_collector = SunOSNetworkCollector(module=module)
    assert network_collector.platform == 'SunOS'
    assert network_collector.fact_class == SunOSNetwork

# Generated at 2022-06-20 18:22:15.740799
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    module.params = {
        'gather_subset': ['all'],
    }

    args = (module, '/usr/sbin/ifconfig')
    obj = SunOSNetwork(*args)
    out = obj.get_interfaces_info('/usr/sbin/ifconfig')

    # All interfaces
    assert out[0]['lo1']['device'] == 'lo1'
    assert out[0]['lo1']['ipv4'][0]['address'] == '127.0.0.1'
    assert out[0]['lo1']['ipv4'][0]['netmask'] == '255.0.0.0'

# Generated at 2022-06-20 18:22:18.656096
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-20 18:22:26.137914
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # Test for 'options=' in line
    module = AnsibleModule(argument_spec=dict())
    n = SunOSNetwork(module)
    n.parse_options_line(['options=',
                          '3<RXCSUM,TXCSUM,VLAN_MTU,LOOPBACK,LINKSTATE,RXCSUM_IPV6,TXCSUM_IPV6>',
                          'mtu', '1500'],
                         {}, {})
    assert n.options.get('rxcsum') == 1
    assert n.options.get('txcsum') == 1
    assert n.options.get('vlan_mtu') == 1
    assert n.options.get('loopback') == 1
    assert n.options.get('linkstate') == 1

# Generated at 2022-06-20 18:22:39.881021
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    new_if = {}
    interfaces = {}

    # test simple interface
    words = ['e1000g0:', 'flags=201000843', 'mtu', '9000']
    expected_if = {'ipv4': [{'flags': 'flags=201000843', 'mtu': 'mtu'}], 'ipv6': [], 'device': 'e1000g0', 'type': 'unknown', 'macaddress': 'unknown'}
    new_if = SunOSNetwork().parse_interface_line(words, new_if, interfaces)
    assert new_if == expected_if

    # test IPv6 interface
    words = ['xge0:', 'flags=201000843', 'mtu', '9000', 'index', '4']

# Generated at 2022-06-20 18:22:45.165529
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunosnetwork = SunOSNetwork({}, None, None)
    line = 'ether 0:1:2:d:e:f'
    words = line.split()
    current_if = {}
    ips = {}
    sunosnetwork.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:22:57.168783
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = get_module_mock()
    ifconfig_path = '/sbin/ifconfig'
    current_if = {'device': 'qfe0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'qfe0': current_if}
    words = 'qfe0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 2'.split()
    sunos_network_obj = SunOSNetwork(module)

    current_if = sunos_network_obj.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'qfe0'
    assert not current_if['ipv6']

# Generated at 2022-06-20 18:23:09.049584
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network_collector = SunOSNetworkCollector()
    ifconfig_out = '''
lo0:0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
lo0:1: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 10.66.71.254 netmask ff000000
ether 8:0:20:e:a:1
'''
    interfaces = {}
    current_if = {}
    ips = {}
    for line in ifconfig_out.splitlines():
        if line:
            words = line.split()

# Generated at 2022-06-20 18:23:23.862749
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    macaddress = '00:01:02:0a:0b:0c'
    words = ['ether', '0:1:2:a:b:c']
    current_if = {}
    current_if['macaddress'] = 'unknown'
    SunOSNetwork.parse_ether_line(None, words, current_if, None)
    assert current_if['macaddress'] == macaddress

# Generated at 2022-06-20 18:23:26.959197
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-20 18:23:30.608830
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector (None)
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-20 18:23:40.677173
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Arrange
    test_device = 'lo0'
    test_ip4_address = '127.0.0.1'
    test_ip4_netmask = '255.0.0.0'
    test_ip6_address = '::1/128'
    test_ip6_netmask = 'ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff'


# Generated at 2022-06-20 18:23:43.016852
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(), sunos.SunOSNetworkCollector)


# Generated at 2022-06-20 18:23:53.161348
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:23:55.764994
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    nc = SunOSNetworkCollector()
    assert nc._fact_class.platform == 'SunOS', "platform should equal 'SunOS'"

# Generated at 2022-06-20 18:23:58.910488
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.get_facts() == {}

# Generated at 2022-06-20 18:24:10.964230
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = SunOSNetwork(dict(module=dict(run_command=run_command_mock)))
    assert module.get_interfaces_info(None) == (dict(interfaces), dict(ips))



# Generated at 2022-06-20 18:24:18.516135
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork()
    assert sunos_network.parse_ether_line(['ether', '0:1:2:d:e:f'],
                                          {}, {}) == {'macaddress': '00:01:02:0d:0e:0f'}
    assert sunos_network.parse_ether_line(['ether', '0:1:2:3:4:5'],
                                          {}, {}) == {'macaddress': '00:01:02:03:04:05'}

# Generated at 2022-06-20 18:24:29.648561
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = SunOSNetwork()
    assert module.platform == 'SunOS'

# Generated at 2022-06-20 18:24:41.292242
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Create a dictionary to match the 'current_if' dictionary returned by Solaris ifconfig -a.
    current_if = {'device': 'e1000g1', 'ipv4': [{'flags': ['STREAMS'], 'mtu': 1500}, {'flags': ['STREAMS'], 'mtu': 1500}], 'ipv6': [{'flags': ['AUTO-CONFIG', 'IPv6'], 'mtu': 1500}, {'flags': ['AUTO-CONFIG', 'IPv6'], 'mtu': 1500}], 'type': 'unknown'}

    # Create a dummy instance of the SunOSNetwork class
    sunos_network = SunOSNetwork()

    # Expected output is '0:8:20:1:2:3'
    # 'words' is a dummy list required by the function being tested


# Generated at 2022-06-20 18:24:52.140518
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-20 18:25:03.644484
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    # solaris ifconfig output
    line1 = "bge0: flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS> mtu 1500 index 2"
    line2 = "bge0: flags=2001002<BROADCAST,MULTICAST,RUNNING,SIMPLEX,M-DOWN> mtu 9000 index 2"
    line3 = "bge0: flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS> mtu 1500 index 2"

# Generated at 2022-06-20 18:25:15.550929
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts = SunOSNetwork()
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    macaddress = ''
    words = ''
    # test 1
    words = 'ether 0:1:2:d:e:f'
    macaddress = ''
    # test 1.1
    octet = '0:1:2:d:e:f'.split(':')
    for octet in words[1].split(':'):
        octet = ('0' + octet)[-2:None]
        macaddress += (octet + ':')
    macaddress = macaddress[0:-1]
    facts.parse_ether_line(words.split(), current_if, {})

# Generated at 2022-06-20 18:25:23.096358
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    words = ['ether', '0:e:1:2d:3e:f']
    current_if = {}
    ips = {}
    sunos = SunOSNetwork()
    sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '0a:e1:02:2d:03:0e:f0'

# Generated at 2022-06-20 18:25:35.394906
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    sn = SunOSNetwork()
    # Test IPv4 interface
    words = ['e1000g0:', 'flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4>', 'mtu', '1500']
    current_if = {}
    interfaces = {}
    frags = sn.parse_interface_line(words, current_if, interfaces)
    assert len(interfaces) == 1
    assert interfaces['e1000g0']['flags'] == '1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4>'
    assert interfaces['e1000g0']['ipv4'][0]['mtu'] == '1500'
    # Test

# Generated at 2022-06-20 18:25:41.219872
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    # Super class constructor is tested in tes_GenericIfconfigNetwork
    testFactClass = SunOSNetwork(dict(module=dict()))
    assert testFactClass.get_file_path() == '/sbin/ifconfig'
    assert testFactClass.platform == 'SunOS'

# Generated at 2022-06-20 18:25:55.022243
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    '''Unit test for method parse_ether_line of class SunOSNetwork
    '''
    d = {'1.1.1.1': {'device': 'lo0', 'ipv4': [{'netmask': '255.0.0.0', 'prefixlen': 8, 'broadcast': '127.255.255.255', 'network': '127.0.0.0'}], 'ipv6': [{'prefixlen': 64, 'address': '::1', 'scope': 'host'}, {'prefixlen': 128, 'address': 'fe80::1%lo0', 'scope': 'link'}, {'prefixlen': 8, 'address': 'fe80::%lo0', 'scope': 'link'}]}}
    s = SunOSNetwork()

# Generated at 2022-06-20 18:25:58.164320
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-20 18:26:24.603736
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:26:31.902558
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    ifconfig_path = '/sbin/ifconfig'
    output = open('./SunOS_ifconfig_output.txt', 'r').read()
    rc = 0
    err = ''

    module = mock.Mock()
    module.run_command.return_value = rc, output, err


# Generated at 2022-06-20 18:26:34.691909
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    This test ensures that the SunOSNetworkCollector constructor creates
    the correct object
    """
    obj = SunOSNetworkCollector()
    assert isinstance(obj, SunOSNetworkCollector)

# Generated at 2022-06-20 18:26:45.450220
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('Module', (object, ), {})()
    module.run_command = run_command_mock
    module.params = {}
    nm = SunOSNetwork(module)
    interfaces, ips = nm.get_interfaces_info('/sbin/ifconfig')

# Generated at 2022-06-20 18:26:57.426622
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_module = type('Module', (object,), {'module': None})
    SunOSNetwork.get_module = lambda self: test_module

    sun = SunOSNetwork()
    test_cases = [
        ('ether 0:1:2:3:4:5', {'device': 'unknown', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': '00:01:02:03:04:05'}),
        ('ether 0:1:2:d:e:f', {'device': 'unknown', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': '00:01:02:0d:0e:0f'}),
    ]

# Generated at 2022-06-20 18:27:08.268787
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_data = [
        ('ether 0:1:2:d:e:f', '00:01:02:0d:0e:0f'),
        ('ether 0:1:2:3:4:5',  '00:01:02:03:04:05'),
        ('ether 0:1:2:3:4:5a','00:01:02:03:04:5a'),
    ]
    ifc = SunOSNetwork({'module_args': ''})
    for test in test_data:
        ifc.parse_ether_line(test[0].split(), {}, {})
        assert ifc.interfaces[ifc.current_if]['macaddress'] == test[1]



# Generated at 2022-06-20 18:27:19.377306
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    ifconfig_path = ''


# Generated at 2022-06-20 18:27:26.492416
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())

    ip1 = SunOSNetwork()
    ansible_facts = dict(ansible_net_interfaces = ip1.get_interfaces_info()[0],
                         ansible_net_all_ipv4_addresses = ip1.get_interfaces_info()[1]['all_ipv4_addresses'],
                         ansible_net_all_ipv6_addresses = ip1.get_interfaces_info()[1]['all_ipv6_addresses'])

    module.exit_json(ansible_facts=ansible_facts)

from ansible.module_utils.basic import *
if __name__ == '__main__':
    test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-20 18:27:37.625740
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:27:48.292212
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ifc = SunOSNetwork()
    ifc.parse_ether_line(['ether', '0:1:2:d:e:f'], {}, {})
    ifc.parse_ether_line(['ether', '0:1:2e:d:e:f'], {}, {})
    ifc.parse_ether_line(['ether', '00:1:2:d:e:f'], {}, {})
    ifc.parse_ether_line(['ether', '0:01:2:d:e:f'], {}, {})
    ifc.parse_ether_line(['ether', '0:1:02:d:e:f'], {}, {})

# Generated at 2022-06-20 18:28:38.753689
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_dict = {}

    # bge1 is seen first and is saved in 'test_dict'
    test_dict = SunOSNetwork._parse_interface_line(
        ['bge1:', 'flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500'],
        {}, test_dict)

    # As bge1 is in 'test_dict' it is not saved again
    test_dict = SunOSNetwork._parse_interface_line(
        ['bge1', 'flags=23008843<UP,BROADCAST,RUNNING,MULTICAST,IPv6,CoS>', 'mtu', '1500'],
        {}, test_dict)

    # eri0 is seen first and is saved in 'test_dict'

# Generated at 2022-06-20 18:28:49.318255
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos = SunOSNetwork()
    interface = {}
    ips = {}
    sunos.parse_ether_line(['ether', '0:1:2:d:e:f'], interface, ips)
    assert interface['macaddress'] == '00:01:02:0d:0e:0f'
    sunos.parse_ether_line(['ether', '0:1:2:0:0:0:d:e:f'], interface, ips)
    assert interface['macaddress'] == '00:01:02:00:00:00:0d:0e:0f'

# Generated at 2022-06-20 18:28:53.056791
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.generic_bsd import NetworkCollector
    obj = SunOSNetworkCollector()
    assert isinstance(obj, NetworkCollector)

# Generated at 2022-06-20 18:28:57.655942
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetwork(module=module)

    # Check important attributes
    assert collector.platform == 'SunOS'
    assert collector.command == '/sbin/ifconfig -a'


# Generated at 2022-06-20 18:29:04.845865
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    This is a unit test for the method get_interfaces_info.
    """

    collector = SunOSNetworkCollector()
    path = '/usr/sbin/ifconfig'

# Generated at 2022-06-20 18:29:12.319895
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    This test case is to test the function get_interfaces_info of class SunOSNetwork
    """

    iface_re = re.compile(r'^\S+')
    # Expected result

# Generated at 2022-06-20 18:29:21.739462
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    ifaceDict = dict(device='lo0', ipv4=[], ipv6=[], type='unknown')

    words = ['lo0:', 'flags=2001000849',
             'mtu', '8232', 'index', '1', 'inet', '127.0.0.1',
             'netmask', 'ffffff00']
    flags = ['IPv6', 'MULTICAST', 'LOOPBACK', 'ZONE', 'ZONE']
    # Solaris ifconfig -a displays a newline between lines that are not on the same interface
    # To test the code within the if statement not entered by this test case
    # we need to pass in an interface that has already been seen.
    interfaces = {'lo0': ifaceDict}

    sn = SunOSNetwork()
    ifaceDict = sn.parse

# Generated at 2022-06-20 18:29:24.534747
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_network_test = SunOSNetwork({})
    assert sunos_network_test is not None

# Generated at 2022-06-20 18:29:27.252529
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class is SunOSNetwork


# Generated at 2022-06-20 18:29:30.254255
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the constructor of SunOSNetworkCollector.
    """
    # Test without parameters
    SunOSNetworkCollector()