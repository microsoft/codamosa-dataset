

# Generated at 2022-06-20 18:20:07.822246
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert isinstance(SunOSNetwork(dict(module=dict())), SunOSNetwork)

# Generated at 2022-06-20 18:20:16.965409
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """ Test method parse_interface_line of class SunOSNetwork """
    # Prepare data for test
    args = {}
    words = ['lo0:']
    current_if = {}
    interfaces = {}
    # Execute function
    sunosNetwork = SunOSNetwork(args)
    interfaces = sunosNetwork.parse_interface_line(words, current_if, interfaces)
    # Assertions
    assert interfaces['lo0'] == {'device': 'lo0', 'ipv4': [{'mtu': None, 'flags': []}], 'ipv6': [], 'type': 'unknown'}
    # Prepare data for test
    args = {}
    words = ['lo0:', 'options=3008', '<LOOPBACK,UP,LOWER_UP>', 'mtu', '65536']

# Generated at 2022-06-20 18:20:17.766532
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork(dict(module=dict()))

# Generated at 2022-06-20 18:20:23.157925
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network_module = SunOSNetwork(module)
    ifaces = dict()
    current_if = dict()

    # Test one interface with IPv4
    words = 'lo0:5 flags=3001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'.split()
    current_if = network_module.parse_interface_line(words, current_if, ifaces)

    assert current_if['device'] == 'lo0'
    assert len(current_if['ipv4']) == 1
    assert len(current_if['ipv6']) == 0
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-20 18:20:36.196421
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = generic_network_test_module(SunOSNetwork)


# Generated at 2022-06-20 18:20:48.066325
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    class MockModule:
        def run_command(self, commands):
            interface_lines = []
            interface_lines.append("lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1")
            interface_lines.append("    inet 127.0.0.1 netmask ff000000")
            interface_lines.append("ham0: flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4> mtu 1500 index 2")
            interface_lines.append("    inet 10.228.43.218 netmask ffffff00 broadcast 10.228.43.255")
            interface_lines.append("    ether 0:1:2:d:e:f")
            interface_lines

# Generated at 2022-06-20 18:20:57.640056
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    my_obj = SunOSNetwork()
    assert(my_obj.platform == 'SunOS')
    assert(my_obj.__doc__ == '\n    This is the SunOS Network Class.\n    It uses the GenericBsdIfconfigNetwork.\n\n    Solaris can have different FLAGS and MTU for IPv4 and IPv6 on the same interface\n    so these facts have been moved inside the \'ipv4\' and \'ipv6\' lists.\n    ')
    assert(my_obj.get_default_interfaces_defs() == {})
    assert(my_obj.get_interfaces_defs() == {})
    assert(my_obj.get_interfaces_ip() == {})
    assert(my_obj.get_interfaces() == {})

# Generated at 2022-06-20 18:21:05.307598
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector().collect()
    interfaces = facts['interfaces']
    for iface in interfaces:
        for v in 'ipv4', 'ipv6':
            for subdict in interfaces[iface][v]:
                assert isinstance(subdict['address'], str)
                assert isinstance(subdict['broadcast'], str)
                assert isinstance(subdict['netmask'], str)
    assert isinstance(facts['default_ipv4']['address'], str)
    assert isinstance(facts['default_ipv6']['address'], str)

# Generated at 2022-06-20 18:21:07.401930
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-20 18:21:19.414999
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Code is executed in an Ansible module_utils.facts.network.sunos.SunOSNetwork instance
    # An instance of the module class is 'self'
    self = SunOSNetwork()
    # Code is executed in a dict called 'current_if'
    current_if = {}
    # Code is executed in a dict called 'interfaces'
    interfaces = {}
    # Code is executed in a list called 'words'
    words = ['net0:', 'flags=1e080863,c0', 'mtu', '1500', 'index', '10']
    # The function being tested
    current_if = self.parse_interface_line(words, current_if, interfaces)
    # Test for valid results
    # Test for device
    assert 'device' in current_if, "Failed to capture device"
    assert current_if

# Generated at 2022-06-20 18:21:33.387055
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    if 'SunOS' not in SunOSNetwork.facter['kernel']:
        return

    facts = SunOSNetwork.get_interfaces_info('/sbin/ifconfig')

    assert len(facts[0]['eth0']) > 0
    assert facts[0]['eth0']['ipv4'][0]['address'] == '10.17.39.119'
    assert facts[0]['eth0']['ipv4'][0]['netmask'] == '255.255.255.0'
    assert facts[0]['eth0']['ipv6'][0]['address'] == 'fe80::213:20ff:feac:3c3b'
    assert facts[0]['eth0']['ipv6'][0]['prefix'] == '64'

# Generated at 2022-06-20 18:21:43.169475
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    facter = SunOSNetwork()
    interfaces, ips = facter.get_interfaces_info('/usr/sbin/ifconfig')
    assert len(interfaces) == 2
    assert len(interfaces['lo0']) == 3
    assert len(interfaces['lo0']['ipv4']) == 1
    assert len(interfaces['lo0']['ipv6']) == 1
    assert len(interfaces['lo0']['ipv4'][0]) == 2
    assert len(interfaces['lo0']['ipv6'][0]) == 2
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']

# Generated at 2022-06-20 18:21:47.352929
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Test class SunOSNetwork constructor."""
    sunos_net = SunOSNetwork()
    assert sunos_net.platform == 'SunOS'


# Generated at 2022-06-20 18:21:49.032492
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    o = SunOSNetworkCollector()
    assert o.platform == 'SunOS'
    assert o._fact_class == SunOSNetwork



# Generated at 2022-06-20 18:22:02.183118
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork(module=None)
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    current_if = m.parse_ether_line(['ether', '0:1:2:d:e:f'], current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'
    current_if = m.parse_ether_line(['ether', 'a:b:c:1:2:3'], current_if, ips)
    assert current_if['macaddress'] == '0a:0b:0c:01:02:03'
    current_if = m.parse_ether_

# Generated at 2022-06-20 18:22:13.222539
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_obj = SunOSNetwork()

    # Create test interface dict
    test_current_if = dict(
        device='test_device',
        type='test_type',
        ipv4=[{'flags': 'IPv4', 'mtu': 'test_mtu'}],
        ipv6=[{'flags': 'IPv6', 'mtu': 'test_mtu'}],
        macaddress='test_macaddress',
    )

    # Create test ips dict
    test_ips = dict(
        all_ipv4_addresses=['test_all_ipv4_addresses'],
        all_ipv6_addresses=['test_all_ipv6_addresses'],
    )

    # Create test words

# Generated at 2022-06-20 18:22:15.173693
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert hasattr(SunOSNetworkCollector, '_platform')
    assert hasattr(SunOSNetworkCollector, '_fact_class')
    assert isinstance(SunOSNetworkCollector._fact_class, SunOSNetwork)

# Generated at 2022-06-20 18:22:25.377098
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    def mock_run_command(module, command):
        return (0, "lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1\n")

    class MySunOSNetwork(SunOSNetwork):
        def __init__(self, module):
            super(MySunOSNetwork, self).__init__(module)

        def run_command(self, command):
            return mock_run_command(None, command)

    def test(line, expectation):
        current_if = {}
        interfaces = {}
        words = line.split()
        net = MySunOSNetwork(None)
        result = net.parse_interface_line(words, current_if, interfaces)
        assert result == expectation


# Generated at 2022-06-20 18:22:29.210333
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert type(obj._fact_class) == SunOSNetwork

# Generated at 2022-06-20 18:22:40.520587
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    obj = SunOSNetwork(module)

    ret = obj.get_interfaces_info('/sbin/ifconfig')
    interfaces = ret[0]
    ips = ret[1]
    assert sorted(interfaces.keys()) == sorted(['lo0', 'lo1', 'lo2', 'lo3', 'net0', 'net1', 'net2', 'net3'])

    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']

    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'

# Generated at 2022-06-20 18:23:00.350227
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_platform = 'SunOS'
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    test_obj = SunOSNetwork(test_module)
    test_path = test_obj.module.get_bin_path('ifconfig', True, ['/usr/sbin', '/sbin'])

    test_interfaces, test_ips = test_obj.get_interfaces_info(test_path)
    test_all_ipv4_addresses = test_ips['all_ipv4_addresses']
    test_all_ipv6_addresses = test_ips['all_ipv6_addresses']

    # test_interfaces
    print("test_interfaces = {0}".format(test_interfaces))
    assert test_interfaces is not None

# Generated at 2022-06-20 18:23:03.109688
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    assert SunOSNetwork.parse_ether_line(None, ['ether', '0:1:2:d:e:f'], None, None) == \
           {'macaddress': '00:01:02:0d:0e:0f'}

# Generated at 2022-06-20 18:23:14.476942
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    config_content = """
lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000 
lo0: flags=2002000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8252 index 1
        inet6 ::1/128
ether 0:1:2:d:e:f
"""
    sunos_ifconfig_content = dict(
        interface=config_content,
    )
    sunos_ifconfig_path = 'module.run_command.return_value.stdout'


# Generated at 2022-06-20 18:23:19.219440
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the constructor of the class SunOSNetworkCollector.
    """
    network_facts = SunOSNetworkCollector()
    assert network_facts.get_device_type() == "SunOS"



# Generated at 2022-06-20 18:23:22.480116
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class.platform == 'SunOS'


# Generated at 2022-06-20 18:23:28.585618
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    module = type('obj', (object,), {'run_command': run_command, 'fail_json': fail_json})
    net = SunOSNetwork(module)

    # ifconfig -a output from a SunOS system

# Generated at 2022-06-20 18:23:30.959197
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    inv_obj = SunOSNetwork(module)

    assert inv_obj.platform == 'SunOS'

# Generated at 2022-06-20 18:23:32.472513
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork(dict(module=None))

# Generated at 2022-06-20 18:23:34.425556
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock()
    net_collector = SunOSNetworkCollector(module)
    assert net_collector.platform == 'SunOS'


# Generated at 2022-06-20 18:23:45.727618
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork()
    i = {'ipv4': [], 'ipv6': [], 'device': 'bge0', 'type': 'unknown'}
    ip = {'all_ipv6_addresses': [], 'all_ipv4_addresses': []}

    words = ['ether', '0:1:2:d:e:f']
    m.parse_ether_line(words, i, ip)
    assert i['macaddress'] == '00:01:02:0d:0e:0f'

    # Test with a single digit in the last octet
    words = ['ether', '0:1:2:d:e:f']
    m.parse_ether_line(words, i, ip)

# Generated at 2022-06-20 18:24:12.392609
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_words = ['ether', '0:1:2:d:e:f']
    test_current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    test_ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    expected_current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': '00:01:02:0d:0e:0f'}

    # prepare test object
    test_object = SunOSNetwork()

    # run test
    test_object.parse_ether_line(test_words, test_current_if, test_ips)

   

# Generated at 2022-06-20 18:24:22.259926
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    test_words = ['ether', '0:1:2:d:e:f']
    test_if = {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    test_ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    test_obj = SunOSNetwork({}, {}, {})
    test_if = test_obj.parse_ether_line(test_words, test_if, test_ips)

# Generated at 2022-06-20 18:24:25.924258
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts = SunOSNetwork()
    words = ['ether', '0:1:2:d:e:f']
    current_if = {'macaddress': 'unknown'}
    ips = {}
    facts.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-20 18:24:39.247112
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    with open('unit/modules/utils/facts/network/bsd/test_SunOSNetwork_get_interfaces_info.raw') as f:
        test_string = f.read()
    module = type('test', (object, ), {'run_command': lambda self, x: (0, test_string, None)})()
    interfaces, ips = SunOSNetwork(module).get_interfaces_info('/usr/bin/fake_ifconfig')
    assert len(interfaces) == 4
    assert len(ips) == 2  # only 'all_ipv4_addresses' and 'all_ipv6_addresses' are populated
    assert len(ips['all_ipv4_addresses']) == 2
    assert len(ips['all_ipv6_addresses']) == 1

# Generated at 2022-06-20 18:24:46.096658
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # test instantiating a class SunOSNetworkCollector
    sunos_facts = SunOSNetworkCollector()
    assert sunos_facts is not None
    assert sunos_facts.platform == 'SunOS'
    assert sunos_facts._fact_class == SunOSNetwork
    assert sunos_facts._fact_class.platform == 'SunOS'

# Generated at 2022-06-20 18:24:53.341493
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Test setup:
    ifconfig_path = '/sbin/ifconfig'

# Generated at 2022-06-20 18:24:59.783016
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """ test ifconfig parsing """
    b = SunOSNetwork()
    b.parse_ether_line(['ether', '0:1:2:d:e:f'], {}, {})
    assert '00:01:02:0d:0e:0f' == b.interfaces[b.current_ifname]['macaddress']

# Generated at 2022-06-20 18:25:13.188306
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = FakeModule({})
    net = SunOSNetwork(module, run_commands)
    interfaces = {}
    current_if = {}
    words = "e1000g0: flags=100008e<UP,BROADCAST,SMART,SIMPLEX,MULTICAST,NEEDSGIANT> mtu 1500 index 3".split()
    current_if = net.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'e1000g0'
    assert current_if['ipv4'][0]['flags'] == '100008e<UP,BROADCAST,SMART,SIMPLEX,MULTICAST,NEEDSGIANT>'
    assert current_if['ipv4'][0]['mtu'] == '1500'
    # IPv4 interface, so only

# Generated at 2022-06-20 18:25:20.308847
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Fake the module
    module = 'dummy'
    module.run_command = MagicMock(return_value=(0, FAKE_OUT_LONG, ""))
    # Call the function
    fake_network = SunOSNetwork()
    facts = fake_network.get_interfaces_info("dummy")
    # Assertion
    assert facts[0]['lo0']['ipv4'][0]['address'] == '127.0.0.1'


# Generated at 2022-06-20 18:25:21.886065
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-20 18:25:58.523112
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    facts = SunOSNetwork()

# Generated at 2022-06-20 18:26:02.302200
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ifc = SunOSNetwork()
    ifc.parse_ether_line(['ether', '0:1:2:d:e:f'], dict(), dict())
    ifc.parse_ether_line(['ether', '1::2:3::4:5'], dict(), dict())

# Generated at 2022-06-20 18:26:05.462539
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts = SunOSNetwork({})
    current_if = {}
    ips = {}
    line = 'ether 0:3:ba:0:0:b5'
    words = line.split()
    facts.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:03:ba:00:00:b5'

# Generated at 2022-06-20 18:26:16.296761
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_SunOSNetwork = SunOSNetwork()

    # Test normal interface

# Generated at 2022-06-20 18:26:25.080586
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = MockModule()
    sunos_network = SunOSNetwork(module=module)
    current_if = {}
    interfaces = {}
    words = ['ce0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu=1500']
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    assert current_if == {'device': 'ce0', 'ipv4': [{'flags': '1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown'}
    interfaces['ce0'] = current_if

# Generated at 2022-06-20 18:26:37.353882
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ether_output = [
        "ether 0:1:2:d:e:f",
        "ether 0:1:2:d:e:f tap0",
        "ether 0:1:2:d:e:f:g:h:i:j:k:l:m:n:o:p:q"
    ]
    # Verify valid MAC addresses
    for line in ether_output:
        words = line.split()
        current_if = {}
        ips = {}
        if len(words) > 2:
            device = words[2]
            current_if['device'] = device
            current_if['macaddress'] = 'unknown'
        else:
            current_if['macaddress'] = 'unknown'
        SunOSNetwork().parse_ether_line(words, current_if, ips)
       

# Generated at 2022-06-20 18:26:40.152276
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    assert collector._platform == 'SunOS'


# Generated at 2022-06-20 18:26:49.701658
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    print('Unit test for method "parse_ether_line()" of class "SunOSNetwork"')
    ifc = SunOSNetwork({})
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'lo0': current_if}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    print('Test case: MAC address 0:1:2:d:e:f (should be 0:01:02:0d:0e:0f)')
    words = 'ether 0:1:2:d:e:f'.split()
    ifc.parse_ether_line(words, current_if, ips)

# Generated at 2022-06-20 18:27:01.668621
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-20 18:27:02.959068
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec=dict())
    assert isinstance(SunOSNetwork(module), SunOSNetwork)
    assert SunOSNetwork(module).platform == 'SunOS'

# Generated at 2022-06-20 18:28:16.695476
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Create an object of class SunOSNetworkCollector
    sunos_network = SunOSNetworkCollector()

    # Check the type of 'sunos_network' object
    assert isinstance(sunos_network, SunOSNetworkCollector)

    # Check the type of 'sunos_network._fact_class' attribute
    assert isinstance(sunos_network._fact_class, SunOSNetwork)

    # Check the value of 'sunos_network._platform' attribute
    assert sunos_network._platform == 'SunOS'

# Generated at 2022-06-20 18:28:17.930153
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork({'module': 1})

# Generated at 2022-06-20 18:28:21.389636
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    cls = SunOSNetworkCollector()
    assert isinstance(cls._fact_class, SunOSNetwork)
    assert cls._platform == 'SunOS'


# Generated at 2022-06-20 18:28:24.207854
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector()
    assert net_collector.__class__.__name__ == 'SunOSNetworkCollector'

# Generated at 2022-06-20 18:28:33.678152
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # Call the constructor directly
    module = 'fakeModule'
    args = 'fakeArgs'
    sunos = SunOSNetwork(module, args)

    # Check that a new fact class was created
    assert sunos.__class__.__name__ == 'SunOSNetwork'

    # Check that the module variable was set correctly
    assert sunos.module == module

    # Check that the platform variable was set correctly
    assert sunos.platform == 'SunOS'

    # Check that the ifconfig_path variable was set correctly
    assert sunos.ifconfig_path == '/usr/sbin/ifconfig'

    # Check that the ipv6_enabled variable was set correctly
    assert sunos.ipv6_enabled is True

    # Check that the get_interfaces_info function was set correctly

# Generated at 2022-06-20 18:28:41.560847
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ip = SunOSNetwork(None)
    words = ['ether', '0:1:2:d:e:f', 'some/more/words']
    ip.parse_ether_line(words, {}, {})
    assert words[1] == '00:01:02:0d:0e:0f', \
        'parse_ether_line() has not added required leading zero to this MAC address: ' + words[1]

# Generated at 2022-06-20 18:28:42.169041
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-20 18:28:53.781436
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """Unit test for the SunOSNetwork.parse_interface_line() method"""
    test_module = type('test_module', (object,), {})()
    test_module.run_command = lambda *args, **kwargs: (0, '', '')
    test_module.params = {}
    test_module.boolean = lambda value, module=None: False
    test_module.check_mode = False
    test_network = SunOSNetwork(module=test_module)

    # First test line with multiple formats
    words = ['lo0', 'UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'MTU:', '8232', 'Metric:', '1']
    current_if = {}
    current_if = test_network.parse_interface_line(words, current_if, {})

# Generated at 2022-06-20 18:28:56.963965
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert (obj.platform == 'SunOS')
    assert (obj.fact_class == SunOSNetwork)

# Generated at 2022-06-20 18:29:04.486299
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    device = 'net0:'
    words = [device, 'flags=843<UP,BROADCAST,RUNNING,MULTICAST,IPv6>', 'mtu 1500']
    current_if = {'device': device, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    interfaces[device] = current_if
    expected_result = {'device': device, 'ipv4': [{'flags': '843<UP,BROADCAST,RUNNING,MULTICAST,IPv6>', 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}
    fact_class = SunOSNetwork()
