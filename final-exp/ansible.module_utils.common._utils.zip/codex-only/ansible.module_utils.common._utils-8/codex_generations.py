

# Generated at 2022-06-22 21:09:47.222939
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    A class to test get_all_subclasses logic

    >>> import ansible_collections.ansible.community._utils
    >>> from ansible_collections.ansible.community._utils import get_all_subclasses
    >>> A = type('A', (), {})
    >>> B = type('B', (), {})
    >>> C = type('C', (B,), {})
    >>> D = type('D', (A, B), {})
    >>> E = type('E', (A, C), {})
    >>> F = type('F', (D, E), {})
    >>> classes = get_all_subclasses(A)
    >>> sorted([x.__name__ for x in classes])
    ['D', 'E', 'F']
    '''


# Generated at 2022-06-22 21:09:58.045618
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Simple class tree
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass

    # Test base class
    assert get_all_subclasses(A) == set([B, C, D])
    # Test child class
    assert get_all_subclasses(B) == set([D])
    # Test final class
    assert get_all_subclasses(D) == set()

    # Test on a unordered class tree
    class Source:
        pass
    class Target(D, C):
        pass

    # Test base class with multiple parents
    assert get_all_subclasses(Source) == set([A, C, B, D, Target])
    # Test child class with multiple parents
    assert get_all_subclasses(Target)

# Generated at 2022-06-22 21:10:09.053496
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(D): pass
    class F(D): pass
    class G(F): pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([C])
    assert get_all_subclasses(D) == set([E, F, G])


# This is a class that we can use to test whether something is in a list of
# subclasses.  For example, if we want to know if B() is a subclass of A(), we
# would do.
#     isinstance(B(), get_isinstance(A))

# Generated at 2022-06-22 21:10:18.454003
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create the simple classes tree we want to test
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(C): pass
    class E(B): pass
    # The test of function
    assert set(get_all_subclasses(A)) == set((C,D))
    assert set(get_all_subclasses(B)) == set((E,))
    assert get_all_subclasses(C) == set((D,))
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    # The class we will inherit for the new test
    class TestGetAllSubclasses(object): pass
    # Create a new class outside this module
    __import__('ansible').plugins.action.copy

# Generated at 2022-06-22 21:10:29.302027
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test class definitions
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    # Test get_all_subclasses function
    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, F])
    assert get_all_subclasses(C) == set([D, E, F])
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-22 21:10:35.356745
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(B, C):
        pass
    class G(C):
        pass
    all_subclasses = get_all_subclasses(A)
    assert all_subclasses == set([B, C, D, E, F, G])

# Generated at 2022-06-22 21:10:40.156254
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a hierarchy of classes and check that all subclasses are found
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    assert set(get_all_subclasses(A)) == {B, C, D}

# Generated at 2022-06-22 21:10:43.982166
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(object):
        pass
    assert get_all_subclasses(A) == set([B, C])
    assert get_all_subclasses(B) == set([C])


# Generated at 2022-06-22 21:10:52.481572
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Declare some classes
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    # Testing

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set()

    assert get_all_subclasses(int) == set([bool])
    assert get_all_subclasses(str) == set([])

# Generated at 2022-06-22 21:11:03.667271
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # We should return more than just the class we are testing.
    # Build a tree of classes.
    class Leaf: pass
    class Leaf2: pass
    class Tree: pass
    class Tree2(Tree): pass
    class Tree3(Tree): pass
    class Tree4(Tree): pass
    class Tree5(Tree): pass
    class Tree6(Tree): pass
    class Tree7(Tree): pass
    class Tree8(Tree): pass
    class Tree9(Tree): pass
    class Tree10(Tree): pass
    class Tree11(Tree): pass
    class Tree12(Tree): pass
    class Tree13(Tree): pass
    class Tree14(Tree): pass
    class Tree15(Tree): pass
    class Tree16(Tree): pass
    class Tree17(Tree): pass
    class Tree18(Tree): pass

# Generated at 2022-06-22 21:11:12.921250
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function get_all_subclasses
    '''
    import sys
    import unittest
    from numbers import Number

    class TestClass(object):
        '''
        Empty class used only for this test
        '''
        pass

    class TestClassSubclass(TestClass):
        '''
        Empty class used only for this test
        '''
        pass

    class TestClassSubSubclass(TestClassSubclass):
        '''
        Empty class used only for this test
        '''
        pass

    class NumberClass(Number):
        '''
        Empty class used only for this test
        '''
        pass

    class StringClass(basestring):
        '''
        Empty class used only for this test
        '''
        pass


# Generated at 2022-06-22 21:11:19.540572
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Initialize test classes
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass

    # Checks if all subclasses are found
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])

# Generated at 2022-06-22 21:11:28.667587
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(B):
        pass

    class F(object):
        pass

    class G(F):
        pass

    class H(F):
        pass

    class I(H):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(F)) == set([G, H, I])
    assert set(get_all_subclasses(C)) == set([D])

# Generated at 2022-06-22 21:11:34.960329
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Base class
    class A(object):
        def __init__(self):
            pass

    # Derived classes
    class B(A):
        def __init__(self):
            pass

    class C(A):
        def __init__(self):
            pass

    class D(B):
        def __init__(self):
            pass

    # Testing
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert D in get_all_subclasses(B)
    assert D not in get_all_subclasses(C)
    assert D not in get_all_subclasses(D)

# Generated at 2022-06-22 21:11:43.201148
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import os

    class Parent(object):
        pass

    class Child(Parent):
        pass

    class GrandChild(Child):
        pass

    class GrandChild2(Child):
        pass

    class Uncle(Parent):
        pass

    class Cousin(Uncle):
        pass

    class Cousin2(Uncle):
        pass

    assert os.path.basename(GrandChild.__module__) == "_utils"
    assert os.path.basename(GrandChild2.__module__) == "_utils"
    assert os.path.basename(Cousin.__module__) == "_utils"
    assert os.path.basename(Cousin2.__module__) == "_utils"


# Generated at 2022-06-22 21:11:54.633623
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This is a unit test for function get_all_subclasses
    '''

    # Example taken from http://code.activestate.com/recipes/576949/
    # It's a pretty old one, but it works
    class A: pass

    class B(A): pass

    class C(A): pass

    class D(B,C): pass

    class E(B): pass

    class F(D,E): pass

    class G(D): pass

    class H: pass

    class I(H): pass

    class J(H): pass

    class K(I,J): pass

    class L(J): pass

    # Adding other classes to the tree
    class M(L): pass

    class N(L): pass

    class O(L): pass

    # Recursively find all subclasses


# Generated at 2022-06-22 21:12:05.039862
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types

    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(E): pass

    def assert_subclasses(cls, subclasses):
        assert len(subclasses) == len(set(subclasses))
        subclasses = list(subclasses)
        for i, sc in enumerate(subclasses):
            assert isinstance(sc, types.TypeType)
            assert issubclass(sc, cls)
            assert sc not in subclasses[:i]

    assert_subclasses(A, get_all_subclasses(A))
    assert_subclasses(B, get_all_subclasses(B))
    assert_subclasses(C, get_all_subclasses(C))
    assert_

# Generated at 2022-06-22 21:12:11.666419
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G():
        pass
    class H(C, G):
        pass

    assert get_all_subclasses(A) == set((B, C, D, E, F, H))

# Generated at 2022-06-22 21:12:21.233085
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test the function get_all_subclasses()
    '''
    import collections
    import pytest

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(A):
        pass

    class F(E):
        pass

    class G(E):
        pass

    class H(E):
        pass

    assert collections.Counter(get_all_subclasses(A)) == collections.Counter([B, C, D, E, F, G, H])
    assert collections.Counter(get_all_subclasses(A())) == collections.Counter([B, C, D, E, F, G, H])
    with pytest.raises(TypeError):
        get_all_subclasses

# Generated at 2022-06-22 21:12:32.029408
# Unit test for function get_all_subclasses
def test_get_all_subclasses():   # pragma: no cover
    class A(object):  pass
    class B(A):  pass
    class C(A):  pass
    class D(B):  pass
    class E(B):  pass
    class F(C):  pass
    class G(C):  pass
    class H(C):  pass
    class I(D):  pass
    class J(D):  pass
    class K(D):  pass

    assert set([A,B,C,D,E,F,G,H,I,J,K]) == set(get_all_subclasses(A))
    assert set([B,D,E]) == set(get_all_subclasses(B))
    assert set([C,F,G,H]) == set(get_all_subclasses(C))

# Generated at 2022-06-22 21:12:35.320714
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert get_all_subclasses(A) == set([B, C, D])

# Generated at 2022-06-22 21:12:46.266794
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Example of hierarchy
    #  A
    #  |_B
    #  | |_C
    #  |_D
    #    |_E
    #    |_F

    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(D): pass
    class F(D): pass
    class G(object): pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    # If a classe doesn't have any subclass, return itself
    assert get_all_subclasses(C) == set([C])
    # If a class is not a subclass of the start class, return an empty set
    assert get_all_subclasses(E) == set([])

# Generated at 2022-06-22 21:12:50.356261
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])

# Generated at 2022-06-22 21:12:55.112905
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.system

    classes = get_all_subclasses(ansible.module_utils.facts.system.System)

    assert ansible.module_utils.facts.hardware.Linux in classes
    assert ansible.module_utils.facts.hardware.SunOS in classes
    assert ansible.module_utils.facts.system.System in classes

# Generated at 2022-06-22 21:13:06.206954
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(A):
        pass
    class F(A):
        pass
    class G(C):
        pass
    class H(D):
        pass

    # Test normal case
    assert set(get_all_subclasses(A)) == set([B, C, G, D, E, F, H])
    # Test class A by itself
    assert set(get_all_subclasses(A)) == set([B, C, G, D, E, F, H])
    # Test class C by itself
    assert set(get_all_subclasses(C)) == set([G])
    # Test class H by itself

# Generated at 2022-06-22 21:13:10.310045
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Foo(object):
        pass
    class Bar(Foo):
        pass
    class Foobar(Bar):
        pass
    class NotFoo(object):
        pass
    classes = get_all_subclasses(Foo)
    assert len(classes) == 2
    assert Bar in classes
    assert Foobar in classes
    assert NotFoo not in classes

# Generated at 2022-06-22 21:13:16.287232
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This function tests the get_all_subclasses function in module '_utils'.

    1. Class A is defined with 2 subclasses: B and C
    2. Class B is defined with 2 subclasses: D and E
    3. Class C is defined with 0 subclasses
    4. Class D is defined with 2 subclasses: F and G
    5. Class E is defined with 0 subclasses
    6. Class F is defined with 0 subclasses
    7. Class G is defined with 0 subclasses
    8. Then we test the get_all_subclasses function.
       The expected result is the set of all defined subclasses:
       (B, C, D, E, F, G)
    '''
    # Define test classes
    class A(object):
        pass
    class B(A):
        pass

# Generated at 2022-06-22 21:13:23.649165
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])
    assert get_all_subclasses(B) == set([D, E, H])
    assert get_all_subclasses(C) == set([F, G])

# Generated at 2022-06-22 21:13:33.552692
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a class hierarchy
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(E):
        pass

    # Test expected class hierarchy
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set()
    assert set(get_all_subclasses(C)) == set([D, E, F])
    assert set(get_all_subclasses(D)) == set([E, F])
    assert set(get_all_subclasses(E)) == set([F])
    assert set(get_all_subclasses(F)) == set()

# Generated at 2022-06-22 21:13:39.510305
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a simple hierachy
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(E):
        pass

    subclasses_list = get_all_subclasses(A)

    # Correct result is
    result = [B, C, D, E, F]
    for item in result:
        assert item in subclasses_list
    assert len(subclasses_list) == len(result)

# Generated at 2022-06-22 21:13:45.916439
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(D):
        pass
    class G(D):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])

# Generated at 2022-06-22 21:13:57.596468
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    # create sample classes
    class Parent(object):
        pass
    class Child1(Parent):
        pass
    class Child2(Parent):
        pass
    class Child11(Child1):
        pass
    class Child12(Child1):
        pass

    # Check that we return all subclasses
    assert Child1 in get_all_subclasses(Parent)
    assert Child2 in get_all_subclasses(Parent)
    assert Child11 in get_all_subclasses(Parent)
    assert Child12 in get_all_subclasses(Parent)
    assert Child1 in get_all_subclasses(Parent)

    # Check that we return only one instance of each class
    assert len(get_all_subclasses(Parent)) == 4



# Generated at 2022-06-22 21:14:03.525985
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Simple test to check that get_all_subclasses() returns the desired output.
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(object):
        pass

    subclasses = get_all_subclasses(A)
    assert subclasses == set([B, C, D])

# Generated at 2022-06-22 21:14:13.228679
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit tests for the :py:func:`get_all_subclasses` function.
    '''

    # Defining some classes
    class A: pass
    class B: pass
    class C: pass
    class D(A): pass
    class E(B): pass
    class F(C): pass
    class G(B, C): pass
    class H(F): pass
    class I(H): pass
    class J(D, E, F, G): pass

    # Testing classes
    assert A in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert J in get_all_subclasses(A)

    assert B in get_all_subclasses(B)
    assert E in get_all_subclasses(B)
    assert G in get_

# Generated at 2022-06-22 21:14:21.848637
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(F):
        pass

    # Ensure that we can retrieve all of the subclasses
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D, E, F, G])
    assert get_all_subclasses(D) == set([E, F, G])
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set([G])


# Generated at 2022-06-22 21:14:32.653635
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(A):
        pass

    class G(A):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class K(A):
        pass

    class J(K):
        pass

    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 9
    assert D in subclasses
    assert E in subclasses
    assert H in subclasses
    assert I in subclasses
    assert J in subclasses
    assert B in subclasses
    assert C in subclasses
    assert F in subclasses

# Generated at 2022-06-22 21:14:43.280110
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Pure unit test for get_all_subclasses
    class A(object):  # pylint:disable=too-few-public-methods
        pass

    class B(A):  # pylint:disable=too-few-public-methods
        pass

    class C(B):  # pylint:disable=too-few-public-methods
        pass

    class D(C):  # pylint:disable=too-few-public-methods
        pass

    class E(D):  # pylint:disable=too-few-public-methods
        pass

    class F(D):  # pylint:disable=too-few-public-methods
        pass

    class G(E):  # pylint:disable=too-few-public-methods
        pass


# Generated at 2022-06-22 21:14:51.092060
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types
    import unittest

    class BaseModule(object):
        pass
    class BaseActionModule(BaseModule):
        pass
    class BaseLookupModule(BaseActionModule):
        pass
    class LookupModule(BaseLookupModule):
        pass
    class ActionModule(BaseActionModule):
        pass
    class Module(BaseModule):
        pass

    class BaseTestCase(unittest.TestCase):
        def test_lookup_module(self):
            expected = set([BaseLookupModule, LookupModule])
            actual = get_all_subclasses(BaseLookupModule)
            self.assertEqual(expected, actual)
        def test_action_module(self):
            expected = set([BaseActionModule, LookupModule, ActionModule])
            actual = get_all_subclasses(BaseActionModule)

# Generated at 2022-06-22 21:14:57.815773
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit tests for function get_all_subclasses

    :rtype: bool
    :returns: True if all test cases pass; otherwise, False
    '''
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(E): pass
    class G(F): pass
    class H(D,G): pass
    assert set(get_all_subclasses(A)) == set([C, E, F, G, H])
    assert set(get_all_subclasses(B)) == set([D, H])
    assert set(get_all_subclasses(C)) == set([E, F, G, H])

# Generated at 2022-06-22 21:15:08.467334
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a class hierarchy
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(object):
        pass
    class F(D):
        pass
    def check_subclasses(class_a, class_b):
        """Check if class_a is a subclass of class_b"""
        return class_b in get_all_subclasses(class_a)

    # Check subclass definition
    assert check_subclasses(A, B)
    assert check_subclasses(A, C)
    assert check_subclasses(A, D)
    assert check_subclasses(A, F)
    assert check_subclasses(B, D)
    assert check_subclasses(B, F)
    assert check

# Generated at 2022-06-22 21:15:17.631040
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    classes = get_all_subclasses(object)
    # Check if all classes or parent class from classes has been found
    assert(A in classes and B in classes and C in classes and D in classes and E in classes)
    # Check if class from other module/frame has been found
    assert(types.ModuleType in classes)
    # Check if class from builtin has been found
    assert(str in classes)

# Generated at 2022-06-22 21:15:27.478620
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C0(object):
        pass

    class C1(C0):
        pass

    class C2(C1):
        pass

    class C3(C1):
        pass

    class C4(C2):
        pass

    class C5(C2):
        pass

    class C6(C4):
        pass

    class C7(C4):
        pass

    class C8(C5):
        pass

    class C9(C5):
        pass

    class C10(C9):
        pass

    class C11(C10):
        pass

    class C12(C11):
        pass

    class C13(C10):
        pass


# Generated at 2022-06-22 21:15:36.097767
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(B):
        pass
    class G(C):
        pass
    class H(D):
        pass

    all_classes = get_all_subclasses(A)
    assert isinstance(all_classes, set)
    assert B in all_classes
    assert C in all_classes
    assert D in all_classes
    assert E in all_classes
    assert F in all_classes
    assert G in all_classes
    assert H in all_classes



# Generated at 2022-06-22 21:15:41.873373
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Tester:
        pass

    class Child1(Tester):
        pass

    class Child2(Tester):
        pass

    class GrandChild(Child1):
        pass

    assert Tester in get_all_subclasses(Tester)
    assert Child1 in get_all_subclasses(Tester)
    assert Child2 in get_all_subclasses(Tester)
    assert GrandChild in get_all_subclasses(Tester)

# Generated at 2022-06-22 21:15:46.280901
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert get_all_subclasses(A) == set([B, C, D])



# Generated at 2022-06-22 21:15:53.160078
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert 'B' in [x.__name__ for x in get_all_subclasses(A)]
    assert 'C' in [x.__name__ for x in get_all_subclasses(A)]
    assert 'D' in [x.__name__ for x in get_all_subclasses(A)]

# Generated at 2022-06-22 21:15:57.460022
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    unit test for function get_all_subclasses
    """

    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(A):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-22 21:16:03.327549
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(C):
        pass

    classes = get_all_subclasses(A)

    expected_classes = set([B, C, D, E, F])

    assert set(classes) == set(expected_classes)


# Generated at 2022-06-22 21:16:13.455196
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    def print_module_paths(cls):
        for subclass in get_all_subclasses(cls):
            print(subclass.__module__ + "." + subclass.__name__)

    # Test class
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    if __name__ == "__main__":
        print("All subclasses of A:")
        print_module_paths(A)
        print("All subclasses of B:")
        print_module_paths(B)
        print("All subclasses of C:")
        print_module_paths(C)
        print("All subclasses of D:")

# Generated at 2022-06-22 21:16:16.795679
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Function used to unit test function get_all_subclasses
    '''
    # This class is used to test the function get_all_subclasses
    class ClassParent:
        '''
        Class used to test get_all_subclasses
        '''

# Generated at 2022-06-22 21:16:22.074038
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for get_all_subclasses function.
    '''
    class A: # pylint: disable=R0903
        pass
    class B(A): # pylint: disable=R0903
        pass
    class C(B): # pylint: disable=R0903
        pass
    class D(B): # pylint: disable=R0903
        pass
    class E(C): # pylint: disable=R0903
        pass
    class F(C): # pylint: disable=R0903
        pass
    class G(D): # pylint: disable=R0903
        pass
    class H: # pylint: disable=R0903
        pass
    all_A_subclasses = get_all_subclasses(A)
    expected_A

# Generated at 2022-06-22 21:16:30.552435
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(G):
        pass
    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 9
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in subclasses
    assert H in subclasses
    assert I in subclasses
    assert J in subclasses
    # Test empty case
    subclasses_empty = get_

# Generated at 2022-06-22 21:16:35.538579
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible_collections.notstdlib.moveitallout.tests._utils.plugins.action.bigip_gtm_wide_ip import ActionModule as TestClass
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.removed import RemovedModule

    assert get_all_subclasses(ActionModule) == {TestClass, RemovedModule}

# Generated at 2022-06-22 21:16:40.562926
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(C): pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G}

# Generated at 2022-06-22 21:16:48.584859
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    E1 = E()
    all_subclasses = get_all_subclasses(A)
    assert C in all_subclasses
    assert D in all_subclasses
    assert E1.__class__ in all_subclasses
    assert B in all_subclasses
    assert A not in all_subclasses

# Generated at 2022-06-22 21:16:51.480672
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    assert set([B, C]) == get_all_subclasses(A)

# Generated at 2022-06-22 21:16:56.448186
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass
    class F(A): pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(F)) == set()

# Generated at 2022-06-22 21:17:05.356393
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(A):
        pass
    class F(B):
        pass
    class G(F):
        pass
    class H(E, C):
        pass
    class I(H):
        pass

    result = get_all_subclasses(A)
    assert B in result
    assert C in result
    assert D in result
    assert E in result
    assert F in result
    assert G in result
    assert H in result
    assert I in result

# Generated at 2022-06-22 21:17:15.548593
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Defining a class hierarchy to use for unit tests.
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(B):
        pass

    class G(C):
        pass

    class H(C):
        pass

    class I(D):
        pass

    # Unit test the function
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I])
    assert get_all_subclasses(B) == set([E, F])
    assert get_all_subclasses(C) == set([G, H])
    assert get_all_subclasses(D) == set([I])



# Generated at 2022-06-22 21:17:25.542777
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    The following is a basic unit test which demonstrates the get_all_subclasses function.  The test constructs the following
    class hierarchy:

    Base
        |
        |__
        |   |__ A1
        |   |__ A2
        |        |__ B1
        |        |__ B2
        |        |__ B3
        |
        |__ C1
        |
        |__ D1
            |__ E1

    The test then compares the results of get_all_subclasses to the constructed class hierarchy.
    '''
    class Base(object):
        pass
    class A1(Base):
        pass
    class A2(Base):
        pass
    class B1(A2):
        pass
    class B2(A2):
        pass

# Generated at 2022-06-22 21:17:32.544656
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestClassA:
        pass

    class TestClassB:
        pass

    class TestClassC(TestClassA, TestClassB):
        pass

    class TestClassD(TestClassA):
        pass

    assert get_all_subclasses(TestClassA) == set([TestClassC, TestClassD])
    assert get_all_subclasses(TestClassB) == set([TestClassC])
    assert get_all_subclasses(TestClassC) == set([])
    assert get_all_subclasses(TestClassD) == set([])

# Generated at 2022-06-22 21:17:37.119993
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    loader_sub_classes = get_all_subclasses(DataLoader)
    assert AnsibleDumper in loader_sub_classes



# Generated at 2022-06-22 21:17:46.606843
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections

    # Create a parent class
    class Parent:
        pass

    # Create a child class
    class Child(Parent):
        pass

    # Create a grandchild class
    class GrandChild(Child):
        pass

    subclasses = get_all_subclasses(Parent)

    # These classes should all exist in the list of subclasses
    for cls in [Parent, Child, GrandChild]:
        assert cls in subclasses

    # Test with a non-class parameter
    assert get_all_subclasses(collections) == set()

    # Test with an empty class
    assert get_all_subclasses(object) == set()

# Generated at 2022-06-22 21:17:51.082919
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # create some classes
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(D):
        pass
    # create some classes without inheritance
    class G(object):
        pass
    class H(object):
        pass
    class I(object):
        pass
    # call function
    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(G) == set()
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(G) == set()

# Generated at 2022-06-22 21:18:01.590297
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass
    expected = set([B,D,C,E,F])
    # By default, you get the first-level subclasses
    assert A.__subclasses__() == [B, C], 'test_get_all_subclasses: first level subclasses'
    # Check that get_all_subclasses return expected subclasses for class A
    assert get_all_subclasses(A) == expected, 'test_get_all_subclasses: recursive subclasses'
    # Check when used with a new class

# Generated at 2022-06-22 21:18:10.476505
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a fake class hierarchy
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    # Testing that we find all the classes
    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E])
    # Slicing to make sure we cope with non-list objects
    assert list(get_all_subclasses(A))[:1] == [B]


# Generated at 2022-06-22 21:18:21.797857
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    ''' test_get_all_subclasses is a utility function used to test get_all_subclasses.
        This is a very simple test, with no test discovery.
    '''
    # Example of class tree to test
    #         A
    #  B            C
    #    D       E    F
    #        G    H
    #       I
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(E):
        pass

    class H(E):
        pass

    class I(G):
        pass

    # This is what we expect

# Generated at 2022-06-22 21:18:33.372547
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Foo(object):
        pass

    class Bar(Foo):
        def __init__(self):
            pass

    class Baz(Foo):
        def __init__(self):
            pass

    class Zab(object):
        def __init__(self):
            pass

    class Zul(Zab):
        def __init__(self):
            pass

    class Zan(Zab):
        def __init__(self):
            pass

    class Zod(Zab):
        def __init__(self):
            pass

    class Zol(Zod):
        def __init__(self):
            pass

    class Zil(Zol):
        def __init__(self):
            pass

    assert set(get_all_subclasses(Foo)) == set([Bar, Baz])
    assert set

# Generated at 2022-06-22 21:18:42.174336
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test for get_all_subclasses for a simple inheritance

    :rtype: None
    :returns: Nothing

    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    # Set of expected subclasses
    expected = {B, C, D, E}
    
    # Assertion
    assert(expected == get_all_subclasses(A))

# Generated at 2022-06-22 21:18:44.997033
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    assert get_all_subclasses(A) == {B, C}



# Generated at 2022-06-22 21:18:53.236886
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(B): pass
    class E(C, D): pass

    class F(C): pass

    assert C in get_all_subclasses(A)
    assert D not in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert D in get_all_subclasses(B)
    assert E in get_all_subclasses(B)
    assert F not in get_all_subclasses(B)

# Generated at 2022-06-22 21:18:58.354656
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass  # direct subclass
    class C(A): pass  # direct subclass
    class D(C): pass  # indirect subclass
    class E(B): pass  # indirect subclass
    class F(D): pass  # indirect subclass
    result = set([B, C, D, E, F])
    assert get_all_subclasses(A) == result

# Generated at 2022-06-22 21:19:08.075621
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import yaml
    # Create a test class to find subclasses of
    class TestClass(object):
        pass

    # Create some children of TestClass
    class TestClassChild1(TestClass):
        pass

    class TestClassChild2(TestClass):
        pass

    # Ensure that these TestClassChildren don't show up
    class TestClassGrandchild1(TestClassChild1):
        pass

    class TestClassGrandchild2(TestClassChild2):
        pass

    # Add a child class of TestClassChild1 and TestClassGrandchild1
    class TestClassGreatGrandchild1(TestClassGrandchild1):
        pass

    # Test that all subclasses of TestClass are as expected

# Generated at 2022-06-22 21:19:15.339956
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    
    subclasses = get_all_subclasses(A)
    assert set(subclasses) == set([B, C, D, E])

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-22 21:19:25.003114
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(D, E):
        pass

    class H(D, F):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])
    assert get_all_subclasses(B) == set([D, G])
    assert get_all_subclasses(C) == set([E, F])
    assert get_all_subclasses(D) == set([G])
    assert get_all_subclasses(E) == set([G])

# Generated at 2022-06-22 21:19:33.622868
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import Mock
    # Create dummy base class
    base = Mock()
    # Create dummy child class
    child1 = Mock()
    child2 = Mock()
    child3 = Mock()
    # Create dummy children of children
    grandchild1 = Mock()
    grandchild2 = Mock()
    # Create dummy grandchild of grandchild
    greatgrandchild1 = Mock()
    # Register all subclasses
    child1.__class__.__subclasses__ = Mock(return_value=[])
    child2.__class__.__subclasses__ = Mock(return_value=[grandchild1, grandchild2])
    grandchild1.__class__.__subclasses__ = Mock(return_value=[])
    grandchild2.__class__

# Generated at 2022-06-22 21:19:36.153723
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    l = [A, B, C, D]
    assert sorted(l) == sorted(get_all_subclasses(A))

# Generated at 2022-06-22 21:19:41.158049
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    class F(E):
        pass
    return get_all_subclasses(A) == set([B, C, D, E, F])