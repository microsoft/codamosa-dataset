

# Generated at 2022-06-22 21:09:46.783388
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class TestParent(object):
        pass

    class TestChild1(TestParent):
        pass

    class TestChild2(TestParent):
        pass

    class TestGrandChild1(TestChild1):
        pass

    class TestGrandChild2(TestChild1):
        pass

    class TestGreatGrandChild1(TestGrandChild1):
        pass

    class TestGreatGrandChild2(TestGrandChild1):
        pass

    # This is the set of all classes that should be retrieved from TestParent
    all_subclasses = set([
        TestChild1,
        TestChild2,
        TestGrandChild1,
        TestGrandChild2,
        TestGreatGrandChild1,
        TestGreatGrandChild2,
    ])

    # Check that the function returns only expected classes

# Generated at 2022-06-22 21:09:52.500644
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(object):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-22 21:10:03.573494
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test get_all_subclasses function
    """
    class Base(object):
        """
        Base class for test
        """
        pass

    class Child1_1(Base):
        """
        Child class of Base
        """
        pass

    class Child1_2(Base):
        """
        Child class of Base
        """
        pass

    class Child2_1(Child1_1):
        """
        Child class of Child1_1
        """
        pass

    class Child2_2(Child1_1):
        """
        Child class of Child1_1
        """
        pass

    # Need to use list because class objects are not hashable in Python 3
    # http://stackoverflow.com/a/10473850/1354696

# Generated at 2022-06-22 21:10:08.869277
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(A, B):
        pass
    class F(A, D):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-22 21:10:14.498718
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(object): pass
    classes = get_all_subclasses(A)
    assert C in classes, 'class C should be in classes'
    assert D in classes, 'class D should be in classes'
    assert E not in classes, 'class E should not be in classes'

# Generated at 2022-06-22 21:10:19.856845
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(A, B):
        pass
    class E(D):
        pass
    class F(C, D):
        pass
    class G(E):
        pass
    class H(F):
        pass

    # Ensure we correctly find our way through the tree
    assert H in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert G in get_all_subclasses(A)

# Generated at 2022-06-22 21:10:25.562919
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # This function is to be used only in unit testing
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(C): pass
    class F(B, D, E): pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-22 21:10:31.735332
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(E): pass
    class G(C): pass
    subclasses = get_all_subclasses(A)

    assert len(subclasses) == 7
    for c in [B,C,D,E,F,G]:
        assert c in subclasses

# Generated at 2022-06-22 21:10:37.046602
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import doctest

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(B):
        pass

    doctest.testmod()
    assert set(get_all_subclasses(A)) == set([A, B, C, D, E, F])

# Generated at 2022-06-22 21:10:42.238919
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(D):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert get_all_subclasses(A) == get_all_subclasses(B)
    assert get_all_subclasses(E) == [E]



# Generated at 2022-06-22 21:10:48.036273
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function get_all_subclasses
    '''

    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(C):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D, E, F}

# Generated at 2022-06-22 21:10:55.981795
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function get_all_subclasses
    '''

    # Create a test class hierarchy
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass
    class F(C,D): pass
    class G(D,E): pass
    class H(G): pass

    expected = set([B, C, D, E, F, G, H])
    # Ignore python implementation class for the sake of the test
    # eg: class 'abc.ABCMeta' has no '__subclasses__' member
    actual = set([x for x in get_all_subclasses(A) if '__subclasses__' in dir(x)])

    assert expected == actual

# Generated at 2022-06-22 21:11:00.924242
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(A, B): pass
    class D(C): pass

    assert(set(get_all_subclasses(C)) == set([D]))
    assert(set(get_all_subclasses(D)) == set())
    assert(set(get_all_subclasses(A)) == set([B, C, D]))

# Generated at 2022-06-22 21:11:11.569242
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # class PyBase(Base)
    PyBase = type('PyBase', (object,), {})
    # class PyChildA(PyBase)
    PyChildA = type('PyChildA', (PyBase,), {})
    # class PyChildB(PyBase)
    PyChildB = type('PyChildB', (PyBase,), {})
    # class PyChildC(PyBase)
    PyChildC = type('PyChildC', (PyBase,), {})
    # class PyChildD(PyChildC)
    PyChildD = type('PyChildD', (PyChildC,), {})

    assert PyChildA in get_all_subclasses(PyBase)
    assert PyChildB in get_all_subclasses(PyBase)
    assert PyChildC in get_all_subclasses(PyBase)
   

# Generated at 2022-06-22 21:11:17.659012
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.plugins.loader import shared_loader, action_loader

    def test_class():
        pass

    def test_class2():
        pass

    class test_class3(test_class):
        pass

    class test_class4(test_class2):
        pass

    class test_class5(test_class4):
        pass

    assert test_class3 in test_class.__subclasses__()
    assert test_class4 in test_class2.__subclasses__()
    assert test_class5 in test_class4.__subclasses__()
    assert test_class5 in test_class2.__subclasses__()
    assert test_class5 not in test_class.__subclasses__()

    assert test_class3 in get_all_subclasses(test_class)
    assert test_class4

# Generated at 2022-06-22 21:11:28.312266
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(E):
        pass

    #Testing if we get all the subclasses of A
    assert(get_all_subclasses(A) == set([B, C, D, E, F]))
    #Testing if we get all the subclasses of B
    assert(get_all_subclasses(B) == set([C]))
    assert(get_all_subclasses(C) == set([]))
    #Testing if we get all the subclasses of D
    assert(get_all_subclasses(D) == set([E, F]))

# Generated at 2022-06-22 21:11:35.558070
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys
    import unittest

    # Sample data
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(A): pass
    class E(B): pass
    class F(B): pass
    class G(C): pass
    class H(C): pass
    class I(D): pass
    class J(D): pass
    class K(D): pass

    # Unit test
    class TestGetAllSubclasses(unittest.TestCase):
        def test(self):
            subclasses = get_all_subclasses(A)
            self.assertListEqual(sorted(subclasses, key=lambda c: c.__name__), [B, C, D, E, F, G, H, I, J, K])


# Generated at 2022-06-22 21:11:43.659142
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import ansible.module_utils.basic
    import ansible.module_utils.facts.system.aix
    import ansible.module_utils.facts.system.bsd
    import ansible.module_utils.facts.system.debian
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.freebsd
    import ansible.module_utils.facts.system.hpux
    import ansible.module_utils.facts.system.linux
    import ansible.module_utils.facts.system.netbsd
    import ansible.module_utils.facts.system.openbsd
    import ansible.module_utils.facts.system.openindiana
    import ansible.module_utils.facts.system.opensolaris

# Generated at 2022-06-22 21:11:47.563738
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(B):
        pass
    assert set([A, B, C]) == get_all_subclasses(A)

# Generated at 2022-06-22 21:11:55.311787
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''Unit tests for get_all_subclasses
    '''
    class DummyClass(object):
        '''Class for test'''

    class DummySubclass(DummyClass):
        '''Class for test'''

    class DummySubclass2(DummyClass):
        '''Class for test'''

    class DummySubclass3(DummySubclass):
        '''Class for test'''

    assert get_all_subclasses(DummyClass) == set([DummySubclass,
                                                  DummySubclass2,
                                                  DummySubclass3])

# Generated at 2022-06-22 21:12:05.245204
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import os
    import sys
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D):
        pass

    subclasses_ref = {D, E, B, C}

    class TestGetAllSubclasses(unittest.TestCase):
        def test_subclasses_of_object(self):
            subclasses = get_all_subclasses(object)
            self.assertEqual(subclasses, subclasses_ref)

        def test_subclasses_of_A(self):
            subclasses = get_all_subclasses(A)
            self.assertEqual(subclasses, subclasses_ref)


# Execute the unittests

# Generated at 2022-06-22 21:12:11.802537
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # This unit test is a little weird because of the way classes are created in Python
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-22 21:12:18.432191
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(A): pass
    class F(E): pass
    res = get_all_subclasses(A)
    assert B in res
    assert C in res
    assert D in res
    assert E in res
    assert F in res
    assert len(res) == 5
    assert len(set(get_all_subclasses(object))) > 100  # nosec

# Generated at 2022-06-22 21:12:25.168673
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class TestGetAllSubclasses(unittest.TestCase):
        def test_return_classes(self):
            excepted = [B, C, D, E, F, G]
            result = get_all_subclasses(A)
            self.assertEqual(set(result), set(excepted))

    return unittest.main()

# Generated at 2022-06-22 21:12:31.683899
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set([F])
    assert list(get_all_subclasses(D)) == []

# Generated at 2022-06-22 21:12:41.785908
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(object):
        pass

    class TestClass(unittest.TestCase):
        def test_same_level(self):
            # A => B, C
            self.assertEqual(set(get_all_subclasses(A)), {B, C})

        def test_different_level(self):
            # A => B, C => D, E
            self.assertEqual(set(get_all_subclasses(A)), {B, C, D, E})
            self.assertEqual(set(get_all_subclasses(B)), {D})

# Generated at 2022-06-22 21:12:53.260172
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass

    """
        The graph looks like this:

        A
        | \
        B  C
        |   |
        D   E
         \ /
          F
    """

    assert set(A.__subclasses__()) == set([B, C])
    assert set(B.__subclasses__()) == set([D])
    assert set(C.__subclasses__()) == set([E])
    assert set(D.__subclasses__()) == set()
    assert set(E.__subclasses__()) == set([F])
    assert set(F.__subclasses__())

# Generated at 2022-06-22 21:12:59.107419
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-22 21:13:06.207419
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test get_all_subclasses
    '''
    from ansible.plugins.loader import module_loader

    parent_class_name = 'Raw'
    parent_class = module_loader._get_plugin_class('ansible.modules.files.raw', parent_class_name)
    all_descendent_classes = get_all_subclasses(parent_class)
    assert len(all_descendent_classes) > 0
    for cls in all_descendent_classes:
        assert issubclass(cls, parent_class)


# Generated at 2022-06-22 21:13:10.309164
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    classes = set([A, B, C])
    assert classes == get_all_subclasses(A)
    assert set([C]) == get_all_subclasses(B)
    assert set() == get_all_subclasses(C)

# Generated at 2022-06-22 21:13:13.344010
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(B):
        pass
    class F(D):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-22 21:13:22.982682
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class AB(A):
        pass
    class D(A):
        pass
    class AC(A):
        pass
    class AD(A):
        pass
    class AE(A):
        pass
    class AF(A):
        pass
    class AA(A):
        pass
    class ABB(A):
        pass
    class ABC(A):
        pass
    class ACD(A):
        pass
    class ACE(A):
        pass
    class AAB(A):
        pass
    class AAC(A):
        pass

    assert set([B, C, AB, ABB, ABC]) == get_all_subclasses(B)

# Generated at 2022-06-22 21:13:33.470590
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(A):
        pass

    class G(D):
        pass

    class H(F):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(F):
        pass

    class L(F):
        pass

    class M(L):
        pass

    # Do not delete or change the order of the following classes
    # This is necessary to check the different results of the recursion
    # with the same tree structure
    class X(object):
        pass
    class Y(X):
        pass

# Generated at 2022-06-22 21:13:41.295317
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a(object):
        pass
    class a1(a):
        pass
    class a2(a):
        pass
    class a3(a):
        pass
    class a11(a1):
        pass
    class a12(a1):
        pass
    class a121(a12):
        pass
    class a13(a1):
        pass
    class a131(a13):
        pass
    class a132(a13):
        pass
    class a21(a2):
        pass
    class a22(a2):
        pass
    class a23(a2):
        pass
    class b(object):
        pass
    class b1(b):
        pass
    class b2(b):
        pass


# Generated at 2022-06-22 21:13:47.101748
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D}
    assert set(get_all_subclasses(C)) == {D}
    assert set(get_all_subclasses(E)) == set()



# Generated at 2022-06-22 21:13:58.814333
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Minimal unittest for function get_all_subclasses
    '''
    import doctest
    import inspect

    def get_data():
        '''
        :rtype: tuple
        :returns: tuple containing:
            - The mocked class "A"
            - The mocked class "B"
            - The mocked class "C"
            - The mocked class "D"
            - The mocked class "E"
            - The mocked class "F"
        '''
        # Class A is intended to have no subclass
        class A(object):
            pass

        # Class B is intended to have one subclass: C
        class B(object):
            pass

        # Class C is intended to have two subclasses: D and E
        class C(object):
            pass

        # Class D is intended to have one subclass: F

# Generated at 2022-06-22 21:14:06.302728
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define parent class
    class A(object):
        pass

    # Define child class
    class B(A):
        pass

    # Define child of child class
    class C(B):
        pass

    # Define child of child of child class
    class D(C):
        pass

    assert set([B]) == set(get_all_subclasses(A))
    assert set([C, D]) == set(get_all_subclasses(B))
    assert set([D]) == set(get_all_subclasses(C))
    assert set() == set(get_all_subclasses(D))

# Generated at 2022-06-22 21:14:08.833197
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass

    assert set(get_all_subclasses(A)) == set([B, C, D])

# Generated at 2022-06-22 21:14:13.478083
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(A):
        pass
    class F(E):
        pass
    class G(E):
        pass
    class H(G):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])

# Generated at 2022-06-22 21:14:17.570711
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(C):
        pass
    class F(B):
        pass
    assert get_all_subclasses(A) == {C, D, E}

# Generated at 2022-06-22 21:14:22.966355
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_text
    import sys

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(object):
        pass

    assert get_all_subclasses(A) == set((B, C)), 'Expected %s, but got %s' % (set((B, C)), get_all_subclasses(A))
    assert get_all_subclasses(D) == set(), 'Expected %s, but got %s' % (set(), get_all_subclasses(D))

    class E(object):
        pass

    class F(E):
        pass


# Generated at 2022-06-22 21:14:28.646798
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(F):
        pass

    class H(F):
        pass

    assert set([B, D, E, G, H]) == get_all_subclasses(A)
    assert set([B]) == get_all_subclasses(B)
    assert set([D, E, G, H]) == get_all_subclasses(C)
    assert set([]) == get_all_subclasses(D)
    assert set([]) == get_all_subclasses(G)

test_get_all_subclasses()

# Generated at 2022-06-22 21:14:36.182041
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(G):
        pass

    subs = get_all_subclasses(A)
    assert B in subs
    assert C in subs
    assert D in subs
    assert E in subs
    assert F in subs
    assert G in subs
    assert H in subs

# Generated at 2022-06-22 21:14:46.938789
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections
    import unittest
    class A(object):
        pass
    class A0(A):
        pass
    class A1(A0):
        pass
    class A3(A0):
        pass
    class A4(A3):
        pass
    class A2(A1, A3):
        pass
    class B(A, A1):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    # Creating class tree of A, B, C, D, E, A0, A1, A2, A3, A4
    # Compare the result with the expected result
    # Create the expected result

# Generated at 2022-06-22 21:14:57.586909
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import itertools
    def print_cls(cls, level=0):
        print('{} {}'.format(cls.__name__, ' ' * (2 * level)))

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(E):
        pass

    class G(D):
        pass

    class H(object):
        pass

    class I(H):
        pass

    class J(H):
        pass

    class K(H):
        pass

    class L(K):
        pass

    # Make sure that the function works correctly with multiple inheritance
    class M(K, L, I):
        pass

    # Make sure that the

# Generated at 2022-06-22 21:15:03.763064
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D):
        pass

    class F(object):
        pass

    assert get_all_subclasses(B) == {D, E}
    assert get_all_subclasses(C) == {D, E}
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()


# Generated at 2022-06-22 21:15:10.005802
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Ensure the get_all_subclasses() function properly searches for classes.
    """

    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([C])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-22 21:15:14.814060
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass

    a_subclasses = get_all_subclasses(A)
    assert a_subclasses == set([B, C, D, E])

# Generated at 2022-06-22 21:15:26.062228
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections
    import types

    # Testing get_all_subclasses
    class not_extending:
        pass

    class awesome(not_extending):
        pass

    class awesome_bis(not_extending):
        pass

    class python(awesome):
        pass

    class dynamic(awesome_bis):
        pass

    class ugly(awesome, collections.Sequence):
        pass

    # Important note on testing
    # Unfortunately, there is a bug in unittest regarding the comparison of
    # classes. To make a long story short, it is impossible to test if
    # python in (awesome, awesome_bis)
    # So we have to check each class separately
    classes = get_all_subclasses(not_extending)
    assert len(classes) == 3
    assert awesome in classes
    assert awesome_bis

# Generated at 2022-06-22 21:15:34.790481
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class First(object):
        pass

    class Second(First):
        pass

    class Third(First):
        pass

    class Fourth(Third):
        pass

    class Fifth(Third):
        pass

    assert set(get_all_subclasses(First)) == set([Second, Third, Fourth, Fifth])
    assert set(get_all_subclasses(Second)) == set()
    assert set(get_all_subclasses(Third)) == set([Fourth, Fifth])
    assert set(get_all_subclasses(Fourth)) == set()
    assert set(get_all_subclasses(Fifth)) == set()

# Generated at 2022-06-22 21:15:45.152790
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins import module_loader

    m_path = module_loader._load_paths[0]
    m_factory = module_loader._get_all_plugin_loaders(m_path)[0]
    modules = list(m_factory.all(class_only=True))

    # Class children
    children = set()
    for child in modules:
        try:
            children = children.union(set(child.__subclasses__()))
        except TypeError:
            pass

    # Sub classes
    real_subclasses = set()
    for child in modules:
        real_subclasses = real_subclasses.union(get_all_subclasses(child))

   

# Generated at 2022-06-22 21:15:53.571584
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class X(object):
        pass

    class Y(X):
        pass

    class Z(Y):
        pass

    class W(Z):
        pass

    class V(object):
        pass

    assert set(get_all_subclasses(X)) == {V, W, Z, Y}

    class X(object):
        pass

    class Y(X):
        pass

    class Z(X):
        pass

    class W(object):
        pass

    assert set(get_all_subclasses(X)) == {W, Z, Y}

# Generated at 2022-06-22 21:16:03.878925
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])
    assert get_all_subclasses(B) == set([D, H])
    assert get_all_subclasses(C) == set([E, F, G])
    assert get_all_subclasses(D) == set([H])
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-22 21:16:10.983487
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class BB(B):
        pass

    class BC(B):
        pass

    class CC(C):
        pass

    # Retrieve all subclasses
    subclasses = get_all_subclasses(A)
    # Expected result
    expected = frozenset((B, C, BB, BC, CC))
    # Test result
    assert subclasses == expected


# Generated at 2022-06-22 21:16:17.444097
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test get_all_subclasses function
    """
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(C):
        pass

    assert set(get_all_subclasses(A)) == set((A, B, D, E, C, F))
    assert set(get_all_subclasses(F)) == set((F,))
    assert set(get_all_subclasses(E)) == set((E,))

__all__ = ['get_all_subclasses']

# Generated at 2022-06-22 21:16:28.228481
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(object):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    assert get_all_subclasses(object) == set()
    assert get_all_subclasses(A) == set([B, D, F])
    assert get_all_subclasses(B) == set([D, F])
    assert get_all_subclasses(C) == set([E])
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-22 21:16:35.126121
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass

    subclasses = get_all_subclasses(A)
    assert subclasses == set([B, C, D, E, F, G])
    subclasses = get_all_subclasses(D)
    assert subclasses == set([F])
    subclasses = get_all_subclasses(E)
    assert subclasses == set([G])

    subclasses = get_all_subclasses(object)
    assert subclasses == set([A, B, C, D, E, F, G])

# Generated at 2022-06-22 21:16:39.556926
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    assert(set(get_all_subclasses(A)) == {B, C, D, E, F})

    try:
        get_all_subclasses(F)
    except:
        raise AssertionError("Cannot use get_all_subclasses with leaf class")



# Generated at 2022-06-22 21:16:44.206131
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass

    assert set([B, D]) == get_all_subclasses(A)

'''
TODO Remove this once we are ready to go away from deprecated modules
'''

# Generated at 2022-06-22 21:16:54.671920
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(F):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in subclasses
    assert H in subclasses
    assert len(subclasses) == 7

    subclasses = get_all_subclasses(B)
    assert D in subclasses
    assert E in subclasses
    assert len(subclasses) == 2

    subclasses = get_all_

# Generated at 2022-06-22 21:17:05.755928
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test get_all_subclasses
    '''
    class A(object):
        ''' A is parent class '''
        pass

    class B(A):
        ''' B is child class '''
        pass

    class C(A):
        ''' C is child class '''
        pass

    class D(B):
        ''' D is Dchild class '''
        pass

    class E(B):
        ''' E is child class '''
        pass

    class F(B):
        ''' F is child class '''
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, E, F])

# Generated at 2022-06-22 21:17:12.002856
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    # Define subclasses
    class C(A):
        class C1(B): pass
        class C2(B): pass
    # Define a lone class
    class LoneClass(object): pass

    # Test 1
    assert set(get_all_subclasses(A)) == {B, C.C1, C.C2, C}
    # Test 2
    assert set(get_all_subclasses(LoneClass)) == set()

# Generated at 2022-06-22 21:17:20.942148
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(object):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(B):
        pass

    ans = get_all_subclasses(A)
    to_compare_number = len(ans)
    should_be_number = 5

    assert to_compare_number == should_be_number
    assert B in ans
    assert C in ans
    assert E in ans
    assert F in ans
    assert G in ans

# Generated at 2022-06-22 21:17:27.712100
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B1(A):
        pass
    class B2(A):
        pass
    class B3(A):
        pass
    class C1(B1):
        pass
    class C2(B1):
        pass
    class C3(B2):
        pass
    class D1(C1):
        pass
    subclasses = get_all_subclasses(A)
    assert B1 in subclasses
    assert B2 in subclasses
    assert B3 in subclasses
    assert C1 in subclasses
    assert C2 in subclasses
    assert C3 in subclasses
    assert D1 in subclasses

# Generated at 2022-06-22 21:17:36.608196
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
        Testing the function get_all_subclasses.
    """

    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert A not in get_all_subclasses(A)



# Generated at 2022-06-22 21:17:42.077298
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a(object):
        pass
    class c(a):
        pass
    class d(c):
        pass
    class b(object):
        pass
    subclasses = get_all_subclasses(a)
    assert c in subclasses
    assert d in subclasses
    assert b not in subclasses


# Duplicate of the function in module_utils/basic.py to avoid dependency

# Generated at 2022-06-22 21:17:47.021234
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(B): pass

    assert set(get_all_subclasses(A)) == {B, C, D, E}

# Generated at 2022-06-22 21:17:51.809061
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a(object): pass
    class b(a): pass
    class c(a): pass
    class d(c): pass
    class e(b): pass
    classes = get_all_subclasses(a)
    assert b in classes
    assert c in classes
    assert d in classes
    assert e in classes
    assert not (a in classes)
    assert len(classes) == 4

# Generated at 2022-06-22 21:17:55.499808
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class ParentClass:
        pass

    class ChildClass(ParentClass):
        pass

    class GrandChildClass(ChildClass):
        pass

    assert set([ParentClass, ChildClass, GrandChildClass]) == get_all_subclasses(ParentClass)

# Generated at 2022-06-22 21:18:02.669322
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(A):
        pass
    class F(object):
        pass
    class G(F):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(F) == {G}

# Generated at 2022-06-22 21:18:10.014136
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    assert get_all_subclasses(A) == {B, C, D}
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == {D}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-22 21:18:19.090985
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(E):
        pass
    class G(E):
        pass
    class H(D, G):
        pass
    classes = [A, B, C, D, E, F, G, H]
    assert set(classes) == set(get_all_subclasses(A))
    classes.remove(A)
    assert set(classes) == set(get_all_subclasses(E))

# Generated at 2022-06-22 21:18:23.981935
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base: pass
    class A(Base): pass
    class B(Base): pass
    class C(Base): pass
    class D(A): pass
    class E(B): pass
    class F(A): pass
    assert get_all_subclasses(Base) == set((A, B, C, D, E, F))

# Generated at 2022-06-22 21:18:35.657263
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Mapping, MutableMapping, MappingView
    from ansible.module_utils._text import to_text

    def _mutable_mapping_to_dict(instance):
        # MappingView has no items method
        if not isinstance(instance, MappingView):
            return dict(instance.items())
        else:
            return instance

    def _compare_objs(expected, actual):
        if isinstance(expected, Mapping):
            return _mutable_mapping_to_dict(expected) == _mutable_mapping_to_dict(actual)
        else:
            return expected == actual

    class DummyClass1(object):
        pass

    dummy_obj1 = DummyClass1()
    dummy_obj2 = DummyClass1()


# Generated at 2022-06-22 21:18:46.743674
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for :py:func:`get_all_subclasses`
    '''
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    assert len(get_all_subclasses(A)) == 1
    assert len(get_all_subclasses(B)) == 1
    assert len(get_all_subclasses(C)) == 1
    assert len(get_all_subclasses(D)) == 1
    assert len(get_all_subclasses(E)) == 0
    assert len(get_all_subclasses(F)) == 0
    assert D in get_all_subclasses(B)
    assert F

# Generated at 2022-06-22 21:18:57.238423
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from _utils import get_all_subclasses

    class A(object):
        pass
    class B(object):
        pass
    class C1(A):
        pass
    class C2(A):
        pass
    class D1(B):
        pass
    class D2(B):
        pass
    class E(C2):
        pass
    class F(D1):
        pass
    class G(E, F):
        pass
    class H(G):
        pass
    class U(object):
        pass

    # Manual check
    assert set(get_all_subclasses(A)) == {C1, C2, E, G, H}
    assert set(get_all_subclasses(B)) == {D1, D2, F, G, H}

# Generated at 2022-06-22 21:19:02.234123
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    a_subclasses = get_all_subclasses(A)
    assert a_subclasses == set([B, C, D, E])
    b_subclasses = get_all_subclasses(B)
    assert b_subclasses == set([D, E])



# Generated at 2022-06-22 21:19:08.213469
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class super_class(): pass
    class A(super_class): pass
    class B(super_class): pass
    class C(A): pass
    class D(A): pass
    class E(C): pass
    class F(E): pass

    assert get_all_subclasses(super_class) == {A, B, C, D, E, F}
    assert get_all_subclasses(C) == {E, F}
    assert get_all_subclasses(F) == set()
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-22 21:19:19.009987
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    test_get_all_subclasses
    '''
    # Create a mock class structure
    class one(object):
        '''
        one
        '''
    class two(one):
        '''
        two
        '''
    class three(one):
        '''
        three
        '''
    class four(two):
        '''
        four
        '''
    class five(three):
        '''
        five
        '''
    class six(two):
        '''
        six
        '''

    # Get all subclasses
    all_subclasses = get_all_subclasses(one)
    # Only return six subclasses
    assert len(all_subclasses) == 6
    # Make sure all subclasses are in the set
    assert two in all_subclasses
   

# Generated at 2022-06-22 21:19:26.583568
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create test class
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(B): pass
    class F(E): pass
    class G(D): pass
    class H(B, D): pass
    class I(E, F): pass
    # Test correct subclasses
    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert G in get_all_subclasses(A)

# Generated at 2022-06-22 21:19:35.954162
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(object):
        pass

    class F(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set([])