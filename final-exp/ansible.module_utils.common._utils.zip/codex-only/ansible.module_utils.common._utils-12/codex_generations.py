

# Generated at 2022-06-22 21:09:47.974012
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a tree of classes to test the function
    class X:
        pass
    class X0(X):
        pass
    class X1(X):
        pass
    class X10(X1):
        pass
    class X20(X1):
        pass
    class X200(X20):
        pass

    # Test if we find all descendants of X
    subclasses = get_all_subclasses(X)
    assert X0 in subclasses
    assert X1 in subclasses
    assert X10 in subclasses
    assert X20 in subclasses
    assert X200 in subclasses
    # Test if we find all descendants of X10
    subclasses = get_all_subclasses(X10)
    assert X200 not in subclasses

# Generated at 2022-06-22 21:09:55.263297
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(object):
        pass
    assert(set(get_all_subclasses(A)) == set([B, C, D]))
    assert(set(get_all_subclasses(A)) != set([B, C, E]))
    assert(set(get_all_subclasses(A)) != set([B, C, D, E]))

# Generated at 2022-06-22 21:09:58.418303
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    assert(B in get_all_subclasses(A))
    assert(C in get_all_subclasses(A))

# Generated at 2022-06-22 21:10:04.052217
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(D,E):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F])

# Generated at 2022-06-22 21:10:11.086192
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(A):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(E):
        pass

    assert get_all_subclasses(A) == set([C, E, F, H])
    assert get_all_subclasses(B) == set([D, G])

# Generated at 2022-06-22 21:10:15.797021
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(object):
        pass

    subclasses = get_all_subclasses(A)
    assert D in subclasses
    assert E not in subclasses



# Generated at 2022-06-22 21:10:23.603015
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C(object):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(C):
        pass

    classes = get_all_subclasses(C)
    # Check for the correct number of subclasses
    assert len(classes) == 3
    assert D in classes
    assert E in classes
    assert F in classes

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-22 21:10:32.147805
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        def __init__(self):
            pass
    class B(A):
        def __init__(self):
            pass
    class C(B):
        def __init__(self):
            pass
    class D(A):
        def __init__(self):
            pass
    class E(D):
        def __init__(self):
            pass
    class F(D):
        def __init__(self):
            pass
    class G(F):
        def __init__(self):
            pass
    for c in get_all_subclasses(A):
        assert issubclass(c, A)

# Generated at 2022-06-22 21:10:37.081150
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(B):
        pass
    class F(B):
        pass
    class G(F):
        pass

    test_set = get_all_subclasses(A)
    assert test_set == {D, E, G}



# Generated at 2022-06-22 21:10:41.961382
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert get_all_subclasses(A) == set((B, C, D))
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set((D,))
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-22 21:10:49.792137
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a simple class
    class A(object):
        pass
    # Create a subclass of it
    class B(A):
        pass
    # Create another subclass of it
    class C(B):
        pass
    # The class A has two subclasses: B and C
    assert get_all_subclasses(A) == set([B, C])
    # The class B has one subclass: C
    assert get_all_subclasses(B) == set([C])
    # The class C has no subclass
    assert get_all_subclasses(C) == set()

# Generated at 2022-06-22 21:11:01.208575
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Parent class
    class Parent:
        pass

    # Child class
    class Child(Parent):
        pass

    # GrandChild class
    class GrandChild(Child):
        pass

    # Hidden child class (no direct instance)
    class HiddenChild(Child):
        pass

    # Great grandchild class
    class GreatGrandChild(GrandChild):
        pass

    # Test for an empty set of subclasses
    assert set() == get_all_subclasses(object)

    # Test for one subclass
    assert compare_subclasses(set([Child]), get_all_subclasses(Parent))

    # Test for three subclasses
    assert compare_subclasses(set([Child, GrandChild, GreatGrandChild]), get_all_subclasses(Parent))

    # Test for subclasses of a subclass

# Generated at 2022-06-22 21:11:10.730387
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    A function to test get_all_subclasses function
    '''

    class A(object):
        '''
        The base class
        '''
        pass

    class B(A):
        '''
        A subclass of A
        '''
        pass

    class C(A):
        '''
        A subclass of A
        '''
        pass

    class D(C):
        '''
        A subclass of C
        '''
        pass

    class E(C):
        '''
        A subclass of C
        '''
        pass

    class F(E):
        '''
        A subclass of E
        '''
        pass

    assert set([B, C, D, E, F]) == get_all_subclasses(A)

# Generated at 2022-06-22 21:11:19.697155
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class MetaA(type):
        def __new__(cls, name, bases, dct):
            if name not in ["A", "AA"]:
                raise Exception("Bad class name: " + name)
            return super(MetaA, cls).__new__(cls, name, bases, dct)

    class A(object):
        __metaclass__ = MetaA

    class AA(A):
        pass

    class AAA(AA):
        pass

    class B(object):
        pass

    assert(set(get_all_subclasses(A)) == set([AA, AAA]))
    assert(set(get_all_subclasses(AA)) == set([AAA]))
    assert(set(get_all_subclasses(AAA)) == set([]))

# Generated at 2022-06-22 21:11:30.575830
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import string
    import six

    classes = {}

    # Generate a random string for class name
    rand_str = ''.join(six.moves.random.sample(string.ascii_letters + string.digits, 10))

    # Create a base class
    classes[rand_str] = type(rand_str, (object,), {})

    # Create a class which inherit from the base class
    classes[rand_str + '_subclass_1'] = type(rand_str + '_subclass_1', (classes[rand_str],), {})

    # Create a class which inherit from the base class
    classes[rand_str + '_subclass_2'] = type(rand_str + '_subclass_2', (classes[rand_str],), {})

    # Create a class which inherit from the base class

# Generated at 2022-06-22 21:11:40.605032
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Defining a test class hierarchy
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(D, F):
        pass
    # Checking that all the classes are returned
    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert G in get_all_subclasses(A)

# Generated at 2022-06-22 21:11:43.382364
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(A):
        pass

    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert not E in get_all_subclasses(A)


# Generated at 2022-06-22 21:11:54.816536
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    def assert_subclasses(cls, expected):
        assert get_all_subclasses(cls) == set(expected)

    class A(object):
        pass
    assert_subclasses(A, [])

    class B(A):
        pass
    assert_subclasses(A, [B])
    assert_subclasses(B, [])

    class C(A):
        pass
    assert_subclasses(A, [B, C])
    assert_subclasses(C, [])

    class D(B):
        pass
    assert_subclasses(A, [B, C, D])
    assert_subclasses(D, [])

    class E(D):
        pass
    assert_subclasses(A, [B, C, D, E])
    assert_subclasses(E, [])


# Generated at 2022-06-22 21:12:03.634792
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class F(B, C):
        pass

    class G(F):
        pass

    class H(G):
        pass

    assert get_all_subclasses(A) == {B, F, G, H, C}
    assert get_all_subclasses(B) == {F, G, H}
    assert get_all_subclasses(F) == {G, H}
    assert get_all_subclasses(G) == {H}
    assert get_all_subclasses(H) == set()

# Generated at 2022-06-22 21:12:11.475147
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
        Example to test function get_all_subclasses
        A
        |_B
           |_D
        |_C
           |_E
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}

# Generated at 2022-06-22 21:12:17.356233
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C: pass
    class D(A): pass
    class E(B,C): pass
    class F(B,C): pass
    class G(D,E,F): pass
    class H(G): pass
    class I(H): pass

    assert get_all_subclasses(A) == set([B, D, E, F, G, H, I])

# Generated at 2022-06-22 21:12:25.168733
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # The base class
    class C1(object):
        pass

    # A class with a subclass
    class C2(C1):
        pass

    class C3(C1):
        pass

    class C4(C3):
        pass

    class C5(C2):
        pass

    # Test the recursive feature
    class C6(C2):
        pass

    class C7(C6):
        pass

    class C8(C7):
        pass

    assert C1 in get_all_subclasses(C1)
    assert C2 in get_all_subclasses(C1)
    assert C3 in get_all_subclasses(C1)
    assert C4 in get_all_subclasses(C1)
    assert C5 in get_all_subclasses(C1)
    assert C

# Generated at 2022-06-22 21:12:28.900251
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass

    results = get_all_subclasses(A)
    assert B in results
    assert C in results



# Generated at 2022-06-22 21:12:38.043494
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(C):
        pass

    class MyTest(unittest.TestCase):
        def test_get_all_subclasses(self):
            subclasses = get_all_subclasses(A)
            self.assertEqual(subclasses, set((B, C, D, E)))

    mytest = MyTest()
    mytest.test_get_all_subclasses()

# Generated at 2022-06-22 21:12:45.792679
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B, C):
        pass

    class TestGetAllSubclasses(unittest.TestCase):
        def test_get_all_subclasses(self):
            self.assertEqual(
                get_all_subclasses(A),
                set([B, C, D, E])
            )

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-22 21:12:49.806296
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass
    assert get_all_subclasses(A) == set([B, C, D])

# Generated at 2022-06-22 21:12:57.365325
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    class G(C): pass
    class H(C): pass
    class I(F, G, H): pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I])
    assert get_all_subclasses(B) == set([D, F, I])
    assert get_all_subclasses(C) == set([E, G, H, I])
    assert get_all_subclasses(D) == set([F, I])
    assert get_all_subclasses(E) == set([])

# Generated at 2022-06-22 21:13:08.173304
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    class G():
        pass

    class H(G):
        pass

    ref_set_a = set([B, C, D, E, F])
    ref_set_b = set([H])
    ref_set_c = set([A])
    ref_set_d = set([G])
    ref_set_f = set([F])

    assert(get_all_subclasses(A) == ref_set_a)
    assert(get_all_subclasses(B) == ref_set_a)

# Generated at 2022-06-22 21:13:15.085818
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C1(object):
        pass
    class C2(C1):
        pass
    class C3(C2):
        pass
    class D(object):
        pass
    class E(C3, D):
        pass
    class F(C3):
        pass
    class G(C1):
        pass

    res = get_all_subclasses(C1)
    assert res == set([C2, C3, E, F, G])

    res = get_all_subclasses(C3)
    assert res == set([E, F])

    res = get_all_subclasses(D)
    assert res == set([E])

    res = get_all_subclasses(object)
    assert res == set([C1, D, E, F])

# Generated at 2022-06-22 21:13:17.731608
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest.case

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    classes = get_all_subclasses(A)

    assert len(classes) == 3
    assert C in classes
    assert D in classes

# Generated at 2022-06-22 21:13:21.739402
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class class1:
        pass

    class class2(class1):
        pass

    class class3:
        pass

    class class4(class1):
        pass

    subclasses = get_all_subclasses(class1)
    assert class2 in subclasses
    assert class4 in subclasses
    assert class3 not in subclasses

# Generated at 2022-06-22 21:13:31.811306
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses

    '''
    import random

    # Define a dummy class
    class Parent(object):
        pass

    # Init a Parent class
    o = Parent()

    # We will create a random tree of subclasses.
    # A tree contains nodes, each node has a name, a parent node and a list of child nodes
    def get_random_tree(nb_node=10, root_node='root'):
        # Return a random tree
        if nb_node == 0:
            return {'name': root_node, 'parent': None, 'children': []}
        else:
            # Init the root node
            root_node = {'name': root_node, 'parent': None, 'children': []}
            # Add a new node on each level of the tree


# Generated at 2022-06-22 21:13:36.243697
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F])


# Generated at 2022-06-22 21:13:42.156669
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Just a simple test
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == {B, C, D}
    assert get_all_subclasses(B) == {D}
    assert get_all_subclasses(C) == {D}
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(str) == set()



# Generated at 2022-06-22 21:13:45.357928
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(F):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])



# Generated at 2022-06-22 21:13:49.451922
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This function tests the function get_all_subclasses() which is in _utils.py.
    Two classes are set as base class and its subclass, then the function is called to test.
    '''
    class Base(object):
        pass
    class A(Base):
        pass
    class B(Base):
        pass
    class C(A):
        pass
    class D(C):
        pass

    subclasses = get_all_subclasses(Base)
    assert (A in subclasses)
    assert (B in subclasses)
    assert (C in subclasses)
    assert (D in subclasses)

# Generated at 2022-06-22 21:14:01.029284
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class T0(object):
        pass

    assert {} == get_all_subclasses(T0)

    class T1(T0):
        pass

    assert {T1} == get_all_subclasses(T0)

    class T2(T0):
        pass

    assert {T1, T2} == get_all_subclasses(T0)

    class T3(T1):
        pass

    assert {T1, T2, T3} == get_all_subclasses(T0)

    class T3_duplicate(T1):
        pass

    assert {T1, T2, T3, T3_duplicate} == get_all_subclasses(T0)

    class T4(T2):
        pass


# Generated at 2022-06-22 21:14:05.110901
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(D): pass
    class F(C, E): pass
    assert get_all_subclasses(A) == set([B, C, D, E, F])



# Generated at 2022-06-22 21:14:09.070378
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D, E}

# Generated at 2022-06-22 21:14:16.706447
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(E):
        pass

    class G(object):
        pass

    assert get_all_subclasses(A) == set([C, D, E, F])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set([E, F])
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set()
    assert get_all_subclasses(G) == set()

# ================================================
#
#  

# Generated at 2022-06-22 21:14:23.019838
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    test_cls = get_all_subclasses(A) # return D, E and C (in no particular order)
    assert "D" in test_cls
    assert "E" in test_cls
    assert "C" in test_cls
    test_cls = get_all_subclasses(C) # return empty set
    assert len(test_cls) == 0

# Generated at 2022-06-22 21:14:33.917460
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for the :py:func:`~_utils.get_all_subclasses` function

    This unit test was adapted from http://stackoverflow.com/a/3862957/2571826.
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D):
        pass

    # This class is intentionally not in the hierarchy of class A
    class Z(object):
        pass

    # Asserting all subclasses of A are detected
    assert get_all_subclasses(A) == set([B, C, D, E])

    # Asserting Z class is not in the list of subclasses

# Generated at 2022-06-22 21:14:42.654742
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    result = set(get_all_subclasses(A))
    assert B in result
    assert C in result
    assert D in result
    assert E in result
    assert F in result

    result = set(get_all_subclasses(F))
    assert F in result

    result = set(get_all_subclasses(E))
    assert F in result



# Generated at 2022-06-22 21:14:50.756825
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import os

    # Simplified class tree
    #
    #     A
    #     |\
    #     B C
    #     | |\
    #     D E F
    #     |\|
    #     G H
    #

    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(E):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G, H}
    assert get_all_subclasses(B) == {D, E, G, H}

# Generated at 2022-06-22 21:14:59.599334
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Foo(object): pass
    class Bar(Foo): pass
    class Baz(Foo): pass
    class Skuz(Bar): pass
    class Arthashastra(Baz): pass
    class Ora(Baz): pass
    class OraOra(Ora): pass
    class BarOra(Ora): pass
    class OraOraOra(OraOra): pass
    class OraOraOraOra(OraOraOra): pass
    classes = {Foo, Bar, Baz, Skuz, Arthashastra, Ora, OraOra, BarOra, OraOraOra, OraOraOraOra}
    assert classes == get_all_subclasses(Foo)

# Generated at 2022-06-22 21:15:07.433173
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(object):
        pass

    class E(D):
        pass

    class F(E):
        pass

    classes = get_all_subclasses(A)
    # Check if the set of classes B,C is in get_all_subclasses(A)
    assert classes == {B,C}

# Generated at 2022-06-22 21:15:14.862783
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Defining a basic class
    class A(object): pass

    # Defining subclass of class A
    class B(A): pass

    # Defining another subclass of class A
    class C(A): pass

    # Defining a subclass of class B
    class D(B): pass

    # Defining a subclass of class C
    class E(C): pass

    # Checking the result of get_all_subclasses
    assert get_all_subclasses(A) == {B, C, D, E}

# Generated at 2022-06-22 21:15:22.841291
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestClass(object):
        pass

    class TestClass1(TestClass):
        pass

    class TestClass2(TestClass):
        pass

    class TestClass3(TestClass1):
        pass

    class TestClass4(TestClass3):
        pass

    all_subclasses = get_all_subclasses(TestClass)
    assert TestClass1 in all_subclasses
    assert TestClass2 in all_subclasses
    assert TestClass3 in all_subclasses
    assert TestClass4 in all_subclasses



# Generated at 2022-06-22 21:15:25.972764
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    assert get_all_subclasses(A) == set([B, C, D])

# Generated at 2022-06-22 21:15:36.538749
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Mocking classes for testing
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass
    class G(D):
        pass
    class H(E):
        pass
    class I(F):
        pass
    class J(G):
        pass
    class K(H):
        pass
    class L(I):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G, H, I, J, K, L}
    assert get_all_subclasses(B) == {D, G, J}

# Generated at 2022-06-22 21:15:45.865092
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(B):
        pass

    class G(F):
        pass

    assert get_all_subclasses(A) == set([C, D, E])
    assert get_all_subclasses(B) == set([F, G])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set([E])
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set([G])
    assert get_all_subclasses(G) == set()

# Generated at 2022-06-22 21:15:56.409081
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        """
        /
        |
        A
        """

    class B(A):
        """
        / \
        |  B
        A
        """

    class C(A):
        """
        / \
        |  C
        A
        """

    class D(object):
        """
        /
        |
        D
        """

    class E(C):
        """
        / \
        |  E
        C  |
        |  D
        A
        """

    assert get_all_subclasses(A) == {B, C, E}
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == {E}
    assert get_all_subclasses(D) == set()
    assert get_

# Generated at 2022-06-22 21:15:59.903789
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a:
        pass

    class b(a):
        pass

    class c(a):
        pass

    class d(c):
        pass

    assert set([b, c, d]) == get_all_subclasses(a)

# Generated at 2022-06-22 21:16:10.769174
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import random
    import string

    def random_string(str_len):
        return ''.join(random.choice(string.ascii_lowercase) for _ in range(str_len))
    # Create a random class
    base_class1 = type(random_string(10), (object, ), {})
    base_class2 = type(random_string(10), (object, ), {})
    sub_class1 = type(random_string(10), (base_class1, ), {})
    sub_class2 = type(random_string(10), (base_class2, ), {})
    class_list = [base_class1, base_class2, sub_class1, sub_class2]
    result = get_all_subclasses(object)

# Generated at 2022-06-22 21:16:13.297084
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base(object):
        pass
    class Class1(Base):
        pass
    class Class2(Base):
        pass

    assert(get_all_subclasses(Base) == set([Class1, Class2]))

# Generated at 2022-06-22 21:16:18.416001
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        a = 10

    class B(A):
        b = 20

    class C(A):
        c = 30

    class D(B):
        d = 40

    class E(B, C):
        e = 50

    class F(E):
        f = 60

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    return True

__all__ = ('get_all_subclasses', 'test_get_all_subclasses')

# Generated at 2022-06-22 21:16:26.906359
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Init the tree view
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(A):
        pass
    class F(A):
        pass
    class G(B):
        pass
    class H(B):
        pass
    class I(H):
        pass

    # Check that it works
    a = A()
    assert(set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H, I]))


# Generated at 2022-06-22 21:16:37.936949
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Testing get_all_subclasses
    """
    class A(object):
        '''
        Root class
        '''
        pass

    class B(A):
        '''
        First child class
        '''
        pass

    class C(A):
        '''
        Second child class
        '''
        pass

    class D(B):
        '''
        First subchild class
        '''
        pass

    class E(B):
        '''
        Second subchild class
        '''
        pass

    class F(E):
        '''
        Subsubchild class
        '''
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-22 21:16:41.697362
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A: pass
    class B: pass
    class C(A): pass
    class D(B): pass
    class E(A): pass
    class F(C): pass
    class G(D): pass

    # The order should not be important
    assert set([A, B, C, D, E, F, G]) == get_all_subclasses(object)

    assert set([C, E, F]) == get_all_subclasses(A)
    assert set([F]) == get_all_subclasses(C)



# Generated at 2022-06-22 21:16:48.765275
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(object):
        pass

    class D(C):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == {B}
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == {D, E}
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-22 21:16:56.418354
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    class F(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, F])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D, F])
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()



# Generated at 2022-06-22 21:17:07.626896
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(G):
        pass
    class Z(object):
        pass

    res = get_all_subclasses(A)
    assert len(res) == 6
    assert B in res
    assert C in res
    assert D in res
    assert E in res
    assert F in res
    assert G in res
    assert H not in res
    assert Z not in res

    res = get_all_subclasses(B)
    assert len(res) == 2
    assert C not in res
    assert D in res

# Generated at 2022-06-22 21:17:18.574197
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # This is the following tree:
    #
    # class A(object):
    #    pass
    #
    # class B(A):
    #    pass
    #
    # class C(A):
    #    pass
    #
    # class D(C):
    #    pass
    #
    # class E(C):
    #    pass
    #
    # class F(A):
    #    pass
    #
    # class G(D):
    #    pass

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(A):
        pass

    class G(D):
        pass

    assert get_all_subclasses

# Generated at 2022-06-22 21:17:27.113504
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Create a first class
    class ParentClass(object):
        def __init__(self, variable1):
            self.variable1 = variable1

    # Then create two child classes
    class ChildClass1(ParentClass):
        def __init__(self, variable1, variable2):
            super(ChildClass1, self).__init__(variable1)
            self.variable2 = variable2

    class ChildClass2(ParentClass):
        def __init__(self, variable1, variable3):
            super(ChildClass2, self).__init__(variable1)
            self.variable3 = variable3

    # And then create a third class which inherits from the first child

# Generated at 2022-06-22 21:17:32.920924
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(D): pass
    class F(C): pass
    class G(D): pass
    class H(F): pass

    assert get_all_subclasses(A) == set([B, C, F, H, D, E, G])



# Generated at 2022-06-22 21:17:38.588711
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E:
        pass
    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([])
    assert get_all_subclasses(E) == set([])

# Generated at 2022-06-22 21:17:46.555446
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    class F(E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(E)) == set([F])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-22 21:17:49.814569
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class X(A, B):
        pass

    class Y(B, D):
        pass

    class Z(B, C):
        pass

    class P:
        pass

    assert get_all_subclasses(A) == set([B, X, Y, Z, C, D])
    assert get_all_subclasses(P) == set([])

# Generated at 2022-06-22 21:18:00.674562
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(G):
        pass

    classes = {'A': A, 'B': B, 'C': C, 'D': D, 'E': E, 'F': F, 'G': G, 'H': H, 'I': I}

    for cls in classes:
        assert classes[cls] in get_all_subclasses(A)
        assert classes[cls] in get_all_subclasses(classes[cls])


# Generated at 2022-06-22 21:18:06.350633
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-22 21:18:12.451680
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create the tree of class we want to test on
    #
    #      BaseCls
    #      / | \
    #     /  |  \
    #  C1   C2   C3
    #        \
    #        C4
    #
    class BaseCls(object):
        pass

    class C1(BaseCls):
        pass

    class C2(BaseCls):
        pass

    class C3(BaseCls):
        pass

    class C4(C2):
        pass

    result = get_all_subclasses(BaseCls)
    expected = {C1, C2, C3, C4}
    assert result == expected

# Generated at 2022-06-22 21:18:15.944097
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D}

# Generated at 2022-06-22 21:18:20.934122
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    assert set == type(get_all_subclasses(A))
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert C in get_all_subclasses(B)

# Generated at 2022-06-22 21:18:31.911424
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Ensures that get_all_subclasses works as expected
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(D):
        pass
    class G(D):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D, E, F, G}
    assert set(get_all_subclasses(B)) == {D, E, F, G}
    assert set(get_all_subclasses(C)) == set()
    assert set(get_all_subclasses(D)) == {F, G}
    assert set(get_all_subclasses(E)) == set()
   

# Generated at 2022-06-22 21:18:39.341856
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    # initializing a dict to store the class name and its number of subclass
    class_map = {}

    # First, we want to verify that the function get_all_subclasses works as expected so we use a test based
    # on mock module.
    # Mock a class A. This class has two subclasses B and C.
    # Class B has two subclasses D and E. And class C has only one subclass F
    from mock import Mock
    class A(object):
        pass

    # mock all classes
    A = Mock(A)
    B = Mock(name='B')
    C = Mock(name='C')
    D = Mock(name='D')
    E = Mock(name='E')
    F = Mock(name='F')

    #

# Generated at 2022-06-22 21:18:44.735178
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(object):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(D):
        pass
    class H(E):
        pass
    class I(H):
        pass

    assert set([B, D, F, G, I]) == get_all_subclasses(C)
    assert set([B, F, G, I]) == get_all_subclasses(D)

# Generated at 2022-06-22 21:18:51.625142
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    class A(object):
        pass
    class B(object):
        pass
    class C(object):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass
    class G(A, C):
        pass

    assert get_all_subclasses(A) == set([G])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E, F, G])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()
    assert get_all_sub

# Generated at 2022-06-22 21:18:59.861505
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(E):
        pass

    assert set([B, C, D, E, F]) == get_all_subclasses(A)
    assert set([C]) == get_all_subclasses(B)
    assert set([]) == get_all_subclasses(C)
    assert set([E, F]) == get_all_subclasses(D)
    assert set([F]) == get_all_subclasses(E)
    assert set([]) == get_all_subclasses(F)

# Generated at 2022-06-22 21:19:08.521399
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils.six import with_metaclass

    class Meta1(type):
        pass

    class Meta2(type):
        pass

    class A(object):
        __metaclass__ = Meta1

        class B(object):
            __metaclass__ = Meta2

            class C1(object):
                pass

            class C2(object):
                pass

        class B2(object):
            pass


# Generated at 2022-06-22 21:19:16.740366
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # A small hierarchy of classes
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(A):
        pass
    class F(E):
        pass
    class G(F):
        pass
    # The expected output is : [B, C, D, E, F, G]
    assert set([B, C, D, E, F, G]) == get_all_subclasses(A)

# Generated at 2022-06-22 21:19:25.594539
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(D):
        pass

    assert get_all_subclasses(object) == {A, B, C, D, E, F, G}

    assert get_all_subclasses(A) == {C, D, E, F, G}

    assert get_all_subclasses(B) == set()

    assert get_all_subclasses(C) == {E, F}

    assert get_all_subclasses(D) == {G}

# Test of the module
if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-22 21:19:35.574523
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a(object):
        pass

    class b(object):
        pass

    class c(object):
        pass

    class d(a, b):
        pass

    class e(b, c):
        pass

    class f(d, e):
        pass

    """                                           a
                                            /      \
                                          d         b
                                        /   \      / \
                                      f     e    c   b
                                            /  \
                                           b    c
    """

    expected_results = {a, b, c, d, e, f}
    actual_results = get_all_subclasses(a)
    assert actual_results == expected_results

# Generated at 2022-06-22 21:19:41.229018
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass

    assert set(get_all_subclasses(A)) == set((B, C, D, E, F))
    assert set(get_all_subclasses(B)) == set((D, F))
    assert set(get_all_subclasses(C)) == set((E,))
    assert set(get_all_subclasses(D)) == set((F,))
    assert set(get_all_subclasses(E)) == set(())
    assert set(get_all_subclasses(F)) == set(())