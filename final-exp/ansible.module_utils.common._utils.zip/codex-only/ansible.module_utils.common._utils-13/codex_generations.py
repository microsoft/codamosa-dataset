

# Generated at 2022-06-22 21:09:48.171752
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit-test function for get_all_subclasses function
    :rtype: bool
    :returns: True when the unit test suceeds or False when it fails.

    This class structure represents a test for the function `get_all_subclasses`.  The following
    classes are defined in this function:

    * class A: the root class to search
    * class B0-2: the direct subclasses of A
    * class C0-2: the subclasses of B0-2
    * class D0-2: the subclasses of C0-2

    The unit test ensures that the function `get_all_subclasses` returns the correct set of
    subclasses for class A.
    '''
    class A():
        pass

    class B0(A):
        pass

    class B1(A):
        pass

# Generated at 2022-06-22 21:09:58.785604
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define classes
    class A: pass
    class B(A): pass
    class C(A): pass
    class AA(A): pass
    class AB(A): pass
    class BA(B): pass
    class BB(B): pass
    class BC(B): pass
    class BA1(BA): pass
    class BB1(BB): pass
    class BB2(BB): pass
    class BB3(BB): pass
    class CA(C): pass
    class CB(C): pass
    class CC(C): pass
    class CB1(CB): pass
    # Get all subclasses
    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert AA in get_all_subclasses(A)

# Generated at 2022-06-22 21:10:02.395667
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Iterable
    import ansible.module_utils.common.removed
    classes = get_all_subclasses(Iterable)
    assert ansible.module_utils.common.removed.RemovedModule in classes

# Generated at 2022-06-22 21:10:08.034385
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(int) == set([bool])
    assert get_all_subclasses(bool) == set()
    assert get_all_subclasses(dict) == set()
    assert get_all_subclasses(list) == set()
    assert get_all_subclasses(unicode) == set([str])
    assert get_all_subclasses(str) == set()

# Generated at 2022-06-22 21:10:17.737019
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Example of a classic class
    class A(object):
        """dummy class"""
        pass
    # Example of a newstyle class
    class NewstyleClass:
        """dummy class"""
        pass
    class B(A):
        """dummy class"""
        pass
    class C(A):
        """dummy class"""
        pass
    class D(B):
        """dummy class"""
        pass
    class E(C):
        """dummy class"""
        pass
    class F(D, NewstyleClass):
        """dummy class"""
        pass
    class G(E, NewstyleClass):
        """dummy class"""
        pass
    class H(G):
        """dummy class"""
        pass


# Generated at 2022-06-22 21:10:22.376300
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define our test architecture
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    # Test if we get the expected subclasses
    assert get_all_subclasses(A) == set([B, C])

# Generated at 2022-06-22 21:10:33.005782
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # A simple hierarchy of classes to test class hierarchy
    # B and C are direct subclasses of A
    # D and E are direct subclasses of C
    # F is direct subclass of E
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(E):
        pass

    # Test if A returns B, C, D, E & F
    assert get_all_subclasses(A) == {B, C, D, E, F}
    # D and E should be returned from C
    assert get_all_subclasses(C) == {D, E, F}
    # F should be returned from E

# Generated at 2022-06-22 21:10:43.112096
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Recursively search and find all subclasses of a given class

    :arg cls: A python class
    :rtype: set
    :returns: The set of python classes which are the subclasses of `cls`.

    In python, you can use a class's :py:meth:`__subclasses__` method to determine what subclasses
    of a class exist.  However, `__subclasses__` only goes one level deep.  This function searches
    each child class's `__subclasses__` method to find all of the descendent classes.  It then
    returns an iterable of the descendent classes.
    '''
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    classes = get_all_sub

# Generated at 2022-06-22 21:10:49.978661
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert A not in get_all_subclasses(A)

# Generated at 2022-06-22 21:11:01.348354
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(A):
        pass
    class F(object):
        pass
    assert get_all_subclasses(A) == {B, C, D, E}, "Invalid set of subclasses"
    assert get_all_subclasses(B) == {C, D}, "Invalid set of subclasses"
    assert get_all_subclasses(C) == {D}, "Invalid set of subclasses"
    assert get_all_subclasses(D) == set(), "Invalid set of subclasses"
    assert get_all_subclasses(E) == set(), "Invalid set of subclasses"

# Generated at 2022-06-22 21:11:08.564415
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass
    class G(object):
        pass
    class H(F):
        pass
    class I(H):
        pass
    class J(I):
        pass
    assert set(get_all_subclasses(A)) == set((B, C, D, E, F, H, I, J))

# Generated at 2022-06-22 21:11:15.081452
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(A):
        pass

    class G(object):
        pass

    classes = get_all_subclasses(A)
    assert A in classes
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert G not in classes

# Generated at 2022-06-22 21:11:25.709282
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-22 21:11:34.519229
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This function is the unit test of `get_all_subclasses`

    The test case is following:
        class A(): pass
        class B(): pass
        class C(): pass
        class D(A, B): pass
        class E(B, C): pass
        class F(B, D): pass
        class G(D, E): pass
    '''
    import unittest
    class A(): pass
    class B(): pass
    class C(): pass
    class D(A, B): pass
    class E(B, C): pass
    class F(B, D): pass
    class G(D, E): pass

# Generated at 2022-06-22 21:11:40.284460
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(): pass
    class B(A): pass
    class C(A): pass
    class D(A): pass
    class E(B): pass
    class F(B): pass
    class G(E): pass
    class H(G): pass

    classes = get_all_subclasses(A)
    assert A in classes
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert G in classes
    assert H in classes

# Generated at 2022-06-22 21:11:46.380208
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.plugins.loader import module_loader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import IncludeRole
    from ansible.inventory.host import Host
    # A list of classes who have multiple subclasses
    classes = [
        module_loader.ModuleLoader,
        Host,
        Play,
        Task,
        IncludeRole
    ]
    # For each class, find all subclasses and compare the list with the expected value
    for cls in classes:
        subclasses = list(get_all_subclasses(cls))
        subclasses.sort()

        # Build the expected list of subclasses
        expected = []
        for sc in cls.__subclasses__():
            expected.append(sc)

# Generated at 2022-06-22 21:11:51.346686
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(D):
        pass
    assert(set([B, C, D, E, F]) == get_all_subclasses(A))

# Generated at 2022-06-22 21:11:58.736014
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(B):
        pass

    class G(B):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(F):
        pass

    class K(F):
        pass

    class L(G):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(F):
        pass

    class P(A):
        pass

    class Q(A):
        pass

    class R(A):
        pass

    class S(A):
        pass


# Generated at 2022-06-22 21:12:03.116346
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])

# Generated at 2022-06-22 21:12:12.682985
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types
    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(D, C):
        pass
    all_subclasses = get_all_subclasses(A)
    assert A in all_subclasses
    assert B in all_subclasses
    assert C in all_subclasses
    assert D in all_subclasses
    assert E in all_subclasses
    assert F in all_subclasses
    assert isinstance(all_subclasses, types.GeneratorType)

# Generated at 2022-06-22 21:12:19.761915
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(E):
        pass

    class G(F):
        pass

    class I(E):
        pass

    class J(E):
        pass

    class K(C):
        pass

    class L(K):
        pass

    # Retrieve all classes subclasses of A, class by class
    all_sub_classes = [D, E, F, G, I, J, B, K, L, C]
    res = set(get_all_subclasses(A))
    success = True

# Generated at 2022-06-22 21:12:31.145643
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a tree with 2 levels of subclasses to test
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(B):
        pass

    class G(C):
        pass

    class H(C):
        pass

    class I(D):
        pass

    class J(D):
        pass

    class K(F):
        pass

    # Test a leaf class
    assert set(get_all_subclasses(J)) == set()

    # Test a class with 1 layer of children
    assert set(get_all_subclasses(A)) == {B, C, D}

    # Test a class with 2 layers of children

# Generated at 2022-06-22 21:12:40.243092
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-22 21:12:43.896596
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Animal(object):
        pass

    class Fish(Animal):
        pass

    class Bird(Animal):
        pass

    class Mammal(Animal):
        pass

    class Dog(Mammal):
        pass

    class Cat(Mammal):
        pass

    class Parrot(Bird):
        pass

    class Ostrich(Bird):
        pass

    assert set(get_all_subclasses(Animal)) == {Fish, Bird, Mammal, Dog, Cat, Parrot, Ostrich}

# Generated at 2022-06-22 21:12:54.333101
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    class G(F): pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([D, F, G])
    assert get_all_subclasses(C) == set([E])
    assert get_all_subclasses(D) == set([F, G])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([G])
    assert get_all_subclasses(G) == set([])

# Generated at 2022-06-22 21:13:04.760896
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class B():
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F():
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(D, E):
        pass
    class J(F, I):
        pass
    class K(J, H):
        pass
    assert get_all_subclasses(B) == set([C, D, E, I, J, K])
    assert get_all_subclasses(F) == set([G, H, J, K])
    assert get_all_subclasses(E) == set([I, J, K])

# Generated at 2022-06-22 21:13:12.913952
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E:
        pass

    class F(E):
        pass

    class G(E):
        pass

    class H(F, G):
        pass

    class I(H, D):
        pass
    try:
        assert(get_all_subclasses(A) == {B, C, D})
        assert(get_all_subclasses(E) == {F, G, H})
        assert(get_all_subclasses(I) == {D, H})
    except AssertionError:
        raise AssertionError('Failure in test_get_all_subclasses')

# Uncomment the line below to execute the test
# test_

# Generated at 2022-06-22 21:13:17.545804
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set([])
    assert set(get_all_subclasses(D)) == set([E])
    assert set(get_all_subclasses(E)) == set([])



# Generated at 2022-06-22 21:13:25.735745
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Here is an example of how to verify that :func:`get_all_subclasses() returns
    all of the subclasses of a class.
    """
    import types

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    def F():
        pass

    def func():
        pass

    class_a = A()
    class_b = B()
    class_c = C()
    class_d = D()
    class_e = E()

    # func() and F() are not a class
    assert isinstance(func, types.FunctionType)
    assert isinstance(F, types.FunctionType)

    # We want to verify that function get_all

# Generated at 2022-06-22 21:13:34.979701
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils import _utils
    from ansible.module_utils._text import to_text

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    # Create a subclass dynamically
    F = type('F', (A,), {})

    def check_subclass(cls, all_subclasses):
        sc = get_all_subclasses(cls)
        if len(all_subclasses) != len(sc):
            return False
        for c in sc:
            if c not in all_subclasses:
                return False
        return True

    # Test cases
    assert check_subclass(A, [B, C, D, E, F])


# Generated at 2022-06-22 21:13:39.465031
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass

    assert get_all_subclasses(A) == set([B,C,D]), 'All classes should be found'
    assert get_all_subclasses(B) == set([D]), 'Only child classes should be found'

# Generated at 2022-06-22 21:13:50.982088
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function: get_all_subclasses()
    '''

    # Define a test hierarchy
    #          /> A
    #         /> B
    #        /> C -> E
    #    Root
    #        \> D
    #         \> E -> F
    #          \> F
    #
    #     Root
    #
    class Root:
        '''
        Dummy class Root
        '''
        pass
    class A(Root):
        '''
        Dummy class A
        '''
        pass
    class B(Root):
        '''
        Dummy class B
        '''
        pass
    class C(Root):
        '''
        Dummy class C
        '''
        pass

# Generated at 2022-06-22 21:14:01.497026
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        def __init__(self):
            pass

    class B(A):
        def __init__(self):
            pass

    class C(A):
        def __init__(self):
            pass

    class D(B):
        def __init__(self):
            pass

    class E(C):
        def __init__(self):
            pass

    class F(D):
        def __init__(self):
            pass

    class G(E):
        def __init__(self):
            pass

    subclasses = get_all_subclasses(A)
    assert sorted(subclasses, key=lambda x: x.__name__) == [B, C, D, E, F, G]

# Generated at 2022-06-22 21:14:07.181885
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(B)) == set([])
    assert set(get_all_subclasses(C)) == set([D])
    assert set(get_all_subclasses(D)) == set([])

# Generated at 2022-06-22 21:14:16.249074
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''Unit test for function get_all_subclasses'''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    subclasses = get_all_subclasses(A)
    assert B in subclasses and C in subclasses and D in subclasses and E in subclasses and\
           F in subclasses and G in subclasses
    assert len(subclasses) == 6

# Generated at 2022-06-22 21:14:23.425277
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This is a unit test for the function get_all_subclasses

    :rtype: bool
    :returns: True if the function behaves properly, False otherwise

    Example of a class hierarchy:
         [A]
         /  \
        [B] [C]
        / \  |
       [D] [E] [F]
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    classes = get_all_subclasses(A)
    return len(classes) == 6

# Generated at 2022-06-22 21:14:34.391309
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types

    # Creating a class with a subclass
    class dummyclass(object):
        pass

    class dummyclass_subclass(dummyclass):
        pass

    assert set([dummyclass_subclass]) == get_all_subclasses(dummyclass)

    # Creating a class with multiple subclasses
    class dummyclass_2(object):
        pass

    class dummyclass_subclass_2(dummyclass_2):
        pass

    class dummyclass_subclass_3(dummyclass_2):
        pass

    assert set([dummyclass_subclass_2, dummyclass_subclass_3]) == get_all_subclasses(dummyclass_2)

    # Creating a class with multiple levels of subclasses
    class dummyclass_3(object):
        pass


# Generated at 2022-06-22 21:14:45.380316
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(B):
        pass
    class H(G):
        pass
    assert get_all_subclasses(A) == set([C, D, E, F])
    assert get_all_subclasses(B) == set([G, H])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set([E, F])
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()
    assert get_all_subclasses(G) == set

# Generated at 2022-06-22 21:14:52.484905
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    #
    # B(A)
    # |
    # D(C)
    # |
    # C(A)
    #

    assert set([B, D, C]) == get_all_subclasses(A)

# Generated at 2022-06-22 21:14:58.373779
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # In order to test this function, we need to create a small class hierarchy:
    #                                                +--------> C
    #                                                |
    #   A -> B -> D -> E -> F -> G -> L -> M -> N -> +--------> J
    #                                                |
    #                                                +--------> H -> I
    #
    # Note: since this is a recursive function, we need to be careful with the circular dependencies
    #       of class definitions.

    # Define A
    class A(object):
        pass
    expected_result = set([A])
    assert get_all_subclasses(A) == expected_result

    # Define B
    class B(A):
        pass
    expected_result.add(B)
    assert get_all_subclasses(A) == expected_result

    #

# Generated at 2022-06-22 21:15:03.364676
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(B):
        pass

    class F(E):
        pass

    class G(object):
        pass

    class H(G):
        pass

    expected = {C, D, B, E, F}
    found = set(get_all_subclasses(A))
    assert found == expected

# Generated at 2022-06-22 21:15:10.867177
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Example class and sub classes
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    # Must include current class
    assert A in get_all_subclasses(A)
    # Must include direct sub classes
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    # Must include indirect sub classes
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)

    # If no sub classes, only current class
    assert list(get_all_subclasses(B)) == [B]

# Generated at 2022-06-22 21:15:21.851037
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test get_all_subclasses function
    This function create a graph of classes and subclasses to see if we can get all
    """
    T = type('T', (object,), {})
    S = type('S', (T,), {})
    U = type('U', (T,), {})
    V = type('V', (T,), {})
    W = type('W', (T,), {})
    X = type('X', (T,), {})
    Y = type('Y', (T,), {})
    Z = type('Z', (T,), {})

    sub_s = type('Sub_s', (S,), {})
    sub_u = type('Sub_u', (U,), {})

# Generated at 2022-06-22 21:15:29.111595
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H():
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(Z) == set()
    assert get_all_subclasses(H) == set()



# Generated at 2022-06-22 21:15:34.149078
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(F):
        pass

    assert set([B, D, E, F, G]) == get_all_subclasses(A)

# Generated at 2022-06-22 21:15:44.569974
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest2

    class TestClass(object):
        pass

    class TestClass2(TestClass):
        pass

    class TestClass3(TestClass):
        pass


    class TestClass4(TestClass2):
        pass

    class TestClass5(TestClass4):
        pass

    class TestSubclassPath(unittest2.TestCase):

        def test_get_subclass_path_one_level(self):
            self.assertEqual(set(TestClass.__subclasses__()), set([TestClass2, TestClass3]))

        # For the following, class TestClass4 is a descendent of class TestClass.
        # It is important to verify that get_all_subclasses can find descendent classes
        # even if they are more than one level deep.

# Generated at 2022-06-22 21:15:51.383484
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class A1(A):
        pass

    class A11(A1):
        pass

    class A12(A1):
        pass

    class A2(A):
        pass

    class B(object):
        pass

    class B1(B):
        pass

    class B2(B):
        pass

    # Should return 4 classes
    assert len(get_all_subclasses(A)) == 4
    # Should return 2 classes
    assert len(get_all_subclasses(B)) == 2
    # Should return 0 classes
    assert len(get_all_subclasses(B1)) == 0


# Generated at 2022-06-22 21:15:59.123221
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set([F])
    assert set(get_all_subclasses(D)) == set()
    assert set(get_all_subclasses(E)) == set()
    assert set(get_all_subclasses(F)) == set()

# Generated at 2022-06-22 21:16:10.085003
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """Test get_all_subclasses function by validating that all
    subclasses where found.
    Return True if tests passed or False on failure"""
    import os
    import pkgutil
    import ansible.module_utils

    # Test current function
    def assert_all_subclasses(classs, expected_subclasses):
        found_subclasses = get_all_subclasses(classs)
        if found_subclasses != set(expected_subclasses):
            print('all_subclasses for %s do not match expected %s == %s' % (classs, found_subclasses, expected_subclasses))
            return False
        return True

    # Check our test function works
    if not assert_all_subclasses(int, []):
        return False

    # Check the test results
    total_failed = 0
    base_class

# Generated at 2022-06-22 21:16:14.374086
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys

    # Define a class's tree with all its subclasses

    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(A): pass
    class E(B, C): pass
    class F(D): pass
    class G(E, F): pass
    class H(G): pass

    # No subclass
    class I(object): pass

    # class A has its own subclasses
    assert set(get_all_subclasses(A)) == {B, C, D, E, F, G, H}
    # class B has its own subclasses
    assert set(get_all_subclasses(B)) == {E, G, H}
    # class I has no subclass
    assert not set(get_all_subclasses(I))

    # Test subclass with

# Generated at 2022-06-22 21:16:25.045190
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Class used for the purpose of unittest of the function get_all_subclasses.
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    class G(object):
        pass

    class H(G):
        pass

    class I(H):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D])
    assert set(get_all_subclasses(C)) == set([E, F])
    assert set(get_all_subclasses(D))

# Generated at 2022-06-22 21:16:33.534703
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestData(object):
        pass
    class TestData1(TestData):
        pass
    class TestData2(TestData):
        pass
    class TestData3(TestData):
        pass
    class TestData4(TestData3):
        pass
    class TestData5(TestData3):
        pass
    class TestData6(TestData5):
        pass
    class TestData7(TestData5):
        pass
    print('Current available class : {}'.format(get_all_subclasses(TestData)))

# Generated at 2022-06-22 21:16:42.783036
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object): pass
    class B(object): pass
    class C(object): pass
    class D(A): pass
    class E(B): pass
    class F(D): pass
    class G(E): pass
    class H(F, G): pass
    class I(A): pass

    assert get_all_subclasses(object) == set([A, B, C, D, E, F, G, H, I])
    assert get_all_subclasses(A) == set([D, I])
    assert get_all_subclasses(H) == set([])
    assert get_all_subclasses(B) == set([E])
    assert get_all_subclasses(C) == set([])

# Generated at 2022-06-22 21:16:54.349288
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(B):
        pass

    class G(C):
        pass

    class H(G):
        pass

    class I(D):
        pass

    def is_sublist(list1, list2):
        for item1 in list1:
            if item1 not in list2:
                return False
        return True

    assert is_sublist([B, D, E, F, I], get_all_subclasses(A))
    assert is_sublist([C, G, H], get_all_subclasses(A))

# Generated at 2022-06-22 21:17:01.533555
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D, E): pass

    assert sorted(get_all_subclasses(A)) == sorted([B, C, D, E, F])
    assert not get_all_subclasses(D)
    assert not get_all_subclasses(F)



# Generated at 2022-06-22 21:17:09.322192
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test get_all_subclasses function

    There is no unit test for function get_all_subclasses, because it's not possible to test it
    easily.  However ...
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    # This test should pass for any python version.
    assert set(get_all_subclasses(A)) == set([B, C, D, E])

# Generated at 2022-06-22 21:17:19.917317
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections
    import string

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D):
        pass

    def is_equal(l1, l2):
        l1 = list(l1)
        l2 = list(l2)
        l1.sort()
        l2.sort()
        return l1 == l2

    assert is_equal(get_all_subclasses(string.Formatter), [])
    assert is_equal(get_all_subclasses(collections.Callable), [])
    assert is_equal(get_all_subclasses(A), [B, C, D, E])

# Generated at 2022-06-22 21:17:26.268525
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for get_all_subclasses
    '''
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(C): pass
    assert(set(get_all_subclasses(A)) == set((B, C, D)))
    assert(set(get_all_subclasses(B)) == set((C, D)))
    assert(set(get_all_subclasses(C)) == set((D,)))
    assert(set(get_all_subclasses(D)) == set())

# Generated at 2022-06-22 21:17:33.999984
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Given
    class Sample(object):
        pass
    class SubClass1(Sample):
        pass
    class SubClass2(Sample):
        pass
    class SubSubClass1(SubClass1):
        pass
    class SubSubClass2(SubClass2):
        pass
    expected = {
        SubClass1,
        SubSubClass1,
        SubClass2,
        SubSubClass2
    }
    # When
    actual = get_all_subclasses(Sample)
    # Then
    assert actual == expected

# Generated at 2022-06-22 21:17:41.032257
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import namedtuple
    # Build a tree of class
    A = namedtuple('A', [])
    B = namedtuple('B', [])
    C = namedtuple('C', [])
    E = namedtuple('E', [])
    AA = namedtuple('AA', [])
    AB = namedtuple('AB', [])
    BA = namedtuple('BA', [])
    BAA = namedtuple('BAA', [])
    BBB = namedtuple('BBB', [])
    EEE = namedtuple('EEE', [])
    # Define heritance
    A.__subclasses__ = lambda self: [self.AA, self.AB]
    B.__subclasses__ = lambda self: [self.BA]
    C.__subclasses__ = lambda self: []


# Generated at 2022-06-22 21:17:48.726876
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(B, C):
        pass

    assert get_all_subclasses(int) == set()
    assert get_all_subclasses(object) == set()
    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(int) == set()

# Generated at 2022-06-22 21:17:52.360605
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    classes = get_all_subclasses(A)
    assert B in classes
    assert C in classes
    assert D in classes

# Generated at 2022-06-22 21:17:59.418243
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    subclasses = get_all_subclasses(A)
    # Only B and D are direct subclasses of A
    # So B, C and D have to be found
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert len(subclasses) == 3

# Generated at 2022-06-22 21:18:08.309877
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Iterable
    from .test_module import TestModule

    assert isinstance(get_all_subclasses(TestModule), Iterable)

    classes = get_all_subclasses(TestModule)
    assert len(classes) == 2

    for c in classes:
        if c.__name__ == 'TestModule':
            continue
        if c.__name__ == 'TestSubclass':
            TestSubclass = c
        else:
            # We don't want any more classes
            assert False

    assert TestSubclass.__module__ == 'lib.ansible_test.units.modules._utils'

# Generated at 2022-06-22 21:18:16.649610
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Function testing if all the subclasses are found

    :returns: A boolean value that is true when the test is passed
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(A):
        pass

    class F(object):
        pass

    all_subclasses = set([B, D, C, E])
    assert all_subclasses == get_all_subclasses(A)

# Generated at 2022-06-22 21:18:26.149069
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(E):
        pass
    class J(F):
        pass
    class K(F):
        pass
    class L(G):
        pass
    class M(G):
        pass
    class N(I):
        pass
    class O(J):
        pass
    class P(K):
        pass
    class Q(L):
        pass
    class R(M):
        pass
    all_classes = get_all_subclasses(A)


# Generated at 2022-06-22 21:18:35.911181
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Creating a sample class hierarchy
    from ansible.module_utils._text import to_bytes
    class BaseClass(object):
        pass
    class SubClass1(BaseClass):
        pass
    class SubClass2(BaseClass):
        pass
    class SubSubClass1(SubClass1):
        pass
    class SubSubClass2(SubClass2):
        pass
    class SubSubSubClass1(SubSubClass1):
        pass
    test = get_all_subclasses(BaseClass)
    # Testing results
    assert SubClass1 in test
    assert SubClass2 in test
    assert SubSubClass1 in test
    assert SubSubClass2 in test
    assert SubSubSubClass1 in test

# Generated at 2022-06-22 21:18:43.776095
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(A):
        pass

    class G(A):
        pass

    class H(F):
        pass

    results = get_all_subclasses(A)

    for cls in [A, B, C, D, E, F, G, H]:
        assert cls in results

# Generated at 2022-06-22 21:18:48.305576
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    assert get_all_subclasses(A) == set([B,C,D])
    assert get_all_subclasses(B) == set([])
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set([])

# Generated at 2022-06-22 21:18:54.116602
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(E):
        pass

    class G(B):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])

# Generated at 2022-06-22 21:19:01.642493
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    classes = get_all_subclasses(A)
    assert D in classes
    assert D not in A.__subclasses__()
    assert B in classes
    assert B not in A.__subclasses__()
    assert C in classes
    assert C not in A.__subclasses__()
    assert E in classes
    assert E not in A.__subclasses__()



# Generated at 2022-06-22 21:19:09.730335
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # pylint: disable=too-few-public-methods,no-init
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set([F, G])
    assert set(get_all_subclasses(D)) == set([])
    assert set(get_all_subclasses(E)) == set([])
   

# Generated at 2022-06-22 21:19:19.184423
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test if the method get_all_subclasses works properly.
    It will test if the method get_all_subclasses return the correct number of subclasses
    for the class TestClass.

    :func:`get_all_subclasses` is used on the class TestClass which has 5 other subclasses.
    It will check if the length of the list of subclasses returned by `get_all_subclasses` is 5.

    This method is placed in the same file as :func:`get_all_subclasses` to avoid being loaded
    in the __init__.py file.
    '''
    class TestClass(object):
        pass

    class TestSubClass1(TestClass):
        pass

    class TestSubClass2(TestClass):
        pass

    class TestSubClass3(TestSubClass1):
        pass

   

# Generated at 2022-06-22 21:19:28.825404
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(C):
        pass
    class F(A):
        pass
    class G(B):
        pass
    class H(G):
        pass
    class I(B):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I])

# Generated at 2022-06-22 21:19:33.776927
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # pylint: disable=too-few-public-methods
    class A(object):  # noqa
        pass

    class B(A):  # noqa
        pass

    class C(A):  # noqa
        pass

    class D(C):  # noqa
        pass

    assert set([B, C, D]) == get_all_subclasses(A)

# Generated at 2022-06-22 21:19:35.834037
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(B): pass

    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-22 21:19:41.611235
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a hierarchy class
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass

    # We must retrieve all objects
    A_subclasses = get_all_subclasses(A)
    assert len(A_subclasses) == 6
    assert B in A_subclasses
    assert C in A_subclasses
    assert D in A_subclasses
    assert E in A_subclasses
    assert F in A_subclasses

    # We must only retrieve D and E objects
    B_subclasses = get_all_subclasses(B)
    assert len(B_subclasses) == 2
    assert D in B_subclasses
    assert E