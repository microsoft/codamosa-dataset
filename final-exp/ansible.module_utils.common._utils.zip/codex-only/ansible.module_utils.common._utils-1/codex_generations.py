

# Generated at 2022-06-22 21:09:46.904416
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(C): pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D])
    assert set(get_all_subclasses(C)) == set([E, F])
    assert set(get_all_subclasses(D)) == set([])
    assert set(get_all_subclasses(E)) == set([])
    assert set(get_all_subclasses(F)) == set([])


# Generated at 2022-06-22 21:09:58.045752
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert set() == get_all_subclasses(A) & get_all_subclasses(B) & get_all_subclasses(C) & \
        get_all_subclasses(D) & get_all_subclasses(E)
    assert {E} == get_all_subclasses(D)
    assert {B, D, E} == get_all_subclasses(A)
    assert {B, D, E} == get_all_subclasses(object)

# Generated at 2022-06-22 21:10:09.423936
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D, E, F}
    assert set(get_all_subclasses(B)) == {D, E, F}
    assert set(get_all_subclasses(C)) == set()
    assert set(get_all_subclasses(D)) == {E, F}
    assert set(get_all_subclasses(E)) == {F}
    assert set(get_all_subclasses(F)) == set()


#
# Module arguments converting functions.
#



# Generated at 2022-06-22 21:10:18.212801
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class SampleClass:
        pass

    class SubClassSampleClass(SampleClass):
        pass

    class SubClassSubClassSampleClass(SubClassSampleClass):
        pass

    class UnrelatedClass:
        pass

    assert SubClassSubClassSampleClass in get_all_subclasses(SampleClass)
    assert SubClassSampleClass in get_all_subclasses(SampleClass)
    assert SubClassSubClassSampleClass in get_all_subclasses(SubClassSampleClass)
    assert SubClassSubClassSampleClass in get_all_subclasses(SubClassSubClassSampleClass)
    assert UnrelatedClass not in get_all_subclasses(SubClassSubClassSampleClass)
    assert UnrelatedClass not in get_all_subclasses(SubClassSampleClass)

# Generated at 2022-06-22 21:10:29.120622
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(D):
        pass
    class G(D):
        pass
    # Expected result
    # A: B, C
    # B: D, E
    # C:
    # D: F, G
    # E:
    # F:
    # G:

    # Test function get_all_subclasses recursively
    assert(get_all_subclasses(A) == set([B, C, D, E, F, G]))
    # Test manually
    assert(set([B, C]) == set(A.__subclasses__()))

# Generated at 2022-06-22 21:10:35.479399
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    classes = get_all_subclasses(A)
    assert set(classes) == set([B, C, D, E]), "All subclasses are not found"

    assert get_all_subclasses(B) == set([D]), "All subclasses of B are not found"

# Generated at 2022-06-22 21:10:42.350430
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(E):
        pass

    class G(object):
        pass

    assert set(get_all_subclasses(A)) == set((B, C, D, E, F))


try:
    from __main__ import display
except ImportError:
    from ansible.utils.display import Display
    display = Display()



# Generated at 2022-06-22 21:10:51.926277
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a simple class hierarchy
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(A): pass
    class E(B): pass
    class F(B): pass
    class G(C): pass
    class H(C): pass
    class I(F): pass

    # Call get_all_subclasses(A)
    subclasses = get_all_subclasses(A)

    # Check that the correct classes are returned
    assert A in subclasses
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in subclasses
    assert H in subclasses
    assert I in subclasses

# Generated at 2022-06-22 21:10:56.557091
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(B):
        pass
    class G(F):
        pass
    class H(F):
        pass
    class I(G, H):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H, I])

# Generated at 2022-06-22 21:11:04.276809
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class _SuperClass():
        pass
    class _ChildClass(_SuperClass):
        pass
    class _SecondChildClass(_SuperClass):
        pass
    class _GrandChildClass(_ChildClass):
        pass
    class _UnknownClass():
        pass
    all_subclasses = get_all_subclasses(_SuperClass)
    assert set(_ChildClass.__mro__) <= all_subclasses
    assert set(_SecondChildClass.__mro__) <= all_subclasses
    assert set(_GrandChildClass.__mro__) <= all_subclasses
    assert _UnknownClass not in all_subclasses

# Generated at 2022-06-22 21:11:09.847854
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test for function get_all_subclasses
    """
    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F(D):
        pass

    #Unlinked class
    class K():
        pass

    # Test
    assert get_all_subclasses(A) == set([B, C, D, E, F])

# Generated at 2022-06-22 21:11:19.211253
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Animal(object):
        pass
    class Mammal(Animal):
        pass
    class Aquatic(Animal):
        pass
    class Carnivore(Mammal):
        pass
    class Herbivore(Mammal):
        pass
    class Bear(Carnivore):
        pass
    class Rabbit(Carnivore):
        pass
    class Giraffe(Herbivore):
        pass
    class Whale(Aquatic):
        pass

    animal_classes = get_all_subclasses(Animal)
    assert set(animal_classes) == set([Mammal, Aquatic, Carnivore, Herbivore, Bear, Rabbit, Giraffe, Whale])

    carnivore_classes = get_all_subclasses(Carnivore)

# Generated at 2022-06-22 21:11:30.183524
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class A1(A):
        pass

    class A2(A):
        pass

    class A11(A1):
        pass

    class A12(A1):
        pass

    class A21(A2):
        pass

    class B(object):
        pass

    class B1(B):
        pass

    classes = get_all_subclasses(A)
    assert A1 in classes
    assert A2 in classes
    assert A11 in classes
    assert A12 in classes
    assert A21 in classes
    assert B in classes
    assert B1 in classes

    classes = get_all_subclasses(A1)
    assert A11 in classes
    assert A12 in classes

    classes = get_all_subclasses(A11)

# Generated at 2022-06-22 21:11:35.422134
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    assert set(get_all_subclasses(A)) == {B, C, D, E}

# Generated at 2022-06-22 21:11:41.960550
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(A): pass
    class E(D): pass
    class F(E): pass
    class G(E): pass
    class H(B, C): pass
    class I(C, D): pass
    class J(B, F): pass
    # The expected result
    expected_iterator = set([B, C, D, E, F, G, H, I, J])
    # Make sure we have not forgotten any class
    assert expected_iterator == get_all_subclasses(A)

# Generated at 2022-06-22 21:11:48.204445
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass

    all_subclasses = get_all_subclasses(A)
    assert B in all_subclasses
    assert C in all_subclasses
    assert D in all_subclasses
    assert E in all_subclasses
    assert B.__subclasses__() not in all_subclasses

# Generated at 2022-06-22 21:11:57.488114
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B:
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(F):
        pass

    # Get subclasses of A
    actual = get_all_subclasses(A)
    # Expected subclasses of A are C, D, E, F, G
    expected = {C, D, E, F, G}
    # Assert expected equals actual
    assert actual == expected

    # Get subclasses of D
    actual = get_all_subclasses(D)
    # Expected subclasses of D are F, G
    expected = {F, G}
    # Assert expected equals actual
    assert actual == expected

# Generated at 2022-06-22 21:12:03.753871
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Test(object):
        pass
    class Test1(Test):
        pass
    class Test2(Test):
        pass
    class Test11(Test1):
        pass
    class Test12(Test1):
        pass
    class Test21(Test2):
        pass
    class Test22(Test2):
        pass

    assert set(get_all_subclasses(Test)) == set([Test1, Test2, Test11, Test12, Test21, Test22])

# Generated at 2022-06-22 21:12:11.898914
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(B,A):
        pass
    class D(C):
        pass
    assert set([A,B,C,D]) == get_all_subclasses(A)
    assert set([B,C,D]) == get_all_subclasses(B)
    assert set([C,D]) == get_all_subclasses(C)
    assert set([D]) == get_all_subclasses(D)

# Generated at 2022-06-22 21:12:21.428296
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class SuperSuperClass(object):
        pass

    class SuperClass(SuperSuperClass):
        pass

    class SubClass1(SuperClass):
        pass

    class SubClass2(SuperClass):
        pass

    class SubSubClass1(SubClass1):
        pass

    class SubSubClass2(SubClass2):
        pass

    class SuperDuperClass(object):
        pass

    class SuperDuperSubClass(SuperDuperClass):
        pass

    assert get_all_subclasses(SuperSuperClass) == set([SuperSuperClass, SuperClass, SubClass1,
                                                       SubClass2, SubSubClass1, SubSubClass2])
    assert get_all_subclasses(SuperClass) == set([SuperClass, SubClass1, SubClass2, SubSubClass1,
                                                  SubSubClass2])
   

# Generated at 2022-06-22 21:12:32.167503
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_native
    from six import class_types
    from types import ClassType
    from unittest import TestCase

    class Alpha(object): pass
    class Beta(Alpha): pass
    class Gamma(Alpha): pass
    class Delta(Beta): pass
    class Epsilon(Delta): pass

    class Zeta(object): pass
    class Eta(object): pass
    class Theta(object): pass
    class Iota(object): pass
    class Kappa(object): pass

    class Lambda(object): pass
    class Mu(Lambda): pass
    class Nu(Lambda): pass
    class Xi(Mu): pass
    class Omicron(Mu): pass
    class Pi(Omicron): pass

    class Rho(object): pass
    class Sigma(Rho): pass


# Generated at 2022-06-22 21:12:41.421873
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(E):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(F):
        pass

    classes = [A, B, C, D, E, F, G, H, I]
    for parent in classes:
        subclasses = get_all_subclasses(parent)
        # Check that the subclasses are a subset of the classes list and are not the parent itself
        assert len(subclasses) == len(set(subclasses).intersection(set(classes))) - 1



# Generated at 2022-06-22 21:12:46.784415
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])

# Generated at 2022-06-22 21:12:55.080023
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(A):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F}
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == {D, E}
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-22 21:13:01.784228
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    # Build a list of the expected classes
    expected = [A, B, C, D]

    # Find the classes
    classes = get_all_subclasses(A)

    # Check to make sure they match
    assert expected == list(classes)


# Generated at 2022-06-22 21:13:07.972028
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    assert get_all_subclasses(A) == set([B, C, D])

# Generated at 2022-06-22 21:13:14.538985
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.action.netconf import ActionModule as NetconfActionModule
    from ansible.plugins.action.netconf_get import ActionModule as NetconfGetActionModule
    from ansible.plugins.action.netconf_get_config import ActionModule as NetconfGetConfigActionModule

    assert ActionModule in get_all_subclasses(ActionModule)
    assert NetconfActionModule in get_all_subclasses(ActionModule)
    assert NetconfGetActionModule in get_all_subclasses(ActionModule)
    assert NetconfGetConfigActionModule in get_all_subclasses(ActionModule)
    assert len(get_all_subclasses(ActionModule)) == 4

# Generated at 2022-06-22 21:13:24.109575
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(E):
        pass

    # A
    all_subclasses = get_all_subclasses(A)
    assert all_subclasses == {B, C, D, E, F}
    # B
    all_subclasses = get_all_subclasses(B)
    assert all_subclasses == {C, E, F}
    # C
    all_subclasses = get_all_subclasses(C)
    assert all_subclasses == set()
    # D
    all_subclasses = get_all_subclasses(D)
    assert all_subclasses == set()
    # E
   

# Generated at 2022-06-22 21:13:33.763514
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base(object):  # pylint: disable=too-few-public-methods
        '''
        Base class used in the test

        It should have several descendants
        '''
        pass

    class Child1(Base):  # pylint: disable=too-few-public-methods
        '''
        Child1 class used in the test

        This class should have no descendants
        '''
        pass

    class Child2(Base):  # pylint: disable=too-few-public-methods
        '''
        Child2 class used in the test

        It should have one descendant
        '''
        pass


# Generated at 2022-06-22 21:13:39.110478
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(Exception) == set(BaseException.__subclasses__())
    assert set(isinstance(sc, BaseException) for sc in get_all_subclasses(Exception)) == set([True])
    assert get_all_subclasses(dict) == set([dict, OrderedDict])
    assert get_all_subclasses(dict) == set(dict.__subclasses__())
    assert set(isinstance(sc, dict) for sc in get_all_subclasses(dict)) == set([True])

# Generated at 2022-06-22 21:13:50.298142
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a simple example
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class AB(A, B):
        pass

    classes = get_all_subclasses(A)

    # Check if everything is working as expected
    assert A in classes
    assert B in classes
    assert C in classes
    assert D in classes
    assert AB in classes

    # Check if the total number is correct
    assert len(classes) == 5

    # Check the inheritance
    assert issubclass(B, A)
    assert issubclass(C, A)
    assert issubclass(D, A)
    assert issubclass(D, B)
    assert issubclass(AB, A)



# Generated at 2022-06-22 21:13:55.228986
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert len(get_all_subclasses(A)) == 5

# Generated at 2022-06-22 21:14:01.836883
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([])
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set([])

# Generated at 2022-06-22 21:14:08.719613
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-22 21:14:13.382684
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base(object):
        pass

    class A1(Base):
        pass

    class A2(Base):
        pass

    class B1(A1):
        pass

    class B2(A1):
        pass

    class C1(B1):
        pass

    assert(set(get_all_subclasses(Base)) == set([A1, A2, B1, B2, C1]))



# Generated at 2022-06-22 21:14:18.124913
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D, C):
        pass

    all_classes = get_all_subclasses(A)
    assert all_classes == set([B, C, D, E, F])



# Generated at 2022-06-22 21:14:25.270590
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a:
        pass
    class b:
        pass
    class c:
        pass
    class x(a, b):
        pass
    class y(a, c):
        pass
    class z(a, x, y, b):
        pass

    assert set(get_all_subclasses(a)) == set([x, y, z]), 'Simple a class subclass'
    assert set(get_all_subclasses(b)) == set([x, z]), 'Simple b class subclass'
    assert set(get_all_subclasses(c)) == set([y]), 'Simple c class subclass'
    assert set(get_all_subclasses(x)) == set([z]), 'Simple x class subclass'
    assert set(get_all_subclasses(y)) == set([z]), 'Simple y class subclass'

# Generated at 2022-06-22 21:14:30.141331
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C(object):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    assert set([D, E, F, G]) == get_all_subclasses(C)

# Generated at 2022-06-22 21:14:36.136051
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(A):
        pass
    assert get_all_subclasses(A) == set([B, C, E, D])
    assert get_all_subclasses(B) == set([])
    assert get_all_subclasses(D) == set([])

# Generated at 2022-06-22 21:14:41.934628
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C(object): pass
    class D(C): pass
    class E(C): pass
    class F(D): pass
    class G(F): pass
    assert get_all_subclasses(C) == set([D, E, F, G])
    assert get_all_subclasses(C) == get_all_subclasses(C)


# Generated at 2022-06-22 21:14:46.459997
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    assert(set([B, C, D, E, F]) == get_all_subclasses(A))

# Generated at 2022-06-22 21:14:57.545915
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    The following tree of classes is used for testing.

        A
        |
        |__ C
        |
        |__ B
        |   |
        |   |__ D
        |   |   |
        |   |   |__ I
        |   |   |
        |   |   |__ J
        |   |
        |   |__ E
        |
        |__ F
            |
            |__ G
            |
            |__ H
    """
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(A):
        pass
    class G(F):
        pass
    class H(F):
        pass

# Generated at 2022-06-22 21:15:03.738556
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # pylint: disable=C0103,W0621
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(C): pass
    class E(D): pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    class F(A): pass
    class G(F): pass
    class H(G): pass
    class I(H): pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H, I])

# Generated at 2022-06-22 21:15:08.113615
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses and C in subclasses and D in subclasses and E not in subclasses

# Generated at 2022-06-22 21:15:15.189897
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class test_parent():
        pass

    class test_child1(test_parent):
        pass

    class test_child2(test_parent):
        pass

    class test_child3(test_child2):
        pass

    class test_child4(test_child3):
        pass

    # The test
    assert set(get_all_subclasses(test_parent)) == set([test_child1, test_child2, test_child3, test_child4])

# Generated at 2022-06-22 21:15:26.431840
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(C):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == {D}
    assert get_all_subclasses(C) == {D, E}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(object) == {A, B, C, D, E}
    try:
        class F(D, D):
            pass
        assert False
    except TypeError:
        pass


# Generated at 2022-06-22 21:15:36.605787
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    subclasses_of_A = get_all_subclasses(A)
    subclasses_of_B = get_all_subclasses(B)
    subclasses_of_C = get_all_subclasses(C)

    assert len(subclasses_of_A) == 5
    assert len(subclasses_of_B) == 3
    assert len(subclasses_of_C) == 2

    assert B in subclasses_of_A
    assert C in subclasses_of_A
    assert D in subclasses_of_A
    assert E in subclasses_of_A
   

# Generated at 2022-06-22 21:15:41.356072
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Test:
        pass

    class TestSub(Test):
        pass

    class TestSubSub(TestSub):
        pass

    class TestSubSubSub(TestSubSub):
        pass

    class Test2:
        pass

    class Test3(Test2):
        pass

    assert get_all_subclasses(Test) == {TestSub, TestSubSub, TestSubSubSub}

# Generated at 2022-06-22 21:15:51.231952
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(B):
        pass

    class G(B):
        pass

    class H(B):
        pass

    class I(H):
        pass

    class J(F):
        pass

    class K(G):
        pass


# Generated at 2022-06-22 21:15:59.416983
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    This function checks that the get_all_subclasses function returns the correct subclasses.
    It does this by creating a small mock hierarchy of classes with various subclasses and
    checking that the correct subclasses are returned.  Note that this is an integration test
    rather than a unit test, since the testing of get_all_subclasses can only be done by
    creating a hierarchy of classes.
    """
    # Creating a mock hierarchy of classes with several subclasses
    class SuperClass(object):
        pass

    class SubClass1(SuperClass):
        pass

    class SubClass2(SuperClass):
        pass

    class SubSubClass1(SubClass1):
        pass

    class SubSubClass2(SubClass2):
        pass

    class BaseClass(object):
        pass

    # Testing the function with each class in the hierarchy
    classes

# Generated at 2022-06-22 21:16:07.132988
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass

    assert get_all_subclasses(A) == set((B, C, D, E))
    assert get_all_subclasses(B) == set((D, ))
    assert get_all_subclasses(C) == set((E, ))
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-22 21:16:12.567877
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(collections.Mapping):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(E)) == set([collections.OrderedDict])

# Generated at 2022-06-22 21:16:17.639061
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass
    class G(F):
        pass
    expected_subclasses = [B, C, D, E, F, G]
    subclasses = list(get_all_subclasses(A))
    for sc in expected_subclasses:
        assert sc in subclasses

# Generated at 2022-06-22 21:16:24.951428
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(G):
        pass

    assert(set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H]))

# Generated at 2022-06-22 21:16:33.534410
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(object):
        pass

    assert not get_all_subclasses(A)
    assert get_all_subclasses(D) == set()
    assert set(get_all_subclasses(types.ModuleType)) == set(get_all_subclasses(types.ObjectType))
    assert {B, C} == get_all_subclasses(A)

# AnsibleApp class

# Generated at 2022-06-22 21:16:36.352632
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Simply verify that a given class has all its subclasses.
    '''
    class Foo:
        pass

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    assert set(get_all_subclasses(Foo)) == set((Bar, Baz))

# Generated at 2022-06-22 21:16:47.117157
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # pylint: disable=missing-docstring,too-few-public-methods,invalid-name
    class a_cls:
        pass
    class b_cls(a_cls):
        pass
    class c_cls(a_cls):
        pass
    class d_cls(c_cls):
        pass
    class e_cls(b_cls):
        pass
    class f_cls(b_cls, c_cls):
        pass
    class g_cls(f_cls):
        pass
    class h_cls:
        pass
    count = len(get_all_subclasses(a_cls))
    assert count == 6
    count = len(get_all_subclasses(h_cls))
    assert count == 0

# Generated at 2022-06-22 21:16:56.327084
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a class
    class A(object):
        def __init__(self):
            pass

    # Define subclasses
    class B(A):
        def __init__(self):
            pass

    # Define subclasses
    class C(A):
        def __init__(self):
            pass

    # Define subclasses
    class D(B):
        def __init__(self):
            pass

    # Define subclasses
    class E(C):
        def __init__(self):
            pass

    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == {D}
    assert get_all_subclasses(C) == {E}
    assert get_all_subclasses(D) == set()


# Generated at 2022-06-22 21:17:03.916435
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Testing that get_all_subclasses works on a simple case
    '''
    # Defining a class
    class A(object):
        pass

    # Defining subclasses
    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(A):
        pass

    # Testing return
    results = get_all_subclasses(A)
    assert [B, C, D, E] == list(results)


# Generated at 2022-06-22 21:17:13.912453
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import os

    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(B):
        pass

    class F(E):
        pass

    class G(F):
        pass

    class H(F):
        pass

    class I(H):
        pass

    assert get_all_subclasses(B) == {E, F, G, H, I}
    assert get_all_subclasses(E) == {F, G, H, I}
    assert get_all_subclasses(C) == {D}
    assert get_all_subclasses(G) == set()
    assert get_all_subclasses(I) == set()

# Generated at 2022-06-22 21:17:23.944856
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Class used to test the function get_all_subclasses
    """
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D, E, F])
    assert get_all_subclasses(D) == set([E, F])
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-22 21:17:27.745969
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class B2(B):
        pass
    class C(object):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    assert get_all_subclasses(A) == set([B, D, E, B2])

# Generated at 2022-06-22 21:17:34.388272
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base(object):
        pass
    class A(Base):
        pass
    class B(Base):
        pass
    class C(A):
        pass
    class D(object):
        pass
    class E(C):
        pass
    class F(C):
        pass
    assert(set([A, B, C, D, E, F]) == get_all_subclasses(Base))

# Generated at 2022-06-22 21:17:40.234648
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(object): pass
    class F(E): pass
    class G(C): pass
    class H(D): pass

    assert len(get_all_subclasses(A)) == 4
    assert len(get_all_subclasses(B)) == 0
    assert len(get_all_subclasses(E)) == 1
    assert len(get_all_subclasses(G)) == 2
    assert len(get_all_subclasses(object)) == 7

# Generated at 2022-06-22 21:17:48.726694
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create the following graph for testing purpose
    #      A
    #    / | \
    #   D  B  C
    #   |    |
    #   E    F
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(C):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])



# Generated at 2022-06-22 21:17:59.920252
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define small hierarchy
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G:
        pass

    class H(G):
        pass

    # All classes except A and G must be reachable from A and G
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(G)) == set([H])
    # B and C must be reachable from each other
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set([F])

# Generated at 2022-06-22 21:18:10.639339
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function get_all_subclasses. Search all subclasses of a class
    '''

    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C, D):
        pass

    class F(E, D):
        pass

    class G(E):
        pass

    assert get_all_subclasses(object) == {A, B, C, D, E, F, G}
    assert get_all_subclasses(A) == {C, E, F, G}
    assert get_all_subclasses(F) == set()
    # Check that the function is not fooled by multiple inheritance
    assert get_all_subclasses(E) == {F, G}

# Generated at 2022-06-22 21:18:19.037797
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C1(object):
        pass
    class C2(C1):
        pass
    class C3(C1):
        pass
    class C4(C2):
        pass
    class C5(C2):
        pass
    class C6(C3):
        pass
    res = get_all_subclasses(C1)
    assert res == set([C2, C3, C4, C5, C6])
    res = get_all_subclasses(C2)
    assert res == set([C4, C5])

# Generated at 2022-06-22 21:18:27.302848
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(object):
        pass

    class D(C):
        pass

    class E(A):
        pass

    class F(D):
        pass

    assert F in get_all_subclasses(object)
    assert B in get_all_subclasses(object)
    assert B in get_all_subclasses(A)
    assert D in get_all_subclasses(C)
    assert D in get_all_subclasses(object)
    assert F in get_all_subclasses(D)
    assert F in get_all_subclasses(object)
    assert E in get_all_subclasses(object)
    assert E in get_all_subclasses(A)
    assert len(get_all_subclasses(A))

# Generated at 2022-06-22 21:18:31.692130
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E(A): pass
    class F(E): pass
    class G(F): pass
    class H(object): pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G}

    assert get_all_subclasses(B) == {D}
    assert get_all_subclasses(C) == {D}
    assert get_all_subclasses(D) == set()

    assert get_all_subclasses(E) == {F, G}
    assert get_all_subclasses(F) == {G}
    assert get_all_subclasses(G) == set()

    assert get_all_subclasses(H)

# Generated at 2022-06-22 21:18:37.074204
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test the get_all_subclasses
    :return: None
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(C):
        pass

    class Test(A):
        pass

    assert Test in get_all_subclasses(A)
    assert len(get_all_subclasses(A)) == 7

# Generated at 2022-06-22 21:18:43.904987
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class G(D, E):
        pass

    class F(object):
        pass

    subclasses = get_all_subclasses(A)
    assert(set((B, C, D, E, G)) == subclasses)
    assert(F not in subclasses)



# Generated at 2022-06-22 21:18:51.090602
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define some classes
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(A):
        pass
    class F(A):
        pass
    class G(B):
        pass
    class H(G):
        pass
    class I(G):
        pass
    class J(G):
        pass
    class K(J):
        pass
    class L(J):
        pass
    # check that get_all_subclasses can find Class C, D, E, F, G, H, I, J, K, L that are children of Class A

# Generated at 2022-06-22 21:18:59.438366
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import abc
    import sys
    import unittest

    class First(object):
        __metaclass__ = abc.ABCMeta
        def __init__(self):
            pass

    class Second(First):
        def __init__(self):
            pass

    class Third(First):
        def __init__(self):
            pass

    class Fourth(Second):
        def __init__(self):
            pass

    class Fifth(Second):
        def __init__(self):
            pass

    class Sixth(Third):
        def __init__(self):
            pass

    class Seventh(Third):
        def __init__(self):
            pass


# Generated at 2022-06-22 21:19:03.384004
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(C):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])

# Generated at 2022-06-22 21:19:07.075724
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses and C in subclasses and D in subclasses and E in subclasses

# Generated at 2022-06-22 21:19:12.618250
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C1(object):
        pass

    class C2(C1):
        pass

    class C3(C1):
        pass

    class C4(C2):
        pass

    class C5(object):
        pass

    class C6(C5):
        pass

    assert get_all_subclasses(C1) == set([C2, C3, C4])
    assert get_all_subclasses(C2) == set([C4])
    assert get_all_subclasses(C3) == set([])
    assert get_all_subclasses(C4) == set([])
    assert get_all_subclasses(C5) == set([C6])

# Generated at 2022-06-22 21:19:18.824164
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-22 21:19:26.524648
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(object):
        pass
    assert set([A, B, C, D, E]) == get_all_subclasses(A)
    assert set([A, B, C, D, E]) == get_all_subclasses(B)
    assert set([C]) == get_all_subclasses(C)
    assert set([D, E]) == get_all_subclasses(D)
    assert set([E]) == get_all_subclasses(E)
    assert set([F]) == get_all_subclasses(F)
    assert set([]) == get_all_subclasses(object)

# Generated at 2022-06-22 21:19:37.159334
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This function tests the function get_all_subclasses.
    '''
    # A simple example
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    assert get_all_subclasses(A) == {B, C, D}
    assert get_all_subclasses(B) == {C, D}
    assert get_all_subclasses(C) == {D}
    assert get_all_subclasses(D) == set()
    # A more complex example
    class E(object):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    assert get_all

# Generated at 2022-06-22 21:19:41.590223
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test case
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass
    # Test for method get_all_subclasses
    assert get_all_subclasses(A) == set([A, B, C, D])