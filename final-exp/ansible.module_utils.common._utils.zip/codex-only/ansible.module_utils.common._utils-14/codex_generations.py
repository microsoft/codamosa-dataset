

# Generated at 2022-06-22 21:09:47.446183
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys
    # Test basic case
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses

    # Test a more complex case
    class E(B):
        pass
    class F:
        pass
    class G(F):
        pass
    class H(E):
        pass
    class I(G):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert H in subclasses


# Generated at 2022-06-22 21:09:58.087364
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class ClassA(object):
        ''' Class A has no subclass '''

    class ClassB(object):
        ''' Class B has one subclass '''

    class ClassC(ClassB):
        ''' Class C is the subclass of Class B '''

    class ClassD(object):
        ''' Class D has two subclasses '''

    class ClassE(ClassD):
        ''' Class E is the subclass of Class D '''

    class ClassF(ClassD):
        ''' Class F is the subclass of Class D '''

    class ClassG(object):
        ''' Class G has one subclass and one subclass has a subclass '''

    class ClassH(ClassG):
        ''' Class H is the subclass of Class G '''

    class ClassI(ClassG):
        ''' Class I is the subclass of Class G '''

   

# Generated at 2022-06-22 21:10:04.037950
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(D) == set([E])

# Generated at 2022-06-22 21:10:14.814606
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    assert get_all_subclasses(A) == {B, C, D, E, F}
    assert get_all_subclasses(B) == {D, E}
    assert get_all_subclasses(C) == {F}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()
    assert get_all_subclasses(object) == {A}
    assert get_all_subclasses(Exception) == set()
    assert get_all

# Generated at 2022-06-22 21:10:20.642335
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F}
    assert get_all_subclasses(B) == {D}
    assert get_all_subclasses(C) == {E, F}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == {F}
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-22 21:10:31.429635
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        def __init__(self):
            pass

    class B(A):
        def __init__(self):
            pass

    class C(A):
        def __init__(self):
            pass

    class D(B):
        def __init__(self):
            pass

    class E(B):
        def __init__(self):
            pass

    class F(E):
        def __init__(self):
            pass

    class G(B):
        def __init__(self):
            pass

    class H(C):
        def __init__(self):
            pass

    class I(D):
        def __init__(self):
            pass

    class J(E):
        def __init__(self):
            pass


# Generated at 2022-06-22 21:10:38.528754
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Testing class
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(object):
        pass

    class E(D):
        pass

    class F(E):
        pass

    # Testing
    assert set(get_all_subclasses(A)) == set([B, C])
    assert set(get_all_subclasses(B)) == set([C])
    assert set(get_all_subclasses(C)) == set()
    assert set(get_all_subclasses(D)) == set([E, F])


# Generated at 2022-06-22 21:10:44.659009
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Foo():
        pass
    class Bar(Foo):
        pass
    class Baz(Foo):
        pass
    class BarBaz(Bar, Baz):
        pass
    class BazBar(Baz, Bar):
        pass
    assert sorted(get_all_subclasses(Foo), key=lambda e: e.__name__) == sorted([Bar, BarBaz, Baz, BazBar], key=lambda e: e.__name__)

# Generated at 2022-06-22 21:10:52.752579
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(C): pass
    class G(D): pass
    class H(F): pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])
    assert get_all_subclasses(B) == set([D, G])
    assert get_all_subclasses(D) == set([G])
    assert get_all_subclasses(H) == set([])

# Generated at 2022-06-22 21:11:01.878303
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass

    # Before:  A -> B -> D, E -> F, G
    # After:   A -> B -> D, E, C -> F, G
    expected = set([B, D, E, C, F, G])
    actual = get_all_subclasses(A)
    assert actual == expected, 'get_all_subclasses(A) returned {}. Expected set({})'.format(actual, expected)


# Generated at 2022-06-22 21:11:09.245910
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Toto(object): pass
    class Tata(object): pass
    class Titi(Tata): pass
    class Tutu(Tata): pass
    class Tata(Tata): pass
    class Tata(Tata): pass

    assert get_all_subclasses(Toto) == set()
    assert get_all_subclasses(Tata) == {Titi, Tutu}
    assert get_all_subclasses(object) == {Tata, Toto, Titi, Tutu}
    assert get_all_subclasses(type) == {bool, dict, int, list, object, set, str, type}

# Generated at 2022-06-22 21:11:15.410336
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(F):
        pass
    class I(G):
        pass

    assert set(get_all_subclasses(A)) == set((B, D, E, C, F, H, G, I))

# Generated at 2022-06-22 21:11:19.734935
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-22 21:11:21.943186
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(A): pass
    class E(B): pass
    class F(B): pass
    assert get_all_subclasses(A) == set([B, C, D, E, F])



# Generated at 2022-06-22 21:11:27.067224
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C1:
        pass
    class C12(C1):
        pass
    class C2:
        pass
    class C21(C2):
        pass
    class C22(C2):
        pass
    class C3:
        pass
    class C31(C3):
        pass
    class C32(C3):
        pass
    subclasses = get_all_subclasses(C1)
    assert len(subclasses) == 2
    assert C1 in subclasses
    assert C12 in subclasses
    subclasses = get_all_subclasses(C2)
    assert len(subclasses) == 2
    assert C21 in subclasses
    assert C22 in subclasses
    subclasses = get_all_subclasses(C3)
    assert len(subclasses) == 2

# Generated at 2022-06-22 21:11:38.505615
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import become_loader, connection_loader
    from ansible.plugins.loader import lookups_loader, module_loader, strategy_loader, vars_loader
    from ansible.plugins.strategy import StrategyBase

    subclasses_PlayContext = get_all_subclasses(PlayContext)
    assert len(subclasses_PlayContext) == 0
    subclasses_StrategyBase = get_all_subclasses(StrategyBase)
    assert len(subclasses_StrategyBase) != 0
    subclasses_become_loader = get_all_subclasses(become_loader)
    assert len(subclasses_become_loader) != 0
    subclasses_connection_loader = get_all_subclasses(connection_loader)

# Generated at 2022-06-22 21:11:45.386488
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Simple test to make sure we get all subclasses
    """
    import types
    class BaseClass(object):
        pass
    class Class1(BaseClass):
        pass
    class Class2(BaseClass):
        pass
    class Class3(Class1):
        pass
    class Class4(Class2):
        pass
    class Class5(Class1):
        pass
    class Class6(Class2):
        pass
    class Class7(Class3):
        pass
    class Class8(Class4):
        pass
    class Class9(Class4):
        pass
    class Class10(Class9):
        pass
    class Class11(Class4):
        pass
    class Class12(Class4):
        pass
    class Class13(Class11):
        pass

# Generated at 2022-06-22 21:11:52.399450
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass

    classes = get_all_subclasses(A)
    assert len(classes) == 6
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert A not in classes

# Generated at 2022-06-22 21:11:57.510317
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    classes = [A, B, C, D, E, F, G]

    for index, a in enumerate(classes):
        if index == 0:
            continue

        assert a in get_all_subclasses(classes[0])

# Generated at 2022-06-22 21:12:06.456428
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a tree with 10 nodes
    #  A
    #
    # B    C
    #     D E
    #       F
    #      G
    #     H
    #   I
    # J
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(C):
        pass

    class I(A):
        pass

    class J(A):
        pass
    classes = get_all_subclasses(A)
    assert set([B, C, D, E, F, G, H, I, J]) == classes
    classes = get_all_sub

# Generated at 2022-06-22 21:12:14.093583
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(B):
        pass
    class G(C):
        pass
    class H(F):
        pass
    class I(F):
        pass
    subclass_list = [H, I, G, D, E, F, B, C, A]
    assert len(subclass_list) == len(get_all_subclasses(A))

# Generated at 2022-06-22 21:12:23.361449
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestCls(object):
        pass
    class TestClsChild1(TestCls):
        pass
    class TestClsChild2(TestCls):
        pass
    class TestClsChild3(TestCls):
        class TestClsChild3_1(TestCls):
            pass
    # Test that test is working correctly
    assert TestClsChild3.__subclasses__()[0] == TestClsChild3_1
    # Test that get_all_subclasses works for depth of 1
    assert set([TestClsChild1, TestClsChild2, TestClsChild3]) == set(TestCls.__subclasses__())
    # Test that get_all_subclasses works for multiple levels of subclassing

# Generated at 2022-06-22 21:12:29.884391
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D:
        pass

    class E(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C])
    assert set(get_all_subclasses(B)) == set()
    assert set(get_all_subclasses(D)) == set([E])

# Generated at 2022-06-22 21:12:38.002912
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import ansible.module_utils.basic
    scalc = get_all_subclasses(ansible.module_utils.basic._AnsibleModule)
    assert len(scalc) == 10
    assert ansible.module_utils.basic._AnsibleModule in scalc
    assert ansible.module_utils.basic.AnsibleModule in scalc
    assert ansible.module_utils.basic._AnsibleModuleShell in scalc
    assert ansible.module_utils.basic.AnsibleModuleShell in scalc


# Generated at 2022-06-22 21:12:48.405740
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(A):
        pass

    # Testing only subclasses of class A
    subclasses = set(get_all_subclasses(A))
    assert len(subclasses) == 3
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses

    # Testing only subclasses of class B
    subclasses = set(get_all_subclasses(B))
    assert len(subclasses) == 2
    assert C in subclasses
    assert D in subclasses

    # Testing only subclasses of class C
    subclasses = set(get_all_subclasses(C))
    assert len(subclasses) == 1
   

# Generated at 2022-06-22 21:12:57.023285
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Testing get_all_subclasses
    '''
    # Simple inheritance test
    # We have 3 subclasses: B, C and D
    #   A -> B -> C
    #          \-> D
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    assert get_all_subclasses(A) == {B, C, D}
    # Multiple inheritance test
    # We have 3 subclasses: B, C and D
    #   A -> B
    #   |
    #   \-> C -> D
    class E(object):
        pass
    class F(D, E):
        pass
    assert get_all_subclasses(A) == {B, C, D, F}

# Generated at 2022-06-22 21:13:01.053619
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    assert get_all_subclasses(A) == set((B, C, D))

# Generated at 2022-06-22 21:13:10.372763
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class BaseClass(object):
        pass

    class ChildClass1(BaseClass):
        pass

    class ChildChildClass1(ChildClass1):
        pass

    class GrandChildClass1(ChildClass1):
        pass

    class ChildClass2(BaseClass):
        pass

    class GrandChildClass2(ChildClass2):
        pass

    class GrandGrandChildClass2(GrandChildClass2):
        pass

    class ChildClass3(BaseClass):
        pass

    class ChildClass4(BaseClass):
        pass

    class FakeChildChildClass1(BaseClass):
        pass

    classes = get_all_subclasses(BaseClass)
    assert ChildChildClass1 in classes
    assert GrandChildClass1 in classes
    assert GrandChildClass2 in classes
    assert GrandGrandChildClass2 in classes
    assert ChildChildClass1 in classes

# Generated at 2022-06-22 21:13:12.932965
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class a(object): pass
    class b(a): pass
    class c(a): pass
    class d(c): pass
    class e(c): pass
    class f(d, e): pass

    assert get_all_subclasses(a) == set([b, c, d, e, f])

# Generated at 2022-06-22 21:13:17.952761
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(A):
        pass

    class F(E):
        pass

    class G:
        pass

    class H(G):
        pass

    A_subclasses = get_all_subclasses(A)

    # Tests classes are retrieved
    assert B in A_subclasses
    assert C in A_subclasses
    assert D in A_subclasses
    assert E in A_subclasses
    assert F in A_subclasses
    # Tests not ancestor are not retrieved
    assert G not in A_subclasses
    assert H not in A_subclasses

# Generated at 2022-06-22 21:13:21.943065
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a(object):
        pass

    class b(a):
        pass

    class c(a):
        pass

    class d(c):
        pass

    class e(c):
        pass

    assert sorted(list(get_all_subclasses(a))) == sorted([b, c, d, e])



# Generated at 2022-06-22 21:13:32.632063
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import namedtuple
    A = namedtuple('A', ['a'])
    B = namedtuple('B', ['b'])

    C = namedtuple('C', ['a', 'b'])

    D = namedtuple('D', ['b'])

    E = namedtuple('E', ['e'])
    F = namedtuple('F', ['e'])

    # Expected result
    exp = [C, D]

    # Test
    res = get_all_subclasses(C)
    assert res == exp, 'Expecting {0} got {1}'.format(exp, res)

    # Test with multiple levels of inheritance
    res = get_all_subclasses(B)
    assert res == exp, 'Expecting {0} got {1}'.format(exp, res)

    #

# Generated at 2022-06-22 21:13:36.564841
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(D):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(D)) == set([E])

# Generated at 2022-06-22 21:13:46.042302
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(F):
        pass
    class I(F):
        pass
    class J(G):
        pass
    class K(G):
        pass

    # Let's check the whole tree
    assert set([A, B, C, D, E, F, G, H, I, J, K]) == get_all_subclasses(A)



# Generated at 2022-06-22 21:13:50.649043
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E])



# Generated at 2022-06-22 21:14:01.925219
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        def __init__(self):
            self.x = 0

    class B(A):
        def __init__(self):
            super(B, self).__init__()
            self.x = 1

    class C(A):
        def __init__(self):
            super(C, self).__init__()
            self.x = 2

    class D(B):
        def __init__(self):
            super(D, self).__init__()
            self.x = 3

    class E(B):
        def __init__(self):
            super(E, self).__init__()
            self.x = 4

    class F(C):
        def __init__(self):
            super(F, self).__init__()
            self.x = 5

   

# Generated at 2022-06-22 21:14:06.542193
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Example of class structure
    class A(object):
        a = 1
    class B(A):
        b = 2
    class C(A):
        c = 3
    class D(B, C):
        d = 4
    class E(A):
        e = 5
    class F(D, E):
        f = 6
    class G(E):
        i = 7

    # Creation of a list of class which contain all subclasses of E
    expected_list = [B, C, D, E, F, G]

    # Test that returned list contains the same elements
    assert sorted(get_all_subclasses(E), key=lambda x: x.__name__) == expected_list

# Generated at 2022-06-22 21:14:14.377220
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class A1(A):
        pass
    class A2(A):
        pass
    class A11(A1):
        pass
    class A12(A1):
        pass
    assert get_all_subclasses(A) == set([A1, A11, A12, A2])

    class B: pass
    class B1(B): pass
    class B2(B): pass
    class B11(B1): pass
    class B12(B1): pass
    class B111(B11): pass
    class B121(B12): pass
    assert get_all_subclasses(B) == set([B1, B2, B11, B111, B12, B121])

    class C: pass
    class C1(C): pass

# Generated at 2022-06-22 21:14:19.340117
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert get_all_subclasses(A) == set((B, D, C))
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set((D,))
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-22 21:14:27.964129
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test of get_all_subclasses(class)

    :rtype: list
    :returns: The list of all the classes present in the test.

    This test will fail if a new class is added or removed from the test.
    '''
    # Testing class
    class A():
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    # Running test
    assert get_all_subclasses(A) == {B, C, D}

# Generated at 2022-06-22 21:14:35.857330
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(object):
        pass

    assert set([B, C, D, E]) == get_all_subclasses(A)
    assert set([B, C, D, E]) != get_all_subclasses(A)
    assert len(set([B, C, D, E, F])) == len(get_all_subclasses(object))

# Generated at 2022-06-22 21:14:44.083724
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # We create a random class hierarchy to check the function
    # Function to check if a node is in a path
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(B):
        pass
    class H(B):
        pass
    class I(F):
        pass
    for i in get_all_subclasses(A):
        print(i)

# Generated at 2022-06-22 21:14:50.411265
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(object):
        pass

    assert sorted(get_all_subclasses(A)) == [B, C, D]
    assert sorted(get_all_subclasses(B)) == [C]
    assert sorted(get_all_subclasses(C)) == []
    assert sorted(get_all_subclasses(D)) == []
    assert sorted(get_all_subclasses(E)) == []
    assert sorted(get_all_subclasses(object)) == []

# Generated at 2022-06-22 21:14:59.867306
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(A): pass
    class F(D): pass
    class G(D): pass

    # Test a direct inheritance
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert G in get_all_subclasses(A)

    # Test a indirect inheritance
    assert D in get_all_subclasses(B)
    assert F in get_all_subclasses(B)
    assert G in get_all_subclasses(B)

    # Test

# Generated at 2022-06-22 21:15:10.385037
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    class G(E): pass

    l_classes_A = [B, C]
    l_classes_B = [D]
    l_classes_C = [E]
    l_classes_D = [F]
    l_classes_E = [G]

    assert B in get_all_subclasses(A)
    # Test that get_all_subclasses works with a list of classes
    assert get_all_subclasses(A) == set(l_classes_A + l_classes_B + l_classes_C + l_classes_D + l_classes_E)
    # Test that get_all_subclasses

# Generated at 2022-06-22 21:15:14.764025
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Test1(object):
        pass

    class Test2(Test1):
        pass

    class Test3(Test1):
        pass

    class Test4(Test2):
        pass

    assert(set(get_all_subclasses(Test1)) == set([Test2, Test3, Test4]))

# Generated at 2022-06-22 21:15:26.018894
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(C): pass
    class F(E): pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([])
    assert set(get_all_subclasses(C)) == set([D, E, F])
    assert set(get_all_subclasses(D)) == set([])
    assert set(get_all_subclasses(E)) == set([F])
    assert set(get_all_subclasses(F)) == set([])

    # Confirm with a second call to get_all_subclasses

# Generated at 2022-06-22 21:15:32.585166
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(A):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(F):
        pass

    res = get_all_subclasses(A)

    # Check if res contains all expected classes
    assert B in res
    assert C in res
    assert D in res
    assert E in res
    assert F in res
    assert G in res
    assert H in res

# Generated at 2022-06-22 21:15:43.385271
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Generating an inheritance tree
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(D): pass
    class F(D): pass
    class G(D): pass
    class Z(B, F): pass

    # Testing the various class
    assert(set(get_all_subclasses(A)) == set([B, C, D, E, F, G, Z]))
    assert(set(get_all_subclasses(B)) == set([Z]))
    assert(set(get_all_subclasses(C)) == set([D, E, F, G]))
    assert(set(get_all_subclasses(D)) == set([E, F, G]))

# Generated at 2022-06-22 21:15:51.752548
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    This function is a unit test for function get_all_subclasses.

    This is a simple unit test.  It uses the following class definition:

    .. code-block:: python

        class A(object):
            pass
        class B(A):
            pass
        class C(A):
            pass
        class D(C):
            pass

    It then uses the :py:func:`get_all_subclasses` function to find all of the subclasses of
    class A.  It asserts that the result is a set containing the classes B, C, and D.
    """
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass

    found_classes = get_all_subclasses(A)

# Generated at 2022-06-22 21:15:57.854128
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(F):
        pass
    class K(F):
        pass
    class L(J):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H, I, J, K, L])



# Generated at 2022-06-22 21:16:08.516355
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    In order to test this function, we had to create some dummy python classes
    which could be instantiated and assigned the following structure:
        ClassA
        - SubClassA1
          - SubClassA2
        - SubClassA3
          - SubClassA4
              - SubClassA5
              - SubClassA6
        - SubClassA7
          - SubClassA8
              - SubClassA9
                  - SubClassA10
                      - SubClassA11
    '''
    class ClassA(object):
        pass

    class SubClassA1(ClassA):
        pass

    class SubClassA2(SubClassA1):
        pass

    class SubClassA3(ClassA):
        pass

    class SubClassA4(SubClassA3):
        pass


# Generated at 2022-06-22 21:16:17.146762
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert E in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert len(get_all_subclasses(A)) == 4


# Re-export only all methods, without prefixing them with get_
# This makes it easier to use them as helpers, without having to import all of _utils
# Example:
# from ansible.module_utils._text import to_text
# to_text(b'foo')
#
# Instead of:
# from ansible

# Generated at 2022-06-22 21:16:22.304802
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Base class to test
    class Base(object):
        pass

    # Simple class hierarchy to test
    class SimpleRoot(Base):
        pass
    class SimpleChild(SimpleRoot):
        pass

    # Multiple levels class hierarchy to test
    class MultiRoot(Base):
        pass
    class MultiChild(MultiRoot):
        pass
    class MultiSubChild(MultiChild):
        pass

    # Multiple inheritance
    class MultiChild2(MultiRoot):
        pass
    class MultiChild3(MultiChild):
        pass

    # Declare a unknown class to test if it is returned
    class Unknown(object):
        pass

    # Search all subclasses of Base class
    class_iter = get_all_subclasses(Base)

    # Check if all subclasses are found
    assert(len(class_iter) == 6)

# Generated at 2022-06-22 21:16:27.981077
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(A) == set([C, E, F])
    assert get_all_subclasses(B) == set([D])



# Generated at 2022-06-22 21:16:38.957776
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):               # class A
        pass
    class B(A):                    # class A > class B
        pass
    class C(A):                    # class A > class C
        pass
    class D(B):                    # class A > class B > class D
        pass
    class E(object):               # class E
        pass
    class F(E):                    # class E > class F
        pass
    class G(E):                    # class E > class G
        pass
    class H(object):               # class H
        pass
    class I(H):                    # class H > class I
        pass
    class J(H):                    # class H > class J
        pass
    class K(object):               # class K
        pass
    class L(K):                    # class K > class L
        pass

# Generated at 2022-06-22 21:16:48.800636
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass
    class F(D): pass
    class G(object): pass
    class H(G): pass
    class I(H): pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, E, F])
    assert set(get_all_subclasses(D)) == set([E, F])
    assert set(get_all_subclasses(G)) == set([H, I])
    assert set(get_all_subclasses(I)) == set([])

# Generated at 2022-06-22 21:16:51.702834
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a(object): pass
    class b(a): pass
    class c(b): pass
    class d(a): pass

    assert set(get_all_subclasses(a)) == set([b, c, d])

# Generated at 2022-06-22 21:16:57.046007
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
        Test the get_all_subclasses function
    """
    # Create test classes
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class Z(object):
        pass

    # Check if comes with the expected values
    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(Z)) == set()

# Generated at 2022-06-22 21:17:03.915874
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test that get_all_subclasses(cls) behaves as expected
    """
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    classes = set([A, B, C, D, E])
    assert set(get_all_subclasses(A)) == classes



# Generated at 2022-06-22 21:17:13.957392
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(F):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G, H}
    assert get_all_subclasses(B) == {D, G}
    assert get_all_subclasses(C) == {E, F, H}
    assert get_all_subclasses(D) == {G}
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == {H}
    assert get_all_subclasses

# Generated at 2022-06-22 21:17:15.799365
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(object) == {object}

# Generated at 2022-06-22 21:17:21.002505
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Defining some random python classes
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(A):
        pass

    class F(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([C])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-22 21:17:29.991697
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(C): pass
    class F(D): pass
    class G(F): pass
    class H(G): pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H])
    assert set(get_all_subclasses(B)) == set([])
    assert set(get_all_subclasses(C)) == set([D, E, F, G, H])
    assert set(get_all_subclasses(D)) == set([F, G, H])
    assert set(get_all_subclasses(E)) == set([])

# Generated at 2022-06-22 21:17:37.353565
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E(D): pass
    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(D) == set([E])
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-22 21:17:48.874303
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    assert set([B, C, D, E]) == get_all_subclasses(A)
    assert set([C, D, E]) == get_all_subclasses(B)
    assert set([D, E]) == get_all_subclasses(C)
    assert set([E]) == get_all_subclasses(D)
    assert set([]) == get_all_subclasses(E)
    assert set([C, D, E]) == get_all_subclasses(C)
    assert set([E]) == get_all_subclasses(D)
    assert set([]) == get_all_subclasses(E)

# Generated at 2022-06-22 21:18:00.039865
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test class model
    class TestClass1(object):
        pass

    class TestClass2(object):
        pass

    t1 = TestClass1()
    t2 = TestClass2()
    t11 = TestClass1()
    # Testing two levels of subclasses
    assert set(t2.__class__.__subclasses__()) == set([t11.__class__])
    assert get_all_subclasses(t2.__class__) == set([t11.__class__])
    # Testing subclasses of several levels
    assert t1.__class__.__subclasses__() == [t11.__class__, t2.__class__]
    assert get_all_subclasses(t1.__class__) == set([t11.__class__, t2.__class__])
    # Testing classes with

# Generated at 2022-06-22 21:18:07.552507
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class E(A):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class K(B):
        pass

    assert set(get_all_subclasses(A)) == set([B,C,E,F,G,H,K])



# Generated at 2022-06-22 21:18:13.273431
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Object(object):
        pass

    class A(Object):
        pass

    class B(Object):
        pass

    class C(A):
        pass

    class D(C, B):
        pass

    subclasses = get_all_subclasses(Object)
    expected_subclasses = [A, C, B, D]
    assert subclasses == set(expected_subclasses)

# Generated at 2022-06-22 21:18:24.198538
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a(object):
        pass

    class b(a):
        pass

    class c(a):
        pass

    class f(b):
        pass

    class e(b):
        pass

    class d(c):
        pass

    assert a in get_all_subclasses(a), "a should be in the set of a's subclasses"
    assert b in get_all_subclasses(a), "b should be in the set of a's subclasses"
    assert c in get_all_subclasses(a), "c should be in the set of a's subclasses"
    assert d in get_all_subclasses(a), "d should be in the set of a's subclasses"
    assert e in get_all_subclasses(a), "e should be in the set of a's subclasses"

# Generated at 2022-06-22 21:18:29.995118
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])



# Generated at 2022-06-22 21:18:33.889155
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert(get_all_subclasses(A) == {B, C, D})



# Generated at 2022-06-22 21:18:41.372492
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([])
    assert get_all_subclasses(E) == set([])



# Generated at 2022-06-22 21:18:46.084730
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test case for function get_all_subclasses

    Define two classes A and B. B extends class A.
    Testing function get_all_subclasses for class A should return class A and class B
    '''
    class A:
        pass

    class B(A):
        pass

    classes = get_all_subclasses(A)
    assert A in classes
    assert B in classes

# Generated at 2022-06-22 21:18:55.237423
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(object): pass
    class D(A): pass
    class E(A): pass
    class F(B): pass
    class G(F): pass
    class H(G): pass
    class I(D): pass
    assert get_all_subclasses(A) == set([B, D, E, F, G, H, I])
    assert get_all_subclasses(B) == set([F, G, H])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([I])

# Generated at 2022-06-22 21:19:06.499777
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function :py:func:`get_all_subclasses`.
    '''

    # Defined an example classes
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(G):
        pass

    class I(H):
        pass

    # Check the functions
    assert get_all_subclasses(A) == {B, C, D, E, F, G, H, I}
    assert get_all_subclasses(B) == {D, E, F, G, H, I}

# Generated at 2022-06-22 21:19:17.099493
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    A test function to test the get_all_subclasses function.
    '''
    class Animal(object):
        pass

    class Dog(Animal):
        pass

    class Duck(Animal):
        pass

    class Poodle(Dog):
        pass

    class JackRussel(Dog):
        pass

    class Fish(object):
        pass

    assert set([Poodle, JackRussel]) == set(get_all_subclasses(Dog))
    assert set([Dog, Duck, Poodle, JackRussel]) == set(get_all_subclasses(Animal))
    assert set([Fish]) == set(get_all_subclasses(Fish))

# Generated at 2022-06-22 21:19:21.801722
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections

    # Create a custom class
    class A(object):
        pass

    # Create a subclass of class A
    class B(A):
        pass

    # Create a subclass of class B
    class C(B):
        pass

    # Test the function works
    assert get_all_subclasses(A) == set([B, C])

# Generated at 2022-06-22 21:19:32.099054
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils.common.collections import ImmutableDict
    import ansible.module_utils.basic


# Generated at 2022-06-22 21:19:36.146512
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestParent(object):
        pass

    class TestChild1(TestParent):
        pass

    class TestChild2(TestParent):
        pass

    class TestGrandChild(TestChild1):
        pass

    assert set(get_all_subclasses(TestParent)) == set((TestChild1, TestChild2, TestGrandChild))