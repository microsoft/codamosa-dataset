

# Generated at 2022-06-22 21:09:46.071750
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function get_all_subclasses

    To test this function, we will build a class hierarchy like:
     C1
     |\
     | C3
     |/
     C2
     |\
     | C5
     |/
     C4

    We will then validate that C1, C2, C3, C4, C5 and their
    subclasses is the list of subclasses of C1.
    '''

    # Build the class hierarchy
    class C1(object):
        pass

    class C2(C1):
        pass

    class C3(C1):
        pass

    class C4(C2):
        pass

    class C5(C2):
        pass

    assert set([C1, C2, C3, C4, C5]) == get_all_sub

# Generated at 2022-06-22 21:09:57.488279
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(C):
        pass

    class G(object):
        pass
    class H(object):
        pass
    class I(object):
        pass
    class J(object):
        pass

    class K(H, I, J):
        pass

    class L(A, G, K):
        pass

    class M(C, K):
        pass

    test_classes = [A, B, C, D, E, F, G, H, I, J, K, L, M]

    for cls in get_all_subclasses(object):
        assert cls in test_classes
        test

# Generated at 2022-06-22 21:10:05.146606
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])
    # C does not have any subclasses
    assert set(get_all_subclasses(C)) == set([])

# Generated at 2022-06-22 21:10:15.636659
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D, object):
        pass

    class F(E):
        pass

    class G(object):
        pass

    class H(G):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, E, F])
    assert get_all_subclasses(C) == set([D, E, F])
    assert get_all_subclasses(D) == set([E, F])
    assert get_all_subclasses(E) == set([F])

# Generated at 2022-06-22 21:10:27.444965
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import collections

    class Foo(object):
        pass

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    class Boo(Bar):
        pass

    class Baa(Bar):
        pass

    class Bee(Baa):
        pass

    class Bii(Baz):
        pass

    class BiiFoo(Bii, Foo):
        pass

    class Foob(object):
        pass

    class TestGetAllSubclasses(unittest.TestCase):
        def test_no_subclass(self):
            self.assertSetEqual(set(), get_all_subclasses(Foob))

        def test_one_subclasses(self):
            self.assertSetEqual(set(), get_all_subclasses(Foo))

# Generated at 2022-06-22 21:10:34.207637
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # The classes for this test
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(F):
        pass

    subclasses = get_all_subclasses(A)
    assert set(subclasses) == set((B, C, D, E, F, G))

# Generated at 2022-06-22 21:10:44.383675
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # This is the class hierarchy we are going to use for our tests
    # o, oo
    # |  |
    # o, oo
    class o(object):
        pass

    class oo(object):
        pass

    class ooo(o):
        pass

    class oooo(o):
        pass

    class ooooo(oo):
        pass

    class oooooo(oo):
        pass

    expected_classes = [o, ooo, ooo, oooo, ooo, ooooo, ooo, oooooo, oo]
    for cls in [o, oo]:
        # Retrieve all subclasses
        result = get_all_subclasses(cls)
        assert len(result) == len(expected_classes)
        for rc in result:
            assert rc in expected_classes



# Generated at 2022-06-22 21:10:54.259492
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(I):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G, H, I, J, K}
    assert get_all_subclasses(B) == {D, F, H, J}
    assert get_all_subclasses(C) == {E, G, I, K}
    assert get_all_subclasses(D)

# Generated at 2022-06-22 21:11:01.391624
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C, D):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == {D, E}
    assert get_all_subclasses(C) == {E}
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-22 21:11:05.737822
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Foo():
        pass
    class Faa(Foo):
        pass
    class Fee(Foo):
        pass
    class Fii(Fee):
        pass
    res = get_all_subclasses(Foo)
    assert res == set([Faa, Fee, Fii])

# Generated at 2022-06-22 21:11:10.148366
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import re
    import types

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(object):
        pass

    assert get_all_subclasses(A) == [B, C, E]
    assert get_all_subclasses(B) == [C]
    assert get_all_subclasses(C) == []
    assert get_all_subclasses(D) == [E]
    assert get_all_subclasses(E) == []
    assert get_all_subclasses(F) == []
    assert get_all_subclasses(object) == get_all_subclasses(re)
    assert get_all_subclasses(object) == get_all

# Generated at 2022-06-22 21:11:19.422751
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for get_all_subclasses
    '''

    class A(object):
        '''
        A is the base class
        '''
        pass

    class B(A):
        '''
        B inherits A
        '''
        pass

    class C(A):
        '''
        C inherits A
        '''
        pass

    class D(B):
        '''
        D inherits from B
        '''
        pass

    class E(C):
        '''
        E inherits from C
        '''
        pass

    class F(D):
        '''
        F inherits from D
        '''
        pass

    class G(F):
        '''
        G inherits from F
        '''
        pass


# Generated at 2022-06-22 21:11:30.343135
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test that get_all_subclasses return expected data
    """
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(D):
        pass
    class H(F):
        pass
    class I(H):
        pass
    class J(H):
        pass
    class K(J):
        pass
    class L(A):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I, J, K, L])
    assert get_all_subclasses(B) == set([C])
    assert get_all_

# Generated at 2022-06-22 21:11:38.793560
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Verify that get_all_subclasses function returns expected results
    # Create a class containing a single function returning the subclasses
    class ClassA(object):
        def __subclasses__(self):
            return [ClassB, ClassC]

    # Create 2 classes for testing
    class ClassB(ClassA):
        pass

    class ClassC(ClassA):
        pass

    # Verify that we get the expected classes
    expected = set([ClassA, ClassB, ClassC])
    result = get_all_subclasses(ClassA)
    assert len(result) == len(expected)
    assert result == expected


# Generated at 2022-06-22 21:11:40.603207
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from _jsonnet import Jsonnet
    from _text import Text
    assert Jsonnet in get_all_subclasses(Text)

# Generated at 2022-06-22 21:11:46.526865
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define unit test class
    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(A):
        pass

    class G(F):
        pass

    class H(F):
        pass

    class I(H):
        pass

    class J(I):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G, H, I, J}
    assert get_all_subclasses(B) == {C, D, E}
    assert get_all_subclasses(C) == {D, E}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses

# Generated at 2022-06-22 21:11:52.446906
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)

    class D(B):
        pass

    assert D in get_all_subclasses(A)

# Generated at 2022-06-22 21:11:55.109760
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Parent(object):
        pass

    class Child1(Parent):
        pass

    class Child2(Parent):
        pass

    class GrandChild1(Child1):
        pass

    class GrandChild2(Child2):
        pass

    assert set(get_all_subclasses(Parent)) == set((Child1, Child2, GrandChild1, GrandChild2))
    assert set(get_all_subclasses(Child1)) == set((GrandChild1,))
    assert set(get_all_subclasses(Child2)) == set((GrandChild2,))

# Generated at 2022-06-22 21:12:01.162439
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])



# Generated at 2022-06-22 21:12:06.624266
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    assert(get_all_subclasses(A) == {B, C, D, E})
    assert(get_all_subclasses(B) == {C})
    assert(get_all_subclasses(C) == set())
    assert(get_all_subclasses(D) == {E})
    assert(get_all_subclasses(E) == set())

# Generated at 2022-06-22 21:12:17.546382
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    from collections import Iterable

    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass

    class D(object):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(E):
        pass
    class I(G):
        pass

    # no subclass
    assert set(get_all_subclasses(Iterable)) == set()

    # only one level
    assert set(get_all_subclasses(A)) == set([B, C])
    assert set(get_all_subclasses(D)) == set([E, F])

    # multiple levels
    assert set(get_all_subclasses(E)) == set([G, H])

# Generated at 2022-06-22 21:12:21.074985
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])

# Generated at 2022-06-22 21:12:30.233456
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(C): pass
    class E(C): pass
    class F(D): pass
    class G(D): pass
    class H(E): pass
    class I(H): pass

    subclasses = get_all_subclasses(A)
    subclasses_list = [C, D, E, F, G, H, I]
    assert all(x in subclasses for x in subclasses_list)
    assert all(x in subclasses_list for x in subclasses)



# Generated at 2022-06-22 21:12:41.126062
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define sample classes to test function
    class SampleBaseClass(object):
        pass

    class SampleClass1(SampleBaseClass):
        pass

    class SampleClass2(SampleBaseClass):
        pass

    class SampleClass2_2(SampleClass2):
        pass

    class SampleClass2_2_2(SampleClass2_2):
        pass

    class SampleClass3(SampleClass2_2_2):
        pass

    # Run function
    subclasses = get_all_subclasses(SampleBaseClass)

    # Test number
    assert len(subclasses) == 5

    # Test all subclasses have been listed
    assert SampleClass1 in subclasses
    assert SampleClass2 in subclasses
    assert SampleClass2_2 in subclasses
    assert SampleClass2_2_2 in subclasses
    assert SampleClass3 in sub

# Generated at 2022-06-22 21:12:52.738533
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base:
        pass

    class A(Base):
        pass

    class B(Base):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    assert(set([A, B, C, D, E, F]) == get_all_subclasses(Base))
    assert(set([C, E]) == get_all_subclasses(A))
    assert(set([D, F]) == get_all_subclasses(B))
    assert(set([E]) == get_all_subclasses(C))
    assert(set([F]) == get_all_subclasses(D))
    assert(set() == get_all_subclasses(E))

# Generated at 2022-06-22 21:13:04.149079
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    class Test(unittest.TestCase):
        def test_get_all_subclasses(self):
            class A(object): pass
            class B(A): pass
            class C(B): pass
            class D(A): pass
            class E(A): pass
            class F(E): pass

            self.assertEqual({B, C, D, E, F}, get_all_subclasses(A))
            self.assertEqual({C}, get_all_subclasses(B))
            self.assertEqual(set(), get_all_subclasses(C))
            self.assertEqual(set(), get_all_subclasses(D))
            self.assertEqual({F}, get_all_subclasses(E))

# Generated at 2022-06-22 21:13:08.273322
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-22 21:13:15.270273
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import ansible.module_utils.six as six

    class A(object):  # pylint: disable=too-few-public-methods
        ''' class A '''
        pass

    class B(A):  # pylint: disable=too-few-public-methods
        ''' class B '''
        pass

    class C(A):  # pylint: disable=too-few-public-methods
        ''' class C '''
        pass

    class D(B):  # pylint: disable=too-few-public-methods
        ''' class D '''
        pass

    class E(object):  # pylint: disable=too-few-public-methods
        ''' class E '''
        pass

    classes_descendents = dict()
    classes_descendents

# Generated at 2022-06-22 21:13:20.352086
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    A simple mock up for testing get_all_subclasses() before using it in modules.

    :rtype: bool
    :returns: True if test passes, False if test fails.

    The `get_all_subclasses` function can be difficult to test.  This function creates a few mock
    classes and then checks the result of `get_all_subclasses` to ensure that they are correctly
    identified as decendents of the class `One`.
    '''
    # pylint: disable=too-few-public-methods,missing-docstring
    class One(object):
        pass

    class Two(One):
        pass

    class Three(One):
        pass

    class Four(Two):
        pass

    class Five(Three):
        pass

    class Six(Four):
        pass


# Generated at 2022-06-22 21:13:31.659949
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test Class
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(C): pass
    class H(D): pass
    class I(H): pass

    # Get all subclasses of H
    h_subclasses = get_all_subclasses(H)
    check_h_subclasses = set([H, I])
    if h_subclasses != check_h_subclasses:
        raise AssertionError('get_all_subclasses for H is incorrect')

    # Get all subclasses of C
    c_subclasses = get_all_subclasses(C)
    check_c_subclasses = set([C, F, G])

# Generated at 2022-06-22 21:13:35.500949
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(C): pass
    class F(D): pass
    assert get_all_subclasses(A) == set([B, C, D, E, F])

# Generated at 2022-06-22 21:13:42.102864
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    test_list = [A, B, C, D]
    assert set(test_list) == get_all_subclasses(A)
    assert set([D]) == get_all_subclasses(B)
    assert set([]) == get_all_subclasses(C)
    assert set([]) == get_all_subclasses(D)
    # Test on an empty class
    class Empty(object):
        pass
    assert set([]) == get_all_subclasses(Empty)

# Generated at 2022-06-22 21:13:48.111129
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(B): pass
    class E(D): pass

    class F(object): pass
    class G(F): pass
    class H(G): pass
    class I(H): pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(F)
    assert G in get_all_subclasses(F)
    assert H in get_all_subclasses(F)
    assert I in get_all_subclasses(F)
   

# Generated at 2022-06-22 21:13:59.310091
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Fruit(object):
        pass

    class Vegetable(object):
        pass

    class Apple(Fruit):
        pass

    class Orange(Fruit):
        pass

    class Pear(Fruit):
        pass

    class Lettuce(Vegetable):
        pass

    class Cucumber(Vegetable):
        pass

    class Broccoli(Vegetable):
        pass

    assert sorted(get_all_subclasses(Fruit), key=lambda food: food.__name__) == \
        [Apple, Orange, Pear]

    assert sorted(get_all_subclasses(Vegetable), key=lambda food: food.__name__) == \
        [Broccoli, Cucumber, Lettuce]

    assert sorted(get_all_subclasses(object), key=lambda food: food.__name__)

# Generated at 2022-06-22 21:14:08.345972
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types
    class A(object): pass
    class B(object): pass
    class C(object): pass
    class D(A): pass
    class E(A): pass
    class F(B): pass
    class G(B): pass
    class H(C): pass
    class I(D): pass
    class J(H): pass
    class K(I): pass
    class L(J): pass
    # Standard cases
    assert get_all_subclasses(A) == set([D, E, I, K, L])
    assert get_all_subclasses(B) == set([F, G])
    assert get_all_subclasses(C) == set([H, J, K, L])
    assert get_all_subclasses(D) == set([I, K, L])
    assert get_all_

# Generated at 2022-06-22 21:14:11.689622
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E])

# Generated at 2022-06-22 21:14:20.688314
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a test case tree
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(E):
        pass
    class J(F):
        pass
    class K(G):
        pass

    # Test with class A
    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 8
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in subclasses
    assert H in subclasses
    assert I

# Generated at 2022-06-22 21:14:31.653076
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    class G(E): pass

    cases = [
        (A, set([B, C, D, E, F, G])),
        (B, set([D, F])),
        (C, set([E, G])),
        (D, set([F])),
        (E, set([G])),
        (F, set([])),
        (G, set([])),
    ]

    class GetAllSubclassesTests(unittest.TestCase):
        def test_get_all_subclasses(self):
            for cls, expected in cases:
                subclasses = get_

# Generated at 2022-06-22 21:14:37.338874
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(B)) == set([C])
    assert set(get_all_subclasses(C)) == set()
    assert set(get_all_subclasses(D)) == set()

# Generated at 2022-06-22 21:14:43.276214
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B,C):
        pass
    class F(D,E):
        pass
    assert get_all_subclasses(A) == set([B,C,D,E,F])

# Generated at 2022-06-22 21:14:51.091806
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    .. code-block:: yaml

        classes:
            - Foo
            - Bar
        class_c:
            subclass_d:
                subclass_e: []
            subclass_f: []
        class_g:
            subclass_h: []
        class_i:
            - Foo
    '''

    class Foo(object): pass
    class Bar(object): pass
    class ClassC(object): pass
    class ClassD(ClassC): pass
    class ClassE(ClassD): pass
    class ClassF(ClassC): pass
    class ClassG(object): pass
    class ClassH(ClassG): pass
    class ClassI(object): pass
    assert get_all_subclasses(Foo) == set()
    assert get_all_subclasses(Bar) == set()
    assert get_all_sub

# Generated at 2022-06-22 21:14:57.813955
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types

    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(A): pass
    class E(B): pass
    class F(C): pass
    class G(D): pass
    class H(E): pass
    class I(F): pass

    # Declare the expected subclasses
    expected_result = set([B, C, D, E, F, G, H, I])

    # Retrieve subclasses
    result = get_all_subclasses(A)

    # Test result
    assert isinstance(result, types.GeneratorType)
    assert set(result) == expected_result
    # Test edge case where no subclasses exist
    result = get_all_subclasses(object)
    assert set(result) == set()

# Generated at 2022-06-22 21:15:05.108081
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestA(object):
        pass

    class TestAA(TestA):
        pass

    class TestAB(TestA):
        pass

    class TestABB(TestAB):
        pass

    class TestAC(TestA):
        pass

    class TestB(object):
        pass

    assert get_all_subclasses(TestA) == set([TestAA, TestAB, TestABB, TestAC])
    assert get_all_subclasses(TestB) == set()

# Generated at 2022-06-22 21:15:11.866546
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(object):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(F):
        pass
    assert get_all_subclasses(A) == set([])
    assert get_all_subclasses(B) == set([])
    assert get_all_subclasses(C) == set([D, E, F, G])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([F, G])
    assert get_all_subclasses(F) == set([G])
    assert get_all_subclasses(G) == set([])

# Generated at 2022-06-22 21:15:15.640323
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert get_all_subclasses(A) == set([B, D, C])


# Generated at 2022-06-22 21:15:20.108766
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Let's create a fake class and some subclasses
    class Foo:
        pass

    class FooFoo(Foo):
        pass

    class FooBar(Foo):
        pass

    assert set(get_all_subclasses(Foo)) == set([FooFoo, FooBar])

# Generated at 2022-06-22 21:15:26.710865
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    assert get_all_subclasses(A) == set([B, C, D])
    class E(D):
        pass
    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(C) == set([])

# Generated at 2022-06-22 21:15:31.395339
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class A0(A):
        pass

    class A1(A):
        pass

    class A00(A0):
        pass

    class A10(A1):
        pass

    class A000(A00):
        pass

    assert set([A, A0, A1, A00, A10, A000]) == get_all_subclasses(A)

# Generated at 2022-06-22 21:15:38.621601
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(A): pass
    class E(B): pass
    class F(B): pass
    class G(C): pass
    class H(D): pass
    class I(F): pass
    class J(F): pass
    class K(G): pass
    class L(H): pass
    class M(I): pass
    class N(J): pass

    class X(object): pass
    class Y(object): pass
    class Z(object): pass

    assert get_all_subclasses(A) == set([E, H, J, C, F, L, G, I, K, M, N, D])
    assert get_all_subclasses(X) == set([Z, Y])

# Generated at 2022-06-22 21:15:49.206693
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class SuperClass1(object):
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    class SubClass1(SuperClass1):
        def __init__(self, name):
            super(SubClass1, self).__init__(name)

    class SubClass2(SuperClass1):
        def __init__(self, name):
            super(SubClass2, self).__init__(name)

    class SubSubClass(SubClass1):
        def __init__(self, name):
            super(SubSubClass, self).__init__(name)

    assert SubClass1 in get_all_subclasses(SuperClass1)
    assert SubClass2 in get_all_subclasses(SuperClass1)
    assert SubSubClass in get

# Generated at 2022-06-22 21:15:53.877894
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(D):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D, E, F}

# Generated at 2022-06-22 21:15:58.725929
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Test(object):
        pass
    class Test2(Test):
        pass
    class Test22(Test2):
        pass
    class Test3(Test):
        pass
    class Test33(Test3):
        pass

    assert get_all_subclasses(Test) == set([Test2, Test22, Test3, Test33])



# Generated at 2022-06-22 21:16:07.226045
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Parent(object):
        pass

    class Child(Parent):
        pass

    class GrandChild(Child):
        pass

    class GreatGrandChild(GrandChild):
        pass

    parent_set = set([Parent])
    child_set = set([Child, GrandChild, GreatGrandChild])
    grand_child_set = set([GrandChild, GreatGrandChild])

    assert parent_set == set(get_all_subclasses(Parent))
    assert child_set == set(get_all_subclasses(Child))
    assert grand_child_set == set(get_all_subclasses(GrandChild))

# Generated at 2022-06-22 21:16:12.324727
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    # A and E are not related between them
    assert set([A, B, C, D]) == get_all_subclasses(A)
    assert set([E]) == get_all_subclasses(E)

# Generated at 2022-06-22 21:16:16.039068
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G, H}


# Generated at 2022-06-22 21:16:20.007068
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # These classes are used for test only
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert get_all_subclasses(A) == set([B, C, D])

# Generated at 2022-06-22 21:16:29.790741
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):  pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(B,C): pass

    all_subclasses = get_all_subclasses(A)
    assert A in all_subclasses
    assert B in all_subclasses
    assert C in all_subclasses
    assert D in all_subclasses
    assert E in all_subclasses

    class F(object): pass
    class G(F): pass
    class H(G): pass

    class I(object): pass
    class J(I): pass
    class K(J): pass

    all_subclasses = get_all_subclasses(F)
    assert F in all_subclasses
    assert G in all_subclasses
    assert H in all_subclasses

# Generated at 2022-06-22 21:16:34.809236
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(C):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])

# Generated at 2022-06-22 21:16:38.903137
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    assert set([B, D]) == get_all_subclasses(A)
    assert set([D, C, E]) == get_all_subclasses(A)

# Generated at 2022-06-22 21:16:49.563817
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(C): pass
    class F(D): pass
    class G(D): pass
    class H(E): pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])
    assert get_all_subclasses(B) == set([])
    assert get_all_subclasses(C) == set([D, E, F, G, H])
    assert get_all_subclasses(D) == set([F, G])
    assert get_all_subclasses(E) == set([H])
    assert get_all_subclasses(F) == set([])
    assert get_all_subclasses(G) == set

# Generated at 2022-06-22 21:16:58.062912
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(I):
        pass

    class K(I):
        pass

    assert get_all_subclasses(A) == set([B, D, E, C, F, G, H, I, J, K])
    assert get_all_subclasses(B) == set([C, F, G, D, E, H, I, J, K])

# Generated at 2022-06-22 21:17:08.945727
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_text
    import ansible.module_utils.six

    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(object): pass

    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 3, 'Got %i subclasses: %s' % (len(subclasses), to_text(subclasses))
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses

    subclasses = get_all_subclasses(B)
    assert len(subclasses) == 0, 'Got %i subclasses: %s' % (len(subclasses), to_text(subclasses))

    subclasses = get_all_subclasses(E)


# Generated at 2022-06-22 21:17:19.047732
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create test classes
    class C1():
        pass

    class C2():
        pass

    class C3():
        pass

    class C4(C1):
        pass

    class C5(C4):
        pass

    class C6(C2):
        pass

    assert get_all_subclasses(C1) == set([C4, C5])
    assert get_all_subclasses(C2) == set([C6])
    assert get_all_subclasses(C3) == set()
    assert get_all_subclasses(C4) == set([C5])
    assert get_all_subclasses(C5) == set()
    assert get_all_subclasses(C6) == set()

# Generated at 2022-06-22 21:17:22.541632
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}

# Generated at 2022-06-22 21:17:32.420920
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.parameters import _AnsibleModuleParameters
    from ansible.module_utils.common.removed import RemovedModule
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import SafeConfigParser, NoOptionError, NoSectionError
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url, fetch_url, url_argument_spec, URLFail, ConnectionError

# Generated at 2022-06-22 21:17:36.655848
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert set([A, B, C, D]) == get_all_subclasses(A)

# Generated at 2022-06-22 21:17:48.068375
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C1: pass
    class C2(C1): pass
    class C3(C1): pass
    class C4(C2): pass
    class C5: pass
    class C6(C5): pass
    class C7(C2): pass
    assert get_all_subclasses(C1) == set([C2, C3, C4, C7])
    assert get_all_subclasses(C2) == set([C4, C7])
    assert get_all_subclasses(C3) == set([])
    assert get_all_subclasses(C4) == set([])
    assert get_all_subclasses(C5) == set([C6])
    assert get_all_subclasses(C6) == set([])

# Generated at 2022-06-22 21:17:59.283800
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # A
    class A(object):
        pass
    # B
    class B(A):
        pass
    # C
    class C(A):
        pass
    # D
    class D(C):
        pass
    # E
    class E(D):
        pass
    # F
    class F(B,D):
        pass
    # G
    class G(F):
        pass
    # H
    class H(A):
        pass
    # I
    class I(C,G,H):
        pass

    assert get_all_subclasses(A) == {B,C,D,E,F,G,H,I}
    assert get_all_subclasses(B) == {F,G}

# Generated at 2022-06-22 21:18:06.169924
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    assert {B, C, D, E, F} == get_all_subclasses(A)
    assert set() == get_all_subclasses(B)

# Generated at 2022-06-22 21:18:13.072733
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from abc import ABC
    from abc import abstractmethod
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(D): pass
    a = A()
    b = B()
    c = C()
    d = D()
    e = E()
    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D, E])
    assert get_all_subclasses(D) == set([E])
    assert get_all_subclasses(E) == set()
    class Parent(object): pass
    class Child1(Parent): pass
    class Child2(Parent): pass

# Generated at 2022-06-22 21:18:23.753872
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    d = get_all_subclasses(object)
    assert len(d) == 5
    assert A in d
    assert B in d
    assert C in d
    assert D in d
    assert E in d
    d = get_all_subclasses(B)
    assert len(d) == 2
    assert D in d
    assert E in d
    d = get_all_subclasses(C)
    assert len(d) == 1
    assert E in d
    d = get_all_subclasses(D)
    assert len(d) == 0

# Generated at 2022-06-22 21:18:28.877482
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass

    assert get_all_subclasses(A) == {B, C, D}

# Generated at 2022-06-22 21:18:36.356933
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    ''' test_get_all_subclasses tests that get_all_subclasses works as expected '''
    class A(object):
        ''' Class A '''
    class B(A):
        ''' Class B '''
    class C(B):
        ''' Class C '''
    class D(A):
        ''' Class D '''

    classes = [A, B, C, D]
    subclasses = get_all_subclasses(A)
    # Checking all subclasses are retrieved
    assert len(classes) == len(subclasses)
    for cls in subclasses:
        assert cls in classes

# Generated at 2022-06-22 21:18:42.713060
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(F):
        pass

    # Testing the function
    assert set([A, B, C, D, E, F, G]) == get_all_subclasses(A)

# Generated at 2022-06-22 21:18:50.284322
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class A1(A):
        pass

    class A2(A):
        pass

    class B1(B):
        pass

    # B contains no subclass
    assert set() == set(get_all_subclasses(B))

    # A contains 2 subclasses A1 and A2 and no other
    assert set([A1, A2]) == set(get_all_subclasses(A))

    # B1 contains no subclasses
    assert set() == set(get_all_subclasses(B1))

    # A contains 2 subclasses A1 and A2, A1 contains 2 subclasses B and B1
    assert set([B, B1]) == set(get_all_subclasses(A1))

    # Add a new subclass B2


# Generated at 2022-06-22 21:18:55.635418
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == set((B, C, D, E))
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set((D, E))
    assert get_all_subclasses(D) == set((E,))
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-22 21:19:06.864950
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import network_engine

    # create example class hierachy
    class A(object):
        pass

    class B(object):
        pass

    class C(object):
        pass

    class D(A):
        pass

    class E(A):
        pass

    class F(D):
        pass

    class G(D, B):
        pass

    class H(F, E, A):
        pass

    class I(G, C):
        pass

    class J(I):
        pass

    class K(J, A):
        pass

    class L(J, F, H):
        pass

    # the reference dump of all subclasses
    ref_classes = [A, B, C, D, E, F, G, H, I, J, K, L]

# Generated at 2022-06-22 21:19:13.529442
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B,C):
        pass
    subclasses = get_all_subclasses(A)
    expected_superclasses = {A,B,C,D}
    assert subclasses == expected_superclasses

# Generated at 2022-06-22 21:19:24.311340
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(B, C, A):
        pass

    class F(object):
        pass

    class G(F):
        pass

    class H(G):
        pass

    class I(G):
        pass

    class J(G, H, I):
        pass

    class K(F):
        pass


    # Simple test class
    class test_get_all_subclass(unittest.TestCase):
        def test_basic(self):
            result = get_all_subclasses(A)
            self.assertEqual(result, set([B, C, D, E]))

# Generated at 2022-06-22 21:19:33.198953
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define classes
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(C): pass
    class H(D): pass
    class I(D): pass

    # Test list A subclasses
    assert set(get_all_subclasses(A)) == {B, C, D, E, F, G, H, I}

    # Test list B subclasses
    assert set(get_all_subclasses(B)) == {D, E, H, I}

    # Test list C subclasses
    assert set(get_all_subclasses(C)) == {F, G}

    # Test list D subclasses
    assert set(get_all_subclasses(D))

# Generated at 2022-06-22 21:19:36.530512
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])