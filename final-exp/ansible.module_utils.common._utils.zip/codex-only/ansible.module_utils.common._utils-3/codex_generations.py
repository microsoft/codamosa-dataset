

# Generated at 2022-06-22 21:09:45.709343
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import defaultdict
    import types
    import warnings

    class Foo(object):
        pass

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    class Bad1(object):
        __subclasses__ = 1

    class Bad2(object):
        __subclasses__ = lambda: 1

    class Bad3(object):
        def __iter__(self): raise ValueError

    # We expect to receive a UserWarning in some versions of python
    # https://github.com/python/cpython/pull/9794
    warnings.filterwarnings('always', category=UserWarning)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        assert get_all_subclasses(Foo) == set([Bar, Baz])
        assert get_

# Generated at 2022-06-22 21:09:57.016357
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class X(object):
        pass
    class Y(X):
        pass
    class Z(Y):
        pass
    class M(A, X):
        pass
    class N(A, Y):
        pass
    class O(D, Z):
        pass

    expected = set([A, B, C, D, E, F, X, Y, Z, M, N, O])
    result = set(get_all_subclasses(object))
    unittest.TestCase().assertEqual(expected, result)

# Generated at 2022-06-22 21:10:03.755676
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert get_all_subclasses(A) == set([B, D, C])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set()



# Generated at 2022-06-22 21:10:07.527362
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        def func(self):
            pass

    class B(A):
        pass

    class C(B):
        pass

    assert set(get_all_subclasses(A)) == set([B, C])



# Generated at 2022-06-22 21:10:15.064694
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class foo():
        pass
    class bar():
        pass
    class baz():
        pass
    class qux():
        pass
    class quux():
        pass

    foo.x = bar
    foo.y = baz
    bar.z = qux
    baz.q = quux

    foo_subclasses = get_all_subclasses(foo)
    assert bar in foo_subclasses
    assert baz in foo_subclasses
    assert qux in foo_subclasses
    assert quux in foo_subclasses

    assert not foo in foo_subclasses

# Generated at 2022-06-22 21:10:23.895727
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a simple class test structure
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(F):
        pass

    # Verify that the correct list of classes is received
    assert get_all_subclasses(A) == set((B, C, D, E, F, G))

# Generated at 2022-06-22 21:10:34.531210
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import ansible.plugins.action

    # Create a test class
    class SuperClass:
        pass

    class SubClass(SuperClass):
        pass

    class OtherSubClass(SuperClass):
        pass

    # Check that the direct subclasses are returned.
    assert set([SubClass, OtherSubClass]) == set(SuperClass.__subclasses__())

    # Check the subclasses that are not direct
    assert set([ansible.plugins.action.Module, ansible.plugins.action.ModuleExecutor]) == set(get_all_subclasses(ansible.plugins.action.ActionBase))

    # Check that the subclasses in no particular order
    assert set([SubClass, OtherSubClass, ansible.plugins.action.Module, ansible.plugins.action.ModuleExecutor]) == set(get_all_subclasses(SuperClass))
   

# Generated at 2022-06-22 21:10:39.461671
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from _ansible_test_fake_class import A, B, C, D, E

    assert set([C, D, E]) == set(get_all_subclasses(B))

    assert set([B, C, D, E]) == set(get_all_subclasses(A))

# Generated at 2022-06-22 21:10:48.703746
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()
    assert get_all_subclasses(object) == set()

# Generated at 2022-06-22 21:10:55.669706
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C(object):
        pass
    class A(C):
        pass
    class B(C):
        pass
    class D(A):
        pass
    assert C in get_all_subclasses(C)
    assert A in get_all_subclasses(C)
    assert B in get_all_subclasses(C)
    assert D in get_all_subclasses(C)
    assert D in get_all_subclasses(A)
    assert D in get_all_subclasses(B)
    assert len(get_all_subclasses(C)) == 4
    assert len(get_all_subclasses(A)) == 2
    assert len(get_all_subclasses(B)) == 1

# Generated at 2022-06-22 21:11:01.872850
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    subclasses = get_all_subclasses(A)
    assert isinstance(subclasses, set)
    assert len(subclasses) == 5
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert A not in subclasses

# Generated at 2022-06-22 21:11:08.605840
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E:
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H:
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(E)) == set([F, G])
    assert set(get_all_subclasses(H)) == set()

# Generated at 2022-06-22 21:11:16.204449
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(E):
        pass

    class G(F):
        pass

    assert G in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert B in get_all_subclasses(A)

# Generated at 2022-06-22 21:11:20.697197
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(C):
        pass
    assert (get_all_subclasses(A) == set([B, C, D, E, F]))

# Generated at 2022-06-22 21:11:26.960126
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(F):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D, E, F, G, H}

# Generated at 2022-06-22 21:11:35.794293
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == {D, E}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-22 21:11:43.832384
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(C):
        pass

    class G(F):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G}
    assert get_all_subclasses(B) == {D, E}
    assert get_all_subclasses(C) == {F, G}
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == {G}
    assert get_all_subclasses(G) == set()

# Generated at 2022-06-22 21:11:55.271602
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(B): pass
    class D: pass
    class E(A): pass
    class F(E): pass
    class G(F): pass
    classes = [A, B, C, D, E, F, G]
    assert(set(classes) == get_all_subclasses(A) == get_all_subclasses(B) == get_all_subclasses(C))
    assert(set([E, F, G]) == get_all_subclasses(E) == get_all_subclasses(F) == get_all_subclasses(G))
    assert(set(classes) == get_all_subclasses(object))
    assert(set([C]) == get_all_subclasses(C))

# Generated at 2022-06-22 21:12:02.158839
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(object):
        pass

    all_subclasses = get_all_subclasses(A)
    assert len(all_subclasses) == 3
    assert B in all_subclasses
    assert C in all_subclasses
    assert D in all_subclasses
    assert E not in all_subclasses

# Generated at 2022-06-22 21:12:08.986161
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(C): pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F, G])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])
    assert get_all_subclasses(G) == set([])



# Generated at 2022-06-22 21:12:15.777882
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B: pass
    class C: pass
    class D: pass

    A.subclasses = get_all_subclasses(A)
    assert A.subclasses == set([B, C, D])
    B.subclasses = get_all_subclasses(B)
    assert B.subclasses == set([D])
    C.subclasses = get_all_subclasses(C)
    assert C.subclasses == set([D])
    D.subclasses = get_all_subclasses(D)
    assert D.subclasses == set()

# Generated at 2022-06-22 21:12:24.606935
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function get_all_subclasses defined above.
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(D):
        pass
    class H(E):
        pass
    class I(F):
        pass
    class J(G):
        pass

    assert(set(get_all_subclasses(A)) == set([B, H, D, G, E, J, F, C, I]))
    assert(set(get_all_subclasses(B)) == set([H, D, G, E, J]))

# Generated at 2022-06-22 21:12:30.388368
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestClass():
        pass
    class TestClassChild(TestClass):
        pass
    class TestClassDeepChild(TestClassChild):
        pass
    class TestClassDeepestChild(TestClassDeepChild):
        pass
    class TestClassUnrelated():
        pass
    assert get_all_subclasses(TestClass) == set([TestClassChild, TestClassDeepChild, TestClassDeepestChild])

# Generated at 2022-06-22 21:12:41.254829
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert set() == get_all_subclasses(None)
    assert set() == get_all_subclasses(bool)
    assert set() == get_all_subclasses(int)
    assert set() == get_all_subclasses(set)

    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass

    assert set() == get_all_subclasses(A)
    assert {B, C} == get_all_subclasses(A)
    assert {D, E} == get_all_subclasses(B)
    assert {F, G} == get_all_subclasses(C)

# Generated at 2022-06-22 21:12:52.778802
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert G in get_all_subclasses(A)

    assert A not in get_all_subclasses(B)
    assert C not in get_all_subclasses(B)
   

# Generated at 2022-06-22 21:12:59.387301
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(C):
        pass
    subclasses = get_all_subclasses(A)
    assert sorted(list(subclasses)) == [A, B, C, D, E, F]

# Generated at 2022-06-22 21:13:09.223841
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(object): pass
    class E(D): pass

    class F(B): pass
    class G(B): pass
    class H(C): pass

    class I(G): pass
    class J(I): pass
    class K(J): pass

    assert get_all_subclasses(A) == set([B, C, F, G, I, J, K, H])
    assert get_all_subclasses(B) == set([F, G, I, J, K])
    assert get_all_subclasses(C) == set([H])
    assert get_all_subclasses(D) == set([E])

    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-22 21:13:15.090614
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class A_1(A):
        pass

    class A_2(A):
        pass

    class B(object):
        pass

    class B_1(B):
        pass

    class B_2(B):
        pass

    class C(A_1, B_1):
        pass

    class D(A_2, B_2):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == set([A_1, C, A_2, D, E])
    assert get_all_subclasses(B) == set([B_1, C, B_2, D, E])
    assert get_all_subclasses(C) == set([C, E])



# Generated at 2022-06-22 21:13:20.247727
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(D): pass
    class F(E): pass
    class G(A): pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])
    assert set(get_all_subclasses(B)) == set([C])
    assert set(get_all_subclasses(C)) == set([])
    assert set(get_all_subclasses(D)) == set([E, F])
    assert set(get_all_subclasses(E)) == set([F])
    assert set(get_all_subclasses(F)) == set([])
    assert set(get_all_subclasses(G)) == set([])

# Generated at 2022-06-22 21:13:26.950322
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        def __init__(self):
            pass

    class B(A):
        def __init__(self):
            pass

    class C(A):
        def __init__(self):
            pass

    class D(B):
        def __init__(self):
            pass

    assert set([B, D]) == get_all_subclasses(A)

# Generated at 2022-06-22 21:13:31.063544
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class X(object):
        pass
    class Y(X):
        pass
    class Z(X):
        pass
    class A(Y):
        pass
    class B(Y):
        pass
    class C(Z):
        pass
    assert set(get_all_subclasses(X)) == set([Y, Z, A, B, C])

# Generated at 2022-06-22 21:13:39.686430
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a simple tree like that :
    #  A
    #  |- B
    #  |  |- C
    #  |  |  |- E
    #  |  |  |- F
    #  |  |- D
    #  |  |  |- G
    #  |  |  |- H
    #  |- I
    #  |  |- J
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(D):
        pass

    class I(A):
        pass

    class J(I):
        pass

# Generated at 2022-06-22 21:13:51.123261
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    We test get_all_subclasses function with a dummy class
    """
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass
    # Tests with classes having different children
    assert (get_all_subclasses(A) == set([B, C, D, E]))
    assert (get_all_subclasses(B) == set([D]))
    assert (get_all_subclasses(C) == set([E]))
    assert (get_all_subclasses(D) == set([]))
    assert (get_all_subclasses(E) == set([]))
    # Tests with classes having no children
    class F(object):
        pass

   

# Generated at 2022-06-22 21:14:02.161620
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C: pass
    class D: pass
    class E(D): pass
    class F(D): pass
    class G(E, F): pass
    import sys

    if sys.version_info >= (3, 3):
        assert set([B]) == get_all_subclasses(A)
        assert set() == get_all_subclasses(C)
        assert set([E, F, G]) == get_all_subclasses(D)
    else:
        # In python 2.7, the following error is raised "RuntimeError: maximum recursion depth exceeded while calling a Python object".
        # As we are not using get_all_subclasses in python 2.7, we simply assert True
        assert True

# Generated at 2022-06-22 21:14:08.443469
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(D):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)

# Generated at 2022-06-22 21:14:11.460455
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    assert get_all_subclasses(A) == set([B, C, D])

# Generated at 2022-06-22 21:14:20.498176
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    ''' Unit test for testing get_all_subclasses function '''
    from collections import Iterable

    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G():
        pass

    class H(G):
        pass

    class I(H):
        pass

    assert isinstance(get_all_subclasses(A), Iterable), 'get_all_subclasses must return an iterable'
    assert set(get_all_subclasses(A)) == {B, C, D, E, F}, 'get_all_subclasses do not return expected result'

# Generated at 2022-06-22 21:14:30.374650
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class X(object):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(B)) == set([D])
    assert set(get_all_subclasses(C)) == set()
    assert set(get_all_subclasses(D)) == set()
    assert set(get_all_subclasses(X)) == set()
    assert set(get_all_subclasses(X)) != set([A, B, C, D])

# Generated at 2022-06-22 21:14:37.403276
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    def sub_classes(cls):
        return [c.__name__ for c in cls.__subclasses__()]

    class A(object):
        pass

    class B(object):
        pass

    class C(object):
        pass

    class D(A):
        pass

    class E(A):
        pass

    class F(E):
        pass

    class G(C):
        pass

    class H(G):
        pass

    assert set(sub_classes(A)) == set(['D', 'E'])
    assert set(sub_classes(B)) == set()
    assert set(sub_classes(C)) == set(['G'])
    assert set(sub_classes(D)) == set()
    assert set(sub_classes(E)) == set(['F'])
    assert set

# Generated at 2022-06-22 21:14:47.888385
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Example of class definition
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(B):
        pass

    class G(C):
        pass

    class H(C):
        pass

    # Tests of function get_all_subclasses
    t1 = set([B, C])
    a = get_all_subclasses(A)
    assert t1 == a

    t2 = set([D, E, F])
    b = get_all_subclasses(B)
    assert t2 == b

    t3 = set([G, H])
    c = get_all_subclasses(C)
    assert t3 == c

    t4 = set

# Generated at 2022-06-22 21:14:57.793404
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class F(object): pass
    class G(F): pass
    class H(F): pass
    class K(H, G): pass
    class I(K, D, F): pass

    expected_results = [A, B, C, D, F, G, H, K, I]
    assert set(expected_results) == get_all_subclasses(A)
    assert set(expected_results) == get_all_subclasses(B)
    assert set(expected_results) == get_all_subclasses(D)
    assert set(expected_results) == get_all_subclasses(F)
    assert set(expected_results) == get_all_subclasses(I)

# Generated at 2022-06-22 21:15:07.317129
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import mock

    class TestClass(object):
        def __init__(self, number):
            self.number = number

    class TestClassChild(TestClass):
        pass

    class TestClassChildOfChild(TestClassChild):
        pass

    class TestClassChildOfChild2(TestClassChild):
        pass

    # This is intended to be a non-child class
    class NonChildClass(object):
        pass

    class Test(unittest.TestCase):
        def test_get_all_subclasses(self):
            all_subclasses = get_all_subclasses(TestClass)
            self.assertEqual(
                set(all_subclasses),
                set([TestClassChild, TestClassChildOfChild, TestClassChildOfChild2])
            )

    test_loader = unittest

# Generated at 2022-06-22 21:15:12.612789
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(B, C): pass
    class G(B, C, E): pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G}

# Generated at 2022-06-22 21:15:17.498772
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])



# Generated at 2022-06-22 21:15:27.799359
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(E):
        pass
    class J(F):
        pass
    class K(G):
        pass

    subclasses_of_A = get_all_subclasses(A)
    assert subclasses_of_A == set([B, C, D, E, F, G, H, I, J, K])

    subclasses_of_F = get_all_subclasses(F)
    assert subclasses_of_F == set([J])

# Generated at 2022-06-22 21:15:32.043897
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define three classes
    class A(object):
        def foo(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    # Test the function
    assert set([A, B, C, D, E]) == get_all_subclasses(A)

# Generated at 2022-06-22 21:15:33.455813
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # These definitions are only usefull for the unit test
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert set(get_all_subclasses(A)) == set([B, D, C])

# Generated at 2022-06-22 21:15:38.649346
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This is a test for the :py:func:`~_utils.get_all_subclasses` function.
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(F):
        pass

    subclasses = get_all_subclasses(A)
    assert sorted(subclasses) == sorted([B, C, D, E, F, G])

# Generated at 2022-06-22 21:15:49.196014
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Mapping

    assert(set(get_all_subclasses(str)) == set([unicode]))
    assert(set(get_all_subclasses(Mapping)) == set([dict, UserDict.DictMixin, UserDict.IterableUserDict, UserDict.UserDict, collections.defaultdict, collections.OrderedDict]))

# Generated at 2022-06-22 21:15:55.546419
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class One(object):
        pass

    class OneOne(One):
        pass

    class OneTwo(One):
        pass

    class OneOneOne(OneOne):
        pass

    class Two(object):
        pass

    class TwoOne(Two):
        pass

    class OneTwoOne(OneTwo):
        pass

    expected_output = set([OneOneOne, OneOne, OneTwoOne, OneTwo, TwoOne, Two])
    assert(expected_output == get_all_subclasses(object))

# Generated at 2022-06-22 21:16:07.133088
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(G):
        pass

    classes = get_all_subclasses(A)

    if class_id(A) not in classes:
        raise AssertionError('Expecting start class being in result')
    if class_id(B) not in classes:
        raise AssertionError('Expecting B being in result')
    if class_id(C) not in classes:
        raise AssertionError('Expecting C being in result')
   

# Generated at 2022-06-22 21:16:16.032880
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(C):
        pass
    class I(F):
        pass
    class J(H):
        pass
    class K(H):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H, I, J, K])
    assert set(get_all_subclasses(B)) == set([D, E])

# Generated at 2022-06-22 21:16:25.882797
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define basic classes
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(D):
        pass

    # Launch test
    all_subclasses = get_all_subclasses(A)
    # Make sure that all the classes are listed
    assert set([A, B, C, D, E, F]) == all_subclasses
    # Make sure that all the subclasses are listed
    assert all([True if c not in all_subclasses else False for c in [A, B, C, D, E, F]])

# Generated at 2022-06-22 21:16:36.954437
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.utils._pkg_resources import RequirementParseError, Requirement
    def subclass_tree(obj):
        """
        Recursive function to get a string representation of the tree of subclasses
        """
        s = [obj]
        for sc in obj.__subclasses__():
            s.append(subclass_tree(sc))
        return "[" + ", ".join(s) + "]"


# Generated at 2022-06-22 21:16:47.558880
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert set(get_all_subclasses(A)) == set((A, B, C, D, E))
    assert set(get_all_subclasses(B)) == set((B, D))
    assert set(get_all_subclasses(C)) == set((C, E))

# Generated at 2022-06-22 21:16:55.293865
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define an external class to prevent interference with other tests
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    class G(E): pass

    assert G in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)


# Generated at 2022-06-22 21:17:04.629293
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    # Example of usage
    assert get_all_subclasses(A) == set()
    # Test all class are retrieved
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E])
    # Test class added later are also retrieved
    class F(A):
        pass
    class G(F):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])

# Generated at 2022-06-22 21:17:11.065534
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(F):
        pass

    class H(F):
        pass

    expected = set([B, D, E, C, F, G, H])
    observed = get_all_subclasses(A)
    assert expected == observed


# Generated at 2022-06-22 21:17:15.755448
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(C): pass
    class G(E): pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])

# Generated at 2022-06-22 21:17:25.579186
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    import ansible.module_utils.dictdiffer

    subclasses = get_all_subclasses(ansible.module_utils.dictdiffer.AnsibleDict)

    assert ansible.module_utils.dictdiffer.AnsibleUnorderedDict in subclasses
    assert ansible.module_utils.dictdiffer.AnsibleMapping in subclasses
    assert ansible.module_utils.dictdiffer.AnsibleSequence in subclasses
    assert ansible.module_utils.dictdiffer.AnsibleUserDict in subclasses

    # When called on type, we should get all the classes derived from it
    subclasses = get_all_subclasses(type)

    assert str in subclasses
    assert int in subclasses
   

# Generated at 2022-06-22 21:17:35.231198
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(G):
        pass

    class I(G):
        pass

    subclasses = get_all_subclasses(A)

    assert len(subclasses) == 8
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in subclasses
    assert H in subclasses
    assert I in subclasses

# Generated at 2022-06-22 21:17:40.873145
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    # Check if A have subclasses
    assert get_all_subclasses(A) == set([B, C, D])
    # Check if B have subclasses
    assert get_all_subclasses(B) == set([C])
    # Check if C have no subclasses
    assert not get_all_subclasses(C)
    # Check if D have no subclasses
    assert not get_all_subclasses(D)
    # Check if object have no subclasses
    assert not get_all_subclasses(object)

# Generated at 2022-06-22 21:17:47.454483
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])

# Generated at 2022-06-22 21:17:51.788749
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class FirstLevel(object):
        pass

    class SecondLevel(FirstLevel):
        pass

    class ThirdLevel(SecondLevel):
        pass

    class SecondLevel2(FirstLevel):
        pass

    class ThirdLevel2(SecondLevel2):
        pass

    class ThirdLevelNoParent(object):
        pass

    assert ThirdLevelNoParent not in get_all_subclasses(FirstLevel)
    assert SecondLevel in get_all_subclasses(FirstLevel)
    assert SecondLevel2 in get_all_subclasses(FirstLevel)
    assert ThirdLevel in get_all_subclasses(FirstLevel)
    assert ThirdLevel2 in get_all_subclasses(FirstLevel)
    assert len(list(get_all_subclasses(FirstLevel))) == 4


# Generated at 2022-06-22 21:18:00.776601
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Parent1(object):
        pass

    class Parent2(object):
        pass

    class Child1(Parent1):
        pass

    class Child2(Parent2):
        pass

    class Grandchild1(Child1):
        pass

    assert set(get_all_subclasses(Parent1)) == set([Child1, Grandchild1])
    assert set(get_all_subclasses(Parent2)) == set([Child2])
    assert set(get_all_subclasses(Parent1)) != set(get_all_subclasses(Parent2))
    assert set(get_all_subclasses(Parent1)) != set([Child2])



# Generated at 2022-06-22 21:18:11.159583
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(G):
        pass

    expected = set([C, D, E, F, G, H])
    assert get_all_subclasses(A) == expected

    expected = set([D, E, F, G, H])
    assert get_all_subclasses(B) == expected

    expected = set([E, F, G, H])
    assert get_all_subclasses(C) == expected

    expected = set([E, F])
    assert get_all_subclasses(D) == expected

    assert get_all

# Generated at 2022-06-22 21:18:22.112957
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''Verifies that get_all_subclasses works properly
    '''
    class A(object):  # pylint: disable=too-few-public-methods,useless-object-inheritance
        '''Test class A'''
    class B(A):  # pylint: disable=too-few-public-methods
        '''Test class B'''
    class C(B):  # pylint: disable=too-few-public-methods
        '''Test class C'''
    class D(A):  # pylint: disable=too-few-public-methods
        '''Test class D'''
    class E(A):  # pylint: disable=too-few-public-methods
        '''Test class E'''

    assert get_all_subclasses(A)

# Generated at 2022-06-22 21:18:30.838964
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    assert set([D, B, C]) == set(get_all_subclasses(A))
    assert set([D, B]) == set(get_all_subclasses(B))
    assert set() == set(get_all_subclasses(D))
    assert set([C]) == set(get_all_subclasses(C))
    assert set([C]) == set(get_all_subclasses(C))

# Generated at 2022-06-22 21:18:38.810430
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create the following class hierarchy
    #          Base
    #          |
    #         Child1
    #          |
    #         Child2
    #          |
    #         Child3
    #          |
    #         Child4
    #          |
    #         Child5
    #          |
    #         Child6
    class Base():
        pass

    class Child1(Base):
        pass

    class Child2(Child1):
        pass

    class Child3(Child2):
        pass

    class Child4(Base):
        pass

    class Child5(Child4):
        pass

    class Child6(Child5):
        pass

    # Calling get_all_subclasses on class Base should return
    # all children and sub-children

# Generated at 2022-06-22 21:18:43.122349
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    assert get_all_subclasses(A) == set([B, C])
    assert get_all_subclasses(B) == set([])
    assert get_all_subclasses(C) == set([])

# Generated at 2022-06-22 21:18:50.553649
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # We test with the following hierarchy
    #
    #         +---+
    #         | A |
    #         +---+
    #         /   \
    #        /     \
    #    +---------+
    #    |     |   |
    #    |   +---+ |
    #    |   | B | |
    #    |   +---+ |
    #    |     |   |
    #    +-----+   +
    #          |
    #          |
    #        +---+
    #        | C |
    #        +---+

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    ansible_subcls = get_all_subclasses(A)
    assert ansible_subcls == set([B, C])

# Generated at 2022-06-22 21:18:59.393984
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(G):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert G in get_all_subclasses(A)
    assert H in get_all_subclasses(A)

    assert B in get_all

# Generated at 2022-06-22 21:19:03.972041
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test the get_all_subclasses utility function
    """
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    assert set(get_all_subclasses(A)) == set([B,C,D,E])

# Generated at 2022-06-22 21:19:11.353897
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(object): pass
    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])

# compat.py

# This file is part of Ansible
#
# Ansible is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License

# Generated at 2022-06-22 21:19:18.960109
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class cls0(object):
        pass
    class cls1(object):
        pass
    class cls2(cls1):
        pass
    class cls3(cls2):
        pass
    class cls4(cls0):
        pass
    class cls5(cls0):
        pass
    class cls6(cls5):
        pass
    class cls7(cls5):
        pass
    assert sorted(get_all_subclasses(object)) == sorted([cls1, cls2, cls3, cls4, cls5, cls6, cls7])


# Generated at 2022-06-22 21:19:24.311483
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    reference_classes = [A,B,C,D,E]
    test_classes = get_all_subclasses(A)
    for test_class in test_classes:
        assert test_class in reference_classes



# Generated at 2022-06-22 21:19:26.659240
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import tempfile
    import os
    module_name = 'dummy_module'
    file_name = module_name + '.py'

# Generated at 2022-06-22 21:19:37.158554
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(G):
        pass
    class I(G):
        pass
    class J(I):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert G in get_all_subclasses(A)
    assert H