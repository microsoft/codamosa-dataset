

# Generated at 2022-06-22 21:09:41.752992
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(E):
        pass

    assert set(get_all_subclasses(A)) == { B, C, D, E, F }

# Generated at 2022-06-22 21:09:50.360596
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Note that you cannot use the standard unit test discovery in this case, because the
    unit tests will be used before this code is imported into the main code (i.e.
    ansible-test), which means the unit tests will not exercise the function.
    """
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(F):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H])

# Generated at 2022-06-22 21:10:00.980427
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Testing the get_all_subclasses function
    '''

    # Setting up a basic tree

    class Root:
        '''
        A root class
        '''

    class A(Root):
        '''
        A sub class of Root
        '''

    class B(Root):
        '''
        A sub class of Root
        '''

    class C(B):
        '''
        A sub class of B
        '''

    class D(Root):
        '''
        A sub class of Root
        '''

    class E(D):
        '''
        A sub class of D
        '''

    class F(D):
        '''
        A sub class of D
        '''

    class G(F):
        '''
        A sub class of F
        '''



# Generated at 2022-06-22 21:10:09.822195
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import ansible.module_utils._text
    import ansible.module_utils._text.to_text
    import ansible.module_utils._text.to_bytes
    import ansible.module_utils._text.to_native

    classes = get_all_subclasses(ansible.module_utils._text.Text)
    assert ansible.module_utils._text.Text in classes
    assert ansible.module_utils._text.to_text.to_text in classes
    assert ansible.module_utils._text.to_bytes.to_bytes in classes
    assert ansible.module_utils._text.to_native.to_native in classes

# Generated at 2022-06-22 21:10:14.814325
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(E):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F])

# Generated at 2022-06-22 21:10:21.202724
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Arrange
    # Create classes to test
    class SuperClass(object):
        pass

    class FirstClass(SuperClass):
        pass

    class SecondClass(SuperClass):
        pass

    class FirstSubClass(FirstClass):
        pass

    class SecondSubClass(SecondClass):
        pass

    class FirstSubSubClass(FirstSubClass):
        pass

    # Act
    # Retrieve all subclasses of SuperClass
    subclasses = get_all_subclasses(SuperClass)

    # Assert
    # Test if all subclasses of SuperClass are in the subclasses list
    assert FirstClass in subclasses
    assert SecondClass in subclasses
    assert FirstSubClass in subclasses
    assert SecondSubClass in subclasses
    assert FirstSubSubClass in subclasses

# Generated at 2022-06-22 21:10:31.554939
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Inner class used in test
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(D):
        pass

    subclasses_of_A = get_all_subclasses(A)
    for current_class in (B, C, D, E, F):
        assert current_class in subclasses_of_A
    assert len(subclasses_of_A) == 5

    subclasses_of_B = get_all_subclasses(B)
    for current_class in (D, E, F):
        assert current_class in subclasses_of_B
    assert len(subclasses_of_B) == 3

    subclasses_of_F = get

# Generated at 2022-06-22 21:10:42.247178
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Simple(object):
        pass
    class A(Simple):
        pass
    class B(Simple):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass

    assert get_all_subclasses(Simple) == set([A, B, C, D, E, F])
    assert get_all_subclasses(A) == set([C, E])
    assert get_all_subclasses(B) == set([D, F])
    assert get_all_subclasses(C) == set([E])
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-22 21:10:46.186612
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    res = get_all_subclasses(A)
    assert set(res) == set([B, C, D])

# Generated at 2022-06-22 21:10:55.052671
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass

    # Test that all the classes are returned
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F, G])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-22 21:11:04.741474
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F:
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(B)) == set([D])
    assert set(get_all_subclasses(C)) == set([E])
    assert set(get_all_subclasses(D)) == set([])
    assert set(get_all_subclasses(E)) == set([])
    assert set(get_all_subclasses(F)) == set([])
test_get_all_subclasses()

# Generated at 2022-06-22 21:11:09.086416
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C, D): pass
    class G(D, E): pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])

# Generated at 2022-06-22 21:11:13.790697
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])

# Generated at 2022-06-22 21:11:24.333731
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit tests for function get_all_subclasses
    '''
    class1 = ansible_mitogen_class()
    class11 = ansible_mitogen_child_class1(class1)
    class12 = ansible_mitogen_child_class2(class1)
    class21 = ansible_mitogen_child_class1(class11)
    class22 = ansible_mitogen_child_class2(class11)
    class3 = ansible_mitogen_child_class3(class11)
    class31 = ansible_mitogen_child_class1(class3)
    class32 = ansible_mitogen_child_class2(class3)
    # Create the set manually
    test_set = set()
    test_set.add(class1)

# Generated at 2022-06-22 21:11:31.787312
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    test get_all_subclasses
    """
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == set()
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set([E])

# Generated at 2022-06-22 21:11:40.684195
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test get_all_subclasses by creating a dummy class hierarchy and iterating over
    each return value to assert that it exists in the class hierarchy
    '''
    # Create dummy class hierarchy
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    my_class = B
    # Get list of subclasses
    subclasses = get_all_subclasses(my_class)
    # Define list of expected subclasses
    expected = [B, D, E]
    # Assert that every subclass is expected
    for subclass in subclasses:
        assert subclass in expected

# Generated at 2022-06-22 21:11:43.453451
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(object):
        pass

    class E(D):
        pass

    class F(E):
        pass

    assert set(get_all_subclasses(A)) == set((B, C))
    assert set(get_all_subclasses(D)) == set((E, F))

# Generated at 2022-06-22 21:11:54.945289
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Creating simple classes
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(D):
        pass

    # Creating a set of expected subclasses
    expected_subclasses = {B, C, D, E, F}
    assert get_all_subclasses(A) == expected_subclasses
    assert get_all_subclasses(B) == {D, E, F}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == {F}
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Import submodules to make them available

# Generated at 2022-06-22 21:12:03.116279
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class cls_a():
        pass
    class cls_b(cls_a):
        pass
    class cls_c(cls_a):
        pass
    class cls_d(cls_b):
        pass
    class cls_e(cls_d):
        pass
    class cls_f(cls_d):
        pass

    # Check function output
    assert get_all_subclasses(cls_a) == {cls_b, cls_c, cls_d, cls_e, cls_f}

# Generated at 2022-06-22 21:12:14.339270
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert G in get_all_subclasses(A)
    assert not H in get_all_subclasses(A)


# Generated at 2022-06-22 21:12:23.570893
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Define a class A
    class A(object):
        pass

    # Define a class B subclass of A
    class B(A):
        pass

    # Define a class C subclass of A
    class C(A):
        pass

    # Define a class D subclass of B
    class D(B):
        pass

    # Define a class E subclass of D
    class E(D):
        pass

    # Define a class F subclass of D
    class F(D):
        pass

    # Define a class G and E
    class G(B,C):
        pass

    # Define a class H and G
    class H(G):
        pass

    # Define a class I and G
    class I(G):
        pass

    # Define a class J and G

# Generated at 2022-06-22 21:12:28.803820
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E(B): pass
    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-22 21:12:40.499478
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Parent(object):
        def __init__(self):
            self.parent = True

    class Child(Parent):
        def __init__(self):
            self.child = True

    class Grandchild(Child):
        def __init__(self):
            self.grandchild = True

    class Sibling(Parent):
        def __init__(self):
            self.sibling = True

    class Spouse(object):
        def __init__(self):
            self.spouse = True

    # Test that all classes are correctly retrieved
    assert Parent in get_all_subclasses(Parent)
    assert Child in get_all_subclasses(Parent)
    assert Grandchild in get_all_subclasses(Parent)
    assert Sibling in get_all_subclasses(Parent)

    # Test that child classes are not retrieved


# Generated at 2022-06-22 21:12:52.074695
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import sys

    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(E):
        pass

    class TestAllSubclasses(unittest.TestCase):
        def test_get_all_subclasses(self):
            # We are testing a recursive function so we use 2 iterations to check
            self.assertEqual(set([D, E, H, F, G]), set(get_all_subclasses(B)))
            self.assertEqual(set([D, E, H, F, G, B]), set(get_all_subclasses(A)))



# Generated at 2022-06-22 21:12:58.582799
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C, B):
        pass

    # Test on all classes
    assert get_all_subclasses(A) == set([B, C, D, E])

    # Test on a specific class
    assert get_all_subclasses(C) == set([D, E])

# Generated at 2022-06-22 21:13:08.818348
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    def assert_sets(s1, s2):
        print(s1)
        print(s2)
        assert s1 == s2

    # Define the class to test
    class A(object):
        pass

    class A1(A):
        pass

    class A1_1(A1):
        pass

    class A1_2(A1):
        pass

    class A1_2_1(A1_2):
        pass

    class A1_3(A1):
        pass

    class A2(A):
        pass

    class A2_1(A2):
        pass

    class A2_2(A2):
        pass

    # Test the function
    subclasses = get_all_subclasses(A)

# Generated at 2022-06-22 21:13:13.906956
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass

    all_subclasses = get_all_subclasses(A)
    for c in [A, B, C, D, E, F, G]:
        assert c not in all_subclasses
    for c in [B, C, D, E, F, G]:
        assert c in all_subclasses

# Module based unit test

# Generated at 2022-06-22 21:13:23.493105
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for method get_all_subclasses

    :returns: None
    '''
    # Define two simple classes with a class hierarchy
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    # Test on class B
    all_subclasses_B = get_all_subclasses(B)
    assert len(all_subclasses_B) == 1
    assert D in all_subclasses_B

    # Test on A
    all_subclasses_A = get_all_subclasses(A)
    assert len(all_subclasses_A) == 3
    assert C in all_subclasses_A
    assert E in all_subclasses_A

# Generated at 2022-06-22 21:13:27.646094
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    classes = get_all_subclasses(A)
    assert classes == set([D, C, B])



# Generated at 2022-06-22 21:13:34.061336
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Tests get_all_subclasses()
    1. Test for all None values for the tests
    2. Test for when head has no subclasses
    3. Test for when there is one subclass of head
    4. Test for when there are multiple subclasses
    '''
    assert get_all_subclasses(None) == set()
    assert get_all_subclasses(int) == {bool}
    assert get_all_subclasses(bool) == set()
    assert get_all_subclasses(float) == set()

# Generated at 2022-06-22 21:13:41.658509
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class B(object):
        pass

    class C(object):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(E):
        pass

    class G(object):
        pass

    subclasses = get_all_subclasses(B)

    assert len(subclasses) == 0, 'get_all_subclasses should return an empty set'

    subclasses = get_all_subclasses(C)

    assert len(subclasses) == 2, 'get_all_subclasses should return 2 classes'
    assert D in subclasses, 'get_all_subclasses must return class D'
    assert E in subclasses, 'get_all_subclasses must return class E'

    subclasses = get_all_subclasses(G)


# Generated at 2022-06-22 21:13:47.843775
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(B, E):
        pass
    class G:
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([C, F])
    assert set(get_all_subclasses(C)) == set()
    assert set(get_all_subclasses(D)) == set([E, F])
    assert set(get_all_subclasses(E)) == set([F])
    assert set(get_all_subclasses(F)) == set()

# Generated at 2022-06-22 21:13:59.269212
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test for module util

    :rtype: bool
    :returns: True if the test passes, else False

    This unit test verifies that the module util's method get_all_subclasses() does what it is
    supposed to.  It uses the following class hierarchy to test the function:

            Animal
          /        \
        Dog        Cat
        |           |
       Pug         Siamese
    '''

    class Animal:
        pass

    class Dog(Animal):
        pass

    class Cat(Animal):
        pass

    class Pug(Dog):
        pass

    class Siamese(Cat):
        pass

    dog_test = set([Dog, Pug])
    cat_test = set([Cat, Siamese])

    assert get_all_subclasses(Animal) == dog_test.union(cat_test)

# Generated at 2022-06-22 21:14:08.346246
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(D):
        pass
    class G(D):
        pass
    l = [A, B, C, D, E, F, G]
    assert(set(get_all_subclasses(A)) == set(l))
    assert(set(get_all_subclasses(D)) == set([D, F, G]))
    assert(set(get_all_subclasses(B)) == set([B, D, E, F, G]))
    class H(object):
        pass
    l.append(H)

# Generated at 2022-06-22 21:14:12.828071
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B,C):
        pass
    class E(B,C):
        pass

    assert B not in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)

# Generated at 2022-06-22 21:14:17.570840
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(A): pass
    class E(B): pass
    class F(C): pass
    class G(F): pass
    class H(D): pass
    result = get_all_subclasses(A)
    assert(result == set([C, F, G, D, H]))

# Generated at 2022-06-22 21:14:21.959232
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Super(object): pass
    class Sub1(Super): pass
    class Sub2(Super): pass
    class Sub3(Sub1): pass
    class Sub4(Sub2): pass
    class Sub5(Super): pass
    class Sub6(Sub5): pass
    assert set(get_all_subclasses(Super)) == {Sub1, Sub2, Sub3, Sub4, Sub5, Sub6}

# Generated at 2022-06-22 21:14:32.701857
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        '''Class for test get_all_subclasses function'''
        pass
    assert get_all_subclasses(A) == set()

    class B(A):
        '''Class for test get_all_subclasses function'''
        pass
    assert get_all_subclasses(A) == set([B])

    class C(A):
        '''Class for test get_all_subclasses function'''
        pass
    assert get_all_subclasses(A) == set([B, C])

    class D(B):
        '''Class for test get_all_subclasses function'''
        pass
    assert get_all_subclasses(A) == set([B, C, D])

    class E(C):
        '''Class for test get_all_subclasses function'''


# Generated at 2022-06-22 21:14:42.177303
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test to check get_all_subclasses
    '''
    class A(object):
        '''
        The class A
        '''
        pass
    class B(A):
        '''
        The class B
        '''
        pass
    class C(A):
        '''
        The class C
        '''
        pass
    class D(B):
        '''
        The class D
        '''
        pass
    class E(B):
        '''
        The class E
        '''
        pass
    # Testing if the function can find all subclasses of A
    assert get_all_subclasses(A) == {B, C, D, E}


# Generated at 2022-06-22 21:14:47.792019
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(F):
        pass
    class H(E):
        pass

    assert get_all_subclasses(A) == set((B, C, D, E, F, G, H))



# Generated at 2022-06-22 21:14:53.896184
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(object):
        pass
    class F(E):
        pass
    class G(E):
        pass
    class H(C, D, G):
        pass

    assert get_all_subclasses(A) == {B, C, D, H}
    assert get_all_subclasses(B) == {C, H}

# Generated at 2022-06-22 21:15:03.136870
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function "get_all_subclasses".
    '''
    # A simple class
    class A(object):
        pass
    # A is subclass of object
    assert A in object.__subclasses__()
    # B is subclass of A
    class B(A):
        pass
    class C(B):
        pass
    assert B in A.__subclasses__()
    # D and E are subclass of A
    class D(A):
        pass
    class E(A):
        pass
    # F is subclass of D
    class F(D):
        pass
    class G(F):
        pass
    # H is subclass of K
    class H(E):
        pass
    class K(A):
        pass
    class L(K):
        pass

# Generated at 2022-06-22 21:15:08.776904
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    class G(F): pass
    subclasses = get_all_subclasses(A)
    assert(list(subclasses) == [D, F, B, G, E, C])
    assert(list(get_all_subclasses(B)) == [D, F, G])


# Generated at 2022-06-22 21:15:19.903611
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Simple test for function get_all_subclasses
    """
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set()
    assert set(get_all_subclasses(C)) == set([D, E, F])
    assert set(get_all_subclasses(D)) == set([F])
    assert set(get_all_subclasses(E)) == set([F])

# Generated at 2022-06-22 21:15:28.064629
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Helper function to help test if get_all_subclasses works properly
    '''
    class A(object):
        pass

    class B(A):
        class C(object):
            pass

    class D(A):
        class E(object):
            pass

    class F(B.C, D.E):
        pass

    # Test that all subclasses are found
    assert get_all_subclasses(A) == set([B, D, B.C, D.E, F])

    # Test empty case
    assert get_all_subclasses(object) == set()

# Generated at 2022-06-22 21:15:37.268283
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Build a mock class class hierarchy using dictionaries to represent classes
    class_tree = {
        'a': {},
        'b': {},
        'c': {},
        'd': {},
        'e': {},
        'f': {},
        'g': {},
        'h': {},
        'i': {},
        'j': {},
        'k': {},
        'l': {},
        'm': {},
        'n': {},
    }
    class_tree['a']['subclasses'] = [class_tree['b'], class_tree['c'], class_tree['d']]
    class_tree['b']['subclasses'] = [class_tree['e'], class_tree['f']]

# Generated at 2022-06-22 21:15:45.471747
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(F):
        pass

    # Ensure that we have the expected subclasses
    assert set([B, C, E, F, G]) == get_all_subclasses(A)

    # Ensure that we don't include the original class
    assert G not in get_all_subclasses(A)

    # Ensure that we don't include non-subclasses
    class H(object):
        pass
    assert H not in get_all_subclasses(A)

# Generated at 2022-06-22 21:15:52.858409
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Defining a small inheritance tree to test the function
    class E(object): pass
    class C(E): pass
    class D(E): pass
    class B(C, D): pass
    class A(B): pass

    # The list of subclass should return A and B.
    subclasses = get_all_subclasses(E)
    assert len(subclasses) == 4
    assert sorted([x.__name__ for x in subclasses]) == ['A', 'B', 'C', 'D']

# Generated at 2022-06-22 21:15:56.409007
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Foo(object): pass
    class Bar(Foo): pass
    class Baz(Bar): pass
    classes = get_all_subclasses(Foo)
    assert len(classes) == 3
    assert Foo in classes
    assert Bar in classes
    assert Baz in classes



# Generated at 2022-06-22 21:16:07.408950
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # We can use a common class to have all class inheritance
    class CommonSuperClass(object):
        pass

    def _test_get_all_subclasses(cls, cls_list):
        assert set(cls_list) == set(get_all_subclasses(cls))

    # With only one sub class to check
    class MyClass(CommonSuperClass):
        pass

    _test_get_all_subclasses(MyClass, [MyClass])

    # One sub class and one sub sub class
    class SubMyClass(MyClass):
        pass

    _test_get_all_subclasses(MyClass, [MyClass, SubMyClass])

    # One sub class and one sub sub class and one sub sub sub class
    class SubSubMyClass(SubMyClass):
        pass

    _test_get_all_

# Generated at 2022-06-22 21:16:14.991436
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    # Set in python < 3.x are unordered, so we need to sort the result of get_subclasses
    # in order to use ==
    assert get_all_subclasses(A) == set(sorted([B, C, D], key=lambda c: c.__name__))
    assert get_all_subclasses(object) == set(sorted([A, B, C, D], key=lambda c: c.__name__))
    assert get_all_subclasses(str) == set()

# Generated at 2022-06-22 21:16:18.702438
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(object): pass
    class G(F): pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(F)) == set([G])

# Generated at 2022-06-22 21:16:28.840038
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    ## Define a small class tree layout
    #
    # class A
    # +-- B(A)
    #     +-- D(B)
    #         +-- E(D)
    # +-- C(A)
    #     +-- F(C)
    #     +-- G(C)
    #         +-- H(G)
    #             +-- I(H)
    #
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(G):
        pass
    class I(H):
        pass
    #
    # Testing get_all_

# Generated at 2022-06-22 21:16:32.976823
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(F):
        pass

    class H(object):
        pass

    assert get_all_subclasses(A) == set((B, C, D, E, F, G))
    assert get_all_subclasses(H) == set()

# Generated at 2022-06-22 21:16:38.416903
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    assert get_all_subclasses(A) == set([C,E])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(object) == set([A,B,C,D,E])

# Generated at 2022-06-22 21:16:44.201348
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D):
        pass

    # Class E has to be at the end of the list
    assert get_all_subclasses(A) == {B, C, D, E}

# Generated at 2022-06-22 21:16:54.348397
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(A):
        pass

    class B1(B):
        pass

    class B2(B):
        pass

    class C1(C):
        pass

    class C2(C):
        pass

    class D1(D):
        pass

    class D2(D):
        pass

    class D3(D):
        pass

    class D4(D):
        pass

    assert get_all_subclasses(A) == set((B, C, D, E, B1, B2, C1, C2, D1, D2, D3, D4))

# Generated at 2022-06-22 21:17:00.018810
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])


# Generated at 2022-06-22 21:17:10.403838
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class AA(object):
        pass

    class BB(AA):
        pass

    class DD(BB):
        pass

    class EE(BB):
        pass

    class FF(BB):
        pass

    class TestGetAllSubclasses(unittest.TestCase):

        def _assert_equals(self, cls, expected):
            self.assertEqual(get_all_subclasses(cls), set(expected))

        def test_basic(self):
            self._assert_equals(object, [])

# Generated at 2022-06-22 21:17:19.364894
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(D):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert G in get_all_subclasses(A)
    assert len(list(get_all_subclasses(A))) == 7

# Generated at 2022-06-22 21:17:27.635327
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(E):
        pass
    class H(G):
        pass
    assert get_all_subclasses(A) == {B, C, D, E, F, G, H}
    assert get_all_subclasses(B) == {D, E, F, G, H}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == {E, F, G, H}
    assert get_all_subclasses(E) == {F, G, H}

# Generated at 2022-06-22 21:17:38.621138
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test for the function :py:func:`get_all_subclasses`.

    Create the following class structure:

        BaseClass
            |
            +-- SubClass1
            |
            +-- SubClass2
                |
                +-- SubSubClass2a
                |
                +-- SubSubClass2b

    Then call :py:func:`get_all_subclasses` on BaseClass and SubClass1 and make sure the same
    classes are returned.
    '''
    class BaseClass:
        pass

    class SubClass1(BaseClass):
        pass

    class SubClass2(BaseClass):
        pass

    class SubSubClass2a(SubClass2):
        pass

    class SubSubClass2b(SubClass2):
        pass


# Generated at 2022-06-22 21:17:49.339516
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(F):
        pass
    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in subclasses
    assert H in subclasses
    assert len(subclasses) == 7

#------------------------------------------------------------------------------
# New sub class with super() that keep compatibility with old style class
#------------------------------------------------------------------------------


# Generated at 2022-06-22 21:17:53.989940
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    list_classes = [D, A, B, C, E]
    assert list_classes == get_all_subclasses(A)

# Generated at 2022-06-22 21:18:01.145761
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define some classes to use in test.
    class A(object):
        pass
    class A1(A):
        pass
    class A2(A):
        pass
    class A11(A1):
        pass

    # Define expected result.
    expected_result = set([A, A1, A2, A11])

    # Call function.
    actual_result = get_all_subclasses(A)

    # Compare result.
    assert expected_result == actual_result


# Generated at 2022-06-22 21:18:07.876704
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # This is the class to test
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(E): pass
    # create the reference set
    ref_set = set([B, C, D, E, F])
    # assert the result
    assert get_all_subclasses(A) == ref_set

# Generated at 2022-06-22 21:18:12.148673
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert len(subclasses) == 5

# Generated at 2022-06-22 21:18:18.112622
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(object): pass
    class D(B): pass
    class E(B): pass
    class F(D): pass
    class G(F): pass
    class H(object): pass
    class I(H): pass
    class J(D): pass

    assert get_all_subclasses(A) == {B, D, E, F, G, J}

# Generated at 2022-06-22 21:18:24.928622
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I])

# Generated at 2022-06-22 21:18:34.008959
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(B)) == set([C])
    assert set(get_all_subclasses(C)) == set([])
    assert set(get_all_subclasses(D)) == set([E])
    assert set(get_all_subclasses(E)) == set([])

# Generated at 2022-06-22 21:18:43.029714
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class J(C):
        pass

    assert set([D, E, F, J]) == get_all_subclasses(A)
    assert set([F]) == get_all_subclasses(D)
    assert set([J]) == get_all_subclasses(C)
    assert set() == get_all_subclasses(object)

# Generated at 2022-06-22 21:18:48.536620
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Hopefully this class isn't used in multiple test cases at the same time
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(A):
        pass

    class F(A):
        pass

    assert D not in get_all_subclasses(B)
    assert get_all_subclasses(B) == set((C, ))
    assert get_all_subclasses(A) == set((B, C, D, E, F))

# Generated at 2022-06-22 21:18:55.893919
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    # C and D are indirect subclasses of A
    class C(object):
        pass

    class D(C):
        pass

    class E(D):
        pass

    A.__bases__ += (C,)

    # B is a direct subclass of A and C
    assert B in get_all_subclasses(A)
    assert B in get_all_subclasses(C)
    # E is an indirect subclass of A
    assert E in get_all_subclasses(A)

# Generated at 2022-06-22 21:19:07.075853
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    # The set of classes which we expect to be direct subclasses of AnsibleModule
    expected_subclasses = {basic.AnsibleModule}

    # The set of classes which we expect to be direct subclasses of AnsibleModule
    expected_subclasses.update(basic.AnsibleModule.__subclasses__())

    # The set of classes which we expect to be subclasses of AnsibleModule

# Generated at 2022-06-22 21:19:18.782481
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_text
    from ansible.parsing.ajson import AnsibleJSONEncoder

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    a_subclasses = get_all_subclasses(A)

    assert A in a_subclasses
    assert B in a_subclasses
    assert C in a_subclasses
    assert D in a_subclasses
    assert E in a_subclasses

    a_subclasses_str = to_text(AJsonEncoder().encode(a_subclasses))
    assert len(a_subclasses_str) == 42

# Generated at 2022-06-22 21:19:25.735407
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class X(object):
        pass

    class Y(X):
        pass

    class Z(X):
        pass

    class T(Y, Z):
        pass

    class U(Y):
        pass

    assert get_all_subclasses(X) == set([Y, Z, T, U])

    class M(object):
        pass

    class N(object):
        pass

    class O(object):
        pass

    class P(O):
        pass

    assert get_all_subclasses(M) == set()
    assert get_all_subclasses(N) == set()
    assert get_all_subclasses(O) == set([P])

# Generated at 2022-06-22 21:19:33.861482
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(A):
        pass
    class F(object):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(F) == set()
    assert get_all_subclasses(str) == set(str.__subclasses__())


# Generated at 2022-06-22 21:19:38.587359
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    # Create tree A -> B -> D E, A -> C -> F G
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
