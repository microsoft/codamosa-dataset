

# Generated at 2022-06-22 21:09:47.555189
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(object):
        pass
    class I(H):
        pass

    assert set(get_all_subclasses(A)) == set((B, C, D, E, F, G))
    assert set(get_all_subclasses(B)) == set((C, D, E, F, G))
    assert set(get_all_subclasses(C)) == set((D, E, F, G))
    assert set(get_all_subclasses(D)) == set((E, F, G))

# Generated at 2022-06-22 21:09:58.164712
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(G):
        pass

    class I(G):
        pass

    # Checking all subclasses are known
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I])
    assert get_all_subclasses(B) == set([D, E, F, G, H, I])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set([F])

# Generated at 2022-06-22 21:10:09.194947
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # We take several classes to test the function
    class ClassA(object):
        pass

    class ClassB(ClassA):
        pass

    class ClassC(ClassA):
        pass

    class ClassD(ClassB):
        pass

    # For this class, we set dynamically the subclasses
    class ClassE(ClassD):
        pass

    ClassE.__bases__ += (ClassA,)

    class ClassF(ClassB):
        pass

    class ClassG(ClassF):
        pass

    class ClassH(object):
        pass

    classes = set([ClassA, ClassB, ClassC, ClassD, ClassE, ClassF, ClassG, ClassH])
    all_class = get_all_subclasses(ClassA)
    assert all_class == classes

# Generated at 2022-06-22 21:10:18.591494
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(object):
        pass
    class G(F):
        pass

    assert get_all_subclasses(A) == set([B, D, C, E])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([G])
    assert get_all_subclasses(G) == set([])

# Generated at 2022-06-22 21:10:24.268698
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass

    # Here is the result for class A
    assert A.__subclasses__() == [B, C]
    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-22 21:10:33.910035
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(C): pass
    class G(F): pass
    class H: pass
    class I: pass
    class J(H): pass
    class K(J): pass

    # Test simple case
    result = get_all_subclasses(A)
    assert result == set([B, C, D, E, F, G])

    # Test multiple roots case
    result = get_all_subclasses(object)
    assert result == set([A, B, C, D, E, F, G, H, I, J, K])

# Generated at 2022-06-22 21:10:41.344155
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(C): pass
    assert(get_all_subclasses(A) == set([B, C, D, E]))
    assert(get_all_subclasses(B) == set())
    assert(get_all_subclasses(C) == set([D, E]))
    assert(get_all_subclasses(D) == set())
    assert(get_all_subclasses(E) == set())

# Generated at 2022-06-22 21:10:51.567231
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class A1(A):
        pass
    class A2(A):
        pass
    class A11(A1):
        pass
    class A22(A2):
        pass
    class A111(A11):
        pass
    class B(object):
        pass
    class B1(B):
        pass
    classes = [A, A1, A2, A11, A22, A111, B, B1]
    subclasses_of_A = set([A1, A2, A11, A22, A111])
    subclasses_of_A1 = set([A11, A111])
    subclasses_of_A11 = set([A111])
    subclasses_of_A2 = set([A22])

# Generated at 2022-06-22 21:11:01.873065
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from _utils import get_all_subclasses
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(C):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([D, E, F])
    assert get_all_subclasses(C) == set([G])
    assert get_all_subclasses(D) == set([E, F])
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()
    assert get

# Generated at 2022-06-22 21:11:11.714848
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # We use this simple class hierarchy for testing
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass

    # Expected results
    A_classes = [A, B, C, D, E, F]
    B_classes = [B, D, F]
    C_classes = [C, E]
    D_classes = [D, F]
    E_classes = [E]
    F_classes = [F]

    assert get_all_subclasses(A) == set(A_classes)
    assert get_all_subclasses(B) == set(B_classes)

# Generated at 2022-06-22 21:11:14.951994
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    assert get_all_subclasses(A) == set((B, C, D))

# Generated at 2022-06-22 21:11:25.662303
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import inspect
    from ansible.module_utils.six import PY3

    python_version = inspect.getargspec(get_all_subclasses)[1]
    if PY3:
        assert python_version == ['cls']
        assert 'cls' in get_all_subclasses.__code__.co_varnames
    else:
        assert python_version == ['cls', '_seen']
        assert 'cls' in get_all_subclasses.__code__.co_varnames
        assert '_seen' in get_all_subclasses.__code__.co_varnames

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    subclasses_of_A = get_all_subclasses(A)
    #

# Generated at 2022-06-22 21:11:33.464205
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import mock
    # Create two fake classes
    class B(object):
        pass
    class C(B):
        pass
    # Mock B class
    mock_B = mock.Mock(spec=B)
    mock_B.__subclasses__.return_value = [C]
    # Run function
    result = get_all_subclasses(mock_B)
    # Assert result is a set and contains only C
    assert isinstance(result, set)
    assert len(result) == 1
    assert C in result
    # Assert __subclasses__ of B was called
    mock_B.__subclasses__.assert_called_once_with()

# Generated at 2022-06-22 21:11:41.358524
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(E):
        pass

    assert get_all_subclasses(A) == set([B,C,D,E,F])
    assert get_all_subclasses(B) == set([C])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set([E,F])
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-22 21:11:52.911814
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Animal: pass
    class Mammal(Animal): pass
    class Marsupial(Mammal): pass
    class Carnivore(Mammal): pass
    class Oviparous(Animal): pass
    class MammalCarnivore(Carnivore): pass
    class MammalOviparous(Oviparous): pass

    assert get_all_subclasses(Animal) == {Mammal, Marsupial, Carnivore, Oviparous, MammalCarnivore, MammalOviparous}
    assert get_all_subclasses(Mammal) == {Marsupial, Carnivore, MammalCarnivore, MammalOviparous}
    assert get_all_subclasses(MammalCarnivore) == set()

# Generated at 2022-06-22 21:11:57.347503
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    assert get_all_subclasses(A) == {B, D, C}
    assert get_all_subclasses(B) == {C}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-22 21:12:03.031171
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class cls1():
        pass
    class cls2():
        pass
    class cls3(cls1, cls2):
        pass
    class cls4(cls2):
        pass
    class cls5(cls3, cls4):
        pass
    assert get_all_subclasses(cls2) == {cls3, cls4, cls5}

# Generated at 2022-06-22 21:12:08.738232
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])



# Generated at 2022-06-22 21:12:19.035528
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Unit test for get_all_subclasses()
    """
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(B):
        pass
    class H(G):
        pass

    assert get_all_subclasses(object) == set([A, B, C, D, E, F, G, H])
    assert get_all_subclasses(A) == set([A, C, D, E, F])
    assert get_all_subclasses(B) == set([B, G, H])
    assert get_all_subclasses(C) == set([C])
    assert get_all_sub

# Generated at 2022-06-22 21:12:26.196986
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a class hierarchy
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(B): pass
    class F(E): pass
    class G(D): pass
    class H(D): pass
    # Test getting all subclasses of a given class
    assert get_all_subclasses(object) == get_all_subclasses(object())
    assert get_all_subclasses(object) == set([A, B, C, D, E, F, G, H])
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])
    assert get_all_subclasses(B) == set([C, E, F])

# Generated at 2022-06-22 21:12:32.134021
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Defining test class hierarchy
    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(C):
        pass

    # Testing get_all_subclasses
    assert get_all_subclasses(A) == set([C,D,E])
    # Testing get_all_subclasses of top-level class
    assert get_all_subclasses(object) == set([type,type(type),])

# Generated at 2022-06-22 21:12:39.608779
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    assert get_all_subclasses(A) == set((B, C, D, E))
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set((D, E))
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-22 21:12:51.096379
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class D(A): pass
    class E(D): pass
    class F(E): pass
    class G(E): pass
    class C(B, D): pass
    class H(C): pass
    # Testing that H is an instance of all its superclass
    assert issubclass(H, A)
    assert issubclass(H, B)
    assert issubclass(H, C)
    assert issubclass(H, D)
    assert issubclass(H, E)
    assert issubclass(H, F)
    assert issubclass(H, G)
    assert issubclass(H, H)
    # Testing function get_all_subclasses on each classes

# Generated at 2022-06-22 21:12:57.918776
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys

    if sys.version_info < (2, 7):
        return

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(D):
        pass

    class I(F):
        pass

    sub_classes = get_all_subclasses(A)
    assert B in sub_classes
    assert C in sub_classes
    assert D in sub_classes
    assert E in sub_classes
    assert F in sub_classes
    assert G in sub_classes
    assert H in sub_classes
    assert I in sub_classes

    sub_classes = get_all_

# Generated at 2022-06-22 21:13:08.467090
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    ''' Unit test for function `get_all_subclasses`.

    This function declares a series of classes and tests the `get_all_subclasses` function with
    these classes.  If the function does not return the expected results, an `AssertionError` is
    raised.
    '''
    class A(): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(F): pass
    class H(C): pass
    class I(H): pass
    class J(): pass
    class K(J): pass
    class L(K): pass
    class M(K): pass
    class N(J): pass
    class O(N): pass
    class P(N): pass

# Generated at 2022-06-22 21:13:12.232424
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    class G(D): pass
    class H(E): pass
    A_subclasses = set([B, C, D, E, F, G, H])
    assert get_all_subclasses(A) == A_subclasses



# Generated at 2022-06-22 21:13:17.655910
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Iterable
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    assert(
        set([A, C, B, D]) == get_all_subclasses(A)
    )

# Generated at 2022-06-22 21:13:25.798973
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(B):
        pass


# Generated at 2022-06-22 21:13:34.067846
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(E):
        pass
    assert get_all_subclasses(A) == set((B, C, D, E, F))
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set((D, E, F))
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set((F,))
    assert get_all_subclasses(F) == set()



# Generated at 2022-06-22 21:13:39.095385
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)

# Generated at 2022-06-22 21:13:44.565741
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(B): pass
    assert set((B, C)) == get_all_subclasses(A)
    assert set((C,)) == get_all_subclasses(B)
    assert set((A)) == get_all_subclasses(A, only_leaf=True)


# Generated at 2022-06-22 21:13:46.608650
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert(set(get_all_subclasses(bool)) == set([True.__class__, False.__class__]))



# Generated at 2022-06-22 21:13:58.317118
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        '''
        Simple class A
        '''
        pass

    class B(A):
        '''
        Simple class B, subclass of A
        '''
        pass

    class C(B):
        '''
        Simple class C, subclass of B
        '''
        pass

    class D(A):
        '''
        Simple class D, subclass of A
        '''
        pass

    # Check we found all subclasses of A
    all_subclasses_A = get_all_subclasses(A)  # pylint: disable=no-value-for-parameter
    assert all_subclasses_A == {B, C, D}

    # Check we found the subclasses of D
    all_subclasses_D = get_all_subclasses(D)  # pylint

# Generated at 2022-06-22 21:14:07.751907
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        """Base class which don't have subclasses"""
        pass

    class B(A):
        pass

    class C(A):
        """Class with two subclasses"""
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(C):
        """Class with one subclass and one sub-sub-class"""
        pass

    class G(F):
        pass

    class H(G):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D, E, F, G, H}
    assert set(get_all_subclasses(B)) == set()
    assert set(get_all_subclasses(C)) == {D, E, F, G, H}

# Generated at 2022-06-22 21:14:11.386657
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])

# Generated at 2022-06-22 21:14:20.460354
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class B(object):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class FF(E):
        pass
    class GG(E):
        pass
    class F(object):
        pass
    class G(F):
        pass
    class H(F):
        pass
    class I(F):
        pass
    class K(G):
        pass
    class L(H):
        pass
    class MM(L):
        pass
    class NN(MM):
        pass
    class P(G):
        pass
    classes = get_all_subclasses(object)
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert FF in classes
    assert GG in classes

# Generated at 2022-06-22 21:14:27.240852
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class F(object):
        pass

    # Only direct subclasses
    assert C.__subclasses__() == [D]
    assert D.__subclasses__() == []
    assert F.__subclasses__() == []
    assert A.__subclasses__() == [B, C]

    # Classes with subclasses
    assert list(get_all_subclasses(C)) == [D]
    assert list(get_all_subclasses(B)) == []
    assert list(get_all_subclasses(F)) == []
    assert list(get_all_subclasses(A)) == [B, C, D]

# Generated at 2022-06-22 21:14:31.846796
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    assert set([B,C,D,E]) == get_all_subclasses(A)

# Generated at 2022-06-22 21:14:37.474740
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Two level
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    assert(get_all_subclasses(A) == set([B, C]))
    # Three level
    class D(B):
        pass
    class E(C):
        pass
    assert(get_all_subclasses(A) == set([B, C, D, E]))

# Generated at 2022-06-22 21:14:47.148763
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Cls1:
        pass

    class Cls2(Cls1):
        pass

    class Cls2bis(Cls1):
        pass

    class Cls3(Cls1):
        pass

    class Cls3bis(Cls3):
        pass

    class Cls3tris(Cls3):
        pass

    subclasses = get_all_subclasses(Cls1)
    assert len(subclasses) == 5

    assert all(cls in subclasses for cls in (Cls1, Cls2, Cls2bis, Cls3, Cls3bis, Cls3tris))
    assert all(isinstance(cls, Cls1) for cls in subclasses)

# Generated at 2022-06-22 21:14:57.627106
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(E, C):
        pass

    class G:
        pass

    A.__subclasses__ = lambda x=A: [B, C]
    B.__subclasses__ = lambda x=B: []
    C.__subclasses__ = lambda x=C: [D]
    D.__subclasses__ = lambda x=D: [E]
    E.__subclasses__ = lambda x=E: []
    F.__subclasses__ = lambda x=F: []
    G.__subclasses__ = lambda x=G: []

    classes = get_all_subclasses(A)
    assert B in classes

# Generated at 2022-06-22 21:15:01.477414
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == set([B, D, E, C])

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-22 21:15:06.067134
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    subclasses = get_all_subclasses(A)
    assert {B, C, D} == subclasses

# Generated at 2022-06-22 21:15:10.711595
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D])

# Generated at 2022-06-22 21:15:21.720379
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import ansible.module_utils as mutils

    class C1:
        pass

    C1_1 = C1

    class C2(C1):
        pass

    class C2_1(C2):
        pass

    class C2_2(C2):
        pass

    C2_1_1 = C2_1

    # Classes from module_utils submodules
    C3_1 = mutils.module_utils_common.AnsibleModule

    # Classes from builtins modules
    class C4(list):
        pass

    subclasses = get_all_subclasses(C1)
    assert type(C2) in subclasses
    assert type(C2_1) in subclasses
    assert type(C2_2) in subclasses
    assert type(C2_1_1) in subclasses


# Generated at 2022-06-22 21:15:27.950727
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test class
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(F):
        pass
    all_subclasses = get_all_subclasses(A)
    assert all_subclasses == set([C, E, G, F, D, B])

# Generated at 2022-06-22 21:15:38.859708
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Hello(object):
        pass

    class Hello1(Hello):
        pass

    class Hello2(Hello):
        pass

    class Hello3(Hello):
        pass

    class Hello11(Hello1):
        pass

    class Hello12(Hello1):
        pass

    class Hello12A(Hello12):
        pass

    class Hello12B(Hello12):
        pass

    class Hello13(Hello1):
        pass

    # Expected class tree for the test

# Generated at 2022-06-22 21:15:46.177559
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(B)) == set([])
    assert set(get_all_subclasses(C)) == set([D])
    assert set(get_all_subclasses(D)) == set([])
    assert set(get_all_subclasses(E)) == set([])

# Generated at 2022-06-22 21:15:51.332817
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Cls1(object): pass
    class SubCls1(Cls1): pass
    class Sub2Cls1(Cls1): pass
    class SubSubCls1(SubCls1): pass

    assert get_all_subclasses(Cls1) == {SubCls1, Sub2Cls1, SubSubCls1}

# Generated at 2022-06-22 21:15:59.484978
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Testing on a class with tree-structured of subclasses
    #
    # cls
    # +-- sc1
    # |   +-- ssc1
    # |   +-- ssc2
    # +-- sc2
    # |   +-- ssc3
    # |       +-- sssc1
    # |       +-- sssc2
    # +-- sc3
    # |   +-- ssc4
    # +-- sc4
    class cls(object):
        pass
    class sc1(cls):
        pass
    class sc2(cls):
        pass
    class sc3(cls):
        pass
    class sc4(cls):
        pass
    class ssc1(sc1):
        pass
    class ssc2(sc1):
        pass
   

# Generated at 2022-06-22 21:16:07.561448
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    assert (A in get_all_subclasses(A))
    class B(A): pass
    assert (A in get_all_subclasses(B))
    assert (B in get_all_subclasses(A))
    class C(A): pass
    class D(C): pass
    assert (A in get_all_subclasses(C))
    assert (A in get_all_subclasses(D))
    assert (B not in get_all_subclasses(D))
    assert (C in get_all_subclasses(D))

# Generated at 2022-06-22 21:16:12.609011
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(D):
        pass

    l = get_all_subclasses(A)
    assert l == {B, C, D, E, F, G}

# Generated at 2022-06-22 21:16:19.596806
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(object):
        pass
    class G(object):
        pass
    class H(G):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(D) == set([E])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])
    assert get_all_subclasses(G) == set([H])
    assert get_all_subclasses(H)

# Generated at 2022-06-22 21:16:29.502715
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Super():
        pass

    class Sub(Super):
        pass

    class Sub2(Super):
        pass

    class SubSub(Sub):
        pass

    class SubSubSub(SubSub):
        pass

    class SubSubSub2(SubSub):
        pass

    class SubSub2(Sub2):
        pass

    assert set(get_all_subclasses(Super)) == {Sub, Sub2, SubSub, SubSubSub, SubSubSub2, SubSub2}
    assert set(get_all_subclasses(Sub)) == {SubSub, SubSubSub, SubSubSub2}
    assert set(get_all_subclasses(Sub2)) == {SubSub2}
    assert set(get_all_subclasses(SubSub)) == {SubSubSub, SubSubSub2}



# Generated at 2022-06-22 21:16:40.068564
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object): pass
    class B(A): pass
    class C(A): pass
    class C1(C): pass
    class C2(C): pass
    class C21(C2): pass
    class C22(C2): pass
    class D(B): pass
    class E(D): pass

# Generated at 2022-06-22 21:16:44.666363
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(B):
        pass

    expected = {A, B, C, D, E}
    assert expected == get_all_subclasses(object)

# Generated at 2022-06-22 21:16:54.864737
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class C(object):
        pass

    class D(B, A):
        pass

    class E(D, C):
        pass

    class F(E):
        pass

    class G(E):
        pass

    assert set([A, D, E, F, G]) == get_all_subclasses(A)
    assert set([B, D, E, F, G]) == get_all_subclasses(B)
    assert set([C, E]) == get_all_subclasses(C)
    assert set([D, E, F, G]) == get_all_subclasses(D)
    assert set([E, F, G]) == get_all_subclasses(E)
    assert set([F]) == get_all_sub

# Generated at 2022-06-22 21:17:06.167397
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a dummy class tree
    class B(object):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(object):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(F):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass

    assert set(get_all_subclasses(B)) == set([C, D, E])
    assert set(get_all_subclasses(F)) == set([G, H, I, J, K, L, M])

# Generated at 2022-06-22 21:17:11.742944
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(object):
        pass

    assert get_all_subclasses(A) == {B, C}
    assert get_all_subclasses(B) == {C}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-22 21:17:18.609773
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(G):
        pass

    classes = get_all_subclasses(A)
    assert len(classes) == 7
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert G in classes
    assert H in classes

# Generated at 2022-06-22 21:17:26.561919
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test getting all subclasses of a given class
    """
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class B2(A): pass
    class C2(B2): pass
    class C3(B2): pass
    class X(A): pass

    assert(set(get_all_subclasses(A)) == set([B, C, B2, C2, C3, X]))
    assert(set(get_all_subclasses(B)) == set([C]))
    assert(set(get_all_subclasses(B2)) == set([C2, C3]))

# Generated at 2022-06-22 21:17:31.174520
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A (object): pass
    class B (A): pass
    class C (A): pass
    class D (B): pass
    class E (D,C): pass
    class F (A): pass
    assert get_all_subclasses(A) == set([B,C,D,E,F])

# Generated at 2022-06-22 21:17:36.886600
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(A): pass
    class E(C): pass
    class F(C): pass
    class G(E): pass
    assert(set(get_all_subclasses(A)) == set([B, C, D, E, F, G]))



# Generated at 2022-06-22 21:17:48.397802
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class MyClass(object):
        '''
        An empty class that is used for testing.
        '''

    class MyClass1(MyClass):
        '''
        An empty class that is used for testing.
        '''

    class MyClass2(MyClass):
        '''
        An empty class that is used for testing.
        '''

    class MyClass3(MyClass):
        '''
        An empty class that is used for testing.
        '''

    class MyClass4(MyClass):
        '''
        An empty class that is used for testing.
        '''

    class MyClass5(MyClass):
        '''
        An empty class that is used for testing.
        '''


# Generated at 2022-06-22 21:17:59.614971
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types
    import unittest
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D,E):
        pass

    class TestGetMethodTests(unittest.TestCase):
        def test_get_all_subclasses(self):
            res = get_all_subclasses(A)
            self.assertIn(B,res)
            self.assertIn(C,res)
            self.assertIn(D,res)
            self.assertIn(E,res)
            self.assertIn(F,res)

# Generated at 2022-06-22 21:18:09.581356
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a test class hierarchy
    class A(object):
        """ This is A """
    class B(object):
        """ This is B """
    class C(A):
        """ This is C """
    class D(A):
        """ This is D """
    class E(B):
        """ This is E """
    class F(E):
        """ This is F """
    class G(F):
        """ This is G """

    # Expected class hierarchy
    expected_classes = set([A, C, D, B, E, F, G])
    derived_classes = get_all_subclasses(object)

    # Compute class hierarchy
    assert set(derived_classes) == expected_classes

# Generated at 2022-06-22 21:18:20.933858
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # pylint: disable=invalid-name
    """
    This unit test checks the functionality of the (function) get_all_subclasses.
    """
    # Create an example of class hierarchy containing these classes
    # (parents are used as bases for their children)
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(B):
        pass

    class F(E):
        pass

    class G(B):
        pass

    class H(C):
        pass

    class I(H):
        pass

    # Class for testing comparing performances of get_all_subclasses and
    # using direct calls of __subclasses__ method
    class Z(object):
        pass


# Generated at 2022-06-22 21:18:31.544148
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This tests the function get_all_subclasses by creating a nested class structure and
    comparing the result of get_all_subclasses with the expected class structure.
    '''
    import unittest

    class __test__(unittest.TestCase):
        def test_get_all_subclasses(self):
            class B(object):
                pass
            class C(B):
                pass
            class D(B):
                pass
            class E(D):
                pass
            class F(object):
                pass

            class G(object):
                pass

            class A(B, C, F):
                pass

            self.assertEqual(get_all_subclasses(A), set([B, C, A, E, F, D]))

# Generated at 2022-06-22 21:18:36.457349
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    found_classes = set(get_all_subclasses(A))

    assert B in found_classes
    assert C in found_classes
    assert D in found_classes
    assert E in found_classes

# Generated at 2022-06-22 21:18:46.815881
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a parent class
    class A(object):
        pass
    # Define two direct children classes
    class B(A):
        pass
    class C(A):
        pass

    # Define a grandchild
    class D(B):
        pass

    # Define a class which is not a child of A
    class E(object):
        pass

    subclasses = get_all_subclasses(A)
    assert A in subclasses
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E not in subclasses

    subclasses = get_all_subclasses(B)
    assert A not in subclasses
    assert B in subclasses
    assert C not in subclasses
    assert D in subclasses
    assert E not in subclasses

#
# Compatibility functions for plain

# Generated at 2022-06-22 21:18:56.458092
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class C1(object):
        pass

    class C2(C1):
        pass

    class C3(object):
        pass

    class C4(C1):
        pass

    class C5(C3):
        pass

    assert(set(get_all_subclasses(C1)) == set([C2, C4]))
    assert(set(get_all_subclasses(C2)) == set())
    assert(set(get_all_subclasses(C3)) == set([C5]))
    assert(set(get_all_subclasses(C4)) == set())
    assert(set(get_all_subclasses(C5)) == set())


# Generated at 2022-06-22 21:19:06.834145
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    def subclass_tree(cls):
        return {
            cls.__name__: [subclass_tree(subclass) for subclass in get_all_subclasses(cls)]
        }

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    from copy import deepcopy
    expected_tree = {
        'A': [{
            'C': [{
                'E': []
            }, {
                'D': []
            }]
        }, {
            'B': []
        }],
    }

    assert deepcopy(expected_tree) == subclass_tree(A)



# Generated at 2022-06-22 21:19:17.748783
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(A):
        pass

    class F(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([C, D])
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-22 21:19:26.032121
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Small inheritance
    class Test1(object):
        pass

    class Test2(Test1):
        pass

    class Test3(Test2):
        pass

    assert Test1 in get_all_subclasses(Test1)
    assert Test2 in get_all_subclasses(Test1)
    assert Test3 in get_all_subclasses(Test1)

    # Multiple inheritance on one level
    class Test1(object):
        pass

    class Test2(Test1):
        pass

    class Test3(Test1):
        pass

    assert Test3 in get_all_subclasses(Test1)
    assert Test2 in get_all_subclasses(Test1)
    assert Test1 in get_all_subclasses(Test1)

    # Multiple inheritance on two level
    class Test1(object):
        pass

   

# Generated at 2022-06-22 21:19:37.123986
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from units.compat import unittest
    from units.compat.mock import Mock, patch
    from units.modules.utils import AnsibleModule
    from units.modules._utils import base_action

    class Action_A(base_action):
        pass

    class Action_B(Action_A):
        pass

    class Action_C(Action_B):
        pass

    class Action_D(Action_B):
        pass

    # We use a mock module to isolate Action_A and its subclasses
    # I would prefer to use a metaclass to do this, but that would make the
    # test itself much harder to write and understand