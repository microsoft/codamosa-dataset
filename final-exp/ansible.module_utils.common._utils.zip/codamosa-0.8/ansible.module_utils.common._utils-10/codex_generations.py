

# Generated at 2022-06-11 00:32:44.544991
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class meta(type):
        def __repr__(self):
            return self.__name__
    class A(metaclass=meta):
        pass
    class B(A):
        pass
    class C(metaclass=meta):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    class F(D):
        pass

    assert set([A, B, D, E, F, object]) == get_all_subclasses(A)
    assert set([B, D, E, F]) == get_all_subclasses(B)
    assert set([C]) == get_all_subclasses(C)
    assert set([D, E, F]) == get_all_subclasses(D)
    assert set([E]) == get_all_subclasses(E)

# Generated at 2022-06-11 00:32:48.942169
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(A):
        pass
    class F(E):
        pass
    class G(E):
        pass
    class H(G):
        pass
    all_classes = get_all_subclasses(A)
    assert B in all_classes
    assert C in all_classes
    assert D in all_classes
    assert E in all_classes
    assert F in all_classes
    assert G in all_classes
    assert H in all_classes

# Generated at 2022-06-11 00:32:57.051829
# Unit test for function get_all_subclasses

# Generated at 2022-06-11 00:33:01.929656
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B:
        pass

    class C(B):
        pass

    class D(A):
        pass

    # Subclasses of A
    assert set([D]) == get_all_subclasses(A)
    # Subclasses of B
    assert set([C]) == get_all_subclasses(B)

# Generated at 2022-06-11 00:33:09.182782
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This function is used to test get_all_subclasses.
    Please do not modify the code.
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    subclasses = get_all_subclasses(A)
    expected = set([B, C, D, E, F])
    assert subclasses == expected

# Generated at 2022-06-11 00:33:18.891729
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(E):
        pass

    # A --> C --> F
    #      --> D --> G
    # B --> E --> H
    assert set(get_all_subclasses(A)) == set([C, D, F, G])
    assert set(get_all_subclasses(B)) == set([E, H])
    assert set(get_all_subclasses(C)) == set([F])
    assert set(get_all_subclasses(D)) == set([G])

# Generated at 2022-06-11 00:33:27.453898
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Father:
        pass
    class Son1(Father):
        pass
    class Son2(Father):
        pass
    class GrandSon1(Son1):
        pass
    class GrandSon2(Son1):
        pass
    class GrandGrandSon(GrandSon1):
        pass
    class Uncle(Father):
        pass
    subclasses = get_all_subclasses(Father)
    assert Father not in subclasses
    assert Son1 in subclasses
    assert Son2 in subclasses
    assert GrandSon1 in subclasses
    assert GrandSon2 in subclasses
    assert GrandGrandSon in subclasses
    assert Uncle in subclasses


# Generated at 2022-06-11 00:33:36.621281
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(object):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([C])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([E])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])


# Generated at 2022-06-11 00:33:44.526110
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([C])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([E])
    assert get_all_subclasses(E) == set([])

# Generated at 2022-06-11 00:33:50.556400
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # We create a class "base" which has 3 subclass: A, B, C which has itself subclass AA and AB
    class base:
        pass
    class A(base):
        pass
    class B(base):
        pass
    class C(base):
        pass
    class AA(A):
        pass
    class AB(A):
        pass
    assert len(get_all_subclasses(base)) == 5



# Generated at 2022-06-11 00:34:03.821414
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(D):
        pass
    class H(E):
        pass

    assert set([B, D, F, G, C, E, H]) == get_all_subclasses(A)
    assert set([D, F, G]) == get_all_subclasses(B)
    assert set([E, H]) == get_all_subclasses(C)
    assert set([F, G]) == get_all_subclasses(D)
    assert set([H]) == get_all_subclasses(E)
    assert set() == get_all_subclasses(F)

# Generated at 2022-06-11 00:34:15.146442
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(B):
        pass

    class H(G):
        pass

    class I(B):
        pass

    class J(C):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H, I, J])

    class K(E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H, I, J, K])

    class L(collections.Iterable):
        pass

# Generated at 2022-06-11 00:34:21.399895
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Animal:
        pass

    class Dog(Animal):
        pass

    class Cat(Animal):
        pass

    class Labrador(Dog):
        pass

    class Poodle(Dog):
        pass

    class Siamese(Cat):
        pass

    class Yorkshire(Cat):
        pass

    assert get_all_subclasses(Animal) == {Dog, Cat, Labrador, Poodle, Siamese, Yorkshire}

# Generated at 2022-06-11 00:34:26.958106
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Example of A python class hierarchy for unit test
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass
    class E(object):
        pass
    class F(D):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, F])
    assert set(get_all_subclasses(E)) == set([])

# Generated at 2022-06-11 00:34:32.818047
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class ClassA(object):
        pass

    class ClassB(ClassA):
        pass

    class ClassC(ClassB):
        pass

    class ClassD(ClassA):
        pass

    expected_subclasses = set([ClassB, ClassC, ClassD])
    actual_subclasses = get_all_subclasses(ClassA)
    assert actual_subclasses == expected_subclasses

# Generated at 2022-06-11 00:34:41.063707
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(A):
        pass

    class H(object):
        pass

    assert set(A.__subclasses__()) == set([B, D, G])
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(H) == set([])

# Generated at 2022-06-11 00:34:45.401610
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert get_all_subclasses(A) == set([B, C, D])

# Generated at 2022-06-11 00:34:57.351036
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types
    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F():
        pass
    class G(F):
        pass
    class H(F):
        pass
    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 4
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses

    subclasses = get_all_subclasses(F)
    assert len(subclasses) == 2
    assert G in subclasses
    assert H in subclasses

    subclasses = get_all_subclasses(types.ModuleType)
    assert len(subclasses) == 0

# Generated at 2022-06-11 00:35:08.648354
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types
    import inspect
    # Test classes
    class A: pass
    class B: pass
    class C: pass
    class D(A): pass
    class E(B,C): pass
    class F(C): pass
    class G(D,E,F): pass
    # Test
    assert not get_all_subclasses(type)
    subclasses = get_all_subclasses(object)
    assert len(subclasses) == 1
    assert type in subclasses
    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 3
    assert D in subclasses
    assert E in subclasses
    assert G in subclasses
    assert C not in subclasses
    subclasses = get_all_subclasses(types.ModuleType)
    assert len(subclasses) == 6

# Generated at 2022-06-11 00:35:16.469048
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(E):
        pass

    def assert_subclasses(result, *expected):
        """Asserts expected and result contain the same classes."""
        assert set(expected) == set(result), 'Expected: %s, got: %s' % (expected, result)

    assert_subclasses(get_all_subclasses(A), B, C, D, E, F)
    assert_subclasses(get_all_subclasses(B), D, E, F)
    assert_subclasses(get_all_subclasses(C))
    assert_subclasses(get_all_subclasses(D))
   

# Generated at 2022-06-11 00:35:24.056238
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-11 00:35:27.897180
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    # We should have class A,B,C,D and E
    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-11 00:35:33.400273
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(C):
        pass

    assert set(get_all_subclasses(A)) == set([G, B, E, F, C, D])
    assert set(get_all_subclasses(B)) == set([E, F, D])
    assert set(get_all_subclasses(C)) == set([G])
    assert set(get_all_subclasses(D)) == set([E, F])
    assert set(get_all_subclasses(E)) == set()
    assert set(get_all_subclasses(F)) == set()
    assert set

# Generated at 2022-06-11 00:35:38.526886
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(B, E):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-11 00:35:44.140720
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D, B):
        pass
    class F(E):
        pass
    all_subclasses = get_all_subclasses(A)
    assert set(all_subclasses) == {B, C, D, E, F}
    assert set(get_all_subclasses(E)) == set()
    assert set(get_all_subclasses(types.ModuleType)) == set()
    assert set(get_all_subclasses(object)) != set()

# Generated at 2022-06-11 00:35:50.342567
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(object) == set([A, B, C, D])
    assert get_all_subclasses(D) == set([])



# Generated at 2022-06-11 00:35:56.754050
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class ObjA:
        pass

    class ObjB(ObjA):
        pass

    class ObjBB(ObjB):
        pass

    class ObjBBB(ObjBB):
        pass

    class ObjC(ObjA):
        pass

    class Test(object):
        pass

    assert get_all_subclasses(ObjA) == set([ObjB, ObjBB, ObjBBB, ObjC])
    assert get_all_subclasses(Test) == set()

# Generated at 2022-06-11 00:36:04.436301
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Test():
        pass
    class Test1(Test):
        pass
    class Test2(Test):
        pass
    class Test11(Test1):
        pass
    class Test12(Test1):
        pass
    subclasses = get_all_subclasses(Test)
    assert Test1 in subclasses
    assert Test2 in subclasses
    assert Test11 in subclasses
    assert Test12 in subclasses

if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(['-vvv', __file__]))

# Generated at 2022-06-11 00:36:11.876509
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Use the methods from unittest to test the get_all_subclasses function
    '''
    import unittest

    class A: pass
    class B(A): pass
    class C(B): pass
    class D(B): pass
    class E(C, D): pass

    class TestGetSubclasses(unittest.TestCase):
        '''
        class to test the get_all_subclasses function
        '''
        def setUp(self):
            '''
            Set up the class with all of the subclasses
            '''
            self.subclasses = {B, C, D, E}

        def test_get_all_subclasses(self):
            '''
            test the get_all_subclasses function
            '''

# Generated at 2022-06-11 00:36:21.956412
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(A):
        pass

    class F(B):
        pass

    class G(object):
        pass

    class H(B, G, object):
        pass

    class I(F, H):
        pass

    assert A in get_all_subclasses(object)
    assert B in get_all_subclasses(object)
    assert C in get_all_subclasses(object)
    assert D in get_all_subclasses(object)
    assert E in get_all_subclasses(object)
    assert F in get_all_subclasses(object)
    assert A in get_all_subclasses(A)
    assert B in get

# Generated at 2022-06-11 00:36:55.111736
# Unit test for function get_all_subclasses

# Generated at 2022-06-11 00:37:04.272362
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(C):
        pass

    # Get all subclasses of A
    subclasses_of_a = get_all_subclasses(A)

    # Assert that all 6 classes are in the list
    assert B in subclasses_of_a
    assert C in subclasses_of_a
    assert D in subclasses_of_a
    assert E in subclasses_of_a
    assert F in subclasses_of_a
    assert A in subclasses_of_a

# Generated at 2022-06-11 00:37:12.241819
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This unit test checks that get_all_subclasses is working as intended.
    Basically, it creates a dummy class hierarchy and it makes sure that all
    subclasses of the dummy root class are correctly found by the get_all_subclasses method.
    '''
    # The following is the class hierarchy we are testing
    #
    #                      Root
    #                 /        \
    #               /            \
    #              /              \
    #            /                  \
    #        Child1                Child2
    #        /   \                /       \
    #     /       \            /           \
    #  C1Child1  C1Child2    C2Child1      C2Child2
    #                            |
    #                          C2Child3
    #
    # It contains 3 generations.  The bottom 2 generations contain a total

# Generated at 2022-06-11 00:37:15.301305
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    assert get_all_subclasses(A) == set((B, C))



# Generated at 2022-06-11 00:37:25.230810
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
        This is a dummy example for unit test, it corresponds to the following tree structure:
        A
        |- AB1
        |  |- AB11
        |  |- AB12
        |- AB2
        |  |- AB21
        |- AB3
        |  |- AB31
        B
        C

        A, AB1, AB2, AB3, B, C are classes.
        Each class correspond to a node.
        List of classes at the same level are in the same list.
        Each list contains the classes of children in the node.

        It is up to the user to organize the list as a tree to check that the function is behaving
        as expected.
    '''
    class A:
        pass
    class B:
        pass
    class C:
        pass

# Generated at 2022-06-11 00:37:35.437528
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(E):
        pass
    class H(object):
        pass
    class I(H):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([C])
    assert get_all_subclasses(D) == set([E, F, G])
    assert get_all_subclasses(H) == set([I])


# Generated at 2022-06-11 00:37:42.529196
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # This test is based on a real use case
    # which was discovered when running tests
    # under Windows due to platform sensitive
    # file path handling
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(A):
        pass

    class G(F):
        pass

    class H(object):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([C, D, E])
    assert get_all_subclasses(H) == set()



# Generated at 2022-06-11 00:37:50.269390
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import namedtuple

    GrandChildClass = namedtuple('GrandChildClass', '')
    ChildClass = namedtuple('ChildClass', '')
    ChildClass.__bases__ += (GrandChildClass,)
    BaseClass = namedtuple('BaseClass', '')
    BaseClass.__bases__ += (ChildClass,)

    classes = get_all_subclasses(BaseClass)
    assert len(classes) == 2
    assert ChildClass in classes
    assert GrandChildClass in classes
    assert BaseClass not in classes

# Generated at 2022-06-11 00:37:57.722494
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # The class Tree is used as an example
    class Tree(object):
        pass
    class FloweringTree(Tree):
        pass
    class NonFloweringTree(Tree):
        pass
    class AppleTree(FloweringTree):
        pass
    class CherryTree(FloweringTree):
        pass
    class ConiferTree(NonFloweringTree):
        pass
    class EtcTree(NonFloweringTree):
        pass
    classes = get_all_subclasses(Tree)
    assert all(c in classes for c in [FloweringTree, NonFloweringTree, AppleTree, CherryTree, ConiferTree, EtcTree])

# Generated at 2022-06-11 00:38:03.467223
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(A):
        pass

    class F(E):
        pass

    class G(B):
        pass

    class H(G):
        pass

    assert set(get_all_subclasses(A)) == set((B, C, D, E, F, G, H))

# Generated at 2022-06-11 00:38:13.214484
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class ClassA(object):
        pass
    class ClassB(ClassA):
        pass
    class ClassC(ClassA):
        pass
    class ClassD(ClassC):
        pass

    # Check single parent
    assert get_all_subclasses(ClassA) == {ClassB, ClassC, ClassD}
    # Check multiple parents
    assert get_all_subclasses(object) == {ClassA, ClassB, ClassC, ClassD}
    # Check error case: no subclasses
    assert get_all_subclasses(ClassD) == set()
    # Check non-class
    assert get_all_subclasses(1) == TypeError

# Generated at 2022-06-11 00:38:19.199118
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This function tests function get_all_subclasses.
    '''
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    res = get_all_subclasses(A)
    assert(res == {B, C, D, E})


# Generated at 2022-06-11 00:38:27.242139
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a tree of classes
    class A(object):
        pass
    class A1(A):
        pass
    class A2(A):
        pass
    class A3(A):
        pass
    class B(object):
        pass
    class B1(B):
        pass
    class B2(B):
        pass
    class B3(B):
        pass
    class B4(B):
        pass

    # Create a dict of all classes
    classes = dict(locals())

    # Do specific and generic tests

# Generated at 2022-06-11 00:38:34.513408
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(D, F):
        pass

    return get_all_subclasses(A) == set([B, C, D, E, F, G])

# Function is_ascii returns True if all characters in the string are ASCII, False if at least one character is not

# Generated at 2022-06-11 00:38:43.151956
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class P1(object):
        pass
    class P2(object):
        pass
    class P3(object):
        pass
    class P4(object):
        pass
    class P1_1(P1):
        pass
    class P1_2(P1):
        pass
    class P1_1_1(P1_1):
        pass
    class P2_1(P2):
        pass
    class P2_1_1(P2_1):
        pass
    class P2_2(P2):
        pass
    class P2_2_1(P2_2):
        pass

# Generated at 2022-06-11 00:38:49.437607
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a class
    class A(object):
        pass
    # Define subclasses for both
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    # Create list of expected subclasses
    expected_subclasses = [B, C, D]
    # Then test function get_all_subclasses
    result = get_all_subclasses(A)
    assert(set(expected_subclasses) == set(result))

# Generated at 2022-06-11 00:38:56.622326
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set([])
    assert set(get_all_subclasses(D)) == set([E])
    assert set(get_all_subclasses(E)) == set([])

# Generated at 2022-06-11 00:39:03.836241
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test for function get_all_subclasses
    """
    import json
    import os
    import sys
    import tempfile
    import yaml

    class ParentTest(object):
        """
        Parent class to test get_all_subclasses
        """
        def __init__(self):
            pass

    class ChildTest1(ParentTest):
        """
        First child class to test get_all_subclasses
        """
        def __init__(self):
            pass

    class ChildTest2(ParentTest):
        """
        Second child class to test get_all_subclasses
        """
        def __init__(self):
            pass

    class GrandChildTest1(ChildTest1):
        """
        Grand child class to test get_all_subclasses
        """

# Generated at 2022-06-11 00:39:10.696426
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class DummyClass:
        pass

    class DummyClass1(DummyClass):
        pass

    class DummyClass2(DummyClass):
        pass

    class DummyClass3(DummyClass1):
        pass

    class DummyClass4(DummyClass2):
        pass

    class DummyClass5(DummyClass3):
        pass

    class DummyClass6(DummyClass3):
        pass

    result = get_all_subclasses(DummyClass)
    assert set(result) == {DummyClass1, DummyClass2, DummyClass3, DummyClass4, DummyClass5, DummyClass6}

# Generated at 2022-06-11 00:39:24.326807
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from base64 import b32encode
    from random import randint, seed
    seed(123)

    # Generate a new class name for testing
    class_name = b32encode(bytes(bytearray([randint(0, 255) for i in range(8)]))).lower().decode('utf-8')

    # If a class with that name already exists, we don't want to clobber it
    if class_name in globals():
        class_name += '_test'

    # Create an empty class
    cls = type(class_name, (object,), {})

    subclasses = set()
    for i in range(0, 5):
        name = class_name + '_' + str(i)
        sub_cls = type(name, (cls,), {})
        subclasses

# Generated at 2022-06-11 00:39:34.445834
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses


# Will be moved and renamed to a more appropriate location
# Make class available in utils namespace
dict_transform_options = None
minimal_dependent_tree_all_exceptions = None



# Generated at 2022-06-11 00:39:42.680479
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This function is only used for testing the get_all_subclasses function
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass
    class G(D):
        pass
    class H(E):
        pass
    class I(F):
        pass
    class J(F):
        pass
    assert get_all_subclasses(A) == {B, C, D, E, F, G, H, I, J}

# Generated at 2022-06-11 00:39:47.602691
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass

    # Check function get_all_subclasses
    assert get_all_subclasses(A) == set([B,C,D,E,F])

# Generated at 2022-06-11 00:39:58.190169
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(E):
        pass

    def _test(result, expected):
        result = set(result)
        assert result == expected, "Got %s instead of %s" % (result, expected)

    _test(get_all_subclasses(A), set([B, C, D, E, F]))
    _test(get_all_subclasses(B), set())
    _test(get_all_subclasses(C), set([D, E, F]))
    _test(get_all_subclasses(D), set())

# Generated at 2022-06-11 00:40:04.665312
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Foo1(object):
        pass
    class Foo2(Foo1):
        pass
    class Foo3(Foo1):
        pass
    class Foo4(Foo2):
        pass
    class Foo5(Foo4):
        pass
    class Foo6(Foo4):
        pass
    assert(set(get_all_subclasses(Foo1)) == set([Foo2, Foo3, Foo4, Foo5, Foo6]))
    assert(set(get_all_subclasses(Foo2)) == set([Foo4, Foo5, Foo6]))

# Generated at 2022-06-11 00:40:11.233494
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(C): pass

    all_subclasses = get_all_subclasses(A)
    assert all_subclasses.intersection([B, C, D, E, F, G]) == set([B, C, D, E, F, G])



# Generated at 2022-06-11 00:40:16.151475
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(C):
        pass

    class F(C):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-11 00:40:24.658042
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set()
    assert set(get_all_subclasses(D)) == set([E])
    assert set(get_all_subclasses(E)) == set()
    assert set(get_all_subclasses(object)) == set()

# Generated at 2022-06-11 00:40:31.726885
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(D, C):
        pass

    class G:
        pass

    class H(G):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(G) == set([H])



# Generated at 2022-06-11 00:40:38.625330
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test of get_all_subclasses method
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    assert sorted([a.__name__ for a in get_all_subclasses(A)]) == ['B', 'C', 'D', 'E', 'F']
    assert sorted([a.__name__ for a in get_all_subclasses(B)]) == ['D']
    assert sorted([a.__name__ for a in get_all_subclasses(C)]) == ['E', 'F']

# Generated at 2022-06-11 00:40:55.579219
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import deque
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(D):
        pass
    res = get_all_subclasses(A)
    # all classes are subclass of A
    assert(A in res)
    assert(B in res)
    assert(C in res)
    assert(D in res)
    assert(E in res)
    assert(F in res)
    # B,C,D,E,F are the subclass of A
    assert(len(res)==6)
    # Test with different class
    class G(object):
        pass
    class H(G):
        pass
    res = get_all_subclasses

# Generated at 2022-06-11 00:41:05.387938
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys
    import types
    import unittest

    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(object):
        pass

    class TestGetAllSubclasses(unittest.TestCase):

        def test_get_all_subclasses_no_classes(self):
            self.assertIn(A, get_all_subclasses(A))

        def test_get_all_subclasses_with_classes(self):
            classes = get_all_subclasses(A)
            self.assertIn(A, classes)
            self.assertIn(B, classes)
            self.assertIn(C, classes)
            self.assertIn(D, classes)

# Generated at 2022-06-11 00:41:10.926069
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Aaa:
        pass

    class Bbb(Aaa):
        pass

    class Ccc(Aaa):
        pass

    class Ddd(Bbb):
        pass

    class Eee(Ccc):
        pass

    class Fff(Eee):
        pass

    Aaa_subclasses = get_all_subclasses(Aaa)
    assert Bbb in Aaa_subclasses
    assert Ccc in Aaa_subclasses
    assert Ddd in Aaa_subclasses
    assert Eee in Aaa_subclasses
    assert Fff in Aaa_subclasses

    assert len(Aaa_subclasses) == 5

# Generated at 2022-06-11 00:41:14.685943
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}

# Generated at 2022-06-11 00:41:21.815262
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class A1(A): pass
    class A2(A): pass
    class A11(A1): pass
    class A12(A1): pass
    class A111(A11): pass
    class A112(A11): pass
    class A113(A11): pass
    assert {A1, A11, A111, A112, A113, A12, A2} == get_all_subclasses(A)

# Generated at 2022-06-11 00:41:33.512577
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: """parent class"""
    class B(A): """direct child of A"""
    class C(A): """direct child of A"""
    class D(B): """direct child of B"""
    class E(B): """direct child of B"""
    class F(C): """direct child of C"""
    class G: """another parent class"""
    class H(G): """direct child of G"""
    class I(H): """direct child of H"""

    assert get_all_subclasses(A) == set([B,C,D,E,F])
    assert get_all_subclasses(B) == set([D,E])
    assert get_all_subclasses(C) == set([F])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set

# Generated at 2022-06-11 00:41:42.536295
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define various classes and check if we can retrieve them
    class TopClass(object):
        pass
    class ChildClass1(TopClass):
        pass
    class ChildClass2(TopClass):
        pass
    class GrandChildClass1(ChildClass1):
        pass
    class GrandChildClass2(ChildClass2):
        pass
    class GrandChildClass3(ChildClass2):
        pass
    class GrandGrandChildClass1(GrandChildClass2):
        pass
    class GrandGrandChildClass2(GrandChildClass3):
        pass
    assert TopClass in get_all_subclasses(TopClass)
    assert ChildClass1 in get_all_subclasses(TopClass)
    assert ChildClass2 in get_all_subclasses(TopClass)
    assert GrandChildClass1 in get_all_subclasses(TopClass)
   

# Generated at 2022-06-11 00:41:50.671352
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys, types

    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(D):
        pass
    class H(D):
        pass
    class I(E):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(J):
        pass
    # The list of all classes
    classes = [A, B, C, D, E, F, G, H, I, J, K, L]
    # Mark all classes as non visited
    visited = [False] * len(classes)

# Generated at 2022-06-11 00:41:58.403031
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(object):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(E):
        pass
    assert get_all_subclasses(A) == set([B])
    assert get_all_subclasses(D) == set([E, F, G])
    assert get_all_subclasses(E) == set([F, G])
    assert get_all_subclasses(B) == set([])



# Generated at 2022-06-11 00:42:06.896152
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This function check that get_all_subclasses returns the right result
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(object):
        pass

    class G(F):
        pass

    class H(object):
        pass

    class I(H):
        pass

    result = list(get_all_subclasses(A))
    assert len(result) == 4
    assert B in result
    assert C in result
    assert D in result
    assert E in result

    result = list(get_all_subclasses(F))
    assert len(result) == 1
    assert G in result


# Generated at 2022-06-11 00:42:32.971598
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(B, D):
        pass

    class G(B, D):
        pass

    # Should find all subclass of class A: B, C, D, E, F, G
    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert G in get_all_subclasses(A)
    # Should not find