

# Generated at 2022-06-11 00:32:45.784943
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(D):
        pass

    # DSE

    assert set(get_all_subclasses(C)) == set([D, E, F, G])
    assert set(get_all_subclasses(D)) == set([E, F, G])
    assert set(get_all_subclasses(E)) == set()
    assert set(get_all_subclasses(F)) == set()
    assert set(get_all_subclasses(G)) == set()

# Generated at 2022-06-11 00:32:53.816527
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.action.copy import ActionModule as CopyActionModule
    from ansible.plugins.action.file import ActionModule as FileActionModule
    assert 'ansible.plugins.action.copy.ActionModule' in get_all_subclasses(ActionModule)
    assert 'ansible.plugins.action.file.ActionModule' in get_all_subclasses(ActionModule)
    assert CopyActionModule in get_all_subclasses(ActionModule)
    assert FileActionModule in get_all_subclasses(ActionModule)
    assert len(get_all_subclasses(ActionModule)) == 2

# Generated at 2022-06-11 00:33:04.324749
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import json
    import os

    # Mocking class to have an easy recursive mock structure
    class ParentClass(object):
        def __init__(self, name, parent=None):
            self.name = name
            self.parent = parent
            self.children = []
            if parent is not None:
                parent.children.append(self)

    def load_classes(classes_data):
        def load_class(name, parent=None):
            children = classes_data.get(name, [])
            cls = ParentClass(name, parent=parent)
            for c in children:
                load_class(c, parent=cls)

        for c in classes_data:
            load_class(c)

    # populate classes structure with children

# Generated at 2022-06-11 00:33:09.502200
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])

# Generated at 2022-06-11 00:33:22.292262
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    The following is a simple example to test the function.
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(B):
        pass

    class G(C):
        pass

    class H(A):
        pass

    class I(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I])
    assert get_all_subclasses(B) == set([D, F, I])
    assert get_all_subclasses(C) == set([E, G])
    assert get_all_subclasses(D) == set([I])

# Generated at 2022-06-11 00:33:27.428103
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.plugins.action.copy import ActionModule as Copy
    from ansible.plugins.action.move import ActionModule as Move
    from ansible.plugins.action.template import ActionModule as Template
    from ansible.plugins.action.file import ActionModule as FileModule

    assert set(get_all_subclasses(Copy)) == {Move, Template, FileModule}



# Generated at 2022-06-11 00:33:35.336377
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a simple class hierarchy
    class A(object): pass
    class B(A): pass
    class C(object): pass
    class D(B): pass
    class E(C): pass
    class F(C): pass
    class G(D): pass
    class H(E): pass
    class I(H): pass

    assert get_all_subclasses(A) == set([B, D, G])
    assert get_all_subclasses(C) == set([E, F])
    assert get_all_subclasses(H) == set([I])
    assert get_all_subclasses(E) == set([H, I])



# Generated at 2022-06-11 00:33:44.155188
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a():
        pass
    class b(a):
        pass
    class c(b):
        pass
    class d(c):
        pass
    class e(d):
        pass
    class f(a):
        pass
    class g(f):
        pass
    class h(g):
        pass
    class i(h):
        pass
    assert(set(get_all_subclasses(a)) == set([b, c, d, e, f, g, h, i]))
    assert(set(get_all_subclasses(b)) == set([c, d, e]))



# Generated at 2022-06-11 00:33:52.110355
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Unit test for get_all_subclasses()
    """
    import operator

    class A(object):
        pass

    class Aa(A):
        pass

    class Ab(A):
        pass

    class Aaa(Aa):
        pass

    class Aba(Ab):
        pass

    subclasses_expected = {Aa, Ab, Aaa, Aba}
    subclasses_actual = get_all_subclasses(A)

    assert set(subclasses_actual) == subclasses_expected
    assert operator.contains(subclasses_actual, A) is False


# Generated at 2022-06-11 00:34:02.676886
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create an empty class to work with
    class A:
        pass

    # Create basic subclasses
    class B(A):
        pass

    class C(A):
        pass

    # Create a subclass which has subclasses
    class D(A):
        pass

    class E(D):
        pass

    # Create a subclass which has multiple subclasses
    class F(A):
        pass

    class G(F):
        pass

    class H(F):
        pass

    # Create a subclass which has a subclass with multiple subclasses
    class I(A):
        pass

    class J(I):
        pass

    class K(J):
        pass

    class L(J):
        pass

    # Create a subclass that does not inherit from A
    class M():
        pass

    # Create a subclass that has a subclass

# Generated at 2022-06-11 00:34:11.031559
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class A1(A): pass
    class A2(A): pass
    class A1a(A1): pass

    assert get_all_subclasses(A) == set([A1, A2, A1a])
    assert get_all_subclasses(B) == set()

# Generated at 2022-06-11 00:34:23.119976
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # A tree of classes to test recursion
    # class A()
    # |---- class B()
    # |     |---- class D()
    # |     |---- class E()
    # |           |---- class F()
    # |---- class C()
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(E):
        pass
    # Test get_all_subclasses
    A_subclasses = get_all_subclasses(A)
    for subclass in A_subclasses:
        assert issubclass(subclass, A)
    # There should be 6 subclasses of A
    num_A_subclasses = len(A_subclasses)
    assert num

# Generated at 2022-06-11 00:34:30.385527
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses.
    It simply tests that get_all_subclasses returns the
    good number of items and does not fail.
    '''

    # A really basic class which has a simple __init__ method
    class A:
        def __init__(self, item):
            self.item = item

    # Inheriting A
    class B(A):
        pass

    # Inheriting B
    class C(B):
        pass

    # Inheriting A, and also B
    class D(A, B):
        pass

    # Inheriting C, and also D
    class E(C, D):
        pass

    # Inheriting C only
    class F(C):
        pass

    # Inheriting A only
    class G(A):
        pass

    # Instanciating

# Generated at 2022-06-11 00:34:36.354992
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    classes = get_all_subclasses(A)
    assert(len(classes) == 4)
    assert({B, C, D, E} == classes)

# Generated at 2022-06-11 00:34:43.456980
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses.
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(object):
        pass

    class D(C):
        pass

    class E(B):
        pass

    class F(C):
        pass

    assert get_all_subclasses(object) == set([A, C])
    assert get_all_subclasses(A) == set([B, E])
    assert get_all_subclasses(C) == set([D, F])

# Generated at 2022-06-11 00:34:49.385500
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a three level hierarchy
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass

    # Check that all subclasses are retrieved
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-11 00:34:55.429790
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert get_all_subclasses(B) == set([B])
    assert get_all_subclasses(A) == set([B, C])
    assert get_all_subclasses(object) == set([A, B, C, D])

# Generated at 2022-06-11 00:35:06.374922
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass
    class G(F):
        pass

    assert get_all_subclasses(A) == set([B,C,D,E,F,G])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E,F,G])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([G])
    assert get_all_subclasses(G) == set([])

# Generated at 2022-06-11 00:35:14.444407
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(A): pass
    class F(D): pass
    class G(F): pass

    def classes_set(cls):
        return set(get_all_subclasses(cls))

    expected = { B, C, D, E, F, G }
    assert classes_set(A) == expected
    assert classes_set(B) == { D, F, G }
    assert classes_set(C) == set()
    assert classes_set(D) == { F, G }
    assert classes_set(E) == set()

# Generated at 2022-06-11 00:35:25.392351
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import _utils

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass


    class GetAllSubclassesTestCase(unittest.TestCase):
        def setUp(self):
            self.get_all_subclasses = _utils.get_all_subclasses

        def test_type(self):
            self.assertEqual(type(self.get_all_subclasses(A)), set)

        def test_none(self):
            self.assertEqual(self.get_all_subclasses(None), set())


# Generated at 2022-06-11 00:35:40.910341
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B, C):
        pass
    class F(D, E):
        pass
    class G:
        pass
    class H(G):
        pass
    class I(G):
        pass
    # Test 1
    subclasses = set(get_all_subclasses(A))
    assert subclasses == set([E, F, B, C, D])
    # Test 2
    subclasses = set(get_all_subclasses(G))
    assert subclasses == set([H, I])

# Generated at 2022-06-11 00:35:52.574688
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A1(object):
        pass

    class A2(object):
        pass

    class B1(A1):
        pass

    class B2(A1):
        pass

    class B3(A2):
        pass

    class C(B1):
        pass

    class D(object):
        pass

    class E(object):
        pass

    class F(E):
        pass

    class G(F):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(I):
        pass

    assert get_all_subclasses(object) == set([A1, A2, B1, B2, B3, C, D, E, F, G, H, I, J])
    assert get_all_subclasses(A1) == set

# Generated at 2022-06-11 00:36:03.296428
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B: pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C, D):
        pass
    class F(C, B):
        pass
    class G(F):
        pass
    class H:
        pass

    class Ansible(object):
        pass
    assert get_all_subclasses(A) == {C, E, F, G}
    assert get_all_subclasses(B) == {D, F, G}
    assert get_all_subclasses(C) == {E, F, G}
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == {G}
    assert get_all

# Generated at 2022-06-11 00:36:09.551477
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set([E, F])

# Generated at 2022-06-11 00:36:19.486042
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function get_all_subclasses
    '''
    class_a = type('class_a', (), {})
    class_b = type('class_b', (class_a,), {})
    class_c = type('class_c', (class_a,), {})
    class_d = type('class_d', (class_b,), {})
    all_subclasses = set((class_b, class_c, class_d,))
    assert all_subclasses == get_all_subclasses(class_a)
    assert set((class_d,)) == get_all_subclasses(class_b)
    assert set() == get_all_subclasses(class_c)
    assert set() == get_all_subclasses(class_d)



# Generated at 2022-06-11 00:36:53.987407
# Unit test for function get_all_subclasses

# Generated at 2022-06-11 00:37:01.876235
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    import os
    import sys
    from ansible.utils.display import Display
    from ansible.plugins.loader import module_utils_loader

    display = Display()
    module_utils_paths = module_utils_loader._get_paths()

    for path in module_utils_paths:
        sys.path.append(path)

# Generated at 2022-06-11 00:37:06.503812
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass

    assert get_all_subclasses(A) == {B, C, D}
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == {D}

# Generated at 2022-06-11 00:37:10.869291
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    result = get_all_subclasses(A)
    assert B in result, "Result doens't contain B class"
    assert C in result, "Result doens't contain C class"
    assert D in result, "Result doens't contain D class"

# Generated at 2022-06-11 00:37:22.605161
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    # Searching subclasses of object
    assert get_all_subclasses(object).difference({object,
                                                  A, B, C, D, E, F}) == set()

    # Searching subclasses of class A
    assert get_all_subclasses(A).difference({B, C, D, E, F}) == set()

    # Searching subclasses of class B
    assert get_all_subclasses(B).difference({C, D, E, F}) == set()

if __name__ == '__main__':
    test_get_all_sub

# Generated at 2022-06-11 00:37:41.712824
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # pylint: disable=R0903
    #         Too few public methods (1/2) (too-few-public-methods)

    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(A):
        pass
    class G(F):
        pass
    class H(F):
        pass
    class I(H):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G, H, I}
    assert get_all_subclasses(B) == {D, E}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D)

# Generated at 2022-06-11 00:37:50.363141
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # The following classes represent a tree :
    #
    #   A
    #  /\
    # B  C
    #  \/\
    #  E  F
    #
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class E(B):
        pass

    class F(C):
        pass

    # Function to test
    results = get_all_subclasses(A)
    assert B in results
    assert C in results
    assert E in results
    assert F in results

# Generated at 2022-06-11 00:37:55.515807
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(A) != {B, C, E}

# Generated at 2022-06-11 00:38:00.855852
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    assert get_all_subclasses(object) == set([
        A, B, C, D, E, F
    ])
    assert get_all_subclasses(C) == set([
        E
    ])


# Generated at 2022-06-11 00:38:08.810314
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    all_subclasses = get_all_subclasses(object)
    # Classes dict
    classes = {
        'A': object,
        'B': object,
        'C': A,
        'D': B,
        'E': B,
        'F': C,
        'G': F,
        'H': F,
        'I': E,
        'K': object,
        'L': object,
        'M': L,
        'N': M,
        'O': M,
        'P': O,
        'Q': P,
        'R': P,
    }
    # Build the tree
    for key, parent in classes.items():
        classes[key] = type(key, (parent,), {})
    # All tested classes
    all_classes = set(classes.values())

# Generated at 2022-06-11 00:38:18.951036
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a(object): pass
    class b(a): pass
    class c(a): pass
    class d(b): pass
    class e(d): pass
    class f(c): pass
    class g(e): pass
    class h(f): pass
    class i(d): pass
    class j(e): pass
    class k(f): pass

    assert set(get_all_subclasses(a)) == set([b, c, d, e, f, g, h, i, j, k])
    assert set(get_all_subclasses(b)) == set([d, e, g])
    assert set(get_all_subclasses(c)) == set([f, h, k])
    assert set(get_all_subclasses(d)) == set([e, i])

# Generated at 2022-06-11 00:38:27.061648
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses

    In the test we defined a super class `Cls` and three subclasses
    `SubCls`, `SSCls1`, `SSCls2`.  SSCls2 is subclass of SSCls1, which
    is subclass of SubCls, which is subclass of Cls.

    We then use the :py:meth:`get_all_subclasses` to find all subclasses
    of Cls and compare the result with the expected result.

    '''
    class Cls(object):
        pass

    class SubCls(Cls):
        pass

    class SSCls1(SubCls):
        pass

    class SSCls2(SSCls1):
        pass

    cls_subclasses = get_all_subclasses(Cls)


# Generated at 2022-06-11 00:38:37.140079
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    def compare_classes_list(cls, list_of_class):
        set_classes = get_all_subclasses(cls)
        if len(set_classes) != len(list_of_class):
            return False
        for c in list_of_class:
            if c not in set_classes:
                return False
        return True

    assert compare_classes_list(A, [B, C])
    assert compare_classes_list(B, [])
    assert compare_classes_list(C, [])

# Generated at 2022-06-11 00:38:44.248929
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H, I, J])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set([F, G, H, I, J])

# Generated at 2022-06-11 00:38:49.431929
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(object):
        pass

    class E(D):
        pass

    classes = [A, B, C, D, E]
    subcls = get_all_subclasses(object)
    assert all(klass in subcls for klass in classes)


# Generated at 2022-06-11 00:39:24.264922
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define class hierarchy
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass
    class F(D): pass
    class G(C): pass

    # Search all subclasses
    assert set([B, D, E, F]) == get_all_subclasses(A)
    assert set([D, E, F]) == get_all_subclasses(B)
    assert set([G]) == get_all_subclasses(C)
    assert set([E, F]) == get_all_subclasses(D)
    assert set([G]) == get_all_subclasses(E)
    assert set([G]) == get_all_subclasses(F)
    assert set([G]) == get_all_subclasses(G)

# Generated at 2022-06-11 00:39:30.670920
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(A):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-11 00:39:38.825871
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Defining a tree of classes
    # Test a single class
    class Test_Class_1:
        pass

    assert list(get_all_subclasses(Test_Class_1)) == []

    # Test a class with subclasses
    class Test_Class_2:
        pass

    class Test_Class_2a(Test_Class_2):
        pass

    class Test_Class_2b(Test_Class_2):
        pass

    assert set(get_all_subclasses(Test_Class_2)) == set([Test_Class_2a, Test_Class_2b])

    # Test a class with grand subclasses
    class Test_Class_3:
        pass

    class Test_Class_3a(Test_Class_3):
        pass


# Generated at 2022-06-11 00:39:45.638497
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # [1] Create 3 class levels
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(D):
        pass

    # [2] Check if all classes are found
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-11 00:39:49.463745
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])

# Generated at 2022-06-11 00:39:56.160003
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)


# Generated at 2022-06-11 00:40:04.931242
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Definition of class hierarchy to test
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C, D): pass

    # get_all_subclasses returns set of class in args, but also all subclasses
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, E, F])
    assert set(get_all_subclasses(C)) == set([F])
    assert set(get_all_subclasses(D)) == set([F])
    assert set(get_all_subclasses(E)) == set([])
    assert set(get_all_subclasses(F))

# Generated at 2022-06-11 00:40:10.559512
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test for function get_all_subclasses

    This is a fairly simple test.  I'm only testing the case where there's a single subclass.
    However, it's pretty easy to add more cases where there are multiple layers of subclasses.
    '''
    class A(object):
        pass
    class B(A):
        pass

    assert get_all_subclasses(A) == set([B])

# Generated at 2022-06-11 00:40:16.632057
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    assert set(get_all_subclasses(A)) == {B, C, D, E, F}
    assert set(get_all_subclasses(B)) == {D, E}
    assert set(get_all_subclasses(C)) == {F}

# Generated at 2022-06-11 00:40:26.837032
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from unittest import TestCase, main
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(D, F):
        pass

    class Tests(TestCase):
        def test_get_all_subclasses(self):
            ret = get_all_subclasses(A)
            self.assertEqual(len(ret), 6)
            self.assertIn(B, ret)
            self.assertIn(C, ret)
            self.assertIn(D, ret)
            self.assertIn(E, ret)
            self.assertIn(F, ret)
            self.assertIn(G, ret)

   

# Generated at 2022-06-11 00:41:19.044568
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class C(object):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(E):
        pass

    class I(F):
        pass

    assert set([A, D, G]) == get_all_subclasses(A)
    assert set([B, E, H]) == get_all_subclasses(B)
    assert set([C, F, I]) == get_all_subclasses(C)

# Generated at 2022-06-11 00:41:31.639428
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class BaseClass(object):
        pass

    class ClassA(BaseClass):
        pass

    class ClassB(BaseClass):
        pass

    class ClassC(BaseClass):
        pass

    class ClassD(ClassA):
        pass

    class ClassE(ClassA):
        pass

    class ClassF(ClassA):
        pass

    class ClassG(ClassD):
        pass

    class ClassH(ClassF):
        pass

    class ClassI(object):
        pass

    assert get_all_subclasses(BaseClass) == { ClassA, ClassB, ClassC, ClassD, ClassE, ClassF, ClassG, ClassH }
    assert get_all_subclasses(ClassA) == { ClassD, ClassE, ClassF, ClassG, ClassH }

# Generated at 2022-06-11 00:41:40.643762
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    # Now we have :
    # A -> B, C -> D
    # Expected result is B, D, C
    assert set(get_all_subclasses(A)) == set([B, D, C])
    # Check if __subclasses__ is still working
    assert set(A.__subclasses__()) == set([B, C])
    # Check if this is not broken for builtin type
    assert set(get_all_subclasses(object)) == set([type, object])
    # Check if this is not broken for old-style class
    class Foobar:
        pass
    class Barfoo(Foobar):
        pass

# Generated at 2022-06-11 00:41:47.795136
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test class
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(A):
        pass
    class F:
        pass
    #
    # Test
    assert {A, B, C, D, E} == get_all_subclasses(A)
    assert {A, B, C, D, E} == get_all_subclasses(B)
    assert {A, B, C, D, E} == get_all_subclasses(C)
    assert {A, B, C, D, E} == get_all_subclasses(D)
    assert {A, B, C, D, E} == get_all_subclasses(E)
    assert {F} == get_all_sub

# Generated at 2022-06-11 00:41:57.857384
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class NoSubclass(object):
        pass

    class Child(NoSubclass):
        pass

    class GrandChild(Child):
        pass

    class GrandChild2(Child):
        pass

    class GreatGrandChild(GrandChild):
        pass

    class GreatGrandChild2(GrandChild):
        pass

    class GreatGrandChild3(GrandChild2):
        pass

    class GreatGreatGrandChild(GreatGrandChild):
        pass

    class GreatGreatGrandChild2(GreatGrandChild):
        pass

    class GreatGreatGrandChild3(GreatGrandChild2):
        pass

    assert get_all_subclasses(NoSubclass) == set([Child, GrandChild, GrandChild2, GreatGrandChild, GreatGrandChild2, GreatGrandChild3, GreatGreatGrandChild, GreatGreatGrandChild2, GreatGreatGrandChild3])

# Generated at 2022-06-11 00:42:02.700062
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])



# Generated at 2022-06-11 00:42:05.752960
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass

    result = get_all_subclasses(A)
    assert B in result
    assert C in result
    assert D in result



# Generated at 2022-06-11 00:42:13.280607
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit tests for function get_all_subclasses

    To test this we will use a simple class hierarchy.  The classes, A, B, and C are all
    related.  A is a parent class which has two children, B and C.  B is a parent which has
    a single child, C.  The get_all_subclasses function should return a set containing the
    classes, B and C.
    '''

    import types
    import unittest

    # Create class hierarchy
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    # Create an instance
    a = A()

    # Create an instance method
    def get_subclasses(self):
        return get_all_subclasses(self.__class__)

    # Bind instance method to

# Generated at 2022-06-11 00:42:21.267232
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit tests for function `get_all_subclasses`

    The tests for `get_all_subclasses` test that the function can successfully do the following:

    - [x] Correctly find classes which are subclasses of a class, where no further subclassing
      occurs.  This is the case for the class `class_testing_1`.
    - [x] Correctly find classes which are subclasses of a class, where further subclassing occurs
      and the subclasses are far removed.  This is the case for the class `class_testing_2`.
    '''
    # class_testing_1 is subclass of class_testing
    # class_testing_2 is subclass of class_testing
    # class_testing_3 is subclass of class_testing_2
    # class_testing_4 is subclass of class_testing_2

# Generated at 2022-06-11 00:42:27.902932
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Dummy classes
    class Foo(object):
        pass
    class Bar(object):
        pass
    class Foobar(Foo):
        pass
    class Barfoo(Bar):
        pass
    class FooBarFoo(Foo):
        pass
    class FooBarBar(Bar):
        pass
    # Test
    # We don't start on object class
    assert(not get_all_subclasses(object))
    assert(get_all_subclasses(Foo) == set([Foobar, FooBarFoo]))
    assert(get_all_subclasses(Bar) == set([FooBarBar, Barfoo]))