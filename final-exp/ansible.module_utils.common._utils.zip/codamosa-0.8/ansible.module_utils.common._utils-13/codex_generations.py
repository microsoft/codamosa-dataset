

# Generated at 2022-06-11 00:32:42.125322
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base: pass
    class Intermediate(Base): pass
    class Intermediate2(Base): pass
    class Child1(Intermediate): pass
    class Child2(Intermediate): pass
    class Child3(Intermediate2): pass
    class Child4(Intermediate2): pass
    class GrandChild1(Child1): pass
    assert get_all_subclasses(Base) == set([Intermediate, Intermediate2, Child1, Child2, Child3, Child4, GrandChild1])

# Generated at 2022-06-11 00:32:52.981068
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B: pass
    class C(B): pass
    class D(C): pass
    class E(C): pass
    class F(D): pass
    class G(D, E): pass
    class H(F, G): pass

    assert get_all_subclasses(A) == set()
    assert get_all_subclasses(B) == set([C, D, E])
    assert get_all_subclasses(C) == set([D, E])
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()
    assert get_all_subclasses(G) == set([H])
    assert get_all_subclasses(H) == set()
   

# Generated at 2022-06-11 00:33:00.973965
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class C(B):
        pass

    class D(B):
        pass

    classes = [A, B, C, D]
    subclasses = get_all_subclasses(object)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert len(set(classes).difference(subclasses)) == 0

# Generated at 2022-06-11 00:33:11.998062
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    class F(D):
        pass
    assert get_all_subclasses(A) == set([C, B, D, E, F])
    assert get_all_subclasses(B) == set([D, E, F])
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set([E, F])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-11 00:33:16.379738
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # We use properties of str and bytes to test this function
    assert get_all_subclasses(str) == {str, basestring}
    assert get_all_subclasses(bytes) == {bytes, bytearray, str}



# Generated at 2022-06-11 00:33:24.842145
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class AA(A): pass
    class AAA(AA): pass
    class AAAA(AA): pass
    class AB(A): pass
    class B(object): pass
    class BA(B): pass
    class BB(B): pass

    assert get_all_subclasses(A) == {AA, AAA, AAAA, AB}
    assert get_all_subclasses(object) == {A, AA, AAA, AAAA, AB, B, BA, BB}
    assert get_all_subclasses(B) == {BA, BB}

# Generated at 2022-06-11 00:33:32.974897
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F():
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(B)) == set([D])
    assert set(get_all_subclasses(C)) == set([E])
    assert set(get_all_subclasses(D)) == set([])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-11 00:33:40.533656
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Parent1:
        pass

    class Parent2:
        pass

    class Child(Parent1):
        pass

    class Grandchild(Child):
        pass

    class Greatgrandchild(Grandchild):
        pass

    assert set(get_all_subclasses(Parent1)) == set([Child, Grandchild, Greatgrandchild])
    assert set(get_all_subclasses(Parent2)) == set()
    assert set(get_all_subclasses(Child)) == set([Grandchild, Greatgrandchild])
    assert set(get_all_subclasses(Grandchild)) == set([Greatgrandchild])
    assert set(get_all_subclasses(Greatgrandchild)) == set()

# Generated at 2022-06-11 00:33:44.154519
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        """Base class"""
        pass

    class B(A):
        """A child of class A"""
        pass

    class C(A):
        """A child of class A"""
        pass


# Generated at 2022-06-11 00:33:54.132997
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class C1(object):
        pass
    class C2(C1):
        pass
    class C3(C1):
        pass
    class C4(C2, C3):
        pass
    class C5(object):
        pass

    class TestGetAllSubclasses(unittest.TestCase):
        def test_get_all_subclasses(self):
            self.assertEqual(get_all_subclasses(C1), set((C2, C3, C4)))

        def test_get_all_subclasses_and_self(self):
            self.assertEqual(get_all_subclasses(C1), set((C1, C2, C3, C4)))

    unittest.main()

# Generated at 2022-06-11 00:34:06.086771
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C1(object): pass
    class C2(object): pass
    class C3(object): pass
    class C4(C2, C1): pass
    class C5(C2): pass
    class C6(C5): pass
    class C7(C5): pass
    class C8(C6): pass
    class C9(C5): pass
    class C10(C9): pass

    assert set([C1, C2, C3, C4, C5, C6, C7, C8, C9, C10]) == get_all_subclasses(object)
    assert set([C4, C5, C6, C7, C8, C9, C10]) == get_all_subclasses(C2)

# Legacy names for backwards compatibility
AllSubclasses = get_all_sub

# Generated at 2022-06-11 00:34:17.528103
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(E):
        pass

    class I(A):
        pass

    class J(I):
        pass

    assert set([B, C, D, E, F, G, H, J]) == get_all_subclasses(A)
    assert set([C, D, E, F, G, H]) == get_all_subclasses(B)
    assert set([D, E, F, G, H]) == get_all_subclasses(C)

# Generated at 2022-06-11 00:34:22.102910
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    assert get_all_subclasses(A) == set([B, C])
    assert get_all_subclasses(B) == set([C])

# Generated at 2022-06-11 00:34:25.612351
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    assert get_all_subclasses(A) == set([B, C, D])



# Generated at 2022-06-11 00:34:36.423020
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(B):
        pass
    class G(B):
        pass
    class H(F):
        pass
    class I(D):
        pass
    class J(I):
        pass
    # the class to retrieve all of its subclasses
    cls = A
    # the expected output a list of subclasses
    expected = [C, D, I, J]
    # now we can test the function
    assert get_all_subclasses(A) == set(expected)


# Generated at 2022-06-11 00:34:38.115492
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    assert get_all_subclasses(A) == set([B, C, D])

# Generated at 2022-06-11 00:34:47.269300
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    class G(E): pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([D, F])
    assert get_all_subclasses(C) == set([E, G])
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set([G])
    assert get_all_subclasses(F) == set()
    assert get_all_subclasses(G) == set()



# Generated at 2022-06-11 00:34:57.052188
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert get_all_subclasses(A) == set([B, C, D])

    class A(object):
        pass

    assert get_all_subclasses(A) == set()

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    assert get_all_subclasses(A) == set([B, C])

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    assert get_

# Generated at 2022-06-11 00:35:06.327319
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Vehicule(object):
        pass

    class Car(Vehicule):
        pass

    class SportCar(Car):
        pass

    class Truck(Vehicule):
        pass

    class SportTruck(Truck):
        pass

    assert Vehicule not in get_all_subclasses(Truck)
    assert Truck in get_all_subclasses(Vehicule)
    assert Car in get_all_subclasses(Vehicule)
    assert SportCar in get_all_subclasses(Vehicule)
    assert SportTruck not in get_all_subclasses(Car)
    assert len(get_all_subclasses(Vehicule)) == 3

# Generated at 2022-06-11 00:35:15.443114
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):pass
    class B(object):pass
    class C(B):pass
    class D(A, B):pass
    class E(F):pass
    class F(D, C):pass
    class G(F):pass

    # Testing direct subclasses cases
    assert set([F, A, B, C, D]) == get_all_subclasses(object)
    assert set([E, F, A, B, C, D, G]) == get_all_subclasses(F)
    assert set([]) == get_all_subclasses(G)

    # Testing different level of subclasses cases
    assert set([E, F, G, A, B, C, D]) == get_all_subclasses(E)
    assert set([E, F, G, A, B, C, D]) == get_all

# Generated at 2022-06-11 00:35:29.229092
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test for function :py:func:`get_all_subclasses`.
    '''
    class A(object):  # pylint: disable=unused-variable
        """
        Base class
        """
        pass

    class B(A):  # pylint: disable=unused-variable
        """
        Sub class of A
        """
        pass

    class C(A):  # pylint: disable=unused-variable
        """
        Sub class of A
        """
        pass

    class D(B, C):  # pylint: disable=unused-variable
        """
        Sub class of B, C and A
        """
        pass


# Generated at 2022-06-11 00:35:36.923333
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class FirstClass(object):
        pass
    class SecondClass(object):
        pass
    class ThirdClass(SecondClass):
        pass
    class FourthClass(FirstClass):
        pass
    class FifthClass(ThirdClass):
        pass

    subclasses = get_all_subclasses(SecondClass)
    assert ThirdClass in subclasses
    assert FifthClass in subclasses
    assert SecondClass not in subclasses

    subclasses = get_all_subclasses(FirstClass)
    assert FourthClass in subclasses
    assert ThirdClass not in subclasses
    assert FifthClass not in subclasses


# Generated at 2022-06-11 00:35:44.650845
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(E):
        pass

    class G(C):
        pass

    class H(C):
        pass

    class I(E):
        pass

    class J(E):
        pass

    class K(J):
        pass

    class L(E):
        pass

    class M(L):
        pass

    class N(L):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D, E, F, G, H, I, J, K, L, M, N}

# Generated at 2022-06-11 00:35:55.815054
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(D): pass
    class F(E): pass
    assert set(get_all_subclasses(A)) == set((B, C, D, E, F))
    assert set(get_all_subclasses(B)) == set((C,))
    assert set(get_all_subclasses(C)) == set(())
    assert set(get_all_subclasses(D)) == set((E, F))
    assert set(get_all_subclasses(E)) == set((F,))
    assert set(get_all_subclasses(F)) == set(())
    assert set(get_all_subclasses(object)) != set()

# Generated at 2022-06-11 00:36:05.829027
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(G):
        pass

    assert set((D, E)) == get_all_subclasses(B)
    assert set((D, E)) <= get_all_subclasses(A)
    assert set((D, E)) <= get_all_subclasses(object)
    assert set((H,)) <= get_all_subclasses(C)

# Generated at 2022-06-11 00:36:14.696550
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C1: pass
    class C2(C1): pass
    class C3(C1): pass
    class C4(C2): pass
    class C5(C2): pass
    class D6: pass
    assertequal(get_all_subclasses(C1), set([C2, C3, C4, C5]))
    assertequal(get_all_subclasses(C2), set([C4, C5]))
    assertequal(get_all_subclasses(object), set([C1, C2, C3, C4, C5, D6]))

# Generated at 2022-06-11 00:36:53.985236
# Unit test for function get_all_subclasses

# Generated at 2022-06-11 00:37:01.875971
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        pass

    class A1(A):
        pass

    class A2(A):
        pass

    class A1_1(A1):
        pass

    class B(object):
        pass

    class B1(B):
        pass

    class B2(B):
        pass

    class B1_1(B1):
        pass

    class Test(unittest.TestCase):
        def test1(self):
            self.assertEqual(get_all_subclasses(A), set([A1, A1_1, A2]))
            self.assertEqual(get_all_subclasses(A1), set([A1_1]))

# Generated at 2022-06-11 00:37:04.750225
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E])



# Generated at 2022-06-11 00:37:08.130444
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Foo(object): pass
    class Bar(Foo): pass
    class Baz(Foo): pass
    class Qux(Bar): pass
    classes = get_all_subclasses(Foo)
    assert isinstance(classes, set)
    assert len(classes) == 3
    assert Bar in classes
    assert Baz in classes
    assert Qux in classes

# Generated at 2022-06-11 00:37:25.720937
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Verify that get_all_subclasses() produces the correct results.
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass

    classes = get_all_subclasses(A)

    assert B in classes
    assert C in classes
    assert D in classes
    assert len(classes) == 3

# Generated at 2022-06-11 00:37:36.853637
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class father_class(object):
        pass

    class child_class(father_class):
        pass

    class child_class_2(father_class):
        pass

    class child_class_3(father_class):
        pass

    class deeper_child_class(child_class):
        pass

    class deeper_child_class_2(child_class):
        pass

    class deeper_child_class_3(child_class_2):
        pass

    class deeper_child_class_4(child_class_3):
        pass

    # Printing tree that should be returned by get_all_subclasses
    # father_class
    # |___child_class
    # |      |___deeper_child_class
    # |      |___deeper_child_class_2
    # |___child_class_2

# Generated at 2022-06-11 00:37:41.777082
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(D): pass
    class F(E): pass
    class G(F): pass
    class H(F): pass
    class I(G, H): pass
    class J(I): pass
    class K(I): pass
    class L(I): pass
    class M(I): pass
    assert len(get_all_subclasses(A)) == 9

# Generated at 2022-06-11 00:37:53.075033
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """Class Foo and Bar use inheritance.
    In the same time, Foo use multiple inheritance.
    Each class use the method "index()"
    """
    class Foo(object):
        def index(self):
            return self.__class__.__name__
        pass

    class Bar(object):
        def index(self):
            return self.__class__.__name__
        pass

    class FooBar(Foo, Bar):
        pass

    class FooBarBaz(FooBar):
        pass

    class FooBarQix(FooBar):
        pass

    # Add some class which is not a subclass
    class Baz(object):
        def index(self):
            return self.__class__.__name__

    # Build dict of class and expected result

# Generated at 2022-06-11 00:37:57.575559
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestClass(object):
        pass

    class TestClassFirstChild(TestClass):
        pass

    class TestClassSecondChild(TestClassFirstChild):
        pass

    class TestClassFirstChildSecondChild(TestClassFirstChild):
        pass

    class TestClassSecondChildSecondChild(TestClassFirstChild):
        pass

    subclasses = get_all_subclasses(TestClass)
    assert TestClassFirstChild in subclasses
    assert TestClassSecondChild in subclasses
    assert TestClassFirstChildSecondChild in subclasses
    assert TestClassSecondChildSecondChild in subclasses

# Generated at 2022-06-11 00:38:05.096960
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A:
        def __init__(self):
            pass

    class A1(A):
        pass

    class A2(A):
        pass

    class A1a(A1):
        pass

    class B:
        pass

    classes = get_all_subclasses(A)
    assert all([A1, A2, A1a] <= classes)
    assert B not in classes
    assert A not in classes

    classes = get_all_subclasses(B)
    assert all([A, A1, A2, A1a] & classes == set())
    assert B not in classes

# Generated at 2022-06-11 00:38:13.214910
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses

    :rtype: bool
    :returns: A boolean indicating if the unit test passes or fails.

    The unit test creates the following class hierarchy::

        TestClass
        |
        TestClassA
        |
        TestClassB
        |
        TestClassC
        |
        TestClassD

    It then attempts to get the subclasses of each class.  It tests that each class found is a
    subclass of the expected class.

    If the unit test fails, it returns False.
    '''
    class TestClass(object):
        pass

    class TestClassA(TestClass):
        pass

    class TestClassB(TestClassA):
        pass

    class TestClassC(TestClassB):
        pass

    class TestClassD(TestClassC):
        pass

# Generated at 2022-06-11 00:38:22.635448
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Declare simple class hierarchy
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-11 00:38:32.598875
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    The purpose of this function is to test the function get_all_subclasses
    '''
    class A(object):
        '''
        Class which will be the parent class
        '''
        pass

    class B(A):
        '''
        Class which will inherit from class A
        '''
        pass

    class C(A):
        '''
        Class which will inherit from class A
        '''
        pass

    class D(B):
        '''
        Class which will inherit from class B
        '''
        pass

    # The set which contains all subclasses
    references = set([B, C, D])
    # Get all subclasses
    subclasses = get_all_subclasses(A)
    # Check the result
    assert subclasses == references

# Generated at 2022-06-11 00:38:42.304196
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for get_all_subclasses

    To run the unit test, execute::

        python -m ansible._utils.test_get_all_subclasses

    The output will look like::

        Ran 1 tests in 0.001s
        OK

    '''
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(B, D):
        pass

    class G(F):
        pass

    class H(G):
        pass

    class U(object):
        pass

    class V(U):
        pass

    class W(V):
        pass

    class Z(W):
        pass


# Generated at 2022-06-11 00:39:11.725012
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class BaseClass(object):
        pass

    class SubClass1(BaseClass):
        pass

    class SubSubClass1(SubClass1):
        pass

    class SubSubClass2(SubClass1):
        pass

    class SubClass2(BaseClass):
        pass

    class SubSubClass3(SubClass2):
        pass

    subclasses = get_all_subclasses(BaseClass)
    assert len(subclasses) == 5
    assert SubClass1 in subclasses
    assert SubClass2 in subclasses
    assert SubSubClass1 in subclasses
    assert SubSubClass2 in subclasses
    assert SubSubClass3 in subclasses

# Generated at 2022-06-11 00:39:25.245871
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test for function get_all_subclasses

    :rtype: bool
    :returns: True if test is passed, else False
    '''
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(D): pass

    # Test with class A
    subclasses = get_all_subclasses(A)
    if len(subclasses) == 4:
        if B in subclasses:
            if C in subclasses:
                if D in subclasses:
                    if E in subclasses:
                        # Test with class B
                        subclasses = get_all_subclasses(B)
                        if len(subclasses) == 1:
                            if C in subclasses:
                                return True
    return False


# Generated at 2022-06-11 00:39:29.359240
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    assert(set(get_all_subclasses(A)) == set([B, C, D, E, F]))

# Generated at 2022-06-11 00:39:33.068632
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(B)) == set([D])
    assert set(get_all_subclasses(C)) == set([])
    assert set(get_all_subclasses(D)) == set([])

# Generated at 2022-06-11 00:39:39.671885
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Creating a basic class
    class TestClass(object):
        pass
    # Creating 2st level of subclasses
    class TestClass1(TestClass):
        pass
    class TestClass2(TestClass):
        pass
    class TestClass3(TestClass):
        pass
    # Creating 3rd level of subclasses
    class TestClass2_1(TestClass2):
        pass
    class TestClass2_2(TestClass2):
        pass
    class TestClass3_1(TestClass3):
        pass
    # Create 4th level of subclasses
    class TestClass2_2_1(TestClass2_2):
        pass
    # Create a list of all subclasses

# Generated at 2022-06-11 00:39:48.283958
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Parent:
        pass

    class Child1(Parent):
        pass

    class Child2(Parent):
        pass

    class GrandChild1(Child1):
        pass

    class GrandChild2(Child1):
        pass

    class GrandChild3(Child2):
        pass

    class GreatGrandChild1(GrandChild1):
        pass

    subclasses = get_all_subclasses(Parent)
    assert subclasses == set([Child1, Child2, GrandChild1, GrandChild2, GrandChild3, GreatGrandChild1]), subclasses


# Generated at 2022-06-11 00:39:58.818588
# Unit test for function get_all_subclasses

# Generated at 2022-06-11 00:40:06.258201
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G:
        pass

    g = G()

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(G) == set([])

    try:
        get_all_subclasses(g)
    except TypeError as e:
        assert 'is not a class' in str(e)
    else:
        raise Exception('Does not raise a TypeError when arg is not a class')


# Generated at 2022-06-11 00:40:14.661402
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(object):
        pass
    subclasses_A = get_all_subclasses(A)
    subclasses_B = get_all_subclasses(B)
    subclasses_D = get_all_subclasses(D)
    assert len(subclasses_A) == 3
    assert len(subclasses_B) == 1
    assert len(subclasses_D) == 0
    assert C in subclasses_A
    assert B in subclasses_A
    assert C in subclasses_B


# Generated at 2022-06-11 00:40:22.347985
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This unit test can be run with ``python -m ansible.module_utils._utils.test_get_all_subclasses``
    '''

    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass

    # Test for all classes
    assert get_all_subclasses(A) == set([B, C, D])

    # Test for no class
    assert get_all_subclasses(object) == set()

    # Test for only one class
    assert get_all_subclasses(B) == set([D])



# Generated at 2022-06-11 00:41:14.418583
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    r = get_all_subclasses(A)
    r = sorted([Sc.__name__ for Sc in r])
    assert r == ['B', 'C', 'D', 'E', 'F']

# Generated at 2022-06-11 00:41:23.012955
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # This class is used for testing purpose
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    # Now we expect to have A, B, C, D, E in the returned set
    result = get_all_subclasses(A)
    assert result == set([A, B, C, D, E])

# Basic test for module import from ansible/plugins/module_utils/

# Generated at 2022-06-11 00:41:34.317085
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from unittest import TestCase
    from unittest import mock

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    class TestSubclasses(TestCase):
        def test_get_all_subclasses(self):
            with mock.patch('ansible.module_utils._text.ANSIBLE_MODULE_UTILS._utils.get_all_subclasses') as mock_get_all_subclasses:
                mock_get_all_subclasses.return_value = {B, C, D}
                r = get_all_subclasses(A)

            self.assertTupleEqual(tuple(r), (B, C, D))


# Generated at 2022-06-11 00:41:43.241244
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Animal(object):
        pass

    class Mammal(Animal):
        pass

    class Carnivore(Mammal):
        pass

    class Dog(Carnivore):
        pass

    class Tiger(Carnivore):
        pass

    class Elephant(Mammal):
        pass

    class Plant(object):
        pass

    assert get_all_subclasses(Animal) == set([Carnivore, Elephant, Dog, Tiger])
    assert get_all_subclasses(Mammal) == set([Carnivore, Elephant, Dog, Tiger])
    assert get_all_subclasses(Plant) == set()
    assert get_all_subclasses(Carnivore) == set([Dog, Tiger])
    assert get_all_subclasses(Dog) == set()

# Generated at 2022-06-11 00:41:52.594557
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import pytest
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(A): pass
    class F(E): pass
    class G(A): pass

    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert G in get_all_subclasses(A)
    assert F in get_all_subclasses(E)
    assert D in get_all_subclasses(A)

    assert len(get_all_subclasses(A)) == 5
    assert len(get_all_subclasses(E)) == 1

# Generated at 2022-06-11 00:42:01.713424
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(object):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(H):
        pass

    classes = [A, B, C, D, E, F, G, H, I, J, K]
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G]), \
        get_all_subclasses(A)

# Generated at 2022-06-11 00:42:06.295371
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test for the function get_all_subclasses
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(E):
        pass
    # Test the result
    assert get_all_subclasses(A) == {B, C, D, E, F}

# Generated at 2022-06-11 00:42:11.655327
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a(object): pass
    class b(a): pass
    class c(a): pass
    class d(b): pass
    class e(b): pass
    class f(c): pass
    subclass_dict = dict(
        [(subclass.__name__, subclass) for subclass in get_all_subclasses(a)])
    assert a in subclass_dict
    assert b in subclass_dict
    assert c in subclass_dict
    assert d in subclass_dict
    assert e in subclass_dict
    assert f in subclass_dict
    assert len(subclass_dict) == 6

# Generated at 2022-06-11 00:42:19.564909
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """ Stolen from flask.globals._app_ctx_stack """
    class AppStack(object):
        def __init__(self):
            self._stack = []

    class Stack(object):
        def __init__(self):
            self._local = threading.local()

        def push(self, obj):
            self._local.stack.append(obj)

        def pop(self):
            return self._local.stack.pop()

    class _AppCtxGlobals(object):
        pass

    class _AppCtxStack(object):
        def __init__(self):
            self._local = threading.local()

        def push(self, app):
            self._local.stack.append(app)

        def pop(self):
            rv = self._local.stack.pop()
            self._

# Generated at 2022-06-11 00:42:27.654674
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(object):
        pass

    class H(G):
        pass

    assert set(get_all_subclasses(A)) == set((B, D, E, F, C))
    assert set(get_all_subclasses(B)) == set((D, E, F))
    assert set(get_all_subclasses(C)) == set()
    assert set(get_all_subclasses(D)) == set((E, F))
    assert set(get_all_subclasses(E)) == set()