

# Generated at 2022-06-11 00:32:40.070712
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class D(object):
        pass
    class C(D):
        pass
    class B(D):
        pass
    class A(B, C):
        pass

    assert get_all_subclasses(D) == set([A, B, C])



# Generated at 2022-06-11 00:32:43.908319
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(object) == set([])
    class A(object): pass
    class B(object): pass
    class C(A): pass
    assert get_all_subclasses(object) == set([A, B, C])
    class D(B): pass
    assert get_all_subclasses(object) == set([A, B, C, D])

# Generated at 2022-06-11 00:32:46.372779
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D])



# Generated at 2022-06-11 00:32:55.631961
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # This test is a simple configuration

    # An abstract class
    class ClsA(object):
        pass

    # A class
    class ClsB(ClsA):
        pass

    # A class
    class ClsC(ClsA):
        pass

    # A class
    class ClsD(ClsB):
        pass

    # A class
    class ClsE(ClsD):
        pass

    # B is a subclass of A
    assert ClsB in get_all_subclasses(ClsA)
    # D is a subclass of A
    assert ClsD in get_all_subclasses(ClsA)
    # E is a subclass of A
    assert ClsE in get_all_subclasses(ClsA)

    # A is not a subclass of B
    assert ClsA

# Generated at 2022-06-11 00:33:09.027483
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Initialize classes A,B and C
    class A: pass
    class B: pass
    class C: pass

    # Initialize subclasses of A, B and C
    class AA(A): pass
    class AB(A): pass
    class AC(A): pass
    class BA(B): pass
    class BB(B): pass
    class BC(B): pass
    class CA(C): pass
    class CB(C): pass
    class CC(C): pass

    # Initialize sub subclasses of subclasses of A, B and C
    class AAA(AA): pass
    class ABA(AB): pass
    class ACA(AC): pass
    class BAA(BA): pass
    class BBA(BB): pass
    class BCA(BC): pass
    class CAA(CA): pass

# Generated at 2022-06-11 00:33:21.179005
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class B2(A):
        pass

    class C2(B2):
        pass

    class C3(B2):
        pass

    assert get_all_subclasses(A) == set([B, B2, C, C2, C3])
    assert get_all_subclasses(B) == set([C])
    assert get_all_subclasses(B2) == set([C2, C3])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(C2) == set([])
    assert get_all_subclasses(C3) == set([])

# Generated at 2022-06-11 00:33:28.138810
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(E):
        pass
    class H(D):
        pass
    class I(G):
        pass

    result = get_all_subclasses(A)
    expected = set([B, C, D, E, F, G, H, I])
    assert result == expected



# Generated at 2022-06-11 00:33:34.264941
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test function get_all_subclasses()
    """

    # First example:
    #           A
    #            \
    #             B
    #            / \
    #           C   D

    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])

# Generated at 2022-06-11 00:33:40.807375
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a: pass
    class b(a): pass
    class c(a): pass
    class d(c): pass
    class e(b): pass
    class f(e): pass
    class g(d): pass
    class h(g): pass
    class i: pass
    class j(i): pass
    class k(j): pass
    class l(k): pass
    class m(l): pass
    class n(m): pass

    assert get_all_subclasses(a) == set([b, c, d, e, f, g, h]), 'Error in get_all_subclasses()'

# Generated at 2022-06-11 00:33:50.940876
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Build a simple class tree
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(C): pass
    class H(F): pass
    class I(F): pass
    class J(G): pass
    class K(H): pass
    class L(G): pass

    # build a dictionary of class : [list of subclasses]

# Generated at 2022-06-11 00:34:00.796808
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Testing get_all_subclasses with an example.
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(E):
        pass

    class G(E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])

# Generated at 2022-06-11 00:34:07.585044
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(B)) == set([])
    assert set(get_all_subclasses(C)) == set([D, E])
    assert set(get_all_subclasses(D)) == set([E])
    assert set(get_all_subclasses(E)) == set([])

    assert set(get_all_subclasses(object)) != set([])

# Generated at 2022-06-11 00:34:18.111291
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    from collections import UserList, UserDict
    # Ensure Py26 compatibility
    try:
        from collections import UserString
    except ImportError:
        from UserString import UserString
    # Simple test
    class Base(object):
        pass

    class A(Base):
        pass

    class B(Base):
        pass

    assert get_all_subclasses(Base) == set([A, B])
    # Test with multiple level of inheritance
    class C(A):
        pass

    assert get_all_subclasses(Base) == set([A, B, C])
    # Test with buildin classes
    assert get_all_subclasses(UserList) == set([])

# Generated at 2022-06-11 00:34:27.244221
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestClassA(object):
        pass

    class TestClassB(object):
        pass

    class TestClassC(TestClassA):
        pass

    class TestClassD(TestClassC):
        pass

    class TestClassE(TestClassC):
        pass

    assert TestClassC in get_all_subclasses(TestClassA)
    assert TestClassD in get_all_subclasses(TestClassA)
    assert TestClassE in get_all_subclasses(TestClassA)

    assert TestClassA not in get_all_subclasses(TestClassA)
    assert TestClassB not in get_all_subclasses(TestClassA)

    assert TestClassD in get_all_subclasses(TestClassB)

# Generated at 2022-06-11 00:34:37.007552
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Simple test class
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(D):
        pass

   # Building a set of classes [A,B,C,D,E,F]
    classes = {A(), B(), C(), D(), E(), F()}
    subclasses = get_all_subclasses(A)

    # Check if all returned subclasses are subclasses of A
    for subcls in subclasses:
        assert issubclass(subcls, A)
        assert subcls in classes

# Generated at 2022-06-11 00:34:46.624255
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Create some test classes

    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(B):
        pass

    class F(E):
        pass

    class G:
        pass

    class H(G):
        pass

    # Some test assertions
    assert D in get_all_subclasses(A)
    assert set([D, E, F]) == get_all_subclasses(B)
    assert set([C, E, F]) == get_all_subclasses(A)
    assert set([D, E, F]) == get_all_subclasses(B)
    assert set([D]) == get_all_subclasses(C)

# Generated at 2022-06-11 00:34:57.592181
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types
    import sys
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D, A): pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, F])
    assert set(get_all_subclasses(C)) == set([E])
    assert set(get_all_subclasses(D)) == set([F])
    assert set(get_all_subclasses(E)) == set([])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-11 00:35:02.691420
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(D): pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    # TODO: add tests for modules importing this file, like modules/cloud/amazon/ec2.py

# Generated at 2022-06-11 00:35:07.085462
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Here is a simple test, without going too deep
    # Create a class
    class Foo(object):
        pass

    # Create subclasses
    class Foo1(Foo):
        pass

    class Foo2(Foo):
        pas

# Generated at 2022-06-11 00:35:11.217450
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    assert get_all_subclasses(A) == set([B, C, D])

test_get_all_subclasses()

# Generated at 2022-06-11 00:35:21.936571
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Iterable
    from ansible.plugins.loader import connection_loader

    assert isinstance(get_all_subclasses(object), Iterable)
    assert isinstance(get_all_subclasses(object), set)
    assert not get_all_subclasses(object)

    connection_classes = get_all_subclasses(connection_loader._get_plugin_class())

    assert len(connection_classes) > 10
    assert object not in connection_classes

    for connection_class in connection_classes:
        assert connection_class.__bases__[-1] == connection_loader._get_plugin_class()

# Generated at 2022-06-11 00:35:26.982376
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # A simple test class
    class A: pass
    class A1(A): pass
    class A2(A): pass
    class A11(A1): pass
    class A12(A1): pass
    class A21(A2): pass
    class A22(A2): pass
    class A111(A11): pass
    class A112(A11): pass
    # Test
    assert get_all_subclasses(A) == set([A, A1, A11, A111, A112, A12, A2, A21, A22])

# Generated at 2022-06-11 00:35:38.070222
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.utils._text import to_text
    from ansible.compat.tests.mock import call
    from ansible.compat.tests import unittest

    class GrandParent(object):
        pass

    class Parent(GrandParent):
        pass

    class Child(Parent):
        pass

    class GrandChild(Child):
        pass

    class Uncle(GrandParent):
        pass

    class Cousin(Uncle):
        pass

    class ClassToIgnore(object):
        pass

    class TestGetAllSubclasses(unittest.TestCase):
        def test_get_all_subclasses(self):
            # get_all_subclasses(GrandParent)
            # should return {Child, Cousin, GrandChild, Parent, Uncle}
            subclasses = get_all_subclasses(GrandParent)
            self

# Generated at 2022-06-11 00:35:41.680294
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(A):
        pass

    assert set(A.__subclasses__()) == {B, C, E}
    assert set(get_all_subclasses(A)) == {B, C, D, E}

# Generated at 2022-06-11 00:35:53.032493
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class SuperClass(object):
        pass

    class SubClassOne(SuperClass):
        pass

    class SubSubClassOne(SubClassOne):
        pass

    class SubSubClassTwo(SubClassOne):
        pass

    class SubClassTwo(SuperClass):
        pass

    class SubSubSubClass(SubSubClassOne):
        pass

    expected_subclasses = set([
        SubClassOne,
        SubSubClassOne,
        SubSubClassTwo,
        SubClassTwo,
        SubSubSubClass
    ])

    assert get_all_subclasses(SuperClass) == expected_subclasses
    assert get_all_subclasses(SubClassTwo) == set([])
    assert get_all_subclasses(SubSubSubClass) == set([])

# Generated at 2022-06-11 00:36:01.899711
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.utils._text import to_text

    class Foo(object): pass
    class Bar(Foo): pass
    class Baz(Foo): pass

    classes = get_all_subclasses(Foo)
    for cls in [Foo, Bar, Baz]:
        assert cls in classes
    assert to_text(classes) == 'set([<class \'ansible.utils._utils.Bar\'>, <class \'ansible.utils._utils.Foo\'>, <class \'ansible.utils._utils.Baz\'>])'

    classes = get_all_subclasses(Bar)
    assert classes == set() or classes == set([Bar])

# Generated at 2022-06-11 00:36:07.018039
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Dummy class for testing
    class father(object):
        pass
    class child(father):
        pass
    class grandchild(child):
        pass

    # Testing
    assert sorted(get_all_subclasses(father)) == sorted([child, grandchild])
    assert sorted(get_all_subclasses(child)) == sorted([grandchild])
    assert sorted(get_all_subclasses(grandchild)) == sorted([])

# Generated at 2022-06-11 00:36:13.666074
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set([F])
    assert set(get_all_subclasses(D)) == set()
    assert set(get_all_subclasses(E)) == set()
    assert set(get_all_subclasses(F)) == set()


# Generated at 2022-06-11 00:36:53.685919
# Unit test for function get_all_subclasses

# Generated at 2022-06-11 00:37:04.648076
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        pass
    class B(A):
        pass
    class A2(object):
        pass
    class B2(A2):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(A):
        pass
    class C2(B):
        pass
    class F(B):
        pass
    class G(B):
        pass
    class H(C):
        pass
    class I(D):
        pass
    class J(F):
        pass
    class K(F):
        pass

    classes_list = [A, A2, B, B2, C, D, E, C2, F, G, H, I, J, K]


# Generated at 2022-06-11 00:37:25.250672
# Unit test for function get_all_subclasses

# Generated at 2022-06-11 00:37:29.738404
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    result = get_all_subclasses(A)
    assert result == set([B, C, D, E])

# Generated at 2022-06-11 00:37:34.631755
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Foo(object):
        pass

    class Bar(Foo):
        pass

    class John(Foo):
        pass

    class Doe(John):
        pass

    assert get_all_subclasses(Foo) == set([Bar, John, Doe])



# Generated at 2022-06-11 00:37:42.436591
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(E):
        pass

    class G(D):
        pass

    class H(G):
        pass

    classes = get_all_subclasses(A)
    assert A in classes
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert G in classes
    assert H in classes
    assert len(classes) == 8
    # Call get_all_subclasses on B
    classes = get_all_subclasses(B)
    assert A not in classes

# Generated at 2022-06-11 00:37:50.632575
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
   # Create a fake class to avoid import in test
   class C(object):
       pass
   class D(C):
       pass
   class E(C):
       pass
   class F(D):
       pass

   assert set(get_all_subclasses(C)) == set([D, F, E])
   assert set(get_all_subclasses(D)) == set([F])
   assert set(get_all_subclasses(E)) == set([])
   assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-11 00:37:59.134510
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class Aa(A):
        pass

    class Ab(A):
        pass

    class Ac(A):
        pass

    class C(object):
        pass

    class D(object):
        pass

    class E(object):
        pass

    assert set(get_all_subclasses(A)) == {Aa, Ab, Ac}
    assert set(get_all_subclasses(B)) == set()
    assert set(get_all_subclasses(C)) == set()
    assert set(get_all_subclasses(D)) == set()
    assert set(get_all_subclasses(E)) == set()

# Generated at 2022-06-11 00:38:07.592250
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Example usage of get_all_subclasses
    # Define class hierarchy
    class class_a(object):
        pass
    class class_b(class_a):
        pass
    class class_c(class_a):
        pass
    class class_d(class_c):
        pass
    class class_e(class_c):
        pass
    class class_f(class_d):
        pass
    class class_g(class_e):
        pass

    # Call function get_all_subclasses
    result = get_all_subclasses(class_a)
    # Create expected subclasses
    expected_subclasses = set([class_b, class_c, class_d, class_e, class_f, class_g])

    assert(result == expected_subclasses)

# Generated at 2022-06-11 00:38:17.289682
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create classes for testing
    class MyException(Exception):
        pass
    class MyOtherException(Exception):
        pass
    class MySubException(MyException):
        pass
    class MySubClass(MyOtherException):
        pass
    class MyOtherExceptionBis(MyOtherException):
        pass
    class MySubClassBis(MyOtherException):
        pass

    # Retrieve all subclasses of Exception, should return {MyException, MyOtherException, MySubException}
    assert get_all_subclasses(Exception) == {MyException, MyOtherException, MySubException}

    # Retrieve all subclasses of MyOtherException, should return {MySubClass, MyOtherExceptionBis, MySubClassBis}

# Generated at 2022-06-11 00:38:24.654508
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Class used for tests
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(C):
        pass
    class H(C):
        pass
    class I(G):
        pass
    class J(F):
        pass
    # Check we get all the classes
    subclasses = get_all_subclasses(A)
    assert set(subclasses) == {B, C, D, E, F, G, H, I, J}

# Generated at 2022-06-11 00:38:32.305727
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Aaa:
        pass
    class Bbb(Aaa):
        pass
    class Ccc(Aaa):
        pass
    class Ddd(Ccc):
        pass
    class Eee:
        pass
    class Fff(Eee):
        pass
    class Ggg(Fff):
        pass

    assert get_all_subclasses(Aaa) == {Bbb, Ccc, Ddd}
    assert get_all_subclasses(Eee) == {Fff, Ggg}

# Generated at 2022-06-11 00:39:01.946536
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(A):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(object):
        pass
    class K(object):
        pass
    class L(K):
        pass

    assert get_all_subclasses(A) == set([B, G, H, I, C, D, E, F, object])
    assert get_all_subclasses(object) == set([type, object])
    assert get_all_subclasses(J) == set([type, object])
    assert get_all_subclasses

# Generated at 2022-06-11 00:39:08.156811
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class InitialClass(object):
        pass

    class ChildA(InitialClass):
        pass

    class ChildB(InitialClass):
        pass

    class SonOfChildA(ChildA):
        pass

    class SonOfChildB(ChildB):
        pass

    class DaughterOfChildB(ChildB):
        pass

    result = get_all_subclasses(InitialClass)
    assert InitialClass in result
    assert ChildA in result
    assert ChildB in result
    assert SonOfChildA in result
    assert SonOfChildB in result
    assert DaughterOfChildB in result

# Generated at 2022-06-11 00:39:11.589911
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    assert(A in get_all_subclasses(A))
    assert(B in get_all_subclasses(A))
    assert(B in get_all_subclasses(B))


# Generated at 2022-06-11 00:39:20.034403
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class P(object): pass
    p = P()
    class C(P): pass
    class C1(C): pass
    class C11(C1): pass
    class C12(C1): pass
    class C2(C): pass
    class C21(C2): pass
    class C3(C): pass
    assert set([C1, C11, C12, C2, C21, C3]) == get_all_subclasses(C)

# Generated at 2022-06-11 00:39:25.159711
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass

    class B(A): pass
    class C(A): pass
    class D(B): pass

    class E(A): pass
    class F(D): pass
    class G(E): pass
    class H(G): pass
    class I(C, F): pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I])

# Generated at 2022-06-11 00:39:28.721583
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E])



# Generated at 2022-06-11 00:39:32.367451
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(A): pass
    assert set(get_all_subclasses(A)) == {B, C, D, E}

# Generated at 2022-06-11 00:39:38.679771
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass

    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 4
    subclasses = get_all_subclasses(B)
    assert len(subclasses) == 1
    subclasses = get_all_subclasses(C)
    assert len(subclasses) == 1
    subclasses = get_all_subclasses(D)
    assert len(subclasses) == 0
    subclasses = get_all_subclasses(E)
    assert len(subclasses) == 0



# Generated at 2022-06-11 00:39:46.620864
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.plugins.action import ActionBase

    class ActionBase1(ActionBase):
        pass

    class ActionBase2(ActionBase):
        pass

    class ActionBase2_1(ActionBase2):
        pass

    class ActionBase2_2(ActionBase2):
        pass

    class ActionBase2_2_1(ActionBase2_2):
        pass

    assert get_all_subclasses(ActionBase) == set([ActionBase1, ActionBase2, ActionBase2_1, ActionBase2_2, ActionBase2_2_1])

# Generated at 2022-06-11 00:39:52.354158
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    #  class Tree
    #  |
    #  +-class AppleTree(Tree)
    #  |
    #  +-class PearTree(Tree)
    #  |  |
    #  |  +-class PearTree1(PearTree)
    #  |  |
    #  |  +-class PearTree2(PearTree)
    #  |
    #  +-class PineTree(Tree)
    class Tree(object):
        x = 12

    class AppleTree(Tree):
        x = 23

    class PearTree(Tree):
        x = 45

    class PearTree1(PearTree):
        x = 56

    class PearTree2(PearTree):
        x = 78

    class PineTree(Tree):
        x = 100

    # Tree's subclasses
    got = get_all_sub

# Generated at 2022-06-11 00:40:44.837421
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Python 2/3 compatibility
    try:
        from future_builtins import zip
    except ImportError:
        pass

    class A(object):
        pass

    class B1(A):
        pass

    class B2(A):
        pass

    class B3(A):
        pass

    class C1(B1):
        pass

    class C2(B1):
        pass

    class C3(B1):
        pass

    class D1(C1):
        pass

    class D2(C1):
        pass

    class E(B2):
        pass

    class F(B3):
        pass

    class G1(C2):
        pass

    class G2(C2):
        pass

    class G3(C2):
        pass


# Generated at 2022-06-11 00:40:46.509061
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B, C):
        pass
    assert set([B, C, D, E]) == get_all_subclasses(A)

# Generated at 2022-06-11 00:40:55.961269
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Sequence, MutableSequence
    from ansible.module_utils._text import to_native
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(A, Sequence): pass
    class E(D, MutableSequence): pass
    class F(B, C): pass
    expected_classes = (B, C, E)
    result = get_all_subclasses(A)
    assert result, "No class found"
    assert len(result) == len(expected_classes), "Incorrect number of classes found"
    for cls in expected_classes:
        if cls not in result:
            assert False, "Class %s not found in result" % to_native(cls)

if __name__ == '__main__':
    test_get_

# Generated at 2022-06-11 00:41:05.709729
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E():
        pass
    class F(E):
        pass

    subclasses = get_all_subclasses(A)
    assert subclasses == set([B, C, D])

    subclasses = get_all_subclasses(B)
    assert subclasses == set([C, D])

    subclasses = get_all_subclasses(C)
    assert subclasses == set([D])

    subclasses = get_all_subclasses(D)
    assert subclasses == set([])

    subclasses = get_all_subclasses(E)
    assert subclasses == set([F])

    subclasses = get_all_subclasses(F)
    assert subclasses

# Generated at 2022-06-11 00:41:09.199300
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Foo:
        pass
    class Bar(Foo):
        pass
    class Bar2(Foo):
        pass
    class Baz(Bar):
        pass

    assert Foo in get_all_subclasses(Foo)
    assert Bar in get_all_subclasses(Foo)
    assert Baz in get_all_subclasses(Foo)

# Generated at 2022-06-11 00:41:18.337250
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(object): pass
    class F(E): pass
    class G(E): pass
    class H(F, G): pass

    assert_equal(set(), get_all_subclasses(E))
    assert_equal(set([F, G, H]), get_all_subclasses(E))
    assert_equal(set([B, C, D]), get_all_subclasses(A))
    assert_equal(set([D]), get_all_subclasses(B))
    assert_equal(set(), get_all_subclasses(C))
    assert_equal(set(), get_all_subclasses(D))

# Generated at 2022-06-11 00:41:28.860323
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(B):
        pass
    class G(D):
        pass
    class H(E):
        pass
    class I(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(H) == set([])

# Generated at 2022-06-11 00:41:38.640060
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    class F(D, E):
        pass

    def test(a, klass, answer):
        if isinstance(klass, str):
            klass = eval(klass)
        a.assertEqual(set(ansible.module_utils.basic._utils.get_all_subclasses(klass)), set(answer))

    a = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 00:41:44.249166
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D: pass
    class E(D): pass

    assert {A, B, C} == get_all_subclasses(A)
    assert {A, B, C} == get_all_subclasses(B)
    assert {A, B, C} == get_all_subclasses(C)
    assert {D, E} == get_all_subclasses(D)
    assert {D, E} == get_all_subclasses(E)

# Generated at 2022-06-11 00:41:52.830528
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class F: pass
    assert not get_all_subclasses(F)
    class E(F): pass
    assert get_all_subclasses(F) == set([E])
    class D(F): pass
    assert get_all_subclasses(F) == set([E, D])
    class C(D): pass
    assert get_all_subclasses(F) == set([E, D, C])
    class B(E, D): pass
    assert get_all_subclasses(F) == set([E, D, C, B])
    class A(B, C): pass
    assert get_all_subclasses(F) == set([E, D, C, B, A])

