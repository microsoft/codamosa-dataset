

# Generated at 2022-06-11 00:32:40.808533
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object): pass
    class B(A): pass
    class C(object): pass
    class D(B, C): pass
    class E(D): pass

    reachable_classes = get_all_subclasses(A)
    assert reachable_classes == set([B, D, E]), "function get_all_subclasses() failed to retrieve every subclasses of class A"
    reachable_classes = get_all_subclasses(object)
    assert reachable_classes == set([A, B, C, D, E]), "function get_all_subclasses() failed to retrieve every subclasses of object"

# Generated at 2022-06-11 00:32:44.644928
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(object): pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(object)) == set([A, B, C, D, E])

# Generated at 2022-06-11 00:32:53.177332
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(): # test class 1
        pass

    class B(A): # test class 2
        pass

    class C(B): # test class 3
        pass

    class D(A): # test class 4
        pass

    class E(): # test class 5
        pass

    class F(): # test class 6
        pass

    assert set([B, C]) == get_all_subclasses(A)
    assert set([D]) == get_all_subclasses(D)
    assert set([C]) == get_all_subclasses(C)
    assert set([B, C, D]) == get_all_subclasses(A)

# Generated at 2022-06-11 00:33:01.969758
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == {D, E}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-11 00:33:12.158149
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    class A(object):  # pylint: disable=too-few-public-methods
        '''
        Fake class to test function
        '''
        pass

    class B(A):  # pylint: disable=too-few-public-methods
        '''
        Fake class to test function
        '''
        pass

    class C(A):  # pylint: disable=too-few-public-methods
        '''
        Fake class to test function
        '''
        pass

    class D(C):  # pylint: disable=too-few-public-methods
        '''
        Fake class to test function
        '''
        pass


# Generated at 2022-06-11 00:33:21.490255
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Foo:
        pass
    class Bar(Foo):
        pass
    class Baz(Foo):
        pass
    class Spam(Baz):
        pass

    assert Foo in get_all_subclasses(Foo)
    assert Baz in get_all_subclasses(Foo)
    assert Spam in get_all_subclasses(Foo)
    assert Spam in get_all_subclasses(Baz)
    assert Bar in get_all_subclasses(Foo)
    assert Baz not in get_all_subclasses(Spam)
    assert Bar not in get_all_subclasses(Spam)

# Generated at 2022-06-11 00:33:31.104387
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        def __init__(self):
            pass

    class B(A):
        def __init__(self):
            pass

    class C(B):
        def __init__(self):
            pass

    class D(C):
        def __init__(self):
            pass

    class E(C):
        def __init__(self):
            pass

    class F(C):
        def __init__(self):
            pass

    assert len(get_all_subclasses(A)) == 5
    assert len(get_all_subclasses(B)) == 4
    assert len(get_all_subclasses(C)) == 3
    assert len(get_all_subclasses(D)) == 0
    assert len(get_all_subclasses(E)) == 0

# Generated at 2022-06-11 00:33:36.467533
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-11 00:33:47.661105
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E not in get_all_subclasses(A)

    assert A in get_all_subclasses(B)
    assert B in get_all_subclasses(B)
    assert C in get_all_subclasses(B)
    assert D in get_all_subclasses(B)
    assert E not in get_all_subclasses(B)

    assert A in get_all

# Generated at 2022-06-11 00:33:58.206780
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Sample class for test
    class A(object): #pylint: disable=too-few-public-methods
        ''' a class A which inherits from object '''

    class B(A): #pylint: disable=too-few-public-methods
        ''' a class B which inherits from A '''

    class C(A): #pylint: disable=too-few-public-methods
        ''' a class C which inherits from A '''

    class D(B): #pylint: disable=too-few-public-methods
        ''' a class D which inherits from B '''

    class E(C): #pylint: disable=too-few-public-methods
        ''' a class E which inherits from C '''


# Generated at 2022-06-11 00:34:06.086333
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    classes = set(get_all_subclasses(A))
    assert classes == set([A, B, C, D, E, F, G, H])

# Generated at 2022-06-11 00:34:12.610335
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(object): pass
    class F(D): pass
    assert set(get_all_subclasses(A)) == set([B, C])
    assert set(get_all_subclasses(D)) == set([F])
    assert set(get_all_subclasses(F)) == set([])


# Generated at 2022-06-11 00:34:23.657200
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class E(C):
        pass

    class F(A):
        pass

    class G(F):
        pass

    assert types.ModuleType in get_all_subclasses(object)
    assert A in get_all_subclasses(object)
    assert B in get_all_subclasses(object)
    assert C in get_all_subclasses(object)
    assert A in get_all_subclasses(object)
    assert F in get_all_subclasses(object)

    assert set([B, C, E]) <= get_all_subclasses(A)
    assert set([B, C, E]) <= get_all_subclasses(B)
    assert set([E])

# Generated at 2022-06-11 00:34:30.628526
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(D):
        pass
    class M(E):
        pass
    class N(F):
        pass
    class O(G):
        pass
    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses


# Generated at 2022-06-11 00:34:40.913034
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base(object):
        pass

    class Child_1(Base):
        pass

    class Child_2(Base):
        pass

    class GrandChild_1(Child_1):
        pass

    class GrandChild_2(Child_2):
        pass

    assert get_all_subclasses(Base) == set([Child_1, GrandChild_1, Child_2, GrandChild_2])
    assert get_all_subclasses(Child_1) == set([GrandChild_1])
    assert get_all_subclasses(Child_2) == set([GrandChild_2])
    assert get_all_subclasses(GrandChild_1) == set([])
    assert get_all_subclasses(GrandChild_2) == set([])

# Generated at 2022-06-11 00:34:48.545806
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Forbid to move this function on another file
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(C): pass
    class G(E): pass

    expected_results = set([B, D, C, E, F, G])
    result = get_all_subclasses(A)

    assert set(result) == expected_results

# Generated at 2022-06-11 00:34:59.195152
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function `get_all_subclasses`
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(object):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F(B):
        pass
    class G(F):
        pass
    class H(G):
        pass
    assert(sorted(get_all_subclasses(A)) == [B, F, G, H])
    assert(sorted(get_all_subclasses(B)) == [F, G, H])
    assert(sorted(get_all_subclasses(C)) == [D, E])
    assert(sorted(get_all_subclasses(D)) == [E])

# Generated at 2022-06-11 00:35:04.767801
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C: pass
    class D(B): pass
    class E(C): pass
    class F(C): pass
    assert get_all_subclasses(A) == set([B, D])
    assert get_all_subclasses(C) == set([E, F])

###############################################################################


# Generated at 2022-06-11 00:35:13.922142
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass

    assert set(get_all_subclasses(A)) == set([B,D,C,E,F])
    assert set(get_all_subclasses(B)) == set([D,F])
    assert set(get_all_subclasses(C)) == set([E])
    assert set(get_all_subclasses(D)) == set([F])
    assert set(get_all_subclasses(E)) == set([])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-11 00:35:25.163876
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Basic case, no subclasses
    class A:
        pass

    assert get_all_subclasses(A) == set()
    # Direct subclasses
    class B(A):
        pass

    class C(A):
        pass

    assert get_all_subclasses(A) == set([B, C])
    # Direct and sub-subclasses
    class D(B):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    # Multiple branches
    class E(A):
        pass

    class F(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])

    # As a generator
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-11 00:35:40.024588
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This function contains a test to ensure the function get_all_subclasses properly retrieves
    all subclasses of a given class.
    '''

    class A(object):
        pass

    class B(A):  # B is subclass of A
        pass

    class E(object):  # E is not subclass of A
        pass

    class C(E, A):  # C is subclass of A and E
        pass

    class D(B):  # D is subclass of B and A
        pass

    assert set(get_all_subclasses(A)) == set([B, D, C])

# Generated at 2022-06-11 00:35:51.414047
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''Simple unit test for get_all_subclasses'''

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(B, D):
        pass

    classes = [A, B, C, D, E]
    # assert A has only B and C as children
    assert get_all_subclasses(A) == set((B, C))
    # assert B has only E as children
    assert get_all_subclasses(B) == set((E,))
    # assert C has only D as children
    assert get_all_subclasses(C) == set((D,))
    # assert D has no children
    assert get_all_subclasses(D) == set(())
    # assert E has

# Generated at 2022-06-11 00:35:56.125888
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(object):
        pass

    assert get_all_subclasses(A) == set([B, D, C])
    assert get_all_subclasses(E) == set([])

# Generated at 2022-06-11 00:36:08.658675
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    The function get_all_subclasses must return the list of all subclasses
    of the given classes
    '''
    import unittest
    import sys
    from ansible.module_utils._text import to_text

    class A(object):
        '''
        Class A
        '''

    class B(A):
        '''
        Class B
        '''

    class C(A):
        '''
        Class C
        '''

    class D(C):
        '''
        Class D
        '''

    class TestGetAllSubclasses(unittest.TestCase):
        '''
        The function get_all_subclasses must return the list of all subclasses
        of the given classes
        '''


# Generated at 2022-06-11 00:36:19.119952
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Class tree (depth=3)
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(D):
        pass
    class H(F):
        pass

    expected_subclasses = [B, C, E, F, G, H]

    assert set(get_all_subclasses(A)) == set(expected_subclasses)
    assert set(get_all_subclasses(B)) == set()
    assert set(get_all_subclasses(C)) == set()
    assert set(get_all_subclasses(D)) == set([E, F, G])

# Generated at 2022-06-11 00:36:53.626882
# Unit test for function get_all_subclasses

# Generated at 2022-06-11 00:37:04.562825
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(B, D):
        pass
    class F(B, D):
        pass
    class G(B, E, F):
        pass
    class Z(C, E, G):
        pass

    class TestGetAllSubclasses(unittest.TestCase):
        def test_all_subclasses(self):
            self.assertSetEqual(get_all_subclasses(A), set((B, C, D, E, F, G, Z)))
            self.assertSetEqual(get_all_subclasses(Z), set())

    unittest.main(module=__name__, verbosity=2)

# Generated at 2022-06-11 00:37:11.992696
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        def __init__(self, name):
            self.name = name
    class B(A):
        pass
    class C(A):
        pass
    class BB(B):
        pass
    class BC(B, C):
        pass
    class CC(C):
        pass
    classes = {A: ['B', 'C'], B: ['BB', 'BC'], C: ['BC', 'CC']}
    for cls, subclass_names in classes.items():
        subclasses = get_all_subclasses(cls)
        subclass_names = [cls.__name__ for cls in subclasses]
        subclass_names.sort()
        assert subclass_names == subclass_names.sort()


# Generated at 2022-06-11 00:37:18.850267
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a class tree to test
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(B):
        pass

    class G(B):
        pass

    class H(G):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])

# Generated at 2022-06-11 00:37:29.923466
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(B):
        pass
    class G(B):
        pass
    class I(G):
        pass
    class J(G):
        pass
    class K(E):
        pass
    class L(I):
        pass
    classes = {}
    classes['A'] = A
    classes['B'] = B
    classes['C'] = C
    classes['D'] = D
    classes['E'] = E
    classes['F'] = F
    classes['G'] = G
    classes['I'] = I
    classes['J'] = J
    classes['K'] = K

# Generated at 2022-06-11 00:37:53.075142
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test function get_all_subclasses
    """
    try:
        from _text import *
    except ImportError:
        # We're running tests on an older version of Ansible
        # that doesn't have _text.py, so skip the test.
        return

    # Test 1 -
    # Test class structure:
    #    A
    #    |
    #    B
    #   /|\
    #  C D E
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(B):
        pass

    assert sorted([c.__name__ for c in get_all_subclasses(A)]) == sorted(['B', 'C', 'D', 'E'])

   

# Generated at 2022-06-11 00:37:58.856908
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    b = B()
    c = C()

    assert b.__class__ in get_all_subclasses(a.__class__)
    assert c.__class__ in get_all_subclasses(a.__class__)
    assert len(get_all_subclasses(a.__class__)) == 2

# Generated at 2022-06-11 00:38:02.023394
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for get_all_subclasses
    '''
    result = []
    result = get_all_subclasses(object)
    assert(object in result)
    assert(dict in result)
    assert(list in result)

# Generated at 2022-06-11 00:38:09.517812
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define the test classes
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G:
        pass
    class H(G):
        pass

    # A list of expected subclasses
    expected_subclasses = [B, D, E, C, F]

    # Test on class A
    subclasses = get_all_subclasses(A)
    assert subclasses == set(expected_subclasses)

    # Test on class B
    subclasses = get_all_subclasses(B)
    assert subclasses == set(expected_subclasses).difference([B])

    # Test on class C
    subclasses = get_all_

# Generated at 2022-06-11 00:38:13.865532
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a sample class tree
    class Base: pass
    class Child(Base): pass
    class GrandChild1(Child): pass
    class GrandChild2(Child): pass
    class GreatGrandChild(GrandChild1): pass

    assert set(get_all_subclasses(Base)) == set([Child, GrandChild1, GrandChild2, GreatGrandChild])

# Generated at 2022-06-11 00:38:23.648504
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import os
    import sys
    import types

    # The class we're going to use for testing, and the parent classes of
    # the class we're going to use for testing
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(B, D): pass
    class F(A, object): pass
    class G(object, A): pass
    class H(A, object, object): pass
    class I(object, object, A): pass

    # Get the names of the classes we're using for testing
    class_names = [name for name, value in globals().items()
                   if isinstance(value, (types.ClassType, type)) and value.__name__ == 'A']

    # Use the names of the classes we're using for testing

# Generated at 2022-06-11 00:38:35.074116
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(object):
        pass
    class F(E):
        pass
    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(E) == set([F])

# Generated at 2022-06-11 00:38:41.316255
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for :py:meth:`get_all_subclasses`
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(B):
        pass

    class G(C):
        pass

    assert get_all_subclasses(A) == set((B, C, D, E, F, G))

# Generated at 2022-06-11 00:38:51.489460
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    :returns: Nothing. This function will raise an exception if the test fails.
    """
    class A(object):
        """Base class for testing get_all_subclasses"""
    class B(A):
        """Subclass of A"""
    class C(A):
        """Subclass of A"""
    class D(B):
        """Subclass of B and A"""
    class E(D):
        """Subclass of D, B and A"""
    class F(object):
        """Another parent class"""
    class G(F):
        """Subclass of F"""
    class H(F):
        """Subclass of F"""
    class I(G):
        """Subclass of G and F"""
    class J(I):
        """Subclass of I, G and F"""

    assert J in get_all

# Generated at 2022-06-11 00:38:57.296340
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    There is nothing wrong with testing a utils module
    """
    class A: pass
    class B(A): pass
    class C(B): pass

    assert set([A, B, C]) == get_all_subclasses(A)
    assert set([B, C]) == get_all_subclasses(B)
    assert set([C]) == get_all_subclasses(C)
    assert set() == get_all_subclasses(object)

# Generated at 2022-06-11 00:39:27.577473
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(object):
        pass
    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F not in subclasses

# Generated at 2022-06-11 00:39:34.649382
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass

    assert set([A, B, C, D]) == get_all_subclasses(A)
    assert set([B, D]) == get_all_subclasses(B)
    assert set([C]) == get_all_subclasses(C)
    assert set([D]) == get_all_subclasses(D)
    try:
        get_all_subclasses(E)
    except NameError:
        pass
    else:
        raise NameError('This line should not be executed')

# Generated at 2022-06-11 00:39:38.511710
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E():
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-11 00:39:44.292129
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E(D): pass

    expected = set((B, C, D, E))
    result = get_all_subclasses(A)
    assert result == expected, "%r != %r" % (result, expected)


# Generated at 2022-06-11 00:39:54.869751
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import os
    import sys
    import collections
    import unittest

    class TestType(type):
        '''Metaclass that allows you to register subclasses in a list'''
        _registry = []

        def __init__(cls, name, bases, dct):
            super(TestType, cls).__init__(name, bases, dct)
            TestType._registry.append(cls)

        @classmethod
        def get_all_instances(cls):
            '''Get all of the instances of the classes which were registered'''
            return TestType._registry

    class TestBase(object):
        '''Base class for unit tests'''
        __metaclass__ = TestType

    class TestOne(TestBase):
        '''Simple test class'''
        pass


# Generated at 2022-06-11 00:40:04.272996
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import unittest.mock as mock

    class DummyClass:
        pass

    class DummyChildOne(DummyClass):
        pass

    class DummyChildTwo(DummyClass):
        pass

    class DummyGrandChildOne(DummyChildOne):
        pass

    class DummyGrandChildTwo(DummyChildOne):
        pass

    class DummyGrandChildThree(DummyChildTwo):
        pass


# Generated at 2022-06-11 00:40:13.569669
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    A function to test the `get_all_subclasses` function.
    '''

    class A(object):
        ''' Class A '''
        pass

    class B(A):
        ''' Class B '''
        pass

    class C(A):
        ''' Class C '''
        pass

    class D(C):
        ''' Class D '''
        pass

    assert get_all_subclasses(A) is not None
    assert len(get_all_subclasses(A)) == 3
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)


# Generated at 2022-06-11 00:40:17.479229
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass

    assert set([B, E, D, C]) == get_all_subclasses(A)

# Generated at 2022-06-11 00:40:23.920106
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # create a example class
    class Object(object):
        pass

    class FirstSubClass(Object):
        pass

    class SecondSubClass(Object):
        pass

    class LastSubClass(FirstSubClass):
        pass

    # Retrieve all subclasses
    retrieved_subclasses = get_all_subclasses(Object)
    # Check that all classes were retrieved
    for sc in [FirstSubClass, SecondSubClass, LastSubClass]:
        assert sc in retrieved_subclasses

# Generated at 2022-06-11 00:40:33.550443
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a class hierarchy
    class C(object):
        pass
    class A(C):
        pass
    class B(C):
        pass
    class B0(B):
        pass
    class B1(B):
        pass
    class B10(B1):
        pass
    class B11(B1):
        pass
    class B110(B11):
        pass
    class B111(B11):
        pass
    class B12(B1):
        pass

    # Check that we can find all subclasses
    assert set(get_all_subclasses(C)) == {A, B, B0, B1, B10, B11, B110, B111, B12}

# Generated at 2022-06-11 00:41:32.531429
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Base class
    class A(object): pass
    # Direct sub classes of A
    class B(A): pass
    class C(A): pass
    # Sub classes of sub classes of A
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(C): pass
    class H(C): pass
    # Check results
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])
    # Verify that __subclasses__ can't do what we've done
    assert A.__subclasses__() == [B, C]

# Generated at 2022-06-11 00:41:36.048492
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    assert get_all_subclasses(A) == {B, C, D, E}


# Generated at 2022-06-11 00:41:44.822907
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(object):
        pass

    class F(E):
        pass

    def assert_same_unordered_set(iterable1, iterable2):
        assert(set(iterable1) == set(iterable2))

    assert_same_unordered_set(get_all_subclasses(A), [B, C, D])
    assert_same_unordered_set(get_all_subclasses(B), [D])
    assert_same_unordered_set(get_all_subclasses(C), [])
    assert_same_unordered_set(get_all_subclasses(D), [])
    assert_same_unordered_

# Generated at 2022-06-11 00:41:49.148234
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a class hierarchy
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(C):
        pass

    class F(E):
        pass

    # Check that we have the good result
    assert get_all_subclasses(A) == set([B, C, D, E, F])

# Generated at 2022-06-11 00:41:57.767197
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a class hierarchy for test purpose
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(C):
        pass

    # Testing the function over the above class hierarchy
    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([D, E])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()



# Generated at 2022-06-11 00:42:02.621521
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C, object):
        pass

    class E(A):
        pass

    class F(E):
        pass

    class G(F):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])

# Generated at 2022-06-11 00:42:09.707119
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(object):
        pass
    class G(F):
        pass
    classes = {A, B, C, D, E, F, G}
    subcls = get_all_subclasses(object)
    for cls in subcls:
        if cls not in classes:
            raise AssertionError('Class %s found in result but should not be here' % repr(cls))
    if len(subcls) != len(classes):
        raise AssertionError('Error while calling get_all_subclasses')

# Generated at 2022-06-11 00:42:12.209033
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(C): pass

    ansible_all_classes = {A, B, C, D, E, F}

    all_classes = get_all_subclasses(A)
    assert len(all_classes) == 6
    assert all_classes == ansible_all_classes

# Generated at 2022-06-11 00:42:15.262113
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C():
        pass

    class D(A):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == set([B, D, E])

# Generated at 2022-06-11 00:42:19.075540
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Unit test for the get_all_subclasses function
    """
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    # Function return a set, to get a comparable result we cast the list in set
    assert(set(get_all_subclasses(A)) == set([A, B, C, D]))