

# Generated at 2022-06-11 00:32:43.115966
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass
    class F(D): pass
    class G(D): pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([D, E, F, G])

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-11 00:32:49.117836
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(A): pass
    class E(B): pass
    class F(C): pass
    class G(D): pass
    class H(D): pass
    class I(E): pass
    class J(F): pass
    class K(F): pass
    class L(G): pass

    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 8
    for cls in (C, D, F, G, H, J, K, L):
        assert cls in subclasses

    subclasses = get_all_subclasses(B)
    assert len(subclasses) == 2
    for cls in (E, I):
        assert cls in subclasses

# Generated at 2022-06-11 00:32:57.090269
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    A basic test for get_all_subclasses

    This test is not complete, but it does provide a basic unit test for the function.  It is also
    a useful example for how to use the function.
    """
    class Dog(object):
        pass

    class GoldenRetriever(Dog):
        pass

    class YellowLab(Dog):
        pass

    class Bloodhound(Dog):
        pass

    class JackRussellTerrier(Dog):
        pass

    class Chihuahua(Dog):
        pass

    class Corgi(Dog):
        pass

    # Build a list of all the subclasses of Dog.
    dog_subclasses = get_all_subclasses(Dog)

    # Verify that the dog_subclasses list contains the expected subclasses of Dog.
    assert GoldenRetriever in dog_subclasses
   

# Generated at 2022-06-11 00:33:03.725681
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(object):
        pass

    assert get_all_subclasses(A) == set([B,C,D])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-11 00:33:11.689686
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.plugins import module_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    loader = AnsibleCollectionLoader()
    collection_name = 'test_collections.namespace.test_collection1'
    plugin_dirs = loader._get_collections(collection_name)
    module_finder = module_loader.ModuleUtilBase(plugin_dirs=plugin_dirs, class_name_filter='*')
    all_plugins = module_finder.get_all_classes()
    clsses = get_all_subclasses(module_loader.ModuleUtilBase)
    assert all_plugins == clsses



# Generated at 2022-06-11 00:33:22.962988
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test class for get_all_subclasses, test is run on following class:

    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(B, C, E):
        pass

    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(B, C, E):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F])

# Generated at 2022-06-11 00:33:28.966431
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass

    # Test if the function returns all subclasses
    assert get_all_subclasses(A) == {B, C, D}

    # Test if the function returns correct subclass at different level
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(B) == {D}


# Generated at 2022-06-11 00:33:32.321102
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define two classes
    class C(object):
        pass

    class B(C):
        pass

    class A(B):
        pass

    assert get_all_subclasses(C) == set([B, A])

# Generated at 2022-06-11 00:33:41.024552
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    ''' Test get_all_subclasses '''
    import types
    import unittest

    class ClassOne(object):
        ''' dummy class 1 '''
    class ClassTwo(ClassOne):
        ''' dummy class 2 '''
    class ClassThree(ClassTwo):
        ''' dummy class 3 '''
    class ClassFour(ClassOne):
        ''' dummy class 4 '''
    class ClassFive(ClassOne):
        ''' dummy class 5 '''
    class ClassSix(ClassFour, ClassFive):
        ''' dummy class 6 '''
    class ClassSeven(ClassTwo, ClassFive):
        ''' dummy class 7 '''
    class ClassEight(ClassThree, ClassSix, ClassSeven):
        ''' dummy class 8 '''
    class ClassNine(object):
        ''' dummy class 9 '''


# Generated at 2022-06-11 00:33:46.712910
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a sample class hierarchy
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D, E, F}


# Generated at 2022-06-11 00:33:58.861852
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    This function tests the get_all_subclasses function.

    It creates the following class structure:
    C
    |_ A
    |  |_ B
    |_ D

    B inherits from C
    A inherits from B
    D inherits from C

    It then calls get_all_subclasses for C and verifies it returns A and D.
    """
    class C(object):
        pass

    class A(C):
        pass

    class B(A):
        pass

    class D(C):
        pass

    assert set(get_all_subclasses(C)) == set([A, D]), 'get_all_subclasses does not work with multilevel class structure'

# Generated at 2022-06-11 00:34:03.121893
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(B): pass
    class E(D): pass
    class F(object): pass
    subclasses = get_all_subclasses(A)
    assert D in subclasses
    assert E in subclasses
    assert F not in subclasses

# Generated at 2022-06-11 00:34:08.764614
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(object):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == {C}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()



# Generated at 2022-06-11 00:34:20.979747
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Create the following classes to test get_all_subclasses function:
        class a(object)
        class b(a)
        class c(a)
        class d(b)
        class e(b)
        class f(c)

    :rtype: bool
    :return: True if the unit test is succeeded
    """
    class a(object):
        pass
    class b(a):
        pass
    class c(a):
        pass
    class d(b):
        pass
    class e(b):
        pass
    class f(c):
        pass

    assert set(get_all_subclasses(a)) == set([b, c, d, e, f])
    assert set(get_all_subclasses(b)) == set([d, e])

# Generated at 2022-06-11 00:34:29.318606
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.utils._get_all_subclasses_unit_test_class import ExampleParentClass
    from ansible.utils._get_all_subclasses_unit_test_class import ExampleChildClass
    from ansible.utils._get_all_subclasses_unit_test_class import ExampleSubChildClass
    from ansible.utils._get_all_subclasses_unit_test_class import ExampleParentClass2
    from ansible.utils._get_all_subclasses_unit_test_class import ExampleChildClass2
    from ansible.utils._get_all_subclasses_unit_test_class import ExampleSubChildClass2
    assert ExampleParentClass in get_all_subclasses(ExampleParentClass)
    assert ExampleChildClass in get_all_subclasses(ExampleParentClass)

# Generated at 2022-06-11 00:34:40.386748
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import six

    # Defining a mock class for test purpose
    @six.add_metaclass(type)
    class A(object):
        pass

    @six.add_metaclass(type)
    class B(A):
        pass

    @six.add_metaclass(type)
    class C(A):
        pass

    @six.add_metaclass(type)
    class D(B):
        pass

    @six.add_metaclass(type)
    class E(B):
        pass

    @six.add_metaclass(type)
    class F(C):
        pass

    # Testing all cases
    returned = get_all_subclasses(A)
    assert returned == set([D, E, F, B, C])


# Generated at 2022-06-11 00:34:52.724172
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Lets build a test classes for this function
    class TestClass(object):
        pass

    class TestClassA(TestClass):
        pass

    class TestClassB(TestClass):
        pass

    class TestClassAA(TestClassA):
        pass

    class TestClassAB(TestClassA):
        pass

    class TestClassBA(TestClassB):
        pass

    class TestClassBB(TestClassB):
        pass

    class OtherClass(object):
        pass

    assert frozenset(get_all_subclasses(TestClass)) == frozenset([TestClassA, TestClassB, TestClassAA, TestClassAB, TestClassBA, TestClassBB])
    assert frozenset(get_all_subclasses(TestClassA)) == frozenset([TestClassAA, TestClassAB])

# Generated at 2022-06-11 00:34:59.077034
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        pass

    class A1(A):
        pass

    class A2(A):
        pass

    class A1a(A1):
        pass

    class A1b(A1):
        pass

    class A1b1(A1b):
        pass

    class A2a(A2):
        pass

    class A2b(A2):
        pass

    class B(object):
        pass

    class B1(B):
        pass

    # Test basic scenarios:
    # Test that the method returns all subclasses
    assert set(get_all_subclasses(A)) == set([A1, A2, A1a, A1b, A1b1, A2a, A2b])

# Generated at 2022-06-11 00:35:06.327098
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class B(object):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(E):
        pass

    class H(F):
        pass

    classes = get_all_subclasses(B)

    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert G in classes
    assert H in classes

# Generated at 2022-06-11 00:35:15.443469
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.plugins import ActionModule
    from ansible.plugins.action import copy
    from ansible.plugins.action import file
    from ansible.plugins.action import lineinfile
    from ansible.plugins.action import script
    from ansible.plugins.action import shell
    from ansible.plugins.action import synchronize
    from ansible.plugins.action import template

    assert file.ActionModule in get_all_subclasses(ActionModule)
    assert shell.ActionModule in get_all_subclasses(ActionModule)
    assert template.ActionModule in get_all_subclasses(ActionModule)
    assert copy.ActionModule in get_all_subclasses(ActionModule)
    assert script.ActionModule in get_all_subclasses(ActionModule)
    assert synchronize.ActionModule in get_all_subclasses(ActionModule)


# Generated at 2022-06-11 00:35:20.435015
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    assert get_all_subclasses(A) == {B, C}
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set()

# Generated at 2022-06-11 00:35:29.051949
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for get_all_subclasses

    These tests are based on the Python reference, but it works for version 2 and 3.
    Checked on Python 2.7.5 and 3.2.5
    >>> class A(object): pass
    ...
    >>> class B(A): pass
    ...
    >>> class C(A): pass
    ...
    >>> class D(B,C): pass
    ...
    >>> class E(B,C): pass
    ...
    >>> print(test_get_all_subclasses())
    [<class '__main__.D'>, <class '__main__.E'>, <class '__main__.B'>, <class '__main__.C'>]
    '''
    all_subclasses = get_all_subclasses(A)

# Generated at 2022-06-11 00:35:39.985585
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Parent(object): pass
    class ChildA(Parent): pass
    class ChildB(Parent): pass
    class ChildC(Parent): pass

    class GrandChildA(ChildA): pass
    class GrandChildB(ChildA): pass
    class GrandChildC(ChildB): pass
    class GrandChildD(ChildB): pass
    class GrandChildE(ChildC): pass
    class GrandChildF(ChildC): pass

    class GreatGrandChildA(GrandChildA): pass
    class GreatGrandChildB(GrandChildA): pass
    class GreatGrandChildC(GrandChildB): pass
    class GreatGrandChildD(GrandChildB): pass
    class GreatGrandChildE(GrandChildC): pass
    class GreatGrandChildF(GrandChildC): pass
    class GreatGrandChildG(GrandChildD): pass

# Generated at 2022-06-11 00:35:43.081142
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    assert set(get_all_subclasses(A)) == set((A, B, C))

# Generated at 2022-06-11 00:35:54.501922
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test class with no subclass
    class Test_get_all_subclasses:
        def __init__(self):
            pass

    # Test class with subclass
    class Test_with_subclass(Test_get_all_subclasses):
        def __init__(self):
            pass

    # Test class with more subclasses
    class Test_subsubclass(Test_with_subclass):
        def __init__(self):
            pass

    class Test_subsubsubclass(Test_subsubclass):
        def __init__(self):
            pass

    class Test_subsubsubsubclass(Test_subsubsubclass):
        def __init__(self):
            pass

    # Test class with 2 subclasses

# Generated at 2022-06-11 00:36:01.310732
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(E):
        pass
    classes = get_all_subclasses(A)
    assert A in classes
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert len(classes) == 6

# Generated at 2022-06-11 00:36:08.090949
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.copy import ActionModule as CopyActionModule
    from ansible.plugins.action.template import ActionModule as TemplateActionModule
    from ansible.plugins.action.synchronize import ActionModule as SynchronizeActionModule

    # Testing the retrieval of all subclasses of ActionBase
    subclasses = get_all_subclasses(ActionBase)
    assert(len(subclasses) == 5)
    assert(CopyActionModule in subclasses)
    assert(TemplateActionModule in subclasses)
    assert(SynchronizeActionModule in subclasses)


# Generated at 2022-06-11 00:36:15.019234
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a class for test
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    # Set of all subclasses of A
    result = get_all_subclasses(A)
    # Set of classes for expected result
    expected = {B, C, D, E}
    assert set(result) == set(expected)

# Generated at 2022-06-11 00:36:53.625412
# Unit test for function get_all_subclasses

# Generated at 2022-06-11 00:37:00.661153
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert set([C, D]) == get_all_subclasses(A)

    class E(D):
        pass

    assert set([C, D, E]) == get_all_subclasses(A)



# Generated at 2022-06-11 00:37:09.871386
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(F):
        pass
    class I(object):
        pass
    classes = get_all_subclasses(A)
    assert all(_ in classes for _ in [B, C, D, E, F, G, H])
    assert I not in classes
    assert not get_all_subclasses(I)

# Generated at 2022-06-11 00:37:21.655868
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a test class hierarchy
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass
    class F(D, C): pass

    # Retrieve all subclasses of class A
    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 5
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses

    # Retrieve all subclasses of class B
    subclasses = get_all_subclasses(B)
    assert len(subclasses) == 2
    assert D in subclasses
    assert F in subclasses

    # Retrieve all subclasses of class C
    subclasses = get_all_subclasses(C)

# Generated at 2022-06-11 00:37:28.677791
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    class F(E):
        pass

    class G(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(E) == set([F, G])
    assert get_all_subclasses(G) == set([])

# Generated at 2022-06-11 00:37:39.038459
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestClass1:
        pass

    class TestClass2(TestClass1):
        pass

    class TestClass3(TestClass1):
        pass

    class TestClass4(TestClass2):
        pass

    class TestClass5(TestClass3):
        pass

    class TestClass6(TestClass3):
        pass

    class TestClass7(TestClass5):
        pass

    class TestClass8(TestClass6):
        pass

    assert get_all_subclasses(TestClass1) == set([TestClass2, TestClass3, TestClass4, TestClass5, TestClass6, TestClass7, TestClass8])
    assert get_all_subclasses(TestClass2) == set([TestClass4])

# Generated at 2022-06-11 00:37:44.460221
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(B):
        pass

    class G(C):
        pass

    class H(C):
        pass

    class I(D):
        pass

    class J(D):
        pass

    class K:
        pass

    class L(A, K):
        pass

    subclasses = get_all_subclasses(A)
    assert set(subclasses) == set([B, C, D, E, F, G, H, I, J, L])

# Generated at 2022-06-11 00:37:54.897822
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function get_all_subclasses
    '''
    class Test(object):
        '''Class Test used to test get_all_subclasses'''
        pass
    class Test1(Test):
        '''Class Test1 used to test get_all_subclasses'''
        pass
    class Test11(Test1):
        '''Class Test1 used to test get_all_subclasses'''
        pass
    class Test2(Test):
        '''Class Test2 used to test get_all_subclasses'''
        pass
    cls = Test

    # Check that Test class has Test1 and Test2 as subclasses
    assert cls.__subclasses__() == [Test1, Test2]
    # Check that Test2 class has no subclasses
    assert Test2.__subclasses__() == []


# Generated at 2022-06-11 00:37:58.325649
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(A):
        pass
    class F(E):
        pass
    class G():
        pass
    A_subclasses = get_all_subclasses(A)
    assert set(A_subclasses) == {B, C, D, E, F}
    assert set(get_all_subclasses(G)) == {G}

# Generated at 2022-06-11 00:38:07.060667
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B:
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(D,E):
        pass

    a = A()
    assert(set(get_all_subclasses(A)) == {C, D, E, F})
    assert(set(get_all_subclasses(B)) == set())
    assert(set(get_all_subclasses(C)) == {D, E, F})
    assert(set(get_all_subclasses(D)) == {F})
    assert(set(get_all_subclasses(E)) == {F})
    assert(set(get_all_subclasses(F)) == set())

# Generated at 2022-06-11 00:38:16.546827
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Animal(object): pass
    class Mammal(Animal): pass
    class Fish(Animal): pass
    class Carnivore(Mammal): pass
    class Herbivore(Mammal): pass
    class Placental(Mammal): pass
    class Marsupial(Mammal): pass
    class Dog(Carnivore): pass
    class Lion(Carnivore): pass
    class Human(Placental): pass
    class Koala(Marsupial): pass
    assert get_all_subclasses(Animal) == set([Mammal, Fish, Carnivore, Herbivore, Placental, Marsupial, Dog, Lion, Human, Koala])

# Generated at 2022-06-11 00:38:20.688984
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass # won't be found
    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-11 00:38:34.144354
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(D):
        pass
    class G(D):
        pass
    ret = get_all_subclasses(A)
    assert len(ret) == 7
    assert F in ret
    assert G in ret
    assert C in ret
    assert D in ret
    assert E in ret
    assert B in ret
    assert A not in ret

# Generated at 2022-06-11 00:38:41.086663
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Unit test for get_all_subclasses

    :returns: None
    """
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    # Found classes must be equal to expected classes
    assert get_all_subclasses(A) == {B, C, D, E, F, G}

# Generated at 2022-06-11 00:38:45.570097
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(B):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-11 00:38:50.800550
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D, E):
        pass
    class G(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])

# Generated at 2022-06-11 00:38:59.151695
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(A):
        pass

    class F(E):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(F):
        pass

    class J(I):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in subclasses
    assert H in subclasses
    assert I in subclasses
    assert J in subclasses


# Generated at 2022-06-11 00:39:02.658970
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    assert set([B, C, D]) == get_all_subclasses(A)
    assert set([C]) == get_all_subclasses(B)
    assert set() == get_all_subclasses(C)



# Generated at 2022-06-11 00:39:05.619828
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E(C): pass

    assert get_all_subclasses(A) == {B, C, D, E}

# Generated at 2022-06-11 00:39:14.685310
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(E):
        pass

    class I(H):
        pass

    class J(C):
        pass

    class K(J):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H, I, J, K])
    assert set(get_all_subclasses(B)) == set([E, H, I])
    assert set(get_all_subclasses(C)) == set([F, G, J, K])

# Generated at 2022-06-11 00:39:23.762336
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    # Getting all subclasses of A
    subclasses_A = get_all_subclasses(A)

    assert B in subclasses_A
    assert C in subclasses_A
    assert D in subclasses_A
    assert E in subclasses_A
    assert F in subclasses_A

# Generated at 2022-06-11 00:39:31.254136
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys
    from types import ModuleType
    from ansible.module_utils._text import to_text

    class ParentClass(object):
        pass
    class ChildClass(ParentClass):
        pass
    class GrandChildClass(ChildClass):
        pass

    # Add an object to the module which has a __subclasses__ attribute
    # but is not a class
    class Foo(object):
        pass
    ParentClass.subclasses = Foo()

    # Assert that get_subclasses returns a set
    subclasses = get_all_subclasses(ParentClass)
    assert isinstance(subclasses, set), "get_subclasses is not a set"
    assert len(subclasses) == 2, "get_subclasses did not return 2 items.  It returned %s" % to_text(subclasses)
    assert ChildClass in subclasses

# Generated at 2022-06-11 00:39:51.628746
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(E):
        pass

    class G(E):
        pass

    class H(object):
        pass

    class I(object):
        pass

    class J(I):
        pass

    class TestGetAllSubclasses(unittest.TestCase):
        def test_get_all_subclasses(self):
            self.assertEqual(set(get_all_subclasses(A)), {B, C, D, E, F, G})
            self.assertEqual(set(get_all_subclasses(H)), set())
            all_objects = type.__subclasses

# Generated at 2022-06-11 00:39:59.045175
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass
    class F(D): pass
    class G(C): pass
    class H(G): pass
    class I(H): pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H, I])
    assert set(get_all_subclasses(A)) == set(get_all_subclasses(A))



# Generated at 2022-06-11 00:40:06.368985
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Math:
        pass
    class Geometry(Math):
        pass
    class Calculus(Math):
        pass
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass
    class G(D):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(G):
        pass
    assert set(get_all_subclasses(Math)) == {Geometry, Calculus}
    assert set(get_all_subclasses(A)) == {B, C, D, E, F}
    assert set(get_all_subclasses(C)) == {E, F}
    assert set

# Generated at 2022-06-11 00:40:16.589768
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a simple class hierarchy
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    # Get all classes from A
    classes = get_all_subclasses(A)
    assert len(classes) == 4
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes

    # Get all classes from B
    classes = get_all_subclasses(B)
    assert len(classes) == 3
    assert D in classes
    assert E in classes
    assert C not in classes

    # Get all classes from C
    classes = get_all_subclasses(C)
    assert len(classes) == 0

    # Get all classes from D

# Generated at 2022-06-11 00:40:18.807025
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(list) == set([list, tuple])
    assert get_all_subclasses(tuple) == set([tuple])

# Generated at 2022-06-11 00:40:26.197152
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    assert set([B, D]) == get_all_subclasses(A)
    assert set([C, D, E, F]) == get_all_subclasses(A)
    assert set([E, F]) == get_all_subclasses(C)
    assert set([F]) == get_all_subclasses(E)

# Generated at 2022-06-11 00:40:36.844490
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    assert get_all_subclasses(A) == set([B, C, D]), \
        'The returned set should be equivalent to set([B, C, D])'
    assert get_all_subclasses(B) == set([]), \
        'The returned set should be equivalent to set([])'
    assert get_all_subclasses(C) == set([D]), \
        'The returned set should be equivalent to set([D])'
    assert get_all_subclasses(D) == set([]), \
        'The returned set should be equivalent to set([])'
    assert get_all_subclasses(E)

# Generated at 2022-06-11 00:40:40.491718
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    assert get_all_subclasses(A) == set([B, C, D])
    class E: pass
    assert get_all_subclasses(E) == set([])

# Generated at 2022-06-11 00:40:45.287590
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(D)) == set([])
    assert set(get_all_subclasses(E)) == set([])

# Generated at 2022-06-11 00:40:50.620563
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Simple function to test function get_all_subclasses
    '''
    class A(object):
        pass

    class B(object):
        pass

    class C(object):
        pass

    class AB(A):
        pass

    class AC(A):
        pass

    class ABC(AB, C):
        pass

    assert get_all_subclasses(A) == set([AB, AC, ABC])

# Generated at 2022-06-11 00:41:16.514288
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(C):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F}



# Generated at 2022-06-11 00:41:20.439920
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    # C class has not been used
    class C(A):
        pass

    class D(B):
        pass

    assert D in get_all_subclasses(A)

# Generated at 2022-06-11 00:41:26.369532
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C0(object): pass
    class C1(C0): pass
    class C2(C0): pass
    class C3(C2): pass
    class C4(C2): pass

    assert get_all_subclasses(C0) == {C1, C2, C3, C4}

# Generated at 2022-06-11 00:41:36.721402
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import types
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(object):
        pass

    class F(object):
        pass

    class G(F):
        pass
    # the decorator causes this function to be run when the test runs,
    # and it also causes it to be an alias for the function name.
    @unittest.skipIf(not hasattr(types, 'ClassType'), 'python2 only test')
    def test_get_all_subclasses_compatibility():
        '''
        Test get_all_subclasses with old style class
        '''
        class OldStyle(object):
            pass

        class OldChildStyle(OldStyle):
            pass

# Generated at 2022-06-11 00:41:45.199518
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test get_all_subclasses
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    dataloader = DataLoader()
    inventory = InventoryManager(loader=dataloader)
    variable_manager = VariableManager(loader=dataloader, inventory=inventory)

# Generated at 2022-06-11 00:41:54.697270
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        '''
        A simple class which is used for testing our function get_all_subclasses in this file.
        '''
        pass

    class B(A):
        '''
        A class B which inherits from A
        '''
        pass

    class C(A):
        '''
        A class C which inherits from A
        '''
        pass


    class D(B):
        '''
        A class D which inherits from B
        '''
        pass

    class E(B):
        '''
        A class E which inherits from B
        '''
        pass

    class F(C):
        '''
        A class F which inherits from C
        '''
        pass

    assert A in get_all_subclasses(A)

# Generated at 2022-06-11 00:41:57.896297
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Foo(object):
        pass

    class Bar(object):
        pass

    class FooBar(Foo, Bar):
        pass

    class Other(object):
        pass

    assert get_all_subclasses(Foo) == {FooBar}

# Generated at 2022-06-11 00:42:03.034282
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(C):
        pass

    class G(F):
        pass

    # Recursively find all subclasses for A class
    assert set(get_all_subclasses(A)) == {B, C, D, E, F, G}

# Generated at 2022-06-11 00:42:10.595820
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(A):
        pass

    class D1(D):
        pass

    class D2(D):
        pass

    class D11(D1):
        pass

    class D22(D2):
        pass

    assert get_all_subclasses(A) == set([B, C, D, D1, D11, D2, D22, E])
    assert get_all_subclasses(B) == set([C])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set([D1, D11, D2, D22])

# Generated at 2022-06-11 00:42:15.088673
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert get_all_subclasses(A) == get_all_subclasses(B) == get_all_subclasses(C) == get_all_subclasses(D)