

# Generated at 2022-06-11 00:32:40.699332
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    classes = get_all_subclasses(A)

    assert classes == set([B, C, D])

    classes = get_all_subclasses(C)

    assert classes == set([D])

    classes = get_all_subclasses(A)

    assert classes == set([B, C, D])



# Generated at 2022-06-11 00:32:45.047752
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass

    # This is the list of all classes below A in the class hierarchy
    result = set([B, C, D])

    # Using the tested function, we look for all subclasses below A
    print(get_all_subclasses(A))
    assert get_all_subclasses(A) == result

# Generated at 2022-06-11 00:32:52.567288
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C, D):
        pass

    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert not set(get_all_subclasses(B)).intersection(set(get_all_subclasses(C)))

# Generated at 2022-06-11 00:32:59.984114
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(D): pass
    class F(E): pass
    class G(F): pass

    assert set([A,B,C,D,E,F,G]) == get_all_subclasses(A)


# Generated at 2022-06-11 00:33:04.292313
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils import facts

    subclasses = get_all_subclasses(facts.FactsBase)
    # Asserting that not empty
    assert len(subclasses) > 0
    # Asserting that all the classes are indeed subclass of FactsBase
    from collections import Iterable
    assert all(issubclass(sc, facts.FactsBase) for sc in subclasses)

# Generated at 2022-06-11 00:33:13.653659
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test scenario for function :py:func:`get_all_subclasses`.
    We create the following class hierarchy and then test that :py:func:`get_all_subclasses` behaves
    as expected.
    The class hierarchy::

        object
            |
            |
        A
            |
            |
        B   C
            | |
            | |
        D   E
    """
    # pylint: disable=too-few-public-methods

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    # Check that object is correctly considered here
    assert object in get_all_subclasses(object)
    # Check that get_all_subclasses

# Generated at 2022-06-11 00:33:18.929348
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(object):
        pass

    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 2
    assert B in subclasses
    assert C in subclasses
    assert D not in subclasses

# Generated at 2022-06-11 00:33:28.530732
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class A1(A):
        pass
    class A2(A):
        pass
    class A11(A1):
        pass
    class A22(A2):
        pass
    class A33(A2):
        pass
    class A111(A11):
        pass
    assert get_all_subclasses(A) == set([A1, A11, A111, A2, A22, A33])
    assert get_all_subclasses(A1) == set([A11, A111])
    assert get_all_subclasses(A11) == set([A111])
    assert get_all_subclasses(A2) == set([A22, A33])

# Generated at 2022-06-11 00:33:38.439080
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import abc, sys

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(F):
        pass

    class H(D, F):
        pass

    class I(E):
        pass

    class J(I):
        pass

    class K(H):
        pass

    class L(K):
        pass

    class M(abc.ABCMeta):
        pass

    class N(object):
        __metaclass__ = M

    # check the output for python3

# Generated at 2022-06-11 00:33:49.395284
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    all_subclasses = get_all_subclasses(A)
    for subclass in (B, C, D, E):
        assert subclass in all_subclasses

    all_subclasses = get_all_subclasses(B)
    for subclass in (D, E):
        assert subclass in all_subclasses

    all_subclasses = get_all_subclasses(D)
    for subclass in (E,):
        assert subclass in all_subclasses

    all_subclasses = get_all_subclasses(E)
    assert 0 == len(all_subclasses)



# Generated at 2022-06-11 00:34:02.472491
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import ansible.module_utils.basic
    import ansible.module_utils.facts
    import ansible.module_utils.six
    import ansible.module_utils.urls
    import ansible.module_utils.wait_for
    import ansible.module_utils.network.common.netconf

    assert ansible.module_utils.basic.AnsibleModule in get_all_subclasses(object)
    assert ansible.module_utils.facts.AnsibleFacts in get_all_subclasses(object)
    assert ansible.module_utils.six.binary_type in get_all_subclasses(object)
    assert ansible.module_utils.urls.ConnectionError in get_all_subclasses(object)
    assert ansible.module_utils.wait_for.WaitFor in get_all_subclasses

# Generated at 2022-06-11 00:34:06.289136
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert set(get_all_subclasses(object)) == set([type, A, B, C, D])
    assert set(get_all_subclasses(A)) == set([B, C, D])

# Generated at 2022-06-11 00:34:13.946914
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    classes = get_all_subclasses(A)

    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert len(get_all_subclasses(A)) == 5

# Generated at 2022-06-11 00:34:24.895862
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    subclass_a1 = type('SubclassA1', (object,), {})
    subclass_a2 = type('SubclassA2', (object,), {})
    subclass_b1 = type('SubclassB1', (object,), {})
    subclass_b2 = type('SubclassB2', (object,), {})
    subclass_b3 = type('SubclassB3', (object,), {})
    subclass_b4 = type('SubclassB4', (object,), {})
    subclass_c1 = type('SubclassC1', (object,), {})
    subclass_c2 = type('SubclassC2', (object,), {})
    subclass_c3 = type('SubclassC3', (object,), {})
    subclass_c4 = type('SubclassC4', (object,), {})

# Generated at 2022-06-11 00:34:37.077637
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a(object): pass
    class b(object): pass
    class c(a): pass
    class d(a): pass
    class e(b): pass
    class f(c): pass
    class g(d): pass
    class h(f): pass
    class i(g): pass
    class j(g): pass
    class k(j): pass
    class l(e): pass

    assert set([c, d, f, g, h, i, j, k]) == get_all_subclasses(a)
    assert set([e, l]) == get_all_subclasses(b)
    assert set([f, h]) == get_all_subclasses(c)
    assert set([g, i, j, k]) == get_all_subclasses(d)
    assert set([l]) == get_all_

# Generated at 2022-06-11 00:34:45.058737
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Creates a class tree like this with get_all_subclasses:
    #     A
    #   /   \
    #  B     C
    # / \   / \
    # D  E  F  G
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    assert set(get_all_subclasses(A)) == set([D, E, F, G, B, C])

# Generated at 2022-06-11 00:34:55.873394
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    assert get_all_subclasses(A) == set(B, C, D)

    class E(A):
        pass

    class F(A):
        pass

    class G(F):
        pass

    assert get_all_subclasses(A) == set(B, C, D, E, F, G)

    class H(object):
        pass

    class I(H):
        pass

    assert get_all_subclasses(A) == set(B, C, D, E, F, G)
    assert get_all_subclasses(H) == set(I)



# Generated at 2022-06-11 00:35:05.188700
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses

    :note: This function is only used for unit test, not part of the public API
    '''
    # Define a class for test
    class TestClass(object):
        pass

    # Define a subclass
    class SubClass(TestClass):
        pass

    # Define another subclass
    class SubSubClass(SubClass):
        pass

    # Check the result
    assert(get_all_subclasses(TestClass) == {SubClass, SubSubClass})
    assert(get_all_subclasses(SubClass) == {SubSubClass})
    assert(get_all_subclasses(SubSubClass) == set())

# Generated at 2022-06-11 00:35:12.742725
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(object):
        pass

    assert set([B, C, D]) == get_all_subclasses(A)
    assert set([C, D]) == get_all_subclasses(B)
    assert set([]) == get_all_subclasses(C)
    assert set([]) == get_all_subclasses(D)
    assert set([]) == get_all_subclasses(E)

# Generated at 2022-06-11 00:35:24.144213
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(E):
        pass
    assert get_all_subclasses(A) == {B, C, D, E, F}
    assert get_all_subclasses(A) == {B, C, D, E, F}
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == {D, E, F}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == {F}
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-11 00:35:36.556227
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define class A
    class A(object):
        pass
    # Define class B
    class B(A):
        pass
    # Define class C
    class C(B):
        pass

    s = get_all_subclasses(A)
    # Assert that class B and class C were located during the search
    assert B in s
    assert C in s
    # Assert that there were only two subclasses and that class A was not included
    assert len(s) == 2
    assert A not in s

# Generated at 2022-06-11 00:35:40.944101
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    assert get_all_subclasses(A) == {B, C, D, E}

# Generated at 2022-06-11 00:35:50.921295
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F}
    assert get_all_subclasses(B) == {D, E}
    assert get_all_subclasses(C) == {F}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-11 00:36:01.810206
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Make sure the function get_all_subclasses() works
    """
    import re

    class Base(object):
        pass

    class First(Base):
        pass

    class Second(Base):
        pass

    class Third(Second):
        pass

    base = Base
    perms = set(get_all_subclasses(base))

    # make sure the correct classes are returned
    assert_mesg = 'get_all_subclasses did not return the correct classes'
    assert len(perms) == 3, assert_mesg
    assert First in perms, assert_mesg
    assert Second in perms, assert_mesg
    assert Third in perms, assert_mesg

    # make sure there are no other classes
    assert_mesg = 'get_all_subclasses returned more classes than it should'
   

# Generated at 2022-06-11 00:36:10.135140
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_all_subclasses(self):
            class A(object):
                pass
            class B(A):
                pass
            class C(B):
                pass
            class D(B):
                pass
            class E(D):
                pass
            class F(E):
                pass
            class G(B):
                pass
            class H(G):
                pass
            class I(B):
                pass
            class J(B):
                pass

            expected_classes = frozenset([B, C, D, E, F, G, H, I, J])
            self.assertEqual(get_all_subclasses(B), expected_classes)

# Generated at 2022-06-11 00:36:19.952925
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types

    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D]), 'Basic test failed'

# Generated at 2022-06-11 00:36:53.920918
# Unit test for function get_all_subclasses

# Generated at 2022-06-11 00:36:59.775394
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(G):
        pass

    class I(E):
        pass

    classes = get_all_subclasses(A)
    assert set(classes) == set([B, C, D, E, F, G, H, I])



# Generated at 2022-06-11 00:37:09.199126
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(C): pass
    class H(D): pass
    class I(D): pass
    class J(E): pass
    class K(E): pass
    class L(F): pass
    class M(F): pass
    class N(G): pass
    class O(G): pass
    class P(H): pass
    class Q(H): pass
    class R(I): pass
    class S(I): pass
    class T(J): pass
    class U(J): pass
    class V(K): pass
    class W(K): pass
    class X(L): pass
    class Y(L): pass
   

# Generated at 2022-06-11 00:37:14.136361
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])

# Generated at 2022-06-11 00:37:24.308019
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C():
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(F):
        pass

    class H(E):
        pass

    assert set(get_all_subclasses(C)) == set([D, E, F, G, H])

# Generated at 2022-06-11 00:37:29.168308
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types
    class Testing(object):
        pass
    class Testing1(Testing):
        pass
    class Testing2(Testing):
        pass
    class Testing3(Testing):
        pass
    class Testing4(Testing2):
        pass
    assert get_all_subclasses(Testing) == set([Testing1, Testing2, Testing3, Testing4])

# Generated at 2022-06-11 00:37:39.437042
# Unit test for function get_all_subclasses

# Generated at 2022-06-11 00:37:50.503292
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        def __init__(self):
            pass
    class B(A):
        def __init__(self):
            pass
    class C(A):
        def __init__(self):
            pass
    class D(B):
        def __init__(self):
            pass
    class E(D):
        def __init__(self):
            pass
    class F(C, D):
        def __init__(self):
            pass

    # Number of direct subclasses of A
    assert(len(get_all_subclasses(A)) == 4)
    # Get all subclasses of A
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_

# Generated at 2022-06-11 00:38:00.130987
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass
    class G(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([D, G])
    assert get_all_subclasses(C) == set([E, F])
    assert get_all_subclasses(D) == set([G])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])
    assert get_all_subclasses(G) == set([])

# Generated at 2022-06-11 00:38:04.526893
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(A):
        pass

    class F(object):
        pass

    classes = set([B, C, D, E, A])
    assert classes == get_all_subclasses(A)

# Generated at 2022-06-11 00:38:12.436697
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a class structure
    class A: pass
    class B: pass
    class C: pass
    class D: pass
    class E: pass
    class F(A): pass
    class G(A): pass
    class H(G): pass
    class I(F): pass
    class J(A, B): pass
    class K(J): pass
    class L(C): pass
    class M(D): pass
    # Check that the function find all the classes
    assert set(get_all_subclasses(A)) == { F, G, H, I, J, K }
    assert set(get_all_subclasses(B)) == { J, K }
    assert set(get_all_subclasses(F)) == { I }
    assert set(get_all_subclasses(J)) == { K }
   

# Generated at 2022-06-11 00:38:20.479835
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class AA(A):
        pass

    class AAA(AA):
        pass

    class AB(A):
        pass

    class ABA(AB):
        pass

    # Ensure we didn't forget to define a test class
    assert len(A.__subclasses__()) == 2

    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 4
    for i, cls in enumerate([AAA, AA, ABA, AB]):
        assert cls in subclasses
        assert cls.__name__ in [sc.__name__ for sc in subclasses]

# Generated at 2022-06-11 00:38:27.181854
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(D):
        pass

    # Here we are sure of what are the subclasses of A
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

    class G(E):
        pass

    class H(F):
        pass

    class I(F):
        pass

    assert set(get_all_subclasses(A)) != set([B, C, D, E, F, G, H, I])

# Generated at 2022-06-11 00:38:36.849311
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.utils._collections import ImmutableDict
    class A(ImmutableDict): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(D): pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([])
    assert get_all_subclasses(C) == set([D, E])
    assert get_all_subclasses(D) == set([E])
    assert get_all_subclasses(E) == set([])

# Generated at 2022-06-11 00:38:54.307443
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Parent(object):
        pass
    class Child1(Parent):
        pass
    class Child2(Parent):
        pass
    class Child3(Child1):
        pass
    class Child4(Child2):
        pass
    class Child5(Child3):
        pass

    all_subclasses = get_all_subclasses(Parent)
    assert Child1 in all_subclasses
    assert Child2 in all_subclasses
    assert Child3 in all_subclasses
    assert Child4 in all_subclasses
    assert Child5 in all_subclasses



# Generated at 2022-06-11 00:39:02.305944
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # setup
    class BaseClass(object):
        pass
    class AClass(BaseClass):
        pass
    class BClass(BaseClass):
        pass
    class CClass(BaseClass):
        pass
    class A1Class(AClass):
        pass
    class B1Class(BClass):
        pass
    class B2Class(BClass):
        pass
    class C1Class(CClass):
        pass

    # test
    classes = get_all_subclasses(BaseClass)
    classes = set(classes)

    # assert
    assert(AClass in classes)
    assert(BClass in classes)
    assert(CClass in classes)
    assert(A1Class in classes)
    assert(B1Class in classes)
    assert(B2Class in classes)
    assert(C1Class in classes)

# Generated at 2022-06-11 00:39:05.898981
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Not that the test is valid only with the content of this file
    # and will fail if other classes are added in _utils folder
    assert get_all_subclasses(dict) == set()
    assert get_all_subclasses(Exception) == set()
    assert get_all_subclasses(Warning) == set()

# Generated at 2022-06-11 00:39:09.712192
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])


# Find all subclasses of a class

# Generated at 2022-06-11 00:39:23.323973
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class Base(object):
        pass

    class ChildA(Base):
        pass

    class ChildB(Base):
        pass

    class GrandChildA(ChildA):
        pass

    class GrandChildB(ChildB):
        pass

    class GrandChildC(ChildB):
        pass

    class GrandGrandChildA(GrandChildA):
        pass

    class GrandGrandChildB(GrandChildB):
        pass

    class GrandGrandChildC(GrandChildC):
        pass

    class GrandGrandChildC(GrandChildC):
        pass

    class GrandGrandGrandChildA(GrandGrandChildA):
        pass

    class GrandGrandGrandChildB(GrandGrandChildB):
        pass

    class GrandGrandGrandChildC(GrandGrandChildC):
        pass

    class C1(object):
        pass


# Generated at 2022-06-11 00:39:30.928230
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types
    # Create a known tree structure
    class A(object): pass
    class B(object): pass
    class C(object): pass
    class A1(A): pass
    class A2(A): pass
    class B1(B): pass
    class B2(B): pass
    class C1(C): pass
    class C2(C): pass
    class A1_1(A1): pass
    class A1_2(A1): pass
    class A2_1(A2): pass
    class A2_2(A2): pass
    class B1_1(B1): pass
    class B1_2(B1): pass
    class B2_1(B2): pass
    class B2_2(B2): pass
    class C1_1(C1): pass
   

# Generated at 2022-06-11 00:39:34.572364
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert set([A, B, C, D]) == get_all_subclasses(A)

# Generated at 2022-06-11 00:39:39.585405
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E])

# Generated at 2022-06-11 00:39:50.620676
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.utils._pytest.plugins.module_utils import get_all_subclasses
    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    x = B()
    y = D()
    z = E()

    # Set of classes for regression test
    classes = set([A, B, C, D, E, F])
    assert set(get_all_subclasses(x.__class__)) == classes
    assert set(get_all_subclasses(y.__class__)) == classes
    assert set(get_all_subclasses(z.__class__)) == classes

# Generated at 2022-06-11 00:39:59.134964
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class C(object):
        pass

    class C1(C):
        pass

    class C3(C):
        pass

    class C2(C1):
        pass

    assert set(C.__subclasses__()) == set([C1, C3])
    assert set(C2.__subclasses__()) == set([])
    assert set(C1.__subclasses__()) == set([C2])
    assert set(C3.__subclasses__()) == set([])
    assert set(get_all_subclasses(C)) == set([C1, C2, C3])
# test_get_all_subclasses()

# Generated at 2022-06-11 00:40:25.380020
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.ping import ActionModule as PingActionModule
    from ansible.plugins.connection import ConnectionBase
    from ansible.plugins.shell import ShellModule

    # Test success case
    ping_actions = get_all_subclasses(ActionBase)
    assert PingActionModule in ping_actions
    assert ShellModule in ping_actions

    # Test empty case
    no_actions = get_all_subclasses(ConnectionBase)
    assert not list(no_actions)

# Generated at 2022-06-11 00:40:36.100159
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base(object):
        pass
    class IntermediateA(Base):
        pass
    class IntermediateB(Base):
        pass
    class IntermediateC(IntermediateA):
        pass
    class IntermediateD(IntermediateB):
        pass
    class IntermediateE(IntermediateC):
        pass
    class IntermediateF(IntermediateC):
        pass
    class Child(IntermediateE):
        pass
    class GrandChild(Child):
        pass

    # Test that function get_all_subclasses return the expected list of classes
    subclasses = get_all_subclasses(Base)
    assert GrandChild in subclasses
    assert Child in subclasses
    assert IntermediateF in subclasses
    assert IntermediateE in subclasses
    assert IntermediateD in subclasses
    assert IntermediateC in subclasses
    assert IntermediateB in subclasses

# Generated at 2022-06-11 00:40:44.870145
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(C, D):
        pass

    expected = [A, B, C, D, E]

    class test_get_all_subclasses(unittest.TestCase):

        def test_get_all_subclasses_A(self):
            real = get_all_subclasses(A)
            self.assertEqual(len(expected), len(real), 'Found unexpected classes')
            for cls in expected:
                self.assertIn(cls, real, 'Expected class {0} not found'.format(cls))

        def test_get_all_subclasses_C(self):
            real = get_all

# Generated at 2022-06-11 00:40:51.483353
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(B): pass
    class E(A): pass
    class F(E): pass
    class G(E): pass
    class H(F): pass
    class I(G): pass
    class J(I): pass
    class K(I): pass
    class L(J): pass
    class M(L): pass

    cls_list = [A, B, C, D, E, F, G, H, I, J, K, L, M]  # This is the list of classes we should
                                                       # find.  It will be used for testing
                                                       # purposes.


# Generated at 2022-06-11 00:41:01.668795
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Testing class A which inherits B, C and E, and contains a specialized implementation of B
    # class A can be used as a parent class to function get_all_subclasses
    class A:
        pass
    class B:
        pass
    class C:
        pass
    class E:
        pass
    class B_A(B):
        pass
    class B_B(B):
        pass
    class C_A(C):
        pass
    class C_B(C):
        pass
    class E_A(E):
        pass
    class E_B(E):
        pass

    A.__bases__ += (B, C, E)
    B.__bases__ += (B_A, B_B)
    C.__bases__ += (C_A, C_B)
   

# Generated at 2022-06-11 00:41:07.612433
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(F):
        pass
    class H(F):
        pass
    class I(G):
        pass

    expected = set([B, C, D, E, F, G, H, I])
    result = get_all_subclasses(A)
    assert result == expected

# Generated at 2022-06-11 00:41:12.623732
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E(C): pass

    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == {D}
    assert get_all_subclasses(C) == {D, E}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-11 00:41:22.169393
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(B):
        pass
    class G(B):
        pass
    class H(D):
        pass
    assert get_all_subclasses(A) == set([B, C, E, F, G, D, H])
    assert get_all_subclasses(B) == set([E, F, G])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([H])
    assert get_all_subclasses(D) == set([H])
    assert get_all_subclasses(E) == set([])
    assert get

# Generated at 2022-06-11 00:41:33.798187
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import sys
    # Create some test classes
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass

    # Create a test class with some subclasses
    class TestClass(unittest.TestCase):
        def test_get_all_subclasses(self):
            expected = {A, B, C, D}
            self.assertEqual(set(get_all_subclasses(A)), expected)
            self.assertEqual(set(get_all_subclasses(B)), {B})
            self.assertEqual(set(get_all_subclasses(C)), {C, D})
            self.assertEqual(set(get_all_subclasses(D)), {D})
            self

# Generated at 2022-06-11 00:41:42.734645
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test the utility function get_all_subclasses.
    '''
    import unittest

    class A(object): pass
    class B(object): pass
    class C(object): pass
    class D(A): pass
    class E(A): pass
    class F(D): pass
    class G(D): pass
    class H(G): pass
    class I(E): pass
    class J(A): pass
    class K(J): pass
    class L(J): pass
    class M(J): pass

    class TestGetAllSubclasses(unittest.TestCase):
        '''
        Test the utility function get_all_subclasses.
        '''
        def test_no_subclasses(self):
            '''
            Test when a class has no subclasses.
            '''
