

# Generated at 2022-06-11 00:32:40.978025
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(A):
        pass
    class G(B):
        pass
    class H(F):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])

# Generated at 2022-06-11 00:32:47.761428
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(D):
        pass

    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)

    assert C in get_all_subclasses(B)
    assert D in get_all_subclasses(B)
    assert E in get_all_subclasses(B)
    assert F in get_all_subclasses(B)

    assert C in get_all_subclasses(C)
    assert D in get_all_subclasses(C)

# Generated at 2022-06-11 00:32:52.469480
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    res = get_all_subclasses(A)
    assert len(res) == 2
    assert A in res
    assert B in res
    assert C in res
    assert object in res

# Generated at 2022-06-11 00:32:55.290087
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    test case for get_all_subclasses
    '''
    assert set(get_all_subclasses(int)) == set([bool])

# Generated at 2022-06-11 00:33:08.834414
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import sys
    import types

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(object):
        pass

    class E(B):
        pass

    class F(E):
        pass

    class TestCase_get_all_subclasses(unittest.TestCase):
        def test_no_subclasses(self):
            assert len(get_all_subclasses(D)) == 0

        def test_subclass_1(self):
            expected = {B, C, E, F}
            result = get_all_subclasses(A)
            assert result == expected

        def test_subclass_2(self):
            expected = {E, F}
            result = get_all_subclasses(B)

# Generated at 2022-06-11 00:33:17.191347
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types
    from ansible.module_utils.basic import AnsibleModule

    class grandparent(object):
        pass

    class parent_1(grandparent):
        pass

    class parent_2(grandparent):
        pass

    class child_1(parent_1):
        pass

    class child_2(parent_1):
        pass

    class child_3(parent_2):
        pass

    class child_4(parent_2):
        pass

    class grandchild_1(child_1):
        pass

    class grandchild_2(child_1):
        pass

    class grandchild_3(child_2):
        pass

    class grandchild_4(child_2):
        pass


# Generated at 2022-06-11 00:33:21.906803
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys, types
    from ansible.module_utils import basic

    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass

    assert list(get_all_subclasses(types.ModuleType)) == [basic.AnsibleModule]
    assert list(get_all_subclasses(A)) == [D, B, C]

# Generated at 2022-06-11 00:33:28.099511
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    # Checking
    assert get_all_subclasses(A) == {B, C, D}
    assert get_all_subclasses(B) == {D}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set()



# Generated at 2022-06-11 00:33:35.336167
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(B, D):
        pass

    class F(B, D):
        pass

    subclasses_of_a = get_all_subclasses(A)
    assert subclasses_of_a == set([B, C, D, E, F])

    subclasses_of_f = get_all_subclasses(F)
    assert subclasses_of_f == set([])



# Generated at 2022-06-11 00:33:47.037600
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import inspect

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class TestGetAllSubclasses(unittest.TestCase):
        def test_subclasses_a(self):
            subclasses = get_all_subclasses(A)
            self.assertTrue(B in subclasses)
            self.assertTrue(C in subclasses)
            self.assertTrue(D in subclasses)
            self.assertTrue(E in subclasses)
            self.assertTrue(F in subclasses)
            self.assertTrue(G in subclasses)


# Generated at 2022-06-11 00:33:54.984476
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass

    assert(set(get_all_subclasses(A)) == set([B, C, D, E]))
    assert(set(get_all_subclasses(E)) == set([]))

# Generated at 2022-06-11 00:34:01.268729
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(E):
        pass

    class G(F):
        pass

    class H:
        pass

    expected_result = set([G, F, E, D])
    assert get_all_subclasses(B) == expected_result



# Generated at 2022-06-11 00:34:06.480181
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test the get_all_subclasses function.
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert not A in get_all_subclasses(A)


# Generated at 2022-06-11 00:34:15.726656
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    A_subclasses = get_all_subclasses(A)
    assert set(A_subclasses) == {D, B, C, E}
    assert set(map(type, A_subclasses)) == {type(D), type(B), type(C), type(E)}
    assert set(type(c) for c in A_subclasses) == {type(D), type(B), type(C), type(E)}



# Generated at 2022-06-11 00:34:21.212325
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(B):
        pass

    class F(C):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F}

# Generated at 2022-06-11 00:34:29.431042
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    def a():
        pass

    def b():
        pass

    class c():
        class d():
            pass

        class e():
            class f():
                pass

    # List of all classes defined in this sample
    classes = [a, b, c, c.d, c.e, c.e.f]
    # Check that all subclasses of a class are returned as expected
    for cls in classes:
        subclasses = get_all_subclasses(cls)
        # Check that the number of subclasses is the expected one
        assert len(subclasses) == classes.count(cls)
        # Check that all subclasses returned are the right ones
        for subclass in subclasses:
            assert subclass.__name__ in [sc.__name__ for sc in subclasses]

# Generated at 2022-06-11 00:34:35.762757
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(C) == set([F])

# Generated at 2022-06-11 00:34:39.969194
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(B):
        pass
    assert get_all_subclasses(A) == {B, C}
    assert get_all_subclasses(B) == {C}
    assert get_all_subclasses(C) == set()

# Generated at 2022-06-11 00:34:45.624471
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E:
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(E)) == set()
    assert set(get_all_subclasses(object)) == set()
    
    

# Generated at 2022-06-11 00:34:56.366644
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    class F(E):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D}
    assert set(get_all_subclasses(B)) == set()
    assert set(get_all_subclasses(C)) == {D}
    assert set(get_all_subclasses(D)) == set()
    assert set(get_all_subclasses(E)) == {F}
    assert set(get_all_subclasses(F)) == set()
    assert set(get_all_subclasses(object)) == {A, B, C, D, E, F}

# Generated at 2022-06-11 00:35:12.469115
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(A, collections.MutableSequence):
        pass

    subclasses = get_all_subclasses(A)

    assert(B in subclasses)
    assert(C in subclasses)
    assert(D in subclasses)
    assert(E in subclasses)
    assert(F in subclasses)
    assert(collections.MutableSequence not in subclasses)

    # Check a class with no subclasses
    subclasses = get_all_subclasses(collections.MutableSequence)
    assert(len(subclasses) == 0)

# Generated at 2022-06-11 00:35:19.158254
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types
    class Base:
        def __init__(self):
            pass
    class ChildA(Base):
        pass
    class ChildB(Base):
        def __init__(self):
            pass
    class GrandchildB(ChildB):
        pass

    assert(set(get_all_subclasses(Base)) == set([ChildA,ChildB,GrandchildB]))



# Generated at 2022-06-11 00:35:28.293739
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.playbook.task_include
    from ansible.playbook.block import Block
    from ansible.plugins.callback import CallbackBase

    # Test get_all_subclasses() function
    assert Play in get_all_subclasses(ansible.playbook.play.Play)
    assert TaskInclude in get_all_subclasses(ansible.playbook.play.Play)
    assert PlayContext in get_all_subclasses(ansible.playbook.play_context.PlayContext)
    assert Block in get_all_subclasses(Block)


# Generated at 2022-06-11 00:35:39.224935
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(C): pass
    class H(D): pass

    # Ensure that A has only the required subclasses
    subclasses = get_all_subclasses(A)
    assert set(subclasses) == set([B, C, D, E, F, G, H])

    # Ensure that D has only the required subclasses
    subclasses = get_all_subclasses(D)
    assert set(subclasses) == set([H])

    # Ensure that G has not subclass
    subclasses = get_all_subclasses(G)
    assert set(subclasses) == set([])

    # Ensure that A has only the required sub

# Generated at 2022-06-11 00:35:47.175181
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F(E, B):
        pass
    assert set(get_all_subclasses(F)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(C)) == set([A, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([A, B, F])



# Generated at 2022-06-11 00:35:57.867377
# Unit test for function get_all_subclasses

# Generated at 2022-06-11 00:35:59.454389
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-11 00:36:04.137490
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
  class A(): pass
  class B(A): pass
  class C(A): pass
  class D(B): pass
  class E(B): pass
  class F(C): pass

  subclasses = get_all_subclasses(A)
  assert subclasses == set([B, C, D, E, F])

# Generated at 2022-06-11 00:36:14.108893
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class Base(object):
        """Base class"""
        pass

    class A(Base):
        """Class A"""
        pass

    class B(Base):
        """Class B"""
        pass

    class C(A):
        """Class C"""
        pass

    class D(C):
        """Class D"""
        pass

    class E(B):
        """Class E"""
        pass

    class F(E):
        """Class F"""
        pass

    class G(E):
        """Class G"""
        pass

    classes = [Base, A, B, C, D, E, F, G]
    for cls in classes:
        assert cls in get_all_subclasses(Base)

# Generated at 2022-06-11 00:36:24.545739
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define some example classes
    class A(object): pass
    class B(A): pass
    class C(object): pass
    class D(C): pass
    class E(A): pass

    # Check if get_all_subclasses returns all subclasses
    assert set(get_all_subclasses(A)) == set([B, E])
    assert set(get_all_subclasses(C)) == set([D])

    # Check if get_all_subclasses returns only direct subclasses
    assert set(get_all_subclasses(A)) & set([B])
    assert set(get_all_subclasses(A)) & set([E])
    assert not set(get_all_subclasses(A)) & set([B, E])

    assert set(get_all_subclasses(C)) & set([D])
   

# Generated at 2022-06-11 00:36:36.829189
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(C): pass
    assert get_all_subclasses(A) == set([B, C, D])

# Generated at 2022-06-11 00:36:41.609566
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Class1:
        pass
    class Class2(Class1):
        pass
    class Class3(Class2):
        pass
    class Class4:
        pass
    class Class5(Class1):
        pass
    class Class6(Class4):
        pass
    assert set(get_all_subclasses(Class1)) == {Class2, Class3, Class5}
    assert not get_all_subclasses(Class4)
    try:
        get_all_subclasses("Test")
        assert False
    except TypeError:
        assert True

if __name__ == "__main__":
    print("Testing get_all_subclasses")
    test_get_all_subclasses()

# Generated at 2022-06-11 00:36:45.723722
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test function get_all_subclasses
    """

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert get_all_subclasses(E) == []

# Generated at 2022-06-11 00:36:52.771425
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass

    a = A()
    b = B()
    c = C()
    d = D()
    e = E()
    f = F()
    g = G()

    # Test subclasses method
    assert set([B, C]) == set(A.__subclasses__())
    assert set([D, E]) == set(B.__subclasses__())
    assert set([F, G]) == set(C.__subclasses__())
    assert set([]) == set(D.__subclasses__())
    assert set([]) == set

# Generated at 2022-06-11 00:37:03.210360
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class A1(A):
        pass

    class A2(A):
        pass

    class A3(A):
        pass

    class A11(A1):
        pass

    class A12(A1):
        pass

    class A121(A12):
        pass

    class A122(A12):
        pass

    class A21(A2):
        pass

    class A22(A2):
        pass

    class A221(A22):
        pass

    class A222(A22):
        pass

    class A3_5(A3):
        pass

    class A3_7(A3):
        pass

    # Tuple of all the classes

# Generated at 2022-06-11 00:37:11.573895
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(F):
        pass

    subclasses_a = set(get_all_subclasses(A))
    subclasses_b = set(get_all_subclasses(B))
    subclasses_c = set(get_all_subclasses(C))
    subclasses_f = set(get_all_subclasses(F))

    assert subclasses_a == set([B, C, D, E, F, G])
    assert subclasses_b == set([D])
    assert subclasses_c == set([E, F, G])

# Generated at 2022-06-11 00:37:19.718331
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create example class
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    # Calling get_all_subclasses
    result = get_all_subclasses(A)

    # Validation
    assert len(result) == 4  # B, C, D and E are subclass of A
    assert B in result
    assert C in result
    assert D in result
    assert E in result

# Generated at 2022-06-11 00:37:31.162181
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test for the get_all_subclasses function
    '''

    class TestA(object):
        '''
        A class for testing the function get_all_subclasses
        '''
        pass

    class TestB(object):
        '''
        A class for testing the function get_all_subclasses
        '''
        pass

    class TestC(TestA):
        '''
        A class for testing the function get_all_subclasses
        '''
        pass

    class TestD(TestB):
        '''
        A class for testing the function get_all_subclasses
        '''
        pass

    class TestE(TestD):
        '''
        A class for testing the function get_all_subclasses
        '''
        pass

    cls_list = get_all_sub

# Generated at 2022-06-11 00:37:39.542620
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(G):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H])
    assert set(get_all_subclasses(B)) == set([D, F])
    assert set(get_all_subclasses(G)) == set([H])
    assert set(get_all_subclasses(H)) == set()

# Generated at 2022-06-11 00:37:50.502636
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(A): pass
    class E(C): pass
    class F(C): pass
    class G(F): pass

    assert get_all_subclasses(object) == set([A, B, C, D, E, F, G])
    assert get_all_subclasses(A) == set([C, D, E, F, G])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([E, F, G])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set([G])
    assert get_all_

# Generated at 2022-06-11 00:38:21.171024
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Animal:
        pass

    class Cat(Animal):
        pass

    class Dog(Animal):
        pass

    class Husky(Dog):
        pass

    class Poodle(Dog):
        pass

    class Chihuahua(Dog):
        pass

    assert get_all_subclasses(Animal) == {Cat, Dog, Husky, Poodle, Chihuahua}
    assert get_all_subclasses(Dog) == {Husky, Poodle, Chihuahua}


############
#
# Collection of constants for legacy ansible module arguments
#
############


ALLOWED_TRANSPORTS = ('cli', 'jrpc', 'httpapi', 'local')

MULTI_TRANSPORTS = ('cli', 'jrpc')


# Generated at 2022-06-11 00:38:26.102745
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass

    assert get_all_subclasses(A) == {B,E,D,G,F,H,C,I}

# Generated at 2022-06-11 00:38:38.351200
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections
    import sys

    # This is a clean dict for the purpose of adding elements without side effect
    MOCK_MODULES = collections.defaultdict(dict)

    # Building mock modules
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E():
        pass

    class F(A):
        class G(A):
            pass

    class H():
        pass

    class I(H):
        pass

    # Mock module update
    MOCK_MODULES.update(
        {'a': A, 'b': B, 'c': C, 'd': D, 'e': E, 'f': F, 'h': H, 'i': I}
    )

    # Mock sys.modules update


# Generated at 2022-06-11 00:38:47.725488
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import re

    # Defining a set of classes
    class A(object):
        pass

    class B1(A):
        pass

    class B2(A):
        pass

    class C1(B1):
        pass

    class C2(B2):
        pass

    class D1(C1):
        pass

    class D2(C2):
        pass

    # Comparing expected values to retrieved values
    expected_result = set([B1, C1, D1, B2, C2, D2])
    result = get_all_subclasses(A)
    assert result == expected_result, "get_all_subclasses() did not return expected result"

    # Checking that function returns an empty set
    expected_result = set()

# Generated at 2022-06-11 00:38:54.589871
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B: pass
    class C: pass
    class D(A): pass
    class E(B): pass
    class F(C): pass
    class G(D): pass
    class H(E): pass
    class I(F): pass
    class J(G): pass
    class K(H): pass
    class L(I): pass
    assert set(get_all_subclasses(A)) == {D, G, J}
    assert get_all_subclasses(C) == {F, I, L}

# Generated at 2022-06-11 00:38:59.843060
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class Test(unittest.TestCase):
        def test(self):
            self.assertEqual(set(get_all_subclasses(A)), {B, C, D, E})

    t = Test()
    t.test()

# Generated at 2022-06-11 00:39:07.856718
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Base class
    class A(object):
        pass

    # Partial inheritance
    class B(A):
        pass

    class C(A):
        pass

    # Multiple inheritance
    class D(A):
        pass

    class E(B, C):
        pass

    class F(E):
        pass

    class G(B, D):
        pass

    class H(B, E):
        pass

    class I(G):
        pass

    class J(B, G, H, I):
        pass

    # Inheritance with class in the middle
    class K(F):
        pass

    class L(K):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I, J, K, L])
    assert get_all

# Generated at 2022-06-11 00:39:15.806771
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(object):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(C):
        pass

    class H(G):
        pass

    class I(G):
        pass

    assert set(get_all_subclasses(A)) == set([B, D, E, F])
    assert set(get_all_subclasses(B)) == set([])
    assert set(get_all_subclasses(C)) == set([G, I, H])

# Generated at 2022-06-11 00:39:23.329780
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define class hierarchy
    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B,C):
        pass
    class E(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([D, E])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])

# Generated at 2022-06-11 00:39:27.796427
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class GrandParent(object):
        pass

    class Parent(GrandParent):
        pass

    class Child1(Parent):
        pass

    class Child2(Parent):
        pass

    class GrandChild(Child1):
        pass

    class Uncle(GrandParent):
        pass

    #
    # Unit test
    #

    assert get_all_subclasses(GrandParent) == set([Parent, Child1, Child2, Uncle, GrandChild])

# Generated at 2022-06-11 00:40:16.327439
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class X():
        pass

    class Y(X):
        pass

    class Z(X):
        pass

    class A(Y):
        pass

    class B(A):
        pass

    # Expect A and B to be subclasses of X
    assert set([A, B]).issubset(get_all_subclasses(X))
    # Expect A and B to be subclasses of X, Y and Z
    assert set([A, B]).issubset(get_all_subclasses(X) | get_all_subclasses(Y) | get_all_subclasses(Z))

# Generated at 2022-06-11 00:40:23.343133
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test the get_all_subclasses function
    """
    # Defining a class hierarchy
    class Foo:
        pass

    class Foo1(Foo):
        pass

    class Fooo(Foo1):
        pass

    class Foo2(Foo):
        pass

    class Bar(Foo2):
        pass

    class Foo3(Foo):
        pass

    class Foo4(Foo3, Bar):
        pass

    foo = Foo()
    foo1 = Foo1()
    fooo = Fooo()
    bar = Bar()
    foo2 = Foo2()
    foo3 = Foo3()
    foo4 = Foo4()
    # List of all classes
    class_list = [Foo, Foo1, Fooo, Bar, Foo2, Foo3, Foo4]
    # List of

# Generated at 2022-06-11 00:40:32.007023
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-11 00:40:36.142977
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-11 00:40:43.873800
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(E, C):
        pass

    class G(F):
        pass

    class H(G):
        pass

    class I(G):
        pass

    class J(C):
        pass

    classes = get_all_subclasses(A)
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert G in classes
    assert H in classes
    assert I in classes
    assert J in classes

# Generated at 2022-06-11 00:40:50.891075
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C1(object): pass
    class C2(object): pass
    class C3(object): pass
    class CBase(object): pass
    class C11(CBase): pass
    class C21(CBase): pass
    class C31(CBase): pass
    class C311(C31): pass

    class C(object): pass
    class D(C): pass
    class E(D): pass
    class F(E): pass
    class G(F): pass

    assert set(get_all_subclasses(object)) == set(get_all_subclasses(C1))
    assert set(get_all_subclasses(C1)) == set(get_all_subclasses(C2))
    assert set(get_all_subclasses(C2)) == set(get_all_subclasses(C3))


# Generated at 2022-06-11 00:41:01.196388
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        def __init__(self):
            pass
    class B(A):
        def __init__(self):
            pass
    class C(A):
        def __init__(self):
            pass
    class D(B):
        def __init__(self):
            pass
    class E(D):
        def __init__(self):
            pass
    class F(E):
        def __init__(self):
            pass
    class G(F):
        def __init__(self):
            pass
    class H(G):
        def __init__(self):
            pass
    class I(H):
        def __init__(self):
            pass
    class J(I):
        def __init__(self):
            pass

# Generated at 2022-06-11 00:41:06.134210
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D:
        pass
    assert set([C, B, A]) == get_all_subclasses(A)
    assert set([C, B]) == get_all_subclasses(B)
    assert set([C]) == get_all_subclasses(C)
    assert set([]) == get_all_subclasses(D)

# Generated at 2022-06-11 00:41:12.215195
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B, C):
        pass

    class F(D, E):
        pass

    class G(object):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([E, F])
    assert set(get_all_subclasses(C)) == set([E])
    assert set(get_all_subclasses(D)) == set([F])
    assert set(get_all_subclasses(E)) == set([F])
    assert set(get_all_subclasses(F)) == set()
    assert set

# Generated at 2022-06-11 00:41:14.644734
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestParentClass(object):
        pass

    class TestChildClass(TestParentClass):
        pass

    assert TestChildClass in get_all_subclasses(TestParentClass)