

# Generated at 2022-06-11 00:32:38.110126
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Init classes for test
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}



# Generated at 2022-06-11 00:32:45.813749
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''Unit test for function get_all_subclasses

    :rtype: bool
    :returns: True if the test passes, False otherwise.
    '''
    a = object()
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass

    # Testing empty
    assert get_all_subclasses(a) == set()
    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set([E])

# Generated at 2022-06-11 00:32:53.216238
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == {D, E}
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-11 00:33:00.136650
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a:
        pass

    class b(a):
        pass

    class c():
        pass

    class d(a, c):
        pass

    assert b in get_all_subclasses(a), "get_all_subclasses test failed"
    assert d in get_all_subclasses(a), "get_all_subclasses test failed"

# Generated at 2022-06-11 00:33:07.286166
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This function tests the functionality of get_all_subclasses

    :rtype: A dictionary containing the classes and the expected results
    '''
    # Create class hierarchy
    class cls1(object):
        pass

    class cls2(cls1):
        pass

    class cls3(cls1):
        pass

    class cls4(object):
        pass

    class cls5(cls3):
        pass

    class cls6(cls3):
        pass

    class cls7(cls4):
        pass

    class cls8(cls6):
        pass

    # Expected results

# Generated at 2022-06-11 00:33:12.958300
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    assert get_all_subclasses(A) == set((B, C, D))

    # Test if get_all_subclasses is working on object
    assert get_all_subclasses(object) == set((type, A, B, C, D, E))

# Generated at 2022-06-11 00:33:21.559634
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass

    assert set(get_all_subclasses(A)) == set((B, C, D, E))
    assert set(get_all_subclasses(B)) == set((D, E))
    assert set(get_all_subclasses(C)) == set(())
    assert set(get_all_subclasses(D)) == set(())
    assert set(get_all_subclasses(E)) == set(())

# Generated at 2022-06-11 00:33:25.094847
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(object):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(E) == set()

test_get_all_subclasses()

# Generated at 2022-06-11 00:33:34.412525
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    # test basic single entry
    assert A.__subclasses__() == [B, C]
    assert get_all_subclasses(A) == {B, C, D}

    # test with multiple entries of one type
    class E:
        pass

    class F(E):
        pass

    class G(E):
        pass

    class H(G):
        pass

    class I(G):
        pass

    assert E.__subclasses__() == [F, G]
    assert get_all_subclasses(E) == {F, G, H, I}

# Generated at 2022-06-11 00:33:39.644358
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(object):
        pass

    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(object)
    assert C in get_all_subclasses(A)
    assert E not in get_all_subclasses(A)

# Generated at 2022-06-11 00:33:47.661070
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    all = get_all_subclasses(A)
    assert E not in all
    assert A in all
    assert B in all
    assert C in all
    assert D in all

# Generated at 2022-06-11 00:33:53.724081
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(object):
        pass

    results = get_all_subclasses(A)

    assert(results == set([B, D, E, C]))

    results = get_all_subclasses(F)

    assert(results == set([]))

# Generated at 2022-06-11 00:34:02.918553
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(B): pass
    #
    # The tree is the following:
    #
    #         A
    #        / \
    #       B   C
    #      /   /
    #     E   D
    assert set() == get_all_subclasses(set())
    assert {A, B, C, E, D} == get_all_subclasses(A)
    assert {B, E} == get_all_subclasses(B)
    assert {C, D} == get_all_subclasses(C)

# Generated at 2022-06-11 00:34:09.397711
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test the get_all_subclasses function
    """
    # pylint: disable=invalid-name
    class A(object):
        """
        Class A
        """
        pass
    class B(A):
        """
        Class B
        """
        pass
    class C(A):
        """
        Class C
        """
        pass
    class D(C):
        """
        Class D
        """
        pass
    class E(C):
        """
        Class E
        """
        pass
    class F(A):
        """
        Class F
        """
        pass
    class G(F):
        """
        Class G
        """
        pass
    class H(G):
        """
        Class H
        """
        pass

# Generated at 2022-06-11 00:34:14.468617
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(E):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F])

# Generated at 2022-06-11 00:34:24.664772
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(object):
        pass

    class F(E):
        pass

    class G(E):
        pass

    assert set([B, D, C, A]).difference(get_all_subclasses(A)) == set()
    assert set([A, B, C, D]).difference(get_all_subclasses(A)) == set()
    assert set([C, A]).difference(get_all_subclasses(A)) == set()
    assert set([C, A, B, E, F, G]).difference(get_all_subclasses(object)) == set()

# Generated at 2022-06-11 00:34:36.906462
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B:
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(C):
        pass

    assert set(get_all_subclasses(A)) == set([C, D, F])

    class G(B):
        pass

    class H(G):
        pass

    class I(E):
        pass

    assert set(get_all_subclasses(B)) == set([E, G, H, I])

    # Test with multiple inheritance
    class J(A):
        pass

    class K(B):
        pass

    class L(J, K):
        pass

    class M(L):
        pass


# Generated at 2022-06-11 00:34:44.101418
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F(E):
        pass

    subclasses = get_all_subclasses(A)
    assert(subclasses == {B, C, D, E, F})

    subclasses = get_all_subclasses(E)
    assert(subclasses == {F})

    subclasses = get_all_subclasses(B)
    assert(subclasses == set())

# Generated at 2022-06-11 00:34:46.643750
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.plugins.connection.local import Connection as cls
    l = get_all_subclasses(cls)
    assert cls in l

# Generated at 2022-06-11 00:34:53.442365
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestClass1(object):
        pass

    class TestClass2(TestClass1):
        pass

    class TestClass3(TestClass1):
        pass

    class TestClass4(TestClass2):
        pass

    assert TestClass1 in get_all_subclasses(TestClass1)
    assert TestClass2 in get_all_subclasses(TestClass1)
    assert TestClass3 in get_all_subclasses(TestClass1)
    assert TestClass4 in get_all_subclasses(TestClass1)

# Generated at 2022-06-11 00:35:07.306298
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    This class is only for test purpose.
     A
      B
        D
      C
        E
        F
      G
    """
    from ansible.utils.module_docs_fragments import skip_if
    from ansible.module_utils import basic

    class A(object):
        """A"""
        pass
    class B(A):
        """B"""
        pass
    class C(A):
        """C"""
        pass
    class D(B):
        """D"""
        pass
    class E(C):
        """E"""
        pass
    class F(C):
        """F"""
        pass
    class G(A):
        """G"""
        pass
    classes = set([A, B, C, D, E, F, G])
    subclasses = get_all

# Generated at 2022-06-11 00:35:11.483696
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    assert(set(get_all_subclasses(A)) == set([B,C]))

# Quick unit test of function get_all_subclasses
test_get_all_subclasses()

# Generated at 2022-06-11 00:35:20.312262
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test get_all_subclasses function
    '''

    # Test get_all_subclasses function with a correct class
    # The class A is the super class
    assert(set([B, C, D, E]) == get_all_subclasses(A))

    # Test get_all_subclasses function with an empty class
    class F:
        pass
    assert(set([]) == get_all_subclasses(F))

    # Test get_all_subclasses function with a class which has no subclass
    assert(set([]) == get_all_subclasses(E))


# Generated at 2022-06-11 00:35:28.289565
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(B):
        pass
    # This class is not related, it is used to check that all class are referenced
    class D():
        pass
    class E(D):
        pass
    class F(E):
        pass
    # Check that all classes are returned
    assert set(get_all_subclasses(A)) == set([B, C])
    assert set(get_all_subclasses(D)) == set([E, F])
    assert set(get_all_subclasses(object)) == set([A, B, C, D, E, F])
    assert set(get_all_subclasses(int)) == set()

# Generated at 2022-06-11 00:35:39.231257
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(object):
        pass
    class H(G):
        pass
    class I(H):
        pass

    result = get_all_subclasses(A)
    assert B in result
    assert C in result
    assert D in result
    assert E in result
    assert F in result
    assert G not in result
    assert H not in result
    assert I not in result
    assert len(result) == 5
    result = get_all_subclasses(B)
    assert C in result
    assert D in result
    assert E in result
    assert F in result

# Generated at 2022-06-11 00:35:45.008616
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Grandfather:
        pass
    class Father(Grandfather):
        pass
    class Son(Father):
        pass
    class Daughter(Father):
        pass
    class Uncle(Grandfather):
        pass
    class Cousin(Uncle):
        pass
    class Nephew(Cousin):
        pass
    assert set(get_all_subclasses(Grandfather)) == set([Father, Son, Daughter, Uncle, Cousin, Nephew])



# Generated at 2022-06-11 00:35:56.178481
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections
    import itertools
    import sys

    def check_get_all_subclasses(cls):
        for c in get_all_subclasses(cls):
            assert issubclass(c, cls)

    check_get_all_subclasses(object)
    check_get_all_subclasses(collections.Mapping)
    check_get_all_subclasses(collections.Hashable)
    check_get_all_subclasses(collections.Iterable)
    check_get_all_subclasses(collections.Iterator)
    check_get_all_subclasses(collections.Container)
    check_get_all_subclasses(collections.Sized)
    check_get_all_subclasses(collections.Callable)

# Generated at 2022-06-11 00:36:03.200771
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(object):
        pass

    class D(C):
        pass

    class E(A):
        pass

    class F(D):
        pass

    class G(C, D):
        pass

    assert get_all_subclasses(A) == {B, E}
    assert get_all_subclasses(C) == {D, F, G}

# Generated at 2022-06-11 00:36:08.697527
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G:
        pass

    all_subclasses = {B,C,D,E,F}

    assert set(get_all_subclasses(A)) == all_subclasses
    assert set(get_all_subclasses(B)) == {D,F}

# Generated at 2022-06-11 00:36:15.332474
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(object):
        pass

    subclasses = get_all_subclasses(A)
    assert set([B, C, D, E, F]) == subclasses, "Wrong subclasses"



# Generated at 2022-06-11 00:36:53.474214
# Unit test for function get_all_subclasses

# Generated at 2022-06-11 00:37:04.348929
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(F):
        pass
    classes = [
        A, B, C, D, E, F, G, H, I
    ]
    # Check every class can find
    for c in classes:
        found_classes = get_all_subclasses(c)
        for f in classes:
            if f is c:
                continue
            if f in found_classes:
                if c is not A:
                    assert c in type.mro(f)[1:]

# Generated at 2022-06-11 00:37:13.303666
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Build following class structure:
    #
    #  class A: pass
    #
    #  class B(A): pass
    #
    #  class C(A): pass
    #
    #  class D(B, C): pass
    #
    #  class E(A): pass
    #
    #  class F(E): pass
    #
    #  class G(F): pass
    #
    #  class H(C): pass
    #
    #  class I(D): pass
    #
    #  class J(G): pass
    #
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(A):
        pass


# Generated at 2022-06-11 00:37:24.473563
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C1:
        pass
    class C2(C1):
        pass
    class C3:
        pass
    class C4(C1):
        pass
    class C5(C3):
        pass
    class C6(C5):
        pass
    class C7(C5):
        pass
    class C8(C2):
        pass
    class C9(C8):
        pass

    assert(set([C1, C2, C4, C8, C9]) == get_all_subclasses(C1))
    assert(set([C3, C5, C6, C7]) == get_all_subclasses(C3))
    assert(set([C5, C6, C7]) == get_all_subclasses(C5))

# Generated at 2022-06-11 00:37:35.789546
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(B): pass
    class E(D): pass
    class F(D): pass
    class G(F): pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G}
    assert get_all_subclasses(B) == {C, D, E, F, G}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == {E, F, G}
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == {G}
    assert get_all_subclasses(G) == set()

# Generated at 2022-06-11 00:37:41.979019
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class AClass(object):
        pass
    class BClass(AClass):
        pass
    class CClass(BClass):
        pass
    class DClass(CClass):
        pass
    class EClass(AClass):
        pass
    class FClass(EClass):
        pass
    ac = AClass()
    bc = BClass()
    cc = CClass()
    dc = DClass()
    ec = EClass()
    fc = FClass()
    assert ac.__subclasses__() == [bc, ec]
    assert get_all_subclasses(ac) == set([bc, cc, dc, ec, fc])



# Generated at 2022-06-11 00:37:53.328527
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import ansible.module_utils.basic

    class ParentClass(object):
        pass

    class ChildClass(ParentClass):
        pass

    class GrandChildClass(ChildClass):
        pass

    class GrandChildClass2(ChildClass):
        pass

    class GrandChildOfGrandChildClass(GrandChildClass):
        pass

    class ParentClass2(object):
        pass

    class ChildClass2(ParentClass2):
        pass

    class ParentClass3(object):
        pass

    class ChildClass3(ParentClass3):
        pass

    class GrandChildOfGrandChildClass2(GrandChildClass2):
        pass

    class UnrelatedClass(object):
        pass


# Generated at 2022-06-11 00:37:59.546520
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    ans = [A, B, C, D]
    assert set(ans) == get_all_subclasses(A)
    assert set(ans) == get_all_subclasses(B)
    assert set(ans) == get_all_subclasses(C)
    assert set(ans) == get_all_subclasses(D)
    assert not get_all_subclasses(float)

# Generated at 2022-06-11 00:38:02.880611
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(object): pass
    expected = {B, C, D}
    assert get_all_subclasses(A) == expected



# Generated at 2022-06-11 00:38:09.209485
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestClass1(object):
        pass

    class TestClass2(TestClass1):
        pass

    class TestClass3(TestClass2):
        pass

    class TestClass4(TestClass1):
        pass

    class TestClass5(object):
        pass

    assert set(get_all_subclasses(TestClass1)) == set([TestClass2, TestClass3, TestClass4])
    assert set(get_all_subclasses(TestClass2)) == set([TestClass3])
    assert set(get_all_subclasses(object)) == set([TestClass1, TestClass2, TestClass3, TestClass4, TestClass5])


# Generated at 2022-06-11 00:38:16.461528
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(object):
        pass

    class F(E, A):
        pass

    assert get_all_subclasses(A) == {B, C, D, F}

# Generated at 2022-06-11 00:38:20.606498
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(C): pass
    class F(D): pass
    assert set(get_all_subclasses(A)) == {B, C, D, E, F}



# Generated at 2022-06-11 00:38:28.161453
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses

    Test:
    - A class with no subclass
    - An empty class
    - A class with only direct subclasses
    '''
    class C1(object):
        pass
    class C2(object):
        pass
    class C3(object):
        pass

    class CC1(C1):
       pass
    class CC2(C1):
        pass

    C1.subclasses = get_all_subclasses(C1)
    C2.subclasses = get_all_subclasses(C2)
    CC3 = type('CC3', (CC2, CC1), {})
    C1.subclasses = get_all_subclasses(C1)

    assert not C1.subclasses
    assert not C2.subclasses

    assert CC

# Generated at 2022-06-11 00:38:36.907462
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    assert get_all_subclasses(object) == get_all_subclasses(A) == set()
    assert get_all_subclasses(A) == set([B, C])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set()

    class D(object):
        pass

    assert get_all_subclasses(D) == set()

# Generated at 2022-06-11 00:38:43.377688
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    # The set of expected subclasses
    expected_subclasses = set((C, D))

    # Test get_all_subclasses function
    subclasses = get_all_subclasses(A)
    # Test that the returned value is a set
    assert isinstance(subclasses, set)
    # Test that all expected subclasses are returned
    for expected_subclass in expected_subclasses:
        assert expected_subclass in subclasses
    # Test that there are not other subclasses
    assert len(subclasses) == 2

# Generated at 2022-06-11 00:38:49.666944
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(D): pass
    class G(D): pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([D, E, F, G])
    assert get_all_subclasses(C) == set()

# Generated at 2022-06-11 00:38:58.934820
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # class definition
    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(D):
        pass
    class G(E):
        pass

    # Testing
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])
    assert set(get_all_subclasses(B)) == set([D, E, F, G])
    assert set(get_all_subclasses(C)) == set()
    assert set(get_all_subclasses(D)) == set([F])
    assert set(get_all_subclasses(E)) == set([G])
    assert set(get_all_subclasses(F))

# Generated at 2022-06-11 00:39:02.406250
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import os
    import sys
    from tempfile import NamedTemporaryFile
    from ansible.module_utils import _utils

    # Create a fake module with a class and subclasses
    fd, fname = NamedTemporaryFile(suffix='.py', delete=False).file, NamedTemporaryFile(delete=False).name

# Generated at 2022-06-11 00:39:06.304148
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(D):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F}

# Generated at 2022-06-11 00:39:09.209084
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    assert get_all_subclasses(A) == set([B, D, C])

# Generated at 2022-06-11 00:39:27.097136
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    def AssertClassesEqual(a, b):
        # Compare two sets of classes, asserting that they are equal
        assert set(cls.__name__ for cls in a) == set(cls.__name__ for cls in b)

    class X: pass
    class Y: pass
    class A(X): pass
    class B(X): pass
    class C(Y): pass
    class D(B, Y): pass
    class E(D): pass

    AssertClassesEqual(get_all_subclasses(X), {A, B, D, E})
    AssertClassesEqual(get_all_subclasses(Y), {C, D, E})
    AssertClassesEqual(get_all_subclasses(D), {E})

# Generated at 2022-06-11 00:39:33.069724
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for the get_all_subclasses function
    '''

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E, F])

# Import all constants into _utils namespace
from ansible.module_utils.facts import *
from ansible.module_utils.facts.system import *

# Generated at 2022-06-11 00:39:38.241836
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B, C):
        pass
    class F(B, A):
        pass
    class G(D, E):
        pass

    assert set(get_all_subclasses(A)) == set([B,C,D,E,F,G])

# Generated at 2022-06-11 00:39:49.628608
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    # Base class
    class A(object):
        def __init__(self):
            pass

    # Regular class
    class B(A):
        def __init__(self):
            A.__init__(self)

    # Class with direct subclass
    class C(A):
        def __init__(self):
            A.__init__(self)

    class D(C):
        def __init__(self):
            C.__init__(self)

    # Class with two direct subclasses
    class E(A):
        def __init__(self):
            A.__init__(self)

    class F(E):
        def __init__(self):
            E.__init__(self)

    class G(E):
        def __init__(self):
            E

# Generated at 2022-06-11 00:39:58.038170
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Test:
        pass

    class TestA(Test):
        pass

    class TestB(Test):
        pass

    class TestA1(TestA):
        pass

    class TestA2(TestA):
        pass

    class TestB1(TestB):
        pass

    class TestB2(TestB):
        pass

    allSubclasses = get_all_subclasses(Test)
    assert TestA in allSubclasses
    assert TestB in allSubclasses
    assert TestA1 in allSubclasses
    assert TestA2 in allSubclasses
    assert TestB1 in allSubclasses
    assert TestB2 in allSubclasses

# Generated at 2022-06-11 00:40:05.865587
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from module_utils.basic import AnsibleModule
    from module_utils._text import to_bytes
    from ansible.compat.tests.mock import patch

    def _create_module(cls):
        with patch.object(AnsibleModule, '__init__', return_value=None):
            Amodule = AnsibleModule(argument_spec=dict())
            Amodule.params = dict()
        return cls(Amodule, dict())

    # Define base classes
    class A(object):
        def __init__(self, module, params):
            self.module = module
            self.params = params
    class B(object):
        def __init__(self, module, params):
            self.module = module
            self.params = params

# Generated at 2022-06-11 00:40:16.151628
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    class G():
        pass

    class H():
        pass

    assert(get_all_subclasses(A) == set([B, C, D, E, F]))
    assert(get_all_subclasses(B) == set([D]))
    assert(get_all_subclasses(C) == set([E, F]))
    assert(get_all_subclasses(D) == set([]))
    assert(get_all_subclasses(E) == set([F]))
    assert(get_all_subclasses(F) == set([]))

# Generated at 2022-06-11 00:40:26.197692
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test to test get_all_subclasses()
    '''
    # The class and its subclass
    class A(object):
        pass
    class B(A):
        pass

    assert A in get_all_subclasses(B)
    assert B in get_all_subclasses(B)
    assert B in get_all_subclasses(A)
    assert len(get_all_subclasses(B)) == 2

    # The class and two subclasses
    class C(object):
        pass
    class D(C):
        pass
    class E(C):
        pass

    assert D in get_all_subclasses(C)
    assert E in get_all_subclasses(C)
    assert len(get_all_subclasses(C)) == 3

    # The class and one subclass and the

# Generated at 2022-06-11 00:40:30.268831
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestA(object):
        pass

    class TestB(TestA):
        pass

    subclasses = get_all_subclasses(TestA)
    assert TestA in subclasses
    assert TestB in subclasses
    assert len(subclasses) == 2

# Generated at 2022-06-11 00:40:39.360384
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(A):
        pass

    class F(E):
        pass

    class G():
        pass

    class H(G):
        pass

    class I(H):
        pass

    sub_classes = get_all_subclasses(A)
    assert set(sub_classes) == {B, C, D, E, F}

# Generated at 2022-06-11 00:40:59.794889
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass
    class G(F):
        pass
    class H(E):
        pass
    class I(B):
        pass
    class J(I):
        pass

    assert set(get_all_subclasses(A)) == {C, E, F, G, H}
    assert set(get_all_subclasses(B)) == {D, I, J}
    assert set(get_all_subclasses(C)) == {E, F, G, H}
    assert set(get_all_subclasses(D)) == set()

# Generated at 2022-06-11 00:41:08.439232
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    import pytest
    from ansible.module_utils._text import to_text

    def assert_subclasses(cls, subclass_names):
        subclasses = get_all_subclasses(cls)
        subclass_names = set(subclass_names)
        subclass_strs = set(to_text(sc.__name__) for sc in subclasses)

        assert subclass_names == subclass_strs

    class A(object):
        pass

    class A1(A):
        pass

    class A2(A):
        pass

    class B(object):
        pass

    class C(B):
        pass

    class C1(C):
        pass

    assert_subclasses(A, ['A1', 'A2'])
    assert_subclasses(B, ['C', 'C1'])


# Generated at 2022-06-11 00:41:17.331043
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    from abc import ABCMeta

    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G:
        pass

    class H(G):
        pass

    class I(H):
        pass

    # Mix classic and new style class
    class J:
        __metaclass__ = ABCMeta

    class K(J):
        pass

    class L(K):
        pass

    class M(L):
        pass

    class N(L):
        pass

    class O(K):
        pass

    class P(O):
        pass

    class Q(O):
        pass

    assert get_all_subclasses(A)

# Generated at 2022-06-11 00:41:21.935971
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])

# Generated at 2022-06-11 00:41:33.599891
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This test case creates the following class tree::

      BaseClass
      |    L ParentClass
      |    L ChildClass
      |    |    L GrandchildClass1
      |    |    L GrandchildClass2
      |    L ChildClass2

    It then asserts that get_all_subclasses(BaseClass) returns the set
    containing `ParentClass`, `ChildClass`, `ChildClass2`, `GrandchildClass1`,
    and `GrandchildClass2`.
    '''
    base_list = []
    parent_list = []
    child_list = []
    child_list2 = []
    grandchild_list = []
    grandchild_list2 = []
    class BaseClass():
        def __init__(self):
            base_list.append(self)


# Generated at 2022-06-11 00:41:38.677297
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(C):
        pass

    class G(F):
        pass

    assert (set(get_all_subclasses(A)) == set([B, C, D, E, F, G]))

# Generated at 2022-06-11 00:41:43.124110
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class c:
        pass
    class c1(c):
        pass
    class c2(c):
        pass
    class c11(c1):
        pass
    class c21(c2):
        pass
    class c22(c2):
        pass
    assert set([c, c1, c2, c11, c21, c22]) == get_all_subclasses(c)

# Generated at 2022-06-11 00:41:48.579984
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    def compare_subclasses(cls, subclasses, recurse=True):
        all_subclasses = {}
        for s in cls.__subclasses__():
            if recurse:
                all_subclasses[s] = compare_subclasses(s, subclasses, recurse=False)
        return all_subclasses

    expected = compare_subclasses(A, set([B, C, D, E]))

    returned = compare_subclasses(A, get_all_subclasses(A))

    assert returned == expected

# Generated at 2022-06-11 00:41:54.904953
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    assert get_all_subclasses(A) == {B, C, D, E, F}
    assert get_all_subclasses(B) == {D, E}
    assert get_all_subclasses(C) == {F}


# Generated at 2022-06-11 00:42:03.957227
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Ensure that get_all_subclasses() function returns exactly the same result.

    To test the function, we use the following class tree:

        + M
        |
        +-> S1
        |
        +-> S2
        |  |
        |  +-> SS1
        |
        +-> S3
           |
           +-> SS2
    '''
    def recursive_get_all_subclasses(cls):
        to_return = set()
        to_visit = list(cls.__subclasses__())
        while to_visit:
            for sc in to_visit:
                to_visit.remove(sc)
                to_return.add(sc)
                for ssc in sc.__subclasses__():
                    if ssc not in to_return:
                        to_

# Generated at 2022-06-11 00:42:35.504414
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class ParentClass(object):
        pass
    class ChildClass1(ParentClass):
        pass
    class ChildClass2(ParentClass):
        pass
    class ChildClass1_1(ChildClass1):
        pass
    class ChildClass2_1(ChildClass2):
        pass
    class AnotherChildClass2_1(ChildClass2):
        pass
    assert get_all_subclasses(ParentClass) == set([ChildClass1, ChildClass2, ChildClass1_1, ChildClass2_1, AnotherChildClass2_1]), "Classes are not the same"

