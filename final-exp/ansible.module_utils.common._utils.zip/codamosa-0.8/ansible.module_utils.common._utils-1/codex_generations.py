

# Generated at 2022-06-11 00:32:44.230093
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import tempfile

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class E(object):
        pass

    class F(B):
        pass

    class G(E):
        pass

    class TestGetAllSubclasses(unittest.TestCase):
        """ Test function get_all_subclasses """
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_get_all_subclasses(self):
            """ Test method get_all_subclasses """
            self.assertEqual(get_all_subclasses(A), set([B, C, F]))

# Generated at 2022-06-11 00:32:54.423145
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a dummy class AA for test
    class AA(object):
        pass

    # Create a dummy subclass of AA: AAA
    class AAA(AA):
        pass

    # Create a dummy subclass of AAA: AAAA
    class AAAA(AAA):
        pass

    # Create a dummy subclass of AA: AAB
    class AAB(AA):
        pass

    # Create a dummy subclass of AAB: AABB
    class AABB(AAB):
        pass

    # Test case 1: AA class
    subclasses = get_all_subclasses(AA)
    # AA.__subclasses__() returns only direct child classes(AAA and AAB), so we add AAAA and AABB to test if the
    # function searches all subclasses even the indirect ones

# Generated at 2022-06-11 00:33:00.928399
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class foo(): pass
    class bar(foo): pass
    class baz(foo): pass
    class moo(bar): pass
    class zoo(bar): pass

    assert get_all_subclasses(foo) == set([bar, baz, moo, zoo])
    assert get_all_subclasses(baz) == set([])
    assert get_all_subclasses(moo) == set([])

# Generated at 2022-06-11 00:33:04.805975
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(B):
        pass

    class F(E):
        pass

    class G(B):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G}

# Generated at 2022-06-11 00:33:14.125920
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(D):
        pass
    class G(D):
        pass

    assert G in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert G in get_all_subclasses(B)
    assert F in get_all_subclasses(B)
    assert E in get_all_subclasses(B)
    assert D

# Generated at 2022-06-11 00:33:17.904343
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    class G(D): pass

    assert(set(get_all_subclasses(A)) == set([B,C,D,E,F,G]))



# Generated at 2022-06-11 00:33:20.946411
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    assert get_all_subclasses(A) == set([B, C, D])

# Generated at 2022-06-11 00:33:25.149047
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(D):
        pass
    class H(F):
        pass

    assert get_all_subclasses(A) == set([B,C,D,E,F,G,H])


# Generated at 2022-06-11 00:33:29.750935
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(E): pass
    class G(F): pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])

# Generated at 2022-06-11 00:33:39.407380
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(D):
        pass

    expected = {A, B, C, D, E, F, G}
    assert get_all_subclasses(A) == expected
    assert get_all_subclasses(B) == expected
    assert get_all_subclasses(C) == expected
    assert get_all_subclasses(D) == expected
    assert get_all_subclasses(E) == expected
    assert get_all_subclasses(F) == expected
    assert get_all_subclasses(G) == expected

# Generated at 2022-06-11 00:33:53.195463
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test the get_all_subclasses function.

    This unit tests use a class tree that looks like the following::

        class A(object):
            pass
        class B(A):
            pass
        class C(A):
            pass
        class D(B):
            pass
        class E(C):
            pass
        class F(A):
            pass
        class G(B, C):
            pass
        class H(D, E, F):
            pass

    This should have the following results::

        In [1]: get_all_subclasses(A) == set([B, C, D, E, F, G, H])
        Out[1]: True
    '''
    # Create class tree
    class A(object):
        pass
    class B(A):
        pass

# Generated at 2022-06-11 00:34:00.509843
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test the get_all_subclasses function.
    '''
    from ansible.module_utils._text import to_text

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    subclasses = get_all_subclasses(A)

    assert to_text(subclasses) == to_text(set([B, C, D, E]))



# Generated at 2022-06-11 00:34:08.049275
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(D): pass
    class F(E): pass
    class G(F): pass
    class H(G): pass
    subclasses = set([B, C, D, E, F, G, H])
    assert subclasses == get_all_subclasses(object)
    assert subclasses == get_all_subclasses(A)
    assert subclasses == get_all_subclasses(B)
    assert subclasses == get_all_subclasses(C)
    assert subclasses == get_all_subclasses(D)
    assert subclasses == get_all_subclasses(E)
    assert subclasses == get_all_subclasses(F)
    assert subclasses == get_all_

# Generated at 2022-06-11 00:34:19.642625
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B: pass
    class C: pass
    class D: pass
    class E: pass
    class F(A): pass
    class G(A): pass
    class H(G): pass
    class I(B): pass
    class J(C): pass
    class K(C): pass
    class L(B): pass
    class M(A): pass
    class N(I): pass

    # We expect A, B, C and D to have subclasses
    for base in [A, B, C, D]:
        for sub in get_all_subclasses(base):
            assert base in sub.__bases__
    # But E and F should not
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

    assert get

# Generated at 2022-06-11 00:34:27.547571
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(A): pass
    class F(E): pass
    class G(B): pass
    class H(E): pass
    class I(H): pass
    class J(I): pass
    class K(I): pass
    class L(H): pass

    subclasses = get_all_subclasses(A)
    classes = set([B, C, D, E, F, G, H, I, J, K, L])
    assert subclasses == classes
    assert len(subclasses) == len(classes)


# Generated at 2022-06-11 00:34:33.237267
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    expected_class_set = {B, C, D, E, F}
    assert expected_class_set == get_all_subclasses(A)



# Generated at 2022-06-11 00:34:41.112146
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # define a classical graph
    class S:
        pass
    class A(S):
        pass
    class B(S):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(B):
        pass
    class G(C):
        pass

    assert(set(get_all_subclasses(S)) == set([A,B,C,D,E,F,G]))

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-11 00:34:47.356251
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(B):
        pass
    assert set([B, C, D, E, F]) == get_all_subclasses(A)

# Generated at 2022-06-11 00:34:57.097890
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test to check all subclasses of a class
    '''
    class A(object):
        '''
        Base class
        '''
        pass

    class B(A):
        '''
        Subclass of A
        '''
        pass

    class C(A):
        '''
        Subclass of A
        '''
        pass

    class D(B):
        '''
        Subclass of B
        '''
        pass

    class E(A):
        '''
        Subclass of A
        '''
        pass

    class F(A):
        '''
        Subclass of A
        '''
        pass

    class G(E):
        '''
        Subclass of E
        '''
        pass


# Generated at 2022-06-11 00:35:03.330719
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass
    class F(C): pass

    assert E in get_all_subclasses(A)
    assert E in get_all_subclasses(B)
    assert F in get_all_subclasses(C)

    assert E not in get_all_subclasses(C)
    assert E not in get_all_subclasses(F)

# Generated at 2022-06-11 00:35:13.161432
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class B1(B):
        pass

    class B2(B):
        pass

    class C(A):
        pass

    class D(B):
        pass

    classes = get_all_subclasses(A)
    assert A in classes
    assert B in classes
    assert B1 in classes
    assert B2 in classes
    assert C in classes
    assert D in classes
    assert len(classes) == 6

# Generated at 2022-06-11 00:35:17.535577
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(object):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C not in subclasses

# Generated at 2022-06-11 00:35:21.402906
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A1(object):
        pass

    class A2(A1):
        pass

    class A3(A1):
        pass

    class B1(A2):
        pass

    assert set(get_all_subclasses(A1)) == set((A2, A3, B1))
    assert set(get_all_subclasses(A2)) == set((B1,))
    assert set(get_all_subclasses(A3)) == set()

# Generated at 2022-06-11 00:35:27.295953
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Father(object):
        pass
    class Son1(Father):
        pass
    class Son2(Father):
        pass
    class Son3(Father):
        pass
    class Grand_son1(Son3):
        pass
    class Grand_son2(Son3):
        pass
    sub_cls = get_all_subclasses(Father)
    assert isinstance(sub_cls, set)
    assert sub_cls == set([Son1, Son2, Son3, Grand_son1, Grand_son2])

# Generated at 2022-06-11 00:35:35.090076
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test get_all_subclasses
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(object):
        pass
    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == {C}
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-11 00:35:39.131507
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert get_all_subclasses(A) == {B, C, D}



# Generated at 2022-06-11 00:35:49.957813
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Ensure that get_all_subclasses function test the availability of the subclasses
    '''
    class A(object):
        '''
        A class which has only one subclass
        '''

    class B(A):
        '''
        A class which has the same subclass
        '''

    class C(A):
        '''
        A class which has the same subclass
        '''

    class D(B):
        '''
        A class which has no subclass
        '''

    class E(B):
        '''
        A class which has the same subclass
        '''

    class F(B):
        '''
        A class which has no subclass
        '''

    assert get_all_subclasses(A) == set([B, C, D, E, F])



# Generated at 2022-06-11 00:36:00.993985
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a example class structure
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(B):
        pass
    class F(E):
        pass
    class G(E):
        pass
    class H(D, F, G):
        pass
    class I(E):
        pass
    class J(G, I):
        pass
    class K(J, object):
        pass
    class L(D, H, K, object):
        pass
    assert get_all_subclasses(A) == set((B,C,D,E,F,G,H,I,J,K,L))


# Generated at 2022-06-11 00:36:07.815092
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    assert set(get_all_subclasses(A)) == set((B, C, D, E))
    assert set(get_all_subclasses(B)) == set((D,))
    assert set(get_all_subclasses(C)) == set((E,))
    assert set(get_all_subclasses(D)) == set()
    assert set(get_all_subclasses(E)) == set()

# Generated at 2022-06-11 00:36:14.779726
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert B in get_all_subclasses(B)
    assert C in get_all_subclasses(B)
    assert C in get_all_subclasses(C)
    assert A not in get_all_subclasses(A)

# Generated at 2022-06-11 00:36:53.857034
# Unit test for function get_all_subclasses

# Generated at 2022-06-11 00:36:57.948760
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    assert get_all_subclasses(A) == set([B, C, D])

# Generated at 2022-06-11 00:37:03.755227
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit tests for the get_all_subclasses() function.
    '''

    class Base(object):
        pass

    class A(Base):
        pass

    class B(Base):
        pass

    class C(A):
        pass

    assert C in get_all_subclasses(Base)
    assert A in get_all_subclasses(Base)
    assert B in get_all_subclasses(Base)

# Generated at 2022-06-11 00:37:11.936200
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(C):
        pass

    class I(D):
        pass

    # Test for class E
    cs = get_all_subclasses(E)
    assert E not in cs
    assert D not in cs
    assert I in cs
    assert B in cs
    assert A in cs

    # Test for class B
    cs = get_all_subclasses(B)
    assert E not in cs
    assert D in cs
    assert I in cs
    assert B not in cs
    assert A in cs

    # Test for class

# Generated at 2022-06-11 00:37:23.531129
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass

    assert set(get_all_subclasses(A)) == set([C, E])
    assert set(get_all_subclasses(B)) == set([D, F])

    # Tested class is included in the returned set
    assert set(get_all_subclasses(object)) == set([type, A, B, C, D, E, F])

if __name__ == "__main__":
    import sys
    import doctest
    if len(sys.argv) == 1:
        doctest.testmod()    # no cmd args, do tests

# Generated at 2022-06-11 00:37:28.728029
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(E):
        pass

    class G(F):
        pass

    assert set([B, C, D, E, F, G]) == get_all_subclasses(A)

# Generated at 2022-06-11 00:37:37.202455
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    classes = get_all_subclasses(A)
    assert len(classes) == 4
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes

    classes = get_all_subclasses(C)
    assert len(classes) == 2
    assert D in classes
    assert E in classes

    classes = get_all_subclasses(B)
    assert len(classes) == 0

# Generated at 2022-06-11 00:37:44.108998
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import random

    class TestClass(object):
        pass

    class TestSubClass1(TestClass):
        pass

    class TestSubClass2(TestClass):
        pass

    class TestSubSubClass1(TestSubClass1):
        pass

    class TestSubSubClass2(TestSubClass1):
        pass

    class TestSubSubClass3(TestSubClass2):
        pass

    class TestSubSubSubClass1(TestSubSubClass1):
        pass

    class TestSubClass3(TestSubClass2):
        pass

    class TestSubSubClass4(TestSubSubClass3):
        pass

    class TestSubSubClass5(TestSubSubClass3):
        pass


# Generated at 2022-06-11 00:37:54.621347
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define base class for test
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(object):
        pass
    # create assertIn instance since python2 doesn't have assertCountEqual()
    assertIn = lambda self, x, y: self.assertTrue(x in y)

    class TestGetAllSubclasses(unittest.TestCase):
        def test_is_subclass(self):
            subclasses = get_all_subclasses(A)
            self.assertCountEqual(subclasses, {B, C})

        def test_not_subclass(self):
            subclasses = get_all_subclasses(D)
            self.assertCountEqual(subclasses, set())


# Generated at 2022-06-11 00:37:59.441311
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import os
    from tempfile import NamedTemporaryFile

    class ClassA:
        pass

    class ClassB(ClassA):
        pass

    class ClassC(ClassA):
        pass

    class ClassD:
        pass

    class ClassE(ClassD):
        pass

    class ClassF(ClassD):
        pass
    class ClassG:
        pass

    class ClassH(ClassG):
        pass
    assert set([ClassA, ClassB, ClassC]) == get_all_subclasses(ClassA)
    assert set([ClassD, ClassE, ClassF]) == get_all_subclasses(ClassD)
    assert set([ClassG, ClassH]) == get_all_subclasses(ClassG)


# Generated at 2022-06-11 00:38:09.972663
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(B):
        pass

    # Set of all subclasses of class A
    assert get_all_subclasses(A) == set([B, C, D, E])

    # Set of all subclasses of class B
    assert get_all_subclasses(B) == set([C, E])

    # Set of all subclasses of class C
    assert get_all_subclasses(C) == set([])

    # Set of all subclasses of class D
    assert get_all_subclasses(D) == set([])

    # Set of all subclasses of class E
    assert get_all_subclasses(E) == set([])


# Generated at 2022-06-11 00:38:20.184697
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass

    # Test recursive function get_all_subclasses
    class TestGetAllSubclasses(unittest.TestCase):
        def test_class_a(self):
            res = get_all_subclasses(A)
            self.assertEqual(len(res), 3)
            self.assertIn(B, res)
            self.assertIn(C, res)
            self.assertIn(D, res)

        def test_class_b(self):
            res = get_all_subclasses(B)
            self.assertEqual(len(res), 0)
            self.assertNotIn(A, res)

# Generated at 2022-06-11 00:38:27.896518
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    ''' Unit Test for function get_all_subclasses '''
    # Defining a class hierarchy
    class C1(object):
        ''' Class hierarchy definition '''
    class C2(object):
        ''' Class hierarchy definition '''
    class C3(object):
        ''' Class hierarchy definition '''
    class C4(object):
        ''' Class hierarchy definition '''
    class C5(object):
        ''' Class hierarchy definition '''
    class C6(object):
        ''' Class hierarchy definition '''
    class C7(C1, C2):
        ''' Class hierarchy definition '''
    class C8(C3, C4):
        ''' Class hierarchy definition '''
    class C9(C7, C8):
        ''' Class hierarchy definition '''

# Generated at 2022-06-11 00:38:34.303380
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(B): pass
    class D: pass
    class E(D): pass

    # Test class related to class A
    assert get_all_subclasses(A) == {B, C}
    # Test class not related to class A
    assert get_all_subclasses(D) == {E}
    # Test class which has no subclasses
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-11 00:38:45.002975
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This function is a unit test for get_all_subclasses function.

    It verifies that function works correctly with this example :

    +----------+
    | A        |
    |----------|
    | __init__ |
    +----------+
          |
          v
        +-----+
        |  B  |
        |-----|
        |  C  |
        |-----|
        |  D  |
        +-----+
           |
           v
        +-----+
        |  E  |
        +-----+
    '''
    class A:
        def __init__(self):
            self.attr = "foo"

    class B(A):
        def __init__(self):
            super(B, self).__init__()

    class C(A):
        pass


# Generated at 2022-06-11 00:38:50.944487
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(D): pass
    class F(A): pass

    all_classes = get_all_subclasses(A)
    assert len(all_classes) == 5
    assert B in all_classes
    assert C in all_classes
    assert D in all_classes
    assert E in all_classes
    assert F in all_classes



# Generated at 2022-06-11 00:38:57.456857
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(B, A):
        pass
    A_subclasses = get_all_subclasses(A)
    assert C in A_subclasses
    assert D in A_subclasses
    assert E in A_subclasses
    assert F in A_subclasses
    assert len(A_subclasses) == 4

# Generated at 2022-06-11 00:39:01.686542
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, object):
        pass

    class E(D, C, object):
        pass

    class F(E, object):
        pass

    class G(E, object):
        pass

    assert set(get_all_subclasses(E)) == set([D, F, G])



# Generated at 2022-06-11 00:39:10.421919
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass
    class F(C): pass
    class G(D): pass

    groups = {
        "a": set([A, B, C, D, E, F]),
        "b": set([B, D, E, G]),
        "c": set([C, F]),
        "f": set([F]),
        "g": set([G])
    }

    for cls in [A, B, C, D, E, F, G]:
        subs = get_all_subclasses(cls)
        for (name,value) in groups.items():
            if subs == value:
                break

# Generated at 2022-06-11 00:39:21.526136
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(A):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass

    subclasses = get_all_subclasses(A)
    assert A in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in subclasses
    assert H in subclasses

    assert B not in subclasses


# Generated at 2022-06-11 00:39:36.512794
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    # A
    # -B
    # -C
    #  -D
    #   -E

    all_subclasses_a = get_all_subclasses(A)
    assert class_is_in_list(B, all_subclasses_a)
    assert class_is_in_list(C, all_subclasses_a)
    assert class_is_in_list(D, all_subclasses_a)
    assert class_is_in_list(E, all_subclasses_a)

    all_subclasses_b = get_all_subclasses(B)
    assert class_is_in

# Generated at 2022-06-11 00:39:40.055621
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(object):
        pass
    assert get_all_subclasses(A) == set([B, C])
    assert get_all_subclasses(D) == set([])

# Generated at 2022-06-11 00:39:51.460437
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Create an example class hierarchy and verify that get_all_subclasses returns what we expect
    '''
    A = type('A', (object,), {})
    B = type('B', (A,), {})
    C = type('C', (A,), {})
    D = type('D', (B,), {})
    E = type('E', (B,), {})
    def assert_contains(actual, expected):
        missing = set(expected) - set(actual)
        if missing:
            raise AssertionError('Missing items: %s' % ', '.join(missing))
    assert_contains(get_all_subclasses(A), (B, C, D, E))
    assert_contains(get_all_subclasses(B), (D, E))
    assert_cont

# Generated at 2022-06-11 00:40:01.809814
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(F):
        pass

    class H(G):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])
    assert get_all_subclasses(B) == set([C])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([E, F, G, H])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([G, H])

# Generated at 2022-06-11 00:40:06.493582
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(E): pass
    assert(set(get_all_subclasses(A)) == set((B, D, C, E, F)))

# Generated at 2022-06-11 00:40:13.261559
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(object):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    import pytest
    assert set(get_all_subclasses(A)) == set([B, D, F])
    assert set(get_all_subclasses(D)) == set([F])
    assert set(get_all_subclasses(E)) == set([])

# Generated at 2022-06-11 00:40:20.504066
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define some simple classes
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(F):
        pass

    # list all subclass of A
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])

    # list all subclass of B
    assert get_all_subclasses(B) == set([D, F, G])

    # list all subclass of C
    assert get_all_subclasses(C) == set([E])

# Generated at 2022-06-11 00:40:25.814230
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class p1(object):
        pass

    class p2(p1):
        pass

    class p3(p1):
        pass

    class p4(p3):
        pass

    class p5(object):
        pass

    hierarchy = [p1, p2, p3, p4, p5]
    assert set(hierarchy) == get_all_subclasses(object)

# Generated at 2022-06-11 00:40:31.714938
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(C): pass
    res = get_all_subclasses(A)
    assert B in res
    assert C in res
    assert D in res
    assert E in res
    assert F in res
    assert len(res) == 5

# Generated at 2022-06-11 00:40:44.002292
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(D):
        pass

    # Verify behaviour with a single subclass
    subclasses = get_all_subclasses(A)
    assert(len(subclasses) == 2)
    assert(B in subclasses)
    assert(C in subclasses)

    # Verify behaviour for a class with no subclasses
    subclasses = get_all_subclasses(B)
    assert(len(subclasses) == 2)
    assert(D in subclasses)
    assert(E in subclasses)

    # Verify behaviour for a class with no subclasses

# Generated at 2022-06-11 00:41:06.891820
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Simple unit test to ensure get_all_subclasses function is working as expected.
    """
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert(get_all_subclasses(A) == set([B, C, D, E]))
    assert(get_all_subclasses(B) == set([C, D, E]))
    assert(get_all_subclasses(C) == set([]))
    assert(get_all_subclasses(D) == set([E]))
    assert(get_all_subclasses(E) == set([]))

# Generated at 2022-06-11 00:41:14.943765
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function `get_all_subclasses`
    '''
    import os
    import sys
    import unittest
    import types
    import itertools

    # This function won't find the special builtin classes
    # And it won't find the future builtin exception classes
    # So the test code only verifies that it can find the standard module exception classes
    import exceptions

    # Creating an hierarchy of classes
    class A(object):
        '''Base class'''
    class B(A):
        '''Child class'''
    class C(A):
        '''Child class'''
    class D(B, C):
        '''Grandchild class'''

    # Creating the expected result
    expected_result = set()
    expected_result.add(exceptions.StandardError)
    expected_

# Generated at 2022-06-11 00:41:26.739688
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(E): pass
    class G(object): pass

    assert get_all_subclasses(A) == set([B, D, C, E, F])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E, F])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set()
    assert get_all_subclasses(G) == set()

# Generated at 2022-06-11 00:41:37.305306
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(object):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F(B, E):
        pass
    class G(E, A):
        pass
    class H(E, object):
        pass
    class J(H, object):
        pass
    assert G in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert F in get_all_subclasses(object)
    assert C in get_all_subclasses(object)
    assert A in get_all_subclasses(object)
    assert H in get_all_subclasses(object)
    assert H in get_all_subclasses(E)
    assert J

# Generated at 2022-06-11 00:41:41.043220
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    subclasses = get_all_subclasses(A)
    assert A in subclasses
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses

# Generated at 2022-06-11 00:41:45.523576
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(object):
        pass

    assert set(get_all_subclasses(A)) == set([A, B, C])
    assert get_all_subclasses(D) == set([D])
    assert list(get_all_subclasses(collections.Iterable)) != []

# Generated at 2022-06-11 00:41:48.238542
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D}

# Generated at 2022-06-11 00:41:54.656169
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Unit test for function get_all_subclasses

    It is a recursive test
    """
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])



# Generated at 2022-06-11 00:42:01.522803
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(C): pass
    class E(object): pass
    class F(E): pass
    class G(F): pass
    class H(G): pass

    all_classes = get_all_subclasses(A)
    assert C in all_classes
    assert D in all_classes
    assert B in all_classes
    assert E not in all_classes
    assert F not in all_classes
    assert G not in all_classes
    assert H not in all_classes

# Generated at 2022-06-11 00:42:08.457250
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(E): pass
    class G(F): pass
    class H: pass
    class I(H): pass

    assert get_all_subclasses(A) == set([
        __builtin__.object, A, B, C, D, E, F, G
    ])

    assert get_all_subclasses(B) == set([
        __builtin__.object, B, D
    ])

    assert get_all_subclasses(H)== set([
        __builtin__.object, H, I
    ])