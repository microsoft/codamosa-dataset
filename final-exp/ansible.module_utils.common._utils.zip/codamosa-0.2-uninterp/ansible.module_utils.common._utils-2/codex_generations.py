

# Generated at 2022-06-16 22:06:55.777545
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:07:01.389902
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])

# Generated at 2022-06-16 22:07:13.246952
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(G):
        pass

    class I(G):
        pass

    class J(I):
        pass

    class K(I):
        pass

    class L(I):
        pass

    class M(I):
        pass

    class N(I):
        pass

    class O(I):
        pass

    class P(I):
        pass

    class Q(I):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(I):
        pass

# Generated at 2022-06-16 22:07:23.193262
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:07:31.699633
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(I):
        pass

    class L(J):
        pass

    class M(K):
        pass

    class N(L):
        pass

    class O(M):
        pass

    class P(N):
        pass

    class Q(O):
        pass

    class R(P):
        pass

    class S(Q):
        pass

    class T(R):
        pass

# Generated at 2022-06-16 22:07:39.759434
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(F):
        pass

    class I(G):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H, I])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set([F, G, H, I])
    assert set(get_all_subclasses(D)) == set([])

# Generated at 2022-06-16 22:07:49.480778
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(E):
        pass

    class G(F):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(J):
        pass

    class L(K):
        pass

    class M(L):
        pass

    class N(M):
        pass

    class O(N):
        pass

    class P(O):
        pass

    class Q(P):
        pass

    class R(Q):
        pass

    class S(R):
        pass

    class T(S):
        pass

# Generated at 2022-06-16 22:08:00.266012
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(I):
        pass

    class L(J):
        pass

    class M(K):
        pass

    class N(L):
        pass

    class O(M):
        pass

    class P(N):
        pass

    class Q(O):
        pass

    class R(P):
        pass

    class S(Q):
        pass

    class T(R):
        pass

# Generated at 2022-06-16 22:08:12.909005
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(I):
        pass

    class L(J):
        pass

    class M(K):
        pass

    class N(L):
        pass

    class O(M):
        pass

    class P(N):
        pass

    class Q(O):
        pass

    class R(P):
        pass

    class S(Q):
        pass

    class T(R):
        pass

# Generated at 2022-06-16 22:08:23.641760
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:08:38.247571
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E, F])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-16 22:08:48.696753
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, F])
    assert get_all_subclasses(C) == set([E])
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-16 22:08:55.629464
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:09:06.674057
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(D):
        pass

    class I(E):
        pass

    class J(F):
        pass

    class K(F):
        pass

    class L(G):
        pass

    class M(H):
        pass

    class N(I):
        pass

    class O(J):
        pass

    class P(K):
        pass

    class Q(L):
        pass

    class R(M):
        pass

    class S(N):
        pass

    class T(O):
        pass

# Generated at 2022-06-16 22:09:15.732690
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(D):
        pass

    class I(E):
        pass

    class J(F):
        pass

    class K(F):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I, J, K])
    assert get_all_subclasses(B) == set([D, G, H])
    assert get_all_subclasses(C) == set([E, F, I, J, K])
    assert get_all_subclasses

# Generated at 2022-06-16 22:09:26.379164
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])
    assert set(get_all_subclasses(B)) == set([D, F])
    assert set(get_all_subclasses(C)) == set([E, G])
    assert set(get_all_subclasses(D)) == set([F])
    assert set(get_all_subclasses(E)) == set([G])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-16 22:09:37.523990
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:09:46.028447
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(J):
        pass

    class L(J):
        pass

    class M(L):
        pass

    class N(M):
        pass

    class O(M):
        pass

    class P(O):
        pass

    class Q(P):
        pass

    class R(P):
        pass

    class S(R):
        pass

    class T(R):
        pass

# Generated at 2022-06-16 22:09:51.588335
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])

# Generated at 2022-06-16 22:09:59.106586
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:10:16.069994
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:10:23.167853
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(G):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D, E, F, G, H])
    assert get_all_subclasses(D) == set([F, G, H])
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-16 22:10:34.273796
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:10:41.920340
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:10:53.546826
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:11:02.139814
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:11:13.224377
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:11:22.024316
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([D, F])
    assert get_all_subclasses(C) == set([E, G])
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set([G])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-16 22:11:33.360253
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(I):
        pass

    class L(J):
        pass

    class M(K):
        pass

    class N(L):
        pass

    class O(M):
        pass

    class P(N):
        pass

    class Q(O):
        pass

    class R(P):
        pass

    class S(Q):
        pass

    class T(R):
        pass

   

# Generated at 2022-06-16 22:11:43.281111
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:12:04.724001
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:12:13.900808
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D])
    assert set(get_all_subclasses(C)) == set([E, F])
    assert set(get_all_subclasses(D)) == set([])
    assert set(get_all_subclasses(E)) == set([F])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-16 22:12:25.503356
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:12:36.288152
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:12:45.227267
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:12:51.869704
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:12:59.468995
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass

# Generated at 2022-06-16 22:13:11.161819
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:13:21.138990
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:13:30.934243
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:14:02.046343
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:14:13.286366
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:14:23.741358
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:14:35.022762
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:14:43.496918
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D])
    assert set(get_all_subclasses(C)) == set([E, F])
    assert set(get_all_subclasses(D)) == set([])
    assert set(get_all_subclasses(E)) == set([F])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-16 22:14:55.331316
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(I):
        pass

    class L(J):
        pass

    class M(K):
        pass

    class N(L):
        pass

    class O(M):
        pass

    class P(N):
        pass

    class Q(O):
        pass

    class R(P):
        pass

    class S(Q):
        pass

    class T(R):
        pass

# Generated at 2022-06-16 22:15:04.322340
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(I):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(K):
        pass
    class O(M):
        pass
    class P(M):
        pass
    class Q(P):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:15:14.212813
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I, J, K, L, M, N, O])
    assert get_all_

# Generated at 2022-06-16 22:15:26.185961
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:15:33.162936
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:16:46.979184
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(G):
        pass

    class K(I):
        pass

    class L(J):
        pass

    class M(J):
        pass

    class N(M):
        pass

    class O(M):
        pass

    class P(O):
        pass

    class Q(O):
        pass

    class R(Q):
        pass

    class S(Q):
        pass

    class T(S):
        pass