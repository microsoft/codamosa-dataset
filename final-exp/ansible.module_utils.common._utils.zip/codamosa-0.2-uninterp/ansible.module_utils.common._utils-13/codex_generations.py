

# Generated at 2022-06-16 22:06:57.907977
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(I):
        pass

    class L(J):
        pass

    class M(K):
        pass

    class N(L):
        pass

    class O(M):
        pass

    class P(N):
        pass

    class Q(O):
        pass

    class R(P):
        pass

    class S(Q):
        pass

    class T(R):
        pass

# Generated at 2022-06-16 22:07:05.937807
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:07:18.042056
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([D, F])
    assert get_all_subclasses(C) == set([E, G])
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set([G])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-16 22:07:25.999698
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:07:37.731323
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:07:46.405932
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:07:58.485028
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:08:10.560408
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(F):
        pass

    class I(F):
        pass

    class J(G):
        pass

    class K(G):
        pass

    class L(H):
        pass

    class M(H):
        pass

    class N(I):
        pass

    class O(I):
        pass

    class P(J):
        pass

    class Q(J):
        pass

    class R(K):
        pass

    class S(K):
        pass

    class T(L):
        pass

# Generated at 2022-06-16 22:08:16.858860
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(G):
        pass

    class I(G):
        pass

    class J(I):
        pass

    class K(I):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I, J, K])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F, G, H, I, J, K])
    assert get_all_subclasses

# Generated at 2022-06-16 22:08:25.951076
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D])
    assert set(get_all_subclasses(C)) == set([E, F])
    assert set(get_all_subclasses(D)) == set([])
    assert set(get_all_subclasses(E)) == set([F])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-16 22:08:40.605773
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:08:51.162483
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:09:02.178688
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:09:11.782823
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])
    assert set(get_all_subclasses(B)) == set([D, F])
    assert set(get_all_subclasses(C)) == set([E, G])
    assert set(get_all_subclasses(D)) == set([F])
    assert set(get_all_subclasses(E)) == set([G])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-16 22:09:23.244667
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:09:31.594749
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:09:39.106242
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(D):
        pass
    class H(E):
        pass
    class I(E):
        pass
    class J(F):
        pass
    class K(G):
        pass
    class L(H):
        pass
    class M(I):
        pass
    class N(J):
        pass
    class O(K):
        pass
    class P(L):
        pass
    class Q(M):
        pass
    class R(N):
        pass
    class S(O):
        pass
    class T(P):
        pass

# Generated at 2022-06-16 22:09:47.144972
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(C):
        pass

    class H(G):
        pass

    class I(G):
        pass

    class J(I):
        pass

    class K(I):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I, J, K])
    assert get_all_subclasses(B) == set([D, E, F])
    assert get_all_subclasses(C) == set([G, H, I, J, K])
    assert get_all_subclasses

# Generated at 2022-06-16 22:09:57.387364
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:10:09.627612
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(G):
        pass

    class I(G):
        pass

    class J(I):
        pass

    class K(I):
        pass

    class L(K):
        pass

    class M(K):
        pass

    class N(M):
        pass

    class O(M):
        pass

    class P(O):
        pass

    class Q(O):
        pass

    class R(Q):
        pass

    class S(Q):
        pass

    class T(S):
        pass

# Generated at 2022-06-16 22:10:23.021658
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(D):
        pass

    class I(E):
        pass

    class J(F):
        pass

    class K(F):
        pass

    class L(G):
        pass

    class M(H):
        pass

    class N(I):
        pass

    class O(J):
        pass

    class P(K):
        pass

    class Q(L):
        pass

    class R(M):
        pass

    class S(N):
        pass

    class T(O):
        pass

# Generated at 2022-06-16 22:10:34.192099
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:10:41.892684
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(I):
        pass

    class L(J):
        pass

    class M(K):
        pass

    class N(L):
        pass

    class O(M):
        pass

    class P(N):
        pass

    class Q(O):
        pass

    class R(P):
        pass

    class S(Q):
        pass

    class T(R):
        pass

# Generated at 2022-06-16 22:10:53.545160
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(I):
        pass

    class L(J):
        pass

    class M(K):
        pass

    class N(L):
        pass

    class O(M):
        pass

    class P(N):
        pass

    class Q(O):
        pass

    class R(P):
        pass

    class S(Q):
        pass

    class T(R):
        pass

# Generated at 2022-06-16 22:11:02.139423
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(I):
        pass

    class L(J):
        pass

    class M(K):
        pass

    class N(L):
        pass

    class O(M):
        pass

    class P(N):
        pass

    class Q(O):
        pass

    class R(P):
        pass

    class S(Q):
        pass

    class T(R):
        pass

# Generated at 2022-06-16 22:11:13.224716
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(D):
        pass
    class H(G):
        pass
    class I(G):
        pass
    class J(I):
        pass
    class K(I):
        pass
    class L(K):
        pass
    class M(K):
        pass
    class N(M):
        pass
    class O(M):
        pass
    class P(O):
        pass
    class Q(O):
        pass
    class R(Q):
        pass
    class S(Q):
        pass
    class T(S):
        pass

# Generated at 2022-06-16 22:11:22.024540
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:11:33.354357
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:11:38.775608
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(E)) == set([])

# Generated at 2022-06-16 22:11:46.853031
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(C):
        pass

    class H(G):
        pass

    class I(G):
        pass

    class J(I):
        pass

    class K(I):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I, J, K])
    assert get_all_subclasses(B) == set([D, E, F])
    assert get_all_subclasses(C) == set([G, H, I, J, K])
    assert get_all_subclasses

# Generated at 2022-06-16 22:12:07.621877
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:12:18.797279
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:12:22.392669
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(E):
        pass

    class I(F):
        pass

    class J(G):
        pass

    class K(H):
        pass

    class L(I):
        pass

    class M(J):
        pass

    class N(K):
        pass

    class O(L):
        pass

    class P(M):
        pass

    class Q(N):
        pass

    class R(O):
        pass

    class S(P):
        pass

    class T(Q):
        pass

# Generated at 2022-06-16 22:12:31.750616
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:12:41.651762
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:12:49.282424
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(I):
        pass

    class L(J):
        pass

    class M(K):
        pass

    class N(L):
        pass

    class O(M):
        pass

    class P(N):
        pass

    class Q(O):
        pass

    class R(P):
        pass

    class S(Q):
        pass

    class T(R):
        pass

# Generated at 2022-06-16 22:12:57.901341
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:13:09.118611
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:13:16.838484
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(G):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(H):
        pass

    class L(I):
        pass

    class M(I):
        pass

    class N(M):
        pass

    class O(M):
        pass

    class P(O):
        pass

    class Q(O):
        pass

    class R(P):
        pass

    class S(P):
        pass

    class T(Q):
        pass

# Generated at 2022-06-16 22:13:27.610330
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:14:01.907576
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(D):
        pass

    class I(E):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(E):
        pass

    class M(E):
        pass

    class N(E):
        pass

    class O(E):
        pass

    class P(E):
        pass

    class Q(E):
        pass

    class R(E):
        pass

    class S(E):
        pass

    class T(E):
        pass

# Generated at 2022-06-16 22:14:12.191255
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([C])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([E, F])
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-16 22:14:23.025052
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:14:33.928077
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:14:43.497341
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(G):
        pass

    class I(G):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F, G, H, I])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])
    assert get_

# Generated at 2022-06-16 22:14:55.332623
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass
    class G(D):
        pass
    class H(D):
        pass
    class I(E):
        pass
    class J(E):
        pass
    class K(F):
        pass
    class L(F):
        pass
    class M(G):
        pass
    class N(H):
        pass
    class O(I):
        pass
    class P(J):
        pass
    class Q(K):
        pass
    class R(L):
        pass
    class S(M):
        pass
    class T(N):
        pass

# Generated at 2022-06-16 22:15:04.321666
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H, I, J, K, L, M, N, O])

# Generated at 2022-06-16 22:15:12.235722
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([])
    assert get_all_subclasses(C) == set([D, E])
    assert get_all_subclasses(D) == set([E])
    assert get_all_subclasses(E) == set([])

# Generated at 2022-06-16 22:15:23.626860
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:15:32.954246
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:16:42.991557
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-16 22:16:51.516622
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(C):
        pass
    class H(G):
        pass
    class I(G):
        pass
    class J(I):
        pass
    class K(I):
        pass
    class L(I):
        pass
    class M(L):
        pass
    class N(L):
        pass
    class O(N):
        pass
    class P(N):
        pass
    class Q(P):
        pass
    class R(P):
        pass
    class S(P):
        pass
    class T(S):
        pass