

# Generated at 2022-06-16 22:06:57.151992
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, F])
    assert get_all_subclasses(C) == set([E])
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-16 22:07:05.390041
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(E):
        pass

    class J(F):
        pass

    class K(G):
        pass

    class L(H):
        pass

    class M(I):
        pass

    class N(J):
        pass

    class O(K):
        pass

    class P(L):
        pass

    class Q(M):
        pass

    class R(N):
        pass

    class S(O):
        pass

    class T(P):
        pass

# Generated at 2022-06-16 22:07:17.441305
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:07:27.254995
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-16 22:07:35.072265
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:07:44.856021
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:07:53.041357
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(I):
        pass

    class L(J):
        pass

    class M(K):
        pass

    class N(L):
        pass

    class O(M):
        pass

    class P(N):
        pass

    class Q(O):
        pass

    class R(P):
        pass

    class S(Q):
        pass

    class T(R):
        pass

# Generated at 2022-06-16 22:08:01.838607
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(J):
        pass

    class L(K):
        pass

    class M(L):
        pass

    class N(M):
        pass

    class O(N):
        pass

    class P(O):
        pass

    class Q(P):
        pass

    class R(Q):
        pass

    class S(R):
        pass

    class T(S):
        pass

# Generated at 2022-06-16 22:08:13.664272
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(I):
        pass

    class L(J):
        pass

    class M(K):
        pass

    class N(L):
        pass

    class O(M):
        pass

    class P(N):
        pass

    class Q(O):
        pass

    class R(P):
        pass

    class S(Q):
        pass

    class T(R):
        pass

# Generated at 2022-06-16 22:08:23.397734
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E, F])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-16 22:08:39.095839
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:08:50.880786
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:09:01.367448
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([D, F])
    assert get_all_subclasses(C) == set([E, G])
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set([G])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-16 22:09:11.472647
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:09:22.856498
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:09:28.097579
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(H):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I])
    assert get_all_subclasses(B) == set([D, E, F, G, H, I])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set([E, F, G, H, I])
    assert get_all_subclasses(E)

# Generated at 2022-06-16 22:09:36.244024
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:09:40.094578
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-16 22:09:44.024756
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-16 22:09:55.707633
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:10:13.491447
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I, J, K, L, M, N, O])
    assert get_all_

# Generated at 2022-06-16 22:10:18.800864
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-16 22:10:27.390427
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, F])
    assert get_all_subclasses(C) == set([E])
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-16 22:10:37.413433
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:10:43.903906
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(E):
        pass

    class I(E):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(K):
        pass

    class M(K):
        pass

    class N(K):
        pass

    class O(K):
        pass

    class P(K):
        pass

    class Q(K):
        pass

    class R(K):
        pass

    class S(K):
        pass

    class T(K):
        pass

# Generated at 2022-06-16 22:10:54.740716
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(I):
        pass

    class L(K):
        pass

    class M(L):
        pass

    class N(L):
        pass

    class O(N):
        pass

    class P(N):
        pass

    class Q(P):
        pass

    class R(P):
        pass

    class S(R):
        pass

    class T(R):
        pass

# Generated at 2022-06-16 22:10:59.750306
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-16 22:11:08.289611
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E, F])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-16 22:11:18.637472
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:11:24.849615
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:11:43.147838
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:11:51.498609
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(G):
        pass

    class I(G):
        pass

    class J(I):
        pass

    class K(I):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H, I, J, K])

# Generated at 2022-06-16 22:12:01.829530
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(G):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F, G, H])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()
    assert get_all

# Generated at 2022-06-16 22:12:08.939288
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(D):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(J):
        pass
    class M(L):
        pass
    class N(L):
        pass
    class O(N):
        pass
    class P(N):
        pass
    class Q(P):
        pass
    class R(P):
        pass
    class S(R):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:12:20.111818
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D])
    assert set(get_all_subclasses(C)) == set([E, F])
    assert set(get_all_subclasses(D)) == set([])
    assert set(get_all_subclasses(E)) == set([F])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-16 22:12:29.173044
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, F])
    assert get_all_subclasses(C) == set([E])
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-16 22:12:36.211802
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:12:45.130075
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([D, F])
    assert get_all_subclasses(C) == set([E, G])
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set([G])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-16 22:12:51.813201
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:12:59.441067
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:13:32.226950
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(C):
        pass

    class G(F):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set([F, G])
    assert set(get_all_subclasses(D)) == set([E])
    assert set(get_all_subclasses(E)) == set([])
    assert set(get_all_subclasses(F)) == set([G])

# Generated at 2022-06-16 22:13:39.985400
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, E, F])
    assert set(get_all_subclasses(C)) == set([])
    assert set(get_all_subclasses(D)) == set([E, F])
    assert set(get_all_subclasses(E)) == set([])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-16 22:13:51.216113
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:14:00.209529
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:14:12.063548
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:14:22.874380
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:14:33.736338
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:14:43.379855
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])
    assert set(get_all_subclasses(B)) == set([D, F])
    assert set(get_all_subclasses(C)) == set([E, G])
    assert set(get_all_subclasses(D)) == set([F])
    assert set(get_all_subclasses(E)) == set([G])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-16 22:14:55.331971
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass

# Generated at 2022-06-16 22:15:04.324007
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(G):
        pass
    class J(I):
        pass
    class K(I):
        pass
    class L(K):
        pass
    class M(K):
        pass
    class N(M):
        pass
    class O(M):
        pass
    class P(O):
        pass
    class Q(O):
        pass
    class R(Q):
        pass
    class S(Q):
        pass
    class T(S):
        pass

# Generated at 2022-06-16 22:16:16.676747
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E, F])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-16 22:16:27.495064
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass

# Generated at 2022-06-16 22:16:34.188471
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

# Generated at 2022-06-16 22:16:39.459745
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])

# Generated at 2022-06-16 22:16:48.961295
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(G):
        pass

    class I(G):
        pass

    class J(I):
        pass

    class K(I):
        pass

    class L(K):
        pass

    class M(K):
        pass

    class N(M):
        pass

    class O(M):
        pass

    class P(O):
        pass

    class Q(O):
        pass

    class R(Q):
        pass

    class S(Q):
        pass

    class T(S):
        pass