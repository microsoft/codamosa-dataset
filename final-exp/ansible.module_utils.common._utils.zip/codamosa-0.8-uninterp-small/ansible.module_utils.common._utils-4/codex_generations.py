

# Generated at 2022-06-24 20:01:45.796626
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()


if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:01:46.900320
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() is None


# Generated at 2022-06-24 20:01:49.127268
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    r_0 = get_all_subclasses(int)
    assert int in r_0
    assert bool in r_0
    assert long in r_0
    assert float in r_0

# Generated at 2022-06-24 20:01:55.072297
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Ensure that the function returns a set of types
    assert isinstance(get_all_subclasses(str), set)
    # Ensure that the function returns a set of available subclasses
    assert str in get_all_subclasses(str)
    # Ensure that the function returns a set of available subclasses
    assert basestring in get_all_subclasses(str)

# Generated at 2022-06-24 20:01:55.860119
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(bytearray('test_pass'.encode()))

# Generated at 2022-06-24 20:01:59.815140
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print("Testing get_all_subclasses")
    test_case_0()
    print("Done")

# Local Variables:
# compile-command: "make -C ../.. utils/"
# End:

# Generated at 2022-06-24 20:02:05.662206
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except Exception as err:
        print(err)
        return 1

if __name__ == '__main__':
    exit(test_get_all_subclasses())

# Generated at 2022-06-24 20:02:10.243269
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()
# Main Program
if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:11.311687
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:02:12.626555
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() == None


# Generated at 2022-06-24 20:02:21.125339
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = '!^ttal/og\x0ch\t%|'
    var_0 = get_all_subclasses(str_0)
    # Checking the type of var_0
    assert isinstance(var_0, set)

# Generated at 2022-06-24 20:02:29.774066
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Initialize a dict for storing test information
    info = dict()
    info['tc_id'] = 'test_case_0'
    info['func_name'] = 'test_case_0'
    info['start_time'] = 'Tue Aug 28 16:22:09 2018'
    info['location'] = '/foo/bar/test.py:test_case_0'
    info['passed'] = 'True'
    # Call the function
    try:
        test_case_0()
    except:
        info['passed'] = 'False'
        info['error_info'] = 'This test has failed'
    # This is the data that the UI uses to generate the web page.
    return info

# Generated at 2022-06-24 20:02:33.080222
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)
    # We do not actually have tests for this function, but at least exercise
    # all branches so we can have a test coverage of 100% :)
    test_case_0()

# Generated at 2022-06-24 20:02:39.368209
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses(str)
    assert str in var_0
    assert unicode in var_0
    assert basestring not in var_0
    assert type in var_0

    # TODO: Update this test when we have a plugin that implements ntlm_auth
    # var_1 = get_all_subclasses(Credential)
    # assert BasicCredential in var_1
    # assert NtlmCredential not in var_1
    # assert UserPassCredential not in var_1

# Generated at 2022-06-24 20:02:50.454189
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import os.path
    import copy
    import sys
    import traceback
    import tempfile
    import shutil
    import subprocess
    import json
    import inspect
    import atexit
    import time
    import math
    import collections

    ## Python version
    import platform
    python_major = int(platform.python_version().split('.')[0])
    python_minor = int(platform.python_version().split('.')[1])

    # Python 2.6-2.7 shim
    if python_major == 2 and python_minor < 7:
        import imp

        try:
            from ordereddict import OrderedDict
        except (ImportError, SyntaxError):
            sys.stderr.write("Python 2.6 requires the ordereddict Python module (pip install ordereddict)\n")

# Generated at 2022-06-24 20:02:57.755058
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import random
    import string
    import hashlib
    # Checking for class inheritance
    for _ in range(200):
        class str_0(str):
            pass
        var_1 = random.choice(range(10, 100))
        str_1 = ''.join(random.choice(string.ascii_letters) for _ in range(var_1))
        assert var_0(str_1) == get_all_subclasses(str_0)
        del str_0
    # Checking for code integrity i.e. function should not be changed
    var_2 = hashlib.sha256(open(__file__, 'r').read().encode()).hexdigest()

# Generated at 2022-06-24 20:02:58.953272
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 20:03:04.488179
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Replace var_0 with real value for test
    var_0 = None
    # Replace var_1 with real value for test
    var_1 = None
    # Replace class_0 with real value for test
    class_0 = None
    var_2 = get_all_subclasses(class_0)
    assert var_2 == var_1
    assert var_2 != var_0

# Generated at 2022-06-24 20:03:13.078096
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # These tests were automatically generated by:
    #
    #   /home/jay/repos/ansible/hacking/test_generator.py
    #

    # Test cases for get_all_subclasses

    # These tests were automatically generated by:
    #
    #   /home/jay/repos/ansible/hacking/test_generator.py
    #

    # Test cases for get_all_subclasses

    # Test case with args: ('/\x1e',)
    test_case_0()

    # Test case with args: ('',)
    test_case_0()

    # Test case with args: ('2\x1c,\x0f',)
    test_case_0()

# Generated at 2022-06-24 20:03:13.585264
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    pass

# Generated at 2022-06-24 20:03:29.521589
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = '5wHU6[i^"YSy'
    # base class
    class A(object):
        str_0 = '4Mw*G/b@Q'
        pass
    # child class
    class B(A):
        str_0 = 's\tsc[p\n'
        pass
    # child class of child class
    class C(B):
        str_0 = 'h`(u~7Vb'
        pass
    assert get_all_subclasses(A) == set([B, C])
    assert get_all_subclasses(B) == set([C])
    assert not get_all_subclasses(C)


if __name__ == '__main__':
    test_case_0()
    test_get_all_subclasses()

##

# Generated at 2022-06-24 20:03:36.130299
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = '1zo\xbc\x19\x0f\x03\x11'
    str_1 = ')\\\x14\x10\x07\x1c\x1f'
    str_2 = ' >y'
    __repr__ = get_all_subclasses
    assert str_2 == str_1.join(__repr__('!!%\x1d\x08\x19\x15\x1b'))


# Generated at 2022-06-24 20:03:38.523768
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses), "Function `get_all_subclasses` is not callable."
    test_case_0()

# Generated at 2022-06-24 20:03:43.571598
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    get_all_subclasses('|P')
    get_all_subclasses('|P')
    get_all_subclasses('')
    get_all_subclasses('|P')
    get_all_subclasses('|P')
    get_all_subclasses('|P')
    get_all_subclasses('|P')
    get_all_subclasses('|P')
    get_all_subclasses('|P')
    get_all_subclasses('')
    get_all_subclasses('|P')
    get_all_subclasses('|P')
    get_all_subclasses('|P')
    get_all_subclasses('|P')
    get_all_subclasses('|P')
    get_all_subclasses('')
    get_all_subclasses('')

# Generated at 2022-06-24 20:03:53.836844
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print('Testing Function get_all_subclasses...', end='')

    # Test case 0
    str_0 = '!^ttal/og\x0ch\t%|'
    var_0 = get_all_subclasses(str_0)
    assert var_0 == {bytes, bytearray}, 'Failed test case 0'

    # Test case 1
    str_0 = ''
    var_0 = get_all_subclasses(str_0)
    assert var_0 == {bytes, bytearray}, 'Failed test case 1'

    # Test case 2
    str_0 = 'ZZ'
    var_0 = get_all_subclasses(str_0)
    assert var_0 == {bytes, bytearray}, 'Failed test case 2'

    # Test case 3
    str

# Generated at 2022-06-24 20:03:56.235284
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = '!^ttal/og\x0ch\t%|'
    var_0 = get_all_subclasses(str_0)
    return None


# Generated at 2022-06-24 20:03:57.915460
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    #assert False # TODO: implement your test here
    assert True # TODO: implement your test here


# Generated at 2022-06-24 20:03:59.117593
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils import _utils
    test_case_0()

# Generated at 2022-06-24 20:04:04.851335
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible_collections.ansible.community._utils.unittests.compat.mock import patch

    get_all_subclasses_mock = patch('ansible_collections.ansible.community._utils.get_all_subclasses')
    get_all_subclasses_mock.start()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    get_all_subclasses_mock.stop()


test_get_all_subclasses()

# Generated at 2022-06-24 20:04:06.184726
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    assert callable(get_all_subclasses)

    # test normal case
    test_case_0()

# Generated at 2022-06-24 20:04:23.024404
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert not get_all_subclasses("!^ttal/og\x0ch\t%|")
    assert not get_all_subclasses("$")
    assert not get_all_subclasses("6")
    assert not get_all_subclasses("{q")
    assert not get_all_subclasses("=r")
    assert not get_all_subclasses("8s")

# Generated at 2022-06-24 20:04:26.946194
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = '!^ttal/og\x0ch\t%|'
    var_0 = get_all_subclasses(str_0) # Should be a non-empty set

    int_0 = -22
    var_1 = get_all_subclasses(int_0) # Should be a non-empty set

    dict_0 = {}
    dict_0 = dict(zip(range(3), range(3)))
    var_2 = get_all_subclasses(dict_0) # Should be a non-empty set

    float_0 = 8.643102111606936e-307
    var_3 = get_all_subclasses(float_0) # Should be a non-empty set



# Generated at 2022-06-24 20:04:36.726619
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # List to store expected and actual output
    test_results = []
    # Test case 1:
    # str_0 = '5\114bbf'
    str_1 = '!^ttal/og\x0ch\t%|'
    # test_results.append((var_0, var_0))
    test_results.append(get_all_subclasses(str_1))
    var_1 = get_all_subclasses(str_1)
    # Test case 2:
    # str_1 = '!^ttal/og\x0ch\t%|'
    str_2 = '5\114bbf'
    # test_results.append((var_1, var_1))
    test_results.append(get_all_subclasses(str_2))
    var_2 = get_

# Generated at 2022-06-24 20:04:40.892926
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_1 = get_all_subclasses(str)
    assert len(var_1) > 0
    #assert all(isinstance(v, str) for v in var_1)

if __name__ == '__main__':
    test_case_0()
    test_get_all_subclasses()

# Generated at 2022-06-24 20:04:50.479832
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        # Test with an int
        with pytest.raises(TypeError):
            get_all_subclasses(2)
            assert False
    except AssertionError:
        assert False
    else:
        assert True
    try:
        # test with a list
        with pytest.raises(TypeError):
            get_all_subclasses([])
            assert False
    except AssertionError:
        assert False
    else:
        assert True
    try:
        # Test with a tuple
        with pytest.raises(TypeError):
            get_all_subclasses(())
            assert False
    except AssertionError:
        assert False
    else:
        assert True

# Generated at 2022-06-24 20:04:51.371282
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() == None

# Generated at 2022-06-24 20:04:52.782267
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except Exception as e:
        print(e)

# Generated at 2022-06-24 20:04:59.043286
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses(type(list))
    assert len(var_0) == 5
    assert list in var_0
    assert tuple in var_0
    assert set in var_0
    assert deque in var_0
    assert UserList in var_0

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:05:01.249995
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
        print('Test case 0: Pass')
    except:
        print('Test case 0: Fail')




# Generated at 2022-06-24 20:05:02.017682
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()



# Generated at 2022-06-24 20:05:28.427834
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_1 = get_all_subclasses()


# Generated at 2022-06-24 20:05:29.806153
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)
    test_case_0()

# Generated at 2022-06-24 20:05:35.853832
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == frozenset([basestring, unicode, str])
    assert get_all_subclasses(str)[1] == unicode
    assert get_all_subclasses(str)[2] == str
    assert get_all_subclasses(str)[0] == basestring

# Generated at 2022-06-24 20:05:36.545259
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()


# Generated at 2022-06-24 20:05:46.421456
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_0 = get_all_subclasses('!^ttal/og\x0ch\t%|')
    assert test_0
    test_1 = get_all_subclasses(False)
    assert test_1
    test_2 = get_all_subclasses(True)
    assert test_2
    test_3 = get_all_subclasses('+z$"3\'\x16\x18\x07\x12\x0f\x07\x1e\x1b\x1d\x18\x07D\x1c')
    assert test_3

# Generated at 2022-06-24 20:05:52.954562
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = 'l\x7fd\x15\x7f\x0f\x7f\x19\x06\x08\x11'
    var_1 = get_all_subclasses(var_0)
    assert var_1 == set([])
    var_2 = 'z\n[\x12\x01\x1a\x1c\x1c\x1b\x18\x0f'
    var_3 = get_all_subclasses(var_2)
    assert var_3 == set([])
    var_4 = 'l\x7f\x01\x12\x1a\x1b\x07\x06\x01\x17\x18\x14\r'
    var_5 = get_all_subclasses(var_4)


# Generated at 2022-06-24 20:05:55.889999
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = 'T}Q'
    var_0 = get_all_subclasses(str_0)
    assert var_0 == True



# Generated at 2022-06-24 20:06:05.402057
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_1 = '!^ttal/og\x0ch\t%|'
    var_0 = get_all_subclasses(str_1)
    assert var_0 == set()
    int_0 = -9
    var_1 = get_all_subclasses(int_0)
    assert var_1 == set()
    str_0 = '#|\x7f\x18\x06@\t\x0c}'
    var_2 = get_all_subclasses(str_0)
    assert var_2 == set()
    int_1 = -1
    var_3 = get_all_subclasses(int_1)
    assert var_3 == set()
    int_2 = 6
    var_4 = get_all_subclasses(int_2)
    assert var_4

# Generated at 2022-06-24 20:06:12.060618
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = FileType()
    var_0.name = 'MlpEx4WfN'
    var_0.path = 'UdlbSZ6X'
    var_0.mode = 'w'
    var_0.port = 4488
    var_0.timeout = 4.661923
    var_0.encoding = 'sqlite3'
    var_1 = '!^ttal/og\x0ch\t%|'
    var_2 = var_1.encode()
    var_3 = get_all_subclasses(var_0)


# Generated at 2022-06-24 20:06:16.330815
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = '!^ttal/og\x0ch\t%|'
    var_0 = get_all_subclasses(str_0)
    print(var_0)

test_get_all_subclasses()

# Generated at 2022-06-24 20:07:14.585724
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert not get_all_subclasses({})
    assert 'pd' in get_all_subclasses('!^ttal/og\x0ch\t%|')

# Generated at 2022-06-24 20:07:20.135896
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Try to get the list of classes that inherit from str_0
    str_0 = '!^ttal/og\x0ch\t%|'
    var_0 = get_all_subclasses(str_0)

    # Check that bytes and unicode are children of str_0
    assert bytes in var_0
    assert str_0 in var_0

# Generated at 2022-06-24 20:07:21.739961
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test for function get_all_subclasses with the type of arguments of list
    test_case_0()

# Generated at 2022-06-24 20:07:24.899144
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert False, 'No tests defined'


# Test the module name
if __name__ == "__main__":
    test_case_0()
    test_get_all_subclasses()

# Generated at 2022-06-24 20:07:26.360532
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Calling test_get_all_subclasses
test_get_all_subclasses()

# Generated at 2022-06-24 20:07:31.544714
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        assert get_all_subclasses.__doc__
        test_case_0()
    except AssertionError:
        assert 0, "Missing docstring for function get_all_subclasses"
    except NameError:
        assert 0, "Function get_all_subclasses not defined"



# Generated at 2022-06-24 20:07:33.090991
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        assert test_case_0() == None
    except AssertionError as e:
        raise(e)

# Generated at 2022-06-24 20:07:39.963709
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = 'asd'
    var_0 = get_all_subclasses(var_0)
    var_1 = set()
    var_2 = bytearray()
    var_1.add(var_2)
    var_1.add(str)
    var_1.add(tuple)
    var_1.add(basestring)
    var_1.add(object)
    var_1.add(type)
    var_1.add(str)
    var_1.add(basestring)
    var_2 = set()
    var_2.add(bytearray)
    var_2.add(list)
    var_2.add(int)
    var_2.add(dict)
    var_2.add(float)

# Generated at 2022-06-24 20:07:42.687748
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Assert that urlparse has all the subclasses we expect based on the python
    # versions that support this module.
    subclasses = get_all_subclasses(urlparse.ParseResult)
    assert set([urlparse.SplitResult]) == subclasses


# Generated at 2022-06-24 20:07:51.605995
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.errors import AnsibleExitJson
    from ansible.module_utils._text import to_native
    from ansible.parsing.vault import VaultLib

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    display.warn(to_text(u'\n<The next message may be a false alarm>'))

    try:
        assert u'_utils' == u'_utils'
    except AssertionError as exc:
        raise AssertionError(to_text(u'AssertionError: %s' % to_native(exc)))


# Generated at 2022-06-24 20:10:20.308404
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        str_0 = 'X'
        bytes_0 = None
        var_0 = get_all_subclasses(str_0)
        assert var_0 is not None
    # Conditional branch 1
    except:
        assert True

if __name__ == '__main__':
    # Begin the unit test
    test_get_all_subclasses()

# Generated at 2022-06-24 20:10:25.798937
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = ' \x0b'
    var_0 = get_all_subclasses(str_0)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='Unit test for module')
    parser.add_argument('--test', help='Name of the function to test', required=True)
    args = parser.parse_args()
    if args.test == 'get_all_subclasses':
        test_get_all_subclasses()
    elif args.test == 'test_case_0':
        test_case_0()
    else:
        raise ValueError("Invalid test name")

# Generated at 2022-06-24 20:10:31.939542
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_1 = '!^ttal/og\x0ch\t%|'
    assert(get_all_subclasses(var_1)) == set()


# Generated at 2022-06-24 20:10:32.986264
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert(test_case_0())

# Generated at 2022-06-24 20:10:34.755965
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    sub_class = []
    sub_class.extend([int, str])
    assert (get_all_subclasses(object) == set(sub_class))

# Generated at 2022-06-24 20:10:37.881538
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() == None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:10:40.231001
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # FIXME: Add test code for function get_all_subclasses
    pass

if __name__ == '__main__':
    test_case_0()
    test_get_all_subclasses()

# Generated at 2022-06-24 20:10:42.050109
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)
    test_case_0()
    test_case_1()



# Generated at 2022-06-24 20:10:44.742151
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:10:46.941701
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    x_0 = str
    # Check the return values
    assert get_all_subclasses(x_0) is not None
