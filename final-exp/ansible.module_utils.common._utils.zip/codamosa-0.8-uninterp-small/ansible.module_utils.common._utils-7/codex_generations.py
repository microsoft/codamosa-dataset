

# Generated at 2022-06-24 20:01:49.702534
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    dict_0 = {}
    var_0 = get_all_subclasses(dict_0)
    assert (var_0 == set())



# Generated at 2022-06-24 20:01:51.499023
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)
    assert test_case_0() is None

# Generated at 2022-06-24 20:01:54.335567
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except (TypeError, ValueError) as e:
        print(e)
        assert False
    else:
        print('All tests passed')


if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:01.201046
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    dict_0 = collections.defaultdict()
    assert get_all_subclasses(dict_0) == {collections.defaultdict, collections.OrderedDict, collections.Counter, collections.UserList,collections.UserDict, collections.UserString}
    dict_1 = collections.OrderedDict()
    assert get_all_subclasses(dict_1) == {collections.OrderedDict, collections.Counter}
    dict_2 = collections.Counter()
    assert get_all_subclasses(dict_2) == {collections.Counter}

# Generated at 2022-06-24 20:02:03.563244
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:06.199067
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert(False)

    print('Test passed.')

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:13.920218
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True # TODO: implement your test here

# unit test a function
# call below like this :
# python -m <this_file> <function name>
# python -m <this_file>.py test_get_all_subclasses
if __name__ == "__main__":
    import sys
    req_func = sys.argv[1]
    print("Running test function : " , req_func)
    eval(req_func)()
    print("DOne.")

# Generated at 2022-06-24 20:02:14.845784
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()


# Generated at 2022-06-24 20:02:16.231034
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    dict_1 = {}
    var_1 = get_all_subclasses(dict_1)

# Generated at 2022-06-24 20:02:19.894583
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Tests the case where you pass in a class with no subclasses
    test_case_0()


# Execute the tests above
if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:29.173401
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    try:
        # Testing argument types and counts
        get_all_subclasses(dict_0 = {})         # Type-checking
    except:
        # Thrown when the argument types are incorrect
        assert False, "Invalid argument types passed to get_all_subclasses"
    # No argument errors to this point
    assert True, "get_all_subclasses() passed without errors"
    # No return type errors to this point
    assert True, "get_all_subclasses() did not return a value"

# Generated at 2022-06-24 20:02:39.210570
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections
    import copy
    import traceback

    test_case_0()
    print('Test getter for get_all_subclasses:')
    print('get_all_subclasses(collections.OrderedDict)')
    print("type(get_all_subclasses(collections.OrderedDict)) - %s" % type(get_all_subclasses(collections.OrderedDict)))
    print("len(get_all_subclasses(collections.OrderedDict)) - %s" % len(get_all_subclasses(collections.OrderedDict)))
    print("list(get_all_subclasses(collections.OrderedDict))[0] - %s" % list(get_all_subclasses(collections.OrderedDict))[0])

# Generated at 2022-06-24 20:02:40.511389
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    result = get_all_subclasses(dict)

    assert result

# Generated at 2022-06-24 20:02:45.939657
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    wrong_types = [None, 0, 1, 3.14, dict(), dict(a=1, b=2)]
    correct_type = type
    # every subclass of any instance of correct_type should return True
    correct_type_subs = get_all_subclasses(correct_type)
    correct_type_subs.add(correct_type)

    for el in wrong_types:
        assert isinstance(el, correct_type) == False, "test_get_all_subclasses: incorrect input passed test"

    for el in correct_type_subs:
        assert isinstance(el, correct_type) == True, "test_get_all_subclasses: incorrect output passed test"


if __name__ == '__main__':
    test_get_all_subclasses()
    test_case_0()

# Generated at 2022-06-24 20:02:56.237917
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Define class Dict
    class Dict(object):
        pass

    # Define class DictProxy
    class DictProxy(Dict):
        pass

    # Define class DictMixin
    class DictMixin(Dict):
        pass

    # Define class UserDict
    class UserDict(DictMixin, dict):
        pass

    # Define class IterableUserDict
    class IterableUserDict(UserDict):
        pass

    # Define class DefaultDict
    class DefaultDict(DictMixin, dict):
        pass

    # Define class OrderDict
    class OrderDict(DictMixin, dict):
        pass

    # Define class ChainMap
    class ChainMap(DictMixin, dict):
        pass

    # Define class

# Generated at 2022-06-24 20:02:57.443497
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() is None

# Generated at 2022-06-24 20:02:59.767016
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    dict_0 = {}
    var_0 = get_all_subclasses(dict_0)

# Generated at 2022-06-24 20:03:01.697648
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    dict_0 = {}
    var_0 = get_all_subclasses(dict_0)

# Generated at 2022-06-24 20:03:05.945822
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Initializing dictionary obj with foo and bar classes
    class foo:
        pass

    class bar:
        pass

    dict_obj = {
        foo: (bar,),
        bar: ()
    }
    # Calling get_all_subclasses()
    var_0 = get_all_subclasses(dict_obj)

    assert var_0[0].__name__ == 'bar'

# Generated at 2022-06-24 20:03:14.322145
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils import _utils
    from types import ModuleType

    # Test the function with a dictionary class
    # Should return an empty set
    dict_0 = {}
    assert get_all_subclasses(dict_0) == set()

    # Test the function with a module class
    # Should return an empty set
    mod_0 = ModuleType("mod_0")
    assert get_all_subclasses(mod_0) == set()

    # Test the function with a class that has a subclass
    # Should return a set with a single element
    class Cls_0(): pass
    class Cls_1(Cls_0): pass
    assert get_all_subclasses(Cls_0) == set([Cls_1])

    # Test the function with a class that has a subclass, which has a subclass
    #

# Generated at 2022-06-24 20:03:20.478154
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(dict) == set([collections.OrderedDict])

# Generated at 2022-06-24 20:03:30.296022
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Loading required modules
    import unittest
    import ddt
    import random

    # Define the data used to test the function
    class A(object):
        pass

    class B(object):
        pass

    class C(B, A):
        pass

    class D(B):
        pass

    class E(C, D):
        pass

    class F(A):
        pass


# Generated at 2022-06-24 20:03:32.516366
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert len(get_all_subclasses(int)) == 0
    assert len(get_all_subclasses(dict)) == 1
    assert len(get_all_subclasses(list)) == 0



# Generated at 2022-06-24 20:03:37.317201
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    dict_0 = {}
    var_0 = get_all_subclasses(dict_0)
    assert var_0 == set({})


# Generated at 2022-06-24 20:03:41.952747
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(dict) == {
        dict,
        OrderedDict,
        defaultdict,
        UserDict,
        UserDict.DictMixin,
        UserDict.IterableUserDict,
    }

# Generated at 2022-06-24 20:03:46.889176
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    dict_0 = {}
    assert get_all_subclasses(dict_0) == set([dict])
    dict_1 = dict()
    assert get_all_subclasses(dict_1) == set([dict])
    dict_2 = dict({})
    assert get_all_subclasses(dict_2) == set([dict])

# Generated at 2022-06-24 20:03:48.634486
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    dict_0 = {}
    var_0 = get_all_subclasses(dict_0)



# Generated at 2022-06-24 20:03:50.201834
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    ret = get_all_subclasses(dict)

# Generated at 2022-06-24 20:03:57.945854
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import pytest
    # Creation of a class
    class test_class_0(object):
        pass
    # Creation of a subclass
    class test_class_1(test_class_0):
        pass
    # Creation of a subclass of the subclass
    class test_class_2(test_class_1):
        pass
    # Call the function
    var_0 = get_all_subclasses(test_class_0)
    # We expect in the list the two subclasses
    assert test_class_1 in var_0
    assert test_class_2 in var_0
    assert len(var_0) == 2

# Generate a list of all objects

# Generated at 2022-06-24 20:04:00.483612
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print("Testing getting all subclasses")
    test_case_0()
    print("All tests passed")

# Unit test driver
if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:04:15.348829
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # The test case should be function name followed by test number
    # The function should have a single argument 'self' for class TestXXX
    test_case_0()


# Generated at 2022-06-24 20:04:19.110505
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(int) == set([bool, complex])
    test_case_0()



# Generated at 2022-06-24 20:04:20.974837
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_1 = get_all_subclasses(int)

# Generated at 2022-06-24 20:04:23.114399
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:04:25.171400
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert (list(get_all_subclasses(dict)) == [collections.defaultdict])
    assert (list(get_all_subclasses(collections.defaultdict)) == [collections.OrderedDict])
    assert (list(get_all_subclasses(collections.OrderedDict)) == [])

# Generated at 2022-06-24 20:04:25.991988
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(set) == {frozenset}

# Generated at 2022-06-24 20:04:36.295512
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from difflib import unified_diff
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import (
        MutableMapping,
        MutableSet,
        MutableSequence,
    )
    from ansible.module_utils.six import (
        string_types,
        integer_types,
        text_type,
        binary_type,
        add_metaclass,
    )

    # class without any subclasses
    class A(object):
        pass

    # single class with subclasses
    class B(object):
        pass

    class C(B):
        pass

    class D(B):
        pass

    # multiple subclasses
    class E(object):
        pass

    class F(E):
        pass


# Generated at 2022-06-24 20:04:37.608297
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

if __name__ == '__main__':
    print(test_get_all_subclasses())

# Generated at 2022-06-24 20:04:38.690618
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:04:43.883100
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    dict_0 = dict()
    assert get_all_subclasses(dict_0) == dict_0.__subclasses__()



# Generated at 2022-06-24 20:05:04.014090
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True


# Generated at 2022-06-24 20:05:08.436895
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test exceptions thrown by function
    try:
        # Case without parameters
        test_case_0()
    except Exception as e:
        raise Exception(e)


if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:05:17.327120
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Creating a test class
    class test_a:
        pass

    # Creating a subclass of test_a
    class test_b(test_a):
        pass

    # Creating a subclass of test_a
    class test_c(test_a):
        pass

    # Creating a subclass of test_a
    class test_d(test_a):
        pass

    # creating a subclass of test_c
    class test_e(test_c):
        pass

    # Creating a subclass of test_e
    class test_f(test_e):
        pass

    # Creating a subclass of test_f
    class test_g(test_f):
        pass

    # Creating a subclass of test_f
    class test_h(test_f):
        pass

    # Creating a subclass of test_f

# Generated at 2022-06-24 20:05:17.889842
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True

# Generated at 2022-06-24 20:05:27.497254
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import platform
    import sys

    class Class0:
        def __init__(self):
            pass

    class Class1(Class0):
        def __init__(self):
            pass

    class Class2(Class0):
        def __init__(self):
            pass

    class Class3(Class1):
        def __init__(self):
            pass

    assert(get_all_subclasses(Class0) == set([Class1, Class2, Class3]))


if __name__ == "__main__":
    import os
    import sys
    import unittest
    import tempfile

    # If run directly, create a temporary directory to act as FOO_DIR
    tempdir = tempfile.mkdtemp()

    test_case_0()
    test_get_all_subclasses()

# Generated at 2022-06-24 20:05:37.085420
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    dict_0 = {}
    dict_1 = dict_0
    dict_1['a'] = 'a'
    dict_2 = dict_1
    dict_2['b'] = 'b'
    dict_3 = dict_2
    dict_2['c'] = 'c'
    dict_1['d'] = 'd'
    dict_0['e'] = 'e'
    dict_1['f'] = 'f'
    dict_2['g'] = 'g'
    dict_3['h'] = 'h'
    dict_1['i'] = 'i'
    dict_2['j'] = 'j'
    dict_3['k'] = 'k'
    dict_1['l'] = 'l'
    dict_2['m'] = 'm'

# Generated at 2022-06-24 20:05:39.073559
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    dict_0 = {}
    var_0 = get_all_subclasses(dict_0)
    assert var_0 is not False

test_get_all_subclasses()

# Generated at 2022-06-24 20:05:40.787229
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import doctest
    doctest.testmod(verbose=True)

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:05:43.575844
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # The function returns an iterator so the output of each test
    #   is converted in a list
    assert list(get_all_subclasses(dict)) \
        == [collections.defaultdict, collections.OrderedDict, collections.Counter]
    assert list(get_all_subclasses(collections.defaultdict)) == []

# Generated at 2022-06-24 20:05:44.730326
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print("IN test_get_all_subclasses")
    test_case_0()



# Generated at 2022-06-24 20:06:41.676133
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import pytest
    import operator
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(D):
        pass
    assert set(get_all_subclasses(A)) == set((B, C, D, E, F, G))
    # with pytest.raises(TypeError):
    #     get_all_subclasses(None)
    # with pytest.raises(TypeError):
    #     get_all_subclasses(dict)
    # with pytest.raises(TypeError):
    #     get_all_subclasses(list)
    # with pytest.raises(TypeError):


# Generated at 2022-06-24 20:06:42.835888
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print("Start test!")
    test_case_0()
    print("Done!")

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:06:47.649778
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

if __name__ == "__main__":
    # If a specific test case is specified, run it.
    # Otherwise, run all test cases.

    if len(sys.argv) > 1:
        import imp
        command = "test_case_%s()" % sys.argv[1]
        imp.load_source("__main__", "utils")

        eval(command)
    else:
        test_get_all_subclasses()

# Generated at 2022-06-24 20:06:50.397627
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    dict_0 = {}
    var_0 = get_all_subclasses(dict_0)
    assert (set() == var_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:06:52.361533
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:06:55.481095
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except Exception as e:
        print('test_case_0 failed: ' + str(e))


if __name__ == '__main__':
    # Run unit test
    test_get_all_subclasses()

# Generated at 2022-06-24 20:06:58.145351
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# main function
if __name__ == '__main__':
    test_get_all_subclasses()
    print('Tests passed!')

# Generated at 2022-06-24 20:07:01.263455
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() is None



# Generated at 2022-06-24 20:07:03.996715
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Testing if get_all_subclasses function can access the class
    try:
        test_case_0()
    except Exception as e:
        print("get_all_subclasses could not access the class", e)

# Generated at 2022-06-24 20:07:04.821526
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True # TODO: implement your test here

# Generated at 2022-06-24 20:09:06.132491
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create class instances
    var_0 = {}
    var_1 = {}

    # Create class instances
    var_2 = {}
    var_3 = {}

    # Create class instances
    var_4 = {}
    var_5 = {}

    # Create class instances
    var_6 = {}
    var_7 = {}

    # Create class instances
    var_8 = {}

    # Check if the object classes are the same

# Generated at 2022-06-24 20:09:09.080787
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        assert get_all_subclasses() == 'Insufficient number of arguments (0) passed to the function.  Minimum number of arguments required is 1'
    except AssertionError:
        raise AssertionError(get_all_subclasses())

# Generated at 2022-06-24 20:09:16.428269
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test a module or class without any child subclasses
    dict_0 = {}
    var_0 = get_all_subclasses(dict_0)
    assert var_0 == set([])
    # Test a module with some child subclasses
    var_0 = get_all_subclasses(ansible.modules.cloud.amazon)

# Generated at 2022-06-24 20:09:19.512779
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(dict) == set()
    list_0 = [1,2,3]
    assert get_all_subclasses(list_0) == []
    assert get_all_subclasses(str) == []
    assert get_all_subclasses(int) == []
    dict_1 = dict()
    assert get_all_subclasses(dict_1) == []

# test for function get_all_subclasses()

# Generated at 2022-06-24 20:09:22.396223
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert(len(get_all_subclasses(dict)) == 27), "Failed to retrieve all subclasses of `dict`"



# Generated at 2022-06-24 20:09:23.122437
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()



# Generated at 2022-06-24 20:09:24.911550
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        dict_0 = {}
        print (get_all_subclasses(dict_0))
    except Exception as e:
        import traceback
        traceback.print_exc()
        assert False, "unexpected error occurred"



# Generated at 2022-06-24 20:09:31.129779
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)
    cls_0 = dict
    set_0 = get_all_subclasses(cls_0)
    assert test_case_0()
    return True

test_get_all_subclasses()

# Generated at 2022-06-24 20:09:39.703946
# Unit test for function get_all_subclasses

# Generated at 2022-06-24 20:09:44.696586
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert len(get_all_subclasses(dict)) == 3
    assert len(get_all_subclasses(object)) == 74
    assert len(get_all_subclasses(dict)) == 3

