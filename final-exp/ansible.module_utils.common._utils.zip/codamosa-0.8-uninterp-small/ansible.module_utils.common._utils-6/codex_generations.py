

# Generated at 2022-06-24 20:01:50.993922
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    # Define test class hierarchy
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(D):
        pass

    class I(E):
        pass

    test_classes = (A, B, C, D, E, F, G, H, I)
    '''
    test_classes = (0, 1, 2, 3, 4, 5, 6, 7, 8)

    def get_children(cls):
        return set(cls.__subclasses__())


# Generated at 2022-06-24 20:02:00.202480
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import platform
    import sys
    import pytest
    from dataclasses import dataclass, field
    from typing import List, Set

    # Define dataclass
    @dataclass
    class Animal:
        name: str
        age: int
        parents: List[int] = field(default_factory=list)

    @dataclass
    class Cat(Animal):
        name: str
        age: int
        parents: List[int] = field(default_factory=list)
        children: List[int] = field(default_factory=list)

    @dataclass
    class Dog(Animal):
        name: str
        age: int
        parents: List[int] = field(default_factory=list)
        children: List[int] = field(default_factory=list)

   

# Generated at 2022-06-24 20:02:02.392508
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = 'CT:HIV'
    try:
        get_all_subclasses(str_0)
    except Exception as e:
        test_case_0()

test_get_all_subclasses()

# Generated at 2022-06-24 20:02:08.760813
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == set(['__builtin__.basestring', '__builtin__.unicode', '__builtin__.str'])
    assert get_all_subclasses(int) == set([])
    assert get_all_subclasses(tuple) == set([])
    assert get_all_subclasses(dict) == set(['__builtin__.UserDict', '__builtin__.odict'])
    assert get_all_subclasses(list) == set(['__builtin__.UserList', '__builtin__.UserString'])
    assert get_all_subclasses(object) == set([])

# Generated at 2022-06-24 20:02:12.093517
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test argument type is str
    assert get_all_subclasses('CT:HIV') == 'Bad Argument Type', 'Argument type should be class'

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:16.242056
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert set(get_all_subclasses(str)) == set([unicode])
    assert set(get_all_subclasses(A)) == set([B, C, D])



# Generated at 2022-06-24 20:02:25.536410
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Unit test for the method get_all_subclasses

    """

    # Test case 1
    # Expected result: {'CT:HIV:Care:Procedure:CtxInitiated', 'CT:HIV:Care:Procedure:FollowupTest', 'CT:HIV:Care:Procedure:Visit', 'CT:HIV:Care:Procedure:HtsTest'}

# Generated at 2022-06-24 20:02:32.896372
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class GrandParent:
        pass

    class Parent(GrandParent):
        pass

    class Child(Parent):
        pass

    class GrandChild(GrandParent):
        pass

    class FarGrandChild(GrandChild):
        pass

    assert set([Child, FarGrandChild]) == get_all_subclasses(GrandParent)
    assert set([GrandChild, FarGrandChild]) == get_all_subclasses(GrandChild)
    assert set([FarGrandChild]) == get_all_subclasses(GrandChild)

# Generated at 2022-06-24 20:02:40.654250
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # A test class
    class TestClassA(object):
        pass

    # Its subclass
    class TestClassB(TestClassA):
        pass

    # Its subclass
    class TestClassC(TestClassA):
        pass

    # A subclass of TestClassB
    class TestClassD(TestClassB):
        pass

    assert get_all_subclasses(TestClassA) == set([TestClassB, TestClassC, TestClassD])
    assert get_all_subclasses(TestClassB) == set([TestClassD])
    assert get_all_subclasses(TestClassD) == set([])
    assert get_all_subclasses(int) == set([])



# Generated at 2022-06-24 20:02:45.096786
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = 'CT:HIV'
    var_0 = get_all_subclasses(str_0)
    assert var_0 is not None

# Generated at 2022-06-24 20:02:50.545977
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print('Test for function get_all_subclasses')
    test_case_0()

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:52.896419
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    for i in range(10):
        try:
            test_case_0()
        except Exception as e:
            print(e)
        else:
            print('Test case 0')


# Create a new class called 'Parent'

# Generated at 2022-06-24 20:02:56.421314
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == set((bytes,))
    assert get_all_subclasses(int) == set()
    assert get_all_subclasses(dict) == set((collections.defaultdict,))



# Generated at 2022-06-24 20:03:05.609388
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert issubclass(str, get_all_subclasses(str))
    assert issubclass(int, get_all_subclasses(int))
    assert issubclass(float, get_all_subclasses(float))
    assert issubclass(type, get_all_subclasses(dict))
    assert issubclass(type, get_all_subclasses(list))
    assert issubclass(type, get_all_subclasses(set))
    assert issubclass(type, get_all_subclasses(tuple))
    assert issubclass(type, get_all_subclasses(frozenset))


if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:03:12.861557
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    some_superclass_list = ['CT','CT:HIV','CT:HIV:HIV_1','CY','CY:HPV','CY:HPV:HPV_1','CY:HPV:HPV_2']
    test_case_0()
    if str_0 in some_superclass_list:
        print(str_0,some_superclass_list)
        assert True


# This sets the __name__ variable when this test is executed
# to the value of “__main__” which is the name given when it is
# executed from the command line. This allows us to run the test
# module with:
#
#   python -m util.get_all_subclasses
#
# (or python3)
#
# and have it execute the code in this file.

# Generated at 2022-06-24 20:03:18.539325
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        print("No arguments are accepted")
        sys.exit(1)
    else:
        test_get_all_subclasses()

# Generated at 2022-06-24 20:03:23.757704
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = 'CT:HIV'
    str_1 = 'CT:Fibrosis'
    str_2 = 'CT:GastroIntestinal'

    var_0 = get_all_subclasses(str_0)
    var_1 = get_all_subclasses(str_1)
    var_2 = get_all_subclasses(str_2)


# Generated at 2022-06-24 20:03:33.119874
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    cls_0 = str
    var_0 = get_all_subclasses(cls_0)
    cls_1 = int
    var_1 = get_all_subclasses(cls_1)
    cls_2 = float
    var_2 = get_all_subclasses(cls_2)
    cls_3 = bool
    var_3 = get_all_subclasses(cls_3)

    assert len(var_0) == 0
    assert len(var_1) == 1
    assert len(var_2) == 1
    assert len(var_3) == 1
    assert complex in var_0
    assert complex not in var_1
    assert complex not in var_2
    assert complex not in var_3


# Main function

# Generated at 2022-06-24 20:03:36.749345
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True == True


# Generated at 2022-06-24 20:03:38.622768
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()



# Generated at 2022-06-24 20:03:45.760150
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    start_time = time.time()

    # check if function get_all_subclasses returns the correct output
    assert test_case_0() == ['CT:HIV']

    run_time = time.time() -start_time
    return "Success" if run_time < 5 else "Failure"



# Generated at 2022-06-24 20:03:46.382454
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True

# Generated at 2022-06-24 20:03:48.238839
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:03:49.547272
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # No assert from the function
    return


# Generated at 2022-06-24 20:03:58.398639
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Init the class to be tested
    # data_dir = './'
    # m = models.load_model(data_dir)
    A = type('A', (object,), dict())
    B = type('B', (A,), dict())
    C = type('C', (A,), dict())
    D = type('D', (B, C), dict())

    print(A.__mro__)
    print(B.__mro__)
    print(C.__mro__)
    print(D.__mro__)

    all_subclasses_of_A = get_all_subclasses(A)
    assert D in all_subclasses_of_A

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:04:01.396306
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Run 0 test case
    str_0 = 'CT:HIV'
    var_0 = get_all_subclasses(str_0)
    assert "set" in str(type(var_0)) and len(var_0) == 1



# Generated at 2022-06-24 20:04:04.041065
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # testcase 0
    assert test_case_0() == 0


if __name__ == '__main__':
    import sys
    import pytest

    pytest.main(sys.argv)

    # Unit test for function test_case_0
    test_case_0()

# Generated at 2022-06-24 20:04:07.664428
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        if not test_case_0():
            raise AssertionError
    except AssertionError as ae:
        print(ae)
        print("AssertionError occurred in test_get_all_subclasses()")
    else:
        print("test_get_all_subclasses() passed")



# Generated at 2022-06-24 20:04:09.035792
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == {
        unicode,
        str
    }

# Generated at 2022-06-24 20:04:09.748634
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:04:22.649177
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    pass

# Generated at 2022-06-24 20:04:23.493616
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True == True



# Generated at 2022-06-24 20:04:27.225004
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print(get_all_subclasses)


if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:04:29.007638
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print(get_all_subclasses(str))

# Generated at 2022-06-24 20:04:33.087608
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert(len(get_all_subclasses(BaseException)) >= 8)
    assert(len(get_all_subclasses(object)) == 1)
    assert(len(get_all_subclasses(int)) == 0)

# Generated at 2022-06-24 20:04:35.365524
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    str = 'CT:HIV'
    var = get_all_subclasses('CT:HIV')
    print(var)

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:04:39.241388
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    comment = 'Return type should be an iterable.'
    assert issubclass(get_all_subclasses(str).__class__, type(iter(()))), comment

# Generated at 2022-06-24 20:04:43.200447
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Call function to be tested
    assert callable(get_all_subclasses)



# Generated at 2022-06-24 20:04:51.484808
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert_equal(get_all_subclasses(str), {list, tuple})
    assert_equal(get_all_subclasses(int), {bool})  # Here we go.
    assert_equal(get_all_subclasses(float), {})
    assert_equal(get_all_subclasses(complex), {})
    assert_equal(get_all_subclasses(dict), {})
    assert_equal(get_all_subclasses(list), {})
    assert_equal(get_all_subclasses(tuple), {})
    assert_equal(get_all_subclasses(bool), {})
    assert_equal(get_all_subclasses(type(None)), {})
    assert_equal(get_all_subclasses(Ellipsis), {})

# Generated at 2022-06-24 20:04:56.550702
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Code must be called from main
if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:05:02.976638
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys

    if(len(sys.argv) > 1):
        for arg in sys.argv[1:]:
            eval('test_case_' + arg + '()')
    else:
        for i in range(18):
            eval('test_case_' + str(i) + '()')



# Generated at 2022-06-24 20:05:04.310749
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)



# Generated at 2022-06-24 20:05:13.794093
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert type(get_all_subclasses(1)) == set


# class ThatClass(object):
#     pass
#
#
# class ThisClass(ThatClass):
#     pass
#
#
# class TheOtherClass(ThatClass):
#     pass
#
#
# class ThatOtherClass(object):
#     pass
#
#
# class ThisOtherClass(ThatOtherClass):
#     pass
#
#
# class TheOtherOtherClass(ThatOtherClass):
#     pass
#
#
# class ThisClassBase(object):
#     pass
#
#
# class ThisClass(ThisClassBase):
#     pass

# Generated at 2022-06-24 20:05:20.541660
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils.basic import AnsibleModule, missing_required_lib
    import sys
    import os

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
        ),
        supports_check_mode=True,
    )

    path = module.params['path']

    # check if path exists
    if not os.path.exists(path):
        module.fail_json(msg="Path %s doesn't exist" % path)


# Generated at 2022-06-24 20:05:21.072200
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True

# Generated at 2022-06-24 20:05:25.600521
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = "test_val"
    result = get_all_subclasses(str_0)
    assert result == "test_val"


# Generated at 2022-06-24 20:05:27.774831
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() == 'CT:HIV'


# This function is used by Resmoke test discovery to identify the test cases to run.

# Generated at 2022-06-24 20:05:37.361434
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A0:
        pass

    class A1(A0):
        pass

    class A2(A1):
        pass

    class A3(A1):
        pass

    class A4(A0):
        pass

    class A5(A4):
        pass

    class A6(A5):
        pass

    class A7(A5):
        pass

    assert get_all_subclasses(A0) == {A1, A2, A3, A4, A5, A6, A7}
    assert get_all_subclasses(A1) == {A2, A3}
    assert get_all_subclasses(A2) == set()
    assert get_all_subclasses(A3) == set()

# Generated at 2022-06-24 20:05:38.535311
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Ansible parameter_set_context



# Generated at 2022-06-24 20:05:41.957892
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()



# Generated at 2022-06-24 20:05:51.016970
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print("in test_get_all_subclasses")


if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:05:53.471138
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = 'CT:HIV'
    var_0 = get_all_subclasses(str_0)
    assert var_0 == 'CT:CMV'

# Generated at 2022-06-24 20:05:59.393938
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = 'CT:HIV'
    var_1 = get_all_subclasses(str_0)
    print(var_1)
    int_0 = isinstance(var_1,set)
    assert int_0 == 1

if __name__ == "__main__":
    test_get_all_subclasses()
    print('TEST SUCEEDED')

# Generated at 2022-06-24 20:05:59.953097
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    pass

# Generated at 2022-06-24 20:06:04.978468
# Unit test for function get_all_subclasses

# Generated at 2022-06-24 20:06:14.032253
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses()
    var_1 = get_all_subclasses()
    var_2 = get_all_subclasses()
    var_3 = get_all_subclasses()
    var_4 = get_all_subclasses()
    var_5 = get_all_subclasses()
    var_6 = get_all_subclasses()
    var_7 = get_all_subclasses()
    var_8 = get_all_subclasses()
    var_9 = get_all_subclasses()
    var_10 = get_all_subclasses()
    var_11 = get_all_subclasses()
    var_12 = get_all_subclasses()
    var_13 = get_all_subclasses()
    var_14 = get_all_subclasses()
    var_15

# Generated at 2022-06-24 20:06:17.000901
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    parent = Base
    subclasses = get_all_subclasses(parent)
    assert(subclasses == set([A, B]))


# Generated at 2022-06-24 20:06:19.211175
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == set
    assert get_all_subclasses(bool) == set([int])
    assert get_all_subclasses(int) == set()


# Generated at 2022-06-24 20:06:22.409149
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == {unicode}

# Test to check that inheritance works as expected

# Generated at 2022-06-24 20:06:27.857857
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test case definition
    list_0 = []
    list_1 = []
    list_2 = []
    list_3 = []
    list_4 = []
    list_5 = []
    list_6 = []
    str_0 = 'UV'
    str_1 = 'CT:HIV'
    str_2 = 'Toxicology'
    str_3 = 'Surveillance'
    str_4 = 'Research'
    str_5 = 'Quality Improvement'
    list_0.append(str_0)
    list_1.append(str_1)
    list_2.append(str_2)
    list_3.append(str_3)
    list_4.append(str_4)
    list_5.append(str_5)

# Generated at 2022-06-24 20:06:42.002175
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Checking the content of str_0
    str_0 = 'CT:HIV'
    assert get_all_subclasses(str_0) == {'CT:HIV_2'}



# Generated at 2022-06-24 20:06:44.174965
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # input data
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    # test get_all_subclasses
    assert get_all_subclasses(A) == set([B, D, C])

# Generated at 2022-06-24 20:06:52.402939
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from types import ClassType
    from collections import Iterable
    from test_utils import Class0, Class1, Class2, Class3, Class4
    assert isinstance(get_all_subclasses(Class0), Iterable)
    assert isinstance(get_all_subclasses(Class0)[0], ClassType)
    assert get_all_subclasses(Class0)[0] == Class1
    assert get_all_subclasses(Class0)[1] == Class2
    assert get_all_subclasses(Class0)[2] == Class3
    assert get_all_subclasses(Class0)[3] == Class4

# Generated at 2022-06-24 20:06:53.636621
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == set([unicode])



# Generated at 2022-06-24 20:07:00.206998
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test case 0
    print('Test case 0')
    str_0 = 'CT:HIV'
    var_0 = get_all_subclasses(str_0)
    print('Result:')
    print(var_0)
    # Test case 1
    print('Test case 1')
    str_0 = 'CT:Morbidity'
    var_0 = get_all_subclasses(str_0)
    print('Result:')
    print(var_0)
    # Test case 2
    print('Test case 2')
    str_0 = 'CT:Immunization'
    var_0 = get_all_subclasses(str_0)
    print('Result:')
    print(var_0)
    # Test case 3
    print('Test case 3')

# Generated at 2022-06-24 20:07:01.070128
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    expected = 8
    observed = len(get_all_subclasses(str))
    assert expected == observed

# Generated at 2022-06-24 20:07:08.894869
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert 'A' == 'A'

# ---------------------------------------------------------------------------
# Copyright 2016 Cisco Systems
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ------------------------------------------------------------------
'''
# Test the PyDevd API - Test case for module 'get_all_subclasses'
'''
import unittest

# Generated at 2022-06-24 20:07:11.401018
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()
    
if __name__ == "__main__":
    test_get_all_subclasses()
    print("Success")


# Generated at 2022-06-24 20:07:16.641445
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # prepare data
    str1 = 'CT:HIV'
    expected_result = 'CT:HIV'

    # get actual result
    result = get_all_subclasses(str1)

    # compare result to expected result
    assert result == expected_result




# Generated at 2022-06-24 20:07:21.097217
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Read in and parse test cases from input file
    file = open('test_cases_for_get_all_subclasses.txt', 'r')
    for line in file:
        test_case_0()

    # Run unit tests
    #test_case_0()

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:07:55.724077
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == {bytes, unicode}, "Incorrect value for get_all_subclasses(str)"

# Generated at 2022-06-24 20:08:01.570432
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()


# Python library imports

# Import Ansible modules
from ansible.module_utils.basic import *
import os
import sys
import requests

# Global variables

headers = {
    'APIKEY': 'APIKEY',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept': 'application/json'
}

url = 'https://www.virustotal.com/vtapi/v2/file/report'
params = {'apikey': 'APIKEY', 'resource': 'MD5'}

# Function definitions



# Generated at 2022-06-24 20:08:06.220876
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        # with no error
        test_case_0()
    except Exception as e:
        raise AssertionError('Test exception raised: {}'.format(e))
    except:
        raise AssertionError('Test unexpected exception')


# Generated at 2022-06-24 20:08:09.864431
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = 'CT:HIV'
    var_0 = get_all_subclasses(str_0)
    assert var_0 == str_0


# Generated at 2022-06-24 20:08:11.099345
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_1()
    test_case_0()

# Generated at 2022-06-24 20:08:17.894091
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(B, C, D):
        pass

    class G(B, D):
        pass

    class H(B, D):
        pass

    for c in get_all_subclasses(A):
        print(c)


if __name__ == '__main__':
    print('Start program')
    test_case_0()
    test_get_all_subclasses()

# Generated at 2022-06-24 20:08:20.133163
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print(get_all_subclasses(str))

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:08:22.274706
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == set()


if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:08:23.398306
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

__all__ = ["get_all_subclasses"]

# Generated at 2022-06-24 20:08:24.532183
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses('ABC') == 'get_all_subclasses() is not implemented'

# Generated at 2022-06-24 20:09:23.436563
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == {bytes}
    assert get_all_subclasses(bytes) == set()



# Generated at 2022-06-24 20:09:24.600104
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.utils.module_docs_fragments import get_all_subclasses
    assert get_all_subclasses.__name_

# Generated at 2022-06-24 20:09:31.929844
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    num_subclasses = 0
    num_subclasses += len(get_all_subclasses(str))
    num_subclasses += len(get_all_subclasses(int))
    # This is a somewhat arbitrary number, but it will likely detect regressions should a new
    # subclass be added in the future.
    assert num_subclasses > 10



# Generated at 2022-06-24 20:09:36.790798
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(int) == set(
        [bool,
         float,
         complex,
         int,
         long,
         ]
    ), "get_all_subclasses({0}) should return {1}, got {2}".format(
        int,
        set([bool, float, complex, int, long]),
        get_all_subclasses(int)
    )

# Generated at 2022-06-24 20:09:38.825179
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = 'CT:HIV'
    var_0 = get_all_subclasses(str_0)
    pass

# Generated at 2022-06-24 20:09:44.943830
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    for cls in get_all_subclasses(list):
        assert issubclass(cls, list)
    for cls in get_all_subclasses(dict):
        assert issubclass(cls, dict)
    # Just test if we have a match
    assert list in get_all_subclasses(object)




# Generated at 2022-06-24 20:09:48.637989
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test that get_all_subclasses returns an iterable with the correct number of items.
    """
    assert len(get_all_subclasses(str)) == 1


# Generated at 2022-06-24 20:09:53.449832
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert 0 == 0

# class cc:
#     # print(cc)
#
#     def __init__(self):
#         print(self.__doc__)
#         print(self.args)
#         print(self.kwargs)
#
# cc()

# Generated at 2022-06-24 20:09:55.766829
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses(test_case_0)
    assert var_0 == 'CT:HIV'

# Generated at 2022-06-24 20:09:57.953178
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()
    test_case_1()
    test_case_2()

# Python 3.6+