

# Generated at 2022-06-24 20:01:47.186221
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True

# Generated at 2022-06-24 20:01:48.841499
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    with pytest.raises(AssertionError):
        test_case_1()


# Generated at 2022-06-24 20:01:53.026323
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:01:53.980503
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    pass

# Generated at 2022-06-24 20:02:02.260544
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # No coverage for boolean, integers and string
    try:
        test_case_0()
    except:
        pass
    # Create a class hierarchy with abc.ABCMeta metaclass
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(E):
        pass
    class H(G):
        pass
    # Test all possible combinations
    expected = {B, D, C, E, F, G, H}
    assert expected == get_all_subclasses(A)
    assert {D} == get_all_subclasses(B)
    assert {E, F, G, H} == get_all_sub

# Generated at 2022-06-24 20:02:04.168264
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        assert get_all_subclasses(bool) == set([])
    except:
        return False
    return True

# Generated at 2022-06-24 20:02:10.888581
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    TEST_CASES = [
        dict(
            name='0',
            function=test_case_0,
            exception=TypeError,
            exception_message="bool_0 is not a class",
        ),
#        dict(
#            # Should fail because bool_1 is not a class
#            name='1',
#            function=test_case_1,
#            exception=TypeError,
#            exception_message="bool_1 is not a class",
#        ),
#        dict(
#            # Should pass
#            name='2',
#            function=test_case_2,
#        ),
    ]


# Generated at 2022-06-24 20:02:20.917670
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import pytest
    from ansible.module_utils._text import to_text

    from ansible.module_utils._utils import get_all_subclasses
    from ansible.module_utils._text import to_bytes

    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(B):
        pass
    class G(E):
        pass

    assert get_all_subclasses(A) == set([C, D, E, G])
    assert get_all_subclasses(B) == set([F])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set([E, G])

# Generated at 2022-06-24 20:02:21.906012
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert(get_all_subclasses(bool))


# Generated at 2022-06-24 20:02:22.777395
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses is not None



# Generated at 2022-06-24 20:02:33.685686
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bool_0 = False
    var_0 = get_all_subclasses(bool_0)
    bool_1 = True
    var_1 = get_all_subclasses(bool_1)
    bool_2 = bool(0)
    var_2 = get_all_subclasses(bool_2)
    bool_3 = bool(1)
    var_3 = get_all_subclasses(bool_3)
    assert var_0 != var_1 != var_2 != var_3 != None, "get_all_subclasses does not work as expected"

# Generated at 2022-06-24 20:02:36.552442
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses(bool)
    assert isinstance(var_0, set)
    assert len(var_0) == 1
    assert isinstance(var_0.pop(), bool)



# Generated at 2022-06-24 20:02:37.795184
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True == bool_0
    assert 0 == len(var_0)

# Generated at 2022-06-24 20:02:38.619026
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:02:40.138854
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    cls = bool_0 = False
    var_0 = get_all_subclasses(cls)
    assert var_0 == ()



# Generated at 2022-06-24 20:02:46.196963
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bool_0 = False
    assert get_all_subclasses(bool_0) == {False, True}
    str_0 = "string"
    assert get_all_subclasses(str_0) == {basestring, str, unicode}
    int_0 = 1
    assert get_all_subclasses(int_0) == {int, long}
    str_1 = ""
    assert get_all_subclasses(str_1) == {basestring, str, unicode}
    int_1 = 0
    assert get_all_subclasses(int_1) == {int, long}
    bool_1 = True
    assert get_all_subclasses(bool_1) == {False, True}


if __name__ == "__main__":
    test_case_0()
    test_get_

# Generated at 2022-06-24 20:02:50.296688
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == set()
    assert get_all_subclasses(False) == set()
    assert get_all_subclasses(list) == set()



# Generated at 2022-06-24 20:02:57.698397
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert(test_case_0() == None), "test_case_0()"

# Generated at 2022-06-24 20:02:59.854283
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = False
    var_1 = get_all_subclasses(var_0)



# Generated at 2022-06-24 20:03:01.444256
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(False) == [True, False]

# Generated at 2022-06-24 20:03:14.763083
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from copy import deepcopy
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils._text import to_bytes
    # During testing we need a different behavior for sending ansible.module_utils.basic.AnsibleModule.exit_json
    # to the module.
    # In order to do that we set the module.exit_json to our own exit_json
    ansible_module_exit_json = ansible.module_utils.basic.AnsibleModule.exit_json
    # We declare an exit_json function with different behavior - in our case it just raises an exception
    def exit_json(*args, **kwargs):
        raise Exception(to_bytes(json.dumps(kwargs)))
    # We set the AnsiModule.exit_json to the exit_json function we created
    ansible

# Generated at 2022-06-24 20:03:23.302150
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = False
    var_1 = True
    var_2 = get_all_subclasses(var_0)
    assert var_2 == set()
    var_3 = get_all_subclasses(var_1)
    assert var_3 == set()
    var_4 = str
    var_5 = ''
    var_6 = get_all_subclasses(var_4)
    assert var_6 == set([basestring])
    var_7 = get_all_subclasses(var_5)
    assert var_7 == set([str, unicode, basestring])

# Generated at 2022-06-24 20:03:31.897730
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestClass_0:
        """
        This is a test class
        """
        pass

    class TestSubClass_0(TestClass_0):
        """
        This is a test subclass
        """
        pass

    class TestSubSubClass_0(TestSubClass_0):
        """
        This is a test subsubclass
        """
        pass

    class TestSubClass_1(TestClass_0):
        """
        This is a second test subclass
        """
        pass

    assert TestClass_0 in get_all_subclasses(TestClass_0)
    assert TestSubClass_0 in get_all_subclasses(TestClass_0)
    assert TestSubSubClass_0 in get_all_subclasses(TestClass_0)

# Generated at 2022-06-24 20:03:33.358306
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True == True # TODO: may be false



# Generated at 2022-06-24 20:03:40.228764
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        from collections import OrderedDict
    except ImportError:
        from ansible.utils.ordereddict import OrderedDict
    test_classes = {
        'a': object,
        'b': OrderedDict,
        'c': OrderedDict,
    }
    test_class_dict = dict()
    for class_name, base_class in test_classes.items():
        test_class = type(class_name, (base_class,), {})
        test_class_dict[class_name] = test_class

    assert get_all_subclasses(object) == set(test_class_dict.values())

    if test_class_dict['b'] in get_all_subclasses(object):
        raise RuntimeError('get_all_subclasses failed')
    else:
        pass



# Generated at 2022-06-24 20:03:47.534663
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E])


# Generated at 2022-06-24 20:03:48.464771
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert(test_case_0() == None)

# Generated at 2022-06-24 20:03:51.687180
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bool_0 = False
    var_0 = get_all_subclasses(bool_0)
    assert var_0 == {int,float}

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 20:03:54.875363
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print("Testing function get_all_subclasses")
    assert test_case_0()

# Execute test cases
if __name__ == "__main__":
    test_get_all_subclasses()
    print("All tests passed successfully!")

# Generated at 2022-06-24 20:03:58.200259
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses(AnsibleModule)
    assert True == isinstance(var_0, set)
    assert True == isinstance(list(var_0)[0], type)
    assert True == issubclass(list(var_0)[0], AnsibleModule)

# Generated at 2022-06-24 20:04:11.513332
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_1 = get_all_subclasses(False)
    assert len(var_1) == 1
    for current in var_1:
        assert current == bool



# Generated at 2022-06-24 20:04:13.011364
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = test_case_0()
    assert var_0 == False


# Generated at 2022-06-24 20:04:16.851853
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(False) == {bool, int}
    assert get_all_subclasses(int) == {bool, int, long}
    assert get_all_subclasses(bool) == {bool, int}
    assert get_all_subclasses(NavigableString) == {NavigableString, PreformattedString, Comment, Declaration, ProcessingInstruction}

# Generated at 2022-06-24 20:04:18.731102
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bool_0 = False
    var_0 = get_all_subclasses(bool_0)


if __name__ == '__main__':
    test_case_0()
    test_get_all_subclasses()

# Generated at 2022-06-24 20:04:25.797058
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence
    from ansible.module_utils.common._collections_compat import MutableSet

    required_subclasses = ['_ansible_select_dest', '_ansible_select_src', 'MutableSet',
                           '_ansible_string_concat', 'MutableMapping', 'MutableSequence']
    assert set(required_subclasses).issubset(set([to_native(s.__name__) for s in get_all_subclasses(MutableMapping)]))


# Generated at 2022-06-24 20:04:29.689504
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except Exception:
        assert False



# Generated at 2022-06-24 20:04:30.496072
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:04:33.600680
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(False) == set()



# Generated at 2022-06-24 20:04:34.417444
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()



# Generated at 2022-06-24 20:04:42.684134
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bool_0 = False
    var_0 = get_all_subclasses(bool_0)
    assert var_0 != None, 'Does not return None'
    assert len(var_0) == 1, 'Does not return bool'
    bool_0 = False
    var_0 = get_all_subclasses(bool_0)
    bool_0 = True
    var_1 = get_all_subclasses(bool_0)
    assert var_0 == var_1, 'Does not return bool'
    list_0 = []
    var_0 = get_all_subclasses(list_0)
    assert len(var_0) == 1, 'Does not return list'
    dict_0 = {}
    var_0 = get_all_subclasses(dict_0)

# Generated at 2022-06-24 20:05:07.547561
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = True
    var_2 = get_all_subclasses(var_0)
    var_3 = len(var_2)
    assert var_3 == 0


# Generated at 2022-06-24 20:05:16.958580
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bool_0 = False
    assert issubclass(get_all_subclasses(bool_0), set)
    assert get_all_subclasses(bool_0) == set()
    bool_1 = True
    assert issubclass(get_all_subclasses(bool_1), set)
    assert get_all_subclasses(bool_1) == set()
    byte_0 = b'\x80\x00\x0C\x03'
    assert issubclass(get_all_subclasses(byte_0), set)
    assert get_all_subclasses(byte_0) == set()

# Generated at 2022-06-24 20:05:23.750878
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = 'AnsibleModule'
    try:
        import ansible
        from ansible.module_utils import basic
        has_ansible_module_utils = True
    except ImportError:
        has_ansible_module_utils = False

    if has_ansible_module_utils:
        var_1 = getattr(basic, var_0)
        var_2 = get_all_subclasses(var_1)
        assert var_2
    else:
        # AnsibleModule is not available
        assert not var_0


# Generated at 2022-06-24 20:05:24.597242
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()


# Generated at 2022-06-24 20:05:25.474961
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() is not None

# Generated at 2022-06-24 20:05:28.285189
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print('\n\nStart test_get_all_subclasses\n')
    test_case_0()
    print('\nFinished test_get_all_subclasses\n')


# Generated at 2022-06-24 20:05:33.128184
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bool_0 = False
    var_0 = get_all_subclasses(bool_0)
    bool_0 = True
    var_1 = get_all_subclasses(bool_0)
    bool_0 = True
    var_2 = get_all_subclasses(bool_0)
    bool_0 = False
    var_3 = get_all_subclasses(bool_0)

# Generated at 2022-06-24 20:05:35.964824
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

if __name__ == '__main__':
    pass

# Generated at 2022-06-24 20:05:39.504667
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # test_case_0
    try:
        test_case_0()
    except Exception as e0:
        print('Test case 0 failed')
        print(e0)

# Main
if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:05:43.401077
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(False) is None, 'did not return None as expected'
    assert get_all_subclasses(False) == set(), 'did not return set() as expected'

# Generated at 2022-06-24 20:06:38.030273
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)



# Generated at 2022-06-24 20:06:39.017941
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)


# Generated at 2022-06-24 20:06:40.286466
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test cases
    test_case_0()



# Generated at 2022-06-24 20:06:41.651185
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)
    assert get_all_subclasses("test") == set([])
    assert get_all_subclasses(0) == set([int])

# Generated at 2022-06-24 20:06:47.448327
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    from ansible.module_utils._text import to_text

    a, b, c = type('a', (), {}), type('b', (a,), {}), type('c', (b,), {})
    d, e = type('d', (), {}), type('e', (d,), {})

    all_subs = get_all_subclasses(a)
    len_all_subs = len(all_subs)
    len_all_subs_should_be = 3

    assert len_all_subs == len_all_subs_should_be

    all_subs = list(get_all_subclasses(d))
    len_all_subs = len(all_subs)
    len_all_subs_should_be = 1

    assert len_all_subs == len_all

# Generated at 2022-06-24 20:06:56.834647
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bool_1 = False
    var_1 = get_all_subclasses(bool_1)
    assert var_1 == set()
    from ansible.module_utils import six
    bool_3 = True
    var_3 = get_all_subclasses(six.integer_types)
    assert var_3 == set()
    from ansible.module_utils._text import to_text
    var_5 = get_all_subclasses(to_text)
    assert var_5 == set()
    bool_8 = False
    var_8 = get_all_subclasses(bool_8)
    assert var_8 == set()
    var_10 = get_all_subclasses(bool_8)
    assert var_10 == set()
    var_12 = get_all_subclasses(to_text)
    assert var

# Generated at 2022-06-24 20:06:57.634116
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:07:02.791423
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Tests for function 'get_all_subclasses'
    assert callable(get_all_subclasses)
    test_case_0()


# Generated at 2022-06-24 20:07:05.013510
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

if __name__ == '__main__':
    test_get_all_subclasses()
    test_case_0()

# Generated at 2022-06-24 20:07:10.917199
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bool_0 = False
    float_0 = float(0.0)
    float_1 = float(1.0)
    int_0 = int(0)
    int_1 = int(1)
    str_0 = str(0)
    str_1 = str(1)
    type_0 = type(0.0)
    # Call function get_all_subclasses with argument (bool_0)
    # int(0), float(0.0), float(1.0), int(1), type(0.0), str(0), str(1), bool(False)
    expected_0 = { int, float, type, str }
    try:
        assert (expected_0 == get_all_subclasses(bool_0))
    except AssertionError:
        print("bool_0 FAILED")


# Generated at 2022-06-24 20:09:21.897404
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bool_0 = False
    var_0_0 = get_all_subclasses(bool_0)

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:09:24.753079
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:09:35.067490
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils.basic import AnsibleModule
    import unittest
    import ansible.module_utils._text as _text

    bool_0 = False
    list_0 = get_all_subclasses(bool_0)
    bool_1 = False
    list_1 = get_all_subclasses(bool_1)
    bool_2 = False
    list_2 = get_all_subclasses(bool_2)
    bool_3 = False
    list_3 = get_all_subclasses(bool_3)
    bool_4 = False
    list_4 = get_all_subclasses(bool_4)
    bool_5 = False
    list_5 = get_all_subclasses(bool_5)
    bool_6 = False

# Generated at 2022-06-24 20:09:38.402237
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except Exception:
        import traceback
        traceback.print_exc()
        assert False

# Unit tests to check if get_all_subclasses is added to the correct namespace

# Generated at 2022-06-24 20:09:39.909261
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test for boolean
    assert test_case_0() == NotImplemented



# Generated at 2022-06-24 20:09:43.498264
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:09:45.089221
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:09:50.130730
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Check that list_0 is equal to ['str', 'int', 'float', 'bool']
    bool_0 = False
    list_0 = get_all_subclasses(bool_0)
    if(list_0 == ['str', 'int', 'float', 'bool']):
        print('function get_all_subclasses is succesfull!')
    else:
        print('function get_all_subclasses is not succesfull!')

# Generated at 2022-06-24 20:09:53.638548
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bool_0 = False
    var_0 = get_all_subclasses(bool_0)
    assert var_0 == set([])

# Generated at 2022-06-24 20:10:04.229407
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        from types import ClassType
    except ImportError:
        from ansible.module_utils._text import to_bytes as ClassType
    except ImportError:
        from ansible.module_utils._text import to_text as ClassType

    class TestClass0(object):
        pass

    class TestClass1(TestClass0):
        pass

    class TestClass2(TestClass1):
        pass

    class TestClass3(TestClass0):
        pass

    assert len(list(get_all_subclasses(TestClass0))) == 3
    assert len(list(get_all_subclasses(TestClass1))) == 2
    assert len(list(get_all_subclasses(TestClass2))) == 1
    assert len(list(get_all_subclasses(TestClass3))) == 2