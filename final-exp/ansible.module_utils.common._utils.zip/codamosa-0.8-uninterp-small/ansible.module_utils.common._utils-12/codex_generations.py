

# Generated at 2022-06-24 20:01:52.043828
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print("# Unit test for function get_all_subclasses")
    print("# function get_all_subclasses:")
    var_0 = True
    print("# var_0: ", var_0)
    var_1 = get_all_subclasses(var_0)
    print("# var_1: ", var_1)
    bool_0 = False
    print("# bool_0: ", bool_0)
    var_2 = get_all_subclasses(bool_0)
    print("# var_2: ", var_2)
    print("# function test_case_0")
    test_case_0()

# main function

# Generated at 2022-06-24 20:01:58.588445
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = True
    var_1 = False
    test_0 = get_all_subclasses(var_0.__class__)
    assert test_0 == set([])
    test_1 = get_all_subclasses(var_1.__class__)
    assert test_1 == set([])

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:01:59.382569
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:02:00.918419
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()


# Program entry point
if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:04.245374
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import pytest
    test_cases = [
        {'test_case_0': ('var', 'bool', 'False')},
    ]
    for test_case in test_cases:
        test_case_id, result, value = test_case.values()[0]
        yield check_get_all_subclasses, test_case_id, result, value


# Generated at 2022-06-24 20:02:09.818048
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_cases = [
        dict(
            test_case_0=dict(
                bool_0=False,
                var_0=get_all_subclasses(bool_0),
            ),
        ),
    ]

    for case in test_cases:
        for test_name in case:
            assert test_name, 'Test is missing a name'
            for kwarg, arg_val in case[test_name].items():
                globals()[kwarg] = arg_val
            try:
                yield function_name,
            finally:
                for kwarg in case[test_name]:
                    del globals()[kwarg]

# Generated at 2022-06-24 20:02:10.469563
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True
    # test_case_0()

# Generated at 2022-06-24 20:02:11.735134
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test case 0: testing a boolean and prints the results
    test_case_0()

# Generated at 2022-06-24 20:02:12.670201
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Test cases
    test_case_0()

# Generated at 2022-06-24 20:02:15.403790
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    a = get_all_subclasses(int)
    b = get_all_subclasses(str)
    c = get_all_subclasses(bool)
    # 3 tests
    print(len(a))

