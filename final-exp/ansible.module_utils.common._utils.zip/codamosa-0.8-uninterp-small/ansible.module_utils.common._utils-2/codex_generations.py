

# Generated at 2022-06-24 20:01:47.885591
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    pass



# Generated at 2022-06-24 20:01:49.769629
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(list) == get_all_subclasses(list)

# Generated at 2022-06-24 20:01:51.016711
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True == True



# Generated at 2022-06-24 20:01:51.874359
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:01:54.993599
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try_0 = test_case_0()
    assert(str(type(try_0)) == "<class 'set'>\n")
    temp_0 = get_all_subclasses(try_0)
    assert(str(type(temp_0)) == "<class 'set'>\n")


# Generated at 2022-06-24 20:01:58.630828
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    result = get_all_subclasses(bytes)
    assert type(result) is set
    assert bytes in result
    assert bytearray in result



# Generated at 2022-06-24 20:02:00.548415
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        assert test_case_0() == b''
    except AssertionError:
        raise AssertionError('The assertion failed.')



# Generated at 2022-06-24 20:02:04.023052
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:02:04.731052
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(test_case_0)



# Generated at 2022-06-24 20:02:11.189809
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import create_autospec
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils._text import to_text

    mock_subclass1 = type("subclass1", (), {})
    mock_subclass2 = type("subclass2", (), {})
    mock_subclass3 = type("subclass3", (), {})
    mock_subclass1.subsubclass1 = mock_subclass2
    mock_subclass1.subsubclass2 = mock_subclass3
    mock_subclass2.subsubsubclass = type("subsubsubclass", (), {})

    mock_cls = type("cls", (), {})

# Generated at 2022-06-24 20:02:19.630735
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    
    # Test for correct type of return value
    assert(isinstance(get_all_subclasses(1), set))
    
    # Test for condition when class is not subclass of any other class
    assert(get_all_subclasses(int) == set())
    
    # Test for condition when class is subclass of some other class
    assert(get_all_subclasses(int) == set())
    

# Generated at 2022-06-24 20:02:20.515269
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(bytes_0) == None

# Generated at 2022-06-24 20:02:21.734186
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-24 20:02:22.624503
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:02:23.435396
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bytes_0 = b''
    pass



# Generated at 2022-06-24 20:02:34.132672
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    assert set([H, G, F]) == get_all_subclasses(E)
    assert set([H, G, F, E]) == get_all_subclasses(D)
    assert set([H, G, F, E, D]) == get_all_subclasses(C)
    assert set([H, G, F, E, D, C]) == get_all_subclasses(B)
    assert set([H, G, F, E, D, C, B]) == get_all_

# Generated at 2022-06-24 20:02:37.335501
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    byte_0 = b''
    var_0 = get_all_subclasses(byte_0)
    assert not var_0, 'Expected value of `var_0` to be False, got: ' + str(var_0)

# Generated at 2022-06-24 20:02:38.623384
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(object) == {type}



# Generated at 2022-06-24 20:02:39.437709
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:02:43.895502
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except Exception as err:
        print("AssertionError raised in test_get_all_subclasses: %s" % err)



# Generated at 2022-06-24 20:02:51.088334
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Tests the following.
    test_case_0()
    # End of test_get_all_subclasses


# Generated at 2022-06-24 20:02:52.127701
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Set up test cases
    test_case_0()

# Generated at 2022-06-24 20:02:53.825386
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:57.191693
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bytes_0 = b''
    var_0 = get_all_subclasses(bytes_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:03:00.701716
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses), "Function `get_all_subclasses` not defined"


# Invoke test_get_all_subclasses to run its unit tests
test_get_all_subclasses()

# Generated at 2022-06-24 20:03:10.301373
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # These tests will fail in Python 2 because its bytes class does not have a __subclasses__ method

    bytes_0 = b''
    var_0 = get_all_subclasses(bytes_0)
    assert(var_0 == set())

    mock_class_0 = type('mock_class_0', (bytes,), {})
    var_1 = get_all_subclasses(bytes)
    assert(mock_class_0 in var_1)
    assert(not any(c not in var_1 for c in get_all_subclasses(mock_class_0)))

    mock_class_1 = type('mock_class_1', (bytes,), {})
    mock_class_2 = type('mock_class_2', (bytes,), {})

# Generated at 2022-06-24 20:03:13.328461
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:03:20.240878
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    object_0 = object()
    bool_0 = bool()
    str_0 = str()
    int_0 = int()
    float_0 = float()
    tuple_0 = tuple()
    list_0 = list()
    dict_0 = dict()
    set_0 = set()
    frozenset_0 = frozenset()


# Generated at 2022-06-24 20:03:20.839495
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True

# Generated at 2022-06-24 20:03:21.735009
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:03:32.553368
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:03:37.060857
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bytes_0 = b''
    var_0 = get_all_subclasses(bytes_0)



# Generated at 2022-06-24 20:03:40.385562
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bytes_0 = b''
    var_0 = get_all_subclasses(bytes_0)

# Generated at 2022-06-24 20:03:41.796407
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    pass

# Generated at 2022-06-24 20:03:43.097965
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses('foo') == 'foo'

# Generated at 2022-06-24 20:03:48.632638
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_1 = get_all_subclasses(unicode)
    assert var_1 is not None and var_1.__class__.__name__ == 'set'
    assert set([int, long]) < var_1 or var_1 < set([int, long])
    assert set([unicode]) < var_1 or var_1 < set([unicode])



# Generated at 2022-06-24 20:03:51.862605
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Building input variable 'bytes_0'
    bytes_0 = bytearray(b'')

    # Call function 'get_all_subclasses'
    var_0 = get_all_subclasses(bytes_0)


# Generated at 2022-06-24 20:03:54.439137
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # This will not have any test values in it, 
    # because we are testing whether or not the 
    # function runs without error.
    try:
        test_case_0()
    except Exception as e:
        raise AssertionError(str(e))


# Generated at 2022-06-24 20:03:55.622708
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-24 20:03:58.239471
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bytes_0 = b''
    var_0 = get_all_subclasses(bytes_0)


if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:04:21.891126
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bytes_0 = b''
    var_0 = get_all_subclasses(bytes_0)

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:04:23.187244
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True
    test_case_0()

# Generated at 2022-06-24 20:04:23.805272
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert 1 == 1


# Generated at 2022-06-24 20:04:30.492498
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # no parameters
    test_case_0()


if __name__ == '__main__':
    import sys
    # The following function call will generate a code coverage report
    # It won't work for command line arguments execept for the first one
    test_get_all_subclasses()
    # sys.argv[1] should be one of the test case number
    if len(sys.argv) > 1:
        testcase_number = int(sys.argv[1])
        func_name = sys.argv[0] + '_' + str(testcase_number)
        locals()[func_name]()

# Generated at 2022-06-24 20:04:36.113577
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    with open('get_all_subclasses_test_data.txt', 'r') as test_data:
        for line in test_data:
            if test_case_0() == line:
                print("Test Case 0 Passed")
            else:
                print("Test Case 0 Failed")

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:04:41.140813
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Testing with 1 input
    func_get_all_subclasses_1 = get_all_subclasses()
    # Testing with 2 inputs
    func_get_all_subclasses_2 = get_all_subclasses()

    # Testing if the function returns what it is supposed to
    assert func_get_all_subclasses_1 == get_all_subclasses('')
    assert func_get_all_subclasses_2 == get_all_subclasses('')

# Generated at 2022-06-24 20:04:42.723549
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True == 1



# Generated at 2022-06-24 20:04:44.354686
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(bytes) == set([bytearray])

# Generated at 2022-06-24 20:04:52.260740
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import subprocess
    from os import path
    # Generate test file
    this_file = path.abspath(__file__)
    test_path = path.join(path.dirname(this_file), '__tmp_test_file.py')
    with open(test_path, 'w') as test_fp:
        with open(this_file, 'r') as this_fp:
            in_test_section = False
            test_case = 0
            for line in this_fp:
                if not in_test_section and line.startswith('# Unit test for function get_all_subclasses'):
                    in_test_section = True
                elif in_test_section:
                    if line.startswith('# Unit test for function'):
                        break

# Generated at 2022-06-24 20:04:55.825777
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-24 20:05:37.545762
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert 1 == 1


# Generated at 2022-06-24 20:05:38.918940
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    this_var = ''
    class_0 = get_all_subclasses(this_var)

# Generated at 2022-06-24 20:05:42.013366
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = test_case_0()

# Generated at 2022-06-24 20:05:42.703326
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # TestCase_0
    test_case_0()

# Generated at 2022-06-24 20:05:46.422086
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:05:46.893653
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True

# Generated at 2022-06-24 20:05:54.633133
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bytes_0 = b''
    var_0 = get_all_subclasses(bytes_0)
    assert var_0 == b''
    list_0 = []
    var_0 = get_all_subclasses(list_0)
    assert var_0 == []
    dict_0 = {}
    var_0 = get_all_subclasses(dict_0)
    assert var_0 == {}
    set_0 = set()
    var_0 = get_all_subclasses(set_0)
    assert var_0 == set()
    bool_0 = bool()
    var_0 = get_all_subclasses(bool_0)
    assert var_0 == bool()
    # b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t

# Generated at 2022-06-24 20:05:56.949694
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(bytes) == set([])

# Generated at 2022-06-24 20:05:58.668488
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:05:59.939932
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bytes_0 = b''
    var_0 = get_all_subclasses(bytes_0)

test_case_0()
test_get_all_subclasses()

# Generated at 2022-06-24 20:07:42.660325
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        assert(subprocess.check_output(['/usr/bin/python3', '-m', 'ansible.module_utils._text', 'get_all_subclasses']) == 'Success')
    except subprocess.CalledProcessError as err:
        print('test_get_all_subclasses failed: ' + str(err))
        raise

# Generated at 2022-06-24 20:07:50.641483
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # no given class should raise an error
    with pytest.raises(TypeError) as error:
        get_all_subclasses()
    assert str(error.value) == 'get_all_subclasses() takes exactly 1 argument (0 given)'

    # no subclass
    result = set(get_all_subclasses(list))
    assert result == set()

    # one level of subclass
    class List(list):
        pass

    result = get_all_subclasses(list)
    assert result == {List}

    # multiple levels of subclasses
    result = get_all_subclasses(list)
    assert result == {List, ListSubclass}



# Generated at 2022-06-24 20:07:51.549122
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    for x in get_all_subclasses(x):
        x


# Generated at 2022-06-24 20:07:55.000498
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() == None

# Generated at 2022-06-24 20:07:57.496012
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()


# Generated at 2022-06-24 20:08:03.517061
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    def test_case_0():
        from ansible_collections.ansible.community.plugins.module_utils._text import to_bytes

        with patch.object(to_bytes, '__subclasses__', return_value=[2]):
            var_0 = get_all_subclasses(to_bytes)
            assert 2 in var_0


# Tested to make sure that it is possible to use the function in a playbook.
# This is not a complete list of the features the function offers.

# Generated at 2022-06-24 20:08:04.434906
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-24 20:08:07.885248
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_bytes
    test_case_0()


# Generated at 2022-06-24 20:08:09.997283
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print('Test get_all_subclasses')
    test_case_0()

test_get_all_subclasses()

# Generated at 2022-06-24 20:08:10.882704
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses('foo') is None