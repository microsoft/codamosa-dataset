

# Generated at 2022-06-24 20:01:56.122752
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import bytes_to_human

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import bytes_to_human

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    set_0 = set()
    var_0 = to_text(get_all_subclasses(set_0), errors='surrogate_or_strict')
    display.display(var_0)

# Generated at 2022-06-24 20:01:58.586477
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses


# Generated at 2022-06-24 20:02:03.411128
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a class `Parent` with 2 subclasses: `Child1` and `Child2`
    class Parent(object):
        def foo(self):
            pass

    class Child1(Parent):
        def bar(self):
            pass

    class Child2(Parent):
        def baz(self):
            pass

    # Retrieve all children of `Parent` and verify that our new classes are included in the set
    result = get_all_subclasses(Parent)
    assert Child1 in result
    assert Child2 in result
    assert len(result) == 2


# Generated at 2022-06-24 20:02:05.287685
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = set()
    var_0 = get_all_subclasses(set_0)
    assert var_0 == {}

# Generated at 2022-06-24 20:02:15.287172
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test for no subclass
    var = set()
    assert set(get_all_subclasses(set)) == var

    # Test for one subclass
    var = {frozenset}
    assert get_all_subclasses(set) == var

    # Test for more subclasses
    var = {frozenset, frozenset([1, 2, 3])}
    assert get_all_subclasses(set) == var

    # Test for unordered set
    var = {frozenset, frozenset([1, 2, 3])}
    assert set(get_all_subclasses(set)) == var

# Generated at 2022-06-24 20:02:19.004590
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list = list()
    assert get_all_subclasses(list) == {set, frozenset}
    assert get_all_subclasses(int) == {bool}
    assert get_all_subclasses(str) == {bytes, bytearray}
    assert get_all_subclasses(dict) == {defaultdict, OrderedDict}
    assert get_all_subclasses(set) == {frozenset}
    assert get_all_subclasses(float) == {complex}
    assert get_all_subclasses(range) == set()

# Generated at 2022-06-24 20:02:21.993365
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(set) == {frozenset, set}
    assert get_all_subclasses(object) == set(type.__subclasses__())
    assert get_all_subclasses(str) == {str}

# Generated at 2022-06-24 20:02:32.333051
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(C):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F}
    assert get_all_subclasses(B) == {D, E}
    assert get_all_subclasses(C) == {F}
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

    class AA:
        pass
    class BB(AA):
        pass
    class CC(AA):
        pass
    class DD(BB):
        pass

# Generated at 2022-06-24 20:02:36.850804
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Test with a parameter of incorrect type
    try:
        get_all_subclasses(0)
    except TypeError as e:
        assert(e.message == 'Only class can be sorted')

    # Test with a known class
    var_0 = get_all_subclasses(object)
    assert(len(var_0) == 369)

# Generated at 2022-06-24 20:02:43.868690
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a testing class
    class Parent(object):
        '''
        This is the parent class for testing get_all_subclasses
        '''
        pass

    class Child1(Parent):
        '''
        This is the first child class for testing get_all_subclasses
        '''
        pass

    class Child2(Parent):
        '''
        This is the second child class for testing get_all_subclasses
        '''
        pass

    class Grandchild1(Child1):
        '''
        This is the grandchild class for testing get_all_subclasses
        '''
        pass

    class Grandchild2(Child1):
        '''
        This is the grandchild class for testing get_all_subclasses
        '''
        pass


# Generated at 2022-06-24 20:02:47.275608
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()



# Generated at 2022-06-24 20:02:48.495883
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert not hasattr(test_get_all_subclasses(), 'test_case_0')

# Generated at 2022-06-24 20:02:50.545329
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(set) == {frozenset, frozenset([]), frozenset([1])}

# Generated at 2022-06-24 20:02:55.553822
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(C): pass
    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(B)) == set([C, D])
    assert set(get_all_subclasses(C)) == set([D])
    assert set(get_all_subclasses(D)) == set([])

# Generated at 2022-06-24 20:02:56.259326
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    pass



# Generated at 2022-06-24 20:03:06.357169
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = set()
    set_1 = frozenset()
    set_2 = dict()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    list_0 = list()
    list_1 = list()
    list_2 = list()
    list_3 = list()
    list_4 = list()
    list_5 = list()
    list_6 = list()

# Generated at 2022-06-24 20:03:14.531335
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import abc, OrderedDict, deque, defaultdict, UserDict, UserList, UserString
    set_0 = get_all_subclasses(abc.Set)
    frozenset_0 = get_all_subclasses(abc.FrozenSet)
    mapping_0 = get_all_subclasses(abc.Mapping)
    keys_view_0 = get_all_subclasses(abc.KeysView)
    items_view_0 = get_all_subclasses(abc.ItemsView)
    values_view_0 = get_all_subclasses(abc.ValuesView)
    mapping_proxy_0 = get_all_subclasses(abc.MappingProxyType)
    ordered_dict_0 = get_all_subclasses(OrderedDict)

# Generated at 2022-06-24 20:03:16.441737
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:03:18.954626
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses.__doc__
    assert type(get_all_subclasses(["a"])) is set



# Generated at 2022-06-24 20:03:23.534924
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test case for the get_all_subclasses function

    :returns: None
    :rtype: None
    """
    var_1 = set([])
    try:
        var_2 = get_all_subclasses(var_1)
    except:
        print("Exception found in function get_all_subclasses")
        print("")


# Generated at 2022-06-24 20:03:34.213884
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
  arg0 = '''

'''
  expected_output = '''

'''
  with patch('sys.stdout', new_callable=StringIO) as fake_stdout:
    get_all_subclasses(arg0)
    assert fake_stdout.getvalue() == expected_output

# Generated at 2022-06-24 20:03:36.870289
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert(test_case_0())

# Generated at 2022-06-24 20:03:47.040185
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import random
    import os
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text

    PY3 = sys.version_info[0] == 3

    # Set default values for testing
    DIR = os.path.dirname(os.path.realpath(__file__))

    OUTPUT_DIR = os.path.join(DIR, 'test_output')

    ANSIBLE_MODULES_PATH = os.path.join(DIR, '../../../../lib/ansible/modules')

    SUMMARY_FILE = os.path.join(ANSIBLE_MODULES_PATH, 'summary')

    os.path.isfile

# Generated at 2022-06-24 20:03:48.763290
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print("Unit test for function `get_all_subclasses`")
    test_case_0()

# Generated at 2022-06-24 20:03:58.073297
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test a class with one sub class
    class A:
        pass
    class B(A):
        pass
    classes = [cls for cls in get_all_subclasses(A)]
    assert len(classes) == 1
    assert B in classes
    assert A not in classes

    # Test a class with one grand-sub class
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    classes = [cls for cls in get_all_subclasses(A)]
    assert len(classes) == 2
    assert B in classes
    assert C in classes
    assert A not in classes

    # Test a class with multiple grand-sub classes
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
   

# Generated at 2022-06-24 20:03:59.959858
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses(set)
    assert isinstance(var_0, set)

# Generated at 2022-06-24 20:04:00.950584
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(Exception) == set()

# Generated at 2022-06-24 20:04:06.868976
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(set()) == {set, frozenset, dict}
    assert get_all_subclasses(dict) == {dict, UserDict}
    assert get_all_subclasses(UserDict) == {UserDict}
    assert get_all_subclasses(UserDict) == {UserDict}

# Generated at 2022-06-24 20:04:07.892699
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert "set" in get_all_subclasses(list)

# Generated at 2022-06-24 20:04:09.531743
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = set()
    set_1 = get_all_subclasses(set_0)
    assert set_1 == set()

# Generated at 2022-06-24 20:04:22.213744
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(set()) == set()
    assert get_all_subclasses(int) == set()
    assert get_all_subclasses(dict) == set()

# Generated at 2022-06-24 20:04:23.123543
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = set()
    var_1 = get_all_subclasses(set_0)


# Generated at 2022-06-24 20:04:24.320123
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    result = get_all_subclasses(set())
    assert 'set' in result  # A set should be in result

# Generated at 2022-06-24 20:04:29.400713
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class c1(object):
        pass

    class c2(object):
        pass

    class c3(object):
        pass

    class c4(object):
        pass

    class c5(object):
        pass

    class c6(object):
        pass

    class c7(object):
        pass

    class c8(object):
        pass

    class c9(object):
        pass

    class c10(object):
        pass

    class c11(object):
        pass

    class c12(object):
        pass

    class c13(object):
        pass

    class c14(object):
        pass

    class c15(object):
        pass

    class c16(object):
        pass

    class c17(object):
        pass

    class c18(object):
        pass

   

# Generated at 2022-06-24 20:04:37.296130
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import doctest
    from ansible.module_utils._text import to_text
    from ansible.module_utils import _utils

    failed, tests = doctest.testmod(m=_utils, optionflags=doctest.NORMALIZE_WHITESPACE)
    if failed == 0:
        print(to_text(u"Success: %d tests passed." % (tests)))

if __name__ == '__main__':
    begin_time = time.time()
    test_get_all_subclasses()
    print("Test End Time: %.2f" % (time.time() - begin_time), 'to run test_get_all_subclasses')

# Generated at 2022-06-24 20:04:42.545351
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(object): pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])

# Generated at 2022-06-24 20:04:51.073771
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()


# Compute the module name based on the filename
from ansible.module_utils.facts import *
from ansible.module_utils.facts.hardware.bsd import *
from ansible.module_utils.facts.hardware.linux import *
from ansible.module_utils.facts.hardware.sunos import *
from ansible.module_utils.facts.hardware.windows import *
from ansible.module_utils.facts.network.base import *
from ansible.module_utils.facts.network.bsd import *
from ansible.module_utils.facts.network.linux import *
from ansible.module_utils.facts.network.sunos import *
from ansible.module_utils.facts.network.windows import *

# Generated at 2022-06-24 20:04:57.205908
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Initializations
    test = []
    result = []

    # Defining class and subclasses
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(G):
        pass

    # Creating a reference list
    for i in [A, B, C, D, E, F, G, H]:
        result.append(i)

    # Creating a test list
    test = list(get_all_subclasses(A))

    # Verifying that the two lists are equal
    assert(test == result)

    # Verifying that the two lists don't reference the same elements

# Generated at 2022-06-24 20:05:06.021312
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Toto(object):
        pass

    class Tata(Toto):
        pass

    class Titi(Toto):
        pass

    class Tutu(Titi):
        pass

    assert get_all_subclasses(Toto) == set([Tata, Titi, Tutu])
    assert get_all_subclasses(Tata) == set([])
    assert get_all_subclasses(Titi) == set([Tutu])
    assert get_all_subclasses(Tutu) == set([])

    assert get_all_subclasses(object) != set([])
    assert get_all_subclasses(object) != 0

    assert get_all_subclasses(set) == set([])
    assert get_all_subclasses(Exception) == set([])


# Generated at 2022-06-24 20:05:09.541867
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    expected_result = set()
    result = get_all_subclasses(set())
    assert result == expected_result, "Test passed"


# Test with built in python classes

# Generated at 2022-06-24 20:05:28.888960
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = set()
    var_0 = get_all_subclasses(set_0)

# Generated at 2022-06-24 20:05:31.916761
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Unit test to assert expected number of subclasses returned
    assert len(list(get_all_subclasses(set))) >= 8


# Unit test to assert if all the subclasses are returned

# Generated at 2022-06-24 20:05:33.048108
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0()

# Generated at 2022-06-24 20:05:40.698577
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_native
    set_0 = set()
    var_0 = get_all_subclasses(set_0)
    assert (var_0 == set_0), to_native("Failed test for get_all_subclasses: Expected {}. Received {}.".format(set_0, var_0))
    set_0 = {list}
    var_0 = get_all_subclasses(set_0)
    assert (var_0 == {list}), to_native("Failed test for get_all_subclasses: Expected {}. Received {}.".format({list}, var_0))
    set_0 = {set, frozenset}
    var_0 = get_all_subclasses(set_0)

# Generated at 2022-06-24 20:05:46.934441
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create an instance of class set
    set_0 = set()
    # Try to find all subclasses of set
    var_0 = get_all_subclasses(set_0)
    # Check if the set of subclasses includes frozenset, set and tuple
    assert frozenset in var_0
    assert set in var_0
    assert tuple in var_0
    # Create an instance of frozenset
    frozenset_0 = frozenset()
    # Try to find all subclasses of frozenset
    var_1 = get_all_subclasses(frozenset_0)
    # Check if the subclasses set is empty
    assert not var_1
    # Create an instance of class set
    set_1 = set()
    # Try to find all subclasses of set
    var_2 = get_all_

# Generated at 2022-06-24 20:05:53.158828
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Testing the following statement:
    # var_0 = get_all_subclasses(set_0)
    # Calling function set_0
    set_0 = set()
    # Calling function get_all_subclasses with parameters set_0
    var_0 = get_all_subclasses(set_0)
    # Printing variable var_0 after calling function get_all_subclasses
    print("get_all_subclasses(set_0) produces: ")
    print(var_0)



# Generated at 2022-06-24 20:06:04.337701
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Unittest for the Python class 'set'
    set_0 = set()
    var_0 = get_all_subclasses(set_0)
    assert(var_0)
    for sc in var_0:
        assert(isinstance(sc, set))

    # Unittest for the Python class 'bool'
    bool_0 = bool()
    var_1 = get_all_subclasses(bool_0)
    assert(var_1)
    for sc in var_1:
        assert(isinstance(sc, bool))

    # Unittest for the Python class 'list'
    list_0 = list()
    var_2 = get_all_subclasses(list_0)
    assert(var_2)
    for sc in var_2:
        assert(isinstance(sc, list))



# Generated at 2022-06-24 20:06:13.184148
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a test class
    class test_get_all(object):
        pass

    class test_true_0(test_get_all):
        pass

    class test_true_1(test_get_all):
        pass

    class test_true_2(test_true_1):
        pass

    class test_false_0(object):
        pass

    class test_false_1(test_false_0):
        pass

    # test cases
    assert test_true_0 in get_all_subclasses(test_get_all)
    assert test_true_1 in get_all_subclasses(test_get_all)
    assert test_true_2 in get_all_subclasses(test_get_all)

# Generated at 2022-06-24 20:06:17.988781
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C(object):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass

    assert set(get_all_subclasses(C)) == set([D, E, F, G])

# Generated at 2022-06-24 20:06:22.567251
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = set()
    var_0 = get_all_subclasses(set_0)
    assert var_0 == set()

# Generated at 2022-06-24 20:07:04.975010
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = set()
    var_1 = get_all_subclasses(set_0)


# Generated at 2022-06-24 20:07:06.761652
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except TypeError as err:
        print(err)
        return False
    return True



# Generated at 2022-06-24 20:07:09.924010
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test case 0
    test_case_0()

# Generated at 2022-06-24 20:07:12.590998
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Test with a class that does not have subclasses
    assert set(get_all_subclasses(str)) == set()

    # Test with a class that does have subclasses
    assert get_all_subclasses(set) == {frozenset}

# Generated at 2022-06-24 20:07:17.787842
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import test_utils

    class TestGetAllSubclasses(unittest.TestCase):
        def test_get_all_subclasses(self):
            pass

    # Create test suite
    suite = unittest.TestLoader().loadTestsFromTestCase(TestGetAllSubclasses)

    # Execute the test suite
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-24 20:07:18.852081
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert 1 == 1

test_module_0 = [('test_module_0', 1)]

# Generated at 2022-06-24 20:07:21.666482
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert_equal(get_all_subclasses, expected)

# Generated at 2022-06-24 20:07:30.663564
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import mock

    def get_all_subclasses(cls):
        try:
            class1 = mock.Mock()
            class2 = mock.Mock()
            class1.__subclasses__.return_value = [class2]
            class2.__subclasses__.return_value = []
            return set([class1, class2])
        except:
            pass
    unittest.mock('ansible._utils.get_all_subclasses', get_all_subclasses)

    class TestGetAllSubclasses(unittest.TestCase):
        @mock.patch('ansible._utils.get_all_subclasses')
        def test_mock_get_all_subclasses(self, mock_get_all_subclasses):
            cls = mock.Mock()
           

# Generated at 2022-06-24 20:07:32.297025
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Set
    assert get_all_subclasses(set) == { frozenset, Set }
    assert get_all_subclasses(str) == { bytes, bytearray, "unicode" }

# Generated at 2022-06-24 20:07:37.294472
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        set_0 = set()
        var_0 = get_all_subclasses(set_0)
    except:
        print("Test getting all subclasses failed.");
        return
    print("Test get_all_subclasses passed");

test_get_all_subclasses()

# Generated at 2022-06-24 20:09:34.918146
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses({}) == set()
    assert get_all_subclasses(()) == {()}
    assert get_all_subclasses(str) == set()
    assert get_all_subclasses(list) == {list, tuple, }
    assert get_all_subclasses(list) == get_all_subclasses(tuple)
    assert {set, } == get_all_subclasses({})
    assert {set, frozenset, } == get_all_subclasses(set)


# Generated at 2022-06-24 20:09:42.605809
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Initialize class A
    class A():
        pass
    # Initialize classes B, C, D
    class B(A):
        pass
    class C(A):
        pass
    class D(A):
        pass
    # Initialize classes E, F
    class E(B):
        pass
    class F(E):
        pass
    # Initialize G, H
    class G(C):
        pass
    class H(D):
        pass

    # Try to get all subclasses of class A
    var_1 = get_all_subclasses(A)
    # Check to make sure the correct classes are returned

# Generated at 2022-06-24 20:09:48.496885
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = set()
    var_0 = get_all_subclasses(set_0)
    if not type(var_0) == set:
        raise ValueError('the returned value should be of type set')



# Generated at 2022-06-24 20:09:59.651536
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Foo:
        pass
    class Bar(Foo):
        pass
    class Baz(Foo):
        pass
    class Qux(Bar):
        pass
    class Quux(Baz):
        pass

    assert(Foo in get_all_subclasses(Foo))
    assert(Foo in get_all_subclasses(Bar))
    assert(Foo in get_all_subclasses(Baz))
    assert(Foo in get_all_subclasses(Qux))
    assert(Foo in get_all_subclasses(Quux))

    assert(Bar in get_all_subclasses(Foo))
    assert(Bar in get_all_subclasses(Baz))
    assert(Bar in get_all_subclasses(Qux))

# Generated at 2022-06-24 20:10:03.148092
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test cases for get_all_subclasses
    test_case_0()
    # Return value tests
    # Function test call
    # Black box tests
    pass



# Generated at 2022-06-24 20:10:07.047771
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses({}.__class__) == {{}.__class__}

# Generated at 2022-06-24 20:10:16.434474
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import PY3
    from ansible.parsing.dataloader import DataLoader

    # Normal use case with list
    set_0 = set()
    var_0 = get_all_subclasses(set_0)
    assert not var_0

    # Normal use case with dict
    set_1 = {}
    var_1 = get_all_subclasses(set_1)
    assert not var_1

    # Normal use case with str
    set_2 = "str"
    var_2 = get_all_subclasses(set_2)
    assert not var_2

    # Normal use case with int
    set_3 = 7

# Generated at 2022-06-24 20:10:17.224527
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses() == "*"

# Generated at 2022-06-24 20:10:17.916035
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:10:19.017350
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() == None, "test_case_0 failed"

# Generated at 2022-06-24 20:10:57.397078
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(tuple) == frozenset([tuple])
    assert get_all_subclasses(set) == frozenset([set, frozenset])
    assert get_all_subclasses(dict) == frozenset([dict, OrderedDict])



# Generated at 2022-06-24 20:11:02.319400
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = set()
    var_0 = get_all_subclasses(set_0)
    assert var_0 == set({dict, frozenset})

# Generated at 2022-06-24 20:11:05.347245
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test case 0
    assert test_case_0() == set()

# Generated at 2022-06-24 20:11:11.139109
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # First, test that get_all_subclasses works on a simple example hierarchy
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    # set of subclasses of A
    subclasses_A = get_all_subclasses(A)
    print(subclasses_A)
    assert(subclasses_A == {B, D, C, E})
    # set of subclasses of B
    subclasses_B = get_all_subclasses(B)
    print(subclasses_B)
    assert(subclasses_B == {D})
    # set of subclasses of C
    subclasses_C = get_all_subclasses(C)

# Generated at 2022-06-24 20:11:16.777946
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    from ansible_collections.notstdlib.moveitallout.tests import utils
    from ansible_collections.notstdlib.moveitallout.tests._utils import get_all_subclasses

    subclasses = get_all_subclasses(utils.TestCase)
    assert utils.TestCaseABC in subclasses
    assert utils.TestCaseXYZ in subclasses



# Generated at 2022-06-24 20:11:19.177246
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()
    test_case_1()
    test_case_2()

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:11:23.810984
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import pytest
    # Create a class
    class MyClass:
        pass
    # Create some child classes
    class MyClassChild1(MyClass):
        pass
    class MyClassChild2(MyClass):
        pass
    class MyClassChild3(MyClassChild1):
        pass
    class MyClassChild4(MyClassChild2):
        pass
    # Child classes of MyClassChild4
    class MyClassChild4Child1(MyClassChild4):
        pass
    class MyClassChild4Child2(MyClassChild4):
        pass
    # Create an instance of MyClassChild4Child1
    class_instance = MyClassChild4Child1()
    # Check if get_all_subclasses return only the expected classes

# Generated at 2022-06-24 20:11:33.745264
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._multiprocessing import ForkingMixIn
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.ec2 import HAS_BOTO3
    module_utils_dict = {
        'Connection': Connection,
        'AnsibleModule': AnsibleModule,
        'ForkingMixIn': ForkingMixIn,
        'MutableMapping': MutableMapping,
        'HAS_BOTO3': HAS_BOTO3,
        'to_text': to_text,
        }

# Generated at 2022-06-24 20:11:42.112114
# Unit test for function get_all_subclasses

# Generated at 2022-06-24 20:11:43.034361
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(set) == set([frozenset])