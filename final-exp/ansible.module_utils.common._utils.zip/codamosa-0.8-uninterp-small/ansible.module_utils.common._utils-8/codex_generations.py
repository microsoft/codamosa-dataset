

# Generated at 2022-06-24 20:01:48.182670
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:01:51.980152
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    classes = get_all_subclasses(A)
    # Expected behaviour: classes should contain B and C
    assert B in classes
    assert C in classes

# Generated at 2022-06-24 20:02:01.171105
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool()
    bool_24 = bool()

# Generated at 2022-06-24 20:02:03.292654
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
#    cls = bool_0
    var_1 = get_all_subclasses(bool)
    if var_1:
        print(var_1)

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:05.464573
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses(list)
    if var_0 == set():
        return 0
    else:
        return 1


# Generated at 2022-06-24 20:02:09.230146
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(bool) == {False, True}


# Generated at 2022-06-24 20:02:11.790838
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = bool()
    bool_0 = False
    get_all_subclasses(var_0)
    get_all_subclasses(bool_0)



# Generated at 2022-06-24 20:02:17.634460
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bool_0 = False
    var_0 = get_all_subclasses(bool_0)

# Boilerplate
if __name__ == '__main__':
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_sequence
    import pytest

    failed, skipped, passed = pytest.main([__file__, '-v', '-p', 'no:warnings'])
    sys.exit(skipped or failed)

# Generated at 2022-06-24 20:02:19.197767
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True

# Generated at 2022-06-24 20:02:26.841871
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bool_0 = False
    var_0 = get_all_subclasses(bool_0)
    bool_1 = True
    var_1 = get_all_subclasses(bool_1)
    bool_2 = True
    var_2 = get_all_subclasses(bool_2)
    bool_3 = False
    var_3 = get_all_subclasses(bool_3)
    bool_4 = True
    var_4 = get_all_subclasses(bool_4)
    bool_5 = False
    var_5 = get_all_subclasses(bool_5)
    bool_6 = False
    var_6 = get_all_subclasses(bool_6)
    bool_7 = False
    var_7 = get_all_subclasses(bool_7)
    bool_8 = True


# Generated at 2022-06-24 20:02:33.047277
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses()



# Generated at 2022-06-24 20:02:34.372938
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)


# Generated at 2022-06-24 20:02:36.509490
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        assert type(var_0) == list
        assert var_0 == ''
    except AssertionError:
        raise AssertionError

# Generated at 2022-06-24 20:02:37.753263
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert type(get_all_subclasses(bool)) == set


# Generated at 2022-06-24 20:02:44.479829
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Retrieve class names
    class_names = [str(x).split('.')[-1].split('\'')[0] for x in get_all_subclasses(dict)]

# Generated at 2022-06-24 20:02:56.129524
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test run of the get_all_subclasses function
    from ansible.module_utils._text import to_native
    from ansible.tests.unit.compat import mock
    import os
    import pytest
    from ansible.module_utils._text import to_native

    # Test case 0
    to_native_0 = to_native(os.path.basename(__file__))
    pytest.raises(Exception, test_case_0)

    # Test case 1
    bool_0 = False
    pytest.raises(Exception, get_all_subclasses, bool_0)

    # Test case 2
    # TODO: Fix the class hierarchy in ansible.module_utils.parsing 
    #       to pass this test case
    # class_name_0 = 'AnsibleModule'
   

# Generated at 2022-06-24 20:03:01.610105
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        assert get_all_subclasses is not None
    except AssertionError as e:
        raise(e)
    try:
        assert get_all_subclasses(test_case_0) is not None
    except AssertionError as e:
        raise(e)

test_get_all_subclasses()

# Generated at 2022-06-24 20:03:10.277972
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Defining classes
    class class_0(bool):
        pass
    class class_1(bool):
        pass
    class class_2(bool):
        pass
    # Initializing class
    cls = bool
    # Results for the following conditions:
    # First, we get all sublasses
    result = get_all_subclasses(cls)
    #Then, we test if all subclasses are contained
    assert class_0 in result
    assert class_1 in result
    assert class_2 in result
    # Finally, we test if there are only subclasses, no other class
    assert len(result) == 3
    # Finally, we check if there are no duplicates
    assert len(result) == len(set(result))



# Generated at 2022-06-24 20:03:13.292974
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:03:15.970684
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert var_0 == None

# Generated at 2022-06-24 20:03:26.144959
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.text.converters import to_bytes

    # Passing a bytes object to the function
    value = b'\xc3\xbc'

    try:
        to_bytes(value)
    except Exception as e:
        assert False, "Unexpected Exception: %s" % e
    else:
        assert True



# Generated at 2022-06-24 20:03:31.276340
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(bool) == {bool}
    class Bool_0:
        pass
    assert get_all_subclasses(Bool_0) == set()
    bool_0 = bool()
    bool_0.__class__ = Bool_0
    assert get_all_subclasses(bool_0) == set()
    var_0 = get_all_subclasses(bool_0)

# Generated at 2022-06-24 20:03:41.697918
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        from types import ClassType
    except ImportError:
        from types import ClassType
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils import _utils

    # A simple test to make sure get_all_subclasses can find its own subclasses
    # Create a subclass of get_all_subclasses
    def get_all_subclasses_sub(cls):
        return []
    get_all_subclasses_sub.__name__ = 'get_all_subclasses_sub'
    _utils.get_all_subclasses_sub = ClassType(get_all_subclasses_sub.__name__,
                                              (object,),
                                              {'__call__': get_all_subclasses_sub})

    # Create another subclass of get_all_subclasses


# Generated at 2022-06-24 20:03:49.642583
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)
    assert isinstance(get_all_subclasses(bool), set)
    assert isinstance(get_all_subclasses(bool()) or get_all_subclasses(bool), set)
    assert isinstance(get_all_subclasses(bool), set)
    assert isinstance(get_all_subclasses(bool()) or get_all_subclasses(bool), set)
    #
    # Tests for get_all_subclasses
    # Raise a TypeError when the argument is not a class
    # assert get_all_subclasses(int())
    #
    # Tests for get_all_subclasses
    # Raise a TypeError when the argument is not a class
    # assert get_all_subclasses(bool())
    #
    # Tests for get_all_subclasses
    #

# Generated at 2022-06-24 20:03:50.993239
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses(bool)


# Generated at 2022-06-24 20:03:52.341123
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(bool) == [True, False]


# Generated at 2022-06-24 20:03:55.805891
# Unit test for function get_all_subclasses

# Generated at 2022-06-24 20:03:56.710535
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:03:57.783869
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()



# Generated at 2022-06-24 20:03:58.990025
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    pass
    # Place your unit test for function get_all_subclasses here


# Generated at 2022-06-24 20:04:14.001416
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    function_name = 'get_all_subclasses'
    assert_raises_regexp(AssertionError, "Type of argument 'cls' must be 'class', got 'bool'", test_case_0)
    # Test successful call to the function
    # Get the class list, which must be a subset of the subclass list
    test_class_list = [type(True), type(False)]
    test_subclass_list = get_all_subclasses(bool)
    test = all([test_class in test_subclass_list for test_class in test_class_list])
    assert_true(test, "In test_" + function_name + "(): Successful call to function '" + function_name + "', but result is unexpected")


# Generated at 2022-06-24 20:04:15.094369
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)
    test_case_0()

# Generated at 2022-06-24 20:04:22.311467
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    cls_3 = get_all_subclasses(object)
    assert cls_3
    cls_2 = get_all_subclasses(str)
    assert cls_2
    cls_1 = get_all_subclasses(float)
    assert cls_1
    cls_0 = get_all_subclasses(int)
    assert cls_0

# Generated at 2022-06-24 20:04:30.656533
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    list_0 = ['A']
    list_0[0] = 'A'
    list_0[0] = 'A'
    list_0[0] = 'A'
    tuple_0 = (1)
    int_0 = 0
    tuple_0 = (1)
    assert (get_all_subclasses(list_0) == set()), "Expected ([]), actual ({0})".format(get_all_subclasses(list_0))
    assert (get_all_subclasses(tuple_0) == set()), "Expected ([]), actual ({0})".format(get_all_subclasses(tuple_0))

# Generated at 2022-06-24 20:04:39.315574
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)
    case_0 = ['Apple']
    case_0_bool_0 = False
    case_0_var_0 = get_all_subclasses(case_0_bool_0)
    assert case_0_var_0 == case_0
    case_1 = None
    case_1_bool_0 = False
    case_1_var_0 = get_all_subclasses(case_1_bool_0)
    assert case_1_var_0 == case_1
    case_2 = 100
    case_2_bool_0 = False
    case_2_var_0 = get_all_subclasses(case_2_bool_0)
    assert case_2_var_0 == case_2
    case_3 = 27.27
    case_3

# Generated at 2022-06-24 20:04:46.763348
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Trivial test of get_all_subclasses
    '''

    var_0 = get_all_subclasses(str)

    var_0.sort()
    assert len(var_0) == 3

    assert var_0[0] == bytearray
    assert var_0[1] == bytes
    assert var_0[2] == unicode



# Generated at 2022-06-24 20:04:50.690209
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:04:52.170343
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses() == "something", "Can't use get_all_subclasses"


# Generated at 2022-06-24 20:05:00.014569
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    :return: A tuple with a boolean and a string.  The boolean is True
             for pass and False for fail.  In the case of failure, the
             string contains details about the failure.
    :rtype: tuple(bool, str)
    '''
    try:
        test_case_0()
    except:
        return (False, "get_all_subclasses() failed")
    else:
        return (True, "get_all_subclasses() passed")

# Generated at 2022-06-24 20:05:04.779457
# Unit test for function get_all_subclasses

# Generated at 2022-06-24 20:05:25.370508
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert(get_all_subclasses(bool) == {False, True})

# Generated at 2022-06-24 20:05:26.498545
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:05:32.822205
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bool_0 = False
    del bool_0
    bool_0 = True
    bool_1 = False
    bool_1 = bool_0
    var_0 = get_all_subclasses(bool_1)
    var_0 = get_all_subclasses(bool_0)
    del bool_0
    del bool_1
    del var_0

if __name__ == '__main__':
    test_case_0()

    # Unit test for function get_all_subclasses
    test_get_all_subclasses()

# Generated at 2022-06-24 20:05:35.740970
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_1 = '__subclasses__'
    assert var_1 not in globals(), 'You cannot setup for this test'
    bool_1 = True
    test_case_0()


# Generated at 2022-06-24 20:05:37.734863
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # cases
    test_case_0()


# Command line entry point

# Generated at 2022-06-24 20:05:42.423062
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert not get_all_subclasses(True)
    assert not get_all_subclasses(False)
    assert not get_all_subclasses(None)
    assert not get_all_subclasses(1)
    assert not get_all_subclasses(3.14)
    assert not get_all_subclasses('string')
    assert not get_all_subclasses([])
    assert not get_all_subclasses(())
    assert not get_all_subclasses({})
    assert not get_all_subclasses(set())

# Generated at 2022-06-24 20:05:48.347760
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert False == get_all_subclasses(bool)
    assert False == get_all_subclasses(int)
    assert False == get_all_subclasses(complex)
    assert False == get_all_subclasses(float)
    assert False == get_all_subclasses(object)
    assert False == get_all_subclasses(bytearray)
    assert False == get_all_subclasses(set)
    assert False == get_all_subclasses(str)
    assert False == get_all_subclasses(tuple)
    assert False == get_all_subclasses(list)
    assert False == get_all_subclasses(dict)

    assert False == test_case_0()

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:05:51.788361
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """Test function get_all_subclasses."""
    assert get_all_subclasses(float) == set([int, complex, long])
    assert get_all_subclasses(int) == set([bool, long])



# Generated at 2022-06-24 20:05:56.848782
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    assert set(get_all_subclasses(object)) == set([bool, A, classmethod, dict, float, int, list, object, property, range, str, tuple, type, complex, bytes, bytearray, memoryview, NotImplementedType, super, file, set])

# Generated at 2022-06-24 20:05:57.860723
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses(None)

# Generated at 2022-06-24 20:06:45.540989
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except:
        print('An exception was raised. Please check your code.')
    else:
        print('No exception was raised. Everything should be OK!')



# Generated at 2022-06-24 20:06:46.102335
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True

# Generated at 2022-06-24 20:06:47.793724
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(bool) == {bool}, "Cannot find all subclasses of a given class!"



# Generated at 2022-06-24 20:06:54.689528
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    for test_input, expected_output in [
        ((True,), {bool, int}),
        ((False,), {bool, int}),
        ((None,), {type(None), bool, int}),
        ((set(),), {set, dict}),
        ((dict(),), {dict}),
        (([],), {list, tuple}),
        ((type(None),), {type(None)}),
    ]:
        assert get_all_subclasses(*test_input) == expected_output

# Generated at 2022-06-24 20:06:56.916297
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() is None

# Generated at 2022-06-24 20:07:00.144075
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    bool_0 = bool
    assert bool_0
    var_0 = get_all_subclasses(bool_0)
    print("Top level subclasses of 'bool' are:")
    for i in var_0:
        print("  "+i.__name__)
    int_0 = int
    assert int_0
    var_1 = get_all_subclasses(int_0)
    print("Top level subclasses of 'int' are:")
    for i in var_1:
        print("  "+i.__name__)

# Generated at 2022-06-24 20:07:04.385064
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except Exception as e:
        print('Exception: {}'.format(e))
        raise
    else:
        print('Success: get_all_subclasses')


if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:07:05.544081
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    with pytest.raises(TypeError):
        test_case_0()

# Generated at 2022-06-24 20:07:06.686679
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert(test_case_0())

test_get_all_subclasses()

# Generated at 2022-06-24 20:07:10.891045
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses(float)
    assert isinstance(var_0, set)
    assert float in var_0



# Generated at 2022-06-24 20:09:01.428837
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        def __init__(self):
            self = object
        def run(self):
            print("running")
    class B(A):
        def __init__(self):
            self = A
        def run(self):
            print("running more")

    assert(get_all_subclasses(A) == {B})


# Generated at 2022-06-24 20:09:02.420599
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True, "Test not implemented"


# Generated at 2022-06-24 20:09:08.762254
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses(__name__)
    try:
        assert var_0 == b'_utils'
    except AssertionError as e:
        raise Exception(e)
    try:
        assert var_0 == u'_utils'
    except AssertionError as e:
        raise Exception(e)
    try:
        assert var_0 == ''
    except AssertionError as e:
        raise Exception(e)
    try:
        assert var_0 == __name__
    except AssertionError as e:
        raise Exception(e)

# Generated at 2022-06-24 20:09:09.696228
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() == "something"

# Generated at 2022-06-24 20:09:10.981882
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert var_0 == var_0

# Generated at 2022-06-24 20:09:15.869231
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test for method get_all_subclasses
    bool_0 = False
    var_0 = get_all_subclasses(bool_0)
    assert var_0 <= set([])


if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-24 20:09:19.721393
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test that the function properly returns an iterable of all of the subclasses
    of a given class.
    '''
    # Declare a simple test class
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass

    # Get all subclasses
    subclasses = get_all_subclasses(A)

    # Check the results
    assert subclasses == {B, C, D}




# Generated at 2022-06-24 20:09:22.157330
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:09:24.978805
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_1 = get_all_subclasses('abc')
    var_2 = get_all_subclasses(1)
    var_3 = get_all_subclasses(None)
    var_4 = get_all_subclasses(True)
    var_5 = get_all_subclasses([])
    var_6 = get_all_subclasses(set())
    var_7 = get_all_subclasses(dict())

# Generated at 2022-06-24 20:09:33.985565
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    vars_0 = get_all_subclasses(type(get_all_subclasses))
    check_0 = {type(get_all_subclasses)}
    check_1 = type(get_all_subclasses) in vars_0
    check_2 = type(get_all_subclasses) not in vars_0
    check_3 = type(get_all_subclasses) in vars_0
    return check_1, check_2, check_3

if __name__ == '__main__':
    test_case_0()
    test_get_all_subclasses()