

# Generated at 2022-06-24 20:01:47.655771
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    pass



# Generated at 2022-06-24 20:01:57.041299
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Get all subclasses of class str
    str_subclasses = get_all_subclasses(str)
    # Assert that there exists a subclass of type str
    assert(any(type(item) == str for item in str_subclasses))
    # Assert that there exists a subclass of type unicode
    assert(any(any(type(item) == unicode for item in item.__subclasses__()) for item in str_subclasses))
    # Assert that there exists a subclass of type object
    assert(any(any(type(item) == object for item in item.__subclasses__()) for item in str_subclasses))
    # Assert that there exists a subclass of type TypeType
    assert(any(any(type(item) == type for item in item.__subclasses__()) for item in str_subclasses))



# Generated at 2022-06-24 20:01:58.928397
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # str_0 = "\x0bN}HR6'W.QW :o"
    # var_0 = get_all_subclasses(str_0)
    pass



# Generated at 2022-06-24 20:02:02.311620
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == {bytes, str}
    assert get_all_subclasses(int) == {bool, type(NotImplemented), type(Ellipsis), complex, float, int}
    assert get_all_subclasses(dict) == {collections.defaultdict, collections.OrderedDict, collections.Counter, dict}



# Generated at 2022-06-24 20:02:03.522249
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses("test") == {str}



# Generated at 2022-06-24 20:02:10.499007
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import ansible.module_utils.basic
    import ansible.utils.module_docs
    import ansible.utils.module_docs_fragments
    import ansible.utils.template
    import ansible.utils.vars
    import ansible.utils.verify

    assert get_all_subclasses(ansible.module_utils.basic.AnsibleModule) == set()
    assert get_all_subclasses(ansible.utils.module_docs.AnsibleModuleDoc) == set()
    assert get_all_subclasses(ansible.utils.module_docs_fragments.AnsibleModuleDocFragment) == set()
    assert get_all_subclasses(ansible.utils.template.AnsibleModuleUtilsTemplate) == set()

# Generated at 2022-06-24 20:02:13.560619
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = "\x0bN}HR6'W.QW :o"
    var_0 = get_all_subclasses(str_0)
    assert var_0 == str_0
    test_case_0()

# Generated at 2022-06-24 20:02:16.611808
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses(str)
    assert(len(var_0) == 3)
    assert(unicode in var_0)
    assert(basestring in var_0)
    assert(str in var_0)

# Generated at 2022-06-24 20:02:25.819396
# Unit test for function get_all_subclasses

# Generated at 2022-06-24 20:02:31.600631
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    def function_0(arg_0, arg_1):
        return arg_0 * arg_1
    str_0 = str
    print(str_0('iterable') in get_all_subclasses(function_0))


test_case_0()
class_0 = get_all_subclasses(test_case_0)
print(class_0)
test_get_all_subclasses()

# Generated at 2022-06-24 20:02:42.700280
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_1 = get_all_subclasses((0x0e7 + 1483 - 0x5e8))
    assert var_1 == set()
    var_0 = get_all_subclasses(str)
    assert var_0 == set([bytes, unicode])
    var_2 = get_all_subclasses(int)
    assert var_2 == set([float, long, bool])
    # This test is a negative test to distinguish between Python 2 and Python 3.
    # Python 2 has an explicit `basestring` class, but Python 3 does not.
    if str is unicode:
        assert basestring not in var_0
    else:
        assert basestring in var_0
    assert set([int, float]) <= var_2
    assert bool not in var_2
    # Ensure that our function is recursive


# Generated at 2022-06-24 20:02:49.721648
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_1 = 'string_0'
    var_2 = 'string_1'
    var_3 = 'string_2'
    var_4 = 'string_3'
    var_5 = 'string_4'
    var_6 = 'string_5'
    var_7 = 'string_6'
    var_8 = 'string_7'
    var_9 = 'string_8'
    str_0 = "\x0bN}HR6'W.QW :o"
    test_case_0()

# Generated at 2022-06-24 20:02:51.990458
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print('Test #0')
    test_case_0()

test_get_all_subclasses()

# Generated at 2022-06-24 20:03:02.481728
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# class AnsibleModuleHelper:

#     _shared_state = {}
#     __instance = None

#     def __init__(self, *args, **kwargs):
#         self.__dict__ = self._shared_state
#         if not self.__instance:
#             self.__instance = AnsibleModuleHelper.__impl(self, *args, **kwargs)
#         else:
#             self.__instance.__init__(self, *args, **kwargs)

#     def __getattr__(self, attr):
#         return getattr(self.__instance, attr)
#         # class AnsibleModuleHelper:

#     _shared_state = {}
#     __instance = None

#     def __init__(self, *args, **kw

# Generated at 2022-06-24 20:03:05.784249
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert False, "A test function is not implemented"



# Generated at 2022-06-24 20:03:07.113547
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test = [type, object, str]
    assert test == get_all_subclasses(basestring)



# Generated at 2022-06-24 20:03:10.278314
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print('Start test_get_all_subclasses')
    test_case_0()
    print('End test_get_all_subclasses')

# Main function

# Generated at 2022-06-24 20:03:18.096966
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    for class_name in [set, list, tuple, dict, int, str, unicode, object]:
        not_subclass = False
        for klass in get_all_subclasses(class_name):
            if not isinstance(klass(), class_name):
                not_subclass = True
                break
        assert not_subclass is False, "%s is not a subclass of %s" % (klass, class_name)


if __name__ == "__main__":
    print("Running test cases...")
    test_get_all_subclasses()

# Generated at 2022-06-24 20:03:24.850640
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert not isinstance(get_all_subclasses, str)
    assert not isinstance(get_all_subclasses, int)
    assert not isinstance(get_all_subclasses, float)
    assert not isinstance(get_all_subclasses, tuple)
    assert not isinstance(get_all_subclasses, list)
    assert not isinstance(get_all_subclasses, dict)
    assert isinstance(get_all_subclasses, set)

# run unit test
print(test_get_all_subclasses())
print(test_case_0())

# Generated at 2022-06-24 20:03:27.359378
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except:
        print("Failure in test_case_0()")


# Generated at 2022-06-24 20:03:42.377589
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test with a python class
    subclasses = get_all_subclasses(str)
    assert all(isinstance(key, type) for key in subclasses)
    assert not isinstance(str, str)
    assert str in subclasses
    assert unicode in subclasses
    assert not int in subclasses

    # Test with a string
    subclasses = get_all_subclasses('test')
    assert all(isinstance(key, type) for key in subclasses)
    assert str in subclasses
    assert unicode in subclasses
    assert not int in subclasses

    # Test with an integer
    subclasses = get_all_subclasses(1)
    assert all(isinstance(key, type) for key in subclasses)
    assert str in subclasses
    assert unicode in subclasses
    assert not int in subclasses



# Generated at 2022-06-24 20:03:45.474030
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == (unicode, basestring)
    try:
        from collections import UserString
        assert UserString in get_all_subclasses(str)
    except ImportError:
        assert True


# Generated at 2022-06-24 20:03:46.469478
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test with the first function
    test_case_0()
    pass

# Generated at 2022-06-24 20:03:48.963596
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_obj = [str, int]
    assert len(get_all_subclasses(str)) == 11
    assert len(get_all_subclasses(int)) == 0

# Generated at 2022-06-24 20:03:50.364364
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == [str, unicode]



# Generated at 2022-06-24 20:03:53.575854
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = "\x0bN}HR6'W.QW :o"
    var_0 = get_all_subclasses(str_0)
    assert var_0 == 'set([]),'


# Generated at 2022-06-24 20:03:57.334483
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == {basestring, unicode}
    assert get_all_subclasses(int) == {bool, long, complex}
    assert get_all_subclasses(basestring) == {unicode}
    assert get_all_subclasses(unicode) == set()

# Generated at 2022-06-24 20:03:58.839310
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == set()
    assert get_all_subclasses(int) == set()

# Generated at 2022-06-24 20:04:06.561141
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = ()
    var_1 = get_all_subclasses(var_0)

    assert(len(var_1) == 22)
    assert(str_1[0] in var_1)
    assert(unicode in var_1)

    var_2 = base_1
    var_3 = get_all_subclasses(var_2)

    assert(len(var_3) == 3)
    assert(base_2 in var_3)
    assert(base_3 in var_3)
    assert(base_4 in var_3)

    var_4 = base_5()
    var_5 = get_all_subclasses(var_4)

    assert(len(var_5) == 2)
    assert(base_1 in var_5)

# Generated at 2022-06-24 20:04:10.085034
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(0) == set()


# Generated at 2022-06-24 20:04:24.437631
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()


# Generated at 2022-06-24 20:04:25.826895
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() is None, "get_all_subclasses test case 0 failed"


# Generated at 2022-06-24 20:04:27.198341
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()


# Generated at 2022-06-24 20:04:35.947702
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import pytest
    def check_get_all_subclasses(cls):
        assert set(cls.__subclasses__()) == get_all_subclasses(cls)

    A = type('A', (object,), {})  # class A
    B = type('B', (A,), {})  # class B
    C = type('C', (A,), {})  # class C
    D = type('D', (B, C), {})  # class D

    check_get_all_subclasses(A)

if __name__ == '__main__':
    test_case_0()
    test_get_all_subclasses()

# Generated at 2022-06-24 20:04:39.516507
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

#
# Test output of get_all_subclasses on type 'str'
#

# Calling test_case_0
test_case_0()

# Generated at 2022-06-24 20:04:48.658234
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses("") == set([])
    assert get_all_subclasses("abc") == set([])
    x = "abc"
    assert get_all_subclasses(x) == set([])
    x = [1,2,3]
    assert get_all_subclasses(x) == set([])
    assert get_all_subclasses(1.0) == set([])
    assert get_all_subclasses(1) == set([])
    assert get_all_subclasses(True) == set([])
    assert get_all_subclasses(()) == set([])

# Generated at 2022-06-24 20:04:50.906780
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    test_case_0()


# Generated at 2022-06-24 20:04:52.959086
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = "\x0bN}HR6'W.QW :o"
    test_case_0()

test_get_all_subclasses()

# Generated at 2022-06-24 20:04:55.867417
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test function
    test_case_0()



# Generated at 2022-06-24 20:04:57.790904
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert var_0 == set([type(None)])

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:05:26.002997
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()
    print('Test successfull')



# Generated at 2022-06-24 20:05:26.775413
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() is None


# Generated at 2022-06-24 20:05:32.941869
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Simple test with an empty class
    class MyClass(): pass
    assert get_all_subclasses(MyClass) == set()
    # Simple test with one subclass
    class MyClass2(MyClass): pass
    assert get_all_subclasses(MyClass) == set([MyClass2])
    # Test with multiple levels
    class MyClass3(MyClass): pass
    class MyClass4(MyClass2): pass
    class MyClass5(MyClass4): pass
    class MyClass6(MyClass2): pass
    assert get_all_subclasses(MyClass) == set([MyClass3, MyClass4, MyClass5, MyClass6])

# Generated at 2022-06-24 20:05:37.961896
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_1 = "FhG;P"
    str_2 = "D}Uf"
    str_3 = " "- 'A'
    str_4 = "Rm<0"
    str_0 = str_1 + str_2
    str_0 += str_3
    str_0 += str_4
    str_0 = str_0.decode('zlib')
    var_0 = get_all_subclasses(str_0)
    

# Generated at 2022-06-24 20:05:43.258318
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Get the type of an object
    assert type('x') is str
    assert type(u'x') is unicode
    test_case_0()



# Generated at 2022-06-24 20:05:45.548658
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_1 = isinstance(test_case_0, object)
    str_1 = "\x0bN}HR6'W.QW :o"
    var_2 = isinstance(str_1, object)
    assert var_2
    assert var_1



# Generated at 2022-06-24 20:05:46.923260
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    obj = Test_get_all_subclasses()
    obj.test_function_0()


# Generated at 2022-06-24 20:05:51.327054
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import ansible.module_utils._text
    assert ansible.module_utils._text.to_text in get_all_subclasses(ansible.module_utils._text.to_unicode)

# Generated at 2022-06-24 20:05:56.899382
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Basic test
    str_0 = "hello"
    list_0 = get_all_subclasses(str_0)
    # Remove NoneTypes
    list_0 = [x for x in list_0 if x is not None]
    assert "world" in list_0

test_case_1 = lambda: test_get_all_subclasses()

# Generated at 2022-06-24 20:05:57.910620
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:07:07.564857
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import get_all_subclasses
    str_0 = "\x0bN}HR6'W.QW :o"
    var_0 = get_all_subclasses(str_0)
    eq_(type(var_0), set)
    assert set([type(str_0), type(u"\x0bN}HR6'W.QW :o")]) == var_0



# Generated at 2022-06-24 20:07:08.614968
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()


if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:07:09.010716
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True

# Generated at 2022-06-24 20:07:16.168019
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = "\x0bN}HR6'W.QW :o"
    var_0 = get_all_subclasses(str_0)
    var_1 = list(var_0)
    if (int(var_1[0].__hash__) > int(var_1[-1].__hash__)):
        assert True
    else:
        assert False
    #assert var_1 == [str, bytes, bytearray, basestring]



# Generated at 2022-06-24 20:07:19.138551
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Retrieve all subclasses for class basestring
    subclasses = get_all_subclasses(basestring)
    assert str in subclasses
    assert unicode in subclasses
    assert bytes in subclasses
    assert bytearray in subclasses
    assert subclasses == set([str, unicode, bytes, bytearray])


# Generated at 2022-06-24 20:07:19.633595
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True

# Generated at 2022-06-24 20:07:24.494958
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses({}) == set()
    assert get_all_subclasses(list()) == set()
    assert get_all_subclasses(str()) == set()
    assert get_all_subclasses(dict()) == set()
    assert get_all_subclasses(int) == set()

# Generated at 2022-06-24 20:07:33.441453
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types
    # Assert that the following class is not included in subclass list
    str_0 = "\x0bN}HR6'W.QW :o"
    assert bytes not in get_all_subclasses(str_0)
    # Assert that the following class is included in subclass list
    list_0 = [1, 2, 3]
    assert types.ListType not in get_all_subclasses(list_0)
    # Assert that the following class is included in subclass list

# Generated at 2022-06-24 20:07:35.783291
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    string_0 = "\x0bN}HR6'W.QW :o"
    result_0 = get_all_subclasses(string_0)
    assert result_0 == [str]



# Generated at 2022-06-24 20:07:42.133549
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses(str)
    assert var_0 == set([str, unicode, basestring, object])
    var_1 = get_all_subclasses(unicode)
    assert var_1 == set([unicode, object])
    var_2 = get_all_subclasses(int)
    assert var_2 == set([int, long])
    var_3 = get_all_subclasses(long)
    assert var_3 == set([long, object])
    var_4 = get_all_subclasses(list)
    assert var_4 == set([list, object])
    var_5 = get_all_subclasses(dict)
    assert var_5 == set([dict, object])
    var_6 = get_all_subclasses(set)
    assert var_6 == set

# Generated at 2022-06-24 20:10:22.822473
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # 1. Define inputs
    str_1 = "N#e'nX>C[-r:r"
    # 2. Setup mocks
    # 3. Invoke test function
    var_1 = get_all_subclasses(str_1)
    # 4. Check results
    assert type(var_1) == set
    # assert var_1 == expected_var_1


# Generated at 2022-06-24 20:10:25.717932
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = "0m1EZ^2QhYzgP@,w\x14\x1f?\x0b$\x06\n"
    set_0 = set()
    var_0 = get_all_subclasses(str_0)
    assert var_0 == set_0

# Generated at 2022-06-24 20:10:29.779309
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:10:33.877145
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.six import string_types

from ansible.module_utils._text import to_text, to_native



# Generated at 2022-06-24 20:10:37.798167
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()
    print("test_get_all_subclasses() completed successfully")

# Generated at 2022-06-24 20:10:40.788464
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = "b\xb2\\\x0c\x02\xe9\xbb\x08\x13\x83\x1a\xc2\x83\xd0"
    var_0 = get_all_subclasses(str_0)



# Generated at 2022-06-24 20:10:41.681039
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:10:46.364642
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    :param str_0: string
    :type str_0: string
    :returns: 
    :rtype: None
    """

    assert test_case_0() == None

# Generated at 2022-06-24 20:10:50.161950
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = "\x0bN}HR6'W.QW :o"
    var_0 = get_all_subclasses(str_0)
    if var_0 != {str, bytes}:
        print(False)



# Generated at 2022-06-24 20:10:59.678175
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = "\x0bN}HR6'W.QW :o"
    var_0 = get_all_subclasses(str_0)
    var_1 = get_all_subclasses(var_0)
    str_1 = "\x0bN}HR6'W.QW :o"
    var_2 = get_all_subclasses(str_1)

    assert var_0 == str_0
    assert var_1 == var_0
    assert var_2 == str_1


