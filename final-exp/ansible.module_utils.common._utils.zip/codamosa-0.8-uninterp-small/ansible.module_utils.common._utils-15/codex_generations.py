

# Generated at 2022-06-24 20:01:45.905533
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)


if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:01:56.088623
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert set(get_all_subclasses(dict)) == {collections.OrderedDict}
    assert set(get_all_subclasses(collections.OrderedDict)) == set()

    import ansible.plugins.loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_finder
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import module_utils_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import vars

# Generated at 2022-06-24 20:02:05.601446
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Counter
    from collections import namedtuple
    from collections import deque
    from collections import UserDict
    from collections import UserList
    from collections import UserString
    from collections import UserString
    from collections import Iterable
    from collections import Hashable
    from collections import Sequence
    from collections import Sized
    from collections import Container
    from collections import Callable
    from collections import Set
    from collections import Mapping
    from collections import MappingView
    from collections import KeysView
    from collections import ItemsView
    from collections import ValuesView
    from collections import MutableMapping
    from collections import Mapping
    from collections import MutableSet
    from collections import MutableSequence
    from collections import Queue
    from collections import MutableMapping
    from collections import OrderedDict
    from collections import defaultdict

# Generated at 2022-06-24 20:02:15.612983
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    cls = dict
    subclasses = set([dict])
    to_visit = list(get_all_subclasses(cls))
    while to_visit:
        for sc in to_visit:
            # The current class is now visited, so remove it from list
            to_visit.remove(sc)
            # Appending all subclasses to visit and keep a reference of available class
            for ssc in sc.__subclasses__():
                if ssc not in subclasses:
                    to_visit.append(ssc)
                    subclasses.add(ssc)
    assert subclasses == set(get_all_subclasses(cls))

# Generated at 2022-06-24 20:02:25.071485
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # list_0 = []
    # var_0 = get_all_subclasses(list_0)

    expected_list = [set(), dict(), set(), dict(), dict()]
    actual_list = []

    a = A()
    actual_list.append(get_all_subclasses(a))
    b = B()
    actual_list.append(get_all_subclasses(b))
    c = C()
    actual_list.append(get_all_subclasses(c))
    d = D()
    actual_list.append(get_all_subclasses(d))
    e = E()
    actual_list.append(get_all_subclasses(e))
    assert actual_list == expected_list


# The following test classes are for unit testing of get_all_subclasses

# Generated at 2022-06-24 20:02:26.405791
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses()
    assert var_0 == 0

# Generated at 2022-06-24 20:02:27.882648
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()
    test_case_0()



# Generated at 2022-06-24 20:02:30.442126
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        assert False
    except AssertionError:
        pass
    else:
        raise AssertionError('AssertionError expected')

# Generated at 2022-06-24 20:02:37.384882
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    jason = {'name': 'Jason', 'age': 22}
    eric = {'name': 'Eric', 'age': 22}
    mike = {'name': 'Mike', 'age': 23}
    larry = {'name': 'Larry', 'age': 59}

    list_0 = [jason, eric, mike, larry]

    var_0 = get_all_subclasses(list_0)
    return var_0


if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:38.979299
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_0 = []
    var_0 = get_all_subclasses(list_0)

# Generated at 2022-06-24 20:02:48.952471
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(list) == set([list, str, tuple, dict])
    assert get_all_subclasses(str) == set([str, basestring, unicode, int, list, tuple, dict])
    assert get_all_subclasses(tuple) == set([tuple, dict])
    assert get_all_subclasses(dict) == set([dict])
    assert get_all_subclasses(int) == set([int, list, tuple, dict])

# Generated at 2022-06-24 20:02:54.167458
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_text
    import ansible.module_utils.common.text
    import ansible.module_utils.common.collections
    import ansible.module_utils.urls
    import ansible.module_utils.six
    import ansible.module_utils.common.parameters
    import ansible.module_utils.common.netcommon
    import ansible.module_utils.common.remotes
    import ansible.module_utils.common.validation
    import ansible.module_utils.common.ssl
    import ansible.module_utils.facts.networking.nios.facts
    import ansible.module_utils.facts.networking.nios.api

    # Find all subclasses for ansible.module_utils.common.text.NetworkModule

# Generated at 2022-06-24 20:02:55.916395
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    test_case_0()

test_get_all_subclasses()

# Generated at 2022-06-24 20:02:58.592931
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-24 20:02:59.815257
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() == None

# Generated at 2022-06-24 20:03:04.956421
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert (
        len(get_all_subclasses(list)) ==
        len({
            tuple,
            list,
            object,
            collections.abc.MutableSequence,
            collections.abc.Sequence,
            collections.abc.Container,
            collections.abc.Sized,
            collections.abc.Iterable,
        })
    ), get_all_subclasses(list)



# Generated at 2022-06-24 20:03:13.786675
# Unit test for function get_all_subclasses

# Generated at 2022-06-24 20:03:17.244482
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:03:27.136022
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import defaultdict
    from distutils.version import LooseVersion
    import os
    import sys

    import ansible_collections.ansible.builtin
    import ansible_collections.ansible.devel
    import ansible_collections.ansible.posix
    import ansible_collections.sensu.sensu_go
    import ansible
    import ansible.plugins
    import ansible.plugins.action
    import ansible.modules

    test_data_dir = os.path.join(os.path.dirname(__file__), 'test_data')
    base_module_path = os.path.join(test_data_dir, 'base_module.py')
    version_module_path = os.path.join(test_data_dir, 'version_module.py')
   

# Generated at 2022-06-24 20:03:29.037936
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() is None, "Function 'test_case_0' missing from function 'test_get_all_subclasses'"

# Generated at 2022-06-24 20:03:42.416142
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(E):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(H):
        pass

    class L(H):
        pass

    classes = [A, B, C, D, E, F, G, H, I, J, K, L]
    all_subclasses = get_all_subclasses(A)

    assert sorted(classes) == sorted(all_subclasses)



# Generated at 2022-06-24 20:03:43.225989
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() == None


# Generated at 2022-06-24 20:03:45.447959
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
   assert get_all_subclasses(list) == [set, tuple]
#    assert get_all_

# Generated at 2022-06-24 20:03:49.652230
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Get a reference for all classes of type object
    obj_list = get_all_subclasses(object)

    # Check if list is a subclass of object
    assert(list in obj_list)

    # Check if dict is a subclass of object
    assert (dict in obj_list)


# Generated at 2022-06-24 20:03:51.729624
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # check that get_all_subclasses() returns the expected value
    assert get_all_subclasses(list_0) == var_0

# Generated at 2022-06-24 20:03:57.376152
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test when the input class is a list
    try:
        test_case_0()
    except AssertionError as e:
        print('AssertionError raised when the input class is a list')
    # Test when the input class is not a class
    try:
        get_all_subclasses('a')
    except TypeError as e:
        print('TypeError raised when the input class is not a class')

# Run unit tests
test_get_all_subclasses()

# Generated at 2022-06-24 20:03:59.244461
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test get_all_subclasses

    :return: No return value
    """
    test_case_0()


# Main function

# Generated at 2022-06-24 20:04:06.357145
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import random
    import string
    import unittest

    class B(unittest.TestCase):
        pass

    class C(B):
        pass

    class D(C):
        pass

    all_subclasses = get_all_subclasses(B)
    assert isinstance(all_subclasses, set), '%s is a set' % all_subclasses.__class__.__name__

    assert C in all_subclasses
    assert D in all_subclasses

    assert B not in all_subclasses
    assert unittest.TestCase not in all_subclasses

    # Test random class
    class Test():
        pass
    Test_subclasses = get_all_subclasses(Test)

    assert Test_subclasses == set()



# Generated at 2022-06-24 20:04:10.041272
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Expected to fail!

# Generated at 2022-06-24 20:04:12.776191
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_0 = []
    var_0 = get_all_subclasses(list_0)
    assert var_0 is not None, "Unit test for function get_all_subclasses returned None"

# Generated at 2022-06-24 20:04:23.460974
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()


# Generated at 2022-06-24 20:04:26.900555
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    result = get_all_subclasses("foo")
    assert result == "foo"


# Generated at 2022-06-24 20:04:29.648932
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:04:30.459472
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0 == True

# Generated at 2022-06-24 20:04:32.136397
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_0 = []
    var_0 = get_all_subclasses(list_0)

# Generated at 2022-06-24 20:04:41.542749
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    import traceback
    import sys

    module_test_results = dict(changed=False, failed=False, msg='')
    import ansible.module_utils.basic

    function_names = ['get_all_subclasses']
    import ansible.module_utils._text

    function_names.append('to_native')
    function_names.append('test_case_0')
    import traceback

    function_names.append('extract_tb')
    function_names.append('format_exception')
    from ansible.module_utils.basic import AnsibleModule

    function_names.append('AnsibleModule')
    import sys


# Generated at 2022-06-24 20:04:43.694335
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Initial test - empty list
    test_case_0()
    # TODO - more test cases

# Generated at 2022-06-24 20:04:45.163261
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except Exception:
        import traceback
        traceback.print_exc()
        assert False

# Run unit tests
test_get_all_subclasses()

# Generated at 2022-06-24 20:04:52.726522
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test 1:
    list_0 = []
    var_0 = get_all_subclasses(list_0)
    assert var_0 == set()
    # Test 2:
    str_0 = 'E'
    str_1 = 'W'
    str_2 = 'H'
    str_3 = 'L'
    str_4 = 'O'
    str_5 = ' '
    str_6 = 'W'
    str_7 = 'O'
    str_8 = 'R'
    str_9 = 'L'
    str_10 = 'D'
    str_11 = '!'
    str_12 = str_0 + str_1 + str_2 + str_3 + str_4 + str_5 + str_6 + str_7 + str_8 + str_9 + str_10

# Generated at 2022-06-24 20:04:56.678838
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    No way to reliably test this without implementation-specific knowledge.
    Not clear it is worth testing until it is better documented.
    """
    pass

# Generated at 2022-06-24 20:05:16.624496
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:05:26.367798
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_text

    # Import base_module
    from ansible.module_utils.basic import AnsibleModule

    # Import Python modules
    import sys
    import textwrap
    import types
    import warnings

    # Import Ansible Modules
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Import 3rd party modules
    from ansible.module_utils.six import iteritems

    # Import additional modules
    from . import basic_module
    from . import basic
    from . import basic_module

    # Import classes
    from ansible.module_utils.basic import AnsibleModule

    # Import functions
    from ansible.module_utils.six import iteritems

    # Import constants
    from ansible.module_utils import basic


# Generated at 2022-06-24 20:05:33.200735
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar
    from ansible.plugins.action.normal import ActionModule as ActionBase
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from io import StringIO
    from unittest import TestCase

    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

# Generated at 2022-06-24 20:05:35.385835
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    a_test_get_all_subclasses = TestGetAllSubclasses()
    a_test_get_all_subclasses.test_case_0()

# Generated at 2022-06-24 20:05:41.777084
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = ()
    list_0 = [var_0]
    var_1 = get_all_subclasses(list_0)
    var_2 = [var_0]
    var_3 = var_2 == var_1
    assert var_3 is False, "Expected: "+str(var_2)+", Got "+str(var_1)
    tuple_0 = (1,)
    var_4 = get_all_subclasses(tuple_0)
    var_5 = [list_0, tuple_0, var_0]
    var_6 = var_5 == var_4
    assert var_6 is False, "Expected: "+str(var_5)+", Got "+str(var_4)
    tuple_1 = tuple()

# Generated at 2022-06-24 20:05:46.989449
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Creating some dummy classes for testing purpose
    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E:
        pass

    class F:
        pass

    assert get_all_subclasses(A) == {B, C, D}
    assert get_all_subclasses(B) == {C}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-24 20:05:54.632118
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils import six
    import os
    import tempfile
    import textwrap
    import pytest

    class_name_0 = 'Foo'
    class_name_1 = 'Bar'
    class_name_2 = 'FooBar'
    class_name_3 = 'BarFoo'
    class_name_4 = 'Qux'

    class_0 = textwrap.dedent("""
        class %s:
            pass
    """ % class_name_0)

    class_1 = textwrap.dedent("""
        class %s(%s):
            pass
    """ % (class_name_1, class_name_0))


# Generated at 2022-06-24 20:05:56.950930
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(list_0) == var_0

# Generated at 2022-06-24 20:05:59.099874
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False

# Main processing function

# Generated at 2022-06-24 20:06:04.244532
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_0 = [1, 2, 3]
    list_1 = [4, 5, 6]
    var_0 = get_all_subclasses(list_0)
    var_1 = get_all_subclasses(list_1)
    assert var_0 == var_1
    assert var_0 != list_0
    assert var_1 != list_1

# Generated at 2022-06-24 20:06:58.756341
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_0 = list()
    tuple_0 = tuple()
    dict_0 = dict()
    set_0 = set()
    str_0 = str()

    class_0 = get_all_subclasses(int)
    assert type(class_0) is set and isinstance(class_0.pop(), int)
    class_1 = get_all_subclasses(float)
    assert type(class_1) is set and isinstance(class_1.pop(), float)
    class_2 = get_all_subclasses(list_0)
    assert type(class_2) is set and isinstance(class_2.pop(), list)
    class_3 = get_all_subclasses(tuple_0)
    assert type(class_3) is set and isinstance(class_3.pop(), tuple)

# Generated at 2022-06-24 20:07:04.588587
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses([]) == get_all_subclasses(tuple)
    assert get_all_subclasses([]) != set()
    assert get_all_subclasses(list) != set()
    assert get_all_subclasses(int) != set()
    assert get_all_subclasses(object) != set()

# Generated at 2022-06-24 20:07:05.392374
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert func_out == func_expected

# Generated at 2022-06-24 20:07:07.400572
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test case 0
    test_case_0()
    # Test case 1
    list_0 = []
    var_0 = get_all_subclasses(list_0)



# Generated at 2022-06-24 20:07:08.222857
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-24 20:07:11.042940
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_1 = [test_case_0]
    value = get_all_subclasses(list_1)
    assert value is not None

# Generated at 2022-06-24 20:07:20.191778
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections

    # function in module
    def test_function_0(self):
        pass

    # class in module
    class TestClass_0(collections.MutableMapping):

        def __init__(self):
            pass

        def __getitem__(self, key):
            pass

        def __setitem__(self, key, value):
            pass

        def __delitem__(self, key):
            pass

        def __iter__(self):
            pass

        def __len__(self):
            pass

        def test_method_0(self):
            pass

    # class in module
    class TestClass_1(collections.MutableMapping):

        def __init__(self):
            pass

        def __getitem__(self, key):
            pass


# Generated at 2022-06-24 20:07:21.949153
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    with pytest.raises(AttributeError):
        get_all_subclasses()

# Generated at 2022-06-24 20:07:24.372900
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except:
        print("Fail test_case_0")
        raise

# Generated at 2022-06-24 20:07:26.274125
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)
    assert get_all_subclasses(list_0) == set()

# Generated at 2022-06-24 20:09:21.494466
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True

# Generated at 2022-06-24 20:09:28.103344
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(A, D): pass

    # Get all subclasses of A:
    # print(get_all_subclasses(A)) #{<class '__main__.D'>, <class '__main__.E'>, <class '__main__.C'>, <class '__main__.B'>, <class '__main__.F'>}

    # Get all subclasses of B:
    # print(get_all_subclasses(B)) #{<class '__main__.D'>}

    # Get all subclasses of C:
    # print(get_all_subclasses(C)) #{<class '__main__.E'>}

   

# Generated at 2022-06-24 20:09:32.280792
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test function get_all_subclasses.

    This function is currently not tested because it is used only in
    the network_cli.py module which is deprecated and will be removed
    in Ansible 2.10.
    """
    pass

# Generated at 2022-06-24 20:09:40.773373
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert type(get_all_subclasses('test')) is set
    assert get_all_subclasses('test') == set()
    assert type(get_all_subclasses(list)) is set
    assert get_all_subclasses(list) == set()
    assert type(get_all_subclasses(int)) is set
    assert get_all_subclasses(int) == set([bool])
    assert type(get_all_subclasses(dict)) is set
    assert get_all_subclasses(dict) == set()
    assert type(get_all_subclasses(set)) is set
    assert get_all_subclasses(set) == set()
    assert type(get_all_subclasses(tuple)) is set
    assert get_all_subclasses(tuple) == set()

# Generated at 2022-06-24 20:09:44.617497
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        # test with an empty list
        test_case_0()
    except Exception:
        assert False
    # If no exception, test is good
    assert True



# Generated at 2022-06-24 20:09:51.507550
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test with a sample tree of classes
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-24 20:09:52.976815
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert False # implement your test here


# Generated at 2022-06-24 20:09:57.992141
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Tests for initial case, if __subclasses__ is not implemented.
    get_all_subclasses(int)

    # Tests for class with no subclasses.
    assert set() == get_all_subclasses(bool)

    # Tests for class with subclasses
    assert set({dict, list}) == get_all_subclasses(Sequence)


test_get_all_subclasses()

# Generated at 2022-06-24 20:10:01.587708
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(list) == set
    assert get_all_subclasses(set) == frozenset
    assert get_all_subclasses(dict) == collections.defaultdict
    assert get_all_subclasses(frozenset) == set



# Generated at 2022-06-24 20:10:03.600367
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() == 0