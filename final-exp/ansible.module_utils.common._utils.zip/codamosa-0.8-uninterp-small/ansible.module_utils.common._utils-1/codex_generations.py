

# Generated at 2022-06-24 20:01:47.705130
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert False

# Generated at 2022-06-24 20:01:55.764692
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert (get_all_subclasses(bool) == set([])
        ), "`get_all_subclasses` should return `set([])` for input `bool`"
    assert (get_all_subclasses(int) == set([])
        ), "`get_all_subclasses` should return `set([])` for input `int`"
    assert (get_all_subclasses(str) == set([])
        ), "`get_all_subclasses` should return `set([])` for input `str`"
    assert (get_all_subclasses(float) == set([])
        ), "`get_all_subclasses` should return `set([])` for input `float`"


# Generated at 2022-06-24 20:01:56.544158
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() == None

# Generated at 2022-06-24 20:02:00.167687
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Test assertion: function get_all_subclasses
    assert test_case_0()

# Test assertion: function get_all_subclasses
test_get_all_subclasses()

# Generated at 2022-06-24 20:02:04.255578
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses(int)


# Generated at 2022-06-24 20:02:08.070302
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == set([bytes, unicode])
    assert get_all_subclasses(list) == set([type('A', (list,), {'__module__': '__main__'}),
                                            type('B', (list,), {'__module__': '__main__'})])
    assert get_all_subclasses(dict) == set()

# Generated at 2022-06-24 20:02:12.294074
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import inspect
    # Get all cases from unit test file
    cases = inspect.getmembers(sys.modules[__name__], predicate=lambda m: m.startswith('test_case_'))
    # For each case, print out the predefined test_case
    for case in cases:
        case[1]()

# Generated at 2022-06-24 20:02:13.975939
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = str
    var_0 = get_all_subclasses(str_0)


# Generated at 2022-06-24 20:02:23.716654
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils.six import PY3
    from types import ModuleType
    from collections import deque

    __all__ = ['Test_0', 'Test_1']

    class Test_0():
        pass

    class Test_1():
        pass

    # Build the test class tree
    Test_0.__subclasses__ = lambda: [Test_1]
    Test_1.__subclasses__ = lambda: []
    # Get a list of all modules
    modules = set([module for module in globals().values() if isinstance(module, ModuleType)])
    # Parse through the module and check the test classes

# Generated at 2022-06-24 20:02:25.864020
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Function call. There is no class named 'test_get_all_subclasses'
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:36.475063
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_1 = "A string"
    var_0 = get_all_subclasses(str_1)
    int_1 = 1
    var_1 = get_all_subclasses(int_1)
    float_0 = 6.0
    var_2 = get_all_subclasses(float_0)
    dict_0 = {"A": "B"}
    var_3 = get_all_subclasses(dict_0)
    #  Return type assertion
    assert all(isinstance(var_x, set) for var_x in [var_0, var_1, var_2, var_3])

# Generated at 2022-06-24 20:02:39.625042
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    f = open('test_get_all_subclasses.txt', 'w')
    suite = unittest.TestLoader().loadTestsFromTestCase(test_case_0)
    unittest.TextTestRunner(f, verbosity=2).run(suite)

# Generated at 2022-06-24 20:02:43.616120
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == set(
        [
            basestring,
            bytearray,
            bytes,
            unicode
        ]
    )

# Generated at 2022-06-24 20:02:52.489662
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = None
    var_0 = get_all_subclasses(str_0)


if __name__ == "__main__":
    import sys
    import traceback
    try:
        test_get_all_subclasses()
    except AssertionError:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_exception(exc_type, exc_value, exc_traceback, limit=2, file=sys.stdout)
        sys.exit(1)
    except:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_exception(exc_type, exc_value, exc_traceback, limit=2, file=sys.stdout)
        sys.exit(0)
   

# Generated at 2022-06-24 20:02:54.127508
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert issubclass(int, str)
    test_case_0()


# Generated at 2022-06-24 20:02:56.880385
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = None
    var_0 = get_all_subclasses(str_0)
    raise NotImplementedError()


# Generated at 2022-06-24 20:02:59.618195
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)
    test_case_0()


import json
import pprint
import subprocess


# Generated at 2022-06-24 20:03:09.711635
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = str
    var_0 = get_all_subclasses(str_0)
    var_0.sort()
    assert (var_0 == [bytes, bytearray, basestring, unicode])
    # Get a list of all subclasses of `dict`
    dict_0 = dict
    var_1 = get_all_subclasses(dict_0)
    var_1.sort()

# Generated at 2022-06-24 20:03:11.156205
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test case 0
    test_case_0()


# Generated at 2022-06-24 20:03:13.044702
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str)==set([type(b''), type(bytearray()), type(memoryview()), type(u'')])

# Generated at 2022-06-24 20:03:19.485615
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = None
    assert get_all_subclasses(str_0) is None

# Generated at 2022-06-24 20:03:26.556813
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # String (?) has one subclass (basestring)
    assert len(get_all_subclasses(str)) == 1
    assert basestring in get_all_subclasses(str)
    # Int has none
    assert not get_all_subclasses(int)
    # List has many
    assert len(get_all_subclasses(list)) > 100
    # Number has two (int, float)
    assert len(get_all_subclasses(int)) == 2
    assert int in get_all_subclasses(int)
    assert float in get_all_subclasses(int)

# Generated at 2022-06-24 20:03:27.356553
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses

# Generated at 2022-06-24 20:03:28.672678
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(1) == set()



# Generated at 2022-06-24 20:03:30.708392
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:03:32.345614
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    param_0 = None
    test_case_0()

# Generated at 2022-06-24 20:03:33.944938
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = list()
    var_1 = get_all_subclasses(var_0)
    assert var_1 == set([])

# Generated at 2022-06-24 20:03:36.990553
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:03:41.269839
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == set([])
    assert get_all_subclasses(int) == set([])
    assert get_all_subclasses(bool) == set([])


# Generated at 2022-06-24 20:03:49.369004
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()
# Load the module
from ansible.module_utils._text import to_text
from ansible.module_utils._text import to_native

from ansible.module_utils.six.moves import zip
from ansible.module_utils.six import PY3, string_types

# Load the json module
from ansible.module_utils.six import iteritems
from ansible.module_utils.six import text_type
# Load the BasicModuleBase
from ansible.module_utils.basic import BasicModuleBase

from ansible.module_utils.six import BytesIO
# Load the json module
import json

# Load the AnsibleModule
from ansible.module_utils.basic import AnsibleModule


# Load the json module
from ansible.module_utils.six import iteritems

# Generated at 2022-06-24 20:04:00.402285
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:04:03.099528
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)
    str_0 = None
    var_0 = get_all_subclasses(str_0)
    assert isinstance(var_0, set)



# Generated at 2022-06-24 20:04:04.141794
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)



# Generated at 2022-06-24 20:04:06.408205
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print("Running test_get_all_subclasses")
    test_case_0()

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:04:10.452547
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Verify that the result is a set
    assert isinstance(get_all_subclasses(str), set)



# Generated at 2022-06-24 20:04:13.437167
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    pass



# Generated at 2022-06-24 20:04:16.641386
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses('scenario_0_0') == 'expected_0_0'
    assert get_all_subclasses('scenario_1_1') == 'expected_1_1'
    assert get_all_subclasses('scenario_2_2') == 'expected_2_2'

# Generated at 2022-06-24 20:04:20.645012
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(test_case_0) == None, 'test_case_0: Check input parameter is not'


# Generated at 2022-06-24 20:04:30.582680
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class_s = str
    class_a = bytes
    class_b = bytearray
    class_c = memoryview
    class_d = dict
    class_e = list
    class_f = tuple
    class_g = set
    class_h = frozenset

    str_subclass = get_all_subclasses(class_s)
    assert class_a in str_subclass, "Class 'bytes is not a subclass of str"
    assert class_b in str_subclass, "Class 'bytearray is not a subclass of str"
    assert class_c in str_subclass, "Class 'memoryview is not a subclass of str"

    dict_subclass = get_all_subclasses(class_d)

# Generated at 2022-06-24 20:04:38.924843
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    s = get_all_subclasses(str)
    assert len(s) == 9
    assert unicode in s
    assert str in s
    assert basestring in s
    assert type(None) in s

    s = get_all_subclasses(basestring)
    assert len(s) == 8
    assert unicode in s
    assert str in s
    assert type(None) in s

    s = get_all_subclasses(unicode)
    assert len(s) == 7
    assert str in s
    assert type(None) in s

    s = get_all_subclasses(Exception)
    assert len(s) == 393
    assert EnvironmentError in s
    assert OSError in s
    assert IOError in s
    assert WindowsError in s
    assert AssertionError in s
   

# Generated at 2022-06-24 20:05:04.135823
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print('Testing function get_all_subclasses')

    # We disable to following message:
    # 'Instance of a class' has no '__call__' member (no-member)

    # pylint: disable=no-member
    assert get_all_subclasses(str) == {unicode}
    assert get_all_subclasses(list) == {tuple, set, frozenset, deque}
    assert get_all_subclasses(dict) == {OrderedDict}
    assert get_all_subclasses(int) == {bool}

# Generated at 2022-06-24 20:05:09.012328
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test case 0
    str_0 = None
    var_0 = get_all_subclasses(str_0)

    # Test case 1
    str_1 = 'i'
    var_1 = get_all_subclasses(str_1)



# Generated at 2022-06-24 20:05:09.646150
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    pass

# Generated at 2022-06-24 20:05:11.222154
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(test_case_0) is None


# Generated at 2022-06-24 20:05:13.239205
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print('Test get_all_subclasses')
    test_case_0()

# Main function

# Generated at 2022-06-24 20:05:14.527474
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test the class variable case
    assert test_case_0() == 0

# Generated at 2022-06-24 20:05:16.300650
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = None
    var_0 = get_all_subclasses(str_0)


# Generated at 2022-06-24 20:05:22.168967
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses(str)
    assert var_0 == {str} , 'Expected equality but got: %s' % var_0
    var_0 = get_all_subclasses(list)
    assert var_0 == {list, bytes, bytearray, set, frozenset} , 'Expected equality but got: %s' % var_0

test_get_all_subclasses()

# Generated at 2022-06-24 20:05:25.308325
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(test_get_all_subclasses) != None

# Generated at 2022-06-24 20:05:27.175708
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = None
    assert get_all_subclasses(str_0) != None



# Generated at 2022-06-24 20:06:13.467559
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except:
        assert False



# Generated at 2022-06-24 20:06:21.343774
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses('0') == set()
    assert get_all_subclasses(True) == set()
    assert get_all_subclasses(0) == set()
    assert get_all_subclasses(test_case_0) == set()
    assert get_all_subclasses(str) == {str}
    assert get_all_subclasses(int) == set()
    assert get_all_subclasses(bool) == set()
    assert get_all_subclasses(float) == set()
    assert get_all_subclasses(complex) == {complex}
    assert get_all_subclasses(object) == set()
    assert get_all_subclasses(type) == {type}

# Generated at 2022-06-24 20:06:24.805275
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Imports for test
    import __main__
    import json
    import sys
    import types
    import os
    import unittest
    from importlib import import_module
    from ansible.module_utils._text import to_bytes

    # Unit test for function get_all_subclasses

    __main__.test_case_0()

    # Check if result is an isinstance of the class we think it should be
    assert isinstance(var_0, set)

# Generated at 2022-06-24 20:06:28.575261
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Function definitions for test cases
    def test_case_0(str_0):
        var_0 = get_all_subclasses(str_0)
        return var_0

    # Test cases
    assert test_case_0(None) == None


# Generated at 2022-06-24 20:06:32.743960
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = 'test'
    assert get_all_subclasses(str_0) == set()
    list_0 = list('')
    assert get_all_subclasses(list_0) == set()
test_case_0()
test_get_all_subclasses()

# Generated at 2022-06-24 20:06:41.469559
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import text_type

    number_subclasses = 4  # py3: int, float, complex, bool
    str_subclasses = 2     # py2: unicode, long
    bytes_subclasses = 2   # py2: str, long
    list_subclasses = 11   # py2: range, tuple, xrange, UserList, UserList.UserList, list, UserString, UserString.MutableString, str, UserByteString, UserByteString.MutableByteString
    text_subclass = 1      # py3: str
    native_subclass = 1    # py3: bytes


# Generated at 2022-06-24 20:06:42.052222
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert False # Stub


# Generated at 2022-06-24 20:06:42.748623
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert isinstance(get_all_subclasses(str), set)



# Generated at 2022-06-24 20:06:45.935125
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == set()
    assert get_all_subclasses(type) == set()



# Generated at 2022-06-24 20:06:48.721301
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert 'set' in get_all_subclasses(set)
    assert 'list' in get_all_subclasses(list)
    assert 'dict' in get_all_subclasses(dict)




# Generated at 2022-06-24 20:08:29.531295
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == {unicode}
    # get_all_subclasses error condition
    with pytest.raises(AttributeError):
        get_all_subclasses(None)

# Generated at 2022-06-24 20:08:31.188635
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = None
    var_0 = get_all_subclasses(str_0)



# Generated at 2022-06-24 20:08:38.809233
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(int) == set()
    assert get_all_subclasses(str) == set()
    assert get_all_subclasses(object) == set([str, list, int, float, set, tuple, dict])
    assert get_all_subclasses(tuple) == set()
    assert get_all_subclasses(list) == set()

# Generated at 2022-06-24 20:08:40.600173
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """ Test for get_all_subclasses """

    assert True == True

if __name__ == "__main__":
    import pytest
    pytest.main('-qq -test_get_all_subclasses')

# Generated at 2022-06-24 20:08:45.314949
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert hasattr(get_all_subclasses, '__call__')
    assert hasattr(get_all_subclasses, '__annotations__')

# Generated at 2022-06-24 20:08:48.242731
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = None
    var_0 = get_all_subclasses(str_0)
    str_1 = "str"
    var_1 = get_all_subclasses(str_1)
    int_0 = None
    var_2 = get_all_subclasses(int_0)
    int_1 = 1
    var_3 = get_all_subclasses(int_1)

if __name__ == "__main__":
    test_case_0()
    test_get_all_subclasses()

# Generated at 2022-06-24 20:08:54.964469
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    from ansible.module_utils.six import PY3

    import pytest
    import sys

    if sys.version_info[:2] == (2, 6):
        pytest.skip('Unable to get __subclasses__() on Python 2.6')

    # Python 3
    if PY3:
        str_0 = str
        var_0 = get_all_subclasses(str_0)
        assert(var_0 == set([bytes]))

        var_1 = get_all_subclasses(bytes)
        assert(var_1 == set())

        # Python 2
    else:
        str_0 = str
        var_0 = get_all_subclasses(str_0)
        assert(var_0 == set([unicode]))


# Generated at 2022-06-24 20:08:58.791593
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    res_0 = get_all_subclasses()


# Code starts here
# class name(object):


if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:09:03.022293
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_1 = 'test_get_all_subclasses'
    var_1 = get_all_subclasses(str_1)
    str_1 = 'test_get_all_subclasses'
    var_2 = get_all_subclasses(str_1)


# Generated at 2022-06-24 20:09:03.821245
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True
