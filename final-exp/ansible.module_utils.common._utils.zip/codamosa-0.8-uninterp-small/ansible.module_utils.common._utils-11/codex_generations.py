

# Generated at 2022-06-24 20:01:43.316846
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(set) is not None

# Generated at 2022-06-24 20:01:47.970302
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = None
    var_0 = get_all_subclasses(set_0)
    set_1 = None
    var_1 = get_all_subclasses(set_1)
    set_2 = None
    var_2 = get_all_subclasses(set_2)
    set_3 = None
    var_3 = get_all_subclasses(set_3)


# Generated at 2022-06-24 20:01:51.395394
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes
    assert to_text(to_bytes('Hello')) == u'Hello'

# Generated at 2022-06-24 20:01:58.869856
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(D): pass

    set_0 = {A, B, C, D, E}
    var_0 = get_all_subclasses(A)
    var_1 = get_all_subclasses(B)
    var_2 = get_all_subclasses(C)
    var_3 = get_all_subclasses(D)
    var_4 = get_all_subclasses(E)
    assert set_0 == var_0



# Generated at 2022-06-24 20:02:05.119474
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """ Test that all needed class are found with get_all_subclasses """
    # Test with an empty class
    class Test0():
        """ Test class """

    # Test if Test0 is returned
    assert get_all_subclasses(Test0) == set([Test0])

    # Test with a class containing one subclass
    class Test1():
        """ Test class """

    class Test11(Test1):
        """ Test child class """

    # Test if Test11 is returned
    assert get_all_subclasses(Test1) == set([Test11])

    # Test with a class containing two subclasses
    class Test2():
        """ Test class """

    class Test21(Test2):
        """ Test child class """

    class Test22(Test2):
        """ Test child class """

    # Test if Test21 and Test22 are returned


# Generated at 2022-06-24 20:02:10.601403
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    result = get_all_subclasses(set)
    assert len(result) == 2
    assert frozenset((set, frozenset)) == frozenset(result)

# Generated at 2022-06-24 20:02:14.061124
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    ansible_module_class = type('AnsibleModule', (object, ), {'__module__': 'ansible.module_utils.basic'})
    ansible_module = ansible_module_class()
    assert type(get_all_subclasses(set)) == set

# Generated at 2022-06-24 20:02:15.319559
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(set) == { frozenset }

# Generated at 2022-06-24 20:02:17.544287
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_1 = get_all_subclasses(set)
    var_1 = get_all_subclasses(set)

# Function to test get_all_subclasses

# Generated at 2022-06-24 20:02:26.478057
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys
    import types

# Generated at 2022-06-24 20:02:38.796069
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test all subclasses of str
    assert set(get_all_subclasses(str)) == {
        str, unicode, bytes, basestring,
        bytearray, buffer
    }

    # Test all subclasses of dict
    assert set(get_all_subclasses(dict)) == {
        dict, defaultdict, OrderedDict,
        UserDict, UserString, UserList
    }

    # Test all subclasses of set

# Generated at 2022-06-24 20:02:40.066303
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = None
    var_0 = get_all_subclasses(set_0)

# Generated at 2022-06-24 20:02:44.674905
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = None
    set_1 = frozenset()
    set_2 = frozenset("abc")
    set_3 = frozenset("123")

    var_0 = get_all_subclasses(set_0)
    var_1 = get_all_subclasses(set_1)
    var_2 = get_all_subclasses(set_2)
    var_3 = get_all_subclasses(set_3)


if __name__ == "__main__":
    # Test for get_all_subclasses
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:52.842151
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Project configuration file
    from ansible.parsing.vault import VaultLib

    # Test with VaultLib class
    vault_lib_class = VaultLib

    # Retrieve all descendent classes of VaultLib
    descendent_classes = get_all_subclasses(vault_lib_class)

    # Assert that the class Password only got 1 descendent class
    assert len(descendent_classes) == 1

    # Assert that the class Password only got VaultLibAES256 as descendent class
    assert list(descendent_classes)[0].__name__ == 'VaultLibAES256'

    # Test with Password class
    password_class = vault_lib_class.Password

    # Retrieve all descendent classes of Password
    descendent_classes = get_all_subclasses(password_class)

    # Assert that

# Generated at 2022-06-24 20:02:54.127107
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(set) == set([frozenset])

# Generated at 2022-06-24 20:02:55.406403
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()



# Generated at 2022-06-24 20:02:56.522308
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert var_0 == set_0

# Generated at 2022-06-24 20:03:06.522158
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class Vehicle(object):
        pass

    class Car(Vehicle):
        pass

    class SUV(Car):
        pass

    class Motorcycle(Vehicle):
        pass

    class Lorry(Vehicle):
        pass

    class FastMotorcycle(Motorcycle):
        pass

    class FasterMotorcycle(FastMotorcycle):
        pass

    my_vehicle = Vehicle()
    my_car = Car()
    my_suv = SUV()
    my_motorcycle = Motorcycle()
    my_lorry = Lorry()
    my_fast_motorcycle = FastMotorcycle()
    my_faster_motorcycle = FasterMotorcycle()

    assert SUV in get_all_subclasses(Vehicle)
    assert SUV in get_all_subclasses(Car)

# Generated at 2022-06-24 20:03:09.652507
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(set([1, 2])) == (int, basestring, frozenset, list, set)

# Generated at 2022-06-24 20:03:11.404971
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(test_case_0) != test_case_0
# end unit test

# Generated at 2022-06-24 20:03:26.182122
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    return

if __name__ == "__main__":
    import sys
    print("In main program for module utils")
    item_to_test = sys.argv[1] if len(sys.argv) > 1 else ""
    print("item_to_test: " + str(item_to_test))
    if item_to_test:
        test_case_0()
        test_case_1()
        test_case_2()
        test_case_3()
        test_case_4()
        test_case_5()
        test_case_6()
        test_case_7()
        test_case_8()
        test_case_9()
        test_case_10()
        test_case_11()
        test_case_12()
        test_case_13()


# Generated at 2022-06-24 20:03:34.539856
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(A):
        pass

    class F(E):
        pass

    class G(E):
        pass

    class H(G):
        pass

    class I(F):
        pass

    class J(H):
        pass

    set_0 = A
    var_0 = get_all_subclasses(set_0)
    assert var_0 == {B, C, D, E, F, G, H, I, J}

    set_1 = E
    var_1 = get_all_subclasses(set_1)
    assert var_1 == {F, G, H, I, J}

    set_

# Generated at 2022-06-24 20:03:42.805417
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Set
    from collections import Iterable

    wbr = get_all_subclasses(set())
    assert isinstance(wbr, Set)
    assert issubclass(wbr.__class__, Iterable)
    assert set([type({}), type(set()), type(frozenset())]) == wbr
    assert len(set([type({}), type(set()), type(frozenset())])) == len(wbr)
    assert set([type({}), type(set()), type(frozenset())]) <= wbr

    wbr = get_all_subclasses(frozenset())
    assert isinstance(wbr, Set)
    assert issubclass(wbr.__class__, Iterable)

# Generated at 2022-06-24 20:03:50.305363
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Testing when the class is None
    try:
        test_case_0()
    except TypeError:
        pass
    else:
        raise AssertionError('An exception should have been thrown')
    # Testing when 0 subclasses
    class TestCase1:
        pass
    set_1 = TestCase1
    set_1_result = set()
    assert get_all_subclasses(set_1) == set_1_result
    # Testing when 1 subclasses
    class TestCase2(TestCase1):
        pass
    set_2 = TestCase1
    set_2_result = {TestCase2}
    assert get_all_subclasses(set_2) == set_2_result
    # Testing when 2 subclasses
    class TestCase21(TestCase2):
        pass
    set_21 = TestCase

# Generated at 2022-06-24 20:03:58.021729
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    foo_classes = []
    # Define some trivial classes
    class Foo(object): pass
    class Foo1(Foo): pass
    class Foo2(Foo): pass
    class Foo3(Foo1): pass
    class Foo4(Foo1): pass
    class Foo5(Foo4): pass

    foo_classes += [Foo1, Foo2, Foo3, Foo4, Foo5]

    # Verify that we've got all the subclasses
    assert set(foo_classes) == set(get_all_subclasses(Foo))

if __name__ == "__main__":
    test_case_0()
    test_get_all_subclasses()

# Generated at 2022-06-24 20:04:05.656730
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_text
    # Test cases for get_all_subclasses
    set_0 = frozenset([])
    var_0 = get_all_subclasses(set_0)
    assert var_0 == set([])

    set_1 = frozenset(['foo'])
    var_1 = get_all_subclasses(set_1)
    assert var_1 == set(['foo'])

    set_2 = frozenset([1, 2, 3])
    var_2 = get_all_subclasses(set_2)
    assert var_2 == set([1, 2, 3])

    set_3 = frozenset({})
    var_3 = get_all_subclasses(set_3)
    assert var_3 == set({})

    set_4

# Generated at 2022-06-24 20:04:11.506755
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = 14
    var_0 = get_all_subclasses(set_0)
    assert var_0 != -1, "get_all_subclasses failed with %s" % var_0


# Generated at 2022-06-24 20:04:13.982358
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert 'module_utils.common.removed' not in str(get_all_subclasses(set))
    assert 'module_utils.common.removed' in str(get_all_subclasses(object))

# Generated at 2022-06-24 20:04:15.957144
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = {'name'}
    if get_all_subclasses(set_0) != {'name'}:
        raise AssertionError()


# Generated at 2022-06-24 20:04:17.049895
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(set_0) == var_0

# Generated at 2022-06-24 20:04:36.570169
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Perform unit tests on function get_all_subclasses
    from ansible import module_utils
    from ansible.module_utils import six

    # Create a Dummy class for testing
    class TestClass(object):
        """ Used for testing get_all_subclasses """

    # Create two subclasses of TestClass
    class TestClass_0(TestClass):
        """ Used for testing get_all_subclasses """
    class TestClass_1(TestClass):
        """ Used for testing get_all_subclasses """

    # Create two subclasses of TestClass_0
    class TestClass_2(TestClass_0):
        """ Used for testing get_all_subclasses """
    class TestClass_3(TestClass_0):
        """ Used for testing get_all_subclasses """

    # Run test cases

# Generated at 2022-06-24 20:04:37.601320
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() is None

# Generated at 2022-06-24 20:04:42.904512
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(object):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(F) == set([])
    assert get_all_subclasses(E) == set([])

# Generated at 2022-06-24 20:04:51.331165
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        from collections import Set
        from collections import namedtuple
        import pprint

        MySet = Set
    except ImportError:
        pass

    class MySet(set):
        pass

    SetItem = namedtuple('SetItem', ['name', ])

    class A(MySet):
        pass

    class B(MySet):
        pass

    class C(MySet):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    result = get_all_subclasses(MySet)

    pprint.pprint(result)
    assert not result.difference({A, B, C, D, E, F, G})

    result = get_all_subclasses(SetItem)


# Generated at 2022-06-24 20:04:52.460561
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    classes = get_all_subclasses(set)
    assert len(classes) == 8

# Generated at 2022-06-24 20:04:56.294832
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = {2, 3}
    assert set_0 == get_all_subclasses(set_0)

# Generated at 2022-06-24 20:05:04.107771
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.plugins.loader import find_plugin_filenames, find_template_paths

    # The file find_plugin_filenames contains this line:
    #   for _path in find_template_paths():
    # but we are only interested in the set of all the subclasses of find_template_paths
    # so the rest of the code is removed.
    subclasses = get_all_subclasses(find_template_paths)
    assert len(subclasses) > 0



# Generated at 2022-06-24 20:05:08.544926
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = None
    var_0 = get_all_subclasses(set_0)
    assert var_0 is not None
    # Check if len is equal to 0 
    assert len(var_0) == 0 


# Generated at 2022-06-24 20:05:15.386331
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(G):
        pass
    class J(H):
        pass

    assert sorted([B, D, E, C, F, G, H, I, J]) == sorted(get_all_subclasses(A))

# Generated at 2022-06-24 20:05:16.853162
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # run all test cases here
    test_case_0()

# Generated at 2022-06-24 20:05:43.489562
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    my_class = type('my_class', (), {})
    my_sub_class = type('my_sub_class', (my_class,), {})
    my_other_sub_class = type('my_other_sub_class', (my_class,), {})
    my_grand_child_class = type('my_grand_child_class', (my_sub_class,), {})

    my_other_class = type('my_other_class', (), {})
    my_other_sub_class = type('my_other_sub_class', (my_other_class,), {})

    assert get_all_subclasses(my_class) == (my_sub_class, my_other_sub_class, my_grand_child_class)
    assert get_all_subclasses(my_other_class)

# Generated at 2022-06-24 20:05:44.429833
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(__builtins__.set) is not None

# Generated at 2022-06-24 20:05:52.725735
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # check return type
    assert isinstance(get_all_subclasses(object), object)
    # call function with no parameters
    try:
        get_all_subclasses()
    except TypeError as e:
        assert e.args[0] == "get_all_subclasses() takes exactly 1 argument (0 given)"
    # call function with too many parameters
    try:
        get_all_subclasses(object, object)
    except TypeError as e:
        assert e.args[0] == "get_all_subclasses() takes exactly 1 argument (2 given)"
    # call function with invalid parameters
    try:
        get_all_subclasses(var_0)
    except UnboundLocalError:
        assert True

# Generated at 2022-06-24 20:06:04.042516
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    
    # testing function with empty set
    set_0 = set()
    var_0 = get_all_subclasses(set_0)
    assert var_0 == set()
    # testing functions with non empty set
    set_1 = set()
    set_1.add(object)
    var_1 = get_all_subclasses(set_1)
    # assert var_1 == set(['<class \'str\'>', '<class \'dict\'>', '<class \'object\'>', '<class \'int\'>', '<class \'range\'>', '<class \'list\'>', '<class \'set\'>', '<class \'float\'>', '<class \'tuple\'>'])
    assert var_1 == set()


# Generated at 2022-06-24 20:06:12.437587
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import abc
    import types

    class MyABC(object):
        __metaclass__ = abc.ABCMeta

    class Foo(object):
        pass

    class Bar(MyABC):
        pass

    class Baz(Bar):
        pass

    assert set(get_all_subclasses(Foo)) == set([])
    assert set(get_all_subclasses(MyABC)) == set([Bar])
    assert set(get_all_subclasses(object)) == set([bool, int, basestring, tuple, long, list, dict, set, frozenset, file, types.NoneType, type])
    assert set(get_all_subclasses(Bar)) == set([Baz])
    assert set(get_all_subclasses(Baz)) == set([])

# Generated at 2022-06-24 20:06:14.224729
# Unit test for function get_all_subclasses
def test_get_all_subclasses(): # functions without GET or POST methods do not require a CSRF check
    assert (test_case_0())


# Generated at 2022-06-24 20:06:20.943461
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print("Test function `test_get_all_subclasses` in module `test_get_all_subclasses.py`")
    set_0 = None
    test_set_0 = {'NoneType'}
    var_0 = get_all_subclasses(set_0)
    assert var_0 == test_set_0, "Function returns unexpected value!"
    test_case_0()
    print("Function `get_all_subclasses` passed unit tests!")

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:06:27.922085
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Arbitrary class for testing
    class ArbitraryClass(object):
        def __init__(self, *args, **kwargs):
            pass

    # Test a class with no subclasses
    assert get_all_subclasses(ArbitraryClass) == set([])

    # Test a class with one subclass
    sub_class_1 = type('SubClass1', (ArbitraryClass, ), dict())
    assert get_all_subclasses(ArbitraryClass) == set([sub_class_1])

    # Test a class with two subclasses
    sub_class_2 = type('SubClass2', (ArbitraryClass, ), dict())
    assert get_all_subclasses(ArbitraryClass) == set([sub_class_1, sub_class_2])

    # Test a class with a subclass of a subclass
    sub_

# Generated at 2022-06-24 20:06:29.345267
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() == None


# Generated at 2022-06-24 20:06:31.287508
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(set) == {
        frozenset,
        set,
    }

# Generated at 2022-06-24 20:06:50.198473
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Set
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Set
    from ansible.module_utils.six import with_metaclass
    # Test case with input set_0
    result = get_all_subclasses(basic.AnsibleModule)
    assert result == {basic.AnsibleModuleHelper}



# Generated at 2022-06-24 20:06:55.971935
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    import unittest

    class MyClass: pass
    class Child(MyClass): pass
    class ChildChild(Child): pass

    class TestGetAllSubclasses(unittest.TestCase):

        def test_get_all_subclasses(self):
            self.assertEqual(set([Child, ChildChild]), get_all_subclasses(MyClass))

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-24 20:06:59.983102
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_of_module_names = []
    for module in [__import__(x) for x in __all__]:
        f = getattr(module, 'test_get_all_subclasses', None)
        if callable(f):
            f()
            list_of_module_names.append(module.__name__)
    assert list_of_module_names == ['_utils', 'ansible_test', 'ansible_test.loader', 'ansible_test.errors']



# Generated at 2022-06-24 20:07:02.707986
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        return False

    return True

# Generated at 2022-06-24 20:07:09.701572
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A:
        pass
    class B:
        pass
    class C:
        pass
    class D:
        pass
    class E(A, B, C):
        pass
    class F(D):
        pass
    class G(E, F):
        pass
    class H(G):
        pass

    assert get_all_subclasses(object) == {type}

    assert get_all_subclasses(A) == {E, G, H}
    assert get_all_subclasses(B) == {E, G, H}
    assert get_all_subclasses(C) == {E, G, H}
    assert get_all_subclasses(D) == {F, G, H}
    assert get_all_subclasses(E) == {G, H}
    assert get_all_sub

# Generated at 2022-06-24 20:07:12.073479
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    if not test_case_0():
        print("Unit test for function get_all_subclasses FAILED.")
    else:
        print("Unit test for function get_all_subclasses PASSED.")

# Generated at 2022-06-24 20:07:14.987000
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(set) == {frozenset,}

# Generated at 2022-06-24 20:07:25.600382
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = None
    var_0 = get_all_subclasses(set_0)
    set_1 = {0}
    set_0 = {int}
    var_0 = get_all_subclasses(set_0)
    var_1 = {bool}
    var_2 = {str}
    var_3 = {float}
    var_4 = {list}
    var_5 = {dict}
    var_6 = {complex}
    var_7 = {tuple}
    var_8 = {set}
    var_9 = {object}
    var_10 = {bytearray}
    var_11 = {bytes}
    var_12 = {frozenset}
    var_13 = {range}



# Generated at 2022-06-24 20:07:34.114814
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a base class
    class base_class(object):
        pass

    # Create a child class
    class child_class(base_class):
        pass

    # Create a second child class
    class second_child_class(child_class):
        pass

    # Create another class not subclassed from base_class
    class non_subclass(object):
        pass

    # Get all subclasses
    subclasses = get_all_subclasses(base_class)

    # Check if the desired class is present
    if child_class in subclasses:
        assert True

    # Check if the second child is present
    if second_child_class in subclasses:
        assert True

    # Check if the non_subclass is present
    if non_subclass in subclasses:
        assert False

    # Assert that the subclasses is

# Generated at 2022-06-24 20:07:37.609305
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = {'a', 'b', 'c', 'd'}
    var_0 = 'a' in get_all_subclasses(set_0)
    assert var_0 == True
    assert type(var_0) == bool


# Generated at 2022-06-24 20:08:09.417471
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = get_all_subclasses(set)
    var_0 = set_0
    set_1 = get_all_subclasses(list)
    var_1 = set_1
    set_2 = get_all_subclasses(dict)
    var_2 = set_2
    return var_0, var_1, var_2

if __name__ == "__main__":
    var = test_get_all_subclasses()
    print(var)

# Generated at 2022-06-24 20:08:10.042534
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert False


# Generated at 2022-06-24 20:08:19.265905
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from unittest import TestCase
    import _utils
    setup_test_utils = """
    a = set()
    b = set()
    c = set()
    d = set()
    e = set()
    f = set()
    g = set()
    set_0 = set()
    set_0.add(a)
    set_0.add(b)
    b_0 = set()
    b_0.add(c)
    b_0.add(d)
    set_0.add(e)
    set_0.add(f)
    e_0 = set()
    e_0.add(g)
    set_0.add(e_0)
"""

# Generated at 2022-06-24 20:08:27.184101
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(0) == set()
    assert get_all_subclasses(None) == set()
    assert get_all_subclasses('') == set()
    assert get_all_subclasses(True) == set()
    assert get_all_subclasses(False) == set()

if __name__ == '__main__':
    test_case_0()
    test_get_all_subclasses()

# Generated at 2022-06-24 20:08:30.911959
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    test_case_0()

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:08:35.434698
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(None) is None

# Generated at 2022-06-24 20:08:42.924543
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test with empty class
    test_class_0 = type('', (), {})
    assert get_all_subclasses(test_class_0) == set()
    # Test with one subclass
    test_class_1 = type('TestClass1', (), {})
    assert test_class_1.__bases__ == ()
    test_class_2 = type('TestClass2', (test_class_1, ), {})
    assert test_class_2.__bases__ == (test_class_1, )
    assert get_all_subclasses(test_class_1) == set([test_class_2])
    # Test with multiple subclasses
    test_class_3 = type('TestClass3', (), {})

# Generated at 2022-06-24 20:08:46.475362
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = {1, 2, 3}
    var_0 = get_all_subclasses(set_0)
    assert var_0 == { int, str, object}, "Return value is not the expected value"


# Generated at 2022-06-24 20:08:48.960424
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert 1 == 1

# Generated at 2022-06-24 20:08:55.284738
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    set_0 = {'b', 'c', 'a', 'd'}
    set_0.add('a')
    set_0.remove('d')
    set_0.discard('b')
    set_0.add('b')
    list_1 = []
    list_1.extend(list_0)
    list_1.sort()
    list_1.sort(key=bool)
    list_1.sort(key=bool, reverse=True)

    # Test cases
    assert isinstance(list_1, list)
    assert len(list_1) > 2
    assert list_1[0] == 'a'
    assert list_1[1] == 'b'
    assert list_1[2] == 'c'

# Generated at 2022-06-24 20:09:49.936000
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    assert(set(get_all_subclasses(A)) == set([B, C, D, E]))
    assert(set(get_all_subclasses(B)) == set([D]))
    assert(set(get_all_subclasses(C)) == set([E]))
    assert(set(get_all_subclasses(D)) == set([]))
    assert(set(get_all_subclasses(E)) == set([]))

# Generated at 2022-06-24 20:09:57.069699
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text

    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_text

    a = to_bytes('\xf1')
    print(a)

    a = to_native('\xc5\x82')
    print(a)

    assert True


# Generated at 2022-06-24 20:10:06.200688
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Set
    from collections import UserList

    set_0 = get_all_subclasses(Set)
    var_0 = set([Set])
    set_1 = get_all_subclasses(UserList)
    var_1 = set([UserList])
    set_2 = get_all_subclasses(None)
    var_2 = set([])

    assert set_0 == var_0, "Expected: %s, Actual: %s" % (var_0, set_0)
    assert set_1 == var_1, "Expected: %s, Actual: %s" % (var_1, set_1)
    assert set_2 == var_2, "Expected: %s, Actual: %s" % (var_2, set_2)


# Generated at 2022-06-24 20:10:12.510126
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(C):
        pass

    class Z(D, E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, Z, E])
    assert set(get_all_subclasses(B)) == set([D, Z])
    assert set(get_all_subclasses(C)) == set([D, E, Z])
    assert se

# Generated at 2022-06-24 20:10:14.370031
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except BaseException as e:
        print("Test case 0 failed - " + str(e))
        raise



# Generated at 2022-06-24 20:10:19.869382
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(object):
        pass

    class F(E):
        pass

    class G(F):
        pass

    class J(object):
        pass

    class K(J):
        pass

    class L(K):
        pass

    class H(D, G):
        pass

    class I(L, H):
        pass

    r = get_all_subclasses(A)
    assert r == set([B, C, D, H, I])

# Generated at 2022-06-24 20:10:24.710425
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common._collections_compat import Mapping, MutableMapping
    from ansible.module_utils.six import string_types, numeric_types
    from ansible.module_utils.six import with_metaclass
    # Make sure we have all classes in our test_case
    set_0 = {to_bytes, to_native, Mapping, MutableMapping, string_types, numeric_types, with_metaclass}
    # Test case 0
    test_case_0()
    # Verify class equality
    var_0 = get_all_subclasses(set_0)
    assert var_0 == set_0

# Generated at 2022-06-24 20:10:33.269337
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    assert test_case_0() == None


# def load_platform_subclass(cls, *args, **kwargs):
#     '''
#     Load a subclass of `cls`.
#
#     :arg cls: A class object.
#     :arg args: Arguments to pass to the constructor of `cls` if no subclasses of `cls` is
#                loaded.
#     :arg kwargs: Keyword arguments to pass to the constructor of `cls` if no subclasses of
#                  `cls` is loaded.
#     :returns: An object of a subclass of `cls`.
#
#     This function loads a subclass of `cls`.  If none of the subclasses load, it will instantiate
#     the `cls` object using the constructor arguments `args` and `kwargs`.


# Generated at 2022-06-24 20:10:39.870092
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(object):
        pass

    class G(F):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(object):
        pass

    class L(K):
        pass

    class M(L):
        pass

    class N(M):
        pass

    class O(N):
        pass

    expected = set([D, E, B, C, J, H, I, G, F, O, N, M, L, K])
    actual = get_all_subclasses

# Generated at 2022-06-24 20:10:42.030539
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert hasattr(get_all_subclasses, '__call__')
    assert callable(get_all_subclasses)
    assert test_case_0() == None