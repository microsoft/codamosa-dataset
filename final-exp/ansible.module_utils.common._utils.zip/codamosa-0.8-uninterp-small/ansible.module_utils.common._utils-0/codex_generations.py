

# Generated at 2022-06-24 20:01:47.111555
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except Exception:
        assert False, "unit test for get_all_subclasses raise Exception"
    else:
        assert True, "unit test for get_all_subclasses"


if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:01:49.640723
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)
    assert isinstance(get_all_subclasses(), set)
    assert callable(get_all_subclasses)

test_get_all_subclasses()

# Generated at 2022-06-24 20:01:52.787778
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True

# Generated at 2022-06-24 20:02:01.356581
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # create a class
    class A(object):
        def __init__(self):
            pass

    # create a subclass of the first class
    class B(A):
        def __init__(self):
            pass

    # create a second subclass of the first class
    class C(A):
        def __init__(self):
            pass

    # create a subclass of the second class
    class D(C):
        def __init__(self):
            pass

    # create a second subclass of the second class
    class E(C):
        def __init__(self):
            pass

    # create an instance of class A and use that object to
    # search for all the subclasses of class A
    var_0 = A()
  

# Generated at 2022-06-24 20:02:09.151136
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert_equal(get_all_subclasses(self),
                          result)
    assert_equal(get_all_subclasses(self),
                          result)
    assert_equal(get_all_subclasses(self),
                          result)
    assert_equal(get_all_subclasses(self),
                          result)
    assert_equal(get_all_subclasses(self),
                          result)
    assert_equal(get_all_subclasses(self),
                          result)
    assert_equal(get_all_subclasses(self),
                          result)
    assert_equal(get_all_subclasses(self),
                          result)

# Generated at 2022-06-24 20:02:19.545364
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys, tempfile, shutil
    print("Test start: get_all_subclasses")

    # A test list of classes.
    # We don't have to include types.BuiltinMethodType because it isn't a real class.
    test_class_list = ['type', 'types.CodeType', 'types.BuiltinFunctionType', 'types.FunctionType', 'types.TypeType', 'types.GeneratorType', 'types.GetSetDescriptorType', 'types.MemberDescriptorType', 'types.LambdaType']

    # Capture the output of get_all_subclasses, and turn it into a set to remove duplicates
    result_class_set = set(get_all_subclasses(type))

    # Turn the list of classes in test_class_list into a set for easier comparison

# Generated at 2022-06-24 20:02:23.753103
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print("Test if function get_all_subclasses() works...")
    print("If no asserts error, function works!")

    class_0 = list

    while class_0:
        class_0 = get_all_subclasses(class_0)
        try:
            class_0.pop()
        except:
            break

    assert(True)



# Generated at 2022-06-24 20:02:26.717432
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import datetime
    classes = get_all_subclasses(datetime.date)
    assert datetime.datetime in classes
    assert datetime.time in classes
    assert datetime.datetime in classes


# Generated at 2022-06-24 20:02:36.595836
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Is it a list
    assert isinstance(get_all_subclasses(list), list)

    # Properly retrieve classes
    assert dict in get_all_subclasses(list)
    assert dict in get_all_subclasses(dict)

    # Do not retrieve same class
    assert dict not in get_all_subclasses(dict)
    assert set not in get_all_subclasses(dict)

    # Do not retrieve abstract base classes:
    ABC = get_all_subclasses(object)  # ABC are all classes derived from object
    for a in ABC:
        assert a not in get_all_subclasses(set)
        assert a not in get_all_subclasses(dict)
        assert a not in get_all_subclasses(list)

# Generated at 2022-06-24 20:02:38.583815
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test function body
    var_0 = get_all_subclasses(list)
    assert isinstance(var_0, set)

# Generated at 2022-06-24 20:02:44.370628
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-24 20:02:50.405548
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    result = get_all_subclasses(list)
    assert len(result) == 2
    assert list in result
    assert tuple in result

    result = get_all_subclasses(dict)
    assert len(result) == 0

# Generated at 2022-06-24 20:02:52.639356
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_0 = []
    var_0 = get_all_subclasses(list_0)
    assert var_0

# Generated at 2022-06-24 20:03:03.275065
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_bytes
    import time

    class A:
        pass

    class B:
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(A):
        pass

    class G(E):
        pass

    class H(E, F):
        pass

    class I(H):
        pass

    expected = set([C, E, G, H])
    result = get_all_subclasses(A)

    assert result == expected, "Set %s is not equal expected set %s" % (result, expected)

    expected = set([D])
    result = get_all_subclasses(B)


# Generated at 2022-06-24 20:03:08.111123
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
    	# Unit test for function get_all_subclasses
        test_case_0()
    except Exception as e:
    	print("Testcase 1")
    	print(e)
    	assert False



# Generated at 2022-06-24 20:03:14.000643
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    ansible_module_utils_path = 'ansible_collections.ansible.community.plugins.module_utils.'
    test_case_0()


# Execute unit tests on this module
if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:03:24.981593
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except Exception as e:
        print('Caught exception: ' + repr(e))


if __name__ == '__main__':
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule

    import json
    import inspect

    param_types = {
        'get_all_subclasses': {
            'cls': {'required': True, 'type': 'object'}
        }
    }

    params = {
        'get_all_subclasses': {
            'cls': {}
        }
    }

    # x = []
    # print(type(x))
    # print(type('x'))
    # print(type(10))
    # print(type(True))

   

# Generated at 2022-06-24 20:03:26.607074
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:03:27.433077
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() == None



# Generated at 2022-06-24 20:03:28.713546
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    with pytest.raises(ValueError):
        test_case_0()

# Generated at 2022-06-24 20:03:38.834381
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print('get_all_subclasses test')
    test_case_0()
    print('all tests passed')


if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:03:39.965885
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    stu_test = test_case_0()
    assert True

test_get_a

# Generated at 2022-06-24 20:03:49.415951
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()


# Boiler-plate code for CLI execution
if __name__ == '__main__':
    import sys
    if len(sys.argv) == 2:
        module_name = sys.argv[1].split('.')[0]
        test_func_name = 'test_' + sys.argv[1].split('.')[1]
        module = __import__(module_name)
        try:
            test_func = getattr(module, test_func_name)
            test_func()
        except AttributeError:
            print('Test case not found')
    else:
        print('Invalid input arguments')

# Generated at 2022-06-24 20:03:51.904959
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_0 = []
    assert_equal((list_0.__subclasses__()), [dict])
    assert_equal((get_all_subclasses(list_0)), [dict])

# Generated at 2022-06-24 20:03:54.685481
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_text
    result = get_all_subclasses(to_text)

    assert to_text in result
    assert hasattr(result, '__iter__')



# Generated at 2022-06-24 20:04:02.737814
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import OrderedDict
    import inspect

    # Test for the case where a non-class is passed in
    try:
        get_all_subclasses("test")
        # This should fail
        assert(False)
    except TypeError:
        pass

    # Retrieve all subclasses defined in this file
    subclasses = set()
    for cls in globals().values():
        # Only check classes
        if inspect.isclass(cls):
            subclasses.update(get_all_subclasses(cls))

    # Create a dictionary mapping the class name to the class
    class_dict = OrderedDict()
    for cls in subclasses:
        class_dict[cls.__name__] = cls

    # Check that every class defined in this file appears in the set of subclasses

# Generated at 2022-06-24 20:04:06.697619
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert 'list' in get_all_subclasses(list)
    assert 'dict' in get_all_subclasses(dict)
    assert 'str' in get_all_subclasses(str)
    assert 'int' not in get_all_subclasses(str)


if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:04:11.993881
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    try:
        list_0 = get_all_subclasses(A)
        assert list_0 == [B, C, D]
    except Exception:
        print('Test failed with exception')

test_get_all_subclasses()

# Generated at 2022-06-24 20:04:13.828683
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_0 = []
    var_0 = get_all_subclasses(list_0)
    assert var_0 is not None

# Generated at 2022-06-24 20:04:20.375728
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Build test suite
    suite = unittest.TestSuite()
    suite.addTest(TestGetAllSubclasses('test_case_0'))
    # Execute test suite
    result = unittest.TestResult()
    suite.run(result)
    # Print test result
    print('Errors : ' + str(len(result.errors)))
    print('Failures : ' + str(len(result.failures)))
    for failure in result.failures:
        print(failure[0])
        print(failure[1])
# unit test
if __name__ == '__main__':
    # import python libraries
    import unittest
    # Create a TestSuite object
    suite = unittest.TestSuite()

# Generated at 2022-06-24 20:04:33.207505
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_0 = []
    var_0 = get_all_subclasses(list_0)

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:04:42.151792
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    expected_0 = set()
    expected_1 = set()
    expected_2 = set()
    expected_3 = set([dict])
    expected_4 = set([dict])
    expected_5 = set()
    expected_6 = set([type])
    expected_7 = set([str])
    expected_8 = set([tuple])
    var_0 = get_all_subclasses(list)
    if var_0 == expected_0:
        assert True
    else:
        assert False
    var_1 = get_all_subclasses(str)
    if var_1 == expected_1:
        assert True
    else:
        assert False
    var_2 = get_all_subclasses(int)
    if var_2 == expected_2:
        assert True
    else:
        assert False
    var

# Generated at 2022-06-24 20:04:44.502852
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """Check if function returns a list of class names"""
    assert get_all_subclasses(list) == ['set']



# Generated at 2022-06-24 20:04:45.429083
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:04:47.059399
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_0 = []
    assert(get_all_subclasses(list_0) == [])

# Generated at 2022-06-24 20:04:52.060533
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses([]) == set()
    assert get_all_subclasses(set()) == set()
    assert get_all_subclasses(dict()) == set()

# Generated at 2022-06-24 20:04:57.585633
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(list) == set([list, tuple])
    assert get_all_subclasses(list) == set([tuple, list])
    assert get_all_subclasses(list) == set([list, tuple])

# Generated at 2022-06-24 20:05:06.046700
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    import pytest

    with pytest.raises(TypeError) as error:
        # Test if the function raises a TypeError if the attribute '__subclasses__' is not found
        test_case_0()
    assert "object has no attribute '__subclasses__'" in str(error.value)


# Generated at 2022-06-24 20:05:16.465990
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test class A
    class A:
        def __init__(self):
            pass

    # Test class B
    class B(A):
        def __init__(self):
            pass

    # Test class C
    class C(A):
        def __init__(self):
            pass

    # Test class D
    class D(B):
        def __init__(self):
            pass

    # Test class E
    class E(C):
        def __init__(self):
            pass

    # Result of get_all_subclasses
    result_b = get_all_subclasses(B)
    result_c = get_all_subclasses(C)
    result_a = get_all_subclasses(A)
    result_d = get_all_subclasses(D)

# Generated at 2022-06-24 20:05:20.168449
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        assert get_all_subclasses("") == set()
    except AssertionError:
        raise AssertionError("Expected get_all_subclasses() to return an empty set, but instead it returned: " + repr(get_all_subclasses("")))



# Generated at 2022-06-24 20:05:46.717148
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base1:
        pass

    class Base2(Base1):
        pass

    class Base3(Base2):
        pass

    class SubClass1(Base1):
        pass

    class SubClass2(Base1):
        pass

    class SubSubClass(SubClass1):
        pass

    assert SubSubClass in get_all_subclasses(Base1)
    assert SubClass2 in get_all_subclasses(Base1)
    assert SubSubClass in get_all_subclasses(Base2)
    assert SubSubClass in get_all_subclasses(Base3)
    assert SubClass2 not in get_all_subclasses(Base3)

# Generated at 2022-06-24 20:05:53.142673
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    results_1 = get_all_subclasses()
    # Assertion: 'list' object has no attribute '__subclasses__' in 'get_all_subclasses' ignored
    results_2 = get_all_subclasses([])
    # Assertion: 'list' object has no attribute '__subclasses__' in 'get_all_subclasses' ignored
    results_3 = get_all_subclasses(['a'])
    # Assertion: 'str' object has no attribute '__subclasses__' in 'get_all_subclasses' ignored
    results_4 = get_all_subclasses('a')
    # Assertion: 'str' object has no attribute '__subclasses__' in 'get_all_subclasses' ignored
    results_5 = get_all_subclasses(set())
    # Assertion

# Generated at 2022-06-24 20:05:56.374429
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert 1 == 1, "Test to see if 1 == 1"

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:06:05.123894
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansiblelint.rules import RulesCollection
    from ansiblelint import Runner

    collection = RulesCollection.create_from_directory('lib/ansiblelint/rules')
    test_case_0()
    runner = Runner(collection, 'test/parser.yml', [], [], [])
    assert runner.run() == [{'filename': 'test/parser.yml', 'line': 1, 'linter': 'ANSIBLE0013', 'ruleId': 'ANSIBLE0013', 'severity': 'VERY_HIGH', 'start_line_number': 0, 'end_line_number': 0, 'start_column': 0, 'end_column': 0, 'message': 'Use shell only when shell functionality is needed'}]

# Generated at 2022-06-24 20:06:06.780156
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses), 'Function "get_all_subclasses" is not callable'



# Generated at 2022-06-24 20:06:16.725998
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    #
    # Verify the list of all subclasses of list_0
    #
    list_0 = list()
    list_1 = get_all_subclasses(list_0)
    assert list_1 == {set, tuple, dict, frozenset}
    #
    # Verify the list of all subclasses of dict_0
    #
    dict_0 = dict()
    dict_1 = get_all_subclasses(dict_0)
    assert dict_1 == set()
    #
    # Verify the list of all subclasses of int_0
    #
    int_0 = int()
    int_1 = get_all_subclasses(int_0)
    assert int_1 == set()


if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:06:17.577145
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:06:19.147400
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_0 = []
    var_0 = get_all_subclasses(list_0)
    assert var_0 == list_0

# Generated at 2022-06-24 20:06:22.153127
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    x = test_case_0()
    assert x is None, x

# Generated at 2022-06-24 20:06:23.475691
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print('Testing get_all_subclasses')
    test_case_0()
    print('Implementation of get_all_subclasses passed all test cases')

# Generated at 2022-06-24 20:07:10.095242
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from io import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    import contextlib

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    test_result = True

# Generated at 2022-06-24 20:07:13.481611
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class_A = object

# Generated at 2022-06-24 20:07:14.666050
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_cases = [test_case_0]
    for test in test_cases:
        test()

# Generated at 2022-06-24 20:07:18.084451
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_0 = []
    var_0 = get_all_subclasses(list_0)


if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:07:24.913589
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import _utils
    assert(_utils.get_all_subclasses([]) == [])
    assert(_utils.get_all_subclasses('') == [])
    assert(_utils.get_all_subclasses([]) == [])
    assert(_utils.get_all_subclasses(()) == [])
    assert(_utils.get_all_subclasses({}) == [])
    # You can use set to check asserting. For example
    assert(set(_utils.get_all_subclasses(dict)) == set({}))


# Generated at 2022-06-24 20:07:32.232832
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_0 = []
    assert get_all_subclasses(list_0) == []
    dict_0 = dict(list_0)
    assert get_all_subclasses(dict_0) == []
    set_0 = set(list_0)
    assert get_all_subclasses(set_0) == []
    int_0 = int()
    assert get_all_subclasses(int_0) == []
    str_0 = str()
    assert get_all_subclasses(str_0) == []
    value = False
    try:
        get_all_subclasses(value)
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 20:07:33.089526
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert False


# Generated at 2022-06-24 20:07:34.222593
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(0) == TypeError, 'Expected error does not match'



# Generated at 2022-06-24 20:07:36.016374
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        # Check the case
        test_case_0()

    except Exception as ex:
        assert False, 'Unable to execute test case: ' + str(ex)

# Generated at 2022-06-24 20:07:39.570634
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)
    assert get_all_subclasses.__name__ == 'get_all_subclasses'
    assert get_all_subclasses.__doc__ is not None
# end of test_get_all_subclasses

if __name__ == "__main__":
    test_get_all_subclasses()
# end of main

# Generated at 2022-06-24 20:09:33.063806
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_native
    has_failed = False
    try:
        test_case_0()
    except Exception as exc:
        has_failed = True
        msg = "TEST CASE 0: %s" % (to_native(exc))
    assert not has_failed, msg

# Generated at 2022-06-24 20:09:35.075698
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_1 = []
    var_1 = get_all_subclasses(list_1)
    assert(var_1 == set())

# Generated at 2022-06-24 20:09:39.015993
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_0 = []
    assert get_all_subclasses(list_0) == []
    list_1 = ["a",1]
    assert get_all_subclasses(list_1) == ['list']


if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:09:48.079217
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(list) == set([])
    assert get_all_subclasses(dict) == {collections.defaultdict}
    assert get_all_subclasses(collections.defaultdict) == set([])
    assert get_all_subclasses(str) == {frozenset, bytes, bytearray, xrange, tuple, object, memoryview, list, type,
                                       property, staticmethod, slice, frozendict, set, weakref.ReferenceType,
                                       buffer, weakref.WeakSet, weakref.WeakKeyDictionary, complex,
                                       weakref.WeakValueDictionary, super, classmethod, frozenset, enumerate,
                                       BaseException, dict, int}

# Generated at 2022-06-24 20:09:48.884463
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert 0 == 0



# Generated at 2022-06-24 20:09:52.691610
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_1 = get_all_subclasses(test_case_0)
    assert var_1 is None
    assert len(var_1) == 0
    return var_1

# Generated at 2022-06-24 20:10:03.566340
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)
#! /usr/bin/python
"""
Test for class get_all_subclasses and method get_all_subclasses
"""

# System imports
import sys
import unittest
import os
import time


# Global Data
import ansible.module_utils.basic as Basic
import ansible.module_utils._text as text

# Setup logging
Basic.logging.basicConfig(level=Basic.logging.NOTSET)
logger = Basic.logging.getLogger(__name__)
logger.setLevel(Basic.logging.INFO)

# Get the current file's directory
file_dir = os.path.dirname(os.path.realpath(os.path.abspath(__file__)))

# Add parent directory to $PATH so we can import

# Generated at 2022-06-24 20:10:06.780890
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(object)

# Generated at 2022-06-24 20:10:09.986683
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    list_0 = []
    assert get_all_subclasses(list_0) == None, "AssertionError: {} == None".format(get_all_subclasses(list_0))


# Generated at 2022-06-24 20:10:13.449422
# Unit test for function get_all_subclasses