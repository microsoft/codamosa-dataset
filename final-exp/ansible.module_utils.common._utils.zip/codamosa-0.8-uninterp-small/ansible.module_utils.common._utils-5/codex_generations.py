

# Generated at 2022-06-24 20:01:49.767096
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    get_all_subclasses(str)

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:01:53.329893
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test get_all_subclasses function
    """
    s = 'ansible_collections.not_a_real_collection.plugins.modules.my_test.my_obj.MyTest'
    # This will blow up if the function is not defined.
    var_0 = get_all_subclasses(s)

# Generated at 2022-06-24 20:01:59.303312
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = "u\x92\x7fW\xba\xc7\xe9\xfe\x90\x8fH\x99\x01\n\xa2\x8d\xbd\x0b\xabM\x9d\x9c\x1e\x80\xb8\xca\xc6\xaa'"
    var_0 = get_all_subclasses(str_0)


# Generated at 2022-06-24 20:02:00.348041
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(None) == {}



# Generated at 2022-06-24 20:02:07.743862
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import OrderedDict

    class BaseClass(object):
        pass

    class DerivedClass1(BaseClass):
        pass

    class DerivedClass2(BaseClass):
        pass

    class DerivedClass3(DerivedClass1):
        pass

    class OtherBaseClass(object):
        pass

    class DerivedClass4(OtherBaseClass):
        pass

    expected_classes = OrderedDict()
    expected_classes[BaseClass] = [DerivedClass1, DerivedClass2, DerivedClass3]
    expected_classes[DerivedClass1] = [DerivedClass3]
    expected_classes[DerivedClass3] = list()
    expected_classes[DerivedClass2] = list()
    expected_classes[OtherBaseClass] = [DerivedClass4]

# Generated at 2022-06-24 20:02:09.422291
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    print(test_case_0())

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:16.883236
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses("lorem ipsum") == set()
    assert get_all_subclasses(object) == {type, bool, basestring, bytes, tuple, bytearray, xrange, complex, int, float, long, list, memoryview, set, frozenset, dict}
    assert get_all_subclasses(int) == set([bool])
    assert get_all_subclasses(basestring) == set([str, unicode])
    assert get_all_subclasses(basestring) == get_all_subclasses(str)
    assert get_all_subclasses(bool) == set()



# Generated at 2022-06-24 20:02:17.325613
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert True

# Generated at 2022-06-24 20:02:19.122500
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = "9LH9w'}N!\r1&p$"
    var_0 = get_all_subclasses(str_0)


if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:21.398049
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except Exception:
        assert False


if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:25.399219
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert test_case_0() == False

# Generated at 2022-06-24 20:02:27.680534
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except:
        assert False

# Unit tests for function get_all_subclasses

# Generated at 2022-06-24 20:02:38.147868
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # No arguments
    assert get_all_subclasses() is None, "get_all_subclasses() returns %s" % (get_all_subclasses())

    # First argument is a string
    assert get_all_subclasses("string") is None, "get_all_subclasses(\"string\") returns %s" % (get_all_subclasses("string"))

    # First argument is a boolean
    assert get_all_subclasses(True) is None, "get_all_subclasses(True) returns %s" % (get_all_subclasses(True))

    # First argument is a list

# Generated at 2022-06-24 20:02:40.004298
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except:
        print("Exception in test case 0")
#     else:
#         print("Test case 0 passed")


# Generated at 2022-06-24 20:02:43.929796
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except:
        import sys
        print("[FAIL]\tFailed to execute function test_get_all_subclasses.\n\tException: ", sys.exc_info()[0])
        raise e
    else:
        print("[OK]\tSuccessfully executed function test_get_all_subclasses.")


if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:02:45.480499
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:02:46.094079
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:02:56.262653
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = get_all_subclasses(str)
    if (len(var_0) != 1):
        raise AssertionError()
    if (type not in var_0):
        raise AssertionError()

    var_1 = get_all_subclasses(int)
    if (len(var_1) != 0):
        raise AssertionError()

    var_2 = get_all_subclasses(int)
    if (len(var_2) != 0):
        raise AssertionError()

    var_3 = get_all_subclasses(int)
    if (len(var_3) != 0):
        raise AssertionError()

    var_4 = get_all_subclasses(int)
    if (len(var_4) != 0):
        raise AssertionError()


# Generated at 2022-06-24 20:03:02.395704
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = "9LH9w'}N!\r1&p$"
    var_0 = get_all_subclasses(str_0)
    str_1 = "o&~e4Yz4['R1N"
    var_1 = get_all_subclasses(str_1)
    assert var_0 == var_1

# Run test case
test_get_all_subclasses()

# Generated at 2022-06-24 20:03:05.276479
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses)

# Generated at 2022-06-24 20:03:11.846724
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

test_get_all_subclasses()

# Generated at 2022-06-24 20:03:13.169091
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = "TE'@M<Z=E^,%i\x0cf\\5\x11\x12"
    var_0 = get_all_subclasses(str_0)



# Generated at 2022-06-24 20:03:19.611280
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    def test_case_0():
        str_0 = "9LH9w'}N!\r1&p$"
        var_0 = get_all_subclasses(str_0)

# Generated at 2022-06-24 20:03:24.401366
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert callable(get_all_subclasses), "Function does not exist"
    assert isinstance(get_all_subclasses(""), set), "Returned not a set"
    assert get_all_subclasses("") is not None, "Returned None instead of a set"

# Call function that has not yet been defined
test_case_0()

# Tests
test_get_all_subclasses()

# Generated at 2022-06-24 20:03:33.762424
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = "9LH9w'}N!\r1&p$"
    str_1 = "9LH9w'}N!\r1&p$"
    var_0 = get_all_subclasses(str_0)
    assert len(list(var_0)) == 1, "Expected [1], got [{}]".format(len(list(var_0)))
    assert all(isinstance(x, str) for x in list(var_0)), "Expected [True, True], got [{}, {}]".format(all(isinstance(x, str) for x in list(var_0)), all(isinstance(x, str) for x in list(var_0)))

# Generated at 2022-06-24 20:03:36.830917
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()


# Generated at 2022-06-24 20:03:39.901064
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert(str(type(test_case_0())) == "<type 'set'>")

# Generated at 2022-06-24 20:03:45.761065
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    str_0 = "9LH9w'}N!\r1&p$"
    var_0 = "9LH9w'}N!\r1&p$"
    var_1 = get_all_subclasses(str_0)

    assert var_0 == str_0
    assert var_1 != str_0


# Generated at 2022-06-24 20:03:49.980749
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import _ast
    assert get_all_subclasses(_ast.alias) == {_ast.alias}
    # This test tries to verify the recursiveness of the function
    import collections
    assert get_all_subclasses(collections.abc.MutableSequence).__contains__(list)

# Generated at 2022-06-24 20:03:56.788956
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Get list of subclasses
    subclasses = get_all_subclasses(list([4, 3,2,1]))
    print("subclasses of list:", subclasses)
    # Get list of subclasses
    subclasses = get_all_subclasses("")
    print("subclasses of str:", subclasses)
    # Get list of subclasses
    subclasses = get_all_subclasses(set(["", ""]))
    print("subclasses of set:", subclasses)

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-24 20:04:10.180222
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    try:
        test_case_0()
    except Exception:
        import traceback
        exception = traceback.format_exc()
        assert False, exception
    else:
        assert True

# Generated at 2022-06-24 20:04:14.469813
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test if an exception is thrown when an input is not a class
    with pytest.raises(TypeError):
        get_all_subclasses("This is a String")

    # Test another case
    class TestClass(object):
        pass

    mySubClass = TestClass()

    test_case_0()
    test_case_2()
    test_case_3()

# Generated at 2022-06-24 20:04:21.350389
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    user_str = "user_str"
    user_str_check = get_all_subclasses(str)
    user_str_check.append(str)
    test_case_0()
    assert str in user_str_check

# Generated at 2022-06-24 20:04:23.149359
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Generated at 2022-06-24 20:04:24.147987
# Unit test for function get_all_subclasses

# Generated at 2022-06-24 20:04:32.092642
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    var_0 = 'class_0'
    str_0 = ")p4+b'}8W!\r1vw$"
    class_0 = get_all_subclasses(var_0)
    str_1 = "4LH4w'}N!\r1&p$"
    class_1 = get_all_subclasses(str_0)
    class_2 = get_all_subclasses(str_1)
    var_1 = class_0.__subclasses__()
    str_2 = "0LH0w'}N!\r1&p$"
    var_2 = class_1.__subclasses__()
    str_3 = "6LH6w'}N!\r1&p$"
    var_3 = class_2.__subclasses__()

# Generated at 2022-06-24 20:04:33.179777
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    test_case_0()

# Main entry point

# Generated at 2022-06-24 20:04:36.665769
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert(issubclass(type([]), get_all_subclasses(type([]))))
    assert(issubclass(type(''), get_all_subclasses(type(''))))
    assert(issubclass(type({}), get_all_subclasses(type({}))))
    assert(issubclass(type(9), get_all_subclasses(type(9))))

# Generated at 2022-06-24 20:04:40.614338
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    str_0 = "9LH9w'}N!\r1&p$"
    assert type(str_0) == str
    var_0 = get_all_subclasses(str_0)
    assert type(var_0) == set


# Generated at 2022-06-24 20:04:46.185810
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert(get_all_subclasses(str) is not None)
    assert(get_all_subclasses(list) is not None)
    assert(get_all_subclasses(dict) is not None)
    class ExampleClass:
        pass
    assert(get_all_subclasses(ExampleClass) is not None)
# END OF FILE#