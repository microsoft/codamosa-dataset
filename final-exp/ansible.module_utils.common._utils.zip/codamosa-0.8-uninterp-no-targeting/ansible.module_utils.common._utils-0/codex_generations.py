

# Generated at 2022-06-20 15:20:36.900926
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(C): pass
    class H(F): pass

    assert len(get_all_subclasses(A)) == 7


# Generated at 2022-06-20 15:20:45.171161
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C, D): pass
    class F(B, D): pass
    class G(E): pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(object) == set([type, type(A), type(B), type(C), type(D), type(E), type(F), type(G)])

# Generated at 2022-06-20 15:20:54.703830
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(A):
        pass
    class F(D):
        pass
    assert set(get_all_subclasses(A)) == set([B,C,D,E,F])
    assert set(get_all_subclasses(B)) == set([C])
    assert set(get_all_subclasses(C)) == set([])
    assert set(get_all_subclasses(D)) == set([F])
    assert set(get_all_subclasses(E)) == set([])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-20 15:20:59.405298
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Classtree
    #
    #                       A
    #                     /   \
    #           B -- C -- D    E -- F
    #          /
    #      G -- H
    #
    # Expected : [B, C, D, G, H, E, F]
    #
    # The class `metaclass` is saved to keep compatibility with python 2 and 3

    class A(object):
        __metaclass__ = type

    class B(A):
        __metaclass__ = type

    class C(B):
        __metaclass__ = type

    class D(C):
        __metaclass__ = type

    class E(A):
        __metaclass__ = type

    class F(E):
        __metaclass__ = type

    class G(B):
        __

# Generated at 2022-06-20 15:21:03.347184
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(C, D):
        pass

    class F(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-20 15:21:12.258881
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(B): pass
    class D(B): pass
    class E(C, D): pass
    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == {C, D, E}
    assert get_all_subclasses(C) == {E}
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(E) == set()



# Generated at 2022-06-20 15:21:22.432787
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == {D, E}
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(E) == set()


# Generated at 2022-06-20 15:21:32.661339
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Generate a class tree
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(E): pass
    class G(D): pass

    # Test different class
    assert set([A, B, C, D, E, F, G]) == get_all_subclasses(A)
    assert set([B, D]) == set(get_all_subclasses(B))
    assert set([C, E, F]) == set(get_all_subclasses(C))
    assert set([D, G]) == set(get_all_subclasses(D))
    assert set([E, F]) == set(get_all_subclasses(E))

# Generated at 2022-06-20 15:21:39.673905
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(B)) == set([C, D])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([])



# Generated at 2022-06-20 15:21:46.482961
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D, C):
        pass
    class F:
        pass

    a = A()
    b = B()
    c = C()
    d = D()
    e = E()
    f = F()

    assert get_all_subclasses(A) == set([B, C])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E])
    assert get_all_subclasses(D) == set([E])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-20 15:21:56.870225
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Basic class
    class A(): pass
    # Create a class B with inheritance A
    class B(A): pass
    # Create a class C with inheritance A
    class C(A): pass
    # Create a class D with inheritance B
    class D(B): pass
    # Create a class E with inheritance C
    class E(C): pass
    # Create a class F with inheritance C
    class F(C): pass
    # Create a class G with inheritance B
    class G(B): pass
    # Test the results
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])

# Generated at 2022-06-20 15:22:06.838260
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This function is not intended to be run as a test case, but it is intended
    to be run manually.  When this file is renamed and moved to a permanent
    location, delete this function.
    '''

    class A(object):
        pass


    class B(A):
        pass


    class C(A):
        pass


    class D(C):
        pass


    assert set(get_all_subclasses(A)) == set([B, C, D])

    class E(object):
        pass


    assert set(get_all_subclasses(E)) == set([])


if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-20 15:22:12.189883
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class BaseClass(object):
        pass

    class Level1_A(BaseClass):
        pass

    class Level1_B(BaseClass):
        pass

    class Level2_A(Level1_A):
        pass

    class Level2_B(Level1_A):
        pass

    class Level2_C(Level1_B):
        pass

    class Level3_A(Level2_A):
        pass

    class Level3_B(Level2_A):
        pass

    class Level3_C(Level2_B):
        pass

    class Level3_D(Level2_B):
        pass

    class Level3_E(Level2_C):
        pass

    class Level3_F(Level2_C):
        pass


# Generated at 2022-06-20 15:22:18.038671
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set()


# Generated at 2022-06-20 15:22:22.726648
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    sub_classes = get_all_subclasses(A)
    expected = {B, C, D, E, F}
    assert sub_classes == expected

# Note: Python 2 does not support subclassing built-in types like "dict",
# so we need to add a layer of indirection here.

# Generated at 2022-06-20 15:22:30.701056
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import ansible.plugins.action.network as network

    network_subclasses = get_all_subclasses(network.ActionModule)
    assert len(network_subclasses) == 81
    assert 'ansible.plugins.action.network.iosxr.ActionModule' in str(network_subclasses)
    assert 'ansible.plugins.action.network.aos.ActionModule' in str(network_subclasses)
    assert 'ansible.plugins.action.network.nxos_acl_interface.ActionModule' in str(network_subclasses)
    assert 'ansible.plugins.action.network.ios_vlan_interfaces.ActionModule' in str(network_subclasses)

# Generated at 2022-06-20 15:22:38.366746
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Defining a tree-like class structure
    class parent(object): pass
    class c1(parent): pass
    class c2(parent): pass
    class gc1(c1): pass
    class gc11(gc1): pass
    class gc12(gc1): pass
    class gc2(c1): pass
    class gc3(c2): pass
    class gc4(c2): pass

    # Retrieving all subclasses
    subclasses = get_all_subclasses(parent)
    assert subclasses == set([c1, c2, gc1, gc2, gc3, gc4, gc11, gc12])

# Generated at 2022-06-20 15:22:44.305948
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a(object):
        pass

    class b(a):
        pass

    class c(a):
        pass

    class d(c):
        pass

    class e(object):
        pass

    assert d in get_all_subclasses(a)
    assert c in get_all_subclasses(a)
    assert d in get_all_subclasses(c)
    assert b in get_all_subclasses(a)
    assert b not in get_all_subclasses(c)
    assert d not in get_all_subclasses(e)
    assert d not in get_all_subclasses(b)

# Generated at 2022-06-20 15:22:50.089149
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a few classes to play with
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(object):
        pass

    class G(C, F):
        pass

    classes = get_all_subclasses(A)
    assert len(classes) == 4
    assert B in classes
    assert C in classes
    assert D in classes
    assert G in classes

# Generated at 2022-06-20 15:23:00.424666
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(E):
        pass
    classes = get_all_subclasses(A)
    assert H in classes
    assert G in classes
    assert F in classes
    assert E in classes
    assert D in classes

# A decorator to allow a function to be wrapped such that it will pass options
# to the AnsibleModule defined by the function. It is expected to run before the
# function_wrapper.

# Generated at 2022-06-20 15:23:10.075704
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(object): pass
    class D(A): pass
    class E(A): pass
    class F(E): pass
    class G(A): pass
    class H(G): pass
    class I(G): pass
    assert get_all_subclasses(object) == set()
    assert get_all_subclasses(A) == set([D, E, F, G, H, I])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set()
    assert get_all_subclasses

# Generated at 2022-06-20 15:23:16.388134
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass

    # Test
    all_classes = get_all_subclasses(A)

    assert(B in all_classes)
    assert(C in all_classes)
    assert(D in all_classes)
    assert(E in all_classes)
    assert(A not in all_classes)

# Generated at 2022-06-20 15:23:26.518902
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Iterable
    import unittest
    import types

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class TestAllSubclasses(unittest.TestCase):

        def setUp(self):
            self.a = A
            self.b = B
            self.c = C
            self.d = D
            self.e = E
            self.f = F
            self.g = G
            self.h = H


# Generated at 2022-06-20 15:23:33.577281
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class testA(object):
        pass

    class testB(testA):
        pass

    class testC(testA):
        pass

    class testD(testB):
        pass

    class testE(testC):
        pass

    class testF(testD):
        pass

    subclasses = set([testB, testC, testD, testE, testF])
    assert get_all_subclasses(testA) == subclasses
    try:
        class testG(testD):
            pass
    except Exception as e:
        assert False, 'Unable to create class testG: %s' % str(e)

    # testG is not in subclasses because get_all_subclasses uses set() to
    # include only unique subclasses
    assert testG in get_all_subclasses(testA)


# Generated at 2022-06-20 15:23:39.376645
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    ''' This is the unit test for get_all_subclasses() '''

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D])

# Generated at 2022-06-20 15:23:46.442128
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert len(get_all_subclasses(A)) == 5



# Generated at 2022-06-20 15:23:55.217432
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(D):
        pass

    assert(set(get_all_subclasses(A)) == {B, C, D, E, F})
    assert(set(get_all_subclasses(B)) == {D, E, F})
    assert(set(get_all_subclasses(C)) == set())
    assert(set(get_all_subclasses(D)) == {E, F})
    assert(set(get_all_subclasses(E)) == set())
    assert(set(get_all_subclasses(F)) == set())


# Generated at 2022-06-20 15:24:06.822295
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    assert len(get_all_subclasses(A)) == 5
    assert len(get_all_subclasses(B)) == 3
    assert len(get_all_subclasses(C)) == 1
    assert len(get_all_subclasses(D)) == 1
    assert len(get_all_subclasses(E)) == 1

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)

# Generated at 2022-06-20 15:24:16.362047
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    assert set([B,C]) == get_all_subclasses(A)
    assert set([C]) == get_all_subclasses(B)
    assert set([C]) == get_all_subclasses(C)
    assert set([E]) == get_all_subclasses(D)
    assert set([E]) == get_all_subclasses(E)

# Generated at 2022-06-20 15:24:22.432028
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(object): pass
    class D(A): pass
    class E(B): pass
    class F(C): pass
    class G(D): pass
    class H(E): pass
    class I(F): pass
    class J(G): pass
    class K(H): pass
    class L(I): pass
    class M(J): pass
    class N(K): pass
    class O(L): pass
    assert sorted(get_all_subclasses(A)) == sorted([D, G, J, M])
    assert sorted(get_all_subclasses(B)) == sorted([E, H, K, N])
    assert sorted(get_all_subclasses(C)) == sorted([F, I, L, O])

# Generated at 2022-06-20 15:24:33.022315
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''Unit test for function get_all_subclasses'''
    class a(object):
        pass

    class b(a):
        pass

    class c(b):
        pass

    class d(a):
        pass

    class e(d):
        pass

    assert set(get_all_subclasses(a)) == set([b, c, d, e])

# Generated at 2022-06-20 15:24:42.519632
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test class
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    #
    #          A
    #         / \
    #        B   C
    #       /
    #      D
    #
    #
    #
    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert D in get_all_subclasses(B)
    assert D in get_all_subclasses(C)
    assert D in get_all_subclasses(D)

# Generated at 2022-06-20 15:24:53.358761
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Class1(object):
        pass

    class Class2(Class1):
        pass

    class Class3(Class1):
        pass

    class Class4(object):
        pass

    class Class5(Class2):
        pass

    class Class6(Class5):
        pass

    class Class7(Class5):
        pass

    class Class8(Class7):
        pass

    class Class9(Class8):
        pass

    class Class10(Class9):
        pass

    assert Class1 in get_all_subclasses(Class1)
    assert Class2 in get_all_subclasses(Class1)
    assert Class3 in get_all_subclasses(Class1)
    assert Class4 in get_all_subclasses(Class4)
    assert Class5 in get_all_subclasses(Class1)
   

# Generated at 2022-06-20 15:24:58.494986
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(A): pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    # empty case too
    assert set(get_all_subclasses(D)) == set()


# Generated at 2022-06-20 15:25:05.673146
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Parent(object):
        pass

    class Child(Parent):
        pass

    class Child2(Parent):
        pass

    class GrandChild(Child):
        pass

    class GrandChild2(Child):
        pass

    class GrandChild3(Child2):
        pass

    # Testing with parent class (Parent)
    assert set(get_all_subclasses(Parent)) == set([Child, Child2, GrandChild, GrandChild2, GrandChild3])

    # Testing with child class (Child)
    assert set(get_all_subclasses(Child)) == set([GrandChild, GrandChild2])

# Generated at 2022-06-20 15:25:13.824538
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # A helper class for testing get_all_subclasses
    class A(object):
        pass
    class A1(A):
        pass
    class A2(A):
        pass
    class A1a(A1):
        pass
    class A1b(A1):
        pass
    class A2a(A2):
        pass
    assert set(get_all_subclasses(A)) == set([A1, A1a, A1b, A2, A2a])
    assert set(get_all_subclasses(A1)) == set([A1a, A1b])
    assert set(get_all_subclasses(A2)) == set([A2a])


# Generated at 2022-06-20 15:25:24.407552
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import namedtuple
    class A(object):
        pass
    class B(object):
        pass
    class C(object):
        pass
    class D(object):
        pass
    class E(object):
        pass
    class G(object):
        pass
    class F(C, E):
        pass
    # Tree
    #
    #         A
    #       /  \
    #      B    C
    #     / \   |
    #   D   F   G
    #     \ /
    #      E
    assert get_all_subclasses(object) == set()
    assert get_all_subclasses(A) == set([B, C, D, F, E, G])
    assert get_all_subclasses(B) == set([D, F, E])

# Generated at 2022-06-20 15:25:29.444816
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(F):
        pass

    classes_set = set((A, B, C, D, E, F, G))
    assert get_all_subclasses(A) == classes_set, 'Error: get_all_subclasses is broken'



# Generated at 2022-06-20 15:25:40.969880
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test to ensure that we get the right count of subclasses

    :rtype: bool
    :returns: True if all test passes, False otherwise.
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(E):
        pass

    assert len(get_all_subclasses(A)) == 7
    assert len(get_all_subclasses(B)) == 3
    assert len(get_all_subclasses(C)) == 4
    assert len(get_all_subclasses(D)) == 0

# Generated at 2022-06-20 15:25:45.623175
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(object): pass
    class E(B): pass
    class F(C): pass

    assert get_all_subclasses(A) == {B, C, E, F}

# Generated at 2022-06-20 15:26:03.976430
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define some classes
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(A):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(F):
        pass

    # Define expected result
    expected = {B, C, D, E, F, G, H}

    # Real test
    subclasses = get_all_subclasses(A)
    assert subclasses == expected



# Generated at 2022-06-20 15:26:11.039096
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(object):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(B, C):
        pass
    class G(F):
        pass
    class H(G, C):
        pass
    class I(G):
        pass
    assert get_all_subclasses(object) == {A, B, C, D, E, F, G, H, I}
    assert get_all_subclasses(A) == {B, D, E}
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(C) == set()



# Generated at 2022-06-20 15:26:21.640867
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test to check if each class is found and that we don't find the same class twice
    """

    class A(object):
        """
        A class
        """
        pass

    class B(A):
        """
        B class which inherits from A
        """
        pass

    class C(A):
        """
        C class which inherits from A
        """
        pass

    class D(B):
        """
        D class which inherits from B
        """
        pass

    class E(C):
        """
        E class which inherits from C
        """
        pass

    classes = get_all_subclasses(A)
    # Check that each class is find
    assert len(classes) == 5
    assert A in classes
    assert B in classes
    assert C in classes

# Generated at 2022-06-20 15:26:29.204942
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class base_class(object):
        pass

    class subclass_one(base_class):
        pass

    class subclass_two(base_class):
        pass

    class subclass_three(base_class):
        pass

    class subclass_four(subclass_three):
        pass

    class subclass_five(subclass_three):
        pass

    assert get_all_subclasses(base_class) == set([subclass_one, subclass_two, subclass_three,
                                                  subclass_four, subclass_five])

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-20 15:26:36.166807
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class X(object):
        pass

    class Y(X):
        pass

    class Z(X):
        pass

    class A(Y):
        pass

    class B(Y):
        pass

    class D(Z):
        pass
    classes = get_all_subclasses(X)
    assert Y in classes
    assert Z in classes
    assert A in classes
    assert B in classes
    assert D in classes

# Generated at 2022-06-20 15:26:43.614987
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B: pass
    class C: pass
    class D(A): pass
    class E(A): pass
    class F(B): pass
    class G(D): pass
    class H(E): pass
    class I(F): pass
    class J(G): pass
    class Z(C): pass

    assert get_all_subclasses(A) == {D, E, G, H}
    assert get_all_subclasses(B) == {F, I}
    assert get_all_subclasses(C) == {Z}
    assert get_all_subclasses(D) == {G, J}
    assert get_all_subclasses(E) == {H}
    assert get_all_subclasses(F) == {I}
    assert get_all_subclasses(G)

# Generated at 2022-06-20 15:26:53.399151
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    A unit test for module get_all_subclasses
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    classes = get_all_subclasses(A)
    for cl in [B, C, D, E, F]:
        assert cl in classes

    classes = get_all_subclasses(B)
    for cl in [D, E]:
        assert cl in classes

    classes = get_all_subclasses(C)
    for cl in [F]:
        assert cl in classes

# Generated at 2022-06-20 15:27:04.513687
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(G):
        pass
    class I(G):
        pass
    class J(G):
        pass
    class K(J):
        pass
    class L(J):
        pass

    class TestUtils(unittest.TestCase):
        def test_get_all_subclasses_simple(self):
            self.assertEqual(set(get_all_subclasses(A)), {B, C, D, E, F, G, H, I, J, K, L})
           

# Generated at 2022-06-20 15:27:09.125632
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(C):
        pass
    class G(object):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])

# Generated at 2022-06-20 15:27:13.330096
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(B): pass
    class F(D): pass
    class G(D): pass
    class I(A): pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, I])



# Generated at 2022-06-20 15:27:39.118084
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    class Parent(object):
        '''
        Parent class
        '''

    class Child1(Parent):
        '''
        Child 1
        '''

    class Child2(Parent):
        '''
        Child 2
        '''

    class GrandChild1(Child1):
        '''
        Grand Child 1
        '''

    class GrandChild2(Child2):
        '''
        Grand Child 2
        '''

    assert set([Child1, Child2, GrandChild1, GrandChild2]) == set(get_all_subclasses(Parent))

# Generated at 2022-06-20 15:27:43.043378
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(B,C): pass

    # Check for the number of subclasses
    subclasses = get_all_subclasses(A)
    subclasses_except_a = get_all_subclasses(A)
    subclasses_except_a.remove(A)
    assert len(subclasses) == 6
    assert len(subclasses_except_a) == 5

    # Check whether all the classes are in the list
    assert A in subclasses
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses

# Generated at 2022-06-20 15:27:50.206845
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import UserList
    from ansible.module_utils.six import add_metaclass
    # Python 2 and 3 compatiblity for the metaclass.  In Python 2, `metaclass` is a keyword.  In Python 3, it is not a keyword, but `six` adds it as a keyword.
    @add_metaclass(type)
    class Parent(object): pass

    class Child1(Parent): pass

    class Child2(Parent): pass

    class GrandChild(Child1): pass

    class NotChild(UserList): pass

    assert set([Parent, Child1, GrandChild, Child2]) == get_all_subclasses(Parent)
    assert set([Child1, GrandChild]) == get_all_subclasses(Child1)
    assert set([GrandChild]) == get_all_subclasses(GrandChild)



# Generated at 2022-06-20 15:27:57.864514
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Define a simple tree of classes
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    # Get all subclasses
    all_subclasses_of_A = get_all_subclasses(A)
    assert len(all_subclasses_of_A) == 3
    assert B in all_subclasses_of_A
    assert C in all_subclasses_of_A
    assert D in all_subclasses_of_A

# Generated at 2022-06-20 15:28:08.182741
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        def __init__(self):
            pass
    class B(A):
        def __init__(self):
            pass
    class C(A):
        def __init__(self):
            pass
    class D(C):
        def __init__(self):
            pass
    class E(C):
        def __init__(self):
            pass
    class F(B, D):
        def __init__(self):
            pass
    class G(B, E):
        def __init__(self):
            pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([F, G])

# Generated at 2022-06-20 15:28:13.536562
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    assert(set([B, D, C, E]) == get_all_subclasses(A))
    print("Test passed")

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-20 15:28:18.800637
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.utils._entity_cache import EntityCache

    class A(EntityCache):  # pylint: disable=too-few-public-methods
        pass

    class B(A):  # pylint: disable=too-few-public-methods
        pass

    class C(A):  # pylint: disable=too-few-public-methods
        pass

    class D(C):  # pylint: disable=too-few-public-methods
        pass

    c = get_all_subclasses(A)
    assert(B in c)
    assert(C in c)
    assert(D in c)
    assert(A not in c)

# Generated at 2022-06-20 15:28:22.076533
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a dummy class hierarchy
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(D):
        pass

    # Create an expected result
    expected_result = {B, C, D, E, F}

    # Create the real result
    real_result = get_all_subclasses(A)
    # Check equality of both
    assert expected_result == real_result

# Generated at 2022-06-20 15:28:25.701102
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C,B): pass
    class F(C): pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])

# Generated at 2022-06-20 15:28:35.606231
# Unit test for function get_all_subclasses

# Generated at 2022-06-20 15:29:36.412425
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    A_subclasses = set([B, C, D, E, F])
    B_subclasses = set([D, F])
    C_subclasses = set([E])
    assert A_subclasses == get_all_subclasses(A)
    assert B_subclasses == get_all_subclasses(B)
    assert C_subclasses == get_all_subclasses(C)
    assert set([]) == get_all_subclasses(D)
    assert set([]) == get_all_subclasses(E)
    assert set([]) == get_all_subclasses(F)

# Generated at 2022-06-20 15:29:40.310797
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(): pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(list) == set([])

# Generated at 2022-06-20 15:29:43.873633
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class Z(object):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D, E])
    assert get_all_subclasses(Z) == set()

# Generated at 2022-06-20 15:29:51.763125
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class D(object):
        pass
    class B(D):
        pass
    class C(D):
        pass
    class E(object):
        pass
    class A(B, C, E):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(D) == set([B, C])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-20 15:30:01.315692
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import copy

    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(A):
        pass
    all_subclasses = get_all_subclasses(A)
    assert all_subclasses == set([B, C, D, E])

    class A1:
        pass
    class A2(A1):
        pass
    class B1:
        pass
    class B2(B1):
        pass
    class C1(A1, B1):
        pass
    class C2(B1, A1):
        pass
    class D(C1, C2, A2):
        pass
    all_subclasses = get_all_subclasses(A1)
    assert all_sub

# Generated at 2022-06-20 15:30:07.869777
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Root(): pass
    class Child1(Root): pass
    class Child2(Root): pass
    class GrandChild1(Child1): pass
    class GrandChild2(Child2): pass
    root = Root()
    root_subclasses = get_all_subclasses(Root)
    assert len(root_subclasses) == 3
    assert Child1 in root_subclasses
    assert GrandChild1 in root_subclasses
    assert GrandChild2 in root_subclasses
    assert Child2 not in root_subclasses

# Generated at 2022-06-20 15:30:12.099802
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])



# Generated at 2022-06-20 15:30:16.753217
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(C):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E])



# Generated at 2022-06-20 15:30:24.343548
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Definition of a test class
    class ClassA(object):
        pass

    class ClassB(ClassA):
        pass

    class ClassC(ClassB):
        pass

    class ClassD(ClassB):
        pass

    class ClassE(ClassA):
        pass

    assert set(get_all_subclasses(ClassA)) == set([ClassB, ClassC, ClassD, ClassE])



# Generated at 2022-06-20 15:30:33.467772
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, F])
    assert get_all_subclasses(C) == set([E])
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])
    assert get_all_subclasses(object) == set([A, B, C, D, E, F])