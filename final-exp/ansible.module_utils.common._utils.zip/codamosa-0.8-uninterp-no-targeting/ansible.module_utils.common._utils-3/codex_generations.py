

# Generated at 2022-06-20 15:20:45.803874
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    def class_generator(name):
        def init(self, i):
            self.i = i
        cls = type(name, (object,), {'__init__': init, 'i': 0})
        return cls

    class0 = class_generator('class0')
    class1 = class_generator('class1')
    class2 = class_generator('class2')
    class3 = class_generator('class3')
    class4 = class_generator('class4')
    class5 = class_generator('class5')
    class6 = class_generator('class6')
    class7 = class_generator('class7')
    class8 = class_generator('class8')
    class9 = class_generator('class9')
    class10 = class_generator('class10')

# Generated at 2022-06-20 15:20:53.397871
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types
    import inspect

    class Test0(object):
        pass

    class Test1(Test0):
        pass

    class Test2(Test0):
        pass

    class Test3(Test1):
        pass

    class Test4(Test3):
        pass

    class Test5(Test3):
        pass

    class Test6(Test4):
        pass

    class Test7(Test4):
        pass

    # Add a class with no parent
    class TestNoParent(object):
        pass

    # Add a class from a module
    class Test8(types.ModuleType):
        pass

    # Add a class from a namespace
    class Test9(types.Namespace):
        pass

    # Add a class from an object
    class Test10(object):
        pass
    # Set custom __subclasses__ for

# Generated at 2022-06-20 15:20:58.103934
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B,C): pass
    class E(D): pass
    class F(D): pass

    assert set(['B','C','D','E','F']) == set([c.__name__ for c in get_all_subclasses(A)])
    assert set(['E','F']) == set([c.__name__ for c in get_all_subclasses(D)])

# Generated at 2022-06-20 15:21:05.959517
# Unit test for function get_all_subclasses

# Generated at 2022-06-20 15:21:11.585255
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class F(object):
        pass
    class E(F):
        pass
    class D(F):
        pass
    class C(D):
        pass
    class B(D):
        pass
    class A(B, C):
        pass

    assert get_all_subclasses(F) == {A, B, C, D, E}

# Generated at 2022-06-20 15:21:21.133471
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    This code tests the get_all_subclasses function.

    The get_all_subclasses function is a helper function to get all subclasses of
    a class.  It is used to find all modules defined in the collection.

    It is important to test the get_all_subclasses function to make sure that the
    data structure it returns is reliable.  If it does not work properly, the
    collection will not load properly.
    """

    # Define a test class
    class parent():
        """
        Simple test class
        """
        name = "test_get_all_subclasses"

    # Define two subclasses
    class child1(parent):
        """
        Simple test class
        """
        name = "child1"

    class child2(parent):
        """
        Simple test class
        """

# Generated at 2022-06-20 15:21:32.929467
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    assert set(get_all_subclasses(A)) == set([C, D, E, F, G])
    assert set(get_all_subclasses(B)) == set()
    assert set(get_all_subclasses(C)) == set([D, E, F, G])
    assert set(get_all_subclasses(D)) == set([F, G])
    assert set(get_all_subclasses(E)) == set()
    assert set(get_all_subclasses(F)) == set()

# Generated at 2022-06-20 15:21:37.095810
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    expected_subclasses = {B, C, D, E}
    assert get_all_subclasses(A) == expected_subclasses

# Generated at 2022-06-20 15:21:45.852227
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Mock a Class
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    # Test that the function returns all subclasses
    test_set = get_all_subclasses(A)
    assert len(test_set) == 3, 'get_all_subclasses did not return all subclasses (expected 3, got {})'.format(len(test_set))
    assert B in test_set, 'get_all_subclasses did not return the class B'
    assert C in test_set, 'get_all_subclasses did not return the class C'
    assert D in test_set, 'get_all_subclasses did not return the class D'

# Generated at 2022-06-20 15:21:49.755907
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class C1(A):
        pass

    class C2(A):
        pass

    class C3(B):
        pass

    class C4(B):
        pass

    class D1(C1):
        pass

    class D2(C2):
        pass

    class D3(C3):
        pass

    class D4(C4):
        pass

    assert set([D1, D2, D3, D4]) == get_all_subclasses(A) + get_all_subclasses(B)
    assert set([D1, D2]) == get_all_subclasses(A)
    assert set([D3, D4]) == get_all_subclasses(B)

# Generated at 2022-06-20 15:21:59.055030
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class my_first_class(object):
        pass
    class my_second_class(object):
        pass
    class my_child_class(my_first_class):
        pass
    class my_second_child_class(my_second_class):
        pass
    class my_grandchild_class(my_child_class):
        pass
    class my_third_child(my_second_class):
        pass
    class my_third_grandchild_class(my_third_child):
        pass

    assert my_child_class in get_all_subclasses(my_first_class)
    assert my_grandchild_class in get_all_subclasses(my_first_class)
    assert my_second_class not in get_all_subclasses(my_first_class)
    assert my_second_child

# Generated at 2022-06-20 15:22:09.083151
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(D):
        pass

    assert E in get_all_subclasses(A)
    assert E in get_all_subclasses(B)
    assert E in get_all_subclasses(C)
    assert E in get_all_subclasses(D)
    assert E in get_all_subclasses(E)
    assert E in get_all_subclasses(F)

    assert D in get_all_subclasses(A)
    assert D in get_all_subclasses(B)
    assert D in get_all_subclasses(C)
    assert D in get_all_subclasses(D)

# Generated at 2022-06-20 15:22:16.732680
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F:
        pass
    class G(F):
        pass

    assert(get_all_subclasses(A) == set([B, C, D, E]))
    assert(get_all_subclasses(object) == set([A, D, E, B, C, G, F]))

# Generated at 2022-06-20 15:22:26.902962
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)

# Generated at 2022-06-20 15:22:31.893767
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''Unit test for get_all_subclasses function'''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B, C):
        pass

    class F(C, D):
        pass

    result = get_all_subclasses(A)
    assert A in result
    assert B in result
    assert C in result
    assert D in result
    assert E in result
    assert F in result

# Generated at 2022-06-20 15:22:41.207135
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    :returns: Whether get_all_subclass function passes or not all unit tests.
    '''

# Generated at 2022-06-20 15:22:52.082418
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, F])
    assert set(get_all_subclasses(C)) == set([E, F])
    assert set(get_all_subclasses(D)) == set([F])
    assert set(get_all_subclasses(E)) == set([F])
    assert set(get_all_subclasses(F)) == set()

# Generated at 2022-06-20 15:23:00.773195
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    This is a unit test to test the get_all_subclasses function.
    """
    class ParentClass(object):
        pass

    class ChildClass1(ParentClass):
        pass

    class ChildClass2(ParentClass):
        pass

    class SubChildClass1(ChildClass1):
        pass

    class SubChildClass2(ChildClass1):
        pass

    expected_classes = set([ChildClass1, ChildClass2, SubChildClass1, SubChildClass2])
    found_classes = get_all_subclasses(ParentClass)
    assert expected_classes == found_classes

# Generated at 2022-06-20 15:23:04.566161
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    assert get_all_subclasses(B) == {B, D, F}
    assert get_all_subclasses(C) == {C, E}
    assert get_all_subclasses(A) == {A, B, C, D, E, F}
    assert get_all_subclasses(F) == {F}



# Generated at 2022-06-20 15:23:14.766597
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define classes for tests
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(A):
        pass
    class G(F):
        pass
    class H(C):
        pass
    classes = get_all_subclasses(A)
    # Check if all children classes are present in the result
    assert C in classes
    assert D in classes
    assert F in classes
    assert G in classes
    assert H in classes
    # Check if there aren't other classes
    assert E not in classes
    assert B not in classes

# Generated at 2022-06-20 15:23:26.480304
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base(object):
        pass
    class A(Base):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(object):
        pass
    class F(object):
        pass
    class G(F):
        pass
    assert set(get_all_subclasses(Base)) == set([A, B, C, D])
    assert set(get_all_subclasses(E)) == set()
    assert set(get_all_subclasses(G)) == set()


# Generated at 2022-06-20 15:23:32.285079
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(A):
        pass

    class F(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])



# Generated at 2022-06-20 15:23:39.686527
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class obj:
        pass

    class child1(obj):
        pass

    class child2(obj):
        pass

    class child3(child1):
        pass

    assert obj in get_all_subclasses(obj)
    assert child1 in get_all_subclasses(obj)
    assert child3 in get_all_subclasses(obj)
    assert child2 in get_all_subclasses(obj)
    assert not any([cli not in [obj, child1, child2, child3] for cli in get_all_subclasses(obj)])

# Generated at 2022-06-20 15:23:49.784846
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.test import test_utils as utils_test
    from ansible.compat.tests.mock import patch

    with patch.object(utils_test.MyUtilsTest, '__subclasses__',
                      return_value=utils_test.MyUtilsTest.create_subclasses()):
        res = get_all_subclasses(utils_test.MyUtilsTest)

        assert len(res) == 3
        assert utils_test.MyUtilsTestSubclassA in res
        assert utils_test.MyUtilsTestSubclassB in res
        assert utils_test.MyUtilsTestSubclassB2 in res
        assert utils_test.MyUtilsTestSubclassC in res



# Generated at 2022-06-20 15:23:54.665442
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    class F(E):
        pass

    classes = get_all_subclasses(A)
    assert A in classes
    assert B in classes
    assert C in classes
    assert D in classes
    assert E not in classes
    assert F not in classes

# Generated at 2022-06-20 15:24:06.308104
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(object):
        pass

    class G(F):
        pass

    class H(G):
        pass

    # Test a complex class
    assert set([B, C, E]) == get_all_subclasses(A)

    # Test a class with no subclasses
    assert set([]) == get_all_subclasses(F)

    # Test a class with one subclasses
    assert set([G]) == get_all_subclasses(F)

    # Test a class with two levels subclasses
    assert set([B, C]) == get_all_subclasses(A)
    assert set([C, E])

# Generated at 2022-06-20 15:24:10.799189
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(object):
        pass

    assert get_all_subclasses(A) == set((B, C))
    assert get_all_subclasses(B) == set((C))
    assert get_all_subclasses(C) == set(())
    assert get_all_subclasses(D) == set(())

# Generated at 2022-06-20 15:24:20.087249
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    assert get_all_subclasses(A) == set([B, C, D])
    class F(object):
        pass
    class G(F):
        pass
    class H(F):
        pass
    class I(H):
        pass
    class J(I):
        pass
    assert get_all_subclasses(F) == set([G, H, I, J])
    class K(J):
        pass
    assert get_all_subclasses(F) == set([G, H, I, J])

# Generated at 2022-06-20 15:24:29.048952
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(B):
        pass
    A_subclasses = get_all_subclasses(A)
    B_subclasses = get_all_subclasses(B)
    C_subclasses = get_all_subclasses(C)
    D_subclasses = get_all_subclasses(D)
    E_subclasses = get_all_subclasses(E)
    assert set(A_subclasses) == set([B, C, D, E])
    assert set(B_subclasses) == set([C, D, E])
    assert set(C_subclasses) == set([D])
    assert set(D_subclasses) == set([])


# Generated at 2022-06-20 15:24:39.335432
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, E, F])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-20 15:24:58.213946
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(object):
        pass
    class F(E):
        pass

    # check if function returns correct
    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(B) == set([C, D])
    assert get_all_subclasses(A) != set([A])
    assert get_all_subclasses(A) != set([A, F])
    print('Function get_all_subclasses is OK')


# Generated at 2022-06-20 15:25:05.731592
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Testing get_all_subclasses function
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([C, D])
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(object) == set(get_all_subclasses(A))



# Generated at 2022-06-20 15:25:10.170578
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    a_subclasses = get_all_subclasses(A)

    assert B in a_subclasses
    assert C in a_subclasses
    assert A not in a_subclasses

# Generated at 2022-06-20 15:25:16.330141
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F}
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == {D, E, F}
    assert get_all_subclasses(D) == {F}
    assert get_all_subclasses(E) == {F}
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-20 15:25:26.801606
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Simple unittest for function get_all_subclasses
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(B):
        pass
    # Check if C, D, E and F are subclasses of A
    assert set([C, D, E, F]) == get_all_subclasses(A)
    # Check if B, C, D, E and F are subclasses of object
    assert set([B, C, D, E, F]) == get_all_subclasses(object)
    # Check if F is a subclass of object
    assert set([F]) != get_all_subclasses(object)

# Generated at 2022-06-20 15:25:32.452153
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass
    class G(D):
        pass
    class H:
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])
    assert set(get_all_subclasses(B)) == set([D, G])
    assert set(get_all_subclasses(C)) == set([E, F])
    assert set(get_all_subclasses(D)) == set([G])
    assert set(get_all_subclasses(G)) == set([])
    assert set(get_all_subclasses(H)) == set

# Generated at 2022-06-20 15:25:37.224852
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(E):
        pass
    assert(set(get_all_subclasses(A)) == {B, C, D, E, F})

# Generated at 2022-06-20 15:25:40.064442
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C():
        pass
    class D(B):
        pass
    class E(D):
        pass
    result = get_all_subclasses(A)
    assert result == set([type(E()), type(D()), type(B())])
    result = get_all_subclasses(C)
    assert result == set()


# Generated at 2022-06-20 15:25:50.565937
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses()

    :returns: 0 on success, 1 otherwise
    :rtype: integer

    This function creates the following class structure::

      BaseClass
      |-- SubClass1
      |    |-- SubSubClass1
      |    |-- SubSubClass2
      |    `-- SubSubClass3
      |-- SubClass2
      |    |-- SubSubClass4
      |    `-- SubSubClass5
      `-- SubClass3
           `-- SubSubClass6

    It then calls the function `get_all_subclasses(BaseClass)` and compares the results
    with a list of expected results.
    '''

    # Defining the class structure
    class BaseClass():
        pass

    class SubClass1(BaseClass):
        pass


# Generated at 2022-06-20 15:25:54.330293
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class foo:
        pass
    class bar(foo):
        pass
    class baz(foo):
        pass
    class qux(bar):
        pass

    assert set([bar, qux]) == get_all_subclasses(foo)

    del foo
    del bar
    del baz
    del qux

# Generated at 2022-06-20 15:26:20.464436
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(C):
        pass
    class F(A):
        pass
    assert get_all_subclasses(A) == {B, C, D, E, F}
    assert get_all_subclasses(B) == {C, E}
    assert get_all_subclasses(C) == {E}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-20 15:26:30.174045
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This function returns an assert statement, which will fail if the get_all_subclasses
    function is returning an unexpected result.  The function relies on the presence of
    the following classes, which are created dynamically:

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(F):
        pass

    class I(F):
        pass
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass


# Generated at 2022-06-20 15:26:37.740299
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define some test classes
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass

    expected_results = set([B, C, D, E, F, G])
    observed_results = get_all_subclasses(A)
    assert expected_results == observed_results

# Generated at 2022-06-20 15:26:42.234323
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B:
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(C):
        pass
    class F(E):
        pass
    classes = get_all_subclasses(A)
    assert set(classes) == set([C, D, E, F])

# Generated at 2022-06-20 15:26:50.083179
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    class G(D): pass

    # Expected results
    result = {B, C, D, E, F, G}

    # Function to test
    test = get_all_subclasses(A)

    # Check if subclass is found
    assert test == result

    # Check number of element
    assert len(test) == len(result)

# Generated at 2022-06-20 15:26:58.479170
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Here is a simple class hierarchy to test the function
    #
    #   A
    #  / \
    # B   C
    #    / \
    #   D   E
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass

    subclasses = get_all_subclasses(A)
    expected_subclasses = set([B, C, D, E])
    assert subclasses == expected_subclasses

# Generated at 2022-06-20 15:27:08.341230
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E():
        pass

    class F(E):
        pass

    class G(F):
        pass

    class H(G):
        pass

    classes = get_all_subclasses(A)
    assert A in classes
    assert B in classes
    assert C in classes
    assert D in classes
    assert E not in classes
    assert F not in classes
    assert G not in classes
    assert H not in classes
    assert len(classes) == 3, "Some subclasses of A are missing"

    classes = get_all_subclasses(E)
    assert E in classes
    assert F in classes
    assert G in classes
    assert H in classes

# Generated at 2022-06-20 15:27:15.372275
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(F): pass
    class H(F): pass
    class I(G): pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G, H, I}
    assert get_all_subclasses(B) == {D, E}
    assert get_all_subclasses(C) == {F}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == {G, H}
    assert get_all_subclasses(G) == {I}

# Generated at 2022-06-20 15:27:21.957009
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses

    assert A not in subclasses

# Generated at 2022-06-20 15:27:27.670402
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(object):
        pass
    class F(E):
        pass
    class G(F):
        pass

    assert set([B, C, D]) == get_all_subclasses(A)
    assert set([B, D]) == get_all_subclasses(C)
    assert set([G]) == get_all_subclasses(F)
    assert set([]) == get_all_subclasses(E)

# Generated at 2022-06-20 15:28:10.106409
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import namedtuple
    # A is the parent class, B, C and D are subclasses
    A = namedtuple('A', ['id'])
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass

    # Function get_all_subclasses should return a set containing classes B, C and D
    assert (set([B, C, D]) == get_all_subclasses(A))

# Generated at 2022-06-20 15:28:14.974047
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Ensure get_all_subclasses works correctly
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(E):
        pass

    assert get_all_subclasses(A) == set([B,C,D,E,F,G])



# Generated at 2022-06-20 15:28:18.002051
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G}

# Generated at 2022-06-20 15:28:24.841281
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Parent(object):
        pass

    class Child1(Parent):
        pass

    class Child2(Parent):
        pass

    class GrandChild1(Child1):
        pass

    class GrandChild2(Child2):
        pass

    class GrandGrandChild(GrandChild1):
        pass

    assert get_all_subclasses(Parent) == {Child1, Child2, GrandChild1, GrandChild2, GrandGrandChild}

# Generated at 2022-06-20 15:28:35.534439
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(E):
        pass

    # Result is a set, so the order of the elements does not matter
    assert get_all_subclasses(object) == set([A, B, C, D, E, F, G])
    assert get_all_subclasses(A) == set([C, D, E, F, G])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set([E, F, G])
    assert get_all_sub

# Generated at 2022-06-20 15:28:41.535477
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Simple test to check if the get_all_subclasses function
    works as expected
    """
    class A(object):
        """
        Class A
        """
    class B(A):
        """
        Class B, subclass of A
        """
    class C(B):
        """
        Class C, subclass of B
        """
    class D(C):
        """
        Class D, subclass of C
        """
    class E(B):
        """
        Class E, subclass of B
        """
    all_subclasses = get_all_subclasses(A)
    expected_classes = [B, C, D, E]
    assert len(all_subclasses) == len(expected_classes)
    for expected_class in expected_classes:
        assert expected_class in all_subclasses

# Generated at 2022-06-20 15:28:45.904289
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-20 15:28:56.718207
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''Create a test harness to verify get_all_subclasses works correctly
    '''
    class Parent():
        pass

    class ChildA(Parent):
        pass

    class GrandChildA(ChildA):
        pass

    class GrandChildB(ChildA):
        pass

    class ChildB(Parent):
        pass

    class GrandChildC(ChildB):
        pass

    class GrandChildD(ChildB):
        pass

    class GrandChildE(GrandChildD):
        pass

    parent_class = Parent
    expected_count = 7

    # Here is the test harness
    subclasses = get_all_subclasses(parent_class)
    assert len(subclasses) == expected_count, 'Unexpected number of subclasses'
    assert GrandChildA in subclasses
    assert GrandChildB in subclasses
    assert GrandChild

# Generated at 2022-06-20 15:29:01.325696
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(A):
        pass
    class G(F):
        pass
    class H(F):
        pass
    class I(H):
        pass
    # This is a useless class to test a top level class
    class J(object):
        pass
    class K(object):
        pa

# Generated at 2022-06-20 15:29:10.028093
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for the get_all_subclasses function
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(object):
        pass

    class G(F):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(F) == set([G])
    assert get_all_subclasses(object) == set([A, F])