

# Generated at 2022-06-20 15:20:45.405904
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B: pass
    class C: pass
    class D: pass
    class E(A): pass
    class F(A): pass
    class G(E): pass
    class H(F): pass
    class I(F): pass
    class J(E): pass
    class K(H): pass
    class L(H): pass
    class M(J): pass
    class N(J): pass
    class O(K): pass
    class P(L): pass
    class Q(M): pass
    class R(N): pass
    assert get_all_subclasses(A) == set([E, G, H, I, J, K, L, M, N, O, P, Q, R])

# Generated at 2022-06-20 15:20:53.332729
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Unit test for function get_all_subclasses
    """
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    subclasses = get_all_subclasses(A)
    assert(B in subclasses)
    assert(C in subclasses)
    assert(D in subclasses)
    assert(E in subclasses)
    assert(F in subclasses)

# Generated at 2022-06-20 15:20:57.371761
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(D): pass
    class H(D): pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])



# Generated at 2022-06-20 15:21:02.597520
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(object):
        pass
    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E not in subclasses



# Generated at 2022-06-20 15:21:15.186767
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert B in get_all_subclasses(B)
    assert C in get_all_subclasses(B)
    assert D in get_all_subclasses(B)
    assert E in get_all_subclasses(B)
    assert D in get_all_subclasses(C)
    assert E in get_all_subclasses(C)
    assert D in get_all_sub

# Generated at 2022-06-20 15:21:24.908688
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # This is a fake module where 1 is the base class and 3 and 4 are its subclasses
    # 2 is a subclass of 3.
    # 1 <-- 2 <-- 3
    # |
    # +----- 4
    class module3:
        @staticmethod
        def get_deprecated_cli_commands():
            return ['3']

    class module2(module3):
        @staticmethod
        def get_deprecated_cli_commands():
            return ['2']

    class module1(module2):
        @staticmethod
        def get_deprecated_cli_commands():
            return ['1']

    class module4(module1):
        @staticmethod
        def get_deprecated_cli_commands():
            return ['4']


# Generated at 2022-06-20 15:21:34.138494
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    class G(E): pass
    class H(F): pass
    class I(G): pass
    class J(H): pass
    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in subclasses
    assert H in subclasses
    assert I in subclasses
    assert J in subclasses
    assert len(subclasses) == 9

# Generated at 2022-06-20 15:21:43.738882
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(object):
        pass
    class F(A):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(B):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, F, G, H, I])
    assert set(get_all_subclasses(B)) == set([D])
    assert set(get_all_subclasses(C)) == set([])
    assert set(get_all_subclasses(D)) == set([])
    assert set(get_all_subclasses(E)) == set([])

# Generated at 2022-06-20 15:21:52.589997
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Mock a basic class tree and test find_all_subclasses
    '''
    class a(object):
        pass
    class b(a):
        pass
    class c(a):
        pass
    class d(b):
        pass
    class e(b):
        pass
    class f(c):
        pass

    assert list(get_all_subclasses(a)) == [b, c, d, e, f]



# Generated at 2022-06-20 15:21:56.458479
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # For this test we don't need to test in python 2
    # pylint: disable=unused-variable
    class Base(object):
        pass

    class A(Base):
        pass

    class B(Base):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(B):
        pass

    class G(C):
        pass

    class H(C):
        pass
    # pylint: enable=unused-variable

    expected = {A, C, D, G, H, B, E, F}
    observed = get_all_subclasses(Base)
    assert observed == expected

# Generated at 2022-06-20 15:22:08.106682
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import itertools

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D, E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])
    assert set(get_all_subclasses(object)) == set(itertools.chain(*[get_all_subclasses(c) for c in A.__subclasses__()]))

# Generated at 2022-06-20 15:22:18.776216
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(object):
        pass
    class F(D):
        pass
    class G(F):
        pass
    class H(F):
        pass
    subclasses = get_all_subclasses(A)

    assert D in subclasses
    assert B in subclasses
    assert C in subclasses
    assert F in subclasses
    assert G in subclasses
    assert H in subclasses
    assert E not in subclasses
    try:
        assert A in subclasses
    except AssertionError as e:
        print(e)
    else:
        assert False, 'get_all_subclasses should not return the class itself'

# Generated at 2022-06-20 15:22:22.423423
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class X:
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([C])
    assert get_all_subclasses(X) == set()

# Generated at 2022-06-20 15:22:31.458897
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        """
        Base class
        """
        def __init__(self):
            pass

    class B(A):
        """
        Sub class B of A
        """
        def __init__(self):
            pass

    class C(A):
        """
        Sub class C of A
        """
        def __init__(self):
            pass

    class D(B):
        """
        Sub class D of B
        """
        def __init__(self):
            pass

    class F(D):
        """
        Sub class F of D
        """
        def __init__(self):
            pass

    class E(F):
        """
        Sub class E of F
        """
        def __init__(self):
            pass


# Generated at 2022-06-20 15:22:38.601285
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(B):
        pass
    class G(C):
        pass
    class H(D):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])
    try:
        get_all_subclasses(1)
    except TypeError:
        pass
    else:
        raise AssertionError('invalid type is not detected')

# Generated at 2022-06-20 15:22:42.132678
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(object): pass
    class D(B, C): pass
    class E(B, C): pass
    assert get_all_subclasses(A) == {B, D, E}

# Generated at 2022-06-20 15:22:48.292400
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Parent(object):
        pass

    class Child1(Parent):
        pass

    class Child2(Parent):
        pass

    class Child3(Child2):
        pass

    assert len(list(get_all_subclasses(Parent))) == 3


# Generated at 2022-06-20 15:22:59.796699
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(C): pass
    class E(A): pass
    class F(E): pass
    class G(D): pass
    class H(D): pass
    class I(D): pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I])
    assert get_all_subclasses(B) == set([C, D, G, H, I])
    assert get_all_subclasses(C) == set([D, G, H, I])
    assert get_all_subclasses(D) == set([G, H, I])
    assert get_all_subclasses(E) == set([F])

# Generated at 2022-06-20 15:23:08.385671
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function get_all_subclasses()
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(F):
        pass
    assert len(get_all_subclasses(A)) == 6
    assert len(get_all_subclasses(B)) == 0
    assert len(get_all_subclasses(C)) == 1
    assert len(get_all_subclasses(D)) == 1
    assert len(get_all_subclasses(E)) == 1
    assert len(get_all_subclasses(F)) == 1

# Generated at 2022-06-20 15:23:19.204940
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        def __init__(self):
            pass

    class B1(A):
        def __init__(self):
            pass

    class B2(A):
        def __init__(self):
            pass

    class C1(B1):
        def __init__(self):
            pass

    class C2(B2):
        def __init__(self):
            pass

    class C3(B1):
        def __init__(self):
            pass


    class ClassTests(unittest.TestCase):
        def test_get_all_subclasses(self):
            self.assertEqual(set(get_all_subclasses(A)), {B1, B2, C1, C2, C3})


# Generated at 2022-06-20 15:23:26.772075
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    assert get_all_subclasses(str) == {str, bytes}
    assert get_all_subclasses(bytes) == {bytes}

# Generated at 2022-06-20 15:23:36.235117
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(object):
        pass

    class F(E):
        pass

    a_subclasses_ref = frozenset(set([F, D]))
    assert get_all_subclasses(A) == a_subclasses_ref
    assert get_all_subclasses(B) == a_subclasses_ref
    assert get_all_subclasses(C) == a_subclasses_ref
    assert get_all_subclasses(D) == a_subclasses_ref
    assert get_all_subclasses(E) == frozenset([F])
    assert get_all_subclasses(F) == frozenset([])

# Generated at 2022-06-20 15:23:39.365564
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    assert(set(get_all_subclasses(A)) == set([B, C, D]))

# Generated at 2022-06-20 15:23:45.416353
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    all_subclasses = get_all_subclasses(A)
    assert B in all_subclasses
    assert C in all_subclasses
    assert D in all_subclasses
    assert len(all_subclasses) == 3
    assert len(get_all_subclasses(object)) == 0


# Generated at 2022-06-20 15:23:51.026140
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(D):
        pass

    classes = {A, B, C, D, E}
    assert get_all_subclasses(A) == classes

    classes.add(F)
    assert get_all_subclasses(A) == classes

# Generated at 2022-06-20 15:23:54.854373
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C(object): pass
    class D(C): pass
    class E(C): pass
    class F(D): pass
    class G(D): pass
    class H(E): pass
    assert get_all_subclasses(C) == set([D, E, F, G, H]), "Error while retrieving all subclasses"

# Generated at 2022-06-20 15:24:00.736421
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(object):
        pass

    klasses = get_all_subclasses(A)
    # classes A and B should be ignored
    assert C in klasses
    assert D in klasses
    assert E not in klasses

# Generated at 2022-06-20 15:24:08.954909
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(D):
        pass

    subclasses = get_all_subclasses(A)
    assert len(subclasses) == len({B, C, D, E, F, G, H})



# Generated at 2022-06-20 15:24:16.926975
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Check get_all_subclasses() with two levels of inheritance
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    # test
    result = get_all_subclasses(A)
    assert result == {B, C, D, E}, 'test_get_all_subclasses() returned {} instead of {}, failed'.format(result, {B, C, D, E})

# Generated at 2022-06-20 15:24:22.962353
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B1(A):
        pass
    class B2(A):
        pass
    class C1(B1):
        pass
    class D1(B2):
        pass
    class D2(B2):
        pass
    class E1(D1):
        pass
    class E2(D1):
        pass
    class E3(D1):
        pass

    assert get_all_subclasses(A) == {B1, B2, C1, D1, D2, E1, E2, E3}

    class A1(object):
        pass
    class A2(object):
        pass
    class B(A1, A2):
        pass
    class C(A1):
        pass

# Generated at 2022-06-20 15:24:39.335080
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(B)) == set([D, E])

# Generated at 2022-06-20 15:24:46.554229
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        foo = 5
    class B(A):
        bar = 3
    class C(A):
        baz = 4
    class D(B):
        quux = 1
    class E(D):
        qux = 0
    assert E in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert E in get_all_subclasses(B)
    assert D in get_all_subclasses(B)
    assert E not in get_all_subclasses(C)

# Generated at 2022-06-20 15:24:57.322341
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class TestA(object):
        pass

    class TestB(TestA):
        pass

    class TestC(TestB):
        pass

    class TestD(TestB):
        pass

    class TestE(TestD):
        pass

    class TestF(TestE):
        pass

    assert get_all_subclasses(TestA) == {TestB, TestC, TestD, TestE, TestF}
    assert get_all_subclasses(TestB) == {TestC, TestD, TestE, TestF}
    assert get_all_subclasses(TestC) == set()
    assert get_all_subclasses(TestD) == {TestE, TestF}
    assert get_all_subclasses(TestE) == {TestF}
    assert get_all_subclasses(TestF) == set()

# Generated at 2022-06-20 15:25:02.886321
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(A): pass
    class E(B): pass
    class F(D): pass
    class G(D): pass

    assert set(get_all_subclasses(A)) == set([C,D,F,G])
    assert set(get_all_subclasses(B)) == set([E])

# Generated at 2022-06-20 15:25:12.397946
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Used as a simple unit test for the get_all_subclasses function, to make sure it returns
    the right classes

    :rtype: None
    :returns: Nothing
    '''

    # Dummy classes
    class A(object):
        ''' A class for the get_all_subclasses test '''
    class B(A):
        ''' A class for the get_all_subclasses test '''
    class C(A):
        ''' A class for the get_all_subclasses test '''
    class D(A):
        ''' A class for the get_all_subclasses test '''
    class E(B):
        ''' A class for the get_all_subclasses test '''
    class F(B):
        ''' A class for the get_all_subclasses test '''

# Generated at 2022-06-20 15:25:20.998473
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Setup test classes
    class Human(object):
        pass

    class Male(Human):
        pass

    class Female(Human):
        pass

    class MaleChild(Male):
        pass

    class FemaleChild(Female):
        pass

    class MaleGrandChild(MaleChild):
        pass

    class FemaleGrandChild(FemaleChild):
        pass

    # Run test
    lst = get_all_subclasses(Human)
    assert Male in lst
    assert Female in lst
    assert MaleChild in lst
    assert FemaleChild in lst
    assert MaleGrandChild in lst
    assert FemaleGrandChild in lst

# Generated at 2022-06-20 15:25:26.396508
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(D): pass
    # Should work with classic classes
    assert get_all_subclasses(A) == set([B, C, D, E])
    # Should work with new style classes
    assert get_all_subclasses(object) == set([type, A, B, C, D, E])



# Generated at 2022-06-20 15:25:32.262412
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function get_all_subclasses

    The following is a testable example of a class hierarchy:

        object
            |
        class A(object)
            |
            |--class B(A)
            |
            |--class C(A)
                |
                |--class D(C)
                |
                |--class E(C)
    '''
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(C): pass
    test_classes = [A, B, C, D, E]
    assert get_all_subclasses(A) == set(test_classes)
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D, E])


# Generated at 2022-06-20 15:25:42.941778
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class_A = type('class_A', (object,), {})
    class_B = type('class_B', (class_A,), {})
    class_C = type('class_C', (class_A,), {})
    class_D = type('class_D', (class_C,), {})
    class_E = type('class_E', (class_C,), {})
    class_F = type('class_F', (class_C,), {})
    class_G = type('class_G', (class_C,), {})
    class_H = type('class_H', (class_G,), {})
    class_I = type('class_I', (class_G,), {})
    class_J = type('class_J', (class_C,), {})
   

# Generated at 2022-06-20 15:25:48.569372
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Dog(object):
        pass

    class Wolf(Dog):
        pass

    class Fox(Dog):
        pass

    class Deer(object):
        pass

    class Elk(Deer):
        pass

    class Moose(Elk):
        pass

    assert get_all_subclasses(Dog) == {Wolf, Fox}
    assert get_all_subclasses(Deer) == {Elk, Moose}

# Generated at 2022-06-20 15:26:21.681012
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from units.compat.mock import patch, MagicMock
    from ansible.plugins.loader import module_loader

    class C1(object):
        pass

    class C2(C1):
        pass

    class C3(C2):
        pass

    class C4(C2):
        pass

    class C5(C4):
        pass

    class C6(C1):
        pass

    class C7(C6):
        pass

    class C8(C7):
        pass

    class C9(C8):
        pass

    class C10(C8):
        pass

    # Mock module loader to be able to use the get_all_subclasses() function

# Generated at 2022-06-20 15:26:26.472195
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass

    assert(set([B, D, E, C]) == get_all_subclasses(A))


# Generated at 2022-06-20 15:26:30.471603
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base(object):
        pass

    class A(Base):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(E):
        pass

    assert get_all_subclasses(Base) == set([A, B, C, D, E, F])

# Generated at 2022-06-20 15:26:37.613792
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import ansible.module_utils.facts.system.distribution
    im_subclasses = get_all_subclasses(ansible.module_utils.facts.system.distribution.Distribution)
    # There are 8 subclasses of Distribution and 8 subclasses of DistributionSubclass
    # expected = 16
    expected = 1
    assert len(im_subclasses) == expected, 'There should be %i, but there are %i' % (expected, len(im_subclasses))

# Generated at 2022-06-20 15:26:42.393703
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(object):
        pass

    class E(B, C):
        pass

    assert get_all_subclasses(A) == set([B, C, E])
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-20 15:26:48.071328
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Parent(object):
        pass
    class Child1(Parent):
        pass
    class Child2(Parent):
        pass
    class Grandchild(Child2):
        pass
    result = get_all_subclasses(Parent)
    assert Parent in result
    assert Child1 in result
    assert Child2 in result
    assert Grandchild in result

# Generated at 2022-06-20 15:26:57.910302
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class DummyParent(object):
        pass
    class DummyChild1(DummyParent):
        pass
    class DummyChild2(DummyParent):
        pass
    class DummyChild3(DummyChild1):
        pass
    class DummyChild4(DummyParent):
        pass
    class DummyChild5(DummyChild2):
        pass
    class DummyChild6(DummyChild3):
        pass
    class DummyChild7(DummyChild4):
        pass

    assert set([DummyChild1, DummyChild2, DummyChild3, DummyChild4, DummyChild5, DummyChild6, DummyChild7]) == get_all_subclasses(DummyParent)

# Generated at 2022-06-20 15:27:07.572538
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a fake class hierarchy
    class Base(object): pass
    class A(Base): pass
    class B(Base): pass
    class AA(A): pass
    class AB(A): pass
    class AC(A): pass
    class AAA(AA): pass
    class ABA(AB): pass
    class ABB(AB): pass
    class ABC(AB): pass

    # Create an iterable of class bases
    iterable = set()
    for subclass in get_all_subclasses(Base):
        iterable.add(subclass)
    # Create reference of all classes from base to subclass
    ref = set((A, AA, AAA, AB, ABA, ABB, ABC, B, Base))
    assert iterable == ref

# Generated at 2022-06-20 15:27:10.902014
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
       pass

    class B(A):
       pass

    class C(B):
       pass

    class D(B):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-20 15:27:14.216471
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B,C):
        pass

    class E(B,C):
        pass

    class F(D,E):
        pass

    assert set(get_all_subclasses(A)) == set([A,B,C,D,E,F])

# Generated at 2022-06-20 15:28:06.931038
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function get_all_subclasses
    '''
    # Test classes
    class TestBase(): pass
    class Test1(TestBase): pass
    class Test2(TestBase): pass
    class Test11(Test1): pass
    class Test111(Test11): pass
    class Test112(Test11): pass
    class Test21(Test2): pass

    # Run tes
    ret = get_all_subclasses(TestBase)
    assert ret == set([Test1, Test2, Test11, Test111, Test112, Test21])

# Generated at 2022-06-20 15:28:15.604861
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Sample class definition
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(E):
        pass

    # Get all subclasses of A
    cls_a_subclasses = get_all_subclasses(A)

    # If the function is correct,
    # The expected result is {B, C, D, E, F}
    assert len(cls_a_subclasses) == 5
    assert B in cls_a_subclasses
    assert C in cls_a_subclasses
    assert D in cls_a_subclasses
    assert E in cls_a_subclasses
    assert F in cls_a_subclasses

# Generated at 2022-06-20 15:28:20.055204
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):   pass
    class B(A):    pass
    class C(B):    pass
    class D(A):    pass
    class E(D):    pass
    class F(E):    pass

    assert get_all_subclasses(A) == {B,C,D,E,F}

# Generated at 2022-06-20 15:28:28.137292
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class ClassA(object): pass
    class ClassB(object): pass
    class ClassC(ClassB): pass
    class ClassD(ClassB): pass
    class ClassE(ClassD): pass
    assert ClassA in get_all_subclasses(object)
    assert ClassB in get_all_subclasses(object)
    assert ClassC in get_all_subclasses(object)
    assert ClassD in get_all_subclasses(object)
    assert ClassE in get_all_subclasses(object)
    assert ClassA in get_all_subclasses(ClassA)
    assert ClassB in get_all_subclasses(ClassA)
    assert ClassC in get_all_subclasses(ClassA)
    assert ClassD in get_all_subclasses(ClassA)

# Generated at 2022-06-20 15:28:35.839456
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):  # noqa - F811
        pass

    class C(A):  # noqa - F811
        pass

    class D(C):  # noqa - F811
        pass

    class E(object):  # noqa - F811
        pass

    assert get_all_subclasses(A) == set([B, C])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-20 15:28:47.955441
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Iterable
    from collections import Iterator
    from collections import Sized
    from collections import Container
    from collections import Callable

    assert isinstance(get_all_subclasses(Iterable), set)
    assert isinstance(get_all_subclasses(Iterator), set)
    assert isinstance(get_all_subclasses(Sized), set)
    assert isinstance(get_all_subclasses(Container), set)
    assert isinstance(get_all_subclasses(Callable), set)

    assert Iterator in get_all_subclasses(Iterable)
    assert Sized in get_all_subclasses(Iterable)
    assert Container in get_all_subclasses(Iterable)

    assert Sized in get_all_subclasses(Iterator)
    assert Container in get_all_subclasses(Iterator)

   

# Generated at 2022-06-20 15:28:58.377017
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(E):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, E, F])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set([E, F])
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set()
    assert get_all_subclasses(int) == set()



# Generated at 2022-06-20 15:29:01.900723
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B,C):
        pass

    assert get_all_subclasses(A) == {B, C, D}
    assert get_all_subclasses(B) == {D}
    assert get_all_subclasses(C) == {D}
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-20 15:29:11.666315
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function used to verify that get_all_subclasses works as expected

    Test definition:
    Create a class A and 3 subclasses B, C and D of class A. Ensure that get_all_subclasses
    return a set containing all the classes.

    '''
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert len(get_all_subclasses(A)) == 4

# Generated at 2022-06-20 15:29:20.073266
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(E):
        pass

    subclasses = get_all_subclasses(A)
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses

    subclasses = get_all_subclasses(B)
    assert len(subclasses) == 0

