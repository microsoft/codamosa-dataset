

# Generated at 2022-06-20 15:20:45.823268
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test for the function get_all_subclasses
    '''
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, F])
    assert set(get_all_subclasses(C)) == set([E])
    assert set(get_all_subclasses(D)) == set([F])
    assert set(get_all_subclasses(E)) == set([])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-20 15:20:48.300333
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    assert A in get_all_subclasses(B)
    assert B in get_all_subclasses(A)


# Generated at 2022-06-20 15:20:51.631396
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    assert list(A.__subclasses__()) == [B, C]
    assert list(get_all_subclasses(A)) == [B, C, D]

# Generated at 2022-06-20 15:20:58.736345
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a class for the sole purpose of testing get_all_subclasses
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    classes = [A, B, C, D, E, F]
    assert set(get_all_subclasses(A)) == set(classes)

    class G(F):
        pass

    classes.append(G)
    assert set(get_all_subclasses(A)) == set(classes)

# Generated at 2022-06-20 15:21:02.862895
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(object):
        pass

    class D(C):
        pass

    assert set(get_all_subclasses(A)) == {B}
    assert set(get_all_subclasses(C)) == {D}
    assert set(get_all_subclasses(D)) == set()

# Generated at 2022-06-20 15:21:12.212258
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert set([A, B, C]) == set(A.__subclasses__())
    assert set([B, D]) == set(B.__subclasses__())
    assert set([C]) == set(C.__subclasses__())
    assert set([D]) == set(D.__subclasses__())
    assert set([A, B, C, D]) == get_all_subclasses(A)

# Generated at 2022-06-20 15:21:23.124432
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(object) == set()

# Generated at 2022-06-20 15:21:33.748554
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B:
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(C):
        pass
    class F(B):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(B):
        pass
    classes = [A,B,C,D,E,F,G,H,I]
    assert set(get_all_subclasses(A)) == set(classes[2:])
    assert set(get_all_subclasses(B)) == set(classes[5:])
    assert set(get_all_subclasses(C)) == set(classes[4:])
    assert set(get_all_subclasses(D)) == set()

# Generated at 2022-06-20 15:21:41.054466
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test get_all_subclasses function
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(object):
        pass

    class F(E):
        pass

    class G(D):
        pass

    class H(D):
        pass


# Generated at 2022-06-20 15:21:44.795041
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(D):
        pass

    subclasses = get_all_subclasses(A)
    assert [B, C, D, E, F] == [cls for cls in subclasses]

# Generated at 2022-06-20 15:21:52.456121
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(object): pass

    assert set([B, C, D]) == get_all_subclasses(A)
    assert set([]) == get_all_subclasses(E)

# Generated at 2022-06-20 15:21:59.054695
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    a = A()
    b = B()
    c = C()
    d = D()
    e = E()

    assert(set(get_all_subclasses(A)) == set([B, C, D, E]))
    assert(set(get_all_subclasses(B)) == set([D]))
    assert(set(get_all_subclasses(C)) == set([E]))
    assert(set(get_all_subclasses(D)) == set([]))
    assert(set(get_all_subclasses(E)) == set([]))

# Generated at 2022-06-20 15:22:03.469310
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    assert get_all_subclasses(A) == set([B, C])

# Generated at 2022-06-20 15:22:17.075262
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    global A, B, C, D, E, F, X
    class A():
        def __init__(self):
            pass
    class B(A):
        def __init__(self):
            pass
    class C(A):
        def __init__(self):
            pass
    class D(B):
        def __init__(self):
            pass
    class E(B):
        def __init__(self):
            pass
    class F(B):
        def __init__(self):
            pass
    class X():
        def __init__(self):
            pass
    all_subclasses = get_all_subclasses(A)
    assert all_subclasses == set([B, C, D, E, F])

test_get_all_subclasses()

# Generated at 2022-06-20 15:22:21.690727
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set([F])

# Generated at 2022-06-20 15:22:28.336689
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestClassA(object):
        pass

    class TestClassB(TestClassA):
        pass

    class TestClassC(object):
        pass

    class TestClassD(TestClassB):
        pass

    # Test simple example
    assert TestClassB in get_all_subclasses(TestClassA)
    assert TestClassD in get_all_subclasses(TestClassA)

    # Test that other classes are not found
    assert TestClassD not in get_all_subclasses(TestClassC)


# Generated at 2022-06-20 15:22:39.603763
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C, D): pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set([E])
    assert set(get_all_subclasses(D)) == set([E])
    assert set(get_all_subclasses(E)) == set([])

    class F(object): pass
    class G(object): pass
    assert set(get_all_subclasses(F)) == set([])
    assert set(get_all_subclasses(G)) == set([])



# Generated at 2022-06-20 15:22:50.873439
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F(C):
        pass
    class G(D):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(G):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(K):
        pass
    class O(L):
        pass

    input_test_class = A
    expected_subclasses = [M, N, O]
    subclasses_result = get_all_subclasses(input_test_class)
    # Test that classes found are correct

# Generated at 2022-06-20 15:22:58.491353
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set([])
    assert set(get_all_subclasses(D)) == set([E])

# Generated at 2022-06-20 15:23:03.485672
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    subclass = get_all_subclasses(A)
    assert B in subclass and C in subclass and D in subclass and E in subclass, "get_all_subclasses error"

# Generated at 2022-06-20 15:23:20.118731
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test class definition
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F(C):
        pass
    class G(B,F):
        pass
    # Compute class_list and subclasses_list
    class_list = [A,B,C,D,E,F,G]
    subclasses_list = [set([B,C,G]), set([C,G]), set([D,E,F,G]), set([E]), set(), set([G]), set([])]
    for cls, subclasses in zip(class_list, subclasses_list):
        assert subclasses == get_all_subclasses(cls)

# Generated at 2022-06-20 15:23:29.606541
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test for function get_all_subclasses.

    This test will create a tree class for test purpose.
    '''

    class Test(object):
        pass

    class TestSubclass(Test):
        pass

    class TestSubsubclass(TestSubclass):
        pass

    class TestSubsubsubclass(TestSubsubclass):
        pass

    class AnotherTestSubsubsubclass(TestSubsubclass):
        pass

    subclasses = get_all_subclasses(Test)

    # Check that all the expected classes are in the subclasses set
    assert TestSubclass in subclasses
    assert TestSubsubclass in subclasses
    assert TestSubsubsubclass in subclasses
    assert AnotherTestSubsubsubclass in subclasses

    # Check that the parent class is not in the subclasses set
    assert Test not in subclasses



# Generated at 2022-06-20 15:23:33.172675
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)

# Generated at 2022-06-20 15:23:42.623123
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(A):
        pass
    class F(A):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(H):
        pass
    class L(A):
        pass
    class M(I):
        pass
    class N(I):
        pass
    class O(J):
        pass
    class P(K):
        pass
    class Q(K):
        pass
    class R(L):
        pass
    class S(L):
        pass
    # The result should be the same

# Generated at 2022-06-20 15:23:45.938639
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import ansible.plugins.loader
    subclass_count = len(get_all_subclasses(ansible.plugins.loader.ModuleLoader))
    assert subclass_count == 3, "get_all_subclasses did not return all subclasses"


# Generated at 2022-06-20 15:23:55.113683
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import os
    import sys
    import types

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    # create a temporary importable module using dummy classes
    fd = None
    fd, fn = tempfile.mkstemp()
    module_name = 'ansible_module_utils_dummy_class'

# Generated at 2022-06-20 15:24:06.392081
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest2

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(object):
        pass

    class G(F):
        pass

    class H(G):
        pass

    class TestGetAllSubclasses(unittest2.TestCase):
        def test_no_subclasses(self):
            self.assertEqual(get_all_subclasses(A), set([B, C, D, E]))
            self.assertEqual(get_all_subclasses(F), set([G, H]))

    if __name__ == '__main__':
        unittest2.main()

# Generated at 2022-06-20 15:24:14.940776
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class BaseClass(object):
        pass
    class InheritFromBaseClass(BaseClass):
        pass
    class DoubleInheritance(InheritFromBaseClass):
        pass
    # Test BaseClass doesn't have subclasses
    assert not get_all_subclasses(BaseClass)
    # Test InheritFromBaseClass has one subclasses
    assert tuple(get_all_subclasses(InheritFromBaseClass)) == (DoubleInheritance,)

# Generated at 2022-06-20 15:24:19.970053
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([])
    assert get_all_subclasses(D) == set([])

# Generated at 2022-06-20 15:24:28.929833
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for the get_all_subclasses function.

    '''
    class A:
        pass

    class B:
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(B):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(E):
        pass

    class J(F):
        pass

    class K(E):
        pass

    all_subclasses = get_all_subclasses(A)
    assert set([C, D, G, H]) == all_subclasses

    all_subclasses = get_all_subclasses(B)
    assert set([E, F, I, J, K]) == all_subclasses

   

# Generated at 2022-06-20 15:24:40.654986
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(object):
        pass
    subclasses = get_all_subclasses(A)
    assert(B in subclasses)
    assert(C in subclasses)
    assert(D in subclasses)
    assert(E not in subclasses)

# Generated at 2022-06-20 15:24:45.653362
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(F):
        pass

    classes = get_all_subclasses(A)
    assert len(classes) == 7
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert G in classes

# Generated at 2022-06-20 15:24:52.272052
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses

# Generated at 2022-06-20 15:24:56.664329
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}

# Generated at 2022-06-20 15:25:02.874401
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Define classes
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass

    assert set([B, C, D]) == get_all_subclasses(A)
    assert set([C]) == get_all_subclasses(B)
    assert set([]) == get_all_subclasses(C)
    assert set([]) == get_all_subclasses(D)

# Generated at 2022-06-20 15:25:06.712008
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(C): pass

    assert get_all_subclasses(A) == {B, C, D, E, F}

# Generated at 2022-06-20 15:25:13.786699
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    A function to test if get_all_subclasses works
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(object):
        pass

    class H(G):
        pass

    class I(G):
        pass

    class J(F,I):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, J])

# Generated at 2022-06-20 15:25:19.838906
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    # Testing
    all_subclasses = get_all_subclasses(A)
    assert B in all_subclasses
    assert C in all_subclasses
    assert D in all_subclasses
    assert len(all_subclasses) == 3

# Generated at 2022-06-20 15:25:26.004690
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D):
        pass

    assert E in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert len(get_all_subclasses(A)) == 4

# Generated at 2022-06-20 15:25:31.394381
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # GIVEN a set of classes
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    # WHEN retrieving all direct subclasses of class A
    subclasses = get_all_subclasses(A)
    # THEN get all subclasses which are B, C, D, E
    assert subclasses == set([B, C, D, E])
    # WHEN retrieving all direct subclasses of class B
    subclasses = get_all_subclasses(B)
    # THEN get all subclasses which are D.
    assert subclasses == set([D])

# Generated at 2022-06-20 15:25:50.671097
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(object):
        pass
    # Create set of expected classes from get_all_subclasses(A)
    ref_subclasses = set([B, C, D, E, F])
    subclasses = get_all_subclasses(A)
    assert ref_subclasses == subclasses

# Generated at 2022-06-20 15:26:02.361552
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.utils.yaml_loader import AnsibleLoader
    from ansible.plugins.loader import find_plugin
    import os

    current_dir = os.path.dirname(__file__)

    ansible_dir = os.path.abspath(os.path.join(current_dir, '..', '..', '..', 'lib', 'ansible'))

    def _init_plugins(type):
        plugins = {}
        source = os.path.join(ansible_dir, 'plugins', type)
        if os.path.isdir(source):
            for plugin_file in os.listdir(source):
                if plugin_file.startswith('_') or plugin_file.startswith('.') or not plugin_file.endswith('.py'):
                    continue

# Generated at 2022-06-20 15:26:07.803568
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(D) == set([E])
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-20 15:26:16.315480
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(B,D):
        pass
    assert E in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert A not in get_all_subclasses(A)

# Generated at 2022-06-20 15:26:27.068065
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit tests for the get_all_subclasses function
    '''
    module_test = [
        'ansible.plugins.action.ActionModule',
    ]

    for cls in module_test:
        importlib.import_module(cls)

    # from ansible.plugins.action.ActionModule import ActionModule
    from ansible.plugins import action as action
    action_module = action.ActionModule

    # Retrieve direct subclasses
    subclasses = set(action_module.__subclasses__())
    to_visit = list(subclasses)
    # Then visit all subclasses
    while to_visit:
        for sc in to_visit:
            # The current class is now visited, so remove it from list
            to_visit.remove(sc)
            # Appending all subclasses to

# Generated at 2022-06-20 15:26:31.690428
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(E):
        pass

    # This array includes all expected classes
    expected = [C, D, E, F]
    result = get_all_subclasses(A)
    # If a class is expected, it has to be included in result
    assert(0 == len([x for x in expected if x not in result]))

# Generated at 2022-06-20 15:26:37.132684
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Simple test for get_all_subclasses function
    """
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    assert set(B, C, D) == get_all_subclasses(A)
    assert set() == get_all_subclasses(D)

# Generated at 2022-06-20 15:26:41.586060
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test get_all_subclasses function.

    Usage:

    class Foo():
        pass
    class Bar(Foo):
        pass
    class Baz(Bar):
        pass

    assert set([Bar, Baz]) == get_all_subclasses(Foo)
    """
    pass

# Generated at 2022-06-20 15:26:49.775633
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(A):
        pass

    assert (get_all_subclasses(A) == {B, C, D, E})
    assert (get_all_subclasses(B) == set())
    assert (get_all_subclasses(C) == {D})
    assert (get_all_subclasses(D) == set())
    assert (get_all_subclasses(E) == set())



# Generated at 2022-06-20 15:27:00.527281
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass

    class E(object):
        pass
    class F(E):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E not in get_all_subclasses(A)
    assert F not in get_all_subclasses(A)

    assert A in get_all_subclasses(B)
    assert B in get_all_subclasses(B)
    assert C in get_all_subclasses(B)

# Generated at 2022-06-20 15:27:37.139945
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(B, C):
        pass
    class F(D, E):
        pass
    class G(object):
        pass
    class H(B, G):
        pass
    class I(B, G):
        pass
    class J(H, I):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, H, I, J])
    assert get_all_subclasses(B) == set([D, E, F, H, I, J])
    assert get_all_subclasses(E) == set([F])

# Generated at 2022-06-20 15:27:45.762725
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(object):
        pass

    class H(G):
        pass

    # B --> A
    # C --> A
    # D --> C
    # E --> C
    # F --> D
    # G --> object
    # H --> G

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([])
    assert set(get_all_subclasses(C)) == set([D, E, F])

# Generated at 2022-06-20 15:27:52.155339
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import re

    class A(object):
        def __init__(self, *args, **kwargs): pass

    class B(A):
        def __init__(self, *args, **kwargs): pass

    class C(A):
        def __init__(self, *args, **kwargs): pass

    class D(C):
        def __init__(self, *args, **kwargs): pass

    class E(B):
        def __init__(self, *args, **kwargs): pass

    class F(C):
        def __init__(self, *args, **kwargs): pass

    class G(C):
        def __init__(self, *args, **kwargs): pass

    class H(C):
        def __init__(self, *args, **kwargs): pass


# Generated at 2022-06-20 15:27:56.414579
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    assert get_all_subclasses(A) == set([B, C, D])

# Generated at 2022-06-20 15:28:01.291416
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F])

# Generated at 2022-06-20 15:28:11.383020
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a class unique to this test
    class A(object):
        pass

    # Create subclasses of A to test
    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(D):
        pass

    class G(D):
        pass

    # Test presence of expected results
    a_classes = get_all_subclasses(A)
    assert (B in a_classes)
    assert (C in a_classes)
    assert (D in a_classes)
    assert (E in a_classes)
    assert (F in a_classes)
    assert (G in a_classes)
    # Test absence of expected results
    b_classes = get_all_subclasses(B)

# Generated at 2022-06-20 15:28:17.639465
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a class hierarchy
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(object):
        pass
    # Test the function
    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([])
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(object) == set([A, E, B, C, D])

# Generated at 2022-06-20 15:28:25.852910
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class BaseClass(object):
        pass

    class ParentClass(BaseClass):
        pass

    class ParentClass2(BaseClass):
        pass

    class ChildClass(ParentClass):
        pass

    class ChildClass2(ParentClass):
        pass

    class ChildClass3(ParentClass2):
        pass

    class ChildClass4(ParentClass2):
        pass

    class GrandChildClass(ChildClass):
        pass

    assert set(get_all_subclasses(BaseClass)) == set([ParentClass, ParentClass2, ChildClass, ChildClass2, ChildClass3, ChildClass4, GrandChildClass])

# Generated at 2022-06-20 15:28:35.611615
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base0(object):
        pass

    class Base1(Base0):
        pass

    class Base2(Base1):
        pass

    class OtherBase0(object):
        pass

    # noinspection PyTypeChecker
    assert set(get_all_subclasses(object)) == set(x for x in globals().values() if isinstance(x, type) and issubclass(x, object))
    assert set(get_all_subclasses(Base0)) == {Base1, Base2}
    assert set(get_all_subclasses(Base1)) == {Base2}
    assert set(get_all_subclasses(Base2)) == set()
    assert set(get_all_subclasses(OtherBase0)) == set()


# import module snippets

# Generated at 2022-06-20 15:28:39.985130
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-20 15:29:50.202488
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])

# Generated at 2022-06-20 15:29:56.381324
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B:
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    # class F:
    #     pass

    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 3
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    # assert F not in subclasses



# Generated at 2022-06-20 15:30:05.012763
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(B):
        pass

    class H(G):
        pass

    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 7
    assert set(subclasses) == set((B, C, D, E, F, G, H))

    # Quick test of subclasses ordering
    classes = [B, C, D, E, F, G, H]
    for cls in classes:
        assert cls in subclasses

# Generated at 2022-06-20 15:30:08.106389
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(B): pass
    class E(A): pass
    class F(C): pass

    classes = set(get_all_subclasses(A))
    assert classes == set([B,C,D,F,E])

# Generated at 2022-06-20 15:30:19.258451
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(C, D): # Reuses the same subclasses
        pass

    class G(object):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, E, F])
    assert set(get_all_subclasses(C)) == set([F])
    assert set(get_all_subclasses(D)) == set([E, F])
    assert set(get_all_subclasses(E)) == set([])

# Generated at 2022-06-20 15:30:27.045501
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Defining classes to use
    class A:
        pass
    class B:
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(E):
        pass

    # Searching subclasses of A
    subclasses = get_all_subclasses(A)
    assert C in subclasses, 'Class C is a subclass of A but is not in the list of A\'s subclasses!'
    assert D in subclasses, 'Class D is a subclass of A but is not in the list of A\'s subclasses!'
    assert B not in subclasses, 'Class B is not a subclass of A but is in the list of A\'s subclasses!'

# Generated at 2022-06-20 15:30:36.170988
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A:
        pass
    class B:
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(B):
        pass
    class F(C, B):
        pass
    class G(F):
        pass
    class H(G, D):
        pass
    class I(D, E):
        pass

    class L:
        pass

    class T(H, I, L):
        pass

    assert get_all_subclasses(A) == {C, D, F, G, H, I, T}
    assert get_all_subclasses(B) == {E, F, G, H, I, T}
    assert get_all_subclasses(C) == {D, F, G, H, I, T}
    assert get_all