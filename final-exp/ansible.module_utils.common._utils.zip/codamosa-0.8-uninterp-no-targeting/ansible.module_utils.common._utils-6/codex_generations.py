

# Generated at 2022-06-20 15:20:45.227267
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    def get_class_hierarchy(cls):
        return [cls.__name__] + [get_class_hierarchy(c) for c in get_all_subclasses(cls)]

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class G(D):
        pass

    class I(E):
        pass

    class K(I):
        pass

    assert get_class_hierarchy(A) == [['A', ['C', ['E', ['I', ['K']]]], ['B', ['D', ['G']]]]]

# Generated at 2022-06-20 15:20:54.530079
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    def assert_classes(class_list):
        subclasses = get_all_subclasses(class_list[0])
        assert len(subclasses) == len(class_list)
        for cls in class_list:
            assert cls in subclasses
    assert_classes([A])
    assert_classes([B])
    assert_classes([B, D])
    assert_classes([B, D, C, E])
    assert_classes([A, B, D, C, E])

# Generated at 2022-06-20 15:20:57.317135
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(E):
        pass

    class G(F):
        pass
    assert set(get_all_subclasses(A)) == {B, C, D, E, F, G}

# Generated at 2022-06-20 15:21:03.240822
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a class hierarchy
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class C1(C):
        pass

    class C2(C):
        pass

    class D(B):
        pass

    class E(D):
        pass
    try:
        # Assert the result
        assert get_all_subclasses(A) == set([B, C, D, C1, C2, E])
    except AssertionError:
        get_all_subclasses(A) == set([B, C, D, E, C1, C2])

# Generated at 2022-06-20 15:21:10.980232
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class Test(C):
        pass

    assert Test in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)

# Generated at 2022-06-20 15:21:15.855497
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(C): pass
    class F(B, D): pass
    class G(E): pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])



# Generated at 2022-06-20 15:21:25.165575
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test for function get_all_subclasses
    '''
    class GrandParent(object):
        '''
        Class GrandParent to test get_all_subclasses
        '''
        pass

    class ParentOne(GrandParent):
        '''
        Class ParentOne to test get_all_subclasses
        '''
        pass

    class ParentTwo(GrandParent):
        '''
        Class ParentTwo to test get_all_subclasses
        '''
        pass

    class ChildOne(ParentOne):
        '''
        Class ChildOne to test get_all_subclasses
        '''
        pass

    class ChildTwo(ParentOne):
        '''
        Class ChildTwo to test get_all_subclasses
        '''
        pass


# Generated at 2022-06-20 15:21:30.276151
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(C): pass
    assert get_all_subclasses(A) == set([B,C,D,E])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D,E])

# Generated at 2022-06-20 15:21:40.987709
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Animal(object):
        pass
    class Carnivore(Animal):
        pass
    class Herbivore(Animal):
        pass
    class Cat(Carnivore):
        pass
    class Dog(Carnivore):
        pass
    class Cow(Herbivore):
        pass
    class Tiger(Cat):
        pass
    class Lion(Cat):
        pass
    class Mouton(Cow):
        pass
    class Chien(Dog):
        pass
    class Siamois(Tiger):
        pass

    # Test if the function can find subclasses
    animal = Animal()
    carnivore = Carnivore()
    herbivore = Herbivore()
    cat = Cat()
    dog = Dog()
    cow = Cow()
    tiger = Tiger()
    lion = Lion()
    mouton

# Generated at 2022-06-20 15:21:46.181403
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(B):
        pass
    reference = [B, C, D, E, F, G]

    subclasses = get_all_subclasses(A)
    for i in reference:
        assert i in subclasses
    for i in subclasses:
        assert i in reference

# Generated at 2022-06-20 15:21:56.426044
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(F):
        pass

    classes = get_all_subclasses(A)
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert G in classes
    assert H in classes



# Generated at 2022-06-20 15:22:07.885973
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections

    # Create classes
    class BaseClass(object):
        pass

    class ChildClass(BaseClass):
        pass

    class GrandChildClass(ChildClass):
        pass

    class AnotherChildClass(BaseClass):
        pass

    class SecondGrandChildClass(AnotherChildClass):
        pass

    # Prepare an iterable for comparaison
    inheritances = [
        GrandChildClass,
        AnotherChildClass,
        SecondGrandChildClass,
    ]

    # Test
    assert get_all_subclasses(BaseClass) == set(inheritances)

    # Test with an iterable type

# Generated at 2022-06-20 15:22:13.856494
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(C):
        pass

    assert set([A, B, C, D, E, F]) == get_all_subclasses(object)

# Generated at 2022-06-20 15:22:26.637019
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    # Direct child of A
    class B(A): pass
    class C(A): pass
    # Indirect child of A
    class D(B): pass
    class E(D): pass
    class F(D): pass
    # Another direct child of A
    class G(A): pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert G in get_all_subclasses(A)


# Generated at 2022-06-20 15:22:32.129450
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    # Just for covering more cases
    class F(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D, E, F])
    assert get_all_subclasses(D) == set([F])

# Generated at 2022-06-20 15:22:41.422467
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class AA(A): pass
    class AB(A): pass
    class AAA(AA): pass
    class AAC(AA): pass
    class ABA(AB): pass
    class ABB(AB): pass
    class ABBA(ABB): pass
    classes = {A, AA, AB, AAA, AAC, ABA, ABB, ABBA}
    assert classes == get_all_subclasses(A)
    assert classes == get_all_subclasses(AA)
    assert classes == get_all_subclasses(AB)
    assert classes == get_all_subclasses(AAA)
    assert classes == get_all_subclasses(AAC)
    assert classes == get_all_subclasses(ABA)
    assert classes == get_all_subclasses(ABB)
    assert classes == get_all_

# Generated at 2022-06-20 15:22:52.596135
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a():
        pass

    class b(a):
        pass

    class c(a):
        pass

    class d(a):
        pass

    class e(b, c):
        pass

    class f(e):
        pass

    class g():
        pass

    # The result is stored on a list because set is not guaranteed to be sorted
    assert sorted(list(get_all_subclasses(a))) == [b, c, d, e, f]
    assert sorted(list(get_all_subclasses(b))) == [b, e, f]
    assert sorted(list(get_all_subclasses(c))) == [c, e, f]
    assert sorted(list(get_all_subclasses(d))) == [d]

# Generated at 2022-06-20 15:22:56.192745
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a sample class hierarchy
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E:
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E not in subclasses
    subclasses = get_all_subclasses(E)
    assert B not in subclasses
    assert C not in subclasses
    assert D not in subclasses
    assert E not in subclasses

# Generated at 2022-06-20 15:23:00.048777
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class X(B, D):
        pass
    class Y(object):
        pass
    assert get_all_subclasses(A) == {B, C, D, X}
    assert get_all_subclasses(B) == {C, X}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == {X}
    assert get_all_subclasses(X) == set()
    assert get_all_subclasses(Y) == set()
    assert get_all_subclasses(object) == {A, B, C, D, X, Y}



# Generated at 2022-06-20 15:23:08.535182
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import ansible.plugins.loader
    # The call to get_all_subclasses should return the subclasses of AnsibleModule, even if they are
    # nested in a subclass of AnsibleModule.
    # See the example below:
    #    |- AnsibleModule
    #    |- AnsibleTestModule
    #        |- MyModule_1
    #        |- MyModule_2
    #        |- MyModule_3
    # The below assertion checks that MyModule_1, MyModule_2, and MyModule_3 are all in the iterable
    # returned by get_all_subclasses.

    # Only assert on an expected module

# Generated at 2022-06-20 15:23:20.032653
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    get_all_subclasses should return all of the subclasses of a given class, to n-levels deep.
    """
    class Mother(object):
        pass

    class ChildA(Mother):
        pass

    class ChildB(Mother):
        pass

    class ChildC1(ChildA):
        pass

    class ChildC2(ChildA):
        pass

    class ChildD(ChildC1):
        pass

    x = get_all_subclasses(Mother)
    y = [ChildA, ChildB, ChildC1, ChildC2, ChildD]
    assert set(y) == x, "Mismatched classes when retrieving all subclasses"
    pass

# Generated at 2022-06-20 15:23:29.545581
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import _utils

    # Create a class for testing get_all_subclasses
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(F):
        pass

    # Create a class for testing get_all_subclasses with multiple inheritance
    class H(A):
        pass

    class I(B):
        pass

    class J(H, I):
        pass

    class K(H, I):
        pass

    class L(J):
        pass

    class M(K):
        pass

    class N(M):
        pass

    class O(N):
        pass


# Generated at 2022-06-20 15:23:32.444535
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(D):
        pass

    # This is the unit test
    assert set([C, D, E]) == get_all_subclasses(A)

# Generated at 2022-06-20 15:23:42.427313
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Sequence
    from itertools import islice

    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    class G(F): pass

    assert isinstance(get_all_subclasses(A), Sequence)
    assert list(islice(get_all_subclasses(A), None)) == [B, C, D, E, F, G]
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])
    assert list(islice(get_all_subclasses(B), None)) == [D, F, G]
    assert set(get_all_subclasses(B)) == set([D, F, G])


# Generated at 2022-06-20 15:23:50.190239
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E():
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(B)) == set([E])
    assert set(get_all_subclasses(C)) == set([D, E])
    assert set(get_all_subclasses(D)) == set([E])
    assert set(get_all_subclasses(E)) == set()

# Generated at 2022-06-20 15:23:56.596379
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # This is a simple class to use in the unittest
    class GrandFather(object):
        pass

    class Father(GrandFather):
        pass

    class Son(Father):
        pass

    class GrandSon(Son):
        pass

    class Uncle(GrandFather):
        pass

    if set(get_all_subclasses(GrandFather)) != {Father, Uncle, Son, GrandSon}:
        raise RuntimeError("get_all_subclasses test failed (1)")

    if set(get_all_subclasses(Father)) != {Son, GrandSon}:
        raise RuntimeError("get_all_subclasses test failed (2)")

# Generated at 2022-06-20 15:24:06.309581
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B:
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    assert get_all_subclasses(A) == {C, D}, 'direct subclasses not retrieved'
    assert get_all_subclasses(B) == {E}, 'direct subclasses not retrieved'
    assert get_all_subclasses(C) == set(), 'no subclass for C'
    assert get_all_subclasses(D) == set(), 'no subclass for D'
    assert get_all_subclasses(E) == set(), 'no subclass for E'

# Generated at 2022-06-20 15:24:13.407282
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses, 'B should be a subclass of A'
    assert C in subclasses, 'C should be a subclass of A'
    assert D in subclasses, 'D should be a subclass of A'
    assert subclasses == set([B, C, D]), 'Only B, C and D should be subclasses of A'

    subclasses = get_all_subclasses(C)
    assert D in subclasses, 'D should be a subclass of C'
    assert subclasses == set([D]), 'Only D should be a subclass of C'

# Generated at 2022-06-20 15:24:22.075025
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestClassA(object):
        pass
    class TestClassB(object):
        pass
    class TestClassC(TestClassB):
        pass
    class TestClassD(TestClassC):
        pass
    class TestClassE(TestClassD):
        pass
    class TestClassF(TestClassA):
        pass
    class TestClassG(TestClassF):
        pass
    class TestClassH(TestClassA):
        pass
    class TestClassI(object):
        pass
    class TestClassJ(TestClassE):
        pass
    class TestClassK(TestClassJ):
        pass
    class TestClassL(TestClassK):
        pass


# Generated at 2022-06-20 15:24:29.965685
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(A): pass
    class E(B): pass
    class F(D): pass
    a = A()
    b = B()
    c = C()
    d = D()
    e = E()
    f = F()

    assert get_all_subclasses(A) == set([C,D,F])
    assert get_all_subclasses(B) == set([E])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([F])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-20 15:24:41.001937
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    assert get_all_subclasses(object) == set()
    assert get_all_subclasses(A) == {B, C, D, E, F, G}

# Generated at 2022-06-20 15:24:47.524695
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys
    import types

    class FakeModule:
        pass

    class FakeClass:
        pass

    class FakeMetaClass(type):
        pass

    module = FakeModule()
    # Creates a class object with object as ancestor
    cls = type('FakeClass', (FakeClass,), {})
    # Creates a class object with FakeClass as ancestor
    cls2 = type('FakeClass2', (FakeClass,), {})
    # Creates a class object with FakeClass2 as ancestor
    cls3 = type('FakeClass3', (FakeClass2,), {})
    # Creates a class object with FakeClass3 as ancestor
    cls4 = type('FakeClass4', (FakeClass3,), {})
    metadata = {'__module__': module}
    # Creates a class object with FakeMetaClass as ancestor

# Generated at 2022-06-20 15:24:58.295219
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Defining a simple class hierarchy
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(I):
        pass

    # Then check returned class list
    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)

# Generated at 2022-06-20 15:25:05.526424
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == frozenset([B, C, D, E])
    assert get_all_subclasses(B) == frozenset([C])
    assert get_all_subclasses(C) == frozenset([])
    assert get_all_subclasses(D) == frozenset([E])
    assert get_all_subclasses(E) == frozenset([])

# Generated at 2022-06-20 15:25:14.535071
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys
    import os
    import unittest
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_native

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(C):
        pass

    class I(D):
        pass

    class J(D):
        pass

    class K(H):
        pass

    class L(H):
        pass

    if sys.version_info < (2, 7):
        unittest.skipTest("Test requires Python >= 2.7")


# Generated at 2022-06-20 15:25:25.191904
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test method get_all_subclasses
    '''
    class TestAncestor(object):
        pass

    class TestChild1(TestAncestor):
        pass

    class TestSubChild1(TestChild1):
        pass

    class TestSubSubSubChild1(TestSubChild1):
        pass

    class TestSubSubSubChild2(TestChild1):
        pass

    class TestSubSubChild1(TestChild1):
        pass

    class TestSubChild2(TestAncestor):
        pass

    class TestSubSubSubChild3(TestSubChild2):
        pass

    class TestChild2(TestAncestor):
        pass

    class TestSubChild3(TestChild2):
        pass


# Generated at 2022-06-20 15:25:31.671498
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(E):
        pass

    class G(F):
        pass

    class H(G):
        pass

    class I(B):
        pass

    class J(object):
        pass

    # Test with A
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H, I])

    # Test with J
    assert set(get_all_subclasses(J)) == set([])

    # Test with object

# Generated at 2022-06-20 15:25:42.778815
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class SuperClass(object):
        pass

    class SubClassOne(SuperClass):
        pass

    class SubSubClassOneOne(SubClassOne):
        pass

    class SubSubClassOneTwo(SubClassOne):
        pass

    class SubClassTwo(SuperClass):
        pass

    class SubSubClassTwoOne(SubClassTwo):
        pass

    class SubSubSubClassTwoOneOne(SubSubClassTwoOne):
        pass

    # Assertion: there are only two subclass for SuperClass
    assert(len(SuperClass.__subclasses__()) == 2)
    # Assertion: there are three subclass for SubClassOne
    assert(len(SubClassOne.__subclasses__()) == 2)
    # Assertion: there is only one subclass for SubClassTwo

# Generated at 2022-06-20 15:25:52.102003
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types
    import datetime

    class func(object):
        pass
    # Create a subclass of a builtin class
    class str_subclass(str):
        pass
    # Create a subclass of a subclass of a builtin class
    class str_subclass2(str_subclass):
        pass
    # Create a subclass of a function
    class func_subclass(func):
        pass
    # Create a subclass of a subclass of a function
    class func_subclass2(func_subclass):
        pass
    # Create a subclass of a datetime
    class datetime_subclass(datetime.datetime):
        pass
    # Create a subclass of a subclass of a datetime
    class datetime_subclass2(datetime_subclass):
        pass

    # Expected result for get_all_subclasses in built

# Generated at 2022-06-20 15:26:02.509935
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(A):
        pass

    class F(D, E):
        pass

    class G:
        pass

    class H(B, G):
        pass

    class I(G):
        pass

    assert set([B, C, D, E, F, H]) == get_all_subclasses(A)
    assert set([C, D, F]) == get_all_subclasses(B)
    assert set([F]) == get_all_subclasses(D)
    assert set([H]) == get_all_subclasses(B)
    assert set([H, I]) == get_all_subclasses(G)

# Generated at 2022-06-20 15:26:17.025476
# Unit test for function get_all_subclasses
def test_get_all_subclasses():  # pragma: no cover
    import ansible.plugins.module_utils.basic
    all_subclasses = get_all_subclasses(ansible.plugins.module_utils.basic.AnsibleModule)
    assert ansible.plugins.action.debug.ActionModule in all_subclasses

# Generated at 2022-06-20 15:26:27.729614
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    get_all_subclasses is a very simple function with an expected
    output for a given input.  Thus, verifying the function's output
    for similar inputs is sufficient for unit testing.
    '''
    # Define base class
    class Base(object):
        '''
        Base is the base class for all other classes.
        '''
        pass

    # Define child classes
    class Child_1(Base):
        '''
        Child_1 is a child of Base.
        '''
        pass

    class Child_2(Base):
        '''
        Child_2 is a child of Base.
        '''
        pass

    class Grandchild_1_1(Child_1):
        '''
        Grandchild_1_1 is a child of Child_1 and Base.
        '''
        pass

# Generated at 2022-06-20 15:26:38.929789
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(object):
        pass

    class G(F):
        pass

    class X(object):
        pass

    class Y(object):
        pass

    class Z(object):
        pass

    # the following test illustrates that the result of __subclasses__ is not enough
    assert set(F.__subclasses__()) == set([G])
    # to test the function we need to check that both B and C are retrieved
    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(F)) == set([G])
    #

# Generated at 2022-06-20 15:26:44.916417
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base(object):
        pass
    class A(Base):
        pass
    class B(Base):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(F):
        pass

    assert get_all_subclasses(Base) == set([A, B, C, D, E, F, G])

    assert get_all_subclasses(A) == set([C])
    assert get_all_subclasses(B) == set([D, E, F, G])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set([E, F, G])

# Generated at 2022-06-20 15:26:49.885838
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(B):
        pass

    subclasses = get_all_subclasses(A)
    assert subclasses == set([B, C, D, E, F])

# Generated at 2022-06-20 15:27:00.642948
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass
    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    class F(E): pass
    assert F in get_all_subclasses(A)
    assert len(get_all_subclasses(A)) == 6
    assert len(get_all_subclasses(B)) == 4
    assert len(get_all_subclasses(C)) == 0
    assert len(get_all_subclasses(D)) == 1
    assert len

# Generated at 2022-06-20 15:27:06.849104
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    classes = get_all_subclasses(A)
    assert B in classes, 'unable to find B in get_all_subclasses'
    assert C in classes, 'unable to find C in get_all_subclasses'
    assert D in classes, 'unable to find D in get_all_subclasses'

# Generated at 2022-06-20 15:27:13.811224
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B, C):
        pass

    class F(B, C):
        pass

    # Recursing on the subclasses of E, the result must be a set of E and all its
    # subclasses.
    assert get_all_subclasses(E) == {E, D, F}
    # Recursing on B, the result must be a set of B, D and F
    assert get_all_subclasses(B) == {B, D, F}

__all__ = ['get_all_subclasses']

# Generated at 2022-06-20 15:27:25.314478
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This function serves as a unit test for the :py:func:`get_all_subclasses` function.
    '''
    # The goal of this unit test is to make sure that the set of classes returned by
    # get_all_subclasses matches the following list of classes:
    subclass_list = {
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R'
    }

    # The following list of classes represents the structure of classes we will use
    # for this unit test
    class A():
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass


# Generated at 2022-06-20 15:27:32.378927
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(B)) == set()
    assert set(get_all_subclasses(C)) == set([D])
    assert set(get_all_subclasses(D)) == set()

# Generated at 2022-06-20 15:28:01.637040
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test get_all_subclasses method definition

    This test is an attempt to cover as many logic as possible inside get_all_subclasses method
    by using the following structure of class compilation:


    A
    |_B
     |_D
    |_C
     |_E
      |_F
     |_E
      |_F

    '''
    # Define class A
    class A(object):
        pass
    # Define class B
    class B(A):
        pass
    # Define class C
    class C(A):
        pass
    # Define class D
    class D(B):
        pass
    # Define class E
    class E(C):
        pass
    # Define class F
    class F(E):
        pass
    # Define class G

# Generated at 2022-06-20 15:28:08.984827
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(object):
        pass
    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([C])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])

# Generated at 2022-06-20 15:28:16.882957
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(A):
        pass
    class F(E):
        pass
    class G(F):
        pass

    all_subclasses_dic = {A: set([B, C, D, E, F, G]), B: set([C])}

    for cl in [A, B]:
        got = get_all_subclasses(cl)
        wanted = all_subclasses_dic.get(cl)
        assert got == wanted, 'get_all_subclasses(%s) returned %s, wanted %s' % (cl, got, wanted)

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-20 15:28:26.830552
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(A): pass
    class E(B, C): pass
    class F(D, B): pass
    class G(D, E): pass
    class H: pass
    class I(H): pass
    class J(H): pass
    class K(I, J): pass
    class L(J, I): pass
    class M(K, L, D): pass
    assert set(get_all_subclasses(A)) == set((B, C, D, E, F, G, M))
    assert set(get_all_subclasses(B)) == set((E, F, G, M))
    assert set(get_all_subclasses(C)) == set((E, G, M))

# Generated at 2022-06-20 15:28:35.007768
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(F):
        pass
    class K(H):
        pass
    class L(J):
        pass
    assert set([B, D, E, H, I, F, J, C, G, K, L]) == get_all_subclasses(A)


# Generated at 2022-06-20 15:28:39.013502
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a:
        pass
    class b:
        pass
    class c(a):
        pass
    class d(a):
        pass
    class e(c):
        pass
    class f(d):
        pass
    result = get_all_subclasses(a)
    assert c in result
    assert d in result
    assert e in result
    assert f in result
    assert b not in result
    assert a not in result

# Generated at 2022-06-20 15:28:49.040030
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create some simple classes for testing
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class X(object):
        pass

    class Y(X):
        pass

    class Z(Y):
        pass

    # Check that subclasses are correctly retrieved
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert E in get_all_subclasses(C)
    assert E in get_all_subclasses(D)
    assert Y in get_all_subclasses(X)

# Generated at 2022-06-20 15:28:59.545722
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass

    assert get_all_subclasses(A) == set([B, D, C, E, F])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E, F])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set([])

    # Test empty result
    class G(object):
        pass
    assert get_all_subclasses(G) == set

# Generated at 2022-06-20 15:29:11.426720
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestA(object):
        '''base class for testing'''
        pass
    class TestB(object):
        '''base class for testing'''
        pass
    class TestC(TestA):
        '''subclass for testing'''
        pass
    class TestD(TestA):
        '''subclass for testing'''
        pass
    class TestE(TestB):
        '''subclass for testing'''
        pass
    class TestF(TestB):
        '''subclass for testing'''
        pass
    class TestG(TestC):
        '''subclass for testing'''
        pass
    class TestH(TestD):
        '''subclass for testing'''
        pass


# Generated at 2022-06-20 15:29:19.607576
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(B):
        pass

    subclasses_a = get_all_subclasses(A)
    assert A in subclasses_a
    assert B in subclasses_a
    assert C in subclasses_a
    assert D in subclasses_a
    assert E in subclasses_a
    assert F in subclasses_a

# Generated at 2022-06-20 15:30:16.717929
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    # On Python3, some subclasses of "object" are getting into "subclasses" list
    # So we include all classes in a list
    assert set(get_all_subclasses(A)) == set([D,F,B,C,E])

# Generated at 2022-06-20 15:30:24.426436
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create classes to test get_all_subclasses function
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(D):
        pass
    class H:
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(H) == set()

# Generated at 2022-06-20 15:30:33.577800
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base(object):
        pass

    class A(Base):
        pass

    class B(Base):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(B):
        pass

    class G(D):
        pass

    class H(D):
        pass

    assert(get_all_subclasses(Base) == {A, B, C, D, E, F, G, H})
    assert(get_all_subclasses(A) == {C, D, G, H})
    assert(get_all_subclasses(B) == {E, F})
    assert(get_all_subclasses(C) == set())
    assert(get_all_subclasses(D) == {G, H})
   