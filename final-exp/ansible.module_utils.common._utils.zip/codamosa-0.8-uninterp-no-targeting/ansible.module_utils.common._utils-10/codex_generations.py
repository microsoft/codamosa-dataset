

# Generated at 2022-06-20 15:20:43.983330
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    python -m ansible.module_utils._utils test_get_all_subclasses
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    assert set([A, B, C, D]) == get_all_subclasses(A)

# Generated at 2022-06-20 15:20:51.748335
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for get_all_subclasses
    '''

    class Object(object):
        pass

    class A(Object):
        pass

    class B(Object):
        pass

    assert(get_all_subclasses(Object) == set([A, B]))

    class C(A):
        pass
    assert(get_all_subclasses(Object) == set([A, B, C]))

    class D(B):
        pass
    assert(get_all_subclasses(Object) == set([A, B, C, D]))

    class E(D):
        pass
    assert(get_all_subclasses(Object) == set([A, B, C, D, E]))


# Generated at 2022-06-20 15:21:03.382231
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Set

    # Creating class structure
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(E, C):
        pass

    class G(F):
        pass

    assert(G in get_all_subclasses(A))
    assert(B in get_all_subclasses(A))
    assert(F in get_all_subclasses(A))
    assert(len(set(get_all_subclasses(A))) == 7)

# Generated at 2022-06-20 15:21:09.762433
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class X:
        pass

    class Y(X):
        pass

    assert get_all_subclasses(A) == set([B, C])
    assert get_all_subclasses(X) == set([Y])

# Generated at 2022-06-20 15:21:16.413754
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(A) != set([B, C, D, E])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(B) == set([])

# Generated at 2022-06-20 15:21:25.473032
# Unit test for function get_all_subclasses

# Generated at 2022-06-20 15:21:27.715408
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import subclasses as sc
    descendants = get_all_subclasses(sc.A)
    assert all(isinstance(c, sc.A) for c in descendants)

# Generated at 2022-06-20 15:21:31.690027
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass
    assert get_all_subclasses(A) == set([B, C, D])

# Generated at 2022-06-20 15:21:42.423326
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function `get_all_subclasses`
    '''
    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C, D):
        pass

    class F(D):
        pass

    assert get_all_subclasses(A) == {C, E}
    assert get_all_subclasses(B) == {D, E, F}
    assert get_all_subclasses(C) == {E}
    assert get_all_subclasses(D) == {E, F}
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-20 15:21:52.199370
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass

    a = A()
    b = B()
    c = C()
    d = D()
    e = E()
    f = F()

    assert {A, B, C, D, E, F} == get_all_subclasses(A)
    assert {B, D, E, F} == get_all_subclasses(B)
    assert {C} == get_all_subclasses(C)
    assert {D, E, F} == get_all_subclasses(D)
    assert {E, F} == get_all_subclasses(E)
   

# Generated at 2022-06-20 15:22:05.938640
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test the get_all_subclasses function by creating a simple class hierarchy, then traversing it
    and verifying the results.  The expected output is:
    [A, B, C, D, E, F, G, H]
    """

    class A:
        """
        A class with no subclasses
        """
        pass

    class B(A):
        """
        A class with one subclass, which has no subclasses
        """
        pass

    class C(A):
        """
        A class with one subclass, which subclasses it.
        """
        pass

    class D(C):
        """
        A class which subclasses C
        """
        pass

    class E(A):
        """
        A class with three subclasses
        """

        pass


# Generated at 2022-06-20 15:22:09.509287
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass

    result = get_all_subclasses(A)
    assert B in result
    assert C in result
    assert D in result

    assert len(result) == 3

# Generated at 2022-06-20 15:22:18.959016
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """Test to ensure that get_all_subclasses returns as expected."""

    import ansible.plugins.loader

    action_plugin_names = ('command', 'shell', 'script', 'copy', 'synchronize', 'fetch',
                           'template', 'file', 'copy', 'lineinfile', 'template', 'copy', 'synchronize', 'fetch')

    for plugin in ansible.plugins.loader.all(class_only=True):
        if hasattr(plugin, '__name__') and plugin.__name__ in action_plugin_names:
            assert plugin in get_all_subclasses(ansible.plugins.action.ActionBase)
            assert plugin in get_all_subclasses(plugin)

# Generated at 2022-06-20 15:22:26.028069
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(B)) == set([C])
    assert set(get_all_subclasses(C)) == set()
    assert set(get_all_subclasses(D)) == set([E])
    assert set(get_all_subclasses(E)) == set()

# Generated at 2022-06-20 15:22:32.899324
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import os

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(object):
        pass

    class G(F):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == {D, E}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == {G}
    assert get_all_subclasses(G) == set()
    assert get_all_subclasses

# Generated at 2022-06-20 15:22:42.032818
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Create a python class and a subclass

    class Parent(object):
        pass

    class ChildOne(Parent):
        pass

    class ChildTwo(Parent):
        pass

    # Create more classes with multiple generations

    class GrandChildOne(ChildOne):
        pass

    class GrandChildTwo(ChildOne):
        pass

    class GreatGrandChildOne(GrandChildOne):
        pass

    class GreatGrandChildTwo(GrandChildOne):
        pass

    # Create class with no subclasses

    class Empty(object):
        pass

    # Test function with a single class

    assert get_all_subclasses(Parent) == set([ChildOne, ChildTwo,
                                              GrandChildOne, GrandChildTwo,
                                              GreatGrandChildOne, GreatGrandChildTwo])

    # Test function with a class with no subclasses

    assert get_all

# Generated at 2022-06-20 15:22:49.998997
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(A):
        pass

    class F(A):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F}
    assert get_all_subclasses(B) == {D}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-20 15:23:01.468123
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(B):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(object):
        pass
    class K(J):
        pass
    class L(J):
        pass
    class M(J):
        pass
    class N(J):
        pass
    class O(object):
        pass
    class P(O):
        pass

# Generated at 2022-06-20 15:23:09.247111
# Unit test for function get_all_subclasses

# Generated at 2022-06-20 15:23:16.399551
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        """Class A"""
    class B(A):
        """Class B"""
    class C(A):
        """Class C"""
    class D(B, C):
        """Class D"""
    class E(C):
        """Class E"""
    class F(D):
        """Class F"""
    result = get_all_subclasses(A)
    assert len(result) == 5
    assert B in result
    assert C in result
    assert D in result
    assert E in result
    assert F in result

# Generated at 2022-06-20 15:23:26.291365
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    assert C in A.__subclasses__()
    assert B in A.__subclasses__()
    assert D in A.__subclasses__()
    assert D not in B.__subclasses__()
    assert C not in B.__subclasses__()
    assert C not in D.__subclasses__()

    assert set([C, B, D]) == get_all_subclasses(A)

# Generated at 2022-06-20 15:23:30.437391
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    expected = [B, D, E]

    assert(set(expected) == get_all_subclasses(A))

# Generated at 2022-06-20 15:23:38.008780
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(B): pass
    class E(D): pass
    class F(A): pass
    class G(F): pass
    class H(F): pass
    class I(G): pass
    class J(H): pass
    class K(G): pass

    # Ensure that all expected subclasses were found.
    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert G in get_all_subclasses(A)
   

# Generated at 2022-06-20 15:23:40.992699
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])

# Generated at 2022-06-20 15:23:48.859569
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    A basic test of get_all_subclasses
    '''
    import types

    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set()

    assert get_all_subclasses(types.ModuleType) == set()

# Generated at 2022-06-20 15:23:56.159710
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass
    class F(D, C): pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, E, F])
    assert set(get_all_subclasses(C)) == set([F])
    assert set(get_all_subclasses(D)) == set([E, F])
    assert set(get_all_subclasses(E)) == set()
    assert set(get_all_subclasses(F)) == set()

# Generated at 2022-06-20 15:24:02.942526
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This unit test verify that all subclasses of exceptions.Exception are retrieved by
    get_all_subclasses function.
    '''
    import exceptions
    subclasses = get_all_subclasses(exceptions.Exception)
    # Should be a list of exceptions (including one single class)
    assert len(subclasses) > 0
    for class_name in subclasses:
        assert issubclass(class_name, exceptions.Exception)

# Generated at 2022-06-20 15:24:10.800724
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B,C):
        pass
    class E(A):
        pass
    class F(E):
        pass
    class G(E):
        pass
    class H(F,G):
        pass
    class I(D,H):
        pass

    assert I in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert H in get_all_subclasses(A)

    assert F in get_all_subclasses(E)
    assert G in get_all_subclasses(E)

# Generated at 2022-06-20 15:24:21.411108
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    class F(E):
        pass

    #   A
    #  / \
    # B   C
    #      \
    #       D
    # E
    #  \
    #   F

    assert get_all_subclasses(A) == {B, C, D}
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == {D}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == {F}
    assert get_all_subclasses(F) == set()




# Generated at 2022-06-20 15:24:26.506504
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(F):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])



# Generated at 2022-06-20 15:24:36.720117
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(C):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])

# Generated at 2022-06-20 15:24:42.602673
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(E):
        pass

    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 7
    assert set([B, C, D, E, F, G, H]) == subclasses

# Generated at 2022-06-20 15:24:50.423452
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(E):
        pass

    all_subclasses = [B, D, C, E, F, G]
    for subclass in all_subclasses:
        assert get_all_subclasses(A) == set(all_subclasses)



# Generated at 2022-06-20 15:25:00.814038
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import Iterable

    class Foo(object):
        pass

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    class Bis(Bar):
        pass

    class Boz(Baz):
        pass

    class Toz(Baz):
        pass

    class Torz(Toz):
        pass

    # Test with class Foo
    subclasses = get_all_subclasses(Foo)
    if not isinstance(subclasses, Iterable):
        raise AssertionError('get_all_subclasses should return an iterable. Instead, it returns a {0}'.format(type(subclasses)))

# Generated at 2022-06-20 15:25:06.874647
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(F):
        pass

    class H(G):
        pass

    subclasses = get_all_subclasses(A)
    assert A in subclasses
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in subclasses
    assert H in subclasses

# Generated at 2022-06-20 15:25:15.397107
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base(object): pass
        # All parents are: Base
    class Alpha(Base): pass
        # All parents are: Alpha, Base
    class Beta(Base): pass
        # All parents are: Beta, Base
    class Gamma(Alpha): pass
        # All parents are: Gamma, Alpha, Base
    class Delta(Alpha): pass
        # All parents are: Delta, Alpha, Base
    class Epsilon(Alpha, Beta): pass
        # All parents are: Epsilon, Alpha, Beta, Base
    class Zeta(Alpha, Beta, Gamma): pass
        # All parents are: Zeta, Alpha, Beta, Gamma, Base
    class Eta(Epsilon, Delta, Zeta): pass
        # All parents are: Eta, Epsilon, Delta, Zeta, Alpha, Beta, Gamma, Base

    # Base has parents: <class '__

# Generated at 2022-06-20 15:25:18.213836
# Unit test for function get_all_subclasses

# Generated at 2022-06-20 15:25:23.310544
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a simple class hierarchy for testing
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(C):
        pass
    assert get_all_subclasses(A) == set([D, C, E])
    assert get_all_subclasses(B) == set([])

# Generated at 2022-06-20 15:25:30.333758
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(D):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G}

    # Following is an interesting case to test wether __subclass__ return only objects directly
    # inherited
    class H(E):
        pass

    assert H not in C.__subclasses__()

    # Check that builtin class object is not affected by this method
    assert object.__subclasses__ == object.__subclasses__


# Generated at 2022-06-20 15:25:37.894821
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(A): pass
    class G(F): pass
    classes = get_all_subclasses(A)
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert G in classes

# vim: foldmethod=marker

# Generated at 2022-06-20 15:25:52.998816
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D, E}



# Generated at 2022-06-20 15:25:59.209718
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(D):
        pass
    class G():
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(G)) == set([])

# Generated at 2022-06-20 15:26:05.315730
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(D): pass
    class F(object): pass

    subclasses = get_all_subclasses(object)
    assert A in subclasses
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses

# Generated at 2022-06-20 15:26:10.107350
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test class definition for testing
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(C):
        pass

    class G(E):
        pass

    # Test retrieve all subclasses
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])

# Generated at 2022-06-20 15:26:21.204091
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a simple class tree
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    # Direct subclasses
    assert A.__subclasses__() == [B, D]
    assert B.__subclasses__() == [C]
    assert C.__subclasses__() == []
    assert D.__subclasses__() == [E]
    assert E.__subclasses__() == []
    # Recursive subclasses
    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(B)) == set([C])

# Generated at 2022-06-20 15:26:30.670825
# Unit test for function get_all_subclasses

# Generated at 2022-06-20 15:26:37.886846
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test recursive search of subclasses
    """
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(A):
        pass

    class F(D):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F}

# Generated at 2022-06-20 15:26:44.624441
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    # Check number of classes
    a_subclasses = set([B, C, D])
    assert len(get_all_subclasses(A)) == len(a_subclasses)

    # Check classes returned are the same
    for cls in get_all_subclasses(A):
        assert cls in a_subclasses

# Generated at 2022-06-20 15:26:54.891850
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Class definition to test function get_all_subclasses
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(E):
        pass

    class G(F):
        pass

    class H(F):
        pass

    class I(E):
        pass

    class J(D):
        pass

    class K(D):
        pass

    # Initialize the classes
    a = A()
    b = B()
    c = C()
    d = D()
    e = E()
    f = F()
    g = G()
    h = H()
    i = I()
    j = J()
    k = K()

    #

# Generated at 2022-06-20 15:26:59.819389
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert get_all_subclasses(A) == {B, C, D}, "test_get_all_subclasses doesn't work as expected."



# Generated at 2022-06-20 15:27:26.920390
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    A.__subclasses__ = lambda: [B, C]
    B.__subclasses__ = lambda: []
    C.__subclasses__ = lambda: [D]
    D.__subclasses__ = lambda: []

    res = get_all_subclasses(A)
    assert res == {A, B, C, D}

# Generated at 2022-06-20 15:27:37.220850
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''Test of get_all_subclasses'''
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    # Check all the direct subclasses of A
    assert set([B, C]) == set(A.__subclasses__())
    # Check all the subclasses of A
    assert set([B, C, D, E, F, G]) == get_all_subclasses(A)
    # Check all the direct subclasses of B
    assert set([D]) == set(B.__subclasses__())
    # Check all the subclasses of B
    assert set([D, F]) == get_all

# Generated at 2022-06-20 15:27:45.861658
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # We will use this class as the base class for our unit test
    class A(object):
        pass

    # Define the following classes:
    #   B inherits from A
    #   C inherits from A
    #   D inherits from C and B
    #   E inherits from C
    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(C):
        pass

    # Test to make sure the function works
    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)


# Generated at 2022-06-20 15:27:52.222581
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(A):
        pass
    class H(E):
        pass
    cls_set = get_all_subclasses(A)
    assert len(cls_set) == 8
    assert B in cls_set
    assert C in cls_set
    assert D in cls_set
    assert E in cls_set
    assert F in cls_set
    assert G in cls_set
    assert H in cls_set
    assert A not in cls_set

# Unit test: Special case where there is no subclass

# Generated at 2022-06-20 15:27:59.577436
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a:
        pass
    class b(a):
        pass
    class c(a):
        pass
    class d(b):
        pass
    class e(c):
        pass
    class f(e):
        pass

    assert(get_all_subclasses(a) == set([b, c, d, e, f]))
    assert(get_all_subclasses(object) == set([type]))
    # Test if order is preserved
    assert(get_all_subclasses(a) == set([b, c, d, e, f]))

# Test if order is preserved

# Generated at 2022-06-20 15:28:08.414051
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestA(object):
        pass

    class TestB(TestA):
        pass

    class TestC(TestB):
        pass

    class TestD(TestC):
        pass

    class TestE(TestB):
        pass

    assert(get_all_subclasses(TestA) == set([TestB, TestC, TestD, TestE]))
    assert(get_all_subclasses(TestB) == set([TestC, TestD, TestE]))
    assert(get_all_subclasses(TestC) == set([TestD]))
    assert(get_all_subclasses(TestD) == set())
    assert(get_all_subclasses(TestE) == set())

# Generated at 2022-06-20 15:28:13.146955
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B, C): pass
    class F(D, E): pass
    # If we want to get all subclasses of class A
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-20 15:28:16.368606
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(B):
        pass
    class F(D):
        pass

    assert get_all_subclasses(A) == set([B, C, E, D, F])

# Generated at 2022-06-20 15:28:26.334102
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(E):
        pass

    class G(F):
        pass

    class H(G):
        pass

    class I(object):
        pass

    class J(I):
        pass

    class K(I):
        pass

    class L(K):
        pass

    class M(I):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in subclasses
    assert H in subclasses
    assert I not in sub

# Generated at 2022-06-20 15:28:34.008150
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    # We do not want to retrieve A here because it is not a subclass of object
    assert get_all_subclasses(object) == {B,C,D,E}
    assert get_all_subclasses(B) == {D,E}
    assert get_all_subclasses(A) == {B,C,D,E}
    assert get_all_subclasses(E) == set()



# Generated at 2022-06-20 15:29:36.738153
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # pylint: disable=too-few-public-methods,no-init
    '''
    Tests for function get_all_subclasses
    '''
    class ClassA(object):
        '''Class A'''
    class ClassB(ClassA):
        '''Class B'''
    class ClassC(ClassA):
        '''Class C'''
    class ClassD(ClassB):
        '''Class D'''
    class ClassE(ClassB):
        '''Class E'''
    class ClassF(ClassC):
        '''Class F'''
    class ClassG(ClassC):
        '''Class G'''

    # Test if all subclasses are retrieved
    subclasses = get_all_subclasses(ClassA)
    assert len(subclasses) == 7
    # Check each subclass is

# Generated at 2022-06-20 15:29:44.515865
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class Test(object):
        pass
    class Test1(Test):
        pass
    class Test2(Test):
        pass
    class Test11(Test1):
        pass
    class Test111(Test11):
        pass
    class Test12(Test1):
        pass

    class TestUtils(unittest.TestCase):
        def test_get_all_subclasses(self):
            self.assertEqual(set([Test11, Test111, Test12]), get_all_subclasses(Test1))

    unittest.main(verbosity=2)
    # python -m ansible.utils.test_get_all_subclasses

# Generated at 2022-06-20 15:29:49.716631
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B,C):
        pass
    ret = get_all_subclasses(A)
    assert ret == set([B,C,D,E])

# Generated at 2022-06-20 15:29:59.897390
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)

    assert C not in get_all_subclasses(B)
    assert D in get_all_subclasses(B)
    assert E in get_all_subclasses(B)

    assert A not in get_all_subclasses(B)
    assert B not in get_all_subclasses(B)
    assert C not in get

# Generated at 2022-06-20 15:30:05.196326
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([C])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-20 15:30:08.694777
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert D in get_all_subclasses(C)


# Generated at 2022-06-20 15:30:16.683498
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(object):
        pass
    class D(A):
        pass
    class E(A):
        pass
    class F(C):
        pass
    class G(B):
        pass
    class H(F):
        pass
    class I(B):
        pass
    class J(I):
        pass

    assert get_all_subclasses(A) == set([B, D, G, I, J, E])
    assert get_all_subclasses(B) == set([G, I, J])
    assert get_all_subclasses(C) == set([F, H])

# Generated at 2022-06-20 15:30:26.272743
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(A): pass
    class F(E): pass
    class H(E): pass
    class I(H): pass
    class G: pass
    class AA: pass

    a = A()
    b = B()
    c = C()
    d = D()
    e = E()
    f = F()
    g = G()
    h = H()
    i = I()
    aa = AA()

    classes = get_all_subclasses(A)
    expected = set([B, C, D, E, F, H, I])
    assert classes == expected, 'Unexpected subclasses found'
    classes = get_all_subclasses(G)
    expected = set

# Generated at 2022-06-20 15:30:33.548056
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(object):
        pass

    class D(B, C):
        pass

    class E(C):
        class F(C):
            pass
        pass

    class G(C):
        pass

    assert get_all_subclasses(A) == set([B, D])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([D, E, G, E.F])
    assert get_all_subclasses(D) == set([])