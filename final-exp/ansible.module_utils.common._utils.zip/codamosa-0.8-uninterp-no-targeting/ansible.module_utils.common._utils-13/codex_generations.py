

# Generated at 2022-06-20 15:20:45.175829
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F}
    assert get_all_subclasses(B) == {D, E, F}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == {E, F}
    assert get_all_subclasses(E) == {F}
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-20 15:20:53.685793
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a(object):
        pass
    class b(a):
        pass
    class c(a):
        pass
    class d(b):
        pass
    class e(b):
        pass
    class f(c):
        pass
    class g(c):
        pass
    class h(d):
        pass
    class i(d):
        pass
    class j(g):
        pass
    assert set(get_all_subclasses(a)) == set([b, c, d, e, f, g, h, i, j])



# Generated at 2022-06-20 15:20:56.215298
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Testing A
    class A():
        pass

    # Testing B
    class B(A):
        pass

    # Testing C
    class C(A):
        pass

    assert get_all_subclasses(A) == set([B, C])

# Generated at 2022-06-20 15:21:05.095959
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """ Examples of how to use function get_all_subclasses()
    """
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(B):
        pass
    class F(B):
        pass
    class G(F):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(G):
        pass
    class K(J):
        pass
    class L(J):
        pass
    assert get_all_subclasses(B) == {E, F, G, H, I, J, K, L}

# Generated at 2022-06-20 15:21:12.024740
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Let the following class hierarchy be:
      A
      +---B
      +---C
           +---D
    This tests makes sure that all the 4 classes are retrieved by the method.
    """
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass

    assert set(get_all_subclasses(A)) == set([B, C, D])

# Generated at 2022-06-20 15:21:21.272910
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    ''' test get_all_subclasses function '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(D, B):
        pass

    # get_all_subclasses should return every class and subclasses
    A_subclasses = get_all_subclasses(A)
    assert A_subclasses == set([B, C, D, E, F, G])
    B_subclasses = get_all_subclasses(B)
    assert B_subclasses == set([G])
    C_subclasses = get_all_subclasses(C)
    assert C_subclasses == set([D, E])
   

# Generated at 2022-06-20 15:21:28.457475
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D1(B):
        pass
    class D2(B):
        pass
    class E(C):
        pass
    assert(get_all_subclasses(A) == set([B, C, D1, D2, E]))
    # Should return an empty list
    assert(get_all_subclasses(D1) == set([]))

# Generated at 2022-06-20 15:21:40.035088
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        def __init__(self, name):
            self.name = name

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(C):
        pass

    class W(object):
        pass

    class X(W):
        pass

    class Y(X):
        pass

    class Z(W):
        pass

    subclasses_a = get_all_subclasses(A)
    assert D in subclasses_a
    assert E in subclasses_a
    assert F in subclasses_a
    assert W not in subclasses_a

    subclasses_b = get_all_subclasses(B)
    assert D in subclasses_b
    assert E in subclasses

# Generated at 2022-06-20 15:21:43.664539
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(object): pass
    class D(A): pass
    class E(B): pass
    class F(D): pass

    assert get_all_subclasses(A) == set([B, D, E, F])
    assert get_all_subclasses(C) == set()

# Generated at 2022-06-20 15:21:48.642014
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import abc
    class A(abc.ABC):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    assert get_all_subclasses(A) == {B, C, D}
    assert get_all_subclasses(B) == {C}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-20 15:21:58.647236
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test for get_all_subclasses function

    This function tests get_all_subclasses by defining a class tree.  It then
    calls get_all_subclasses on the root class and checks to see if it returns
    the expected set of classes.
    '''
    class A(object):
        ''' root class '''
        pass

    class B(A):
        ''' first level of child classes '''
        pass

    class C(A):
        ''' first level of child classes '''
        pass

    class D(B):
        ''' second level of child classes '''
        pass

    class E(B):
        ''' second level of child classes '''
        pass

    class F(D):
        ''' third level of child classes '''
        pass

    # Create set of all descendents of

# Generated at 2022-06-20 15:22:03.671598
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    assert sorted(get_all_subclasses(A), key=lambda x: x.__name__) == [B, C]

# Generated at 2022-06-20 15:22:14.269577
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(object):
        pass

    assert(A in get_all_subclasses(A))
    assert(B in get_all_subclasses(A))
    assert(C in get_all_subclasses(A))
    assert(D in get_all_subclasses(A))
    assert(E not in get_all_subclasses(A))



# Generated at 2022-06-20 15:22:21.452951
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(object):
        pass
    class F(object):
        pass
    class G(F):
        pass
    class H(E):
        pass
    class I(H):
        pass
    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E not in subclasses
    assert F not in subclasses
    assert G not in subclasses
    assert H not in subclasses
    assert I not in subclasses

# Generated at 2022-06-20 15:22:27.855101
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    # Testing availibility of class and order of returned classes
    assert A in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert list(get_all_subclasses(A)) == [A, B, C, D, E, F]

# Generated at 2022-06-20 15:22:39.622781
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class A_1(A): pass
    class A_1_1(A_1): pass
    class A_2(A): pass
    class B: pass
    class B_1(B): pass
    class B_2(B): pass
    class C(B): pass
    class D(C): pass
    class E: pass
    class F(E): pass
    class G(F): pass
    class H(G): pass
    # We have 8 classes with 8 references in the graph
    assert len(get_all_subclasses(A)) == 4
    assert len(get_all_subclasses(B)) == 3
    assert len(get_all_subclasses(C)) == 1
    assert len(get_all_subclasses(D)) == 0
    # We should avoid infinite loop

# Generated at 2022-06-20 15:22:50.872702
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(C, B):
        pass

    class F(D, E):
        pass

    class G(E):
        pass

    assert get_all_subclasses(A) == {C, D, F}
    assert get_all_subclasses(B) == {E, F}
    assert get_all_subclasses(C) == {E, F}
    assert get_all_subclasses(D) == {F}
    assert get_all_subclasses(E) == {F, G}
    assert get_all_subclasses(F) == set()
    assert get_all_subclasses(G) == set()

# Generated at 2022-06-20 15:23:01.999398
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C1():
        pass
    class C2():
        pass
    class C3():
        pass
    class C4():
        pass
    class C2_1(C2):
        pass
    class C2_2(C2):
        pass
    class C3_1(C3):
        pass
    class C3_2(C3):
        pass
    class C4_1(C4):
        pass
    class C4_2(C4):
        pass
    class C4_3(C4):
        pass
    class C2_2_1(C2_2):
        pass
    class C4_3_1(C4_3):
        pass
    class C4_3_2(C4_3):
        pass

# Generated at 2022-06-20 15:23:06.712786
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(A):
        pass

    class F(E):
        pass

    class G(F):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])

# Generated at 2022-06-20 15:23:17.143280
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class zero: pass
    class one(zero): pass
    class two(zero): pass
    class three(two): pass
    class four(one): pass
    class five(four): pass
    class six(two, five): pass
    # Check that we can find all expected class
    assert get_all_subclasses(zero) == set([one, two, three, four, five, six])
    assert get_all_subclasses(six) == set()
    assert get_all_subclasses(three) == set()
    assert get_all_subclasses(two) == set([three, six])
    assert get_all_subclasses(one) == set([four, five, six])

# Generated at 2022-06-20 15:23:29.617128
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansibullbot.utils.test_helpers import (
        MockModule,
        MockClass
    )

    # Init a mocked module
    m = MockModule('test_get_all_subclasses')

    # Define a class hierarchy
    A = MockClass(m, 'A', (object,))
    B = MockClass(m, 'B', (A,))
    C = MockClass(m, 'C', (B,))
    D = MockClass(m, 'D', (B,))
    BB = MockClass(m, 'BB', (B,))
    CC = MockClass(m, 'CC', (C,))

    # Search for all subclasses of A
    subclasses = get_all_subclasses(A)
    assert BB in subclasses
    assert CC in subclasses
    assert D in subclasses

# Generated at 2022-06-20 15:23:37.258226
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a testing class structure
    # A   B    C
    # | \/ \ /  \
    # |  D   E   F
    # |  |       |
    # G  H       I
    # |
    # J
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(D): pass
    class H(D): pass
    class I(F): pass
    class J(G): pass

    # Test that it has the expected behavior with class A
    assert get_all_subclasses(A) == set([B, D, G, H, E, C, F, I, J])
    # Test that it has the expected behavior with class D

# Generated at 2022-06-20 15:23:44.226152
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(C):
        pass
    class G:
        pass
    assert get_all_subclasses(A) == set([B, D, E, C, F])
    assert get_all_subclasses(C) == set([F])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(G) == set([])

# Generated at 2022-06-20 15:23:51.238557
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(B): pass
    assert get_all_subclasses(object) == set()
    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == {E}
    assert get_all_subclasses(C) == {D}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-20 15:23:58.127982
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class MyClass1:
        pass
    class MyClass2(MyClass1):
        pass
    class MyClass3(MyClass1):
        pass
    class MyClass4(MyClass2):
        pass
    class MyClass5(MyClass2):
        pass
    class MyClass6:
        pass
    assert get_all_subclasses(MyClass1) == {MyClass2, MyClass3, MyClass4, MyClass5}
    assert get_all_subclasses(MyClass2) == {MyClass4, MyClass5}
    assert get_all_subclasses(MyClass3) == set()
    assert get_all_subclasses(MyClass4) == set()
    assert get_all_subclasses(MyClass5) == set()

# ==============================================================
# Tests for module level methods
# =================================

# Generated at 2022-06-20 15:24:08.686732
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F(C):
        pass
    # Test if all subclasses are gathered
    result = get_all_subclasses(A)
    expected = set([B, C, D, E, F])
    assert result == expected

    # Test if there is no duplicate
    result = get_all_subclasses(D)
    expected = set([D, E])
    assert result == expected

    # Test with no subclass
    result = get_all_subclasses(F)
    expected = set([F])
    assert result == expected

# Generated at 2022-06-20 15:24:20.165921
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(object):
        pass
    class G(E):
        pass
    class H(G):
        pass
    class I(A):
        pass
    class J(F):
        pass
    class K(object):
        pass
    k = get_all_subclasses(A)
    assert set(k) == {B, C, D, E, I, G, H}
    k = get_all_subclasses(B)
    assert set(k) == {C, D, E, G, H}
    k = get_all_subclasses(C)

# Generated at 2022-06-20 15:24:29.073845
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(E):
        pass

    class I(F):
        pass

    class J(F):
        pass

    class K(F):
        pass

    def check_result(cls, result):
        '''
        Check if the result is correct regarding the hierarchy described above
        '''
        assert(cls in result)
        assert((cls is K) or (K in result))
        assert((cls is J) or (J in result))
        assert((cls is I) or (I in result))

# Generated at 2022-06-20 15:24:39.205816
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a class hierarchy
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    # First check, no subclasses
    assert set(get_all_subclasses(A)) == {B, C}

    # Second check, no subclasses
    assert set(get_all_subclasses(C)) == set()

    # Third check
    assert set(get_all_subclasses(B)) == {D, E}
    assert set(get_all_subclasses(D)) == {E}
    assert set(get_all_subclasses(E)) == set()

# Generated at 2022-06-20 15:24:46.478981
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        def __init__(self):
            pass

    class B(A):
        def __init__(self):
            pass

    class C(A):
        def __init__(self):
            pass

    class D(C):
        def __init__(self):
            pass

    class E(C):
        def __init__(self):
            pass

    # Test 1: An array of class A
    assert(set([A, B, C, D, E]) == get_all_subclasses(A))

    # Test 2: An array of class C
    assert(set([C, D, E]) == get_all_subclasses(C))

    # Test 3: An array of class B
    assert(set([B]) == get_all_subclasses(B))

    # Test 4: An array

# Generated at 2022-06-20 15:24:57.636488
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import mock

    A = mock.Mock()
    A.__subclasses__.return_value = []
    B = mock.Mock()
    B.__subclasses__.return_value = [A]
    C = mock.Mock()
    C.__subclasses__.return_value = [B]
    D = mock.Mock()
    D.__subclasses__.return_value = [C]

    assert get_all_subclasses(D) == set([A, B, C, D])
    # This makes sure that A's __subclasses__ was only called once
    assert A.__subclasses__.call_count == 1

# Generated at 2022-06-20 15:25:01.918438
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    res = get_all_subclasses(A)
    assert len(res) == 4

    assert B in res
    assert C in res
    assert D in res
    assert E in res

# Generated at 2022-06-20 15:25:09.685485
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(A):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(C):
        pass
    class K(D):
        pass
    class L(G):
        pass

    assert set(get_all_subclasses(object)) == set([A, B, C, D, E, F, G, H, K, L])
    assert set(get_all_subclasses(A)) == set([C, D, E, F, G, H, K])
    assert set(get_all_subclasses(C)) == set([F, G, H, L])

# Generated at 2022-06-20 15:25:16.482313
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(E): pass
    class G(D): pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([D, G])
    assert get_all_subclasses(C) == set([E, F])
    assert get_all_subclasses(D) == set([G])
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set([])
    assert get_all_subclasses(G) == set([])

# Generated at 2022-06-20 15:25:20.655093
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    assert set(get_all_subclasses(A)) == set([B, D, C, E])

# Generated at 2022-06-20 15:25:27.386980
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class C1(C):
        pass

    class C2(C):
        pass

    class B1(B):
        pass

    class B2(B):
        pass

    subclasses = get_all_subclasses(A)

    assert B in subclasses
    assert C in subclasses
    assert B1 in subclasses
    assert B2 in subclasses
    assert C1 in subclasses
    assert C2 in subclasses
    assert len(subclasses) == 6

# Generated at 2022-06-20 15:25:35.532258
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F:
        pass

    class G(F):
        pass

    class H(G):
        pass


    result = get_all_subclasses(A)
    assert result == {B, C, D, E}

    result2 = get_all_subclasses(F)
    assert result2 == {G, H}

# Generated at 2022-06-20 15:25:46.470404
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function get_all_subclasses()
    '''
    import sys
    import argparse
    # Test 1: test __subclasses__() with one level of subclasses
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    assert get_all_subclasses(A) == {B, C}

    # Test 2: test __subclasses__() with two levels of subclasses
    class D:
        pass
    class E(D):
        pass
    class F(E):
        pass
    assert get_all_subclasses(D) == {E, F}

    # Test 3: test __subclasses__() with three levels of subclasses
    class G:
        pass
    class H(G):
        pass

# Generated at 2022-06-20 15:25:53.800279
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define some classes
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(object):
        pass

    class F(E):
        pass

    class G(F):
        pass

    class H(F):
        pass

    class I(H):
        pass

    class J(H):
        pass

    class K(J):
        pass

    class L(K):
        pass

    # Test the function using some test classes
    classes = get_all_subclasses(A)
    assert classes == {B, C, D}
    classes = get_all_subclasses(E)
    assert classes == {F, G, H, I, J, K, L}
    classes = get

# Generated at 2022-06-20 15:26:04.958064
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(D):
        pass
    class H(E):
        pass

    # All classes available
    all_classes = set([A, B, C, D, E, F, G, H])

    assert get_all_subclasses(A) == all_classes
    assert get_all_subclasses(B) == set([B, D, F, G])
    assert get_all_subclasses(C) == set([C, E, H])
    assert get_all_subclasses(D) == set([D, F, G])
    assert get_all_subclasses

# Generated at 2022-06-20 15:26:25.472892
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(F):
        pass
    class I(object):
        pass
    classes = get_all_subclasses(A)
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert G in classes
    assert H in classes
    assert I not in classes

# Generated at 2022-06-20 15:26:29.168034
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        """Class A"""
        pass

    class B(A):
        """Class B"""
        pass

    class C(A):
        """Class C"""
        pass

    all_subclasses = get_all_subclasses(A)

    assert B in all_subclasses
    assert C in all_subclasses

# Generated at 2022-06-20 15:26:39.454877
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class Test(object):
        pass

    assert get_all_subclasses(A) == set((B, C, D, E))
    assert get_all_subclasses(B) == set((D,))
    assert get_all_subclasses(C) == set((E,))
    assert get_all_subclasses(D) == set(())
    assert get_all_subclasses(E) == set(())
    assert get_all_subclasses(Test) == set(())


# Generated at 2022-06-20 15:26:42.813373
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a:
        pass

    class b(a):
        pass

    class c(a):
        pass

    class d(b):
        pass

    class e(b):
        pass

    class f(c):
        pass

    assert set(get_all_subclasses(a)) == set((b, c, d, e, f))



# Generated at 2022-06-20 15:26:53.878407
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for get_all_subclasses

    :rtype: bool
    :returns: True if test passes, False otherwise
    '''
    class A(object):
        pass
    class A1(A):
        pass
    class A2(A):
        pass
    class A1_1(A1):
        pass
    class A1_2(A1):
        pass
    class A2_1(A2):
        pass
    class B(object):
        pass
    class C(object):
        pass
    subclasses = get_all_subclasses(A)
    if not all(elem in [A, A1, A2, A1_1, A1_2, A2_1] for elem in subclasses):
        return False
    subclasses = get_all_

# Generated at 2022-06-20 15:27:04.840137
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F, G])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()
    assert get_all_subclasses(G) == set()

# Generated at 2022-06-20 15:27:10.673510
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    The following test is a good example to show how to use get_all_subclasses
    It works in python2 and python3 at the same time
    """
    import sys
    import pytest
    if sys.version_info[0] == 3:
        class A:
            pass

        class B(A):
            pass

        class C(A):
            pass

        class D(C):
            pass

# Generated at 2022-06-20 15:27:16.498884
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections
    import unittest

    class Person:
        pass

    class Parent(Person):
        pass

    class Child(Person):
        pass

    class GChild(Child):
        pass

    class GHGrandchild_1(GChild):
        pass

    class GHGrandchild_2(GChild):
        pass

    class Grandchild_3(Child):
        pass

    class Grandchild_4(Child):
        pass

    class Grandchild_5(Child):
        pass

    class NotRelated:
        pass


    # We expect the set of subclasses to have the following classes
    expected_subclasses = set([Parent, Child, GChild, GHGrandchild_1, GHGrandchild_2, Grandchild_3,
                              Grandchild_4, Grandchild_5])

    subclasses = get_all_subclasses

# Generated at 2022-06-20 15:27:26.139818
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Set up the test
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(D):
        pass

    # Call the function and test the results
    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, E, F])
    assert get_all_subclasses(D) == set([E, F])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-20 15:27:34.579001
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(B):
        pass

    class G(B):
        pass

    class H(E):
        pass

    class I(E):
        pass

    class J(G):
        pass

    class K(G):
        pass

    expected = {A, B, C, D, E, F, G, H, I, J, K}
    found = get_all_subclasses(A)

    assert found == expected

# Generated at 2022-06-20 15:28:07.267044
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass
    class G(E): pass
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert G in get_all_subclasses(A)
    assert E in get_all_subclasses(C)
    assert F in get_all_subclasses(C)
    assert G in get_all_subclasses(C)


# Generated at 2022-06-20 15:28:11.971633
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys
    import io

    # Create a fake class
    class A(object):
        def __init__(self):
            self.a = 'a'
    # Create a fake subclass
    class B(A):
        def __init__(self):
            self.b = 'b'
    # Create a fake sub-subclass
    class C(B):
        def __init__(self):
            self.c = 'c'

    # Test 1, verify that A and B are present
    classes = get_all_subclasses(A)
    assert(A in classes)
    assert(B in classes)
    assert(C in classes)
    # Test 2, verify that A.__subclasses__ is empty
    assert(A.__subclasses__() == [])
    # Test 3, verify that B.__subclasses

# Generated at 2022-06-20 15:28:20.055637
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define class A
    class A:
        pass

    # Define class B
    class B:
        pass

    # Define class C which inherits from class A
    class C(A):
        pass

    # Define class D which inherits from class B and C
    class D(B, C):
        pass

    # Define class E which inherits from classes B and C
    class E(B, C):
        pass

    assert get_all_subclasses(A) == {C}
    assert get_all_subclasses(B) == {D, E}

# Generated at 2022-06-20 15:28:25.739361
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Top:
        pass
    class A(Top):
        pass
    class B(Top):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(G):
        pass

    assert get_all_subclasses(Top) == set([A, B, C, D, E, F, G, H])

# Generated at 2022-06-20 15:28:32.006693
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D}
    assert set(get_all_subclasses(B)) == set()
    assert set(get_all_subclasses(C)) == {D}
    assert set(get_all_subclasses(D)) == set()

# Generated at 2022-06-20 15:28:38.439373
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(object):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, D, E])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set([])
    assert set(get_all_subclasses(D)) == set([E])
    assert set(get_all_subclasses(E)) == set([])



# Generated at 2022-06-20 15:28:48.939551
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B: pass
    class C: pass
    class D: pass
    class E(A): pass
    class F(A): pass
    class G(B,C): pass
    class H(C,D): pass
    class I(B,D): pass
    class J(E,F): pass
    class K(I,J): pass
    class L(G,H): pass
    class M(L,K): pass
    assert M.__mro__ == (M,L,K,G,I,J,E,F,B,H,C,D,A,object)
    assert not get_all_subclasses(M)
    assert set(get_all_subclasses(H)) == {L,K}
    assert set(get_all_subclasses(I)) == {K}

# Generated at 2022-06-20 15:28:59.417921
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections
    import ansible.parsing.dataloader

    # Since get_all_subclasses is recursive, we need to test with a recursive class
    class RecursiveClass(object):
        pass

    tmp = RecursiveClass()
    RecursiveClass.__bases__ = (tmp,)

    # The classes to expect are:
    # RecursiveClass
    # ansible.parsing.dataloader.DataLoader
    # ansible.parsing.dataloader.DataLoader (yes, this one again)
    classes_to_expect = set([RecursiveClass, ansible.parsing.dataloader.DataLoader])

    # Test get_all_subclasses
    subclasses = get_all_subclasses(RecursiveClass)
    assert isinstance(subclasses, collections.Set)
   

# Generated at 2022-06-20 15:29:05.040296
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(A):
        pass

    assert get_all_subclasses(A) == set([A, B, C, D, E])

# Generated at 2022-06-20 15:29:15.980813
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function to ensure that get_all_subclasses works as expected
    '''
    # Test given a class without subclasses
    testclass_a = type('TestClass_a', (object,), {})
    assert get_all_subclasses(testclass_a) == set()
    # Test given a class with one subclass
    testclass_b = type('TestClass_b', (testclass_a,), {})
    assert get_all_subclasses(testclass_a) == set([testclass_b])
    # Test given a class with two subclasses
    testclass_c = type('TestClass_c', (testclass_a,), {})
    assert get_all_subclasses(testclass_a) == set([testclass_b, testclass_c])
    # Test given a class with three sub

# Generated at 2022-06-20 15:30:21.054295
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Class with no subclasses
    """
    class A(object):
        pass

    assert get_all_subclasses(A) == set()

    """
    Class with one direct subclass
    """
    class B(A):
        pass

    assert get_all_subclasses(A) == set([B])

    """
    Class with one direct subclass and one subclass of this subclass
    """
    class C(B):
        pass

    assert get_all_subclasses(A) == set([B, C])

    """
    Class from which we don't want to look for subclasses
    """
    class D(object):
        pass

    assert get_all_subclasses(D) == set()

# Generated at 2022-06-20 15:30:27.044586
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a simple class tree
    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    # Verify that the tree is correctly retrieved
    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 6
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    # Test no duplicate
    assert len(set(subclasses)) == 6

# Generated at 2022-06-20 15:30:34.706156
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(F):
        pass

    class H(G):
        pass

    classes_set_1 = set([B, C, D, E, F, G, H])
    classes_set_2 = get_all_subclasses(A)
    assert len(classes_set_1) == len(classes_set_2)
    assert classes_set_1 == classes_set_2

