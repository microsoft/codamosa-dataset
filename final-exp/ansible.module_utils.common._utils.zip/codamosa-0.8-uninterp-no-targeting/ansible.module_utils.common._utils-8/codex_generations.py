

# Generated at 2022-06-20 15:20:45.803874
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    #create a simple inheritance tree
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(object):
        pass
    class E(D):
        pass
    class F(C, E):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A) #direct subclass of A
    assert C in get_all_subclasses(A) #indirect subclass of A
    assert D in get_all_subclasses(A) #not related to A
    assert E in get_all_subclasses(A) #not related to A
    assert F in get_all_subclasses(A) #related to A
    assert F in get_all_subclasses(B)
    assert D in get_

# Generated at 2022-06-20 15:20:47.467443
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.plugins.action import ActionBase

    assert ActionBase in get_all_subclasses(ActionBase)

# Generated at 2022-06-20 15:20:58.440840
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(E,C):
        pass
    class G(E,C):
        pass
    class H(G):
        pass
    # Classes B, C, D, E, F, G, H are subclasses of A
    assert {B,C,D,E,F,G,H} == get_all_subclasses(A)
    # Classes C, F, G, H are subclasses of A
    assert {C,F,G,H} == get_all_subclasses(B)
    # Classes F, H are subclasses of C

# Generated at 2022-06-20 15:21:06.430391
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(C): pass
    class H(G): pass

    classes = get_all_subclasses(A)
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert G in classes
    assert H in classes
    assert len(classes) == 7

    classes = get_all_subclasses(B)
    assert D in classes
    assert E in classes
    assert len(classes) == 2

# Generated at 2022-06-20 15:21:16.326767
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(F, D):
        pass
    subclasses_A = get_all_subclasses(A)
    assert set(subclasses_A) == set([B, C, D, E, F, G])

    class H(G):
        pass
    class I(H):
        pass
    class J(H):
        pass
    subclasses_G = get_all_subclasses(G)
    assert set(subclasses_G) == set([H, I, J])

# Generated at 2022-06-20 15:21:25.445353
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A:
        """
        Class A, parent class.
        """
        pass

    class B(A):
        """
        Class B, subclass A.
        """
        pass

    class C(B):
        """
        Class C, subclass B.
        """
        pass

    class D(A):
        """
        Class D, subclass A.
        """
        pass

    class E(D):
        """
        Class E, subclass D.
        """
        pass

    A_subclasses = get_all_subclasses(A)
    assert C in A_subclasses
    assert B in A_subclasses
    assert E in A_subclasses
    assert D in A_subclasses
    assert A not in A_subclasses

__all__ = ('get_all_subclasses')

# Generated at 2022-06-20 15:21:32.102350
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Create a simple class structure with a base class, a child class, and a child class's child class.
    Create a set of all of the descendent classes and ensure that it matches what the function
    :func:`get_all_subclasses` returns.
    """
    class Top(object):
        pass

    class Middle(Top):
        pass

    class Bottom(Middle):
        pass

    expected = set([Bottom, Middle])
    result = get_all_subclasses(Top)
    assert(expected == result)

# Generated at 2022-06-20 15:21:45.141387
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(object):
        pass

    class G(B, C, E):
        pass

    class H(B, F):
        pass

    class I(B, F):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert G in get_all_subclasses(A)
    assert H in get_all_subclasses(A)
    assert I

# Generated at 2022-06-20 15:21:49.538813
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestClass(object):
        def __init__(self, identifier):
            self.identifier = identifier

    class A(TestClass):
        def __init__(self):
            super(A, self).__init__(1)

    class B(TestClass):
        def __init__(self):
            super(B, self).__init__(2)

    class C(A):
        def __init__(self):
            super(C, self).__init__()

    class D(B):
        def __init__(self):
            super(D, self).__init__()

    class E(A):
        def __init__(self):
            super(E, self).__init__()

    class F(E):
        def __init__(self):
            super(F, self).__init__

# Generated at 2022-06-20 15:21:55.698122
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
        class A:
            pass
        class B(A):
            pass
        class C(A):
            pass
        class D(B):
            pass
        class E(C):
            pass
        class F(D, E):
            pass
        class G:  # not a subclass of A
            pass
        print(get_all_subclasses(A))
    """
    class A:
            pass
    class B(A):
            pass
    class C(A):
            pass
    class D(B):
            pass
    class E(C):
            pass
    class F(D, E):
            pass
    class G:  # not a subclass of A
            pass
    assert(set(get_all_subclasses(A)) == set([B, C, D, E, F]))

# Generated at 2022-06-20 15:22:08.253859
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    ''' test function get_all_subclasses '''
    class Foo:
        pass

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    class Fun(Bar):
        pass

    class Faz(Baz):
        pass

    descendents = get_all_subclasses(Foo)
    assert descendents == set([Bar, Baz, Fun, Faz])

    descendents = get_all_subclasses(Baz)
    assert descendents == set([Faz])

    descendents = get_all_subclasses(Bar)
    assert descendents == set([Fun])

    descendents = get_all_subclasses(Fun)
    assert descendents == set()

# Generated at 2022-06-20 15:22:18.885640
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Grandpa(object):
        pass

    class Father1(Grandpa):
        pass

    class Father2(Grandpa):
        pass

    class Uncle1(Father1):
        pass

    class Uncle2(Father1):
        pass

    class Son1(Father2):
        pass

    class Son2(Father2):
        pass

    class Grandson1(Son1):
        pass

    class Grandson2(Son1):
        pass

    assert Grandpa in get_all_subclasses(Grandpa)

    assert Father1 in get_all_subclasses(Grandpa)
    assert Father1 in get_all_subclasses(Father1)

    assert Father2 in get_all_subclasses(Grandpa)
    assert Father2 in get_all_subclasses(Father2)

    assert Uncle1 in get_all_sub

# Generated at 2022-06-20 15:22:23.079211
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-20 15:22:31.812680
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass
    class G(D):
        pass
    class H(G):
        pass
    class I(G):
        pass

    # Test A
    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 8
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in subclasses
    assert H in subclasses
    assert I in subclasses

    # Test B
    subclasses = get_all_subclasses(B)

# Generated at 2022-06-20 15:22:36.819130
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''Unit test for function get_all_subclasses'''
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    classes = get_all_subclasses(A)
    assert isinstance(classes, set)
    assert len(classes) == 3
    assert B in classes
    assert C in classes
    assert D in classes

# Generated at 2022-06-20 15:22:42.400953
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B: pass
    class C(A): pass
    class D(B): pass
    class E(C): pass

    assert get_all_subclasses(A) == {C, E}
    assert get_all_subclasses(B) == {D}
    assert get_all_subclasses(C) == {E}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()


# Generated at 2022-06-20 15:22:51.501954
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(D):
        pass
    class H(F):
        pass
    class I(F):
        pass
    def check_get_all_subclasses(cls, expected):
        subclasses = get_all_subclasses(cls)
        assert subclasses == set(expected)
    # Checking all cases
    check_get_all_subclasses(A, [C, E])
    check_get_all_subclasses(B, [D, F, G, H, I])
    check_get_all_subclasses(C, [E])

# Generated at 2022-06-20 15:23:00.471366
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class Test1:
        pass

    class Test11(Test1):
        pass

    class Test12(Test1):
        pass

    class Test111(Test11):
        pass

    class Test112(Test11):
        pass

    class Test121(Test12):
        pass

    class Test122(Test12):
        pass

    res = get_all_subclasses(Test1)
    assert Test1 in res
    assert Test11 in res
    assert Test12 in res
    assert Test111 in res
    assert Test112 in res
    assert Test121 in res
    assert Test122 in res



# Generated at 2022-06-20 15:23:08.037716
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(object):
        pass

    class G(F):
        pass

    class H(G):
        pass

    class I(G):
        pass

    result = get_all_subclasses(A)
    assert(B in result)
    assert(C in result)
    assert(D in result)
    assert(E in result)
    assert(F not in result)
    assert(G not in result)
    assert(H not in result)
    assert(I not in result)

# Generated at 2022-06-20 15:23:17.222748
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)

    assert A in get_all_subclasses(B)
    assert C in get_all_subclasses(B)
    assert D in get_all_subclasses(B)

    assert A in get_all_subclasses(C)
    assert D in get_all_subclasses(C)

# Generated at 2022-06-20 15:23:29.576133
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(C): pass
    class E(B): pass
    class F(object): pass
    assert get_all_subclasses(A) == set([C, D])
    assert get_all_subclasses(B) == set([E])
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-20 15:23:33.144691
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set() == set(get_all_subclasses(E))



# Generated at 2022-06-20 15:23:36.716507
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    assert get_all_subclasses(A) == set([B, C, D, E])



# Generated at 2022-06-20 15:23:44.656569
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E():
        pass
    class F(E):
        pass

    assert get_all_subclasses(A) == {B, C, D}
    assert get_all_subclasses(B) == {C, D}
    assert get_all_subclasses(C) == {D}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == {F}
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-20 15:23:54.369899
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Defining a class hierarchy
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(G):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set([F, G, H])
    assert set(get_all_subclasses(D)) == set()
    assert set(get_all_subclasses(E)) == set()

# Generated at 2022-06-20 15:24:02.697898
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(object):
        pass

    subclasses = get_all_subclasses(A)
    assert subclasses == set([B, C, D, E])
    subclasses = get_all_subclasses(C)
    assert subclasses == set([E])
    subclasses = get_all_subclasses(F)
    assert subclasses == set([])

# Generated at 2022-06-20 15:24:10.011242
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(B):
        pass
    res = get_all_subclasses(A)
    for cls_ in (B, C, D, E, F):
        assert cls_ in res, "%s not in %s" % (cls_, res)
    assert len(res) == 5, "Size should be 5, had %d" % len(res)



# Generated at 2022-06-20 15:24:17.723926
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(object):
        pass

    assert set([B, C, D]) == get_all_subclasses(A)
    assert set([C]) == get_all_subclasses(B)
    assert set() == get_all_subclasses(C)
    assert set() == get_all_subclasses(D)
    assert set() == get_all_subclasses(E)


# Generated at 2022-06-20 15:24:27.662145
# Unit test for function get_all_subclasses

# Generated at 2022-06-20 15:24:32.031816
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(B): pass

    assert set([B, C, D, E]) == get_all_subclasses(A)



# Generated at 2022-06-20 15:24:51.770162
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils.six import with_metaclass
    from ansible.module_utils._text import to_native

    class Meta(type):
        pass

    class Base(with_metaclass(Meta)):
        pass

    class Sub1(Base):
        pass

    class Sub2(Base):
        pass

    class Sub3(Sub1):
        pass

    class Sub4(Sub3):
        pass

    try:
        super_classes = get_all_subclasses(Base)
        assert Sub1 in super_classes
        assert Sub2 in super_classes
        assert Sub3 in super_classes
        assert Sub4 in super_classes
        assert len(super_classes) == 4
    except Exception as e:
        raise AssertionError(to_native(e))

# Generated at 2022-06-20 15:25:02.089640
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class Aa(A):
        pass
    class Ab(A):
        pass
    class Aba(Ab):
        pass
    class Abb(Ab):
        pass
    class B(object):
        pass
    class Ba(B):
        pass

    assert get_all_subclasses(object) == set([
        A, Ab, Aa, Abb, Aba, B, Ba
    ])
    assert get_all_subclasses(A) == set([
        Aa, Ab, Abb, Aba
    ])
    assert get_all_subclasses(B) == set([
        Ba
    ])
    assert get_all_subclasses(Aa) == set()
    assert get_all_subclasses(Abb) == set()

# Generated at 2022-06-20 15:25:05.741951
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E:
        pass

    result = get_all_subclasses(A)
    assert len(result) == 3
    assert B in result
    assert C in result
    assert D in result

# Generated at 2022-06-20 15:25:14.692458
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(G):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F, G, H])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()
    assert get_all

# Generated at 2022-06-20 15:25:19.709047
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    # Ensure that all direct subclasses of A are returned
    assert set(get_all_subclasses(A)) == set([B, C, D, E])

# Generated at 2022-06-20 15:25:28.323852
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Example of testing and using get_all_subclasses
    from ansible.module_utils._text import to_text

    # initial class
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass

    A.__repr__ = to_text
    B.__repr__ = to_text
    C.__repr__ = to_text
    D.__repr__ = to_text
    E.__repr__ = to_text
    # Subclasses of A
    assert get_all_subclasses(A) == set([B, C, D, E])

    # Subclasses of B
    assert get_all_subclasses(B) == set([D, E])

# Generated at 2022-06-20 15:25:34.820519
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(object):
        pass

    results = get_all_subclasses(A)

    # Test
    assert A in results
    assert B in results
    assert C in results
    assert D in results
    assert E not in results



# Generated at 2022-06-20 15:25:39.870056
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(B):
        pass
    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses

# Generated at 2022-06-20 15:25:48.331955
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a simple mockup to test get_all_subclasses
    class Base:
        pass

    class A(Base):
        pass

    class B(Base):
        pass

    class AB(A, B):
        pass

    class BA(B, A):
        pass

    class C(AB):
        pass

    # Declare the expected results
    expected = set([A, AB, BA, B, Base, C])

    # Retrieve all classes from Base class and their subclasses
    result = get_all_subclasses(Base)

    # Check if expected == result
    assert(expected == result)

# Generated at 2022-06-20 15:25:52.335598
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([])

# Generated at 2022-06-20 15:26:21.760696
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define test classes
    class Dummy: pass
    class A: pass
    class B: pass
    class B1(B): pass
    class B2(B): pass
    class C(Dummy): pass                                                    # The function will only return direct subclasses of class Dummy
    class C1(C): pass                                                       # So class C1 will not be returned
    class C11(C1): pass
    class C12(C1): pass
    class C2(C): pass
    class C21(C2): pass
    class C22(C2): pass
    class D(Dummy): pass
    class D1(D): pass
    class D11(D1): pass
    class D12(D1): pass
    class D2(D): pass
    class D21(D2): pass

# Generated at 2022-06-20 15:26:31.037737
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import defaultdict

    class Parent1(object): pass
    class Parent2(object): pass
    class Parent3(object): pass
    class Child1(Parent1): pass
    class Child2(Parent1): pass
    class Child3(Parent3): pass
    class Grandchild(Child1, Parent2): pass

    expected_classes = {Parent1: {Child1, Child2},
                        Parent2: {Grandchild},
                        Parent3: {Child3}}

    for parent in get_all_subclasses(object):
        assert parent in expected_classes
        assert parent in get_all_subclasses(parent)
        for child in expected_classes[parent]:
            assert child in get_all_subclasses(parent)
            assert child in get_all_subclasses(child)

# Generated at 2022-06-20 15:26:35.874607
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E])

# Generated at 2022-06-20 15:26:40.368244
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass

    output = get_all_subclasses(A)
    expected = set([B, C, D, E, F])
    assert output == expected

# Generated at 2022-06-20 15:26:45.232494
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B:
        pass
    class C(A):
        pass
    class D(B, A):
        pass
    class E(C, D):
        pass
    classes = get_all_subclasses(A)
    assert classes == set([C, D, E])

# Generated at 2022-06-20 15:26:55.813229
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action import ActionModule
    from ansible.plugins.action.copy import ActionModule as CopyActionModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves.urllib.request import Request
    from ansible.module_utils.connection import ConnectionBase
    from ansible.module_utils.connection.netconf import Connection as NetconfConnection

    assert(not set(ActionBase.__subclasses__()).difference(set(get_all_subclasses(ActionBase))))
    assert(not set(AnsibleModule.__subclasses__()).difference(set(get_all_subclasses(AnsibleModule))))
    assert(CopyActionModule in set(get_all_subclasses(ActionModule)))


# Generated at 2022-06-20 15:27:03.889091
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(object):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E not in subclasses

    subclasses = get_all_subclasses(B)
    assert C in subclasses
    assert D in subclasses
    assert E not in subclasses

# Generated at 2022-06-20 15:27:12.834390
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    def _check_list_is_same(a, b):
        for a_item in a:
            if a_item not in b:
                return False
        return True

    # Custom class
    class A(object):
        pass

    # Retrieve direct subclasses
    class B(A):
        pass

    class C(A):
        pass

    assert _check_list_is_same(
        [B, C],
        get_all_subclasses(A)
    ) == True

    # Then visit all subclasses
    class D(B):
        pass

    class E(B):
        pass

    assert _check_list_is_same(
        [D, E],
        get_all_subclasses(B)
    ) == True

# Generated at 2022-06-20 15:27:24.313251
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''

    class Foo(object):
        pass

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    class Doo(Bar):
        pass

    class Hoo(Doo):
        pass

    class Boo(Bar):
        pass

    class Xoo(Boo):
        pass

    class Yoo(Boo):
        pass

    # test with a simple hierarchy
    ret = get_all_subclasses(Foo)
    assert ret == {Bar, Baz, Doo, Hoo, Boo, Xoo, Yoo}

    # test with another hierarchy
    class Foo2(object):
        pass

    class Bar2(Foo2):
        pass

    class Baz2(Bar2):
        pass


# Generated at 2022-06-20 15:27:34.219124
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import ansible.module_utils.basic

    # get_all_subclasses return a set
    # So it could be used with assertEqual
    # If a new basic module is added, this test should be updated
    assertEqual(set(ansible.module_utils.basic.get_all_subclasses(ansible.module_utils.basic.AnsibleModule)),
                {ansible.module_utils.basic.AnsibleModuleHelper,
                 ansible.module_utils.basic.AnsibleModule,
                 ansible.module_utils.basic.AnsibleModule_Utils,
                 ansible.module_utils.basic.AnsibleModule_Utils_Common})


# Generated at 2022-06-20 15:28:17.700396
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a class
    class A(object):
        pass

    # Define child classes
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass

    # Checking that class A has the correct child classes
    subclasses = get_all_subclasses(A)
    assert set([B, C, D]) == set(subclasses)

# Generated at 2022-06-20 15:28:26.170580
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(object):
        pass
    class G(object):
        pass
    class H(G):
        pass

    assert get_all_subclasses(A) == set((B, C, D, E))

    # This confirms that each class is a unique set
    assert get_all_subclasses(F) == get_all_subclasses(G) == set()

    assert get_all_subclasses(G) == set((H,))

# Generated at 2022-06-20 15:28:35.840479
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import defaultdict
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(object):
        pass
    class F(D):
        pass
    class G(F):
        pass
    all_cls = defaultdict(list)
    all_cls['A'] = [A, B, C, D, F, G]
    all_cls['B'] = [B, D, F, G]
    all_cls['C'] = [C]
    all_cls['D'] = [D, F, G]
    all_cls['E'] = [E]
    # Check
    for cls, expected in all_cls.items():
        assert get_all_

# Generated at 2022-06-20 15:28:41.314742
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class CC(A):
        pass
    class D(CC):
        pass
    assert get_all_subclasses(A) == set([B, CC, D])

# Generated at 2022-06-20 15:28:48.515116
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test class definitions
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass

    # Test
    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == {D, E}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-20 15:28:59.111947
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Animal():
        pass

    class Mammal(Animal):
        pass

    class Dog(Mammal):
        pass

    class Cat(Mammal):
        pass

    class Amphibian(Animal):
        pass

    class Frog(Amphibian):
        pass

    class Fish(Amphibian):
        pass

    # returns all the subclasses of Animal
    assert(get_all_subclasses(Animal) == set([Mammal, Amphibian, Dog, Cat, Frog, Fish]))
    # returns all the subclasses of Mammal
    assert(get_all_subclasses(Mammal) == set([Dog, Cat]))
    # returns all the subclasses of Amphibian
    assert(get_all_subclasses(Amphibian) == set([Frog, Fish]))


# Generated at 2022-06-20 15:29:07.576763
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E, B):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D, E, F}
    assert set(get_all_subclasses(C)) == {E, F}
    assert set(get_all_subclasses(E)) == {F}

# Generated at 2022-06-20 15:29:18.114833
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(C):
        pass

    class G(F):
        pass

    class TestGetSubclasses(unittest.TestCase):
        def test_get_subclasses(self):
            # Testing that, when we call get_all_subclasses on A, we get B, C, D, E, and F.
            expected_subclasses = set([B, C, D, E, F, G])
            actual_subclasses = set(get_all_subclasses(A))
            self.assertEqual(expected_subclasses, actual_subclasses)

# Generated at 2022-06-20 15:29:25.566590
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test the get_all_subclasses utility function

    '''
    class A():
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E():
        pass

    class F(A):
        pass

    class G(A):
        pass

    class H(A):
        pass

    class I(F):
        pass

    class J(G):
        pass

    class K(G):
        pass

    class L(H):
        pass

    class M(I):
        pass

    assert get_all_subclasses(A) == set([B, C, D, F, G, H, I, J, K, L, M])

# Generated at 2022-06-20 15:29:30.473097
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Class tree for this test
    #     Root
    #      |
    #       -- Parent
    #            |
    #             --Child -- ChildOfChild
    #            |
    #             -- ChildOfParent
    class Root():pass
    class Parent(Root): p