

# Generated at 2022-06-20 15:20:44.788810
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(object):
        pass

    class D(C):
        pass

    class E(B, C):
        pass

    class G(A):
        pass

    class H(D):
        pass

    assert set([B, D, E, G, H]) == get_all_subclasses(A)

    assert set([E]) == get_all_subclasses(B)

    assert set([D, H]) == get_all_subclasses(D)

    assert set([E]) == get_all_subclasses(C)


# Generated at 2022-06-20 15:20:54.974056
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(object): pass
    class E(B): pass
    class F(C): pass
    class G(D): pass
    all_subclasses = get_all_subclasses(object)
    assert set(all_subclasses) == {A, B, C, D, E, F, G}
    all_subclasses = get_all_subclasses(A)
    assert set(all_subclasses) == {B, C, E, F}
    all_subclasses = get_all_subclasses(C)
    assert set(all_subclasses) == {F}
    all_subclasses = get_all_subclasses(D)
    assert set(all_subclasses) == {G}

# Generated at 2022-06-20 15:20:57.551293
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(C): pass
    class E(D): pass
    class F(A): pass
    class G(F): pass
    class H(A): pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])

# Generated at 2022-06-20 15:21:00.227978
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class B(object):
        pass

    class C(B):
        pass
    assert get_all_subclasses(B) == set([C])

# Generated at 2022-06-20 15:21:06.946905
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(D): pass
    # direct subclasses
    assert C in B.__subclasses__()
    assert B in A.__subclasses__()
    # subclass of subclass
    assert C in A.__subclasses__()
    # Not direct subclasses
    assert C not in A.__subclasses__()
    assert B not in C.__subclasses__()
    # Variables created in the scope of a function are local
    # to the function.  This creates a new scope.  However,
    # from the perspective of this function, the A, B, C
    # and D classes are not defined.  We need to use the
    # types module to get a reference to the classes

# Generated at 2022-06-20 15:21:15.336675
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Creating 2 dummy classes
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(E):
        pass
    class H(G):
        pass
    class I(G):
        pass

    expected = set([B, C, D, E, F, G, H, I])
    computed = get_all_subclasses(A)
    assert computed == expected

# Generated at 2022-06-20 15:21:23.279759
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(E):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F, G}
    assert get_all_subclasses(G) == {G}



# Generated at 2022-06-20 15:21:30.868731
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(E):
        pass

    class I(F):
        pass

    class J(G):
        pass

    assert set(get_all_subclasses(A)) == set((B, C, D, E, F, G, H, I, J))

# Generated at 2022-06-20 15:21:34.046463
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    # Assert that the function returns the right classes
    assert get_all_subclasses(A) == set([B, C, D])

# Generated at 2022-06-20 15:21:37.464171
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class AA(object):
        pass
    class BB(AA):
        pass
    class CC(BB):
        pass
    class DD(AA):
        pass
    ret_set = get_all_subclasses(AA)
    test_set = {BB, CC, DD}
    assert ret_set == test_set