

# Generated at 2022-06-20 15:20:46.911337
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # First, if empty class
    class Root(object):
        pass

    # Then, all derived class
    class A(Root):
        pass

    class B(A):
        pass

    class C(Root):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(F):
        pass

    root = Root()
    a = A()
    b = B()
    c = C()
    d = D()
    e = E()
    f = F()
    g = G()

    assert get_all_subclasses(Root) == {A, B, C, D, E, F, G}
    assert get_all_subclasses(A) == {B}
    assert get_all_subclasses(B)

# Generated at 2022-06-20 15:20:55.753865
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    assert set(get_all_subclasses(A)) == set([B, C])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set(get_all_subclasses(C)) == set()

    C_1 = C()
    D_1 = D()
    E_1 = E()

    assert set(get_all_subclasses(A)) == set([B, C])
    assert set(get_all_subclasses(B)) == set([D, E])
    assert set

# Generated at 2022-06-20 15:21:00.356757
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        def __init__(self): pass
    class B(A):
        def __init__(self): pass
    class C(A):
        def __init__(self): pass
    class D(B):
        def __init__(self): pass
    class E(D):
        def __init__(self): pass
    class F(A):
        def __init__(self): pass
    assert get_all_subclasses(A) == set([B, C, E, D, F])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(E) == set([])


# Generated at 2022-06-20 15:21:06.000697
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(A):
        pass

    class F(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])


# Generated at 2022-06-20 15:21:16.542376
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test the get_all_subclasses function

    This function is heavily dependent on creating multiple classes in a class hierarchy.  However,
    python's classes are executed when they are imported.  This means that when this unit test is
    run, all of the classes come already into existence, and they are already part of the hierarchy
    that get_all_subclasses checks.

    Rather than creating a custom hierarchy and trying to create the classes in an isolated way,
    this unit test creates a throwaway class hierarchy, verifies that it is correct, and then
    throws it away at the end.
    '''

    # Create a throwaway class hierarchy
    class X: pass
    def make_y_class(name):
        class Y(X): pass
        Y.name = name
        return Y

    # Create a bunch of classes and add them to the hierarchy


# Generated at 2022-06-20 15:21:25.549868
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    classes = [A,B,C,D,E,F,G,H,I,J,K,L,M,N,O]

# Generated at 2022-06-20 15:21:33.012410
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G:
        pass
    class H(G):
        pass

    all_sub = get_all_subclasses(A)
    # use str(class) to filter the address of class object
    assert(set(['B', 'D', 'E', 'C', 'F']) == set(str(x) for x in all_sub))

# Generated at 2022-06-20 15:21:43.249165
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        def __init__(self):
            self.name = 'A'
    class B(A):
        def __init__(self):
            self.name = 'B'
    class C(A):
        def __init__(self):
            self.name = 'C'
    class D(B):
        def __init__(self):
            self.name = 'D'
    class E(B):
        def __init__(self):
            self.name = 'E'
    class F(C):
        def __init__(self):
            self.name = 'F'
    class G(C):
        def __init__(self):
            self.name = 'G'
    class H(D):
        def __init__(self):
            self

# Generated at 2022-06-20 15:21:46.974054
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass
    classes = get_all_subclasses(A)
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert A not in classes
    # Verify that the set is not modified in the future
    assert len(classes) == 5

# Generated at 2022-06-20 15:21:54.530539
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert set([B, D]) == get_all_subclasses(A)
    assert set([D]) == get_all_subclasses(B)
    assert set([]) == get_all_subclasses(C)
    assert set([]) == get_all_subclasses(D)
    assert set([B, C, D]) == get_all_subclasses(object)

# Generated at 2022-06-20 15:22:06.484713
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Defining a class A
    class A(object):
        pass

    # Defining a class B which is a subclass of A
    class B(A):
        pass

    # Defining a class C which is a subclass of B
    class C(B):
        pass

    # Defining a class D which is a subclass of A
    class D(A):
        pass

    # Defining a class E which is a subclass of D
    class E(D):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses

# Generated at 2022-06-20 15:22:10.562592
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(E):
        pass

    classes = get_all_subclasses(A)
    assert set(classes) == set((B, D, C, E, F))

    classes = get_all_subclasses(E)
    assert set(classes) == set((F,))

# Generated at 2022-06-20 15:22:20.264674
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test class
    class A(object):
        pass
    # Test subclasses
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass

    # Test

# Generated at 2022-06-20 15:22:27.292394
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test that the method get_all_subclasses retrieve the expected classes
    '''
    class A(object):
        pass
    class B(object):
        pass
    class C(object):
        pass
    # First test of classic util
    class D(A):
        pass
    class E(A):
        pass
    class F(D):
        pass
    class G(B, D):
        pass
    assert get_all_subclasses(A) == set([D, E, F, G])

    # Adding multiple inheritance
    class H(C, D):
        pass
    assert get_all_subclasses(A) == set([D, E, F, G, H])

# Generated at 2022-06-20 15:22:36.904523
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Ensure the function get_all_subclasses retrieves all subclasses recursively
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(D):
        pass

    # List of object to test
    sub_classes = {B, C, D, E, F, G}

    assert sub_classes == get_all_subclasses(A)


# Generated at 2022-06-20 15:22:41.350244
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-20 15:22:47.642050
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class SuperClass(object):
        pass

    class SubClass1(SuperClass):
        pass

    class SubSubClass1(SubClass1):
        pass

    class SubSubClass2(SubClass1):
        pass

    class SubClass2(SuperClass):
        pass

    expected = set([SubClass1, SubSubClass1, SubSubClass2])
    actual = get_all_subclasses(SuperClass)
    assert expected == actual

# Generated at 2022-06-20 15:22:53.053133
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    assert get_all_subclasses(A) == set([B, C, D, E, F])

# Generated at 2022-06-20 15:23:02.489106
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a simple class hierarchy
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    expected_classes = set([B, D, C, E, F])
    # Compare expected classes with those from the method
    cls = A
    observation = get_all_subclasses(cls)
    for sc in observation:
        assert sc in expected_classes
    for sc in expected_classes:
        assert sc in observation
    assert len(observation) == len(expected_classes)


# Generated at 2022-06-20 15:23:09.800656
# Unit test for function get_all_subclasses

# Generated at 2022-06-20 15:23:24.900971
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class ClsA(object):
        pass

    class ClsB(ClsA):
        pass

    class ClsC(ClsB):
        pass

    class ClsD(object):
        pass

    class ClsE(object):
        pass

    class ClsF(ClsE):
        pass

    class ClsG(ClsE):
        pass

    assert_equal(get_all_subclasses(ClsA), set([ClsB, ClsC]))
    assert_equal(get_all_subclasses(ClsB), set([ClsC]))
    assert_equal(get_all_subclasses(ClsD), set([]))
    assert_equal(get_all_subclasses(ClsE), set([ClsF, ClsG]))

# Generated at 2022-06-20 15:23:33.158936
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This function tests the method get_all_subclasses
    '''
    classes_list = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']

    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(B):
        pass

    class G(B):
        pass

    class H(C):
        pass

    classes = get_all_subclasses(A)

    for cls in classes:
        assert cls.__name__ in classes_list

    assert len(classes) == len(classes_list)


# Generated at 2022-06-20 15:23:42.623476
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(F):
        pass

    class I(G):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G, H, I])

    assert set(get_all_subclasses(B)) == set([D, E])

    assert set(get_all_subclasses(C)) == set([F, G, H, I])

    assert set(get_all_subclasses(H)) == set([])

# Generated at 2022-06-20 15:23:50.273016
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(A):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(F):
        pass

    assert set([B, C, D, E, F, G, H]) == get_all_subclasses(A)
    assert set([C, D]) == get_all_subclasses(B)
    assert set([H, G]) == get_all_subclasses(E)

# Generated at 2022-06-20 15:23:57.664079
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass

    # The list of classes should be equal to the following
    test_list = [B, D, C, E]

    # Instantiate the class we're going to check
    a = A()
    subclasses = get_all_subclasses(a.__class__)
    # If a is not a subclass of A, the list should be empty
    if not a.__class__ in subclasses:
        if len(subclasses) > 0:
            raise AssertionError('B is a subclass of A')

    # List of subclasses should now include B, D, C and E

# Generated at 2022-06-20 15:24:09.127918
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import test_test_utils

    class Root(object):
        pass

    class A(Root):
        pass

    class B(Root):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(B):
        pass
    
    root_subclasses = set([A, B])
    a_subclasses = set([C, D])
    b_subclasses = set([E])
    c_subclasses = set([])
    d_subclasses = set([])
    e_subclasses = set([])


    def check_subclasses(in_class, expected):
        assert(get_all_subclasses(in_class) == expected)


# Generated at 2022-06-20 15:24:20.512554
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    assert list(sorted(str(c.__name__) for c in get_all_subclasses(A))) == ['B', 'C', 'D', 'E']

    class F(object):
        pass

    class G(F):
        pass

    class H(object):
        pass

    class I(H):
        pass

    assert list(sorted(str(c.__name__) for c in get_all_subclasses(F))) == ['G']

    assert list(sorted(str(c.__name__) for c in get_all_subclasses(H))) == ['I']

# Generated at 2022-06-20 15:24:29.107288
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    a_subclasses = get_all_subclasses(A)
    assert(B in a_subclasses)
    assert(C in a_subclasses)
    assert(D in a_subclasses)
    assert(E in a_subclasses)
    assert(F in a_subclasses)
    assert(len(a_subclasses) == 5)
    b_subclasses = get_all_subclasses(B)
    assert(D in b_subclasses)
    assert(len(b_subclasses) == 1)

# Generated at 2022-06-20 15:24:40.317618
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(B, D):
        pass

    class G(object):
        pass

    class H(D):
        pass

    class I(E):
        pass

    class J(F):
        pass

    class K(H):
        pass

    class L(H, B):
        pass

    # Different class with the same hierarchy
    class M(object):
        pass

    class N(M):
        pass

    class O(N):
        pass

    class P(O):
        pass

    class Q(O):
        pass

    class R(P):
        pass


# Generated at 2022-06-20 15:24:49.197476
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """Unit test for get_all_subclasses"""
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(A):
        pass

    class F(E):
        pass

    class H(object):
        pass

    class I(H):
        pass

    class G(F, I):
        pass

    class J(object):
        pass

    class K(A, J):
        pass

    # Verify that we can find all of the classes in the hierarchy
    tester = unittest.TestCase('__init__')
    subclasses = get_all_subclasses(A)
    tester.assertIn(B, subclasses)

# Generated at 2022-06-20 15:25:05.764873
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([E, F])
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-20 15:25:14.722093
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set()
    # Add C in B subclass to check D is still here
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C)

# Generated at 2022-06-20 15:25:20.480886
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses

# Generated at 2022-06-20 15:25:29.146217
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Sequence
    from types import MethodType
    from inspect import isclass

    class SuperClass(object):
        def someMethod(self):
            return ",".join(str(e) for e in self)

    class SubClass(SuperClass, Sequence):
        def __init__(self, seq=()):
            self.seq = seq

        def __len__(self):
            return len(self.seq)

        def __getitem__(self, n):
            return self.seq[n]

        def __repr__(self):
            return "SubClass(%s)" % self.seq

    assert(isclass(SuperClass) and isclass(SubClass))

    subClassList = get_all_subclasses(SuperClass)
    assert(len(subClassList) == 1)

# Generated at 2022-06-20 15:25:40.722505
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    a = A()
    b = B()
    c = C()
    d = D()
    e = E()

    # Check of number of subclasses
    assert len(get_all_subclasses(A)) == 4
    assert len(get_all_subclasses(B)) == 2
    assert len(get_all_subclasses(C)) == 0
    assert len(get_all_subclasses(D)) == 1
    assert len(get_all_subclasses(E)) == 0

    # Check if result is not changing
    assert len(get_all_subclasses(A)) == 4

# Generated at 2022-06-20 15:25:45.716309
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}

# Generated at 2022-06-20 15:25:48.985170
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    >>> class A(object):
    ...     pass
    ...
    >>> class B(A):
    ...     pass
    ...
    >>> class C(A):
    ...     pass
    ...
    >>> class D(B):
    ...     pass
    ...
    >>>
    >>> assert set(get_all_subclasses(A)) == set([B, C, D])
    >>> assert set(get_all_subclasses(B)) == set([D])
    >>> assert set(get_all_subclasses(D)) == set([])
    '''

# Generated at 2022-06-20 15:25:56.521018
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Iterable

    class a(object):
        pass

    class b(a):
        pass

    class c(b):
        pass

    class d(a):
        pass

    class e(d):
        pass

    class f(c, d):
        pass

    assert isinstance(get_all_subclasses(a), Iterable)
    assert isinstance(get_all_subclasses(a), set)

    l = [b, c, e, f]

    assert set(get_all_subclasses(a)) == set(l)


# Generated at 2022-06-20 15:26:04.110769
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    unit test: test_get_all_subclasses
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(D):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses

# Generated at 2022-06-20 15:26:11.521034
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This class only exists for the sake of the test.  It is removed when the module is imported.
    '''
    class B(object):
        pass

    class B1(B):
        pass

    class B2(B):
        pass

    class B3(B):
        pass

    class C(object):
        pass

    class C1(C):
        pass

    class C11(C1):
        pass

    class D(C11):
        pass

    class E(D):
        pass

    class F(E):
        pass

    class G(E):
        pass

    # Simple Tests
    assert set([B]) == get_all_subclasses(B)
    assert set([C]) == get_all_subclasses(C)
    assert set([E]) == get_all_sub

# Generated at 2022-06-20 15:26:35.873997
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    all_subclasses = get_all_subclasses(A)

    assert B in all_subclasses
    assert C in all_subclasses
    assert D in all_subclasses

# Generated at 2022-06-20 15:26:40.064809
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    result = get_all_subclasses(A)
    expected_result = {B, C}
    if result != expected_result:
        raise Exception("Expected %r, got %r" % (expected_result, result))

# Generated at 2022-06-20 15:26:43.662448
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(A):
        pass
    assert get_all_subclasses(A) == {B, C, D, E}

# Generated at 2022-06-20 15:26:49.284490
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(C):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F}



# Generated at 2022-06-20 15:26:58.352788
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define some classes
    class A:
        pass

    class B:
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(A, D):
        pass

    assert(set(get_all_subclasses(A)) == {B, C, D, E})
    assert(set(get_all_subclasses(B)) == {C, D})
    assert(set(get_all_subclasses(C)) == set())
    assert(set(get_all_subclasses(D)) == {E})
    assert(set(get_all_subclasses(E)) == set())

# Generated at 2022-06-20 15:27:02.322881
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(A):
        pass

    assert(set([A, B, C, D, E]) == get_all_subclasses(A))

# Generated at 2022-06-20 15:27:10.901874
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test the get_all_subclasses function
    """
    # Create a test class to pass
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(D):
        pass

    # Test the function
    subclasses = get_all_subclasses(A)
    assert all(isinstance(x, type) for x in subclasses)
    assert len(subclasses) == 5
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses

# Generated at 2022-06-20 15:27:13.298078
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class classA(object):
        pass

    class classB(classA):
        pass

    class classC(classB):
        pass

    assert set(get_all_subclasses(classA)) == set([classA, classB, classC])

# Generated at 2022-06-20 15:27:18.625547
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(A): pass

    assert set(get_all_subclasses(A)) == set([B, D, E, F, C])

# Generated at 2022-06-20 15:27:23.811660
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        def f(self):
            pass
    class B(A):
        def f(self):
            pass
    class C(A):
        def f(self):
            pass
    class D(B):
        def f(self):
            pass
    assert set([B, D]) == get_all_subclasses(A)

# Generated at 2022-06-20 15:28:10.864455
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Animal(object):
        pass

    class Herbivore(Animal):
        pass

    class Dog(Herbivore):
        pass

    class Wolf(Dog):
        pass

    class KillerDog(Dog):
        pass

    assert get_all_subclasses(Herbivore) == set([Dog, Wolf, KillerDog])
    assert get_all_subclasses(Dog) == set([Wolf, KillerDog])
    assert get_all_subclasses(Wolf) == set([])
    assert get_all_subclasses(Animal) == set([Herbivore, Dog, Wolf, KillerDog])



# Generated at 2022-06-20 15:28:12.666882
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Retrieve all subclasses of object
    assert get_all_subclasses(object) == type.__subclasses__(object)


# Generated at 2022-06-20 15:28:15.947420
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    assert set(get_all_subclasses(A)) == set([B, C])



# Generated at 2022-06-20 15:28:19.725007
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(F):
        pass
    class H(B):
        pass
    class I(H):
        pass
    assert get_all_subclasses(A) == set([F, G, C, D, E])
    assert get_all_subclasses(B) == set([H, I])

# Generated at 2022-06-20 15:28:27.982388
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # The following code is only executed when this module is called as a script
    # It will not be executed when imported
    #
    # ------------
    # Build a Mock class hierarchy
    # ------------
    class Foo(object):
        pass
    class Bar(Foo):
        pass
    class Baz(Foo):
        pass
    class Bop(Bar):
        pass
    class Blip(Bop):
        pass
    class Bloop(object):
        pass
    assert set(get_all_subclasses(Foo)) == set([Bar, Baz, Bop, Blip])
    assert set(get_all_subclasses(Bar)) == set([Bop, Blip])
    assert set(get_all_subclasses(Baz)) == set([])

# Generated at 2022-06-20 15:28:36.515637
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import namedtuple

    class Base(object):
        pass

    class A(Base):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(E):
        pass

    # The result should be:
    # namedtuple('result', ['a', 'b', 'c', 'd', 'e'])
    result = namedtuple('result', ['a', 'b', 'c', 'd', 'e'])

    expected = result(a=A, b=B, c=C, d=D, e=E)

    assert get_all_subclasses(Base) == set(expected)

# Generated at 2022-06-20 15:28:48.675784
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a set of classes for which we need to know all subclasses
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(object):
        pass

    class G(F):
        pass

    # Define checks for the function
    check = {
        A: [B, C, D, E],
        B: [D, E],
        C: [],
        D: [E],
        E: [],
        F: [G],
        G: []
    }

    # Iter trough check and test the function
    for cls, expected in check.items():
        result = get_all_subclasses(cls)
        assert result == set

# Generated at 2022-06-20 15:28:54.602582
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """Function 'get_all_subclasses'"""
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(F, D):
        pass

    assert set([D, E, F, G]) == get_all_subclasses(B)

# Generated at 2022-06-20 15:29:02.630527
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(B, C):
        pass
    class I(B, C, D):
        pass
    class J(F, G):
        pass
    class K(I):
        pass
    class L(H):
        pass
    classes = get_all_subclasses(A)
    assert sorted(classes, key=lambda x: x.__name__) == sorted([B, C, D, E, F, G, H, I, J, K, L], key=lambda x: x.__name__)


# Generated at 2022-06-20 15:29:13.241260
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Father:
        pass

    class FatherSon(Father):
        pass

    class FatherDaughter(Father):
        pass

    class FatherSonSon(FatherSon):
        pass

    class FatherSonSonSon(FatherSonSon):
        pass

    class FatherSonSonDaughter(FatherSonSon):
        pass

    class FatherSonDaughterSon(FatherSonDaughter):
        pass

    class FatherSonDaughterDaughter(FatherSonDaughter):
        pass

    class FatherDaughterSon(FatherDaughter):
        pass

    class FatherDaughterSonSon(FatherDaughterSon):
        pass

    class FatherDaughterSonDaughter(FatherDaughterSon):
        pass

    class FatherDaughterDaughter(FatherDaughter):
        pass

    class FatherDaughterDaughterSon(FatherDaughterDaughter):
        pass
