

# Generated at 2022-06-20 15:20:43.085676
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F:
        pass

    result = get_all_subclasses(A)
    assert B in result
    assert C in result
    assert D in result
    assert E in result
    assert F not in result

# Generated at 2022-06-20 15:20:47.429918
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''test get_all_subclasses'''
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(A):
        pass

    assert set([B, C, D]) == get_all_subclasses(A)

# Generated at 2022-06-20 15:20:55.317623
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(B)) == set([])
    assert set(get_all_subclasses(C)) == set([D])

# Generated at 2022-06-20 15:20:59.862510
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E(A): pass
    class F(E): pass
    class G(F): pass
    class H(G): pass
    class I(H, object): pass
    class J(A): pass
    class K(J): pass
    class L(J): pass
    class M(L): pass

    class N(object): pass
    class O(N): pass
    M.__bases__ += (O,)

    class P(object): pass
    class Q(P): pass
    Q.__bases__ += (M,)


# Generated at 2022-06-20 15:21:03.201753
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-20 15:21:12.479947
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    :rtype: bool
    :returns: True if all tests pass otherwise False
    '''
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass
    class F(C): pass
    class G(C): pass
    class H(G): pass
    class I(G): pass
    if not set([B, C, D, E, F, G, H, I]) == get_all_subclasses(A):
        return False
    return True


# Generated at 2022-06-20 15:21:24.754916
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    if C.DEFAULT_MODULE_PATH:
        # Import modules if not yet present.
        import ansible.modules

    # This is not a true unit test.  It explores the code in ways that are not possible with
    # traditional unit tests.  At the moment, this is the best way to determine that the output from
    # get_all_subclasses() is correct.
    #
    # This tests the following:
    # 1. The function returns all the subclasses for a given class.
    # 2. The function does not return a given class.
    # 3. The function does not return duplicate subclasses for a given class.
    # 4. The function can handle a class that has no subclasses.
    # 5. The function can handle a class that has subclasses that have no subclasses.
    # 6. The function can handle a class with sub

# Generated at 2022-06-20 15:21:31.558482
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Dummy1(object):
        pass

    class Dummy2(Dummy1):
        pass

    class Dummy3(object):
        pass

    assert set([Dummy2]) == get_all_subclasses(Dummy1)
    assert set([Dummy3]) == get_all_subclasses(object)
    assert set([Dummy2]) == get_all_subclasses(Dummy1)
    assert set([]) == get_all_subclasses(Dummy3)

# Generated at 2022-06-20 15:21:34.310937
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    subclasses = get_all_subclasses(A)
    assert B in subclasses



# Generated at 2022-06-20 15:21:40.704824
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(F):
        pass

    # Test
    assert set(get_all_subclasses(A)) == set((B, C, D, E, F, G))



# Generated at 2022-06-20 15:21:49.929914
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import namedtuple
    from types import ModuleType

    class Base:
        pass

    class Child(Base):
        pass

    class GrandChild(Child):
        pass

    class Uncle(Base):
        pass

    class Nephew(Uncle):
        pass

    class GreatGreatGrandChild(Nephew):
        pass

    class AnotherChild(Base):
        pass

    results = get_all_subclasses(Base)
    assert(results == {Uncle, Child, Nephew, GrandChild, AnotherChild, GreatGreatGrandChild})
    assert(Child not in results)
    assert(GrandChild not in results)

# Generated at 2022-06-20 15:21:55.026055
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(B):
        pass
    class G(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])

# Generated at 2022-06-20 15:22:03.063367
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class BB(A):
        pass

    assert set(get_all_subclasses(A)) == {B, C, BB}
    assert set(get_all_subclasses(B)) == {C}
    assert set(get_all_subclasses(C)) == set()
    assert set(get_all_subclasses(BB)) == set()

# Generated at 2022-06-20 15:22:12.439376
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B1(A):
        pass

    class B2(A):
        pass

    class C1(B1):
        pass

    class C2(B1):
        pass

    class D(B2):
        pass

    assert get_all_subclasses(A) == set([B1, B2, C1, C2, D])

# Generated at 2022-06-20 15:22:19.542035
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(A): pass
    class E(B): pass
    class F(C): pass
    class G(D): pass
    class H(D): pass
    class I(E): pass
    class J(F): pass
    class K(D): pass

    assert get_all_subclasses(A) == set([C, D, F, G, H, J, K])
    assert get_all_subclasses(B) == set([E, I])


# Generated at 2022-06-20 15:22:27.799929
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # these classes arbritrarily chosen to test subclass findings
    class A:
        pass
    class B:
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(D):
        pass
    class H(E):
        pass
    class I(F):
        pass
    class J(G):
        pass
    class K(H):
        pass
    class L(I):
        pass
    class M(J):
        pass
    # all the subclasses of A
    assert K in get_all_subclasses(A)
    assert K in get_all_subclasses(C)

    # all the subclasses of B
    assert K in get_all_subclasses(B)

# Generated at 2022-06-20 15:22:37.184506
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 6, subclasses
    assert B in subclasses, subclasses
    assert C in subclasses, subclasses
    assert D in subclasses, subclasses
    assert E in subclasses, subclasses
    assert F in subclasses, subclasses
    assert A in subclasses, subclasses

# Generated at 2022-06-20 15:22:43.265433
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Prepare class
    class a(object):
        pass
    class b(a):
        pass
    class c(a):
        pass
    class d(c):
        pass

    assert b in get_all_subclasses(a)
    assert c in get_all_subclasses(a)
    assert d in get_all_subclasses(a)
    assert d in get_all_subclasses(c)
    assert d not in get_all_subclasses(b)

if __name__ == "__main__":
    test_get_all_subclasses()

# Generated at 2022-06-20 15:22:51.178962
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create classes
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(D):
        pass
    # Verify the results
    assert get_all_subclasses(A) == {B, C, D, E, F}
    assert get_all_subclasses(B) == {D, E, F}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == {F}
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-20 15:22:53.120445
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D():
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(E,F):
        pass
    assert get_all_subclasses(A) == {B,C}
    assert get_all_subclasses(D) == {E,F,G}



# Generated at 2022-06-20 15:23:07.874804
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.ssh import paramiko
    from ansible.module_utils.common.winrm import winrm
    from ansible.module_utils.network.common.utils import NetworkError
    from ansible.module_utils.network.common.config import NetworkConfig, dumps
    from ansible.module_utils.connection import ConnectionError
    class Base(object):
        pass
    class Sub1(Base):
        pass
    class Sub2(Base):
        pass
    class SubSub1(Sub1):
        pass
    class SubSub2(Sub1):
        pass
    class SubSub3(Sub2):
        pass
    class SubSubSub1(SubSub1):
        pass

# Generated at 2022-06-20 15:23:15.550300
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(object):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(B):
        pass

    assert get_all_subclasses(A) == set([B, D, G])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(B) == set([D, G])

# Generated at 2022-06-20 15:23:25.728892
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Function to test the get_all_subclasses function
    '''
    import ansible.module_utils._text as ansible_module_utils__text
    # Testing if a class that didn't inherit anything doesn't produce any output
    assert get_all_subclasses(ansible_module_utils__text.AnsibleUnicode) == set()
    # Testing if a class that inherited from str and not from AnsibleUnicode doesn't produce any output
    assert get_all_subclasses(str) == set()
    # Testing if a class that inherited from AnsibleUnicode has one subclass
    # The subclass is the AnsibleUnicode class itself

# Generated at 2022-06-20 15:23:30.175845
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function `get_all_subclasses`
    '''

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(B):
        pass

    class F(E):
        pass

    assert get_all_subclasses(A) == set([B, D, C, F, E])

# Generated at 2022-06-20 15:23:37.577900
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class MyClass(object):
        pass
    class MySubClass(MyClass):
        pass
    class MySubSubClass(MySubClass):
        pass
    class MySecondSubClass(MyClass):
        pass
    class MySecondSubSubClass(MySecondSubClass):
        pass

    if MyClass not in get_all_subclasses(MyClass):
        raise AssertionError('get_all_subclasses does not return the root class.')

    if MySubClass not in get_all_subclasses(MyClass):
        raise AssertionError('get_all_subclasses does not return the immediate subclasses.')

    if MySubSubClass not in get_all_subclasses(MyClass):
        raise AssertionError('get_all_subclasses does not return the subclasses\' subclasses.')


# Generated at 2022-06-20 15:23:42.484529
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(D): pass
    class F(D): pass
    a, b, c, d, e, f = A(), B(), C(), D(), E(), F()
    assert set([a,b,c,d,e,f]) == set(get_all_subclasses(A))
    assert set([e,f]) == set(get_all_subclasses(D))
    assert set([b]) == set(get_all_subclasses(B))
    assert set([b]) == set(get_all_subclasses(b))

# Generated at 2022-06-20 15:23:49.599924
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class I(object):
        pass
    class A(I):
        pass
    class B(I):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B):
        pass
    assert set(get_all_subclasses(I)) == {A, B, C, D, E}

# TODO: Remove the following after a suitable deprecation period
# The following functions were extracted from module_utils/shell.py and updated to use get_all_subclasses

# Generated at 2022-06-20 15:23:57.273134
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Mapping
    from collections import Set
    from collections import Sequence
    from collections import Hashable
    from collections import Sized
    from collections import Iterable
    from collections import Container
    from collections import Callable
    from collections import deque

    # Checking that function detects all subclasses of a class
    # Expected output:
    # {<class 'collections.abc.Mapping'>, <class 'collections.RangeSet'>, <class 'collections.OrderedDict'>, <class 'collections.ChainMap'>, <class 'collections.abc.Set'>, <class 'collections.Set'>, <class 'collections.abc.Sequence'>, <class 'collections.Sequence'>, <class 'collections.abc.Hashable'>, <class 'collections.abc.Sized'>, <class 'collections.

# Generated at 2022-06-20 15:24:08.988933
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Testing get_all_subclasses
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(object):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(B)) == set([D])
    assert set(get_all_subclasses(C)) == set([E])
    assert set(get_all_subclasses(D)) == set([])
    assert set(get_all_subclasses(E)) == set([])
    assert set(get_all_subclasses(F)) == set([])


# Generated at 2022-06-20 15:24:20.086392
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Parent class
    class A(object):
        pass

    # Simple classes
    class B(A):
        pass

    class C(A):
        pass

    # Child classes
    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(G):
        pass

    # Creating a direct subclass of B
    class I(B):
        pass

    subclasses = get_all_subclasses(A)

    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in subclasses
    assert H in subclasses
    assert I in subclasses


# Generated at 2022-06-20 15:24:40.318409
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C:
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D, E):
        pass

    class H(D, A):
        pass

    class I(H):
        pass

    assert get_all_subclasses(A) == set([B])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D, E, F, G, H, I])
    assert get_all_subclasses(D) == set([F, G, H, I])
    assert get_all_subclasses(E) == set([G])

# Generated at 2022-06-20 15:24:49.197874
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        """
        Class A is used for testing get_all_subclasses method has two direct subclasses B, C and one sub-subclass D.
        Class B and C has no subclasses.
        """
        pass
    class B(A):
        """
        Class B is a subclass of A which has no subclasses.
        """
        pass
    class C(A):
        """
        Class C is a subclass of A which has no subclasses.
        """
        pass
    class D(B):
        """
        Class D is the only subclass of B
        """
        pass
    class E(object):
        """
        Class E is used for testing get_all_subclasses method has no subclasses.
        """
        pass
    # List of expected subclasses

# Generated at 2022-06-20 15:24:58.052691
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass

    A_subclasses = get_all_subclasses(A)
    assert {B, C, D}.issubset(A_subclasses)
    B_subclasses = get_all_subclasses(B)
    assert {D}.issubset(B_subclasses)
    C_subclasses = get_all_subclasses(C)
    assert {C_subclasses.empty()}
    D_subclasses = get_all_subclasses(D)
    assert {D_subclasses.empty()}

# Generated at 2022-06-20 15:25:06.549387
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    assert set([B, D, C, E, F]) == get_all_subclasses(A)
    assert set([D]) == get_all_subclasses(B)
    assert set([E, F]) == get_all_subclasses(C)
    assert set([]) == get_all_subclasses(D)
    assert set([F]) == get_all_subclasses(E)
    assert set([]) == get_all_subclasses(F)
    assert set([]) == get_all_subclasses(object)



# Generated at 2022-06-20 15:25:13.347714
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Ensures that get_all_subclasses returns all subclasses of a given class, including both direct
    subclasses and indirect subclasses, and that it does not return the original class
    '''
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(B): pass
    class E(D): pass
    subclasses = get_all_subclasses(A)
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert A not in subclasses

# Generated at 2022-06-20 15:25:23.516387
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    The function get_all_subclasses should be able to find all subclasses of a given class.
    This test creates a simple tree of classes and attempt to find all subclasses in the tree.
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(E):
        pass
    class G(C):
        pass
    subclasses = get_all_subclasses(A)
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in subclasses
    assert subclasses == set([D, E, F, G])

# Generated at 2022-06-20 15:25:27.504362
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Parent():
        pass

    class Child(Parent):
        pass

    class GrandChild(Child):
        pass

    class Child2(Parent):
        pass

    class GrandChild2(Child2):
        pass

    assert set(get_all_subclasses(Parent)) == set([Child, GrandChild, Child2, GrandChild2])

# Generated at 2022-06-20 15:25:31.923774
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(C): pass
    class E(A): pass

    assert get_all_subclasses(A) == {B, C, D, E}



# Generated at 2022-06-20 15:25:38.427106
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D, E}
    assert set(get_all_subclasses(B)) == {D, E}
    assert set(get_all_subclasses(C)) == set()

# Generated at 2022-06-20 15:25:48.913099
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(D): pass
    class F(D): pass
    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([C])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set([E, F])
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

    class G(object): pass
    class H(object): pass
    class I(G, H): pass
    class J(G, H): pass
    class K(I, J): pass

# Generated at 2022-06-20 15:26:13.400775
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(object):
        pass

    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert B in get_all_subclasses(B)
    assert C in get_all_subclasses(B)
    assert D in get_all_subclasses(B)
    assert C in get_all_subclasses(C)
    assert D in get_all_subclasses(D)
    assert A not in get_all_subclasses(B)
    assert A not in get_all_subclasses(C)
    assert A not in get_

# Generated at 2022-06-20 15:26:23.905183
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test the function get_all_subclasses
    '''

    class A(object):
        '''
        Class A
        '''
        def __init__(self):
            '''
            Constructor
            '''

    class B(A):
        '''
        Class B
        '''
        def __init__(self):
            '''
            Constructor
            '''

    class C(B):
        '''
        Class B
        '''
        def __init__(self):
            '''
            Constructor
            '''

    class D(C):
        '''
        Class B
        '''
        def __init__(self):
            '''
            Constructor
            '''

    # Testing that A has only B as subclass
    result = get_all_subclasses

# Generated at 2022-06-20 15:26:30.802460
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(C, B):
        pass
    class F(D, E):
        pass
    classes = get_all_subclasses(F)

    # Test that all class are present
    assert A in classes
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes

    for class_a in classes:
        for class_b in classes:
            assert issubclass(class_a, class_b)

# Generated at 2022-06-20 15:26:39.985861
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test function get_all_subclasses
    """
    # Creating 3 class
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    class G(A):
        pass

    class H(G):
        pass

    totest = [A, B, C, D, E, F, G, H]
    result = get_all_subclasses(A)
    assert len(result) == len(totest)
    for klass in result:
        assert klass in totest

# Generated at 2022-06-20 15:26:50.637152
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(B): pass
    class E(A): pass
    class F(E): pass

    # The result should be B, C, D, E, F
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    # There is no subclasses for B
    assert get_all_subclasses(B) == set([C, D])
    # There is no subclasses for C
    assert get_all_subclasses(C) == set()
    # There is no subclasses for D
    assert get_all_subclasses(D) == set()
    # The result should be F
    assert get_all_subclasses(E) == set([F])
    # There is

# Generated at 2022-06-20 15:27:01.450340
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(G):
        pass

    class I(object):
        pass

    class J(I):
        pass

    class K(J):
        pass

    class L(J):
        pass

    class TestGetAllSubClasses(unittest.TestCase):
        def setUp(self):
            self.classes = [A, B, C, D, E, F, G, H, I, J, K, L]


# Generated at 2022-06-20 15:27:11.267187
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    def assert_list_of_classes_equal(list_a, list_b):
        assert len(list_a) == len(list_b)
        for x in list_a:
            assert type(x) == type
        for x in list_b:
            assert type(x) == type
        for x in list_a:
            assert x in list_b
        for x in list_b:
            assert x in list_a

    # Define classes
    class A():
        pass
    class B():
        pass
    class C():
        pass
    class A1(A):
        pass
    class A2(A):
        pass
    class A11(A1):
        pass
    class A111(A11):
        pass
    class A12(A1):
        pass

# Generated at 2022-06-20 15:27:13.589543
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    assert set(get_all_subclasses(A)) == set([B, D, C, E, F])



# Generated at 2022-06-20 15:27:24.653220
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Computer(object): pass
    class Computer_pc(Computer): pass
    class Computer_pc_server(Computer_pc): pass
    class Computer_pc_client(Computer_pc): pass
    class Computer_mac(Computer): pass
    class Computer_mac_server(Computer_mac): pass
    class Computer_mac_client(Computer_mac): pass
    class Computer_other(Computer): pass
    class Computer_other_server(Computer_other): pass
    class Computer_other_client(Computer_other): pass
    assert sorted(get_all_subclasses(Computer)) == [
        Computer_other_client, Computer_other_server,
        Computer_mac_client, Computer_mac_server,
        Computer_pc_client, Computer_pc_server]



# Generated at 2022-06-20 15:27:31.126170
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections

    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E(B, C): pass

    assert get_all_subclasses(collections.Hashable) == set()
    assert get_all_subclasses(A) == {B, C, D, E}

# Generated at 2022-06-20 15:28:10.506364
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a class tree
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass

    # Get classes which are children of A
    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 4
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses

# Generated at 2022-06-20 15:28:15.495549
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        class B:
            class D:
                pass
            class E:
                pass
        class C:
            class F:
                pass
            class G:
                pass
            class H:
                pass
    assert get_all_subclasses(A) == {A.B, A.B.D, A.B.E, A.C, A.C.F, A.C.G, A.C.H}

# Generated at 2022-06-20 15:28:21.942748
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Defining a simple class hierarchy
    class A(object):
        pass

    class B1(A):
        pass

    class B2(A):
        pass

    class C(B1):
        pass

    # Running the test
    assert get_all_subclasses(A) == set([B1, C, B2])
    assert get_all_subclasses(B1) == set([C])
    assert get_all_subclasses(C) == set()


# Generated at 2022-06-20 15:28:29.009385
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Top(object):
        pass

    class A(Top):
        pass

    class B(Top):
        pass

    class C(Top):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(E):
        pass

    class G(C):
        pass

    class H(G):
        pass

    classes = [Top, A, B, C, D, E, F, G, H]
    for cls in classes:
        for subclass in get_all_subclasses(Top):
            assert issubclass(subclass, Top)
        for subclass in get_all_subclasses(A):
            assert issubclass(subclass, A)
        for subclass in get_all_subclasses(B):
            assert issubclass(subclass, B)


# Generated at 2022-06-20 15:28:36.516658
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(object):
        pass

    class F(A):
        pass

    # Test with A as an input
    assert set(get_all_subclasses(A)) == set([B, C, D, F])

    # Test with E as an input
    assert set(get_all_subclasses(E)) == set()

    # Test with object as an input
    assert set(get_all_subclasses(object)) == set([type, A, B, C, D, E, F])



# Generated at 2022-06-20 15:28:47.737495
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import random as rd

    class ParentClass(object):
        pass

    class SubClass1(ParentClass):
        pass

    class SubClass2(ParentClass):
        pass

    class GrandSubClass1(SubClass1):
        pass

    class GrandSubClass2(SubClass1):
        pass

    class GrandSubClass3(SubClass2):
        pass

    class GrandSubClass4(SubClass2):
        pass

    class GrandSubClass5(SubClass2):
        pass

    assert set(get_all_subclasses(ParentClass)) == set([SubClass1, SubClass2, GrandSubClass1, GrandSubClass2, GrandSubClass3, GrandSubClass4, GrandSubClass5])



# Generated at 2022-06-20 15:28:56.406077
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(F):
        pass
    class H(G):
        pass
    # Force the creation of each subclasses
    _ = [A(), B(), C(), D(), E(), F(), G(), H()]

    # Test
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])

# Generated at 2022-06-20 15:29:00.450262
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(A):
        pass

    class F(D):
        pass

    assert get_all_subclasses(A) == {C, D, E, F}
    assert get_all_subclasses(B) == set()

# Generated at 2022-06-20 15:29:09.981859
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(B):
        pass

    expected = [A, B, D, E, F, C]
    all_subclasses = get_all_subclasses(A)
    for cls in expected:
        assert cls in all_subclasses
    assert len(all_subclasses) == len(expected)

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-20 15:29:19.702739
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(B)) == set([])
    assert set(get_all_subclasses(C)) == set([D, E])
    assert set(get_all_subclasses(D)) == set([E])
    assert set(get_all_subclasses(E)) == set([])

