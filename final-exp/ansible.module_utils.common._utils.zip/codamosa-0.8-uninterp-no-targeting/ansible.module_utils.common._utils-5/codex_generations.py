

# Generated at 2022-06-20 15:20:38.778916
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E(D): pass

    assert get_all_subclasses(object) == {A, B, C, D, E}
    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == {D, E}
    assert get_all_subclasses(C) == {D}
    assert get_all_subclasses(D) == {E}
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-20 15:20:46.975916
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        """Empty class"""
    class B(A):
        """Empty class"""
    class C(A):
        """Empty class"""
    class D(B):
        """Empty class"""
    class E(C):
        """Empty class"""
    class F(D):
        """Empty class"""
    class G(D):
        """Empty class"""
    class H(E):
        """Empty class"""
    class I(G):
        """Empty class"""
    class J(I):
        """Empty class"""
    class K:
        """Empty class"""
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I, J])
    assert get_all_subclasses(D) == set([F, G, I, J])
    assert get_

# Generated at 2022-06-20 15:20:53.564798
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B)  == set()
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-20 15:21:00.832596
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    class DummyModule(object):
        def __init__(self, module_name):
            self.module_name = module_name

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert get_all_subclasses(A) == {B, C, D} == get_all_subclasses(B) == get_all_subclasses(C)
    assert get_all_subclasses(D) == set()

    class AnsibleBase(object):
        pass


# Generated at 2022-06-20 15:21:12.122454
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test class hierarchy
    #
    #   class A(object)
    #   class B(A)
    #   class C(A)
    #   class D(B, C)
    #   class E(object)
    #
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(object):
        pass

    # Searching for all subclasses of A
    for available in get_all_subclasses(A):
        assert available in [ B, C, D ]
    assert len(get_all_subclasses(A)) == 3

    # Searching for all subclasses of E
    for available in get_all_subclasses(E):
        assert available == set()
    assert len

# Generated at 2022-06-20 15:21:23.279725
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function `get_all_subclasses`
    '''
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F])
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-20 15:21:33.749037
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import defaultdict
    from ansible.plugins.action.normal import ActionModule as AnsibleActionModule
    from ansible.plugins.action.zabbix import ActionModule as ZabbixActionModule
    from ansible.plugins.action.zabbix import ZabbixUserInterface
    classes_with_subclasses = {AnsibleActionModule, ZabbixActionModule, ZabbixUserInterface}
    # Testing if all classes are subclasses of AnsibleActionModule
    assert all(get_all_subclasses(AnsibleActionModule))
    # Testing if AnsibleActionModule is subclass of AnsibleActionModule
    assert AnsibleActionModule in get_all_subclasses(AnsibleActionModule)
    # Testing if ZabbixActionModule is subclass of AnsibleActionModule

# Generated at 2022-06-20 15:21:39.352031
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    A = type('A', (object,), {})
    B = type('B', (A,), {})
    C = type('C', (A,), {})
    D = type('D', (B,), {})
    subclasses = get_all_subclasses(A)

    assert subclasses == set([B, D, C])

# Generated at 2022-06-20 15:21:43.627068
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create helper classes
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    # Assertion
    assert get_all_subclasses(A) == set([D, B, C, E, F])

# Generated at 2022-06-20 15:21:48.158404
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Create a hierarchy of classes
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass

    # Add a method to the class to identify it
    def class_id(cls):
        return cls.__name__
    list(map(lambda cls: setattr(cls, 'name', class_id(cls)), [A, B, C, D, E]))

    # Assert all the subclasses of A
    assert {obj.name for obj in get_all_subclasses(A)} == {B.name, C.name, D.name, E.name}
    # Assert all the subclasses of B

# Generated at 2022-06-20 15:21:58.230021
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestBaseClass(object):
        pass
    class TestClassForSubclassing(TestBaseClass):
        pass
    class TestInheritSubclass(TestClassForSubclassing):
        pass
    class TestInheritSubclass2(TestClassForSubclassing):
        pass
    class TestSubclassOfSubclass(TestInheritSubclass):
        pass
    class TestSubclassOfSubclass2(TestInheritSubclass):
        pass
    class TestSubclassOfSubclass3(TestInheritSubclass2):
        pass

# Generated at 2022-06-20 15:22:08.961683
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(A):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(F):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(I):
        pass
    class L(D):
        pass
    class M(L):
        pass
    class N(L):
        pass
    class O(E):
        pass
    assert set([B, C, D, E, F, G, H, I, J, K, L, M, N, O]) == get_all_subclasses(A)


# Generated at 2022-06-20 15:22:15.110517
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass

    # List of subclass for class A
    assert(get_all_subclasses(A) == set([B, C, D]))
    # List of subclass for class B
    assert(get_all_subclasses(B) == set([D]))

# Generated at 2022-06-20 15:22:19.272834
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Parent(object):
        pass

    class Foo(Parent):
        pass

    class Bar(Parent):
        pass

    class Bob(Bar):
        pass

    assert get_all_subclasses(Parent) == set([Foo, Bar, Bob])
    assert get_all_subclasses(Foo) == set()
    assert get_all_subclasses(Bar) == set([Bob])

# Generated at 2022-06-20 15:22:23.951784
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Not a very good test, as it does not test the recursivity but
    # it is better than nothing
    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(A):
        pass

    assert(set(get_all_subclasses(object)) == set([A, B, C, D]))

# Generated at 2022-06-20 15:22:31.232255
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    a = A()
    b = B()
    c = C()
    d = D()
    e = E()

    assert b.__class__ in get_all_subclasses(A)
    assert c.__class__ in get_all_subclasses(A)
    assert d.__class__ in get_all_subclasses(A)
    assert e.__class__ not in get_all_subclasses(A)

# Generated at 2022-06-20 15:22:36.215747
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(D):
        pass

    result = get_all_subclasses(A)
    expected = set([B, C, D, E, F, G])
    assert result == expected

# Generated at 2022-06-20 15:22:44.307483
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class Animal(object):
        pass

    class Mammal(Animal):
        pass

    class Fish(Animal):
        pass

    class Carnivore(Animal):
        pass

    class Mammal(Animal):
        pass

    class Fish(Animal):
        pass

    class Carnivore(Animal):
        pass

    class Dog(Mammal, Carnivore):
        pass

    class Cat(Mammal, Carnivore):
        pass

    class Shark(Fish, Carnivore):
        pass

    class BlueWhale(Mammal):
        pass

    class Clownfish(Fish):
        pass

    class Dolphin(Mammal, Fish):
        pass

    # Get all subclasses of class Animal

# Generated at 2022-06-20 15:22:50.990587
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F(B, D):
        pass
    class G(F):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])



# Generated at 2022-06-20 15:22:58.672698
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        """Class A"""
        pass

    class B(A):
        """Class B"""
        pass

    class C(A):
        """Class C"""
        pass

    class D(C):
        """Class D"""
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set()



# Generated at 2022-06-20 15:23:09.372253
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.plugins.loader import lookup_loader

    class Foo(object):
        pass

    class Bar(Foo):
        pass

    class Baz(Bar):
        pass

    class Hello(object):
        pass

    class World(object):
        pass
    # If you are adding more classes, you must put them in their own module
    # See Ansible #31033 and #38339
    # class Books(object):
    #     pass
    #
    # class Film(object):
    #     pass
    #
    # class Music(object):
    #     pass
    #
    # class Theater(object):
    #     pass

    # Test with custom classes

# Generated at 2022-06-20 15:23:15.460134
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([])



# Generated at 2022-06-20 15:23:25.649398
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(object):
        pass

    class E(B):
        pass

    class F(B):
        pass

    class G(C):
        pass

    class H(C):
        pass

    class I(G):
        pass

    class J(D):
        pass

    class K(J):
        pass

    class L(J):
        pass

    # The correct result should be:
    #   set(E, F, G, H, I)
    result = get_all_subclasses(B)
    assert isinstance(result, set)
    assert len(result) == 5
    assert E in result
    assert F in result
    assert G in result

# Generated at 2022-06-20 15:23:32.477117
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define the class tree
    clsA = int
    clsB = dict
    clsC = classmethod
    clsD = list
    clsE = str

    # Define the list of the expected returned subclasses
    expected_subclasses = [int, dict, list]

    # Compare the result
    assert get_all_subclasses(clsA) == set(expected_subclasses)

# Generated at 2022-06-20 15:23:42.428601
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    This test assert that we have the right subclasses list
    '''
    class A(object):pass
    class B(object):pass
    class C(A):pass
    class D(A):pass
    class E(C):pass
    class F(C):pass
    class G(D):pass
    class H(D):pass
    class I(E):pass
    class J(E):pass
    class K(F):pass
    class L(F):pass

    subclasses = get_all_subclasses(A)
    assert B not in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in subclasses
    assert H in subclasses
    assert I in subclasses
    assert J in subclasses

# Generated at 2022-06-20 15:23:52.403408
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils.basic import AnsibleModule

    class A(object):
        pass

    assert not get_all_subclasses(A)

    class B(A):
        pass

    class C(A):
        pass

    assert len(get_all_subclasses(A)) == 2
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)

    class D(B):
        pass

    class E(C):
        pass

    assert len(get_all_subclasses(A)) == 4
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)

    class F(E):
        pass

    class G(F):
        pass

    class H(F):
        pass

    assert len

# Generated at 2022-06-20 15:23:58.143998
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a constant class for testing
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class C1(C):
        pass
    class C11(C1):
        pass
    class C2(C):
        pass
    class C21(C2):
        pass
    class C22(C2):
        pass
    classes = get_all_subclasses(A)
    assert len(classes) == 7, 'The number of classes does not match'
    assert set(classes) == set([B, C, C1, C11, C2, C21, C22]), 'The classes do not match'


# Generated at 2022-06-20 15:24:09.267611
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''
    import random
    # Create a set of classes with random inheritance
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(object):
        pass
    class E(C, A, object):
        pass
    class F(random.choice([A, B, C, D, E])):
        pass
    class G(random.choice([A, B, C, D, E])):
        pass

    my_classes = [A, B, C, D, E, F, G]
    for cls in my_classes:
        assert cls in get_all_subclasses(object), "%s is not supposed to be a subclass of object" % cls
        assert cl

# Generated at 2022-06-20 15:24:17.361223
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Foo(object):
        pass

    class Foo1(Foo):
        pass

    class Foo2(Foo):
        pass

    class Foo3(Foo):
        pass

    class Foo11(Foo1):
        pass

    class Foo21(Foo2):
        pass

    subclasses = get_all_subclasses(Foo)
    assert Foo1 in subclasses
    assert Foo2 in subclasses
    assert Foo3 in subclasses
    assert Foo11 in subclasses
    assert Foo21 in subclasses
    assert len(subclasses) == 5



# Generated at 2022-06-20 15:24:25.974442
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Mocking a class hierarchy
    class Parent(object):
        pass

    class Child(Parent):
        pass

    class GrandChild1(Child):
         pass

    class GrandChild2(Child):
        pass

    class GrandChild3(GrandChild1):
        pass

    class GrandChild4(GrandChild3):
        pass

    class GrandChild5(GrandChild3):
        pass

    class GrandChild6(GrandChild2):
        pass

    # Testing
    class_list = get_all_subclasses(Parent)
    assert set(class_list) == set([GrandChild1, GrandChild2, GrandChild3, GrandChild4, GrandChild5,
                                   GrandChild6])

# Generated at 2022-06-20 15:24:41.434759
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections
    import os
    import sys

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(E):
        pass

    class Callable:
        def __call__(self):
            pass

    class Sequences:
        pass

    class Iterable:
        def __iter__(self):
            pass

    class Sized:
        def __len__(self):
            pass

    class Container:
        def __contains__(self, e):
            pass

    class Iterables(Iterable, Sized, Container):
        pass


# Generated at 2022-06-20 15:24:47.753606
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY2

    class ClassA(object):
        pass

    class ClassB(ClassA):
        pass

    class ClassC(ClassA):
        pass

    # ClassD is not a subclass of ClassA
    class ClassD(object):
        pass

    expected_return = to_text(u"{'ClassB', 'ClassC'}")
    if PY2:
        # In python2, we have to specify the base class (object) as the last argument
        # which is not necessary in python3
        actual_return = to_text(u"{'{0}', '{1}'}".format(ClassB.__name__, ClassC.__name__))

# Generated at 2022-06-20 15:24:58.531450
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(D): pass
    class G(D): pass
    class H(E): pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert G in get_all_subclasses(A)
    assert H in get_all_subclasses(A)

    assert len(get_all_subclasses(A)) == 8

    assert A in get_all

# Generated at 2022-06-20 15:25:04.573158
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(A): pass
    # Get all subclasses of A
    subclasses = get_all_subclasses(A)
    assert D in subclasses and B in subclasses and E in subclasses and E in subclasses

# Add a list of directories relative to an absolute path
# to the python sys.path to help import modules

# Generated at 2022-06-20 15:25:11.174052
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class A1(A):
        pass

    class A2(A):
        pass

    class A11(A1):
        pass

    class A12(A1):
        pass

    class A21(A2):
        pass

    class B(object):
        pass

    assert set(get_all_subclasses(A)) == set([A1, A2, A11, A12, A21])
    assert set(get_all_subclasses(B)) == set()



# Generated at 2022-06-20 15:25:20.339907
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Building a test namespace to work with
    #
    #  class A
    #  class B(A)
    #  class C(A)
    #  class D(B)
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass

    # Now we want to check class A as the root
    # The result must be B, C, D
    result = get_all_subclasses(A)
    try:
        assert B in result
        assert C in result
        assert D in result
    except AssertionError as e:
        raise e


# Generated at 2022-06-20 15:25:28.499034
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(F):
        pass
    class H(F):
        pass
    class I(F):
        pass

    assert set([B, C, D, E, F, G, H, I]) == get_all_subclasses(A)
    assert set([D, E]) == get_all_subclasses(B)
    assert set([F]) == get_all_subclasses(C)
    assert set([G, H, I]) == get_all_subclasses(F)

# Generated at 2022-06-20 15:25:39.832124
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(F):
        pass

    class H(F):
        pass

    class I(F):
        pass

    class J(G):
        pass

    good_answer = set([B, D, E, F, G, H, I, J, C])
    bad_answer = set([A, B, C, D, E, F, G, H, I, J])
    current_answer = set(get_all_subclasses(A))
    # Check that the current answer is not bad

# Generated at 2022-06-20 15:25:46.708779
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(E, D): pass

    assert get_all_subclasses(object) == {A, B, C, D, E, F}
    assert get_all_subclasses(A) == {C, E, F}
    assert get_all_subclasses(B) == {D, F}

# Generated at 2022-06-20 15:25:52.745659
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Minimal test to make sure that function get_all_subclasses is working
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    classes = get_all_subclasses(A)
    # we must have found all subclasses
    assert A in classes
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    # we must not have false positives
    assert len(classes) == 5


# Generated at 2022-06-20 15:26:10.139523
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class base(object): pass
    class child1(base): pass
    class child2(base): pass
    class child3(base): pass
    class child11(child1): pass
    class child12(child1): pass
    class child21(child2): pass
    class child22(child2): pass
    class child111(child11): pass
    class child222(child22): pass
    assert set([child1, child2, child3]) == set(get_all_subclasses(base))
    assert set([child11, child12]) == set(get_all_subclasses(child1))
    assert set([child21, child22]) == set(get_all_subclasses(child2))
    assert set([child111]) == set(get_all_subclasses(child11))
    assert set([child222]) == set

# Generated at 2022-06-20 15:26:21.194914
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Test1:
        pass
    class Test2(Test1):
        pass
    class Test3(Test1):
        pass
    class Test4(Test2):
        pass
    class Test5(Test3):
        pass

    assert Test1 in get_all_subclasses(Test1)
    assert Test2 in get_all_subclasses(Test1)
    assert Test3 in get_all_subclasses(Test1)
    assert Test4 in get_all_subclasses(Test1)
    assert Test5 in get_all_subclasses(Test1)
    assert Test4 in get_all_subclasses(Test2)
    assert Test5 in get_all_subclasses(Test3)

    assert Test2 not in get_all_subclasses(Test2)

# Generated at 2022-06-20 15:26:27.265457
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert set(get_all_subclasses(A)) == set([B, D, C])
    assert set(get_all_subclasses(B)) == set()
    assert set(get_all_subclasses(C)) == set([D])

# Generated at 2022-06-20 15:26:38.320415
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(D):
        pass

    class G(D):
        pass

    def create_tree(subclasses):
        """
        Create a tree of subclasses with dict
        :arg subclasses: The set of subclasses of one class
        :rtype: dict
        :returns: A tree of subclasses
        """
        # Create a dict to represent classes as tree: key is class, value is children classes

# Generated at 2022-06-20 15:26:43.121707
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set([E])
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-20 15:26:49.762193
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a test class
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(A):
        pass

    class F(E):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(E) == set([F])


# Generated at 2022-06-20 15:27:00.526062
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    def get_mro(cls):
        return [c.__name__ for c in cls.mro()]
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(C): pass
    class H(B): pass
    class I(F): pass
    class J(H): pass
    class K(H): pass
    class L(A): pass
    class M(L): pass

    # A is the class from which we retrieve the subclasses
    s = get_all_subclasses(A)

    # 11 subclasses... as expected
    assert len(s) == 11


# Generated at 2022-06-20 15:27:07.572497
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # A is subclass of B, C is subclass of D
    class A(B):
        pass
    class C(D):
        pass
    assert set(get_all_subclasses(object)) == set(get_all_subclasses(object))
    assert set(get_all_subclasses(B)) == set([A])
    assert set(get_all_subclasses(D)) == set([C])


# Generated at 2022-06-20 15:27:13.395361
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class A0(A):
        pass

    class A1(A):
        pass

    class A2(A):
        pass

    class A3(A):
        pass

    class A00(A0):
        pass

    class A01(A0):
        pass

    classes = get_all_subclasses(A)

    assert len(classes) == 6
    assert A0 in classes
    assert A1 in classes
    assert A2 in classes
    assert A3 in classes
    assert A00 in classes
    assert A01 in classes

# Generated at 2022-06-20 15:27:21.995153
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Some base classes for testing

    class Animal:
        pass
    class Feline(Animal):
        pass
    class Dog(Animal):
        pass
    class Cat(Feline):
        pass
    class DogCat(Cat, Dog):
        pass
    class DogCat2(Dog, Cat):
        pass

    got_classes = get_all_subclasses(Animal)
    assert Feline in got_classes
    assert Dog in got_classes
    assert Cat in got_classes
    assert DogCat in got_classes
    assert DogCat2 in got_classes

# Generated at 2022-06-20 15:27:46.592871
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    #
    assert get_all_subclasses(A) == {B, C, D, E, F}
    assert get_all_subclasses(B) == {D}
    assert get_all_subclasses(C) == {E, F}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == {F}
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-20 15:27:52.969332
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import defaultdict

    class Class1(object):
        pass

    class Class2(Class1):
        pass

    class Class3(Class2):
        pass

    class Class4(Class1):
        pass

    class Class5(Class4):
        pass

    class Class6(Class5):
        pass

    class Class7(object):
        pass

    class Class8(Class7):
        pass

    class Class9(Class5):
        pass

    hierarchy = defaultdict(lambda: [])
    hierarchy[Class1].append([Class2, Class4])
    hierarchy[Class2].append([Class3])
    hierarchy[Class4].append([Class5])
    hierarchy[Class5].append([Class6, Class9])
    hierarchy[Class7].append([Class8])


# Generated at 2022-06-20 15:27:59.018570
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(D):
        pass
    class H(G):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])



# Generated at 2022-06-20 15:28:03.243481
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(B, D):
        pass
    assert get_all_subclasses(A) == set([E, C, B, D])

# Generated at 2022-06-20 15:28:13.266368
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(C): pass
    class G(D): pass
    class H(G): pass
    assert set(get_all_subclasses(A)) == set((B,C,D,E,F,G,H))
    assert set(get_all_subclasses(B)) == set((D,G,H))
    assert set(get_all_subclasses(C)) == set((E,F))
    assert set(get_all_subclasses(D)) == set((G,H))
    assert set(get_all_subclasses(E)) == set()
    assert set(get_all_subclasses(F)) == set()

# Generated at 2022-06-20 15:28:17.105175
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(object): pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert len(get_all_subclasses(E)) == 0



# Generated at 2022-06-20 15:28:27.064023
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # This class should be available
    class A(object):
        pass

    # The following classes should be skipped because they are not class of A
    class C(object):
        pass

    # Direct child class of A
    class B1(A):
        pass

    # Sub class of B1
    class B2(B1):
        pass

    # Sub class of B2
    class B3(B2):
        pass

    # Sub class of B3
    class B4(B3):
        pass

    # Sub class of B2
    class B5(B2):
        pass

    # Sub class of B4
    class B6(B4):
        pass

    result = get_all_subclasses(A)
    assert len(result) == 6
    assert B1 in result
    assert B2 in result


# Generated at 2022-06-20 15:28:35.240537
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(object): pass

    assert get_all_subclasses(A) == {B, C, D}
    assert get_all_subclasses(B) == {D}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(object) == {A, B, C, D, E}
    assert get_all_subclasses(type) == set()

# Generated at 2022-06-20 15:28:41.366591
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(object):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(object) == set([A, E, B, C, D])
    assert get_all_subclasses(E) == set()

# Import the classes in the module
from ansible.utils.parsing.convert_bool import boolean
from ansible.utils.parsing.dataloader import DataLoader
from ansible.utils.parsing.yamlcache import YamlCache
from ansible.utils.unsafe_proxy import AnsibleUnsafeText, wrap_var

# Generated at 2022-06-20 15:28:52.130533
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import namedtuple

    # A small fake class hierarchy
    Animal = namedtuple('Animal', [])
    Mammal = namedtuple('Mammal', [])
    Dog = namedtuple('Dog', [])
    Cat = namedtuple('Cat', [])
    Fish = namedtuple('Fish', [])
    GithubBandit = namedtuple('GithubBandit', [])
    Shark = namedtuple('Shark', [])
    Salmon = namedtuple('Salmon', [])
    Mammal.__subclasses__ = lambda: [Dog, Cat]
    Dog.__subclasses__ = lambda: []
    Cat.__subclasses__ = lambda: []
    Fish.__subclasses__ = lambda: [Shark, Salmon]
    Shark.__subclasses__ = lambda: [GithubBandit]
    Salmon

# Generated at 2022-06-20 15:29:41.082464
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(C): pass
    class E(A): pass
    class F(E): pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([C, D])
    assert set(get_all_subclasses(E)) == set([F])

# Generated at 2022-06-20 15:29:47.606290
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''

    class BaseClass(object):
        '''
        A base class to be used for testing get_all_subclasses
        '''
        pass

    class Level1Class(BaseClass):
        '''
        A class to be used for testing get_all_subclasses
        '''
        pass

    class Level2Class(Level1Class):
        '''
        A class to be used for testing get_all_subclasses
        '''
        pass

    class Level2bClass(Level1Class):
        '''
        A class to be used for testing get_all_subclasses
        '''
        pass

    class Level3Class(Level2Class):
        '''
        A class to be used for testing get_all_subclasses
        '''

# Generated at 2022-06-20 15:29:53.024949
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    assert(get_all_subclasses(A) == set([B, C, D]))

# Generated at 2022-06-20 15:29:59.806645
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B1(A):
        pass

    class B2(A):
        pass

    class C(B1):
        pass

    class D(B2):
        pass

    E = B2

    assert {B1, C} == get_all_subclasses(A)
    assert {D, E} == get_all_subclasses(B2)
    assert {A, B1, C, B2, D, E} == get_all_subclasses(object)

# Generated at 2022-06-20 15:30:08.048387
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from _utils import get_all_subclasses
    # Create a test class which will be used to test the get_all_subclasses method.
    class TestClass(object):
        pass
    class ChildClass1(TestClass):
        pass
    class ChildClass2(TestClass):
        pass
    class GrandchildClass1(ChildClass1):
        pass
    class GrandchildClass2(ChildClass1):
        pass
    class GrandchildClass3(ChildClass2):
        pass
    assert set([GrandchildClass1, GrandchildClass2]) == set(get_all_subclasses(ChildClass1))
    assert set([GrandchildClass3]) == set(get_all_subclasses(ChildClass2))

# Generated at 2022-06-20 15:30:19.257905
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.action.copy import ActionModule as CopyActionModule
    from ansible.plugins.action.template import ActionModule as TemplateActionModule
    from ansible.plugins.action.win_copy import ActionModule as WinCopyActionModule
    from ansible.plugins.action.win_template import ActionModule as WinTemplateActionModule

    # Create a fake class where we know the subclasses
    class FakeParentClass(object):
        pass

    class FakeSubclass(FakeParentClass):
        pass

    class AnotherFakeSubclass(FakeParentClass):
        pass

    # Assert we have the expected subclasses
    assert FakeSubclass in get_all_subclasses(FakeParentClass)
    assert AnotherFakeSubclass in get_all_subclasses(FakeParentClass)

    # Test with a

# Generated at 2022-06-20 15:30:24.573788
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    # Example class
    class A(object):
        pass

    # Create 2 subclasses in 2 different lines
    class B(A):
        pass

    class C(A):
        pass

    # Create 2 sub sub classes in 2 different lines
    class D(B):
        pass

    class E(B):
        pass

    # Testing get_all_subclasses
    assert get_all_subclasses(A) == set([B, D, E, C])

# Generated at 2022-06-20 15:30:33.756274
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test case.

    .. code-block:: python

        class A(object):
            pass

        class B(A):
            pass

        class C(A):
            pass

        class D(C):
            pass

        class E(object):
            pass

        class F(object):
            pass

        print(get_all_subclasses(A))
        # => set([<class '__main__.B'>, <class '__main__.C'>, <class '__main__.D'>])
        print(get_all_subclasses(B))
        # => set([])
        print(get_all_subclasses(E))
        # => set([])
        print(get_all_subclasses(F))
        # => set([])
    '''
