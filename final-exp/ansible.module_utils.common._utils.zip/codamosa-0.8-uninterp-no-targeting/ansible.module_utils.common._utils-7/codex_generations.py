

# Generated at 2022-06-20 15:20:44.458102
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(C): pass
    assert get_all_subclasses(A) == {B, C, D, E, F}
    assert get_all_subclasses(B) == {D}
    assert get_all_subclasses(C) == {E, F}

# Generated at 2022-06-20 15:20:48.724009
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(D):
        pass

    classes = get_all_subclasses(A)

    assert C in classes
    assert D in classes
    assert E in classes
    assert A not in classes

# Generated at 2022-06-20 15:20:55.126957
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''Test for the function get_all_subclasses
    '''
    import unittest

    # Define a dummy class hierarchy to test the function
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass


    class TestGetAllSubclasses(unittest.TestCase):
        def test_get_all_subclasses(self):
            '''Test function get_all_subclasses'''
            self.assertIn(D, get_all_subclasses(A), "D has to be retrieved")
            self.assertIn(E, get_all_subclasses(A), "E has to be retrieved")

# Generated at 2022-06-20 15:20:59.740503
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for get_all_subclasses

    Create a dictionary of classes with a particular inheritance structure.
    This test makes sure that get_all_subclasses correctly returns the classes
    in the structure, then checks that it correctly returns an empty set when
    called on a class which has no subclasses.
    '''
    # Create a test class structure, using the following classes in a hierarchy:
    # ClassA
    # |-- ClassB
    # |   |-- ClassC
    # |   |   |-- ClassD
    # |   |-- ClassE
    # |   |   |-- ClassF
    # |-- ClassG
    # |   |-- ClassH
    # |-- ClassI
    class ClassA(object):
        pass

    class ClassB(ClassA):
        pass

    class ClassC(ClassB):
        pass


# Generated at 2022-06-20 15:21:05.851216
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(B, E):
        pass
    assert get_all_subclasses(A) == {C, D, E, F}
    assert get_all_subclasses(B) == {F}
    assert get_all_subclasses(C) == {D, E, F}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == {F}
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-20 15:21:12.220488
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(D):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(C) == set()

# Generated at 2022-06-20 15:21:23.699142
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses
    '''

    class Class1(object):
        pass

    class Class2(Class1):
        pass

    class Class3(Class1):
        pass

    class Class4(Class2):
        pass

    class Class5(Class3):
        pass

    class Class6(Class2):
        pass

    class Class7(Class6):
        pass

    class Class8(Class6):
        pass

    subclasses = get_all_subclasses(Class1)
    assert all(x in subclasses for x in [Class2, Class3, Class4, Class5, Class6, Class7, Class8])


# Generated at 2022-06-20 15:21:32.226516
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class IA:
        pass

    class IB(IA):
        pass

    class IC(IA):
        pass

    class CA(IB):
        pass

    class CB(IB):
        pass

    class DA(IC):
        pass

    class DB(IC):
        pass

    class DC(IC):
        pass

    assert set(get_all_subclasses(IA)) == { IB, IC, CA, CB, DA, DB, DC }
    assert set(get_all_subclasses(IB)) == { CA, CB }
    assert set(get_all_subclasses(IC)) == { DA, DB, DC }

# Generated at 2022-06-20 15:21:35.398624
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(G):
        pass
    assert H in get_all_subclasses(A)

# Generated at 2022-06-20 15:21:43.478071
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])
    assert set(get_all_subclasses(E)) == set([])

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-20 15:21:56.561823
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(A):
        pass
    class F(object):
        pass
    class G(F):
        pass
    class H(G):
        pass
    assert get_all_subclasses(A) == set([B,C,D,E])
    assert get_all_subclasses(B) == set([])
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(F) == set([G,H])
    assert get_all_subclasses(G) == set([H])
    assert get_all_subclasses(H)

# Generated at 2022-06-20 15:22:07.917558
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for get_all_subclasses.

    For an example of a class hierarchy that this function can handle,
    see: http://code.activestate.com/recipes/576949-find-all-subclasses-of-a-given-class/
    '''
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(B):
        pass
    class F(D, E):
        pass

    # Any class will do, but A is as good a choice as any.
    classes = get_all_subclasses(A)
    for cls in (B, C, D, E, F):
        assert cls in classes

    # F is the most descendent class,

# Generated at 2022-06-20 15:22:18.665592
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a(object):
        pass
    assert a in get_all_subclasses(a)
    class b(a):
        pass
    assert b in get_all_subclasses(a)
    class c(a):
        pass
    assert c in get_all_subclasses(a)
    class d(a):
        pass
    assert d in get_all_subclasses(a)
    class e(b):
        pass
    assert e in get_all_subclasses(a)
    class f(c):
        pass
    assert f in get_all_subclasses(a)
    class g(d):
        pass
    assert g in get_all_subclasses(a)
    class h(e):
        pass
    assert h in get_all_subclasses(a)

# Generated at 2022-06-20 15:22:24.842363
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(E):
        pass

    class G():
        pass

    class H(G):
        pass

    class I(C):
        pass

    assert(get_all_subclasses(A) == {B, C, D, E, F, I})
    assert(get_all_subclasses(H) == {H})

# Generated at 2022-06-20 15:22:35.339784
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass


    class B(A):
        pass


    class C(A):
        pass


    class D(B):
        pass


    class E(D):
        pass


    assert(E in get_all_subclasses(A))
    assert(E in get_all_subclasses(B))
    assert(E in get_all_subclasses(C))
    assert(E in get_all_subclasses(D))
    assert(set() == get_all_subclasses(E))
    assert(B in get_all_subclasses(A))
    assert(C in get_all_subclasses(A))
    assert(set() == get_all_subclasses(B))
    assert(set() == get_all_subclasses(C))

# Generated at 2022-06-20 15:22:40.527637
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(A): pass
    class F(A): pass
    class G(E): pass
    class H(F): pass
    class I(G): pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I])

# Generated at 2022-06-20 15:22:45.476578
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(B):
        pass
    class G(F):
        pass
    subclasses = get_all_subclasses(object)
    assert A in subclasses is True
    assert B in subclasses is True
    assert C in subclasses is True
    assert D in subclasses is True
    assert E in subclasses is True
    assert F in subclasses is True
    assert G in subclasses is True


# Generated at 2022-06-20 15:22:54.073620
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])

# Generated at 2022-06-20 15:23:03.444275
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(A):
        pass

    assert set([A, B, C, D, E]) == get_all_subclasses(A)
    assert set([B, C, D]) == get_all_subclasses(B)
    assert set([C, D]) == get_all_subclasses(C)
    assert set([D]) == get_all_subclasses(D)
    assert set([E]) == get_all_subclasses(E)
    assert set() == get_all_subclasses(object)

# Generated at 2022-06-20 15:23:08.820169
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Foo: pass
    class Bar(Foo): pass
    class Baz(Foo): pass
    class Bax(Bar): pass
    class Quux(Foo): pass
    class Wibble(Baz): pass
    class Wobble(Wibble): pass
    result = get_all_subclasses(Foo)
    expected = set([Bar, Baz, Bax, Quux, Wibble, Wobble])
    assert result == expected, "Test get_all_subclasses failed. Expected %s got %s" % (expected, result)


# Generated at 2022-06-20 15:23:16.509901
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define a simple class hierarchy
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass

    # Ensure that the number of returned subclasses is correct
    assert len(get_all_subclasses(A)) == 3, "Expected 3 subclasses"

# Generated at 2022-06-20 15:23:24.620832
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(C): pass
    class E(B): pass
    class F(B): pass
    assert get_all_subclasses(A) == set([C, D])
    assert get_all_subclasses(B) == set([E, F])
    assert get_all_subclasses(C) == set([D])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-20 15:23:32.749752
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base(object):
        pass
    class Child(Base):
        pass
    class Grandchild(Child):
        pass
    class OtherChild(Base):
        pass
    class DoubleGrandchild(Grandchild):
        pass
    class DoubleSecondGrandchild(Grandchild):
        pass
    class DoubleGrandchild2(DoubleGrandchild):
        pass
    class SonOfOtherChild(OtherChild):
        pass
    class GrandchildOfOtherChild(SonOfOtherChild):
        pass
    assert set(get_all_subclasses(Base)) == set([Child, Grandchild, OtherChild, DoubleGrandchild, DoubleSecondGrandchild, DoubleGrandchild2, SonOfOtherChild, GrandchildOfOtherChild])

# Generated at 2022-06-20 15:23:37.859482
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class SampleBaseClass:
        pass

    class SampleSubClass1(SampleBaseClass):
        pass

    class SampleSubClass2(SampleBaseClass):
        pass

    class SampleSubClass1_1(SampleSubClass1):
        pass

    assert get_all_subclasses(SampleBaseClass) == {SampleSubClass1, SampleSubClass2, SampleSubClass1_1}

# Generated at 2022-06-20 15:23:42.598257
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass

    assert get_all_subclasses(A) == set((B,C,D,E,F))
    assert get_all_subclasses(B) == set((D,E))
    assert get_all_subclasses(C) == set((F,))
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()

# Generated at 2022-06-20 15:23:52.445934
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(C, D):
        pass
    assert set(get_all_subclasses(A)) == set((C, E, G))
    assert set(get_all_subclasses(B)) == set((D, F, G))
    assert set(get_all_subclasses(C)) == set((E, G))
    assert set(get_all_subclasses(D)) == set((F, G))
    assert set(get_all_subclasses(E)) == set()
    assert set(get_all_subclasses(F)) == set()

# Generated at 2022-06-20 15:23:56.653718
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D,E): pass
    class G(F): pass
    class H(F): pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])

# vim: expandtab filetype=python

# Generated at 2022-06-20 15:24:02.595918
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class ClassA(object): pass
    class ClassB(ClassA): pass
    class ClassC(ClassB): pass
    class ClassD(ClassB): pass
    class ClassE(ClassA): pass
    class ClassF(ClassE): pass
    assert set(get_all_subclasses(ClassA)) == set([ClassB, ClassC, ClassD, ClassE, ClassF])

# Generated at 2022-06-20 15:24:08.988305
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, E])

# Generated at 2022-06-20 15:24:14.535551
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class X(object): pass
    class Y(X): pass
    class Z(X): pass
    class K(Z): pass
    class L(Z): pass

    assert get_all_subclasses(X) == {Y, K, L}
    assert get_all_subclasses(Z) == {K, L}

# Generated at 2022-06-20 15:24:29.402360
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class MyTestClass1:
        pass

    class MyTestClass2:
        pass

    class MyTestClass3:
        pass

    class MyTestClass4(MyTestClass1, MyTestClass2):
        pass

    class MyTestClass5(MyTestClass3):
        pass

    class MyTestClass6(MyTestClass4, MyTestClass5):
        pass

    classes = get_all_subclasses(MyTestClass1)
    assert classes == {MyTestClass4, MyTestClass6}

    classes = get_all_subclasses(MyTestClass2)
    assert classes == {MyTestClass4, MyTestClass6}

    classes = get_all_subclasses(MyTestClass3)
    assert classes == {MyTestClass5, MyTestClass6}


# Generated at 2022-06-20 15:24:34.772006
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    results = set(get_all_subclasses(A))

    assert results == set([B, C, D, E])

# Generated at 2022-06-20 15:24:40.154774
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    my_class = A
    expected_classes = set((B, C, D, E, F))
    assert get_all_subclasses(my_class) == expected_classes

# Generated at 2022-06-20 15:24:48.972332
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class F(D):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D, F}

    # Test multiple inheritance
    class G(A):
        pass

    class I(A):
        pass

    class H(I, G):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D, F, G, H, I}

    # Test mixin class
    class M(object):
        pass

    class N(B, M):
        pass

    class O(B, M):
        pass

    class P(B, O):
        pass


# Generated at 2022-06-20 15:24:55.000267
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([])



# Generated at 2022-06-20 15:24:59.282099
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    assert get_all_subclasses(A) == { B, C, D, E }

# Generated at 2022-06-20 15:25:04.164370
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Defining 3 classes
    class A(object): pass
    class B(A): pass
    class C(B): pass
    assert A in get_all_subclasses(object)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert C not in get_all_subclasses(B)

# Generated at 2022-06-20 15:25:06.662831
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class F(D): pass
    assert F in get_all_subclasses(A)

# Generated at 2022-06-20 15:25:15.258397
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C1:
        pass

    class C2(C1):
        pass

    class C3(C1):
        pass

    class C4(C2):
        pass

    class C5(C2):
        pass

    class C6(C3):
        pass

    class C7(C3):
        pass

    class C8(C4):
        pass

    class C9(C4):
        pass

    class C10(C9):
        pass

    assert get_all_subclasses(object) == set()
    assert get_all_subclasses(C1) == {C2, C4, C5, C8, C9, C10, C3, C6, C7}

# Generated at 2022-06-20 15:25:24.058981
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass

    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert D not in get_all_subclasses(B)
    assert E not in get_all_subclasses(B)
    assert C not in get_all_subclasses(B)
    assert B not in get_all_subclasses(B)

# Generated at 2022-06-20 15:25:42.324895
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test class to check if all subclasses are found
    """

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    # Check if all subclasses are retrieved
    assert set(get_all_subclasses(A)) == {B, C, D, E}

# Generated at 2022-06-20 15:25:49.661736
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a parent class
    class a:
        pass

    # Create two child classes
    class b(a):
        pass

    class c(a):
        pass

    # Create a third child class, which is the child of class b
    class d(b):
        pass

    assert (get_all_subclasses(a) == {b, c, d})
    assert (get_all_subclasses(b) == {d})
    assert (get_all_subclasses(c) == set())
    assert (get_all_subclasses(d) == set())

# Generated at 2022-06-20 15:25:59.562174
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Simple case
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D])

    # Multiple paths
    class E(object):
        pass

    class F(object):
        pass

    class G(F):
        pass

    class H(G):
        pass

    class I(E):
        pass

    class J(I):
        pass

    class K(J):
        pass

    assert get_all_subclasses(E) == set([F, I, J, K, G, H])

# Generated at 2022-06-20 15:26:08.790907
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    # At this time, we have four classes A, B, C, D and the following
    # relationship between these classes :
    #    -> A, B, C, D <-- A
    #      -> B <-- C
    #        -> D <-- B, C
    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(B)) == set([D])
    assert set(get_all_subclasses(C)) == set([D])
    assert set(get_all_subclasses(D)) == set([])

# Generated at 2022-06-20 15:26:19.329795
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(A): pass
    class E(B): pass
    class F(C): pass
    class G(C): pass
    class H(D): pass
    class I(D): pass
    class J(D): pass
    assert get_all_subclasses(A) == set((B,C,D,E,F,G,H,I,J))
    assert get_all_subclasses(B) == set((E,))
    assert get_all_subclasses(C) == set((F,G,))
    assert get_all_subclasses(D) == set((H,I,J,))

# Generated at 2022-06-20 15:26:28.455531
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Parent(object):
        pass
    class Child1(Parent):
        pass
    class Child2(Parent):
        pass
    class Child3(Child1):
        pass
    class Child4(Child1):
        pass
    class Child5(Child4):
        pass
    class Child6(Child4):
        pass
    class Child7(Parent):
        pass

    assert get_all_subclasses(Parent) == {Child1, Child2, Child3, Child4, Child5, Child6, Child7}
    assert get_all_subclasses(Child1) == {Child3, Child4, Child5, Child6}
    assert get_all_subclasses(Child2) == set()

# Generated at 2022-06-20 15:26:39.793397
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import Mapping
    from collections import Sequence
    from collections import Set
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    assert(get_all_subclasses(object) == set((A, Sequence, Mapping, Set)))

# Generated at 2022-06-20 15:26:48.282675
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a(object):
        pass

    class T1(a):
        pass

    class T2(T1):
        pass

    class T3(T1):
        pass

    class T4(T3):
        pass

    class T5(T4):
        pass

    class T6(T5):
        pass

    class T7(T6):
        pass

    class T8(T3):
        pass

    assert get_all_subclasses(a) == set([T1, T2, T3, T4, T5, T6, T7, T8])

# Generated at 2022-06-20 15:26:58.525666
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a class Foo
    class Foo:
        pass

    # Create a class Bar which inherits from Foo
    class Bar(Foo):
        pass

    # Create a class Too which inherits from Bar
    class Too(Bar):
        pass

    # Create a class Yoo which inherits from Bar
    class Yoo(Bar):
        pass

    # Create a class Boo which inherits from Foo
    class Boo(Foo):
        pass

    # Get all subclasses of the class Foo
    sub_classes = get_all_subclasses(Foo)

    assert len(sub_classes) == 3
    assert Bar in sub_classes
    assert Too in sub_classes
    assert Yoo in sub_classes
    assert Boo in sub_classes

# Generated at 2022-06-20 15:27:03.723923
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(object):
        pass

    assert get_all_subclasses(F) == set()

    assert get_all_subclasses(A) == {B, C, D, E}

# Generated at 2022-06-20 15:27:26.222879
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass

    all_subclasses_A = get_all_subclasses(A)
    assert all_subclasses_A == set([B, C, D, E])

    all_subclasses_B = get_all_subclasses(B)
    assert all_subclasses_B == set([D, E])

    all_subclasses_D = get_all_subclasses(D)
    assert all_subclasses_D == set([E])

    all_subclasses_E = get_all_subclasses(E)
    assert all_subclasses_E == set([])

# Generated at 2022-06-20 15:27:31.381430
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    result = get_all_subclasses(A)
    assert B in result
    assert C in result
    assert D in result
    assert E in result

# Generated at 2022-06-20 15:27:36.869206
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class cls1(object):
        pass
    class cls2(cls1):
        pass
    class cls3(cls1):
        pass
    class cls4(cls2):
        pass

    leafs = get_all_subclasses(cls1)
    assert len(leafs) == 3
    assert cls2 in leafs
    assert cls3 in leafs
    assert cls4 in leafs

# Generated at 2022-06-20 15:27:40.014840
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(object):
        pass
    class D(A):
        pass

    assert get_all_subclasses(A) == set([B, D])

# Generated at 2022-06-20 15:27:47.739494
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(): pass
    class B(): pass
    class C(A, B): pass
    class D(A): pass
    class E(A, B, C): pass
    class F(A, E): pass
    class G(D, E): pass
    assert set([C, D, E, F, G]) == get_all_subclasses(A)
    assert set([C, E, F, G]) == get_all_subclasses(B)
    assert set([C, E, F, G]) == get_all_subclasses(C)
    assert set([D, G]) == get_all_subclasses(D)
    assert set([E, F, G]) == get_all_subclasses(E)
    assert set([F, G]) == get_all_subclasses(F)

# Generated at 2022-06-20 15:27:58.519783
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(B):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, E, F])
    assert set(get_all_subclasses(C)) == set([])
    assert set(get_all_subclasses(D)) == set([])
    assert set(get_all_subclasses(E)) == set([])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-20 15:28:09.179502
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define class hierarchy containing two main class
    class Root(object):
        pass

    class A(Root):
        pass

    class B(Root):
        pass

    # Define some subclass and generate class hierarchy
    class A_1(A):
        pass

    class A_2(A):
        pass

    class B_1(B):
        pass

    class B_1_1(B_1):
        pass

    class B_2(B):
        pass

    test_classes = [Root, A, B, A_1, A_2, B_1, B_1_1, B_2]

# Generated at 2022-06-20 15:28:13.456200
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Given
    class Base(object):
        pass

    class ChildA(Base):
        pass

    class ChildB(Base):
        pass

    class GrandChild(ChildA):
        pass

    # When
    result = get_all_subclasses(Base)

    # Then
    assert ChildA in result
    assert ChildB in result
    assert GrandChild in result

# Generated at 2022-06-20 15:28:22.341899
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(C):
        pass

    subclasses = get_all_subclasses(A)
    assert subclasses == set([B, C, D, E])
    # Testing that get_all_subclasses return only one instance of a same class
    class Test(object):
        @staticmethod
        def get_all_subclasses():
            return set([A, Test])

    subclasses = Test.get_all_subclasses()
    assert len(subclasses) == 2
    assert A in subclasses
    assert Test in subclasses

# Generated at 2022-06-20 15:28:29.193000
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Definition of a class tree
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(G):
        pass

    # Check class A subclasses
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H])
    # Check class B subclasses
    assert get_all_subclasses(B) == set([D, E])
    # Check class C subclasses
    assert get_all_subclasses(C) == set([F, G, H])
    # Check class D subclasses

# Generated at 2022-06-20 15:29:12.433349
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    A class that has no subclass
    '''
    class A(object): pass

    '''
    A class that has only one subclass
    '''
    class B(object): pass

    class C(B): pass

    '''
    A class that has multiple subclasses
    '''
    class D(object): pass

    class E(D): pass

    class F(D): pass

    '''
    A class that has multiple subclasses and also one of them has its own subclass
    '''
    class G(object): pass

    class H(G): pass

    class I(H): pass

    class J(G): pass

    assert get_all_subclasses(A) == set()
    assert get_all_subclasses(B) == set([C])
    assert get_all_subclasses(D)

# Generated at 2022-06-20 15:29:22.966351
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Fruit(object):
        pass
    class Apple(Fruit):
        pass
    class Pear(Fruit):
        pass
    class RedDelicious(Apple):
        pass
    class Macintosh(Apple):
        pass
    class GrannySmith(Apple):
        pass
    class GreenPear(Pear):
        pass
    class RedPear(Pear):
        pass
    class BellPear(Pear):
        pass
    class Banana(Fruit):
        pass
    fruits = [Fruit, Apple, Pear, RedDelicious, Macintosh, GrannySmith, GreenPear, RedPear, BellPear, Banana]
    assert(set(fruits) == get_all_subclasses(Fruit))

# Generated at 2022-06-20 15:29:28.256872
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(object):
        pass

    assert set(types.ClassType.__subclasses__()) == {A, B, C, D, E}
    assert get_all_subclasses(A) == {B, C, D}
    assert get_all_subclasses(B) == {D}
    assert get_all_subclasses(C) == {D}
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(object) == {A, B, C, D, E}



# Generated at 2022-06-20 15:29:40.443677
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(C):
        pass
    class I(H):
        pass
    class J(H):
        pass
    class K(H):
        pass
    class L(I):
        pass
    class M(L):
        pass

    assert get_all_subclasses(A) == set([B, D, E, C, F, G, H, I, J, K, L, M])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C)

# Generated at 2022-06-20 15:29:43.325171
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses()
    '''
    # Test class
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    classes = get_all_subclasses(A)

    assert (B in classes)
    assert (C in classes)
    assert (D in classes)

# Generated at 2022-06-20 15:29:50.035061
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(D):
        pass

    class G(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F, G])

# Generated at 2022-06-20 15:29:53.244585
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    assert sorted(get_all_subclasses(A)) == [B, C, D]

# Generated at 2022-06-20 15:30:03.503418
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(C):
        pass

    class F(B):
        pass

    class G(B):
        pass

    class H(G):
        pass

    class I(H):
        pass

    assert get_all_subclasses(A) == set([C, D, E])
    assert get_all_subclasses(B) == set([F, G, H, I])
    assert get_all_subclasses(C) == set([E])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])


# Generated at 2022-06-20 15:30:08.220912
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(B):
        pass
    class H(E):
        pass
    class I(A):
        pass
    assert get_all_subclasses(A) == {B, C, D, E, F, G, H, I}



# Generated at 2022-06-20 15:30:19.258222
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass

    assert A in B.__subclasses__()
    assert A in C.__subclasses__()
    assert B in D.__subclasses__()
    assert C in E.__subclasses__()
    assert C in F.__subclasses__()
    assert len(A.__subclasses__()) == 2
    assert len(C.__subclasses__()) == 2

    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)