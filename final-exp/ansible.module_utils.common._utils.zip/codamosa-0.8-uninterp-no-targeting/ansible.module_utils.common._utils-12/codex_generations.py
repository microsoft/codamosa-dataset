

# Generated at 2022-06-20 15:20:43.199838
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    assert(set(get_all_subclasses(A)) == set([B, C, D]))



# Generated at 2022-06-20 15:20:51.809160
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create sample classes
    class Animal(object):
        pass

    class Dog(Animal):
        pass

    class Lab(Dog):
        pass

    class Huskey(Dog):
        pass

    class Cat(Animal):
        pass

    class Siamese(Cat):
        pass

    class Persian(Cat):
        pass

    assert get_all_subclasses(Animal) == set([Dog, Lab, Huskey, Cat, Siamese, Persian])
    assert get_all_subclasses(Dog) == set([Lab, Huskey])
    assert get_all_subclasses(Lab) == set([])
    assert get_all_subclasses(Huskey) == set([])
    assert get_all_subclasses(Cat) == set([Siamese, Persian])
    assert get_all_subclasses(Siamese) == set

# Generated at 2022-06-20 15:21:04.952308
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a():
        pass
    class b(a):
        pass
    class c(a):
        pass
    class d(b,c):
        pass

    class e():
        pass

    class f(d,e):
        pass

    class g(f):
        pass
    class h(f):
        pass
    class i(g,h):
        pass

    assert set(get_all_subclasses(a)) == set([b,c,d,f,g,h,i])
    assert set(get_all_subclasses(b)) == set([d,f,g,h,i])
    assert set(get_all_subclasses(c)) == set([d,f,g,h,i])

# Generated at 2022-06-20 15:21:16.268443
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import sys
    # Some classes to test get_all_subclasses
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(D):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(D):
        pass

    # A test case for the get_all_subclasses function

# Generated at 2022-06-20 15:21:25.391008
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Parent(object):
        pass
    class Child(Parent):
        pass
    class GrandChild(Child):
        pass
    class GreatGrandChild(GrandChild):
        pass
    class OtherChild(Parent):
        pass
    class OtherGrandChild(OtherChild):
        pass
    class GreatGrandChild2(OtherGrandChild):
        pass

    results = get_all_subclasses(Parent)
    assert Child in results
    assert GrandChild in results
    assert GreatGrandChild in results
    assert OtherChild in results
    assert OtherGrandChild in results
    assert GreatGrandChild2 in results

    results = get_all_subclasses(Child)
    assert GrandChild in results
    assert GreatGrandChild in results

    results = get_all_subclasses(GrandChild)
    assert GreatGrandChild in results

    results = get_all_sub

# Generated at 2022-06-20 15:21:35.645018
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([D, E, F])
    assert set(get_all_subclasses(C)) == set([])
    assert set(get_all_subclasses(D)) == set([E, F])
    assert set(get_all_subclasses(E)) == set([])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-20 15:21:43.664655
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a dummy class hierarchy
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    # Call the function to get all subclasses of A
    subclasses = get_all_subclasses(A)
    assert set(subclasses) == {B, C, D, E}

    # Call the function to get all subclasses of B
    subclasses = get_all_subclasses(B)
    assert set(subclasses) == {D}

# Generated at 2022-06-20 15:21:46.667888
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(object):
        pass
    assert get_all_subclasses(A) == set((B, C, D))
    assert get_all_subclasses(object) == set((A, B, C, D, E))

# Generated at 2022-06-20 15:21:55.100464
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(object):
        pass
    assert(set(get_all_subclasses(A)) == set([B, C, D]))
    assert(set(get_all_subclasses(B)) == set([C]))
    assert(set(get_all_subclasses(C)) == set([]))
    assert(set(get_all_subclasses(D)) == set([]))
    assert(set(get_all_subclasses(E)) == set([]))

# Generated at 2022-06-20 15:22:06.305442
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for the get_all_subclasses function
    '''
    class A(object):
        pass
    assert get_all_subclasses(A) == set()
    # Test with one subclass
    class B(A):
        pass
    assert get_all_subclasses(A) == set([B])
    # Test with multiple subclasses
    class C(B):
        pass
    assert get_all_subclasses(A) == set([C, B])
    # Test with a class inheriting from two classes
    class D(A):
        pass
    class E(D, B):
        pass
    assert get_all_subclasses(A) == set([E, C, D, B])

if __name__ == '__main__':
    test_get_all_subclasses()

# Generated at 2022-06-20 15:22:18.076878
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    A class for testing the get_all_subclasses function.

    Given the following classes and subclasses::

      A
     / \\
    B   C
   / \\
  D   E

    An instance of this class would return the following set::

      {B, C, D, E}

    :rtype: set
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D, E}

# Generated at 2022-06-20 15:22:22.940519
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(A):
        pass

    assert set(get_all_subclasses(object)) == set([A, B, C, D])
    assert set(get_all_subclasses(B)) == set()
    assert set(get_all_subclasses(C)) == set()
    assert set(get_all_subclasses(A)) == set([C, D])
    assert set(get_all_subclasses(D)) == set()

# Generated at 2022-06-20 15:22:30.077865
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set()

# Generated at 2022-06-20 15:22:34.124672
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B:
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(C):
        pass
    class F(C):
        pass
    class G(D):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert G in get_all_subclasses(A)

# Generated at 2022-06-20 15:22:45.045881
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D, E}
    assert set(get_all_subclasses(B)) == {C, D, E}
    assert set(get_all_subclasses(C)) == set()
    assert set(get_all_subclasses(D)) == {E}
    assert set(get_all_subclasses(E)) == set()


# Generated at 2022-06-20 15:22:50.831755
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(A):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])

# Generated at 2022-06-20 15:22:54.437603
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D}



# Generated at 2022-06-20 15:23:01.116078
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(E):
        pass

    class G(D):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])



# Generated at 2022-06-20 15:23:05.002818
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    assert set((A, B, C, D, E)) == get_all_subclasses(A)

# Generated at 2022-06-20 15:23:10.564859
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define some classes
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    # Check all subclasses
    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([])
    assert get_all_subclasses(C) == set([D, E])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(object) == set([A, B, C, D, E])

# Generated at 2022-06-20 15:23:26.264844
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    Test if function get_all_subclasses works as expected
    """

    class TestClass0:
        pass

    class TestClass1(TestClass0):
        pass

    class TestClass2(TestClass1):
        pass

    class TestClass3(TestClass0):
        pass

    class TestClass4(TestClass3):
        pass

    class TestClass5(TestClass3):
        pass

    class TestClass6(TestClass4):
        pass

    class TestClass7(TestClass4):
        pass

    class TestClass8(TestClass5):
        pass

    class TestClass9(TestClass5):
        pass

    class TestClass10(TestClass2):
        pass

    class TestClass11(TestClass8):
        pass


# Generated at 2022-06-20 15:23:36.211195
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(A):
        pass

    class F(B, E):
        pass

    class G(B, E):
        pass

    class H(B, E):
        pass

    class I(D, F, G, H):
        pass

    class J(I):
        pass

    class K(J):
        pass

    class L(J):
        pass

    class M(J):
        pass

    all_subclasses = get_all_subclasses(A)

# Generated at 2022-06-20 15:23:43.368685
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import copy
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(object):
        pass

    class F(E):
        class G(C):
            pass

    # this is a shallow copy because we use '==' in our test, not 'is'
    result = copy.copy(get_all_subclasses(A))

    expect = set([B, C, D, F.G])

    assert expect == result



# Generated at 2022-06-20 15:23:50.397282
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # The tree is faked to test the output of the function
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    # Testing the function
    assert all([
        A in get_all_subclasses(A),
        B in get_all_subclasses(A),
        C in get_all_subclasses(A),
        D in get_all_subclasses(A),
        E in get_all_subclasses(A),
    ])

# Generated at 2022-06-20 15:23:57.698694
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Testing if subclasses are returned
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    declared_subclasses = [B, C, D]
    assert declared_subclasses == get_all_subclasses(A)
    # Testing if order is saved
    assert [B, C, D] == get_all_subclasses(A)

    # Testing that all classes are included
    class E(D):
        pass

    assert [E] == get_all_subclasses(D)
    # Should return A, B and C
    assert [B, C, E] == get_all_subclasses(A)

    # Testing that nothing is in the class itself
    assert [] == get_all_subclasses(E)

# Generated at 2022-06-20 15:24:06.730160
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(D):
        pass
    class H(D):
        pass
    class I(F):
        pass
    class J(F):
        pass
    class K(F):
        pass

    assert get_all_subclasses(A) == set([B,C,D,E,F,G,H,I,J,K])

# Generated at 2022-06-20 15:24:13.049522
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit test for function get_all_subclasses()
    '''
    import _utils
    class A(): pass
    class B(A): pass
    class C(A): pass
    class E(C): pass
    class D(B): pass
    class F(D): pass

    assert _utils.get_all_subclasses(A) == set({B, C, D, E, F})
    assert _utils.get_all_subclasses(B) == set({D, F})
    assert _utils.get_all_subclasses(C) == set({E})
    assert _utils.get_all_subclasses(D) == set({F})



# Generated at 2022-06-20 15:24:19.735268
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B:
        pass
    class C:
        pass

    class AB(A, B, C):
        pass

    class ABAB(AB, A, B):
        pass

    class ABABAB(ABAB, AB, A, B, A):
        pass

    assert set(get_all_subclasses(AB)) == set([ABAB, AB, ABABAB, A, B, C])

# Generated at 2022-06-20 15:24:27.516142
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Unit tests for the :py:meth:`get_all_subclass` function.
    '''

    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(B):
        pass
    class G(F):
        pass
    class H(C):
        pass
    class I(C):
        pass
    class J(D):
        pass

    assert set([B, C, D, E, F, G, H, I, J]) == get_all_subclasses(A)

# Generated at 2022-06-20 15:24:35.015128
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create a simple class hierarchy
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    # Extract all subclasses of A
    extracted_subclasses = get_all_subclasses(A)
    expected_subclasses = set([B, C, D, E])
    assert extracted_subclasses == expected_subclasses

# Generated at 2022-06-20 15:24:53.562456
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Setup test classes
    class A(object):
        pass
    class B1(A):
        pass
    class B2(A):
        pass
    class C1(B1):
        pass
    class C2(B1):
        pass
    class D(B2):
        pass
    # Verify that the set of direct subclasses of A is equal to the set of
    # indirect subclasses of A, including A itself.
    assert get_all_subclasses(A) == set([A, B1, B2, C1, C2, D])

# Generated at 2022-06-20 15:25:03.994828
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(A):
        pass

    assert F in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert G in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert E in get_all_subclasses(A)
    assert F in get_all_subclasses(A)

    assert set([F, G]) == get_all_subclasses(C)
    assert set([D, E]) == get_all

# Generated at 2022-06-20 15:25:12.204502
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass
    class E(A):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E])
    assert get_all_subclasses(B) == set([])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])

    class Z(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, Z])

# Generated at 2022-06-20 15:25:22.216691
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(A):
        pass
    class F(E):
        pass
    assert set(get_all_subclasses(A)) == {B, C, D, E, F}
    assert set(get_all_subclasses(B)) == {C, D}
    assert set(get_all_subclasses(C)) == set()
    assert set(get_all_subclasses(D)) == set()
    assert set(get_all_subclasses(E)) == {F}
    assert set(get_all_subclasses(F)) == set()

# Generated at 2022-06-20 15:25:30.183210
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test for recursively searching the subclasses of a class.
    '''

    # Defining a test class
    class A(object):
        pass
    a = A()

    # Defining a first subclass
    class B(a.__class__):
        pass
    b = B()

    # Defining a second subclass
    class C(a.__class__):
        pass
    c = C()

    # Defining a third subclass
    class D(c.__class__):
        pass
    d = D()

    # Testing if the function returns the correct result
    subclasses = set([c.__class__,d.__class__])
    results = set(get_all_subclasses(a.__class__))
    assert subclasses == results


# Generated at 2022-06-20 15:25:37.096553
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    classes = get_all_subclasses(A)
    assert len(classes) == 6
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert A not in classes

# Generated at 2022-06-20 15:25:47.497060
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(B, C):
        pass
    # Test
    assert E in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert F in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert E not in get_all_subclasses(B)
    assert F not in get_all_subclasses(B)
    assert A not in get_all_subclasses(A)



# Generated at 2022-06-20 15:25:54.329822
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(F):
        pass
    class H(G):
        pass

    # Test the recursivity
    assert get_all_subclasses(A) == set([B, C, E, D, F, G, H])
    # Test excluding duplicates
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(H) == set()



# Generated at 2022-06-20 15:26:05.549976
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class TestClass1:
        pass

    class TestClass2(TestClass1):
        pass

    class TestClass3(TestClass1):
        pass

    class TestClass4(TestClass2):
        pass

    class TestClass5(TestClass3):
        pass

    class TestClass6:
        pass

    result = get_all_subclasses(TestClass1)
    assert TestClass2 in result
    assert TestClass3 in result
    assert TestClass4 in result
    assert TestClass5 in result
    assert TestClass6 not in result

    result = get_all_subclasses(TestClass6)
    assert TestClass2 not in result
    assert TestClass3 not in result
    assert TestClass4 not in result
    assert TestClass5 not in result
    assert TestClass6 not in result

# Generated at 2022-06-20 15:26:12.422748
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(G):
        pass
    class J(G):
        pass
    class K(H, I, J):
        pass
    assert K in get_all_subclasses(A)
    subclasses = get_all_subclasses(A)
    assert len(subclasses) == 9
    assert A in subclasses
    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in sub

# Generated at 2022-06-20 15:26:42.053056
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(D):
        pass

    subclasses = get_all_subclasses(A)

    assert B in subclasses
    assert C in subclasses
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert G in subclasses

    # test if subclasses are not found
    subclasses2 = get_all_subclasses(A)
    assert subclasses2 != set()

    assert len(subclasses) == 7

# Generated at 2022-06-20 15:26:51.343941
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    # Testing get_all_subclasses
    assert get_all_subclasses(A) == set([B, C, D, E, F])
    assert get_all_subclasses(B) == set([D, E])
    assert get_all_subclasses(C) == set([F])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-20 15:27:02.362018
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Verify that the method get_all_subclasses returns the correct set of subclasses
    '''
    from collections import Counter
    from operator import mul
    from six.moves import reduce
    # Use a set of test classes and map them in groups by parent class
    # Defines a group of classes with a common parent.
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(C):
        pass
    class I(D):
        pass
    class J(D):
        pass
    class K(E):
        pass
    class L(E):
        pass


# Generated at 2022-06-20 15:27:11.800517
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:pass
    class B: pass
    class C(A): pass
    class D(A): pass
    class E(D): pass
    class F(C): pass
    class G(D): pass
    class H(F): pass
    class X: pass
    class Y: pass
    class Z: pass
    set_of_subclasses = get_all_subclasses(A)
    assert set.union({E, F, G, H}, set_of_subclasses) == set_of_subclasses
    set_of_subclasses = get_all_subclasses(C)
    assert set.union({F, H}, set_of_subclasses) == set_of_subclasses
    set_of_subclasses = get_all_subclasses(X)

# Generated at 2022-06-20 15:27:23.118228
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections
    import itertools

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(E, F, G):
        pass

    # We will use OrderedDict to store expected results of get_all_subclasses.
    # An OrderedDict allow us to store the results in the same order of
    # the example above to make the test easier.
    class OrderedSet(collections.MutableSet):

        def __init__(self, iterable=None):
            self.end = end = []

# Generated at 2022-06-20 15:27:30.870085
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Test class hierarchy
    # A
    # |
    # B1
    # | \
    # B2  B3
    # |
    # C
    class A(object): pass
    class B1(A): pass
    class B2(B1): pass
    class B3(B1): pass
    class C(B2): pass
    subclasses = set((B1, B2, B3, C))
    assert subclasses == get_all_subclasses(A)

# Generated at 2022-06-20 15:27:37.555985
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """
    test_get_all_subclasses()
    Verify that get_all_subclasses() works as expected
    """
    class A(object): pass
    class B(A): pass
    class C(object): pass
    class D(A): pass

    assert(set(get_all_subclasses(object)) == set([A, C, B, D]))
    assert(set(get_all_subclasses(A)) == set([B, D]))
    assert(set(get_all_subclasses(B)) == set([]))

# Generated at 2022-06-20 15:27:46.092720
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C): pass
    class G(F): pass
    class H(G): pass

    assert set(get_all_subclasses(A)) == {B, C, D, E, F, G, H}
    assert set(get_all_subclasses(B)) == {D, E}
    assert set(get_all_subclasses(C)) == {F}
    assert set(get_all_subclasses(G)) == {H}
    assert set(get_all_subclasses(object)) == set()
    assert set(get_all_subclasses(G)) == {H}

    class X: pass
    class Y: pass

# Generated at 2022-06-20 15:27:57.222637
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(D):
        pass
    assert get_all_subclasses(A) == {B,C,D,E,F,G}
    assert get_all_subclasses(B) == {D,E,G}
    assert get_all_subclasses(C) == {F}
    assert get_all_subclasses(D) == {G}
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()
    assert get_all_subclasses(G) == set()



# Generated at 2022-06-20 15:28:07.544431
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:

        def __init__(self):
            pass

        def method_of_A(self):
            pass

    class B(A):

        def __init__(self):
            A.__init__(self)

        def method_of_B(self):
            pass

    class C(B):

        def __init__(self):
            B.__init__(self)

        def method_of_C(self):
            pass

    class D(B):

        def __init__(self):
            B.__init__(self)

        def method_of_D(self):
            pass

    a = A()
    b = B()
    c = C()
    d = D()
    assert get_all_subclasses(A) == set((B, C, D))
    assert get

# Generated at 2022-06-20 15:29:02.630143
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(D):
        pass

    a_subs = get_all_subclasses(A)
    b_subs = get_all_subclasses(B)
    assert a_subs == set([B, C, D, E, F])
    assert b_subs == set([D, E, F])
    assert set(A.__subclasses__()) == set([B, C])
    assert set(B.__subclasses__()) == set([D, E])
    assert set(D.__subclasses__()) == set([F])



# Generated at 2022-06-20 15:29:08.967673
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(A):
        pass
    class F(D):
        pass
    class G(object):
        pass
    class H(G):
        pass
    return get_all_subclasses(A) == set([B, C, D, E, F])

# Generated at 2022-06-20 15:29:16.598401
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class E(object):
        pass

    class F(E):
        pass

    class J(B, C, E, F):
        pass

    assert get_all_subclasses(A) == set([B, C, J])
    assert get_all_subclasses(E) == set([F, J])
    assert get_all_subclasses(object) == set([A, B, C, E, F, J])

# Generated at 2022-06-20 15:29:22.276234
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a:
        b = 1
    class b(a):
        c = 1
    class c(b):
        d = 1
    class d(c):
        e = 1
    class e(d):
        f = 10
    #
    result = get_all_subclasses(a)
    assert b in result
    assert c in result
    assert d in result
    assert e in result

# Generated at 2022-06-20 15:29:27.865771
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    When using this function, we want to verify it properly retrieves
    all of the descendent classes.  In order to do this, this function
    defines some classes and subclasses, and then tests the
    :py:meth:`get_all_subclasses` function against that data.

    This test verifies the following things:

    * The function returns the direct subclasses of a class.
    * The function returns indirect subclasses (subclass of subclass).
    * The function returns descendent classes from multiple branches.
    * The function does not return classes from other branches.
    '''
    # Define a base class which will be used for testing
    class A(object):
        pass

    # Define some direct subclasses of the above class
    class B(A):
        pass
    class C(A):
        pass

    #

# Generated at 2022-06-20 15:29:34.518423
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])

# Generated at 2022-06-20 15:29:44.488540
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test for get_all_subclasses

    This test is not intended to be a full coverage test, but rather
    to provide assurance that this function works as intended when
    called.  This function is used by test_utils.py, and if we're not
    testing the get_all_subclasses function we're testing something
    other than we think we're testing.
    '''
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(E):
        pass

    assert(set(get_all_subclasses(A)) == set([A, B, C, D, E, F]))

    class G(B):
        pass


# Generated at 2022-06-20 15:29:52.416699
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Define the test classes (class C will be used as parent)
    class C: pass
    class A(C): pass
    class B(C): pass
    class D(A): pass
    class E(D): pass
    class F(D): pass
    class G(E): pass
    class H(F): pass
    class I(G): pass
    class J(H): pass

    assert get_all_subclasses(C) == set((A, B, D, E, F, G, H, I, J))

# Generated at 2022-06-20 15:30:00.724011
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Defining a simple class hierarchy
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(object):
        pass

    # Testing function get_all_subclasses
    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(B)) == set([C])
    assert set(get_all_subclasses(C)) == set([])
    assert set(get_all_subclasses(D)) == set([])
    assert set(get_all_subclasses(E)) == set([])

# Generated at 2022-06-20 15:30:05.966073
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(C):
        pass

    classes = get_all_subclasses(A)
    classes_expected = set([B, C, D, E, F, G])
    assert classes == classes_expected