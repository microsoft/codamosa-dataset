

# Generated at 2022-06-20 15:20:45.595320
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E])

    # tests with multiple inheritance
    class F(B, D):
        pass
    class G(F):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G])

    # tests with indirect inheritance
    class H(D):
        pass
    class I(H):
        pass
    assert get_all_subclasses(A) == set([B, C, D, E, F, G, H, I])

# Generated at 2022-06-20 15:20:52.123509
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    x = get_all_subclasses(A)
    assert set(x) == set([B, C, D, E])

# Generated at 2022-06-20 15:20:59.698398
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(E): pass
    class G(F): pass
    assert(get_all_subclasses(A) == set([B, C, D, E, F, G]))
    assert(get_all_subclasses(B) == set([D]))
    assert(get_all_subclasses(C) == set([E]))
    assert(get_all_subclasses(D) == set())


# Generated at 2022-06-20 15:21:03.050829
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass

    # Normal case, we expect to retrieve all subclasses of A
    assert get_all_subclasses(A) == {B, C, D}

# Generated at 2022-06-20 15:21:07.969860
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class a(object):
        pass
    class b(a):
        pass
    class c(a):
        pass
    class d(c):
        pass
    assert get_all_subclasses(a) == {b, c, d}

# Generated at 2022-06-20 15:21:14.542191
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Test(object):
        pass
    class Test0(Test):
        pass
    class Test1(Test):
        pass
    class Test11(Test1):
        pass
    class Test111(Test11):
        pass
    class Test1111(Test111):
        pass
    class Test2(Test):
        pass
    assert {Test0, Test11, Test111, Test1111, Test1, Test2} == get_all_subclasses(Test)

# Generated at 2022-06-20 15:21:19.747265
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(B):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}

# Generated at 2022-06-20 15:21:26.516032
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    classes = get_all_subclasses(A)
    assert B in classes and C in classes and D in classes
    assert classes == set((B, C, D))

# Generated at 2022-06-20 15:21:36.658204
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(object): pass
    class D(B): pass
    class E(object): pass
    class F(E): pass
    assert  A in get_all_subclasses(A)
    assert  B in get_all_subclasses(A)
    assert  D in get_all_subclasses(A)
    assert  E not in get_all_subclasses(A)
    assert  F not in get_all_subclasses(A)
    # Test with multiple inheritance
    class MI2(object): pass
    class MI1(A, MI2): pass
    class MI3(MI1): pass
    assert MI3 in get_all_subclasses(A)
    assert MI3 in get_all_subclasses(MI2)

# Generated at 2022-06-20 15:21:46.119720
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test of function get_all_subclasses
    '''
    # Test if the function return all direct and indirect type
    class A(object):
        '''
        Test class A
        '''
        pass
    class B(A):
        '''
        Test class B
        '''
        pass
    class C(A):
        '''
        Test class C
        '''
        pass
    class D(B):
        '''
        Test class D
        '''
        pass
    class E(B):
        '''
        Test class E
        '''
        pass
    class F(C):
        '''
        Test class F
        '''
        pass
    class G(C):
        '''
        Test class G
        '''
        pass

# Generated at 2022-06-20 15:21:57.825275
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Foo:
        pass

    class Bar(Foo):
        pass

    class Buzz(Bar):
        pass

    class Buzzz(Buzz):
        pass

    assert set(Foo.__subclasses__()) == {Bar}
    assert set(Bar.__subclasses__()) == {Buzz}
    assert set(Buzz.__subclasses__()) == {Buzzz}
    assert set(Buzzz.__subclasses__()) == set()

    assert set(get_all_subclasses(Foo)) == {Bar, Buzz, Buzzz}
    assert set(get_all_subclasses(Bar)) == {Buzz, Buzzz}
    assert set(get_all_subclasses(Buzz)) == {Buzzz}
    assert set(get_all_subclasses(Buzzz)) == set()

# Generated at 2022-06-20 15:22:06.124620
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types

    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass

    assert set(get_all_subclasses(types.ModuleType)) == set()
    assert set(get_all_subclasses(B)) == set()
    assert set(get_all_subclasses(A)) == {B, C, D}
    assert set(get_all_subclasses(C)) == {D}
    assert set(get_all_subclasses(D)) == set()

# Generated at 2022-06-20 15:22:12.147981
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(E): pass
    class G(D): pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F, G])
    assert set(get_all_subclasses(B)) == set([D, G])
    assert set(get_all_subclasses(C)) == set([E, F])
    assert set(get_all_subclasses(D)) == set([G])
    assert set(get_all_subclasses(E)) == set([F])
    assert set(get_all_subclasses(F)) == set([])

# Generated at 2022-06-20 15:22:15.245246
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass

    assert set(get_all_subclasses(A)) == set([B, C])

# Generated at 2022-06-20 15:22:26.654287
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import sys, os.path
    # Importing a module in python can be tricky, this is the easiest way to do it
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'module_utils'))
    from openconfig_module_utils.module.generic_utils import get_all_subclasses
    from ansible.module_utils.network import cliconf

    # Here we define a base class for testing
    class TestClass(object):
        pass

    # Defining two implementation
    class TestClass1(TestClass):
        pass

    class TestClass2(TestClass):
        pass

    # Defining some childs
    class TestClass3(TestClass1):
        pass

    class TestClass4(TestClass2):
        pass

    # Test with Test

# Generated at 2022-06-20 15:22:33.246940
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Creating a class
    class BaseClass:
        pass
    # Creating a subclass of BaseClass
    class Class1(BaseClass):
        pass
    # Creating another subclass of BaseClass
    class Class2(BaseClass):
        pass
    # Creating a subclass of Class1
    class Class1_1(Class1):
        pass
    # Creating a subclass of Class2
    class Class2_1(Class2):
        pass
    # Creating a subclass of Class2
    class Class2_2(Class2):
        pass
    # Creating a subclass of Class2_2
    class Class2_2_1(Class2_2):
        pass
    # Creating a subclass of Class2
    class Class2_3(Class2):
        pass

    # Testing get_all_subclasses on BaseClass
    subclasses = get_all_

# Generated at 2022-06-20 15:22:38.058785
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(A): pass
    class E(B): pass
    class F(B): pass
    assert set(get_all_subclasses(A)) == set([B, C, D, E, F])
    assert set(get_all_subclasses(B)) == set([E, F])


# Generated at 2022-06-20 15:22:45.309089
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import inspect

    class Base(object):
        pass

    class Child1(Base):
        pass

    class Child2(Base):
        pass

    class GrandChild1(Child1):
        pass

    class GrandChild2(Child1):
        pass

    class GrandChild3(Child2):
        pass

    class GreatGrandChild1(GrandChild1):
        pass

    class GreatGrandChild2(GrandChild1):
        pass

    class GreatGrandChild3(GrandChild2):
        pass

    class GreatGrandChild4(GrandChild3):
        pass

    class GreatGrandChild4(GrandChild3):
        pass

    class NotGreatGrandChild(object):
        pass



# Generated at 2022-06-20 15:22:51.703098
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == {D, E}

# Generated at 2022-06-20 15:23:02.819926
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    def assert_subclass_list_equal(subclasses, actual_subclasses):
        actual_subclasses = set(actual_subclasses)
        for ac in actual_subclasses:
            assert ac in subclasses
        for s in subclasses:
            assert s in actual_subclasses

    # A simple class like :
    #
    #     class A(object):
    #         pass
    #
    #     class B(A):
    #         pass
    #
    #     class C(A):
    #         pass
    #
    #     class D(B):
    #         pass
    #
    #     class E(D):
    #         pass
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass

# Generated at 2022-06-20 15:23:17.420324
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class Parent(object):
        pass

    class Child1(Parent):
        pass

    class Child2(Parent):
        pass

    class GrandChild1_1(Child1):
        pass

    class GrandChild1_2(Child1):
        pass

    class GrandChild2_1(Child2):
        pass

    class GrandGrandChild2_1_1(GrandChild2_1):
        pass

    class GrandGrandChild2_1_2(GrandChild2_1):
        pass

    class GrandGrandChild2_1_3(GrandChild2_1):
        pass

    subclasses = get_all_subclasses(Parent)
    assert(len(subclasses) == 8)

    subclasses = get_all_subclasses(Child1)
    assert(len(subclasses) == 2)

    subclasses = get_

# Generated at 2022-06-20 15:23:23.801791
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass

    assert get_all_subclasses(A) == {B, D, C}
    assert get_all_subclasses(B) == set()
    assert get_all_subclasses(C) == {D}
    assert get_all_subclasses(D) == set()

# Generated at 2022-06-20 15:23:33.470151
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    """Verify that get_all_subclasses(B) returns [E,C,D] when class tree is:

             A
            / \
           B   F
          / \
         C   D
          \
           E
    """
    def test_class_tree():
        class A(object):
            pass
        class B(A):
            pass
        class C(B):
            pass
        class D(B):
            pass
        class E(C):
            pass
        class F(A):
            pass
        return A,B,C,D,E,F

    A,B,C,D,E,F = test_class_tree()
    assert E in get_all_subclasses(B)
    assert C in get_all_subclasses(B)
    assert D in get_all_subclasses

# Generated at 2022-06-20 15:23:39.284570
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(D): pass
    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(B) == {C}
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == {E}


# Generated at 2022-06-20 15:23:48.289067
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class C1():
        pass

    class C2():
        pass

    class C3(C1):
        pass

    class C4(C3):
        pass

    class C5(C3):
        pass

    class C6(C2):
        pass

    class C7(C5):
        pass

    class C8(C5):
        pass

    class C9(C8):
        pass

    expected = set([C3, C4, C5, C7, C8, C9])
    actual = get_all_subclasses(C1)
    assert actual == expected, \
        "Expected subclasses are %s. Actual subclasses are %s." % (expected, actual)

# Generated at 2022-06-20 15:23:52.403014
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    result = get_all_subclasses(A)

    assert len(result) == 3
    assert B in result
    assert C in result
    assert D in result

# Generated at 2022-06-20 15:24:01.691981
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass
    class E(object): pass

    assert set(get_all_subclasses(A)) == set([B, C, D])
    assert set(get_all_subclasses(E)) == set([])


valid_names = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_')


# Generated at 2022-06-20 15:24:10.512569
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Defining some test classes
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(object):
        pass

    class F(E):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([])
    assert get_all_subclasses(E) == set([F])
    assert get_all_subclasses(F) == set([])

# Generated at 2022-06-20 15:24:21.198105
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test the get_all_subclasses function.
    '''

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert D not in get_all_subclasses(C)

    assert D in get_all_subclasses(A)

    assert A not in get_all_subclasses(A)

    assert C in get_all_subclasses(A)

    # Ensuring that we get out of the loop with a big number of subclasses
    l = ['cls%s' % i for i in range(1000)]
    for cls in l:
        exec('class %s(object):pass' % cls)
    # Check only the first 5 elements

# Generated at 2022-06-20 15:24:29.902878
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    assert set(get_all_subclasses(A)) == set([B, D, C, E])
    assert set(get_all_subclasses(object)) == set()
    assert set(get_all_subclasses(B)) == set([D])

    # Test non-class test with simple object
    class F(object):
        pass
    # All subclasses are visited, so it should raise a TypeError
    class G(F):
        pass
    try:
        get_all_subclasses(F())
    except TypeError as e:
        print("Error: %s" % e)
        raise e

# Generated at 2022-06-20 15:24:44.193873
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # pylint:disable=invalid-name,too-few-public-methods
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(D):
        pass

    class H(F):
        pass

    classes = get_all_subclasses(A)

    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert G in classes
    assert H in classes

    assert A not in classes
    assert object not in classes

    # Test that we return an empty set from an empty class
    assert set() == get_all_subclasses(object)

# Generated at 2022-06-20 15:24:48.039947
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    assert set(get_all_subclasses(A)) == set([B, C, D])

# Generated at 2022-06-20 15:24:53.159880
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(C):
        pass

    assert get_all_subclasses(A) == set([B, C, D, E, F])

# Generated at 2022-06-20 15:24:59.616873
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Defining a class tree
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E:
        pass

    # Building the expected class tree
    expected_classes = {B, D}

    # Getting classes from get_all_subclasses
    classes = get_all_subclasses(A)

    # Comparing classes tree
    assert classes == expected_classes

# Generated at 2022-06-20 15:25:05.225760
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    classes = get_all_subclasses(A)
    assert len(classes) == 6

    classes = get_all_subclasses(B)
    assert len(classes) == 4
    assert D in classes
    assert E in classes

# Generated at 2022-06-20 15:25:14.277137
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Create the following tree of classes
    # Foo
    # |-- Bar
    # |-- Baz
    #     |-- Qux
    #         |-- Quux
    #     |-- Corge
    #         |-- Grault
    # |-- Graply
    #     |-- Waldo
    class Foo(object):
        pass

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    class Qux(Baz):
        pass

    class Quux(Qux):
        pass

    class Corge(Baz):
        pass

    class Grault(Corge):
        pass

    class Graply(Foo):
        pass

    class Waldo(Graply):
        pass

    # Test that get_all_subclasses functions properly
    classes = get_all_subclasses(Foo)
    subclasses

# Generated at 2022-06-20 15:25:20.343448
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass

    # The expected value for this test
    expected_value = set([B, C, D, E])
    # The real value from get_all_subclasses
    real_value = get_all_subclasses(A)

    assert expected_value == real_value

# Generated at 2022-06-20 15:25:25.761036
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import collections

    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(A): pass

    assert set(get_all_subclasses(A)) == set([C, D])
    assert set(get_all_subclasses(object)) == set([A, B, C, D])
    assert set(get_all_subclasses(collections.OrderedDict)) == set([])

# Generated at 2022-06-20 15:25:30.098513
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Make sure we get what we expect.
    '''
    class Base(object):
        pass

    class A(Base):
        pass

    class B(Base):
        pass

    class C(A):
        pass

    assert get_all_subclasses(Base) == set([A, B, C])

    class D(C):
        pass

    assert get_all_subclasses(Base) == set([A, B, C, D])

# Generated at 2022-06-20 15:25:41.426579
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from collections import OrderedDict

    def class_tree(cls, visited=None, result_list=None):
        if not visited:
            visited = set()
        if not result_list:
            result_list = []
        visited.add(cls)
        # We want to treat subclasses as a list sorted by their name.
        subclasses = sorted(cls.__subclasses__(), key=lambda cls: cls.__name__)
        for sc in subclasses:
            if sc in visited:
                continue
            result_list.append(sc)
            class_tree(sc, visited, result_list)
        return result_list

    # The following is the complete class tree for OrderedDict.  This is used as the expected value for
    # the unittest.

# Generated at 2022-06-20 15:25:55.761843
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert get_all_subclasses(A) == set([B, D, C])
    assert get_all_subclasses(B) == set([D])

# Generated at 2022-06-20 15:26:01.682463
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class B(object):
        pass

    class C(object):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    assert B.__subclasses__() == [C, D, E, F]
    assert set([D, E, C, F, B]) == get_all_subclasses(object)

# Generated at 2022-06-20 15:26:07.312314
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(B):
        pass

    assert get_all_subclasses(A) == {B, C, D, E, F}
    assert get_all_subclasses(B) == {F}
    assert get_all_subclasses(C) == {D, E}

# Generated at 2022-06-20 15:26:13.719344
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A:
        '''
        class used to test get_all_subclasses
        '''
        pass

    class B(A):
        '''
        class used to test get_all_subclasses
        '''
        pass

    class C(A):
        '''
        class used to test get_all_subclasses
        '''
        pass

    class D(B):
        '''
        class used to test get_all_subclasses
        '''
        pass

    class E(C):
        '''
        class used to test get_all_subclasses
        '''
        pass

    class F(C):
        '''
        class used to test get_all_subclasses
        '''
        pass


# Generated at 2022-06-20 15:26:20.036330
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(object):
        pass

    assert get_all_subclasses(A) == {B, C, D, E}
    assert get_all_subclasses(E) == set()
    assert get_all_subclasses(F) == set()



# Generated at 2022-06-20 15:26:26.471602
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    assert get_all_subclasses(A) == set([B, C, D])
    assert get_all_subclasses(B) == set([D])
    assert get_all_subclasses(C) == set([])
    assert get_all_subclasses(D) == set([])

# Generated at 2022-06-20 15:26:32.727732
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import unittest
    import textwrap

    def create_class(name, extra_code=''):
        code = textwrap.dedent('''
        class {}(object):
            pass
        '''.format(name))

        d = {}
        exec(code, d)
        return d[name]

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(B):
        pass

    class F(A):
        pass

    class G(F):
        pass

    class H(G):
        pass

    expected = [A, B, C, D, E, F, G, H]

    class_dict = {}

    # Create a bunch of classes with a similar structure to the one above

# Generated at 2022-06-20 15:26:42.249218
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import os
    import sys
    import tempfile

    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass

    assert A in get_all_subclasses(A)
    assert B in get_all_subclasses(A)
    assert C in get_all_subclasses(A)
    assert D in get_all_subclasses(A)
    assert not B in get_all_subclasses(B)
    assert D in get_all_subclasses(B)
    assert not B in get_all_subclasses(C)
    assert not D in get_all_subclasses(C)
    assert not C in get_all_subclasses(B)
    assert not D in get_all_subclasses(C)
   

# Generated at 2022-06-20 15:26:49.763547
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(object):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    class G(object):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class J(F, I):
        pass

    import pprint
    pprint.pprint(get_all_subclasses(A))

# Generated at 2022-06-20 15:27:00.525854
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    from _utils import get_all_subclasses
    from ansible.plugins.module_utils import basic
    from ansible.plugins.module_utils import utilities
    from ansible.plugins.module_utils.connections import ssh
    from ansible.plugins.module_utils.connections import winrm

    assert basic.AnsibleModule in get_all_subclasses(basic.AnsibleModule)

    # Test if we really get all subclasses
    assert basic.AnsibleModule in get_all_subclasses(basic.AnsibleModule)

    assert utilities.AnsibleModule in get_all_subclasses(utilities.AnsibleModule)
    assert utilities.BasicModule in get_all_subclasses(utilities.AnsibleModule)

# Generated at 2022-06-20 15:27:27.040982
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    # Example of class structure
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(A):
        pass

    # Test function
    found = get_all_subclasses(A)
    # Assert all classes are found
    assert B in found
    assert C in found
    assert D in found
    assert E in found

    # Assert no unwanted class are in the set
    assert A not in found

# Generated at 2022-06-20 15:27:31.642264
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D): pass

    assert set(get_all_subclasses(A)) == set([B, D, C, F, E])

# Generated at 2022-06-20 15:27:41.126597
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''Tiny class tree for test purpose'''
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H():
        pass

    # Behavior of __subclasses__ is only available in Python 2.6+
    if hasattr(A, '__subclasses__'):
        assert G in get_all_subclasses(A), 'G should be a subclasses of A'
        assert F in get_all_subclasses(A), 'F should be a subclasses of A'
        assert H not in get_all_subclasses(A), 'H should not be a subclasses of A'

# Generated at 2022-06-20 15:27:44.196513
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class Animal:
        pass

    class Carnivore(Animal):
        pass

    class Carnivora(Animal):
        pass

    c = Carnivora()
    cv = Carnivore()
    # Get all subclasses
    subclasses = get_all_subclasses(Animal)
    # Unit test
    assert Carnivora in subclasses
    assert Carnivore in subclasses

# Generated at 2022-06-20 15:27:50.847245
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import types

    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(types.ModuleType):
        pass

    class G(F):
        pass

    assert set(get_all_subclasses(D)) == set([D, G, E])
    assert set(get_all_subclasses(B)) == set([B, D, E, G])

# Generated at 2022-06-20 15:27:57.451812
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class GrandPa(object):
        pass

    class Papa(GrandPa):
        pass

    class Uncle(GrandPa):
        pass

    class Son1(Papa):
        pass

    class Son2(Papa):
        pass

    class Cousin(Uncle):
        pass

    expected_subclasses = {Son1, Son2, Cousin}
    assert get_all_subclasses(GrandPa) == expected_subclasses

# Generated at 2022-06-20 15:28:07.510372
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        """Class A"""
        pass

    class B(A):
        """Class B"""
        pass

    class C(A):
        """Class C"""
        pass

    class D(B):
        """Class D"""
        pass

    class E(B):
        """Class E"""
        pass

    class F(C):
        """Class F"""
        pass

    subclasses = get_all_subclasses(A)
    assert D in subclasses
    assert E in subclasses
    assert F in subclasses
    assert B in subclasses
    assert C in subclasses
    assert len(subclasses) == 5

    subclasses = get_all_subclasses(B)
    assert D in subclasses
    assert E in subclasses
    assert len(subclasses) == 2

    subclasses = get_

# Generated at 2022-06-20 15:28:15.273612
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    def compare(expected_classes, classes):
        for cls in classes:
            if cls not in expected_classes:
                raise AssertionError('Expected class %s is missing' % cls)
        if len(classes) != len(expected_classes):
            raise AssertionError('Expected %d classes, got %d' % (len(expected_classes), len(classes)))

    compare([A], get_all_subclasses(object))
    compare([B, C, D], get_all_subclasses(A))

# Generated at 2022-06-20 15:28:21.399032
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class Base: pass
    class Sub1(Base): pass
    class SubSub1(Sub1): pass
    class SubSub2(Sub1): pass

    assert get_all_subclasses(Base) == {Sub1, SubSub1, SubSub2}
    assert get_all_subclasses(Sub1) == {SubSub1, SubSub2}
    assert get_all_subclasses(SubSub1) == set()



# Generated at 2022-06-20 15:28:24.187573
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    assert set(get_all_subclasses(A)) == set([B, C])


# Generated at 2022-06-20 15:29:20.376144
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    classes = get_all_subclasses(A)
    assert classes == set([B, C, D])

# Generated at 2022-06-20 15:29:25.195274
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(F):
        pass
    classes = get_all_subclasses(A)
    assert A in classes
    assert B in classes
    assert C in classes
    assert D in classes
    assert E in classes
    assert F in classes
    assert G in classes
    assert len(classes) == 7

# Generated at 2022-06-20 15:29:34.255158
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(F):
        pass

    result = get_all_subclasses(A)
    assert B in result
    assert C in result
    assert D in result
    assert E in result
    assert F in result
    assert G in result
    assert G in result
    assert H in result
    assert len(result) == 7

# Generated at 2022-06-20 15:29:37.058729
# Unit test for function get_all_subclasses
def test_get_all_subclasses():

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    assert set(get_all_subclasses(A)) == {B, C, D}, 'test_get_all_subclasses: get_all_subclasses(A) failed'

# Generated at 2022-06-20 15:29:45.341425
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass
    class B(object):
        pass
    class C(object):
        pass
    class D(A):
        pass
    class E(A):
        pass
    class F(B):
        pass
    class G(E):
        pass

    assert get_all_subclasses(A) == set([D, E, G])
    assert get_all_subclasses(B) == set([F])
    assert get_all_subclasses(C) == set()
    assert get_all_subclasses(D) == set()
    assert get_all_subclasses(E) == set([G])
    assert get_all_subclasses(F) == set()
    assert get_all_subclasses(G) == set()

# Generated at 2022-06-20 15:29:56.685440
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test get_all_subclasses.  This is written to run against Python 2
    '''

    from _pytest.assertion import rewrite

    # Setup test data:
    #  This test sets up a simple class heirarchy and then queries for all subclasses
    #  and compares them with what we expect

    class BaseClass(object):  # pylint: disable=too-few-public-methods
        pass

    class SubClass1(BaseClass):  # pylint: disable=too-few-public-methods
        pass

    class SubClass2(BaseClass):  # pylint: disable=too-few-public-methods
        pass

    class SubSubClass21(SubClass2):  # pylint: disable=too-few-public-methods
        pass


# Generated at 2022-06-20 15:30:02.488950
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(B, D):
        pass

    assert(set([B, C, D, E, F]) == get_all_subclasses(A))
    assert(set([E]) == get_all_subclasses(D))

# Generated at 2022-06-20 15:30:05.727498
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    '''
    Test function get_all_subclasses.
    '''
    subclasses = get_all_subclasses(UserDict)
    assert dict in subclasses
    assert UserDict in subclasses
    assert UserList in subclasses
    assert UserString in subclasses



# Generated at 2022-06-20 15:30:09.389725
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    class A():
        pass

    class B():
        pass

    class C(B):
        pass

    class D(A):
        pass

    assert get_all_subclasses(type) == {
        type,
        object,
        tuple,
        str,
        A,
        B,
        C,
        D
    }



# Generated at 2022-06-20 15:30:19.791625
# Unit test for function get_all_subclasses
def test_get_all_subclasses():
    import six
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass

    assert set(get_all_subclasses(six.class_types)) == set([A, B, C, D, E])
    assert set(get_all_subclasses(A)) == set([B, C, D, E])
    assert set(get_all_subclasses(B)) == set([])
    assert set(get_all_subclasses(C)) == set([D, E])
    assert set(get_all_subclasses(D)) == set([E])
    assert set(get_all_subclasses(E)) == set([])