

# Generated at 2022-06-20 15:07:52.801126
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host = Host('hostname')
    host.set_variable('hostname', 'server1')
    assert host.vars['hostname'] == 'server1'

    host.set_variable('hostname', 'server2')
    assert host.vars['hostname'] == 'server2'

    host.set_variable('hosts', {'host1': '1.1.1.1', 'host2': '2.2.2.2'})
    assert host.vars['hosts'] == {'host1': '1.1.1.1', 'host2': '2.2.2.2'}

    host.set_variable('hosts', {'host3': '3.3.3.3'})

# Generated at 2022-06-20 15:07:56.511025
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    # Create object
    host = Host()

    # Set name
    host.name = 'host01'

    # Check results
    assert host.get_magic_vars() == {
        'inventory_hostname': 'host01',
        'inventory_hostname_short': 'host01',
        'group_names': [],
    }


# Generated at 2022-06-20 15:08:07.003606
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    """
    Test case:
    Setup:
    1. Make a group and set group vars.
    2. Add host to group.
    3. Set host vars.
    Test:
    1. Get host vars.
    Verify:
    1. Host vars must contain group vars and host vars.
    2. Host vars must not contain magic vars.
    3. Group vars and host vars must not be overriden by magic vars.
    """
    test_group = Group('test_group')
    test_group_vars = { 'test_group_var1': 'test_group_value1', 'test_group_var2': 'test_group_value2' }
    test_group.vars = test_group_vars.copy()

# Generated at 2022-06-20 15:08:11.808838
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    host = Host()
    result = host.get_vars()
    assert result['inventory_hostname'] == host.name
    assert result['inventory_hostname_short'] == host.name.split('.')[0]
    assert result['group_names'] == sorted([g.name for g in host.get_groups() if g.name != 'all'])

# Generated at 2022-06-20 15:08:17.790249
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    h = Host(name='fakehost.example.com')
    assert h.get_magic_vars() == {u'inventory_hostname': u'fakehost.example.com', u'inventory_hostname_short': u'fakehost', u'group_names': []}

# Generated at 2022-06-20 15:08:20.222000
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    host = Host('foo')
    expected = hash('foo')
    actual = host.__hash__()
    assert actual == expected

# Generated at 2022-06-20 15:08:25.313511
# Unit test for method serialize of class Host
def test_Host_serialize():
    h = Host('test.example.com', 123)
    s = h.serialize()

    assert s['name'] == 'test.example.com'
    assert s['address'] == 'test.example.com'
    assert s['vars'] == dict(ansible_port=123)
    assert s.get('uuid', None) is not None
    assert s['implicit'] == False



# Generated at 2022-06-20 15:08:31.949763
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    host = Host(name='127.0.0.1')
    assert host != None
    assert host != 'invalid type'
    host2 = Host(name='127.0.0.2')
    assert host != host2

# Generated at 2022-06-20 15:08:35.819756
# Unit test for constructor of class Host
def test_Host():
    # Make sure the constructor works
    host = Host('localhost', port=22)
    assert(host.name == 'localhost')
    assert(host.get_variable('ansible_port') == 22)
    assert(host.address == 'localhost')


# Generated at 2022-06-20 15:08:41.473072
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    host = Host(name="test")
    vars = host.get_magic_vars()
    assert vars["inventory_hostname"] == "test"
    assert vars["inventory_hostname_short"] == "test"
    assert vars["group_names"] == []
    assert vars["inventory_hostname_short"] == "test"

# Generated at 2022-06-20 15:08:50.269441
# Unit test for method serialize of class Host
def test_Host_serialize():
    h = Host('test')

    # assume fail
    assert False

    # create instance of Host and perform test
    # assume fail if no exception thrown
    assert True


# Generated at 2022-06-20 15:08:56.432649
# Unit test for method __setstate__ of class Host
def test_Host___setstate__():

    from copy import deepcopy

    # Initialize host
    host = Host('localhost')
    host.vars['myvar'] = 'myvalue'

    # Initialize group
    group = Group('mygroup')
    group.vars['mygroupvar'] = 'mygroupvalue'
    group.add_child_group(Group('all'))

    # Add group to host
    host.add_group(group)

    # Copy the host
    host_copy = deepcopy(host)

    # Check that groups have the same vars
    assert host_copy.get_groups()[0].vars == host.get_groups()[0].vars



# Generated at 2022-06-20 15:09:03.598878
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    all_group = Group("all")
    group_a = Group("group_a")
    group_a1 = Group("group_a1")
    group_a2 = Group("group_a2")

    group_b = Group("group_b")
    group_b1 = Group("group_b1")
    group_b2 = Group("group_b2")

    group_a.add_child_group(group_a1)
    group_a.add_child_group(group_a2)
    group_b.add_child_group(group_b1)
    group_b.add_child_group(group_b2)

    host = Host("my_host")

    host.add_group(all_group)
    host.add_group(group_a)

# Generated at 2022-06-20 15:09:08.981021
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    h1 = Host(name="test")
    h2 = Host(name="test")

    assert h1 == h2
    assert hash(h1) == hash(h2)



# Generated at 2022-06-20 15:09:14.916743
# Unit test for method __str__ of class Host
def test_Host___str__():
    h = Host(name='localhost')
    f = Host(name='lala')
    assert str(h) == 'localhost'
    assert h.name == f.name
    assert not h == f
    assert h != f


# Generated at 2022-06-20 15:09:18.541280
# Unit test for method get_name of class Host
def test_Host_get_name():
    name = 'localhost'
    host = Host(name)
    assert(name == host.get_name())


if __name__ == "__main__":
    test_Host_get_name()

# Generated at 2022-06-20 15:09:23.510948
# Unit test for method __getstate__ of class Host
def test_Host___getstate__():
    host = Host('localhost')
    host.vars = {'ansible_ssh_port': 1234}
    host.address = '123.123.123.123'

    expected = {'name': 'localhost', 'vars': {'ansible_ssh_port': 1234}, 'address': '123.123.123.123',
                'uuid': host._uuid, 'groups': []}
    actual = host.__getstate__()

    assert expected == actual



# Generated at 2022-06-20 15:09:27.167112
# Unit test for method add_group of class Host
def test_Host_add_group():
    from ansible.inventory.group import Group

    g = Group()
    h = Host()

    h.add_group(g)
    assert g in h.get_groups()
    assert h in g.get_hosts()


# Generated at 2022-06-20 15:09:31.197977
# Unit test for method get_name of class Host
def test_Host_get_name():
    host_one = Host(gen_uuid=False)
    if host_one.get_name() is not None:
        return False
    else:
        return True


# Generated at 2022-06-20 15:09:41.252749
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    grp1 = Group("group1")
    grp2 = Group("group2")
    grp3 = Group("group3")
    grp4 = Group("group4")
    grp5 = Group("group5")
    grp6 = Group("group6")
    grp7 = Group("group7")
    grp8 = Group("group8")
    grp9 = Group("group9")
    grp10 = Group("group10")
    host1 = Host("host1")
    host2 = Host("host2")

    # Add host-grp relationships
    host1.add_group(grp1)
    host1.add_group(grp2)
    host1.add_group(grp3)
    host1.add_group(grp4)

# Generated at 2022-06-20 15:09:58.298507
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    g1 = Group()
    g1.name = 'g1'
    g2 = Group()
    g2.name = 'g2'
    g3 = Group()
    g3.name = 'g3'
    g4 = Group()
    g4.name = 'g4'
    g1.add_child_group(g2)
    g2.add_child_group(g3)
    g3.add_child_group(g4)
    h1 = Host(name = 'h1')
    h1.add_group(g1)
    h1.add_group(g4)

    groups = h1.get_groups()
    names = set([g.name for g in groups])
    assert set(['g1', 'g2', 'g3', 'g4']) == names

# Generated at 2022-06-20 15:10:03.196799
# Unit test for method serialize of class Host
def test_Host_serialize():
    '''
    Test serialize method of Host class.
    '''

    def get_host():
        '''
        Create a host object.
        '''
        host = Host('test_host')
        host.vars['v'] = 'vv'
        host.vars['k'] = {'kk': 'kkk'}
        host.groups = [Group('test_group_1'), Group('test_group_2')]
        host.address = 'test_address'
        host.port = 1
        host.implicit = True
        return host

    def test_serialize(host):
        '''
        Test serialization for host.
        '''
        data = host.serialize()
        # Check type of data

# Generated at 2022-06-20 15:10:14.257302
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    from ansible.inventory.group import Group
    
    host = Host(name='test')
    groupAll = Group(name='all')
    group1 = Group(name='group1', ancestors=[groupAll])
    group2 = Group(name='group2', ancestors=[groupAll])
    group2_1 = Group(name='group2_1', ancestors=[group2])
    
    # Test 1
    host.add_group(group1)
    host.add_group(group2)
    assert group1 in host.get_groups()
    assert group2 in host.get_groups()
    assert groupAll in host.get_groups()
    
    host.remove_group(group2)
    assert group1 in host.get_groups()
    assert group2 not in host.get_groups()
    assert groupAll not in host

# Generated at 2022-06-20 15:10:19.077841
# Unit test for method get_name of class Host
def test_Host_get_name():
    '''
    [Unit test for method get_name of class Host]
    '''
    host = Host(name = 'test')
    assert host.get_name() == 'test'


# Generated at 2022-06-20 15:10:22.913084
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    import unittest

    class TestGetVars(unittest.TestCase):

        def test_dictionary_replacement(self):
            host = Host('test')
            host.set_variable('test1', {'key': 'value', 'key2': 'value2'})
            host.set_variable('test1', {'key': 'value3'})
            self.assertEqual(host.get_vars(), {'test1': {'key': 'value3', 'key2': 'value2'}, 'inventory_hostname': 'test', 'inventory_hostname_short': 'test'})

        def test_dictionary_replacement_with_non_dictionary(self):
            host = Host('test')

# Generated at 2022-06-20 15:10:34.962787
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    # Initialize a host object
    host_obj1 = Host()
    # add a simple dict to its vars
    host_obj1.vars['foo'] = 'bar'
    # check that it was added
    assert host_obj1.get_vars()['foo'] == 'bar'
    # add a dict to its vars with the same key
    host_obj1.set_variable('foo', {'foo1': 'bar1'})
    # check that the dicts were combined
    assert host_obj1.get_vars()['foo']['foo1'] == 'bar1'
    # add a dict to its vars with the same key
    host_obj1.set_variable('foo', {'foo2': 'bar2'})
    # check that the dicts were combined

# Generated at 2022-06-20 15:10:46.338532
# Unit test for constructor of class Host
def test_Host():
    group_all = Group(name="all")
    group_all.vars = {'vars': {'a': '1'}}
    group_web = Group(name="web")
    group_web.vars = {'vars': {'b': '2'}}
    group_web.parents = [group_all]
    host_foo = Host(name="foo")
    host_bar = Host(name="bar")
    host_foo.groups.append(group_all)
    host_bar.groups.append(group_web)
    assert host_foo.get_vars() == {'inventory_hostname': 'foo', 'inventory_hostname_short': 'foo', 'group_names': ['all'], 'a': '1'}

# Generated at 2022-06-20 15:10:53.501301
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    hostA = Host('myhostA')
    hostA.set_variable('ansible_port', 1234)
    hostA.add_group(Group('mygroupA'))
    hostA.add_group(Group('mygroupB'))
    hostA.add_group(Group('mygroupC'))
    hostA_vars = hostA.get_vars()
    assert hostA_vars['ansible_port'] == 1234
    assert hostA_vars['inventory_hostname'] == 'myhostA'
    assert hostA_vars['group_names'] == ['mygroupA', 'mygroupB', 'mygroupC']
    assert 'ansible_port' in hostA_vars

    hostB = Host('myhostB')
    hostB.add_group(Group('mygroupA'))

# Generated at 2022-06-20 15:11:04.627232
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    test1 = Host(gen_uuid=False)
    test1.deserialize(dict(name="ansible.org", vars=dict(a=1, b=2)))
    assert(test1.name == "ansible.org")
    assert(test1.vars == dict(a=1, b=2))
    assert(test1.address == "ansible.org")
    assert(test1._uuid is None)
    assert(test1.groups == [])
    assert(test1.implicit is False)

    test2 = Host(gen_uuid=False)

# Generated at 2022-06-20 15:11:09.661378
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    h0 = Host()
    h1 = Host()

    assert(h0 != h1)


# Generated at 2022-06-20 15:11:18.761183
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    host1 = Host(name='foo')
    host2 = Host(name='bar')
    assert host1 != host2
    host2 = Host(name='foo')
    assert host1 == host2


# Generated at 2022-06-20 15:11:25.110529
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    host = Host()
    host.vars = {'a':1, 'b':2}
    # The following is a very brittle test - it assumes that the magic
    # variables are always present and in a certain order
    assert host.get_vars()  == {'a': 1, 'b': 2, 'group_names': [], 'inventory_hostname': None, 'inventory_hostname_short': None}



# Generated at 2022-06-20 15:11:36.178523
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    host1 = Host()
    host2 = Host('host2')
    host3 = Host('host3')
    host1.groups.append(Group('group1'))
    host2.groups.append(Group('group2'))
    host3.groups.append(Group('group3'))

    # test that two objects with different keys are not equal
    assert (host1 != host2)
    # test that two objects with the same keys are equal
    assert (host2 == host2)
    # test that two objects with the same keys have the same hash
    assert (hash(host2) == hash(host2))
    # test that two objects with different keys have different hashes
    assert (hash(host1) != hash(host2))
    assert (hash(host1) != hash(host3))

# Generated at 2022-06-20 15:11:43.192859
# Unit test for method add_group of class Host
def test_Host_add_group():
    # Given
    AnsibleGroup = Group("test1")
    AnsibleGroup.add_sub_group("subtest1")
    AnsibleGroup.add_sub_group("subtest2")
    AnsibleHost = Host("test1")

    # When
    AnsibleHost.add_group(AnsibleGroup)

    # Then
    assert len(AnsibleHost.get_groups()) == 3

# Generated at 2022-06-20 15:11:53.142560
# Unit test for method __setstate__ of class Host
def test_Host___setstate__():
    host1 = Host()
    host1.deserialize({'name':"host1", 'vars':{}, 'address':'', 'uuid':None, 'groups':[], 'implicit':False})
    assert host1.name == "host1"
    assert host1.vars == {}
    assert host1.address == ''
    assert host1._uuid == None
    assert len(host1.groups) == 0
    assert host1.implicit == False

    host1.deserialize({'name':"host1", 'vars':{'key1':'value1', 'key2':{'key3':'value3'}}, 'address':'', 'uuid':None, 'groups':[], 'implicit':False})
    assert host1.name == "host1"
    assert host1.vars

# Generated at 2022-06-20 15:11:57.852336
# Unit test for method serialize of class Host
def test_Host_serialize():
    h = Host(name="host1")
    assert h.serialize() == dict(name=h.name, vars=h.vars.copy(), address=h.address, uuid=h._uuid, groups=[], implicit=h.implicit)


# Generated at 2022-06-20 15:12:09.311749
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    host = Host()

# Generated at 2022-06-20 15:12:14.321054
# Unit test for constructor of class Host
def test_Host():
    hosts = [
        Host('localhost'),
        Host('localhost', 22),
        Host('localhost', '22'),
    ]
    assert hosts[0].vars == {}
    assert hosts[0].name == 'localhost'
    assert hosts[1].vars == {'ansible_port': 22}
    assert hosts[1].name == 'localhost'
    assert hosts[2].vars == {'ansible_port': 22}
    assert hosts[2].name == 'localhost'

# Generated at 2022-06-20 15:12:23.342291
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    h = Host("myhostname")
    h.add_group(Group("all"))
    h.add_group(Group("group1"))
    h.add_group(Group("group2"))
    h.add_group(Group("group3"))
    h.add_group(Group("group4"))
    assert h.get_magic_vars() == {
        'group_names': ['group1', 'group2', 'group3', 'group4'],
        'inventory_hostname': 'myhostname',
        'inventory_hostname_short': 'myhostname'
    }, "Host with groups get_magic_vars() failed"

# Generated at 2022-06-20 15:12:26.460018
# Unit test for method get_name of class Host
def test_Host_get_name():
    h = Host('test')
    assert h.get_name() == 'test'
    assert h.name == 'test'

# Generated at 2022-06-20 15:12:41.365889
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    """Test the function Host.populate_ancestors()"""

    from ansible.inventory.group import Group

    # Initialize inventory objects
    group_a = Group('a')
    group_b = Group('b')
    group_c = Group('c')
    group_b.add_child_group(group_c)
    group_a.add_child_group(group_b)
    host_a = Host('a')

    # Add group_b to host_a, only group_b is in host_a.groups
    host_a.add_group(group_b)
    assert( len(host_a.groups) == 1 )
    assert( host_a.groups[0].name == 'b' )

    # Update host_a.groups recursively
    host_a.populate_ancestors

# Generated at 2022-06-20 15:12:50.530773
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():

    # Create a test host, add a test group to it and verify that it was added
    test_host = Host()
    test_group = Group()
    test_host.add_group(test_group)
    assert test_host in test_group.get_hosts(), "Unit test: Host.populate_ancestors() failed"

    # Test that the host's group is added to its ancestors
    test_host.populate_ancestors()
    assert test_group in test_host.groups, "Unit test: Host.populate_ancestors() failed"

    # Test that if the same group is added again, it is not added again
    test_host.populate_ancestors()
    assert len(test_host.groups) == 1, "Unit test: Host.populate_ancestors() failed"


# Generated at 2022-06-20 15:12:54.389888
# Unit test for method __repr__ of class Host
def test_Host___repr__():
    test_name = 'test-host'
    test_host = Host(test_name)
    assert test_host.__repr__() == test_host.__str__() == test_name


# Generated at 2022-06-20 15:13:00.744810
# Unit test for method serialize of class Host
def test_Host_serialize():
    host = Host("localhost")
    hd = host.serialize()
    assert hd['name'] == "localhost"
    assert hd['address'] == "localhost"
    assert hd['uuid'] != ''
    assert hd['vars'] == {}
    assert hd['groups'] == []
    assert hd['implicit'] == False


# Generated at 2022-06-20 15:13:08.079843
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    host = Host()
    host.name = "test.example.com"
    magic_vars = host.get_magic_vars()
    assert(magic_vars['inventory_hostname'] == "test.example.com")
    assert(magic_vars['inventory_hostname_short'] == "test")
    assert(magic_vars['group_names'] == [])
    host.groups.append(Group("group1"))
    host.groups.append(Group("group2"))
    magic_vars = host.get_magic_vars()
    assert(magic_vars['group_names'] == ['group1', 'group2'])

# Generated at 2022-06-20 15:13:19.925022
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    default_host = Host()
    host_1 = Host(gen_uuid=False, name='host_1')
    host_2 = Host(gen_uuid=False, name='host_2')

    # 1. Returns true when Host objects have same uuid

    # 1.1 Arrange
    host_2.vars = dict(uuid=host_1.get_vars().get('uuid'))

    # 1.2 Act
    reslut = host_1.__eq__(host_2)

    # 1.3 Assert
    assert reslut

    # 1.4 Cleanup (not actually needed)


    # 2. Returns false when Host objects have different uuids

    # 2.1 Arrange

    # 2.2 Act

# Generated at 2022-06-20 15:13:22.846283
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host = Host(name='localhost')
    host.set_variable('foo', {'bar': 'baz'})
    if host.vars == {'foo': {'bar': 'baz'}}:
        return True
    else:
        return False

# Generated at 2022-06-20 15:13:26.053952
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    assert Host('test1') == Host('test1')
    assert Host('test2') != Host('test1')
    assert Host('test1') != 'test1'


# Generated at 2022-06-20 15:13:34.550068
# Unit test for method __getstate__ of class Host
def test_Host___getstate__():
    import ast
    import json
    import yaml
    import collections
    import os
    import ansible.inventory.host
    import ansible.inventory.group
    hs = []
    gs = []
    hs.append(ansible.inventory.host.Host('localhost'))
    hs.append(ansible.inventory.host.Host('localhost', 83))
    hs.append(ansible.inventory.host.Host('localhost', 84, True))
    hs[2].set_variable('ansible_port', 85)
    gs.append(ansible.inventory.group.Group('all'))
    gs.append(ansible.inventory.group.Group('localhost'))
    for h in hs:
        for g in gs:
            h.add_group(g)
    hs_expected

# Generated at 2022-06-20 15:13:41.269906
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    host1 = Host("host1")
    host2 = Host("host2")
    host1.set_variable("a",1)
    host1.set_variable("b",2)
    host2.set_variable("a",1)
    host2.set_variable("b",2)
    print("host1 hash = ",host1.__hash__())
    print("host2 hash = ",host2.__hash__())
    print("host1 == host2 : ", host1.__eq__(host2))
    group1 = Group("group1")
    group1.add_host(host1)
    group1.add_host(host2)
    print("group1.hosts: ", group1.get_hosts())


if __name__ == "__main__":
    test_Host___hash__()

# Generated at 2022-06-20 15:13:48.663031
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    h = Host(name='server01')
    assert(hash(h) == hash('server01'))


# Generated at 2022-06-20 15:13:58.208727
# Unit test for method add_group of class Host
def test_Host_add_group():

    g1 = Group(name='group1')
    g2 = Group(name='group2')
    g3 = Group(name='group3')
    g4 = Group(name='group4')
    g5 = Group(name='group5')
    g6 = Group(name='group6')
    g7 = Group(name='group7')
    g8 = Group(name='group8')
    g9 = Group(name='group9')
    g10 = Group(name='group10')

    # Parentage of all the groups
    # g1 -> g2 -> g3
    # g4 -> g5 -> g6
    # g7 -> g8 -> g9
    # g10

    g2.add_parent(g1)
    g3.add_parent(g2)

# Generated at 2022-06-20 15:14:10.027271
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    # host
    host = Host('xxx')

    # groups
    group_all = Group('all')
    group_alice = Group('alice')
    group_alice.add_parent(group_all)
    group_bob = Group('bob')
    group_bob.add_parent(group_all)
    group_charlie = Group('charlie')
    group_charlie.add_parent(group_all)
    group_alice_bob = Group('alice_bob')
    group_alice_bob.add_parent(group_all)
    group_charlie_alice_bob = Group('charlie_alice_bob')
    group_charlie_alice_bob.add_parent(group_all)

    # add groups to

# Generated at 2022-06-20 15:14:14.129840
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    gr = Group()
    gr.name = 'test'
    gr1 = Group()
    gr1.name = 'new'
    gr.add_group(gr1)
    hst = Host('hostname')
    hst.add_group(gr)
    result = hst.get_groups()
    assert len(result) == 2
    assert result[0].name == 'test'
    assert result[1].name == 'new'

# Generated at 2022-06-20 15:14:16.878258
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    '''ensure that inventory hostname and hostname_short are known to host'''

    h = Host('127.0.0.1')
    assert h.name == '127.0.0.1'
    assert h.get_vars()['inventory_hostname'] == '127.0.0.1'
    assert h.get_vars()['inventory_hostname_short'] == '127.0.0.1'


# Generated at 2022-06-20 15:14:21.878471
# Unit test for method remove_group of class Host
def test_Host_remove_group():

    # Create a dummy group
    group = Group()
    group.name = 'foo'
    group._uuid = get_unique_id()

    # Create a dummy host
    host = Host()
    host.name = 'localhost'
    host.gen_uuid = True
    host.add_group(group)

    # Assert that group was added
    assert(group in host.groups)

    # Remove the group
    host.remove_group(group)

    # Assert that group was removed
    assert(group not in host.groups)

# Generated at 2022-06-20 15:14:25.206519
# Unit test for method __str__ of class Host
def test_Host___str__():
    in_ = Host('localhost')
    want = 'localhost'
    got = str(in_)
    assert got == want


# Generated at 2022-06-20 15:14:25.733697
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    pass

# Generated at 2022-06-20 15:14:28.627929
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    # Create a host for testing
    test_name = "Test_Host"
    test_host = Host(name=test_name)
    # Hash should be equal to hash of the host's name
    assert hash(test_host) == hash(test_name)



# Generated at 2022-06-20 15:14:38.716711
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    # Create a host and a group
    h = Host('TEST_HOST')
    g = Group('TEST_GROUP')

    # Add the group to the host
    h.add_group(g)

    # Add the group to the host
    assert g in h.get_groups()

    # Remove the group from the host
    h.remove_group(g)

    # Make sure that the group was removed
    assert g not in h.get_groups()

# Generated at 2022-06-20 15:14:53.452023
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    class GroupMock(Group):
        def get_ancestors(self):
            return self.ancestors
        def __init__(self, name, ancestors):
            super(GroupMock, self).__init__(name)
            self.ancestors = ancestors

    # prepare groups
    groupA = GroupMock('A', [])
    groupB = GroupMock('B', [groupA])
    groupC = GroupMock('C', [groupA])

    groupD = GroupMock('D', [groupB, groupC])
    groupE = GroupMock('E', [groupD])

    # prepare host
    host = Host('TestHost')
    host.groups = [groupE, groupC, groupB]

    host.remove_group(groupC)
    assert len(host.groups) == 1


# Generated at 2022-06-20 15:15:00.766298
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    h1 = Host(name='host1')
    h2 = Host(name='host2.test')

    assert h1.get_magic_vars() == {
            'inventory_hostname': 'host1',
            'inventory_hostname_short': 'host1',
            'group_names': []
            }
    assert h2.get_magic_vars() == {
            'inventory_hostname': 'host2.test',
            'inventory_hostname_short': 'host2',
            'group_names': []
            }

# Generated at 2022-06-20 15:15:02.476948
# Unit test for method __repr__ of class Host
def test_Host___repr__():
    host = Host("test-host")
    repr = host.__repr__()
    assert repr == "test-host"

# Generated at 2022-06-20 15:15:05.148591
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    # Test case #1
    h1 = Host("localhost")
    h2 = Host("127.0.0.1")
    assert h1.__ne__(h2)

    # Test case #2
    h1 = Host("localhost")
    h2 = Host("127.0.0.1")
    assert not h1.__ne__(h1)



# Generated at 2022-06-20 15:15:11.000032
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    h = Host('host')
    h.set_variable('var_1', 'value_1')
    h.set_variable('var_2', {'subvar_2_1': 'subvalue_2_1'})
    h.set_variable('var_2', {'subvar_2_2': 'subvalue_2_2'})

    vars = h.get_vars()

    assert isinstance(vars, dict)
    assert 'var_1' in vars
    assert vars['var_1'] == 'value_1'
    assert 'subvar_2_1' in vars['var_2']
    assert vars['var_2']['subvar_2_1'] == 'subvalue_2_1'

# Generated at 2022-06-20 15:15:15.238738
# Unit test for constructor of class Host
def test_Host():
    test_host = Host(name='localhost', port='22')
    assert test_host.get_name() == 'localhost'
    assert test_host.address == 'localhost'
    assert test_host.vars['ansible_port'] == 22
    assert type(test_host._uuid) == str

# Generated at 2022-06-20 15:15:21.453554
# Unit test for constructor of class Host
def test_Host():
    host = Host('test')
    assert host.get_name() == 'test'
    host = Host(name='test')
    assert host.get_name() == 'test'
    host = Host(name='test', port=22)
    assert host.get_name() == 'test'
    

# Generated at 2022-06-20 15:15:30.274607
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host = Host(name='test', port=222)

    # Dictionnary as value (exemple given in the documentation)
    host.set_variable('ansible_ssh_host', 'test')
    host.set_variable('ansible_ssh_host', {'alias1': 'test', 'alias2': 'test'})
    assert host.vars['ansible_ssh_host'] == {'alias1': 'test', 'alias2': 'test'}

    # Non-dictionnary as value
    host.set_variable('ansible_ssh_host', 'test2')
    assert host.vars['ansible_ssh_host'] == 'test2'

    # Dictionnary as value, where the dictionnary and the value are in the same key

# Generated at 2022-06-20 15:15:36.972819
# Unit test for method add_group of class Host
def test_Host_add_group():
    h = Host('localhost')
    g1 = Group('g1')
    g1_1 = Group('g1_1')
    g1_1.add_child_group(g1)
    g1_2 = Group('g1_2')
    g1.add_child_group(g1_1)
    g1.add_child_group(g1_2)
    h.add_group(g1)
    h.populate_ancestors()
    assert(h.groups == [g1, g1_1, g1_2])

# Generated at 2022-06-20 15:15:43.995508
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    """
    Host.get_groups() returns a list of all groups which a host is a member of
    """

    h = Host(name="h1")
    g1 = Group(name="g1", vars=dict())
    g2 = Group(name="g2", vars=dict())

    # Add groups to a host
    h.add_group(g1)
    h.add_group(g2)

    assert h.get_groups() == [g1, g2]


# Generated at 2022-06-20 15:16:04.690203
# Unit test for constructor of class Host
def test_Host():
    # create host
    h = Host('127.0.0.1')
    assert h.name == '127.0.0.1'
    assert h.address == '127.0.0.1'
    assert h.port == None
    assert isinstance(h.vars, dict)
    assert isinstance(h.groups, list)
    assert isinstance(h._uuid, str)

    # test variables
    h.set_variable('foo', 'bar')
    assert h.get_vars()['foo'] == 'bar'

    # test groups
    g1 = Group('g1')
    g2 = Group('g2')
    h.add_group(g1)
    assert h.groups == [g1]
    h.add_group(g2)

# Generated at 2022-06-20 15:16:14.171988
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host = Host('localhost')
    host.set_variable('a_boolean', True)
    assert host.get_vars() == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost',
                               'group_names': [], 'a_boolean': True}
    host.set_variable('a_boolean', False)
    assert host.get_vars() == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost',
                               'group_names': [], 'a_boolean': False}

# Generated at 2022-06-20 15:16:24.998618
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    h = Host()
    h.deserialize({
        'name'    : 'test_host',
        'vars'    : { 'a': '1', 'b': '2' },
        'groups'  : [
            {
                'name'    : 'test_group',
                'vars'    : { 'c': '3', 'd': '4' },
                'parents' : [
                    {
                        'name'    : 'test_parent',
                        'vars'    : { 'e': '5', 'f': '6' }
                    }
                ]
            },
            {
                'name'    : 'test_parent2',
                'vars'    : { 'g': '7', 'h': '8' }
            }
        ]
    })


# Generated at 2022-06-20 15:16:28.936289
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    host = Host('my-host')
    magic_vars = {'inventory_hostname': 'my-host',
                  'inventory_hostname_short': 'my-host'.split('.')[0],
                  'group_names': []}
    assert magic_vars == host.get_magic_vars()

# Generated at 2022-06-20 15:16:38.061045
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    from ansible.inventory.group import Group
    from ansible.module_utils.common._collections_compat import MutableMapping
    myGroup = Group("testGroup")
    host = Host("localhost")
    host.add_group(myGroup)
    myList = host.get_groups()

    assert(myList[0] == myGroup)
    assert(isinstance(myList[0].vars, MutableMapping))
    assert(isinstance(myList[0].children, MutableMapping))
    assert(isinstance(myList[0].parents, MutableMapping))


# Generated at 2022-06-20 15:16:39.689763
# Unit test for method __repr__ of class Host
def test_Host___repr__():
    host = Host(name="host1")
    assert host.__repr__() == "host1"


# Generated at 2022-06-20 15:16:43.045712
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    h = Host('test.example.com')
    assert(h.get_magic_vars()['inventory_hostname'] == 'test.example.com')
    assert(h.get_magic_vars()['inventory_hostname_short'] == 'test')

# Generated at 2022-06-20 15:16:45.221988
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host = Host(name='test')
    host.set_variable('test', {'a':'b'})
    assert host.vars['test']['a'] == 'b'

# Generated at 2022-06-20 15:16:54.732965
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    ''' Test Host.get_groups'''
    # initialize the host 
    host = Host()

    # test normal case
    group1 = Host('group1')
    group2 = Host('group2')
    group3 = Host('group3')
    host.groups = [group1, group2]
    assert host.get_groups() == [group1, group2]

    # test empty group list
    host.groups = []
    assert host.get_groups() == []

    # test group list is None
    host.groups = None
    assert host.get_groups() == None


# Generated at 2022-06-20 15:17:04.449600
# Unit test for method add_group of class Host
def test_Host_add_group():
    from ansible.inventory.group import Group
    from ansible.inventory.included_file import IncludedFile

    host2 = Host("host2", gen_uuid=False)
    g1 = Group("g1", gen_uuid=False)
    g2 = Group("g2", gen_uuid=False)
    g3 = Group("g3", gen_uuid=False)
    g1.add_child_group(g2)
    g2.add_child_group(g3)

    host2.add_group(g3)
    assert host2.get_groups() == [g3]

    host2.add_group(g2)
    assert host2.get_groups() == [g3, g2]

    host2.add_group(g1)
    assert host2.get_groups

# Generated at 2022-06-20 15:17:23.835389
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    group1 = Group(name='group1')
    group2 = Group(name='group2')
    group21 = Group(name='group2.1', parents=[group2])
    group22 = Group(name='group2.2', parents=[group2])
    group31 = Group(name='group3.1', parents=[group21, group22])
    host = Host('testhost')
    host.add_group(group1)
    host.add_group(group31)
    groups = [group1, group21, group22, group31]
    assert host.groups == groups
    assert host.remove_group(group2)
    assert host.groups == [group1, group31]

    assert host.add_group(group31) == False
    assert host.groups == [group1, group31]
    assert host.remove

# Generated at 2022-06-20 15:17:24.951346
# Unit test for method serialize of class Host
def test_Host_serialize():
    assert(isinstance(Host().serialize(), dict))

# Generated at 2022-06-20 15:17:35.560379
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    """ Host init
    """

    host1 = Host('test1')
    host1.set_variable('testVar','testValue')
    host2 = Host('test2')
    assert host1.__ne__(host2)
    
    host2.set_variable('testVar','testValue')
    assert host1.__ne__(host2)
    
    host1.set_variable('testVar','testValue1')
    assert host1.__ne__(host2)
    
    
    class Test(Host):
        def __init__(self,name=None):
            Host.__init__(self,name)
    
    test1 = Test('test')
    test2 = Test('test')
    assert test1.__ne__(test2)
