

# Generated at 2022-06-20 15:07:42.368526
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    h1 = Host(name="hostname")
    h2 = Host(name="hostname")
    h3 = Host(name="hostname")

    assert(h1 != h2)
    assert(h1 != h3)
    assert(h2 != h3)
    assert(h2 != None)


# Generated at 2022-06-20 15:07:52.046865
# Unit test for method add_group of class Host
def test_Host_add_group():
    '''
    Ansible inventory groups are implemented as a directed acyclic graph. This
    unit test verifies that the add_group method properly adds a new group as a
    descendant of the host's current set of groups (the DAG structure).

    This test is intended to catch any regressions that might be introduced if
    the algorithm for adding groups is changed.
    '''

    # Hosts are supposed to be instantiated with a UUID, but in this unit test
    # we don't want to use a UUID to guarantee consistent behavior during
    # testing.
    h = Host(gen_uuid=False)
    h.name = 'localhost'

    # h starts with no groups
    assert len(h.groups) == 0

    # Start with one group to add ancestors to
    g1 = Group('g1')
    h.add_group

# Generated at 2022-06-20 15:07:54.393660
# Unit test for constructor of class Host
def test_Host():
    """
    Unit test for Host
    """
    host = Host("test-host-1")
    assert host.get_name() == "test-host-1"

# Generated at 2022-06-20 15:08:05.101441
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host = Host()

    # Test replacing a MutableMapping with a non-Mapping value
    host.set_variable('foo', {})
    host.set_variable('foo', 'bar')
    assert host.vars['foo'] == 'bar'

    # Test replacing a MutableMapping with a Mapping value
    host.set_variable('foo', {})
    host.set_variable('foo', {'bar': 'baz'})
    assert host.vars['foo'] == {'bar': 'baz'}

    # Test merging a MutableMapping and a Mapping value
    host.set_variable('ansible_ssh_host', 'foo')
    host.set_variable('ansible_ssh_host', {'baz': 'quux'})

# Generated at 2022-06-20 15:08:12.280938
# Unit test for method __setstate__ of class Host
def test_Host___setstate__():

    h1 = Host('localhost')
    h2 = Host()

    with pytest.raises(AttributeError):
        h1.__getstate__()

    with pytest.raises(AttributeError):
        h2.__setstate__(h1.__dict__)

    h2.__setstate__(h1.__dict__)
    assert h2.__dict__['_uuid'] == h1.__dict__['_uuid']

# Generated at 2022-06-20 15:08:14.212415
# Unit test for method __repr__ of class Host
def test_Host___repr__():
    HOST = Host()
    result = repr(HOST)
    assert result == ''


# Generated at 2022-06-20 15:08:25.760501
# Unit test for method populate_ancestors of class Host

# Generated at 2022-06-20 15:08:38.305521
# Unit test for method serialize of class Host
def test_Host_serialize():
    g1 = Group('g1')
    g2 = Group('g2')
    g3 = Group('g3')
    g3.add_child_group(g1)
    g3.add_child_group(g2)

    h1 = Host('h1')
    h1.add_group(g1)
    h1.add_group(g2)
    h1.add_group(g3)
    h1.set_variable('ansible_port', 22)

    serialized = h1.serialize()


# Generated at 2022-06-20 15:08:49.107951
# Unit test for method __eq__ of class Host
def test_Host___eq__():

    # Test if two hosts with same name are equal
    host1 = Host(name = 'test_name1', gen_uuid=False)
    host2 = Host(name = 'test_name1', gen_uuid=False)
    assert host1 == host2

    # Test if two hosts with different name are not equal
    host3 = Host(name = 'test_name2', gen_uuid=False)
    assert host1 != host3

    # Test if a host and a string with that host's name are not equal
    assert host1 != 'test_name1'

    # Test if a host and None are not equal
    assert host1 is not None


# Generated at 2022-06-20 15:09:01.384837
# Unit test for method __getstate__ of class Host
def test_Host___getstate__():
    # Test with empty object
    h = Host()
    assert h.serialize() == {
        'name': None,
        'vars': {},
        'address': None,
        'uuid': None,
        'groups': [],
        'implicit': False,
    }

    # Test with basic data
    h = Host(name='foo.example.org', port=2222)
    assert h.serialize() == {
        'name': 'foo.example.org',
        'vars': {'ansible_port': 2222},
        'address': 'foo.example.org',
        'uuid': h._uuid,
        'groups': [],
        'implicit': False,
    }

    # Test with groups
    h = Host(name='foo.example.org', port=22)

# Generated at 2022-06-20 15:09:15.059442
# Unit test for method get_vars of class Host
def test_Host_get_vars():

    host = Host(name='spam.egg')

    # host's vars should always be a dict
    assert(isinstance(host.vars, dict) == True)

    # method get_vars should always return a dict
    assert(isinstance(host.get_vars(), dict) == True)

    # test if expected magic variables are present
    assert('inventory_hostname' in host.get_vars())
    assert('inventory_hostname_short' in host.get_vars())
    assert('group_names' in host.get_vars())

# Generated at 2022-06-20 15:09:17.915812
# Unit test for method __repr__ of class Host
def test_Host___repr__():
    host_o = Host()
    host_o.name = 'localhost'
    assert repr(host_o) == 'localhost'

# Generated at 2022-06-20 15:09:20.510275
# Unit test for method get_name of class Host
def test_Host_get_name():
    # TEST
    host = Host('testname')
    name = host.get_name()
    # VERIFY
    assert name == 'testname'


# Generated at 2022-06-20 15:09:23.500799
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    pass


# Generated at 2022-06-20 15:09:25.719743
# Unit test for method get_name of class Host
def test_Host_get_name():
    h = Host('foo.example.com')
    assert h.get_name() == 'foo.example.com'


# Generated at 2022-06-20 15:09:37.183149
# Unit test for method serialize of class Host
def test_Host_serialize():
    def test_serialize_and_deserialize(host):
        host.deserialize(host.serialize())
        return host

    def test_serialize_and_deserialize_many(hosts):
        hosts_serialized = []
        for host in hosts:
            hosts_serialized.append(host.serialize())

        hosts_deserialized = []
        for host_serialized in hosts_serialized:
            host = Host()
            host.deserialize(host_serialized)
            hosts_deserialized.append(host)

        return hosts_deserialized

    assert Host('localhost').groups == []
    assert test_serialize_and_deserialize(Host('localhost')).groups == []

    assert Host('localhost', gen_uuid=False)._uuid is None
    assert test_serialize

# Generated at 2022-06-20 15:09:40.039945
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    # More than one attribute with the same name
    h = Host("test")
    h2 = Host("test2")

    assert h != h2

# Generated at 2022-06-20 15:09:46.351691
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    host = Host("test_host", None, False)
    assert(host == host)

    host_equal = Host("test_host", None, False)
    host_equal.deserialize(host.serialize())
    assert(host == host_equal)

    host_not_equal = Host("test_host_2", None, False)
    host_not_equal.deserialize(host.serialize())
    assert(host != host_not_equal)

# Generated at 2022-06-20 15:09:51.453674
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    h = Host(name='localhost')
    h._uuid = 'dummy_uuid'
    assert h.__hash__() == hash('localhost'), 'Host.__hash__() does not return the correct value.'

# Generated at 2022-06-20 15:10:01.866099
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():

    a = Group('a')
    b = Group('b')
    c = Group('c')

    h1 = Host('host1')
    h2 = Host('host2')

    h1.add_group(a)
    h1.add_group(b)

    h2.add_group(a)
    h2.add_group(c)

    h1.populate_ancestors()

    assert h1.groups[0].name == 'a'
    assert h1.groups[1].name == 'b'
    assert h1.groups[2].name == 'all'

    assert h2.groups[0].name == 'a'
    assert h2.groups[1].name == 'c'
    assert h2.groups[2].name == 'all'

# Generated at 2022-06-20 15:10:12.128786
# Unit test for method add_group of class Host
def test_Host_add_group():
    gr1 = Group('gr1')
    gr2 = Group('gr2')
    gr3 = Group('gr3')
    gr4 = Group('gr4')
    gr2.add_child_group(gr4)
    gr1.add_child_group(gr2)
    gr1.add_child_group(gr3)

    h = Host('h1')
    h.add_group(gr3)
    # h.add_group(gr2)
    assert gr3 in h.get_groups()
    assert not gr2 in h.get_groups()
    assert not gr1 in h.get_groups()

# Generated at 2022-06-20 15:10:21.935421
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    h = Host(gen_uuid=False)
    h.deserialize(dict(
        name='test.example.com',
        vars={'test1': 'test2', 'test3': {'subtest1': 'subtest2'}},
        address='test.example.com',
        uuid=get_unique_id(),
        implicit=False,
        groups=[]
    ))
    assert h.name == 'test.example.com'
    assert h.vars == {'test1': 'test2', 'test3': {'subtest1': 'subtest2'}}
    assert h.address == 'test.example.com'
    assert h._uuid
    assert h.implicit == False
    assert h.groups == []


# Generated at 2022-06-20 15:10:27.215748
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    f = Host('foo', port=22)
    g = Host('foo', port=23)
    g2 = Host('foo', port=23)
    assert f != g and g == g2
    assert hash(f) == hash(g)


# Generated at 2022-06-20 15:10:30.728031
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    host1 = Host(name='host1')
    host2 = Host(name='host2')
    assert host1.__ne__(host2)


# Generated at 2022-06-20 15:10:38.940149
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    # Test case input: group with implicit group 'all'
    group = Group('test')
    group.add_host(Host('test-host'))
    group.add_host(Host('test-host2'))

    # Check with non-empty list of additions
    test_host = Host('test-host')
    # add implicit group 'all'
    test_host.groups.append(Group('all'))
    additions = [group]
    test_host.populate_ancestors(additions=additions)
    assert test_host.vars == {'inventory_hostname': 'test-host',
                            'group_names': ['test']}

    # Check with empty list of additions: group 'test' is not present
    test_host = Host('test-host')
    # add implicit group 'all'
   

# Generated at 2022-06-20 15:10:42.628726
# Unit test for constructor of class Host
def test_Host():
    host = Host(name='test_Host')
    assert host.name == 'test_Host'


# Generated at 2022-06-20 15:10:52.477676
# Unit test for method __getstate__ of class Host
def test_Host___getstate__():
    # Set up test environment
    h = Host(name = 'localhost')
    h.vars = {'key1': 'val1', 'key2': 'val2'}
    g1 = Group()
    g1.vars = {'key1': 'val1', 'key2': 'val2'}
    g2 = Group()
    g2.vars = {'key3': 'val3', 'key4': 'val4'}
    h.groups.append(g1)
    h.groups.append(g2)

# Generated at 2022-06-20 15:11:02.540309
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    h1 = Host('localhost')
    h2 = Host('localhost')
    assert h1 != h2, \
        "Hosts with identical hostnames are not equal"
    assert h1.__ne__(h2), \
        "Hosts with identical hostnames are not equal"
    h2 = Host('otherhost')
    assert h1 != h2, \
        "Hosts with different hostnames are not equal"
    assert h1.__ne__(h2), \
        "Hosts with different hostnames are not equal"
    h2 = 42
    assert h1 != h2, \
        "Hosts and 42 are not equal"


# Generated at 2022-06-20 15:11:12.665445
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    host = Host('hostname')
    group1 = Group('group1')
    group2 = Group('group2')
    group1.add_child_group(group2)
    host.groups = [group2]

    magic_vars = host.get_magic_vars()
    assert len(magic_vars) == 2
    assert magic_vars['inventory_hostname'] == 'hostname'
    assert magic_vars['inventory_hostname_short'] == 'hostname'
    assert magic_vars['group_names'] == ['group1', 'group2']
    return 0

# Generated at 2022-06-20 15:11:25.537441
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    g1 = Group(name='g1')
    g2 = Group(name='g2')
    g21 = Group(name='g2.1')
    g22 = Group(name='g2.2')

    h = Host(name='h')

    g1.add_child_group(g2)
    g2.add_child_group(g21)
    g2.add_child_group(g22)

    h.add_group(g1)
    h.add_group(g21)

    # h has only g1 and g21, but it should have g2 as well
    assert g2 in h.groups
    assert g21 in h.groups
    assert g22 not in h.groups

# Generated at 2022-06-20 15:11:44.318553
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    # create groups
    group_all = Group('all')
    group_test = Group('test')
    group_test.add_child_group(group_all)
    group_test2 = Group('test2')
    group_test2.add_child_group(group_all)
    group_test3 = Group('test3')
    group_test3.add_child_group(group_test)

    # create Host with group test
    host = Host('host.example.com')
    host.add_group(group_test3)

    # test remove_group
    assert(host.remove_group(group_test3))
    assert(not host.remove_group(group_test3))
    assert(host.remove_group(group_all))
    assert(not host.remove_group(group_all))


# Generated at 2022-06-20 15:11:48.482287
# Unit test for method __repr__ of class Host
def test_Host___repr__():

    # Create a new Host object
    myHost = Host(name='localhost')

    # Check that the repr method returns a string containing the object type and its name
    assert repr(myHost) == '<ansible.inventory.host.Host object at 0x7f80db25cf10> [localhost]'



# Generated at 2022-06-20 15:11:53.142737
# Unit test for method get_groups of class Host
def test_Host_get_groups():

    h = Host('localhost')
    h.add_group(Group('group1'))
    h.add_group(Group('group2'))
    h.add_group(Group('group3'))

    assert (h.get_groups() == [Group('group1'), Group('group2'), Group('group3')])

# Generated at 2022-06-20 15:11:59.499003
# Unit test for method __repr__ of class Host
def test_Host___repr__():

    host = Host("localhost")
    assert host.__repr__() == "localhost"

    host = Host("10.0.0.1")
    assert host.__repr__() == "10.0.0.1"

    host = Host("www.example.com")
    assert host.__repr__() == "www.example.com"


# Generated at 2022-06-20 15:12:02.311435
# Unit test for method serialize of class Host
def test_Host_serialize():
    ''' host.serialize()

    This method returns a datastructure representing this host that is serializable
    '''
    pass


# Generated at 2022-06-20 15:12:04.574949
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    h = Host('test_host')
    assert isinstance(h.__hash__(), int), "__hash__() should return an integer"


# Generated at 2022-06-20 15:12:13.933303
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():

    # Create Groups
    g1 = Group('g1_group')
    g2 = Group('g2_group')
    g3 = Group('g3_group')
    g4 = Group('g4_group')
    g5 = Group('g5_group')
    g6 = Group('g6_group')

    # Create nested group structure
    g2.add_child_group(g3)
    g2.add_child_group(g4)
    g4.add_child_group(g5)
    g5.add_child_group(g6)

    # Create host
    h1 = Host('h1_host')
    h2 = Host('h2_host')

    # Test for addition of groups to the host
    h1.populate_ancestors()

# Generated at 2022-06-20 15:12:24.396469
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    parent = Group("parent")
    child = Group("child")
    child.add_parent(parent)

    host = Host("Test")
    host.populate_ancestors(additions=[child])
    assert set(host.get_groups()) == set([child, parent])

    new_child = Group("new_child")
    new_child.add_parent(parent)

    host.populate_ancestors(additions=[new_child])
    assert set(host.get_groups()) == set([child, parent, new_child])

    new_parent = Group("new_parent")
    new_parent.add_child(new_child)

    host.populate_ancestors(additions=[new_child])

# Generated at 2022-06-20 15:12:36.605906
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    h1_data = {
        'name': 'localhost',
        'address': '127.0.0.1',
        'groups': [
            {
                'name': 'local',
                'hosts': [],
                'vars': {},
                'children': [],
                'parents': []
            }
        ],
        'vars': {},
        'uuid': 'a',
    }


# Generated at 2022-06-20 15:12:41.578964
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    h1 = Host('host1')
    h1.set_variable('var1', 'value1')
    h1.add_group(Group('group1'))

    h2 = Host('host1')
    h2.set_variable('var1', 'value1')
    h2.add_group(Group('group1'))

    assert h1 == h2


# Generated at 2022-06-20 15:12:50.899250
# Unit test for method get_name of class Host
def test_Host_get_name():
    h = Host(name="localhost", port=22)
    assert h.get_name() == "localhost"



# Generated at 2022-06-20 15:12:55.276852
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    '''Host: check if two equal hosts are equal'''
    one = Host(name="127.0.0.1")
    two = Host(name="127.0.0.1")
    assert one == two


# Generated at 2022-06-20 15:12:57.739486
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    h = Host(name='test')
    h2 = Host(name='test')
    assert hash(h) == hash(h2)

# Generated at 2022-06-20 15:13:04.099461
# Unit test for constructor of class Host
def test_Host():
    h = Host('hostname')
    assert h.name == 'hostname'
    assert h.address == 'hostname'
    assert not h.vars
    assert h.groups == []
    assert h.get_vars() == {'inventory_hostname': 'hostname', 'inventory_hostname_short': 'hostname', 'group_names': []}

# Generated at 2022-06-20 15:13:07.921819
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    host = Host(name='tester', port=1234)
    data = host.serialize()
    host.deserialize(data)

    assert data['name'] == 'tester'
    assert data['vars'] == dict(ansible_port=1234)

# Generated at 2022-06-20 15:13:19.813971
# Unit test for method __setstate__ of class Host
def test_Host___setstate__():
    h = Host(gen_uuid=False)
    expected_vars = {"foo": "bar"}
    expected_address = "foobar"
    expected_uuid = "bazuuid"
    expected_implicit = True
    data = {
        'name': 'foobar',
        'vars': expected_vars,
        'address': expected_address,
        'uuid': expected_uuid,
        'groups': [],
        'implicit': expected_implicit,
    }
    h.deserialize(data)
    assert h.name == data['name']
    assert h.vars == expected_vars
    assert h.address == expected_address
    assert h._uuid == expected_uuid
    assert h.implicit is expected_implicit
    assert h.groups == []

# Generated at 2022-06-20 15:13:26.474280
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    h1 = Host('server1.example.com')
    h2 = Host('server1.example.com')
    h3 = Host('server2.example.com')

    assert hash(h1) == hash(h2)
    assert hash(h1) != hash(h3)

# Generated at 2022-06-20 15:13:28.916836
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    inventory = '''
        [local]
        localhost

        [local:children]
        all
    '''

    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(inventory)
    all_group = inventory.get_group('all')
    local_host = inventory.get_host('localhost')

    # group all is a child of group local
    assert all_group in local_host.get_groups()


# Generated at 2022-06-20 15:13:30.879107
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    host1 = Host('test_Host___eq__')
    host2 = Host('test_Host___eq__')

    assert host1 == host2


# Generated at 2022-06-20 15:13:38.399774
# Unit test for method __getstate__ of class Host
def test_Host___getstate__():
    h = Host('toto')
    h.set_variable('ansible_ssh_port', 22)
    d = h.__getstate__()
    assert d == {
        'name': 'toto',
        'vars': {'ansible_ssh_port': 22},
        'address': 'toto',
        'uuid': None,
        'groups': list(),
        'implicit': False,
    }


# Generated at 2022-06-20 15:13:52.494445
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    host = Host("test")

    host.vars['test1'] = 'test1'
    assert host.get_vars()['test1'] == 'test1'
    assert host.get_vars()['inventory_hostname'] == 'test'

    host.set_variable('test2', {'a': {'b': 2}})
    assert host.get_vars()['test2']['a']['b'] == 2
    assert host.get_vars()['inventory_hostname'] == 'test'

    host.set_variable('test2', {'a': {'b': 3}})
    assert host.get_vars()['test2']['a']['b'] == 3
    assert host.get_vars()['inventory_hostname'] == 'test'

    host.set_

# Generated at 2022-06-20 15:13:57.385350
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    h = Host(name='testhost.example.com', gen_uuid=True)
    h2 = Host(name='testhost.example.com', gen_uuid=True)
    assert h == h2
    assert h == h
    h3 = Host(name='otherhost.example.com', gen_uuid=True)
    assert h != h3


# Generated at 2022-06-20 15:14:00.789203
# Unit test for method add_group of class Host
def test_Host_add_group():
    h = Host(name="test_host_1")
    h.add_group(Group(name="test_group_1"))
    pass


# Generated at 2022-06-20 15:14:05.482059
# Unit test for method __repr__ of class Host
def test_Host___repr__():
    _host = Host()

    # Test passing a valid host name
    _host.name = 'localhost'
    assert repr(_host) == _host.name

    # Test passing invalid host name
    _host.name = 'None'
    assert repr(_host) == _host.name

# Generated at 2022-06-20 15:14:07.985461
# Unit test for constructor of class Host
def test_Host():
    h = Host(name='test')
    assert h.name == 'test'

    h = Host(name='test', port='22')
    assert h.get_vars()['ansible_port'] == 22

# Generated at 2022-06-20 15:14:10.155228
# Unit test for method __repr__ of class Host
def test_Host___repr__():
    hostObj = Host.Host(name='test_host')
    assert repr(hostObj) == hostObj.get_name()



# Generated at 2022-06-20 15:14:14.621022
# Unit test for method add_group of class Host
def test_Host_add_group():
    ''' Unit test for method add_group of class Host '''
    group = Group()
    group.name = "group1"

    host = Host()
    host.name = "host1"

    host.add_group(group)
    assert host.groups[0] == group
    assert group.hosts[0] == host


# Generated at 2022-06-20 15:14:15.779189
# Unit test for method __str__ of class Host
def test_Host___str__():
    _ = Host('foo')
    __ = str(_)
    assert __ == 'foo'

# Generated at 2022-06-20 15:14:20.340703
# Unit test for method get_name of class Host
def test_Host_get_name():
    host = Host("localhost")
    assert host.get_name() == "localhost"


# Generated at 2022-06-20 15:14:22.174499
# Unit test for method __repr__ of class Host
def test_Host___repr__():
    host = Host("example.com")
    print("--- FINISHED __repr__ ---")
    return host.__repr__()


# Generated at 2022-06-20 15:14:47.783004
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    class fake_group:
        def __init__(self, name):
            self.name = name

    valid_host_name = 'test_host'
    valid_host_group_names = ['group1', 'group2']
    valid_host_group_names_all = valid_host_group_names + ['all']

    host_vars_without_magic_vars = ['nothing_from_inventory_hostname', 'nothing_from_group_names']

    # Initialize host
    host = Host(name=valid_host_name)
    # Add host to groups
    for group_name in valid_host_group_names_all:
        host.add_group(fake_group(name=group_name))

    # Define expected result

# Generated at 2022-06-20 15:14:51.776083
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    host = Host("test")
    group1 = Group("testgroup1")
    group2 = Group("testgroup2")
    group3 = Group("testgroup3")
    host.add_group(group1)
    host.add_group(group2)
    host.add_group(group3)

    assert host != "Host"
    assert host == Host("test")
    assert host == Host("test")
    assert host != Host("test2")

# Generated at 2022-06-20 15:15:01.861743
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    inputHost = Host(name="test", gen_uuid=False)
    inputHost.set_variable('test', [1,2])
    group1 = Group(name="group1", gen_uuid=False)
    group2 = Group(name="group2", gen_uuid=False)
    group1.add_child_group(group2)
    inputHost.add_group(group1)
    inputHost.add_group(group2)

    # Dump our host to json
    serialized = inputHost.serialize()

    # Create a new host from the json
    outputHost = Host(gen_uuid=False)
    outputHost.deserialize(serialized)


# Generated at 2022-06-20 15:15:06.143525
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    host = Host()
    assert isinstance(hash(host), int)



# Generated at 2022-06-20 15:15:08.939397
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    my_host = Host("myhost")
    assert hash(my_host) == hash("myhost")


# Generated at 2022-06-20 15:15:19.709198
# Unit test for method __setstate__ of class Host
def test_Host___setstate__():
    #test for if self.__dict__ doesn't have a key 'address'
    host = Host()
    host.deserialize({})
    assert host.address == ''

    #test for if self.__dict__ has a key 'address'
    host.deserialize({'address':'addresstest'})
    assert host.address == 'addresstest'

    #test for if self.__dict__ doesn't have a key 'vars'
    host.deserialize({})
    assert host.vars == {}

    #test for if self.__dict__ has a key 'vars'
    host.deserialize({'vars':{'vars':'varstest'}})
    assert host.vars == {u'vars': u'varstest'}

# Generated at 2022-06-20 15:15:27.019956
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    h1 = Host("192.168.2.2")
    h2 = Host("192.168.2.4")
    h3 = Host("192.168.2.2", gen_uuid=False)
    h4 = Host("192.168.2.2", gen_uuid=False)

    assert h1 == h1
    assert h3 == h3
    assert h1 != h2
    assert h3 != h4

# Generated at 2022-06-20 15:15:36.045115
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    g1 = Group(name='g1')
    g2 = Group(name='g2')
    g2.add_ancestor(g1)
    h1 = Host('foo')
    h2 = Host('bar')
    for g in [g1,g2]:
        h1.add_group(g)
    for g in [g2]:
        h2.add_group(g)

    h1.populate_ancestors()
    h2.populate_ancestors()

    assert len(h1.groups) == 2
    assert len(h2.groups) == 1

# Generated at 2022-06-20 15:15:38.250014
# Unit test for method get_name of class Host
def test_Host_get_name():
    # create a new Host object
    testObject = Host(name="testObject")

    # confirm the return value
    assert testObject.get_name() == "testObject"


# Generated at 2022-06-20 15:15:47.835164
# Unit test for method add_group of class Host
def test_Host_add_group():
    h1 = Host()
    h2 = Host("myhost")
    h3 = Host("myhost", 1234)
    h3_expected = dict(
        name='myhost',
        vars={'ansible_port': 1234},
        address='myhost',
        uuid=h3._uuid,
        groups=[],
        implicit=False
    )

    assert h1.name is None
    assert h1.vars == {}
    assert h1.groups == []
    assert h1.address == None
    assert h1._uuid is not None
    assert h1.implicit == False

    assert h2.name == "myhost"
    assert h2.vars == {}
    assert h2.groups == []
    assert h2.address == "myhost"
    assert h2._uuid

# Generated at 2022-06-20 15:16:08.785672
# Unit test for method get_name of class Host
def test_Host_get_name():
    h1 = Host('192.168.0.1')
    h2 = Host('192.168.0.1', port=22)

    assert h1.get_name() == '192.168.0.1'
    assert h2.get_name() == '192.168.0.1'



# Generated at 2022-06-20 15:16:11.471238
# Unit test for method __str__ of class Host
def test_Host___str__():
    host = Host(name='foo')
    assert host.__str__() == 'foo'
    assert str(host) == 'foo'


# Generated at 2022-06-20 15:16:14.172504
# Unit test for method serialize of class Host
def test_Host_serialize():
    host = Host(name='test')
    assert host.serialize() == dict(name='test', vars={}, address='test', uuid=host._uuid, groups=[], implicit=False)


# Generated at 2022-06-20 15:16:24.128624
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    '''
    get_groups of Host class should return a list of group that contains this host
    '''
    group = Group('group')
    group_1 = Group('group_1')
    group_2 = Group('group_2')
    group_1_1 = Group('group_1_1')
    group_1_1_1 = Group('group_1_1_1')
    group_1_1_2 = Group('group_1_1_2')

    host = Host('host_1')
    host.add_group(group)
    host.add_group(group_1)
    host.add_group(group_1_1)
    host.add_group(group_1_1_1)
    host.add_group(group_1_1_2)

# Generated at 2022-06-20 15:16:27.098557
# Unit test for method __str__ of class Host
def test_Host___str__():
    host = Host(name="test_host")

    assert host.name == "test_host"
    assert host.get_name() == "test_host"
    assert str(host) == "test_host"

# Generated at 2022-06-20 15:16:33.254194
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    test_host = Host(name='myhost', port=22)
    assert test_host.get_magic_vars() == {'inventory_hostname': 'myhost', 'inventory_hostname_short': 'myhost', 'group_names': []}

# Generated at 2022-06-20 15:16:38.379109
# Unit test for method add_group of class Host
def test_Host_add_group():
    h1 = Host('h1')
    g1 = Group('g1')
    host_add_group_result = h1.add_group(g1)
    h1_groups = h1.get_groups()
    assert host_add_group_result == True and len(h1_groups) == 1
    assert h1_groups[0] == g1

    h1.add_group(g1)
    assert len(h1_groups) == 1



# Generated at 2022-06-20 15:16:43.886079
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    host1 = Host('host1')
    host2 = Host('host2')

    assert (host1 == host2) == False
    assert (host1 == host1) == True

    # Hosts with the same uuid are equal.
    host2._uuid = host1._uuid
    assert (host1 == host2) == True

    # Hosts with the same name are equal.
    host2.set_variable('foo', 'bar')
    assert (host1 == host2) == True

# Generated at 2022-06-20 15:16:48.843432
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    host = Host(name='192.168.1.1')
    assert host.get_vars() == {}
    host.set_variable('foo', 'bar')
    assert host.get_vars() == {'foo': 'bar'}

    host2 = Host(name='192.168.1.1', port=1234)
    assert host2.get_vars() == {'ansible_port': 1234}

    host.set_variable('ansible_port', 5678)
    assert host.get_vars() == {'foo': 'bar', 'ansible_port': 5678}

# Generated at 2022-06-20 15:16:53.633842
# Unit test for method get_name of class Host
def test_Host_get_name():
    host = Host('testhost')
    assert(host.get_name() == 'testhost')