

# Generated at 2022-06-24 19:48:46.455836
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    group_0 = Group(str_0)
    host_0 = Host(str_0)
    host_0.remove_group(group_0)


# Generated at 2022-06-24 19:48:55.206968
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    str_0 = 'T*J~'
    host_0 = Host(str_0)
    str_1 = '-LX'
    str_2 = 'T'
    str_3 = 'c%'

    host_0.set_variable(str_1, str_2)
    dict_1 = host_0.get_vars()
    print(type(dict_1))
    print(dict_1)
    host_0.set_variable(str_3, str_2)
    dict_2 = host_0.get_vars()
    print(type(dict_2))
    print(dict_2)
    dict_2[str_3] = str_2
    dict_3 = dict(dict_2)



# Generated at 2022-06-24 19:48:58.525135
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    host_var_0 = Host()
    host_var_0.deserialize(5)
    assert(host_var_0.vars == {})
    assert(host_var_0._uuid != None)


# Generated at 2022-06-24 19:48:59.461510
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    # Insert your code here
    pass


# Generated at 2022-06-24 19:49:05.683878
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    """
    @summary: This test case will test the remove_group method of the Host class
    """
    # Set Up
    string_0 = 'mxzovguJj4'
    group_0 = Group(string_0)
    host_0 = Host("6+KvWA")
    set_0 = set()
    expected = True
    # Execute / Assert
    host_0.groups = set_0
    actual = host_0.remove_group(group_0)
    assert expected == actual


# Generated at 2022-06-24 19:49:09.949045
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    host_0 = Host('XYz')
    list_0 = []
    host_0.populate_ancestors(list_0)


# Generated at 2022-06-24 19:49:14.059551
# Unit test for method add_group of class Host
def test_Host_add_group():
    result = test_case_0()
    assert Host.add_group == result


# Generated at 2022-06-24 19:49:25.322266
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    str_0 = 'f^*_%c'
    group_0 = Group(str_0)
    group_1 = group_0
    group_2 = group_1
    group_3 = group_2
    group_4 = group_3
    group_5 = group_4
    group_6 = group_5
    group_7 = group_6
    group_8 = group_7
    group_9 = group_8
    group_10 = group_9
    group_11 = group_10
    group_12 = group_11
    group_13 = group_12
    group_14 = group_13
    group_15 = group_14
    group_16 = group_15
    group_17 = group_16
    group_18 = group_17
    group_19 = group_18
    group

# Generated at 2022-06-24 19:49:30.224881
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    # host.vars and value are dict
    host = Host('127.0.0.1')
    host.vars = {'c': 3, 'a': 1, 'b': 2}
    host.set_variable('c', {'d': 4, 'e': 5})
    host_vars = host.get_vars()
    assert(host_vars['c'] == {'c': 3, 'e': 5, 'd': 4, 'a': 1, 'b': 2})

    # host.vars dict, value not dict
    host.set_variable('e', 6)
    host_vars = host.get_vars()
    assert (host_vars['e'] == 6)

# Generated at 2022-06-24 19:49:33.740141
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host = Host('test_host')
    host.set_variable('test_key', 'test_value')
    assert host.vars['test_key'] == 'test_value'


# Generated at 2022-06-24 19:49:43.227570
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    # 
    # 
    # 
    str_0 = '+;i\\O'
    host_0 = Host(str_0)
    str_1 = '+;i\\O'
    int_2 = 0
    host_0.set_variable(str_1, int_2)
    # 
    # 
    # 
    str_3 = '+;i\\O'
    host_0 = Host(str_3)
    int_4 = 0
    host_0.set_variable(str_0, int_4)
    # 
    # 
    # 
    # str_5 = '+;i\\O'
    # host_0 = Host(str_5)
    # int_6 = 0
    # host_0.set_variable(str_0, int

# Generated at 2022-06-24 19:49:53.126113
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    """Unit test for method get_magic_vars of class Host"""
    # Setup test environment
    host_0 = Host()
    host_0.name = 'foo'
    arg_0 = 'bar'
    foo_0 = Group(arg_0)
    host_0.groups.append(foo_0)
    host_0.groups.append(foo_0)
    # Test code
    retval_0 = host_0.get_magic_vars()
    # Verify results
    assert retval_0['inventory_hostname'] == 'foo'
    assert retval_0['inventory_hostname_short'] == 'foo'
    assert retval_0['group_names'] == ['bar']


# Generated at 2022-06-24 19:49:57.088895
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    # test fixture
    host_0 = Host('test_host')
    # testing method set_variable for class Host
    print()
    print("Testing method 'set_variable' for Host object")
    print("Object used :", host_0)
    host_0.set_variable('test_key', 'test_value')
    assert host_0.vars['test_key'] == 'test_value', "Failed: testing Host.set_variable"
    print("Passed: testing Host.set_variable")

# Generated at 2022-06-24 19:49:58.571895
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    host_0 = Host('Lk')
    str_0 = str(host_0.get_magic_vars())
    print(str_0)


# Generated at 2022-06-24 19:50:04.708528
# Unit test for method add_group of class Host
def test_Host_add_group():
    """
    Given a host and a group, add the group to the host's group list
    """
    result = True
    # check if the new group is added to host's group list
    result = result and Host().add_group(Group("test"))
    assert result, "add_group method is failing"


# Generated at 2022-06-24 19:50:08.323369
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    str_0 = '+;i\\O'
    host_0 = Host()
    host_0.deserialize({'address':'+;i\\O'})
    assert host_0.get_name() == '+;i\\O'


# Generated at 2022-06-24 19:50:14.710831
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    str_0 = '+&2l]@'
    host_0 = Host(str_0)
    int_0 = -46
    host_0.set_variable('w', int_0)
    host_0.set_variable('G', '`3jc@')
    host_0.set_variable('B', '%')
    host_0.set_variable('U', '$x')
    host_0.set_variable('p', '5')
    host_0.set_variable('(', '9Xb')
    host_0.set_variable('o', '-')
    host_0.set_variable('{', 'A/x')
    host_0.set_variable('N', '`@]&')
    host_0.set_variable('.', '8Wn>')


# Generated at 2022-06-24 19:50:21.697119
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    str_0 = '!5U*oF'
    host_0 = Host(str_0)

    magic_vars_0 = host_0.get_magic_vars()
    # Check return type
    assert(isinstance(magic_vars_0, dict))
    assert(magic_vars_0['inventory_hostname'] == str_0)
    assert(magic_vars_0['inventory_hostname_short'] == '!5U')
    assert(magic_vars_0['group_names'] == [])


# Generated at 2022-06-24 19:50:28.780185
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    host_0 = Host('*')
    all_group_0 = Group('all')
    ansible_group_0 = Group('ansible')
    ansible_group_0.add_child_group(all_group_0)
    host_0.add_group(ansible_group_0)
    group_0 = all_group_0
    host_0.remove_group(group_0)


# Generated at 2022-06-24 19:50:32.842547
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    str_0 = '+;i\\O'
    host_0 = Host(str_0)
    data_0 = {
        'groups':[],
        'name':str_0,
        'vars':{
        }
    }
    host_0.deserialize(data_0)


# Generated at 2022-06-24 19:50:46.555190
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    str_0 = 'h|'
    str_1 = '<'
    str_2 = 'hE9'
    str_3 = '-4'
    host_0 = Host(str_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_1['name'] = str_3
    dict_0['name'] = str_1
    group_0 = Group()
    group_1 = Group()
    group_0.populate_ancestors(dict([group_0]))
    group_1.populate_ancestors(dict([group_1]))
    host_0.deserialize(dict_0)
    host_0.deserialize(dict_1)


# Generated at 2022-06-24 19:50:57.596425
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    # Testing at least one new format for group, just to make sure all tags are
    # handled properly.
    group_0 = Group('&;tX,', implicit=False, hosts=['+;i\\O'])
    host_0 = Host('+;i\\O')
    host_0.add_group(group_0)

    # TODO: Why don't we have a proper assertion here?
    assert host_0.remove_group(group_0)

    # No real need to test this method with coverage,
    # since it's a very small method, and is only
    # executed in __init__ and add_group functions.

# Local testing
if __name__ == '__main__':
    test_case_0()
    test_Host_remove_group()

# Generated at 2022-06-24 19:51:04.313616
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    # Create a group, for testing purposes
    group_0 = Group()

    # Create host object
    host_0 = Host()

    # Add group_0 to host_0
    group_1 = group_0.add_child_group(group_0)
    host_0.add_group(group_1)

    # Check if host_0 has group_1
    assert_equals(host_0.groups[0], group_1)

    # Remove group_0
    host_0.remove_group(group_0)

    # Check if host_0 groups are empty
    assert_equals(host_0.groups, [])


# Generated at 2022-06-24 19:51:05.113248
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    pass


# Generated at 2022-06-24 19:51:11.483623
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host_0 = Host('DQNj4\x7f0')
    host_0.set_variable('\x0b', '\tz')
    assert(host_0.vars['\x0b'] == '\tz')
    host_0.set_variable('<\x0b', {'=': '\x7f'})
    assert(host_0.vars['<\x0b'] == {'=': '\x7f'})
    host_0.set_variable('\x07', '\x0b\x04\x03\x0f>\x1b')
    assert(host_0.vars['\x07'] == '\x0b\x04\x03\x0f>\x1b')

# Generated at 2022-06-24 19:51:14.837809
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    str_0 = '+;i\\O'
    host = Host(str_0)
    host.set_variable('ansible_host', '192.168.33.10')


# Generated at 2022-06-24 19:51:26.327279
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    str_0 = '+;i\\O'
    host_0 = Host(str_0)
    host_vars = host_0.get_vars()
    assert len(host_vars) >0

# Generated at 2022-06-24 19:51:36.672109
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    import random
    # str_0 = 'N1*\x1e\x1eY'
    str_0 = str()
    # dict_0 = dict(zip([random.random() for x in range(0, random.randint(0, 200))], map(lambda sttrr_0: str(random.random()) if random.random() != random.randint(0, 100) else sttrr_0, [str_0 for x in range(0, random.randint(0, 200))])))

# Generated at 2022-06-24 19:51:44.544374
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    str_0 = '^;'
    host_0 = Host(str_0)
    assert(type(host_0) == Host)
    assert(type(host_0.vars) == dict)
    assert(type(host_0.name) == str)
    assert(type(host_0.groups) == list)
    assert(type(host_0.address) == str)
    assert(type(host_0._uuid) == None)
    assert(type(host_0.implicit) == bool)


# Generated at 2022-06-24 19:51:50.306185
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    print()
    print('Test Host.set_variable')
    str_0 = 'L#|'
    key_1 = '9+a'
    value_1 = 'o'
    host_0 = Host(str_0)
    assert host_0.vars == dict()
    host_0.set_variable(key_1, value_1)
    assert host_0.vars[key_1] == value_1


# Generated at 2022-06-24 19:51:57.559771
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host_0 = Host()
    host_0.set_variable('b2', 3)
    host_0.set_variable('a\\,\\a', 'k\\,\\,6')


# Generated at 2022-06-24 19:52:06.664864
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    # Note, python does not allow for an override for the hash function
    # Thus, I had to comment out the __hash__ function in class Host
    str_0 = '+;i\\O'
    host_0 = Host(str_0)
    str_1 = '8'
    host_0.set_variable(str_0, str_1)
    str_2 = '+;i\\O'
    str_3 = '8'
    assert str_2 in host_0.vars and host_0.vars.get(str_2) == str_3

# Generated at 2022-06-24 19:52:16.634382
# Unit test for method set_variable of class Host
def test_Host_set_variable():
   str_0 = '5dg'
   str_1 = '+H{pX'
   host_0 = Host(str_0)
   host_0.set_variable(str_1, str_1)
   host_0.set_variable(str_0, str_0)
   str_2 = None
   host_0.set_variable(str_0, str_2)
   host_0.set_variable(str_0, str_1)
   host_0.set_variable(str_0, str_2)
   str_3 = 'Y!|'
   host_0.set_variable(str_3, str_3)
   host_0.set_variable(str_1, str_3)
   host_0.set_variable(str_1, str_1)



# Generated at 2022-06-24 19:52:20.256408
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    result = Host.deserialize(data)
    print(result)


# Generated at 2022-06-24 19:52:29.814052
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    # Method set_variable of class Host
    # Test case 0:
    str_0 = '-0'
    int_0 = 0
    host_0 = Host(str_0)
    host_0.set_variable(str_0, int_0)

    # Test case 1:
    str_0 = 'OSm1'
    int_0 = 9
    host_1 = Host(str_0)
    host_1.set_variable(str_0, int_0)

    # Test case 2:
    str_0 = 'f~6'
    int_0 = 6
    host_2 = Host(str_0)
    host_2.set_variable(str_0, int_0)

    # Test case 3:
    str_0 = '$O'
    int_0 = 8
   

# Generated at 2022-06-24 19:52:35.367558
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():

    name = 'test'
    address = 'test'
    name_short = 'test'
    groups = []
    groups_str = []

    host = Host(name)
    host.address = address
    host.groups = groups

    magic_vars = host.get_magic_vars()

    assert magic_vars['inventory_hostname'] == name
    assert magic_vars['inventory_hostname_short'] == name_short
    assert sorted(groups_str) == sorted(magic_vars['group_names'])


# Generated at 2022-06-24 19:52:40.672041
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    str_0 = '6U\u000D'
    host_0 = Host(str_0)
    str_1 = 'H\u0009'
    int_0 = -1105
    host_0.set_variable(str_1, int_0)



# Generated at 2022-06-24 19:52:42.190666
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    str_0 = 'n;u=Dm'
    host_0 = Host(str_0)


# Generated at 2022-06-24 19:52:44.916202
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    host_0 = Host()
    data_0 = dict(name='v5', vars=dict(), address='v5', uuid=None, groups=list(), implicit=False)
    host_0.deserialize(data_0)


# Generated at 2022-06-24 19:52:48.031356
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    str_0 = '+;i\\O'
    host_0 = Host(str_0)

    # Add tests here
    key = 'ansible_port'
    value = 5555
    host_0.set_variable(key, value)
    # pass



# Generated at 2022-06-24 19:52:53.560297
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host_0 = Host('nosqldb')
    host_0.set_variable('R', 'hpr''!')
    host_0.set_variable('3(X', 'tc<$')
    host_0.set_variable('G_6', 'D6:g')
    host_0.set_variable("VPN", "o<wN")


# Generated at 2022-06-24 19:52:56.579584
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    host_0 = Host('127.0.0.1')
    str_0 = '+;i\\O'
    group_0 = Group(str_0)
    host_0.remove_group(group_0)


# Generated at 2022-06-24 19:53:05.508849
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    str_0 = ''
    host_0 = Host(str_0)
    magic_vars = host_0.get_magic_vars()
    assert magic_vars == {'inventory_hostname': '', 'group_names': [], 'inventory_hostname_short': ''}

    str_1 = ''
    host_1 = Host(str_1)
    magic_vars = host_1.get_magic_vars()
    assert magic_vars == {'inventory_hostname': '', 'group_names': [], 'inventory_hostname_short': ''}

    str_2 = 'abc'
    host_2 = Host(str_2)
    magic_vars = host_2.get_magic_vars()

# Generated at 2022-06-24 19:53:08.987363
# Unit test for method set_variable of class Host
def test_Host_set_variable():

    str_0 = 'lH'
    host_0 = Host(str_0)
    val_0 = 4
    key_0 = '+q'
    host_0.set_variable(key_0, val_0)


# Generated at 2022-06-24 19:53:11.796530
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    host = Host('testhost')
    group = Group('somegroup')

    group.hosts.append(host)
    host.add_group(group)

    serialized = host.serialize()

    new_host = Host()
    new_host.deserialize(serialized)

    assert new_host.name == host.name
    assert new_host.vars == host.vars
    assert new_host.address == host.address

    assert new_host.groups[0].name == 'somegroup'

# Generated at 2022-06-24 19:53:16.308480
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    str_0 = '+;i\\O'
    host_0 = Host(str_0)

    magic_vars_0 = host_0.get_magic_vars()
    mv_key_0 = list(magic_vars_0.keys())
    mv_key_1 = list(magic_vars_0.keys())

    str_1 = 'inventory_hostname'
    str_2 = 'inventory_hostname_short'
    str_3 = 'group_names'

    assert mv_key_0[0] == str_1 and mv_key_0[1] == str_2 and mv_key_0[2] == str_3
    assert mv_key_1[0] == str_1 and mv_key_1[1] == str_2 and mv_

# Generated at 2022-06-24 19:53:27.998507
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    str_0 = ''
    host_0 = Host(str_0)
    dict_0 = dict()
    dict_0['a'] = dict()
    dict_0['b'] = dict()
    dict_0['b']['c'] = dict()
    dict_0['d'] = dict()
    dict_0['d']['e'] = dict()
    dict_0['d']['f'] = dict()
    dict_0['g'] = dict()
    dict_0['g']['h'] = dict()
    dict_0['g']['i'] = dict()
    dict_0['g']['j'] = dict()
    dict_0['g']['k'] = dict()
    dict_0['g']['k']['l'] = dict()
    dict_0

# Generated at 2022-06-24 19:53:31.406523
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    host_0 = Host()

    host_0.deserialize({"name": "host_0@mock.com",
                        "vars": {"var_0": "val_0"}})

    assert host_0 is not None


# Generated at 2022-06-24 19:53:39.264600
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    str_0 = '5'
    dict_0 = {
    }
    dict_1 = {
    }
    dict_1['name'] = str_0
    dict_2 = {
    }
    dict_2['name'] = str_0
    dict_2['address'] = str_0
    dict_1['vars'] = dict_2
    dict_0['uuid'] = str_0
    dict_0['groups'] = [
    ]
    host_0 = Host()
    host_0.deserialize(dict_1)
    assert host_0.implicit == False


# Generated at 2022-06-24 19:53:40.120639
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    pass


# Generated at 2022-06-24 19:53:49.912861
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    str_0 = 'M9d'
    list_0 = []
    dict_0 = {}
    list_1 = [dict_0, list_0]
    str_3 = 'N'
    str_4 = 'IS0Qw'
    str_5 = 'b'
    str_6 = '3*B'
    str_7 = 'Mn"'
    str_1 = '5U'
    str_2 = '='
    host_0 = Host(str_0)
    host_0.set_variable(str_1, str_2)
    host_0.set_variable(str_3, str_4)
    host_0.set_variable(str_5, str_6)
    host_0.set_variable(str_7, list_1)

# Generated at 2022-06-24 19:53:59.333649
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    str_0 = '+;i\\O'
    host_0 = Host(str_0)
    dict_0 = host_0.get_magic_vars()

    assert len(dict_0.items()) == 2
    # TODO test return value of dict_0.items()
    for key, value in dict_0.items():
        if key == 'group_names':
            assert value == []
        elif key == 'inventory_hostname':
            assert value == str_0
        elif key == 'inventory_hostname_short':
            assert value == '+'


test_case_0()
test_Host_get_magic_vars()

# Generated at 2022-06-24 19:54:03.437581
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    str_0 = '+;i\\O'
    str_1 = '],('
    host_0 = Host(str_0)
    # Invoke method
    host_0.set_variable(str_0, str_1)
    print('*** Invoked method set_variable')


# Generated at 2022-06-24 19:54:09.502645
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    str_0 = '1.2.3.4'
    port_0 = 22
    host_0 = Host(str_0, port_0)
    str_1 = 'username'
    str_0 = 'testUser'
    host_0.set_variable(str_1, str_0)
    assert host_0.vars['username'] == str_0


# Generated at 2022-06-24 19:54:13.068492
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host_0 = Host()
    str_0 = 'vr6Z'
    list_0 = []
    int_0 = host_0.set_variable(str_0, list_0)
    assert len(host_0.vars) == 1



# Generated at 2022-06-24 19:54:18.036893
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host_0 = Host(str_0)
    str_1 = '+;i\\O'
    host_0.set_variable(str_1, None)
    str_2 = ''
    assert host_0.set_variable(str_1, None) == host_0.set_variable(str_2, None)


# Generated at 2022-06-24 19:54:22.124849
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    group_0 = Group()
    group_1 = Group()
    group_2 = Group()

    host_0 = Host('')

    host_0.populate_ancestors([group_0, group_1, group_2])
    host_0.remove_group(group_1)


# Generated at 2022-06-24 19:54:30.812279
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    str_0 = '+;i\\O'
    host_0 = Host(str_0)

    # test case 0
    list_0 = [1, 2, 3]
    host_0.set_variable(str_0, list_0)

    dict_0 = {}
    # test case 1
    str_0 = '+;i\\O'
    host_0.set_variable(str_0, dict_0)

    # test case 2
    str_0 = '+;i\\O'
    list_0 = [1, 2, 3]
    host_0.set_variable(str_0, list_0)

    # test case 3
    str_0 = '+;i\\O'
    dict_0 = {}
    host_0.set_variable(str_0, dict_0)

# Generated at 2022-06-24 19:54:34.354104
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    str_0 = '-'
    host_0 = Host(str_0)
    key_0 = 'VG'
    value_0 = '#'
    host_0.set_variable(key_0, value_0)


# Generated at 2022-06-24 19:54:37.799801
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    str_0 = 'xm'
    host_0 = Host(str_0)
    str_1 = 'Da'
    str_2 = '&'
    host_0.set_variable(str_1, str_2)


# Generated at 2022-06-24 19:54:44.210738
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    group2 = Group()
    group2.name = 'test2'

    group1 = Group()
    group1.name = 'test1'
    group1.add_child_group(group2)

    host_0 = Host(name='test')
    host_0.add_group(group1)
    host_0.remove_group(group2)


# Generated at 2022-06-24 19:54:49.056320
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host_0 = Host()
    host_0.set_variable("host_0", "host_0")
    assert host_0.vars["host_0"] == "host_0"


# Generated at 2022-06-24 19:54:51.281965
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host_0 = Host('localhost')
    host_0.set_variable('ansible_ssh_user', 'johndoe')


# Generated at 2022-06-24 19:54:55.673045
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    print("Unit test for method remove_group of class Host")
    host_0 = Host("randomString_1")
    group_0 = Group("randomString_2")
    host_0.add_group(group_0)
    removed = host_0.remove_group(group_0)
    print("Successfully removed.") if removed == True else print("Not removed.")


# Generated at 2022-06-24 19:54:58.715158
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host_0 = Host()
    host_0.set_variable({'name': 'ansible_python_interpreter'}, '-;7V')
    # Verify set_variable return a non-empty value for a given key
    assert isinstance(host_0.get_vars().get('ansible_python_interpreter'), str)


# Generated at 2022-06-24 19:55:06.824818
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    # print("Executing test_Host_set_variable...")
    str_0 = 'bwqT'
    str_1 = '-\x7F/'
    str_2 = '4^'
    str_3 = '^i(l'
    str_4 = '(v'
    str_5 = '0*'
    host_0 = Host(str_0)
    host_0.set_variable(str_1, str_2)
    assert host_0.vars[str_1] == str_2
    # print("Test set_variable Passed")


# Generated at 2022-06-24 19:55:09.922061
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    str_0 = '|j)4'
    host_1 = Host(str_0)
    int_0 = 4
    host_1.set_variable('', int_0)


# Generated at 2022-06-24 19:55:17.389393
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    h = Host()

    class Group(object):
        def __init__(self, name):
            self.name = name
            self.parents = set()

        def get_ancestors(self):
            return self.parents

        def __eq__(self, other):
            return self.name == other.name

    g1 = Group('g1')
    g2 = Group('g2')
    g3 = Group('g3')
    g4 = Group('g4')
    g5 = Group('g5')

    g2.parents.add(g1)
    g3.parents.add(g2)
    g4.parents.add(g3)
    g5.parents.add(g4)

    h.add_group(g1)
    h.add_group(g2)
    h

# Generated at 2022-06-24 19:55:27.949423
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    my_test_string = "TestString"
    my_test_list = ["Test1", "Test2"]

    # Create a group containing a variable consisting of a string
    group_0 = Group("Group0")
    group_0.set_variable("var0", my_test_string)

    # Create a host that belongs to the created group
    host_0 = Host("Host0")
    host_0.add_group(group_0)

    # Get the host's magic_variables
    host_0_magic_vars = host_0.get_magic_vars()
    assert_string_type(host_0_magic_vars)
    host_0_magic_vars_inventory_hostname = host_0_magic_vars["inventory_hostname"]

# Generated at 2022-06-24 19:55:38.370039
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    # test for a case in which the key does not exist
    host_0 = Host('192.168.0.1')
    host_0.set_variable('ssh_user', 'foo')
    assert host_0.vars['ssh_user'] == 'foo'

    # test for a case in which the key already exists and is a non-dictionary
    # value
    host_0 = Host('192.168.0.1')
    host_0.set_variable('ssh_user', 'foo')
    host_0.set_variable('ssh_user', 'bar')
    assert host_0.vars['ssh_user'] == 'bar'

    # test for a case in which the key already exists and is a dictionary
    # value
    host_0 = Host('192.168.0.1')

# Generated at 2022-06-24 19:55:49.991793
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    host_1 = Host('test_Host_get_magic_vars')
    vars_1 = host_1.get_magic_vars()
    assert vars_1['inventory_hostname'] == 'test_Host_get_magic_vars'
    assert vars_1['inventory_hostname_short'] == 'test_Host_get_magic_vars'
    assert vars_1['group_names'] == []


# Generated at 2022-06-24 19:55:56.673186
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    group_0 = Group()
    group_1 = Group()
    host_2 = Host()
    group_0.add_host(host_2)
    group_1.add_host(host_2)
    group_1.remove_host(host_2)
    assert host_2.remove_group(group_0) == False
    assert host_2.remove_group(group_1) == False


# Generated at 2022-06-24 19:56:05.682210
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    str_0 = '|'
    host_0 = Host(str_0)
    val_0 = host_0.get_magic_vars()
    assert val_0['inventory_hostname'] == '|'
    assert val_0['inventory_hostname_short'] == '|'

    str_1 = ':'
    host_1 = Host(str_1)
    val_1 = host_1.get_magic_vars()
    assert val_1['inventory_hostname'] == ':'
    assert val_1['inventory_hostname_short'] == ':'

    str_2 = 'H'
    host_2 = Host(str_2)
    val_2 = host_2.get_magic_vars()
    assert val_2['inventory_hostname'] == 'H'
    assert val_

# Generated at 2022-06-24 19:56:11.579414
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    str_0 = 'G\x1eiby\x1fY'
    group_0 = Group(str_0)
    str_1 = 'P\r"rj'
    host_0 = Host(str_1)
    host_0.populate_ancestors()
    host_0.remove_group(group_0)


# Generated at 2022-06-24 19:56:13.990666
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    name_0 = '=X#UE'
    host_0 = Host(name_0)
    magic_vars_0 = host_0.get_magic_vars()


# Generated at 2022-06-24 19:56:18.162525
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    name = 'test.name'
    host_0 = Host(name)
    result = host_0.get_magic_vars()
    assert result == {'inventory_hostname': name, 'inventory_hostname_short': name.split('.')[0], 'group_names': []}


# Generated at 2022-06-24 19:56:24.378991
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    _str = '+;i\\O'
    host_1 = Host(_str)
    _magic_vars = host_1.get_magic_vars()
    assert isinstance(_magic_vars, dict)
    assert _magic_vars['inventory_hostname'] == _str
    assert _magic_vars['inventory_hostname_short'] == _str.split('.')[0]
    assert _magic_vars['group_names'] == []


# Generated at 2022-06-24 19:56:32.441136
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    from ansible.inventory.group import Group

    str_0 = '+;i\\O'
    host_0 = Host(str_0)
    str_1 = '@'
    group_0 = Group(str_1)

    # Testing condition if group in self.groups
    # Calling method remove_group
    str_2 = '&>\x7f'
    group_1 = Group(str_2)
    host_0.add_group(group_1)
    host_0.remove_group(group_0)
    assert host_0.groups == [group_1]

    # Testing condition if group in self.groups
    # Calling method remove_group
    str_3 = 'vq#?\x7f\x7f'
    group_2 = Group(str_3)
    host_0

# Generated at 2022-06-24 19:56:35.304204
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    import ansible.inventory.group
    host_0 = Host('127.0.0.1')
    g = ansible.inventory.group.Group('all')
    host_0.add_group(g)
    assert host_0.remove_group(g) == True


# Generated at 2022-06-24 19:56:46.006390
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    str_0 = 'T'
    str_1 = 'Z'
    str_2 = '_z'
    str_3 = 'a'
    str_4 = 'e'
    str_5 = 'e'
    str_6 = 'k{'
    str_7 = 'X'
    str_8 = 'hM$'
    str_9 = '|dF'
    host_0 = Host(str_0)
    group_0 = Group(str_1)
    group_1 = Group(str_2)
    group_1.add_child_group(group_0)
    host_0.add_group(group_1)
    group_2 = Group(str_3)
    group_3 = Group(str_4)
    group_4 = Group(str_5)
   

# Generated at 2022-06-24 19:56:56.295749
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    pass


# Generated at 2022-06-24 19:57:02.648503
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    str_0 = 'yM'
    host_0 = Host(str_0)

    vars = {str_0: str_0}
    bool_0 = vars['yM']

    bool_1 = bool_0 == str_0

    if bool_1:
        bool_1 = bool_1


# Generated at 2022-06-24 19:57:04.176489
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    str_0 = 'hostname'
    host_0 = Host(str_0)


# Generated at 2022-06-24 19:57:05.057791
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    test_case_0()

# Generated at 2022-06-24 19:57:10.418936
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    host_0 = Host('*V4 j')
    group_0 = Group('f_')
    host_0.remove_group(group_0)



# Generated at 2022-06-24 19:57:15.916427
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    str_0 = '`'
    host_0 = Host(str_0)
    group_0 = group_from_yaml(str_0)
    group_1 = group_from_yaml(str_0)
    group_2 = group_from_yaml(str_0)
    bool_0 = host_0.remove_group(group_0)
    bool_1 = host_0.remove_group(group_1)
    bool_2 = host_0.remove_group(group_2)
    bool_3 = bool_1 and bool_2 and bool_0


# Generated at 2022-06-24 19:57:22.789844
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()


# Generated at 2022-06-24 19:57:23.564552
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    assert True


# Generated at 2022-06-24 19:57:27.172643
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    test_Host = Host()
    test_Host.name = 'test_name'
    answer = test_Host.get_magic_vars()
    assert answer['inventory_hostname'] == 'test_name'
    assert answer['inventory_hostname_short'] == 'test_name'
    assert answer['group_names'] == []


# Generated at 2022-06-24 19:57:32.898009
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    str_0 = 'host'
    str_1 = 'group0'
    str_2 = 'group1'
    host_0 = Host(str_0)
    group_0 = Group(str_1)
    group_1 = Group(str_2)
    host_0.add_group(group_0)
    host_0.add_group(group_1)
    host_0.remove_group(group_0)
    group_0.add_child_group(group_1)
    host_0.add_group(group_0)
    host_0.add_group(group_1)
    host_0.remove_group(group_0)
    host_0.remove_group(group_1)


# Generated at 2022-06-24 19:57:53.394122
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    group_0 = Group('jyQl+m')
    host_1 = Host('&*#Cx')
    host_1.add_group(group_0)
    host_1.remove_group(group_0)


# Generated at 2022-06-24 19:57:59.822293
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    import unittest

    host = Host("test")
    group = Group("test")
    host.groups = [group]
    result = host.remove_group(group)
    assert(len(host.groups) == 0)

    host = Host("test")
    group = Group("test")
    host.groups = [group]
    result = host.remove_group("wrong")
    assert(len(host.groups) == 1)


# Generated at 2022-06-24 19:58:02.187099
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    from ansible.inventory.group import Group
    host_1 = Host('a')
    group_1 = Group()
    host_1.remove_group(group_1)


# Generated at 2022-06-24 19:58:06.297873
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    # Setup
    str_0 = '+;i\\O'
    host_0 = Host(str_0)
    group_0 = Group('Z')
    host_0.populate_ancestors([group_0])

    # Invoke
    result = host_0.remove_group(group_0)

    # Verify
    assert result == True

# Generated at 2022-06-24 19:58:10.231016
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    group_0 = Group()
    group_1 = Group()
    host_0 = Host(name = 'h@ost', port = 55314)
    host_0.add_group(group_0)
    host_0.add_group(group_1)
    host_0.remove_group(group_1)


# Generated at 2022-06-24 19:58:12.291070
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    print("Test Host:remove_group")
    host_0 = Host('Z&X4')

    # should crash because no groups exist
    host_0.remove_group(Group('G'))


# Generated at 2022-06-24 19:58:23.394295
# Unit test for method remove_group of class Host
def test_Host_remove_group():

    # host inheritance
    host_0 = Host('host1')
    host_1 = Host('host2')

    # test empty list
    p_host_0 = host_0.remove_group(host_1)
    if host_0.groups:
        raise Exception('Failed test: groups')

    # test non-existent
    parent_0 = Group('group1')
    host_0.add_group(parent_0)
    host_1.add_group(parent_0)
    p_host_0 = host_0.remove_group(parent_0)
    p_host_1 = host_1.remove_group(parent_0)
    if host_0.groups:
        raise Exception('Failed test: groups')
    if host_1.groups:
        raise Exception('Failed test: groups')


# Generated at 2022-06-24 19:58:30.471185
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    gen_uuid = True
    str_0 = '9A'
    host_0 = Host(str_0, gen_uuid)
    port = 9
    host_0.set_variable('ansible_port', port)
    gen_uuid = True
    str_1 = '9_A'
    host_1 = Host(str_1, gen_uuid)
    port = 8
    host_1.set_variable('ansible_port', port)
    gen_uuid = True
    str_2 = '9aA'
    host_2 = Host(str_2, gen_uuid)
    port = 8
    host_2.set_variable('ansible_port', port)
    group_0 = Group(str_0)
    group_1 = Group(str_1)
    group

# Generated at 2022-06-24 19:58:39.397090
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    group_0 = Group(None)
    group_0.name = 'h'
    group_0.vars = {'P9': 'x', 'a': 'm', 'h': 'O', 'V': 'd'}
    str_0 = '5'
    host_0 = Host(str_0)
    host_0.groups.append(group_0)
    host_0.remove_group(group_0)
    # assert bool_0 is bool_1
    str_1 = host_0.name
    # assert str_1 == str_2
    # assert list_0 == list_1
    # assert dict_0 == dict_1
    # assert bool_0 is bool_1
    # assert str_1 == str_2
    # assert list_0 == list_1
    # assert dict_