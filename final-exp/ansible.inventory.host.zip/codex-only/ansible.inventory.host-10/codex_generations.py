

# Generated at 2022-06-22 20:56:39.172189
# Unit test for method get_name of class Host
def test_Host_get_name():
    name = 'test_name'
    host = Host(name)
    assert host.get_name() == name


# Generated at 2022-06-22 20:56:39.803447
# Unit test for method add_group of class Host
def test_Host_add_group():
    pass

# Generated at 2022-06-22 20:56:48.542117
# Unit test for constructor of class Host
def test_Host():
    h = Host()
    assert h.name == None
    assert h.vars == {}
    assert h.groups == []
    assert h.address == None
    assert h._uuid is not None
    assert h.implicit == False

    h = Host('testhost.example.com', 22)
    assert h.name == 'testhost.example.com'
    assert h.vars == {'ansible_port': 22}
    assert h.groups == []
    assert h.address == 'testhost.example.com'
    assert h._uuid is not None
    assert h.implicit == False

# Generated at 2022-06-22 20:56:59.768029
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    g1 = Group('g1')
    g2 = Group('g2')
    g3 = Group('g3')

    mv = dict(k='v')

    h = Host(name='h1')

    h.add_group(g1)
    h.add_group(g2)
    h.add_group(g3)

    h.set_variable('k', 'v')

    assert h.get_groups() == [g1, g2, g3]
    assert h.get_vars() == mv

    # Make sure group name appear in the order they were added.
    for i, group in enumerate(h.groups):
        assert group.name == 'g{0}'.format(i + 1)

    assert g1 in h.get_groups()
    assert g2 in h.get

# Generated at 2022-06-22 20:57:06.301446
# Unit test for method __getstate__ of class Host
def test_Host___getstate__():
    h = Host(name='foo')
    h.set_variable('bar', 'baz')
    assert h.vars['bar'] == 'baz'

    h_copy = h.__getstate__()
    assert h_copy['vars']['bar'] == 'baz'
    assert h_copy['name'] == 'foo'

# Unit tests for method __setstate__ of class Host

# Generated at 2022-06-22 20:57:08.906084
# Unit test for method __repr__ of class Host
def test_Host___repr__():
    """
    Test __repr__ method
    """
    h = Host(name="localhost")
    h.__repr__()

# Generated at 2022-06-22 20:57:10.248717
# Unit test for method __repr__ of class Host
def test_Host___repr__():
    host = Host('host1')
    assert host == 'host1'

# Generated at 2022-06-22 20:57:18.756231
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    h1 = Host(name='1')
    h2 = Host(name='2')

    # test same uuid
    h1._uuid = 'foo'
    h2._uuid = 'foo'
    assert h1 == h2

    # test different uuid
    h1._uuid = 'foo'
    h2._uuid = 'bar'
    assert h1 != h2

    # test different class
    assert h1 != object()



# Generated at 2022-06-22 20:57:20.738333
# Unit test for method __str__ of class Host
def test_Host___str__():
    host = Host(name='localhost', port=22)
    assert str(host) == 'localhost'


# Generated at 2022-06-22 20:57:29.219203
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    group_all = Group('all')
    group_all.name = 'all'
    group_web = Group('web')
    group_web.name = 'web'
    group_web.add_child_group(group_all)

    host1 = Host('host1')
    host1.add_group(group_all)
    assert host1.remove_group(group_all) == True

    host2 = Host('host2')
    host2.add_group(group_web)
    assert host2.remove_group(group_web) == True
    assert host2.remove_group(group_all) == True

# Generated at 2022-06-22 20:57:40.118838
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    host = Host('127.0.0.1')
    host.vars = {
        'user': 'admin',
        'db': {
            'user': 'root',
            'password': '12345'
        }
    }

    assert host.get_vars()['inventory_hostname'] == '127.0.0.1'
    assert host.get_vars()['inventory_hostname_short'] == '127.0.0.1'
    assert host.get_vars()['user'] == 'admin'
    assert host.get_vars()['group_names'] == []
    assert host.get_vars()['db']['user'] == 'root'
    assert host.get_vars()['db']['password'] == '12345'

# Generated at 2022-06-22 20:57:44.820711
# Unit test for constructor of class Host
def test_Host():
    """
    >>> h = Host('localhost', '22')
    >>> h.get_vars()
    {'ansible_port': 22, 'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost', 'group_names': []}
    """



# Generated at 2022-06-22 20:57:50.053282
# Unit test for constructor of class Host
def test_Host():
    h = Host()
    assert h.address == None
    h = Host('localhost')
    assert h.address == 'localhost'
    h = Host('localhost', 22)
    assert h.address == 'localhost'
    assert h.vars['ansible_port'] == 22


# Generated at 2022-06-22 20:57:56.214823
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    # init a host
    host = Host('localhost')

    # assert that __hash__ is overwritten to return hash(self.name)
    assert hash(host) == hash(host.name), '__hash__() should return hash(self.name)'

    # assert that host hashed by name is in the hash table
    htable = set()
    htable.add(host)
    assert host in htable, "Host hasn't been added"


# Generated at 2022-06-22 20:57:57.130080
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    pass

# Generated at 2022-06-22 20:57:59.583786
# Unit test for method __getstate__ of class Host
def test_Host___getstate__():
    host = Host('/home/scp/test/inventory')
    assert isinstance(host.__getstate__(), dict)


# Generated at 2022-06-22 20:58:02.617240
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    h = Host("test")
    gs = ["group1", "group2"]
    for g in gs:
        h.add_group(g)
    assert gs == h.get_groups()

# Generated at 2022-06-22 20:58:05.681425
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    """
    Method __eq__(self, other) always returns the same result, regardless of the values of the given arguments.

    Returns:
        bool: A value that always equals True.
    """
    return True


# Generated at 2022-06-22 20:58:16.446002
# Unit test for constructor of class Host
def test_Host():
    host1 = Host(name = '192.168.0.1', port = 22)
    host2 = Host(name = '192.168.0.1', port = 22)
    host3 = Host(name = '192.168.0.1', port = 22)

    assert hash(host1) == hash(host2)
    assert hash(host3) == hash(host2)
    assert host1 == host2
    assert host3 == host2
    assert host1 is not host2
    assert host3 is not host2

    host1.set_variable('test_key', 'test_value')
    assert host1.get_vars().get('test_key') == 'test_value'

    host1.set_variable('dict_key', {'key1': 'value1'})
    host1.set_variable

# Generated at 2022-06-22 20:58:25.203031
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host = Host(name="db1")
    host.set_variable("test_key", "test_value")
    assert host.vars["test_key"] == "test_value"
    host.set_variable("test_key", {"test_key_1":"test_value_1", "test_key_2":"test_value_2"})
    assert host.vars["test_key"]["test_key_1"] == "test_value_1"
    assert host.vars["test_key"]["test_key_2"] == "test_value_2"

if __name__ == "__main__":
    # Run simple test if invoked directly
    test_Host_set_variable()

# Generated at 2022-06-22 20:58:36.731122
# Unit test for method serialize of class Host
def test_Host_serialize():
    h1 = Host(name='test1', port='22')
    h2 = Host(name='test2', port='22')
    g1 = Group(name='g1')
    g2 = Group(name='g2')

    h1.add_group(g1)
    h1.add_group(g2)

    h2.add_group(g1)

    h1_s = h1.serialize()
    h2_s = h2.serialize()

    h1_d = Host()
    h2_d = Host()

    h1_d.deserialize(h1_s)
    h2_d.deserialize(h2_s)

    assert(h1_d == h1)
    assert(h2_d == h2)

# Generated at 2022-06-22 20:58:45.060482
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host = Host('test')

    host.set_variable('a', {'b': {'d': 0}})
    host.set_variable('a', {'c': 0})
    assert host.vars == {'a': {'c': 0, 'b': {'d': 0}}}

    host.set_variable('e', {'f': {'g': True}})
    host.set_variable('e', {'f': False})
    assert host.vars == {'a': {'c': 0, 'b': {'d': 0}}, 'e': {'f': False}}


# Generated at 2022-06-22 20:58:50.437090
# Unit test for method get_name of class Host
def test_Host_get_name():
    test1 = Host("test_name")
    assert test1.name == test1.get_name()

    test2 = Host("192.168.0.1")
    assert test2.address == test2.get_name()



# Generated at 2022-06-22 20:59:00.421333
# Unit test for method add_group of class Host
def test_Host_add_group():
    group1 = Group('group1')
    group11 = Group('group11')
    group12 = Group('group12')
    group111 = Group('group111')
    group2 = Group('group2')

    group1.add_child_group(group11)
    group1.add_child_group(group12)
    group11.add_child_group(group111)

    host = Host('host')
    host.add_group(group2)
    host.add_group(group1)

    assert len(host.groups) == 3
    assert group1 in host.groups
    assert group11 in host.groups
    assert group12 in host.groups

    # Test adding an already added group
    host.add_group(group2)
    assert len(host.groups) == 3


# Generated at 2022-06-22 20:59:09.460593
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    my_host = Host(name='my_host')

    assert my_host.get_magic_vars() == {
        'inventory_hostname': 'my_host',
        'inventory_hostname_short': 'my_host',
        'group_names': []
    }

    my_host.add_group(Group(gname='my_group'))

    assert my_host.get_magic_vars() == {
        'inventory_hostname': 'my_host',
        'inventory_hostname_short': 'my_host',
        'group_names': ['my_group']
    }


# Generated at 2022-06-22 20:59:15.922854
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    test_host = Host(name='test_host')
    print(test_host.__dict__)
    test_host.vars = {'a': 1, 'b': {'c': 2, 'd': 3}}
    test_host.address = '10.10.10.10'
    print(test_host.__dict__)

    test_data = test_host.serialize()
    print(test_data)

    test_host1 = Host(name='test_host1')
    test_host1.deserialize(test_data)
    print(test_host1.__dict__)


# Generated at 2022-06-22 20:59:27.798605
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    group1 = Group('group1')
    group2 = Group('group2')
    group3 = Group('group3')

    group1.add_child_group(group2)
    group1.add_child_group(group3)
    group2.add_child_group(group3)

    host1 = Host('host1')
    host2 = Host('host2')
    host3 = Host('host3')

    host1.add_group(group1)
    host1.add_group(group2)
    host1.add_group(group3)

    host2.add_group(group1)
    host2.add_group(group2)
    host2.add_group(group3)

    host3.add_group(group1)

    assert host1 != host2

# Generated at 2022-06-22 20:59:38.597177
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    host = Host('new_host')
    g1 = Group('g1')
    g2 = Group('g2')
    g3 = Group('g3')
    g3.add_parent(g2)
    g2.add_parent(g1)

    # test the populate ancestors method
    host.add_group(g3)
    assert host.groups == [g1, g2, g3]

    # check that this remains the case after re-running populate
    host.populate_ancestors()
    assert host.groups == [g1, g2, g3]

    # check that an ancestor is not added twice
    host.add_group(g1)
    assert host.groups == [g1, g2, g3]

    # check that an ancestor is not added twice

# Generated at 2022-06-22 20:59:50.227496
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    def create_group(name, *args, **kwargs):
        g = Group(name, *args, **kwargs)
        g.add_host(h)
        return g

    h = Host('h1')
    g1 = create_group('g1')
    g2a = create_group('g2a')
    g2b = create_group('g2b')
    g3 = create_group('g3')
    g4 = create_group('g4')

    g2 = Group('g2')
    g2.add_child_group(g2a)
    g2.add_child_group(g2b)

    g2b.add_child_group(g4)

    h.add_group(g1)
    h.add_group(g2)
    h.add

# Generated at 2022-06-22 21:00:01.023703
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    h = Host()
    h.vars = {'a': {'b': {'c': [1, 2, 3]}}}
    h.set_variable('a', {'a': {'a': 'test'}})
    assert h.vars['a'] == {'a': {'a': 'test'}, 'b': {'c': [1, 2, 3]}}
    h.set_variable('a', {'b': {'c': [1, 2, 3]}})
    assert h.vars == {'a': {'b': {'c': [1, 2, 3]}}}
    h.set_variable('a', {'b': {'c': [4, 5, 6]}})

# Generated at 2022-06-22 21:00:12.651662
# Unit test for method __getstate__ of class Host
def test_Host___getstate__():
    host_obj = Host()
    result = host_obj.__getstate__()
    assert result == {'name': '',
                      'vars': {},
                      'address': '',
                      'uuid': None,
                      'groups': [],
                      'implicit': False}
    host_obj.name = '192.168.3.66'
    host_obj.vars = {'ansible_port': 2222, 'ansible_ssh_user': 'root'}
    host_obj.address = '192.168.3.66'
    group_obj = Group()
    group_obj.name = 'group1'
    group_obj.vars = {'test': 'test'}
    group_obj.hosts = [host_obj]
    host_obj.groups = [group_obj]


# Generated at 2022-06-22 21:00:20.241625
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    # Create two host objects with different names
    h = Host('first')
    hh = Host('second')

    # Check that the two hosts are not equal
    assert(h.__ne__(hh)==True)
    assert(hh.__ne__(h)==True)

    # Create two host objects with the same name
    h = Host('first')
    hh = Host('first')

    # Check that the two hosts are not equal
    assert(h.__ne__(hh)==False)
    assert(hh.__ne__(h)==False)

# Generated at 2022-06-22 21:00:22.584827
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    host = Host(name='127.0.0.1')
    assert hash(host) == hash(host.name)



# Generated at 2022-06-22 21:00:27.480217
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    myhost = Host(name="test.example.com")
    expected_vars = {'inventory_hostname': 'test.example.com',
                     'inventory_hostname_short': 'test',
                     'group_names': []}
    assert myhost.vars == {}
    assert myhost.groups == []
    assert myhost.get_magic_vars() == expected_vars

# Generated at 2022-06-22 21:00:33.961022
# Unit test for method add_group of class Host
def test_Host_add_group():
    h = Host(name="test.example.com")
    g_parent = Group(name="parentexample")
    g = Group(name="example")
    g.add_child_group(g_parent)
    h.add_group(g)
    assert(h.groups == [g, g_parent])


# Generated at 2022-06-22 21:00:46.444490
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    all_group = Group(name='all')

    group_a = Group(name='a')
    group_a.add_child_group(all_group)

    group_b = Group(name='b')
    group_b.add_child_group(all_group)

    group_c = Group(name='c')
    group_c.add_child_group(all_group)

    group_d = Group(name='d')
    group_d.add_child_group(group_c)

    test_host = Host(name='test_host')
    test_host.set_variable('test_key', 'test_value')
    test_host.add_group(group_a)

    print("Test case: Group is None")

# Generated at 2022-06-22 21:00:55.065691
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    h1 = Host("h1")
    h2 = Host("h2")
    g1 = Group("g1")
    g2 = Group("g2")
    g1.add_host(h1)
    g2.add_host(h2)
    h1.set_variable("foo", {"bar": "baz"})
    h2.set_variable("foo", "zap")

    h1_vars = h1.get_vars()
    h2_vars = h2.get_vars()
    assert "foo" in h1_vars
    assert "bar" in h1_vars["foo"]
    assert "zap" == h2_vars["foo"]

    h1.add_group(g1)
    g1.add_child_group(g2)



# Generated at 2022-06-22 21:01:02.753803
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    h = Host("foo.bar.com", gen_uuid=False)
    assert h.get_magic_vars() == {"inventory_hostname": "foo.bar.com", "inventory_hostname_short": "foo", "group_names": []}
    h2 = Host("foo.bar.com", gen_uuid=False)
    assert h == h2
    assert hash(h) == hash(h2)
    assert repr(h) == "foo.bar.com"
    assert str(h) == "foo.bar.com"

# Generated at 2022-06-22 21:01:06.308828
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    '''
    test_Host___hash__ test case
    '''
    host = Host(name='test')
    assert hash(host) == hash('test'), 'Expected true, but false'


# Generated at 2022-06-22 21:01:12.135631
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host = Host("myhost")
    host.set_variable("test", {"key": "value"})
    assert host.vars["test"] == {"key": "value"}, "set_variable of Host did NOT set a dict."

    host.set_variable("test", "string")
    assert host.vars["test"] == "string", "set_variable of Host did NOT overwrite a dict."

# Generated at 2022-06-22 21:01:19.195353
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    h1 = Host('127.0.0.1')
    h2 = Host('127.0.0.1')
    assert not h1.__ne__(h2)
    assert not h1.__ne__(h1)

    h2._uuid = 'h2-uuid'
    assert h1.__ne__(h2)

    h3 = Host('127.0.0.3')
    assert h1.__ne__(h3)

    h4 = Host('127.0.0.1')
    h4._uuid = 'h2-uuid'
    assert not h1.__ne__(h4)

# Generated at 2022-06-22 21:01:28.156083
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    # Hosts are assigned groups during creation
    groups = [Group(name='a'), Group(name='b'), Group(name='c')]
    h = Host(name='test', port=1234, groups=groups)
    assert isinstance(h.get_groups()[0], Group)
    assert h.get_groups()[0].name == 'a'
    assert h.get_groups()[1].name == 'b'
    assert h.get_groups()[2].name == 'c'


if __name__ == "__main__":
    test_Host_get_groups()

# Generated at 2022-06-22 21:01:38.669425
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    host_test = Host(name='host-test')

    group1 = Group(name='group1')
    group2 = Group(name='group2')
    group3 = Group(name='group3')

    group2.add_parent(group1)
    group3.add_parent(group2)

    host_test.add_group(group3)

    host_vars = host_test.get_vars()

    assert('group_names' in host_vars) == True
    assert('inventory_hostname' in host_vars) == True
    assert('group_names' in host_vars) == True

    assert(host_vars['inventory_hostname'] == host_test.name)
    assert(host_vars['group_names'] == ['group1', 'group2', 'group3'])

# Generated at 2022-06-22 21:01:45.509275
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    import sys

    test_host = Host('test_hostname', gen_uuid=False)
    test_host.set_variable('test_var', 'test_var_value')
    test_host.vars = {'hello': 'world'}

    test_group = Group('test_group')
    test_group.vars = {'inventory_hostname': 'test_host'}
    test_host.groups = [test_group]

    host_vars = test_host.get_vars()

    if not host_vars.get('inventory_hostname') == 'test_hostname':
        print('ERROR: get_vars() test failed on inventory_hostname')
        sys.exit(1)


# Generated at 2022-06-22 21:01:49.797815
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    h1 = Host(name='test')
    h2 = Host(name='test')
    h3 = Host(name='test1')

    assert h1 == h2
    assert h1 != h3
    assert not h1 == 'test'


# Generated at 2022-06-22 21:02:00.180849
# Unit test for method add_group of class Host
def test_Host_add_group():
    g1 = Group('group1')
    g2 = Group('group2')
    g3 = Group('group3')
    g4 = Group('group4')
    g5 = Group('group5')

    g2.add_child_group(g3)
    g2.add_child_group(g4)
    g3.add_child_group(g5)

    h = Host('test')
    h.populate_ancestors()

    added = []
    for g in [g1, g2, g3, g4, g5]:
        if h.add_group(g):
            added.append(g.name)
    assert added == ['group1', 'group2', 'group3', 'group4', 'group5']


# Generated at 2022-06-22 21:02:12.461795
# Unit test for method __setstate__ of class Host
def test_Host___setstate__():
    h = Host()
    data = dict()
    data['name'] = 'example'
    data['vars'] = {'a': { 'b': { 'c': [1, 2, 3]
                              }
                        }
                   }
    data['address'] = '10.1.1.1'
    data['uuid'] = 'aabbcc'
    data['groups'] = [{ 'hosts': ['example'],
                       'vars': {'group_var1': 'abc'},
                       'name': 'example',
                       'uuid': 'efghij'
                      },
                      { 'hosts': ['example'],
                       'vars': {'group_var2': 'efg'},
                       'name': 'example',
                       'uuid': 'klmnop'
                      }]

# Generated at 2022-06-22 21:02:14.755724
# Unit test for method remove_group of class Host

# Generated at 2022-06-22 21:02:21.960230
# Unit test for method serialize of class Host
def test_Host_serialize():
    host = Host('test_host')
    group = Group('test_group')
    group.add_host(host)

    assert host.serialize() == {
        'name': host.name,
        'vars': host.vars,
        'address': host.address,
        'uuid': host._uuid,
        'groups': [group.serialize()],
        'implicit': host.implicit
    }


# Generated at 2022-06-22 21:02:31.826270
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    inventory = Inventory(variable_manager, "")

    host = Host('host1')
    host1 = Host('host1')
    host2 = Host('host2')

    assert hash(host) == hash(host1)
    assert hash(host) != hash(host2)

    host.add_group(inventory.get_group("all"))
    host1.add_group(inventory.get_group("all"))

    assert hash(host) == hash(host1)
    assert hash(host) != hash(host2)

# Generated at 2022-06-22 21:02:41.757833
# Unit test for method serialize of class Host
def test_Host_serialize():
    # Init an Host object
    host = Host()

    # Check main attributes
    assert host.name == None
    assert host.address == None

    # Set the main attributes
    host.name = 'host1'
    host.address = 'host1'

    # Check main attributes
    assert host.name == 'host1'
    assert host.address == 'host1'

    # Apply test to serialize methods
    data = host.serialize()
    assert data['name'] == 'host1'
    assert data['address'] == 'host1'
    assert data['vars'] == {}
    assert data['groups'] == []
    assert data.get('uuid')
    assert data['implicit'] == False

    # Apply test to deserialize methods
    host2 = Host()
    host2.deserialize(data)



# Generated at 2022-06-22 21:02:46.994065
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    host1 = Host(name='test_1')
    var_test = {'test_var': 'test_value'}
    magic_test = {'inventory_hostname': 'test_1'}
    magic_test['group_names'] = [g.name for g in host1.get_groups() if g.name != 'all']
    assert host1.get_vars() == magic_test

    host2 = Host(name='test_2')
    host2.set_variable('test_var', 'test_value')
    magic_test = {'inventory_hostname': 'test_2'}
    magic_test['group_names'] = [g.name for g in host2.get_groups() if g.name != 'all']

# Generated at 2022-06-22 21:02:49.984773
# Unit test for method __str__ of class Host
def test_Host___str__():
    host_SUT = Host('ansible')
    assert host_SUT.__str__() == host_SUT.name


# Generated at 2022-06-22 21:03:00.873358
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    import unittest

    class TestCase(unittest.TestCase):
        def runTest(self):
            self.assertEqual(
                Host(name='test1').get_vars(),
                {
                    'inventory_hostname': 'test1',
                    'inventory_hostname_short': 'test1',
                    'group_names': [],
                }
            )
            self.assertEqual(
                Host(name='test1', port=22).get_vars(),
                {
                    'inventory_hostname': 'test1',
                    'inventory_hostname_short': 'test1',
                    'group_names': [],
                    'ansible_port': 22,
                }
            )

# Generated at 2022-06-22 21:03:04.671803
# Unit test for method __repr__ of class Host
def test_Host___repr__():
    from ansible.inventory.host import Host
    h = Host("Host1")
    assert h.__repr__() == "Host1"


# Generated at 2022-06-22 21:03:07.249520
# Unit test for method __str__ of class Host
def test_Host___str__():
    kw = {'name': '127.0.0.1'}
    h = Host(**kw)
    assert h.__str__() == h.get_name()


# Generated at 2022-06-22 21:03:18.627033
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    print("\n----- test_Host_remove_group -----")
    h = Host("localhost", "22")

    g1 = Group("group1")
    g1.add_host(h)
    h.add_group(g1)
    print("g1 = {0}".format(g1))

    g2 = Group("group2")
    g2.add_host(h)
    g2.add_parent(g1)
    h.add_group(g2)
    print("g2 = {0}".format(g2))

    print("host_groups = {0}".format(h.groups))

    h.remove_group(g2)
    print("host_groups = {0}".format(h.groups))
# end of test_Host_remove_group



# Generated at 2022-06-22 21:03:23.726974
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    host1 = Host("test")
    host1.vars = {'test': 'one'}
    host2 = Host("test")
    host2.vars = {'test': 'one'}

    assert host1 != host2


# Generated at 2022-06-22 21:03:34.660493
# Unit test for method serialize of class Host
def test_Host_serialize():
    global Host_data1
    global Host_data2
    global Host_data3
    Host_data1 = dict(
        name='1',
        vars={'a': 1},
        address='a',
        uuid=None,
        groups=[],
        implicit=False,
    )
    Host_data2 = dict(
        name='2',
        vars={'b': 2},
        address='b',
        uuid=None,
        groups=[],
        implicit=True,
    )
    Host_data3 = dict(
        name='3',
        vars={'c': 3},
        address='c',
        uuid=None,
        groups=[],
        implicit=False,
    )

    global Host_inst1
    global Host_inst2
    global Host_inst3
   

# Generated at 2022-06-22 21:03:37.294389
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    host = Host()
    assert host.get_groups() == [] 
    assert type(host.get_groups( )) == list


# Generated at 2022-06-22 21:03:47.319400
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    ## test case: check is Ansible 1.9 compatible
    host = Host(name='myhost1.example.com', port=0)
    MagicVars = host.get_magic_vars()
    assert 'inventory_hostname' in MagicVars
    assert 'inventory_hostname_short' in MagicVars
    assert 'group_names' in MagicVars
    assert MagicVars['inventory_hostname'] == 'myhost1.example.com'
    assert MagicVars['inventory_hostname_short'] == 'myhost1'
    assert MagicVars['group_names'] == []

# Generated at 2022-06-22 21:03:52.923323
# Unit test for method serialize of class Host
def test_Host_serialize():
    host = Host(name='web1')
    host.set_variable('foo', 'bar')

    assert(isinstance(host.serialize(), dict))
    assert(host.serialize()['name'] == 'web1')
    assert(host.serialize()['vars']['foo'] == 'bar')
    assert(len(host.serialize()['groups']) == 1)
    assert(host.serialize()['groups'][0]['name'] == 'all')
    assert(host.serialize()['implicit'] == False)


# Generated at 2022-06-22 21:03:58.136125
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    host_1 = Host('host_1')
    host_2 = Host('host_1')
    host_3 = Host('host_3')
    assert(host_1 != host_3)
    assert(not(host_1 != host_2))



# Generated at 2022-06-22 21:03:59.429623
# Unit test for method __repr__ of class Host
def test_Host___repr__():
    host = Host(name='host.example.com')
    assert repr(host) == 'host.example.com'


# Generated at 2022-06-22 21:04:11.117994
# Unit test for constructor of class Host
def test_Host():
    # ansible.inventory.host.Host() is the class we are testing
    # ansible.inventory.group.Group() is the class we are referencing from host module
    # ansible.inventory.group.Group() is the class we are referencing from group module

    from ansible.inventory.group import Group
    host_args = { 'name': 'myhost', 'port': 2222 }

    for gen_uuid in 1, 0, None:
        host = Host(**host_args)
        if gen_uuid is None:
            del(host_args['gen_uuid'])

        # assert default values
        assert host.vars == {}
        assert host.groups == []
        assert host._uuid

        # assert constructor arguments
        assert host.name == host_args['name']

# Generated at 2022-06-22 21:04:17.917026
# Unit test for method __setstate__ of class Host
def test_Host___setstate__():
    '''Test deserialization data to Host instance'''
    host = Host()
    host.__setstate__({"name": "test", "vars": {"var1": "value1", "var2": "value2"}, "address": "test", "uuid": "123", "groups": [{"parents": [], "name": "test"}]})
    assert host.name == "test"
    assert host.vars['var1'] == "value1"
    assert host.vars['var2'] == "value2"
    assert host.address == "test"
    assert host._uuid == "123"
    assert host.groups[0].name == "test"

# Generated at 2022-06-22 21:04:19.961752
# Unit test for method __repr__ of class Host
def test_Host___repr__():
    host = Host('localhost')
    assert host.__repr__() == host.__str__()


# Generated at 2022-06-22 21:04:29.628535
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    # Create Host instance
    host = Host(name='hostname')

    # set variable to Host's vars
    host.set_variable('test1', 'test1_value1')
    assert host.vars['test1'] == 'test1_value1'

    host.set_variable('test2', ['test2_value1', 'test2_value2'])
    assert host.vars['test2'] == ['test2_value1', 'test2_value2']

    host.set_variable('test3', {'test3_key1': 'test3_value1', 'test3_key2': 'test3_value2'})
    assert host.vars['test3'] == {'test3_key1': 'test3_value1', 'test3_key2': 'test3_value2'}



# Generated at 2022-06-22 21:04:41.025678
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    host1 = Host('host1')
    host2 = Host('host2')
    host3 = Host('host3')

    assert (host1 == host1)
    assert (not host1 == host2)

    group1 = Group('group1')
    group1.add_host(host1)

    group2 = Group('group2')
    group2.add_host(host2)

    group3 = Group('group3')
    group3.add_host(host3)


    host1.add_group(group1)
    host2.add_group(group2)
    host3.add_group(group3)

    assert (host1 == host1)
    assert (host2 == host2)
    assert (host3 == host3)

    host3.add_group(group2)


# Generated at 2022-06-22 21:04:43.754111
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    host1 = Host(name='abc')
    host2 = Host(name='abc')
    assert host1 != host2

# Generated at 2022-06-22 21:04:52.520483
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    h1 = Host(name='h1', gen_uuid=False)
    g1 = Group(name='g1')
    g2 = Group(name='g2')
    g3 = Group(name='g3')
    g1.add_child_group(g2)
    g2.add_child_group(g3)
    assert h1.get_groups() == []
    h1.add_group(g1)
    assert h1.get_groups() == [g1]
    h1.populate_ancestors()
    assert h1.get_groups() == [g1, g2, g3]


# Generated at 2022-06-22 21:04:59.976105
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    host = Host(name='test')
    import ansible.inventory.group as group
    g1 = group.Group(name='g1')
    g2 = group.Group(name='g2')
    g2.in_group(g1)
    host.populate_ancestors([g2])
    assert host.groups == [g1, g2]
    assert g1.in_group(g2)
    assert g2.in_group(g1)

# Generated at 2022-06-22 21:05:07.045434
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    hetman = Host('hetman')
    mazepa = Host('mazepa')
    bogdan = Host('bogdan')
    lenin = Host('lenin')
    marx = Host('marx')
    poland = Group('poland')
    ukraine = Group('ukraine')
    russia = Group('russia')
    communism = Group('communism')
    hetman.add_group(poland)
    hetman.add_group(communism)
    mazepa.add_group(ukraine)
    mazepa.add_group(communism)
    bogdan.add_group(russia)
    bogdan.add_group(communism)
    lenin.add_group(russia)
    lenin.add_group(communism)
   

# Generated at 2022-06-22 21:05:10.350226
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    host = Host('localhost')
    host.deserialize(host.serialize())
    assert host.serialize()



# Generated at 2022-06-22 21:05:13.967597
# Unit test for method __hash__ of class Host
def test_Host___hash__():

    # Test Direct call
    h1 = Host(name = 'localhost')
    assert hash(h1) == hash('localhost')

    # Test indirectly
    h1 = Host(name = 'localhost')
    h2 = Host(name = 'localhost')
    assert h1 in set([h2])


# Generated at 2022-06-22 21:05:23.864389
# Unit test for method deserialize of class Host

# Generated at 2022-06-22 21:05:28.296509
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    # Create some object h1
    h1 = Host("h1.test.net")

    # Evaluate __ne__
    assert h1.__ne__(h1) == True
    assert h1.__ne__(Host("h1.test.net")) == False


# Generated at 2022-06-22 21:05:33.876040
# Unit test for constructor of class Host
def test_Host():
    ''' host_test.py:TestHost.test_Host '''

    test_hostname = "test_host"
    test_port = 22

    test_host = Host(name=test_hostname, port=test_port)
    assert test_host is not None
    assert test_hostname == test_host.get_name()
    assert test_port == test_host.get_vars()['ansible_port']



# Generated at 2022-06-22 21:05:43.101983
# Unit test for constructor of class Host
def test_Host():
    host = Host(name='localhost')
    assert host.get_name() == 'localhost'
    host.set_variable('ansible_port', 1122)
    assert host.get_variable('ansible_port') == 1122
    assert 'inventory_hostname' in host.get_magic_vars().keys()
    assert 'inventory_hostname_short' in host.get_magic_vars().keys()
    assert 'group_names' in host.get_magic_vars().keys()
    assert 'ansible_port' in host.get_vars().keys()
    assert 'inventory_hostname' in host.get_vars().keys()
    assert 'inventory_hostname_short' in host.get_vars().keys()
    assert 'group_names' in host.get_vars().keys()
    group

# Generated at 2022-06-22 21:05:51.234960
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    # create a host named host1, add a group g1 to it, populate ancestor groups
    # We expect host1 belongs to g1, g1.1 and g1.1.1 which are ancestor groups of g1
    host1 = Host(name='host1')
    group1 = Group(name='g1')
    group11 = Group(name='g1.1')
    group111 = Group(name='g1.1.1')
    group11.add_parent_group(group1)
    group111.add_parent_group(group11)
    group1.add_child_group(group111)
    host1.add_group(group111)
    host1.populate_ancestors()
    assert(host1.get_groups() == [group111, group11, group1])

    # create a host named

# Generated at 2022-06-22 21:06:03.433505
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    # Test-case 1:
    #    - Set the name of host to 'test-host'
    #    - Set the groups of host to ['all', 'test-group']
    #    - Expected:
    #        - inventory_hostname == 'test-host'
    #        - inventory_hostname_short == 'test-host'
    #        - group_names == ['test-group']

    host = Host()
    host.name = 'test-host'
    host.groups = [Group(name='all'), Group(name='test-group')]

    assert host.get_magic_vars() == {
        'inventory_hostname': 'test-host',
        'inventory_hostname_short': 'test-host',
        'group_names': ['test-group']
    }

    # Test-case 2

# Generated at 2022-06-22 21:06:09.263071
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    h = Host("testhost")
    assert not h.__ne__(h)
    assert not h.__ne__(Host("testhost"))
    assert h.__ne__(Host("anotherhost"))
    assert h.__ne__("testhost")
    assert h.__ne__(None)

# Generated at 2022-06-22 21:06:19.839674
# Unit test for method add_group of class Host
def test_Host_add_group():
    g1 = Group("pxe")
    g1.add_host(Host("host1"))
    g2 = Group("local")
    g2.add_host(Host("host1"))

    g1.set_variable("g1", "var1")
    g2.set_variable("g2", "var2")

    g2.add_group(g1)

    host1 = g2.get_host("host1")

    assert host1.get_vars() == {"g1": "var1", "g2": "var2", "inventory_hostname": "host1", "inventory_hostname_short": "host1", "group_names": ['local', 'pxe']}

# Generated at 2022-06-22 21:06:26.352769
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    group1 = Group()
    group1.name = 'parent_group'
    group2 = Group()
    group2.name = 'child_group'
    host = Host()
    host.add_group(group2)
    host.populate_ancestors([group1])
    assert host.groups == [group2, group1]
    assert host._uuid is not None

# Generated at 2022-06-22 21:06:38.778018
# Unit test for method add_group of class Host
def test_Host_add_group():

    def create_host(hostname):
        h = Host(hostname)
        return h

    host_1 = create_host("host1")
    host_2 = create_host("host2")

    group_1 = Group("group1")
    group_1.add_host(host_1)
    group_1.add_host(host_2)

    group_2 = Group("group2")
    group_2.add_host(host_2)

    group_3 = Group("group3")
    group_3.add_host(host_1)

    group_4 = Group("group4")
    group_4.add_host(host_2)

    assert host_2.add_group(group_1) == True
    assert host_2.add_group(group_2) == True