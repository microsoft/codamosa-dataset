

# Generated at 2022-06-22 20:56:47.213646
# Unit test for method __getstate__ of class Host
def test_Host___getstate__():
    """
    Unit test for method `__getstate__` of class `Host`.
    """
    group_all = Group('all')
    group_g1 = Group('g1')
    host = Host('h1')
    host.vars = {'h1var': 'h1val'}
    host.address = 'h1addr'
    host.groups = [group_all, group_g1]
    results = host.serialize()
    assert results['name'] == 'h1'
    assert results['vars']['h1var'] == 'h1val'
    assert results['address'] == 'h1addr'
    assert isinstance(results['uuid'], str)
    assert results['groups'][0]['name'] == 'all'

# Generated at 2022-06-22 20:56:54.160843
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    h = Host(name="server1")
    g = Group(name="group1")
    g2 = Group(name="group2")
    g3 = Group(name="group3")

    # set group hierarchy
    g3.add_child_group(g2)
    g2.add_child_group(g)

    h.populate_ancestors()

    assert(h.groups == [g, g2, g3])



# Generated at 2022-06-22 20:57:04.339767
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    # Test Host.deserialize()
    host = Host()

# Generated at 2022-06-22 20:57:11.889870
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    h = Host('foo.bar.com')
    h.add_group('a')
    h.add_group('b')
    h.add_group('a_b')
    h.add_group('a_b_c')
    h.add_group('all')
    assert h.get_magic_vars() == {
            'inventory_hostname': 'foo.bar.com',
            'inventory_hostname_short': 'foo',
            'group_names': ['a', 'a_b', 'a_b_c', 'b'],
            }

# Generated at 2022-06-22 20:57:14.640286
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    h1 = Host('localhost')
    h2 = Host('localhost')
    assert hash(h1) == hash(h2)



# Generated at 2022-06-22 20:57:22.049964
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    # Create a host instance
    host = Host('host.example.com')

    # Test when other is a host
    assert host != Host('host.example.com')
    assert host != Host('other.example.com')
    # Test when other is not a host
    assert host != 'host.example.com'
    assert host is not 'host.example.com'
    assert host != ''
    assert host is not ''
    assert host != None
    assert host is not None

# Generated at 2022-06-22 20:57:31.316834
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    from ansible.inventory.group import Group
    import pytest
    g1=Group('g1')
    g2=Group('g2')
    g3=Group('g3')
    g4=Group('g4')
    g5=Group('g5')
    g1.add_child_group(g2)
    g3.add_child_group(g4)
    g3.add_child_group(g5)
    g4.add_child_group(g1)
    g5.add_child_group(g3)
    g5.add_child_group(g2)
    h1=Host('h1')
    h1.add_group(g4)
    h1.add_group(g5)
    h1.populate_ancestors()
    assert g

# Generated at 2022-06-22 20:57:41.435619
# Unit test for method remove_group of class Host
def test_Host_remove_group():

    hosts = ['host1', 'host2']
    g = Group('myg')
    g.vars = {'foo': 'bar'}
    g.set_variable('ansible_port', 22)
    g.set_variable('ansible_password', 'dont tell')
    g.set_variable('foo1', 'bar1')
    g.add_child_group(Group('childg'))
    g.add_child_group(Group('childg2'))

    for host in hosts:
        h = Host(host)
        assert h.add_group(g)
        assert h.add_group(g)

        assert h.get_variable('foo') == 'bar'
        assert h.get_variable('ansible_port') == 22

# Generated at 2022-06-22 20:57:52.990005
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    host = Host(name='node0')

    # Test with no groups added
    assert len(host.get_groups()) == 0

    # Test with a single group added
    host.add_group(Group(name='all'))
    assert len(host.get_groups()) == 1
    assert host.get_groups()[0].name == 'all'

    # Test with a single group added
    host.add_group(Group(name='group1'))
    assert len(host.get_groups()) == 2
    assert host.get_groups()[0].name == 'all'
    assert host.get_groups()[1].name == 'group1'

    # Test with a single group added
    host.add_group(Group(name='group2'))
    assert len(host.get_groups()) == 3

# Generated at 2022-06-22 20:57:54.949311
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    h1 = Host()
    h1.name = "test"
    h2 = Host()
    h2.name = "test"
    assert h1 == h2


# Generated at 2022-06-22 20:58:04.582775
# Unit test for method __getstate__ of class Host
def test_Host___getstate__():
    from ansible.inventory.group import Group

    host = Host('example')
    host.set_variable('foo', 'bar')
    host.add_group(Group('group1'))

    expected = dict(
        name='example',
        vars={'foo': 'bar', 'group_names': ['group1'], 'inventory_hostname': 'example', 'inventory_hostname_short': 'example'},
        address='example',
        uuid=host._uuid,
        groups=[{'_parents': {}, '_vars': {}, '_uuid': None, 'name': 'group1', 'implicit': False}],
        implicit=False
    )

    assert host.__getstate__() == expected



# Generated at 2022-06-22 20:58:15.384667
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    h = Host('myhost', gen_uuid=False)
    h.groups = [Group('all'), Group('group1')]
    vars = h.get_magic_vars()
    assert vars['inventory_hostname'] == 'myhost'
    assert vars['inventory_hostname_short'] == 'myhost'
    assert vars['group_names'] == ['group1']

    h.name = 'myhost2.mydomain.com'
    h.groups = [Group('all'), Group('group2')]
    vars = h.get_magic_vars()
    assert vars['inventory_hostname'] == 'myhost2.mydomain.com'
    assert vars['inventory_hostname_short'] == 'myhost2'
    assert vars['group_names'] == ['group2']

# Generated at 2022-06-22 20:58:24.208403
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    g1, g2 = Group('g1'), Group('g2')
    g1.add_child_group(g2)
    h = Host(name='h')
    h.populate_ancestors()
    assert(len(h.get_groups()) == 0), "Host not yet added to any group, so no ancestor"
    h.populate_ancestors(additions=[g2])
    assert(g1 in h.get_groups()), "Method populate_ancestors must add ancestors"
    assert(g2 not in h.get_groups()), "Method populate_ancestors must not add the group itself"


# Generated at 2022-06-22 20:58:28.381795
# Unit test for method get_name of class Host
def test_Host_get_name():
    host = Host()
    host.name = "myHost"

    assert host.name == host.get_name()


# Generated at 2022-06-22 20:58:37.715961
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    '''
    [inventory_hostname]          => "localhost"
    [inventory_hostname_short]    => "localhost"
    [group_names]                 => []
    '''
    host = Host("localhost")
    assert host.get_magic_vars() == {'inventory_hostname':'localhost', 'inventory_hostname_short':'localhost', 'group_names':[]}

    '''
    [inventory_hostname]          => "example.com"
    [inventory_hostname_short]    => "example"
    [group_names]                 => []
    '''
    host = Host("example.com")
    assert host.get_magic_vars() == {'inventory_hostname':'example.com', 'inventory_hostname_short':'example', 'group_names':[]}


# Generated at 2022-06-22 20:58:47.837871
# Unit test for method set_variable of class Host
def test_Host_set_variable():

    # assert set_variable of Host class can handle data
    # of type dictionary
    host = Host()
    host.set_variable('foo', {'a':1, 'b':2})
    assert host.vars['foo'] == {'a': 1, 'b': 2}

    # assert set_variable of Host class can handle data
    # of type dictionary that is an update of the existing
    # host variable data.
    host.set_variable('foo', {'c':3, 'd':4})
    assert host.vars['foo'] == {'a': 1, 'b': 2, 'c': 3, 'd': 4}

    # assert set_variable of Host class can handle data
    # of type dictionary when a dictionary is not part of
    # the existing host variable data.

# Generated at 2022-06-22 20:58:57.924088
# Unit test for constructor of class Host
def test_Host():
    a = Host('localhost')
    assert a.get_name() == 'localhost', "get_name() should be 'localhost'"
    assert a.get_vars() == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost', 'group_names': []}, "get_vars() should be {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost', 'group_names': []}"

    b = Host('example.com', 22)
    assert b.get_name() == 'example.com', "get_name() should be 'example.com'"

# Generated at 2022-06-22 20:59:08.416750
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    # Init a host object
    h = Host()

    # Init expected results
    groups = ['group1', 'group2']
    results = {'inventory_hostname':None, 'inventory_hostname_short':None, 'group_names':groups}

    # Assign values to the host
    h.name = 'localhost'
    h.groups = groups
    h.vars = {'var1':'value1'}

    # Check results
    assert h.get_vars()=={'inventory_hostname':'localhost', 'inventory_hostname_short':'localhost', 'group_names':groups, 'var1':'value1'}

# Generated at 2022-06-22 20:59:16.408247
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host = Host()
    host.set_variable('a', '1')
    assert host.get_vars() == {'a': '1'}

    host.set_variable('a', '2')
    assert host.get_vars() == {'a': '2'}

    host.set_variable('b', '3')
    assert host.get_vars() == {'a': '2', 'b': '3'}

    host.set_variable('c', {'d': '4'})
    assert host.get_vars() == {'a': '2', 'b': '3', 'c': {'d': '4'}}

    host.set_variable('c', {'e': '5'})

# Generated at 2022-06-22 20:59:23.642590
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    fake_host = Host(name='fake.host.with.many.parts')

    expected_result = {'inventory_hostname': 'fake.host.with.many.parts',
                       'inventory_hostname_short': 'fake.host.with.many.parts',
                       'group_names': []
                      }

    result = fake_host.get_magic_vars()

    assert result == expected_result

# Generated at 2022-06-22 20:59:34.732834
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    from ansible.inventory.group import Group

    # Create the following host and group hierarchy
    #
    # Host H --> Group G1
    #         |-> Group G2 --> Group G4
    #         |               |-> Group G5
    #         |
    #         |-> Group G3
    #
    # Group hierarchy:
    #
    # G1 -> G6
    # G2 -> G6
    # G4 -> G6
    # G5 -> G6 -> G8 -> G9
    # G3 -> G7 -> G8 -> G9
    #
    # Populate ancestors of the host should result in the following
    #
    # Host H -> Group G1 -> Group G6
    #         -> Group G2 -> Group G6
    #         -> Group G4 -> Group G6
    #         -> Group G5

# Generated at 2022-06-22 20:59:37.706580
# Unit test for method __repr__ of class Host
def test_Host___repr__():
    host = Host('localhost')
    if(host != "localhost"):
        raise AssertionError("Test Host___repr__ failed")

if __name__ == '__main__':
    test_Host___repr__()

# Generated at 2022-06-22 20:59:44.721781
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    from ansible.inventory.group import Group

    host = Host()
    d1 = host.serialize()
    assert d1['name'] == host.name
    assert d1['vars'] == host.vars
    assert d1['address'] == host.address
    assert d1['uuid'] == host._uuid
    assert d1['groups'] == []
    assert d1['implicit'] == host.implicit

    g1 = Group('testgroup1')
    g2 = Group('testgroup2')
    d1['groups'].append(g1.serialize())
    d1['groups'].append(g2.serialize())

    host.deserialize(d1)
    assert host.name == d1['name']
    assert host.vars == d1['vars']
    assert host.address

# Generated at 2022-06-22 20:59:55.963094
# Unit test for method __setstate__ of class Host
def test_Host___setstate__():
    host = Host('localhost', '22')
    host.add_group('group1')
    host.set_variable('ansible_user', 'root')
    host_serialized = host.serialize()
    host_unserialized = Host(gen_uuid=False)
    host_unserialized.deserialize(host_serialized)
    assert host == host_unserialized
    assert host.get_vars()['inventory_hostname'] == host_unserialized.get_vars()['inventory_hostname']
    assert host.get_groups()[0] == host_unserialized.get_groups()[0]
    assert host.get_vars()['ansible_user'] == host_unserialized.get_vars()['ansible_user']

# Generated at 2022-06-22 21:00:05.095326
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    import sys

    ostype = ''
    if sys.platform.startswith('win'):
        ostype = "windows"
    elif sys.platform.startswith('darwin'):
        ostype = 'darwin'

    h = Host('localhost')
    h.set_variable('foo', 'bar')
    h.set_variable('yum_baseurlx', "{{ ostype }}" )
    h.set_variable('ostype', ostype)

    h.add_group( Group('all') )
    h.add_group( Group('foo') )
    h.add_group( Group('bar') )

    assert h.get_name() == 'localhost', "Host __init__ name value to be: localhost"

# Generated at 2022-06-22 21:00:07.025415
# Unit test for method __str__ of class Host
def test_Host___str__():
    h = Host('test')
    assert str(h) == 'test'


# Generated at 2022-06-22 21:00:12.042281
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    host1 = Host(name = 'test.example.com')

    expected = {'inventory_hostname': 'test.example.com', 'inventory_hostname_short': 'test', 'group_names': []}

    assert host1.get_magic_vars() == expected

# Generated at 2022-06-22 21:00:15.461048
# Unit test for method __getstate__ of class Host
def test_Host___getstate__():
    # Create a host object
    host = Host(name = 'test_host', port = 22)

    data = dict(name='test_host', address='test_host', groups=[], vars={'ansible_port': 22})
    assert host.__getstate__() == data

# Generated at 2022-06-22 21:00:21.962398
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    host = Host(name='foo')
    group1 = Group(name='group1')
    group2 = Group(name='group2')
    group3 = Group(name='group3')
    group2.add_child_group(group3)
    host.add_group(group1)
    host.add_group(group2)

    assert group1 in host.groups
    assert group2 in host.groups
    assert group3 in host.groups

# Generated at 2022-06-22 21:00:30.258932
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    # All groups
    d = {'all': Group('all'), 'all-here': Group('all-here'), 'all-here-group': Group('all-here-group')}
    d['all-here'].add_child_group(d['all'])
    d['all-here-group'].add_child_group(d['all-here'])

    # Group for test
    g1 = Group('g1')
    g2 = Group('g2')
    g3 = Group('g3')
    g4 = Group('g4')
    g5 = Group('g5')
    g6 = Group('g6')
    g7 = Group('g7')
    g8 = Group('g8')

    g1.add_child_group(d['all'])
    g1.add_child_group

# Generated at 2022-06-22 21:00:37.610295
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    host1 = Host(name="test1")
    host2 = Host(name="test2")
    host3 = Host(name="test1", gen_uuid=False)
    host4 = Host(name="test1")
    assert host1.__eq__(host1) == True
    assert host1.__eq__(host2) == False
    assert host1.__eq__(host3) == False
    assert host1.__eq__(host4) == True
test_Host___eq__()

# Generated at 2022-06-22 21:00:43.573265
# Unit test for constructor of class Host
def test_Host():
    host = Host('test.example.org')
    assert host.name == 'test.example.org'
    assert host.address == 'test.example.org'
    assert host.vars == {}
    assert host.groups == []
    assert host._uuid is not None

# Unit test of __getstate__()

# Generated at 2022-06-22 21:00:48.624207
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    h = Host()
    h.name = "test_host.example.com"
    h.groups = [Group(name="group1"), Group(name="group2")]
    result = h.get_magic_vars()
    assert result["inventory_hostname"] == "test_host.example.com"
    assert result["inventory_hostname_short"] == "test_host"
    assert result["group_names"] == ["group1", "group2"]



# Generated at 2022-06-22 21:00:54.198624
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    host = Host(name="test.example.com")

    host.vars = { "port": 22, "foo": "qux", "group_names": ["bar"] }

    expected = { "port": 22, "foo": "qux", "group_names": ["bar"],
                 "inventory_hostname": "test.example.com",
                 "inventory_hostname_short": "test" }

    assert dict(host.get_vars()) == expected

# Generated at 2022-06-22 21:00:57.235028
# Unit test for method get_name of class Host
def test_Host_get_name():
    test_name = 'foo.example.org'
    test_host = Host(name=test_name)
    assert(test_host.get_name() == test_name)



# Generated at 2022-06-22 21:01:09.214417
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    g1 = Group('g1')
    g2 = Group('g2')
    g3 = Group('g3')
    g2.add_child_group(g1)
    g3.add_child_group(g1)

    h = Host('testhost')

    h.add_group(g1)
    assert len(h.groups) == 1

    h.add_group(g2)
    assert len(h.groups) == 2

    h.add_group(g3)
    assert len(h.groups) == 3

    h.remove_group(g3)
    assert len(h.groups) == 1

    # when remove a child group, parent is also removed
    h.remove_group(g1)
    assert len(h.groups) == 0


# Generated at 2022-06-22 21:01:11.384386
# Unit test for method get_name of class Host
def test_Host_get_name():
    host = Host("test_host")
    assert host.get_name() == "test_host"


# Generated at 2022-06-22 21:01:16.148189
# Unit test for method get_name of class Host
def test_Host_get_name():
    from ansible.inventory.script import InventoryScript

    p = InventoryScript('/path/to/something')
    h = Host('test-host')
    p.add_host(h)
    assert h.get_name() == 'test-host'

    h.name = 'test-host-alias'
    assert h.get_name() == 'test-host'


# Generated at 2022-06-22 21:01:28.645432
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    h = Host()
    h.name = 'test-host'
    assert h.get_magic_vars() == {'inventory_hostname': 'test-host', 'inventory_hostname_short': 'test-host', 'group_names': []}
    h.name = 'test-host.example.org'
    assert h.get_magic_vars() == {'inventory_hostname': 'test-host.example.org', 'inventory_hostname_short': 'test-host', 'group_names': []}

    h.vars = {'foo': 'bar'}
    assert h.get_vars() == {'foo': 'bar', 'inventory_hostname': 'test-host.example.org', 'inventory_hostname_short': 'test-host', 'group_names': []}

    # inventory_host

# Generated at 2022-06-22 21:01:35.728364
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    g1 = Group('all')
    h = Host('foo')
    assert g1 not in h.get_groups()
    assert h.populate_ancestors([g1])
    assert g1 in h.get_groups()
    g2 = Group('g2', ancestors=[g1])
    assert g2 not in h.get_groups()
    assert h.populate_ancestors([g2])
    assert g2 in h.get_groups()
    assert g1 in h.get_groups()


# Generated at 2022-06-22 21:01:37.423969
# Unit test for method get_name of class Host
def test_Host_get_name():
    h = Host(name="test")
    assert h.get_name() == "test"


# Generated at 2022-06-22 21:01:38.805564
# Unit test for method get_name of class Host
def test_Host_get_name():
    h = Host('test')
    assert h.get_name() == 'test'


# Generated at 2022-06-22 21:01:48.915134
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    hg = Host(name="host-group-1")
    hg.add_group(Group(name="group-1"))
    hg.add_group(Group(name="group-2"))
    hg.add_group(Group(name="group-3"))
    groups = hg.get_groups()
    assert(len(groups) == 3)
    assert(groups[0].name == 'group-1')
    assert(groups[1].name == 'group-2')
    assert(groups[2].name == 'group-3')


# Generated at 2022-06-22 21:01:59.882862
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    # empty host
    assert Host().get_magic_vars() == {'inventory_hostname': None, 'inventory_hostname_short': None, 'group_names': []}

    # host with name only
    assert Host('localhost').get_magic_vars() == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost', 'group_names': []}

    # host with name and groups, no all

# Generated at 2022-06-22 21:02:01.842905
# Unit test for method __repr__ of class Host
def test_Host___repr__():
    result = Host()
    assert result.__repr__() == "localhost"



# Generated at 2022-06-22 21:02:13.731024
# Unit test for method add_group of class Host
def test_Host_add_group():
    class Group():
        def __init__(self, name):
            self.name = name
            self.ancestors_missed = []
            self.ancestors_added = []

        def get_ancestors(self):
            # Returns list of ancestors
            if self.name=='b_group':
                # For b_group, it has 2 ancestors
                self.ancestors_missed = [Group('a_group')]
                return self.ancestors_missed
            elif self.name=='a_group':
                # For a_group, it has 1 ancestor
                self.ancestors_missed = [Group('all')]
                return self.ancestors_missed
            else:
                # For all, it has 0 ancestor
                self.ancestors_missed = []
                return

# Generated at 2022-06-22 21:02:22.009033
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    # initialize host
    host = Host('test')
    
    # create group1
    group1 = Group('group1')
    group1.vars = {'test': 'group1'}
    host.add_group(group1)
    
    # create group2
    group2 = Group('group2')
    group2.vars = {'test': 'group2'}
    host.add_group(group2)
    
    # create group11
    group11 = Group('group11')
    group11.add_parent(group1)
    group11.vars = {'test': 'group11'}
    host.add_group(group11)
    
    # create group22
    group22 = Group('group22')
    group22.add_parent(group2)
    group22.vars

# Generated at 2022-06-22 21:02:24.444448
# Unit test for method get_name of class Host
def test_Host_get_name():

    h = Host(name="test")
    assert h.get_name() == "test"


# Generated at 2022-06-22 21:02:26.489381
# Unit test for method get_name of class Host
def test_Host_get_name():
    host = Host("myHost")
    assert host.get_name() == "myHost"


# Generated at 2022-06-22 21:02:32.621379
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    host1 = Host('test')
    host2 = Host('test')
    host3 = Host('test')
    host4 = Host('test')

    assert hash(host1) == hash(host2)
    assert hash(host2) == hash(host3)
    assert hash(host3) == hash(host4)


# Generated at 2022-06-22 21:02:34.683332
# Unit test for method get_name of class Host
def test_Host_get_name():
    host_test = Host(name='test host')
    assert host_test.get_name() == 'test host'

# Generated at 2022-06-22 21:02:38.783700
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    host = Host(name='first')
    host.set_variable('key','value')
    assert host.get_vars()['inventory_hostname'] == 'first'
    assert host.get_vars()['inventory_hostname_short'] == 'first'
    assert host.get_vars()['key'] == 'value'

# Generated at 2022-06-22 21:02:43.275592
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    h1 = Host('h1')
    h2 = Host('h1')
    h3 = Host('h3')
    assert h1 == h2, "Hosts h1 and h2 should be equal"
    assert not h1 == h3, "Hosts h1 and h3 should not be equal"


# Generated at 2022-06-22 21:02:53.084353
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    host = Host('test_host')
    vars1 = dict(a=1, b=2, c=3)
    vars2 = dict(a=1, b=3, c=3)
    host.vars = vars1
    assert id(host.get_vars()) == id(host.vars)
    host.set_variable('b', 2)
    assert id(host.get_vars()) == id(host.vars)
    host.set_variable('b', 3)
    assert id(host.get_vars()) != id(host.vars)
    assert host.get_vars() == vars2

# Generated at 2022-06-22 21:03:02.233545
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    group1 = Group(name='group1')
    group2 = Group(name='group2')
    group = Group(name='group')
    group1.add_child_group(group)

    host = Host(name='host')
    host.add_group(group1)
    host.add_group(group2)

    assert group in host.groups
    assert group1 in host.groups
    assert group2 in host.groups
    assert host.remove_group(group2)
    assert group not in host.groups
    assert group1 in host.groups
    assert group2 not in host.groups
    assert not host.remove_group(group2)

# Generated at 2022-06-22 21:03:06.801321
# Unit test for method __ne__ of class Host
def test_Host___ne__():
    a = Host()
    b = Host()
    c = b

    assert a != b # Default Host instances are different
    assert b != c # Same Host instances are equal
    assert not (a != b) # Default Host instances are different
    assert not (b != c) # Same Host instances are equal


# Generated at 2022-06-22 21:03:16.715385
# Unit test for method __getstate__ of class Host
def test_Host___getstate__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    host_stub = Host(name="sample.com")
    vm = VariableManager()
    host_stub.set_variable("ansible_ssh_user", "larry")
    g1 = Group("g1")
    g2 = Group("g2")
    g1.vars = {"var1": "value1"}
    g2.vars = {"var2": "value2"}
    host_stub.groups.append(g1)
    host_stub.groups.append(g2)

    print(host_stub.__getstate__())

if __name__ == '__main__':
    test_Host___getstate__()

# Generated at 2022-06-22 21:03:20.422118
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    # Test case 1
    host1 = Host(name='localhost')
    host2 = Host(name='localhost')

    assert(host1.__eq__(host2) == host2.__eq__(host1))


# Generated at 2022-06-22 21:03:28.151365
# Unit test for method __getstate__ of class Host
def test_Host___getstate__():
    h = Host(name='testname', port=22)
    h.vars = dict(ansible_ssh_port=22)
    h.groups = ['group1']
    h.address = 'test.name'
    h.implicit = True
    assert h.__getstate__() == dict(
        name='testname',
        vars=dict(ansible_ssh_port=22),
        address='test.name',
        uuid=h._uuid,
        groups=['group1'],
        implicit=True,
    )


# Generated at 2022-06-22 21:03:35.012241
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    h = Host('testhost', gen_uuid=False)
    h.deserialize(dict(name="testhost",
                       vars=dict(ansible_port=22),
                       address="127.0.0.1",
                       uuid="testuuid",
                       implicit=False,
                       groups=[dict(name="testgroup1",
                                    vars=dict(),
                                    parents=[],
                                    children=[],
                                    uuid="testgroup1_uuid",
                                    implicit=False),
                               dict(name="testgroup2",
                                    vars=dict(),
                                    parents=[],
                                    children=[],
                                    uuid="testgroup2_uuid",
                                    implicit=False)]))
    assert h.name == "testhost"

# Generated at 2022-06-22 21:03:43.661213
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    class GroupTest(Group):
        def __init__(self, name=None, vars=None):
            super(GroupTest, self).__init__(name, vars)
            self.parent = None

        def get_ancestors(self):
            groups = []
            parent = self.parent
            while parent is not None:
                groups.append(parent)
                parent = parent.parent
            return groups

    class HostTest(Host):
        def __init__(self, name=None, vars=None, gen_uuid=True):
            super(HostTest, self).__init__(name, vars, gen_uuid)
            self.parent = None

        def add_group(self, group):
            self.groups.append(group)

# Generated at 2022-06-22 21:03:50.307818
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    host = Host('test')
    host.set_variable('ansible_tags', ['tag'])
    host.set_variable('ansible_ssh_port', 1234)
    host.set_variable('ansible_ssh_host', '127.0.0.1')
    host.set_variable('ansible_groups', ['group1', 'group2'])
    host.set_variable('ansible_facts', dict(remote_ip='10.0.0.1'))
    host.set_variable('ansible_facts', dict(mem_total_mb='1024'))
    host.set_variable('ansible_facts', dict(ipaddr='127.0.0.1'))


# Generated at 2022-06-22 21:03:58.354849
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    # Setup a host
    testHost = Host('myHost')

    # Setup some groups
    testGroup1 = Group('testGroup1')
    testGroup11 = Group('testGroup1.1')
    testGroup12 = Group('testGroup1.2')
    testGroup12.add_child_group(testGroup11)
    testGroup2 = Group('testGroup2')
    testGroup2.add_child_group(testGroup12)

    # Add groups to the host
    testHost.add_group(testGroup11)
    testHost.add_group(testGroup2)

    # Remove group 1.2 from the host
    testHost.remove_group(testGroup12)

    # Check that group 1.2 has been removed

# Generated at 2022-06-22 21:04:03.181298
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    host1 = Host("host1")
    host2 = Host("host2")
    host3 = Host("host3")
    host4 = Host("host4")
    host5 = Host("host5")
    host6 = Host("host6")

    group1 = Group("g1")
    group2 = Group("g2")
    group3 = Group("g3")
    group4 = Group("g4")

    group3.add_child_group(group4)
    group2.add_child_group(group3)
    group1.add_child_group(group2)

    group1.add_host(host1)
    group2.add_host(host2)
    group2.add_host(host3)
    group3.add_host(host4)

# Generated at 2022-06-22 21:04:06.835560
# Unit test for method __str__ of class Host
def test_Host___str__():
    h = Host(name='test-host')
    assert h.__str__() == 'test-host'

# Generated at 2022-06-22 21:04:11.302121
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    h1 = Host(name='a', gen_uuid=False)
    h2 = Host(name='a', gen_uuid=False)
    h1._uuid = h2._uuid

    assert(hash(h1) == hash(h2))


# Generated at 2022-06-22 21:04:14.739676
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host = Host(name='localhost')
    host.set_variable('ansible_python_interpreter', '/usr/bin/python2.7')

    assert host.vars == {'ansible_python_interpreter': '/usr/bin/python2.7'}

# Generated at 2022-06-22 21:04:16.169917
# Unit test for method get_name of class Host
def test_Host_get_name():
    h = Host(name='myHost')
    assert h.get_name() == 'myHost'

# Generated at 2022-06-22 21:04:24.520964
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    g1 = Group('g1')
    g2 = Group('g2')
    g3 = Group('g3')
    g1.add_child_group(g2)
    g2.add_child_group(g3)
    h1 = Host('h1')
    h1.groups = [g1, g2]
    h1.populate_ancestors()
    expected_groups = [g1,g2,g3]
    assert h1.groups == expected_groups

# Generated at 2022-06-22 21:04:31.328407
# Unit test for method add_group of class Host
def test_Host_add_group():

    h = Host('web1')
    h.add_group(Group('ungrouped', implicit=True))
    h.add_group(Group('web', implicit=False))
    h.add_group(Group('atlantic', implicit=False))

    assert h.groups == [Group('ungrouped', implicit=True), Group('web', implicit=False), Group('atlantic', implicit=False)]
    assert h.get_groups() == [Group('ungrouped', implicit=True), Group('all', implicit=True), Group("web", implicit=False), Group("atlantic", implicit=False)]
    assert h.get_vars() == {'inventory_hostname': 'web1', 'group_names': [u'atlantic', u'web']}

# Generated at 2022-06-22 21:04:42.061006
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    h = Host('myhost')
    h.set_variable('a', 1)
    h.set_variable('b', 2)
    h.set_variable('c', 3)
    assert h.get_vars()['a'] == 1
    assert h.get_vars()['b'] == 2
    assert h.get_vars()['c'] == 3
    assert h.get_vars()['inventory_hostname'] == 'myhost'
    assert h.get_vars()['inventory_hostname_short'] == 'myhost'
    assert h.get_vars()['group_names'] == []

    # test dict merging
    h.set_variable('a', {'complex': 'var'})
    assert h.get_vars()['a'] == {'complex': 'var'}

# Generated at 2022-06-22 21:04:50.784289
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    test_groups = ["foo", "bar", "baz"]
    test_host = Host("localhost")
    for group in test_groups:
        test_host.add_group(Group(group))
    test_host.populate_ancestors()
    for group in ["all", "foo", "bar", "baz"]:
        assert group in [a.name for a in test_host.groups]
    for group in ["foo", "bar", "baz"]:
        assert group not in [a.name for a in test_host.get_groups()]

# Generated at 2022-06-22 21:05:00.484788
# Unit test for method remove_group of class Host
def test_Host_remove_group():
	h = Host('test-host')
	h.set_variable('test-key', 'test-value')

	# test__None_in_groups
	assert not h.remove_group(None)
	# test__group_in_groups
	assert h.add_group(Group('test-group'))
	assert h.remove_group(Group('test-group'))

	# test__None_not_in_groups
	assert not h.remove_group(None)
	# test__group_not_in_groups
	assert not h.remove_group(Group('test-group'))

# Generated at 2022-06-22 21:05:02.139480
# Unit test for method __str__ of class Host
def test_Host___str__():
    host = Host(name='test_host')
    assert str(host) == host.get_name()

# Generated at 2022-06-22 21:05:05.496545
# Unit test for method get_name of class Host
def test_Host_get_name():
    test_host = Host(name="test_host")
    assert test_host.get_name() == "test_host"


# Generated at 2022-06-22 21:05:11.359524
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    test_host = Host('test_host')
    test_host.set_variable('var1', 'value1')
    test_host.set_variable('var2', 'value2')
    assert test_host.get_vars() == {
        'inventory_hostname': 'test_host',
        'inventory_hostname_short': 'test_host',
        'group_names': [],
        'var1': 'value1',
        'var2': 'value2',
    }

# Generated at 2022-06-22 21:05:19.342291
# Unit test for method get_groups of class Host
def test_Host_get_groups():
    h = Host('test_host')

    g1 = Group('test_g1')
    g2 = Group('test_g2')

    h.add_group(g1)
    h.add_group(g2)

    assert h.get_name() == 'test_host'
    assert len(h.get_groups()) == 2
    assert g1 in h.get_groups()
    assert g2 in h.get_groups()

# Generated at 2022-06-22 21:05:29.001304
# Unit test for constructor of class Host
def test_Host():
    """Host unit test"""
    # Create a Host object
    test_host = Host(name='myhost')
    assert test_host.name == 'myhost'

    # Create a group object
    group = Group(name='test', hostnames=['test1', 'test2'])
    assert group.name == 'test'

    # Add a group to host
    test_host.add_group(group)
    assert test_host.groups[0] == group

    # Remove a group from host
    test_host.remove_group(group)
    assert len(test_host.groups) == 0

# Generated at 2022-06-22 21:05:38.579518
# Unit test for method serialize of class Host
def test_Host_serialize():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    h = Host("test")
    h.set_variable("test", "test")
    g = Group("test")
    g.vars = VariableManager()
    g.vars.update_vars(group_vars={})
    g.vars.set_variable("test", "test")
    h.groups += [g]
    assert h.serialize() == {'name': 'test', 'vars': {'test': 'test'}, 'address': 'test', 'uuid': h._uuid, 'groups': [g.serialize()], 'implicit': False}

# Generated at 2022-06-22 21:05:47.627532
# Unit test for method __eq__ of class Host
def test_Host___eq__():
    # Test 1
    host = Host('localhost', 8080)
    host2 = Host('localhost', 8080)
    assert(host == host2)

    # Test 2
    host = Host('test1', 8080)
    host2 = Host('test2', 8080)
    assert(host != host2)

    # Test 3
    host = Host('test1', 8080)
    host2 = Host('test1', 8081)
    assert(host != host2)

    # Test 4
    host = Host('test1', 8080)
    host2 = Host('test2', 8081)
    assert(host != host2)


# Generated at 2022-06-22 21:05:50.531558
# Unit test for method __hash__ of class Host
def test_Host___hash__():
    host = Host(gen_uuid=False)
    assert hasattr(host, '__hash__')
    assert hash(host) == hash(host.name)

# Generated at 2022-06-22 21:05:56.916848
# Unit test for method __str__ of class Host
def test_Host___str__():
    print("Test Host.__str__ ...")
    # Test data
    group_name = "test_group"
    host_name = "test_host"
    # Create a group
    group = Group(group_name)
    host = Host(host_name)
    # Add the group to host
    host.add_group(group)
    print(host.__str__())


# Generated at 2022-06-22 21:06:06.121031
# Unit test for method get_vars of class Host
def test_Host_get_vars():
    import ansible.inventory.group
    # Create host 'h1'
    h1 = Host(name='h1')
    # Populate host h1 with magic vars
    h1.vars = h1.get_magic_vars()
    # Create group objects
    grp_all = ansible.inventory.group.Group(name='all')
    grp_test1 = ansible.inventory.group.Group(name='test1')
    grp_test2 = ansible.inventory.group.Group(name='test2')
    grp_test3 = ansible.inventory.group.Group(name='test3')
    # Create groups and add groups to groups
    grp_all.groups = [grp_test1]
    grp_test1.groups = [grp_test2]
    grp_

# Generated at 2022-06-22 21:06:13.758380
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    host = Host()
    host.name = "foobar"
    assert host.get_magic_vars() == {
        'inventory_hostname': 'foobar',
        'inventory_hostname_short': 'foobar',
        'group_names': [],
    }
    assert host.get_vars() == {
        'inventory_hostname': 'foobar',
        'inventory_hostname_short': 'foobar',
        'group_names': [],
    }

# Generated at 2022-06-22 21:06:20.884259
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    h = Host(name='test-host')
    g1 = Group(name='all')
    g2 = Group(name='TestGroup')
    g2.add_child_group(g1)
    h.add_group(g2)
    results = {
        'inventory_hostname': 'test-host',
        'inventory_hostname_short': 'test-host',
        'group_names': ['TestGroup'],
    }
    assert h.get_magic_vars() == results

# Generated at 2022-06-22 21:06:25.266011
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    a = Group("a")
    b = Group("b")
    c = Group("c")

    a.add_child_group(b)
    b.add_child_group(c)

    h1 = Host("host1")
    h1.add_group(b)
    h1.populate_ancestors()

    assert(a in h1.groups)
    assert(b in h1.groups)
    assert(c not in h1.groups)

# Generated at 2022-06-22 21:06:29.938311
# Unit test for constructor of class Host
def test_Host():
    print("test_Host()")
    h1 = Host("testHost")
    assert h1.get_name() == "testHost"

    h2 = Host("testHost")
    assert h2.get_name() == "testHost"

    assert  h1.get_name() == h2.get_name()
    print("test_Host() tests OK")

# Generated at 2022-06-22 21:06:33.695289
# Unit test for method __repr__ of class Host
def test_Host___repr__():

    # Setup
    expected = 'localhost'
    host = Host(name='localhost')

    # Exercise
    actual = host.__repr__()

    # Verify
    assert expected == actual

# Generated at 2022-06-22 21:06:42.137953
# Unit test for method populate_ancestors of class Host
def test_Host_populate_ancestors():
    from ansible.inventory.group import Group
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    host = Host()
    host.name = "host1"
    host.address = "host1"

    # test case 1
    host.populate_ancestors()
    assert len(host.groups) == 0

    # test case 2
    host.add_group(Group("group2"))
    host.add_group(Group("group1"))
    host.populate_ancestors()
    assert len(host.groups) == 2

    # test case 3
    host.add_group(Group("group3"))
    host.populate_ancestors()
    assert len(host.groups) == 4
    assert len(host.vars) == 0