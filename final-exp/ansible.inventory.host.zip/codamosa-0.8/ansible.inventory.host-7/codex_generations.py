

# Generated at 2022-06-11 00:17:39.807698
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    pass

# Generated at 2022-06-11 00:17:45.215378
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    assert(True)

    h = Host('test')
    g = Group('test')
    h.add_group(g)

    g2 = Group('test2')
    h.add_group(g2)

    assert(h.remove_group(g) == True)
    assert(len(h.get_groups()) == 1)

    assert(h.remove_group(g2) == True)
    assert(len(h.get_groups()) == 0)

# Generated at 2022-06-11 00:17:52.701793
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    def test(name, expected):
        h = Host(name)
        assert h.get_magic_vars() == expected

    test('localhost.localdomain', {'inventory_hostname': 'localhost.localdomain', 'inventory_hostname_short': 'localhost', 'group_names': []})
    test('localhost', {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost', 'group_names': []})

    test('web01.example.org', {'inventory_hostname_short': 'web01', 'inventory_hostname': 'web01.example.org', 'group_names': []})
    test('web01.example.com', {'inventory_hostname_short': 'web01', 'inventory_hostname': 'web01.example.com', 'group_names': []})

# Generated at 2022-06-11 00:17:59.115526
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_extra': 'extra_value'}
    testHost = Host('192.168.1.1', gen_uuid=False)

    # when the key is not in the host's vars and the value is not a dictionary
    testHost.set_variable('test_key1', 'value1')
    assert testHost.vars == {'test_key1': 'value1'}

    # when the key is in the host's vars and the value is not a dictionary
    testHost.set_variable('test_key2', 'value2')

# Generated at 2022-06-11 00:18:08.908231
# Unit test for method add_group of class Host
def test_Host_add_group():
    ahost = Host('host1')
    g1 = Group('group1')
    g2 = Group('group2')
    g2.add_child_group(g1)

    # Add first group
    if ahost.add_group(g1):
        # Success!
        assert True
    else:
        # Failure!
        assert False

    # Add second group
    if ahost.add_group(g2):
        # Success!
        assert True
    else:
        # Failure!
        assert False

    # Add duplicate group
    if ahost.add_group(g2):
        # Should Fail!
        assert False
    else:
        # Should Succeed!
        assert True


# Generated at 2022-06-11 00:18:16.883607
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host = Host('test')

    # Test 1: Test for assigning a normal value to a variable.
    host.set_variable('key1', 'value1')
    assert host.get_vars()['key1'] == 'value1'

    # Test 2: Test for setting a variable as a dictionary.
    host.set_variable('key2', {'key2_1': 'value2_1', 'key2_2': 'value2_2'})
    assert host.get_vars()['key2']['key2_2'] == 'value2_2'

    # Test 3: Test for merging a dictionary value for a variable with an existing dictionary value for the same variable.
    host.set_variable('key2', {'key2_3': 'value2_3'})

# Generated at 2022-06-11 00:18:22.260041
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    root = Group('root')
    s1 = Group('s1')
    s2 = Group('s2')

    g1 = Group('g1')
    g2 = Group('g2')
    g3 = Group('g3')
    g4 = Group('g4')

    h1 = Host('h1')
    h2 = Host('h2')
    h3 = Host('h3')
    h4 = Host('h4')
    h5 = Host('h5')
    h6 = Host('h6')

    root.add_child_group(s1)
    root.add_child_group(s2)

    s1.add_child_group(g1)
    s1.add_child_group(g2)
    s2.add_child_group(g3)
    s2

# Generated at 2022-06-11 00:18:28.092363
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host = Host("localhost")
    host.set_variable("foo",{"a":1})
    assert host.vars["foo"] == {"a":1}
    host.set_variable("foo",{"b":2})
    # TODO: the following assert should pass
    #assert host.vars["foo"] == {"a":1,"b":2}

# end of test_Host_set_variable


# Generated at 2022-06-11 00:18:35.361535
# Unit test for method add_group of class Host
def test_Host_add_group():
    host = Host('test')
    g = Group('a')
    g1 = Group('b')
    g2 = Group('c')
    g3 = Group('d')
    g1.add_child_group(g2)
    g1.add_child_group(g3)
    g2.add_child_group(g3)
    host.add_group(g)
    assert len(host.get_groups()) == 1
    host.add_group(g1)
    assert len(host.get_groups()) == 4
    host.populate_ancestors()
    assert len(host.get_groups()) == 5



# Generated at 2022-06-11 00:18:40.916918
# Unit test for method set_variable of class Host
def test_Host_set_variable():
    host = Host()
    host.vars = { "foo": { "bar": "oldvalue" } }
    to_set = { "bar": "newvalue" }

    host.set_variable("foo", to_set)
    assert(host.vars["foo"]["bar"] == "newvalue")

# Generated at 2022-06-11 00:18:52.448490
# Unit test for method deserialize of class Host

# Generated at 2022-06-11 00:18:59.285126
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    #host1 is in group1 and group2
    host1 = Host(name='host1')
    group1 = Group(name='group1')
    group2 = Group(name='group2')
    host1.add_group(group1)
    host1.add_group(group2)
    #remove group1 from host1
    host1.remove_group(group1)
    #host1 should be associated with group2 only
    assert len(host1.get_groups()) == 1
    assert group1 not in host1.get_groups()
    assert group2 in host1.get_groups()

# Generated at 2022-06-11 00:19:11.492254
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    host = Host(name='host1')
    group1 = Group(name='group1')
    group2 = Group(name='group2')
    group3 = Group(name='group3')
    group4 = Group(name='group4')
    group5 = Group(name='group5')
    group6 = Group(name='group6')
    group7 = Group(name='group7')
    group8 = Group(name='group8')
    group9 = Group(name='group9')
    group10 = Group(name='group10')
    group11 = Group(name='group11')
    host.add_group(group1)
    host.add_group(group2)
    host.add_group(group3)
    group2.add_child_group(group4)
    group4.add_child_group

# Generated at 2022-06-11 00:19:19.757114
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    import json

# Generated at 2022-06-11 00:19:30.444097
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    gr1 = Group()
    gr2 = Group()
    gr1.name = "gr1"
    gr2.name = "gr2"

    all_grp = Group()
    all_grp.name = "all"
    all_grp.parent_group = gr2

    gr2.parent_group = gr1
    gr1.parent_group = all_grp

    h = Host("h1")
    h.add_group(gr1)
    assert h.groups == [all_grp, gr1, gr2]

    h.remove_group(gr2) # Remove second group
    assert h.groups == [all_grp, gr1]  # Only gr1 and all are in h's groups

    h.remove_group(gr1) # Remove first group

# Generated at 2022-06-11 00:19:39.134184
# Unit test for method remove_group of class Host
def test_Host_remove_group():

    # Create a group
    group = Group()
    group.name = 'test_group'

    # Create a subgroup
    subgroup = Group()
    subgroup.name = 'test_subgroup'

    # Create a host
    host = Host()
    host.name = 'test_host'

    # Add the subgroup to the group
    group.add_child_group(subgroup)

    # Add the group to the host
    host.add_group(group)

    # Remove the group from the host
    host.remove_group(group)

    return host.groups == []

# Generated at 2022-06-11 00:19:46.596265
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    test_data = {
        'name': 'home',
        'groups': [{
            'name': 'group1',
            'vars': {
                'key1': 'value1',
                'key2': 'value2',
            },
            'hosts': ['host1', 'host2'],
            'children': ['group2', 'group3'],
            '_parents': ['group2', 'group3'],
            '_uuid': get_unique_id(),
        }],
        'vars': {
            'key1': 'value1',
            'key2': 'value2',
        },
        'address': '127.0.0.1',
        '_uuid': get_unique_id(),
        'implicit': False,
    }
    test_host = Host()
   

# Generated at 2022-06-11 00:19:50.207493
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    host = Host()
    host.deserialize(dict(name='localhost'))
    assert host.get_name() == 'localhost'


# Generated at 2022-06-11 00:20:00.126974
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    host = Host("test")
    group = Group("g1")
    host.add_group(group)
    host.remove_group(group)
    assert (len(host.groups) == 0)
    group = Group("g1")
    group.add_child_group(Group("g2"))
    host.add_group(group)
    host.remove_group(group)
    assert (len(host.groups) == 0)
    group = Group("g1")
    group.add_child_group(Group("g2"))
    group.add_child_group(Group("g3"))
    group2 = Group("g4")
    group2.add_child_group(Group("g5"))
    host.add_group(group)
    host.add_group(group2)
    host.remove_group

# Generated at 2022-06-11 00:20:13.252549
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    # Create two group objects
    group1 = Group('group1')
    group2 = Group('group2')
    group3 = Group('group3')
    group4 = Group('group4')

    group1.add_child_group(group2)
    group2.add_child_group(group3)
    group2.add_child_group(group4)

    # Create host objects
    host1 = Host('host1')
    host2 = Host('host2')
    host3 = Host('host3')

    # Add groups to the host objects
    host1.add_group(group1)
    host1.add_group(group2)
    host1.add_group(group3)

    host2.add_group

# Generated at 2022-06-11 00:20:23.159763
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    # Scenario:
    # host1 with group1, group2, group3
    # group1 with group3, group4
    # group2 with group3
    host1 = Host(name="host1")
    group1 = Group(name="group1")
    group2 = Group(name="group2")
    group4 = Group(name="group4")
    group3 = Group(name="group3")
    host1.add_group(group1)
    host1.add_group(group2)
    host1.add_group(group3)
    group1.add_group(group4)
    group1.add_group(group3)
    group2.add_group(group3)

    # When we remove group1
    host1.remove_group(group1)
    # Then host1 should not have

# Generated at 2022-06-11 00:20:30.280614
# Unit test for method remove_group of class Host
def test_Host_remove_group():

    #create groups
    tmp_group_1 = Group('group_1')
    tmp_group_2 = Group('group_2')
    tmp_group_3 = Group('group_3')
    tmp_group_4 = Group('group_4')
    tmp_group_5 = Group('group_5')
    tmp_group_6 = Group('group_6')
    tmp_group_7 = Group('group_7')
    tmp_group_8 = Group('group_8')

    #create group relations
    tmp_group_1.add_child_group(tmp_group_2)
    tmp_group_1.add_child_group(tmp_group_3)
    tmp_group_2.add_child_group(tmp_group_4)

# Generated at 2022-06-11 00:20:42.264925
# Unit test for method remove_group of class Host
def test_Host_remove_group():

    import unittest

    class GroupMock:
        def __init__(self, name, parents):
            self.name = name
            self.parents = parents
            self.ancestors = []

        def get_ancestors(self):
            return self.ancestors

        def __eq__(self, other):
            if not isinstance(other, GroupMock):
                return False
            return self.name == other.name

    class InventoryMock:
        def __init__(self, name):
            self.name = name

    host = Host('localhost')
    host.groups.append(GroupMock('all', []))

    # Add a simple group
    host.add_group(GroupMock('simple', ['all']))

    # Add a complex group

# Generated at 2022-06-11 00:20:50.445024
# Unit test for method remove_group of class Host
def test_Host_remove_group():

    # create host H1 (H1 will be part of group G1)
    H1 = Host(name="H1", gen_uuid=False)
    G1 = Group(name="G1", gen_uuid=False)
    G1.add_host(H1)

    # test if G1 is in groups of H1
    assert G1 in H1.groups

    # create group G2 with ancestor G1 (G1 will be part of group G2)
    G2 = Group(name="G2", gen_uuid=False)
    G2.add_ancestor(G1)

    # add G2 to H1
    H1.add_group(G2)

    # test if G1 is in groups of H1
    assert G1 in H1.groups

    # remove G2 from H1


# Generated at 2022-06-11 00:21:02.812782
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    test_host = Host("testhost")
    testgroupall = Group("all")
    testgrouptwo = Group("two")
    testgroupthree = Group("three")
    testgroupfour = Group("four")
    testgroupfive = Group("five")
    testgroupfour.add_child_group(testgroupfive)
    testgroupthree.add_child_group(testgroupfour)
    testgrouptwo.add_child_group(testgroupthree)
    test_host.add_group(testgroupall)
    test_host.add_group(testgrouptwo)
    assert(len(test_host.get_groups()) == 5)
    test_host.remove_group(testgrouptwo)
    assert(len(test_host.get_groups()) == 1)

# Generated at 2022-06-11 00:21:09.940463
# Unit test for method remove_group of class Host
def test_Host_remove_group():

    '''
    1. Create a group "a"
    2. Create group "b" with group "a" added to its parent group
    3. Create a host "host1" with group "a" and "b" added to its groups
    4. Remove group "a" from host "host1"
    5. Verify "a" is removed and "b" remains
    '''
    from ansible.inventory.group import Group
    a = Group('a')
    b = Group('b')
    b.add_parent(a)

    host1 = Host('host1')
    host1.add_group(a)
    host1.add_group(b)

    assert(a in host1.groups)
    assert(b in host1.groups)

    host1.remove_group(a)


# Generated at 2022-06-11 00:21:21.874545
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    allg = Group('all')
    linuxg = Group('linux')
    serversg = Group('servers')

    for g in [allg, linuxg, serversg]:
        g.populate_ancestors()

    # check if all groups have the 'all' ancestor
    for g in [allg, linuxg, serversg]:
        assert allg in g.get_ancestors()

    host = Host('test')
    host.add_group(allg)
    host.add_group(linuxg)
    host.add_group(serversg)
    host.populate_ancestors()

    # check for the 'all' ancestor
    assert allg in host.get_groups()
    # check for the 'linux' ancestor
    assert linuxg in host.get_groups()
    # check for the '

# Generated at 2022-06-11 00:21:30.292196
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnicode
    hosts = [Host(name='dummy1')]
    groups = [Group(name='group1'),Group(name='group2')]
    host = hosts[0]
    host.add_group(groups[1])
    assert host.remove_group(groups[1]) == True
    assert host.remove_group(groups[1]) == False
    groups[0].add_child_group(groups[1])
    host.add_group(groups[0])
    assert host.remove_group(groups[0])

# Generated at 2022-06-11 00:21:38.781743
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    h = Host(name='test_host')
    g1 = Group(name='group1')
    g2 = Group(name='group2')
    g3 = Group(name='group3')
    g4 = Group(name='group4')

    assert len(h.get_groups()) == 0
    assert h.add_group(g1)
    assert h.add_group(g2)
    assert len(h.get_groups()) == 2
    assert g1 in h.get_groups()
    assert g2 in h.get_groups()
    assert h.add_group(g3)
    assert h.add_group(g4)
    assert len(h.get_groups()) == 4
    assert g3 in h.get_groups()
    assert g4 in h.get_groups()

# Generated at 2022-06-11 00:21:47.092833
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    h = Host()
    h.deserialize(dict(
        name='host1',
        vars={'a':'b'},
        address='host1.example.com',
        uuid=None,
        groups=[],
        implicit=False
        ))
    assert h.name == 'host1'
    assert h.vars == {'a':'b'}
    assert h.address == 'host1.example.com'
    assert h.get_name() == 'host1'
    assert h.implicit == False


# Generated at 2022-06-11 00:22:02.358510
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    rahul = Host("rahul")
    all = Group("all")
    unix = Group("unix")
    linux = Group("linux")
    all.add_child_group(unix)
    unix.add_child_group(linux)
    rahul.add_group(all)
    rahul.add_group(unix)
    rahul.add_group(linux)
    assert rahul.remove_group(all) == False #exclusive ancestor of linux
    assert rahul.remove_group(linux) == True
    assert rahul.remove_group(unix) == True
    assert rahul.remove_group(unix) == False

# Generated at 2022-06-11 00:22:13.692513
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    '''
    Test to check that Host can be correctly deserialized from a JSON string
    '''
    host = Host('host_test')

# Generated at 2022-06-11 00:22:18.239390
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    data = {'inventory_hostname': 'foo.example.com', 'inventory_hostname_short': 'foo', 'group_names': []}
    h = Host(name='foo.example.com')
    assert h.get_magic_vars() == data

# Generated at 2022-06-11 00:22:24.708262
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    test_host = Host('test')
    test_group = Group('test_group')
    test_host.add_group(test_group)

    assert test_host in test_group.get_hosts()
    assert test_group in test_host.get_groups()

    test_host.remove_group(test_group)

    assert test_host not in test_group.get_hosts()
    assert test_group not in test_host.get_groups()



# Generated at 2022-06-11 00:22:34.592217
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    host = Host()
    data = {
        "name": "test_host",
        "vars": {
            "test_var": "test_value"
        },
        "address": "test_address",
        "uuid": "1234",
        "groups": [
            {
                "name": "test_group",
                "vars": {
                    "group_var": "group_value"
                }
            }
        ]
    }
    host.deserialize(data)

    assert host.name == data["name"]
    assert host.vars == data["vars"]
    assert host.address == data["address"]
    assert host._uuid == data["uuid"]
    assert len(host.groups) == 1

# Generated at 2022-06-11 00:22:36.387546
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    host = Host(name='test-host')

    data = host.serialize()
    host.deserialize(data)

# Generated at 2022-06-11 00:22:47.504290
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    host = Host()
    # test no name
    data = {'name':'', 'vars':{'key1':'value1'}}
    host.deserialize(data)
    assert host.name == '' and host.vars == {'key1':'value1'}
    # test no vars
    data = {'name':'test1', 'vars':{}}
    host.deserialize(data)
    assert host.name == 'test1' and host.vars == {}
    # test no groups
    data = {'name':'test1', 'vars':{'key1':'value1'}, 'groups':[]}
    host.deserialize(data)
    assert host.name == 'test1' and host.vars == {'key1':'value1'}
    #

# Generated at 2022-06-11 00:22:49.495305
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    host = Host(name='test')
    host.groups = [Group(name='group1')]
    vars = host.get_magic_vars()
    assert vars.get('inventory_hostname') == 'test'
    assert vars.get('inventory_hostname_short') == 'test'
    assert vars.get('group_names') == ['group1']

# Generated at 2022-06-11 00:22:56.471958
# Unit test for method remove_group of class Host
def test_Host_remove_group():
    # initialize host
    h = Host(name='host')
    # initialize group
    g = Group(name='group')

    # create a group graph, all is the topmost ancestor
    all = Group(name='all')
    all.add_child_group(g)
    g.add_host(h)

    # the host should be removed after removing group
    h.add_group(g)
    h.remove_group(g)
    assert len(h.groups) == 0


# Generated at 2022-06-11 00:23:02.667839
# Unit test for method deserialize of class Host
def test_Host_deserialize():
    host = Host('test')
    host.name = 'Test'
    host.address = 'test'
    host.vars = {'ansible_port': '8002'}
    host.groups = ['testgroup']
    host._uuid = '4da4f715-cdb4-4c11-900e-1a7b8fbfedd2'
    host.implicit = False

    def test_name():
        assert host.name == 'Test'
    def test_address():
        assert host.address == 'test'
    def test_vars():
        assert host.vars == {'ansible_port': '8002'}
    def test_groups():
        assert host.groups == ['testgroup']

# Generated at 2022-06-11 00:23:11.030737
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    host = Host(name='test.com', gen_uuid=False)
    assert host.get_magic_vars() == {'inventory_hostname':'test.com', 'inventory_hostname_short':'test', 'group_names':[]}

# Generated at 2022-06-11 00:23:21.934201
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    # Initialize a host
    host = Host('test_host')
    # Define groups for the host
    groups = [Group('test_group')]
    # Add groups to the host
    for group in groups:
        host.add_group(group)
    # Check that the magic variables inventory_hostname and inventory_hostname_short
    # have the correct values
    assert host.get_magic_vars()['inventory_hostname'] == 'test_host'
    assert host.get_magic_vars()['inventory_hostname_short'] == 'test_host'
    # Check that the group_names variable has the correct value
    assert host.get_magic_vars()['group_names'] == ['test_group']



# Generated at 2022-06-11 00:23:33.100763
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    test_host = Host("testhost")
    group_all = Group('all')
    group_a = Group('group_a')
    group_a.add_child_group(group_all)
    group_b = Group('group_b')
    group_b.add_child_group(group_a)
    test_host.add_group(group_b)
    magic_vars = test_host.get_magic_vars()
    assert magic_vars['inventory_hostname'] == test_host.name
    assert magic_vars['inventory_hostname_short'] == test_host.name.split('.')[0]
    assert sorted(magic_vars['group_names']) == sorted(['group_b'])

# Generated at 2022-06-11 00:23:42.956011
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():

    # Initialise the test host
    test_host = Host(name="test_host.example.com")
    test_host.vars = {"inventory_hostname": "test_host.example.com", "inventory_hostname_short": "test_host", "group_names": ["test_group1", "test_group2"]}

    # Run a test
    try:
        assert test_host.get_magic_vars() == test_host.vars
        print("Test get_magic_vars() of class Host() successful!")
    except AssertionError:
        print("Test get_magic_vars() of class Host() failed!")


HostVars = Host



# Generated at 2022-06-11 00:23:53.070077
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    # host with one group
    h1 = Host('test.example.com')
    g1_all = Group('all')
    g1_group1 = Group('group1')
    h1.add_group(g1_all)
    h1.add_group(g1_group1)
    h1_magic_vars = h1.get_magic_vars()

    assert h1_magic_vars['inventory_hostname'] == 'test.example.com'
    assert h1_magic_vars['inventory_hostname_short'] == 'test'
    assert h1_magic_vars['group_names'] == ['group1', 'all']

    # host with two groups
    h2 = Host('test.example.com')
    g2_all = Group('all')
    g2_group1

# Generated at 2022-06-11 00:24:03.875422
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    # @TODO: move test cases to a more reasonable place
    from ansible.inventory.group import Group

    h = Host(name='my_host')
    assert h.get_magic_vars() == {'inventory_hostname': 'my_host', 'inventory_hostname_short': 'my_host', 'group_names': []}

    h = Host(name='my_host', gen_uuid=False)
    assert h.get_magic_vars() == {'inventory_hostname': 'my_host', 'inventory_hostname_short': 'my_host', 'group_names': []}

    h = Host(name='my_host', gen_uuid=False)

# Generated at 2022-06-11 00:24:08.263141
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    host = Host("test_name", "")
    assert host.get_magic_vars() == {"inventory_hostname": "test_name", "inventory_hostname_short": "test_name", "group_names": []}

    host.name = "test_name2"
    assert host.get_magic_vars() == {"inventory_hostname": "test_name2", "inventory_hostname_short": "test_name2", "group_names": []}


# Generated at 2022-06-11 00:24:14.297327
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    host = Host('foo.example.org')
    host.add_group(Group('foo'))
    host.add_group(Group('bar'))
    magic_vars = host.get_magic_vars()
    assert magic_vars['inventory_hostname'] == 'foo.example.org'
    assert magic_vars['inventory_hostname_short'] == 'foo'
    assert magic_vars['group_names'] == ['bar', 'foo']

# Generated at 2022-06-11 00:24:26.780398
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    h = Host(name='test-host')
    h.groups.extend((Group(), Group(name='group-1'), Group(name='group-2')))
    h.vars = {
        'var-1': 'value-1',
        'var-2': 'value-2',
        'var-3': {
            'sub-var-1': 'sub-value-1',
            'sub-var-2': 'sub-value-2'
        },
    }
    magic_vars = h.get_magic_vars()
    assert magic_vars['inventory_hostname'] == 'test-host'
    assert magic_vars['inventory_hostname_short'] == 'test-host'
    assert magic_vars['group_names'] == ['group-1', 'group-2']

    h

# Generated at 2022-06-11 00:24:31.868431
# Unit test for method get_magic_vars of class Host
def test_Host_get_magic_vars():
    h = Host(name='localhost')
    h.get_magic_vars()
    assert h.vars['inventory_hostname'] == 'localhost'
    assert h.vars['inventory_hostname_short'] == 'localhost'
    assert h.vars['group_names'] == []