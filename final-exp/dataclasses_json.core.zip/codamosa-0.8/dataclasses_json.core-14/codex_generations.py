

# Generated at 2022-06-11 20:54:41.288403
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.utcnow().replace(tzinfo=timezone.utc))



# Generated at 2022-06-11 20:54:42.452865
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'



# Generated at 2022-06-11 20:54:50.803309
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([]) == []
    assert encoder.default({}) == {}
    assert encoder.default(datetime.fromtimestamp(1593486458)) == 1593486458
    assert encoder.default(UUID('fd6fad1e-e29d-11ea-adc1-0242ac120002')) == \
        'fd6fad1e-e29d-11ea-adc1-0242ac120002'
    assert encoder.default(Decimal('2.4')) == '2.4'
    assert encoder.default(1) == 1


# Generated at 2022-06-11 20:54:52.641936
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) is not None



# Generated at 2022-06-11 20:54:59.846693
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(
        datetime(2019, 1, 2, 3, 4, 5, 6, timezone.utc)) == "1546751045.000006"
    assert _ExtendedEncoder().encode(Enum('TestEnum', [('A', 1), ('B', 2)]).B) == 2
    assert _ExtendedEncoder().encode(Decimal('3.14')) == "3.14"



# Generated at 2022-06-11 20:55:07.347294
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == "null"
    assert _ExtendedEncoder().encode([1, 2, 3, 4]) == "[1, 2, 3, 4]"
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(UUID("6d09f0c5-0f5c-4d7b-9044-5829b7d4c4fd")) == '"6d09f0c5-0f5c-4d7b-9044-5829b7d4c4fd"'
    assert _ExtendedEncoder().encode(datetime.now(tz=timezone.utc)) == '1563321464.7066820'


# Generated at 2022-06-11 20:55:14.240815
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = [1, 2, 3]
    l = _ExtendedEncoder().default(o)
    assert l == [1, 2, 3]
    o = {"hello": "world"}
    l = _ExtendedEncoder().default(o)
    assert l == {"hello": "world"}
    t = datetime.now(timezone.utc)
    l = _ExtendedEncoder().default(t)
    assert l == t.timestamp()



# Generated at 2022-06-11 20:55:15.528841
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    output = _ExtendedEncoder().default(datetime.now())
    assert isinstance(output, float)


# Generated at 2022-06-11 20:55:26.653626
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from .test_utils import _infer_dataclass

    @_infer_dataclass
    class Example:
        a: Collection[int]
        b: Mapping[str, int]
        c: datetime
        d: UUID
        e: Enum

    ex = Example([1, 2, 3], {'a': 1, 'b': 2}, datetime.now(timezone.utc), UUID(int=0), Example.e)

# Generated at 2022-06-11 20:55:35.762954
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(set([1, 2])) == '[1,2]'
    assert _ExtendedEncoder().encode(tuple((1, 2))) == '[1,2]'
    assert _ExtendedEncoder().encode(frozenset({1, 2})) == '[1,2]'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a":1}'
    d = datetime.now()
    assert _ExtendedEncoder().encode(d) == '{:.6f}'.format(d.timestamp())
    u = UUID('d302047c-3e2b-11ea-b77f-2e728ce88125')

# Generated at 2022-06-11 20:55:58.263453
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps([1, 2], cls=_ExtendedEncoder)
    assert True


# Generated at 2022-06-11 20:56:05.441363
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([123]).strip() == '[123]'
    assert _ExtendedEncoder().encode(
        [123, datetime.now(timezone.utc), Enum('A', 'A B C'), Decimal('3.14')]
    ).strip() == '[123,%d,"A",%s]' % (int(datetime.now().timestamp()), '"3.14"')



# Generated at 2022-06-11 20:56:09.923291
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(datetime.now(), cls=_ExtendedEncoder)
    assert json.dumps(UUID('e2a7a056-1520-4bef-acd0-b1a729b50d19'), cls=_ExtendedEncoder)
    assert json.dumps(dataclasses_json.Undefined, cls=_ExtendedEncoder)

# noinspection PyProtectedMember

# Generated at 2022-06-11 20:56:10.796415
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    a = _ExtendedEncoder()


# Generated at 2022-06-11 20:56:20.218336
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    datetime_ = datetime(2020, 1, 1, tzinfo=timezone.utc)
    datetime_str = encoder.default(datetime_)
    assert datetime_str == datetime_.timestamp()

    uuid_ = UUID('12345678123456781234567812345678')
    uuid_str = encoder.default(uuid_)
    assert uuid_str == uuid_.hex

    enum_value = cfg.LetterCase.CAMEL
    enum_str = encoder.default(enum_value)
    assert enum_str == enum_value.value

    value = Decimal('1.23')
    assert encoder.default(value) == '1.23'



# Generated at 2022-06-11 20:56:27.896498
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(1) == "1"
    assert _ExtendedEncoder().encode(True) == "true"
    assert _ExtendedEncoder().encode(1.0) == "1.0"
    assert _ExtendedEncoder().encode(["1"]) == "[\"1\"]"
    assert _ExtendedEncoder().encode({"a": 1}) == "{\"a\": 1}"
    assert _ExtendedEncoder().encode({"a": "1"}) == "{\"a\": \"1\"}"
    assert _ExtendedEncoder().encode({"a": True}) == "{\"a\": true}"
    assert _ExtendedEncoder().encode({"a": ["1"]}) == "{\"a\": [\"1\"]}"


# Generated at 2022-06-11 20:56:37.720547
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder.default(None, 0) == 0
    assert _ExtendedEncoder.default(None, 1) == 1
    assert _ExtendedEncoder.default(None, 2) == 2
    assert _ExtendedEncoder.default(None, 'test') == 'test'
    assert _ExtendedEncoder.default(None, []) == []
    assert _ExtendedEncoder.default(None, {}) == {}
    assert _ExtendedEncoder.default(None, [1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder.default(None, {1: 2, 3: 4}) == {1: 2, 3: 4}

# Generated at 2022-06-11 20:56:39.363763
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(Decimal('1.0')) == '1.0'


# Generated at 2022-06-11 20:56:42.474688
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(Decimal('2')) == '"2"'
    assert _ExtendedEncoder().encode(12) == '12'
    assert _ExtendedEncoder().encode('{"a": 2}') == '"{\\"a\\": 2}"'



# Generated at 2022-06-11 20:56:48.818212
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(
        {"a": 1, "b": 2, "c": 3}
    ) == '{"a": 1, "b": 2, "c": 3}'



# Generated at 2022-06-11 20:57:35.691443
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    class Test:
        pass
    o = Test()
    assert _ExtendedEncoder().default(o) == o
    o = [0, 1, 2]
    assert _ExtendedEncoder().default(o) == [0, 1, 2]
    o = {'a': 0, 'b': 1}
    assert _ExtendedEncoder().default(o) == {'a': 0, 'b': 1}
    o = datetime(2018, 1, 1, 0, 0, 0, 0, timezone.utc)
    assert _ExtendedEncoder().default(o) == 1514764800
    o = UUID('b4f4bbb0-c4d7-4f86-a9dd-3a8c3f777e17')

# Generated at 2022-06-11 20:57:42.473525
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(1)==1
    assert encoder.default(True)==True
    assert encoder.default(1.0)==1.0
    assert encoder.default('abc')=='abc'
    assert encoder.default(None)==None
    assert encoder.default([1, 2, 3])==[1, 2, 3]
    assert encoder.default({'foo':'bar'})=={'foo':'bar'}
    assert encoder == _ExtendedEncoder()


# Generated at 2022-06-11 20:57:46.129337
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """Example test to verify the extended encoder class."""
    assert _ExtendedEncoder().encode(42) == '42'
    assert _ExtendedEncoder().encode(True) == 'true'

# noinspection PyAbstractClass

# Generated at 2022-06-11 20:57:53.569910
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == "[1, 2, 3]"
    assert _ExtendedEncoder().encode(dict(a=1)) == '{"a": 1}'
    assert _ExtendedEncoder().encode(set(range(2))) == '[0, 1]'
    assert _ExtendedEncoder().encode(set(range(2))) == '[0, 1]'
    assert _ExtendedEncoder().encode(datetime(2000, 1, 1, tzinfo=timezone.utc)) == \
        '946684800.0'

# Generated at 2022-06-11 20:58:03.401393
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert enc.default(1) == 1
    assert enc.default('a') == 'a'
    assert enc.default([]) == []
    assert enc.default({}) == {}
    assert enc.default(True) is True
    assert enc.default(False) is False
    assert enc.default(None) is None
    assert all(isinstance(enc.default(o), str) for o in [set(), frozenset()])
    assert enc.default(decimal.Decimal('1.0')) == '1.0'
    assert enc.default(datetime.now(tz=timezone.utc)) == 1605013791

# Generated at 2022-06-11 20:58:11.571894
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from dataclasses import dataclass
    from datetime import date
    from dataclasses_json.api import encoder

    @dataclass
    class TestType:
        i: int
        s: str

    @dataclass
    class TestContainer:
        li: Collection[int]
        td: date
        obj: TestType

    tc = TestContainer([1,2,3], date(2019,2,2), TestType(1, 'AAA'))
    assert encoder(tc) == {'li': [1,2,3], 'td': '2019-02-02', 'obj': {'i':1, 's':'AAA'}}




# Generated at 2022-06-11 20:58:13.357719
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_str = json.dumps({'datetime': datetime.now(tz=timezone.utc)}, cls=_ExtendedEncoder)
    assert isinstance(json.loads(json_str)['datetime'], (float, int))


# Generated at 2022-06-11 20:58:21.428804
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(datetime.now()) > 1500000000
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal('0.123')) == '"0.123"'


# Generated at 2022-06-11 20:58:32.411759
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert not _ExtendedEncoder().encode(True)
    assert not _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(datetime(2020, 5, 9, tzinfo=timezone.utc)) == '1588974400.0'
    assert _ExtendedEncoder().encode(UUID('10000000-0000-0000-0000-000000000000')) == '10000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().encode(ValueError()) == 'ValueError()'


# Generated at 2022-06-11 20:58:39.104811
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    data = {
        'numbers': [1, 2, 3, 4.0],
        'string': 'hi',
        'bool': True,
        'none': None,
        'tuple': (1, 2, 3),
        'dict': {'a': 1, 'b': 2, 'c': 3},
        'datetime': datetime(2018, 5, 29, 1, 2, 3, 0),
        'uuid': UUID('3e6c98a6-9b6e-48c7-8e6e-8eadacb09619'),
    }
    expected = json.dumps(data)
    actual = _ExtendedEncoder().encode(data)
    assert actual == expected



# Generated at 2022-06-11 20:59:23.498263
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoded = json.dumps([1, 2, 3], cls=_ExtendedEncoder)
    assert encoded == '[1, 2, 3]'

    encoded = json.dumps({'x': 1, 'y': 2}, cls=_ExtendedEncoder)
    assert encoded == '{"x": 1, "y": 2}'

    encoded = json.dumps(UUID('9a6a5db6-5b5d-492d-b585-72ac09c817e6'), cls=_ExtendedEncoder)
    assert encoded == '"9a6a5db6-5b5d-492d-b585-72ac09c817e6"'

    encoded = json.dumps('abc', cls=_ExtendedEncoder)
    assert encoded == '"abc"'


# Generated at 2022-06-11 20:59:33.678774
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    example_dict = {'a': 3, 'b': 4}
    assert encoder.default(example_dict) == example_dict
    assert encoder.default(['a', 'b']) == ['a', 'b']
    assert encoder.default(set(['a', 'b'])) == ['a', 'b']
    assert encoder.default((('a', 'b'), ('c', 'd'))) == [['a', 'b'], ['c', 'd']]
    assert encoder.default(datetime.strptime('2020-09-04T10:19:40Z', '%Y-%m-%dT%H:%M:%SZ')) == 1599197180.0

# Generated at 2022-06-11 20:59:37.898237
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1,2,3]) == "[1, 2, 3]"
    assert _ExtendedEncoder().encode({"a":1, "b":2}) == '{"a": 1, "b": 2}'


# Generated at 2022-06-11 20:59:46.961182
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(['[list]', ('[tuple]',)]) == '["[list]", ["[tuple]"]]'
    assert _ExtendedEncoder().encode({'[dict]': {'[tuple]': 'x'}}) == '{"[dict]": {"x": "[tuple]"}}'
    assert _ExtendedEncoder().encode({'[dict]': 'x'}) == '{"[dict]": "x"}'
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(set(('[1]', '[2]'))) == '["[1]", "[2]"]'
    o = {'[dict]': set(('[1]', '[2]'))}

# Generated at 2022-06-11 20:59:55.515560
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default(datetime.now().replace(tzinfo=timezone.utc)) == datetime.now().replace(tzinfo=timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('7c0b4477-8cd6-4c96-9d6a-e6c1b6d1a6fe')) == '7c0b4477-8cd6-4c96-9d6a-e6c1b6d1a6fe'
    assert _ExtendedEncoder().default(Decimal('1.23')) == '1.23'



# Generated at 2022-06-11 21:00:03.844975
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(4) == 4
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('a8d8c5bc-a9a9-11e9-8f9e-2a86e4085a59')) == 'a8d8c5bc-a9a9-11e9-8f9e-2a86e4085a59'

# Generated at 2022-06-11 21:00:15.911061
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default([1, 3]) == [1, 3]
    assert _ExtendedEncoder().default({1: 2, "a": "b"}) == {"a": "b", 1: 2}
    assert datetime(2000, 1, 1).timestamp() == _ExtendedEncoder().default(datetime(2000, 1, 1))
    assert UUID('12345678123456781234567812345678').__str__() == _ExtendedEncoder().default(UUID('12345678123456781234567812345678'))
    assert Decimal('0.1').__str__() == _ExtendedEncoder().default(Decimal('0.1'))



# Generated at 2022-06-11 21:00:22.683389
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # noinspection PyUnresolvedReferences
    from uuid import UUID
    import time
    import json
    import dataclasses
    @dataclasses.dataclass
    class Foo:
        uuid: UUID
        dt: datetime
        enum: dataclasses_json.tests.test_encoder.FooTestEnum
        decimal: Decimal

    foo = Foo(UUID('00000000-0000-0000-0000-000000000000'),
              datetime.fromtimestamp(time.time(), tz=timezone.utc),
              dataclasses_json.tests.test_encoder.FooTestEnum.BAR,
              Decimal(1.23)
              )
    # Note: don't use json.dumps() because it will call _ExtendedEncoder.default()
    # for all elements of

# Generated at 2022-06-11 21:00:30.246138
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(2019, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == 1546300800.0
    assert _ExtendedEncoder().default(UUID('e53b5fa3-6a5f-4e20-bb5b-330acb8a56d6')) == 'e53b5fa3-6a5f-4e20-bb5b-330acb8a56d6'
    assert _ExtendedEncoder().default(Decimal('15')) == '15'
    assert _ExtendedEncoder().default(['a', 'b']) == ['a', 'b']
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

# Generated at 2022-06-11 21:00:31.971089
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'test': datetime.now(timezone.utc)})



# Generated at 2022-06-11 21:02:16.838710
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoded = json.dumps(True, cls=_ExtendedEncoder)
    assert encoded == 'true'
    encoded = json.dumps("hi", cls=_ExtendedEncoder)
    assert encoded == '"hi"'



# Generated at 2022-06-11 21:02:26.441504
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # type: () -> None
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(()) == []
    assert _ExtendedEncoder().default({'key': 'value'}) == {'key': 'value'}
    assert _ExtendedEncoder().default(datetime(2019, 4, 12, 12, 32, tzinfo=timezone.utc)) == 1555112720.0
    assert _ExtendedEncoder().default(UUID('3c836487-a8a8-4a08-bab0-4d4d8c4ebb7f')) == '3c836487-a8a8-4a08-bab0-4d4d8c4ebb7f'
    assert _Extended

# Generated at 2022-06-11 21:02:33.578799
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    x = encoder.default(Decimal('0.3'))
    assert x == '0.3'
    x = encoder.default(datetime(2019,9,24,19,30,0,0,timezone.utc))
    assert x == 1569307400


# Generated at 2022-06-11 21:02:44.762706
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.encode(True) == json.dumps(True)
    assert encoder.encode(False) == json.dumps(False)
    assert encoder.encode(None) == json.dumps(None)
    assert encoder.encode(0) == json.dumps(0)
    assert encoder.encode(1234) == json.dumps(1234)
    assert encoder.encode(12.34) == json.dumps(12.34)
    assert encoder.encode([1, 2, 3, 4]) == json.dumps([1, 2, 3, 4])

# Generated at 2022-06-11 21:02:46.553609
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc))



# Generated at 2022-06-11 21:02:50.481848
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Arrange
    json_data = dict(a=[1, 2, 3], a1=dict(a="abc", b=1), dt=datetime.now(),
                     d=Decimal('1.11'))

    # Act
    actual = json.dumps(json_data, cls=_ExtendedEncoder)

    # Assert
    assert actual is not None



# Generated at 2022-06-11 21:02:57.386776
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(42) == 42
    assert _ExtendedEncoder().default(-42) == -42
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(3.14159) == 3.14159
    assert _ExtendedEncoder().default('foo') == 'foo'
    assert _ExtendedEncoder().default(b'foo') == 'foo'
    assert _ExtendedEncoder().default(None) is None
    lst = [1, 2, 3]
    assert _ExtendedEncoder().default(lst) == lst
    tpl = (1, 2, 3)
    assert _ExtendedEncoder().default(tpl) == list(tpl)
    assert _Extended

# Generated at 2022-06-11 21:03:06.370081
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import date

    class ColdClass:
        def __init__(self):
            pass

    enc = _ExtendedEncoder()
    assert enc.default([1, 2]) == [1, 2]
    assert enc.default((1, 2)) == [1, 2]
    assert enc.default({1, 2}) == [1, 2]
    assert enc.default({'b': 1, 'a': 2}) == {'b': 1, 'a': 2}
    assert enc.default(date.today()) == date.today().timestamp()
    assert enc.default(ColdClass()) == '{}'
    assert enc.default(datetime.min) == datetime.min.timestamp()

    # Some extra tests
    assert enc.default(None) == None
    assert enc.default(True) == True
   

# Generated at 2022-06-11 21:03:07.686699
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict(aa=1)) == '{"aa": 1}'



# Generated at 2022-06-11 21:03:15.544490
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import pytest

    o = datetime.now()
    encoder = _ExtendedEncoder
    test_data = [
        (encoder(o), "\"" + str(o.timestamp()) + "\""),
        (encoder(UUID('08b90e17-0e44-44c4-8d62-ea8a284a6c4e')),
         "\"08b90e17-0e44-44c4-8d62-ea8a284a6c4e\""),
        (encoder(Decimal('3.14')), "\"3.14\"")
    ]

    for result, expected in test_data:
        assert result == expected
