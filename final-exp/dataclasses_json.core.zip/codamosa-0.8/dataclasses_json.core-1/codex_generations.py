

# Generated at 2022-06-11 20:54:42.919820
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # "Collection"
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'
    assert _ExtendedEncoder().encode(range(3)) == '[0, 1, 2]'
    assert _ExtendedEncoder().encode(tuple()) == '[]'
    assert _ExtendedEncoder().encode(list()) == '[]'
    assert _ExtendedEncoder().encode(dict()) == '{}'
    assert _ExtendedEncoder().encode((1, 2, 3, 4)) == '[1, 2, 3, 4]'
    assert _ExtendedEncoder().encode([1, 2, 3, 4]) == '[1, 2, 3, 4]'

# Generated at 2022-06-11 20:54:51.144774
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ee = _ExtendedEncoder()
    assert ee.default({1: 2}) == {1: 2}
    assert ee.default([1, 2, 3]) == [1, 2, 3]
    assert ee.default(datetime.now(timezone.utc)) == 0
    assert ee.default(UUID(int=0)) == '00000000-0000-0000-0000-000000000000'
    assert ee.default(Enum('A', 'B', 'C')) == 'A'
    assert ee.default(Decimal(1.1)) == '1.1'
    assert ee.default(None) is None



# Generated at 2022-06-11 20:55:02.231516
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    d = datetime(2020, 1, 19, 22, 30, 20, tzinfo=timezone.utc)
    u = UUID('3d3a7c1f-c9a7-46a9-bbf8-81f37d2ca2a1')
    e = Decimal('1.2345')
    e_json = _ExtendedEncoder().default(e)
    assert e_json == str(e)
    e_decoded = json.loads(json.dumps(e, cls=_ExtendedEncoder),
                           parse_float=Decimal)
    assert e_decoded == e
    l = [1, 2, 3]
    assert _ExtendedEncoder().default(l) == l
    m = {'a': 1, 'b': 2}
    assert _Extended

# Generated at 2022-06-11 20:55:03.192270
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder.default(None, 'abc') == 'abc'



# Generated at 2022-06-11 20:55:14.398623
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test of default() method
    assert _ExtendedEncoder().default({'key': 'value'}) == {'key': 'value'}
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default('string') == 'string'
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default(()) == []
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default({}) == {}




# Generated at 2022-06-11 20:55:24.843802
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == list({})
    assert encoder.default(frozenset()) == list({})
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default(1+1j) == json.dumps(1+1j)
    assert encoder.default("abc") == "abc"
    assert encoder.default(b"abc") == json.dumps(b"abc")
    assert encoder.default(()) == []
    assert encoder.default((1,)) == [1]
    assert encoder.default([]) == []

# Generated at 2022-06-11 20:55:34.674043
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(
        {"1": [1, 2, 3], "2": [4, 5, 6]}) == {"1": [1, 2, 3], "2": [4, 5, 6]}
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(
        datetime(2018, 11, 14, 10, 0, 0, 0, timezone.utc)) == 1542160000.0

# Generated at 2022-06-11 20:55:44.480660
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == "[1, 2, 3]"
    assert _ExtendedEncoder().encode([1, 2, {"a":"b"}]) == '[1, 2, {"a": "b"}]'
    assert _ExtendedEncoder().encode(1) == "1"
    assert _ExtendedEncoder().encode(True) == "true"
    assert _ExtendedEncoder().encode({"a":"b"}) == '{"a": "b"}'
    assert _ExtendedEncoder().encode(UUID("{00000000-0000-0000-0000-000000000001}")) == '"00000000-0000-0000-0000-000000000001"'

# Generated at 2022-06-11 20:55:52.406078
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode(["a"]) == '["a"]'
    assert _ExtendedEncoder().encode("a") == '"a"'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'

_EXTENDED_ENCODER = _ExtendedEncoder()



# Generated at 2022-06-11 20:56:02.340433
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(dict(a=1, b=2, c=3)) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode(set(["1", "2", "3"])) == '["1", "2", "3"]'
    assert _ExtendedEncoder().encode((1, 2, 3)) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(frozenset(["1", "2", "3"])) == '["1", "2", "3"]'

# Generated at 2022-06-11 20:56:37.386113
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(['a', 'b', 'c']) == '["a", "b", "c"]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(set([1, 2, 3])) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(Decimal('3.14')) == '"3.14"'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'



# Generated at 2022-06-11 20:56:39.954518
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEncoder().encode({'1': 1, '2': 2}) == '{"1": 1, "2": 2}'
    assert _ExtendedEncoder().encode({1, 2}) == '[1, 2]'



# Generated at 2022-06-11 20:56:45.837124
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert(encoder.default(tuple()) == list())
    assert(encoder.default(set()) == list())
    assert(encoder.default(frozenset()) == list())
    assert(encoder.default({1: 2}) == {1: 2})
    assert(encoder.default({1, 2}) == list([1, 2]))
    assert(encoder.default(frozenset({1, 2})) == list([1, 2]))
    assert(encoder.default([1, 2]) == [1, 2])
    assert(encoder.default('abc') == 'abc')
    assert(encoder.default(123) == 123)
    assert(encoder.default(123.0) == 123.0)

# Generated at 2022-06-11 20:56:55.132237
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import datetime, timezone
    from uuid import UUID
    from enum import Enum
    from decimal import Decimal
    import json

    class Timezone(Enum):
        utc = 'utc'

    class A:
        def __init__(self, value):
            self.value = value
        def to_json_encodeable(self):
            return {'type': 'A', 'value': self.value}
        def __repr__(self):
            return f'<{self.__class__.__name__}>'
        __str__ = __repr__

    # collections.abc.Collection is currently not present in Python 3.6.

# Generated at 2022-06-11 20:57:06.638660
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    mock_encoder = _ExtendedEncoder()
    # core test
    assert isinstance(mock_encoder.default([]), list)
    assert isinstance(mock_encoder.default({}), dict)
    assert isinstance(mock_encoder.default(datetime.now()), float)
    assert isinstance(mock_encoder.default(UUID("22b80f9d-d5c5-4393-90ea-5a5d3e5b5279")), str)
    assert isinstance(mock_encoder.default(Decimal("1.01")), str)

    class MockEnum(Enum):
        field1 = 1
        field2 = 2
    mock_enum = MockEnum("field1")

# Generated at 2022-06-11 20:57:14.395711
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    sorted_by_type = sorted([UUID, Enum, Decimal], key=lambda t: str(t))

    for t in sorted_by_type + [list, dict, str, int, float, bool]:
        assert _ExtendedEncoder().encode(t()) == json.dumps(t())

    for t in sorted_by_type:
        assert _ExtendedEncoder().encode(t()) == json.dumps(t().value)

    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == json.dumps(datetime.now(timezone.utc).timestamp())



# Generated at 2022-06-11 20:57:24.755382
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    data = [
        1, 2, [1, 2], {'a': 1},
        datetime(2020, 2, 12, tzinfo=timezone.utc),
        UUID('d2f76602-3a1e-413f-b6f2-b3db3f5aacb5'),
        Enum('X', 'x'),
        Decimal('1.01')
    ]
    expected = [
        1, 2, [1, 2], {'a': 1},
        1581498000.0,
        'd2f76602-3a1e-413f-b6f2-b3db3f5aacb5',
        'x',
        '1.01'
    ]

# Generated at 2022-06-11 20:57:34.971752
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.fromtimestamp(1591338206)) == '"2020-06-02T17:10:06.000000"', \
        'Tests encoder for datetime'
    assert _ExtendedEncoder().encode(
        set((1, 2, 3))) == '[1, 2, 3]', 'Tests encoder for set'
    assert _ExtendedEncoder().encode({'x': 1, 'y': 2, 'z': 3}) == '{"x": 1, "y": 2, "z": 3}', \
        'Tests encoder for dict'

# Generated at 2022-06-11 20:57:39.180617
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    for i in [{1:2},[1,2],datetime.now(timezone.utc),datetime.now(),UUID('12345678123456781234567812345678'),Decimal(1)]:
        encoder.default(i)


# Generated at 2022-06-11 20:57:49.069214
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps({'foo': [1, 2, 3]}, cls=_ExtendedEncoder) == '{"foo": [1, 2, 3]}'
    assert json.dumps({'foo': {'bar': 1}}, cls=_ExtendedEncoder) == '{"foo": {"bar": 1}}'
    assert json.dumps(
        {'foo': datetime(year=2018, month=11, day=12, tzinfo=timezone.utc)}, cls=_ExtendedEncoder
    ) == '{"foo": 1542045600.0}'
    assert json.dumps(
        {'foo': UUID('2f47aafe-c0cb-4179-bb04-6a3e3b9d9a60')}, cls=_ExtendedEncoder
    )

# Generated at 2022-06-11 20:58:16.137945
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(UUID("d0db7f0e-9f3a-4d15-9f7f-c5c5b0d0c286")) == '"d0db7f0e-9f3a-4d15-9f7f-c5c5b0d0c286"'
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEncoder().encode({1, 2}) == '[1, 2]'
    assert _ExtendedEncoder().encode({1: 2, 3: 4}) == '{"1": 2, "3": 4}'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '0'

# Generated at 2022-06-11 20:58:23.786257
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = 1
    assert _ExtendedEncoder().default(o) == o
    o = 1.2
    assert _ExtendedEncoder().default(o) == o
    o = "str"
    assert _ExtendedEncoder().default(o) == o
    o = True
    assert _ExtendedEncoder().default(o) == o
    o = None
    assert _ExtendedEncoder().default(o) == o
    o = {"key": "value"}
    assert _ExtendedEncoder().default(o) == o
    o = [1, 2, 3, 4]
    assert _ExtendedEncoder().default(o) == o
    o = (1, 2, 3)
    assert _ExtendedEncoder().default(o) == list(o)
    o = set(o)
    assert _Extended

# Generated at 2022-06-11 20:58:34.099238
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _Encoder = _ExtendedEncoder()
    assert _Encoder.encode(set()) == ''
    assert _Encoder.encode(frozenset()) == ''
    assert _Encoder.encode(tuple([1, 2, 3])) == '[1, 2, 3]'
    assert _Encoder.encode(set([1, 2, 3])) == ''
    assert _Encoder.encode(frozenset([1, 2, 3])) == ''
    assert _Encoder.encode(dict({'a': 1, 'b': 2})) == '{"a": 1, "b": 2}'
    assert _Encoder.encode(dict(a=1, b=2)) == '{"a": 1, "b": 2}'


# Generated at 2022-06-11 20:58:40.504062
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps([datetime(2000, 1, 1)], cls=_ExtendedEncoder) == '[946684800.0]'
    assert json.dumps([datetime(2000, 1, 1, 1, 1, 1)], cls=_ExtendedEncoder) == '[946688461.0]'
    assert json.dumps([datetime(2000, 1, 1, 1, 1, 1, 1)], cls=_ExtendedEncoder) == '[946688461.000002]'
    assert json.dumps([datetime(2000, 1, 1, 1, 1, 1, 1, tzinfo=timezone.utc)], cls=_ExtendedEncoder) == '[946688461.000002]'



# Generated at 2022-06-11 20:58:42.841157
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ext = _ExtendedEncoder()
    assert ext.default(datetime(2020, 1, 1)) == 1577876400.0



# Generated at 2022-06-11 20:58:52.689504
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 11, 21, 14, 35, 20, tzinfo=timezone.utc)) == '"1605974520.0"'
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000')) == '"123e4567-e89b-12d3-a456-426655440000"'
    assert _ExtendedEncoder().encode(Enum('A', name='EnumA')) == '"A"'
    assert _ExtendedEncoder().encode(Decimal('1.2')) == '"1.2"'

# Generated at 2022-06-11 20:59:02.053044
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(UUID('f47ac10b-58cc-4372-a567-0e02b2c3d479')) == '"f47ac10b-58cc-4372-a567-0e02b2c3d479"'
    assert _ExtendedEncoder().encode(42) == '42'
    assert _ExtendedEncoder().encode("42") == '"42"'
    assert _ExtendedEncoder().encode(b'42') == '"NDI="'
    assert _ExtendedEncoder().encode(Decimal("42")) == '"42"'


# Generated at 2022-06-11 20:59:08.009573
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj = {'UUID': UUID('f47ac10b-58cc-4372-a567-0e02b2c3d479'),
           'DateTime': datetime(2013, 2, 4, 17, 54, 32, tzinfo=timezone.utc),
           'Enum': ExampleEnum.two,
           'Decimal': Decimal('3.14'),
           }
    print(json.dumps(obj, cls=_ExtendedEncoder))
    #assert False


# Generated at 2022-06-11 20:59:11.815341
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([{1:1}]) == json.dumps([{1:1}])
    assert _ExtendedEncoder(indent=2).encode([{1:1}]) == json.dumps([{1:1}], indent=2)



# Generated at 2022-06-11 20:59:15.595593
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ExtendedEncoder = _ExtendedEncoder()
    ExtendedEncoder.default(['abc'])  # type: ignore
    ExtendedEncoder.default({'abc': 1})  # type: ignore
    ExtendedEncoder.default('abc')  # type: ignore
    ExtendedEncoder.default(123)  # type: ignore



# Generated at 2022-06-11 20:59:47.266974
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoding = [
        (1, 1),
        ([1, 2], [1, 2]),
        ({'foo': 1}, {'foo': 1}),
        (set([1, 2]), [1, 2]),
        (datetime(2018, 12, 30, 9, 30, tzinfo=timezone.utc),
         1546145400),
        (UUID('3a3a3a3a-3a3a-3a3a-3a3a-3a3a3a3a3a3a'),
         '3a3a3a3a-3a3a-3a3a-3a3a-3a3a3a3a3a3a')
    ]

# Generated at 2022-06-11 20:59:56.054632
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # type: () -> None
    assert _ExtendedEncoder().encode(dict(a=1)) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEncoder().encode(str) == '"<class \'str\'>"'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) is None
    assert _ExtendedEncoder().encode(datetime(2020,1,1)) == '1577836800.0'

# Generated at 2022-06-11 20:59:57.608256
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(Decimal('2.0')) == '"2.0"'
    assert _ExtendedEncoder().encode(Decimal('-1.23e-5')) == '"-0.0000123"'


# Generated at 2022-06-11 20:59:58.909583
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert isinstance(_ExtendedEncoder(), json.JSONEncoder)


# Generated at 2022-06-11 21:00:05.238945
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default([]) == []
    assert isinstance(encoder.default(datetime.now()), float)
    assert isinstance(encoder.default(UUID('1cf0e392-4c9b-4f4b-82f4-a5c95a57f8d2')), str)
    assert encoder.default(Enum('TestEnum', {'A': 1})) == 1
    assert encoder.default(Decimal("10")) == "10"


# Generated at 2022-06-11 21:00:12.410974
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')).replace("\"", "") == '12345678-1234-5678-1234-567812345678'



# Generated at 2022-06-11 21:00:14.963353
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(['test', 'test']) == '["test", "test"]'



# Generated at 2022-06-11 21:00:16.952481
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    _isinstance_safe(extended_encoder, json.JSONEncoder)


# Generated at 2022-06-11 21:00:23.218373
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default({"f1":"v1"}) == {'f1':'v1'}
    assert _ExtendedEncoder().default([1,2,3]) == [1,2,3]
    assert _ExtendedEncoder().default(MappingProxyType({"f1":"v1"})) == {'f1':'v1'}
    assert _ExtendedEncoder().default(OrderedDict({"f1":"v1"})) == {'f1':'v1'}
    assert _ExtendedEncoder().default(Counter({'f1':1, 'f2':2})) == {'f1': 1, 'f2': 2}
    assert _ExtendedEncoder().default(set([1,2,3])) == [1,2,3]
    assert _ExtendedEnc

# Generated at 2022-06-11 21:00:25.584875
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(1970, 1, 1, 0, 0, tzinfo=timezone.utc)) == '0.0'



# Generated at 2022-06-11 21:00:55.337567
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with open("src/dataclasses_json/_ExtendedEncoder.py") as f:
        code = f.read()
    code = code[code.find("class _ExtendedEncoder"):code.rfind("# Unit test for constructor of class _ExtendedEncoder")]
    exec(code)
    code = code[code.rfind("# Unit test for constructor of class _ExtendedEncoder"):]
    exec(code)

test__ExtendedEncoder()


# Generated at 2022-06-11 21:01:00.727251
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.utcnow()) == json.dumps(datetime.utcnow(), cls=_ExtendedEncoder)
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == json.dumps(UUID('00000000-0000-0000-0000-000000000000'), cls=_ExtendedEncoder)
    assert _ExtendedEncoder().encode(Decimal('0.1')) == json.dumps(Decimal('0.1'), cls=_ExtendedEncoder)
# TODO: datetime.time, Decimal
# TODO: json.JSONEncoder.default should be used for datetime.date, datetime.time
# TODO: json.JSONEncoder should be used for datetime.date (should be returned by _

# Generated at 2022-06-11 21:01:11.210367
# Unit test for constructor of class _ExtendedEncoder

# Generated at 2022-06-11 21:01:19.689615
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(set([1, 2, 3]), cls=_ExtendedEncoder) == '[1, 2, 3]'
    assert json.dumps(frozenset([1, 2, 3]), cls=_ExtendedEncoder) == '[1, 2, 3]'
    assert json.dumps(tuple([1, 2, 3]), cls=_ExtendedEncoder) == '[1, 2, 3]'
    assert json.dumps(datetime(2012, 10, 5, 1, 54, 4, 880343, tzinfo=timezone.utc), cls=_ExtendedEncoder) == '1349450044.880343'

# Generated at 2022-06-11 21:01:25.522113
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(0) == "0"
    assert _ExtendedEncoder().encode([]) == "[]"
    assert _ExtendedEncoder().encode(()) == '[]'
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode(True) == "true"


# Generated at 2022-06-11 21:01:32.484289
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(range(1, 4)) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert encoder.default(
        datetime(2020, 7, 1, 12, 0, 0, tzinfo=timezone.utc)) == 1593573600.0
    assert encoder.default(UUID('12341234-1234-1234-1234-123412341234')) == '12341234-1234-1234-1234-123412341234'



# Generated at 2022-06-11 21:01:40.970679
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.default('') == ''
    assert extended_encoder.default(set()) == list(set())
    assert extended_encoder.default(dict()) == dict()
    assert extended_encoder.default(datetime(2020, 9, 3, 15, 22, 51, 189000)) == 1599187771.189
    assert extended_encoder.default(UUID('8f897513-3c17-445e-b27b-4c98e4f58217')) == '8f897513-3c17-445e-b27b-4c98e4f58217'
    assert extended_encoder.default(Enum('TestEnum', 'A')) == 'A'

# Generated at 2022-06-11 21:01:49.392983
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict(foo=1)) == '{"foo": 1}'
    assert _ExtendedEncoder().encode(set([1, 2, 3])) == '[1, 2, 3]'
    now = datetime.utcnow()
    assert _ExtendedEncoder().encode(now) == str(now.timestamp())
    uuid1 = UUID('3fa85f64-5717-4562-b3fc-2c963f66afa6')
    assert _ExtendedEncoder().encode(uuid1) == '"3fa85f64-5717-4562-b3fc-2c963f66afa6"'
    assert _ExtendedEncoder().encode(Decimal(2.5)) == '"2.5"'



# Generated at 2022-06-11 21:01:58.460415
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(list((1,2,3))) == [1,2,3]
    assert _ExtendedEncoder().default(dict(((1,2),(3,4)))) == {1:2,3:4}
    assert _ExtendedEncoder().default(datetime(2020,1,1,0,0,0,tzinfo=timezone.utc)) == 1577808000.0
    assert _ExtendedEncoder().default(UUID('67381946-b1a3-3aac-ac6b-9f5b5a5b5a5a')) == '67381946-b1a3-3aac-ac6b-9f5b5a5b5a5a'
    assert _ExtendedEncoder().default(Decimal('1.1'))

# Generated at 2022-06-11 21:02:06.042551
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    def _get_encoder(
        to_encode: Any,
        expected_type: Any,
        expected_value_in_json: Json,
        expected_value_in_object: Any
    ) -> None:
        json_string = json.dumps(to_encode, cls=_ExtendedEncoder)
        assert json_string == json.dumps(expected_value_in_json)
        actual_decoded_value = json.loads(json_string, object_hook=as_dataclass)
        assert isinstance(actual_decoded_value, expected_type)
        assert actual_decoded_value == expected_value_in_object

    container_types = [
        list,
        dict,
        set,
        tuple,
        frozenset
    ]

# Generated at 2022-06-11 21:03:25.912374
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder().encode({
        'int': 1,
        'float': 1.2,
        'str': "foo",
        'list': [1, 2],
        'dict': {'foo': 1},
        'datetime': datetime(2012, 12, 21, 12, 12, 12, tzinfo=timezone.utc),
        'UUID': UUID('123e4567-e89b-12d3-a456-426655440000'),
        'Enum': IntEnum.one,
    })

# Generated at 2022-06-11 21:03:28.086058
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now()) != None


# Generated at 2022-06-11 21:03:30.234551
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # noinspection PyUnusedLocal
    encoder = _ExtendedEncoder()


# noinspection PyProtectedMember

# Generated at 2022-06-11 21:03:32.223627
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert str(datetime.utcnow()) == enc.default(datetime.utcnow())



# Generated at 2022-06-11 21:03:37.839366
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict(a=1)) == '{"a": 1}'
    assert _ExtendedEncoder().encode(list(range(5))) == '[0, 1, 2, 3, 4]'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '{}'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'
    assert _ExtendedEncoder().encode(Decimal('3.141592653589793')) == '"3.141592653589793"'


# Generated at 2022-06-11 21:03:47.067943
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended = _ExtendedEncoder()
    assert extended.default(UUID('11e6c2a2-7a6b-4c1e-bcac-0e2f7e0e44b1')) == '11e6c2a2-7a6b-4c1e-bcac-0e2f7e0e44b1'
    assert extended.default({'a': 1}) == {'a': 1}
    assert extended.default([1, 2, 3]) == [1, 2, 3]
    assert extended.default(datetime(1970, 1, 1)) == 0.0
    assert extended.default(Decimal('1.23')) == '1.23'


# Generated at 2022-06-11 21:03:56.682740
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # fmt: off
    assert _ExtendedEncoder().encode(object()) ==  json.JSONEncoder.default(_ExtendedEncoder(), object())
    assert _ExtendedEncoder().encode(MappingProxyType({})) == json.JSONEncoder.default(_ExtendedEncoder(), MappingProxyType({}))
    assert _ExtendedEncoder().encode([]) == json.JSONEncoder.default(_ExtendedEncoder(), [])
    assert _ExtendedEncoder().encode('') == json.JSONEncoder.default(_ExtendedEncoder(), '')
    assert _ExtendedEncoder().encode({}) == json.JSONEncoder.default(_ExtendedEncoder(), {})
    assert _ExtendedEncoder().encode(1.0) == json.JSONEncoder.default(_ExtendedEncoder(), 1.0)


# Generated at 2022-06-11 21:04:07.582473
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": {"b": 1}}) == '{"a": {"b": 1}}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"a": set([1, 2, 3])}) == '{"a": [1, 2, 3]}'
    assert _ExtendedEncoder().encode(
        datetime(2019, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == '1546300800.0'

# Generated at 2022-06-11 21:04:12.464797
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(UUID("12345678-1234-5678-1234-567812345678")) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(datetime(2000, 1, 2, 3, 4, 5, tzinfo=timezone.utc)) == '"2000-01-02T03:04:05+00:00"'


# Generated at 2022-06-11 21:04:14.161578
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert json.loads(_ExtendedEncoder().encode(Enum('Enum', ('YES', 'NO')))) == 'YES'

