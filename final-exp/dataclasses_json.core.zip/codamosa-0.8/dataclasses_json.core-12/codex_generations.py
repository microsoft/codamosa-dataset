

# Generated at 2022-06-11 20:54:49.657019
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    assert e.default([1, 2]) == [1, 2]
    assert e.default({'1': 'two', '3': 'four'}) == {'1': 'two', '3': 'four'}
    d = datetime.now()
    assert e.default(d) == d.timestamp()
    u = UUID('{12345678-1234-5678-1234-567812345678}')
    assert e.default(u) == '12345678123456781234567812345678'
    class TestEnum(Enum):
        first = 1
        second = 2
    assert e.default(TestEnum.first) == 1
    from decimal import Decimal

# Generated at 2022-06-11 20:55:00.748246
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(TEST_DATETIME) == TEST_DATETIME.timestamp()
    assert encoder.default(TEST_UUID) == str(TEST_UUID)
    assert encoder.default(TEST_SET) == list(TEST_SET)
    assert encoder.default(TEST_SET_TYPING) == list(TEST_SET_TYPING)
    assert encoder.default(TEST_DICT) == dict(TEST_DICT)
    assert encoder.default(TEST_DICT_TYPING) == dict(TEST_DICT_TYPING)
    assert encoder.default(TEST_ENUM) == TEST_ENUM.value

# Generated at 2022-06-11 20:55:02.140251
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'



# Generated at 2022-06-11 20:55:03.403498
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps(cfg.encoder, cls=_ExtendedEncoder)


# Generated at 2022-06-11 20:55:05.161481
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now()) == 0


# Generated at 2022-06-11 20:55:16.172702
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert enc.default(None) == None
    assert enc.default(True) == True
    assert enc.default(False) == False
    assert enc.default(0) == 0
    assert enc.default(1) == 1
    assert enc.default(2) == 2
    assert enc.default(1.5) == 1.5
    assert enc.default("") == ""
    assert enc.default("test") == "test"
    assert enc.default(list()) == list()
    assert enc.default([1, 2]) == [1, 2]
    assert enc.default(dict()) == dict()
    assert enc.default({1:2}) == {1:2}

# Generated at 2022-06-11 20:55:19.482765
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    d = datetime.now(timezone.utc)
    assert {'t': str(d)} == json.loads(json.dumps({'t': d}, cls=_ExtendedEncoder))


################################################################################



# Generated at 2022-06-11 20:55:25.026132
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    decimals = [Decimal(x) for x in range(10)]

    assert _ExtendedEncoder().encode(decimals) == '[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]'
    assert json.loads(_ExtendedEncoder().encode(decimals)) == [str(x) for x in range(10)]


# Generated at 2022-06-11 20:55:27.454823
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict(a=1)) == json.dumps(dict(a=1))



# Generated at 2022-06-11 20:55:34.283243
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import datetime
    from uuid import UUID
    from math import inf
    from enum import Enum
    from decimal import Decimal

    class Test(Enum):
        value = 1

    # noinspection PyTypeChecker
    def test(a: Any, b: Json):
        assert _ExtendedEncoder().encode(a) == json.dumps(b)

    test([1, 2, 3], [1, 2, 3])
    test({"a": 1}, {"a": 1})
    test(datetime(1970, 1, 1, tzinfo=timezone.utc), 0.0)
    test(UUID('00000000-0000-0000-0000-000000000000'), '00000000-0000-0000-0000-000000000000')
    test(Test.value, 1)

# Generated at 2022-06-11 20:55:54.670431
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'



# Generated at 2022-06-11 20:55:57.067565
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'



# Generated at 2022-06-11 20:56:06.501838
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    timestamps = datetime.now().timestamp()
    uuid = UUID('{12345678-1234-5678-1234-567812345678}')
    enum = Enum("test_enum", {"four": 4, "five": 5})
    decimal = Decimal("12.0")

    assert _ExtendedEncoder().default(timestamps) == timestamps
    assert _ExtendedEncoder().default(uuid) == str(uuid)
    assert _ExtendedEncoder().default(enum) == enum.value
    assert _ExtendedEncoder().default(decimal) == "12.0"



# Generated at 2022-06-11 20:56:13.257428
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1,2,3]) == "[1, 2, 3]"
    assert _ExtendedEncoder().encode((1,2,3)) == "[1, 2, 3]"
    assert _ExtendedEncoder().encode({1:2, 2:3, 3:4}) == '{"1": 2, "2": 3, "3": 4}'
    assert _ExtendedEncoder().encode({"1":2, "2":3, "3":4}) == '{"1": 2, "2": 3, "3": 4}'
    assert _ExtendedEncoder().encode(datetime.fromtimestamp(0.00000001, timezone.utc)) == \
        '"0.00000001"'

# Generated at 2022-06-11 20:56:23.538325
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    uut = _ExtendedEncoder()
    assert uut.default(set()) == list(set())
    assert uut.default(tuple()) == list(tuple())
    assert uut.default(dict()) == dict()
    assert uut.default(frozenset()) == list(frozenset())
    assert uut.default(UUID('0e0674d9-e5ca-4ca2-b567-ec0cdd1ffe2a')) == '0e0674d9-e5ca-4ca2-b567-ec0cdd1ffe2a'
    assert uut.default(datetime(2000, 1, 1)) == datetime(2000, 1, 1).timestamp()
    assert uut.default(Decimal('12.6')) == '12.6'


# Generated at 2022-06-11 20:56:29.447970
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == "{}"
    assert _ExtendedEncoder().encode(defaultdict(int)) == "{}"
    assert _ExtendedEncoder().encode(set()) == "[]"
    assert _ExtendedEncoder().encode(frozenset()) == "[]"
    assert _ExtendedEncoder().encode(datetime(2020, 2, 3, 4, 5, 6)) == "1586041906.0"
    assert _ExtendedEncoder().encode(datetime(2020, 2, 3, 4, 5, 6, 789, tzinfo=timezone.utc)) == "1586041906.789"

# Generated at 2022-06-11 20:56:38.105850
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None
    assert encoder.default([]) == []
    assert encoder.default({}) == {}
    assert encoder.default('hello') == 'hello'
    assert encoder.default(123) == 123
    assert encoder.default(datetime.now(timezone.utc)) == \
        datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('8b89d6b2-7b9e-11e9-8f9e-2a86e4085a59')) == \
        '8b89d6b2-7b9e-11e9-8f9e-2a86e4085a59'

# Generated at 2022-06-11 20:56:44.954979
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder().encode(datetime.now(tz=timezone.utc))
    assert isinstance(result, str)
    result = _ExtendedEncoder().encode(UUID('cfd611d7-1327-4dd1-a2c8-b35de6f1cd6e'))
    assert isinstance(result, str)
    assert result == '"cfd611d7-1327-4dd1-a2c8-b35de6f1cd6e"'
    result = _ExtendedEncoder().encode(Decimal('1.0'))
    assert isinstance(result, str)
    assert result == '"1.0"'
    result = _ExtendedEncoder().encode({'a': 1})
    assert isinstance(result, str)
   

# Generated at 2022-06-11 20:56:51.229575
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([datetime(2018, 8, 8, 0, 0, 0, 0, tzinfo=timezone.utc),
                                      datetime(2018, 8, 8, 0, 0, 0, 0, tzinfo=timezone.utc)]) == "[1533657600.0, 1533657600.0]"



# Generated at 2022-06-11 20:56:59.951441
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(set()) == list(set())
    assert _ExtendedEncoder().default(tuple()) == list(tuple())
    assert _ExtendedEncoder().default(frozenset()) == list(frozenset())
    assert _ExtendedEncoder().default(dict()) == dict()
    assert _ExtendedEncoder().default(UUID('810848ab-9b9c-4aeb-9b8f-06cc733f3087')) == '810848ab-9b9c-4aeb-9b8f-06cc733f3087'



# Generated at 2022-06-11 20:57:50.172024
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = {'a': 1}
    assert _ExtendedEncoder().default(o) == o
    o = (1, 2, 3)
    assert _ExtendedEncoder().default(o) == list(o)
    o = set(o)
    assert _ExtendedEncoder().default(o) == list(o)
    o = datetime(2019, 12, 12, 12, 12, 12, 12, tzinfo=timezone.utc)
    assert _ExtendedEncoder().default(o) == o.timestamp()
    o = UUID(int=0)
    assert _ExtendedEncoder().default(o) == str(o)
    o = Decimal(1)
    assert _ExtendedEncoder().default(o) == str(o)

# Generated at 2022-06-11 20:58:01.451875
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode([1, [2, 3], []]) == '[1, [2, 3], []]'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode('') == '""'
    assert _ExtendedEncoder().encode('a') == '"a"'
    assert _ExtendedEncoder().encode(b'a') == '"a"'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(False) == 'false'
    assert _

# Generated at 2022-06-11 20:58:12.057655
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default({'a': [1, 2, 3]}) == {'a': [1, 2, 3]}
    assert encoder.default(datetime(2020, 5, 21, 11, 22, 33,
                                    tzinfo=timezone.utc)) \
        == datetime(2020, 5, 21, 11, 22, 33, tzinfo=timezone.utc).timestamp()

# Generated at 2022-06-11 20:58:21.390311
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import unittest


# Generated at 2022-06-11 20:58:22.163272
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder()


# Generated at 2022-06-11 20:58:33.245773
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode('') == '""'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.1) == '1.1'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(datetime.now()) == '{}'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000001')) == '"00000000-0000-0000-0000-000000000001"'
    assert _ExtendedEncoder

# Generated at 2022-06-11 20:58:40.149901
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(dict(a=1, b=2)) == dict(a=1, b=2)
    assert _ExtendedEncoder().default(set(['a'])) == ['a']
    assert _ExtendedEncoder().default(list([1, 2])) == [1, 2]
    assert _ExtendedEncoder().default(dict(a=1, b=2)) == dict(a=1, b=2)
    d = datetime.now()
    assert _ExtendedEncoder().default(d) == d.timestamp()
    try:
        import uuid
        u = uuid.uuid4()
        assert _ExtendedEncoder().default(u) == str(u)
    except Exception:
        pass

# Generated at 2022-06-11 20:58:50.715911
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert e.default([1,2,3]) == [1,2,3]
    assert e.default({'a':'b'}) == {'a':'b'}
    assert e.default(None) is None
    assert e.default(42) == 42
    assert e.default(set()) == []
    assert e.default(0) == 0
    assert e.default(False) == False
    assert e.default(True) == True
    assert e.default(datetime.utcnow()) == datetime.utcnow().timestamp()

# Generated at 2022-06-11 20:59:01.459787
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings(record=True) as context:
        assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
        assert _ExtendedEncoder().encode(UUID('c6a8f7c0-6a1d-4573-9df8-6e5c5d1a5ff5'))
        assert _ExtendedEncoder().encode(Enum('Status', ('SUCCESS', 'FAILURE')))
        assert _ExtendedEncoder().encode(Decimal('0.1'))
        assert _ExtendedEncoder().encode(set())
        assert _ExtendedEncoder().encode(frozenset())
        assert len(context) == 3


# Generated at 2022-06-11 20:59:10.982257
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert e.default(None) is None
    assert e.default(True) is True
    assert e.default(False) is False
    assert e.default(0) == 0
    assert e.default(0.0) == 0.0
    assert e.default(1) == 1
    assert e.default('a') == 'a'
    assert e.default(0.2) == 0.2
    assert e.default([]) == []
    assert e.default(()) == []
    assert e.default({}) == {}
    assert e.default(set()) == []
    assert e.default(range(3)) == [0, 1, 2]
    assert e.default({'key': 'value'}) == {'key': 'value'}

# Generated at 2022-06-11 21:00:00.043901
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert isinstance(_ExtendedEncoder(), json.JSONEncoder)


# Generated at 2022-06-11 21:00:12.758015
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.JSONEncoder().encode(123) == '123'
    assert _ExtendedEncoder().encode({'a': 123}) == '{"a": 123}'
    assert _ExtendedEncoder().encode((1, 2, 3)) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': [1, 2, 3]}) == '{"a": [1, 2, 3]}'
    assert _ExtendedEncoder().encode(UUID('aab6f0d7-b8fe-4e95-9f14-0d7e43f53cfa')) == '"aab6f0d7-b8fe-4e95-9f14-0d7e43f53cfa"'

# Generated at 2022-06-11 21:00:21.583398
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder(indent=4)
    assert e.default(None) == None
    assert e.default(True) is True
    assert e.default(False) is False
    assert e.default(1) == 1
    assert e.default('abc') == 'abc'
    assert e.default(1.23) == 1.23
    assert e.default(set([1, 2])) == [1, 2]
    assert e.default((1, 2)) == [1, 2]
    assert e.default([1, 2]) == [1, 2]
    assert e.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert e.default(datetime(2020, 2, 29, 12, 0, 0, 0, timezone.utc))

# Generated at 2022-06-11 21:00:29.722363
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(Decimal('1.1')) == '1.1'
    assert encoder.default(UUID('a1a1a1a1-a1a1-a1a1-a1a1-a1a1a1a1a1a1')) == 'a1a1a1a1-a1a1-a1a1-a1a1-a1a1a1a1a1a1'
    assert encoder.default(datetime.now(timezone.utc)) == 1597978962
    assert encoder.default(Decimal('inf')) == 'Infinity'
    assert encoder.default(Decimal('-inf')) == '-Infinity'
    assert encoder.default(Decimal('nan'))

# Generated at 2022-06-11 21:00:31.931378
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """Test for constructor of class _ExtendedEncoder"""
    try:
        assert _ExtendedEncoder()
    except Exception:
        assert False


# Generated at 2022-06-11 21:00:36.057268
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.encode(Decimal('10.1')) == '"10.1"'

_current_instance = [None]


# Generated at 2022-06-11 21:00:43.673184
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    obj = {'foo':'bar', 'blah':123}
    assert encoder.default(obj) == obj
    obj = [1,2,3]
    assert encoder.default(obj) == obj
    obj = "foo"
    assert encoder.default(obj) == obj
    obj = 123
    assert encoder.default(obj) == obj
    obj = True
    assert encoder.default(obj) == obj
    obj = None
    assert encoder.default(obj) == obj
    obj = Enum('TestEnum', {'foo':'bar'})
    assert encoder.default(obj) == 'bar'

# Generated at 2022-06-11 21:00:45.446342
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(Decimal('1.2')) == '1.2'



# Generated at 2022-06-11 21:00:55.297812
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps(0, cls=_ExtendedEncoder)
    json.dumps("", cls=_ExtendedEncoder)
    json.dumps(True, cls=_ExtendedEncoder)
    json.dumps(False, cls=_ExtendedEncoder)
    json.dumps(None, cls=_ExtendedEncoder)
    json.dumps({}, cls=_ExtendedEncoder)
    json.dumps([], cls=_ExtendedEncoder)
    json.dumps({0: 1}, cls=_ExtendedEncoder)
    json.dumps([0, 1], cls=_ExtendedEncoder)
    json.dumps(set(), cls=_ExtendedEncoder)

# Generated at 2022-06-11 21:01:01.986505
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps({'x': [1, 2, 3]}, cls=_ExtendedEncoder) == '{"x": [1, 2, 3]}'  # type: ignore
    assert json.dumps({'x': [1, 2, {'y': 3}]}, cls=_ExtendedEncoder) == '{"x": [1, 2, {"y": 3}]}'  # type: ignore
    assert json.dumps([1, 2, 3], cls=_ExtendedEncoder) == '[1, 2, 3]'  # type: ignore



# Generated at 2022-06-11 21:03:07.900019
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder().default(MappingProxyType({'foo': 'bar'}))
    assert isinstance(result, dict)
    assert result == {'foo': 'bar'}
    result = _ExtendedEncoder().default(ChainMap())
    assert isinstance(result, dict)
    assert result == {}
    result = _ExtendedEncoder().default(datetime(2018, 1, 1, tzinfo=timezone.utc))
    assert isinstance(result, int)
    assert result == 1514764800
    result = _ExtendedEncoder().default(UUID('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11'))
    assert isinstance(result, str)

# Generated at 2022-06-11 21:03:17.970850
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    my_list = [{'key': 'value'}, 'value', []]
    my_set = {'key'}
    my_frozenset = frozenset({'key'})
    my_dict = {'key': 'value'}
    my_datetime = datetime.now(timezone.utc)
    my_uuid = UUID('{12345678-1234-5678-1234-567812345678}')
    my_enum = cfg.type_filter
    my_decimal = Decimal('100.25')

    encoder = _ExtendedEncoder()
    res_list = encoder.default(my_list)
    res_set = encoder.default(my_set)
    res_frozenset = encoder.default(my_frozenset)


# Generated at 2022-06-11 21:03:26.424343
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.loads(json.dumps(Enum('SimpleEnum', 'foo bar'), cls=_ExtendedEncoder))
    json.loads(json.dumps([1, 2], cls=_ExtendedEncoder))
    json.loads(json.dumps({'foo': 'bar'}, cls=_ExtendedEncoder))
    json.loads(json.dumps(datetime.now(timezone.utc), cls=_ExtendedEncoder))
    json.loads(json.dumps(UUID('00112233-4455-6677-8899-aabbccddeeff'), cls=_ExtendedEncoder))
    json.loads(json.dumps(Decimal(1.0), cls=_ExtendedEncoder))



# Generated at 2022-06-11 21:03:36.092710
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert type(_ExtendedEncoder.default(None, '')) is str
    assert type(_ExtendedEncoder.default(None, None)) is None
    assert type(_ExtendedEncoder.default(None, b'')) is str
    assert type(_ExtendedEncoder.default(None, 45)) is int
    assert type(_ExtendedEncoder.default(None, 45.99)) is float
    assert type(_ExtendedEncoder.default(None, False)) is bool
    assert type(_ExtendedEncoder.default(None, {'a': 'b', 'c': 'd'})) is dict
    assert type(_ExtendedEncoder.default(None, ['a', 'b'])) is list
    assert type(_ExtendedEncoder.default(None, (('a', 'b'), ('c', 'd')))) is dict

# Generated at 2022-06-11 21:03:39.169805
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_ = _ExtendedEncoder()
    assert isinstance(extended_encoder_, json.JSONEncoder)

# noinspection PyProtectedMember

# Generated at 2022-06-11 21:03:48.447589
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    se = _ExtendedEncoder()
    assert se.default(object()) == repr(object())
    assert se.default('hello') == 'hello'
    assert se.default(123) == 123
    assert se.default(0.1234) == 0.1234
    assert se.default(True) == True
    assert se.default(False) == False
    assert se.default(None) == None
    assert se.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert se.default(UUID('b0dec75a-a89e-4b45-a0c8-ad56d1687b87')) == 'b0dec75a-a89e-4b45-a0c8-ad56d1687b87'
   

# Generated at 2022-06-11 21:03:51.162211
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    a = _ExtendedEncoder()
    b = a.encode({"a": 1})
    json.loads(b)


# Generated at 2022-06-11 21:03:58.147114
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(UUID('d4b4e4e4-36d4-4ed4-9a9a-9a9a9ad4d4d4')) == '"d4b4e4e4-36d4-4ed4-9a9a-9a9a9ad4d4d4"'
    assert _ExtendedEncoder().encode([1, 2, 3, 4]) == '[1, 2, 3, 4]'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(datetime(2019, 7, 17, 23, 4, 0)) == '1563354240.0'

# Generated at 2022-06-11 21:04:08.815241
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"abc": "abc"}) == '{"abc": "abc"}'
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEncoder().encode("str") == '"str"'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.2) == '1.2'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '1538127740.0'

# Generated at 2022-06-11 21:04:16.961381
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.loads(json.dumps({"a": [1, 2, 3]}, cls=_ExtendedEncoder)) == {"a": [1, 2, 3]}
    assert json.loads(json.dumps({"a": {"b": 123}}, cls=_ExtendedEncoder)) == {"a": {"b": 123}}
    assert json.loads(json.dumps({"a": datetime(2019, 9, 27, tzinfo=timezone.utc)}, cls=_ExtendedEncoder)) == {"a": 1569596800.0}