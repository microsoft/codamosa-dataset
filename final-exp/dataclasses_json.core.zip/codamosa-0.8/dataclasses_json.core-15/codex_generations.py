

# Generated at 2022-06-11 20:54:48.192056
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    o = object()
    result = encoder.default(o)
    assert result == o
    o = [1, 2, 3]
    result = encoder.default(o)
    assert result == o
    o = {'a': 3}
    result = encoder.default(o)
    assert result == o
    o = {'a': 'b'}
    result = encoder.default(o)
    assert result == o
    o = datetime(2000, 1, 2)
    result = encoder.default(o)
    assert result == 949395200.0
    o = UUID('067e6162-3b6f-4ae2-a171-2470b63dff00')
    result = encoder.default(o)

# Generated at 2022-06-11 20:55:00.067156
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert json.dumps(None, cls=_ExtendedEncoder) == 'null'
    assert json.dumps(True, cls=_ExtendedEncoder) == 'true'
    assert json.dumps(False, cls=_ExtendedEncoder) == 'false'
    assert json.dumps(10, cls=_ExtendedEncoder) == '10'
    assert json.dumps(5.5, cls=_ExtendedEncoder) == '5.5'
    assert json.dumps('abc', cls=_ExtendedEncoder) == '"abc"'
    assert json.dumps(['a', 'b', 'c'], cls=_ExtendedEncoder) == '["a", "b", "c"]'

# Generated at 2022-06-11 20:55:07.476947
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode('a') == '"a"'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    # TODO: Why comparing the string version of a datetime object is not
    # correct?
    dt = datetime.now()
    # assert _ExtendedEncoder().encode(
    #     dt) == '"%s"' % dt.strftime(

# Generated at 2022-06-11 20:55:17.457255
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    # from collections
    assert encoder.default(list(range(3))) == list(range(3))
    assert encoder.default(tuple(range(3))) == list(range(3))
    assert encoder.default(set(range(3))) == list(range(3))
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # from datetime
    assert encoder.default(datetime.utcnow()) == datetime.utcnow().timestamp()
    assert encoder.default(datetime(1969, 1, 1, tzinfo=timezone.utc)) == 0.0
    # from uuid

# Generated at 2022-06-11 20:55:27.957547
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3, 4, 5]) == "[1, 2, 3, 4, 5]"
    assert _ExtendedEncoder().encode({1: 2, 3: 4, 5: 6}) == "{\"1\": 2, \"3\": 4, \"5\": 6}"
    assert _ExtendedEncoder().encode("abcd") == "\"abcd\""
    assert _ExtendedEncoder().encode(12345) == "12345"
    assert _ExtendedEncoder().encode(12.345) == "12.345"
    assert _ExtendedEncoder().encode(True) == "true"
    assert _ExtendedEncoder().encode(False) == "false"
    assert _ExtendedEncoder().encode(None) == "null"
    assert _ExtendedEnc

# Generated at 2022-06-11 20:55:36.694836
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.loads(json.dumps({'int': 1, 'string': 'string', 'list': [1, 2, 3]}, cls=_ExtendedEncoder)) \
           == {'int': 1, 'string': 'string', 'list': [1, 2, 3]}
    assert json.loads(json.dumps({'datetime': datetime.fromtimestamp(100.0, timezone.utc)}, cls=_ExtendedEncoder)) \
        == {'datetime': 100.0}

# Generated at 2022-06-11 20:55:47.208870
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc)) == 0
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc).date()) == '1970-01-01'
    assert _ExtendedEncoder().default(datetime.now().time()) == datetime.now().time().isoformat()
    assert _ExtendedEncoder().default(UUID('1b3906fb-b6ae-4cf8-a6e4-d5bff6c4e3d7')) == '1b3906fb-b6ae-4cf8-a6e4-d5bff6c4e3d7'
    assert _ExtendedEncoder().default(Enum('A', 'a'))

# Generated at 2022-06-11 20:55:51.364137
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    result = _ExtendedEncoder().default(UUID('12345678123456781234567812345678'))  # type: ignore
    expected = '12345678-1234-5678-1234-567812345678'
    assert result == expected



# Generated at 2022-06-11 20:56:01.242359
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': [1, 2]}) == '{"a": [1, 2]}'
    assert _ExtendedEncoder().encode({'a': {'b': 2}}) == '{"a": {"b": 2}}'
    assert _ExtendedEncoder().encode(
        datetime.utcnow().replace(tzinfo=timezone.utc)
    ) > '0'
    assert _ExtendedEncoder().encode(UUID('bea29a84-f483-4e99-a90e-e77bf470c693')) == (
        '"bea29a84-f483-4e99-a90e-e77bf470c693"'
    )

# Generated at 2022-06-11 20:56:10.025485
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(42) == 42
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(1.5) == 1.5
    assert _ExtendedEncoder().default('foo') == 'foo'
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'foo': 'bar'}) == {'foo': 'bar'}
    assert _ExtendedEncoder().default(None) is None

    input_ = datetime.fromtimestamp(0, timezone.utc)
    output = _ExtendedEncoder().default(input_)
    assert isinstance(output, float) and output == 0.0


# Generated at 2022-06-11 20:56:37.629114
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def assert_EncoderDefault(test: Any, expected: Json):
        o = _ExtendedEncoder().default(test)
        assert o == expected

    #Actions
    assert_EncoderDefault([1, 2, 3], [1, 2, 3])
    assert_EncoderDefault({'1': 1, '2': 2, '3': 3}, {'1': 1, '2': 2, '3': 3})
    assert_EncoderDefault(datetime(2010, 10, 11, 12, 13, 14, tzinfo=timezone.utc),
                          datetime(2010, 10, 11, 12, 13, 14, tzinfo=timezone.utc).timestamp())

# Generated at 2022-06-11 20:56:46.848395
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(list()) == list()
    assert _ExtendedEncoder().default(dict()) == dict()
    assert _ExtendedEncoder().default(set()) == list(set())
    assert _ExtendedEncoder().default(tuple()) == list(tuple())
    assert _ExtendedEncoder().default(frozenset()) == list(frozenset())
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()

# Generated at 2022-06-11 20:56:55.370038
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime(2000, 1, 1, 12, 34, 56, 789)) == 946685466.789
    assert encoder.default(UUID('e7b2c8ec-8b35-46b5-b301-65e0e876d9f9')) == 'e7b2c8ec-8b35-46b5-b301-65e0e876d9f9'
    assert encoder.default(Decimal('1.2')) == '1.2'

# Generated at 2022-06-11 20:56:58.570851
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3, {'4': 5, '6': 7}]) == \
           '[1, 2, 3, {"4": 5, "6": 7}]'



# Generated at 2022-06-11 20:57:05.031831
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    print(json.dumps(datetime.now(timezone.utc), cls=_ExtendedEncoder))
    print(json.dumps(UUID('16fd2706-8baf-433b-82eb-8c7fada847da'), cls=_ExtendedEncoder))
    print(json.dumps(Decimal('123.456789'), cls=_ExtendedEncoder))
    # test_ExtendedEncoder()



# Generated at 2022-06-11 20:57:07.092181
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1: 1}) == '{"1": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == json.JSONEncoder().encode(datetime.now(timezone.utc))


# Generated at 2022-06-11 20:57:16.196857
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import dataclass, fields
    from typing import List, Dict, Tuple
    from uuid import UUID
    import re
    import pytest
    from datetime import datetime

    @dataclass
    class Test:
        dict: dict
        list: List
        tuple: Tuple
        datetime: datetime
        uuid: UUID

    data = {'dict': {'a': 'b'},
            'list': [1, 2, 3],
            'tuple': (1, 2, 3),
            'datetime': datetime.now(timezone.utc),
            'uuid': UUID('0354e6b4-6b98-4b65-b872-079c3a6d3f67')}


# Generated at 2022-06-11 20:57:22.176566
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(UUID('F0C04E11-35B2-4B9A-8848-A54A12E377A8')) == 'f0c04e11-35b2-4b9a-8848-a54a12e377a8'


# Generated at 2022-06-11 20:57:32.441392
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(2019, 5, 12, 21, 29, 28, 0, timezone.utc)) == 1557699368.0
    assert _ExtendedEncoder().default(UUID('25d065fc-e8e6-49ca-bc25-fb04f9ce937b')) == '25d065fc-e8e6-49ca-bc25-fb04f9ce937b'
    assert _ExtendedEncoder().default(Enum('Enum', ('A',))) == 'A'
    assert _ExtendedEncoder().default(Decimal('3.14')) == '3.14'
    assert _ExtendedEncoder().default(Decimal('3.14')) == '3.14'



# Generated at 2022-06-11 20:57:41.792472
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps([1, 2, 3], cls=_ExtendedEncoder) == '''[1, 2, 3]'''
    assert json.dumps({'foo': 'bar'}, cls=_ExtendedEncoder) == '''{"foo": "bar"}'''
    assert json.dumps(decimal.Decimal("3.14"), cls=_ExtendedEncoder) == '''"3.14"'''
    assert json.dumps(datetime.now(), cls=_ExtendedEncoder) is not None
    assert json.dumps(datetime.now(), cls=_ExtendedEncoder) != 'null'
    assert json.dumps(uuid.uuid4(), cls=_ExtendedEncoder) is not None

# Generated at 2022-06-11 20:58:06.665253
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.loads(json.dumps(_ExtendedEncoder().encode({'a': datetime.now()})))

# noinspection PyProtectedMember

# Generated at 2022-06-11 20:58:08.166027
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(1) == "1"



# Generated at 2022-06-11 20:58:09.717823
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    d = {}
    o = object()
    encoder = _ExtendedEncoder()
    assert encoder.default(d) == d
    assert encoder.default(o) == str(o)



# Generated at 2022-06-11 20:58:14.492779
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj = {
        'uuid_': UUID('847c51bd-2f76-4a9d-9b5e-2f2a19cf759c'),
        'date_': datetime.utcfromtimestamp(0),
        'enum': cfg.EnumOptions.Name,
        'decimal_': Decimal('1.1'),
        1: 1
    }
    result = json.dumps(obj, cls=_ExtendedEncoder)
    assert result == '{"decimal_": "1.1", "enum": "Name", "date_": 0, "1": 1, "uuid_": "847c51bd-2f76-4a9d-9b5e-2f2a19cf759c"}'


# Generated at 2022-06-11 20:58:22.979386
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """
    Tests that all class _ExtendedEncoder supported types are properly encoded and decoded.
    """
    new_encoder = _ExtendedEncoder()
    encoder = json.JSONEncoder()

    # Reference: http://book.pythontips.com/en/latest/datetime.html#naive-vs-aware-datetimes
    utc_dt = datetime.fromtimestamp(1, tz=timezone.utc)
    assert new_encoder.default(utc_dt) == encoder.default(utc_dt)

    dt = datetime.fromtimestamp(1)
    assert new_encoder.default(dt) == encoder.default(dt)


# Generated at 2022-06-11 20:58:24.185898
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-11 20:58:34.439272
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert e.default([1, 2, 3]) == [1, 2, 3]
    assert e.default([1, 2, 3]) == [1, 2, 3]
    assert e.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert e.default(['a']) == ['a']
    assert e.default(1) == 1
    assert e.default(1.0) == 1.0
    assert e.default(True) == True
    assert e.default(False) == False
    assert e.default(None) == None
    assert e.default(datetime(2018, 1, 1)) == 1514761200.0

# Generated at 2022-06-11 20:58:41.004093
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder(indent=4)

# Generated at 2022-06-11 20:58:49.441449
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(year=1,
                  month=1,
                  day=1,
                  tzinfo=timezone.utc)) == '0.0'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == \
            '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal('Infinity')) == '"Infinity"'



# Generated at 2022-06-11 20:58:53.441944
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default([])
    _ExtendedEncoder().default({})
    _ExtendedEncoder().default(UUID(int=1))
    _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc))
    _ExtendedEncoder().default(Decimal(1))
    _ExtendedEncoder().default(1)



# Generated at 2022-06-11 20:59:54.473108
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert encoder.default(UUID('0e4b86f4-6bc5-4c48-a438-9a944f8d65ea')) == '0e4b86f4-6bc5-4c48-a438-9a944f8d65ea'
    assert encoder.default(datetime(2020, 1, 1, 7, 0, 0, tzinfo=timezone.utc)) == 1577883600.0
    assert encoder.default(Decimal('0.5')) == '0.5'



# Generated at 2022-06-11 20:59:58.506423
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(1,1,1)) == '-62135596800.0'
    assert _ExtendedEncoder().encode(timezone.utc) == '""'
    assert _ExtendedEncoder().encode(UUID('89D05A34-E983-11E3-A1AB-0800200C9A66')) == '"89d05a34-e983-11e3-a1ab-0800200c9a66"'
    assert _ExtendedEncoder().encode(Decimal('1.234')) == '"1.234"'



# Generated at 2022-06-11 21:00:05.181468
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.encode(1) == "1"
    assert extended_encoder.encode(1.0) == "1.0"
    assert extended_encoder.encode(True) == "true"
    assert extended_encoder.encode(False) == "false"
    assert extended_encoder.encode(None) == "null"
    assert extended_encoder.encode([1, 2, 3, 4]) == "[1, 2, 3, 4]"
    assert extended_encoder.encode(('a', 1)) == '["a", 1]'
    assert extended_encoder.encode({'a': 1}) == '{"a": 1}'

# Generated at 2022-06-11 21:00:07.988294
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_encoded = json.dumps(datetime.now(), cls=_ExtendedEncoder)
    assert json_encoded is not None



# Generated at 2022-06-11 21:00:18.517187
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps(set(), cls=_ExtendedEncoder)
    json.dumps(dict(), cls=_ExtendedEncoder)
    json.dumps(datetime.now(), cls=_ExtendedEncoder)
    json.dumps(UUID(int=0), cls=_ExtendedEncoder)
    json.dumps(Enum, cls=_ExtendedEncoder)
    json.dumps(Decimal, cls=_ExtendedEncoder)
    try:
        json.dumps(object(), cls=_ExtendedEncoder)
        assert False
    except Exception as e:
        assert isinstance(e, TypeError)
    else:
        assert False



# Generated at 2022-06-11 21:00:28.137742
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    # test normal output
    assert encoder.default(1) == 1
    assert encoder.default([1]) == [1]
    assert encoder.default({1: 1}) == {1: 1}
    assert encoder.default(True) == True
    assert encoder.default(None) == None
    assert encoder.default('hi') == 'hi'
    # test custom output
    now = datetime.now(tz=timezone.utc)
    assert encoder.default(now) == now.timestamp()
    uuid = UUID('02c36718-d8a8-11e9-b632-0800200c9a66')
    assert encoder.default(uuid) == str(uuid)



# Generated at 2022-06-11 21:00:39.115288
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ee = _ExtendedEncoder()
    assert json.dumps({"a" : 1, "b" : 2}, cls=ee) == '{"a":1,"b":2}'
    assert json.dumps("abc", cls=ee) == '"abc"'
    assert json.dumps(True, cls=ee) == 'true'
    assert json.dumps(None, cls=ee) == 'null'
    now = datetime.now(timezone.utc)
    assert json.dumps(now, cls=ee) == str(int(now.timestamp()))

# Generated at 2022-06-11 21:00:45.154541
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(False) == 'false'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode('hello') == '"hello"'
    assert _ExtendedEncoder().encode(1.1) == '1.1'
    assert _ExtendedEncoder().encode({'apple': 1.5}) == '{"apple": 1.5}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'apple': 1.5, 'banana': 2}) == '{"apple": 1.5, "banana": 2}'


EncoderFunc = Mapping

# Generated at 2022-06-11 21:00:55.005771
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([object()]) == '["<object object at 0x7f8f14c56ae8>"]'
    assert _ExtendedEncoder().encode([dict(key='value')]) == '{"key":"value"}'
    assert _ExtendedEncoder().encode([set()]) == '[]'
    assert _ExtendedEncoder().encode([dict(a='b'), dict(c='d')]) == '[{"a":"b"},{"c":"d"}]'
    assert _ExtendedEncoder().encode([1, 2, 3, 4, 5]) == '[1,2,3,4,5]'
    assert _ExtendedEncoder().encode([]) == '[]'

# Generated at 2022-06-11 21:01:04.255434
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(list(range(5))) == '[0, 1, 2, 3, 4]'
    assert _ExtendedEncoder().encode(tuple(range(5))) == '[0, 1, 2, 3, 4]'
    assert _ExtendedEncoder().encode(set(range(5))) == '[0, 1, 2, 3, 4]'
    assert _ExtendedEncoder().encode(dict(zip(range(5), range(5)))) \
        == '{"0": 0, "1": 1, "2": 2, "3": 3, "4": 4}'
    assert _ExtendedEncoder().encode(dict(enumerate(range(5)))) \
        == '{"0": 0, "1": 1, "2": 2, "3": 3, "4": 4}'


# Generated at 2022-06-11 21:03:19.027002
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # noinspection PyUnresolvedReferences
    from dataclasses import dataclass
    d = _ExtendedEncoder().default
    assert d(1) == 1
    assert d(3.14) == 3.14
    assert d(42 + 0j) == 42.0
    assert d(True) == True
    assert d(False) == False
    assert d('abc') == 'abc'
    assert d([1, 2]) == [1, 2]
    assert d({1: 'a', 2: 'b'}) == {'1': 'a', '2': 'b'}
    assert d(None) == None
    # TODO: Set
    assert d(set()) == list()
    assert d({'a', 'b', 'c'}) == ['a', 'b', 'c']

# Generated at 2022-06-11 21:03:21.183839
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(set([1])) == [1]
    assert _ExtendedEncoder().default(frozenset([1])) == [1]



# Generated at 2022-06-11 21:03:23.215949
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-11 21:03:32.587383
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps([1, 2, 3], cls=_ExtendedEncoder)
    json.dumps({'a': 1}, cls=_ExtendedEncoder)
    json.dumps(datetime(2014, 2, 3), cls=_ExtendedEncoder)
    json.dumps(UUID('123e4567-e89b-12d3-a456-426655440000'), cls=_ExtendedEncoder)
    json.dumps(Enum('A', {'a': 1}), cls=_ExtendedEncoder)
    json.dumps(Decimal('1.00'), cls=_ExtendedEncoder)



# Generated at 2022-06-11 21:03:38.800603
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default([]) == []
    assert encoder.default({}) == {}
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default((1, 2)) == [1, 2]
    assert encoder.default(set(['a', 'b'])) == ['a', 'b']
    assert encoder.default(datetime(2020, 3, 1, 1, 2, 3, 4, timezone.utc)) == 1583114923.000004

# Generated at 2022-06-11 21:03:41.302725
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    res = json.dumps(dict(a=1.2345678), cls=_ExtendedEncoder)
    assert res == '{"a":1.2345678}'



# Generated at 2022-06-11 21:03:49.644118
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    x = _ExtendedEncoder()
    assert x.default(5) == 5
    assert x.default(None) is None
    assert x.default("str") == "str"
    assert x.default({"a": 5}) == {"a": 5}
    assert x.default([1, 2]) == [1, 2]
    assert x.default({"a": [1, 2]}) == {"a": [1, 2]}
    assert x.default(datetime.now()) == datetime.now().timestamp()

# Generated at 2022-06-11 21:03:57.409189
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert json.dumps(dict(a=1), cls=_ExtendedEncoder) == '{"a": 1}'
    assert json.dumps({'a': 1}, cls=_ExtendedEncoder) == '{"a": 1}'
    assert json.dumps([1, 'a'], cls=_ExtendedEncoder) == '[1, "a"]'
    assert json.dumps(set([1, 'a']), cls=_ExtendedEncoder) == '[1, "a"]'
    assert json.dumps(frozenset({1, 'a'}), cls=_ExtendedEncoder) == '[1, "a"]'

# Generated at 2022-06-11 21:04:07.100213
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps({'dt': datetime.now()}, cls=_ExtendedEncoder)
    assert json.dumps({'dt': timezone.utc}, cls=_ExtendedEncoder)
    assert json.dumps({'uuid': UUID('0709e280-42c3-4daa-a8e3-f15f9e9d9b98')}, cls=_ExtendedEncoder)
    assert json.dumps({'enum': cfg.LetterCase.snakecase}, cls=_ExtendedEncoder)
    assert json.dumps({'decimal': Decimal('123.35')}, cls=_ExtendedEncoder)



# Generated at 2022-06-11 21:04:15.382210
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(defaultdict()) == "{}"
    assert _ExtendedEncoder().encode(datetime.now(tz=timezone.utc)) == str(datetime.now(tz=timezone.utc).timestamp())
    assert _ExtendedEncoder().encode(UUID('c627020f-8525-4813-8864-c54fafd9f9a2')) == "\"{c627020f-8525-4813-8864-c54fafd9f9a2}\""
    assert _ExtendedEncoder().encode(Decimal('NaN')) == "\"NaN\""
    assert _ExtendedEncoder().encode(False) == "false"
    assert _ExtendedEncoder().encode(MISSING) == "null"