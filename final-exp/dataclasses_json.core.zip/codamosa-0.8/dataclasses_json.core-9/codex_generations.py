

# Generated at 2022-06-11 20:54:40.880668
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(datetime.now(), cls=_ExtendedEncoder) is not None
    assert json.dumps(UUID('00000000-0000-0000-0000-000000000000'), cls=_ExtendedEncoder) is not None
    assert json.dumps(dataclass(repr=False, order=False)(a=1), cls=_ExtendedEncoder) is not None
    assert json.dumps(Decimal('3.14'), cls=_ExtendedEncoder) is not None


# Generated at 2022-06-11 20:54:50.651268
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    a = datetime.now()
    b = Decimal('1.2')
    c = [datetime.now(), Decimal('1.3')]
    d = {datetime.now(): Decimal('1.4')}
    e = {1: 2}
    f = [1, 2, 3]
    g = UUID('eb4e7a45-fead-4a0e-8b83-2d9f93985a41')
    h = EnumTest.C
    i = {'h': h, 'd': datetime.now(), 'g': g}
    j = list(i.values())
    print(json.dumps(a, cls=_ExtendedEncoder))
    print(json.dumps(b, cls=_ExtendedEncoder))

# Generated at 2022-06-11 20:54:56.398799
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc))


_default_field_override = FieldOverride(cfg.DEFAULT_ENCODER,
                                        cfg.DEFAULT_DECODER,
                                        cfg.DEFAULT_MM_FIELD,
                                        cfg.DEFAULT_LETTER_CASE,
                                        cfg.DEFAULT_EXCLUDE)



# Generated at 2022-06-11 20:55:05.796613
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) == None
    assert encoder.default(1) == 1
    assert encoder.default(.1) == .1
    assert encoder.default(True) == True
    assert encoder.default("1") == "1"
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime.fromtimestamp(0, tz=timezone.utc)) == 0.0

# Generated at 2022-06-11 20:55:09.889751
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(datetime.now(timezone.utc).replace(microsecond=0)) == json.dumps(datetime.now(timezone.utc).replace(microsecond=0), cls=_ExtendedEncoder)



# Generated at 2022-06-11 20:55:11.780778
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = _ExtendedEncoder().default(list(range(3)))
    assert o == [0, 1, 2]


T = TypeVar('T')



# Generated at 2022-06-11 20:55:20.206798
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1: 2, 3: 4}) == '{"1": 2, "3": 4}'
    assert _ExtendedEncoder().encode([1, 2, 3, 4]) == '[1, 2, 3, 4]'
    assert _ExtendedEncoder().encode([1, [1, 2, 3], 4]) == '[1, [1, 2, 3], 4]'
    assert _ExtendedEncoder().encode(
        datetime(2015, 1, 1, 12, 0, 0, tzinfo=timezone.utc)) == '1420070400.0'
    assert _ExtendedEncoder().encode(
        datetime(2015, 1, 1, 12, 0, 0)) == '1420070400.0'

# Generated at 2022-06-11 20:55:23.787391
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # I cannot figure out how to test this class.
    result = _ExtendedEncoder().encode({'a': 1, 'b': 2})
    assert result == '{"a": 1, "b": 2}'



# Generated at 2022-06-11 20:55:28.374825
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) is not None
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000')) is not None
    assert _ExtendedEncoder().default(Decimal(0.0)) is not None


# Generated at 2022-06-11 20:55:35.135595
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    data = [123, "abc", [1, 2, 3], [4, 5, 6], {"a": b"a", "b": "b"},
            {"c": "d"}, UUID('1a2b3c4d-5e6f-7a8b-9c0d-1e2f3a4b567c'),
            datetime.now(timezone.utc), datetime.now()]
    assert _ExtendedEncoder().encode(data)


JsonEncoder = _ExtendedEncoder  # type: ignore



# Generated at 2022-06-11 20:56:02.727363
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    """Unit test for function default of class _ExtendedEncoder"""
    encoder = _ExtendedEncoder()
    # noinspection PyTypeChecker
    assert encoder.default(None) == None
    assert encoder.default(True) == True
    assert encoder.default(2) == 2
    assert encoder.default(3.3) == 3.3
    assert encoder.default('as') == 'as'
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1}) == {'a': 1}
    dt = datetime.now(timezone.utc)
    assert encoder.default(dt) == dt.timestamp()

# Generated at 2022-06-11 20:56:03.640767
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-11 20:56:05.702488
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps([0, 1, 2], cls=_ExtendedEncoder)



# Generated at 2022-06-11 20:56:12.654894
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    expected = [1, 2, 3]
    result = extended_encoder.default([1, 2, 3])
    assert(result == expected)

    expected = {'a': 1, 'b': 2, 'c': 3}
    result = extended_encoder.default({'a': 1, 'b': 2, 'c': 3})
    assert(result == expected)

    now = datetime.now()
    expected = now.timestamp()
    result = extended_encoder.default(now)
    assert(result == expected)

    #check that this is not an exact match
    assert(result != now)

    uuid_a = UUID('8e8ec658-c7b8-4bca-9598-c4b2485c2eb2')


# Generated at 2022-06-11 20:56:22.790194
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from decimal import Decimal
    from dataclasses import dataclass
    from enum import Enum
    from datetime import datetime
    from uuid import UUID

    @dataclass
    class Dataclass:
        name: str
        age: int
    class Enumeration(Enum):
        FOO = 1
        BAR = 2
    assert _ExtendedEncoder().encode(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode([1,2,3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(datetime(2020,1,1,tzinfo=timezone.utc)) == '1577836800.0'

# Generated at 2022-06-11 20:56:25.714457
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc)) == 0.0
    assert _ExtendedEncoder().default(datetime(1970, 1, 1)) == 0.0



# Generated at 2022-06-11 20:56:36.655628
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'x': 1, 'y': 2}) == {'x': 1, 'y': 2}
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('9f9df08a-7c0a-47a4-b4f4-4a7eb11dcaab')) == '9f9df08a-7c0a-47a4-b4f4-4a7eb11dcaab'
    assert encoder.default(Enum('test_enum', 'a b c')('a')) == 'a'

# Generated at 2022-06-11 20:56:38.942041
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.utcnow()) is not None



# Generated at 2022-06-11 20:56:45.370609
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def test_case(o, expected: Json):
        assert _ExtendedEncoder().default(o) == expected

    test_case(True, True)
    test_case(False, False)
    test_case(None, None)
    test_case([True], [True])
    test_case([False], [False])
    test_case([None], [None])
    test_case([1, 2, 3], [1, 2, 3])
    test_case([[1, 2, 3]], [[1, 2, 3]])
    test_case([[1, 2, 3], [4, 5, 6,]], [[1, 2, 3], [4, 5, 6,]])
    test_case({1: 2}, {1: 2})

# Generated at 2022-06-11 20:56:54.088919
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = {
        'decimal': Decimal('1.1'),
        'datetime': datetime(2019, 2, 10, 9, 0, 0, tzinfo=timezone.utc),
        'uuid': UUID('906b3650-2900-11ea-bb37-0242ac130002'),
        'enum': Color.RED,
        'list': [1, 2, 3],
        'dict': {'a': 1, 'b': 2},
        'int': 1,
        'str': "hello"
    }
    assert isinstance(_ExtendedEncoder().encode(o), str)


# noinspection PyShadowingBuiltins

# Generated at 2022-06-11 20:57:13.905175
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps(
        1,
        cls=_ExtendedEncoder
    )



# Generated at 2022-06-11 20:57:24.358527
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(True, cls=_ExtendedEncoder) == 'true'
    assert json.dumps(1, cls=_ExtendedEncoder) == '1'
    assert json.dumps(1.2, cls=_ExtendedEncoder) == '1.2'
    assert json.dumps(decimal.Decimal(1.2), cls=_ExtendedEncoder) == '1.2'
    assert json.dumps(Decimal(1.2), cls=_ExtendedEncoder) == '1.2'

# Generated at 2022-06-11 20:57:34.971211
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    # pylint: disable=no-member
    assert json.loads(json.dumps({}, cls=e)) == {}
    # pylint: disable=no-member
    assert json.loads(json.dumps(['a', 1], cls=e)) == ['a', 1]
    # pylint: disable=no-member
    assert json.loads(json.dumps([{'a': 1}], cls=e)) == [{'a': 1}]
    t = datetime.now()
    # pylint: disable=no-member
    assert json.loads(json.dumps(t, cls=e)) == t.timestamp()

# Generated at 2022-06-11 20:57:44.979079
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    result = encoder.default((1,2,3))
    assert isinstance(result, list)
    assert result == [1,2,3]
    result = encoder.default({1:'a',2:'b'})
    assert isinstance(result, dict)
    assert result == {1:'a',2:'b'}
    result = encoder.default(datetime(2020, 5, 18, tzinfo=timezone.utc))
    assert isinstance(result, float)
    assert result == 1589820800.0
    result = encoder.default(UUID('1064a52a-7b08-4516-8d8a-33bfb7a82a51'))
    assert isinstance(result, str)

# Generated at 2022-06-11 20:57:52.955891
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # type: () -> None
    now = datetime.now().replace(tzinfo=timezone.utc)
    x = _ExtendedEncoder().encode([1, now, 2])
    assert x == '[1, %s, 2]' % now.timestamp(), x
    x = [1, now, 2]
    y = _ExtendedEncoder().default(x)
    assert y == [1, now.timestamp(), 2], y
    x = {'a': 1, 'b': now, 'c': 2}
    y = _ExtendedEncoder().default(x)
    assert y == {'a': 1, 'b': now.timestamp(), 'c': 2}, y

# Generated at 2022-06-11 20:57:54.197891
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # type: () -> None
    _ExtendedEncoder()



# Generated at 2022-06-11 20:58:04.224892
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    instance = _ExtendedEncoder()
    from datetime import date, time
    from uuid import uuid4
    from enum import auto
    import decimal
    assert instance.default(date.today()) == date.today().timestamp()
    assert instance.default(time(12, 5, 6, 7)) == time(12, 5, 6, 7).timestamp()
    assert instance.default(datetime.now()) == datetime.now().timestamp()
    assert instance.default(uuid4()) == str(uuid4())
    assert instance.default(auto()) == 1
    assert instance.default(decimal.Decimal('1.1')) == '1.1'
    assert instance.default(decimal.Decimal('1')) == '1'

# Generated at 2022-06-11 20:58:13.168840
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(b'') == '""'
    assert _ExtendedEncoder().encode(bytearray()) == '""'
    assert _ExtendedEncoder().encode(0) == '0'
    assert _ExtendedEncoder().encode(0.0) == '0.0'
    assert _ExtendedEncoder().encode(0j) == '0'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(False) == 'false'
    assert _ExtendedEncoder().encode('abc') == '"abc"'
    assert _ExtendedEncoder().encode('') == '""'
    assert _ExtendedEncoder().en

# Generated at 2022-06-11 20:58:20.147590
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(1970, 1, 1, tzinfo=timezone.utc)) == '0'
    assert _ExtendedEncoder().encode(Enum('TestEnum', {'Name':3}).Name) == '3'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().encode(Decimal('1')) == '"1"'



# Generated at 2022-06-11 20:58:31.044695
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(True)
    assert encoder.default(False)
    assert encoder.default({"hello": "world"}) == {"hello": "world"}
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(1) == 1
    assert encoder.default(1.1) == 1.1
    assert encoder.default('hello') == 'hello'
    assert encoder.default('null') == 'null'
    assert encoder.default(None) is None
    assert encoder.default(
        datetime(2020, 5, 24, 12, 12, 12, 0, timezone.utc)) == 1590261532

# Generated at 2022-06-11 20:58:51.507359
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(
        {"a": 1, "b": 2}) == '{"a": 1, "b": 2}'


# Generated at 2022-06-11 20:59:02.721655
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import datetime
    from uuid import UUID
    from decimal import Decimal

    class MyEnum(Enum):
        A = 1
        B = 2

    t1 = datetime(2020, 12, 31, 23, 59, 59, 999999, timezone.utc)
    t1_json = {'json.datetime': t1.timestamp()}
    assert _ExtendedEncoder().default(t1) == t1_json

    u1 = UUID('06d9ac66-14b8-4b67-82f4-b98260d2e4d4')
    u1_json = '06d9ac66-14b8-4b67-82f4-b98260d2e4d4'
    assert _ExtendedEncoder().default(u1) == u

# Generated at 2022-06-11 20:59:11.891106
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        assert json.dumps({'test': 123}, cls=_ExtendedEncoder) == '{"test": 123}'
        assert json.dumps((1, 2, 3), cls=_ExtendedEncoder) == '[1, 2, 3]'
        assert json.dumps({1: 2, 3: 4}, cls=_ExtendedEncoder) == '{"1": 2, "3": 4}'
        assert json.dumps(UUID('00000000-1111-2222-3333-000000000000'), cls=_ExtendedEncoder) == '"00000000-1111-2222-3333-000000000000"'

# Generated at 2022-06-11 20:59:19.316486
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

    assert encoder.default({'item': 'value'}) == {'item': 'value'}
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(datetime(2020, 1, 1, 12, 0, 0)) == 1577836800.0
    assert encoder.default(UUID('7023a1a1-074c-4c4a-8c4d-da2e2e9d76b0')) ==\
           '7023a1a1-074c-4c4a-8c4d-da2e2e9d76b0'


# Generated at 2022-06-11 20:59:28.441589
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({"a": 1}) == {"a": 1}
    assert encoder.default(datetime(2019, 5, 25, 8, 7, 6, tzinfo=timezone.utc)) == 1558803226
    uuid = UUID('597a9b06-26b6-47f6-b056-b7dd5bac6ac8')
    assert encoder.default(uuid) == '597a9b06-26b6-47f6-b056-b7dd5bac6ac8'
    assert encoder.default(Decimal(10)) == '10'


# Generated at 2022-06-11 20:59:36.372060
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default({1:2}) == {1:2}
    assert encoder.default([1,2]) == [1,2]
    assert encoder.default(datetime.utcnow()) == datetime.utcnow().timestamp()
    assert encoder.default(UUID('7e8a8c2a-cbce-4cbf-9a9f-40de3a3feaed')) == '7e8a8c2a-cbce-4cbf-9a9f-40de3a3feaed'
    assert encoder.default(Decimal(1.1)) == '1.1'
    assert encoder.default('str') == 'str'
    assert encoder.default('1') == '1'




# Generated at 2022-06-11 20:59:39.788380
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert not (json.dumps({"result": [2, 3, 4, 5]}, cls=_ExtendedEncoder) in ["[2, 3, 4, 5]", {'result': [2,3,4,5]}])



# Generated at 2022-06-11 20:59:41.620520
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == "{}"



# Generated at 2022-06-11 20:59:48.380693
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1,2,3]'
    assert _ExtendedEncoder().encode(dict(a=1, b=2)) == '{"a":1,"b":2}'
    assert _ExtendedEncoder().encode(datetime(2017, 1, 1, 0, 0, 1, tzinfo=timezone.utc)) == '1483228801.0'
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'

# Generated at 2022-06-11 20:59:56.454511
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # arrays of different types
    assert _ExtendedEncoder().encode([1, "2"]) == '["1", "2"]'
    assert _ExtendedEncoder().encode([1, "2"]) == json.dumps([1, "2"])

    # dictionaries
    assert _ExtendedEncoder().encode({"a": 1, "b": "2"}) == '{"a": 1, "b": "2"}'
    assert _ExtendedEncoder().encode({"a": 1, "b": "2"}) == json.dumps({"a": 1, "b": "2"})

    # python objects
    class A:
        def __init__(self):
            self.b = "hello"
            self.c = 5


# Generated at 2022-06-11 21:00:49.745574
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) in ('{}', '[]')
    assert _ExtendedEncoder().encode(True) in ('true', 'false')
    assert _ExtendedEncoder().encode(0) == '0'
    assert _ExtendedEncoder().encode(0.5) == '0.5'
    assert _ExtendedEncoder().encode('test') in ('"test"', '"test"')
    assert _ExtendedEncoder().encode(datetime(2019, 10, 15, 8, 30)) == '1571121800.0'
    assert _ExtendedEncoder().encode(datetime(2019, 10, 15, 8, 30, tzinfo=timezone.utc)) == '1571121800.0'

# Generated at 2022-06-11 21:00:59.230995
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default({'a': True}) == {'a': True}
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(UUID('e9bb130b-e060-4d8e-828d-f2c893934ca7')) == 'e9bb130b-e060-4d8e-828d-f2c893934ca7'
    assert _ExtendedEncoder().default(datetime(2020, 6, 10, 23, 8, 36, 12000, timezone.utc)) == 1591821316.012

# Generated at 2022-06-11 21:01:09.582036
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    class Test:
        def __init__(self, name): self.name = name
        def __repr__(self): return f'<Test name={self.name}>'

        # Note that Test is not an instance of Collection.
        # This is why we don't have test_Extended_encoder_with_Collection_as_input


# Generated at 2022-06-11 21:01:15.478753
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == "null"
    assert _ExtendedEncoder().encode(UUID(int=0)) == '"00000000-0000-0000-0000-000000000000"'
    assert _ExtendedEncoder().encode(MappingProxyType({1:1})) == '{"1": 1}'
    assert _ExtendedEncoder().encode(datetime(2000, 1, 1, tzinfo=timezone.utc)) == '946684800.0'


# Generated at 2022-06-11 21:01:20.175742
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    a = 1.1
    b = 2.2
    c = [a, b]
    assert _ExtendedEncoder().encode({"key": a}) == '{"key": 1.1}'
    assert _ExtendedEncoder().encode({"key": b}) == '{"key": 2.2}'
    assert _ExtendedEncoder().encode({"key": c}) == '{"key": [1.1, 2.2]}'



# Generated at 2022-06-11 21:01:30.366691
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1: '1'}) == '{"1": "1"}'
    assert _ExtendedEncoder().encode([1, '1']) == '[1, "1"]'
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([1, {'a': 'b'}, '1']) == '[1, {"a": "b"}, "1"]'
    assert _ExtendedEncoder().encode([1]) == '[1]'
    assert _ExtendedEncoder().encode(list()) == '[]'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000001')) == '"00000000-0000-0000-0000-000000000001"'

# Generated at 2022-06-11 21:01:33.960801
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    data = [datetime(2017, 12, 1, 12, tzinfo=timezone.utc),
            [datetime(2017, 12, 1, 12, 4, 5, tzinfo=timezone.utc)]]
    json.dumps(data, cls=_ExtendedEncoder)



# Generated at 2022-06-11 21:01:36.864866
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_data = json.dumps(
        {'a': 'A', 'b': [1, 2, 3], 'c': datetime.now()}, cls=_ExtendedEncoder)
    assert json_data is not None



# Generated at 2022-06-11 21:01:45.668642
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # init
    ee = _ExtendedEncoder()
    # test
    assert ee.default({}) == {}
    assert ee.default([]) == []
    assert ee.default("") == ""
    assert ee.default(0) == 0
    assert ee.default(0.0) == 0.0
    assert ee.default(True) == True
    assert ee.default(None) == None
    assert ee.default("abc") == "abc"
    assert ee.default(Collection.__args__) == []
    assert ee.default(Mapping.__args__) == {}
    dt_now = datetime.now()
    assert ee.default(dt_now) == dt_now.timestamp()

# Generated at 2022-06-11 21:01:49.518330
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """
    This test is for check if _ExtendedEncoder behaves as expected.
    """
    encoder = _ExtendedEncoder()
    my_list = [1,2,3]
    expected_result = super(_ExtendedEncoder, encoder).default(my_list)
    my_result = encoder.default(my_list)
    assert my_result == expected_result



# Generated at 2022-06-11 21:03:06.125323
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # coverage helps
    assert _ExtendedEncoder().encode({})  # type: ignore



# Generated at 2022-06-11 21:03:14.793604
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import date
    from decimal import Decimal
    from uuid import UUID

    dec = Decimal('3.14')
    dt = date(2019, 1, 1)
    u = UUID('123e4567-e89b-12d3-a456-426655440000')

    et = _ExtendedEncoder()
    assert et.default(dec) == '3.14'
    assert et.default(dt) == 1546300800.0
    assert et.default(u) == '123e4567-e89b-12d3-a456-426655440000'
    assert et.default(set([])) == []
    assert et.default(tuple([])) == []
    assert et.default(frozenset([])) == []

# Generated at 2022-06-11 21:03:25.382976
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import datetime
    from decimal import Decimal
    from uuid import UUID

    class MyEnum(Enum):
        t = 1
        r = 2


# Generated at 2022-06-11 21:03:35.237333
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(10) == 10
    assert encoder.default(10.2) == 10.2
    assert encoder.default('hi') == 'hi'
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(('a', 'b')) == ['a', 'b']
    assert encoder.default(set(('a', 'b'))) == ['a', 'b']
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default(datetime(2020, 4, 6, 22, 0, 0, 0, timezone.utc)) == 1586056000.0

# Generated at 2022-06-11 21:03:45.940525
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().encode([{}, {}])
    _ExtendedEncoder().encode((1, 2, 3))
    _ExtendedEncoder().encode({"k": "v"})
    _ExtendedEncoder().encode(UUID("1d28e6c5-7199-4bfc-b4d4-6eef6b5f6134"))
    _ExtendedEncoder().encode(Decimal("1.1"))


_transp_map = {
    'snake': cfg.from_snake_case,
    'kebab': cfg.from_kebab_case,
    'lower': cfg.lower_case,
    'upper': cfg.upper_case,
}



# Generated at 2022-06-11 21:03:51.572936
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj = namedtuple('Json', ['a'])(1)
    obj_in_list = [obj, obj, obj]
    obj_in_mapping = {'obj': obj}

    assert _ExtendedEncoder().default(obj) == {"a": 1}
    assert _ExtendedEncoder().default(obj_in_list) == [{"a": 1}, {"a": 1}, {"a": 1}]
    assert _ExtendedEncoder().default(obj_in_mapping) == {"obj": {"a": 1}}

    obj = datetime(2020, 1, 1, tzinfo=timezone.utc)
    assert _ExtendedEncoder().default(obj) == 1577836800.0

    obj = UUID('12345678123456781234567812345678')

# Generated at 2022-06-11 21:03:58.171541
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # A simple example
    encoder = _ExtendedEncoder().encode
    assert encoder(1) == "1"
    assert encoder([0, 1]) == "[0, 1]"
    assert encoder({'a': 'A', 'b': 'B'}) == '{"a": "A", "b": "B"}'
    assert encoder({"a": "A", "b": [1, 2]}) == '{"a": "A", "b": [1, 2]}'
    assert encoder(UUID('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11')) == '"a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11"'
    assert encoder(Decimal('1.1'))

# Generated at 2022-06-11 21:03:59.427274
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().encode(tuple())



# Generated at 2022-06-11 21:04:09.938419
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    r = enc.default(17.0)
    assert isinstance(r, float)
    assert r == 17.0
    r = enc.default(datetime.now(tz=timezone.utc))
    assert isinstance(r, float)
    r = enc.default(UUID('be18ab10-945b-49e3-8d8c-2f22fc257e0e'))
    assert r == 'be18ab10-945b-49e3-8d8c-2f22fc257e0e'
    r = enc.default(Enum('test', 'a b'))
    assert r == 'a'
    r = enc.default(Decimal('42'))
    assert r == '42'



# Generated at 2022-06-11 21:04:17.771947
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(12) == 12
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(True) is True
    test_list = [1, 2, 3]
    assert _ExtendedEncoder().default(test_list) == test_list
    test_dict = {'a': 'b', 'c': 'd'}
    assert _ExtendedEncoder().default(test_dict) == test_dict
    assert _ExtendedEncoder().default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577808000