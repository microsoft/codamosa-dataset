

# Generated at 2022-06-11 20:54:42.261757
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.JSONEncoder.default(o)

# noinspection PyMethodMayBeStatic,PyShadowingNames

# Generated at 2022-06-11 20:54:45.002801
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': [1, 2, 3]}) == '{"a": [1, 2, 3]}'



# Generated at 2022-06-11 20:54:55.761733
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

    assert encoder.encode(set()) == '[]'
    assert encoder.encode(frozenset()) == '[]'

    assert encoder.encode({'a': 'b'}) == '{"a": "b"}'
    assert encoder.encode(frozenset({'a', 'b'})) == '["a", "b"]'

    assert encoder.encode(datetime(2017, 1, 1, 0, 0, 0)) == '1483228800.0'
    assert encoder.encode(UUID('{12345678-1234-1234-1234-123456789012}')) == '"12345678-1234-1234-1234-123456789012"'


# Generated at 2022-06-11 20:55:00.194017
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import unittest
    import uuid
    from dataclasses_json.tests.test_utils import test_object
    _ExtendedEncoder().encode(test_object)
    _ExtendedEncoder().encode([uuid.uuid4()])


# Generated at 2022-06-11 20:55:03.911657
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.utcnow()).startswith('"2')
    assert _ExtendedEncoder().encode(UUID('01234567-89ab-cdef-0123-456789abcdef')).startswith('"01234567')



# Generated at 2022-06-11 20:55:10.123595
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(['abc', 'def'], cls=_ExtendedEncoder) == '["abc", "def"]'
    assert json.dumps({'abc': 'def'}, cls=_ExtendedEncoder) == '{"abc": "def"}'
    now = datetime.now(timezone.utc)
    assert json.dumps(now, cls=_ExtendedEncoder) == str(now.timestamp())



# Generated at 2022-06-11 20:55:12.454330
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder().encode({"a": [1, 2, 3], "b": "c"})
    assert result == '{"a": [1, 2, 3], "b": "c"}'



# Generated at 2022-06-11 20:55:19.903082
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime(1970,1,1,0,0,0,0,timezone.utc)) == 0.0
    assert encoder.default(datetime(2005,3,3,0,0,0,0,timezone.utc)) == 1109849600.0
    assert encoder.default(UUID(int=1)) == '00000000-0000-0000-0000-000000000001'
    assert encoder.default(UUID(bytes=bytes(16))) == '00000000-0000-0000-0000-000000000000'
    assert encoder.default(Decimal(1)) == '1'
    assert encoder.default(Decimal(-1)) == '-1'


# Generated at 2022-06-11 20:55:27.307982
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    # assert enc.default([]) == []
    # assert enc.default(()) == []
    # assert enc.default({}) == {}
    # assert enc.default(set()) == []
    # assert enc.default(frozenset()) == []
    assert enc.default(datetime(2001, 1, 1, tzinfo=timezone.utc)) == 978307200.0
# This function exists just to avoid the 'name is used prior to global declaration' error

# Generated at 2022-06-11 20:55:36.256010
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

    # Collection
    assert encoder.default(tuple(range(10))) == list(range(10))
    assert encoder.default(range(10)) == list(range(10))
    assert encoder.default(set(range(10))) == list(range(10))
    assert encoder.default(frozenset(range(10))) == list(range(10))
    assert encoder.default(dict(zip(range(5), range(5)))) == {0: 0, 1: 1, 2: 2, 3: 3, 4: 4}
    assert encoder.default(dict(zip(range(5), range(5)))) == {0: 0, 1: 1, 2: 2, 3: 3, 4: 4}

    # datetime.datetime
    assert encoder.default

# Generated at 2022-06-11 20:56:01.148869
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = _ExtendedEncoder()
    assert o is not None


# noinspection PyProtectedMember

# Generated at 2022-06-11 20:56:06.606621
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime(2009, 1, 6, 15, 8, 24)) == 1231180504.0
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000001')) == '00000000-0000-0000-0000-000000000001'
    assert _ExtendedEncoder().default(D(1.1)) == '1.1'

# noinspection PyProtectedMember

# Generated at 2022-06-11 20:56:12.002767
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(datetime(year=2000, month=1, day=1)) == '946684800'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'
    assert _ExtendedEncoder().encode(Decimal('3.14')) == '"3.14"'


# Generated at 2022-06-11 20:56:22.018993
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder_test_cases = [
        (UUID('6bca5e5a-6282-46a2-8e5f-cc5c5e5ad5ea'),
         '"6bca5e5a-6282-46a2-8e5f-cc5c5e5ad5ea"'),
        (datetime(2020, 8, 30, 3, 30, 30, tzinfo=timezone.utc), "1598781430.0"),
        (Enum("Enum", "value"), "value"),
        (Decimal("1.1"), "1.1"),
        (Exception("Message"), '"Message"')
    ]
    for element, expected in encoder_test_cases:
        encoded = _ExtendedEncoder().encode(element)
        assert encoded == expected, f

# Generated at 2022-06-11 20:56:26.912696
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([Decimal('0.1'), datetime(2019, 1, 1)]) == \
           '[{"jsonclass": ["decimal.Decimal", "0.1"], "__jsonclass__": ["decimal.Decimal"]}, 1546300800]'

# For this encoder, if the object is a mapping, we serialize it as a mapping; if the object is not a mapping, we
# serialize it as a list.

# Generated at 2022-06-11 20:56:32.308047
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ee = _ExtendedEncoder()
    assert ee.default(set()) == list(set())
    assert ee.default({1: 2}) == {1: 2}
    assert ee.default(datetime(2020, 1, 1, 0, 8, 22, tzinfo=timezone.utc)) == 1577880502.0


# Generated at 2022-06-11 20:56:40.321042
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime(1, 1, 1, 1, 1, 1, 1, timezone.utc)) == \
        datetime(1, 1, 1, 1, 1, 1, 1, timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8')) == \
        '6ba7b810-9dad-11d1-80b4-00c04fd430c8'
    assert _ExtendedEncoder().default(1.0) == 1.0



# Generated at 2022-06-11 20:56:52.202829
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict()) == "{}"
    assert _ExtendedEncoder().encode(list()) == "[]"
    assert _ExtendedEncoder().encode(str()) == "\"\""
    assert _ExtendedEncoder().encode(int()) == "0"
    assert _ExtendedEncoder().encode(float()) == "0.0"
    assert _ExtendedEncoder().encode(bool()) == "false"
    assert _ExtendedEncoder().encode(None) == "null"
    assert _ExtendedEncoder().encode(datetime.now()) == str(datetime.now().timestamp())
    assert _ExtendedEncoder().encode(UUID('66aad7e0-c89d-40b2-a80f-f8b379d59e1a'))

# Generated at 2022-06-11 20:57:03.301313
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default(datetime.utcnow()) == datetime.utcnow().timestamp()
    assert encoder.default(Decimal('1.234')) == '1.234'
    assert encoder.default(set()) == []
    assert encoder.default(frozenset()) == []
    assert encoder.default(range(0)) == []
    assert encoder.default(dict()) == {}
    assert encoder.default(list()) == []
    assert encoder.default(tuple()) == []
    assert isinstance(encoder.default(UUID(int=1)), str)
    assert encoder.default(Enum('test', ['a'])) == 'a'
    assert encoder.default(True)

# Generated at 2022-06-11 20:57:04.431355
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default('')



# Generated at 2022-06-11 20:57:50.496371
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    class Foo:
        pass
    foo = Foo()
    assert foo == _ExtendedEncoder().default(foo)
    assert [1, 2] == _ExtendedEncoder().default([1, 2])
    assert {'a': 1, 'b': 2} == _ExtendedEncoder().default({'a': 1, 'b': 2})
    assert 1.2345 == _ExtendedEncoder().default(1.2345)
    assert '1.2345' == _ExtendedEncoder().default(Decimal('1.2345'))
    assert '1' == _ExtendedEncoder().default(1)
    assert 'true' == _ExtendedEncoder().default(True)
    assert 'null' == _ExtendedEncoder().default(None)

# Generated at 2022-06-11 20:58:01.661277
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(
        {'foo': 1, 'bar': 2}) == {'foo': 1, 'bar': 2}
    assert _ExtendedEncoder().default(
        (1, 2, 3)) == [1, 2, 3]
    assert _ExtendedEncoder().default(
        {1, 2, 3}) == [1, 2, 3]
    assert _ExtendedEncoder().default(
        datetime.now(timezone.utc)) == _ExtendedEncoder().default(datetime.now(timezone.utc).timestamp())
    assert _ExtendedEncoder().default(
        UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default

# Generated at 2022-06-11 20:58:12.089415
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    base_test_list = [str, int, float, bool, None]
    base_encoder = _ExtendedEncoder()
    for test in base_test_list:
        assert base_encoder.default(test()) == test()
        assert base_encoder.default(test())

    try:
        _ExtendedEncoder().default(set())
    except TypeError:
        assert True
    else:
        assert False  # pragma: nocover

    try:
        _ExtendedEncoder().default(frozenset())
    except TypeError:
        assert True
    else:
        assert False  # pragma: nocover

    test_list = [set, frozenset]
    for test in test_list:
        assert _ExtendedEncoder().default(test(base_test_list)) == list

# Generated at 2022-06-11 20:58:16.343791
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        _ExtendedEncoder().encode(datetime.strptime('2019-02-13T10:00:00Z', '%Y-%m-%dT%H:%M:%SZ'))
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-11 20:58:23.911921
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(set([1, 2, 3])) == [1, 2, 3]
    assert _ExtendedEncoder().default(frozenset([1, 2, 3])) == [1, 2, 3]
    assert _ExtendedEncoder().default({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert _ExtendedEncoder().default({"a": {"b": [1, 2, 3]}}) == {"a": {"b": [1, 2, 3]}}
    assert _ExtendedEncoder().default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800.0

# Generated at 2022-06-11 20:58:34.210762
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps({'a': set([1,2,3])}, cls=_ExtendedEncoder) == '{"a": [1, 2, 3]}'
    assert json.dumps({'a': {1:1, 2:2, 3:3}}, cls=_ExtendedEncoder) == '{"a": {"1": 1, "2": 2, "3": 3}}'
    dt = datetime(2018, 12, 25, 0, 0, 0, 0, tzinfo=timezone.utc)
    assert json.dumps({'a': dt}, cls=_ExtendedEncoder) == '{"a": 1545692800.0}'

# Generated at 2022-06-11 20:58:41.251843
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(dict(a=1, b=2), cls=_ExtendedEncoder) == '{"a": 1, "b": 2}'
    assert json.dumps([1, 2], cls=_ExtendedEncoder) == "[1, 2]"
    assert json.dumps("hello", cls=_ExtendedEncoder) == '"hello"'
    assert json.dumps(1, cls=_ExtendedEncoder) == "1"
    assert json.dumps(1.5, cls=_ExtendedEncoder) == "1.5"
    assert json.dumps(True, cls=_ExtendedEncoder) == "true"
    assert json.dumps(None, cls=_ExtendedEncoder) == "null"

# Generated at 2022-06-11 20:58:45.448945
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3, 4]) == '[1, 2, 3, 4]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'



# Generated at 2022-06-11 20:58:54.328172
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """Unit test for constructor of class _ExtendedEncoder"""
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(frozenset()) == []
    assert _ExtendedEncoder().default(tuple()) == []
    assert _ExtendedEncoder().default({1:2, 3:4}) == {1:2, 3:4}
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(datetime(2019, 11, 10, 21, 9, 29, tzinfo=timezone.utc)) == 1573411469.0

# Generated at 2022-06-11 20:59:05.798784
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(None, cls=_ExtendedEncoder) == 'null'
    assert json.dumps(True, cls=_ExtendedEncoder) == 'true'
    assert json.dumps(False, cls=_ExtendedEncoder) == 'false'
    assert json.dumps(0, cls=_ExtendedEncoder) == '0'
    assert json.dumps(1.0, cls=_ExtendedEncoder) == '1.0'
    assert json.dumps(0.0, cls=_ExtendedEncoder) == '0.0'
    assert json.dumps(['a', 'b', 'c'], cls=_ExtendedEncoder) == '["a", "b", "c"]'

# Generated at 2022-06-11 21:00:40.146179
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    json_encoder, json_decoder = _ExtendedEncoder, json.JSONDecoder
    assert getattr(json_encoder, 'default') is not getattr(json, 'default')

    today = datetime.now()
    uuid_str = str(UUID('{12345678-1234-5678-1234-567812345678}'))
    uuid = UUID(uuid_str)
    decimal = Decimal(1234567890.0987654321)

# Generated at 2022-06-11 21:00:41.101829
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder()
    assert result


# Generated at 2022-06-11 21:00:49.827269
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert enc.default(None) is None
    assert enc.default(1) == 1
    assert enc.default(1.1) == 1.1
    assert enc.default('1') == '1'
    assert enc.default(True) is True
    assert enc.default(False) is False
    assert enc.default([]) == []
    assert enc.default({}) == {}
    assert enc.default((1, 2, 3)) == [1, 2, 3]
    assert enc.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert enc.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()

# Generated at 2022-06-11 21:00:59.299440
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_int = 5
    test_str = "Hello"
    test_list = [1, 2, 3]
    test_dict = {'key': 'value'}
    test_date = datetime(2019, 11, 8, 18, 52, 44, 142693, timezone.utc)
    test_u = UUID('22a75324-d106-4e40-9b2e-7f5766b5d6ae')
    test_enum = cfg.DecoderMapping.value
    test_decimal = Decimal(1.1)

    expected_dict = {"key": "value"}
    expected_list = [1, 2, 3]
    expected_float = 1.1
    expected_date = 1573235964.142693


# Generated at 2022-06-11 21:01:09.659438
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert '{"a": 1, "b": 2}' == json.dumps(dict(a=1, b=2), cls=_ExtendedEncoder)
    assert '{"a": 1, "b": 2}' == json.dumps({'a': 1, 'b': 2}, cls=_ExtendedEncoder)
    assert '{"a": 1, "b": 2}' == json.dumps(MappingProxyType({'a': 1, 'b': 2}), cls=_ExtendedEncoder)
    assert '{"a": 1, "b": 2}' == json.dumps(ChainMap({'a': 1, 'b': 2}), cls=_ExtendedEncoder)

# Generated at 2022-06-11 21:01:13.540869
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(UUID('6c4e6ef4-6faf-11ea-bc55-0242ac130003')) == '6c4e6ef4-6faf-11ea-bc55-0242ac130003'



# Generated at 2022-06-11 21:01:14.953271
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'



# Generated at 2022-06-11 21:01:21.542770
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([datetime(2020, 1, 1, tzinfo=timezone.utc)]) == '["2020-01-01T00:00:00+00:00"]'
    assert _ExtendedEncoder().encode([datetime(2020, 1, 1)]) == '["2020-01-01T00:00:00"]'
    assert _ExtendedEncoder().encode([UUID('0d37815c-fa0e-11e9-89e9-0242ac120006')]) == '["0d37815c-fa0e-11e9-89e9-0242ac120006"]'
    assert _ExtendedEncoder().encode([Decimal('3.14')]) == '["3.14"]'

# Generated at 2022-06-11 21:01:29.785932
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(dict()) == dict()
    assert _ExtendedEncoder().default(list()) == list()
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().default(datetime(2019, 12, 10, 11, 45, 22, 123456, timezone.utc)) == 1575889922.123456
    assert _ExtendedEncoder().default(Decimal('3.4567')) == '3.4567'


# noinspection Mypy

# Generated at 2022-06-11 21:01:38.488910
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(datetime.now()) > 1.0e11
    assert _ExtendedEncoder().encode(UUID('f47ac10b-58cc-4372-a567-0e02b2c3d479')) == '"f47ac10b-58cc-4372-a567-0e02b2c3d479"'
    assert _ExtendedEncoder().encode(Decimal('10.2')) == '"10.2"'

# ---

