

# Generated at 2022-06-11 20:54:39.885614
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc))



# Generated at 2022-06-11 20:54:46.230427
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # def test_default(self):
    assert json.loads(_ExtendedEncoder().encode(MISSING)).replace(" ", "") == "null"
    assert json.loads(_ExtendedEncoder().encode(timezone.utc)).replace(" ", "") == "0"
    assert json.loads(_ExtendedEncoder().encode(set())).replace(" ", "") == "[]"
    assert json.loads(_ExtendedEncoder().encode(dict())).replace(" ", "") == "{}"



# Generated at 2022-06-11 20:54:47.304645
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(None) is None



# Generated at 2022-06-11 20:54:52.592444
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(123) == 123
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({"a": 1, "b": 2}) == {"a": 1, "b": 2}



# Generated at 2022-06-11 20:55:03.420430
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = json.JSONEncoder()
    result = encoder.encode([{1, 2, 3}, 'abc'])
    assert result == '[{"1", "2", "3"}, "abc"]'
    result = encoder.encode([{1, 2, 3}, 'abc'])
    assert result == '[{"1", "2", "3"}, "abc"]'
    result = encoder.encode(datetime(2020, 7, 8, 16, 53, 58))
    assert result == '"2020-07-08 16:53:58"'
    result = encoder.encode(UUID('67f9f186-b114-4acd-8f0a-52817d4cf2a1'))

# Generated at 2022-06-11 20:55:14.624041
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import pytest
    from dataclasses_json.config import config
    o = _ExtendedEncoder()
    assert o.default(int(1)) == 1
    assert o.default(float(1)) == 1
    assert o.default(str('1')) == '1'
    assert o.default(list([1])) == [1]
    assert o.default(tuple([1])) == [1]
    assert o.default(set([1])) == [1]
    assert o.default(dict({1: 1})) == {1: 1}
    assert config.timezone.localize(
      datetime(2019, 11, 29, 15, 44)).timestamp() == o.default(
          datetime(2019, 11, 29, 15, 44))

# Generated at 2022-06-11 20:55:21.446163
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def _ut(o, expected):
        actual = json.dumps(o, cls=_ExtendedEncoder, sort_keys=True)
        assert actual == expected, "actual: {}, expected:{}".format(actual, expected)

    random_uuid = UUID('32d322f4-4f4b-4e37-9a3b-f1c72fcf60e9')
    _ut(random_uuid, '"32d322f4-4f4b-4e37-9a3b-f1c72fcf60e9"')

    class SomeRandomEnum(Enum):
        ONE = 1
        TWO = 2
    _ut(SomeRandomEnum.ONE, '1')

    _ut([1, 2], '[1,2]')

# Generated at 2022-06-11 20:55:31.239952
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default('a') == 'a'
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000001')) == '00000000-0000-0000-0000-000000000001'
    assert _ExtendedEncoder().default(datetime.now(tz=timezone.utc)) == datetime.now(tz=timezone.utc).timestamp()
    assert _ExtendedEncoder().default(set([1, 2, 3])) == [1, 2, 3]
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'a': 1}) == {'a': 1}


# Generated at 2022-06-11 20:55:38.227682
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # type: () -> None
    from datetime import datetime, timedelta, tzinfo
    from decimal import Decimal
    from enum import Enum
    from time import time
    from uuid import UUID
    import json
    import unittest

    class CustomEnum(Enum):
        TEST_ENUM_VALUE = 'value'

    @dataclass
    class TestObj:
        test_id: UUID = field(default_factory=UUID)
        test_enum: CustomEnum = CustomEnum.TEST_ENUM_VALUE
        test_datetime: datetime = datetime.now()

    extended_encoder = _ExtendedEncoder()
    test_obj = TestObj()
    test_datetime = test_obj.test_datetime

# Generated at 2022-06-11 20:55:47.987268
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps({"foo": 1}, cls=_ExtendedEncoder) == '{"foo": 1}'
    assert json.dumps({"foo": [1, 2, 3]}, cls=_ExtendedEncoder) == '{"foo": [1, 2, 3]}'
    assert json.dumps({"foo": {"bar": 1}}, cls=_ExtendedEncoder) == '{"foo": {"bar": 1}}'
    assert json.dumps({"foo": datetime(2019, 11, 11, 10, 22, tzinfo=timezone.utc)}, cls=_ExtendedEncoder) == '{"foo": 1573475120.0}'

# Generated at 2022-06-11 20:56:14.135305
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == 0
    assert _ExtendedEncoder().default(UUID("c5cf5d21-1b7e-4d6e-83f3-e6b4cdecb950")) == "c5cf5d21-1b7e-4d6e-83f3-e6b4cdecb950"
    assert _ExtendedEncoder().default(Decimal("1.234")) == "1.234"
    assert _ExtendedEncoder().default("test") == "test"

# noinspection

# Generated at 2022-06-11 20:56:24.195071
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps({1, 2, 3}, cls=_ExtendedEncoder) == "[1, 2, 3]"
    assert json.dumps({1: 2, 3: 4}, cls=_ExtendedEncoder) == '{"1": 2, "3": 4}'
    assert json.dumps('hello world', cls=_ExtendedEncoder) == '"hello world"'
    assert json.dumps(123, cls=_ExtendedEncoder) == "123"
    assert json.dumps(12.3, cls=_ExtendedEncoder) == "12.3"
    assert json.dumps(True, cls=_ExtendedEncoder) == "true"
    assert json.dumps(None, cls=_ExtendedEncoder) == "null"

# Generated at 2022-06-11 20:56:35.718316
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1,2,3]) == [1,2,3]
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default(UUID('5d5af5b5-e2ff-4f44-bcc6-a8a1a2c7d9c3')) == '5d5af5b5-e2ff-4f44-bcc6-a8a1a2c7d9c3'
    assert encoder.default(datetime(year=2020, month=2, day=29, tzinfo=timezone.utc)) == 1582976000.0

# Generated at 2022-06-11 20:56:39.838185
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(['a', 1]) == ['a', 1]
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default(DefaultDict(str)) == {}

# noinspection PyProtectedMember

# Generated at 2022-06-11 20:56:45.801213
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(1.1) == 1.1
    assert _ExtendedEncoder().default(datetime(2019, 1, 1, tzinfo=timezone.utc)) == 1546300800.0
    assert _ExtendedEncoder().default(UUID('550e8400-e29b-41d4-a716-446655440000')) == '550e8400-e29b-41d4-a716-446655440000'
    class MyEnum(Enum):
        my_value = 1
    assert _ExtendedEncoder().default(MyEnum.my_value) == 1
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'

# Generated at 2022-06-11 20:56:55.257063
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"abc": 123}) == '{"abc": 123}'
    assert _ExtendedEncoder(indent=2).encode({"abc": 123}) == '{\n  "abc": 123\n}'
    assert _ExtendedEncoder().encode({"abc": [1, 2, 3]}) == '{"abc": [1, 2, 3]}'
    assert _ExtendedEncoder().encode({"abc": [{"a": 1}, {"a": 2}, {"a": 3}]}) == '{"abc": [{"a": 1}, {"a": 2}, {"a": 3}]}'

# Generated at 2022-06-11 20:56:57.725067
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    serialized_data = _ExtendedEncoder().encode(1)
    assert serialized_data == '1'



# Generated at 2022-06-11 20:57:00.617150
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(Decimal('12.45')) == '12.45'

json_encoder = _ExtendedEncoder



# Generated at 2022-06-11 20:57:02.014664
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict()) == '{}'



# Generated at 2022-06-11 20:57:11.494712
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(tuple(range(10)), cls=_ExtendedEncoder) == '{"0": 0, "1": 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9}'
    assert json.dumps(set(range(10)), cls=_ExtendedEncoder) == '{"0": 0, "1": 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9}'
    assert json.dumps({'x':1,'y':2}, cls=_ExtendedEncoder) == '{"x": 1, "y": 2}'

# Generated at 2022-06-11 20:57:40.719280
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # string
    assert _ExtendedEncoder().default('a') == 'a'
    assert _ExtendedEncoder().default('') == ''
    assert _ExtendedEncoder().default('-') == '-'
    assert _ExtendedEncoder().default('_') == '_'
    assert _ExtendedEncoder().default(',') == ','
    assert _ExtendedEncoder().default('ち') == 'ち'
    assert _ExtendedEncoder().default('🤔') == '🤔'
    # number
    assert _ExtendedEncoder().default(0) == 0
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(9) == 9
    assert _ExtendedEncoder().default(10) == 10

# Generated at 2022-06-11 20:57:50.566878
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    date = datetime.now(timezone.utc)

    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _ExtendedEncoder().encode(date) == f'"{date.timestamp()}"'
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000')) == '"123e4567-e89b-12d3-a456-426655440000"'

# Generated at 2022-06-11 20:58:00.127537
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now()) != json.JSONEncoder.default(encoder, datetime.now())
    assert encoder.default(UUID('00000000-0000-0000-0000-000000000001')) != json.JSONEncoder.default(encoder, UUID('00000000-0000-0000-0000-000000000001'))
    assert encoder.default(Enum("Foo", "bar")) != json.JSONEncoder.default(encoder, Enum("Foo", "bar"))
    assert encoder.default(Decimal("11.1")) != json.JSONEncoder.default(encoder, Decimal("11.1"))



# Generated at 2022-06-11 20:58:06.326204
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import dataclass
    from enum import Enum
    from uuid import UUID
    import pytest
    from dataclasses_json.utils import _isinstance_safe
    from dataclasses_json.mm_factory import _ExtendedEncoder

    class TblTypes(Enum):
        TBL_TYPE_1 = 'TBL_TYPE_1'
        TBL_TYPE_2 = 'TBL_TYPE_2'


    @dataclass
    class MyDc:
        an_int: int
        dt: datetime
        a_str: str
        uuid: UUID
        enum: TblTypes

    dt = datetime.now(timezone.utc)

# Generated at 2022-06-11 20:58:09.320478
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.utcnow())
    assert _ExtendedEncoder().default(None)
    assert _ExtendedEncoder().default(object())
    assert _ExtendedEncoder().default(1)


# Generated at 2022-06-11 20:58:17.699425
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    js = dict(o=dict(a=1, b=2), p=[1,2,3], q=str)
    assert js == json.loads(json.dumps(js, cls=_ExtendedEncoder))
    uuid = UUID('{12345678-1234-5678-1234-567812345678}')
    dt = datetime(2018, 4, 17, 16, 7, 59, 234564, tzinfo=timezone.utc)
    assert dict(uuid=str(uuid), dt=dt.timestamp()) == \
        json.loads(json.dumps(dict(uuid=uuid, dt=dt), cls=_ExtendedEncoder))



# Generated at 2022-06-11 20:58:26.647599
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(set([1, 2, 3])) == [1, 2, 3]
    assert not _ExtendedEncoder().default(set([1, 2, 3]))[0] == 2
    assert _ExtendedEncoder().default('str') == 'str'
    assert _ExtendedEncoder().default(b'str') == 'str'
    assert _ExtendedEncoder().default(2) == 2
    assert _ExtendedEncoder().default(1.2) == 1.2
    assert _ExtendedEncoder().default(object) is not None
    assert _ExtendedEncoder().default(object) is not object
    assert _ExtendedEncoder().default(True) is True
    assert _

# Generated at 2022-06-11 20:58:36.359519
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default((1, 2)) == [1, 2]
    assert _ExtendedEncoder().default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(({'a': 1, 'b': 2}, 3, 4)) == [{'a': 1, 'b': 2}, 3, 4]

    assert _ExtendedEncoder().default(UUID('f47ac10b-58cc-4372-a567-0e02b2c3d479')) == 'f47ac10b-58cc-4372-a567-0e02b2c3d479'

# Generated at 2022-06-11 20:58:45.314012
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 3, 4, 5, tzinfo=timezone.utc)) == '1578053245.0'
    assert _ExtendedEncoder().encode(UUID('b8d0157d-fc7c-49e0-a7d8-0f2d7e9cdfdf')) == '"b8d0157d-fc7c-49e0-a7d8-0f2d7e9cdfdf"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode

# Generated at 2022-06-11 20:58:54.246721
# Unit test for constructor of class _ExtendedEncoder

# Generated at 2022-06-11 20:59:46.855215
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode('') == '""'
    assert _ExtendedEncoder().encode(5) == '5'
    assert _ExtendedEncoder().encode(5.5) == '5.5'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(UUID(int=0)) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().encode(Decimal('123.45')) == '123.45'

# Generated at 2022-06-11 20:59:55.673548
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(123) == 123
    assert _ExtendedEncoder().default(.5) == .5
    assert _ExtendedEncoder().default('abc') == 'abc'
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    date_now = datetime.now(tz = timezone.utc)
    assert _ExtendedEncoder().default(date_now) == date_now.timestamp()
    assert _Extended

# Generated at 2022-06-11 20:59:59.043508
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    a = [1, 2, 3]
    b = {'a':1, 'b':2}
    assert _ExtendedEncoder().default(a) == a
    assert _ExtendedEncoder().default(b) == b
    assert _ExtendedEncoder().default(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()



# Generated at 2022-06-11 21:00:05.450208
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    d = _ExtendedEncoder(cfg.config).default
    assert d(1) == 1
    assert d(1.0) == 1.0
    assert d(True) is True
    assert d(None) is None
    assert d({}) == {}
    assert d({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert d([]) == []
    assert d([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert d("111") == "111"
    assert d(set([1, 2, 3, 4])) == [1, 2, 3, 4]
    assert d(frozenset([1, 2, 3, 4])) == [1, 2, 3, 4]

# Generated at 2022-06-11 21:00:17.867400
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': 'test_encoder'}) == '{"a": "test_encoder"}'
    assert _ExtendedEncoder().encode({'a': [1,2,3]}) == '{"a": [1, 2, 3]}'
    assert _ExtendedEncoder().encode({'a': (1,2,3)}) == '{"a": [1, 2, 3]}'
    assert _ExtendedEncoder().encode({'a': (1,2,3)}) == '{"a": [1, 2, 3]}'
    assert _ExtendedEncoder().encode({'a': {'b':'d'}}) == '{"a": {"b": "d"}}'

# Generated at 2022-06-11 21:00:19.753574
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(
        {'a': datetime.now(timezone.utc)} )

# pylint: disable=C0321

# Generated at 2022-06-11 21:00:22.112612
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(Decimal('0.1')) == '0.1'


# Generated at 2022-06-11 21:00:29.924426
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder(indent=0)
    s = '{"a":1}'

    assert encoder.encode({"a": 1}) == s
    assert encoder.encode(1) == "1"
    assert encoder.encode(1.0) == "1.0"
    assert encoder.encode(True) == "true"
    assert encoder.encode(None) == "null"
    assert encoder.encode({"a": [1,2,3]}) == '{"a":[1,2,3]}'
    assert encoder.encode([1,2,3]) == '[1,2,3]'
    assert encoder.encode({"a": set([1,2,3])}) == '{"a":[1,2,3]}'
    assert encoder

# Generated at 2022-06-11 21:00:40.611566
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import pytest
    from dataclasses_json.example import Point, Person
    from dataclasses_json.cfg import Config
    from decimal import Decimal

    assert '_ExtendedEncoder' not in globals()
    from dataclasses_json._json import _ExtendedEncoder

    assert isinstance(_ExtendedEncoder(), _ExtendedEncoder)
    # for unit test
    assert _ExtendedEncoder().default == _ExtendedEncoder().default
    x = [1, 2, 3, 4]
    x_json = _ExtendedEncoder().default(x)
    assert x == x_json
    x_dict = {'a': 1, 'b': 2}
    x_dict_json = _ExtendedEncoder().default(x_dict)
    assert x_dict == x_dict_json
    x_

# Generated at 2022-06-11 21:00:42.136828
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set([(2, 3)])) == [2, 3]



# Generated at 2022-06-11 21:02:36.538765
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == str(time.time())
    assert _ExtendedEncoder().encode(UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8')) == '6ba7b810-9dad-11d1-80b4-00c04fd430c8'
    assert _ExtendedEncoder().encode(Decimal('123.4')) == '123.4'



# Generated at 2022-06-11 21:02:38.689322
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import dataclasses_json.tests.test_encoder as test_encoder

    test_encoder._test_ExtendedEncoder_default(self=_ExtendedEncoder)



# Generated at 2022-06-11 21:02:47.734590
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    dt = datetime.fromisoformat("2020-03-13")
    dt_str = json.dumps(dt, cls=_ExtendedEncoder)
    assert dt_str == '1584130736.0'

    u = UUID("9b8e1547-0ae7-4fa6-a7c8-5311ae69a7e4")
    u_str = json.dumps(u, cls=_ExtendedEncoder)
    assert u_str == '"9b8e1547-0ae7-4fa6-a7c8-5311ae69a7e4"'

    class TestEnum(Enum):
        A = 1
        B = 2
        C = 3
    e = TestEnum.C

# Generated at 2022-06-11 21:02:54.115923
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """
    Test constructor of _ExtendedEncoder.

    :return: None
    """
    assert _ExtendedEncoder is not None
    # Unit test for method that returns json when it is given object that is
    # generated from dataclass or dataclass instance.
    assert json.dumps({'test': 'test'}, cls=_ExtendedEncoder) == json.dumps({'test': 'test'})
    # Unit test for method that returns json when it is given object that
    # is Collection but not Mapping.
    assert json.dumps(['test'], cls=_ExtendedEncoder) == json.dumps(['test'])
    # Unit test for method that returns json when it is given datetime.

# Generated at 2022-06-11 21:02:55.408879
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"abc": datetime.utcnow()}) is not None



# Generated at 2022-06-11 21:03:05.095359
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # noinspection PyTypeChecker
    assert '["123", "456"]' == json.dumps(['123', '456'], cls=_ExtendedEncoder)
    # noinspection PyTypeChecker
    assert '{"a": "b"}' == json.dumps({'a': 'b'}, cls=_ExtendedEncoder)
    # noinspection PyTypeChecker
    assert '"123"' == json.dumps(Decimal('123'), cls=_ExtendedEncoder)
    # noinspection PyTypeChecker
    assert '"123"' == json.dumps(Decimal(123), cls=_ExtendedEncoder)
    # noinspection PyTypeChecker
    assert '"123"' == json.dumps(UUID('123'), cls=_ExtendedEncoder)
    #

# Generated at 2022-06-11 21:03:13.153174
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert isinstance(_ExtendedEncoder().encode(set()),str)
    assert _ExtendedEncoder().encode([])=="[]"
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000001'))=='"00000000-0000-0000-0000-000000000001"'
    assert _ExtendedEncoder().encode(33.3)=="33.3"
    assert _ExtendedEncoder().encode(datetime(2018,7,18,1,1,1,tzinfo=timezone(datetime.now().utcoffset())))=="1531893261.0"
    #assert ExtendedEncoder().encode(Decimal(10.2))=="10.2"


# Generated at 2022-06-11 21:03:23.803951
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.encode(['a', 'b']) == '["a", "b"]'
    assert encoder.encode([1, 2]) == '[1, 2]'
    assert encoder.encode({'a': 1}) == '{"a": 1}'
    assert encoder.encode({'a': 'a'}) == '{"a": "a"}'
    assert encoder.encode({1: 'a'}) == '{"1": "a"}'
    assert encoder.encode({'1': 'a'}) == '{"1": "a"}'
    assert encoder.encode(datetime.now()) == '1.5730403999999999e+09'
    assert encoder.encode(Decimal(1)) == '1'


type

# Generated at 2022-06-11 21:03:34.160727
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import pytest
    from collections import OrderedDict
    from datetime import datetime, timedelta
    from enum import Enum
    from uuid import UUID

    class _ExtendedEncoderTest(Enum):
        TEST_1 = 'test1'
        TEST_2 = 'test2'
        TEST_3 = 'test3'

    def test_default():
        enc = json.JSONEncoder()
        test = _ExtendedEncoder(default=test_default)
        assert enc.default(datetime.utcnow()) == test.default(datetime.utcnow())
        assert enc.default(timedelta(milliseconds=1)) == test.default(timedelta(milliseconds=1))
        with pytest.raises(TypeError):
            test.default(datetime.utcnow())


# Generated at 2022-06-11 21:03:35.374972
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(decimal.Decimal('NaN')) == '"NaN"'

