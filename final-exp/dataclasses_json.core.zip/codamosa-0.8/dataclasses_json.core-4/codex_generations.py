

# Generated at 2022-06-11 20:54:53.251566
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1:2}) == '{"1": 2}'
    assert _ExtendedEncoder().encode({1,2}) == '[1, 2]'
    class Test:
        def __init__(self, a, b):
            self.a = a
            self.b = b
    assert _ExtendedEncoder().encode(Test(1,2)) == '{"a": 1, "b": 2}'

# noinspection PyUnusedLocal

# Generated at 2022-06-11 20:55:03.803611
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    assert e.default('abc') == 'abc'
    assert e.default(12) == 12
    assert e.default(12.3) == 12.3
    assert e.default(True) == True
    assert e.default(False) == False
    assert e.default(None) == None
    assert e.default(['abc', 12, False]) == ['abc', 12, False]
    assert e.default({'a': 'abc', 'b': 12, 'c': False}) == {
                       'a': 'abc', 'b': 12, 'c': False}
    assert e.default(datetime(2010, 1, 1, tzinfo=timezone.utc)) == (
        datetime(2010, 1, 1, tzinfo=timezone.utc).timestamp())


# Generated at 2022-06-11 20:55:13.321151
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) == '12345678123456781234567812345678'
    assert _ExtendedEncoder().default(Decimal('100')) == str('100')
    assert _ExtendedEncoder().default(Decimal("100.00")) == str("100.00")



# Generated at 2022-06-11 20:55:20.605882
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    j1 = json.dumps([1, 2, 3], cls=_ExtendedEncoder)
    assert j1 == '[1, 2, 3]'
    j2 = json.dumps(dict(a=1, b=2), cls=_ExtendedEncoder)
    assert j2 == '{"a": 1, "b": 2}'
    j3 = json.dumps(datetime(2020, 4, 15, 23, 54, 21, 0, tzinfo=timezone.utc), cls=_ExtendedEncoder)
    assert j3 == '1587047461.0'
    j4 = json.dumps(UUID("839f6a26-6a17-440e-b2a2-ad0f1cbadecb"), cls=_ExtendedEncoder)

# Generated at 2022-06-11 20:55:25.564069
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    foo = _ExtendedEncoder()
    assert str(UUID("dac0d9aa-1b44-47cc-8a98-60bc0a6bc2b8")) == foo.default(UUID("dac0d9aa-1b44-47cc-8a98-60bc0a6bc2b8"))


# Generated at 2022-06-11 20:55:33.030960
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert [1, 2, 3] == encoder.default([1, 2, 3])
    assert {"key": "value"} == encoder.default({"key": "value"})
    assert "test" == encoder.default("test")
    assert True == encoder.default(True)
    assert 1 == encoder.default(1)
    assert 0.5 == encoder.default(0.5)
    assert None == encoder.default(None)


DictStrAny = Mapping[str, Any]



# Generated at 2022-06-11 20:55:38.985780
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode([datetime.now(),])
    assert _ExtendedEncoder().encode([datetime.now()])
    assert _ExtendedEncoder().encode({'date': datetime.now()})
    assert _ExtendedEncoder().encode({'date': [datetime.now()]})
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000'))
    assert _ExtendedEncoder().encode([UUID('123e4567-e89b-12d3-a456-426655440000'),])

# Generated at 2022-06-11 20:55:41.405607
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(object, cls=_ExtendedEncoder) == '"<class \'object\'>"'



# Generated at 2022-06-11 20:55:49.162610
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == json.dumps(None)
    assert _ExtendedEncoder().encode(True) == json.dumps(True)
    assert _ExtendedEncoder().encode(False) == json.dumps(False)
    assert _ExtendedEncoder().encode(1) == json.dumps(1)
    assert _ExtendedEncoder().encode(1.1) == json.dumps(1.1)
    assert _ExtendedEncoder().encode("str") == json.dumps("str")
    assert _ExtendedEncoder().encode(["list"]) == json.dumps(["list"])
    assert _ExtendedEncoder().encode({"dict": 1}) == json.dumps({"dict": 1})

    assert _ExtendedEncoder().en

# Generated at 2022-06-11 20:55:53.830560
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    if getattr(__builtins__, '__IPYTHON__', None) is None:
        assert encoder.default(1) == 1  # type: ignore
    assert encoder.default(datetime.utcnow())  # type: ignore
    assert encoder.default(set())  # type: ignore


# Generated at 2022-06-11 20:56:28.598965
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    result = _ExtendedEncoder().default(42)
    assert result == 42
    result = _ExtendedEncoder().default(None)
    assert result is None
    result = _ExtendedEncoder().default('foo')
    assert result == 'foo'
    result = _ExtendedEncoder().default(True)
    assert result is True
    result = _ExtendedEncoder().default(False)
    assert result is False
    result = _ExtendedEncoder().default([1, 2, 3])
    assert result == [1, 2, 3]
    result = _ExtendedEncoder().default({'a': 1, 'b': 2})
    assert result == {'a': 1, 'b': 2}

# Generated at 2022-06-11 20:56:32.110049
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode('abc') == '"abc"'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(False) == 'false'
    assert _ExtendedEncoder().encode(None) == 'null'



# Generated at 2022-06-11 20:56:37.386828
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode({"a": "b"}) == '{"a": "b"}'
    assert _ExtendedEncoder().encode({"a": "b"}) == '{"a": "b"}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'


# noinspection PyProtectedMember

# Generated at 2022-06-11 20:56:44.051746
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    # Basic test for _ExtendedEncoder
    assert encoder.default(datetime.now(timezone.utc))
    assert encoder.default(set([]))
    assert encoder.default(dict())
    assert encoder.default(UUID('12345678123456781234567812345678'))
    # Test for Enum
    class TestEnum(Enum):
        FIRST = 1
        SECOND = 2

    assert encoder.default(TestEnum.FIRST)
    assert encoder.default(TestEnum.SECOND)
    # Test for Decimal
    assert encoder.default(Decimal(12345678))



# Generated at 2022-06-11 20:56:45.179478
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1, 2, 3}) == '{"1": null, "2": null, "3": null}'



# Generated at 2022-06-11 20:56:55.279632
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():

    # Create an instance of class _ExtendedEncoder
    ext_encoder = _ExtendedEncoder()

    # Test method default of class _ExtendedEncoder
    from datetime import date
    import datetime
    from decimal import Decimal
    from enum import Enum
    from uuid import UUID
    uuid = UUID('56e1b5ca-a5a5-4499-8d44-c5a1cd240525')
    # Test default function of class _ExtendedEncoder
    assert ext_encoder.default('foo') == 'foo'
    assert ext_encoder.default(1) == 1
    assert ext_encoder.default(1.0) == 1.0
    assert ext_encoder.default(True) is True
    assert ext_encoder.default(None) is None
   

# Generated at 2022-06-11 20:57:06.766444
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'
    assert _ExtendedEncoder().encode(datetime.now()) == 'null'
    assert _ExtendedEncoder().encode(UUID('7783c2e7-1cf2-4fd7-aa51-8f8286967e99')) == '"7783c2e7-1cf2-4fd7-aa51-8f8286967e99"'
    assert _ExtendedEncoder().encode(Enum('Enum', ('a',))) == '1'
    assert _Extended

# Generated at 2022-06-11 20:57:08.212126
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'key': 2}) == '{"key": 2}'



# Generated at 2022-06-11 20:57:14.292313
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == 0
    assert _ExtendedEncoder().default(UUID('a3f3d173-0c0e-40fb-9455-2e2b75d8e33b')) == 'a3f3d173-0c0e-40fb-9455-2e2b75d8e33b'
    assert _ExtendedEncoder().default(Enum('Enum',['A']).A) == 'A'
    assert _ExtendedEncoder().default(Decimal('1')) == '1'
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default('1') == '1'
    assert _ExtendedEnc

# Generated at 2022-06-11 20:57:24.690815
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """
    test__ExtendedEncoder
    """
    encoder = _ExtendedEncoder()

    expected = {-1: [-1],
                'abc': 'abc'}
    result = json.loads(encoder.encode({-1: [-1], 'abc': 'abc'}))
    assert result == expected

    expected = ['aaa', 'bbb']
    result = json.loads(encoder.encode(['aaa', 'bbb']))
    assert result == expected

    expected = {-1: [-1],
                'abc': 'abc'}
    result = json.loads(encoder.encode({-1: [-1], 'abc': 'abc'}))
    assert result == expected

    expected = ['aaa', 'bbb']

# Generated at 2022-06-11 20:58:04.942085
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    a = _ExtendedEncoder().encode([{'x': 1, 'y': 2}, [1, 2, 3]])
    assert json.loads(a) == [{'x': 1, 'y': 2}, [1, 2, 3]]

    b = _ExtendedEncoder().encode([{"key": "value"}, datetime(2020, 7, 20, 12, 25, tzinfo=timezone.utc)])
    assert json.loads(b) == [{"key": "value"}, 1595090900.0]

    uuid1 = UUID("6ccd780c-baba-1026-9564-0040f4311e29")
    uuid2 = UUID("6ccd780c-baba-1026-9564-0040f4311e30")

# Generated at 2022-06-11 20:58:13.434901
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime(2019, 1, 1, 0, 0, 1, tzinfo=timezone.utc)) == 1546300801.0
    assert encoder.default(UUID('d9a9369d-b91c-4c03-9894-c82f8b30c29b')) == 'd9a9369d-b91c-4c03-9894-c82f8b30c29b'
    assert encoder.default(Decimal('1.234')) == '1.234'
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({1, 2, 3}) == [1, 2, 3]

# Generated at 2022-06-11 20:58:22.524605
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():  # pylint: disable=unused-argument
    assert json.dumps([1, 2, 3], cls=_ExtendedEncoder) == '[1,2,3]'
    assert json.dumps(dict(a=1), cls=_ExtendedEncoder) == '{"a":1}'
    assert json.dumps(dict(a=[1, 2, 3]), cls=_ExtendedEncoder) == '{"a":[1,2,3]}'
    assert json.dumps(dict(a=list([1, 2, 3])), cls=_ExtendedEncoder) == '{"a":[1,2,3]}'
    assert json.dumps(datetime.now(timezone.utc), cls=_ExtendedEncoder)

# Generated at 2022-06-11 20:58:27.513728
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert enc.default(UUID('3b1a8c1f-75ef-4c5d-91d8-7464d50f64b7')) == '3b1a8c1f-75ef-4c5d-91d8-7464d50f64b7'



# Generated at 2022-06-11 20:58:36.898139
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1,2,3])=='[1, 2, 3]'
    assert _ExtendedEncoder().encode([1,2,3,Decimal("0.1")]) == '[1, 2, 3, "0.1"]'
    # UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8") is the UUID of "uuid" field of class JsonDataWithDefaults from test_json_data.py

# Generated at 2022-06-11 20:58:42.545964
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps(['Foo', 'Bar'], cls=_ExtendedEncoder)
    json.dumps({'foo': 100, 'bar': 200}, cls=_ExtendedEncoder)
    json.dumps(datetime(1970, 1, 1, 0, 0, 0, 0, tzinfo=timezone.utc), cls=_ExtendedEncoder)
    json.dumps(UUID('08eae4a4-4a4b-4a4c-4a4d-08eae4a4a4a4'), cls=_ExtendedEncoder)
    json.dumps(SimpleEnum.First, cls=_ExtendedEncoder)
    json.dumps(Decimal('3.14'), cls=_ExtendedEncoder)



# Generated at 2022-06-11 20:58:52.455461
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps({1: 2, 3: 4}, cls=_ExtendedEncoder) == '{"1": 2, "3": 4}'
    assert json.dumps([1, 2, 3, 4], cls=_ExtendedEncoder) == '[1, 2, 3, 4]'
    assert json.dumps(datetime(2020, 9, 29, 2, 0, 2, 123000, timezone.utc), cls=_ExtendedEncoder) == '1600356002.123'
    assert json.dumps(UUID('{12345678-9012-3456-7890-123456789012}'), cls=_ExtendedEncoder) == '"12345678-9012-3456-7890-123456789012"'

# Generated at 2022-06-11 20:58:55.596961
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({None: None}) == '{"null": null}'
    assert _ExtendedEncoder().encode([None]) == '[null]'



# Generated at 2022-06-11 20:59:04.719032
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    d = datetime(2015, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    uu = UUID('ebd584b1-6d63-4f9c-88a0-b9db636c22a4')
    dd = Decimal('0.1')
    o = _ExtendedEncoder().default(d)
    o1 = _ExtendedEncoder().default(uu)
    o2 = _ExtendedEncoder().default(dd)
    assert o == d.timestamp()
    assert o1 == str(uu)
    assert o2 == str(dd)



# Generated at 2022-06-11 20:59:13.112699
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import string
    import uuid

    encoder = _ExtendedEncoder()
    o = {
        'datetime': datetime(2018, 9, 30, 13, 41, 9, 2, tzinfo=timezone.utc),
        'list': [1, 2, 3],
        'set': {'one', 'two', 'three'},
        'tuple': (1, 2, 3),
        'dict': {
            'one': 1,
            'two': 2,
            'three': 3
        },
        'uuid': uuid.uuid4(),
        'enum': string.ascii_letters,
        'decimal': Decimal(1.2345),
        'float': 1.2345,
        'int': 1
    }
    assert encoder.default(o) == o



# Generated at 2022-06-11 21:00:02.472960
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == "null"
    assert _ExtendedEncoder().encode([]) == "[]"
    assert _ExtendedEncoder().encode({}) == "{}"
    assert _ExtendedEncoder().encode(datetime(year=1980, month=1, day=1)) == "315532800.0"
    assert _ExtendedEncoder().encode(datetime(year=2019, month=1, day=1, hour=1, minute=2, second=3, microsecond=4, tzinfo=timezone.utc)) == "1546372723.000004"

# Generated at 2022-06-11 21:00:15.431429
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ExtendedEncoder = _ExtendedEncoder()

    # Collection
    assert ExtendedEncoder.encode({}) == '{}'
    assert ExtendedEncoder.encode([]) == '[]'
    assert ExtendedEncoder.encode({'a': [1, 2, 3], 'b': {'c': 4}}) == '{"a": [1, 2, 3], "b": {"c": 4}}'
    assert ExtendedEncoder.encode({'a': [1, 2, 3], 'b': {'c': {'d': 5}}}) == '{"a": [1, 2, 3], "b": {"c": {"d": 5}}}'

    # datetime
    assert ExtendedEncoder.encode(datetime(2020, 1, 1)) == '1577836800.0'

# Generated at 2022-06-11 21:00:15.951973
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass



# Generated at 2022-06-11 21:00:22.708534
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """Unit test for constructor of class _ExtendedEncoder"""
    obj = type('obj', (object,), {
        'attr': list(range(10)),
        'attr2': range(20),
        'attr3': {'a': 1, 'b': 2},
        'attr4': {1, 2, 3},
        'attr5': UUID('3f3b3a59-7c96-4a2a-a1e2-2f9cae1f948e'),
        'attr6': Enum('Enum', 'a b c'),
        'attr7': Decimal('3.1415'),
    })
    obj2 = type('obj2', (object,), {
        'attr': {'a': 'b'},
        'attr2': set(range(10)),
    })
   

# Generated at 2022-06-11 21:00:30.242075
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    sut = _ExtendedEncoder()
    # it should be an instance of json.JSONEncoder
    assert isinstance(sut, json.JSONEncoder)
    # it should handle collections
    assert sut.default({'a': 'b'}) == {'a': 'b'}
    assert sut.default([1, 2, 3]) == [1, 2, 3]
    # it should handle datetime
    assert sut.default(datetime.fromtimestamp(1, timezone.utc)) == 1.0
    # it should handle uuid

# Generated at 2022-06-11 21:00:40.858096
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(1, cls=_ExtendedEncoder) == '1'
    assert json.dumps([1, 2], cls=_ExtendedEncoder) == '[1, 2]'
    assert json.dumps({"a": 1, "b": 2}, cls=_ExtendedEncoder) == '{"a": 1, "b": 2}'
    assert json.dumps("hello", cls=_ExtendedEncoder) == '"hello"'
    assert json.dumps(True, cls=_ExtendedEncoder) == 'true'
    assert json.dumps(False, cls=_ExtendedEncoder) == 'false'
    assert json.dumps(None, cls=_ExtendedEncoder) == 'null'

# Generated at 2022-06-11 21:00:49.504632
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"key": "val"}) == '{"key": "val"}'
    assert _ExtendedEncoder().encode(["val"]) == '["val"]'
    assert _ExtendedEncoder().encode("val") == '"val"'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode({"key": datetime.fromtimestamp(0, tz=timezone.utc)}) == '{"key": 0}'

# Generated at 2022-06-11 21:00:52.025457
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    class TestXXX:
        pass
    encoder = _ExtendedEncoder()
    test = TestXXX()
    assert encoder.default(test) == test



# Generated at 2022-06-11 21:01:01.146403
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(
        datetime(1900, 1, 1, tzinfo=timezone.utc), cls=_ExtendedEncoder
    ) == '-2208988800'
    assert json.dumps(
        {'foo': datetime(1900, 1, 1, tzinfo=timezone.utc)}, cls=_ExtendedEncoder
    ) == '{"foo": -2208988800}'
    assert json.dumps(
        [datetime(1900, 1, 1, tzinfo=timezone.utc)], cls=_ExtendedEncoder
    ) == '[-2208988800]'

# Generated at 2022-06-11 21:01:11.717088
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    default_encoder = json.JSONEncoder()
    extended_encoder = _ExtendedEncoder()
    assert type(default_encoder.default(list())) != type(list())
    assert type(default_encoder.default(dict())) != type(dict())
    assert extended_encoder.default(list()) == list()
    assert extended_encoder.default(dict()) == dict()
    assert default_encoder.default(datetime.now()) == default_encoder.default(datetime.now().timestamp())
    assert extended_encoder.default(datetime.now()) == datetime.now().timestamp()

# Generated at 2022-06-11 21:02:13.542538
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(object()) == '<object object at 0x0>'
    assert encoder.default(datetime(2015, 1, 1)) == 1420070400.0
    assert encoder.default(Enum("Enum", {"x": 1})) == 1
    assert encoder.default(Decimal("1.234")) == "1.234"
    assert encoder.default(Decimal("-1.234")) == "-1.234"
    assert encoder.default(UUID("00000000-0000-0000-0000-000000000000")) == "00000000-0000-0000-0000-000000000000"



# Generated at 2022-06-11 21:02:23.292760
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    def _test_default(o, expected):
        j = _ExtendedEncoder().default(o)
        assert j == expected

    _test_default(datetime(1970, 1, 1, 0, 0, 0), 0.0)
    _test_default(datetime(1970, 1, 1, 0, 0, 1, 1), 1.000001)
    _test_default(UUID('00000000-0000-0000-0000-000000000000'), '00000000-0000-0000-0000-000000000000')
    _test_default(UUID('00000000-0000-0000-0000-000000000001'), '00000000-0000-0000-0000-000000000001')
    _test_default(Enum('Enum', 'one two three'), 'one')



# Generated at 2022-06-11 21:02:28.953595
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Arrange
    d = {'name': 'Travis', 'age': 30, 'employment': 'Walmart'}
    lst = ['Travis', 30, 'Walmart']
    t = datetime.now(timezone.utc)
    u = UUID('b5c5eec6-b971-41a1-9c2b-1a3b8e07de3f')
    e = Enum('Enum', 'zero one two')
    dec = Decimal('1.23456789')
    # Act
    d_encoded = json.dumps(d, cls=_ExtendedEncoder)
    lst_encoded = json.dumps(lst, cls=_ExtendedEncoder)

# Generated at 2022-06-11 21:02:37.176791
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default('abc') == 'abc'
    assert _ExtendedEncoder().default(10) == 10
    assert _ExtendedEncoder().default(10.5) == 10.5
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False

    assert _ExtendedEncoder().default({'a': 'b'}) == {'a': 'b'}
    assert _ExtendedEncoder().default(['a', 'b']) == ['a', 'b']
    assert _ExtendedEncoder().default({'a', 'b'}) == ['a', 'b']


# Generated at 2022-06-11 21:02:38.949519
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = _ExtendedEncoder()
    assert isinstance(o.encode(datetime.utcnow()), str)



# Generated at 2022-06-11 21:02:39.788679
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-11 21:02:46.343097
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert '[]' == enc.encode([])
    assert '{}' == enc.encode({})
    assert json.dumps({"Test": "test"}, cls=_ExtendedEncoder) == '{"Test":"test"}'
    assert json.dumps([{"Test": "test"}], cls=_ExtendedEncoder) == '[{"Test":"test"}]'
    assert json.dumps([1, 'abc'], cls=_ExtendedEncoder) == '[1,"abc"]'
    assert json.dumps([1, 1.1, 'abc', [1, 2, 3]], cls=_ExtendedEncoder) == '[1,1.1,"abc",[1,2,3]]'

# Generated at 2022-06-11 21:02:53.227335
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    j = _ExtendedEncoder(indent=True).encode({})
    assert j == "{}"
    j = _ExtendedEncoder(indent=True).encode([1, 2, 3])
    assert j == "[\n    1,\n    2,\n    3\n]"
    j = _ExtendedEncoder(indent=True).encode(datetime.utcnow())
    assert j != "{}"
    j = _ExtendedEncoder(indent=True).encode(UUID("111e0f62-aff2-11e8-9fe6-0800200c9a66"))
    assert j == "\"111e0f62-aff2-11e8-9fe6-0800200c9a66\""
    j = _ExtendedEncoder(indent=True).en

# Generated at 2022-06-11 21:02:59.821095
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, "a"]) == [1, "a"]
    assert encoder.default({"a": 1}) == {"a": 1}
    assert encoder.default(datetime.now()) == datetime.now().timestamp()
    assert encoder.default(UUID("05d6de2a-a0aa-4330-b7c1-a5b5e5b5843e")) == "05d6de2a-a0aa-4330-b7c1-a5b5e5b5843e"
    assert encoder.default(Decimal(1.3)) == "1.3"
    assert encoder.default((1, 2, 3)) == [1, 2, 3]

# Generated at 2022-06-11 21:03:06.962332
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # mypy: ignore
    assert json.dumps(['a', 'b', 'c'], cls=_ExtendedEncoder) == '["a", "b", "c"]'
    assert json.dumps({'a': 1, 'b': 2, 'c': 3}, cls=_ExtendedEncoder) == '{"a": 1, "b": 2, "c": 3}'
    assert json.dumps(datetime(2019, 9, 1, 18, 0, 0, 0, timezone.utc), cls=_ExtendedEncoder) == '1567345600.0'