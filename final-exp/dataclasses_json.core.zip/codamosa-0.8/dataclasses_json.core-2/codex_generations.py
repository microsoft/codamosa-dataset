

# Generated at 2022-06-11 20:54:41.739871
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # noinspection PyUnresolvedReferences
    from datetime import datetime  # type: ignore
    d = datetime.now()
    p = _ExtendedEncoder().encode(d)
    assert isinstance(json.loads(p), float)



# Generated at 2022-06-11 20:54:44.045327
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Create an instance of _ExtendedEncoder class
    _ExtendedEncoder()


# Generated at 2022-06-11 20:54:52.382434
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) is None
    assert _ExtendedEncoder().encode(MISSING) is None
    assert _ExtendedEncoder().encode([]) == []
    assert _ExtendedEncoder().encode([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().encode({}) == {}
    assert _ExtendedEncoder().encode({'a': 1}) == {'a': 1}
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == 1595342049

# Generated at 2022-06-11 20:54:56.490458
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now())
    assert _ExtendedEncoder().default(UUID('57d4e4db-4ba4-4d4b-a4c8-a94ffc809b0e'))


# Generated at 2022-06-11 20:55:02.770730
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        _ExtendedEncoder().encode({'a': 1})
        _ExtendedEncoder().encode([1])
        _ExtendedEncoder().encode({1, 2, 3})
        _ExtendedEncoder().encode(datetime.utcnow())
        _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000'))

        assert False
    except Exception:
        assert True



# Generated at 2022-06-11 20:55:07.347867
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = datetime.now(tz=timezone.utc)
    encoder = _ExtendedEncoder()
    encoded = encoder.encode({'a': o})
    decoded = json.loads(encoded)
    assert o.timestamp() == decoded['a']
    assert UUID('12345678123456781234567812345678') == json.loads('{"a": "12345678-1234-5678-1234-567812345678"}',cls=_ExtendedDecoder)['a']


# Generated at 2022-06-11 20:55:17.469232
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder(sort_keys = False, ensure_ascii = False)
    assert encoder.encode(tuple([1, 2])) == '[1, 2]'
    assert encoder.encode(set([1, 2])) == '[1, 2]'
    assert encoder.encode(dict(a = 3, b = 4)) == '{"a": 3, "b": 4}'
    assert encoder.encode(EnumClass.value_a) == '"value_a"'
    assert encoder.encode(Decimal(1.5)) == '"1.5"'
    assert encoder.encode(datetime(2020, 2, 25, 10, 55, 6, 123456, timezone.utc)) == 1603426506.123456


# Generated at 2022-06-11 20:55:27.962916
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(dict()) == dict()
    assert encoder.default([]) == []
    assert encoder.default(set()) == list(set())
    assert encoder.default(frozenset()) == list(frozenset())
    test_datetime = datetime(2020, 1, 1, 0, 0, tzinfo=timezone.utc)
    assert encoder.default(test_datetime) == test_datetime.timestamp()
    test_uuid = UUID('1a3f1d3c-a911-4a3c-b137-6b3d6eb924cf')
    assert encoder.default(test_uuid) == str(test_uuid)
    test_enum = cfg.ORDER


# Generated at 2022-06-11 20:55:32.075415
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default("foo") == "foo"
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default(True) is True
    assert encoder.default(None) is None
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}



# Generated at 2022-06-11 20:55:38.080738
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime(year=2020, month=8, day=15,
                                    tzinfo=timezone.utc)) == 1597478400
    assert encoder.default(UUID('c9bf9e57-1685-4c89-bafb-ff5af830be8a')) \
        == "c9bf9e57-1685-4c89-bafb-ff5af830be8a"



# Generated at 2022-06-11 20:56:07.896399
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import pytest
    from datetime import datetime
    from decimal import Decimal
    from enum import Enum
    import json
    from uuid import UUID
    from dataclasses_json.utils import _is_new_type

    def _is_collection(o) -> bool:
        return _isinstance_safe(o, Collection)

    def _is_mapping(o) -> bool:
        return _isinstance_safe(o, Mapping)

    def _is_optional(o) -> bool:
        from typing import Any, Union, _GenericAlias
        if isinstance(o, type):
            o = get_type_hints(o)
        if (isinstance(o, _GenericAlias)
                and not isinstance(o, type)
                and o.__origin__ == Union):
            o = o.__

# Generated at 2022-06-11 20:56:11.792133
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default(datetime.now())
    _ExtendedEncoder().default(datetime.now(timezone.utc))
    _ExtendedEncoder().default(UUID('4e17c26a-1cb8-4b20-a7a6-e825eaa44b36'))
    _ExtendedEncoder().default(True)



# Generated at 2022-06-11 20:56:15.274092
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    complex_json = {[1, 2, 3] : {'a' : 3, 'b' : 5}}
    with pytest.raises(TypeError):
        _ExtendedEncoder().default(complex_json)



# Generated at 2022-06-11 20:56:25.069291
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ec = _ExtendedEncoder()
    assert ec.default(None) is None
    assert ec.default(0) == 0
    assert ec.default(0.1) == 0.1
    assert ec.default(True) is True
    assert ec.default("abc") == "abc"
    assert ec.default({"abc": "test"}) == {"abc": "test"}
    assert ec.default(["abc"]) == ["abc"]
    u = UUID("12345678-1234-1234-1234-123456789012")
    assert ec.default(u) == "12345678-1234-1234-1234-123456789012"
    d = datetime(1981, 1, 1, 12, 0, 0)
    assert ec.default(d) == 346630400.0
   

# Generated at 2022-06-11 20:56:33.022366
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2]) == "[1, 2]"
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) in ('1482706075.286', '1482706075.286000')



# Generated at 2022-06-11 20:56:42.029714
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    class TestClass:
        pass

    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(["a", "b", "c"]) == ["a", "b", "c"]
    assert encoder.default({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert encoder.default(TestClass()) == '{}'
    assert encoder.default(datetime(2017, 12, 29, tzinfo=timezone.utc)) == 1514540800

# Generated at 2022-06-11 20:56:43.262002
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-11 20:56:53.618468
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(Decimal("1000000000000000000")) == "1000000000000000000"
    assert _ExtendedEncoder().default(Decimal("1.000000000000000000")) == "1.000000000000000000"
    assert _ExtendedEncoder().default(Decimal("100")) == "100"
    assert _ExtendedEncoder().default(Decimal("100.0")) == "100.0"
    assert _ExtendedEncoder().default(Decimal("0")) == "0"
    assert _ExtendedEncoder().default(Decimal("0.0")) == "0.0"

# The function "assert_same_encoder_and_decoder_types" is for unit test of primitive types
# in the _ExtendedEncoder and _ExtendedDecoder.

# Generated at 2022-06-11 20:57:04.982900
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'a': 'b', 'c': 'd'}) == {'a': 'b', 'c': 'd'}
    now = datetime.now(timezone.utc)
    assert _ExtendedEncoder().default(now) == now.timestamp()
    uuid_str = '1d8fb8ca-f5e9-4d25-a4c4-f4d4b4c7b4a4'
    assert _ExtendedEncoder().default(UUID(uuid_str)) == uuid_str
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'



# Generated at 2022-06-11 20:57:11.943666
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(dict(a=1)) == {"a": 1}
    assert _ExtendedEncoder().default(list(range(3))) == [0, 1, 2]
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == \
        datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('1234-abcd-ef56-7890')) == \
        '1234-abcd-ef56-7890'
    assert _ExtendedEncoder().default(Decimal(2)) == '2'



# Generated at 2022-06-11 20:57:39.507082
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = json.dumps(list(range(3)), cls=_ExtendedEncoder)
    assert enc == '[0, 1, 2]'
    now = datetime.utcnow()
    enc = json.dumps(now, cls=_ExtendedEncoder)
    assert enc == str(now.timestamp())
    enc = json.dumps(UUID('{123e4567-e89b-12d3-a456-426655440000}'), cls=_ExtendedEncoder)
    assert enc == '"123e4567-e89b-12d3-a456-426655440000"'
    enc = json.dumps(Decimal('0.123'), cls=_ExtendedEncoder)
    assert enc == '"0.123"'



# Generated at 2022-06-11 20:57:49.443738
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import pytest

    with pytest.raises(TypeError):
        json.dumps(datetime.now(), cls=_ExtendedEncoder)
        json.dumps(UUID('1e7cebfc-d400-4c66-ad00-f746c3dc78e9'), cls=_ExtendedEncoder)
        json.dumps(UUID, cls=_ExtendedEncoder)
        json.dumps(Decimal(1.23), cls=_ExtendedEncoder)
        json.dumps(Decimal, cls=_ExtendedEncoder)
        json.dumps(cfg.EnumEncoder(1), cls=_ExtendedEncoder)
        json.dumps(cfg.EnumEncoder, cls=_ExtendedEncoder)



# Generated at 2022-06-11 20:58:00.823439
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(MISSING) == MISSING
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default(timezone.utc) == "UTC"
    assert _ExtendedEncoder().default(Decimal('1.0')) == '1.0'
    assert _ExtendedEncoder().default([1]) == [1]
    assert _ExtendedEncoder().default(UUID('8808feb7-cad2-4d3a-a8a8-c7f3155d933d')) == '8808feb7-cad2-4d3a-a8a8-c7f3155d933d'
   

# Generated at 2022-06-11 20:58:06.531688
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.loads(_ExtendedEncoder().encode([1, 2, 3])) == [1, 2, 3]
    assert json.loads(_ExtendedEncoder().encode((1, 2, 3))) == (1, 2, 3)
    assert json.loads(_ExtendedEncoder().encode({'a': 1})) == {'a': 1}
    assert json.loads(_ExtendedEncoder().encode({1, 2, 3})) == {1, 2, 3}
    assert json.loads(_ExtendedEncoder().encode(datetime(2019, 1, 1))) == 1546437200.0
    assert json.loads(_ExtendedEncoder().encode(Enum('b', 'b'))) == 'b'

# Generated at 2022-06-11 20:58:15.576686
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():

    o = range(0, 10)
    assert _ExtendedEncoder().encode(o) == '[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]'
    o = (1, 2, 3)
    assert _ExtendedEncoder().encode(o) == '[1, 2, 3]'
    # Test Mapping
    o = {'a':1, 'b':2}
    assert _ExtendedEncoder().encode(o) == '{"a": 1, "b": 2}'
    # Test datetime
    o = datetime(2018, 1, 1, tzinfo=timezone.utc)
    assert _ExtendedEncoder().encode(o) == '1.5147648001e+09'
    # Test UUID
    o = UUID(int=0)

# Generated at 2022-06-11 20:58:23.456112
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default({1, 2, 3}) == [1, 2, 3]
    assert encoder.default(datetime(1970, 1, 1, 0, 0, 0, 0)) == 0
    assert encoder.default(datetime(1970, 1, 1, 0, 0, 0, 0, tzinfo=timezone.utc)) == 0
    assert encoder.default(UUID(int=0)) == '00000000-0000-0000-0000-000000000000'


# Generated at 2022-06-11 20:58:33.792504
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

# Generated at 2022-06-11 20:58:37.130905
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({datetime.now(): [1]})
    assert _ExtendedEncoder().encode(1.0)
    assert _ExtendedEncoder().encode(Decimal('1'))
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000'))


# Generated at 2022-06-11 20:58:46.275997
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import sys
    import json

    def _assert(obj, result_json):
        encoder = _ExtendedEncoder()
        json_result = encoder.encode(obj)
        assert json_result == result_json

    def _assert_default(obj):
        _assert(obj, 'null')

    # Test string
    _assert('abc', '"abc"')
    # Test int
    _assert(1, '1')
    # Test float
    _assert(1.2, '1.2')
    # Test bool
    _assert(True, 'true')
    # Test None
    _assert(None, 'null')
    # Test collection
    _assert([1, 2, 3], '[1, 2, 3]')

# Generated at 2022-06-11 20:58:54.787306
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ee = _ExtendedEncoder()
    assert ee.default(1) == 1
    assert ee.default(1.0) == 1.0
    assert ee.default(10000000000000000) == 10000000000000000
    assert ee.default(True) == True
    assert ee.default(datetime(2002, 12, 25, 12, 30, 10, 100, tzinfo=timezone.utc)) == 1019586610.1
    assert ee.default(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'
    assert ee.default(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert ee

# Generated at 2022-06-11 20:59:45.416500
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now()) == 'null'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == 'null'
    assert _ExtendedEncoder().encode(Decimal('0.0')) == 'null'
    assert json.loads(_ExtendedEncoder().encode([1, 2, 3])) == [1, 2, 3]
    assert json.loads(_ExtendedEncoder().encode({1: 2, 3: 4})) == {'1': 2, '3': 4}
    assert json.loads(_ExtendedEncoder().encode(True)) == True
    assert json.loads(_ExtendedEncoder().encode(False)) == False



# Generated at 2022-06-11 20:59:55.042472
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    JSONEncoder = _ExtendedEncoder()
    assert isinstance(JSONEncoder.default(set()), list)
    assert isinstance(JSONEncoder.default( {}), dict)
    assert isinstance(JSONEncoder.default(None), type(None))
    assert JSONEncoder.default(2) == 2
    assert JSONEncoder.default(1.0) == 1.0
    assert JSONEncoder.default(False) == False
    assert JSONEncoder.default({"a": 1, "b": "2"}) == {"a": 1, "b": '2'}
    assert JSONEncoder.default({"a": datetime.now()}) == {"a": JSONEncoder.default(datetime.now())}
    assert isinstance(JSONEncoder.default(datetime.now()), float)
    assert JSONEncoder

# Generated at 2022-06-11 20:59:56.332191
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder().default(MISSING)
    assert result == MISSING



# Generated at 2022-06-11 21:00:02.408216
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(5) == 5
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default([(1, 2), (3, 4)]) == {1: 2, 3: 4}
    assert _ExtendedEncoder().default(Decimal("2.3")) == "2.3"
    d = datetime.fromtimestamp(1, timezone.utc)
    assert _ExtendedEncoder().default(d) == 1.0



# Generated at 2022-06-11 21:00:15.339973
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(list(range(10))) == list(range(10))
    assert encoder.default(tuple(range(10))) == list(range(10))
    assert encoder.default(dict(a=1, b=2, c=3)) == {'a': 1, 'b': 2, 'c': 3}
    assert encoder.default(set(range(10))) == list(range(10))
    assert encoder.default(frozenset(range(10))) == list(range(10))

    assert encoder.default(datetime(2019, 4, 14, 15, 34, 0)) == 1555048440

# Generated at 2022-06-11 21:00:17.474528
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    result = _ExtendedEncoder().default({'a': 'b', 'c': 'd'})
    assert result == {'a': 'b', 'c': 'd'}



# Generated at 2022-06-11 21:00:23.406212
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default(
        datetime(year=2019, month=4, day=20, tzinfo=timezone.utc
                 ).replace(microsecond=54321)) == 1558099445.054321
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(Enum('Enum', 'A')) == 'A'
    assert _ExtendedEncoder().default(Decimal('3.14')) == '3.14'
    assert _ExtendedEncoder().default(None) == None

# Generated at 2022-06-11 21:00:30.541153
# Unit test for method default of class _ExtendedEncoder

# Generated at 2022-06-11 21:00:40.586793
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def check(o, expected):
        encoder = _ExtendedEncoder()
        actual = encoder.default(o)
        assert actual == expected
    check(['a', 'b'], ['a', 'b'])
    check({'a': 'b'}, {'a': 'b'})
    check(datetime(2020, 1, 2, 3, 4, 5, 6, timezone.utc),
          1577945045.000006)
    check(UUID('{12345678-1234-5678-1234-567812345678}'),
          '12345678123456781234567812345678')
    check(Decimal('1.23'), '1.23')
    check(None, None)



# Generated at 2022-06-11 21:00:47.821429
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({"Hello": "World"}) == {"Hello": "World"}
    now = datetime.now()
    assert _ExtendedEncoder().default(now) == now.timestamp()
    make_uuid = lambda: str(UUID('d0c8ee98-090b-4d61-b45f-54f7a9e62a1d'))
    assert _ExtendedEncoder().default(make_uuid()) == make_uuid()
    assert _ExtendedEncoder().default(Decimal('1.2')) == '1.2'


# Generated at 2022-06-11 21:02:37.905478
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ExtendedEncoder = _ExtendedEncoder()
    assert ExtendedEncoder.default(datetime.utcnow()) is not None


# Generated at 2022-06-11 21:02:46.867882
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(
        datetime(2013, 1, 1, 12, 0, 0, tzinfo=timezone.utc)) == 1356994800.0
    assert encoder.default(datetime(2013, 1, 1, 12, 0, 0)) == 1356994800.0
    assert encoder.default(set([42])) == [42]
    assert encoder.default({42: 'a'}) == {42: 'a'}
    assert encoder.default(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal(42.0)) == '42'

# Generated at 2022-06-11 21:02:53.619721
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('12345678-1234-5678-1234-567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(Decimal('3.14')) == '3.14'


# Generated at 2022-06-11 21:03:00.111396
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'hello': 'world'}) == '{"hello": "world"}'
    assert _ExtendedEncoder().encode(['a', 'b']) == '["a", "b"]'
    assert _ExtendedEncoder().encode(('a', 'b')) == '["a", "b"]'
    assert _ExtendedEncoder().encode({'hello': ['a', 'b']}) == '{"hello": ["a", "b"]}'
    assert _ExtendedEncoder().encode(b'{"hello": "world"}') == '"eyJoZWxsbyI6ICJ3b3JsZCJ9"'

# Generated at 2022-06-11 21:03:07.120504
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert_json_equal(_ExtendedEncoder().encode([]), "[]")
    assert_json_equal(_ExtendedEncoder().encode({}), "{}")
    assert_json_equal(_ExtendedEncoder().encode([1, 2, 3]), "[1, 2, 3]")
    assert_json_equal(_ExtendedEncoder().encode({"a": 1, "b": 2}),
                      '{"a": 1, "b": 2}')
    now = datetime.now(tz=timezone.utc)
    now_timestamp = now.timestamp()
    assert _ExtendedEncoder().encode(now) == now_timestamp

# Generated at 2022-06-11 21:03:16.762736
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ctx = {
        'dict': dict(a=1),
        'list': [1, 2, 3],
        'set': {1, 2, 'a'},
        'datetime': datetime(2018, 12, 14, 14, 0, 3, tzinfo=timezone.utc),
        'uuid': UUID('{a2a42ac2-dca8-452c-b1b0-7a3a1aee8d87}'),
        'class Foo: pass': type('Foo', (), {})(),
        'Enum': cfg.enj .EnumValue,
        'decimal': Decimal('1.23'),
    }
    for k, v in ctx.items():
        r1 = json.dumps(v, cls=_ExtendedEncoder)
        r

# Generated at 2022-06-11 21:03:19.657556
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder(indent=4, ensure_ascii=False, sort_keys=True).encode({"a":1}) == '{\n    "a": 1\n}'


# noinspection PyTypeChecker

# Generated at 2022-06-11 21:03:24.338907
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(
        {'a': [1, 2, 3],
         'b': {'key': 'value'}}
    ) == '''{"a": [1, 2, 3], "b": {"key": "value"}}'''



# Generated at 2022-06-11 21:03:31.305340
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    extended_encoder.default([])
    extended_encoder.default({})
    extended_encoder.default(datetime(2020, 7, 15, 12, 0, 0, tzinfo=timezone.utc))
    extended_encoder.default(UUID('00000000-0000-0000-0000-000000000000'))
    extended_encoder.default(Decimal('12.345'))



# Generated at 2022-06-11 21:03:40.683670
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_encoder = _ExtendedEncoder()
    test_list = ['abc', 'abc']
    assert json_encoder.default(test_list) == ['abc', 'abc']
    test_list = ['abc', 'abc']
    assert json_encoder.default(test_list) == ['abc', 'abc']
    test_date = datetime(2020, 5, 21, 15, 00, 00, tzinfo=timezone.utc)
    assert json_encoder.default(test_date) == 1590009600.0
    test_uuid = UUID('d3b6c3fb-a7e6-42d9-9703-28b60fdd587a')