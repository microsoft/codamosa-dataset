

# Generated at 2022-06-11 20:54:42.417032
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from json import dumps
    from datetime import timedelta, datetime
    from uuid import UUID
    from decimal import Decimal
    from dataclasses_json.utils import _MISSING
    import enum
    class Animal(enum.Enum):
        cat = "cat"
        dog = "dog"
    test = {'test': _MISSING}
    assert dumps([1, 2, 3], cls=_ExtendedEncoder) == "[1, 2, 3]"
    assert dumps({"one": 1, "two": 2}, cls=_ExtendedEncoder) == \
        '{"one": 1, "two": 2}'
    assert dumps(datetime.now(), cls=_ExtendedEncoder) != \
        'datetime.datetime.now()'

# Generated at 2022-06-11 20:54:51.654427
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()
    o: Any = 1
    assert extended_encoder.default(o) == o
    #
    o = [1]
    assert extended_encoder.default(o) == [1]
    #
    o = (1,)
    assert extended_encoder.default(o) == [1]
    #
    o = {1:2}
    assert extended_encoder.default(o) == {1:2}
    #
    o = frozenset([1])
    assert extended_encoder.default(o) == [1]
    #
    o = datetime.now()
    assert extended_encoder.default(o) == o.timestamp()
    #

# Generated at 2022-06-11 20:55:02.603491
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test the constructor of class _ExtendedEncoder
    encoder = _ExtendedEncoder()
    assert encoder.encode(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert encoder.encode([1, 2, 3]) == '[1, 2, 3]'
    assert encoder.encode(str('abc')) == '"abc"'
    assert encoder.encode(int(1)) == '1'
    assert encoder.encode(float(1.23)) == "1.23"
    assert encoder.encode(bool(True)) == "true"
    assert encoder.encode(None) == "null"
    assert encoder.encode(datetime.now()) == str(datetime.now().timestamp())
    assert encoder.en

# Generated at 2022-06-11 20:55:08.791945
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.loads(_ExtendedEncoder().encode(decimal.Decimal('20.30'))) == json.loads(str(decimal.Decimal('20.30')))
    assert json.loads(_ExtendedEncoder().encode(uuid.uuid4())) == json.loads(str(uuid.uuid4()))
    assert json.loads(_ExtendedEncoder().encode(MyEnum.A)) == json.loads(MyEnum.A.value)
    assert json.loads(_ExtendedEncoder().encode(set())) == json.loads(list(set()))
    assert json.loads(_ExtendedEncoder().encode(frozenset())) == json.loads(list(frozenset()))
    assert json.loads(_ExtendedEncoder().encode({1,2,3}))

# Generated at 2022-06-11 20:55:18.275708
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'

    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode({1: 'a'}) == '{1: "a"}'
    assert _ExtendedEncoder().encode(['a', 1]) == '["a", 1]'
    assert _ExtendedEncoder().encode([1, 'a']) == '[1, "a"]'

    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode('a') == '"a"'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _

# Generated at 2022-06-11 20:55:21.919600
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now()) == json.JSONEncoder().default(datetime.now())

_ExtendedEncoder().default(datetime.now()) == json.JSONEncoder().default(datetime.now())



# Generated at 2022-06-11 20:55:32.323225
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(MISSING) is MISSING
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(0) == 0
    assert _ExtendedEncoder().default(0.0) == 0.0
    assert _ExtendedEncoder().default('') == ''
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

# Generated at 2022-06-11 20:55:42.093598
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test collections
    assert _ExtendedEncoder().default(set()) == list(set())
    assert _ExtendedEncoder().default(range(42)) == list(range(42))
    assert _ExtendedEncoder().default(set(range(42))) == list(set(range(42)))
    assert _ExtendedEncoder().default(dict()) == dict(dict())
    assert _ExtendedEncoder().default(dict(a=1, b=2)) == dict(dict(a=1, b=2))

    # Test datetime
    datetime_now = datetime.now(timezone.utc)
    assert _ExtendedEncoder().default(datetime_now) == datetime_now.timestamp()

    # Test UUID

# Generated at 2022-06-11 20:55:44.225929
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2000, 1, 1)) == '946684800.0'


# Generated at 2022-06-11 20:55:54.212593
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode(set([1, 2, 3])) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(datetime(2019, 3, 15, 12, 22, 31, 100000, timezone.utc)) == '1552648351100.0'

# Generated at 2022-06-11 20:56:21.979246
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1, 2, 3}) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({1: '1', 2: '2', 3: '3'}) == '{"1": "1", "2": "2", "3": "3"}'
    assert _ExtendedEncoder().encode(datetime(2016, 7, 6, 5, 4, 3, 2, timezone.utc)) == '1467772203.000002'
    assert _ExtendedEncoder().encode(UUID('58a14c3e-94e8-11e6-a974-000d3ab9bfe2')) == '"58a14c3e-94e8-11e6-a974-000d3ab9bfe2"'
    assert _

# Generated at 2022-06-11 20:56:24.312341
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': datetime(2017, 2, 1, 7, 33, 0)})



# Generated at 2022-06-11 20:56:28.448174
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder(indent=2)
    result = encoder.encode([1, 2, 3])
    assert result == '[\n  1,\n  2,\n  3\n]'


# Generated at 2022-06-11 20:56:38.027212
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    class MyDatetime(datetime):
        pass

    # noinspection PyTypeChecker
    assert _ExtendedEncoder().default(MyDatetime(2000, 1, 1, 1, 1, 1)) == datetime(2000, 1, 1, 1, 1, 1).timestamp()
    # noinspection PyTypeChecker
    assert _ExtendedEncoder().default(UUID('eee98c9a-5f8a-4ad7-9ab6-5d5a8cde2fc0')) == 'eee98c9a-5f8a-4ad7-9ab6-5d5a8cde2fc0'
    # noinspection PyTypeChecker
    assert _ExtendedEncoder().default(None) is None
    # noinspection PyTypeChecker
    assert _ExtendedEnc

# Generated at 2022-06-11 20:56:44.933363
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import timedelta
    from decimal import Decimal
    from uuid import UUID
    from enum import Enum
    from dataclasses import dataclass

    @dataclass
    class TestDataclass:
        foo: str

    class TestEnum(Enum):
        Foo = 'foo'


# Generated at 2022-06-11 20:56:54.849168
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = dict(a=1, b=2)
    assert _ExtendedEncoder().default(o) == o
    assert _ExtendedEncoder().encode(o) == '{"a": 1, "b": 2}'
    o = [1, 2, 3]
    assert _ExtendedEncoder().default(o) == o
    assert _ExtendedEncoder().encode(o) == '[1, 2, 3]'
    o = datetime(2019, 8, 1, 10, 10, 10, 10, timezone.utc)
    assert _ExtendedEncoder().default(o) == 1564664410.000001
    assert _ExtendedEncoder().encode(o) == '1564664410.000001'

# Generated at 2022-06-11 20:57:06.390392
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    # test cases
    @dataclass
    class Test:
        a: int
    assert '{"a": 1}' == enc.encode(Test(1))
    assert '[1, 2, 3]' == enc.encode([1, 2, 3])
    assert '{"a": 1, "b": 2}' == enc.encode({'a': 1, 'b': 2})
    assert '"str"' == enc.encode('str')
    assert '1' == enc.encode(1)
    assert '1.0' == enc.encode(1.0)
    assert 'true' == enc.encode(True)
    assert 'false' == enc.encode(False)
    assert 'null' == enc.encode(None)
    dt = datetime

# Generated at 2022-06-11 20:57:12.906614
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2019, 1, 1, 11, 0, 0, 0, tzinfo=timezone.utc))=="1546318400.0"
    assert _ExtendedEncoder().encode(UUID('e5ec0d83-a6e9-4f9e-9b95-0df4cc7f4cfc'))=='"e5ec0d83-a6e9-4f9e-9b95-0df4cc7f4cfc"'
    assert _ExtendedEncoder().encode(Enum('Enum', 'a'))==1
    assert _ExtendedEncoder().encode(Decimal('1.50'))=='"1.5"'



# Generated at 2022-06-11 20:57:18.899674
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1,2,3]) == '[1,2,3]'
    assert _ExtendedEncoder().encode({'a':1,'b':2}) == '{"a":1,"b":2}'
    assert _ExtendedEncoder().encode(datetime(2020,1,1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('ef7e0337-78eb-4d2f-8fa1-7aab972a9f7d')) == 'ef7e0337-78eb-4d2f-8fa1-7aab972a9f7d'

# Generated at 2022-06-11 20:57:27.098619
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(list((1, 2))) == '[1, 2]'  # type: ignore
    assert _ExtendedEncoder().encode(dict({1: 2})) == '{"1": 2}'  # type: ignore
    assert _ExtendedEncoder().encode(datetime(2017, 12, 12, tzinfo=timezone.utc)) == '"1513071200.0"'  # type: ignore
    assert _ExtendedEncoder().encode(UUID('1a67e43d-2537-44f8-8fb2-d76c955738f3')) == '"1a67e43d-2537-44f8-8fb2-d76c955738f3"'  # type: ignore

# Generated at 2022-06-11 20:57:54.242620
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    l = [1, 2, 3]
    assert encoder.default(l) == l
    d = {"one": 1, "two": 2}
    assert encoder.default(d) == d
    datetime_now = datetime.now()
    dt = datetime_now.timestamp()
    v = encoder.default(datetime_now)
    assert type(v) is float
    # Floating point is not precise enough to compare 2 timestamps directly
    # So we need to convert the value of v to datetime and compare with datetime_now
    assert datetime.fromtimestamp(v) == datetime.fromtimestamp(dt)

# Generated at 2022-06-11 20:58:03.841861
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    t = datetime.now()
    u = UUID('e5d8850d-11cc-4d4c-8bf4-aac2acc2da27')
    x = Decimal('1.1')
    y = x + 1.1

    assert json.dumps(t, cls=_ExtendedEncoder).replace('"', '') == str(t)
    assert json.dumps(u, cls=_ExtendedEncoder).replace('"', '') == str(u)
    assert json.dumps(x, cls=_ExtendedEncoder).replace('"', '') == str(x)
    assert json.dumps(y, cls=_ExtendedEncoder).replace('"', '') == str(y)

# Generated at 2022-06-11 20:58:10.872039
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import unittest.mock as mock
    my_encoder = _ExtendedEncoder()
    my_encoder._iterencode = mock.Mock()
    my_encoder._iterencode.return_value = iter(['["a","b","c"]'])
    result = my_encoder.encode(['a', 'b', 'c'])
    assert result == '["a","b","c"]'
    my_encoder._iterencode.assert_called_once_with(['a', 'b', 'c'], {})


# Generated at 2022-06-11 20:58:12.286460
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(['abcd', 123]) == json.dumps(['abcd', 123])



# Generated at 2022-06-11 20:58:13.128741
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-11 20:58:22.265287
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(1) == 1
    assert encoder.default("a") == "a"
    assert encoder.default(True) == True
    assert encoder.default(None) == None
    assert encoder.default(datetime(2018, 12, 12, 12, 12, 12, 0, timezone.utc).replace(tzinfo=None)) == 1544561932.0
    assert encoder.default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert encoder.default

# Generated at 2022-06-11 20:58:33.368252
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(OrderedDict([('a', 3), ('b', 2), ('c', 1)])) == '{"a": 3, "b": 2, "c": 1}'
    assert _ExtendedEncoder().encode({'a': 3, 'b': 2, 'c': 1}) == '{"a": 3, "b": 2, "c": 1}'
    assert _ExtendedEncoder().encode(['a', [3, 2], 1]) == '["a", [3, 2], 1]'
    assert _ExtendedEncoder().encode(datetime(2001, 11, 23, 12, 34, 56)) == '1005857696.0'

# Generated at 2022-06-11 20:58:34.512617
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default(datetime(2019, 1, 1))



# Generated at 2022-06-11 20:58:41.691841
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(10) == 10
    assert _ExtendedEncoder().default(0.1) == 0.1
    assert _ExtendedEncoder().default(UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8')) == '6ba7b810-9dad-11d1-80b4-00c04fd430c8'
    assert _ExtendedEncoder().default({'k': 'v'}) == {'k': 'v'}
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-11 20:58:52.187797
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import datetime
    from dataclasses import dataclass, field
    from enum import Enum
    from decimal import Decimal
    from uuid import UUID
    @dataclass
    class Currencies(Enum):
        USD = 'USD'
        EUR = 'EUR'
    @dataclass
    class Item:
        id: UUID
        currency: Currencies
        price: Decimal
        valid_until: datetime.datetime
        name: str
        data: dict = field(default_factory=dict)

# Generated at 2022-06-11 20:59:21.309080
# Unit test for constructor of class _ExtendedEncoder

# Generated at 2022-06-11 20:59:31.001656
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    expected_json = '[1, 2, 3]'
    json_from_list = json.dumps([1, 2, 3], cls=_ExtendedEncoder)
    assert json_from_list == expected_json

    expected_json = '{"a": "1", "b": "2", "c": "3"}'
    json_from_dict = json.dumps({"a": 1, "b": 2, "c": 3}, cls=_ExtendedEncoder)
    assert json_from_dict == expected_json

    expected_json = str(datetime.now(tz=timezone.utc).timestamp())
    json_from_datetime = json.dumps(datetime.now(tz=timezone.utc),
                                    cls=_ExtendedEncoder)
    assert json_from_datetime

# Generated at 2022-06-11 20:59:32.405564
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(Decimal('1.0')) == '1.0'
    assert _ExtendedEncoder().default(set([1, 2, 3])) == [1, 2, 3]



# Generated at 2022-06-11 20:59:38.156910
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(False) == 'false'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(0) == '0'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(0.1) == '0.1'
    assert _ExtendedEncoder().encode('string') == '"string"'
    assert _ExtendedEncoder().encode((1, 2)) == '[1, 2]'
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEnc

# Generated at 2022-06-11 20:59:47.142291
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    data = [
        dict(o=None, etalon=None),
        dict(o=1, etalon=1),
        dict(o=dict(a=1), etalon=dict(a=1)),
        dict(o=list(range(1, 10)), etalon=list(range(1, 10))),
        dict(o=UUID('24b76f03-c842-4a16-ae98-53b7e8f43e2e'), etalon='24b76f03-c842-4a16-ae98-53b7e8f43e2e'),
        dict(o=datetime.now(timezone.utc), etalon=None)
    ]
    for d in data:
        assert _ExtendedEncoder().default(d['o']) == d['etalon']

# Generated at 2022-06-11 20:59:48.590251
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-11 20:59:56.569744
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode(UUID('6e7f6d83-2c08-4483-946c-e6d1aa6f5c63')) == '"6e7f6d83-2c08-4483-946c-e6d1aa6f5c63"'
    now_dt = datetime.now(timezone.utc)
    now_str = _ExtendedEncoder().encode(now_dt)
    assert now_str == str(now_dt.timestamp())

    class Foo(Enum):
        BAR = 1


# Generated at 2022-06-11 21:00:04.229906
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

    assert encoder.default(['abc']) == ['abc']
    assert encoder.default({'abc': 'def'}) == {'abc': 'def'}

    dt = datetime(2018, 1, 1, 12, 34, 56, 789, timezone.utc)
    assert encoder.default(dt) == dt.timestamp()

    uuid = UUID('12345678123456781234567812345678')
    assert encoder.default(uuid) == '12345678123456781234567812345678'

    enu = Enum('Color', 'red blue')
    assert encoder.default(enu.red) == 0

    assert encoder.default(Decimal('1.23')) == '1.23'



# Generated at 2022-06-11 21:00:16.608952
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2], [3]) == "[1, 2]"
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}, {'b': 1, 'a': 2}) == '{"a": 1, "b": 2}'
    datetime_test = datetime(2019, 2, 4, 16, 30, 10, tzinfo=timezone.utc)
    assert _ExtendedEncoder().encode(datetime_test) == '1549395010.0'
    assert _ExtendedEncoder().encode(UUID('1234')) == '"1234"'
    assert _ExtendedEncoder().encode(Enum('abc', 'abc')) == '"abc"'
    assert _ExtendedEncoder().encode(Decimal('1.23'))

# Generated at 2022-06-11 21:00:23.041975
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1: 2}) == '{"1": 2}', "Failed to encode a dict instance"
    assert _ExtendedEncoder().encode((1, 2, 3)) == '[1, 2, 3]', "Failed to encode a list instance"
    assert _ExtendedEncoder().encode('1 2 3') == '"1 2 3"', "Failed to encode a str instance"
    assert _ExtendedEncoder().encode(1) == '1', "Failed to encode a int instance"
    assert _ExtendedEncoder().encode(1.1) == '1.1', "Failed to encode a float instance"
    assert _ExtendedEncoder().encode(True) == 'true', "Failed to encode a bool instance"

# Generated at 2022-06-11 21:01:15.200191
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.encode([1, 2, 3]) == '[1, 2, 3]'
    assert encoder.encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert encoder.encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert encoder.encode(UUID('91864f80-98b2-473c-a5d5-630d6a120c21')) == '91864f80-98b2-473c-a5d5-630d6a120c21'


# Generated at 2022-06-11 21:01:21.667015
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert 'null' == json.dumps(None, cls=_ExtendedEncoder)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        assert ('"2019-01-31T23:59:59.999999Z"' ==
                json.dumps(datetime(2019, 1, 31, 23, 59, 59, 999999, timezone.utc),
                           cls=_ExtendedEncoder))
        assert '{"a": "b"}' == json.dumps({'a': 'b'}, cls=_ExtendedEncoder)
        assert '["a", "b"]' == json.dumps(['a', 'b'], cls=_ExtendedEncoder)

# Generated at 2022-06-11 21:01:31.039055
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict(a=1)) == '{"a": 1}'
    assert _ExtendedEncoder().encode([0, 1, 2]) == '[0, 1, 2]'
    assert _ExtendedEncoder().encode(b'name') == '"name"'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == \
        _ExtendedEncoder().encode(datetime.now(timezone.utc).timestamp())


# Generated at 2022-06-11 21:01:32.211279
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(Decimal("42")) == '42'



# Generated at 2022-06-11 21:01:40.739084
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime(2020, 4, 19)) == 1587260800.0
    assert _ExtendedEncoder().default(datetime(2020, 4, 19, tzinfo=timezone.utc)) == 1587260800.0
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default((1, 2, 3)) == [1, 2, 3]
    assert _ExtendedEncoder().default({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-11 21:01:44.031369
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'key': datetime(1970, 1, 1, 0, 0, 0, 0, timezone.utc)}) == \
           _ExtendedEncoder().encode({'key': 0})



# Generated at 2022-06-11 21:01:50.095903
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(dict(key='value')) == dict(key='value')
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(None) == None
    assert encoder.default('string') == 'string'
    assert encoder.default(1) == 1
    assert encoder.default(1.1) == 1.1
    assert encoder.default(datetime(2020, 1, 1,
                                    tzinfo=timezone.utc)) == 1577836800.0



# Generated at 2022-06-11 21:01:58.844540
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps([1, 2, 3], cls=_ExtendedEncoder) == '[1, 2, 3]'
    assert json.dumps({1: 2, 3: 4}, cls=_ExtendedEncoder) == '{"1": 2, "3": 4}'
    assert json.dumps(set([1, 2]), cls=_ExtendedEncoder) == '[1, 2]'
    assert json.dumps(('a', 'b'), cls=_ExtendedEncoder) == '["a", "b"]'
    assert json.dumps('abc', cls=_ExtendedEncoder) == '"abc"'
    assert json.dumps(123, cls=_ExtendedEncoder) == '123'

# Generated at 2022-06-11 21:02:06.687797
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime(2018, 1, 1, 10, 0, 0, tzinfo=timezone.utc)) == 1514764800
    assert encoder.default(UUID('a7d2ca2f-c73e-52ab-b30e-b3d3e9da723b')) == 'a7d2ca2f-c73e-52ab-b30e-b3d3e9da723b'
    assert encoder.default(Decimal('0.1')) == '0.1'
    assert encoder.default({'a':1, 'b':'2'}) == {'a':1, 'b':'2'}

# Generated at 2022-06-11 21:02:08.784150
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder().default(UUID(int=0))
    assert result == '00000000-0000-0000-0000-000000000000'

