

# Generated at 2022-06-11 20:54:47.046638
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from typing import List, Set, Tuple
    def check_equal(o: Any, check_equal_result, cls: type):
        assert _ExtendedEncoder(cls).default(o) == check_equal_result

    check_equal(set({'a', 'b'}), ['a', 'b'], Set[str])
    check_equal(tuple(['a', 'b']), ['a', 'b'], Tuple[str, str])
    check_equal(frozenset({'a', 'b'}), ['a', 'b'], frozenset[str])
    check_equal({'a': 1, 'b': 2}, {'a': 1, 'b': 2}, dict)

# Generated at 2022-06-11 20:54:53.805927
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # noinspection PyTypeChecker
    assert _ExtendedEncoder().encode([1, 'x']) == '[1, "x"]'
    assert _ExtendedEncoder().encode(dict(x=1)) == '{"x": 1}'
    assert _ExtendedEncoder().encode(UUID(int=1)) == '"00000000-0000-0000-0000-000000000001"'


# Generated at 2022-06-11 20:55:03.984553
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses_json.tests.test_decoder import A
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(set([1, 2, 3])) == [1, 2, 3]
    assert _ExtendedEncoder().default({1: 2}) == {1: 2}
    assert _ExtendedEncoder().default(datetime(2019, 1, 1, 12, tzinfo=timezone.utc)) == 1546300800.0
    assert _ExtendedEncoder().default(UUID(bytes=bytes(16))) == '00000000000000000000000000000000'
    assert _ExtendedEncoder().default(Decimal('1.23')) == '1.23'
    assert _ExtendedEncoder().default(A.a) == 1

# Generated at 2022-06-11 20:55:15.048957
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, "simple", "list"]) == \
        '[1, "simple", "list"]'
    assert _ExtendedEncoder().encode(dict(a=1, b="string", c=None, d=1.2)) == \
        '{"a": 1, "b": "string", "c": null, "d": 1.2}'
    assert _ExtendedEncoder().encode(datetime(2020, 5, 14, 15, 7, tzinfo=timezone.utc)) == \
        '1589313220.0' # Value depends on timezone. As we are testing the behaviour of `datetime` irrespective the timezome, it is OK

# Generated at 2022-06-11 20:55:21.680668
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(4) == 4
    assert _ExtendedEncoder().default(4.5) == 4.5
    assert _ExtendedEncoder().default("foo") == "foo"
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert _ExtendedEncoder().default(UUID("123e4567-e89b-12d3-a456-426655440000")) == "123e4567-e89b-12d3-a456-426655440000"
   

# Generated at 2022-06-11 20:55:25.112286
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert cfg.EncoderClass._issubclass_safe(json.JSONEncoder)
    assert _ExtendedEncoder is cfg.EncoderClass
    assert _ExtendedEncoder._issubclass_safe(json.JSONEncoder)


# Generated at 2022-06-11 20:55:27.909783
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    o = [1, 2, 3]
    assert enc.default(o) == [1, 2, 3]

# Generated at 2022-06-11 20:55:36.668135
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().encode(set([1, 2, 3])) == '[1,2,3]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a":1,"b":2}'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1)) == '1577836800'
    assert _ExtendedEncoder().encode(UUID('14b20d9a-95d4-4c4b-a57a-8a4d1b6c1679')) == '"14b20d9a-95d4-4c4b-a57a-8a4d1b6c1679"'
    assert _ExtendedEncoder().encode(Decimal('1')) == '"1"'
    assert _Ext

# Generated at 2022-06-11 20:55:47.209220
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default({}) == {}
    assert encoder.default(set()) == []
    assert encoder.default(frozenset()) == []
    assert encoder.default({1, 2}) == [1, 2]
    assert encoder.default(uuid.uuid4()) == '1d7b6e9c-c34f-4d55-a53b-50a87f951ff4'
    assert encoder.default(datetime(2020, 1, 1)) == 1577880000.0
    assert encoder.default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577880000.0
    assert encoder.default(Decimal('3.14')) == '3.14'
    assert encoder.default

# Generated at 2022-06-11 20:55:56.756113
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    coded = _ExtendedEncoder().encode(defaultdict(int, {'a': 1}))
    assert coded == '{"a": 1}'
    coded = _ExtendedEncoder().encode([1, 2, 3])
    assert coded == '[1, 2, 3]'
    coded = _ExtendedEncoder().encode(datetime(1, 1, 1, 1, 1, 1, 0, timezone.utc))
    assert coded == '-62135596800.0'
    coded = _ExtendedEncoder().encode(UUID('12341234-1234-1234-1234-123456789000'))
    assert coded == '"12341234-1234-1234-1234-123456789000"'

# Generated at 2022-06-11 20:56:39.693955
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.encode([1, 2, 3]) == '[1, 2, 3]'
    assert encoder.encode({'1': 1, '2':2}) == '{"1": 1, "2": 2}'
    assert encoder.encode('test') == '"test"'
    assert encoder.encode(1) == '1'
    assert encoder.encode(1.0) == '1.0'
    assert encoder.encode(True) == 'true'
    assert encoder.encode(None) == 'null'
    assert encoder.encode(datetime.fromtimestamp(int(1520393529))) == '1520393529'

# Generated at 2022-06-11 20:56:41.697590
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'


# Generated at 2022-06-11 20:56:44.497593
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": "hello", "b": 1}) == '{"a": "hello", "b": 1}'



# Generated at 2022-06-11 20:56:48.013516
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # noinspection PyArgumentList
    assert _ExtendedEncoder().default(datetime.now())



# Generated at 2022-06-11 20:56:55.509992
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(123) == 123
    assert _ExtendedEncoder().default(123.0) == 123.0
    assert _ExtendedEncoder().default(123j) == "123j"
    assert _ExtendedEncoder().default("abc") == "abc"
    assert _ExtendedEncoder().default(b"abc") == "abc"
    assert _ExtendedEncoder().default(bytearray(b"abc")) == "abc"
    assert _ExtendedEncoder().default(["abc", 123]) == ["abc", 123]
    assert _ExtendedEncoder().default(("abc", 123)) == ["abc", 123]

# Generated at 2022-06-11 20:57:06.929224
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps(MappingProxyType({'key': 'value'}), cls=_ExtendedEncoder)
    json.dumps(defaultdict(float, foo=1, bar=2), cls=_ExtendedEncoder)
    json.dumps(datetime(2002, 12, 25, tzinfo=timezone.utc), cls=_ExtendedEncoder)
    json.dumps(UUID(int=0), cls=_ExtendedEncoder)
    json.dumps(Decimal('0.000'), cls=_ExtendedEncoder)
    assert json.dumps(42, cls=_ExtendedEncoder) == '42'
    json.dumps('42', cls=_ExtendedEncoder)

# Generated at 2022-06-11 20:57:16.008412
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # noinspection PyTypeChecker
    assert '1' == json.dumps(1, cls=_ExtendedEncoder)
    assert '1.1' == json.dumps(1.1, cls=_ExtendedEncoder)
    assert 'true' == json.dumps(True, cls=_ExtendedEncoder)
    assert 'null' == json.dumps(None, cls=_ExtendedEncoder)
    assert '["a", "b"]' == json.dumps(('a', 'b'), cls=_ExtendedEncoder)
    assert '{"x": "a", "y": "b"}' == json.dumps({'x': 'a', 'y': 'b'}, cls=_ExtendedEncoder)

# Generated at 2022-06-11 20:57:19.972170
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _isinstance_safe(json.dumps({'a': set([1, 2, 3])}, cls=_ExtendedEncoder), str)



# Generated at 2022-06-11 20:57:27.372712
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": [1, 2, 3]}) == '{"a": [1, 2, 3]}'
    assert _ExtendedEncoder().encode({"a": {"1": 2}}) == '{"a": {"1": 2}}'
    assert _ExtendedEncoder().encode({"a": datetime(2020, 1, 1, 0, 0, 0, 0, tzinfo=timezone.utc)}) == '{"a": 1577808000.0}'
    assert _ExtendedEncoder().encode({"a": UUID('{1234567890abcdef1234567890abcdef}')}) == '{"a": "12345678-90ab-cdef-1234-567890abcdef"}'


# Generated at 2022-06-11 20:57:37.379022
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode({'a': datetime(2020, 1, 2, 3, 4, 5, 6, timezone.utc)}) == '{"a": 1577978645.000006}'
    assert _ExtendedEncoder().encode({'a': UUID('d5eac106-db64-49c0-af87-1c06fbf9d9e1')}) == '{"a": "d5eac106-db64-49c0-af87-1c06fbf9d9e1"}'
    class _Enum(Enum):
        A = 4

# Generated at 2022-06-11 20:57:59.707892
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode(None) == 'null'


# Generated at 2022-06-11 20:58:03.128330
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    data = 'hello'
    encoded = encoder.encode(data)
    decoded = json.loads(encoded)
    assert data == decoded

##############################################################################
# Dataclass -> dict
##############################################################################



# Generated at 2022-06-11 20:58:12.575764
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import datetime
    from uuid import uuid4, UUID
    from enum import Enum
    from decimal import Decimal
    from dataclasses import dataclass
    from dataclasses_json.utils import _is_dataclass_instance
    import json
    import numbers

    # noinspection SpellCheckingInspection
    class HumanInt(int):
        pass
    class HumanEnum(Enum):
        human = 1
    # noinspection SpellCheckingInspection
    @dataclass
    class Human:
        name: str
    class HumanDict(dict):
        pass
    class HumanList(list):
        pass
    class HumanTuple(tuple):
        pass
    encoder_ = _ExtendedEncoder()
    assert encoder_.default([]) == []

# Generated at 2022-06-11 20:58:21.818299
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(['a', 'b', 'c']) == '["a", "b", "c"]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode(datetime(2015, 10, 30, 12, 30, 45, 1000, timezone.utc)) == '1446121045.001'
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'

# Generated at 2022-06-11 20:58:32.852439
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert '{"a": {"b": [1, 2]}, "c": 42}' == json.dumps({'a': {'b': [1, 2]}, 'c': 42}, cls=_ExtendedEncoder)
    assert '[5, 4, 3, 2, 1]' == json.dumps([5, 4, 3, 2, 1], cls=_ExtendedEncoder)
    assert '1' == json.dumps(True, cls=_ExtendedEncoder)
    assert '"a"' == json.dumps('a', cls=_ExtendedEncoder)
    assert '6.9' == json.dumps(6.9, cls=_ExtendedEncoder)
    assert 'null' == json.dumps(None, cls=_ExtendedEncoder)

# Generated at 2022-06-11 20:58:39.899808
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps([1, 2, 3], cls=_ExtendedEncoder) == '[1, 2, 3]'
    assert json.dumps({1: 2}, cls=_ExtendedEncoder) == '{"1": 2}'
    assert json.dumps(True, cls=_ExtendedEncoder) == 'true'

    class MyClass:
        def __init__(self, x, y):
            self.x = x
            self.y = y

    class A(MyClass):
        pass

    assert json.dumps(MyClass(1, 'a'), cls=_ExtendedEncoder) == '{"x": 1, "y": "a"}'

# Generated at 2022-06-11 20:58:41.968870
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ee =_ExtendedEncoder()
    assert ee.default(1) == 1
    assert ee.default('2') == '2'



# Generated at 2022-06-11 20:58:44.957529
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder().encode(datetime(1970, 1, 1, tzinfo=timezone.utc))
    assert e == '0'


# Generated at 2022-06-11 20:58:50.749675
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().encode(datetime(2019, 10, 1, 14, 6, tzinfo=timezone.utc))
    _ExtendedEncoder().encode(UUID('3a3b6d71-836e-4876-9a50-b6147df56414'))
    _ExtendedEncoder().encode(Decimal('2.5'))



# Generated at 2022-06-11 20:59:02.319062
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        o = {'a': [1, 2], 'b': 'foo'}
        assert _ExtendedEncoder().default(o) == o
        assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
        assert _ExtendedEncoder().default(UUID('61feeb03-7b2e-4b0c-b521-e9e29c5100fd')) == '61feeb03-7b2e-4b0c-b521-e9e29c5100fd'
        assert _ExtendedEncoder().default(list(range(5))) == list(range(5))

# Generated at 2022-06-11 20:59:30.756665
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# noinspection PyProtectedMember

# Generated at 2022-06-11 20:59:37.403128
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(['abc']) == '["abc"]'
    assert _ExtendedEncoder().encode(dict(abc='abc')) == '{"abc": "abc"}'
    assert _ExtendedEncoder().encode(datetime.fromtimestamp(1)) == '1.0'
    assert _ExtendedEncoder().encode(UUID('{123e4567-e89b-12d3-a456-426655440000}')) == '"123e4567-e89b-12d3-a456-426655440000"'
    assert _ExtendedEncoder().encode(Enum2.a) == '1'
    assert _ExtendedEncoder().encode(Decimal('1.2')) == '"1.2"'



# Generated at 2022-06-11 20:59:45.578826
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    expected = {
        'dt_native': datetime.now(tz=timezone.utc),
        'dt_str': str(datetime.now(tz=timezone.utc)),
        'fd': Decimal('3.14'),
        'fd_str': str(Decimal('3.14')),
        'uuid': UUID('44444444-4444-4444-4444-444444444444'),
    }

    assert expected == json.loads(
        # noinspection PyTypeChecker
        json.dumps(expected, cls=_ExtendedEncoder)
    )


# Generated at 2022-06-11 20:59:55.097503
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    # noinspection PyTypeChecker
    encoder.default(set())
    # noinspection PyTypeChecker
    encoder.default(frozenset())
    # noinspection PyTypeChecker
    encoder.default(1 + 2j)
    # noinspection PyTypeChecker
    encoder.default(object())
    # noinspection PyTypeChecker
    encoder.default(frozenset())
    # noinspection PyTypeChecker
    encoder.default(set())
    encoder.default(datetime(2020, 1, 1, 1, 1, 1, tzinfo=timezone.utc))

# Generated at 2022-06-11 20:59:56.358043
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps(datetime.now(), cls=_ExtendedEncoder)


# Generated at 2022-06-11 21:00:04.208006
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_encoder = _ExtendedEncoder()
    assert json_encoder.encode(['a', 'b', 'c']) == '["a", "b", "c"]'
    assert json_encoder.encode({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert json_encoder.encode(Decimal('12.34')) == '"12.34"'
    assert json_encoder.encode(UUID('f8a7e89e-5b78-499e-a1e6-81c03e7d6f51')) == '"f8a7e89e-5b78-499e-a1e6-81c03e7d6f51"'
    assert json_enc

# Generated at 2022-06-11 21:00:08.251251
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(Decimal('1.0')) == '"1.0"'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'


# Generated at 2022-06-11 21:00:19.524685
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # class used for testing _ExtendedEncoder
    class Foo:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b
        def __eq__(self, other: Any) -> bool:
            return self.a == other.a and self.b == other.b
        def __repr__(self) -> str:
            return f'Foo(a={self.a}, b={self.b})'

    items = [(Foo(0, 1), '{"a": 0, "b": 1}'),
             (datetime(1970, 1, 2, 3, 4, 5, 6, tzinfo=timezone.utc),
              '906900045.000006')]

# Generated at 2022-06-11 21:00:26.488809
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # pylint: disable=unused-variable
    # noinspection PyUnusedLocal
    @dataclass
    class DataClass:
        a: int
        b: list

    # noinspection PyTypeChecker
    encoder = _ExtendedEncoder()
    dataclass_instance = DataClass(1, [1, 2, 3])
    result = encoder.encode(dataclass_instance)
    assert result == '{"a": 1, "b": [1, 2, 3]}'


# Generated at 2022-06-11 21:00:37.481980
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(set([1, 2, 3])) == [1, 2, 3]
    assert _ExtendedEncoder().default({1: 'one', 2: 'two'}) == {1: 'one', 2: 'two'}
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, 0, 0, 0, 0, timezone.utc)) == 0.0
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(Decimal('3.14')) == '3.14'

# Generated at 2022-06-11 21:01:13.606838
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ee = _ExtendedEncoder()
    assert ee.default({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert ee.default(["a", "b"]) == ["a", "b"]
    assert ee.default(UUID("00112233-7766-5544-3322-1100ffeeddcc")) == "00112233-7766-5544-3322-1100ffeeddcc"
    assert ee.default(datetime(1970, 1, 2, 3, 4, 5, tzinfo=timezone.utc)) == 18000
    assert ee.default(Decimal("3.4")) == "3.4"
    assert ee.default(Decimal("1")) == "1"
    assert ee.default(Decimal("0"))

# Generated at 2022-06-11 21:01:14.740907
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder(): # TODO
    assert _ExtendedEncoder().default(datetime.now())



# Generated at 2022-06-11 21:01:15.512058
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-11 21:01:21.743857
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    data = {
        'datetime': datetime.now(),
        'datetime_utc': datetime.utcnow().replace(tzinfo=timezone.utc),
        'uuid': UUID('707deb32-e68d-4a6e-9c9b-23d3a3c3ed06'),
        'decimal': Decimal('12345678901234567890.1234567890'),
        'enum': cfg.omit,
        'builtin': [1, 2, 3],
    }

# Generated at 2022-06-11 21:01:31.064334
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    instance = _ExtendedEncoder()
    assert instance.default(1) == 1
    assert instance.default([1]) == [1]
    assert instance.default((1,)) == [1]
    assert instance.default({(1,): 1}) == {(1,): 1}
    assert instance.default(UUID('c2023270-c403-11e8-8cb9-6c96cf9b2a6b')) == 'c2023270-c403-11e8-8cb9-6c96cf9b2a6b'
    assert instance.default(datetime(2018, 10, 18, tzinfo=timezone.utc)) == 1539827200.0
    assert instance.default(Decimal('1.2')) == '1.2'



# Generated at 2022-06-11 21:01:39.743896
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode('1') == '"1"'
    assert _ExtendedEncoder().encode(datetime(1970, 1, 1, tzinfo=timezone.utc)) == '0'
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000')) == '"123e4567-e89b-12d3-a456-426655440000"'
    assert _ExtendedEncoder().encode(Decimal('0.5')) == '"0.5"'

# Generated at 2022-06-11 21:01:42.113882
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    to_json = json.dumps({'a': 1, 'b': Decimal('1.5')}, cls=_ExtendedEncoder)
    assert to_json == '{"a": 1, "b": "1.5"}'



# Generated at 2022-06-11 21:01:50.033572
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    @dataclass
    class _Test:
        name: str
        value: Any


# Generated at 2022-06-11 21:01:51.927660
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder(ensure_ascii=True).encode(['abc']) == b'["abc"]'



# Generated at 2022-06-11 21:01:59.709250
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(dict(hi=1)) == {'hi': 1}
    assert _ExtendedEncoder().default(set([1, 2, 3])) == [1, 2, 3]
    assert _ExtendedEncoder().default(datetime(2015, 1, 1, 0, 0, 0)) == 1420070400
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(Enum('A', ['A', 'B'])) == 'A'
    assert _ExtendedEncoder().default(Decimal(4.0)) == '4'



# Generated at 2022-06-11 21:02:48.971011
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(False) == 'false'
    assert _ExtendedEncoder().encode(
        datetime(2020, 3, 8, 20, 26, 43, tzinfo=timezone.utc)) == '1583767603.0'
    assert _ExtendedEncoder().encode(UUID('01234567-89ab-cdef-0123-456789abcdef')) == '"01234567-89ab-cdef-0123-456789abcdef"'
    assert _ExtendedEncoder().encode(Enum('A', 1)) == '1'

# Generated at 2022-06-11 21:02:54.759678
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import pytest
    from datetime import datetime
    from uuid import UUID

    with pytest.raises(Exception) as e:
        _ExtendedEncoder().encode(datetime.now(tz=timezone.utc) + datetime.timedelta(days=1))
    assert str(e.value) == "Object of type 'datetime' is not JSON serializable"

    _ExtendedEncoder().encode(datetime.now(tz=timezone.utc))

    _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000'))

    json.loads(json.dumps({"test_date": datetime.now(tz=timezone.utc)}))

# Generated at 2022-06-11 21:02:59.352628
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([]) == []
    assert encoder.default({}) == {}
    assert encoder.default(datetime(2019, 1, 1, tzinfo=timezone.utc)) == 1546300800.0
    assert encoder.default(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'


# Generated at 2022-06-11 21:03:04.996952
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert (encoder.default(datetime.now(timezone.utc)) ==
            datetime.now(timezone.utc).timestamp())
    assert encoder.default(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('1.1')) == '1.1'



# Generated at 2022-06-11 21:03:09.011390
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    dcm = Decimal(1.1)
    assert str(dcm) == '1.1'

    encoder = _ExtendedEncoder()
    assert encoder.default(dcm) == '1.1'
    assert encoder.default(1) == 1
    assert encoder.default('str') == 'str'



# Generated at 2022-06-11 21:03:09.867047
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.JSONEncoder().default(None)



# Generated at 2022-06-11 21:03:13.504220
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = {'a': 'b'}
    has_warnings = False
    with warnings.catch_warnings(record=True) as w:
        _ExtendedEncoder().default(o)
        if len(w) > 0:
            has_warnings = True
    assert not has_warnings


# Generated at 2022-06-11 21:03:24.341405
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert e.default(set()) == []
    assert e.default(frozenset()) == []
    assert e.default(123) == 123
    assert e.default(None) is None
    assert e.default('str') == 'str'
    assert e.default(datetime.now()) == datetime.now().timestamp()
    assert e.default(UUID('9e9d4f65-4c4c-4e2b-98b0-48fefc1f8f00')) == \
        '9e9d4f65-4c4c-4e2b-98b0-48fefc1f8f00'
    assert e.default(Decimal('1.5')) == '1.5'

# Generated at 2022-06-11 21:03:34.376730
# Unit test for method default of class _ExtendedEncoder

# Generated at 2022-06-11 21:03:43.207482
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = _ExtendedEncoder()
    assert o.default(None) == None
    assert o.default([]) == []
    assert o.default({1: 1}) == {1: 1}
    assert o.default(datetime.now()) == datetime.now().timestamp()
    assert o.default(Decimal(1)) == '1'
    assert o.default(UUID('814b2c66-0d5f-42cd-b8af-0ef0d6e48b6b')) == '814b2c66-0d5f-42cd-b8af-0ef0d6e48b6b'
