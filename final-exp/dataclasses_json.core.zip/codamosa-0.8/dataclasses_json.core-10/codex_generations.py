

# Generated at 2022-06-11 20:54:41.820287
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    @dataclass
    class Data:
        data: Json
    c = _ExtendedEncoder()
    json.dumps({"data": [range(0, 100)]}, cls=c)

# noinspection PyProtectedMember

# Generated at 2022-06-11 20:54:51.268553
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime.now(timezone.utc)) == json.JSONEncoder.default(encoder, datetime.now(timezone.utc))
    assert encoder.default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert encoder.default(set()) == json.JSONEncoder.default(encoder, set())
    assert encoder.default(frozenset()) == json.JSONEncoder.default(encoder, frozenset())



# Generated at 2022-06-11 20:54:53.157915
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder() == 'foo'


# noinspection PyProtectedMember

# Generated at 2022-06-11 20:55:03.804359
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None
    assert encoder.default(False) is False
    assert encoder.default(True) is True
    assert encoder.default(1) is 1
    assert encoder.default(1.) is 1.
    assert encoder.default("hoge") == "hoge"
    assert encoder.default(["a", "b"]) == ["a", "b"]
    assert encoder.default({"a": "b"}) == {"a": "b"}

    # class MockDatetime(datetime):
    #     pass
    # assert encoder.default(MockDatetime.utcnow()) == MockDatetime.utcnow().timestamp()


# Generated at 2022-06-11 20:55:08.323121
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder(ignore_nan=False)
    assert enc.default(float('nan')) == float('nan')

    enc = _ExtendedEncoder(ignore_nan=True)
    assert enc.default(float('nan')) is None


# Generated at 2022-06-11 20:55:09.253162
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-11 20:55:16.606850
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

    assert encoder.default(None) is None
    assert encoder.default("") == ""
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({'a': 'b', 'c': 'd'}) == {'a': 'b', 'c': 'd'}
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-11 20:55:18.666980
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    result = _ExtendedEncoder().default(None)
    assert result ==  json.JSONEncoder().default(None)



# Generated at 2022-06-11 20:55:29.141591
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import time
    import pprint
    t = time.localtime()
    encoder = _ExtendedEncoder()
    assert isinstance(encoder.default(t), str)
    assert encoder.default(decimal.Decimal("3.1415926")) == "3.1415926"
    assert encoder.default("abc") == "abc"
    assert encoder.default(123) == 123
    assert encoder.default(True) is True
    assert encoder.default(None) is None
    assert encoder.default(
        [1, 2, 3]) == [1, 2, 3]
    assert encoder.default(
        (1, 2, 3)) == [1, 2, 3]

# Generated at 2022-06-11 20:55:37.427880
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _isinstance_safe(_ExtendedEncoder(), _ExtendedEncoder)
    assert _isinstance_safe(dict, _ExtendedEncoder)
    assert _isinstance_safe(list, _ExtendedEncoder)
    assert _isinstance_safe(str, _ExtendedEncoder)
    assert _isinstance_safe(float, _ExtendedEncoder)
    assert _isinstance_safe(bool, _ExtendedEncoder)
    assert _isinstance_safe(None, _ExtendedEncoder)
    assert _isinstance_safe(UUID, _ExtendedEncoder)
    assert _isinstance_safe(Decimal, _ExtendedEncoder)
    assert _isinstance_safe(datetime, _ExtendedEncoder)
    assert _isinstance_safe(Enum, _ExtendedEncoder)
    assert _Extended

# Generated at 2022-06-11 20:55:58.207880
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now())



# Generated at 2022-06-11 20:56:08.612572
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder(indent=2).encode([1, 2, 'a', 'b']) == '[\n  1,\n  2,\n  "a",\n  "b"\n]'
    assert _ExtendedEncoder(indent=2).encode({1:2, 3:4}) == '{\n  "1": 2,\n  "3": 4\n}'
    t = datetime.now(tz=timezone.utc)
    tstr = t.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'
    assert _ExtendedEncoder(indent=2).encode(t) == tstr

# Generated at 2022-06-11 20:56:13.068068
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    input_str = (
        '{"a": ["1", "2"], "b": {"c": 1, "d": {"e": [], "f": 2}}, "g": 3}')
    expected_result = dict(a=[1, 2], b=dict(c=1, d=dict(e=[], f=2)), g=3)
    assert expected_result == json.loads(input_str, cls=_ExtendedEncoder)


# Generated at 2022-06-11 20:56:21.402421
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'x': 1}) == {'x': 1}
    assert _ExtendedEncoder().default(datetime(2000, 1, 1, 1, 5, 6, 7)) == datetime(2000, 1, 1, 1, 5, 6, 7).timestamp()
    assert _ExtendedEncoder().default(UUID('01234567-89ab-cdef-0123-456789abcdef')) == '01234567-89ab-cdef-0123-456789abcdef'



# Generated at 2022-06-11 20:56:28.489652
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == list(set())
    assert encoder.default(dict()) == dict()
    assert encoder.default(datetime(2017, 1, 1, 0, 0, 0, 0, timezone.utc)) == 1483228800.0
    assert encoder.default(UUID("00000000-0000-0000-0000-000000000000")) == "00000000-0000-0000-0000-000000000000"
    assert encoder.default(Decimal("10.2")) == "10.2"
    assert encoder.default(None) is None
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(10) == 10
    assert encoder.default(10.2) == 10.2
   

# Generated at 2022-06-11 20:56:30.828945
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps(set(), cls=_ExtendedEncoder)



# Generated at 2022-06-11 20:56:38.709772
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'

    dt = datetime(1970, 1, 1, tzinfo=timezone.utc)
    assert _ExtendedEncoder().encode(dt) == '0.0'

# Generated at 2022-06-11 20:56:45.268592
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert json.loads(_ExtendedEncoder().encode({'a': 1})) == {'a': 1}
    assert json.loads(_ExtendedEncoder().encode([1, 2, 3])) == [1, 2, 3]
    assert json.loads(_ExtendedEncoder().encode(
        {'a': {'b': [1, 2, 3]}})) == {'a': {'b': [1, 2, 3]}}
    assert json.loads(_ExtendedEncoder().encode({'a': 1, 'b': None})) == {'a': 1, 'b': None}
    assert json.loads(_ExtendedEncoder().encode({'a': True})) == {'a': True}

# Generated at 2022-06-11 20:56:54.951459
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o1 = [1, 2, 3, 4]
    o2 = {'a': 1, 'b': 2}
    o3 = datetime.utcnow()
    o4 = timezone.utc
    o5 = Decimal('1.0')
    o6 = UUID('a8fdf5ab-9cf7-4c31-8166-d42c0ca0b5ef')
    o7 = Enum('Foo', 'a b c')('a')
    o8 = Enum('Foo', 'a b c')('b')
    o9 = Enum('Foo', 'a b c')('d')
    o10 = _ExtendedDecoder()
    e = _ExtendedEncoder()
    assert e.default(o1) == o1

# Generated at 2022-06-11 20:56:59.056099
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    expected = '{"foo": [{"bar": ["test"]}]}'
    data = {'foo': [{'bar': ['test']}]}
    result = json.dumps(data, cls=_ExtendedEncoder)
    assert result == expected

    

# Generated at 2022-06-11 20:57:26.575977
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([datetime(2017, 2, 12, 7, 35, 0)]) == '[1497053300.0]'
    assert _ExtendedEncoder().encode(
        {'a': datetime(2017, 2, 12, 7, 35, 0)}) == '{"a": 1497053300.0}'
    assert _ExtendedEncoder().encode(datetime(2017, 2, 12, 7, 35, 0)) == '1497053300.0'
    assert _ExtendedEncoder().encode(UUID('f816bce5-eec7-46ca-b3c8-f0f7430c5d5f')) == '"f816bce5-eec7-46ca-b3c8-f0f7430c5d5f"'


# Generated at 2022-06-11 20:57:29.248134
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder is not None
# test__ExtendedEncoder()

_extended_encoder = _ExtendedEncoder()



# Generated at 2022-06-11 20:57:39.466982
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None
    assert encoder.default(True) is True
    assert encoder.default(4) == 4
    assert encoder.default({'hello': 'world'}) == {'hello': 'world'}
    assert encoder.default(['hello', 'world']) == ['hello', 'world']
    assert encoder.default(b'hello') == 'hello'
    assert encoder.default(b'\xff') == '\ufffd'
    assert encoder.default(bytearray(b'\xff')) == '\ufffd'
    assert encoder.default(set()) == {}
    assert encoder.default(frozenset()) == {}

# Generated at 2022-06-11 20:57:49.403967
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default('') == ''
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(Decimal('3.14')) == '3.14'
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc)) == 0

# Generated at 2022-06-11 20:58:00.778554
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = {
        "a": [1, 2, 3],
        "b": {"c": 1, "d": 2},
        "e": {1, 2, 3},
        "f": {"g": 3, 1: 2},
        "h": datetime(2014, 11, 22, 14, 42, 21, 34435, tzinfo=timezone.utc),
        "i": UUID("5a52c5a0-ea39-4c85-b840-ad7d05b2f66e"),
        "j": Enum('j', 'a b c')('c'),
        "k": Decimal(2.5)
    }
    result = _ExtendedEncoder().encode(o)

# Generated at 2022-06-11 20:58:06.517027
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import date, datetime, time
    from decimal import Decimal
    from enum import Enum
    from uuid import UUID

    class Color(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3

    class Test:
        pass

    d = {'d': date(2020, 1, 24), 'dt': datetime(2020, 1, 24), 't': time(16, 50, 0), 'u': UUID('e9e2f7f0-2308-4eac-ac87-ece716406d8d'),
         'de': Decimal('12.34'), 'c': Color.RED, 'Test': Test()}
    print(d)
    j = json.dumps(d, cls=_ExtendedEncoder)
    print(j)

# Generated at 2022-06-11 20:58:15.245296
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def _test(o, expected_result):
        enc = _ExtendedEncoder()
        result = enc.default(o)
        assert result == expected_result

    _test([1, 2, 3], [1, 2, 3])
    _test({'a': 1, 'b': 2}, {'a': 1, 'b': 2})
    _test(datetime(2012, 12, 12, 12, 12, 12, 12, tzinfo=timezone.utc),
          1355257532.000012)
    _test(UUID('12345678123456781234567812345678'),
          '12345678-1234-5678-1234-567812345678')
    _test(Decimal(1.23), '1.23')



# Generated at 2022-06-11 20:58:17.190921
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(2018, 1, 1, 0, 0, 0, 0)) == 1514764800


# Generated at 2022-06-11 20:58:18.472667
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-11 20:58:24.881412
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    data = {
        "mapping": {
            "test1": 1,
            "test2": 2,
        },
        "list": [1, 2, 3],
        "datetime": datetime(2020, 1, 1),
        "uuid": UUID("e5bc5bc8-a7b6-4200-9c62-7977c8e00d1f"),
        "enum": cfg.LetterCase.UPPER_CAMEL,
        "decimal": Decimal('1.1'),
    }
    result = json.dumps(data, cls=_ExtendedEncoder)

# Generated at 2022-06-11 20:58:52.013245
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = [{'foo': 0}, 'bar', datetime(2020, 1, 1, 0, 0, tzinfo=timezone.utc), 
        UUID('c4a760a8-dbcf-5254-a0d9-6a4474bd1b62'), 
        TestEnum.A]
    assert _ExtendedEncoder().default(o) == [{'foo': 0}, 'bar',
                                             1577836800.0,
                                             'c4a760a8-dbcf-5254-a0d9-6a4474bd1b62',
                                             'A']



# Generated at 2022-06-11 20:58:57.991238
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    @dataclass
    class Test:
        a: int

    assert _ExtendedEncoder().encode(Test(1)) == '{"a":1}'
    assert _ExtendedEncoder().encode(Test) == '"Test"'

    class Test2(Test):
        pass

    assert _ExtendedEncoder().encode(Test2(1)) == '{"a":1}'



# Generated at 2022-06-11 20:59:08.075168
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(0) == 0
    assert _ExtendedEncoder().default(0.0) == 0.0
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default('hello') == 'hello'
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'

# Generated at 2022-06-11 20:59:16.516832
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(
        Decimal('0.01')) == '"0.01"'
    assert _ExtendedEncoder().encode(
        datetime(1970, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == '0.0'
    assert _ExtendedEncoder().encode(
        UUID('00112233-4455-6677-8899-aabbccddeeff')) == '"00112233-4455-6677-8899-aabbccddeeff"'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _

# Generated at 2022-06-11 20:59:22.252543
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'a': 3, 'b': 4}) == {'a': 3, 'b': 4}
    assert _ExtendedEncoder().default('string') == 'string'
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(True)
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(datetime(2017, 10, 10, tzinfo=timezone.utc)) == 1507625600.0

# Generated at 2022-06-11 20:59:26.968502
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(datetime.now(timezone.utc), cls=_ExtendedEncoder)
    assert json.dumps(UUID('{12345678-9abc-def0-1234-56789abcdef0}'), cls=_ExtendedEncoder)


_typeof = type



# Generated at 2022-06-11 20:59:28.594552
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))


# Generated at 2022-06-11 20:59:36.475355
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()

    o: Any = [1, 2, 3]
    assert e.default(o) == o

    o = {'q': 1, 4: 'a'}
    assert e.default(o) == o

    tz = timezone.utc
    o = datetime.now(tz)
    assert e.default(o) == o.timestamp()

    o = UUID('123e4567-e89b-12d3-a456-426655440000')
    assert e.default(o) == str(o)

    from enum import Enum
    class Color(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3
    o: Any = Color.GREEN
    assert e.default(o) == o.value


# Generated at 2022-06-11 20:59:37.339218
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-11 20:59:38.920167
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _ExtendedEncoder().default(b'a')


# Generated at 2022-06-11 21:00:13.042906
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    me = _ExtendedEncoder()
    assert me.default([1,2]) == [1,2]
    assert me.default({3,4}) == [3,4]
    assert me.default({1:2}) == {1:2}
    assert me.default(datetime(1970, 1, 1, tzinfo=timezone.utc)) == 0
    assert me.default(UUID('3e8d75ea-dde7-45e3-b1bc-b55a9f929a51')) == '3e8d75ea-dde7-45e3-b1bc-b55a9f929a51' # type: ignore
    assert me.default(Enum('State', 'on off')('on')) == 'on' # type: ignore

# Generated at 2022-06-11 21:00:14.136901
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode({}) == '{}'


# Generated at 2022-06-11 21:00:22.132458
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder(indent=2, ensure_ascii=False)
    assert type(encoder) == _ExtendedEncoder
    assert encoder.indent == 2
    assert encoder.ensure_ascii == False
    assert encoder.default(2.0) == 2.0
    assert encoder.default(UUID('10000000-0000-0000-0000-000000000000')) == '10000000-0000-0000-0000-000000000000'
    assert encoder.default(Decimal('3.0')) == '3.0'
    assert encoder.default(datetime.utcnow()) == datetime.utcnow().timestamp()
    assert encoder.default(Enum) == 'Enum'
    assert encoder.default('str') == 'str'

# Generated at 2022-06-11 21:00:30.244718
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    data = [list('abcde'),
            dict(x=1, y=2),
            datetime(2020, 4, 3, 1, 15, 0, tzinfo=timezone.utc),
            UUID('{12345678-1234-5678-1234-567812345678}'),
            Decimal('3.14'),
            Decimal('10.02'),
            Enum('MyEnum', dict(a=1, b=2, c=3)),
            MyEnum.b]
    result = json.dumps(data, cls=_ExtendedEncoder)

# Generated at 2022-06-11 21:00:40.858036
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == 1607077931.868056
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(frozenset()) == []
    assert _ExtendedEncoder().default(tuple()) == []
    assert _ExtendedEncoder().default(dict()) == {}
    assert _ExtendedEncoder().default(list()) == []
    assert _ExtendedEncoder().default(bool()) == False
    assert _ExtendedEncoder().default(int()) == 0
    assert _ExtendedEncoder().default(float()) == 0.0
    assert _

# Generated at 2022-06-11 21:00:49.543991
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default(1.1) == 1.1
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(['1', '2', '3']) == ['1', '2', '3']
    assert encoder.default({'1': 1, '2': 2, '3': 3}) == {'1': 1, '2': 2, '3': 3}
    assert encoder.default(UUID('00000000-0000-0000-0000-000000000001')) == '00000000-0000-0000-0000-000000000001'
    assert encoder.default(Decimal('1.1')) == '1.1'

# Generated at 2022-06-11 21:00:57.572298
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # This is a hack to prevent the case when the constructor of _ExtendedEncoder
    # would be called with a non-default sort_keys argument.
    # We want this to be non-default to check sort_keys, but the super constructor should never be called with it.
    def raise_error():
        raise Exception('ExtendedEncoder constructor called unexpectedly')
    original_isinstance = isinstance
    try:
        isinstance = raise_error
        json.JSONEncoder._default = raise_error
        _ExtendedEncoder(sort_keys=True)
    finally:
        isinstance = original_isinstance
        del json.JSONEncoder._default



# Generated at 2022-06-11 21:01:00.116143
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from dataclasses import dataclass
    from dataclasses_json.utils import _is_dataclass_instance
    @dataclass
    class T:
        a: int
    t = T(5)
    assert _ExtendedEncoder().encode(t) == '{"a": 5}'
    assert _is_dataclass_instance(t)


# Generated at 2022-06-11 21:01:10.394600
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert enc.default(Decimal('42.123')) == '42.123'
    assert enc.default(Decimal('42.123e10')) == '42.123e+10'
    assert enc.default(Decimal('42.123e-10')) == '42.123e-10'
    assert enc.default(Decimal('42.123E+10')) == '42.123e+10'

    assert enc.default(Decimal('NaN')) == 'NaN'
    assert enc.default(Decimal('-Infinity')) == '-Infinity'
    assert enc.default(Decimal('Infinity')) == 'Infinity'

    assert enc.default(Decimal('-NaN')) == '-NaN'

# Generated at 2022-06-11 21:01:19.162821
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from decimal import Decimal
    from uuid import UUID
    from enum import Enum
    from datetime import datetime
    import json
    class Test(Enum):
        DEFAULT = 2
    encoder = _ExtendedEncoder()
    assert encoder.default(Test.DEFAULT) == Test.DEFAULT.value
    assert encoder.default(UUID('8d98bf61-e6ac-44b2-a21d-5f323e5f5132')) == '8d98bf61-e6ac-44b2-a21d-5f323e5f5132'
    assert encoder.default(Decimal('3.141592653589793238462643383279')) == '3.141592653589793238462643383279'

# Generated at 2022-06-11 21:02:26.100441
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default({"foo": "bar"}) == {"foo": "bar"}
    assert json.loads(_ExtendedEncoder().default({
        "foo": "bar"}))["foo"] == "bar"

    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert json.loads(_ExtendedEncoder().default([1, 2, 3])) == [1, 2, 3]

    assert _ExtendedEncoder().default(b"ab" + "c".encode()) == b"abc"
    assert json.loads(_ExtendedEncoder().default(b"ab" + "c".encode())) == b"abc"


# Generated at 2022-06-11 21:02:26.790559
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    pass



# Generated at 2022-06-11 21:02:29.937657
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now())



# Generated at 2022-06-11 21:02:37.347232
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps([1, 2, 3], cls=_ExtendedEncoder)
    json.dumps({'a': 'A'}, cls=_ExtendedEncoder)
    json.dumps(['a', 'b', 'c'], cls=_ExtendedEncoder)
    json.dumps(datetime(2000, 1, 1), cls=_ExtendedEncoder)
    json.dumps(datetime(2000, 1, 1, tzinfo=timezone.utc), cls=_ExtendedEncoder)
    json.dumps(UUID('0cc175b9-c0f1-b6a8-31c3-99e269772661'), cls=_ExtendedEncoder)
    json.dumps(Decimal(), cls=_ExtendedEncoder)

# Generated at 2022-06-11 21:02:46.416907
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(list()) == []
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(tuple()) == []
    assert _ExtendedEncoder().default(dict()) == dict()
    assert _ExtendedEncoder().default(datetime.fromtimestamp(0)) == 0
    assert _ExtendedEncoder().default(UUID('42c5b5f0-0094-4e09-89a1-efb7a8a62d97')) == '42c5b5f0-0094-4e09-89a1-efb7a8a62d97'
    assert _ExtendedEncoder().default(datetime.fromtimestamp(0, timezone.utc)) == 0

# Generated at 2022-06-11 21:02:53.281662
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(['a', 'b']) == ['a', 'b']
    assert _ExtendedEncoder().default({'a': 'b'}) == {'a': 'b'}
    assert _ExtendedEncoder().default(datetime(1970, 1, 1)) == 0
    assert _ExtendedEncoder().default(UUID('11112222-3333-4444-5555-666677778888')) == '11112222-3333-4444-5555-666677778888'
    assert _ExtendedEncoder().default(Enum('Enum', [('A', 0)])) == 0
    assert _ExtendedEncoder().default(Decimal('5.5')) == '5.5'
    assert _ExtendedEncoder().default('a') == 'a'

custom_enc

# Generated at 2022-06-11 21:02:57.555863
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': datetime.now(timezone.utc)}) is not None
    assert _ExtendedEncoder().encode({'a': UUID('123e4567-e89b-42d3-a456-556642440000')}) is not None
    assert _ExtendedEncoder().encode({'a': UUID('123e4567-e89b-42d3-a456-556642440000')}) is not None


# Generated at 2022-06-11 21:03:06.369988
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # valid cases
    assert _ExtendedEncoder().encode([1, 2, 3]) == '\x1b[42F[1, 2, 3]\x1b[0m'
    assert _ExtendedEncoder().encode([1, "1", 1.0]) == '\x1b[43F[1, "1", 1.0]\x1b[0m'
    assert _ExtendedEncoder().encode({1: 1, 2: 2, 3: 3}) == '\x1b[45F{"1": 1, "2": 2, "3": 3}\x1b[0m'
    assert _ExtendedEncoder().encode([[1, 2], [3, 4]]) == '\x1b[46F[[1, 2], [3, 4]]\x1b[0m'

# Generated at 2022-06-11 21:03:14.277313
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    encoder.default([1,2,3]) == [1,2,3]
    encoder.default({"a":1, "b":2}) == {"a":1, "b":2}
    encoder.default(datetime(2020,4,4,8,8,8, tzinfo=timezone.utc)) == 1586096288
    encoder.default(UUID("44444444-4444-4444-4444-444444444444")) == "44444444-4444-4444-4444-444444444444"
    encoder.default(Decimal("3.1415")) == "3.1415"


# Generated at 2022-06-11 21:03:21.183060
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(datetime.now(), cls=_ExtendedEncoder)
    assert json.dumps(UUID('317fca0a-8b8d-4a3a-a068-f8e8c1de9ebe'), cls=_ExtendedEncoder)
    assert json.dumps(Enum('Foo', {'foo': 1}), cls=_ExtendedEncoder)
    assert json.dumps(Decimal('1.1'), cls=_ExtendedEncoder)



# Generated at 2022-06-11 21:04:17.903706
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(UUID('5f5d3a5a-700e-4f8d-bfa5-b7f3a9445a5c')) == '"5f5d3a5a-700e-4f8d-bfa5-b7f3a9445a5c"'
    assert _ExtendedEncoder().encode(datetime(2019, 11, 22, 11, 11, 11, tzinfo=timezone.utc)) == '1574418271.0'
    assert _ExtendedEncoder().encode(Decimal('0.1')) == '"0.1"'
    assert _ExtendedEncoder().encode(Decimal('-0.1')) == '"-0.1"'



# Generated at 2022-06-11 21:04:27.943153
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default(frozenset([1, 2, 3])) == [1, 2, 3]
    assert encoder.default(b'abc') == 'YWJj'
    assert encoder.default(bytearray(b'abc')) == [97, 98, 99]
    assert encoder.default(True) == True
    assert encoder