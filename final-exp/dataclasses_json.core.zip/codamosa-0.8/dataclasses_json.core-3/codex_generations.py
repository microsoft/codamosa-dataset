

# Generated at 2022-06-11 20:54:51.553282
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('5b1b5bc9-5d4b-4c4d-b1d4-8e8f4cc7b1c1')) == '5b1b5bc9-5d4b-4c4d-b1d4-8e8f4cc7b1c1'
    assert encoder.default(Decimal(1.1)) == '1.1'
    assert encoder.default(cfg.encode_custom_types) == list(cfg.encode_custom_types)

# Generated at 2022-06-11 20:54:54.144765
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': 1, 'b': 'c'}) == '{"a":1,"b":"c"}'



# Generated at 2022-06-11 20:55:04.226162
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert encoder.default(datetime(2000, 1, 1, 1, 1, 1)) == 946684761.0
    assert encoder.default(datetime(2000, 1, 1, 1, 1, 1, tzinfo=timezone.utc)) == 946684761.0
    assert encoder.default(datetime(2000, 1, 1, 1, 1, 1, 123456)) == 946684761.123005

# Generated at 2022-06-11 20:55:15.312187
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': 1, 'b': 'test'}) == '{"a": 1, "b": "test"}'
    assert _ExtendedEncoder().encode([1, 'test']) == '[1, "test"]'
    assert _ExtendedEncoder().encode(set([1, 'test'])) == '[1, "test"]'
    d = datetime.now(timezone.utc)
    assert _ExtendedEncoder().encode(d) == str(d.timestamp())

# Generated at 2022-06-11 20:55:17.384428
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Arrange
    encoder = _ExtendedEncoder()
    # Act
    res = encoder.default(1)
    # Assert
    assert res == 1


# Generated at 2022-06-11 20:55:22.480829
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import pytest
    from dataclasses import dataclass

    @dataclass
    class MyClass:
        name: str
        age: int

    assert MyClass('Alice', 18) == json.loads(json.dumps(MyClass('Alice', 18), cls=_ExtendedEncoder),
                                              object_hook=lambda d: MyClass(**d))



# Generated at 2022-06-11 20:55:27.773709
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime(2020,1,1,0,0,0,0, tzinfo=timezone.utc)) == 1577880000.0
    assert _ExtendedEncoder().default(b"test") == 'test'
    assert _ExtendedEncoder().default(object) == '<class \'object\'>'



# Generated at 2022-06-11 20:55:36.579953
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = _ExtendedEncoder.default(None, {'a': 'b'})
    assert o == {'a': 'b'}
    o = _ExtendedEncoder.default(None, ['a', 'b'])
    assert o == ['a', 'b']
    o = _ExtendedEncoder.default(None, datetime(1970, 1, 1, tzinfo=timezone.utc))
    assert o == 0
    o = _ExtendedEncoder.default(None, datetime(1970, 1, 1, tzinfo=None))
    assert o == 0
    o = _ExtendedEncoder.default(None, UUID('12345678123456781234567812345678'))
    assert o == '12345678-1234-5678-1234-567812345678'
    o

# Generated at 2022-06-11 20:55:47.005166
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import pytest
    from decimal import Decimal

    encoder = _ExtendedEncoder()
    # pylint: disable=E1120
    assert encoder.default({}) == {}
    assert encoder.default([]) == []
    assert encoder.default(datetime.now()) == datetime.now().timestamp()
    assert encoder.default(UUID('a55e7aab-1eaa-4b4e-bef6-567dd1a2e1f4')) == 'a55e7aab-1eaa-4b4e-bef6-567dd1a2e1f4'
    assert encoder.default(Decimal('1.0')) == '1.0'

# Generated at 2022-06-11 20:55:48.776199
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(datetime.now(timezone.utc), cls=_ExtendedEncoder)


# Generated at 2022-06-11 20:56:16.043381
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(Decimal('9.8')) == '"9.8"'



# Generated at 2022-06-11 20:56:25.649534
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
  assert _ExtendedEncoder().default(['a', 'b', 'c']) == ['a', 'b', 'c']
  assert _ExtendedEncoder().default(('a', 'b', 'c')) == ['a', 'b', 'c']
  assert _ExtendedEncoder().default({'a':1, 'b':2, 'c':3}) == {'a':1, 'b':2, 'c':3}
  from datetime import datetime
  assert _ExtendedEncoder().default(datetime(2016, 9, 3, 10, 0, 0)) == 1472857200.0
  from uuid import UUID

# Generated at 2022-06-11 20:56:36.656214
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    x: Json = _ExtendedEncoder().default(dict(a=1,b=2))
    assert x == dict(a=1,b=2)
    x = _ExtendedEncoder().default([1,2,3])
    assert x == [1,2,3]
    x = _ExtendedEncoder().default(datetime.utcnow())
    y = datetime.now()
    assert isinstance(y, datetime)
    x = _ExtendedEncoder().default(UUID('{12345678-1234-5678-1234-567812345678}'))
    assert x == '12345678-1234-5678-1234-567812345678'
    class MyEnum(Enum):
        def __init__(self, _value_: Any):
            self._

# Generated at 2022-06-11 20:56:44.325715
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    s = _ExtendedEncoder().default({"1": 1})
    assert isinstance(s, dict)
    assert s == {"1": 1}
    s = _ExtendedEncoder().default([1, 2])
    assert isinstance(s, list)
    assert s == [1, 2]
    s = _ExtendedEncoder().default("")
    assert isinstance(s, str)
    assert s == ""
    s = _ExtendedEncoder().default(1)
    assert isinstance(s, int)
    assert s == 1
    s = _ExtendedEncoder().default(1.0)
    assert isinstance(s, float)
    assert s == 1.0
    s = _ExtendedEncoder().default(True)
    assert isinstance(s, bool)
    assert s == True


# Generated at 2022-06-11 20:56:54.713192
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from dataclasses_json.utils import _isinstance_safe
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Dummy:
        a: int
        b: List[int]
        c: List[List[int]]
    from datetime import date
    from uuid import UUID
    from decimal import Decimal
    dummy = Dummy(a=1, b=[2], c=[[3]])
    assert json.dumps(dummy, cls=_ExtendedEncoder) == '{"a": 1, "b": [2], "c": [[3]]}'
    assert json.dumps([2], cls=_ExtendedEncoder) == '[2]'

# Generated at 2022-06-11 20:57:06.229918
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([None, 0, 3.14, {'hey': 'there'}]) == '[null,0,3.14,{"hey":"there"}]'
    assert _ExtendedEncoder().encode({'a': 'b'}) == '{"a":"b"}'
    assert _ExtendedEncoder().encode('c') == '"c"'
    assert _ExtendedEncoder().encode(datetime(year=2020, month=3, day=23, hour=11, minute=11)) == '1584914660.0'

# Generated at 2022-06-11 20:57:13.171782
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(123) == 123
    assert _ExtendedEncoder().default(123.0) == 123.0
    assert _ExtendedEncoder().default(Decimal(123)) == '123'
    assert _ExtendedEncoder().default('foo') == 'foo'
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default((1, 2)) == [1, 2]
    assert _ExtendedEncoder().default({1: 'a', 2: 'b'}) == {1: 'a', 2: 'b'}
    assert _ExtendedEncoder().default({1}) == [1]
    assert _ExtendedEncoder().default(True)



# Generated at 2022-06-11 20:57:15.951062
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode([1, 'a', 3]) == '[1, "a", 3]'



# Generated at 2022-06-11 20:57:26.062234
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(1.0) == 1.0
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({1, 2, 3}) == [1, 2, 3]
    assert encoder.default({1: 1}) == {1: 1}
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default(datetime.fromtimestamp(1.0, timezone.utc)) == 1.0

# Generated at 2022-06-11 20:57:35.918804
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode((1, 2, 3)) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'

    try:
        _ExtendedEncoder().encode({1: 2})
        raise AssertionError('fail')
    except TypeError:
        pass

    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '0.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'

# Generated at 2022-06-11 20:58:18.810804
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(123) == 123
    assert _ExtendedEncoder().default(0.123) == 0.123
    assert _ExtendedEncoder().default("abc") == "abc"

###



# Generated at 2022-06-11 20:58:21.194786
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"test": 2.5}) == '{"test": 2.5}'


# Generated at 2022-06-11 20:58:22.023315
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-11 20:58:33.090414
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def decode(s: str) -> Json:
        data = json.loads(s)
        cpy = copy.deepcopy(data)
        return cpy

    def encode(o: Any) -> str:
        s = json.dumps(o, cls=_ExtendedEncoder)
        return s

    assert encode(decode('{"a":2.5}')) == '{"a":2.5}'
    assert encode(decode('{"a":true}')) == '{"a":true}'
    assert encode(decode('{"a":false}')) == '{"a":false}'
    assert encode(decode('{"a":null}')) == '{"a":null}'
    assert encode(decode('{"a":10}')) == '{"a":10}'

# Generated at 2022-06-11 20:58:34.949044
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2018, 1, 1)) == '1514764800.0'

_DEFAULT_ENCODER = _ExtendedEncoder()



# Generated at 2022-06-11 20:58:42.840485
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 5, 'b': 3}) == '{"a": 5, "b": 3}'
    assert _ExtendedEncoder().encode("789") == '"789"'
    assert _ExtendedEncoder().encode(Enum("Enum", ["Test"])) == '"Test"'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '""'

# Generated at 2022-06-11 20:58:48.160927
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    data = {'key1': 'value1', 'key2': ['value2', 12]}
    sample_encoder = _ExtendedEncoder()
    actual = sample_encoder.encode(data)
    expected = json.dumps(data, cls=_ExtendedEncoder)
    assert actual == expected


# Generated at 2022-06-11 20:58:55.302343
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import datetime, timezone
    from uuid import UUID
    from decimal import Decimal
    from dataclasses_json.tests.test_nominal_example import Animal, Gender

# Generated at 2022-06-11 20:58:55.877027
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass



# Generated at 2022-06-11 20:59:04.132968
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(Decimal(1.5)) == '1.5'
    assert _ExtendedEncoder().default([1.5]) == [1.5]
    assert _ExtendedEncoder().default({1.5: 1.5}) == {1.5: 1.5}
    try:
        _ExtendedEncoder().default(1.5)
    except TypeError as e:
        assert str(e) == 'Object of type float is not JSON serializable'
    else:
        raise AssertionError('TypeError is not raised.')


# Generated at 2022-06-11 20:59:52.892590
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-11 21:00:02.903371
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert enc.default([1,2,3]) == [1,2,3]
    assert enc.default({"x": 5}) == {"x": 5}
    assert enc.default(datetime.fromtimestamp(1590238814, tz=timezone.utc)) == 1590238814
    assert enc.default(UUID("00000000-0000-0000-0000-000000000000")) == "00000000-0000-0000-0000-000000000000"
    assert enc.default(True) == True
    assert enc.default(False) == False
    assert enc.default(123) == 123
    assert enc.default(1.23) == 1.23
    assert enc.default(None) == None

    class C:
        def __init__(self, x, y):
            self.x

# Generated at 2022-06-11 21:00:15.673914
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(True, cls=_ExtendedEncoder) == "true"
    assert json.dumps(123, cls=_ExtendedEncoder) == "123"
    assert json.dumps(0.123, cls=_ExtendedEncoder) == "0.123"
    assert json.dumps([123, 456], cls=_ExtendedEncoder) == "[123, 456]"
    assert json.dumps({'a': 123, 'b': 456}, cls=_ExtendedEncoder) == '{"a": 123, "b": 456}'

# Generated at 2022-06-11 21:00:18.224052
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_obj = {"a": 12, "b": "hello"}
    assert json.dumps(test_obj, cls=_ExtendedEncoder) == '{"a": 12, "b": "hello"}'



# Generated at 2022-06-11 21:00:25.148727
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(object(), cls=_ExtendedEncoder) == '{}'
    assert json.dumps(1, cls=_ExtendedEncoder) == '1'
    assert json.dumps(1.0, cls=_ExtendedEncoder) == '1.0'
    assert json.dumps('a', cls=_ExtendedEncoder) == '"a"'
    assert json.dumps([1, 2, 3], cls=_ExtendedEncoder) == '[1, 2, 3]'



# Generated at 2022-06-11 21:00:31.262422
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder(allow_nan=False).encode({}) == '{}'
    assert _ExtendedEncoder(allow_nan=True).encode({}) == '{}'
    # None is not allowed
    assert not _ExtendedEncoder(allow_nan=False).encode(None) == 'null'
    assert _ExtendedEncoder(allow_nan=True).encode(None) == 'null'
    # NAN is not allowed
    assert not _ExtendedEncoder(allow_nan=False).encode(float('nan')) == 'NaN'
    assert _ExtendedEncoder(allow_nan=True).encode(float('nan')) == 'NaN'

    # datetime should be converted to timestamp

# Generated at 2022-06-11 21:00:41.565353
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Tests for Collection
    assert _ExtendedEncoder().encode(['test']) == '["test"]'
    assert _ExtendedEncoder().encode(('test',)) == '["test"]'
    assert _ExtendedEncoder().encode({'test': 1}) == '{"test": 1}'
    assert _ExtendedEncoder().encode({'test', 'test2'}) == '["test", "test2"]'

    # Tests for Python built-in types
    assert _ExtendedEncoder().encode('test') == '"test"'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _ExtendedEncoder().encode(True) is 'true'
    assert _ExtendedEncoder

# Generated at 2022-06-11 21:00:50.944724
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    json_encoder = _ExtendedEncoder()
    assert json_encoder.default({'a': {'b': list(range(10))}}) == {'a': {'b': list(range(10))}}
    assert json_encoder.default([]) == []
    dt = datetime(2008, 7, 6, 5, 4, 3, 2, timezone.utc)
    assert json_encoder.default(dt) == 1215272043.000002
    assert json_encoder.default(UUID('aaaaaaaa-1111-2222-3333-bbbbbbbbbbbb')) == 'aaaaaaaa-1111-2222-3333-bbbbbbbbbbbb'
    assert json_encoder.default(Decimal('1.234')) == '1.234'


# Generated at 2022-06-11 21:00:58.069839
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(1970, 1, 1)) == '0'
    assert _ExtendedEncoder().encode(UUID('c5ad5d7b-2fdc-4a1b-8a76-7a43d26f3d7f')) == '"c5ad5d7b-2fdc-4a1b-8a76-7a43d26f3d7f"'
    assert _ExtendedEncoder().encode(Enum('MONDAY', 1)) == '1'



# Generated at 2022-06-11 21:00:58.977457
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().encode([{}])


# Generated at 2022-06-11 21:03:46.106390
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'
    assert _ExtendedEncoder().default(Decimal('1.35')) == '1.35'
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, 0, 0, tzinfo=timezone.utc)) == 0

# Generated at 2022-06-11 21:03:51.665045
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o1 = [1,2,3,'a',3.2,['b','c'], {'d':'e', 'f':'g'}]
    o2 = {'h':'i','j':'k','l': {'m':'n'}, 'o': [1,2,'r','s',3.4]}
    o3 = datetime(2020,3,11,15,29,0,0)
    o4 = UUID('83f0a1cd-71e8-4d34-a2e7-ea30b881d8a5')
    json.dumps(o1, cls=_ExtendedEncoder)
    json.dumps(o2, cls=_ExtendedEncoder)
    json.dumps(o3, cls=_ExtendedEncoder)


# Generated at 2022-06-11 21:03:58.172189
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(['abc', 'def'], cls=_ExtendedEncoder) == '["abc", "def"]'
    assert json.dumps({'a': 'bcd', 'x': 'yzz'}, cls=_ExtendedEncoder) == '{"a": "bcd", "x": "yzz"}'
    assert json.dumps(UUID('11111111-2222-3333-4444-555555555555'), cls=_ExtendedEncoder) == '"11111111-2222-3333-4444-555555555555"'
    assert json.dumps(datetime(2020, 2, 8, 20, 30, 49, tzinfo=timezone.utc), cls=_ExtendedEncoder) == '1581188449.0'

# Generated at 2022-06-11 21:04:07.617436
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert (_ExtendedEncoder().encode({"date": datetime.now(tz=timezone.utc)}) != None)
    assert (_ExtendedEncoder().encode({"uuid": UUID('{123e4567-e89b-12d3-a456-426614174000}')}) != None)
    assert (_ExtendedEncoder().encode({"enum": Enum('TestEnum', {"test_val": 1})}) != None)
    assert (_ExtendedEncoder().encode({"decimal": Decimal(1)}) != None)
    assert (_ExtendedEncoder().encode({"other": None}) != None)


# Generated at 2022-06-11 21:04:15.212682
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1: 2}) == '{"1": 2}'
    assert _ExtendedEncoder().encode([1]) == '[1]'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '0.0'
    assert _ExtendedEncoder().encode(UUID('12345678901234567890123456789012')) == '"12345678-9012-3456-7890-123456789012"'
    assert _ExtendedEncoder().encode(Decimal('0.1')) == '"0.1"'
    assert _ExtendedEncoder().encode(list) == '"<class \'list\'>"'


# Generated at 2022-06-11 21:04:18.863148
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime(2018, 7, 1, 10, 0)) == 1530381200.0
    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default([1, '2']) == [1, '2']
    assert _ExtendedEncoder().default({1:'2'}) == {1: '2'}

_ExtendedEncoder.__test__ = False

