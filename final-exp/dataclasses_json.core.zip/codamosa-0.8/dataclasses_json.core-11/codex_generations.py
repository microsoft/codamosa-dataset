

# Generated at 2022-06-11 20:54:49.803807
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """
    **1. Testing for the constructor of class _ExtendedEncoder.**

    **Description**
        This test checks if the default method of the class _ExtendedEncoder
        works correctly for different types of input data.

    **Expected behaviour**
        The expected output should match the input object.
    """
    from uuid import uuid4
    from datetime import datetime
    from decimal import Decimal

    test_list = [
        [0, 1, 2, 3, 4],
        {'a': 0, 'b': 1, 'c': 2},
        'string',
        0,
        1.0,
        True,
        None,
        datetime.today(),
        uuid4(),
        Decimal('1.0')
    ]

    extended_encoder = _ExtendedEncoder()
   

# Generated at 2022-06-11 20:54:51.182646
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert isinstance(_ExtendedEncoder, object)


# Generated at 2022-06-11 20:54:57.286010
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ExtendedEncoder = _ExtendedEncoder()
    ExtendedEncoder.default([1,2,3])
    ExtendedEncoder.default({'name':'tom'})
    ExtendedEncoder.default(datetime.now())
    ExtendedEncoder.default(UUID('00000000-0000-0000-0000-000000000000'))
    ExtendedEncoder.default(Decimal(1))
    return 0

test__ExtendedEncoder()


# Generated at 2022-06-11 20:54:58.309769
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    jse = _ExtendedEncoder().encode(dict(a=3))  # type: ignore
    assert jse == '{"a": 3}'



# Generated at 2022-06-11 20:55:04.819292
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    d = datetime(2020, 2, 23, 11, 12, 18, tzinfo=timezone.utc)
    u = UUID('a8098c1a-f86e-11da-bd1a-00112444be1e')
    # test _ExtendedEncoder
    assert _ExtendedEncoder().default(d) == d.timestamp()
    assert _ExtendedEncoder().default(u) == str(u)
    assert _ExtendedEncoder().default(Decimal('1.24')) == str(Decimal('1.24'))



# Generated at 2022-06-11 20:55:08.527428
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert '3.14159' == _ExtendedEncoder().default(Decimal('3.14159'))

# noinspection PyTypeChecker
_extended_encoder = _ExtendedEncoder()



# Generated at 2022-06-11 20:55:18.079622
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """
    test__ExtendedEncoder()

    Unit test for constructor of class _ExtendedEncoder

    Parameters
    ----------

    """
    encoder = _ExtendedEncoder()
    assert encoder is not None
    assert encoder.default(UUID('{12345678-90ab-cdef-1234-567890abcdef}')) == '12345678-90ab-cdef-1234-567890abcdef'
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'one': 1, 'two': 2}) == {'one': 1, 'two': 2}
    assert encoder.default(datetime(2019, 2, 1, 0, 0, 0, 0, timezone.utc)) == 1549068800.0
   

# Generated at 2022-06-11 20:55:28.608649
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # create an instance of the class _ExtendedEncoder
    encoder = _ExtendedEncoder()
    # initialize a dictionary
    d = {'a': 1, 'b': 2}
    # initialize a list
    l = [1, 2, 3]
    # initialize a string
    s = 'hello'
    # initialize a UUID
    u = UUID('4f98db4e-2c2c-4194-bf96-b9bb9bc1c28d')
    # initialize a datetime
    dt = datetime(2020, 4, 27, 15, 5, 12, tzinfo=timezone.utc)
    # initialize a decimal
    decimal = Decimal('3.14')
    # initialize an Enum
    class enum(Enum):
        a = 1
        b = 2
    e

# Generated at 2022-06-11 20:55:37.148388
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_encoder = _ExtendedEncoder()
    data = {'b': 3, 'a': [1, {'a': 1, 'b': 2}, 2], 'c': True}
    assert json_encoder.default(data) == data
    assert json_encoder.default([1, 2]) == [1, 2]
    assert json_encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert json_encoder.default(datetime.utcnow()) == \
            datetime.utcnow().replace(tzinfo=timezone.utc).timestamp()

# Generated at 2022-06-11 20:55:47.362772
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(
        {'foo': 1}) == '{"foo": 1}'
    assert _ExtendedEncoder().encode(['foo', 1]) == '["foo", 1]'
    assert _ExtendedEncoder().encode([1, False]) == '[1, false]'
    assert _ExtendedEncoder().encode(
        [1, MappingProxyType({'foo': 1})]) == '[1, {"foo": 1}]'
    assert _ExtendedEncoder().encode(
        [1, defaultdict(int, foo=1)]) == '[1, {"foo": 1}]'
    assert _ExtendedEncoder().encode(
        [1, Counter({'foo': 1})]) == '[1, {"foo": 1}]'

# Generated at 2022-06-11 20:56:28.037691
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj = [{'a': 1}, {'b': True}]
    enc = _ExtendedEncoder()
    assert enc.encode(obj) == json.dumps(obj, cls=enc)



# Generated at 2022-06-11 20:56:30.414604
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # _ExtendedEncoder()
    _ExtendedEncoder()



# Generated at 2022-06-11 20:56:38.506702
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(4) == 4
    assert _ExtendedEncoder().default(4.2) == 4.2
    assert _ExtendedEncoder().default('example') == 'example'
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(None) is None

    assert _ExtendedEncoder().default(['a', 2, False, 'b']) == ['a', 2, False, 'b']
    assert _ExtendedEncoder().default({'a': 2, 'b': 'example'}) == {'a': 2, 'b': 'example'}

    t = datetime(2000, 1, 1, tzinfo=timezone.utc)

# Generated at 2022-06-11 20:56:40.431261
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """Testing the constructor of class _ExtendedEncoder"""
    assert _is_new_type(_ExtendedEncoder)



# Generated at 2022-06-11 20:56:52.279836
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    testee = _ExtendedEncoder()

    @dataclass(frozen=True)
    class Nested:
        a: int
        b: int

    @dataclass(frozen=True)
    class Sample:
        a: Nested
        b: int
        c: int
        d: Nested
        e: int

    nested1 = Nested(a=1, b=2)
    nested2 = Nested(a=3, b=4)
    sample = Sample(a=nested1, b=5, c=6, d=nested2, e=7)


# Generated at 2022-06-11 20:57:03.380490
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('1a1a1a1a-1a1a-1a1a-1a1a-1a1a1a1a1a1a')) == '1a1a1a1a-1a1a-1a1a-1a1a-1a1a1a1a1a1a'
    assert _ExtendedEncoder().default(Decimal(1)) == '1'
    assert _ExtendedEncoder().default(Enum) == Enum
    assert _ExtendedEnc

# Generated at 2022-06-11 20:57:06.027851
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default(UUID("00000000-0000-0000-0000-000000000000"))


# Generated at 2022-06-11 20:57:13.108366
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    def assert_type(value, json_value, json_type):
        encoder = _ExtendedEncoder()
        if encoder.default(value) != json_value:
            raise ValueError("test__ExtendedEncoder: value: {0}, json_value: {1}, json_type: {2}"
                             .format(value, json_value, json_type))
        if type(encoder.default(value)) != json_type:
            raise TypeError("test__ExtendedEncoder: value: {0}, json_value: {1}, json_type: {2}"
                            .format(value, json_value, json_type))
        if encoder.default(None) != None:
            raise ValueError("test__ExtendedEncoder: None")

    assert_type(None, None, type(None))
   

# Generated at 2022-06-11 20:57:18.126950
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == "null"
    assert _ExtendedEncoder().encode("") == "\"\""
    assert _ExtendedEncoder().encode("a") == "\"a\""
    assert _ExtendedEncoder().encode(1) == "1"
    assert _ExtendedEncoder().encode(1.0) == "1.0"
    assert _ExtendedEncoder().encode(1.1) == "1.1"
    assert _ExtendedEncoder().encode(True) == "true"
    assert _ExtendedEncoder().encode(False) == "false"



# Generated at 2022-06-11 20:57:22.441181
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(UUID(int=0)) == '00000000-0000-0000-0000-000000000000'

_EXTENDED_ENCODER = _ExtendedEncoder()  # Reusable object.



# Generated at 2022-06-11 20:57:48.895486
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([]) == []
    assert encoder.default({}) == {}
    assert encoder.default(set()) == []
    assert encoder.default(frozenset()) == []
    assert encoder.default(datetime(2018, 1, 1, 10, 20, 30)) == 1514765630.0
    assert encoder.default(UUID(bytes=b"\x00" * 16)) == "00000000-0000-0000-0000-000000000000"
    assert encoder.default(Decimal('0.1')) == '0.1'



# Generated at 2022-06-11 20:57:54.550892
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def it_succeeds_for_mapping_container():
        # given
        test_data = {
            'a': 1,
            'b': 2,
        }
        expected = test_data
        # when
        actual = _ExtendedEncoder().default(test_data)
        # then
        assert actual == expected

    def it_succeeds_for_collection_container():
        # given
        test_data = ['a', 'b', 'c']
        expected = test_data
        # when
        actual = _ExtendedEncoder().default(test_data)
        # then
        assert actual == expected

    def it_succeeds_for_date():
        # given
        test_data = datetime.now()
        expected = test_data.timestamp()
        # when
       

# Generated at 2022-06-11 20:58:03.941502
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, [3, 4]]) == '[1, 2, [3, 4]]'
    assert _ExtendedEncoder().encode(dict(a=[1], b=[2, 3])) == '{"a": [1], "b": [2, 3]}'
    assert _ExtendedEncoder().encode(set(list('foobar'))) == '["b", "a", "f", "o", "r"]'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '1.571911622e+09'
    assert _ExtendedEncoder().encode(UUID(int=0)) == '00000000-0000-0000-0000-000000000000'

# Generated at 2022-06-11 20:58:06.108729
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc))



# Generated at 2022-06-11 20:58:15.206468
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"hello": "world"}) == '{"hello": "world"}'
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEncoder().encode(datetime.now()) == 'null'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal('0.1')) == '"0.1"'
    assert _ExtendedEncoder().encode(None) == 'null'

# Is used in json_encoder as default encoder
_EXTENDED_ENCODER = _ExtendedEncoder



# Generated at 2022-06-11 20:58:19.844606
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(UUID('5e5d5a5a-e637-4796-90c6-734d05ee89c3')) == '"5e5d5a5a-e637-4796-90c6-734d05ee89c3"'

test__ExtendedEncoder()



# Generated at 2022-06-11 20:58:24.824409
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    with warnings.catch_warnings(record=True):  # type: ignore
        encoder = _ExtendedEncoder()
        assert encoder.default(datetime.now(timezone.utc))
        assert encoder.default(datetime.now(tz=timezone.utc))
        assert encoder.default(Decimal('1234.5678'))



# Generated at 2022-06-11 20:58:34.957816
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default(datetime.now()) == datetime.now().timestamp()
    assert enc.default(1) == 1
    assert enc.default('abc') == 'abc'
    assert enc.default(True) is True
    assert enc.default(None) is None
    assert enc.default([1, 2]) == [1, 2]
    assert enc.default(set([1, 2])) == [1, 2]  # type: ignore
    assert enc.default({'a': 'a'}) == {'a': 'a'}
    assert enc.default(frozenset([1, 2])) == [1, 2]  # type: ignore

# Generated at 2022-06-11 20:58:42.887744
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

# Generated at 2022-06-11 20:58:44.424223
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


_encoder = _ExtendedEncoder()



# Generated at 2022-06-11 20:59:12.201500
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 1, 1, 1, tzinfo=timezone.utc)) == '1577836861.0'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 1, 1, 1)) == '1577836861.0'

# Generated at 2022-06-11 20:59:19.513642
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = object()
    o_json = json.dumps(o)
    assert o_json == _ExtendedEncoder().encode(o)

    i = 0
    i_json = json.dumps(i)
    assert i_json == _ExtendedEncoder().encode(i)

    s = ''
    s_json = json.dumps(s)
    assert s_json == _ExtendedEncoder().encode(s)

    f = 0.0
    f_json = json.dumps(f)
    assert f_json == _ExtendedEncoder().encode(f)

    t = ()
    t_json = json.dumps(t)
    assert t_json == _ExtendedEncoder().encode(t)

    d = {}

# Generated at 2022-06-11 20:59:24.263458
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    default_encoder = json.JSONEncoder()
    extended_encoder = _ExtendedEncoder()
    o = {"frozenset": frozenset([1, 2]), "collections.deque": collections.deque([1, 2])}
    assert default_encoder.default(o) == extended_encoder.default(o)
    assert default_encoder.default(b"a") == extended_encoder.default(b"a")



# Generated at 2022-06-11 20:59:34.320777
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict(a = 1)) == '{"a": 1}'
    assert _ExtendedEncoder().encode(list(range(10))) == '[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]'
    assert _ExtendedEncoder().encode(12345) == '12345'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(False) == 'false'

# Generated at 2022-06-11 20:59:44.880682
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder().encode(datetime(2018, 10, 10, 20, 10, 0, 0, tzinfo=timezone.utc))
    assert result == '1539196200.000000'
    result = _ExtendedEncoder().encode(datetime(2018, 10, 10, 20, 10, 0, 0))
    assert result == '1539196200.000000'
    result = _ExtendedEncoder().encode(UUID('077e82e1-3773-45f2-8bca-7b9a2c3e7e3d'))
    assert result == '077e82e1-3773-45f2-8bca-7b9a2c3e7e3d'

# Generated at 2022-06-11 20:59:54.873902
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    class MyEnum(Enum):
        A = 1
        B = 2
    assert _ExtendedEncoder().default({"key": "value"}) == {"key": "value"}
    assert _ExtendedEncoder().default(["key1", "value1"]) == ["key1", "value1"]
    assert _ExtendedEncoder().default(MyEnum.A) == 1
    assert _ExtendedEncoder().default(UUID('b5a5b50d-76e2-458e-8c0c-af60c6f3ef6d')) == 'b5a5b50d-76e2-458e-8c0c-af60c6f3ef6d'

# Generated at 2022-06-11 20:59:59.403012
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # define data to test
    dt = datetime(2018, 10, 25, 19, 5, 8)
    invalid_o = object()
    test_data = [
        (123, 123),
        ('abc', 'abc'),
        ([1, 2, 3], [1, 2, 3]),
        ({"1": 2}, {"1": 2}),
        (dt, dt.timestamp())
    ]

    # create ExtendedEncoder
    encoder = _ExtendedEncoder()

    # test all cases
    for o, expect in test_data:
        actual = encoder.default(o)
        assert actual == expect, f"encoder.default({type(o).__name__}) returns {type(actual).__name__}, not {type(expect).__name__}"

    # test failure

# Generated at 2022-06-11 21:00:05.463946
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"1": 2, "3": [1, 2, 3]})\
        in [r'{"1": 2, "3": [1, 2, 3]}', r'{"3": [1, 2, 3], "1": 2}']
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.1) == '1.1'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(datetime.now())\
        == datetime.now().isoformat()

# Generated at 2022-06-11 21:00:08.884964
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    res = json.dumps(
        Decimal("1.2345"),
        cls=_ExtendedEncoder
    )
    assert res == '"1.2345"'


# Generated at 2022-06-11 21:00:19.718090
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps([1, 2, 3], cls=_ExtendedEncoder)
    json.dumps({1: 2, 3: 4}, cls=_ExtendedEncoder)
    loc = timezone.utc
    if cfg.timezone_aware:
        loc = timezone.utc  # this is the default
    assert json.dumps(datetime(1970, 1, 1, 0, 0, 1, tzinfo=loc),
                      cls=_ExtendedEncoder) == '1.0'
    assert json.dumps(UUID('12345678123456781234567812345678'),
                      cls=_ExtendedEncoder) == '"12345678-1234-5678-1234-567812345678"'

# Generated at 2022-06-11 21:01:12.453072
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([]) == []
    assert encoder.default((1, 2)) == [1, 2]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(set()) == []
    assert encoder.default({1, 2}) == [1, 2]
    assert encoder.default(frozenset()) == []
    assert encoder.default({1, 1}) == [1]
    assert encoder.default(datetime(2010, 10, 1, 22, 0, tzinfo=timezone.utc)) == 1285665600.0

# Generated at 2022-06-11 21:01:14.635697
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ee = _ExtendedEncoder()
    assert ee.default(datetime.now(timezone.utc)) is not None


# noinspection PyProtectedMember

# Generated at 2022-06-11 21:01:20.430751
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(list([1,2,3])) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(defaultdict(lambda: 'default')) == '{}'
    assert _ExtendedEncoder().encode(defaultdict(lambda: [1,2,3])) == '{}'
    assert _ExtendedEncoder().encode(dict({'foo': 'bar'})) == '{"foo": "bar"}'
    assert _ExtendedEncoder().encode(set([1,2,3])) == '[1, 2, 3]'


# Generated at 2022-06-11 21:01:27.645241
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    d = datetime.now()
    u = UUID('b4eec95a-2b4c-4c23-9ccc-9e49dcc0c8e8')
    e = cfg.Animal.DOG
    assert d.timestamp() == _ExtendedEncoder().default(d)
    assert str(u) == _ExtendedEncoder().default(u)
    assert e.value == _ExtendedEncoder().default(e)



# Generated at 2022-06-11 21:01:33.104662
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = [{'a': '1', '3': 5}]
    assert _ExtendedEncoder().default(o) == o
    o = datetime.now()
    assert _ExtendedEncoder().default(o) == o.timestamp()
    o = UUID(int=1)
    assert _ExtendedEncoder().default(o) == '00000000-0000-0000-0000-000000000001'
    class Color(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3
    o = Color.GREEN
    assert _ExtendedEncoder().default(o) == 2
    o = Decimal('3.14')
    assert _ExtendedEncoder().default(o) == '3.14'
    o = Exception()
    assert _ExtendedEncoder().default(o) == repr(o)
   

# Generated at 2022-06-11 21:01:37.053771
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_ = json.dumps(['foo', {'bar': ('baz', None, 1.0, 2)}], cls=_ExtendedEncoder)
    assert json_ == '["foo", {"bar": ["baz", null, 1.0, 2]}]'

_DEFAULT_CONFIG = cfg.config.copy()


# Generated at 2022-06-11 21:01:40.873496
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(Decimal('10.1')) == "10.1"
    assert _ExtendedEncoder().default(UUID('01234567-89ab-0123-4567-89abcdef0123')) == '01234567-89ab-0123-4567-89abcdef0123'



# Generated at 2022-06-11 21:01:49.329089
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_list = ["a", "b", "c"]
    test_dict = {"a": 1, "b": 2}
    test_enum = cfg.enums({"test_enum": [("a", 1), ("b", 2)]}).test_enum
    test_datetime = datetime(2018, 8, 20, 12, 50, tzinfo=timezone.utc)
    test_decimal = Decimal("10.2")
    test_uuid = UUID("cc849fe8-03da-4e23-92f5-8e7e971f3a89")
    assert _ExtendedEncoder().default(test_list) == ["a", "b", "c"]
    assert _ExtendedEncoder().default(test_dict) == {"a": 1, "b": 2}

# Generated at 2022-06-11 21:01:50.317169
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder()



# Generated at 2022-06-11 21:01:59.005911
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import date
    from operator import itemgetter
    from typing import Dict, Union
    from dataclasses import dataclass
    
    @dataclass
    class Example:
        name: str
        amount: int
        amount_float: float
        amount_decimal: Decimal
        date: date
        
    data: Dict[str, Union[int, float, Decimal, date]] = {
        "name": "example",
        "amount": 8,
        "amount_float": 0.123456,
        "amount_decimal": Decimal("0.123456789"),
        "date": date(2020, 12, 2)
    }
    e = Example(**data)
    print(e.date)
    result_json_string = _ExtendedEncoder().encode(e)


# Generated at 2022-06-11 21:03:52.106449
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _ExtendedEncoder().default(Any)



# Generated at 2022-06-11 21:03:58.217073
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # check for custom types
    assert _ExtendedEncoder().encode(datetime(year=2019, month=1, day=1, tzinfo=timezone.utc)) == "1546300800.0"
    assert _ExtendedEncoder().encode(UUID('7b84571b-2a2a-492a-87d8-67c08b2b10e9')) == "7b84571b-2a2a-492a-87d8-67c08b2b10e9"
    assert _ExtendedEncoder().encode(Decimal('1.11')) == "1.11"
    # check empty containers
    assert _ExtendedEncoder().encode(list()) == '[]'
    assert _ExtendedEncoder().encode(tuple()) == '[]'
   

# Generated at 2022-06-11 21:04:08.884488
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import unittest
    import datetime as dt
    from uuid import UUID

    class MyEnum(Enum):
        ONE = 1
        TWO = 2

    class TestExtendedEncoder(unittest.TestCase):
        def test_default_with_empty_dict(self):
            o = {}
            expected = {}
            ec = _ExtendedEncoder()
            actual = ec.default(o)
            self.assertEqual(expected, actual)

        def test_default_with_empty_list(self):
            o = []
            expected = []
            ec = _ExtendedEncoder()
            actual = ec.default(o)
            self.assertEqual(expected, actual)

        def test_default_with_list(self):
            o = [1, 2, 3]

# Generated at 2022-06-11 21:04:16.987885
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.encode(set(['foo', 'bar'])) == '["bar", "foo"]'
    assert encoder.encode(set([1, 2])) == '[1, 2]'
    assert encoder.encode(tuple(['foo', 'bar'])) == '["foo", "bar"]'
    assert encoder.encode(tuple({1, 2})) == '[1, 2]'
    assert encoder.encode(tuple([1, 2])) == '[1, 2]'
    assert encoder.encode(frozenset({'foo', 'bar'})) == '["bar", "foo"]'
    assert encoder.encode(frozenset({1, 2})) == '[1, 2]'