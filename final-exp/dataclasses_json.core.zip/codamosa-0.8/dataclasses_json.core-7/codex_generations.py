

# Generated at 2022-06-11 20:54:39.993835
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a':1, 'b':2, 'c':3}) == '{"a": 1, "b": 2, "c": 3}'



# Generated at 2022-06-11 20:54:46.342191
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(Decimal(1)) == '1'
    assert encoder.default(datetime.now(timezone.utc)) == '1593703096.273194'
    assert encoder.default(UUID('14baa0b3-e69e-11ea-adc1-0242ac120002')) == '14baa0b3-e69e-11ea-adc1-0242ac120002'



# Generated at 2022-06-11 20:54:57.807946
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8')) == '6ba7b810-9dad-11d1-80b4-00c04fd430c8'
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc)) == 0
    assert _ExtendedEncoder().default(Enum) == Enum
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(0) == 0
    assert _ExtendedEncoder().default(0.0) == 0.0
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(b'abc') == 'abc'


# Generated at 2022-06-11 20:55:06.386040
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == []
    assert encoder.default(frozenset()) == []
    assert encoder.default(()) == []
    assert encoder.default(tuple()) == []
    assert encoder.default(MappingProxyType({"a": 1, "b": 2})) == \
        {"a": 1, "b": 2}
    assert encoder.default({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(bytearray(b"abc")) == [97, 98, 99]

# Generated at 2022-06-11 20:55:17.274502
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # type: () -> None
    from datetime import datetime
    from decimal import Decimal
    from enum import Enum
    from uuid import uuid4

    class MyEnum(Enum):
        A = 1
        B = 2

    o = {'a': 1, (1, 2): 3}
    assert _ExtendedEncoder().default(o) == {'a': 1}
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(datetime.utcnow()) == datetime.utcnow().timestamp()
    assert _ExtendedEncoder().default(uuid4()) == str(uuid4())
    assert _ExtendedEncoder().default(MyEnum.A) == 1

# Generated at 2022-06-11 20:55:27.773492
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(list()) == list()
    assert _ExtendedEncoder().default(dict()) == dict()
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default(UUID('6c3d9061-6d5f-482f-ab83-0b2a47c496a8')) == '6c3d9061-6d5f-482f-ab83-0b2a47c496a8'
    assert _ExtendedEncoder().default(Decimal('1')) == '1'
    assert _ExtendedEncoder().default(str()) == str()
    assert _ExtendedEncoder().default(int()) == int()
    assert _ExtendedEncoder().default(float()) == float

# Generated at 2022-06-11 20:55:36.579808
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default([1, 2, 3]) == [1, 2, 3]
    assert enc.default(set([1, 2, 3])) == [1, 2, 3]
    assert enc.default({"a": 1}) == {"a": 1}
    assert enc.default(datetime(2017, 1, 1, 12, 34, 56, 0, timezone.utc)) == 1483272096.0
    assert enc.default(UUID("0958a823-65d4-4a77-a4d4-8fc4f4a4a0f4")) == "0958a823-65d4-4a77-a4d4-8fc4f4a4a0f4"

# Generated at 2022-06-11 20:55:44.866566
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.fromtimestamp(0, tz=timezone.utc)) == '0'
    assert _ExtendedEncoder().encode(timezone.utc) == '"UTC"'
    assert _ExtendedEncoder().encode(UUID('680b7f94-ee49-4040-af85-d305d7af6566')) == '"680b7f94-ee49-4040-af85-d305d7af6566"'
    assert _ExtendedEncoder().encode(Decimal('0.01')) == '"0.01"'


# Generated at 2022-06-11 20:55:54.367582
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # given
    a = [
        [1, 2, 3],
        {'a': 'b', 'c': 'd'},
        ('aa', 'bb'),
        ('aa', 'cc'),
        True,
        False,
        None,
        'aaa',
        0,
        1,
        3.14,
        datetime.now(timezone.utc),
        datetime.now(timezone.utc).timestamp(),
        Decimal('3.14'),
        UUID('3a3b1d43-71e8-4c07-a604-08f7a60556f8'),
        Enum(value='AA', name='AA')
    ]

    # when
    j = json.dumps(a, cls=_ExtendedEncoder, allow_nan=True)

   

# Generated at 2022-06-11 20:55:57.407733
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    d = datetime.fromtimestamp(0, tz=timezone.utc)
    assert _ExtendedEncoder().default(d) == d.timestamp()



# Generated at 2022-06-11 20:56:35.889549
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(
        datetime(year=2000, month=1, day=1, hour=0, minute=0, second=0,
                 tzinfo=timezone.utc)) == 946684800.0
    assert _ExtendedEncoder().default(dict(a=1, b=2)) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default(['a', 'b', 'c']) == ['a', 'b', 'c']



# Generated at 2022-06-11 20:56:43.777772
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(list(range(10))) == '[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]'
    assert _ExtendedEncoder().encode(set(range(10))) == '[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]'
    assert _ExtendedEncoder().encode(dict(zip(range(10), range(10)))) == '{"0": 0, "1": 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9}'
    assert _ExtendedEncoder().encode({1, 2, 3}) == '[1, 2, 3]'
    dt = datetime.now()
    assert _ExtendedEnc

# Generated at 2022-06-11 20:56:54.432335
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(
        datetime(
            year=2020,
            month=2,
            day=2,
            hour=0,
            minute=0,
            second=0,
            tzinfo=timezone.utc)) == 1583225200.0
    assert encoder.default(UUID('c9bf9e57-1685-4c89-bafb-ff5af830be8a')) == 'c9bf9e57-1685-4c89-bafb-ff5af830be8a'
    assert encoder.default(Enum('Foo', [('Value', 1)])(1)) == 1
    assert encoder.default(Decimal('55.55')) == '55.55'

# Generated at 2022-06-11 20:57:05.976356
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import datetime
    import uuid
    from enum import Enum
    from decimal import Decimal
    from collections import OrderedDict
    class SomeType:
        pass

    class Color(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3

    obj = SomeType()
    obj.attr1 = 'string'
    obj.attr2 = 1
    dict_obj = dict(a=1, b=2)
    datetime_obj = datetime.datetime.now(tz=timezone.utc)
    uuid_obj = uuid.uuid4()
    enum_obj = Color.RED
    dec_obj = Decimal(15)
    set_obj = {'a', 'b', 'c'}
    list_obj = [1, 2, 3]
    ordered_dict_

# Generated at 2022-06-11 20:57:13.528475
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import collections.abc
    import collections
    import datetime
    import uuid
    import enum
    import decimal
    from dataclasses import dataclass
    from typing import List, Dict, Set, Tuple, Optional, Union

    @dataclass
    class X:
        x: List[int]
        y: Optional[datetime.datetime]

    x = X([1, 2, 3], datetime.datetime.now(tz=datetime.timezone.utc))

    x_json = _ExtendedEncoder().encode(x)
    y = json.loads(x_json)

    assert(y['x'] == x.x)
    assert(y['y'] == x.y.timestamp())



# Generated at 2022-06-11 20:57:19.053180
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime(2019, 6, 27, 11, 19, 0, 0, timezone.utc)) == 1561656740.0
    assert encoder.default(UUID('{12345678-1234-1234-1234-123456789012}')) == '12345678-1234-1234-1234-123456789012'
    assert encoder.default(Enum) == 'Enum'
    assert encoder.default

# Generated at 2022-06-11 20:57:27.155781
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode(datetime.now()) == '"2019-01-19T20:12:01.792901"'
    assert _ExtendedEncoder().encode(UUID('c9a646c1-f8e7-41b3-ab42-03817f8b8d5e')) == '"c9a646c1-f8e7-41b3-ab42-03817f8b8d5e"'

# Generated at 2022-06-11 20:57:37.084849
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(2) == 2

    from datetime import datetime
    assert encoder.default(datetime.now()) == datetime.now().timestamp()

    from decimal import Decimal
    assert encoder.default(Decimal('12.3456')) == '12.3456'

    from uuid import UUID
    assert encoder.default(UUID('091a11bb-c6d1-4b4c-b3a9-9d8b8fcb26be')) == '091a11bb-c6d1-4b4c-b3a9-9d8b8fcb26be'

    import enum
    class Color(enum.Enum):
        red = 0xFF0000
        green = 0x00FF00


# Generated at 2022-06-11 20:57:38.412561
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode(Decimal('1.1').quantize(Decimal('1.0'))) == '"1"'



# Generated at 2022-06-11 20:57:48.760653
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict(a=1, b=2)) == json.dumps(dict(a=1, b=2))
    assert _ExtendedEncoder().encode(list(range(10))) == json.dumps(list(range(10)))
    assert _ExtendedEncoder().encode(datetime(2016, 7, 4, 0, 0, 0, 0, timezone.utc)) == json.dumps(datetime(2016, 7, 4, 0, 0, 0, 0, timezone.utc).timestamp())

# Generated at 2022-06-11 20:58:44.603703
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(['a', 1, dict(a=2, b=3)]) == \
        ['a', 1, dict(a=2, b=3)]
    drei = 3
    assert _ExtendedEncoder().default(Decimal(drei)) == '3'
    # Does not work with pytest.fixture function, therefore omitted:
    # assert _ExtendedEncoder().default(timezone.utc) == 0


_ExtendedEncoder.default(None)  # For coverage



# Generated at 2022-06-11 20:58:53.791903
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1]) == [1]
    assert encoder.default(range(10)) == list(range(10))
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default(dict(a=1)) == {'a': 1}
    assert encoder.default(dict(zip(['a', 'b'], [1, 2]))) == {'a': 1, 'b': 2}
    assert encoder.default(datetime.now()) == datetime.now().timestamp()

# Generated at 2022-06-11 20:58:55.597010
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now()) is not None



# Generated at 2022-06-11 20:59:00.518047
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': datetime.now(timezone.utc)}) is not None
    assert _ExtendedEncoder().encode({'a': UUID('{12345678-1234-5678-1234-567812345678}')}) is not None



# Generated at 2022-06-11 20:59:04.892183
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 'simple', 'list']) == '[1, "simple", "list"]'
    assert _ExtendedEncoder().encode(dict(a=1, b='dict')) == '{"a": 1, "b": "dict"}'



# Generated at 2022-06-11 20:59:07.843982
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    l = list(range(3))
    d = {}
    with pytest.raises(TypeError):
        _ExtendedEncoder().default(l)
    with pytest.raises(TypeError):
        _ExtendedEncoder().default(d)


# Generated at 2022-06-11 20:59:16.317712
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([[1,2],[3,4]]) == "[[1, 2], [3, 4]]"
    assert _ExtendedEncoder().encode({1:2,3:4}) == "{\"1\": 2, \"3\": 4}"
    assert _ExtendedEncoder().encode(datetime.now()) == "0"
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == "0"
    assert _ExtendedEncoder().encode(UUID('4d78f5cc-4b4f-4f66-9e4b-e1d813dbc8d9')) == "\"4d78f5cc-4b4f-4f66-9e4b-e1d813dbc8d9\""


# Generated at 2022-06-11 20:59:19.819001
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder is not None

    # Test datetime
    tz = timezone.utc
    dt = datetime(2020, 5, 2, tzinfo=tz)
    dt_json = json.dumps(dt, cls=_ExtendedEncoder)
    assert dt_json == '1585936000.0'



# Generated at 2022-06-11 20:59:27.945591
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"foo": [1, 2, 3]}) == '{"foo": [1, 2, 3]}'
    assert _ExtendedEncoder().encode({"foo": {"bar": 42}}) == '{"foo": {"bar": 42}}'
    assert _ExtendedEncoder().encode({"foo": datetime.now()}) == '{"foo": %s}' % datetime.now().timestamp()
    assert _ExtendedEncoder().encode({"foo": Decimal(1)}) == '{"foo": "1"}'
    assert _ExtendedEncoder().encode({"foo": Enum(1)}) == '{"foo": 1}'


# Generated at 2022-06-11 20:59:29.250444
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    result = _ExtendedEncoder().default( datetime(2020, 6, 26, hour=16, minute=35, tzinfo=timezone.utc) )
    assert isinstance(result, int)
    assert int(result) == 1593214900


# Generated at 2022-06-11 21:00:28.820057
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode([1.2, 3.4, 5.6]) == '[1.2, 3.4, 5.6]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode({'a': 1.2, 'b': 3.4, 'c': 5.6}) == '{"a": 1.2, "b": 3.4, "c": 5.6}'

# Generated at 2022-06-11 21:00:39.694952
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def _t(o):
        d, = json.loads(json.dumps(o, cls=_ExtendedEncoder))
        return d
    with pytest.raises(TypeError):
        _t(tuple)
    assert _t({}) == {}
    assert _t([]) == []
    assert _t(set()) == []
    assert _t({1: 2}) == {'1': 2}
    assert _t({'1': 2}) == {'1': 2}
    assert _t({1.1: 2.2}) == {'1.1': 2.2}
    assert _t([1, 2, 3]) == [1, 2, 3]
    assert _t([1.1, 2.2, 3.3]) == [1.1, 2.2, 3.3]

# Generated at 2022-06-11 21:00:45.403466
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(dict(a=[], b=dict(a=2)), cls=_ExtendedEncoder).replace(" ", "") == '{"a":[],"b":{"a":2}}'
    assert json.dumps(set([1, 2, 3]), cls=_ExtendedEncoder) == '[1,2,3]'
    dt1 = datetime(year=2019, month=2, day=11, hour=9, minute=55, second=10, tzinfo=timezone.utc)
    # noinspection PyTypeChecker
    assert json.dumps(dt1, cls=_ExtendedEncoder) == '1549798510.0'
    assert json.dumps(Decimal('3.14'), cls=_ExtendedEncoder) == '"3.14"'

# Generated at 2022-06-11 21:00:55.297695
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # type: () -> None
    encoder = _ExtendedEncoder()
    assert encoder.default(dataclasses.make_dataclass('A', [('a', str)])('a')) == '{"a": "a"}'
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default([1, 3, 5, 7]) == [1, 3, 5, 7]
    assert encoder.default('abc') == 'abc'
    assert encoder.default(1234) == 1234
    assert encoder.default(1.234) == 1.234
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(None) == None

# Generated at 2022-06-11 21:01:00.390305
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # when dict
    assert _ExtendedEncoder().default({}) == {}
    # when list
    assert _ExtendedEncoder().default([]) == []
    # when UUID
    assert _ExtendedEncoder().default(UUID(int=123)) == '00000000-0000-0000-0000-0000000000123'
    # when Decimal
    assert _ExtendedEncoder().default(Decimal(1)) == '1'



# Generated at 2022-06-11 21:01:10.752051
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default(datetime(2019, 1, 1, tzinfo=timezone.utc)) == 1546300800
    assert encoder.default(UUID('602359af-ab0b-4d6f-ba6a-a6e9c9d707e1')) == \
        '602359af-ab0b-4d6f-ba6a-a6e9c9d707e1'
    class TestEnum(Enum):
        X = 1
    assert encoder.default(TestEnum.X) == 1
    assert encoder.default(Decimal('1.0')) == '1.0'



# Generated at 2022-06-11 21:01:19.076386
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().encode(
       [1, 2, 3, 'a', 'b', 'c', {'key1': 'value1'},
        {'key2': 'value2'}, {'key3': 'value3'},
        [1, 2, 3, 'a', 'b', 'c'],
        [1, 2, 3, 'a', 'b', 'c'], [1, 2, 3, 'a', 'b', 'c'],
        datetime(2020, 1, 1, tzinfo=timezone.utc),
        {'key4': datetime(2021, 1, 1, tzinfo=timezone.utc)}])

    class Custom: pass
    _ExtendedEncoder().encode(Custom())



# Generated at 2022-06-11 21:01:23.642877
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a":1}) == '{"a": 1}'

_extended_encoder = _ExtendedEncoder(ignore_nan=False, separators=(',', ':'))



# Generated at 2022-06-11 21:01:31.614173
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default({"test": 1}) == {"test": 1}
    assert _ExtendedEncoder().default([None]) == [None]
    assert _ExtendedEncoder().default(datetime(2018, 12, 18, 12, 20, 24, tzinfo=timezone.utc)) == 1_544_938_824.0
    assert _ExtendedEncoder().default(UUID('eb09aad7-d0e1-4d88-922f-396595da4d75')) == 'eb09aad7-d0e1-4d88-922f-396595da4d75'
    assert _ExtendedEncoder().default(Decimal('15.34')) == "15.34"



# Generated at 2022-06-11 21:01:40.229088
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) is None  # type: ignore
    assert _ExtendedEncoder().default(True)
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default("foo") == "foo"
    assert _ExtendedEncoder().default(UUID("9798c2ee-6dbf-46da-b6e8-75413891abf5")) == "9798c2ee-6dbf-46da-b6e8-75413891abf5"
    assert _ExtendedEncoder().default(datetime.now(timezone.utc))
    assert _ExtendedEncoder().default(Enum("test", "foo bar")) == "foo"
   

# Generated at 2022-06-11 21:04:00.933789
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(['a',1,{'t':'a'}]) == ['a',1,{'t':'a'}]
    assert _ExtendedEncoder().default({'a':1,'b':2}) == {'a':1,'b':2}
    assert _ExtendedEncoder().default(datetime.utcnow()) == datetime.utcnow().timestamp()
    assert _ExtendedEncoder().default(UUID('00000000000000000000000000000001')) == '00000000000000000000000000000001'
    assert _ExtendedEncoder().default(Decimal('1')) == '1'


# Generated at 2022-06-11 21:04:10.340964
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(['a']) == '["a"]'
    assert _ExtendedEncoder().encode(dict(a=1)) == '{"a": 1}'
    assert _ExtendedEncoder().encode(datetime.now()) == '{}'
    assert _ExtendedEncoder().encode(UUID('aad183d7-86da-4173-a1fb-8a936b5c9b09')) == '"aad183d7-86da-4173-a1fb-8a936b5c9b09"'
    assert _ExtendedEncoder().encode(Decimal('1.3')) == '"1.3"'


# Generated at 2022-06-11 21:04:18.077055
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"k": "v"}) == '{"k": "v"}'
    assert _ExtendedEncoder().encode((1, 2, 3)) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(set([1, 2, 3])) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"k": 1}) == '{"k": 1}'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == str(datetime.now(timezone.utc).timestamp())