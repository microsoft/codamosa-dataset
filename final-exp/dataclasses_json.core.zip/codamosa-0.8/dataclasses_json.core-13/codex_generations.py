

# Generated at 2022-06-11 20:54:48.191711
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([]) == "[]"
    assert _ExtendedEncoder().encode((1, [2, 3])) == "[1, [2, 3]]"
    assert _ExtendedEncoder().encode({"1": [2, 3]}) == "{\"1\": [2, 3]}"
    assert _ExtendedEncoder().encode({"1": {2: 3}}) == "{\"1\": {\"2\": 3}}"
    assert _ExtendedEncoder().encode(datetime(2019, 1, 19, 16, 26)) == "1548058160.0"

# Generated at 2022-06-11 20:54:51.931408
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.utcnow()) == 'null'
    assert _ExtendedEncoder(sort_keys=True).encode(datetime.utcnow()) == 'null'


# Generated at 2022-06-11 20:54:52.873626
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder()


# Generated at 2022-06-11 20:55:03.655582
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Instantiate a new encoder
    encoder = _ExtendedEncoder()
    # Test normal dictionary works as expected
    try:
        encoder.encode({'a': 1})
    except TypeError:
        raise AssertionError("'a': 1 not encoded ok")
    # Test subclass of UserDict works as expected
    try:
        from collections import UserDict
        class UD(UserDict):
            def __init__(self, d):
                self.data = d
        encoder.encode(UD({'a': 1}))
    except TypeError:
        raise AssertionError("'a': 1 not encoded ok")
    # Test subclass of UserList works as expected

# Generated at 2022-06-11 20:55:14.160019
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default(1) == 1
    assert enc.default(datetime(2018, 1, 1)) == 1514764800.0
    assert enc.default(UUID('6d5216f2-7c83-4b9d-b9c2-2f8cf872a863')) == \
        '6d5216f2-7c83-4b9d-b9c2-2f8cf872a863'
    assert enc.default([1, 2]) == [1, 2]
    assert enc.default({'a': 1}) == {'a': 1}
    assert enc.default((1, 2)) == [1, 2]



# Generated at 2022-06-11 20:55:21.176460
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert json.dumps(datetime(2020, 4, 1, 15, 8, 25, tzinfo=timezone.utc),
                      cls=_ExtendedEncoder) == '1585803705.0'
    assert json.dumps(UUID('9a73b48a-6b95-48d2-b002-aa873d95e3e3'),
                      cls=_ExtendedEncoder) == '"9a73b48a-6b95-48d2-b002-aa873d95e3e3"'
    assert json.dumps(ObjDefault(), cls=_ExtendedEncoder) == '"default"'
    assert json.dumps(ObjDefaultList(), cls=_ExtendedEncoder) == '["default", "default"]'

# Generated at 2022-06-11 20:55:25.211124
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert isinstance(_ExtendedEncoder().encode({}), str)
    assert isinstance(json.loads(_ExtendedEncoder().encode([])), list)
    assert isinstance(json.loads(_ExtendedEncoder().encode({'a': 1})), dict)



# Generated at 2022-06-11 20:55:34.961675
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert [1, 2, 3] == json.loads(json.dumps([1, 2, 3], cls=_ExtendedEncoder))
    assert {'a': 1, 'b': 2, 'c': 3} == json.loads(
        json.dumps({'a': 1, 'b': 2, 'c': 3}, cls=_ExtendedEncoder))
    assert 1 == json.loads(json.dumps(1, cls=_ExtendedEncoder))
    assert 1.0 == json.loads(json.dumps(1.0, cls=_ExtendedEncoder))
    assert 'a' == json.loads(json.dumps('a', cls=_ExtendedEncoder))
    now = datetime.now(timezone.utc)

# Generated at 2022-06-11 20:55:44.763892
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ec = _ExtendedEncoder()
    assert ec.default([1, 2, 3]) == [1, 2, 3]
    assert ec.default((1, 2, 3)) == [1, 2, 3]
    assert ec.default(set([1, 2, 3])) == [1, 2, 3]
    assert ec.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ec.default(datetime.now(tz=timezone.utc)) == \
        datetime.now(tz=timezone.utc).timestamp()
    assert ec.default(datetime.now()) == datetime.now().isoformat()

# Generated at 2022-06-11 20:55:54.326533
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == "null"
    assert _ExtendedEncoder().encode([1,2]) == "[1, 2]"
    assert _ExtendedEncoder().encode({"1": 2}) == '{"1": 2}'
    assert _ExtendedEncoder().encode(datetime(1970, 1, 1)) == "0.0"
    assert _ExtendedEncoder().encode(datetime(1970, 1, 1, tzinfo=timezone.utc)) == "0.0"
    assert _ExtendedEncoder().encode(UUID("00009069-0000-1000-8000-00805f9b34fb")) == \
        '"00009069-0000-1000-8000-00805f9b34fb"'

# Generated at 2022-06-11 20:56:23.589747
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert extended_encoder.default({1: 1, 2: 2}) == {1: 1, 2: 2}
    assert extended_encoder.default(datetime.fromtimestamp(0)) == 0.0
    assert extended_encoder.default(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'
    class MyEnum(Enum):
        a = 1
        b = 2
    assert extended_encoder.default(MyEnum.a) == 1

# Generated at 2022-06-11 20:56:26.859626
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    res = json.dumps(
        [1, 2, 3, {'4': 5, '6': 7}, 8, 9],
        cls=_ExtendedEncoder, sort_keys=True)
    assert res == '''[1, 2, 3, {"4": 5, "6": 7}, 8, 9]'''



# Generated at 2022-06-11 20:56:37.109042
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    # OrderedDict is subclass of Mapping
    assert encoder.default(OrderedDict([('a', 1), ('b', 2)])) == {'a': 1, 'b': 2}
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default(datetime(2012, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == 1325376000.0
    assert encoder.default(UUID('1e09c739-9e27-4b6d-920b-f7e9600de6b3')) == '1e09c739-9e27-4b6d-920b-f7e9600de6b3'
    assert enc

# Generated at 2022-06-11 20:56:41.279438
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(b'\xfc') == r'"\u00fc"'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 12, 0, 0, tzinfo=timezone.utc)) == _ExtendedEncoder().encode(1577894400.0)



# Generated at 2022-06-11 20:56:53.008940
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default((1, 2)) == [1, 2]
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()

# Generated at 2022-06-11 20:57:04.344378
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(Decimal('3.14')) == "3.14"
    assert encoder.default(datetime(2018, 1, 1)) == 1514764800.0
    assert encoder.default(datetime(2018, 1, 1, tzinfo=timezone(offset=3600))) == 1514768400.0
    assert encoder.default(UUID('cbc9ca39-33b3-4f51-b383-7cd03c18c847')) == 'cbc9ca39-33b3-4f51-b383-7cd03c18c847'
    assert encoder.default(Enum('Foo', ['bar'])('bar')) == 'bar'
    assert encoder.default() == 'null'



# Generated at 2022-06-11 20:57:12.648447
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert 'false' == json.dumps(False, cls=_ExtendedEncoder)
    assert 'true' == json.dumps(True, cls=_ExtendedEncoder)
    assert 'null' == json.dumps(None, cls=_ExtendedEncoder)
    assert '0' == json.dumps(0, cls=_ExtendedEncoder)
    assert '1' == json.dumps(1, cls=_ExtendedEncoder)
    assert [] == json.loads(json.dumps([], cls=_ExtendedEncoder))
    assert [0] == json.loads(json.dumps([0], cls=_ExtendedEncoder))
    assert [0, 1] == json.loads(json.dumps([0, 1], cls=_ExtendedEncoder))

# Generated at 2022-06-11 20:57:14.896474
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoded = json.dumps(dict(foo=1), cls=_ExtendedEncoder)
    assert encoded == '{"foo": 1}'



# Generated at 2022-06-11 20:57:25.228235
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(['a', 'b']) == ['a', 'b']
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default(datetime(2019, 2, 15, 10, 21, tzinfo=timezone.utc)) == 1550194460.0
    assert encoder.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Enum('A')) == 'A'
    assert encoder.default(Decimal('1.5')) == '1.5'

# Generated at 2022-06-11 20:57:35.248038
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    val = _ExtendedEncoder().encode([1, 2, 3])
    assert json.loads(val) == [1, 2, 3]
    val = _ExtendedEncoder().encode((1, 2, 3))
    assert json.loads(val) == [1, 2, 3]
    val = _ExtendedEncoder().encode([1, 2, {'a': 1, 'b': 2}])
    assert json.loads(val) == [1, 2, {'a': 1, 'b': 2}]
    val = _ExtendedEncoder().encode((1, 2, {'a': 1, 'b': 2}))
    assert json.loads(val) == [1, 2, {'a': 1, 'b': 2}]
    class DummyClass:
        pass
    dummy = Dummy

# Generated at 2022-06-11 20:58:30.396225
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(False) == 'false'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _ExtendedEncoder().encode('a') == '"a"'



# Generated at 2022-06-11 20:58:32.454421
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():  
    class A:
        pass
    
    assert _ExtendedEncoder().encode(A()) == json.dumps(A())


# Generated at 2022-06-11 20:58:34.510891
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.default(set("123")) == ['1', '2', '3']


# Generated at 2022-06-11 20:58:41.055134
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

    assert encoder.default(123) == json.JSONEncoder().default(123)
    assert encoder.default(123.0) == json.JSONEncoder().default(123.0)
    assert encoder.default([{'a': 'b'}]) == json.JSONEncoder().default([{'a': 'b'}])
    assert encoder.default(('a', 'b')) == json.JSONEncoder().default(('a', 'b'))
    assert encoder.default(datetime(2020, 5, 1, 12, 0, 0, tzinfo=timezone.utc)) == 1588357600.0

# Generated at 2022-06-11 20:58:51.654901
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == json.dumps([1, 2, 3])
    assert _ExtendedEncoder().encode([]) == json.dumps([])
    assert _ExtendedEncoder().encode({'one': 1, 'two': 2}) == json.dumps({'one': 1, 'two': 2})
    assert _ExtendedEncoder().encode({}) == json.dumps({})
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 1, 1, 1, 1, tzinfo=timezone.utc)) == json.dumps(
        1577836861.000001)

# Generated at 2022-06-11 20:59:02.910296
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(['x', 7, '9']) == ['x', 7, '9']
    assert _ExtendedEncoder().default({'x': 7}) == {'x': 7}
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('b4aa4d4d-b1b9-4ea4-a3b6-8d6b40c6a22f')) == 'b4aa4d4d-b1b9-4ea4-a3b6-8d6b40c6a22f'
    assert _ExtendedEncoder().default(TestEnum.A) == 1

# Generated at 2022-06-11 20:59:07.026716
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    d = {'m': {'a': 1, 'b': 2}, 'l': [1, 2], 't': (1, 2), 's': {1, 2, 3}}
    e = json.dumps(d, cls=_ExtendedEncoder, sort_keys=True)
    assert e == '{"l": [1, 2], "m": {"a": 1, "b": 2}, "s": [1, 2, 3], "t": [1, 2]}'

    u = UUID('c9bf9e57-1685-4c89-bafb-ff5af830be8a')
    e = json.dumps(u, cls=_ExtendedEncoder)

# Generated at 2022-06-11 20:59:15.455017
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(datetime(year=2019, month=7, day=2, hour=3, minute=4, second=5)) == '1562133045.0'

# Generated at 2022-06-11 20:59:21.593266
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(list([1, 2, 3])) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(datetime(1, 1, 1, 0, 0, 0, 0, timezone.utc)) == '-62135596800'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEnc

# Generated at 2022-06-11 20:59:31.570408
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default('1') == '1'
    assert encoder.default([1, 2, '3']) == [1, 2, '3']
    assert encoder.default({'a': 1, 'b': 2, 'c': '3'}) == {'a': 1, 'b': 2, 'c': '3'}
    assert encoder.default(datetime(2019, 4, 6, 18, 47, 0, tzinfo=timezone.utc)) == 155464920.0

# Generated at 2022-06-11 21:00:28.013451
# Unit test for constructor of class _ExtendedEncoder

# Generated at 2022-06-11 21:00:39.041504
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # noinspection PyProtectedMember
    params = [
        (list, "[]"),
        (dict, "{}"),
        (datetime(2019, 1, 1, tzinfo=timezone.utc), '1546300800'),
        (UUID('824f70aa-bde5-4423-b0dc-f7d9e9b3c1ab'), '824f70aa-bde5-4423-b0dc-f7d9e9b3c1ab'),
        (Decimal('123456.7890123456789'), '123456.7890123456789'),
        (Exception("foo"), '"foo"'),
    ]
    for item in params:
        assert _ExtendedEncoder().encode(item[0]) == item[1]



# Generated at 2022-06-11 21:00:45.124426
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    exc = _ExtendedEncoder()
    assert exc.default([1,2,3]) == [1,2,3]
    assert exc.default({'a':1}) == {'a':1}
    assert exc.default('g') == 'g'
    assert exc.default(datetime(2012,1,1,12,0,tzinfo=timezone.utc)) == 1325377200.0
    assert exc.default(UUID('4f1d4228-6ea4-4f07-a76c-e88c1ae8f9a9')) == '4f1d4228-6ea4-4f07-a76c-e88c1ae8f9a9'
    assert exc.default(Decimal('1.0')) == '1.0'



# Generated at 2022-06-11 21:00:54.908323
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from collections import Counter
    from datetime import date, timedelta
    from decimal import InvalidOperation
    from dataclasses_json.tests.test_common import Value

    assert _ExtendedEncoder().default(set()) == json.JSONEncoder().default(set())
    assert _ExtendedEncoder().default(Counter()) == json.JSONEncoder().default(Counter())
    assert _ExtendedEncoder().default(date.today()) == json.JSONEncoder().default(date.today())
    assert _ExtendedEncoder().default(timedelta()) == json.JSONEncoder().default(timedelta())
    assert _ExtendedEncoder().default(InvalidOperation()) == json.JSONEncoder().default(InvalidOperation())
    assert _ExtendedEncoder().default(Value()) == json.JSONEncoder().default(Value())



# Generated at 2022-06-11 21:01:03.823425
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(MappingProxyType({})) == {}
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(dict(a=1, b=2)) == dict(a=1, b=2)
    assert encoder.default(datetime.now()) > 1.0e9
    assert encoder.default(UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8')) == '6ba7b810-9dad-11d1-80b4-00c04fd430c8'
    assert encoder.default(Decimal('12.345')) == '12.345'



# Generated at 2022-06-11 21:01:06.479821
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800



# Generated at 2022-06-11 21:01:16.337140
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    a = {'a': 1}
    b = [1, 2, 3]
    lst = [a, b, 1, 2.0, True, {}, []]
    for v in lst:
        assert(json.dumps(v, cls=_ExtendedEncoder) == json.dumps(v))
    dt = datetime.now()
    dt_json = json.dumps(dt, cls=_ExtendedEncoder, default=str)
    assert(dt_json == "\"" + dt.isoformat() + '"')
    dt = datetime.now(timezone.utc)
    dt_json = json.dumps(dt, cls=_ExtendedEncoder, default=str)

# Generated at 2022-06-11 21:01:20.993837
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = datetime(2007, 11, 10, 0, 0, 0, 0, timezone.utc)
    encoded = _ExtendedEncoder().default(o)
    assert encoded == 1194729600.0
    return encoded

encoder = _ExtendedEncoder()



# Generated at 2022-06-11 21:01:22.305335
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    pass  # TODO: implement your test here


# Generated at 2022-06-11 21:01:31.285434
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert enc.default(set([1, 2, 3])) == [1, 2, 3]
    assert enc.default(frozenset([1, 2, 3])) == [1, 2, 3]
    assert enc.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert enc.default({'a': 1, 'b': 2}.items()) == [('a', 1), ('b', 2)]
    assert enc.default(datetime.now(tz=timezone.utc)) == \
           datetime.now(tz=timezone.utc).timestamp()

# Generated at 2022-06-11 21:02:48.693145
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ee = _ExtendedEncoder()
    assert ee.default(datetime.now()) is not None
    assert ee.default(Decimal(2)) == '2'
    assert ee.default(UUID('{c1f6c1b6-a7e9-4a8f-b1a1-2205e43fe870}')) == 'c1f6c1b6-a7e9-4a8f-b1a1-2205e43fe870'
    assert ee.default(Enum('Foo', ['foo'])) == 'foo'
    assert ee.default(None) is None



# Generated at 2022-06-11 21:02:53.386615
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID("cafcc9f9-158b-4d1f-a5c6-cd4d0c21a7e8")) == 'cafcc9f9-158b-4d1f-a5c6-cd4d0c21a7e8'
    assert _ExtendedEncoder().default(Decimal('1.5')) == '1.5'


# Generated at 2022-06-11 21:02:59.743020
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'x': 1, 'y': 2}) == {'x': 1, 'y': 2}
    assert encoder.default(datetime(2019, 1, 1, 0, 30, 30, tzinfo=timezone.utc)) == 1546300630
    assert encoder.default(UUID('d49378a6-c9fe-4f02-b125-89b757c97b67')) == 'd49378a6-c9fe-4f02-b125-89b757c97b67'
    assert encoder.default(Decimal('3.14')) == '3.14'



# Generated at 2022-06-11 21:03:06.632929
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import date
    assert _ExtendedEncoder().encode({
        'a': [1, 2, 3],
        'b': {'b': 1},
        'c': UUID('12345678123456781234567812345678'),
        'd': Enum('Enum', {'A': 1})('A'),
        'e': Decimal('1.2'),
        'f': date(2020,1,1)
    }).replace(' ','') == '{"a":[1,2,3],"b":{"b":1},"c":"12345678-1234-5678-1234-567812345678","d":1,"e":"1.2","f":"2020-01-01"}'



# Generated at 2022-06-11 21:03:14.275997
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def assert_encoding(obj, expected):
        assert _ExtendedEncoder().default(obj) == expected

    assert_encoding(datetime(2019, 3, 2, 1, 2, 3, 4, timezone.utc), 1551555123.000004)
    assert_encoding(UUID('0123456789abcdef0123456789abcdef'), '01234567-89ab-cdef-0123-456789abcdef')
    assert_encoding(Decimal('1234.5678'), '1234.5678')

    class EnumExample(Enum):
        ABC = 'abc'

    assert_encoding(EnumExample.ABC, 'abc')



# Generated at 2022-06-11 21:03:25.079405
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.encode({}) == '{}'

    assert encoder.encode([1, 2, 3]) == '[1, 2, 3]'
    assert encoder.encode({"1": 1, "2": 2}) == '{"1": 1, "2": 2}'

    assert encoder.encode('a') == '"a"'
    assert encoder.encode(1) == '1'
    assert encoder.encode(1.0) == '1.0'
    assert encoder.encode(None) == 'null'
    assert encoder.encode(True) == 'true'

    now = datetime.now(timezone.utc)
    assert json.loads(encoder.encode(now)) == now.timestamp()

    _

# Generated at 2022-06-11 21:03:35.109805
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.encode([]) == '[]'
    assert encoder.encode('foo') == '"foo"'
    assert encoder.encode(123) == '123'
    assert encoder.encode(None) == 'null'
    assert encoder.encode(True) == 'true'

    assert encoder.encode([1, 2, 3]) == '[\n  1,\n  2,\n  3\n]'
    assert encoder.encode({'foo': 'bar'}) == '{\n  "foo": "bar"\n}'

# Generated at 2022-06-11 21:03:46.072688
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([1,2,3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({1:2, 3:4}) == '{"1": 2, "3": 4}'
    assert _ExtendedEncoder().encode('abc') == '"abc"'
    assert _ExtendedEncoder().encode(123) == '123'
    assert _ExtendedEncoder().encode(123.45) == '123.45'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(Decimal('123.45')) == '"123.45"'


# Generated at 2022-06-11 21:03:50.463828
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1,2,3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a':1, 'b':2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(datetime.now()) == 'null'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(False) == 'false'
    assert _ExtendedEncoder().encode(None) == 'null'


# Generated at 2022-06-11 21:03:57.691093
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    class E(Enum):
        a = 0
        b = 1
    d = Decimal('7.8')