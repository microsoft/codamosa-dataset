

# Generated at 2022-06-17 17:45:38.336922
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})



# Generated at 2022-06-17 17:45:51.437141
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'
    assert _ExtendedEncoder().default(Enum('TestEnum', 'A B C')) == 'A'
    assert _ExtendedEncoder().default(Enum('TestEnum', 'A B C')) == 'A'
    assert _ExtendedEncoder().default(Enum('TestEnum', 'A B C')) == 'A'

# Generated at 2022-06-17 17:45:59.516658
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').c)

# Generated at 2022-06-17 17:46:10.791686
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(Decimal('1.23')) == '1.23'
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.23) == 1.23
    assert _ExtendedEncoder().default('abc') == 'abc'
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(None) == None
    assert _Ext

# Generated at 2022-06-17 17:46:16.115239
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.0'))



# Generated at 2022-06-17 17:46:25.007445
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'
    assert _ExtendedEncoder().default(Enum('Test', 'a b c')) == 'a'
    assert _ExtendedEncoder().default(Decimal('1.0')) == '1.0'
    assert _ExtendedEncoder().default(set()) == list(set())
    assert _ExtendedEncoder().default(dict()) == dict()
    assert _ExtendedEncoder().default(None) == None

# Generated at 2022-06-17 17:46:28.200397
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000'))
    assert _ExtendedEncoder().encode(Decimal('0.0'))



# Generated at 2022-06-17 17:46:38.906953
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800.0
    assert encoder.default(UUID('12345678-1234-5678-1234-567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('1.23')) == '1.23'
    assert encoder.default(1.23) == 1.23
    assert encoder.default('abc') == 'abc'
    assert encoder.default(True) is True
    assert encoder.default(None) is None
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder

# Generated at 2022-06-17 17:46:52.199701
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default(True) == True
    assert encoder.default(None) == None
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime(2020, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == 1577836800.0

# Generated at 2022-06-17 17:46:58.986178
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode([1, 2, 3])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2})
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(1)

# Generated at 2022-06-17 17:47:56.989937
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 0, 0, 0, timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('0.1')) == '"0.1"'
    assert _ExtendedEncoder().encode(Decimal('0.123456789012345678901234567890')) == '"0.123456789012345678901234567890"'

# Generated at 2022-06-17 17:48:05.732771
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 0, 0, 0, timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'

# Generated at 2022-06-17 17:48:15.833742
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(None) is None
    assert encoder.default('a') == 'a'
    assert encoder.default(['a', 'b']) == ['a', 'b']
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default(datetime.now()) == datetime.now().timestamp()

# Generated at 2022-06-17 17:48:25.199245
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3})

_extended_encoder = _ExtendedEncoder()



# Generated at 2022-06-17 17:48:30.016734
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3})
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(False)

# Generated at 2022-06-17 17:48:40.841997
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678-1234-5678-1234-567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'

# Generated at 2022-06-17 17:48:53.678806
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc)) == 0.0
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().default(Decimal('0.0')) == '0.0'
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(frozenset()) == []
    assert _ExtendedEncoder().default(dict()) == {}
    assert _ExtendedEncoder().default(list()) == []
    assert _ExtendedEncoder().default(tuple()) == []
    assert _ExtendedEncoder().default(str()) == ''
    assert _ExtendedEncoder

# Generated at 2022-06-17 17:49:05.080615
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b'})
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.1)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(False)
    assert _ExtendedEncoder().en

# Generated at 2022-06-17 17:49:14.401930
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3})


# Generated at 2022-06-17 17:49:20.733587
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').c)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a.value)

# Generated at 2022-06-17 17:50:20.699214
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3, "d": 4}) == '{"a": 1, "b": 2, "c": 3, "d": 4}'

# Generated at 2022-06-17 17:50:28.608594
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000'))
    assert _ExtendedEncoder().encode(Decimal('0.0'))
    assert _ExtendedEncoder().encode(Enum('Test', 'A'))
    assert _ExtendedEncoder().encode(dict())
    assert _ExtendedEncoder().encode(list())
    assert _ExtendedEncoder().encode(set())
    assert _ExtendedEncoder().encode(frozenset())



# Generated at 2022-06-17 17:50:39.487050
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
   

# Generated at 2022-06-17 17:50:52.135528
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a)
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2})
    assert _ExtendedEncoder().encode([1, 2, 3])
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.0)
    assert _ExtendedEnc

# Generated at 2022-06-17 17:50:56.554536
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'
    assert _ExtendedEncoder().encode(dict()) == '{}'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 0, 0, 0, timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal('1.0')) == '"1.0"'

# Generated at 2022-06-17 17:51:07.623328
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(False) == 'false'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.1) == '1.1'
    assert _ExtendedEncoder().encode('a') == '"a"'
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'

# Generated at 2022-06-17 17:51:15.086015
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(False)
    assert _ExtendedEncoder().encode

# Generated at 2022-06-17 17:51:25.338986
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default('1') == '1'
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800.0

# Generated at 2022-06-17 17:51:32.327306
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now()) is not None
    assert encoder.default(UUID('12345678123456781234567812345678')) is not None
    assert encoder.default(Decimal('1.23')) is not None
    assert encoder.default(Enum('TestEnum', 'a b c')) is not None
    assert encoder.default(set()) is not None
    assert encoder.default(frozenset()) is not None
    assert encoder.default(dict()) is not None
    assert encoder.default(list()) is not None
    assert encoder.default(tuple()) is not None
    assert encoder.default(1) is not None
    assert encoder.default(1.0) is not None
    assert encoder

# Generated at 2022-06-17 17:51:39.557762
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'


# Generated at 2022-06-17 17:54:02.653448
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))

# Generated at 2022-06-17 17:54:11.848791
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.0'))
    assert _ExtendedEncoder().encode(Decimal('1.0'))
    assert _ExtendedEncoder().encode(Decimal('1.0'))
    assert _ExtendedEncoder().encode(Decimal('1.0'))
    assert _ExtendedEncoder().encode(Decimal('1.0'))
    assert _ExtendedEncoder().encode(Decimal('1.0'))
    assert _ExtendedEncoder().encode(Decimal('1.0'))
    assert _ExtendedEncoder

# Generated at 2022-06-17 17:54:19.798147
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
   

# Generated at 2022-06-17 17:54:23.399086
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))



# Generated at 2022-06-17 17:54:31.978654
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now()) is not None
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) is not None
    assert _ExtendedEncoder().default(Decimal('1.1')) is not None
    assert _ExtendedEncoder().default(Enum('Test', 'A B C')) is not None
    assert _ExtendedEncoder().default(['a', 'b', 'c']) is not None
    assert _ExtendedEncoder().default({'a': 'b', 'c': 'd'}) is not None
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.1) == 1.1

# Generated at 2022-06-17 17:54:40.202694
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800.0
    assert _ExtendedEncoder().default(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(Decimal('1.23')) == '1.23'
    assert _ExtendedEncoder().default(Decimal('1.23')) == '1.23'
    assert _ExtendedEncoder().default(Decimal('1.23')) == '1.23'
    assert _ExtendedEncoder().default(Decimal('1.23')) == '1.23'
    assert _Extended

# Generated at 2022-06-17 17:54:52.750056
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3, "d": 4}) == '{"a": 1, "b": 2, "c": 3, "d": 4}'

# Generated at 2022-06-17 17:54:59.470124
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23e-10')) == '"1.23e-10"'
    assert _ExtendedEncoder().encode(Decimal('1.23e+10')) == '"1.23e+10"'

# Generated at 2022-06-17 17:55:06.154791
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(False)
    assert _ExtendedEncoder().encode(1)

# Generated at 2022-06-17 17:55:15.657767
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a'))