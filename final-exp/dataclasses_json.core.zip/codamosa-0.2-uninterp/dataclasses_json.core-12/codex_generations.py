

# Generated at 2022-06-17 17:45:43.013676
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('e8e8e8e8-e8e8-e8e8-e8e8-e8e8e8e8e8e8'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('Test', 'test'))
    assert _ExtendedEncoder().encode(Enum('Test', 'test'))
    assert _ExtendedEncoder().encode(Enum('Test', 'test'))
    assert _ExtendedEncoder().encode(Enum('Test', 'test'))
    assert _ExtendedEncoder().encode(Enum('Test', 'test'))
    assert _Ext

# Generated at 2022-06-17 17:45:53.134894
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(datetime(2019, 1, 1, 0, 0, 0, 0, timezone.utc)) == '1546300800.0'
    assert _ExtendedEncoder().encode(UUID('12345678-1234-5678-1234-567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'


# Generated at 2022-06-17 17:46:00.489431
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))

# Generated at 2022-06-17 17:46:11.509684
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').c)
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').a.value)

# Generated at 2022-06-17 17:46:22.497899
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.2')) == '"1.2"'
    assert _ExtendedEncoder().encode(Decimal('1.2e-2')) == '"0.012"'
    assert _ExtendedEncoder().encode(Decimal('1.2e-3')) == '"0.0012"'

# Generated at 2022-06-17 17:46:32.475516
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('3.14'))
    assert _ExtendedEncoder().encode(Enum('test', 'a b c'))
    assert _ExtendedEncoder().encode([1, 2, 3])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2})
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(False)
    assert _ExtendedEncoder().encode(1)

# Generated at 2022-06-17 17:46:41.989390
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').c)
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').a.value)

# Generated at 2022-06-17 17:46:51.312915
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))

# Generated at 2022-06-17 17:46:58.418557
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '0.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _Ext

# Generated at 2022-06-17 17:47:08.998512
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(set([1, 2, 3])) == '[1,2,3]'
    assert _ExtendedEncoder().encode(frozenset([1, 2, 3])) == '[1,2,3]'
    assert _ExtendedEncoder().encode(dict(a=1, b=2)) == '{"a":1,"b":2}'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEnc

# Generated at 2022-06-17 17:47:39.547935
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.1)
    assert _ExtendedEncoder().encode('1')
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode([1, 2, 3])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2})
    assert _ExtendedEncoder().encode(set([1, 2, 3]))


# Generated at 2022-06-17 17:47:52.498367
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now()) == datetime.now().timestamp()
    assert encoder.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('1.23')) == '1.23'
    assert encoder.default(Enum('TestEnum', 'A B C')) == 'A'
    assert encoder.default(Enum('TestEnum', 'A B C')) == 'A'
    assert encoder.default(Enum('TestEnum', 'A B C')) == 'A'

# Generated at 2022-06-17 17:48:02.597252
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _Ext

# Generated at 2022-06-17 17:48:12.529405
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.2345')) == '"1.2345"'
    assert _ExtendedEncoder().encode(Decimal('0.12345')) == '"0.12345"'
    assert _ExtendedEncoder().encode(Decimal('0.012345')) == '"0.012345"'
    assert _ExtendedEnc

# Generated at 2022-06-17 17:48:19.571295
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '0.0'
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000')) == '"123e4567-e89b-12d3-a456-426655440000"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEnc

# Generated at 2022-06-17 17:48:30.526918
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c').c)
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c').a.value)
    assert _ExtendedEncoder

# Generated at 2022-06-17 17:48:41.252119
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.23)
    assert _

# Generated at 2022-06-17 17:48:53.847728
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc))
    assert _ExtendedEncoder().default(UUID('{12345678-1234-5678-1234-567812345678}'))
    assert _ExtendedEncoder().default(Decimal('1.23'))
    assert _ExtendedEncoder().default(Decimal('1.23e-10'))
    assert _ExtendedEncoder().default(Decimal('1.23e+10'))
    assert _ExtendedEncoder().default(Decimal('1.23E-10'))
    assert _ExtendedEncoder().default(Decimal('1.23E+10'))
    assert _ExtendedEncoder().default(Decimal('1.23E10'))

# Generated at 2022-06-17 17:49:05.237884
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default(True) == True
    assert encoder.default(None) == None
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert encoder.default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800.0

# Generated at 2022-06-17 17:49:16.892233
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b'})
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.23)
    assert _ExtendedEncoder().en

# Generated at 2022-06-17 17:49:53.005486
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}'))
    assert _ExtendedEncoder().encode(Decimal('1.0'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(set())
    assert _ExtendedEncoder().encode(frozenset())
    assert _ExtendedEncoder().encode(dict())
    assert _ExtendedEncoder().encode(list())
    assert _ExtendedEncoder().encode(tuple())
    assert _ExtendedEncoder().encode(1)

# Generated at 2022-06-17 17:50:02.190059
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678-1234-5678-1234-567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23e-10')) == '"1.23e-10"'
    assert _ExtendedEncoder().encode(Decimal('1.23e+10')) == '"1.23e+10"'
    assert _ExtendedEncoder().encode

# Generated at 2022-06-17 17:50:10.665274
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'A B C'))
    assert _ExtendedEncoder().encode(Enum('Test', 'A B C').A)
    assert _ExtendedEncoder().encode(Enum('Test', 'A B C').B)
    assert _ExtendedEncoder().encode(Enum('Test', 'A B C').C)
    assert _ExtendedEncoder().encode(Enum('Test', 'A B C').A.value)

# Generated at 2022-06-17 17:50:21.479376
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now()) is not None
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) is not None
    assert _ExtendedEncoder().encode(Decimal('1.23')) is not None
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c')) is not None
    assert _ExtendedEncoder().encode(['a', 'b', 'c']) is not None
    assert _ExtendedEncoder().encode(('a', 'b', 'c')) is not None
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'}) is not None

# Generated at 2022-06-17 17:50:30.994348
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23e-5')) == '"0.0000123"'
    assert _ExtendedEncoder().encode(Decimal('1.23e-6')) == '"0.00000123"'

# Generated at 2022-06-17 17:50:38.937106
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'


# Generated at 2022-06-17 17:50:51.881129
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2})
    assert _ExtendedEncoder().encode([1, 2, 3])
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.23)
    assert _ExtendedEncoder().encode('abc')

# Generated at 2022-06-17 17:50:57.591796
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(0) == 0
    assert encoder.default(0.0) == 0.0
    assert encoder.default('') == ''
    assert encoder.default([]) == []
    assert encoder.default({}) == {}
    assert encoder.default(set()) == []
    assert encoder.default(frozenset()) == []
    assert encoder.default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800.0

# Generated at 2022-06-17 17:51:05.457241
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})


# Generated at 2022-06-17 17:51:14.127489
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default(1.1) == 1.1
    assert encoder.default(True) == True
    assert encoder.default(None) == None
    assert encoder.default('a') == 'a'
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(datetime(2020, 1, 1, 1, 1, 1, tzinfo=timezone.utc)) == 1577836861

# Generated at 2022-06-17 17:52:16.591335
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('0b9d9b8a-f0e9-4f2d-b2f7-a5d5c5b9c9a1'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c'))
    assert _ExtendedEncoder().encode(set())
    assert _ExtendedEncoder().encode(frozenset())
    assert _ExtendedEncoder().encode(dict())
    assert _ExtendedEncoder().encode(list())
    assert _ExtendedEncoder().encode(tuple())

# Generated at 2022-06-17 17:52:21.733002
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '0.0'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal('1.0')) == '"1.0"'
    assert _ExtendedEncoder().encode

# Generated at 2022-06-17 17:52:27.779274
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'A B C'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3})


# Generated at 2022-06-17 17:52:36.186004
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 0, 0, 0, timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('-1.23')) == '"-1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23E+2')) == '"1.23E+2"'

# Generated at 2022-06-17 17:52:44.854208
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').c)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a.value)

# Generated at 2022-06-17 17:52:54.396850
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(False) == 'false'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.1) == '1.1'
    assert _ExtendedEncoder().encode('a') == '"a"'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'

# Generated at 2022-06-17 17:53:03.320172
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'

# Generated at 2022-06-17 17:53:10.330142
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3, "d": 4}) == '{"a": 1, "b": 2, "c": 3, "d": 4}'

# Generated at 2022-06-17 17:53:19.091785
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').c)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _Extended

# Generated at 2022-06-17 17:53:27.997150
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Decimal('1.23e-10'))
    assert _ExtendedEncoder().encode(Decimal('1.23e+10'))
    assert _ExtendedEncoder().encode(Decimal('1.23e-10'))
    assert _ExtendedEncoder().encode(Decimal('1.23e+10'))
    assert _ExtendedEncoder().encode(Decimal('1.23e-10'))