

# Generated at 2022-06-17 17:45:52.074764
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == list(set())
    assert encoder.default(frozenset()) == list(frozenset())
    assert encoder.default(dict()) == dict()
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal(1.0)) == '1.0'
    assert encoder.default(1) == 1


# Generated at 2022-06-17 17:46:00.021460
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now(timezone.utc))
    assert encoder.default(UUID('{12345678-1234-5678-1234-567812345678}'))
    assert encoder.default(Decimal('1.23'))
    assert encoder.default(Enum('Enum', 'a b c'))
    assert encoder.default(Enum('Enum', 'a b c'))
    assert encoder.default(Enum('Enum', 'a b c'))
    assert encoder.default(Enum('Enum', 'a b c'))
    assert encoder.default(Enum('Enum', 'a b c'))
    assert encoder.default(Enum('Enum', 'a b c'))


# Generated at 2022-06-17 17:46:11.287232
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(set())
    assert _ExtendedEncoder().encode(frozenset())
    assert _ExtendedEncoder().encode(dict())
    assert _ExtendedEncoder().encode(list())
    assert _ExtendedEncoder().encode(tuple())
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.1)
    assert _ExtendedEnc

# Generated at 2022-06-17 17:46:22.454420
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('01234567-89ab-cdef-0123-456789abcdef'))
    assert _ExtendedEncoder().encode(Decimal('1.0'))
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c').c)
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c').a.value)


# Generated at 2022-06-17 17:46:28.890244
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})


# Generated at 2022-06-17 17:46:39.942832
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '0.0'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'
    assert _ExtendedEncoder().encode(Decimal('0.0')) == '"0.0"'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode

# Generated at 2022-06-17 17:46:52.570616
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23e-4')) == '"0.000123"'
    assert _ExtendedEncoder().encode(Decimal('1.23e+4')) == '"12300"'
    assert _ExtendedEncoder().encode(Decimal('1.23e+4'))

# Generated at 2022-06-17 17:47:03.830109
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3, "d": 4}) == '{"a": 1, "b": 2, "c": 3, "d": 4}'

# Generated at 2022-06-17 17:47:13.825064
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(set())
    assert _ExtendedEncoder().encode(frozenset())
    assert _ExtendedEncoder().encode(dict())
    assert _ExtendedEncoder().encode(list())
    assert _ExtendedEncoder().encode(tuple())
    assert _ExtendedEncoder().encode(1)

# Generated at 2022-06-17 17:47:25.040992
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3, "d": 4}) == '{"a": 1, "b": 2, "c": 3, "d": 4}'

# Generated at 2022-06-17 17:48:04.104220
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})



# Generated at 2022-06-17 17:48:13.424624
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('1.23')) == '1.23'
    assert encoder.default(Decimal('1.23e-10')) == '1.23e-10'
    assert encoder.default(Decimal('1.23e+10')) == '1.23e+10'
    assert encoder.default(Decimal('1.23e+10')) == '1.23e+10'

# Generated at 2022-06-17 17:48:20.188389
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '{}'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'

# Generated at 2022-06-17 17:48:30.609511
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 0, 0, 0, timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23456789012345678901234567890')) == '1.23456789012345678901234567890'
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c')) == 'a'

# Generated at 2022-06-17 17:48:41.317084
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc))
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000'))
    assert _ExtendedEncoder().default(Decimal('1.0'))
    assert _ExtendedEncoder().default(Decimal('1.0'))
    assert _ExtendedEncoder().default(Decimal('1.0'))
    assert _ExtendedEncoder().default(Decimal('1.0'))
    assert _ExtendedEncoder().default(Decimal('1.0'))
    assert _ExtendedEncoder().default(Decimal('1.0'))
    assert _ExtendedEncoder().default(Decimal('1.0'))
    assert _ExtendedEncoder().default(Decimal('1.0'))

# Generated at 2022-06-17 17:48:53.143860
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').c)



# Generated at 2022-06-17 17:49:04.675369
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c').c)
    assert _ExtendedEncoder().encode([1, 2, 3])

# Generated at 2022-06-17 17:49:10.751731
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.23)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(None)
    assert _

# Generated at 2022-06-17 17:49:19.161246
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(['a', 'b']) == '["a", "b"]'
    assert _ExtendedEncoder().encode(('a', 'b')) == '["a", "b"]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(set(['a', 'b'])) == '["a", "b"]'
    assert _ExtendedEncoder().encode(frozenset(['a', 'b'])) == '["a", "b"]'
    assert _ExtendedEncoder().encode(datetime(2019, 1, 1, tzinfo=timezone.utc)) == '1546300800.0'
    assert _Extended

# Generated at 2022-06-17 17:49:29.301365
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('1.23')) == '1.23'
    assert encoder.default(Enum('TestEnum', 'a b c')) == 'a'
    assert encoder.default(Enum('TestEnum', 'a b c', module='test_module')) == 'a'



# Generated at 2022-06-17 17:50:31.544008
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 0, 0, 0, timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678-1234-5678-1234-567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'

# Generated at 2022-06-17 17:50:39.752423
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.0'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})



# Generated at 2022-06-17 17:50:50.511515
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('test', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})



# Generated at 2022-06-17 17:50:56.793739
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime(2020, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == 1577836800.0
    assert encoder.default(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('1.23')) == '1.23'
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default(frozenset([1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-17 17:51:07.698180
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))

# Generated at 2022-06-17 17:51:15.160678
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'
    assert _ExtendedEncoder().encode(dict()) == '{}'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '0'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode

# Generated at 2022-06-17 17:51:25.373102
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now())
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().default(Decimal('1.23'))
    assert _ExtendedEncoder().default(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().default(set())
    assert _ExtendedEncoder().default(frozenset())
    assert _ExtendedEncoder().default(dict())
    assert _ExtendedEncoder().default(list())
    assert _ExtendedEncoder().default(tuple())
    assert _ExtendedEncoder().default(1)
    assert _ExtendedEncoder().default(1.23)
    assert _ExtendedEncoder().default('abc')

# Generated at 2022-06-17 17:51:29.200934
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))



# Generated at 2022-06-17 17:51:40.436130
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
   

# Generated at 2022-06-17 17:51:52.888981
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime(2020, 1, 1, 12, 0, 0, tzinfo=timezone.utc)) == 1577836800.0
    assert encoder.default(UUID('12345678-1234-5678-1234-567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('1.23')) == '1.23'
    assert encoder.default(None) is None

# Generated at 2022-06-17 17:54:23.015475
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(Decimal('1.23')) == '1.23'
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default('a') == 'a'
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
   

# Generated at 2022-06-17 17:54:31.577804
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(
        [1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(
        {'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(
        datetime(1970, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == '0.0'
    assert _ExtendedEncoder().encode(
        UUID('12345678123456781234567812345678')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(
        Decimal('1.23')) == '"1.23"'



# Generated at 2022-06-17 17:54:39.967083
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'A B C'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3})
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(False)
    assert _ExtendedEncoder().encode(1)
    assert _

# Generated at 2022-06-17 17:54:52.717403
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(set())
    assert _ExtendedEncoder().encode(frozenset())
    assert _ExtendedEncoder().encode(dict())
    assert _ExtendedEncoder().encode(list())
    assert _ExtendedEncoder().encode(tuple())
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(True)

# Generated at 2022-06-17 17:54:59.421637
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').c)
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c')._value_)

# Generated at 2022-06-17 17:55:04.500663
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('Test', 'A'))
    assert _ExtendedEncoder().encode(dict(a=1))
    assert _ExtendedEncoder().encode(list(range(10)))


# Generated at 2022-06-17 17:55:09.832227
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'
    assert _ExtendedEncoder().encode(Decimal('0.1')) == '"0.1"'
    assert _ExtendedEncoder().encode(Decimal('0.1')) == '"0.1"'
    assert _ExtendedEncoder().encode(Decimal('0.1')) == '"0.1"'
    assert _ExtendedEncoder().encode(Decimal('0.1')) == '"0.1"'

# Generated at 2022-06-17 17:55:18.673067
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').c)

# Generated at 2022-06-17 17:55:23.891327
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))

