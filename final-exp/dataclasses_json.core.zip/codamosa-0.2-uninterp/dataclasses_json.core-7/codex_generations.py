

# Generated at 2022-06-17 17:45:49.910349
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('a', 'b'))
    assert _ExtendedEncoder().encode(['a', 'b'])
    assert _ExtendedEncoder().encode({'a': 'b'})
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.23)
    assert _ExtendedEncoder().encode('abc')



# Generated at 2022-06-17 17:45:54.628671
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').c)



# Generated at 2022-06-17 17:46:01.398743
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode([1, 2, 3])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2})
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.1)
    assert _ExtendedEncoder().encode('a')
    assert _ExtendedEncoder().encode(True)

# Generated at 2022-06-17 17:46:07.839981
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now())
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().default(Decimal('1.23'))
    assert _ExtendedEncoder().default(Enum('TestEnum', 'a b c'))



# Generated at 2022-06-17 17:46:14.904395
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc))
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().default(Decimal('1.23'))
    assert _ExtendedEncoder().default(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().default(['a', 'b', 'c'])
    assert _ExtendedEncoder().default({'a': 1, 'b': 2, 'c': 3})
    assert _ExtendedEncoder().default(None)
    assert _ExtendedEncoder().default(True)
    assert _ExtendedEncoder().default(False)
    assert _ExtendedEncoder().default(1)
    assert _ExtendedEncoder

# Generated at 2022-06-17 17:46:24.553148
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default(UUID('b4c3f4e3-b4c3-f4e3-b4c3-f4e3b4c3f4e3')) == 'b4c3f4e3-b4c3-f4e3-b4c3-f4e3b4c3f4e3'
    assert _ExtendedEncoder().default(Decimal('1.0')) == '1.0'
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'
    assert _ExtendedEncoder().default(Decimal('1.01')) == '1.01'

# Generated at 2022-06-17 17:46:32.093313
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('12.34'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').c)
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').a.value)

# Generated at 2022-06-17 17:46:39.542997
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'A B C'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})


# Generated at 2022-06-17 17:46:52.515547
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('A', 'A'))
    assert _ExtendedEncoder().encode(dict(a=1))
    assert _ExtendedEncoder().encode(list(range(10)))
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.23)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode('abc')



# Generated at 2022-06-17 17:46:58.892795
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000'))
    assert _ExtendedEncoder().encode(Enum('Test', {'a': 1}))
    assert _ExtendedEncoder().encode(Decimal('1.1'))


# Generated at 2022-06-17 17:47:36.570999
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))



# Generated at 2022-06-17 17:47:46.549335
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 0, 0, 0, timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23e-10')) == '"1.23e-10"'
    assert _ExtendedEncoder().encode(Decimal('1.23e+10')) == '"1.23e+10"'
    assert _Ext

# Generated at 2022-06-17 17:47:57.083497
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '{}'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'

# Generated at 2022-06-17 17:48:05.804137
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.2'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3})
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(False)
    assert _ExtendedEncoder().encode(1)
    assert _

# Generated at 2022-06-17 17:48:15.832552
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default('a') == 'a'
    assert _ExtendedEncoder().default(['a']) == ['a']
    assert _ExtendedEncoder().default({'a': 'b'}) == {'a': 'b'}
    assert _ExtendedEncoder().default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800.0

# Generated at 2022-06-17 17:48:24.831702
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now())
    assert _ExtendedEncoder().default(UUID('123e4567-e89b-12d3-a456-426655440000'))
    assert _ExtendedEncoder().default(Decimal('1.23'))
    assert _ExtendedEncoder().default(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().default(set())
    assert _ExtendedEncoder().default(frozenset())
    assert _ExtendedEncoder().default(dict())
    assert _ExtendedEncoder().default(list())
    assert _ExtendedEncoder().default(tuple())



# Generated at 2022-06-17 17:48:31.081194
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('A', 'A'))
    assert _ExtendedEncoder().encode(Enum('A', 'A', 'A'))
    assert _ExtendedEncoder().encode(Enum('A', 'A', 'A', 'A'))
    assert _ExtendedEncoder().encode(Enum('A', 'A', 'A', 'A', 'A'))

# Generated at 2022-06-17 17:48:39.816559
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3})



# Generated at 2022-06-17 17:48:53.241543
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'

# Generated at 2022-06-17 17:49:04.674416
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(1970, 1, 1, tzinfo=timezone.utc)) == '0.0'
    assert _ExtendedEncoder().encode(datetime(1970, 1, 1)) == '0.0'
    assert _ExtendedEncoder().encode(UUID('a8a0d9a5-c9a1-4f9d-a2a7-a2a8a9a0a9a5')) == '"a8a0d9a5-c9a1-4f9d-a2a7-a2a8a9a0a9a5"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'

# Generated at 2022-06-17 17:49:58.485781
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode

# Generated at 2022-06-17 17:50:07.422958
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Exception('test')) == '"test"'


# Generated at 2022-06-17 17:50:12.741791
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now()) is not None
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) is not None
    assert _ExtendedEncoder().encode(Decimal('1.23')) is not None
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c')) is not None
    assert _ExtendedEncoder().encode(['a', 'b', 'c']) is not None
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'}) is not None


# Generated at 2022-06-17 17:50:24.279829
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(1970, 1, 1, tzinfo=timezone.utc)) == '0.0'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'
    assert _ExtendedEncoder().encode(Decimal('0.0')) == '"0.0"'
    assert _ExtendedEncoder().encode(Decimal('0')) == '"0"'
    assert _ExtendedEncoder().encode(Decimal('0.00')) == '"0.00"'
    assert _ExtendedEncoder().encode(Decimal('0.000')) == '"0.000"'

# Generated at 2022-06-17 17:50:32.765434
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').c)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a.value)

# Generated at 2022-06-17 17:50:43.068535
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('1.234')) == '1.234'
    assert encoder.default(set()) == []
    assert encoder.default(frozenset()) == []
    assert encoder.default(dict()) == {}
    assert encoder.default(list()) == []
    assert encoder.default(tuple()) == []
    assert encoder.default(1) == 1

# Generated at 2022-06-17 17:50:53.460176
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3, "d": 4}) == '{"a": 1, "b": 2, "c": 3, "d": 4}'

# Generated at 2022-06-17 17:51:04.517654
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.1) == 1.1
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default('abc') == 'abc'
    assert _ExtendedEncoder().default(['a', 1]) == ['a', 1]
    assert _ExtendedEncoder().default({'a': 1}) == {'a': 1}
    assert _ExtendedEncoder().default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800.0

# Generated at 2022-06-17 17:51:13.531215
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict(a=1)) == '{"a": 1}'
    assert _ExtendedEncoder().encode(list(range(10))) == '[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'


# Generated at 2022-06-17 17:51:24.741095
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default('a') == 'a'
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800.0

# Generated at 2022-06-17 17:53:43.351562
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('1.23')) == '1.23'
    assert encoder.default(Decimal('1.23')) == '1.23'
    assert encoder.default(set()) == []
    assert encoder.default(frozenset()) == []
    assert encoder.default(tuple()) == []
    assert encoder.default(dict()) == {}
    assert encoder.default(list()) == []


# Generated at 2022-06-17 17:53:54.699891
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode([1, 2, 3])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2})
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.2)
    assert _ExtendedEncoder().encode('abc')
    assert _ExtendedEncoder().encode(True)

# Generated at 2022-06-17 17:54:02.680095
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict(a=1)) == '{"a": 1}'
    assert _ExtendedEncoder().encode(list(range(3))) == '[0, 1, 2]'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('a9f9d8c4-b2f2-4d2d-8f8d-1e1e1e1e1e1e')) == '"a9f9d8c4-b2f2-4d2d-8f8d-1e1e1e1e1e1e"'

# Generated at 2022-06-17 17:54:11.918216
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime(2020, 1, 1, 12, 0, 0, tzinfo=timezone.utc)) == 1577836800.0
    assert encoder.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('0.1')) == '0.1'

# Generated at 2022-06-17 17:54:17.342688
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now()) is not None
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) is not None
    assert _ExtendedEncoder().encode(Decimal('1.0')) is not None
    assert _ExtendedEncoder().encode(Enum) is not None
    assert _ExtendedEncoder().encode(Enum) is not None
    assert _ExtendedEncoder().encode(Enum) is not None


# Generated at 2022-06-17 17:54:22.216303
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'



# Generated at 2022-06-17 17:54:30.918142
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default('a') == 'a'
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800.0

# Generated at 2022-06-17 17:54:36.401439
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.0'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b'))
    assert _ExtendedEncoder().encode(['a', 'b'])
    assert _ExtendedEncoder().encode({'a': 'b'})



# Generated at 2022-06-17 17:54:43.563550
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('Enum', 'a b c').c)

# Generated at 2022-06-17 17:54:54.158157
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': datetime.now()})
    assert _ExtendedEncoder().encode({'a': UUID('{12345678-1234-5678-1234-567812345678}')})
    assert _ExtendedEncoder().encode({'a': Decimal('1.23')})
    assert _ExtendedEncoder().encode({'a': Enum('a', 'b')})
    assert _ExtendedEncoder().encode({'a': [1, 2, 3]})
    assert _ExtendedEncoder().encode({'a': {'b': 1}})
    assert _ExtendedEncoder().encode({'a': None})
    assert _ExtendedEncoder().encode({'a': True})