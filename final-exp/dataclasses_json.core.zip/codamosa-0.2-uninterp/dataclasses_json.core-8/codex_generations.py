

# Generated at 2022-06-17 17:45:51.803173
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23e-10')) == '"0.000000000123"'
    assert _ExtendedEncoder().encode(Decimal('1.23e+10')) == '"12300000000.0"'

# Generated at 2022-06-17 17:45:59.805659
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now()) == datetime.now().timestamp()
    assert encoder.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('1.23')) == '1.23'
    assert encoder.default(Enum('TestEnum', 'A B C')) == 'A'
    assert encoder.default(Enum('TestEnum', 'A B C')) == 'A'
    assert encoder.default(Enum('TestEnum', 'A B C')) == 'A'

# Generated at 2022-06-17 17:46:08.855971
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})



# Generated at 2022-06-17 17:46:15.419237
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'

# Generated at 2022-06-17 17:46:25.472677
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
   

# Generated at 2022-06-17 17:46:32.781587
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'

# Generated at 2022-06-17 17:46:42.226613
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.1)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode('a')
    assert _ExtendedEncoder().encode([1, 2, 3])

# Generated at 2022-06-17 17:46:53.162302
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2019, 1, 1, tzinfo=timezone.utc)) == '1546300800.0'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'

# Generated at 2022-06-17 17:47:04.575288
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.1) == 1.1
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default('abc') == 'abc'
    assert _ExtendedEncoder().default(['a', 'b']) == ['a', 'b']
    assert _ExtendedEncoder().default({'a': 'b'}) == {'a': 'b'}
    assert _ExtendedEncoder().default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800.0

# Generated at 2022-06-17 17:47:14.448065
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now())
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().default(Decimal('1.23'))
    assert _ExtendedEncoder().default(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().default(['a', 'b', 'c'])
    assert _ExtendedEncoder().default({'a': 1, 'b': 2, 'c': 3})
    assert _ExtendedEncoder().default(None)
    assert _ExtendedEncoder().default(1)
    assert _ExtendedEncoder().default(1.23)
    assert _ExtendedEncoder().default('abc')
    assert _ExtendedEncoder().default(True)


# Generated at 2022-06-17 17:47:50.569257
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b'})


# Generated at 2022-06-17 17:48:01.432141
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000'))
    assert _ExtendedEncoder().encode(Decimal('0.0'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'A B C'))
    assert _ExtendedEncoder().encode(dict(a=1, b=2))
    assert _ExtendedEncoder().encode(list(range(10)))
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(False)
    assert _ExtendedEncoder().encode(0)

# Generated at 2022-06-17 17:48:11.592839
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict(a=1)) == '{"a": 1}'
    assert _ExtendedEncoder().encode(list(range(3))) == '[0, 1, 2]'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'

# Generated at 2022-06-17 17:48:19.430956
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3, "d": 4}) == '{"a": 1, "b": 2, "c": 3, "d": 4}'

# Generated at 2022-06-17 17:48:30.485792
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3, "d": 4}) == '{"a": 1, "b": 2, "c": 3, "d": 4}'

# Generated at 2022-06-17 17:48:41.208805
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _

# Generated at 2022-06-17 17:48:53.823910
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800.0
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'

# Generated at 2022-06-17 17:49:05.200003
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == []
    assert encoder.default(frozenset()) == []
    assert encoder.default(dict()) == {}
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('1.23')) == '1.23'
    assert encoder.default(Enum('TestEnum', {'A': 1})) == 1
    assert encoder.default(Exception()) == 'Exception()'



# Generated at 2022-06-17 17:49:16.891419
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"a": [1, 2, 3]}) == '{"a": [1, 2, 3]}'
    assert _ExtendedEncoder().encode({"a": {"b": 1}}) == '{"a": {"b": 1}}'
    assert _ExtendedEncoder().encode({"a": {"b": [1, 2, 3]}}) == '{"a": {"b": [1, 2, 3]}}'

# Generated at 2022-06-17 17:49:23.865199
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(cfg.NaN)
    assert _ExtendedEncoder().encode(cfg.Infinity)
    assert _ExtendedEncoder().encode(cfg.NegativeInfinity)



# Generated at 2022-06-17 17:50:25.400190
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').c)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a.value)

# Generated at 2022-06-17 17:50:33.027518
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.0'))
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode('1')
    assert _ExtendedEncoder().encode(1.0)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode([1, 2, 3])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2})



# Generated at 2022-06-17 17:50:43.104982
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(1) == 1
    assert encoder.default(1.1) == 1.1
    assert encoder.default('a') == 'a'
    assert encoder.default(['a']) == ['a']
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default(datetime(2020, 1, 1, 12, 0, 0, tzinfo=timezone.utc)) == 1577836800.0
    assert encoder.default(UUID('12345678-1234-5678-1234-567812345678'))

# Generated at 2022-06-17 17:50:53.482800
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23e-10')) == '"1.23e-10"'
    assert _ExtendedEncoder().encode(Decimal('1.23e+10')) == '"1.23e+10"'

# Generated at 2022-06-17 17:51:04.516729
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(datetime(2019, 1, 1, tzinfo=timezone.utc)) == '1546300800.0'

# Generated at 2022-06-17 17:51:13.529435
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(Decimal('1.23')) == '1.23'
    assert _ExtendedEncoder().default(Decimal('1.23')) == '1.23'
    assert _ExtendedEncoder().default(Decimal('1.23')) == '1.23'
    assert _ExtendedEncoder().default(Decimal('1.23')) == '1.23'
    assert _ExtendedEncoder().default(Decimal('1.23')) == '1.23'


# Generated at 2022-06-17 17:51:22.014776
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b'})



# Generated at 2022-06-17 17:51:29.816618
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'
    assert _ExtendedEncoder().encode(()) == '[]'
    assert _ExtendedEncoder().encode(dict()) == '{}'
    assert _ExtendedEncoder().encode(list()) == '[]'
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'
    assert _ExtendedEncoder().encode(tuple()) == '[]'

# Generated at 2022-06-17 17:51:40.641393
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('8e8ec658-c7b8-4b33-8914-a82b00dc2518'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').c)

# Generated at 2022-06-17 17:51:52.957536
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.1)
    assert _Extended

# Generated at 2022-06-17 17:54:02.381489
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('Test', 'test'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.1)
    assert _ExtendedEncoder().encode('a')
    assert _ExtendedEncoder

# Generated at 2022-06-17 17:54:11.599379
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678-1234-5678-1234-567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'

# Generated at 2022-06-17 17:54:19.561918
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": [1, 2, 3]}) == '{"a": [1, 2, 3]}'
    assert _ExtendedEncoder().encode({"a": {"b": 1}}) == '{"a": {"b": 1}}'
    assert _ExtendedEncoder().encode({"a": datetime(2020, 1, 1, 0, 0, 0, 0, timezone.utc)}) == '{"a": 1577836800.0}'
    assert _ExtendedEncoder().encode({"a": UUID("123e4567-e89b-12d3-a456-426655440000")}) == '{"a": "123e4567-e89b-12d3-a456-426655440000"}'
    assert _ExtendedEncoder().en

# Generated at 2022-06-17 17:54:25.482606
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000'))
    assert _ExtendedEncoder().encode(Decimal('1.2'))
    assert _ExtendedEncoder().encode(Enum('test', 'a b c'))
    assert _ExtendedEncoder().encode(set())
    assert _ExtendedEncoder().encode(frozenset())
    assert _ExtendedEncoder().encode(dict())
    assert _ExtendedEncoder().encode(list())
    assert _ExtendedEncoder().encode(tuple())
    assert _ExtendedEncoder().encode(object())



# Generated at 2022-06-17 17:54:34.125001
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').c)
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c').a.value)

# Generated at 2022-06-17 17:54:41.971482
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(1970, 1, 1, tzinfo=timezone.utc)) == '0.0'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'
    assert _ExtendedEncoder().encode(Decimal('0.0')) == '"0.0"'
    assert _ExtendedEncoder().encode(Decimal('0')) == '"0"'
    assert _ExtendedEncoder().encode(Decimal('0.00')) == '"0.00"'
    assert _ExtendedEncoder().encode(Decimal('0.000')) == '"0.000"'

# Generated at 2022-06-17 17:54:53.439072
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3, "d": 4}) == '{"a": 1, "b": 2, "c": 3, "d": 4}'

# Generated at 2022-06-17 17:55:00.043706
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))

# Generated at 2022-06-17 17:55:03.117512
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 0, 0, 0, timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().encode(Decimal('0.0')) == '0.0'


# Generated at 2022-06-17 17:55:08.805184
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800.0
    assert encoder.default(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'
    assert encoder.default(Decimal('1.23')) == '1.23'
    assert encoder.default(Decimal('1.23e-10')) == '0.000000000123'
    assert encoder.default(Decimal('1.23e+10')) == '12300000000.0'