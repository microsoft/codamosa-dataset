

# Generated at 2022-06-17 17:45:49.470225
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})


# Generated at 2022-06-17 17:45:53.836641
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.2'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3})



# Generated at 2022-06-17 17:45:56.196805
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}'))
    assert _ExtendedEncoder().encode(Decimal('12.34'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))



# Generated at 2022-06-17 17:46:06.622547
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('-1.23')) == '"-1.23"'
    assert _ExtendedEncoder().encode(Decimal('0.00')) == '"0.00"'
    assert _ExtendedEncoder().encode(Decimal('-0.00')) == '"-0.00"'

# Generated at 2022-06-17 17:46:11.323089
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))



# Generated at 2022-06-17 17:46:22.457005
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000'))
    assert _ExtendedEncoder().encode(Decimal('0.0'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'A'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(False)
    assert _ExtendedEncoder().encode(0)
    assert _ExtendedEncoder().en

# Generated at 2022-06-17 17:46:28.827552
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('1.0')) == '1.0'
    assert encoder.default(Exception('error')) == 'error'



# Generated at 2022-06-17 17:46:39.863846
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 12, 0, 0, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678-1234-5678-1234-567812345678')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'

# Generated at 2022-06-17 17:46:52.296098
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'
    assert _ExtendedEncoder().encode(datetime.now()) == '{}'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'



# Generated at 2022-06-17 17:46:59.055312
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(1970, 1, 1, tzinfo=timezone.utc)) == '0.0'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'
    assert _ExtendedEncoder().encode(Decimal('0.0')) == '"0.0"'
    assert _ExtendedEncoder().encode(Decimal('0.1')) == '"0.1"'
    assert _ExtendedEncoder().encode(Decimal('1.0')) == '"1.0"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'

# Generated at 2022-06-17 17:47:33.238217
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(1) == 1
    assert encoder.default(1.1) == 1.1
    assert encoder.default('a') == 'a'
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()

# Generated at 2022-06-17 17:47:40.931459
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 12, 0, 0, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23e-2')) == '"0.0123"'
    assert _ExtendedEncoder().encode(Decimal('1.23e+2')) == '"123"'

# Generated at 2022-06-17 17:47:52.751574
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'
    assert _ExtendedEncoder().encode(datetime.now()) == '{}'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode(1) == '1'

# Generated at 2022-06-17 17:48:02.782728
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('Test', 'A B C'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 'b', 'c': 'd'})
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(False)
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder

# Generated at 2022-06-17 17:48:12.679574
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('test', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('test', 'a b c'))

# Generated at 2022-06-17 17:48:22.671406
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11')) == '"a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11"'
    assert _ExtendedEncoder().encode(Decimal('1.0')) == '"1.0"'
    assert _ExtendedEncoder().encode(Decimal('1.0')) == '"1.0"'
    assert _ExtendedEncoder().encode(Decimal('1.0')) == '"1.0"'

# Generated at 2022-06-17 17:48:33.245245
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').b)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').c)
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c').a.value)

# Generated at 2022-06-17 17:48:42.689184
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2})
    assert _ExtendedEncoder().encode([1, 2, 3])
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.23)
    assert _ExtendedEncoder().encode('abc')
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode

# Generated at 2022-06-17 17:48:54.164522
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(1970, 1, 1, tzinfo=timezone.utc)) == '0.0'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'
    assert _ExtendedEncoder().encode(Decimal('0.0')) == '"0.0"'
    assert _ExtendedEncoder().encode(Decimal('0')) == '"0"'
    assert _ExtendedEncoder().encode(Decimal('0.00')) == '"0.00"'
    assert _ExtendedEncoder().encode(Decimal('0.000')) == '"0.000"'

# Generated at 2022-06-17 17:48:59.705909
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))



# Generated at 2022-06-17 17:49:59.369379
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2019, 1, 1, tzinfo=timezone.utc)) == '1546300800.0'
    assert _ExtendedEncoder().encode(UUID('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11')) == '"a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'


# Generated at 2022-06-17 17:50:08.099691
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(1970, 1, 1, tzinfo=timezone.utc)) == '0.0'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'
    assert _ExtendedEncoder().encode(Decimal('0.0')) == '"0.0"'
    assert _ExtendedEncoder().encode(Decimal('1.0')) == '"1.0"'
    assert _ExtendedEncoder().encode(Decimal('-1.0')) == '"-1.0"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'

# Generated at 2022-06-17 17:50:13.869193
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.1'))
    assert _ExtendedEncoder().encode(Enum('Test', 'a b c'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3})
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(False)
    assert _ExtendedEncoder().encode(1)
    assert _Extended

# Generated at 2022-06-17 17:50:24.856507
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2019, 1, 1, tzinfo=timezone.utc)) == '1546300800.0'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23e-10')) == '"1.23e-10"'
    assert _ExtendedEncoder().encode(Decimal('1.23e+10')) == '"1.23e+10"'

# Generated at 2022-06-17 17:50:30.610848
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(UUID('12345678-1234-5678-1234-567812345678')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'


# Generated at 2022-06-17 17:50:40.740462
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(['a', 'b']) == ['a', 'b']
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'
    assert encoder.default(Decimal('1.2')) == '1.2'



# Generated at 2022-06-17 17:50:49.910740
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))

# Generated at 2022-06-17 17:50:56.450002
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": [1, 2, 3]}) == '{"a": [1, 2, 3]}'
    assert _ExtendedEncoder().encode({"a": [1, 2, 3], "b": {"c": "d"}}) == '{"a": [1, 2, 3], "b": {"c": "d"}}'
    assert _ExtendedEncoder().encode({"a": [1, 2, 3], "b": {"c": "d"}, "e": {"f": [1, 2, 3]}}) == '{"a": [1, 2, 3], "b": {"c": "d"}, "e": {"f": [1, 2, 3]}}'

# Generated at 2022-06-17 17:51:07.500920
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'

# Generated at 2022-06-17 17:51:15.007478
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 0, 0, 0, timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'
    assert _ExtendedEncoder().encode(Decimal('1.0')) == '"1.0"'
    assert _ExtendedEncoder().encode(Decimal('1.0')) == '"1.0"'
    assert _ExtendedEncoder().encode(Decimal('1.0')) == '"1.0"'
    assert _ExtendedEncoder().encode(Decimal('1.0')) == '"1.0"'
    assert _ExtendedEnc

# Generated at 2022-06-17 17:53:35.238175
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'A B C'))
    assert _ExtendedEncoder().encode(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3})


# Generated at 2022-06-17 17:53:43.402563
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 12, 0, 0, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'

# Generated at 2022-06-17 17:53:54.422986
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('12.345'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', {'A': 1}))
    assert _ExtendedEncoder().encode({'a': 1})
    assert _ExtendedEncoder().encode([1, 2, 3])
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.0)
    assert _ExtendedEncoder().encode(True)
    assert _ExtendedEncoder().encode(None)


# Generated at 2022-06-17 17:54:02.485498
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(set())
    assert _ExtendedEncoder().encode(frozenset())
    assert _ExtendedEncoder().encode(tuple())
    assert _ExtendedEncoder().encode(dict())
    assert _ExtendedEncoder().encode(list())
    assert _ExtendedEncoder().encode(str())
    assert _ExtendedEncoder().encode(int())
    assert _ExtendedEnc

# Generated at 2022-06-17 17:54:06.159297
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))



# Generated at 2022-06-17 17:54:14.439968
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'
    assert _ExtendedEncoder().encode(Decimal('3.14')) == '"3.14"'
    assert _ExtendedEncoder().encode(Decimal('-3.14')) == '"-3.14"'
    assert _ExtendedEncoder().encode(Decimal('0')) == '"0"'
    assert _ExtendedEncoder().encode(Decimal('-0')) == '"0"'

# Generated at 2022-06-17 17:54:22.186643
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000'))
    assert _ExtendedEncoder().encode(Decimal('1.23'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', 'a b c'))

# Generated at 2022-06-17 17:54:30.883323
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2, "c": 3, "d": 4}) == '{"a": 1, "b": 2, "c": 3, "d": 4}'

# Generated at 2022-06-17 17:54:39.280104
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc))
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().default(Decimal('123.45'))
    assert _ExtendedEncoder().default(Enum('TestEnum', 'A B C'))
    assert _ExtendedEncoder().default(['a', 'b', 'c'])
    assert _ExtendedEncoder().default({'a': 1, 'b': 2, 'c': 3})
    assert _ExtendedEncoder().default(None)
    assert _ExtendedEncoder().default(True)
    assert _ExtendedEncoder().default(False)
    assert _ExtendedEncoder().default(123)
    assert _ExtendedEncoder

# Generated at 2022-06-17 17:54:49.455041
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
