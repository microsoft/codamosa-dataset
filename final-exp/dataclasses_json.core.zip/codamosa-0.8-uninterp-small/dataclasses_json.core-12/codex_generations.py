

# Generated at 2022-06-25 16:02:48.346884
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(4) == 4
    assert encoder.default(4.1) == 4.1
    assert encoder.default('abcd') == 'abcd'
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(None) == None
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime.now()) == datetime.now().timestamp()

# Generated at 2022-06-25 16:02:49.396408
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:02:58.361706
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    myEncoder = _ExtendedEncoder()

    assert myEncoder.default({"a": "1", "b": "2"}) == {"a": "1", "b": "2"}
    assert myEncoder.default(["a", "b", "c"]) == ["a", "b", "c"]
    assert myEncoder.default(datetime.now(timezone.utc)) == myEncoder.default(datetime.now(timezone.utc).timestamp())
    assert myEncoder.default(UUID('3b42d9c0-18f0-11ea-bc55-0242ac130003')) == '3b42d9c0-18f0-11ea-bc55-0242ac130003'

# Generated at 2022-06-25 16:03:07.356119
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ext_encoder = _ExtendedEncoder()

    actual = ext_encoder.default(1)
    expected = 1
    assert actual == expected

    actual = ext_encoder.default(1.1)
    expected = 1.1
    assert actual == expected

    actual = ext_encoder.default('str')
    expected = 'str'
    assert actual == expected

    actual = ext_encoder.default([1, 2])
    expected = [1, 2]
    assert actual == expected

    actual = ext_encoder.default({'a': 1, 'b': 2})
    expected = {'a': 1, 'b': 2}
    assert actual == expected

    actual = ext_encoder.default(datetime(2020, 7, 13, 13, 45, 30, tzinfo=timezone.utc))


# Generated at 2022-06-25 16:03:11.397063
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    expected_result = '<dataclasses_json.converter._ExtendedEncoder object at 0x000001F9C9A15198>'
    actual_result = _ExtendedEncoder().__repr__()
    assert expected_result == actual_result


# Generated at 2022-06-25 16:03:12.464810
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:03:13.954475
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default(set())



# Generated at 2022-06-25 16:03:16.713531
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder(skipkeys=True, ensure_ascii=True,
                            check_circular=True, allow_nan=True, sort_keys=False,
                            indent=None, separators=None, default=None)

# Generated at 2022-06-25 16:03:17.680134
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:03:20.153777
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default(list()) == []
    assert encoder.default(dict()) == {}



# Generated at 2022-06-25 16:03:45.720648
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    json_encoder = _ExtendedEncoder()
    
    # Test case 1
    # input
    test_input_1 = [1, 2, 3]
    # expected output
    test_expected_output_1 = [1, 2, 3]
    # actual output
    test_actual_output_1 = json_encoder.default(test_input_1)

    # Check whether actual output matches expected output
    assert test_actual_output_1 == test_expected_output_1
    
    # Test case 2
    # input
    test_input_2 = {"1": 1, "2": 2}
    # expected output
    test_expected_output_2 = {"1": 1, "2": 2}
    # actual output

# Generated at 2022-06-25 16:03:47.719437
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:03:56.871173
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder_0 = json.JSONEncoder()
    encoder_1 = json.JSONEncoder(skipkeys=None)
    encoder_2 = json.JSONEncoder(skipkeys=False)
    encoder_3 = json.JSONEncoder(skipkeys=True)
    encoder_4 = json.JSONEncoder(skipkeys=None, ensure_ascii=None)
    encoder_5 = json.JSONEncoder(skipkeys=None, ensure_ascii=False)
    encoder_6 = json.JSONEncoder(skipkeys=None, ensure_ascii=True)
    encoder_7 = json.JSONEncoder(skipkeys=None, ensure_ascii=None,
                                 check_circular=None)

# Generated at 2022-06-25 16:03:57.764665
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:03:58.534402
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:04:01.191004
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().__doc__.strip() == 'Extended encoder'



# Generated at 2022-06-25 16:04:11.474197
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    res = _ExtendedEncoder()
    assert res
    assert isinstance(res.__dict__['_ExtendedEncoder__check_circular'], bool)
    assert isinstance(res.__dict__['_ExtendedEncoder__ensure_ascii'], bool)
    assert isinstance(res.__dict__['_ExtendedEncoder__indent'], int)
    assert isinstance(res.__dict__['_ExtendedEncoder__key_separator'], str)
    assert isinstance(res.__dict__['_ExtendedEncoder__item_separator'], str)
    assert isinstance(res.__dict__['_ExtendedEncoder__sort_keys'], bool)
    assert isinstance(res.__dict__['_ExtendedEncoder__skipkeys'], bool)
    assert res.__dict

# Generated at 2022-06-25 16:04:21.441202
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    print("\ntest__ExtendedEncoder_default")

    # Todo:
    # isinstance for each instance of each possible types
    # isinstance with no type
    # isinstance with a random string

    # isinstance for each instance of each possible types
    # int
    res_int = _ExtendedEncoder().default(5)
    assert res_int == 5

    # float
    res_float = _ExtendedEncoder().default(3.14)
    assert res_float == 3.14

    # string
    res_string = _ExtendedEncoder().default('abcd')
    assert res_string == 'abcd'

    # bool
    res_bool = _ExtendedEncoder().default(True)
    assert res_bool == True

    # list

# Generated at 2022-06-25 16:04:24.994955
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:04:27.272513
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()
    test = _ExtendedEncoder()
    assert test is not None
    assert json.JSONEncoder == object
    assert object == object

# Generated at 2022-06-25 16:04:49.922143
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    instance_0 = _ExtendedEncoder()
    assert isinstance(instance_0, _ExtendedEncoder)
    assert isinstance(instance_0, json.JSONEncoder)



# Generated at 2022-06-25 16:04:50.673704
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj = _ExtendedEncoder()


# Generated at 2022-06-25 16:04:52.064991
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    j = _ExtendedEncoder()
    assert j is not None


# Generated at 2022-06-25 16:04:52.934200
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:04:56.116379
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    instance = _ExtendedEncoder()
    assert isinstance(instance, json.JSONEncoder)


# Generated at 2022-06-25 16:04:59.376675
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder == type(_ExtendedEncoder())



_Decoder = namedtuple('Decoder', ['cls', 'cfg', 'is_new_type'])



# Generated at 2022-06-25 16:05:03.814171
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:05:05.501384
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    r = _ExtendedEncoder()
    assert type(r) == _ExtendedEncoder


# Generated at 2022-06-25 16:05:06.785812
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder(0, 0)



# Generated at 2022-06-25 16:05:13.443157
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings(record=True) as warning:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        _ExtendedEncoder()
        # Verify some things
        assert len(warning) == 1
        assert issubclass(warning[-1].category, SyntaxWarning)
        assert "datetime.datetime not JSON serializable" in str(warning[-1].message)



# Generated at 2022-06-25 16:05:56.006570
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:06:03.514192
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ex = _ExtendedEncoder()

# Generated at 2022-06-25 16:06:14.525697
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():

    # Arrange
    class A:
        def __init__(self, value):
            self.value = value

    jsonEncoder = _ExtendedEncoder()
    value_0 = 'foobar'
    value_1 = 0.5
    value_2 = True
    value_3 = None
    value_4 = A('foobar')

    # Act
    actual_result_0 = jsonEncoder.default(value_0)
    actual_result_1 = jsonEncoder.default(value_1)
    actual_result_2 = jsonEncoder.default(value_2)
    actual_result_3 = jsonEncoder.default(value_3)
    actual_result_4 = jsonEncoder.default(value_4)

    # Assert
    assert (actual_result_0 == value_0)

# Generated at 2022-06-25 16:06:20.579802
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()

test_case_0()
class_0 = _ExtendedEncoder()
test__ExtendedEncoder()

# Generated at 2022-06-25 16:06:22.183657
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:06:23.061514
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:06:30.033051
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(11) == 11
    assert _ExtendedEncoder().default(11.0) == 11.0
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default('dummy') == 'dummy'
    assert _ExtendedEncoder().default(UUID('9f8b6239-b6d5-4fea-a8ae-f1c2b89aef5b')) == '9f8b6239-b6d5-4fea-a8ae-f1c2b89aef5b'

# Generated at 2022-06-25 16:06:31.578656
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:06:43.021464
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder.default(_ExtendedEncoder(), list()) == []
    assert _ExtendedEncoder.default(_ExtendedEncoder(), [1]) == [1]
    assert _ExtendedEncoder.default(_ExtendedEncoder(), tuple()) == []
    assert _ExtendedEncoder.default(_ExtendedEncoder(), (1,)) == [1]
    assert _ExtendedEncoder.default(_ExtendedEncoder(), {}) == {}
    assert _ExtendedEncoder.default(_ExtendedEncoder(), {'a': 'b'}) == {'a': 'b'}
    assert _ExtendedEncoder.default(_ExtendedEncoder(), '') == ''
    assert _ExtendedEncoder.default(_ExtendedEncoder(), 'a') == 'a'

# Generated at 2022-06-25 16:06:43.962679
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:07:30.447608
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # simple conversion
    field_override_0 = FieldOverride()
    obj = defaultdict(list, {'a': [1,2,3], 'b': [4,5]})
    encoder = _ExtendedEncoder()
    json.dumps(obj, cls=encoder)
    assert encoder.default(obj) == obj


# Generated at 2022-06-25 16:07:32.775335
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from json import JSONEncoder
    # noinspection PyTypeChecker
    encoder = _ExtendedEncoder(None, None, None)
    assert isinstance(encoder, JSONEncoder)



# Generated at 2022-06-25 16:07:38.424188
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj = _ExtendedEncoder()
    assert obj._current_indent_level is None
    assert obj.item_separator is None
    assert obj.key_separator is None
    assert obj.skipkeys is None
    assert obj.sort_keys is None
    assert obj.ensure_ascii is False
    assert obj.allow_nan is True
    assert obj.check_circular is True
    assert obj.indent is None
    assert obj.separators is None
    assert obj.default is None
    assert obj.encoding is 'utf-8'
    assert obj.namedtuple_as_object is True
    assert obj.tuple_as_array is True
    assert obj.bigint_as_string is False
    assert obj.item_sort_key is None


# Generated at 2022-06-25 16:07:47.757537
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    result = _ExtendedEncoder().default(namedtuple('Test', ['a', 'b'])(a=1, b=2))
    assert result == {'a': 1, 'b': 2}
    namedtuple('Test', ['a', 'b'])(a=1, b=2)
    assert result == {'a': 1, 'b': 2}
    extended_encoder = _ExtendedEncoder()
    result = extended_encoder.default([1, 2])
    assert result == [1, 2]
    extended_encoder = _ExtendedEncoder()
    result = extended_encoder.default({'a': 1, 'b': 2})
    assert result == {'a': 1, 'b': 2}
    extended_encoder = _ExtendedEncoder()

# Generated at 2022-06-25 16:07:48.957037
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()


# Generated at 2022-06-25 16:07:50.817779
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:07:58.241098
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(2020, 2, 2, 0, 0, 0)) == 1583020800.0
    assert _ExtendedEncoder().default(datetime(2020, 2, 2, 0, 0, 0, tzinfo=timezone.utc)) == 1583020800.0
    assert _ExtendedEncoder().default(UUID("c9bf9e57-1685-4c89-bafb-ff5af830be8a")) == "c9bf9e57-1685-4c89-bafb-ff5af830be8a"
    assert _ExtendedEncoder().default(Decimal("0.1")) == "0.1"
    assert _ExtendedEncoder().default(Decimal("0.0")) == "0.0"
    assert _ExtendedEncoder

# Generated at 2022-06-25 16:07:59.654818
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_ext_enc = _ExtendedEncoder()
#   print(json_ext_enc())


# Generated at 2022-06-25 16:08:02.366283
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # initialize instance and get value with calling function default
    encoder_0 = _ExtendedEncoder()
    # test instance and function
    assert encoder_0 is not None



# Generated at 2022-06-25 16:08:03.703984
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:09:14.951219
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder() is not None


# Generated at 2022-06-25 16:09:16.665905
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj = _ExtendedEncoder()
    assert isinstance(obj, json.JSONEncoder)



# Generated at 2022-06-25 16:09:19.455970
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        _ExtendedEncoder()
    except TypeError:
        raise AssertionError("Failed to create an instance of class _ExtendedEncoder")


# Generated at 2022-06-25 16:09:20.864257
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    field_override_0 = FieldOverride()
    result_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:09:25.180049
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():

    test_case_0()

_base_types = Union[int, float, str, bool]
_extended_types = Union[_base_types, list, dict, None]


# Generated at 2022-06-25 16:09:26.523195
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:09:27.507504
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder.__base__ == json.JSONEncoder



# Generated at 2022-06-25 16:09:29.526209
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    field_override_0 = FieldOverride()
    if field_override_0.exclude is False:
        _ExtendedEncoder.default(field_override_0)

# Generated at 2022-06-25 16:09:31.583439
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    field_override_0 = FieldOverride()
    field_override_0 = FieldOverride()
    assert field_override_0 is not None


# Generated at 2022-06-25 16:09:33.053462
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:10:40.444148
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert type(extended_encoder_0) == _ExtendedEncoder
    assert isinstance(extended_encoder_0, json.JSONEncoder)


# Generated at 2022-06-25 16:10:43.407264
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test with default argument values
    extended_encoder_0 = _ExtendedEncoder()

    # Test with specific argument values
    extended_encoder_1 = _ExtendedEncoder()



# Generated at 2022-06-25 16:10:44.996502
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:10:47.952278
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0 is not None
    assert type(extended_encoder_0) == _ExtendedEncoder


# Generated at 2022-06-25 16:10:53.053638
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extracted_arg_0 = list()
    var_0 = _ExtendedEncoderVars.ExtendedEncoder_default_var_0
    expected_0 = _ExtendedEncoderVars.ExtendedEncoder_default_expected_0
    with _handle_type_error('assertEqual() argument 1 must be str, not ' +
                            _type_name(var_0)):
        assert expected_0 == var_0



# Generated at 2022-06-25 16:10:53.852349
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass


# Generated at 2022-06-25 16:10:56.839694
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:11:06.643398
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Constructor test
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_1 = _ExtendedEncoder(skipkeys=True)
    extended_encoder_2 = _ExtendedEncoder(ensure_ascii=True)
    extended_encoder_3 = _ExtendedEncoder(check_circular=True)
    extended_encoder_4 = _ExtendedEncoder(allow_nan=True)
    extended_encoder_5 = _ExtendedEncoder(sort_keys=True)
    extended_encoder_6 = _ExtendedEncoder(indent=4)
    extended_encoder_7 = _ExtendedEncoder(separators=(',', ':'))
    extended_encoder_8 = _ExtendedEncoder(default=None)

# Generated at 2022-06-25 16:11:08.469961
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, object)



# Generated at 2022-06-25 16:11:09.487716
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()

