

# Generated at 2022-06-25 16:02:40.349714
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:02:41.735438
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    inst = _ExtendedEncoder()
    assert inst is not None


# Generated at 2022-06-25 16:02:46.457584
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # 1. create a new instance of class _ExtendedEncoder
    _ExtendedEncoder = _ExtendedEncoder()
    # 2. define input parameters for function default
    o = [1, 2, 3]
    # 3. call function default
    result = _ExtendedEncoder.default(o)
    assert(result == [1, 2, 3])


# Generated at 2022-06-25 16:02:49.107193
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


_ExtendedEncoder()

# Generated at 2022-06-25 16:02:50.014789
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:02:53.534083
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_encoder = _ExtendedEncoder()
    # To verify the type of json_encoder and  is correct
    assert isinstance(json_encoder, json.JSONEncoder) == True


# Generated at 2022-06-25 16:03:00.446840
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # noinspection PyUnresolvedReferences
    encoder = _ExtendedEncoder()
    field_override = FieldOverride()
    case_0 = (field_override, {})
    case_1 = (field_override, [])
    case_2 = (field_override, 100)
    case_3 = (field_override, -1.0)
    case_4 = (field_override, True)
    case_5 = (field_override, "test")
    case_6 = (field_override, None)
    case_7 = (field_override, {'key': 'val'})
    case_8 = (field_override, ['str', 1])
    case_9 = (field_override, datetime.fromtimestamp(0, timezone.utc))
   

# Generated at 2022-06-25 16:03:05.705041
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    print("\nstart unit test for method default of class _ExtendedEncoder")
    """
    class Type:
        def __init__(self, value):
            self.value = value

    type_a = Type("A")
    encoder = _ExtendedEncoder()
    print(encoder.default(type_a))
    """
    print("end unit test for method default of class _ExtendedEncoder")


# Generated at 2022-06-25 16:03:08.168040
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:03:12.553581
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default('abc') == 'abc'
    assert encoder.default(True) == True
    assert encoder.default(None) == None

# Test for Issue #47: TypeError: Object of type 'Decimal' is not JSON serializable

# Generated at 2022-06-25 16:03:33.869541
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder(skipkeys = True, ensure_ascii = False,
                     check_circular = True, allow_nan = True,
                     sort_keys = True, indent = 0.0,
                     separators = (',', ':'), default = 'test_case_0',
                     )


# Generated at 2022-06-25 16:03:36.381326
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    j = _ExtendedEncoder()
    assert _is_dataclass_instance(j, _ExtendedEncoder)
    assert j.default

# Unit test case for function _isinstance_safe

# Generated at 2022-06-25 16:03:37.454266
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()

# Generated at 2022-06-25 16:03:38.258558
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj = _ExtendedEncoder()



# Generated at 2022-06-25 16:03:39.593990
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert_result = _ExtendedEncoder().default(False)
    assert assert_result == False



# Generated at 2022-06-25 16:03:43.416901
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    field_override_0 = FieldOverride()
    field_override_0.encoder = object()
    field_override_0.decoder = object()
    field_override_0.mm_field = object()
    field_override_0.letter_case = object()
    field_override_0.exclude = object()
    _ExtendedEncoder.__init__(field_override_0)


# Generated at 2022-06-25 16:03:51.954984
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    time = datetime.fromtimestamp(0, timezone.utc)
    uuid = UUID('{00010203-0405-0607-0809-0a0b0c0d0e0f}')
    decimal = Decimal("1.1")
    # noinspection PyUnresolvedReferences
    result = encoder.default([time, uuid, decimal])
    assert result == [0.0, '00010203-0405-0607-0809-0a0b0c0d0e0f', '1.1']


# Generated at 2022-06-25 16:03:57.834940
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:03:58.601235
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:04:01.644960
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    field_override_0 = FieldOverride()
    result = _ExtendedEncoder(field_override_0)
    assert result is not None



# Generated at 2022-06-25 16:04:41.588520
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.encode([1, 2, 3]) == "[1, 2, 3]"



# Generated at 2022-06-25 16:04:45.172505
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ext_encoder = _ExtendedEncoder(sort_keys=True, indent=4)
    o = Decimal(1)
    result = ext_encoder.default(o)
    expected = '1'
    assert result == expected


# Generated at 2022-06-25 16:04:46.033044
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:04:47.293375
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()



# Generated at 2022-06-25 16:04:48.460620
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ee = _ExtendedEncoder()


# Generated at 2022-06-25 16:04:51.237922
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:04:53.516034
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    expected = 'dataclasses_json._ExtendedEncoder'
    actual = _ExtendedEncoder().__class__.__name__
    assert actual == expected



# Generated at 2022-06-25 16:04:56.201693
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert isinstance(encoder, _ExtendedEncoder)



# Generated at 2022-06-25 16:04:59.051474
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    # test_case_0
    test_case_0()
    result = encoder.default(None)
    assert result == None

# Generated at 2022-06-25 16:05:00.463941
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj = _ExtendedEncoder(separators=(',', ':'))



# Generated at 2022-06-25 16:05:37.174013
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    field_override_0 = FieldOverride()
    e = _ExtendedEncoder()
    e.default(field_override_0)


# Generated at 2022-06-25 16:05:44.973476
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from dataclasses_json.utils import (json,_ExtendedEncoder)
    from dataclasses_json.types import (Json)
    from typing import (Any, Collection, Mapping, Union)
    from datetime import (datetime)
    from uuid import (UUID)
    from enum import (Enum)
    from decimal import (Decimal)
    o:Any
    result:Json
    o = {'some': 'mapping', 'that': 'just', 'happens': 'to'}
    result={'some': 'mapping', 'that': 'just', 'happens': 'to'}
    o = [1, 2, 3]
    result=[1, 2, 3]
    o = 'abc'
    result='abc'
    o = 123
    result=123

# Generated at 2022-06-25 16:05:53.577703
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Create a _ExtendedEncoder object
    extended_encoder = _ExtendedEncoder()
    field_override_0 = FieldOverride()
    # Check that the default method works
    json_value = extended_encoder.default(field_override_0)
    assert isinstance(json_value, dict)


# Generated at 2022-06-25 16:06:02.218743
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tested = _ExtendedEncoder()
    assert tested.default(None) == None
    assert tested.default(True) == True
    assert tested.default(False) == False
    assert tested.default(1) == 1
    assert tested.default(4.2) == 4.2
    assert tested.default("string") == "string"
    assert tested.default(["list"]) == ["list"]
    assert tested.default(("tuple",)) == ["tuple"]
    assert tested.default({"dict": "value"}) == {"dict": "value"}
    assert tested.default(range(3)) == [0, 1, 2]

# Generated at 2022-06-25 16:06:11.087985
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # simple examples
    p = _ExtendedEncoder()
    assert p.get_encoder_config() == {}
    p = _ExtendedEncoder(cfg.EncoderConfig())
    assert p.get_encoder_config() == {}
    p = _ExtendedEncoder(cfg.EncoderConfig(ordered=True))
    assert p.get_encoder_config() == {"ordered": True}
    p = _ExtendedEncoder(cfg.EncoderConfig(**{"ordered": True}))
    assert p.get_encoder_config() == {"ordered": True}



# Generated at 2022-06-25 16:06:15.305453
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj_0 = _ExtendedEncoder()
    test_case_0()


# noinspection PyProtectedMember

# Generated at 2022-06-25 16:06:24.716901
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    inst = _ExtendedEncoder()
    assert not inst.allow_nan
    assert inst.check_circular
    assert inst.ensure_ascii
    assert inst.indent == None
    assert inst.key_separator == ':'
    assert inst.separators == (',', ':')
    assert inst.skipkeys
    assert inst.sort_keys
    assert inst.item_sort_key



# Generated at 2022-06-25 16:06:25.283219
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:06:32.409392
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(3.14) == 3.14
    assert encoder.default(datetime(1969, 12, 31, 23, 59, 59, tzinfo=timezone.utc)) == -1.0
    assert encoder.default(UUID('550e8400-e29b-41d4-a716-446655440000')) == '550e8400-e29b-41d4-a716-446655440000'


# Generated at 2022-06-25 16:06:38.361495
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    v0 = _ExtendedEncoder(skipkeys=True, ensure_ascii=True, check_circular=True,
                          allow_nan=True, sort_keys=True, indent=4,
                          separators=(',', ':'), default=None)
    assert _issubclass_safe(type(v0), json.JSONEncoder)


# Generated at 2022-06-25 16:07:53.567199
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:07:58.874539
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:08:07.516650
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    field_override_0 = FieldOverride()
    extendedencoder_0 = _ExtendedEncoder(field_override_0)
    date_0 = datetime.now()
    extendedencoder_0.default(date_0)
    extendedencoder_0.default(UUID(int=0))
    extendedencoder_0.default(Decimal('0.0'))
    # Test for code path without byte order mark
    extendedencoder_0.default(b'\x6c')
    extendedencoder_0.default(b'\x61')
    extendedencoder_0.default(b'\x61')


# Generated at 2022-06-25 16:08:09.392307
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert isinstance(encoder, _ExtendedEncoder)
    assert encoder.indent is None


# Generated at 2022-06-25 16:08:11.680860
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        _ExtendedEncoder()
    except TypeError as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-25 16:08:14.910936
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _extended_encoder = _ExtendedEncoder()
    obj = "this is a test"
    actual = _extended_encoder.default(obj)
    expected = obj
    assert actual == expected, f'actual: {actual}, expected: {expected}'


# Generated at 2022-06-25 16:08:16.272920
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        _ExtendedEncoder()
    except TypeError:
        assert False
    else:
        assert True


# Generated at 2022-06-25 16:08:25.936383
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _extended_encoder_instance = _ExtendedEncoder()
    _test_input_0 = _ExtendedEncoder.default(_extended_encoder_instance, _get_type_cons(dict)())
    assert _test_input_0 == {}
    _test_input_1 = _ExtendedEncoder.default(_extended_encoder_instance, _get_type_cons(list)())
    assert _test_input_1 == []
    _test_input_2 = _ExtendedEncoder.default(_extended_encoder_instance, _get_type_cons(dict)())
    assert _test_input_2 == {}
    _test_input_3 = _ExtendedEncoder.default(_extended_encoder_instance, _get_type_cons(list)())

# Generated at 2022-06-25 16:08:29.277008
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:08:31.563312
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test for default arguments
    ExtendedEncoder = _ExtendedEncoder()



# Generated at 2022-06-25 16:10:12.139921
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ee = _ExtendedEncoder()
    assert isinstance(ee, json.JSONEncoder)


# Generated at 2022-06-25 16:10:13.703794
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert (_ExtendedEncoder())


# Generated at 2022-06-25 16:10:14.850421
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:10:16.664181
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:10:19.539170
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    field_override_0 = FieldOverride()
    result = _ExtendedEncoder().default(field_override_0)
    assert result is None
    assert FieldOverride() == field_override_0


# Generated at 2022-06-25 16:10:23.078789
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    field_override_0 = FieldOverride()
    with pytest.warns(DeprecationWarning):
        _ExtendedEncoder(cfg)
    with pytest.warns(DeprecationWarning):
        _ExtendedEncoder(cfg)


# Generated at 2022-06-25 16:10:33.556958
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():

    dict_data_0 = dict( x = 1, y = 2)
    list_data_0 = {1, 2, 3, 'a', 'b', 'c'}
    str_data_0 = 'qqq'
    int_data_0 = 1
    float_data_0 = 2.3
    bool_data_0 = True
    none_data_0 = None
    datetime_data_0 = datetime.now()
    uuid_data_0 = UUID('65f9aa9c-430e-446c-86bb-fdee1fbe0c6d')
    enum_data_0 = cfg.LetterCase.LOWERCASE
    decimal_data_0 = Decimal('1.0')

# Generated at 2022-06-25 16:10:35.788969
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    a = FieldOverride()

## Unit test for method encode

# Generated at 2022-06-25 16:10:38.983018
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    x = _ExtendedEncoder()
    assert isinstance(x, json.JSONEncoder)


# Generated at 2022-06-25 16:10:46.991787
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Initializing object ExtendedEncoder with default arguments.
    test_case = _ExtendedEncoder()
    assert test_case is not None
    assert test_case.item_separator == ','
    assert test_case.key_separator == ':'
    assert test_case.sort_keys is False
    assert test_case.skipkeys is False
    assert test_case.ensure_ascii is True
    assert test_case.indent is None
    assert test_case.separators == (',', ':')
    assert test_case.default is _ExtendedEncoder.default

# Test for function default()