

# Generated at 2022-06-25 16:02:49.894241
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    field_override_0 = FieldOverride()
    _ExtendedEncoder.get_default(field_override_0) # type: ignore
    _ExtendedEncoder.default(field_override_0, field_override_0)
    _ExtendedEncoder.indent(field_override_0, 4, field_override_0)
    _ExtendedEncoder.encode(field_override_0, field_override_0)
    _ExtendedEncoder.iterencode(field_override_0, field_override_0)



# Generated at 2022-06-25 16:02:54.642009
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    a = _ExtendedEncoder()
    json.dumps(2, cls=_ExtendedEncoder)
    json.dumps(1.1, cls=_ExtendedEncoder)
    json.dumps([1], cls=_ExtendedEncoder)
    json.dumps(True, cls=_ExtendedEncoder)



# Generated at 2022-06-25 16:03:05.739728
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from unittest.mock import Mock

    # Test case 1
    t1_json_encoder = json.JSONEncoder()
    t1_args = (t1_json_encoder, )
    t1_kwargs = {'indent': 2, 'skipkeys': True, 'ensure_ascii': False,
                 'check_circular': True, 'allow_nan': True,
                 'cls': None, 'separators': (',', ':'),
                 'default': None, 'sort_keys': False}
    t1_test_case = _ExtendedEncoder(*t1_args, **t1_kwargs)
    # 'default' attr in t1_kwargs should be set to _ExtendedEncoder.default after __init__
    def wrap_default(o):
        return t1

# Generated at 2022-06-25 16:03:09.370649
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # given
    e = _ExtendedEncoder()
    # when
    # then
    assert e is not None


# Generated at 2022-06-25 16:03:14.267955
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0 is not None


# Generated at 2022-06-25 16:03:17.355656
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder(skipkeys=False, ensure_ascii=True,
                     check_circular=True, allow_nan=True,
                     sort_keys=False, indent=None,
                     separators=None, default=None,
                     encode_html_chars=False)


# Generated at 2022-06-25 16:03:19.277313
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_encoder = _ExtendedEncoder()
    assert isinstance(json_encoder, _ExtendedEncoder)


# Generated at 2022-06-25 16:03:20.880428
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder('*', '$', '^', '|', '~')



# Generated at 2022-06-25 16:03:26.597844
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        _ExtendedEncoder()
    except Exception as err:
        raise AssertionError(f'Exception raised when testing __ExtendedEncoder: {err}') from err


# Generated at 2022-06-25 16:03:29.626238
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder(
        skipkeys=False,
        ensure_ascii=True,
        check_circular=True,
        allow_nan=True,
        sort_keys=False,
        indent=None,
        separators=None,
        default=None
    )



# Generated at 2022-06-25 16:03:52.339050
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder()._check_circular
    assert _ExtendedEncoder().ensure_ascii
    assert _ExtendedEncoder().allow_nan
    assert not _ExtendedEncoder().indent
    assert not _ExtendedEncoder().separators
    assert not _ExtendedEncoder().sort_keys
    assert not _ExtendedEncoder().skipkeys


# Generated at 2022-06-25 16:03:54.099440
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:04:01.732500
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Constructor with default args:
    _ExtendedEncoder()

    # Constructor with the following args:
    # (1) skipkeys: bool = True
    # (2) ensure_ascii: bool = True
    # (3) check_circular: bool = True
    # (4) allow_nan: bool = True
    # (5) indent: Optional[Union[int, str]] = None
    # (6) separators: Optional[Tuple[str, str]] = None
    # (7) default: Union[Callable[[Any], Json], None] = None
    # (8) sort_keys: bool = False

# Generated at 2022-06-25 16:04:03.274690
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:04:04.413705
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:04:11.362445
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    #
    # Test 0
    #
    # input = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","[","\\","]","^","_","`","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","{","|","}","~"," "]
    input = "abc 012,.:;'\"\\/?<>{}[]!@#$%^&*()_+-="
    encoder.default(input)

# Emit

# Generated at 2022-06-25 16:04:13.462993
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert isinstance(_ExtendedEncoder(), _ExtendedEncoder)



# Generated at 2022-06-25 16:04:15.034954
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()

# Generated at 2022-06-25 16:04:16.135001
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass


# Generated at 2022-06-25 16:04:19.564828
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ext_encoder = _ExtendedEncoder()
    assert not hasattr(ext_encoder, 'foo')

# Test for _ExtendedEncoder.default()

# Generated at 2022-06-25 16:04:43.379816
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_1 = _ExtendedEncoder.__new__(_ExtendedEncoder)
    var_1.default(var_1, {"key": "some_value"})
    var_1.encode([1, 2, 3])



# Generated at 2022-06-25 16:04:49.069482
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)

    extended_encoder_1 = _ExtendedEncoder(sort_keys=True, ensure_ascii=True, indent=3)
    var_1 = extended_encoder_1.default(extended_encoder_1)


# Generated at 2022-06-25 16:04:52.972269
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)



# Generated at 2022-06-25 16:05:04.370470
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0
    assert extended_encoder_0.default(extended_encoder_0) == '<dataclasses_json.encoder._ExtendedEncoder object at 0x000001D7A0B0A148>'
    assert extended_encoder_0.default({extended_encoder_0: extended_encoder_0}) == {extended_encoder_0: extended_encoder_0}
    assert extended_encoder_0.default([extended_encoder_0]) == [extended_encoder_0]
    assert extended_encoder_0.default(extended_encoder_0)
    assert extended_encoder_0.default(0) == 0

# Generated at 2022-06-25 16:05:06.290568
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    var_0 = _ExtendedEncoder().default(str)
    assert(isinstance(var_0, str))
    assert(var_0 == "'str'")


# Generated at 2022-06-25 16:05:09.677321
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)



# Generated at 2022-06-25 16:05:10.476931
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:05:12.802193
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)



# Generated at 2022-06-25 16:05:15.123111
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_0.default(MISSING)


# Generated at 2022-06-25 16:05:18.730983
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var = _ExtendedEncoder()


# Generated at 2022-06-25 16:05:59.331534
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    return


# Generated at 2022-06-25 16:06:01.063615
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, json.JSONEncoder)



# Generated at 2022-06-25 16:06:03.793030
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    # Test the constructor
    assert hasattr(extended_encoder_0, 'default') is True


# Generated at 2022-06-25 16:06:06.419298
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test case with argument: <_ExtendedEncoder object at 0x11c6a5390>
    test_case_0()



# Generated at 2022-06-25 16:06:18.555821
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj_0 = _ExtendedEncoder()
    var_0 = isinstance(obj_0, json.JSONEncoder)
    var_3 = obj_0.encode([])
    var_4 = obj_0.encode({})
    extended_encoder_0 = _ExtendedEncoder()
    var_5 = isinstance(extended_encoder_0, json.JSONEncoder)
    var_6 = extended_encoder_0.default(extended_encoder_0)
    var_10 = extended_encoder_0.default(extended_encoder_0)
    var_14 = extended_encoder_0.default(extended_encoder_0)
    var_15 = extended_encoder_0.default(extended_encoder_0)
    var_16 = extended_encoder_

# Generated at 2022-06-25 16:06:19.852700
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass


# Generated at 2022-06-25 16:06:22.975710
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()
    assert isinstance(extended_encoder_1, _ExtendedEncoder)



# Generated at 2022-06-25 16:06:25.995388
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """
    Make sure that the unit test runs without errors.
    """

    extended_encoder_0 = _ExtendedEncoder()
    assert _isinstance_safe(extended_encoder_0, json.JSONEncoder)



# Generated at 2022-06-25 16:06:37.101876
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    for i in range(2):
        extended_encoder_0 = _ExtendedEncoder()
        var_0 = extended_encoder_0.default(extended_encoder_0)
        assert isinstance(var_0, dict)
        extended_encoder_1 = _ExtendedEncoder()
        extended_encoder_1._ExtendedEncoder__dict__ = {'repeated_value_entries': {'dataclasses_json.encoder._ExtendedEncoder': [var_0]}}
        extended_encoder_1.default = lambda o: extended_encoder_1._ExtendedEncoder__dict__['repeated_value_entries']['dataclasses_json.encoder._ExtendedEncoder'][-1]
        extended_encoder_1.default_mro = lambda o: extended_enc

# Generated at 2022-06-25 16:06:39.062494
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()
    assert extended_encoder_1



# Generated at 2022-06-25 16:08:04.911849
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:08:11.227842
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    __json_0 = _ExtendedEncoder()
    var_0 = type(__json_0)
    assert isinstance(var_0, type)



# Generated at 2022-06-25 16:08:16.936982
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # method call _ExtendedEncoder.__init__()
    extended_encoder_0 = _ExtendedEncoder()
    # method call _ExtendedEncoder.__init__(indent=None, separators=None,
    # ensure_ascii=True, check_circular=True, allow_nan=True, sort_keys=False,
    # item_sort_key=None, skipkeys=False, default=None, kw=None)
    extended_encoder_1 = _ExtendedEncoder(ensure_ascii=False)
    x = 1

# Generated at 2022-06-25 16:08:19.198645
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:08:22.198821
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)


# Generated at 2022-06-25 16:08:24.280016
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:08:31.273870
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:08:33.323726
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    instance_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:08:33.786936
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()




# Generated at 2022-06-25 16:08:44.043693
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    o = [1, 2, 3]
    assert encoder.default(o) == [1, 2, 3]
    assert encoder.default({'foo': 'bar'}) == {'foo': 'bar'}
    assert encoder.default('foobar') == 'foobar'
    assert encoder.default(123) == 123
    assert encoder.default(123.123) == 123.123
    assert encoder.default(True) == True
    assert encoder.default(None) == None
    assert encoder.default(datetime(2018, 12, 30, tzinfo=timezone.utc)) == 1546215600.0
    assert encoder.default(datetime(2018, 12, 30)) == 1546215600.0