

# Generated at 2022-06-25 16:03:01.633557
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder(skipkeys=True, ensure_ascii=True,  
        check_circular=True, allow_nan=True, sort_keys=False,  
        indent=None, separators=None, default=None,  
        sort_keys=True, indent=4, separators=(',', ': '), default=dict)


# Generated at 2022-06-25 16:03:05.085615
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, json.JSONEncoder), \
        "Assert that extended_encoder_0 is an instance of json.JSONEncoder"


# Generated at 2022-06-25 16:03:09.134480
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert _isinstance_safe(extended_encoder, json.JSONEncoder)

test_case_0()

# Generated at 2022-06-25 16:03:17.768391
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    global _ExtendedEncoder
    extended_encoder = _ExtendedEncoder()
    test_case = []
    isinstance_0          = _isinstance_safe(test_case, Collection)
    isinstance_1          = _isinstance_safe(test_case, Mapping)
    if isinstance_0 or isinstance_1:
        _ExtendedEncoder.default(extended_encoder, test_case)
    else:
        result = json.JSONEncoder.default(extended_encoder, test_case)


# Generated at 2022-06-25 16:03:25.752222
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    o_0 = Collection()
    json_0_0 = extended_encoder_0.default(o_0)
    assert json_0_0 == []
    o_1 = str()
    json_1_0 = extended_encoder_0.default(o_1)
    assert json_1_0 == ""
    o_2 = int()
    json_2_0 = extended_encoder_0.default(o_2)
    assert json_2_0 == 0
    o_3 = float()
    json_3_0 = extended_encoder_0.default(o_3)
    assert json_3_0 == 0.0
    o_4 = bool()

# Generated at 2022-06-25 16:03:27.831118
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert(isinstance(extended_encoder, _ExtendedEncoder))



# Generated at 2022-06-25 16:03:29.858583
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert issubclass(_ExtendedEncoder, json.JSONEncoder)
    assert callable(_ExtendedEncoder)


# Generated at 2022-06-25 16:03:32.948489
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    """
    Test for method _ExtendedEncoder.default
    """
    # Test 0
    extended_encoder_0 = _ExtendedEncoder()
    # Test 1
    extended_encoder_0.default(None)


# Generated at 2022-06-25 16:03:33.913124
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    instance = _ExtendedEncoder()


# Generated at 2022-06-25 16:03:41.758351
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_1 = _ExtendedEncoder()
    # Test dictionary
    dictionary_1 = {}
    dictionary_2 = {'id': 1, 'name': "Jim"}
    dictionary_3 = {'id': 1, 'name': "Jim", 'stu': {'num': '001', 'name': "Fred"}}
    assert(extended_encoder_1.default(dictionary_1) == {})
    assert(extended_encoder_1.default(dictionary_2) == {'id': 1, 'name': "Jim"})
    assert(extended_encoder_1.default(dictionary_3) ==
           {'id': 1, 'name': "Jim", 'stu': {'num': '001', 'name': "Fred"}})
    # Test list

# Generated at 2022-06-25 16:04:06.845744
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()


# Generated at 2022-06-25 16:04:07.607795
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()

# Generated at 2022-06-25 16:04:12.355466
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tt = _ExtendedEncoder()
    assert tt.encode([]) == '[]'
    assert tt.encode({}) == '{}'
    assert tt.encode(datetime(2000, 1, 1, 12, 5, 6, 3, timezone.utc)) == '946689906.000003'
    assert tt.encode(UUID("00000000-0000-0000-0000-000000000000")) == '00000000-0000-0000-0000-000000000000'
    assert tt.encode(Decimal("1.2")) == '"1.2"'


# Generated at 2022-06-25 16:04:16.664271
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    # Run method _ExtendedEncoder.default
    extended_encoder_0.default('abc')
    extended_encoder_0.default(x=1)
    extended_encoder_0.default(1)



# Generated at 2022-06-25 16:04:17.886266
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()


# Generated at 2022-06-25 16:04:19.149802
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()


# Generated at 2022-06-25 16:04:25.036921
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """
    Test constructor of class _ExtendedEncoder
    """
    obj = _ExtendedEncoder()
    assert isinstance(obj,json.JSONEncoder)
    assert obj.encode(b'\xff\x00\x00') == '"\xff\x00\x00"'




# Generated at 2022-06-25 16:04:27.036769
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert issubclass(_ExtendedEncoder, json.JSONEncoder)
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 16:04:38.407904
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from json import JSONEncoder, dumps, loads
    from uuid import UUID
    from decimal import Decimal
    from datetime import datetime, timezone
    from enum import Enum
    class TestJSONEncoder(JSONEncoder):
        def default(self, o) -> Json:
            result: Json
            if isinstance(o, (list, dict, str, int, float, bool, type(None))):
                result = o
            elif isinstance(o, UUID):
                result = str(o)
            elif isinstance(o, Decimal):
                result = str(o)
            elif isinstance(o, datetime):
                result = o.timestamp()
            elif isinstance(o, Enum):
                result = o.value
            else:
                result = JSONEncoder.default

# Generated at 2022-06-25 16:04:42.463134
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()
    assert isinstance(extended_encoder_1, _ExtendedEncoder)
    assert not hasattr(extended_encoder_1, '__str__')


# Generated at 2022-06-25 16:05:10.765532
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tuple_0 = 0
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    var_0 = extended_encoder_0.default(tuple_0)



# Generated at 2022-06-25 16:05:13.072950
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tuple_0 = tuple()
    extended_encoder_0 = _ExtendedEncoder(tuple_0)
    test_case_0()


# Generated at 2022-06-25 16:05:15.859454
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tuple_0 = None
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)


# Generated at 2022-06-25 16:05:20.420920
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tuple_0 = None
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    extended_encoder_0.default(tuple_0)
    tuple_0 = []
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    extended_encoder_0.default(tuple_0)


# Generated at 2022-06-25 16:05:25.377213
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tuple_0 = (dict({1: 1}), str())
    tuple_1 = (datetime.now(timezone.utc).timestamp(), )
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    extended_encoder_0.default(tuple_1)
    # Test with None
    extended_encoder_1 = _ExtendedEncoder(skipkeys=tuple_0)
    var_0 = extended_encoder_1.default(tuple_1)



# Generated at 2022-06-25 16:05:28.134026
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tuple_0 = None
    # Call the __init__ constructor, call the default method, and make an assertion
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    var_0 = extended_encoder_0.default(tuple_0)
    assert (var_0 == tuple_0)


# Generated at 2022-06-25 16:05:38.218577
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    tuple_0 = None
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    var_1 = extended_encoder_0.default(tuple_0)
    var_2 = extended_encoder_0.default(tuple_0)
    var_3 = extended_encoder_0.default(tuple_0)
    assert var_1 == var_2 == var_3

# Parametrized test for method default of class _ExtendedEncoder

# Generated at 2022-06-25 16:05:40.066039
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tuple_0 = None
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    assert extended_encoder_0 is not None


# Generated at 2022-06-25 16:05:43.689799
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # default
    tuple_0 = None
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    var_0 = extended_encoder_0.default(tuple_0)


# Generated at 2022-06-25 16:05:45.918162
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tuple_0 = None
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    extended_encoder_0


# Generated at 2022-06-25 16:06:18.394974
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tuple_0 = None
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    var_0 = extended_encoder_0.default(tuple_0)
    var_1 = extended_encoder_0.default(tuple_0)
    tuple_1 = UUID('0d774b80-3af3-4963-869b-e26cc993a0b2')
    extended_encoder_1 = _ExtendedEncoder(allow_nan=tuple_1)
    var_2 = extended_encoder_1.default(tuple_1)
    var_3 = extended_encoder_1.default(tuple_1)


# Generated at 2022-06-25 16:06:28.182082
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tuple_0 = None
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    extended_encoder_1 = _ExtendedEncoder(ensure_ascii=tuple_0)
    extended_encoder_2 = _ExtendedEncoder(indent=tuple_0)
    extended_encoder_3 = _ExtendedEncoder(sort_keys=tuple_0)
    extended_encoder_4 = _ExtendedEncoder(skipkeys=tuple_0)
    extended_encoder_5 = _ExtendedEncoder(allow_nan=tuple_0, ensure_ascii=tuple_0, indent=tuple_0, sort_keys=tuple_0, skipkeys=tuple_0)


# Generated at 2022-06-25 16:06:32.966475
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # initialization
    tuple_0 = None
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    tuple_0 = None

    assert _isinstance_safe(extended_encoder_0, json.JSONEncoder)
    assert isinstance(var_0, type(None))



# Generated at 2022-06-25 16:06:43.867809
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tuple_0 = None
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    assert isinstance(extended_encoder_0, _ExtendedEncoder)
    assert extended_encoder_0.allow_nan == tuple_0
    assert extended_encoder_0.check_circular == True
    assert extended_encoder_0.ensure_ascii == True
    assert extended_encoder_0.indent == None
    assert extended_encoder_0.key_separator == ':'
    assert extended_encoder_0.skipkeys == False
    assert extended_encoder_0.sort_keys == False
    assert extended_encoder_0.default == extended_encoder_0.default



# Generated at 2022-06-25 16:06:51.049007
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tuple_0 = None
    array_0 = [None, 1]
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    extended_encoder_1 = _ExtendedEncoder(array_0)
    var_0 = extended_encoder_0.default(tuple_0)
    var_1 = extended_encoder_0.default(array_0[1])



# Generated at 2022-06-25 16:06:53.678399
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tuple_0 = None
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    var_0 = extended_encoder_0.default(tuple_0)


# Generated at 2022-06-25 16:07:06.583940
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tuple_1 = None
    extended_encoder_1 = _ExtendedEncoder(allow_nan=tuple_1)
    tuple_2 = None
    extended_encoder_2 = _ExtendedEncoder(allow_nan=tuple_2)
    tuple_3 = None
    extended_encoder_3 = _ExtendedEncoder(allow_nan=tuple_3)
    tuple_4 = None
    extended_encoder_4 = _ExtendedEncoder(allow_nan=tuple_4)
    tuple_5 = None
    extended_encoder_5 = _ExtendedEncoder(allow_nan=tuple_5)
    tuple_6 = None
    extended_encoder_6 = _ExtendedEncoder(allow_nan=tuple_6)
    tuple_7 = None
    extended_encoder_

# Generated at 2022-06-25 16:07:14.601421
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    class ListDictInner(typing.Dict[str, str]):
        pass

    class ListDictOuter(typing.Dict[str, ListDictInner]):
        pass

    tuple_0 = None
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    extended_encoder_0.default(tuple_0)
    tuple_1 = 1
    extended_encoder_1 = _ExtendedEncoder(allow_nan=tuple_1)
    extended_encoder_1.default(tuple_1)


# Generated at 2022-06-25 16:07:16.419172
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Tests for class _ExtendedEncoder can prepare here.
    pass


# Generated at 2022-06-25 16:07:18.166435
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tuple_0 = None
    extended_encoder_0 = _ExtendedEncoder(allow_nan=tuple_0)
    assert extended_encoder_0.allow_nan == tuple_0


# Generated at 2022-06-25 16:08:21.563792
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from dataclasses_json.utils import _ExtendedEncoder
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0



# Generated at 2022-06-25 16:08:25.996090
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test if the class has correct property
    assert _ExtendedEncoder.__name__ == '_ExtendedEncoder'

    # Assert if _ExtendedEncoder is not callable
    with pytest.raises(TypeError) as excinfo:
        _ExtendedEncoder()
    assert 'is not callable' in str(excinfo.value)



# Generated at 2022-06-25 16:08:29.277292
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:08:32.483205
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder.__init__(1, 2) == None
    assert _ExtendedEncoder.__init__(2, 1) == None
    assert _ExtendedEncoder.__init__(1, 1.0) == None
    assert _ExtendedEncoder.__init__(1.0, 1) == None
    assert _ExtendedEncoder.__init__(1, 1) == None
    assert _ExtendedEncoder.__init__(True, False) == None
    assert _ExtendedEncoder.__init__(False, True) == None


# Generated at 2022-06-25 16:08:33.087511
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()


# Generated at 2022-06-25 16:08:37.586123
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        _ExtendedEncoder()
    except TypeError:
        assert False

JsonObj = Union[Mapping[str, Any], list, str, int, float, bool, None]

DTOut = Union[datetime, int, float]



# Generated at 2022-06-25 16:08:42.844883
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)
    assert var_0 == set()
    extended_encoder_1 = _ExtendedEncoder(False)
    var_0 = extended_encoder_1.default(extended_encoder_1)
    assert var_0 == set()
    extended_encoder_2 = _ExtendedEncoder(False, 'b')
    var_0 = extended_encoder_2.default(extended_encoder_2)
    assert var_0 == set()
    extended_encoder_3 = _ExtendedEncoder(False, 'b', False)
    var_0 = extended_encoder_3.default(extended_encoder_3)

# Generated at 2022-06-25 16:08:44.477435
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ext_enc_0 = _ExtendedEncoder()
    assert isinstance(ext_enc_0, _ExtendedEncoder)


# Generated at 2022-06-25 16:08:45.759043
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_0 = _ExtendedEncoder()
    assert type(var_0) is _ExtendedEncoder


# Generated at 2022-06-25 16:08:47.866502
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    test_case_0()



# Generated at 2022-06-25 16:11:16.392385
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    dict_0 = dict(a=extended_encoder_0)
    test_case_0()
    print(dict_0)



# Generated at 2022-06-25 16:11:16.943044
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():

    test_case_0()



# Generated at 2022-06-25 16:11:23.266879
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0._current_indent_level == 0
    assert extended_encoder_0.item_separator == ','
    assert extended_encoder_0.key_separator == ':'
    assert extended_encoder_0.indent == 4
    assert extended_encoder_0.ensure_ascii == True
    assert extended_encoder_0.check_circular == True
    assert extended_encoder_0.allow_nan == True
    assert extended_encoder_0.sort_keys == False
    assert extended_encoder_0.skipkeys == False
    assert extended_encoder_0.use_decimal == True
    assert extended_encoder_0.namedtuple_as_object == True
    assert extended_enc

# Generated at 2022-06-25 16:11:24.190951
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()

# vim: set filetype=python :

# Generated at 2022-06-25 16:11:29.342470
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():

    # default should be a function
    assert isinstance(_ExtendedEncoder.default, type(test_case_0))



# Generated at 2022-06-25 16:11:41.572969
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    key_0 = 'indent'
    val_0 = 0
    extended_encoder_0 = json.JSONEncoder(**{key_0: val_0})
    extended_encoder_0 = _ExtendedEncoder(**{key_0: val_0})
    extended_encoder_0 = _ExtendedEncoder(extended_encoder_0, **{key_0: val_0})
    extended_encoder_0.default(extended_encoder_0)
    extended_encoder_0.default(list())
    extended_encoder_0.default(dict())
    extended_encoder_0.default(datetime.now(timezone.utc))

# Generated at 2022-06-25 16:11:48.603070
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    try:
        var_0 = extended_encoder_0.default(extended_encoder_0)
        assert var_0 == '<dataclasses_json._ExtendedEncoder object at 0x000001D5F5F7C828>'
        print("passed test__ExtendedEncoder")
    except AssertionError:
        print("failed test__ExtendedEncoder")


# Generated at 2022-06-25 16:11:50.211511
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    var_0 = _ExtendedEncoder()
    var_1 = var_0.default(var_0)


# Generated at 2022-06-25 16:11:58.113449
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0._current_indent_level, int)
    assert extended_encoder_0._current_indent_level == 0
    assert isinstance(extended_encoder_0._current_indent, str)
    assert extended_encoder_0._current_indent == ''
    assert isinstance(extended_encoder_0._indent, int)
    assert extended_encoder_0._indent == 0
    assert isinstance(extended_encoder_0._sort_keys, bool)
    assert extended_encoder_0._sort_keys == False
    assert isinstance(extended_encoder_0._skipkeys, bool)
    assert extended_encoder_0._skipkeys == True

# Generated at 2022-06-25 16:11:59.320582
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
