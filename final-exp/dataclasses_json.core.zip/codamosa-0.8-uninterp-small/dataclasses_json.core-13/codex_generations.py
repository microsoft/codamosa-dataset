

# Generated at 2022-06-25 16:02:44.608877
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Ensure that the constructor for _ExtendedEncoder does not throw an exception
    instance = _ExtendedEncoder()
    if instance is not None and instance is not MISSING:
        assert True
    else:
        warnings.warn('_ExtendedEncoder constructor returned None, expected an instance')
        assert False


# Generated at 2022-06-25 16:02:48.111769
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e0 = _ExtendedEncoder()
    assert _ExtendedEncoder.default == _ExtendedEncoder.default



# Generated at 2022-06-25 16:02:49.610107
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = _ExtendedEncoder()
    assert o is not None


# Generated at 2022-06-25 16:02:58.524682
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Init
    encoder = _ExtendedEncoder()
    # Case 0: no type
    type_0: type
    value_0 = None
    # Test
    result_0 = encoder.default(value_0)
    # Assert
    assert result_0 is None
    # Case 1: int
    type_1: int
    value_1 = 1
    # Test
    result_1 = encoder.default(value_1)
    # Assert
    assert result_1 == 1
    # Case 2: float
    type_2: float
    value_2 = 1.0
    # Test
    result_2 = encoder.default(value_2)
    # Assert
    assert result_2 == 1.0
    # Case 3: string
    type_3: str

# Generated at 2022-06-25 16:03:00.224729
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder() is not None


# Generated at 2022-06-25 16:03:01.482302
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:03:05.216933
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings(record=True) as w:
        _ExtendedEncoder()
        assert len(w) == 1
        assert str(w[-1].message) == "_ExtendedEncoder is deprecated and will be removed, use json.JSONEncoder instead."


# Generated at 2022-06-25 16:03:06.819072
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder() is not None



# Generated at 2022-06-25 16:03:09.087095
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()
    pass



# Generated at 2022-06-25 16:03:16.457794
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Create ExtendedEncoder object
    encoder = _ExtendedEncoder()

    for value in [True, False, 1.0, 42, 'Hello World!', None, datetime.now(timezone.utc)]:
        # test default on value
        assert isinstance(encoder.default(value), Json)


# Generated at 2022-06-25 16:03:37.454111
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test object creation
    extended_encoder = _ExtendedEncoder()
    # Test the __str__ method
    string = extended_encoder.__str__()



# Generated at 2022-06-25 16:03:38.333742
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert isinstance(_ExtendedEncoder, type)


# Generated at 2022-06-25 16:03:40.254636
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    instance = _ExtendedEncoder()
    with pytest.raises(TypeError):
        instance.default(123)


# Generated at 2022-06-25 16:03:45.899367
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Arrange
    encoder_0 = _ExtendedEncoder()
    # Act
    # Assert
    assert encoder_0._ExtendedEncoder__check_circular is False
    assert encoder_0._ExtendedEncoder__ensure_ascii is True
    assert encoder_0._ExtendedEncoder__indent is None
    assert encoder_0._ExtendedEncoder__key_separator is ':'
    assert encoder_0._ExtendedEncoder__kw is {
        'allow_nan': True,
        'default': encoder_0.default,
        'indent': None,
        'separators': (',', ':'),
        'skipkeys': False,
        'sort_keys': False,
        'ensure_ascii': True
    }
    assert encoder_0._

# Generated at 2022-06-25 16:03:48.232863
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert(_ExtendedEncoder == json.JSONEncoder)



# Generated at 2022-06-25 16:03:49.474736
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _ExtendedEncoder().default(2)


# Generated at 2022-06-25 16:03:52.199389
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    new_instance = _ExtendedEncoder()
    assert (new_instance is not None)

# Test function to ensure that _ExtendedEncoder is a subclass of json.JSONEncoder

# Generated at 2022-06-25 16:03:59.923047
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()
    field_override = FieldOverride()
    uuid = UUID(int=0)
    assert(extended_encoder.default(uuid) == "00000000-0000-0000-0000-000000000000")
    o = []
    assert(extended_encoder.default(o) == [])
    assert(extended_encoder.default([[u'key', False]]) == [[u'key', False]])
    assert(extended_encoder.default([[{u'key': False}, [False]]]) == [[{u'key': False}, [False]]])
    assert(extended_encoder.default({u'key': False}) == {u'key': False})

# Generated at 2022-06-25 16:04:01.048792
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder is not None


# Generated at 2022-06-25 16:04:08.968540
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        # Test Case 0
        _ExtendedEncoder(indent=0, sort_keys=False, separators=(',', ':'),
                         ensure_ascii=True, allow_nan=True,
                         skipkeys=False, default=MISSING, check_circular=True,
                         cls=MISSING, object_pairs_hook=MISSING,
                         strict=True)
    except TypeError as e:
        assert False, f'TypeError raised: {e}'
    except Exception as e:
        assert False, f'Exception raised: {e}'


# For unit test for class _ExtendedEncoder

# Generated at 2022-06-25 16:04:30.413365
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:04:36.104662
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    for extended_encoder_0 in cfg.encoders:
        _handle_undefined_parameters_safe(extended_encoder_0.default, extended_encoder_0)
    extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:04:41.980838
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Instantiate the class and check the defaults
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0.encoding == 'utf-8'
    assert extended_encoder_0.indent == None
    assert extended_encoder_0.ensure_ascii == True
    assert extended_encoder_0.sort_keys == False
    assert extended_encoder_0.check_circular == True
    assert extended_encoder_0.allow_nan == True
    assert extended_encoder_0.separators == (',', ':')
    assert extended_encoder_0.default == extended_encoder_0.default

    # Set the values for the class and check
    extended_encoder_0.encoding = 'utf-32'
    extended_encoder_0.indent

# Generated at 2022-06-25 16:04:43.101125
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    test_case_0()


# Generated at 2022-06-25 16:04:44.289329
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:04:45.692535
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var = _ExtendedEncoder()
    test_case_0()



# Generated at 2022-06-25 16:04:47.038074
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:04:51.818144
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, json.JSONEncoder)



# Generated at 2022-06-25 16:04:53.667540
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


BrokenField = namedtuple('BrokenField', ['name', 'exc'])



# Generated at 2022-06-25 16:04:55.423680
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()


# Generated at 2022-06-25 16:05:42.182846
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:05:45.177658
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder_0 = _ExtendedEncoder()
    var_0 = encoder_0.default(encoder_0)
    extended_encoder_0 = _ExtendedEncoder()
    var_1 = extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:05:48.714225
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)



# Generated at 2022-06-25 16:05:49.952939
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:06:00.207674
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    with pytest.raises(RuntimeError):
        extended_encoder_0.default(extended_encoder_0)
    extended_encoder_1 = _ExtendedEncoder()
    with pytest.raises(RuntimeError):
        extended_encoder_1.default(extended_encoder_1)
    extended_encoder_2 = _ExtendedEncoder()
    with pytest.raises(RuntimeError):
        extended_encoder_2.default(extended_encoder_2)
    extended_encoder_3 = _ExtendedEncoder()
    with pytest.raises(RuntimeError):
        extended_encoder_3.default(extended_encoder_3)
    extended_encoder_4 = _ExtendedEncoder()


# Generated at 2022-06-25 16:06:11.338025
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    # param in_0
    assert extended_encoder_0.in_0 == 'dataclasses_json._ExtendedEncoder'
    # param floatstr
    assert extended_encoder_0.floatstr == 'inf'
    # param intstr
    assert extended_encoder_0.intstr == 'inf'
    # param str
    assert extended_encoder_0.str == 'inf'
    # param float
    assert extended_encoder_0.float == 'inf'
    # param int
    assert extended_encoder_0.int == 'inf'
    # param bytes
    assert extended_encoder_0.bytes == 'inf'
    # param byte
    assert extended_encoder_0.byte == 'inf'
    # param buf

# Generated at 2022-06-25 16:06:14.055073
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:06:15.461060
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()


# Generated at 2022-06-25 16:06:19.312662
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()


# Generated at 2022-06-25 16:06:22.236059
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder is not None


# Generated at 2022-06-25 16:08:03.555211
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)
    class_0 = _ExtendedEncoder()
    class_0.default(extended_encoder_0)



# Generated at 2022-06-25 16:08:05.713566
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_0.default(extended_encoder_0)



# Generated at 2022-06-25 16:08:08.813869
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = json.JSONEncoder()
    o_1 = copy.deepcopy(extended_encoder_0)
    result_1 = extended_encoder_0.default(o_1)


# Generated at 2022-06-25 16:08:10.454175
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:08:12.217879
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        _ExtendedEncoder()
    except Exception:
        raise AssertionError("calling constructor of class _ExtendedEncoder raises Exception")



# Generated at 2022-06-25 16:08:14.076895
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0 is not None



# Generated at 2022-06-25 16:08:16.415971
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    if json.__name__ == 'json':
        assert isinstance(extended_encoder_0, json.JSONEncoder)
    assert not isinstance(extended_encoder_0, dict)



# Generated at 2022-06-25 16:08:26.089044
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder(ensure_ascii=True, sort_keys=True, indent=10, separators=(',', ':'))
    o_1 = 1
    result_1 = extended_encoder_1.default(o_1)

    extended_encoder_2 = _ExtendedEncoder(ensure_ascii=False, sort_keys=True, indent=10, separators=(',', ':'))
    o_2 = 0.5
    result_2 = extended_encoder_2.default(o_2)

    extended_encoder_3 = _ExtendedEncoder(ensure_ascii=True, sort_keys=False, indent=10, separators=(',', ':'))
    o_3 = None

# Generated at 2022-06-25 16:08:31.344822
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_1 = _ExtendedEncoder()
    var_1 = extended_encoder_1.default(1)
    assert(var_1 == 1)

    extended_encoder_2 = _ExtendedEncoder()
    var_2 = extended_encoder_2.default("abcd")
    assert(var_2 == "abcd")

    extended_encoder_3 = _ExtendedEncoder()
    var_3 = extended_encoder_3.default(True)
    assert(var_3 == True)

    extended_encoder_4 = _ExtendedEncoder()
    var_4 = extended_encoder_4.default("[]")
    assert(var_4 == "[]")

    extended_encoder_5 = _ExtendedEncoder()

# Generated at 2022-06-25 16:08:33.650752
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0
