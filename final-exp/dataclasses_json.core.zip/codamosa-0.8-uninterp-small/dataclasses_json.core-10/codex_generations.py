

# Generated at 2022-06-25 16:02:41.989419
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()




# Generated at 2022-06-25 16:02:43.127275
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:02:44.049104
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:02:52.728942
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # type: () -> None
    def _is_equal(result, expect):
        # type: (Json, Json) -> bool
        return result == expect

    def _is_equal_collection_mapping(result, expect):
        # type: (Collection, Collection) -> bool
        for r, e in zip(result, expect):
            if isinstance(r, (list, tuple, set)):
                if not _is_equal_collection_mapping(r, e):
                    return False
            elif isinstance(r, dict):
                if not _is_equal_collection_mapping(r, e):
                    return False
            else:
                if not _is_equal(r, e):
                    return False
        return True

    # Type testing of Enum.name property

# Generated at 2022-06-25 16:02:53.690497
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:02:57.755607
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = Enum
    i = _ExtendedEncoder.default(None, o)
    assert(i == o)


# Generated at 2022-06-25 16:03:03.434006
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    decoded_0 = encoder.default(None)
    assert(decoded_0 == None)
    decoded_0 = encoder.default(1337)
    assert(decoded_0 == 1337)
    decoded_0 = encoder.default(1337.0)
    assert(decoded_0 == 1337.0)

# Generated at 2022-06-25 16:03:04.415975
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:03:08.725752
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default({"a": [1, 2, 3]}) == {"a": [1, 2, 3]}, "Test #1 failed"



# Generated at 2022-06-25 16:03:11.096173
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder() is not None

# Regression test for issue #117: https://github.com/lidatong/dataclasses-json/issues/117

# Generated at 2022-06-25 16:03:36.231566
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder()
    str_0 = 'P7|"id[O2/OWg_=IA'
    dict_0 = {str_0: str_0, str_0: bool_0, str_0: str_0, str_0: str_0}
    var_0 = extended_encoder_0.default(extended_encoder_0)


# noinspection PyShadowingNames

# Generated at 2022-06-25 16:03:43.381341
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test with bool
    bool_0 = False
    str_0 = 'P7|"id[O2/OWg_=IA'
    dict_0 = {str_0: str_0, str_0: bool_0, str_0: str_0, str_0: str_0}
    extended_encoder_0 = _ExtendedEncoder(check_circular=dict_0)
    # Test with str
    str_1 = 'c0gsC^x?]}e-L>7<X'
    float_0 = 4.301180439535352e-39
    bool_1 = True
    dict_1 = {str_0: str_1, str_0: bool_1, str_0: str_1, str_0: str_1}
    extended_encoder_1 = _

# Generated at 2022-06-25 16:03:54.518228
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test case for __init__
    # Basic usage
    extended_encoder = _ExtendedEncoder(skipkeys=True,
                                        ensure_ascii=True,
                                        check_circular=True,
                                        allow_nan=True,
                                        indent=True,
                                        separators=True,
                                        default=True,
                                        sort_keys=True)

    # Test case for default
    # Basic usage
    o = {'key': 'value'}
    result = extended_encoder.default(o)
    assert result == o

    o = {"key": {'key_2': ['value_2_1', 'value_2_2']}}
    result = extended_encoder.default(o)
    assert result == o

    # Test case for default
    # tzinfo argument
    d

# Generated at 2022-06-25 16:03:56.150508
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        test_case_0()
    except:
        pass

# Generated at 2022-06-25 16:04:02.532504
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Testing constructor of class _ExtendedEncoder
    # Testing instance creation
    instance = _ExtendedEncoder(check_circular={})
    instance_0 = _ExtendedEncoder(skipkeys=True)
    instance_1 = _ExtendedEncoder(ensure_ascii=True)
    instance_2 = _ExtendedEncoder(allow_nan=True)
    instance_3 = _ExtendedEncoder(indent=4)
    instance_4 = _ExtendedEncoder(separators=(", ", ": "))
    instance_5 = _ExtendedEncoder(default=lambda i: i)
    instance_6 = _ExtendedEncoder(sort_keys=False)
    instance_7 = _ExtendedEncoder(encoding="utf8")


# Generated at 2022-06-25 16:04:07.141627
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_0 = True
    str_0 = '~`:+`'
    dict_0 = {str_0: bool_0, str_0: bool_0, str_0: bool_0}
    extended_encoder_0 = _ExtendedEncoder(ensure_ascii=bool_0, check_circular=dict_0)



# Generated at 2022-06-25 16:04:16.291786
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    bool_0 = False
    str_0 = 'P7|"id[O2/OWg_=IA'
    dict_0 = {str_0: str_0, str_0: bool_0, str_0: str_0, str_0: str_0}
    extended_encoder_0 = _ExtendedEncoder(check_circular=dict_0)
    var_0 = extended_encoder_0.default(extended_encoder_0)

if __name__ == '__main__':
    test_case_0()
    test__ExtendedEncoder_default()

# Generated at 2022-06-25 16:04:27.645795
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    """Tests whether the default method of the _ExtendedEncoder class
    handles optional types correctly in case they are filled.
    """
    # Create a bool object
    bool_object = False
    # Create some string objects
    str_object = 'P7|"id[O2/OWg_=IA'
    # Create a dictionary
    dict_object = {str_object: str_object, str_object: bool_object, str_object: str_object, str_object: str_object}
    # Create a _ExtendedEncoder object
    extended_encoder_object = _ExtendedEncoder(check_circular=dict_object)
    # Call the default method of the extended encoder object with the extended encoder object
    var_object = extended_encoder_object.default(extended_encoder_object)

test

# Generated at 2022-06-25 16:04:38.533603
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_0 = True
    bool_1 = False
    dict_0 = {'j[81g|]\':mPgIxH': bool_1}
    dict_1 = {'j[81g|]\':mPgIxH': bool_1}
    int_0 = 1
    str_0 = 'P7|"id[O2/OWg_=IA'
    float_0 = 0.234
    float_1 = -0.234
    list_0 = [int_0, float_0, float_1, float_1, float_1, float_1, float_0, float_0, int_0]
    list_1 = [dict_1]

# Generated at 2022-06-25 16:04:48.919091
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_0 = {}
    var_1 = {}
    extended_encoder_1 = _ExtendedEncoder(var_0)
    assert extended_encoder_1.default == None
    assert extended_encoder_1.c_make_encoder == None
    assert extended_encoder_1.c_make_encoder == None
    assert extended_encoder_1.c_make_encoder == None
    assert extended_encoder_1.c_make_encoder == None
    assert extended_encoder_1.c_make_encoder == None
    assert extended_encoder_1.c_make_encoder == None
    assert extended_encoder_1.c_make_encoder == None
    assert extended_encoder_1.c_make_encoder == None

# Generated at 2022-06-25 16:05:12.996852
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(timezone.utc)
    var_1 = extended_encoder_0.default(timezone.utc)
    print(var_0)


# Generated at 2022-06-25 16:05:18.718486
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test case with no params
    extended_encoder_1 = _ExtendedEncoder()
    assert isinstance(extended_encoder_1, _ExtendedEncoder)

    # Test case with params
    extended_encoder_2 = _ExtendedEncoder(sort_keys=True)
    assert isinstance(extended_encoder_2, _ExtendedEncoder)

    # Test case with no params
    extended_encoder_3 = _ExtendedEncoder()
    assert isinstance(extended_encoder_3, _ExtendedEncoder)

# Generated at 2022-06-25 16:05:28.503715
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # 1. instantiate a _ExtendedEncoder object
    e = _ExtendedEncoder()
    # 2. test the string representation of _ExtendedEncoder object
    assert e.default(e) == "object at 0x7fb67eee5208"
    # 3. test the default method of _ExtendedEncoder object
    assert e.default(datetime(2019, 12, 4, tzinfo=timezone.utc)) == 1575446400.0
    assert e.default(UUID('59db4190-4ff4-4e0b-a7c9-1862be8088e6')) == '59db4190-4ff4-4e0b-a7c9-1862be8088e6'



# Generated at 2022-06-25 16:05:36.162140
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Setup
    extended_encoder = _ExtendedEncoder()


# Generated at 2022-06-25 16:05:36.828768
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()

test__ExtendedEncoder()



# Generated at 2022-06-25 16:05:40.140031
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """
    Test for constructor of class _ExtendedEncoder.
    """
    extended_encoder = _ExtendedEncoder()
    assert isinstance(extended_encoder, _ExtendedEncoder)
    assert isinstance(extended_encoder, json.JSONEncoder)



# Generated at 2022-06-25 16:05:44.729705
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    class TestClassA:
        def __init__(self, a):
            self.a = a
    instance_0 = TestClassA(1)
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(instance_0)


# Generated at 2022-06-25 16:05:49.021435
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, json.JSONEncoder)


# Generated at 2022-06-25 16:05:50.403912
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert isinstance(encoder, json.JSONEncoder)



# Generated at 2022-06-25 16:05:52.592377
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:06:31.320917
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:06:32.456210
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()

# Generated at 2022-06-25 16:06:33.636470
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:06:38.653200
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()
    assert _is_dataclass_instance(extended_encoder_1, json.JSONEncoder)
    assert vars(extended_encoder_1) == vars(json.JSONEncoder())


# Generated at 2022-06-25 16:06:42.500188
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    # Ensure that the object was initialized properly
    assert extended_encoder_0 is not None
    assert extended_encoder_0.default is not None


# Generated at 2022-06-25 16:06:43.307563
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    test_case_0()


# Generated at 2022-06-25 16:06:50.867768
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(dict([(1, 1), (2, 2)]))
    var_1 = extended_encoder_0.default([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    var_2 = extended_encoder_0.default({'a': 'b', 'c': 'd', 'e': 'f'})


# Generated at 2022-06-25 16:06:57.725104
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, json.JSONEncoder)
    assert not hasattr(extended_encoder_0, '__dict__')
    assert hasattr(extended_encoder_0, 'indent')
    assert extended_encoder_0.indent is None
    assert hasattr(extended_encoder_0, 'skipkeys')
    assert extended_encoder_0.skipkeys is False
    assert hasattr(extended_encoder_0, 'default')
    assert hasattr(extended_encoder_0, 'ensure_ascii')
    assert extended_encoder_0.ensure_ascii is True
    assert hasattr(extended_encoder_0, 'check_circular')
    assert extended

# Generated at 2022-06-25 16:07:01.359972
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert (isinstance(extended_encoder_0, _ExtendedEncoder))


# Generated at 2022-06-25 16:07:03.205379
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert isinstance(extended_encoder, json.JSONEncoder)



# Generated at 2022-06-25 16:09:33.982331
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Test for a custom type that has a custom JSON encoder which returns a
    # JSON-serializable value.
    class MyType:
        def to_json(self):
            return 12345

    class MyEncoder(json.JSONEncoder):
        def default(self, obj):
            try:
                return obj.to_json()
            except AttributeError:
                pass
            return json.JSONEncoder.default(self, obj)

    extended_encoder_1 = _ExtendedEncoder(MyEncoder)
    var_1 = extended_encoder_1.default(MyType())


# Generated at 2022-06-25 16:09:36.682270
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()
    var_1 = extended_encoder_1.default(extended_encoder_1)



# Generated at 2022-06-25 16:09:40.005815
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # pass
    extended_encoder = _ExtendedEncoder()
    assert type(extended_encoder) == _ExtendedEncoder


# Generated at 2022-06-25 16:09:45.135969
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        var_0 = _ExtendedEncoder()
        assert var_0.check_circular is False
        assert var_0.ensure_ascii is True
        assert var_0.indent is None
        assert var_0.separators is (', ', ': ')
        assert var_0.skipkeys is False
        assert var_0.sort_keys is False
        assert var_0.allow_nan is True
        assert var_0.cls is None
    except AssertionError:
        print("AssertionError: class _ExtendedEncoder constructor failed")



# Generated at 2022-06-25 16:09:46.812142
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder(allow_nan=False)
    test_case_0()



# Generated at 2022-06-25 16:09:47.988330
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    x = _ExtendedEncoder()


# Generated at 2022-06-25 16:09:49.521396
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    test_case_0()



# Generated at 2022-06-25 16:09:50.769084
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:09:52.900628
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0: Json = extended_encoder_0.default(extended_encoder_0)

# Test for __init__

# Generated at 2022-06-25 16:09:58.384247
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)
