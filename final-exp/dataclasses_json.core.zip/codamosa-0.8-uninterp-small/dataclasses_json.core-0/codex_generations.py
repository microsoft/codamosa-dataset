

# Generated at 2022-06-25 16:02:44.831792
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # noinspection PyPep8Naming
    _ExtendedEncoder().default()



# Generated at 2022-06-25 16:02:52.486010
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

    assert encoder.item_separator == ','
    assert encoder.key_separator == ':'
    assert encoder.default(None) is None
    assert encoder.default(False) is False
    assert encoder.default(True) is True
    assert encoder.default(Enum('A', 'B')) is "A"

# noinspection PyUnresolvedReferences

# Generated at 2022-06-25 16:02:55.040235
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    field_override = FieldOverride()
    default = json.JSONEncoder
    expected = _ExtendedEncoder
    actual = _ExtendedEncoder(field_override)
    assert actual == expected



# Generated at 2022-06-25 16:02:59.810232
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    test_case_0()

fields_v0 = [
        FieldOverride(encoder=_ExtendedEncoder,
                      decoder=None,
                      mm_field=None,
                      letter_case=cfg.LetterCase.CAMEL,
                      exclude=False)]


# Generated at 2022-06-25 16:03:01.534413
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder(sort_keys=True)


# Generated at 2022-06-25 16:03:04.062674
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    o = datetime.utcnow()
    result = encoder.default(o)
    assert(result == o.timestamp())


# Generated at 2022-06-25 16:03:04.969093
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:03:17.137955
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    # Test code

# Generated at 2022-06-25 16:03:18.431413
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Arrange
    # TODO: Add this method test
    pass


# Generated at 2022-06-25 16:03:19.586695
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:03:43.024706
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(sort_keys=bool_0)
    var_0 = extended_encoder_0.default(bool_0)
    bool_1 = True
    extended_encoder_0 = _ExtendedEncoder(sort_keys=bool_1)
    var_1 = extended_encoder_0.default(bool_1)
    bool_2 = False
    extended_encoder_0 = _ExtendedEncoder(sort_keys=bool_2)
    var_2 = extended_encoder_0.default(bool_2)



# Generated at 2022-06-25 16:03:46.665495
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    for i in range(0, 10):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter('always')
            test_case_0()
        assert len(w) == 0


# Generated at 2022-06-25 16:03:50.537503
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test case 0
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(sort_keys=bool_0)
    var_0 = extended_encoder_0.default(bool_0)
    



# Generated at 2022-06-25 16:03:55.539151
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder(sort_keys=True)


# Generated at 2022-06-25 16:03:58.281655
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(sort_keys=bool_0)
    # AssertionError: None == True : None and True are not equal
    assert extended_encoder_0 is None



# Generated at 2022-06-25 16:04:09.064100
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import datetime
    date = datetime.date(2020, 1, 1)
    int_0 = 0
    bool_0 = True
    bool_1 = bool_0
    string_0 = ''
    dict_0 = {}
    extended_encoder_0 = _ExtendedEncoder(skipkeys=bool_1)
    var_0 = extended_encoder_0.default(string_0)
    # self.assertEqual(var_0, string_0)
    extended_encoder_1 = _ExtendedEncoder(sort_keys=bool_0)
    var_1 = extended_encoder_1.default(dict_0)
    # self.assertEqual(var_1, dict_0)
    extended_encoder_2 = _ExtendedEncoder(indent=int_0)
    var_

# Generated at 2022-06-25 16:04:13.602485
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(sort_keys=bool_0)
    bool_1 = extended_encoder_0.sort_keys
    assert bool_1 is True


# Generated at 2022-06-25 16:04:16.663474
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_0 = False
    extended_encoder_0 = _ExtendedEncoder(sort_keys=bool_0)
    assert extended_encoder_0



# Generated at 2022-06-25 16:04:19.822748
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_1 = True
    extended_encoder_1 = _ExtendedEncoder(sort_keys=bool_1)
    assert extended_encoder_1 is not None


# Generated at 2022-06-25 16:04:29.835312
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test base class
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(sort_keys=bool_0)
    assert extended_encoder_0 is not None

    # Test instance parameter
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(bool_0)
    assert extended_encoder_0 is not None

    # Test instance parameter
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(sort_keys=bool_0)
    assert extended_encoder_0 is not None

    # Test instance parameter
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(indent=bool_0)
    assert extended_encoder_0 is not None

    # Test instance parameter
    bool_0 = True

# Generated at 2022-06-25 16:05:10.628951
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass



# Generated at 2022-06-25 16:05:13.806714
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():

    # Constructor creates ExtendedEncoder
    encoder_0 = _ExtendedEncoder()
    assert isinstance(encoder_0, _ExtendedEncoder)
    assert isinstance(encoder_0, json.JSONEncoder)



# Generated at 2022-06-25 16:05:15.749995
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        _ExtendedEncoder(separators=[])
    except:
        assert False



# Generated at 2022-06-25 16:05:17.267973
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0


# Generated at 2022-06-25 16:05:20.535020
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder__extended_encoder = _ExtendedEncoder()
    var__extended_encoder = extended_encoder__extended_encoder.default(extended_encoder__extended_encoder)
    print(var__extended_encoder)


# Generated at 2022-06-25 16:05:27.258548
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_1 = _ExtendedEncoder()
    assert _issubclass_safe(isinstance(extended_encoder_1, datetime), datetime) == False
    assert _issubclass_safe(isinstance(extended_encoder_1, datetime), UUID) == False
    assert _issubclass_safe(isinstance(extended_encoder_1, datetime), Enum) == False
    assert _issubclass_safe(isinstance(extended_encoder_1, datetime), Decimal) == False

    assert _isinstance_safe(extended_encoder_1, Collection) == False
    assert _isinstance_safe(extended_encoder_1, Mapping) == False
    assert _isinstance_safe(extended_encoder_1, datetime) == False
    assert _

# Generated at 2022-06-25 16:05:28.847181
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test for __init__()
    extended_encoder_1 = _ExtendedEncoder()
    assert isinstance(extended_encoder_1, _ExtendedEncoder)



# Generated at 2022-06-25 16:05:33.955765
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()

    # Testing for int
    var_0 = extended_encoder_0.default(0)
    assert var_0 == 0

    # Testing for list
    var_0 = extended_encoder_0.default([1, 2, 3])
    assert var_0 == [1, 2, 3]

    # Testing for dict
    var_0 = extended_encoder_0.default({"x": "y"})
    assert var_0 == {"x": "y"}

    # Testing for string
    var_0 = extended_encoder_0.default("hi")
    assert var_0 == "hi"

    # Testing for float
    var_0 = extended_encoder_0.default(0.0)
    assert var_0 == 0.0

    # Testing

# Generated at 2022-06-25 16:05:42.903888
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    json_0 = extended_encoder_0.default(extended_encoder_0)
    assert json_0['__class__'] == '_ExtendedEncoder'
    assert json_0['check_circular'] == False
    assert json_0['skipkeys'] == False
    assert json_0['ensure_ascii'] == True
    assert json_0['allow_nan'] == True
    assert json_0['indent'] == None
    assert json_0['separators'] == (',', ':')
    assert json_0['default'] == None
    assert json_0['sort_keys'] == False
    assert json_0['__module__'] == 'dataclasses_json.core'
    extended_encoder_1 = _ExtendedEncoder

# Generated at 2022-06-25 16:05:43.959139
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:07:09.843784
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # noinspection PyTypeChecker
    _ExtendedEncoder()



# Generated at 2022-06-25 16:07:12.508465
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:07:14.411877
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:07:16.322267
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    test__ExtendedEncoder_default_0()


# Generated at 2022-06-25 16:07:25.067338
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)
    extended_encoder_1 = _ExtendedEncoder()
    var_1 = extended_encoder_1.default(list())
    extended_encoder_2 = _ExtendedEncoder()
    var_2 = extended_encoder_2.default(dict())
    extended_encoder_3 = _ExtendedEncoder()
    var_3 = extended_encoder_3.default(datetime.now())
    extended_encoder_4 = _ExtendedEncoder()
    var_4 = extended_encoder_4.default(UUID('{12345678-1234-5678-1234-567812345678}'))
    extended_encoder_5

# Generated at 2022-06-25 16:07:27.002832
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:07:33.898583
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    dict_0 = dict()
    dict_0['a'] = 'b'
    bool_0 = extended_encoder_0.default(dict_0)
    dict_1 = dict()
    dict_1['a'] = 'b'
    dict_1['c'] = 'd'
    dict_2 = dict()
    dict_2['d'] = 'e'
    dict_1['b'] = dict_2
    dict_0 = dict()
    dict_0['a'] = 'b'
    bool_1 = extended_encoder_0.default(dict_0)
    dict_4 = dict()
    dict_4['a'] = 'b'
    dict_4['c'] = 'd'
    dict_5 = dict()
    dict

# Generated at 2022-06-25 16:07:35.281941
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    var = extended_encoder.default(extended_encoder)



# Generated at 2022-06-25 16:07:36.353367
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test with default params at _ExtendedEncoder
    _ExtendedEncoder()



# Generated at 2022-06-25 16:07:43.437979
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    try:
        var_0 = extended_encoder_0.default
        assert _isinstance_safe(var_0, types.MethodType)
        assert var_0.__name__ == 'default'
    except AssertionError:
        warnings.warn("Tests for '_ExtendedEncoder.default()' failed")



# Generated at 2022-06-25 16:11:55.424235
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()
    assert isinstance(extended_encoder.default(extended_encoder), Json)


# Generated at 2022-06-25 16:12:06.029761
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_1 = _ExtendedEncoder()
    extended_encoder_1 = _ExtendedEncoder()
    extended_encoder_2 = _ExtendedEncoder()
    extended_encoder_2 = _ExtendedEncoder()
    extended_encoder_3 = _ExtendedEncoder()
    extended_encoder_3 = _ExtendedEncoder()
    extended_encoder_4 = _ExtendedEncoder()
    extended_encoder_4 = _ExtendedEncoder()
    extended_encoder_5 = _ExtendedEncoder()
    extended_encoder_5 = _ExtendedEncoder()
    extended_encoder_6 = _ExtendedEncoder()
    extended_enc

# Generated at 2022-06-25 16:12:09.761969
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0.item_separator == ', '
    var_0 = extended_encoder_0.default(extended_encoder_0)
    assert var_0 == extended_encoder_0



# Generated at 2022-06-25 16:12:18.161344
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)
    assert var_0.__class__ == dict
    assert var_0 == {'json_encoder': '<class \'dataclasses_json.encoder._ExtendedEncoder\'>'}

    var_1 = extended_encoder_0.default(extended_encoder_0)
    assert var_1.__class__ == dict
    assert var_1 == {'json_encoder': '<class \'dataclasses_json.encoder._ExtendedEncoder\'>'}

    var_2 = extended_encoder_0.default(extended_encoder_0)
    assert var_2.__class__ == dict