

# Generated at 2022-06-25 16:02:49.882243
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder._ExtendedEncoder__check_circular is True
    assert encoder._ExtendedEncoder__ensure_ascii is True
    assert encoder._ExtendedEncoder__indent is None
    assert encoder._ExtendedEncoder__key_separator is ':'
    assert encoder._ExtendedEncoder__namedtuple_as_object is True
    assert encoder._ExtendedEncoder__sort_keys is False
    assert encoder._ExtendedEncoder__skipkeys is False
    assert encoder._ExtendedEncoder__allow_nan is True
    assert encoder._ExtendedEncoder__default is None
    assert encoder._ExtendedEncoder__encoding == 'utf-8'
    assert encoder._ExtendedEncoder__ensure_ascii is True


# Generated at 2022-06-25 16:02:58.737249
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ext_encoder = _ExtendedEncoder()

    actual_1 = ext_encoder.default([1,2,3])
    expected_1 = [1,2,3]
    assert actual_1 == expected_1

    actual_2 = ext_encoder.default({"a":"b"})
    expected_2 = {"a":"b"}
    assert actual_2 == expected_2

    actual_3 = ext_encoder.default(datetime(2016, 2, 1, tzinfo=timezone.utc))
    expected_3 = 1454313600.0
    assert actual_3 == expected_3

    actual_4 = ext_encoder.default(Decimal('3.14'))
    expected_4 = '3.14'
    assert actual_4 == expected_4

    actual_5 = ext_enc

# Generated at 2022-06-25 16:03:01.086451
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    result = _ExtendedEncoder().default("")
    assert result == '""'


# Generated at 2022-06-25 16:03:02.613897
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test case 1
    _ExtendedEncoder()


# Generated at 2022-06-25 16:03:04.368632
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(Decimal(1)) == '1'


# Generated at 2022-06-25 16:03:07.006011
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    o = [1, 2, 3]
    assert encoder.default(o) == o


# Generated at 2022-06-25 16:03:10.966102
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()

e1_0 = _ExtendedEncoder()
e1_0.default
e1_1 = _ExtendedEncoder()
e1_1.default

# Generated at 2022-06-25 16:03:13.494028
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()


# Generated at 2022-06-25 16:03:14.987273
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    encoder.default(set())

# Generated at 2022-06-25 16:03:23.030511
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.item_separator == ','
    assert encoder.key_separator == ':'
    assert encoder.skipkeys is False
    assert encoder.ensure_ascii is True
    assert encoder.check_circular is True
    assert encoder.allow_nan is True
    assert encoder.sort_keys is False
    assert encoder.indent is None
    assert encoder.separators is None
    assert encoder.default is None
    assert encoder.encoding is 'utf-8'
    assert encoder.default_flow_style is False
    assert encoder.use_decimal is False
    assert encoder.namedtuple_as_object is True
    assert encoder.tuple_as_array is True
    assert encoder.bigint

# Generated at 2022-06-25 16:03:47.854233
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:03:49.113252
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_encoder = _ExtendedEncoder()


# Generated at 2022-06-25 16:03:50.452752
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:04:01.590423
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert '1' == encoder.encode(1)
    assert '1' == encoder.encode(Decimal('1.0'))
    assert '1' == encoder.encode(Decimal('1'))
    assert '1.0' == encoder.encode(1.0)
    assert '[1, 2, 3]' == encoder.encode([1, 2, 3])
    assert '{"a": 1, "b": 2}' == encoder.encode({'a': 1, 'b': 2})
    assert 'null' == encoder.encode(None)
    assert '"1"' == encoder.encode('1')
    assert 'true' == encoder.encode(True)

# Generated at 2022-06-25 16:04:09.060146
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    date = datetime.now()
    assert e.default(date) == date.timestamp()
    u = UUID('b99a9a3a-07f3-471b-bb78-8c3c4cf4d4c5')
    assert e.default(u) == str(u)
    assert e.default(1.0) == 1.0
    assert e.default(1) == 1
    assert e.default(True) == True
    assert e.default(False) == False
    assert e.default(None) == None
    assert e.default('hi') == 'hi'
    assert e.default(["hi", None]) == ["hi", None]
    assert e.default({'hi': None}) == {'hi': None}
    assert e.default

# Generated at 2022-06-25 16:04:13.602194
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_obj = json.loads('{"foo": [1,2,3]}')
    result = _ExtendedEncoder().default(json_obj)
    assert result == {'foo': [1, 2, 3]}



# Generated at 2022-06-25 16:04:15.163046
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:04:16.481434
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ee = _ExtendedEncoder()


# Generated at 2022-06-25 16:04:17.785114
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:04:18.740098
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:04:40.525278
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj = _ExtendedEncoder()
    assert isinstance(obj, _ExtendedEncoder)


# Generated at 2022-06-25 16:04:42.009408
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:04:43.102041
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:04:46.912456
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Check result of constructor(s)
    extended_encoder_0 = _ExtendedEncoder()
    # Check result of method default(s)
    default_result = extended_encoder_0.default(0)
    assert default_result == '0'



# Generated at 2022-06-25 16:04:48.420346
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        _ExtendedEncoder()
    except TypeError as e:
        assert True



# Generated at 2022-06-25 16:04:51.250363
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:04:53.232409
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    # Test the decoder constructor
    assert encoder is not None


# Generated at 2022-06-25 16:04:56.519588
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Default constructor.
    instance_0 = _ExtendedEncoder()
    assert isinstance(instance_0, _ExtendedEncoder)



# Generated at 2022-06-25 16:04:57.386044
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:04:59.269375
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.JSONEncoder.default(json.JSONEncoder(), object())



# Generated at 2022-06-25 16:05:18.570271
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder


# Generated at 2022-06-25 16:05:24.288071
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test for case 0
    field_override_0 = FieldOverride()
    ext_encoder_0 = _ExtendedEncoder(field_override_0)
    assert _issubclass_safe(ext_encoder_0, json.JSONEncoder)
    assert is_dataclass(ext_encoder_0)


_EncoderInfo = namedtuple('_EncoderInfo', [
    'program', 'fields', 'default_fields', 'encoder_kwargs', 'omit_defaults'])



# Generated at 2022-06-25 16:05:24.918852
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:05:34.303387
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    tup = namedtuple('X', 'a, b')
    assert encoder.default(tup(1, 2)) == {'a': 1, 'b': 2}

    # We should be able to serialize a set
    set_0 = {'foo', 'bar'}
    assert encoder.default(set_0) == ['foo', 'bar']

    # We should be able to serialize a frozenset
    frozen_set_0 = frozenset({3, 1, 2})
    assert encoder.default(frozen_set_0) == [3, 1, 2]

    # We should be able to serialize a datetime object
    dt_0 = datetime(1985, 10, 26, 1, 21, tzinfo=timezone.utc)
   

# Generated at 2022-06-25 16:05:36.682294
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    decoder = _ExtendedEncoder(
        skipkeys=False,
        ensure_ascii=True,
        check_circular=True,
        allow_nan=True,
        sort_keys=False,
        indent=None,
        separators=None,
        default=None,
        )
    assert decoder is not None


# Generated at 2022-06-25 16:05:38.181388
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ext_enc = _ExtendedEncoder()


# Generated at 2022-06-25 16:05:40.040607
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    field_override_0 = FieldOverride()
    result = _ExtendedEncoder(**field_override_0._asdict())
    assert _isinstance_safe(result, _ExtendedEncoder)


# Generated at 2022-06-25 16:05:43.431324
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # test for case when arguments are absent
    enc = _ExtendedEncoder()

    # test for case when arguments are present but invalid
    enc = _ExtendedEncoder(None, None, None)



# Generated at 2022-06-25 16:05:45.023744
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    new_json_encoder = _ExtendedEncoder()
    assert(isinstance(new_json_encoder, json.JSONEncoder))



# Generated at 2022-06-25 16:05:58.822649
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()

    c1 = copy.copy(_ExtendedEncoder)
    assert c1.__repr__() == '<_ExtendedEncoder>'
    c2 = copy.deepcopy(_ExtendedEncoder)
    assert c2.__repr__() == '<_ExtendedEncoder>'


# Generated at 2022-06-25 16:06:21.116291
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    var = extended_encoder.default(extended_encoder)


# Generated at 2022-06-25 16:06:22.857060
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    pass



# Generated at 2022-06-25 16:06:25.924802
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    if extended_encoder_0.default(UUID(int=0)) != '00000000-0000-0000-0000-000000000000':
        print("TypeError")


# Generated at 2022-06-25 16:06:27.837467
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    var_1 = _ExtendedEncoder()
    var_2 = var_1.default([])


# Generated at 2022-06-25 16:06:39.024873
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_0 = _ExtendedEncoder(ensure_ascii=True)
    extended_encoder_0 = _ExtendedEncoder(ensure_ascii=True, skipkeys=True)
    extended_encoder_0 = _ExtendedEncoder(ensure_ascii=True, skipkeys=True,
                                          indent=True)
    extended_encoder_0 = _ExtendedEncoder(ensure_ascii=True, skipkeys=True,
                                          indent=True, sort_keys=True)

# Generated at 2022-06-25 16:06:43.423873
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)
    assert id(var_0) == id(extended_encoder_0)
    assert var_0 == extended_encoder_0


# Generated at 2022-06-25 16:06:46.604095
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()

    # source
    res = extended_encoder_0.default([])
    assert res == []

# Generated at 2022-06-25 16:07:00.199811
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default({
        1: 2,
        '3': 4,
        5: 6
    })
    assert var_0 == {
        1: 2,
        '3': 4,
        5: 6
    }
    var_1 = extended_encoder_0.default([
        1,
        2,
        3,
        4,
        5
    ])
    assert var_1 == [
        1,
        2,
        3,
        4,
        5
    ]
    var_2 = extended_encoder_0.default((
        1,
        2,
        3,
        4,
        5
    ))

# Generated at 2022-06-25 16:07:00.788978
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test = _ExtendedEncoder()
    assert test is not None


# Generated at 2022-06-25 16:07:03.598927
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_1 = _ExtendedEncoder()
    var_1 = extended_encoder_1.default(extended_encoder_1)
    assert var_1 is not None
    assert var_1 == extended_encoder_1


# Generated at 2022-06-25 16:07:42.387910
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()


# Generated at 2022-06-25 16:07:46.155635
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from dataclasses_json.utils import _ExtendedEncoder
    extended_encoder_0 = _ExtendedEncoder()
    is_false_0 = (str(extended_encoder_0) != '<_ExtendedEncoder object at 0x7f5ce92f5510>')
    assert is_false_0



# Generated at 2022-06-25 16:07:56.995580
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test constructor's type hints
    extended_encoder_0: _ExtendedEncoder = _ExtendedEncoder()
    # Test for external access to protected member _ExtendedEncoder._check_circular
    # noinspection PyProtectedMember
    extended_encoder_0._check_circular(extended_encoder_0)
    # Test for external access to protected member _ExtendedEncoder._default
    # noinspection PyProtectedMember
    extended_encoder_0._default(extended_encoder_0)
    # Test for external access to protected member _ExtendedEncoder._encode_dict
    # noinspection PyProtectedMember
    extended_encoder_0._encode_dict(extended_encoder_0)
    # Test for external access to protected member _ExtendedEncoder._iterencode
   

# Generated at 2022-06-25 16:07:58.268671
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:07:58.794786
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass


# Generated at 2022-06-25 16:08:01.682474
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)



# Generated at 2022-06-25 16:08:10.306750
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test the initial value of self.item_separator.
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0.item_separator == ','

    # Test the initial value of self.key_separator.
    extended_encoder_1 = _ExtendedEncoder()
    assert extended_encoder_1.key_separator == ':'

    # Test the initial value of self.skipkeys.
    extended_encoder_2 = _ExtendedEncoder()
    assert extended_encoder_2.skipkeys == False

    # Test the initial value of self.ensure_ascii.
    extended_encoder_3 = _ExtendedEncoder()
    assert extended_encoder_3.ensure_ascii == True

    # Test the initial value of self.check_circular

# Generated at 2022-06-25 16:08:10.839050
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass


# Generated at 2022-06-25 16:08:12.893925
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0._check_circular(extended_encoder_0)
    assert extended_encoder_0._check_circular(None)



# Generated at 2022-06-25 16:08:14.114740
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    var_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:10:03.808652
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    # check for new attribute
    if hasattr(extended_encoder_0, 'ignore_wrapped_extended'):
        try:
            assert extended_encoder_0.ignore_wrapped_extended == False
        except:
            print(u'\nFAILED ASSERTION <<<  extended_encoder_0.ignore_wrapped_extended == False  >>>')
            assert False
    else:
        print(u'\nGENERATED CLASS HAS NO ATTRIBUTE <<<  ignore_wrapped_extended  >>>')



# Generated at 2022-06-25 16:10:06.851382
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0 is not None



# Generated at 2022-06-25 16:10:11.835564
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_1 = copy.copy(extended_encoder_0)
    var_0 = extended_encoder_1.default(extended_encoder_1)


# Generated at 2022-06-25 16:10:15.639930
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, json.JSONEncoder)



# Generated at 2022-06-25 16:10:17.504866
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:10:18.454661
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:10:20.011587
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, json.JSONEncoder)



# Generated at 2022-06-25 16:10:21.484071
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:10:23.878371
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0.default(extended_encoder_0) == _ExtendedEncoder()



# Generated at 2022-06-25 16:10:24.902679
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _ExtendedEncoder()
