

# Generated at 2022-06-25 16:02:49.648107
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass


# Generated at 2022-06-25 16:02:58.554877
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    str_0 = 'vRf/\x8b$\x15<\x0e\x11\x8d\x11\xbe\x16'
    str_1 = '\r"\r\xfb7\x8d\xf0\xfd\x18\xed\xfeB'
    int_0 = 90

    extended_encoder_0 = _ExtendedEncoder(skipkeys=str_0, sort_keys=str_1,
                                          indent=int_0, separators='\x1a\x1d\x0c\x17\x18B\x90\x85\x1f')

# Generated at 2022-06-25 16:03:07.436654
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder
    assert extended_encoder.charset is "utf-8"
    assert extended_encoder.errors is "strict"
    assert extended_encoder.indent == 0
    assert extended_encoder.item_separator == ""
    assert extended_encoder.key_separator == ":"
    assert extended_encoder.sort_keys is False
    assert extended_encoder.skipkeys is False
    assert extended_encoder.use_decimal is False
    assert extended_encoder.namedtuple_as_object is True
    assert extended_encoder.tuple_as_array is True
    str_1 = '9e\\&H)V"RBcAZ}VB\r-t\x0c'
    extended_encoder2

# Generated at 2022-06-25 16:03:12.955303
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o_0: Any = {}
    str_0 = '9e\\&H)V"RBcAZ}VB\r-t\x0c'
    extended_encoder_0 = _ExtendedEncoder(skipkeys=str_0)
    try:
        extended_encoder_0.default(o_0)
    except ValueError as e:
        print(e)

# Generated at 2022-06-25 16:03:18.261250
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    str_1 = '9e\\&H)V"RBcAZ}VB\r-t\x0c'
    extended_encoder_1 = _ExtendedEncoder(skipkeys=str_1)


if __name__ == '__main__':
    test_case_0()
    test__ExtendedEncoder()

# Generated at 2022-06-25 16:03:25.809917
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _ExtendedEncoder._default(1, '9e\\&H)V"RBcAZ}VB\r-t\x0c')
    _ExtendedEncoder._default(1, '9e\\&H)V"RBcAZ}VB\r-t\x0c')
    _ExtendedEncoder._default(1, '9e\\&H)V"RBcAZ}VB\r-t\x0c')
    _ExtendedEncoder._default(1, '9e\\&H)V"RBcAZ}VB\r-t\x0c')
    _ExtendedEncoder._default(1, '9e\\&H)V"RBcAZ}VB\r-t\x0c')

# Generated at 2022-06-25 16:03:28.362004
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    str_1 = '9e\\&H)V"RBcAZ}VB\r-t\x0c'
    extended_encoder_1 = _ExtendedEncoder(skipkeys=str_1)



# Generated at 2022-06-25 16:03:31.982554
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    str_0 = '9e\\&H)V"RBcAZ}VB\r-t\x0c'
    extended_encoder_0 = _ExtendedEncoder(skipkeys=str_0)
    assert isinstance(extended_encoder_0, json.JSONEncoder)


# Generated at 2022-06-25 16:03:36.387323
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Getting the arguments of the call to the constructor
    dict_0 = dict()
    dict_0 = locals()
    str_0 = '9e\\&H)V"RBcAZ}VB\r-t\x0c'
    dict_0['skipkeys'] = str_0
    extended_encoder_0 = _ExtendedEncoder(**dict_0)


# Generated at 2022-06-25 16:03:38.367195
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    result_0 = _ExtendedEncoder().default(str_0)
    assert result_0 == str_0


# Generated at 2022-06-25 16:04:04.244259
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder(skipkeys=False)
    var_0 = extended_encoder_0.default(None)
    assert var_0 is None
    extended_encoder_1 = _ExtendedEncoder(skipkeys=False)
    var_1 = extended_encoder_1.default(1)
    assert var_1 == 1
    extended_encoder_2 = _ExtendedEncoder(skipkeys=False)
    var_2 = extended_encoder_2.default(1.1)
    assert var_2 == 1.1
    extended_encoder_3 = _ExtendedEncoder(skipkeys=False)
    var_3 = extended_encoder_3.default('str_0')
    assert var_3 == 'str_0'
    extended_encoder_4 = _

# Generated at 2022-06-25 16:04:07.441782
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    str_0 = None
    extended_encoder_0 = _ExtendedEncoder()
    # test case 0
    var_0 = extended_encoder_0.default(str_0)
    # test case 1
    var_0 = extended_encoder_0.default(str_0)



# Generated at 2022-06-25 16:04:10.015914
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    str_0 = None
    extended_encoder_0 = _ExtendedEncoder(skipkeys=str_0)
    print('\nUnit test for method _ExtendedEncoder()')
    assert extended_encoder_0 != None
    


# Generated at 2022-06-25 16:04:13.778060
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    str_0 = None
    extended_encoder_0 = _ExtendedEncoder(skipkeys=str_0)
    test_case_0()



# Generated at 2022-06-25 16:04:17.016402
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    str_0 = None
    extended_encoder_0 = _ExtendedEncoder(skipkeys=str_0)
    var_0 = extended_encoder_0.default(str_0)



# Generated at 2022-06-25 16:04:20.128225
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    str_0 = None
    extended_encoder_0 = _ExtendedEncoder(skipkeys=str_0)
    assert extended_encoder_0 is not None


# Generated at 2022-06-25 16:04:26.895704
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test for constructor with skipkeys missing
    try:
        _ExtendedEncoder(skipkeys=None)
    except TypeError:
        pass
    else:
        assert False, 'Expected TypeError'


# Generated at 2022-06-25 16:04:33.916846
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_0 = _ExtendedEncoder(skipkeys=True)
    var_1 = _ExtendedEncoder(skipkeys=0)
    var_2 = _ExtendedEncoder(skipkeys=None)
    var_3 = _ExtendedEncoder(skipkeys=False)
    var_4 = _ExtendedEncoder(skipkeys=1)



# Generated at 2022-06-25 16:04:38.380602
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    str_0 = None
    extended_encoder_0 = _ExtendedEncoder(skipkeys=str_0)
    assert extended_encoder_0.indent is None
    assert extended_encoder_0.sort_keys == False
    assert extended_encoder_0.skipkeys == True
    assert extended_encoder_0.item_sort_key == None
    assert extended_encoder_0.ensure_ascii == True
    assert extended_encoder_0.allow_nan == True
    assert extended_encoder_0.check_circular == True
    assert extended_encoder_0.allow_unicode == True
    assert extended_encoder_0.default == "<bound method _ExtendedEncoder.default of <__main__._ExtendedEncoder object at 0x0000000004F89A58>>"


# Generated at 2022-06-25 16:04:42.940049
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test that  '_ExtendedEncoder()' constructor works as expected.
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder) is True
    test_case_0()



# Generated at 2022-06-25 16:05:06.785427
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:05:13.147201
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # create instance for class _ExtendedEncoder
    extended_encoder = _ExtendedEncoder()
    # assert if instance created
    assert isinstance(extended_encoder, _ExtendedEncoder)
    assert isinstance(extended_encoder, json.JSONEncoder)
    assert _isinstance_safe(extended_encoder, tuple)
    assert _isinstance_safe(extended_encoder, dict)



# Generated at 2022-06-25 16:05:18.016505
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default("1")
    assert (var_0 == "1")
    var_1 = extended_encoder_0.default("1")
    assert (var_1 == "1")
    var_2 = extended_encoder_0.default(["1"])
    assert (var_2 == ["1"])



# Generated at 2022-06-25 16:05:22.713751
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Test 0
    # Unconditional branch coverage
    # Below is the coverage data generated by BullseyeCoverage
    # File: _ExtendedEncoder.py
    # Lines executed:100.00% of 14
    # Branches executed:100.00% of 12
    # Taken at least once:100.00% of 12
    # Calls executed:100.00% of 7
    test_case_0()


# Generated at 2022-06-25 16:05:31.738887
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        from datetime import datetime
        from uuid import UUID, uuid4
        from enum import Enum
        from decimal import Decimal
        var_0 = datetime.now()
        var_1 = UUID(uuid4())
        var_2 = Decimal("0.2")
        test_case_0()
        test_case_1()

    except Exception as e:
        print("ERROR: test__ExtendedEncoder raised an exception: " + str(e))



# Generated at 2022-06-25 16:05:36.459075
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ff_0 = _ExtendedEncoder(indent=4, separators=('-', '|'), sort_keys=True)
    holder_0 = ff_0.default(ff_0)
    holder_1 = json.JSONEncoder.default(ff_0, ff_0)


# Generated at 2022-06-25 16:05:38.636795
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    var_0 = _ExtendedEncoder.default(_ExtendedEncoder(), [1, 'a', {'a': 1.0}])


# Generated at 2022-06-25 16:05:40.325369
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # pytest.skip()
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0 is not None



# Generated at 2022-06-25 16:05:41.904429
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_0 = _ExtendedEncoder()
    assert var_0.encode(var_0) == '{}'


# Generated at 2022-06-25 16:05:42.737283
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass


# Generated at 2022-06-25 16:06:17.879389
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.check_circular
    assert encoder.ensure_ascii
    assert encoder.indent is None
    assert encoder.key_separator == ':'
    assert encoder.namedtuple_as_object is False
    assert encoder.sort_keys is False
    assert encoder.skipkeys is False
    assert encoder.item_separator == ','
    assert encoder.allow_nan is True
    assert encoder.encoding == 'utf-8'
    assert encoder.default is None
    assert encoder.decimal_context is None



# Generated at 2022-06-25 16:06:19.200950
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()


# Generated at 2022-06-25 16:06:22.896192
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Instantiation with no argument
    extended_encoder_1 = _ExtendedEncoder()
    extended_encoder_1.default(extended_encoder_1)



# Generated at 2022-06-25 16:06:24.385850
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:06:27.110335
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Arrange
    extended_encoder_0 = _ExtendedEncoder()

    # Act
    var_0 = extended_encoder_0.default(extended_encoder_0)

    # Assert
    assert var_0 is not None



# Generated at 2022-06-25 16:06:28.013555
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:06:29.373729
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    test_case_0()



# Generated at 2022-06-25 16:06:31.310377
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert True


_T = TypeVar('_T')



# Generated at 2022-06-25 16:06:34.045558
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_1 = _ExtendedEncoder()
    assert extended_encoder_0.default(extended_encoder_1) == None



# Generated at 2022-06-25 16:06:35.797953
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()


# Generated at 2022-06-25 16:07:23.593617
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert issubclass(_ExtendedEncoder, json.JSONEncoder)



# Generated at 2022-06-25 16:07:31.351311
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Method parameters
    # Parameter types
    # Return type
    # if condition
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)
    # if condition
    extended_encoder_1 = _ExtendedEncoder()
    var_1 = extended_encoder_1.default(extended_encoder_1)
    # if condition
    extended_encoder_2 = _ExtendedEncoder()
    var_2 = extended_encoder_2.default(extended_encoder_2)
    # if condition
    extended_encoder_3 = _ExtendedEncoder()
    var_3 = extended_encoder_3.default(extended_encoder_3)
    # if condition
    extended_encoder_

# Generated at 2022-06-25 16:07:37.858723
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0.skipkeys == False
    assert extended_encoder_0.ensure_ascii == True
    assert extended_encoder_0.check_circular == True
    assert extended_encoder_0.allow_nan == True
    assert extended_encoder_0.indent == None
    assert extended_encoder_0.separators == (',', ':')
    assert extended_encoder_0.default == extended_encoder_0.default
    test_case_0()


# Generated at 2022-06-25 16:07:42.744030
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)

    # test _ExtendedEncoder.__init__()
    assert var_0 is not None


# Generated at 2022-06-25 16:07:45.258397
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()
    obj = object()
    assert  extended_encoder.default(obj) == json.JSONEncoder.default(extended_encoder, obj)


# Generated at 2022-06-25 16:07:56.937672
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_0 = _ExtendedEncoder()
    assert var_0 is not None
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_1 = _ExtendedEncoder()
    assert extended_encoder_0 is not extended_encoder_1
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0.default(extended_encoder_0) == {'__class__': '_ExtendedEncoder',
                                                              'kwargs': {},
                                                              'version': 3}
    extended_encoder_0 = _ExtendedEncoder()

# Generated at 2022-06-25 16:07:58.421205
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:08:01.968150
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert _isinstance_safe(extended_encoder_0, json.JSONEncoder)
    assert _issubclass_safe(json.JSONEncoder, json.JSONEncoder)

# Generated at 2022-06-25 16:08:04.001040
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)



# Generated at 2022-06-25 16:08:11.701952
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder(skipkeys=True)
    assert extended_encoder_1.check_circular is False # type: ignore
    assert extended_encoder_1.ensure_ascii is True # type: ignore
    assert extended_encoder_1.indent is None # type: ignore
    assert extended_encoder_1.key_separator is ':' # type: ignore
    assert extended_encoder_1.object_hook is None # type: ignore
    assert extended_encoder_1.sort_keys is False # type: ignore
    assert extended_encoder_1.skipkeys is True # type: ignore
    assert extended_encoder_1.allow_nan is True # type: ignore
    assert extended_encoder_1.encoding == 'utf-8' # type: ignore
   

# Generated at 2022-06-25 16:10:23.732620
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:10:34.623116
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert_equal(_ExtendedEncoder.__init__.__qualname__, '_ExtendedEncoder.__init__')
    assert_equal(_ExtendedEncoder.__init__.__qualname__, '_ExtendedEncoder.__init__')
    assert_equal(_ExtendedEncoder.__init__.__qualname__, '_ExtendedEncoder.__init__')
    assert_equal(_ExtendedEncoder.__init__.__qualname__, '_ExtendedEncoder.__init__')
    assert_equal(_ExtendedEncoder.__init__.__qualname__, '_ExtendedEncoder.__init__')
    assert_equal(_ExtendedEncoder.__init__.__qualname__, '_ExtendedEncoder.__init__')

# Generated at 2022-06-25 16:10:39.677891
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)



# Generated at 2022-06-25 16:10:43.288341
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    # extended encoder0 type is not json.JSONEncoder
    assert extended_encoder_0 != json.JSONEncoder
    assert not isinstance(extended_encoder_0, json.JSONEncoder)


# Generated at 2022-06-25 16:10:45.517108
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    test_case_0()

_DISABLE = object()



# Generated at 2022-06-25 16:10:48.138458
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_1 = _ExtendedEncoder()
    var_1 = extended_encoder_1.default(extended_encoder_1)


# Generated at 2022-06-25 16:10:49.766288
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)


# Generated at 2022-06-25 16:10:55.565012
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        extended_encoder_0 = _ExtendedEncoder()
    except NameError:
        expected = TypeError
        actual = NameError

    else:
        expected = _ExtendedEncoder
        actual = type(extended_encoder_0)

    assert expected == actual


_DefaultLetterCase = namedtuple('_DefaultLetterCase', ['camel_case', 'snake_case'])



# Generated at 2022-06-25 16:11:01.000706
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test raise exception
    # Test normal case
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:11:07.330562
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = str(extended_encoder_0)
    assert (var_0 == '<dataclasses_json.utils._ExtendedEncoder object at 0x0x0x0x0x0>')
    var_1 = repr(extended_encoder_0)
    assert (var_1 == '<dataclasses_json.utils._ExtendedEncoder object at 0x0x0x0x0x0>')
    var_2 = json.dumps(extended_encoder_0)
    assert (var_2 == '{}')
