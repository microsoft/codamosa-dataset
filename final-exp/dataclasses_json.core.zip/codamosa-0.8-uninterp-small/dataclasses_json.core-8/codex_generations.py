

# Generated at 2022-06-25 16:02:44.623590
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    #  Trying to instantiate an instance of this class
    #  should raise an exception
    with pytest.raises(RuntimeError):
        _ExtendedEncoder()



# Generated at 2022-06-25 16:02:46.143191
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    c = _ExtendedEncoder()
    assert c is None



# Generated at 2022-06-25 16:02:48.392062
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:02:50.090938
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert isinstance(encoder, _ExtendedEncoder)


# Generated at 2022-06-25 16:02:57.551530
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder(skipkeys=False, ensure_ascii=True, check_circular=True,
                               allow_nan=True, sort_keys=False, indent=None, separators=None,
                               default=None)
    assert encoder.skipkeys == False
    assert encoder.ensure_ascii == True
    assert encoder.check_circular == True
    assert encoder.allow_nan == True
    assert encoder.sort_keys == False
    assert encoder.indent == None
    assert encoder.separators == None
    assert encoder.default == None


# Generated at 2022-06-25 16:03:00.664374
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    field_override_0 = FieldOverride()
    assert isinstance(_ExtendedEncoder(field_override_0), json.JSONEncoder)
    return None



# Generated at 2022-06-25 16:03:01.768165
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:03:03.556800
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder.__init__ is not None

    _ExtendedEncoder()


# Generated at 2022-06-25 16:03:05.199335
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        _ExtendedEncoder()
    except TypeError:
        print("Failed")
        return



# Generated at 2022-06-25 16:03:06.326762
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:03:35.663945
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    input = [1, "test"]
    encoders = [_ExtendedEncoder(), json.JSONEncoder()]

    for encoder in encoders:
        output = encoder.default(input)
        assert(type(output) == list)
        assert(output == input)

    input = { "field1": 1, "field2": "test" }
    for encoder in encoders:
        output = encoder.default(input)
        assert(type(output) == dict)
        assert(output == input)

    input = datetime.now().astimezone(timezone.utc).replace(microsecond=0)
    for encoder in encoders:
        output = encoder.default(input)
        assert(type(output) == float)


# Generated at 2022-06-25 16:03:43.012263
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder._ExtendedEncoder__default('a') == 'a'
    assert encoder._ExtendedEncoder__default(1) == 1
    assert encoder._ExtendedEncoder__default(1.0) == 1.0
    assert encoder._ExtendedEncoder__default(True) == True
    assert encoder._ExtendedEncoder__default(None) == None
    assert encoder._ExtendedEncoder__default([1, 2, 3]) == [1, 2, 3]
    assert encoder._ExtendedEncoder__default({'a': [1,2,3]}) == {'a': [1,2,3]}
    assert encoder._ExtendedEncoder__default(datetime.now()) == 1597455891.731284
    assert encoder._Ext

# Generated at 2022-06-25 16:03:43.802880
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert callable(_ExtendedEncoder)



# Generated at 2022-06-25 16:03:44.644455
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert True, 'Test not implemented'



# Generated at 2022-06-25 16:03:45.813877
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:03:56.318183
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert_json = Json
    encoder = _ExtendedEncoder()
    assert encoder.default(list()) == assert_json
    assert encoder.default(dict()) == assert_json
    assert encoder.default(str()) == assert_json
    assert encoder.default(int()) == assert_json
    assert encoder.default(float()) == assert_json
    assert encoder.default(bool()) == assert_json
    assert encoder.default(None) == assert_json
    assert encoder.default(set()) == assert_json
    assert encoder.default(object) == assert_json
    assert encoder.default(tuple()) == assert_json
    assert encoder.default(datetime.now()) == assert_json

# Generated at 2022-06-25 16:04:02.844114
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # _ExtendedEncoder object
    _ExtendedEncoder_obj = _ExtendedEncoder()
    assert _ExtendedEncoder_obj.encode('string') == '"string"'
    assert _ExtendedEncoder_obj.encode(1) == '1'
    assert _ExtendedEncoder_obj.encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder_obj.encode(1.1) == '1.1'
    assert _ExtendedEncoder_obj.encode(True) == 'true'
    assert _ExtendedEncoder_obj.encode(None) == 'null'
    assert _ExtendedEncoder_obj.encode(datetime.now(tz=timezone.utc)) == '1555166708.644136'
    assert _Ext

# Generated at 2022-06-25 16:04:10.122528
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings(record=True) as w:
        assert issubclass(w[-1].category, DeprecationWarning)
        assert "the json module is deprecated"
        _extendedencoder = _ExtendedEncoder()
        assert not _extendedencoder.namedtuple_as_object

## Unit Test for method default
# The default method is the one that is called by json.dump when the
# parameter `o` is not a primitive data type: list, tuple, set, dict,
# str, int, float, bool.
# For testing, we will create a namedtuple instance and a class instance.


# Generated at 2022-06-25 16:04:11.954340
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    M = _ExtendedEncoder()



# Generated at 2022-06-25 16:04:15.035251
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    field_override_0 = FieldOverride()
    assert isinstance(_ExtendedEncoder(), json.JSONEncoder)



# Generated at 2022-06-25 16:04:36.776691
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    dict_0 = None
    str_0 = '7/>\r,'
    extended_encoder_0 = _ExtendedEncoder(allow_nan=str_0, indent=str_0)


# Generated at 2022-06-25 16:04:41.435703
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    if __name__ == '__main__':
        extended_encoder_0 = _ExtendedEncoder()
        str_0 = extended_encoder_0.iterencode()


# Generated at 2022-06-25 16:04:45.674931
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    dict_0 = None
    str_0 = '7/>\r,'
    extended_encoder_0 = _ExtendedEncoder(allow_nan=str_0, indent=str_0)
    var_0 = extended_encoder_0.default(dict_0)
    tuple_0 = ()


# Generated at 2022-06-25 16:04:48.666340
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    dict_0 = None
    str_0 = '7/>\r,'
    extended_encoder_0 = _ExtendedEncoder(allow_nan=str_0, indent=str_0)
    assert True


# Generated at 2022-06-25 16:04:54.871992
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    dict_0 = None
    str_0 = '7/>\r,'
    extended_encoder_0 = _ExtendedEncoder(allow_nan=str_0, indent=str_0)
    var_0 = extended_encoder_0.default(dict_0)
    tuple_0 = ()


# Generated at 2022-06-25 16:05:03.135057
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # User input data
    o = None
    # Expected output data
    expected_result = None

    # Perform the method call
    extended_encoder_0 = _ExtendedEncoder(allow_nan="a", indent="a")
    result = extended_encoder_0.default(o)

    # Check the result
    assert result == expected_result



LETTERS = "abcefghijklmnopqrstuvwxyz"
if cfg.use_snake_case:
    LETTERS += "ABCDEFGHIJKLMNOPQRSTUVWXYZ"



# Generated at 2022-06-25 16:05:14.164173
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    dict_0 = None
    dict_1 = {}
    dict_2 = {'list_1': 'sleuqizlzv', 'list_2': 'gxdlakbxdf', 'list_3': 'hzrkrc'}
    str_0 = '5;=&?;$!%'
    extended_encoder_0 = _ExtendedEncoder(allow_nan=str_0, indent=str_0)
    var_0 = extended_encoder_0.default(dict_0)
    var_1 = extended_encoder_0.default(dict_1)
    var_2 = extended_encoder_0.default(dict_2)
    tuple_0 = (var_0, var_1, var_2)


# Generated at 2022-06-25 16:05:20.929156
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    str_0 = '\x1f'
    var_0 = _ExtendedEncoder(allow_nan=str_0, indent=str_0)
    var_0 = _ExtendedEncoder(indent=str_0)


# Generated at 2022-06-25 16:05:25.515809
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    dict_0 = None
    str_0 = '7/>\r,'
    extended_encoder_0 = _ExtendedEncoder(allow_nan=str_0, indent=str_0)
    var_0 = json.JSONEncoder.default(extended_encoder_0, dict_0)
    tuple_0 = ()



# Generated at 2022-06-25 16:05:30.886773
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    dict_0 = None
    str_0 = ';D>Mb'
    extended_encoder_0 = _ExtendedEncoder(allow_nan=str_0, indent=str_0)
    int_0 = extended_encoder_0.encode(dict_0)
    var_0 = extended_encoder_0.default(str_0)



# Generated at 2022-06-25 16:05:56.206363
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    str_0 = '*@!bx?_'
    extended_encoder_0 = _ExtendedEncoder(allow_nan=str_0, indent=str_0)
    str_1 = 'm+l:zv?a'
    extended_encoder_0.default(str_1)


# Generated at 2022-06-25 16:06:01.781564
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test for constructor of class _ExtendedEncoder
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)
    assert var_0 == str(extended_encoder_0)

    extended_encoder_0 = _ExtendedEncoder(sort_keys=False)
    var_0 = extended_encoder_0.default(extended_encoder_0)
    assert var_0 == str(extended_encoder_0)


# Generated at 2022-06-25 16:06:03.794949
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder(allow_nan=True, indent=True).default(1) == 1



# Generated at 2022-06-25 16:06:06.419860
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder(allow_nan='>=\x0b', indent='*#')


# Generated at 2022-06-25 16:06:18.544081
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = [1.2, 3.4, 5.6]
    if _isinstance_safe(o, Mapping):
        result = dict(o)
    else:
        result = list(o)
    if result != {1.2, 3.4, 5.6}:
        raise Exception('assertion error!')
    o = {1.2: 3.4, 5.6: 7.8}
    if _isinstance_safe(o, Mapping):
        result = dict(o)
    else:
        result = list(o)
    if result != {1.2: 3.4, 5.6: 7.8}:
        raise Exception('assertion error!')
    o = 1.2

# Generated at 2022-06-25 16:06:28.240928
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    str_0 = '|'
    int_0 = 30
    extended_encoder_0 = _ExtendedEncoder(allow_nan=str_0, skipkeys=True)
    extended_encoder_1 = _ExtendedEncoder(allow_nan=str_0, skipkeys=True)
    extended_encoder_2 = _ExtendedEncoder(allow_nan=str_0, skipkeys=True)
    extended_encoder_3 = _ExtendedEncoder(allow_nan=str_0, skipkeys=True)
    var_0 = extended_encoder_3.default(extended_encoder_3)
    str_1 = 'default'
    str_2 = 'default'
    str_3 = 'default'
    int_1 = -75
    extended_encoder_4 = _ExtendedEncoder

# Generated at 2022-06-25 16:06:31.794944
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    str_0 = '7/>\r,'
    extended_encoder_0 = _ExtendedEncoder(allow_nan=str_0, indent=str_0)
    assert extended_encoder_0 is not None


# Generated at 2022-06-25 16:06:43.212456
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():

    str_0 = '7/>\r,'
    extended_encoder_0 = _ExtendedEncoder(allow_nan=str_0, indent=str_0)
    var_0 = extended_encoder_0.default(extended_encoder_0)
    assert var_0 == 'Infinity' or var_0 == '-Infinity' or var_0 == 'NaN' or var_0 == '"\\u007f>\\r\\u002c"'

    str_0 = '7/>\r,'
    extended_encoder_0 = _ExtendedEncoder(allow_nan=str_0, indent=str_0)
    var_0 = extended_encoder_0.default(extended_encoder_0)
    assert var_0 == 'Infinity' or var_0 == '-Infinity' or var

# Generated at 2022-06-25 16:06:54.132209
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    str_0 = 'F\xa9\x1b\x1b\x1b'
    int_0 = 8
    with pytest.raises(KeyError, match=''):
        extended_encoder_0 = _ExtendedEncoder(skipkeys=str_0, indent=int_0)
        var_0 = extended_encoder_0.default(extended_encoder_0)
    with pytest.raises(KeyError, match=''):
        str_1 = ')\xcb;\xd6'
        extended_encoder_1 = _ExtendedEncoder(skipkeys=str_1, indent=str_1)
        extended_encoder_1.default(extended_encoder_1)

# Generated at 2022-06-25 16:06:58.039611
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    str_0 = '&QC,%c'
    extended_encoder_0 = _ExtendedEncoder(allow_nan=str_0, indent=str_0)
    var_0 = extended_encoder_0.default(extended_encoder_0)
    var_1 = ()


# Generated at 2022-06-25 16:07:30.345114
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test simple case
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    var_0 = extended_encoder_0.default(bool_0)
    assert var_0 == bool_0

    # Test simple case
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    extended_encoder_0._current_indent_level = 1
    list_0 = [1, 2, 3]
    var_0 = extended_encoder_0.iterencode(list_0)
    assert var_0 == ['[\n', '1,\n', '2,\n', '3\n', ']']

    # Test

# Generated at 2022-06-25 16:07:32.924822
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test case 0
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    extended_encoder_0.default(bool_0)


# Generated at 2022-06-25 16:07:34.739219
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_0 = True
    bool_1 = True
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)


# Generated at 2022-06-25 16:07:37.818466
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    bool_0 = cfg.key_transform
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    var_0 = extended_encoder_0.default(bool_0)



# Generated at 2022-06-25 16:07:40.863356
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    assert extended_encoder_0 is not None


# Generated at 2022-06-25 16:07:49.173318
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    var_0 = extended_encoder_0.default(int_0)


# Generated at 2022-06-25 16:07:55.084651
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    extended_encoder_1 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    assert extended_encoder_0 == extended_encoder_1
    assert extended_encoder_0 is not None
    assert extended_encoder_1 is not None



# Generated at 2022-06-25 16:08:04.075344
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0)
    extended_encoder_0 = _ExtendedEncoder(indent=bool_0)
    extended_encoder_0 = _ExtendedEncoder(sort_keys=bool_0)
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, sort_keys=bool_0)
    extended_encoder_0 = _ExtendedEncoder(indent=bool_0, sort_keys=bool_0)

# Generated at 2022-06-25 16:08:05.133658
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass


# Generated at 2022-06-25 16:08:08.363304
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    var_0 = extended_encoder_0.default(bool_0)


# Generated at 2022-06-25 16:09:17.370194
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    assert isinstance(extended_encoder_0, _ExtendedEncoder)



# Generated at 2022-06-25 16:09:23.861436
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    assert not (1 is not extended_encoder_0)
    int_0 = 0
    float_0 = 0.0
    json_0 = extended_encoder_0.default(int_0)
    assert not (1 is not json_0)
    json_1 = extended_encoder_0.default(float_0)
    assert not (1 is not json_1)
    json_2 = extended_encoder_0.default(bool_0)
    assert not (1 is not json_2)


# Generated at 2022-06-25 16:09:29.977632
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_0 = True
    bool_1 = False
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    assert isinstance(extended_encoder_0, _ExtendedEncoder)
    assert isinstance(extended_encoder_0._skipkeys, bool)
    assert isinstance(extended_encoder_0.allow_nan, bool)
    assert isinstance(extended_encoder_0.check_circular, bool)
    assert isinstance(extended_encoder_0.indent, bool)
    assert isinstance(extended_encoder_0.sort_keys, bool)
    assert isinstance(extended_encoder_0.ensure_ascii, bool)

# Generated at 2022-06-25 16:09:31.153437
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()

# Generated at 2022-06-25 16:09:32.813529
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    test_case_0()


# Generated at 2022-06-25 16:09:35.925493
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_0 = False
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)



# Generated at 2022-06-25 16:09:38.837203
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():

    obj = _ExtendedEncoder()
    assert isinstance(obj, _ExtendedEncoder)



# Generated at 2022-06-25 16:09:39.940429
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # case0 for type(arg) -> bool
    test_case_0()



# Generated at 2022-06-25 16:09:43.222869
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_0 = False
    extended_encoder_0 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)
    str_1 = extended_encoder_0.default(bool_0)
    # check type
    assert isinstance(str_1, str)



# Generated at 2022-06-25 16:09:46.953373
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bool_0 = True
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_1 = _ExtendedEncoder(allow_nan=bool_0)
    extended_encoder_2 = _ExtendedEncoder(allow_nan=bool_0, indent=bool_0)


# Generated at 2022-06-25 16:12:11.891203
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert isinstance(extended_encoder, json.JSONEncoder)


if is_mypy:
    # noinspection PyProtectedMember
    _is_new_type_leaf = lambda cls: _is_new_type(cls) and issubclass(cls, _GenericAlias)
    # noinspection PyProtectedMember
    _is_union_type_leaf = lambda cls: is_union_type(cls) and issubclass(cls, _GenericAlias)
else:
    # noinspection PyProtectedMember
    _is_new_type_leaf = lambda cls: _is_new_type(cls) and _issubclass_safe(cls, _GenericAlias)
    # noinspection PyProtectedMember
    _is_

# Generated at 2022-06-25 16:12:19.519741
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    field_0_0 = extended_encoder_0.ensure_ascii
    field_0_1 = extended_encoder_0.indent
    field_0_2 = extended_encoder_0.key_separator
    field_0_3 = extended_encoder_0.item_separator
    field_0_4 = extended_encoder_0.sort_keys
    field_0_5 = extended_encoder_0.skipkeys
    field_0_6 = extended_encoder_0.allow_nan
    field_0_7 = extended_encoder_0.default
