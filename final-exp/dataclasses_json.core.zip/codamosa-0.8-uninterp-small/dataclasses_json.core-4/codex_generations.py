

# Generated at 2022-06-25 16:02:48.662195
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:02:57.833492
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    field_override_0 = FieldOverride(cfg.Encoder(indent=4, sort_keys=True), cfg.Decoder(), cfg.MmField(process_list=True), cfg.LetterCase('camel'), cfg.Exclude())
    field_override_1 = FieldOverride(encoder=cfg.Encoder(indent=4, sort_keys=True), decoder=cfg.Decoder(), mm_field=cfg.MmField(process_list=True), letter_case=cfg.LetterCase('camel'), exclude=cfg.Exclude())

# Generated at 2022-06-25 16:03:07.109040
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(collection.Counter('abracadabra')) == dict(Counter({'a': 5, 'b': 2, 'r': 2, 'c': 1, 'd': 1}))
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == 1570190348.373798
    assert _ExtendedEncoder().default(UUID('84f0d0f1-c541-4d38-9b4d-9fcdaa9e7f2b')) == '84f0d0f1-c541-4d38-9b4d-9fcdaa9e7f2b'
    assert _ExtendedEncoder().default(Enum('a')) == 'a'

# Generated at 2022-06-25 16:03:18.347511
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder0 = _ExtendedEncoder()
    assert encoder0._ExtendedEncoder_first_iter == True
    assert encoder0.indent == None
    assert encoder0.key_separator == ':'
    assert encoder0.item_separator == ','
    assert encoder0.sort_keys == False
    assert encoder0.skipkeys == False
    assert encoder0.ensure_ascii == True
    assert encoder0.check_circular == True
    assert encoder0.allow_nan == True
    assert encoder0.cls == None
    assert encoder0.encoding == 'utf-8'
    assert encoder0.default == None
    assert encoder0.namedtuple_as_object == True
    assert encoder0.tuple_as_array == True
   

# Generated at 2022-06-25 16:03:19.543459
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:03:22.517611
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # positive test
    try:
        _ExtendedEncoder()
    except:
        raise AssertionError()
    # negative test
    try:
        _ExtendedEncoder(None)
    except:
        raise AssertionError()


# Generated at 2022-06-25 16:03:25.556012
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert hasattr(_ExtendedEncoder, 'default')



# Generated at 2022-06-25 16:03:28.290935
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    instance = _ExtendedEncoder()
    assert isinstance(instance, _ExtendedEncoder)



# Generated at 2022-06-25 16:03:29.249868
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:03:37.797703
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Fixture
    from datetime import timezone
    from datetime import datetime
    from uuid import UUID
    from decimal import Decimal

    dec = Decimal('10.1')
    dt = datetime.now(timezone.utc)
    uuid = UUID('{12345678-1234-5678-1234-567812345678}')
    data = {'uuid': uuid, 'datetime': dt, 'decimal': dec}

    # Test
    enc = _ExtendedEncoder()

    # Verification
    result = enc.default(data)
    assert result == {'uuid': str(uuid),
                      'datetime': dt.timestamp(),
                      'decimal': str(dec)
                      }


# Generated at 2022-06-25 16:04:02.977780
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    field_override_0 = FieldOverride()
    assert isinstance(_ExtendedEncoder(), json.JSONEncoder)



# Generated at 2022-06-25 16:04:04.244903
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # _ExtendedEncoder()
    _ExtendedEncoder()



# Generated at 2022-06-25 16:04:05.020223
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:04:06.531017
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    argument = False
    instance = _ExtendedEncoder(argument)
    assert instance



# Generated at 2022-06-25 16:04:07.442572
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()

# Generated at 2022-06-25 16:04:08.326497
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:04:11.980567
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Instantiate an instance of _ExtendedEncoder
    inst_0 = _ExtendedEncoder()
    # Call default on _ExtendedEncoder instance
    result_0 = inst_0.default(None)



# Generated at 2022-06-25 16:04:12.891270
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass



# Generated at 2022-06-25 16:04:22.044665
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    field_override_0 = FieldOverride()
    encoder_0 = json.JSONEncoder()
    encoder_0.default = _ExtendedEncoder(encoder_0).default
    encoder_0.default({'a': 1, 'c': 3, 'b': 2})
    encoder_0.default([1, 2, 3])
    encoder_0.default(datetime(year=2020, month=6, day=1, hour=9, minute=0, second=0, tzinfo=timezone.utc))
    encoder_0.default(UUID(int=0))
    encoder_0.default(Enum('Foo', 'foo'))
    encoder_0.default(Decimal('0'))
    encoder_0.default(0.0)
    encoder_0

# Generated at 2022-06-25 16:04:31.286431
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert issubclass(_ExtendedEncoder, json.JSONEncoder)
    assert isinstance(_ExtendedEncoder, type)
    assert issubclass(_ExtendedEncoder, type)
    assert _isinstance_safe(_ExtendedEncoder, _ExtendedEncoder)
    assert issubclass(_ExtendedEncoder, Mapping)
    assert issubclass(type, Mapping)
    assert not issubclass(Mapping, _ExtendedEncoder)
    assert issubclass(_ExtendedEncoder, Iterable)
    assert issubclass(_ExtendedEncoder, Sized)
    assert issubclass(type, Sized)
    assert not issubclass(Sized, _ExtendedEncoder)
    assert issubclass(type, Iterable)
    assert issubclass(_ExtendedEncoder, Container)
    assert _isinstance

# Generated at 2022-06-25 16:04:56.072203
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:04:58.890067
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:05:02.978438
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        _ExtendedEncoder()
        # Verify some things
        assert len(w) == 0



# Generated at 2022-06-25 16:05:06.785389
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:05:10.703534
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    # Type assertion error
    with pytest.raises(AssertionError):
        assert type(extended_encoder_0.default(1)) is complex


# Generated at 2022-06-25 16:05:12.063733
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:05:16.301528
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    var = extended_encoder.default(extended_encoder)
    assert str(type(var)) == "<class 'json.encoder.JSONEncoder'>"



# Generated at 2022-06-25 16:05:18.036949
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_0.default(datetime.utcnow())


# Generated at 2022-06-25 16:05:20.142395
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.encode(None) == 'null'



# Generated at 2022-06-25 16:05:22.926990
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()


# Generated at 2022-06-25 16:05:46.423435
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder_0 = _ExtendedEncoder()
    var_0 = encoder_0.default(encoder_0)

# Generated at 2022-06-25 16:05:51.870590
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)
    extended_encoder_1 = _ExtendedEncoder()
    extended_encoder_1.default(extended_encoder_1)
    extended_encoder_2 = _ExtendedEncoder()
    var_1 = extended_encoder_2.default(extended_encoder_2)


# Generated at 2022-06-25 16:05:54.064517
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    var = extended_encoder.default(extended_encoder)



# Generated at 2022-06-25 16:05:55.211870
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:06:03.073536
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Test that maps are converted to dicts
    var_0 = _ExtendedEncoder().default({"hello": "world"})
    # Test that sequences are converted to lists
    var_1 = _ExtendedEncoder().default(["hello", "world"])
    # Test that Sets are converted to list
    var_2 = _ExtendedEncoder().default(set(["hello", "world"]))
    # Test that datetimes are converted to UNIX timestamps
    var_3 = _ExtendedEncoder().default(datetime.now().replace(tzinfo=timezone.utc))
    # Test that UUID are converted to string
    var_4 = _ExtendedEncoder().default(UUID('11111111-1111-1111-1111-111111111111'))
    # Test that Enums are converted to their values
    var_5

# Generated at 2022-06-25 16:06:05.712022
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()
    assert isinstance(extended_encoder_1, json.JSONEncoder)



# Generated at 2022-06-25 16:06:08.642026
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # arrange
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)



# Generated at 2022-06-25 16:06:19.856680
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0.default([]) == []
    assert extended_encoder_0.default(None) is None
    assert extended_encoder_0.default(True)
    assert extended_encoder_0.default(False) is False
    assert extended_encoder_0.default(1) == 1
    assert extended_encoder_0.default(0.1) == 0.1
    assert extended_encoder_0.default("") == ""
    assert extended_encoder_0.default({}) == {}
    assert extended_encoder_0.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert extended_encoder_

# Generated at 2022-06-25 16:06:22.975343
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0._current_indent_level == 0


# Generated at 2022-06-25 16:06:25.110869
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Base case with parameters
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0



# Generated at 2022-06-25 16:07:16.088849
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)



# Generated at 2022-06-25 16:07:16.745155
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    test_case_0()

# Generated at 2022-06-25 16:07:18.898053
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:07:23.011122
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()


# Generated at 2022-06-25 16:07:24.837313
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:07:31.614329
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder
    assert _ExtendedEncoder.__module__ == 'dataclasses_json.encoder'
    assert _ExtendedEncoder.__qualname__ == '_ExtendedEncoder'
    assert _ExtendedEncoder.__name__ == '_ExtendedEncoder'
    assert _ExtendedEncoder.__doc__ is None

    assert _ExtendedEncoder.default

# Generated at 2022-06-25 16:07:33.042919
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)



# Generated at 2022-06-25 16:07:34.166970
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_1 = _ExtendedEncoder()
    assert isinstance(var_1, _ExtendedEncoder)



# Generated at 2022-06-25 16:07:37.295392
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from dataclasses_json.utils import (get_type_hints,
                                    _is_collection, _is_mapping, _is_new_type,
                                    _is_optional,
                                    _issubclass_safe)
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)



# Generated at 2022-06-25 16:07:39.559087
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()
    var_1 = extended_encoder_1.default(extended_encoder_1)


# Generated at 2022-06-25 16:09:45.137301
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    kwargs_0: dict = {}
    extended_encoder_0 = _ExtendedEncoder()
    var_1 = isinstance(extended_encoder_0, json.JSONEncoder)



# Generated at 2022-06-25 16:09:46.351057
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():  # noqa: F811
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = default(extended_encoder_0, extended_encoder_0)



# Generated at 2022-06-25 16:09:47.704827
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:09:53.151285
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Test case configuration
    extended_encoder_0 = _ExtendedEncoder()
    # Test
    variable_0 = extended_encoder_0.default(extended_encoder_0)
    # Validate
    assert isinstance(variable_0, str)
    # Test case configuration
    extended_encoder_1 = _ExtendedEncoder()
    # Test
    variable_1 = extended_encoder_1.default(extended_encoder_1)
    # Validate
    assert isinstance(variable_1, str)



# Generated at 2022-06-25 16:10:03.075153
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    try:
        extended_encoder_0.default(extended_encoder_0)
        extended_encoder_0.default(extended_encoder_0)
    except TypeError as exc_0:
        print(exc_0.__class__.__name__, ": ", exc_0)
        print(repr(traceback.format_tb(exc_0.__traceback__)))
    except AttributeError as exc_0:
        print(exc_0.__class__.__name__, ": ", exc_0)
        print(repr(traceback.format_tb(exc_0.__traceback__)))

# Generated at 2022-06-25 16:10:04.375578
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_0 = json.JSONEncoder()
    extended_encoder_0 = _ExtendedEncoder(var_0)



# Generated at 2022-06-25 16:10:08.064184
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    # call default with argument o
    var_0 = extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:10:11.411658
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:10:15.139424
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Check initialization
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)



# Generated at 2022-06-25 16:10:25.192540
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_0 = _ExtendedEncoder(skipkeys=False)
    extended_encoder_0 = _ExtendedEncoder(ensure_ascii=True)
    extended_encoder_0 = _ExtendedEncoder(check_circular=True)
    extended_encoder_0 = _ExtendedEncoder(allow_nan=True)
    extended_encoder_0 = _ExtendedEncoder(sort_keys=False)
    extended_encoder_0 = _ExtendedEncoder(indent=1)
    extended_encoder_0 = _ExtendedEncoder(separators=(',', ':'))
    extended_encoder_0 = _ExtendedEncoder(default=datetime)
    extended_encoder_0 = _ExtendedEncoder