

# Generated at 2022-06-25 16:02:43.084980
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    class_0 = _ExtendedEncoder()
    assert class_0 is not None



# Generated at 2022-06-25 16:02:44.748754
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    obj = _ExtendedEncoder()
    value = obj.default(42)
    assert value == 42


# Generated at 2022-06-25 16:02:54.127809
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Setup
    dict_0 = {}
    dict_1 = dict_0
    dict_2 = {}
    dict_2["encoder"] = 0
    dict_2["decoder"] = 0
    dict_2["mm_field"] = ""
    dict_2["letter_case"] = ""
    dict_2["exclude"] = True
    ExtendedEncoder = _ExtendedEncoder()
    ExtendedEncoder.default(dict_0)
    ExtendedEncoder.default(dict_1)
    ExtendedEncoder.default(dict_2)

# This class is used to represent an object of type FieldOverride

# Generated at 2022-06-25 16:02:56.870263
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:03:01.031409
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    obj = object()
    with pytest.raises(TypeError) as excinfo:
        encoder.default(obj)
        assert 'TypeError' in str(excinfo.value)


# Generated at 2022-06-25 16:03:05.502541
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings(record=True) as w:
        o = _ExtendedEncoder()
        assert(not _isinstance_safe(o, Enum))
    assert(len(w) == 0)
    assert(not _isinstance_safe(o, list))
    assert(_isinstance_safe(o, _ExtendedEncoder))


# Generated at 2022-06-25 16:03:08.470737
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:03:09.459042
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:03:19.739705
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import datetime
    from typing import List, Optional

    @cfg.register_encoder(datetime)
    def datetime_encoder(_, o: datetime):
        return o.timestamp()

    @cfg.register_encoder(UUID)
    def uuid_encoder(_, o: UUID):
        return str(o)

    @cfg.register_encoder(Decimal)
    def decimal_encoder(_, o: Decimal):
        return str(o)

    dt = datetime(2019, 1, 1, 0, 0, 0, 0, tzinfo=timezone.utc)

    uuid_0 = UUID(hex='0a7da636-1fcf-4252-9a3d-b3a12d2a7a38')

    dec_0

# Generated at 2022-06-25 16:03:20.984327
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """Test _ExtendedEncoder"""
    _ExtendedEncoder()


# Generated at 2022-06-25 16:03:41.106616
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert isinstance(extended_encoder, json.JSONEncoder)


# Generated at 2022-06-25 16:03:42.771189
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    instance = _ExtendedEncoder()
    assert isinstance(instance, _ExtendedEncoder)

# Test case for _ExtendedEncoder.default method

# Generated at 2022-06-25 16:03:44.403335
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()
    assert isinstance(extended_encoder_1, json.JSONEncoder)


# Generated at 2022-06-25 16:03:48.805418
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert type(extended_encoder_0) == _ExtendedEncoder
    assert get_type_hints(extended_encoder_0.default) == Any



# Generated at 2022-06-25 16:03:50.821014
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder


# Generated at 2022-06-25 16:03:57.766124
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    v_0 = _ExtendedEncoder()
    extended_encoder_0 = _ExtendedEncoder()
    assert type(v_0) == _ExtendedEncoder
    assert type(extended_encoder_0) == _ExtendedEncoder



# Generated at 2022-06-25 16:04:08.713779
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():

    # Test if constructor raises TypeError when proper arguments are not passed
    with pytest.raises(TypeError):
        _ExtendedEncoder(1)

    with pytest.raises(TypeError):
        _ExtendedEncoder(1.1)

    with pytest.raises(TypeError):
        _ExtendedEncoder("abc")

    with pytest.raises(TypeError):
        _ExtendedEncoder(None)

    with pytest.raises(TypeError):
        _ExtendedEncoder(True)

    with pytest.raises(TypeError):
        _ExtendedEncoder(False)

    with pytest.raises(TypeError):
        _ExtendedEncoder(b"abc")

    with pytest.raises(TypeError):
        _ExtendedEncoder(b"")


# Generated at 2022-06-25 16:04:10.084510
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:04:12.578653
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:04:15.507718
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert isinstance(extended_encoder, json.JSONEncoder)


# Generated at 2022-06-25 16:04:41.629300
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)

# Generated at 2022-06-25 16:04:43.060550
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:04:44.228850
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:04:47.334008
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    try:
        extended_encoder_0.default(214)
    except Exception as e:
        print(e)

test__ExtendedEncoder_default()


# Generated at 2022-06-25 16:04:48.498798
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    for _ in range(1000):
        _ExtendedEncoder()



# Generated at 2022-06-25 16:04:49.852624
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    test_case_0()



# Generated at 2022-06-25 16:04:51.617219
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """
    Creates an instance of _ExtendedEncoder.
    """
    extended_encoder_0 = _ExtendedEncoder()
    

# Generated at 2022-06-25 16:04:58.316702
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_1 = _ExtendedEncoder()
    list_3 = []
    result_4 = extended_encoder_1.default(list_3)
    assert id(result_4) == id(list_3)
    str_5 = ""
    result_6 = extended_encoder_1.default(str_5)
    assert result_6 == str_5
    int_7 = 1
    result_8 = extended_encoder_1.default(int_7)
    assert result_8 == int_7
    float_9 = 1.2
    result_10 = extended_encoder_1.default(float_9)
    assert result_10 == float_9
    bool_11 = True
    result_12 = extended_encoder_1.default(bool_11)

# Generated at 2022-06-25 16:05:04.559925
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    # param o
    o = None
    o = o
    o = o
    o = o
    o = o
    o = o
    o = o
    o = o
    o = o
    o = o
    o = o
    o = o
    o = o
    o = o
    o = o
    o = o
    o = o
    o = o
    o = o
    o = o
    o = o

# Generated at 2022-06-25 16:05:08.779964
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    input_ = None   # type: Any
    expected_output = None  # type: Any
    actual_output = _ExtendedEncoder()
    assert actual_output == expected_output



# Generated at 2022-06-25 16:05:33.950865
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0 != None


# Generated at 2022-06-25 16:05:36.601087
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert _ExtendedEncoder is type(extended_encoder)


# Generated at 2022-06-25 16:05:38.103379
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:05:38.932138
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()


# Generated at 2022-06-25 16:05:43.532307
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Check whether the _ExtendedEncoder constructor correctly initializes the json.JSONEncoder class
    extended_encoder_1 = _ExtendedEncoder()
    # Should use json.JSONEncoder super class
    assert isinstance(extended_encoder_1, json.JSONEncoder)


# Generated at 2022-06-25 16:05:46.468477
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    s = "[1, 2, 3, 4, 5]"
    expected_out = [1, 2, 3, 4, 5]

    assert extended_encoder.decode(s) == expected_out


# Generated at 2022-06-25 16:05:53.809479
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import datetime
    from decimal import Decimal
    from enum import Enum
    from uuid import uuid4
    extended_encoder_0 = _ExtendedEncoder()
    j: Json
    j = extended_encoder_0.default(1)
    j = extended_encoder_0.default('1')
    j = extended_encoder_0.default(1.0)
    j = extended_encoder_0.default(True)
    j = extended_encoder_0.default(None)
    j = extended_encoder_0.default([1, 2, 3])
    j = extended_encoder_0.default({'a': 1, 'b': 2})
    j = extended_encoder_0.default(datetime.now())

# Generated at 2022-06-25 16:06:01.854429
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    o_0: Json = extended_encoder_0.default(__random_dict())
    o_1: Json = extended_encoder_0.default(__random_list())
    o_2: Json = extended_encoder_0.default(__random_datetime())
    o_3: Json = extended_encoder_0.default(__random_uuid())
    o_4: Json = extended_encoder_0.default(__random_enum())
    o_5: Json = extended_encoder_0.default(__random_decimal())
    o_6: Json = extended_encoder_0.default((__random_str(),))



# Generated at 2022-06-25 16:06:04.718652
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder({}) == _ExtendedEncoder({}), "unit test for __init__ of _ExtendedEncoder"

# Generated at 2022-06-25 16:06:13.816358
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    test_data = [
        (datetime(2020, 1, 1, 12, 12, 12, 123456, tzinfo=timezone.utc), 1577869132.123456),
        (UUID('e80feffa-48d2-4dec-8c4f-9fd6d989b6a1'), 'e80feffa-48d2-4dec-8c4f-9fd6d989b6a1'),
        (Decimal('1.1'), '1.1')
    ]
    for obj, expected in test_data:
        result = _ExtendedEncoder().default(obj)
        assert expected == result


# Generated at 2022-06-25 16:06:46.052427
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        _ExtendedEncoder()
    except Exception:
        assert False
test__ExtendedEncoder()


# Generated at 2022-06-25 16:06:48.527726
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()
    assert isinstance(extended_encoder_1.default, Any)


# test_case_2 is defined

# Generated at 2022-06-25 16:06:50.735946
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert isinstance(_ExtendedEncoder(), json.JSONEncoder)



# Generated at 2022-06-25 16:06:54.632141
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test for __init__ method of class _ExtendedEncoder
    extended_encoder_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:07:01.871919
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import datetime
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_0.default = 0
    extended_encoder_0.default = 1
    extended_encoder_0.default = "abcd"
    extended_encoder_0.default = 3.14
    extended_encoder_0.default = False
    extended_encoder_0.default = None
    extended_encoder_0.default = _ExtendedEncoder
    extended_encoder_0.default = _ExtendedEncoder()
    extended_encoder_0.default = datetime
    extended_encoder_0.default = datetime()



# Generated at 2022-06-25 16:07:03.193070
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        extended_encoder_0 = _ExtendedEncoder()
    except TypeError:
        print("Failed to initialize _ExtendedEncoder")



# Generated at 2022-06-25 16:07:13.609747
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    _isinstance_safe(encoder, _ExtendedEncoder)
    _isinstance_safe(encoder, json.JSONEncoder)
    result = encoder.default(None)
    assert result is None
    result = encoder.default(1)
    assert result == 1
    result = encoder.default(1.2)
    assert result == 1.2
    result = encoder.default(1+2j)
    assert result == (1+2j)
    result = encoder.default("s")
    assert result == "s"
    result = encoder.default(True)
    assert result == True
    result = encoder.default([1,2,3])
    assert result == [1,2,3]

# Generated at 2022-06-25 16:07:15.295838
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert _is_dataclass_instance(extended_encoder)


# Generated at 2022-06-25 16:07:16.821123
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ext_encoder = _ExtendedEncoder()
    assert ext_encoder is not None


# Generated at 2022-06-25 16:07:19.231476
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder() is not None


# Generated at 2022-06-25 16:07:44.800211
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()


# Generated at 2022-06-25 16:07:51.437994
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    field_override_0 = FieldOverride(encoder=extended_encoder_0, decoder=None, mm_field=None, letter_case=None, exclude=None)

    pass


# Generated at 2022-06-25 16:07:55.305845
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert isinstance(extended_encoder, json.JSONEncoder), "_ExtendedEncoder not instance of JSONEncoder"
    assert isinstance(extended_encoder, _ExtendedEncoder), "_ExtendedEncoder not instance of _ExtendedEncoder"



# Generated at 2022-06-25 16:07:56.932058
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()

# Generated at 2022-06-25 16:07:58.829541
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    instance_0 = _ExtendedEncoder()
    assert _issubclass_safe(type(instance_0), json.JSONEncoder)



# Generated at 2022-06-25 16:07:59.808190
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()


# Generated at 2022-06-25 16:08:03.173229
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert isinstance(extended_encoder, json.JSONEncoder)
    assert isinstance(extended_encoder, _ExtendedEncoder)


# Generated at 2022-06-25 16:08:06.604888
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    arg1 = json.JSONEncoder()
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0.__dict__ == arg1.__dict__


# Generated at 2022-06-25 16:08:09.895792
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()


# Generated at 2022-06-25 16:08:15.574123
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    data = {'a': [1, 2.5],
            'b': 'str',
            'c': {},
            'd': {'1': 1, '2': 2},
            'e': (1, 2),
            'f': {'a', 'b', 'c'},
            'g': 1,
            'h': 1.5,
            'i': True,
            'j': None,
            'k': (1,),
            'l': '2019-11-24T15:50:23',
            'm': '636d35b4-b619-4e4c-80eb-7b9a925946d7',
            'n': 'foo.Bar',
            'o': '1.5'}
    
    # Test data for the input:
    # a

# Generated at 2022-06-25 16:09:02.657686
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    x = _ExtendedEncoder()
    assert x

# TODO: Use dataclasses_json.config to set default encoders/decoders
#
# def test_config_default_encoder():
#     class MyEncoder(json.JSONEncoder):
#         pass
#
#     config = cfg.new()
#     config.encoders[MyEncoder] = MyEncoder()
#     config.load_config(config)
#     assert MyEncoder == config.encoders[MyEncoder]



# Generated at 2022-06-25 16:09:05.654815
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_0.default(dict({"a": 1}))



# Generated at 2022-06-25 16:09:11.444005
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, json.JSONEncoder)


# Generated at 2022-06-25 16:09:15.619766
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    x = extended_encoder_0.encode(None)


# Generated at 2022-06-25 16:09:22.909661
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    t = cfg.new_message(cfg.t_conf.JSON_ENCODER, cfg.t_type.CLASS, cfg.d_class.JSON_ENCODER, id(cfg.d_class.JSON_ENCODER))
    cfg.g.add((cfg.new_message(cfg.t_conf.INSTANCE, cfg.t_type.CLASS, cfg.d_class.JSON_ENCODER, id(extended_encoder_0)),
               cfg.new_message(cfg.t_conf.IS_INSTANCE, cfg.t_type.CLASS, cfg.d_class.JSON_ENCODER, id(extended_encoder_0)),
               t))



# Generated at 2022-06-25 16:09:26.606281
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    v0 = extended_encoder_0.default(0)
    assert v0 == 0


# Generated at 2022-06-25 16:09:27.960654
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder()
    assert issubclass(_ExtendedEncoder, json.JSONEncoder)



# Generated at 2022-06-25 16:09:32.522316
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import datetime
    from dataclasses_json.utils import _ExtendedEncoder
    ext_encoder = _ExtendedEncoder()
    dt = datetime.utcnow()
    res = ext_encoder.default(dt)
    from jsonschema_test import json_encoder_test
    json_encoder_test.test_datetime(dt=dt, res=res)



# Generated at 2022-06-25 16:09:34.490869
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _ExtendedEncoder().default(1)


# Generated at 2022-06-25 16:09:35.074246
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass


# Generated at 2022-06-25 16:10:16.911908
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:10:18.504327
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:10:22.353203
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    class TestCase(unittest.TestCase):
        def runTest(self):
            test_case_0()
    suite = unittest.TestSuite()
    suite.addTest(TestCase())
    runner = unittest.TextTestRunner()
    runner.run(suite)

test__ExtendedEncoder_default()



# Generated at 2022-06-25 16:10:33.049309
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder();
    _ExtendedEncoder(skipkeys=True);
    _ExtendedEncoder(ensure_ascii=True);
    _ExtendedEncoder(check_circular=True);
    _ExtendedEncoder(allow_nan=True);
    _ExtendedEncoder(indent=0);
    _ExtendedEncoder(separators=('0', '1'));
    _ExtendedEncoder(default=None);
    _ExtendedEncoder(sort_keys=True);
    _ExtendedEncoder(skipkeys=True, ensure_ascii=True);
    _ExtendedEncoder(skipkeys=True, check_circular=True);
    _ExtendedEncoder(skipkeys=True, allow_nan=True);

# Generated at 2022-06-25 16:10:35.500750
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    args_0 = json.JSONEncoder.default(1)
    extended_encoder_0 = _ExtendedEncoder(args_0)


# Generated at 2022-06-25 16:10:47.170480
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default([])
    # Check data
    assert var_0 == []
    var_1 = extended_encoder_0.default([])
    # Check data
    assert var_1 == []
    var_2 = extended_encoder_0.default(())
    # Check data
    assert var_2 == []
    var_3 = extended_encoder_0.default({})
    # Check data
    assert var_3 == {}
    var_4 = extended_encoder_0.default(set())
    # Check data
    assert var_4 == []
    var_5 = extended_encoder_0.default(1)
    # Check data
    assert var_5 == 1
    var_6 = extended_enc

# Generated at 2022-06-25 16:10:56.685109
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    """Test for method _ExtendedEncoder.default."""
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.default(1)
    assert extended_encoder.default(1.0)
    assert extended_encoder.default(None)
    assert extended_encoder.default(True)
    assert extended_encoder.default(False)
    assert extended_encoder.default(object())
    assert extended_encoder.default(datetime(2017, 1, 1))
    assert extended_encoder.default(datetime(2017, 1, 1, 0, 0, 0, 0, timezone.utc))
    assert extended_encoder.default(datetime(2017, 1, 1, 0, 0, 0, 1, timezone.utc))

# Generated at 2022-06-25 16:11:01.745386
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():

    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_1 = _ExtendedEncoder(indent=None)

    var_0 = extended_encoder_1.default(extended_encoder_0)


# dataclass not defined

# Generated at 2022-06-25 16:11:03.988351
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()
    if _isinstance_safe(extended_encoder, json.JSONEncoder):
        extended_encoder.default(extended_encoder)

test__ExtendedEncoder_default()


# Generated at 2022-06-25 16:11:11.732262
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    # Test attribute self._check_circular of class _ExtendedEncoder
    assert extended_encoder_0._check_circular == True
    # Test attribute self._floatstr of class _ExtendedEncoder
    assert extended_encoder_0._floatstr == '%.16g'
    # Test attribute self._max_seq_length of class _ExtendedEncoder
    assert extended_encoder_0._max_seq_length == 10
    # Test attribute self._skipkeys of class _ExtendedEncoder
    assert extended_encoder_0._skipkeys == False
    # Test attribute self._sort_keys of class _ExtendedEncoder
    assert extended_encoder_0._sort_keys == False
    # Test attribute self._stringify_keys of class _ExtendedEncoder
