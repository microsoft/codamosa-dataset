

# Generated at 2022-06-25 16:02:41.699430
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert _isinstance_safe(extended_encoder, json.JSONEncoder)
    assert not _isinstance_safe(extended_encoder, json.JSONDecoder)



# Generated at 2022-06-25 16:02:42.947627
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:02:45.284637
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()
    assert extended_encoder_1 is not None

_ENCODERS = defaultdict(lambda: None)



# Generated at 2022-06-25 16:02:49.107363
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    text = 'Hello, World!'
    assert extended_encoder.default(text) == 'Hello, World!'



# Generated at 2022-06-25 16:02:52.221146
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """Tests for constructor of class _ExtendedEncoder"""
    a = _ExtendedEncoder()
    assert isinstance(a, _ExtendedEncoder) == True


# Generated at 2022-06-25 16:02:59.720210
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.default({'x': 1}) == {'x': 1}
    assert extended_encoder.default([1, 2, 3]) == [1, 2, 3]
    assert extended_encoder.default('a') == 'a'
    assert extended_encoder.default(1) == 1
    assert extended_encoder.default(1.0) == 1.0
    assert extended_encoder.default(True) == True
    assert extended_encoder.default(None) == None
    # assert extended_encoder.default(set([1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-25 16:03:07.904448
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    o_0 = Decimal('9.99')
    # State 0:
    assert _isinstance_safe(o_0, Decimal)
    # State 1:
    assert _isinstance_safe(o_0, Decimal)
    # State 2:
    assert _isinstance_safe(o_0, Decimal)
    # State 3:
    assert _isinstance_safe(o_0, Decimal)
    # State 4:
    # assert _issubclass_safe(type(result_0), Decimal)
    # assert _issubclass_safe(type(str(o_0)), Decimal)
    assert result_0 == str(o_0) and _isinstance_safe(result_0, str)



# Generated at 2022-06-25 16:03:10.049810
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)



# Generated at 2022-06-25 16:03:11.349469
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder(1)


# Generated at 2022-06-25 16:03:20.419316
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert isinstance(extended_encoder, _ExtendedEncoder)
    assert isinstance(extended_encoder, json.JSONEncoder)
    assert isinstance(extended_encoder, object)


_ExtendedEncoder.default(extended_encoder, [])
_ExtendedEncoder.default(extended_encoder, (1, 2))
_ExtendedEncoder.default(extended_encoder, 'int')
_ExtendedEncoder.default(extended_encoder, 3.14)
_ExtendedEncoder.default(extended_encoder, True)
_ExtendedEncoder.default(extended_encoder, None)



# Generated at 2022-06-25 16:03:43.113308
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)


# Generated at 2022-06-25 16:03:44.850508
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


_puts = print
_puts2 = print
_puts3 = print



# Generated at 2022-06-25 16:03:55.806549
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

    ext_encoder_test_case_0 = {'a': 1}
    # call method default of object encoder
    _ExtendedEncoder.default(encoder, ext_encoder_test_case_0)

    ext_encoder_test_case_1 = ['a', 'b']
    # call method default of object encoder
    _ExtendedEncoder.default(encoder, ext_encoder_test_case_1)

    ext_encoder_test_case_2 = 'a'
    # call method default of object encoder
    _ExtendedEncoder.default(encoder, ext_encoder_test_case_2)

    # call method default of object encoder
    _ExtendedEncoder.default(encoder, 1)

    # call method default of object

# Generated at 2022-06-25 16:03:57.598146
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()
    assert extended_encoder_1


# Generated at 2022-06-25 16:03:58.718122
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:04:03.117131
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():

    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_1 = _ExtendedEncoder()
    assert extended_encoder_1 == extended_encoder_0


# Generated at 2022-06-25 16:04:04.133647
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:04:06.062066
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = 42
    extended_encoder_0 = _ExtendedEncoder()
    result = extended_encoder_0.default(o)
    assert result == 42


# Generated at 2022-06-25 16:04:07.792356
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """
    Unit test for constructor of class _ExtendedEncoder
    """
    extended_encoder_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:04:09.092066
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    extended_encoder.default(None)



# Generated at 2022-06-25 16:04:35.400704
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, json.JSONEncoder)
    assert isinstance(extended_encoder_0, _ExtendedEncoder)



# Generated at 2022-06-25 16:04:41.693338
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import datetime
    from enum import Enum
    from uuid import UUID

    extended_encoder = _ExtendedEncoder()

    result = extended_encoder.default(1)
    assert not isinstance(result, dict)
    assert not isinstance(result, list)
    assert not isinstance(result, str)
    assert not isinstance(result, float)
    assert not isinstance(result, bool)
    assert result is 1
    assert not isinstance(result, type(None))

    result = extended_encoder.default(None)
    assert not isinstance(result, dict)
    assert not isinstance(result, list)
    assert not isinstance(result, str)
    assert not isinstance(result, float)
    assert not isinstance(result, bool)
    assert result is None

# Generated at 2022-06-25 16:04:43.100505
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder() is not None


# Generated at 2022-06-25 16:04:44.286513
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()


# Generated at 2022-06-25 16:04:46.604442
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder is not None

# Integration test for function default() in _ExtendedEncoder

# Generated at 2022-06-25 16:04:47.500939
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder() is not None



# Generated at 2022-06-25 16:04:49.246300
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder_0 = _ExtendedEncoder()
    assert isinstance(encoder_0, _ExtendedEncoder)



# Generated at 2022-06-25 16:04:55.452543
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import datetime as _datetime
    import datetime as __datetime
    import datetime as ___datetime
    import enum as ___enum
    import uuid as __uuid
    import decimal as __decimal
    _ExtendedEncoder_default_0 = _ExtendedEncoder().default(___enum.Enum('test', 'val'))
    _ExtendedEncoder_default_1 = _ExtendedEncoder().default({'a': 1})
    _ExtendedEncoder_default_2 = _ExtendedEncoder().default([1.2, 3.4])
    _ExtendedEncoder_default_3 = _ExtendedEncoder().default(_datetime.datetime(2019, 2, 28, tzinfo=_datetime.timezone(datetime.timedelta(0, 7200))))
    _ExtendedEncoder_default

# Generated at 2022-06-25 16:05:01.018972
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Build a dict of the args to pass to _ExtendedEncoder.default
    args = {}

    # Build a dict of the expected outputs
    expected = {}

    # Get an instance of _ExtendedEncoder
    extender = _ExtendedEncoder()

    # Call the method under test
    result = extender.default(**args)

    # Check the result against the expected value
    assert result == expected


# Generated at 2022-06-25 16:05:10.916852
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        extended_encoder_0 = _ExtendedEncoder()

    with pytest.raises(TypeError):
        extended_encoder_0.default(((['d', 'd'], []),))

    with pytest.raises(TypeError):
        extended_encoder_0.default((str('str'),))

    with pytest.raises(TypeError):
        extended_encoder_0.default((None,))

    with pytest.raises(TypeError):
        extended_encoder_0.default(({'d': None},))

    with pytest.raises(TypeError):
        extended_encoder_0.default((dict({'d': None}),))

    with pytest.raises(TypeError):
        extended_

# Generated at 2022-06-25 16:05:35.190006
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)


# Generated at 2022-06-25 16:05:42.144490
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    def test_case_0():
        extended_encoder_0 = _ExtendedEncoder()


JsonDecoder = json.JSONDecoder

_json_loader = JsonDecoder().raw_decode

# noinspection PyAbstractClass
# noinspection PyUnusedLocal

# Generated at 2022-06-25 16:05:44.791189
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # 1
    extended_encoder_1 = _ExtendedEncoder()
    assert extended_encoder_1 is not None


# Generated at 2022-06-25 16:05:57.809262
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_0.default(1)
    extended_encoder_0.default(1.1)
    extended_encoder_0.default('str')
    extended_encoder_0.default([1, 1.1, 'str'])
    extended_encoder_0.default({1, 1.1, 'str'})
    extended_encoder_0.default({'1': 1, '1.1': 1.1, 'str': 'str'})
    extended_encoder_0.default(False)
    extended_encoder_0.default(None)
    extended_encoder_0.default(True)


# Generated at 2022-06-25 16:06:03.741339
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('b190ab67-f296-45dc-a53b-dfb958db97a0')) == 'b190ab67-f296-45dc-a53b-dfb958db97a0'
    assert _ExtendedEncoder().default(Decimal('42.0')) == '42.0'
    assert _ExtendedEncoder().default('42') == '42'
    assert _ExtendedEncoder().default(42) == 42


# Generated at 2022-06-25 16:06:05.181938
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:06:08.135068
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()
    assert '_ExtendedEncoder' == extended_encoder_1.__class__.__name__


# Generated at 2022-06-25 16:06:19.530111
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0.iterencode, object)
    assert isinstance(extended_encoder_0.indent, object)
    assert isinstance(extended_encoder_0.ensure_ascii, object)
    assert isinstance(extended_encoder_0.check_circular, object)
    assert isinstance(extended_encoder_0.allow_nan, object)
    assert isinstance(extended_encoder_0.sort_keys, object)
    assert isinstance(extended_encoder_0.skipkeys, object)
    assert isinstance(extended_encoder_0.item_sort_key, object)
    assert isinstance(extended_encoder_0.default, object)

# Generated at 2022-06-25 16:06:28.676545
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    o = copy.copy({'p':'s'})
    extended_encoder_1 = _ExtendedEncoder()
    o = copy.copy(['s'])
    extended_encoder_2 = _ExtendedEncoder()
    o = copy.copy('s')
    extended_encoder_3 = _ExtendedEncoder()
    o = copy.copy(5)
    extended_encoder_4 = _ExtendedEncoder()
    o = copy.copy(5.5)
    extended_encoder_5 = _ExtendedEncoder()
    o = copy.copy(True)
    extended_encoder_6 = _ExtendedEncoder()
    o = copy.copy(None)
    extended_encoder_7 = _ExtendedEncoder()


# Generated at 2022-06-25 16:06:30.987107
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)


# Generated at 2022-06-25 16:06:56.142459
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:06:57.114943
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:07:02.014994
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder._current_indent_level == 0
    assert extended_encoder._check_circular is False
    assert extended_encoder._allow_nan is True
    assert extended_encoder._skipkeys is False
    assert extended_encoder._ensure_ascii is True
    assert extended_encoder._indent is None
    assert extended_encoder._separators is (',', ':')



# Generated at 2022-06-25 16:07:03.563674
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    obj = dict(name='John', age=43)
    result = test_case_0()


# Generated at 2022-06-25 16:07:04.909841
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert  extended_encoder_0 != None


# Generated at 2022-06-25 16:07:05.753365
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()

# Generated at 2022-06-25 16:07:07.939000
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()

    assert isinstance(enc, json.JSONEncoder)


# Generated at 2022-06-25 16:07:09.583204
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        extended_encoder_0 = _ExtendedEncoder()
    except TypeError as e:
        assert type(e) == TypeError


# Generated at 2022-06-25 16:07:15.633965
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder is not None
    assert _ExtendedEncoder() is not None


# Generated at 2022-06-25 16:07:24.606242
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = extended_encoder_0.default(0)
    conf = [extended_encoder_0, extended_encoder_1, extended_encoder_1]
    assert conf == [extended_encoder_0, 0, 0]

    extended_encoder_2 = extended_encoder_0.default('0')
    conf = [extended_encoder_0, extended_encoder_1, extended_encoder_1, extended_encoder_2]
    assert conf == [extended_encoder_0, 0, 0, '0']

    extended_encoder_3 = extended_encoder_0.default(True)

# Generated at 2022-06-25 16:07:54.430116
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:07:57.272080
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # type: () -> None
    extended_encoder_1 = _ExtendedEncoder()



# Generated at 2022-06-25 16:07:58.510386
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()


# Generated at 2022-06-25 16:07:59.587425
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()


# Generated at 2022-06-25 16:08:02.567439
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder_0 = _ExtendedEncoder()
# Check whether the constructor of class _ExtendedEncoder returns the correct value
    assert isinstance(encoder_0, _ExtendedEncoder) == True


# Generated at 2022-06-25 16:08:03.407605
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert(True)



# Generated at 2022-06-25 16:08:11.427719
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    # testing for correct call of superclass' constructor
    assert json.JSONEncoder.default(extended_encoder, 'abc') == 'abc'
    # testing for correct mapping of bool to JSON
    assert json.JSONEncoder.default(extended_encoder, True) is True
    # testing for correct mapping of float to JSON
    assert json.JSONEncoder.default(extended_encoder, float(3.14)) == 3.14
    # testing for correct mapping of int to JSON
    assert json.JSONEncoder.default(extended_encoder, int(314)) == 314
    # testing for correct mapping of None to JSON
    assert json.JSONEncoder.default(extended_encoder, None) is None
    # testing for correct mapping of str to JSON
    assert json

# Generated at 2022-06-25 16:08:13.602689
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:08:15.087739
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()

_extended_encoder = _ExtendedEncoder()



# Generated at 2022-06-25 16:08:16.442118
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    res: _ExtendedEncoder = _ExtendedEncoder()
    assert isinstance(res, _ExtendedEncoder)



# Generated at 2022-06-25 16:09:00.229572
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder_0 = _ExtendedEncoder()
    assert _isinstance_safe(encoder_0, json.JSONEncoder)
    assert _isinstance_safe(encoder_0, _ExtendedEncoder)



# Generated at 2022-06-25 16:09:10.988357
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(datetime.utcnow().replace(tzinfo=timezone.utc))
    var_1 = extended_encoder_0.default(OrderedDict({'a': 'b'}))
    var_2 = extended_encoder_0.default(ExtendedEncoder)
    var_3 = extended_encoder_0.default(UUID('59b8e1c1-6e0c-4b7f-9c21-c7e62a35a437'))


# class Encoder(json.JSONEncoder):
#     def encode(self, o) -> str:
#         return super().encode(self._encode(o))
#
#     def _encode(self,

# Generated at 2022-06-25 16:09:17.449646
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _var = json.JSONEncoder.default = object()
    _var_0 = json.JSONEncoder.__init__ = object()
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0.default(_var) == _var
    assert extended_encoder_0.__init__(_var_0) is None


# Generated at 2022-06-25 16:09:20.142659
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, json.JSONEncoder) is True


# Generated at 2022-06-25 16:09:24.556947
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    expected__ExtendedEncoder = _ExtendedEncoder
    actual__ExtendedEncoder = _ExtendedEncoder()
    assert expected__ExtendedEncoder == actual__ExtendedEncoder


# Generated at 2022-06-25 16:09:27.414099
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0.Iterencode != None
    assert extended_encoder_0.encode != None


# Generated at 2022-06-25 16:09:31.224694
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_0 = _ExtendedEncoder().default(1)
    var_1 = _ExtendedEncoder().default([1,2,3])
    var_2 = _ExtendedEncoder().default(Decimal('1.0'))
    var_3 = _ExtendedEncoder().default(ext_enc)


# Generated at 2022-06-25 16:09:35.452041
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)



# Generated at 2022-06-25 16:09:38.639341
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)


# Generated at 2022-06-25 16:09:40.141144
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:10:50.255835
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        assert _ExtendedEncoder()
    except Exception as e:
        print("AssertionError", e)



# Generated at 2022-06-25 16:10:58.638596
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_1 = _ExtendedEncoder(sort_keys=0)
    extended_encoder_2 = _ExtendedEncoder(indent=2)
    extended_encoder_3 = _ExtendedEncoder(indent=2, sort_keys=0)
    extended_encoder_4 = _ExtendedEncoder(sort_keys=0)
    # Assertions on variables
    assert extended_encoder_0 != None
    assert extended_encoder_1 != None
    assert extended_encoder_2 != None
    assert extended_encoder_3 != None
    assert extended_encoder_4 != None


# Generated at 2022-06-25 16:11:00.222451
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:11:02.210002
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()
    extended_encoder.default(extended_encoder)



# Generated at 2022-06-25 16:11:02.927277
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:11:07.725700
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder(sort_keys=True, separators=(',', ':'))
    extended_encoder_1 = _ExtendedEncoder()
    extended_encoder_2 = _ExtendedEncoder(default=extended_encoder_1.default, skipkeys=True)
    # Test with the method default of class _ExtendedEncoder
    var_0 = extended_encoder_2.default(extended_encoder_0)



# Generated at 2022-06-25 16:11:09.786823
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, object)



# Generated at 2022-06-25 16:11:14.189430
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder(skipkeys=True, ensure_ascii=True,
                                        check_circular=True, allow_nan=True,
                                        sort_keys=False, indent=1,
                                        separators=(',', ': '),
                                        default=None, encoding=None)


# Generated at 2022-06-25 16:11:19.826788
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_1 = _ExtendedEncoder()
    # assert _ExtendedEncoder.__dict__ is not None
    # assert _ExtendedEncoder.__slots__ is not None
    assert _ExtendedEncoder.__init__ is not None
    assert _ExtendedEncoder._iterencode is not None
    assert _ExtendedEncoder.default is not None
    assert _ExtendedEncoder.encode is not None
    assert _ExtendedEncoder.iterencode is not None
    assert _ExtendedEncoder.new is not None
    assert _ExtendedEncoder.new_chunk is not None


# Generated at 2022-06-25 16:11:23.475126
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    # result = extended_encoder_0.default(extended_encoder_0)

