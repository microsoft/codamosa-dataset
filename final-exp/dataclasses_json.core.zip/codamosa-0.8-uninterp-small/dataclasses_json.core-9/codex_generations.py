

# Generated at 2022-06-25 16:02:42.014392
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder()


# Generated at 2022-06-25 16:02:43.523956
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    res = _ExtendedEncoder()
    raise NotImplementedError



# Generated at 2022-06-25 16:02:44.308906
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Valid parameter
    encoder = _ExtendedEncoder()



# Generated at 2022-06-25 16:02:49.289491
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Signature: name(self: dataclasses_json.encoder._ExtendedEncoder, o: Any) -> Json
    encoder = _ExtendedEncoder()
    # TODO: add type hints
    result = encoder.default(None)
    return result



# Generated at 2022-06-25 16:02:55.674023
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    field_override_0 = FieldOverride(encoder = lambda o: o)
    json_encoder_0 = _ExtendedEncoder.__init__(json_encoder_0, field_override_0)
    field_override_0 = FieldOverride(mm_field = 'mm_field', decoder = lambda o: o)
    _ExtendedEncoder.__init__(json_encoder_0, field_override_0)
    assert isinstance(json_encoder_0, json.JSONEncoder)

# Generated at 2022-06-25 16:02:57.556276
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert issubclass(_ExtendedEncoder, json.JSONEncoder)
    _ExtendedEncoder()



# Generated at 2022-06-25 16:02:59.748232
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    encoder.default(None)


# Generated at 2022-06-25 16:03:03.810317
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    
    # initialization test
    test_case_0()
    # initialization test
    test_case_1()
    # initialization test
    test_case_2()
    # initialization test
    test_case_3()
    # initialization test
    test_case_4()


# Generated at 2022-06-25 16:03:04.768680
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:03:06.040497
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder is not None


# Generated at 2022-06-25 16:03:31.644329
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from jsons import JSONEncoder

    var_0 = _ExtendedEncoder()
    assert var_0 is not None

    test_case_0()
    test_case_1()
    test__is_json()
    test_json_encoder()
    test_get_field_override()
    test_get_field_configs()
    test__can_override()
    test_is_dict_instance()
    test__obj_hook()
    test_serialize()
    test_deserialize()
    test__default_encoder_config()
    test__validate_config()
    test_encode()
    test_decode()

# Generated at 2022-06-25 16:03:34.127354
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_1 = _ExtendedEncoder()
    var_1 = extended_encoder_1.default([extended_encoder_1])


# Generated at 2022-06-25 16:03:38.667311
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    v_0 = extended_encoder_0.default(extended_encoder_0)
    # check _ExtendedEncoder
    if _isinstance_safe(v_0, _ExtendedEncoder) is False:
        raise AssertionError(f'{v_0} is not instance of class _ExtendedEncoder')



# Generated at 2022-06-25 16:03:40.025772
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()
    var = 2
    var_getitem = extended_encoder[var]

    extended_encoder.default(var)
    extended_encoder.default(var_getitem)


# Generated at 2022-06-25 16:03:40.958515
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert test_case_0() == []


# Generated at 2022-06-25 16:03:41.976033
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """
    # Constructor for class _ExtendedEncoder
    """

# Generated at 2022-06-25 16:03:43.015908
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()


# Generated at 2022-06-25 16:03:45.094717
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()

    assert 0 == json.JSONEncoder.__init__.__code__.co_argcount



# Generated at 2022-06-25 16:03:56.001460
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import datetime
    from uuid import UUID
    from dataclasses import dataclass
    from enum import Enum
    from decimal import Decimal

    @dataclass(frozen=True)
    class Foo:
        b: UUID
        c: Bar
        d: datetime
        e: EnumTest

    @dataclass
    class Bar:
        a: int

    class EnumTest(Enum):
        first = 1
        second = 2
        third = 3

    # Example with dataclass as a type
    foo = Foo(b=UUID(int=0), c=Bar(a=1), d=datetime.fromtimestamp(1), e=EnumTest.first)

    encoder = _ExtendedEncoder()

    assert encoder.default(foo) == foo_json

# Generated at 2022-06-25 16:04:02.649119
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    
    assert extended_encoder_0.encode(None) == 'null'
    assert extended_encoder_0.encode(True) == 'true'
    assert extended_encoder_0.encode(False) == 'false'
    assert extended_encoder_0.encode(1) == '1'
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        extended_encoder_0.encode(1.0)
    assert len(w) == 1
    assert issubclass(w[-1].category, DeprecationWarning)
    assert "Deprecated" in str(w[-1].message)

# Generated at 2022-06-25 16:04:36.338520
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    return


# Generated at 2022-06-25 16:04:38.435860
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test for property/attribute callable - exception thrown
    try:
        extended_encoder_0 = _ExtendedEncoder(globals=globals)
    except TypeError:
        pass


# Generated at 2022-06-25 16:04:48.843139
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.encode(None) == 'null'
    assert extended_encoder.encode(False) == 'false'
    assert extended_encoder.encode(True) == 'true'
    assert extended_encoder.encode(0) == '0'
    assert extended_encoder.encode(0.5) == '0.5'
    assert extended_encoder.encode(1.5) == '1.5'
    assert extended_encoder.encode(-1.5) == '-1.5'
    assert extended_encoder.encode(2 ** 63) == str(2 ** 63)
    assert extended_encoder.encode('hello') == '"hello"'

# Generated at 2022-06-25 16:04:53.447200
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj_0 = _ExtendedEncoder()
    try:
        getattr(obj_0, 'sort_keys')
    except AttributeError:
        pass
    assert obj_0._ExtendedEncoder__sort_keys == False


# Generated at 2022-06-25 16:04:56.519570
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, json.JSONEncoder)



# Generated at 2022-06-25 16:05:05.704061
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()

# set of test cases for _get_type_cons
test_data_0 = [None,
               object,
               set,
               int,
               datetime,
               UUID,
               Enum,
               Decimal
               ]
test_cases_1__get_type_cons = [
    # TestCase 0
    (
        test_data_0,
        {
            None: type(None),
            object: object,
            set: set,
            int: type(2),
            datetime: datetime,
            UUID: UUID,
            Enum: Enum,
            Decimal: Decimal
        }
    )
]
# set of test cases for _is_optional

# Generated at 2022-06-25 16:05:09.801751
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Create instances of class _ExtendedEncoder with and without constructor parameters
    # for each class created by dataclasses.dataclass
    extended_encoder_0 = _ExtendedEncoder()
    test_case_0()



# Generated at 2022-06-25 16:05:10.293531
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass


# Generated at 2022-06-25 16:05:12.958060
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:05:15.775046
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0 is not None


# Generated at 2022-06-25 16:06:23.127721
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # initialization
    t_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:06:24.614883
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:06:26.098744
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0 is not None


# Generated at 2022-06-25 16:06:28.351888
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """Test constructor of class _ExtendedEncoder."""
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:06:31.541053
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0.default(extended_encoder_0))


# Generated at 2022-06-25 16:06:33.597593
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_0 = _ExtendedEncoder()
    assert isinstance(var_0, _ExtendedEncoder)


# Generated at 2022-06-25 16:06:36.723907
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0 is not None


# Generated at 2022-06-25 16:06:38.447035
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert isinstance(_ExtendedEncoder(), _ExtendedEncoder)



# Generated at 2022-06-25 16:06:39.520870
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:06:43.133411
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_1 = _ExtendedEncoder()
    assert extended_encoder_0 is not extended_encoder_1  # noqa


# Generated at 2022-06-25 16:09:34.033986
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder(skipkeys=False,
                                          ensure_ascii=True,
                                          check_circular=True,
                                          allow_nan=True,
                                          sort_keys=False,
                                          indent=None,
                                          separators=None,
                                          default=None,
                                          encoding=None,
                                          cls=None)
    assert extended_encoder_1.skipkeys == False
    assert extended_encoder_1.ensure_ascii == True
    assert extended_encoder_1.check_circular == True
    assert extended_encoder_1.allow_nan == True
    assert extended_encoder_1.sort_keys == False
    assert extended_encoder_1.indent == None

# Generated at 2022-06-25 16:09:35.494373
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:09:41.801967
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)
    # var_0 = extended_encoder_0.default(extended_encoder_0)
    # var_0 = extended_encoder_0.default(extended_encoder_0)
    # var_0 = extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:09:44.245808
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0 is not None


# Generated at 2022-06-25 16:09:46.072246
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    f = _ExtendedEncoder()
    assert isinstance(f, _ExtendedEncoder)



# Generated at 2022-06-25 16:09:47.116807
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:09:48.907069
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder is not None


# Generated at 2022-06-25 16:09:51.145627
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0.default == extended_encoder_0.default


# Generated at 2022-06-25 16:09:52.219478
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert isinstance(test_case_0(), type)



# Generated at 2022-06-25 16:09:57.590894
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    expected_0 = 'dataclasses_json._ExtendedEncoder'
    actual_0 = _ExtendedEncoder.__module__
    try:
        assert actual_0 == expected_0
    except AssertionError as e:
        print('\x1B[1;31m[FAIL]\x1B[0m Expected : %s' % expected_0)
        print('\x1B[1;31m[FAIL]\x1B[0m Actual   : %s' % actual_0)
        print()
        raise e
    else:
        print('\x1B[1;32m[PASS]\x1B[0m Expected : %s' % expected_0)