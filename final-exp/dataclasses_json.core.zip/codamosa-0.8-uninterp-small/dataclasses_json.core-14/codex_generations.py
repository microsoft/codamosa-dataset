

# Generated at 2022-06-25 16:02:42.701156
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Default constructor
    encoder_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:02:43.700627
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:02:45.935805
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    d = datetime.now(timezone.utc)
    assert '{}'.format(d) == json.dumps(d, cls=_ExtendedEncoder)



# Generated at 2022-06-25 16:02:50.318245
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert _isinstance_safe(enc, _ExtendedEncoder)
    assert enc.encode is not None
    assert enc.iterencode is not None
    assert enc.default is not None

# Generated at 2022-06-25 16:02:52.016879
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:02:54.566647
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_encoder = json.JSONEncoder()
    assert isinstance(json_encoder, json.JSONEncoder)
    assert isinstance(json_encoder, json._clone_cls)



# Generated at 2022-06-25 16:02:56.913736
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:03:01.087285
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        _ExtendedEncoder(_ExtendedEncoder)
    except TypeError:
        pass
    except Exception as e:
        print('TypeError expected, got {0} instead.'.format(e))


# Generated at 2022-06-25 16:03:06.511089
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Test case 0
    field_override_0 = FieldOverride()
    field_override_0.encoder = None
    field_override_0.decoder = None
    field_override_0.mm_field = "RAISE"
    field_override_0.letter_case = None
    field_override_0.exclude = False

    o = {'a': 'b'}

    result = _ExtendedEncoder().default(o)
    assert result == o


# Generated at 2022-06-25 16:03:08.983692
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert True



# Generated at 2022-06-25 16:03:27.727385
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        cell_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:03:28.825901
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()


# Generated at 2022-06-25 16:03:31.229688
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == list(set())
    assert encoder.default({}) == {}
    assert encoder.default(1) == 1

# Generated at 2022-06-25 16:03:39.907398
# Unit test for method default of class _ExtendedEncoder

# Generated at 2022-06-25 16:03:40.389105
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:03:40.856444
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:03:46.282152
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = type(FieldOverride)
    o_instance = FieldOverride()
    o_arr = [field_override_0]
    o_dict = {'field_override_0': field_override_0}
    o_datetime = datetime.now(timezone.utc)
    o_uuid = UUID('01234567-89ab-cdef-0123-456789abcdef')
    o_other = 'other'
    encoding_result_0 = _ExtendedEncoder().default(o)
    encoding_result_1 = _ExtendedEncoder().default(o_instance)
    encoding_result_2 = _ExtendedEncoder().default(o_arr)
    encoding_result_3 = _ExtendedEncoder().default(o_dict)
    encoding_result_4 = _Extended

# Generated at 2022-06-25 16:03:49.826975
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.indent == None
    assert encoder.skipkeys == False
    assert encoder.ensure_ascii == True
    assert encoder.check_circular == True
    assert encoder.allow_nan == True
    assert encoder.sort_keys == False
    assert encoder.item_sort_key == None
    assert encoder.default == encoder.default
    assert encoder.encoding == 'utf-8'


# Generated at 2022-06-25 16:03:56.289414
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_encoder = _ExtendedEncoder()
    assert isinstance(json_encoder, _ExtendedEncoder)



# Generated at 2022-06-25 16:03:57.184588
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:04:16.183211
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert repr(_ExtendedEncoder()) == repr(json.JSONEncoder())


# Generated at 2022-06-25 16:04:18.039504
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    q = _ExtendedEncoder()
    assert q


# Generated at 2022-06-25 16:04:28.415557
# Unit test for method default of class _ExtendedEncoder

# Generated at 2022-06-25 16:04:30.184530
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _ExtendedEncoder().default("")


# Generated at 2022-06-25 16:04:34.058455
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # type: () -> Any
    encoder = _ExtendedEncoder()
    try:
        encoder.default(1)
    except Exception as e:
        print("wrong")
        raise e


# Generated at 2022-06-25 16:04:35.750680
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder() is not None



# Generated at 2022-06-25 16:04:41.833776
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    Encoder = _ExtendedEncoder(indent=2)
    sample_1 = {
        'f0': None
    }
    assert 'null' == json.dumps(sample_1, indent=2, cls=Encoder)
    sample_2 = {
        'f0': 2
    }
    assert '2' == json.dumps(sample_2, indent=2, cls=Encoder)
    sample_3 = {
        'f0': 2.0
    }
    assert '2.0' == json.dumps(sample_3, indent=2, cls=Encoder)
    sample_4 = {
        'f0': True
    }
    assert 'true' == json.dumps(sample_4, indent=2, cls=Encoder)

# Generated at 2022-06-25 16:04:42.940112
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:04:44.864563
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ext_encoder_0 = _ExtendedEncoder()
    with warnings.catch_warnings(record=True) as w:
        result_0 = ext_encoder_0.default(ext_encoder_0)
        assert result_0 == json.JSONEncoder.default(ext_encoder_0, ext_encoder_0)


# Generated at 2022-06-25 16:04:45.754381
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()


# Generated at 2022-06-25 16:05:05.082972
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # noinspection PyProtectedMember
    _ExtendedEncoder()



# Generated at 2022-06-25 16:05:16.317035
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.5) == 1.5
    assert _ExtendedEncoder().default("1") == "1"
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default({'a': 1}) == {'a': 1}
    assert _ExtendedEncoder().default([1]) == [1]
    assert _ExtendedEncoder().default(datetime(2018, 3, 11, 4, 31, 22, tzinfo=timezone.utc)) == 1520761882.0

# Generated at 2022-06-25 16:05:18.390013
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # noinspection PyTypeChecker
    result = _ExtendedEncoder()
    assert _isinstance_safe(result, _ExtendedEncoder)


# Generated at 2022-06-25 16:05:23.775301
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_0.default(datetime.now())
    extended_encoder_0.default('abc')
    extended_encoder_0.default(123)
    extended_encoder_0.default(1.8)
    extended_encoder_0.default({'a': 1, 'b': '2'})
    extended_encoder_0.default([1, 2, 3])
    extended_encoder_0.default(UUID('d1cbb0c6-5816-4836-9088-ee14c897c2e2'))
    extended_encoder_0.default(Decimal('1.0'))
    extended_encoder_0.default(True)
    extended_encoder_0.default(None)


# Generated at 2022-06-25 16:05:34.243995
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    field_override_0 = FieldOverride(encoder=_ExtendedEncoder)
    field_override_0 = FieldOverride(encoder=_ExtendedEncoder)
    # Create instance
    obj = _ExtendedEncoder()

    # Call method default with argument o
    result = obj.default(None)
    assert result is None

    # Call method default with argument o
    result = obj.default(MISSING)
    assert result is None

    # Call method default with argument o
    result = obj.default(12345)
    assert result == 12345

    result = obj.default(.12345)
    assert result == .12345

    result = obj.default("abcde")
    assert result == "abcde"

    result = obj.default({1: 2, 3: 4})

# Generated at 2022-06-25 16:05:39.694122
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert isinstance(encoder, _ExtendedEncoder)



# Generated at 2022-06-25 16:05:46.274571
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    result_default: Json
    encoder_0 = _ExtendedEncoder()
    # Test for function default of class _ExtendedEncoder
    test_case_0()
    test_case_1(encoder_0)
    test_case_2(encoder_0)
    test_case_3(encoder_0)
    test_case_4()
    test_case_5(encoder_0)
    test_case_6(encoder_0)


# Test for function default of class _ExtendedEncoder

# Generated at 2022-06-25 16:05:50.463007
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    expected = json.JSONEncoder
    value = _ExtendedEncoder()
    assert type(value) is expected


# Generated at 2022-06-25 16:05:52.204942
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:06:01.286962
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
	# TestBasicTypes
	encoder = _ExtendedEncoder()
	assert encoder.default('string') == 'string'
	assert encoder.default(123) == 123
	assert encoder.default(1.23) == 1.23
	assert encoder.default(True) == True
	assert encoder.default(False) == False
	assert encoder.default(None) == None

	# TestCollectionTypes
	assert encoder.default([1, 2, 3]) == [1, 2, 3]
	assert encoder.default((1, 2, 3)) == [1, 2, 3]
	assert encoder.default({'a': 1, 'b': 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-25 16:06:33.748710
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:06:46.044705
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder._skipkeys == True
    assert encoder._ensure_ascii == True
    assert encoder._check_circular == True
    assert encoder._allow_nan == True
    #assert encoder._sort_keys == False  # Changed by Jens Schmalfuss
    assert encoder._sort_keys == True
    assert encoder._indent == None
    assert encoder._separators == (',', ':')
    assert encoder._encoding == 'utf-8'
    assert encoder._default == None
    assert encoder._namedtuple_as_object == True
    assert encoder._tuple_as_array == True
    assert encoder._bigint_as_string == True
    assert encoder._item_sort_key == None
    assert encoder

# Generated at 2022-06-25 16:06:50.226129
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder()
    assert result is not None


# Generated at 2022-06-25 16:06:53.020065
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder


# Generated at 2022-06-25 16:06:58.322217
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    d = _ExtendedEncoder()
    assert isinstance(d, json.JSONEncoder)



# Generated at 2022-06-25 16:07:01.831129
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # The _ExtendedEncoder.default method is produced by dataclasses_json.api,
    # so we cannot test it separately.
    assert True


# Generated at 2022-06-25 16:07:06.401485
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encode = _ExtendedEncoder().default
    assert encode([1, 2, 3]) == [1, 2, 3]
    assert encode({1:'1', 2:'2'}) == {'1':'1', '2':'2'}

    dt = datetime(1982, 11, 27, 23, 58)
    assert encode(dt) == dt.timestamp()

    uuid = UUID('868ffcc6-c69f-4d87-a8a8-eec6c9aca6d7')
    assert encode(uuid) == str(uuid)

    class Color(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3
    assert encode(Color.RED) == 1

    dec = Decimal('0.123')
    assert encode(dec) == str(dec)

# Generated at 2022-06-25 16:07:16.187582
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()

    # Test for basic json types
    assert extended_encoder.default({}) == {}
    assert extended_encoder.default([]) == []
    assert extended_encoder.default('') == ''
    assert extended_encoder.default(0) == 0
    assert extended_encoder.default(0.0) == 0.0
    assert extended_encoder.default(False) == False
    assert extended_encoder.default(None) == None

    # Test for Collection
    assert extended_encoder.default(set()) == []
    assert extended_encoder.default(dict()) == {}

    # Test for Mapping
    assert extended_encoder.default(dict()) == {}

    # Test for datetime

# Generated at 2022-06-25 16:07:16.873894
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-25 16:07:19.234767
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:07:42.477572
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:07:49.465308
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default("foo")
    assert var_0 == '"foo"'
    var_1 = extended_encoder_0.default(10)
    assert var_1 == 10
    var_2 = extended_encoder_0.default([1, 2, 3])
    assert var_2 == [1, 2, 3]
    var_3 = extended_encoder_0.default({"a": 1, "b": 2})
    assert var_3 == {"a": 1, "b": 2}
    var_4 = extended_encoder_0.default(datetime(1901, 1, 1, 0, 0))
    assert var_4 == -2145916800.0
    var_5 = extended_encoder_0

# Generated at 2022-06-25 16:07:51.934151
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder() # maybe init _ExtendedEncoder


# Generated at 2022-06-25 16:07:58.501890
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder(MISSING, MISSING, MISSING, MISSING, MISSING, MISSING)
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_2 = _ExtendedEncoder(MISSING, MISSING, True, MISSING, 'allow_nan')
    extended_encoder_3 = _ExtendedEncoder(MISSING, MISSING, True, MISSING, 'mimic')
    extended_encoder_4 = _ExtendedEncoder(MISSING, MISSING, True, MISSING, 'raise')
    extended_encoder_5 = _ExtendedEncoder(MISSING, MISSING, True, MISSING, 'ignore')

# Generated at 2022-06-25 16:07:59.589055
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:08:01.351432
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:08:02.545638
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:08:05.090335
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)



# Generated at 2022-06-25 16:08:08.065363
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0
    extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:08:11.029858
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert 1 == 1 # noqa: WPS421

# Generated at 2022-06-25 16:09:06.265430
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        extended_encoder_0 = _ExtendedEncoder()
    except:
        assert False, 'Creation of _ExtendedEncoder failed\n'



# Generated at 2022-06-25 16:09:14.157720
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()
    extended_encoder.default(None)
    extended_encoder.default(datetime.now(timezone.utc))
    extended_encoder.default(UUID('5af5d5c5-5ef5-5bf5-5cf5-5df5e5f5f5f5'))
    extended_encoder.default(True)
    extended_encoder.default(1)
    extended_encoder.default(1.1)
    extended_encoder.default([1, 2, 3, 4, 5])
    extended_encoder.default(['a', 'b', 'c', 'd', 'e'])
    extended_encoder.default(('a', 'b', 'c', 'd', 'e'))

# Generated at 2022-06-25 16:09:22.822095
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()
    for x in range(4):
        var_0 = extended_encoder.default(extended_encoder)
    var_1 = extended_encoder.default({})
    var_2 = extended_encoder.default([])
    var_3 = extended_encoder.default(True)
    var_4 = extended_encoder.default(1)
    var_5 = extended_encoder.default(1.0)
    var_6 = extended_encoder.default(1j)
    var_7 = extended_encoder.default(1.0 + 1j)
    var_8 = extended_encoder.default(var_1)
    var_9 = extended_encoder.default(var_2)

# Generated at 2022-06-25 16:09:24.211862
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    return None



# Generated at 2022-06-25 16:09:27.446146
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Input
    extended_encoder_0 = _ExtendedEncoder()
    o = extended_encoder_0

    actual = extended_encoder_0.default(o)
    expected = extended_encoder_0

    assert actual == expected


# Generated at 2022-06-25 16:09:29.492189
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)



# Generated at 2022-06-25 16:09:30.507689
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:09:32.219117
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()
    assert extended_encoder_1 is not None



# Generated at 2022-06-25 16:09:39.465810
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(UUID('2b0a1c56-f8c9-4d3f-88d0-911f30b09a48'))
    var_1 = extended_encoder_0.default(42.0)


# Generated at 2022-06-25 16:09:45.842207
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()
    uuid = UUID('1488cb37-9ceb-4b2c-8206-1947a1dd6b11')
    assert extended_encoder.default(uuid) == '1488cb37-9ceb-4b2c-8206-1947a1dd6b11'
    assert extended_encoder.default(datetime.now()) == datetime.now().timestamp()
    assert extended_encoder.default(Decimal('1.5')) == '1.5'

# Generated at 2022-06-25 16:10:45.470805
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:10:47.056125
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    check = _ExtendedEncoder()
    assert check is not None



# Generated at 2022-06-25 16:10:49.766660
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_1 = _ExtendedEncoder()
    var_1 = extended_encoder_1.default(extended_encoder_1)
    # The json serialization of the class will be None.
    assert var_1 is None


# Generated at 2022-06-25 16:10:51.595808
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        _ExtendedEncoder()
    except Exception:
        assert False


# Generated at 2022-06-25 16:10:59.745015
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, json.JSONEncoder)
    assert isinstance(extended_encoder_0, _ExtendedEncoder)
    assert extended_encoder_0.default(((extended_encoder_0,), [], {}, [])) == [
        [None], [], {}]
    assert extended_encoder_0.default([object()]) == [None]
    extended_encoder_1 = _ExtendedEncoder()
    assert extended_encoder_0.default(extended_encoder_1) is extended_encoder_1
    assert extended_encoder_0.default(datetime(2018, 8, 23, 6, 7, 54, 823_432,
                                               timezone.utc)) == 1535

# Generated at 2022-06-25 16:11:00.515681
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
	pass


# Generated at 2022-06-25 16:11:01.823427
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
	extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:11:04.046553
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0.encode("") == '""'
    assert isinstance(extended_encoder_0, json.JSONEncoder)



# Generated at 2022-06-25 16:11:05.252074
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:11:07.030364
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(dict())
