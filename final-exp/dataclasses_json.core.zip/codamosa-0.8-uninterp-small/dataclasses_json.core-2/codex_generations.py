

# Generated at 2022-06-25 16:02:52.400209
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    str_0 = 'Pt\x9b\xa9\xa1\xcc;\x19\xfd\x1d\x8cB\x80\x9a\x9a\xbf\xb4\x0b\x05\xc2\x17\xec\x9e\xfd'
    dict_0 = {str_0: str_0}
    bytes_0 = b'O*\xbb\xa1(\xaf\xc8[WP\xc4\xc2\x8d\x0e\xce+\xc5o'
    dict_1 = dict_0.copy()
    dict_1[bytes_0] = bytes_0

# Generated at 2022-06-25 16:02:53.260832
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-25 16:02:59.962180
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bytes_0 = b'o\x17\xdd_\xc6\x0b\xbf\x9f\x9e\xee\xbb\x88\xa1\xad\x8c\xac\xa6\xb3j\x86'
    list_0 = ['Decimal', 'Exclude', 'Decoder', 'Enum']
    str_0 = 'j\x8d\xcc'
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        warnings.warn(str_0, DeprecationWarning)
        _ExtendedEncoder_0 = _ExtendedEncoder(bytes_0, list_0)

test_case_0()
test__ExtendedEncoder()

# Generated at 2022-06-25 16:03:03.641785
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    obj = _ExtendedEncoder()
    args_0 = [1]
    with pytest.raises(TypeError):
        # noinspection PyTypeChecker
        ret = obj.default(*args_0)


# Generated at 2022-06-25 16:03:12.512039
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bytes_0 = b'\xcd\x8b\xf6\x9a9\xc2'
    list_0 = [bytes_0, bytes_0, bytes_0]
    field_override_0 = FieldOverride(*list_0)
    o_0 = _ExtendedEncoder.default(field_override_0, o=field_override_0)
    o_1 = _ExtendedEncoder.default(field_override_0, o=field_override_0)
    # assertEqual(o_0, o_1)
    assert o_0 == o_1



# Generated at 2022-06-25 16:03:22.017614
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    str_0 = 'sXp,<\x80`@\xe8\x98\x84x\x0c\x8a\xb3\x90\x9f'
    str_1 = 'N\xab\xc3\xaf\x83\x10\xf2\x9d\xef\xb3\x960\xda\x07\x1e\x8e\x0a\x9d\x6a\xca\xdc'
    str_2 = '\xeb\xbf"\x8d\x86\xe9\x98r\xee\xc8\x0f,\x13\xe3\x04'

# Generated at 2022-06-25 16:03:30.541103
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    tests = [
        # (object, expected)
        ('O*\xbb\xa1(\xaf\xc8[WP\xc4\xc2\x8d\x0e\xce+\xc5o',
         'O*\xbb\xa1(\xaf\xc8[WP\xc4\xc2\x8d\x0e\xce+\xc5o'),
        (1, 1),
    ]
    for test in tests:
        object, expected = test
        result = json.dumps(object, cls=_ExtendedEncoder)
        assert result == expected


# Generated at 2022-06-25 16:03:36.721333
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings(record=True) as w_0:
        warnings.simplefilter('always')

        # Call method setUpClass of class _ExtendedEncoder
        ret_class_0 = _ExtendedEncoder(warnings.catch_warnings())

        # Check if _ExtendedEncoder._ExtendedEncoder method returns 'None'
        assert ret_class_0 is None
    # Check if _ExtendedEncoder._ExtendedEncoder method returns 'None'
    assert len(w_0) == 1



# Generated at 2022-06-25 16:03:42.629885
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    bytes_0 = b'O*\xbb\xa1(\xaf\xc8[WP\xc4\xc2\x8d\x0e\xce+\xc5o'
    list_0 = [bytes_0, bytes_0]
    field_override_0 = FieldOverride(*list_0)
    _extended_encoder_0 = _ExtendedEncoder()
    try:
        json_0 = json.dumps({field_override_0: 1}, cls=_ExtendedEncoder)
    except TypeError:
        pass

test_case_0()
test__ExtendedEncoder()

# Generated at 2022-06-25 16:03:49.817809
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    bytes_0 = b'L\x94\xf8\xfb\xf2\xe1\xbf\x9b\xd2\xbb\xbd\xbc\xb5)\xe3(\xf5\xad\xa5\x9c\x91\xac\x94\x08\x1c'
    list_0 = [bytes_0, bytes_0]
    field_override_0 = FieldOverride(*list_0)
    _ExtendedEncoder.default(field_override_0)


# Generated at 2022-06-25 16:04:09.874952
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()

# Generated at 2022-06-25 16:04:16.213693
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # input
    _o = datetime.utcnow().replace(tzinfo=timezone.utc)
    # expected output
    _result = _o.timestamp()

    # test
    extended_encoder = _ExtendedEncoder()
    result = extended_encoder.default(_o)

    assert result == _result



# Generated at 2022-06-25 16:04:18.092313
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # type: () -> None
    test_case_0()


# Generated at 2022-06-25 16:04:21.704423
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)



# Generated at 2022-06-25 16:04:25.567325
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder is not None


# Generated at 2022-06-25 16:04:29.465753
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()
    assert isinstance(_ExtendedEncoder(), _ExtendedEncoder)



# Generated at 2022-06-25 16:04:30.642995
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder is not None


# Generated at 2022-06-25 16:04:31.808482
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:04:34.767718
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, json.JSONEncoder)



# Generated at 2022-06-25 16:04:36.104682
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:05:05.422521
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_1 = _ExtendedEncoder(indent=4)
    extended_encoder_2 = _ExtendedEncoder(skipkeys=False)
    extended_encoder_3 = _ExtendedEncoder(ensure_ascii=True)
    extended_encoder_4 = _ExtendedEncoder(check_circular=True)
    extended_encoder_5 = _ExtendedEncoder(allow_nan=True)
    extended_encoder_6 = _ExtendedEncoder(sort_keys=True)

# Generated at 2022-06-25 16:05:08.922472
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    expected_result = _ExtendedEncoder()
    assert extended_encoder_0 == expected_result



# Generated at 2022-06-25 16:05:12.518644
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings(record=True) as w:
        extended_encoder_0 = _ExtendedEncoder()
        assert len(w) == 0
        assert isinstance(extended_encoder_0, _ExtendedEncoder)



# Generated at 2022-06-25 16:05:14.780483
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder() # noqa

# Function to handle field override for encoder

# Generated at 2022-06-25 16:05:16.610507
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    try:
        _ExtendedEncoder()
        assert True
    except:
        assert False



# Generated at 2022-06-25 16:05:19.305646
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:05:24.105336
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()
    assert extended_encoder_1 is not None


# Generated at 2022-06-25 16:05:26.197246
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()


# Generated at 2022-06-25 16:05:27.537894
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:05:29.794777
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:06:13.816330
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    a_uuid = UUID(int=0)
    # Should be safe
    default = extended_encoder_0.default(a_uuid)
    # One of the following should fail
    default = extended_encoder_0.default(a_uuid)


# Generated at 2022-06-25 16:06:16.380489
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:06:19.900565
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_0.default(None)



# Generated at 2022-06-25 16:06:23.012808
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_1 = _ExtendedEncoder()
    assert isinstance(extended_encoder_1, json.JSONEncoder)

# Generated at 2022-06-25 16:06:30.050718
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    eq_(extended_encoder_0.__class__, _ExtendedEncoder)
    eq_(extended_encoder_0.item_separator, ',')
    eq_(extended_encoder_0.key_separator, ':')
    eq_(extended_encoder_0.sort_keys, False)
    eq_(extended_encoder_0.skipkeys, False)
    eq_(extended_encoder_0.allow_nan, True)
    eq_(extended_encoder_0.ensure_ascii, True)
    eq_(extended_encoder_0.check_circular, True)
    eq_(extended_encoder_0.indent, None)

# Generated at 2022-06-25 16:06:38.614336
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0._check_circular
    assert extended_encoder_0._default
    assert extended_encoder_0._indent
    assert extended_encoder_0._skipkeys
    assert extended_encoder_0._sort_keys
    assert extended_encoder_0.current_indent_level
    assert extended_encoder_0.item_separator
    assert extended_encoder_0.key_separator
    assert extended_encoder_0.kw



# Generated at 2022-06-25 16:06:50.249011
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert(extended_encoder_0.item_separator == ",")
    assert(extended_encoder_0.key_separator == ":")
    assert(extended_encoder_0.skipkeys == False)
    assert(extended_encoder_0.ensure_ascii == True)
    assert(extended_encoder_0.check_circular == True)
    assert(extended_encoder_0.allow_nan == True)
    assert(extended_encoder_0.sort_keys == False)
    assert(extended_encoder_0.indent == None)
    assert(extended_encoder_0.separators == (',', ':'))
    assert(extended_encoder_0.encoding == 'utf-8')

# Generated at 2022-06-25 16:06:54.121209
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_1 = _ExtendedEncoder()
    extended_encoder_1.default("")


# Generated at 2022-06-25 16:06:56.291339
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
  extended_encoder_0 = test_case_0()
  assert isinstance(extended_encoder_0, _ExtendedEncoder)

# Generated at 2022-06-25 16:06:58.491533
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    # Positive test case
    dt = datetime.now(timezone.utc)
    assert dt.timestamp() == encoder.default(dt)
    # Negative test case
    assert encoder.default(1000000) == 1000000
    return



# Generated at 2022-06-25 16:07:44.994921
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    # assert extended_encoder is not None
    if extended_encoder is None:
        raise AssertionError("Extended encoder was not initialized")
    return extended_encoder


# Generated at 2022-06-25 16:07:53.142342
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)
    # Test variable 'var_0'
    assert var_0 == '<_ExtendedEncoder object at 0x7f6e7c6f6748>'


# Generated at 2022-06-25 16:07:56.366603
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder(encoding='utf-8', ensure_ascii=True, allow_nan=True,
                     sort_keys=False, indent='utf-8', separators='utf-8',
                     default=None, skipkeys=True, allow_unsupported=False,
                     check_circular=True)



# Generated at 2022-06-25 16:07:57.853413
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:07:59.011442
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()


# Generated at 2022-06-25 16:08:00.435975
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:08:02.330677
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert extended_encoder_0.encoder is None



# Generated at 2022-06-25 16:08:10.764372
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test with a list of dicts
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_0.default([1, 2])
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        dict_0 = extended_encoder_0.default({})
    assert dict_0 == {}

    # Test with a Mapping
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_0.default({})
    # Test with a string
    extended_encoder_0 = _ExtendedEncoder()
    extended_encoder_0.default("abc")

    # Test with a datetime
    extended_encoder_0 = _ExtendedEncoder()

# Generated at 2022-06-25 16:08:11.787243
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()



# Generated at 2022-06-25 16:08:14.244568
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, json.JSONEncoder)
    assert 1 == 0


# Generated at 2022-06-25 16:10:08.849390
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test the constructor of class _ExtendedEncoder.
    print("Constructor Test Start")

    extended_encoder_0 = _ExtendedEncoder()
    test_case_0()
    print("Constructor Test End")
    return extended_encoder_0


# Generated at 2022-06-25 16:10:14.942525
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    assert isinstance(extended_encoder_0, _ExtendedEncoder)



# Generated at 2022-06-25 16:10:16.702768
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()


# Generated at 2022-06-25 16:10:19.312265
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_0 = _ExtendedEncoder()
    var_0 = extended_encoder_0.default(extended_encoder_0)


# Generated at 2022-06-25 16:10:20.215127
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Template code
    if True:
        pass
    else:
        pass



# Generated at 2022-06-25 16:10:21.499348
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()

# Generated at 2022-06-25 16:10:23.624495
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()


_field_type_cache: Mapping[Any, Any] = defaultdict(dict)



# Generated at 2022-06-25 16:10:24.711931
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:10:25.885441
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_case_0()



# Generated at 2022-06-25 16:10:27.568912
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    var_0 = _ExtendedEncoder()
