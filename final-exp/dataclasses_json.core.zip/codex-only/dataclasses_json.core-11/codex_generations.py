

# Generated at 2022-06-23 16:45:15.697451
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import dataclass

    from . import Mock

    encoder = _ExtendedEncoder()

    def check(value, expected):
        assert encoder.default(value) == expected

    check(Mock.namedtuple(x=1, y=2), {'x': 1, 'y': 2})
    check([1, 2, 3], [1, 2, 3])
    check(set([1, 2, 3]), [1, 2, 3])
    check({'x': 1, 'y': 2}, {'x': 1, 'y': 2})
    check(Mock.datetime(2019, 1, 1, 10), 1546344400.0)

# Generated at 2022-06-23 16:45:25.569128
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    assert e.default(1) == 1
    assert e.default([1, 2, 3]) == [1, 2, 3]
    assert e.default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert e.default(datetime(2020, 1, 1, 12, 0, 0)) == 1577852400.0
    assert e.default(datetime(2020, 1, 1, 12, 0, 0, tzinfo=timezone.utc)) == 1577852400.0

# Generated at 2022-06-23 16:45:33.614725
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Check that the constructor raises an AssertionError when the
    # exclude argument is not callable.
    with pytest.raises(AssertionError):
        FieldOverride(exclude=2)

    # Check that the constructor raises an AssertionError when the
    # encoder argument is not callable.
    with pytest.raises(AssertionError):
        FieldOverride(encoder=2)

    # Check that the constructor raises an AssertionError when the
    # decoder argument is not callable.
    with pytest.raises(AssertionError):
        FieldOverride(decoder=2)

    # Check that the constructor raises an AssertionError when the
    # letter_case argument is not callable.

# Generated at 2022-06-23 16:45:43.784074
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.2) == 1.2
    assert _ExtendedEncoder().default('a') == 'a'
    # case for set
    assert _ExtendedEncoder().default(set([1, 2, 3])) == [1, 2, 3]
    # case for tuple
    assert _ExtendedEncoder().default((1, 2, 3)) == [1, 2, 3]
    # case for frozenset
    assert _ExtendedEncoder().default(frozenset([1, 2, 3])) == [1, 2, 3]
    # case for dict

# Generated at 2022-06-23 16:45:55.333559
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test default values
    f1 = FieldOverride()
    assert f1.exclude is None
    assert f1.letter_case is None
    assert f1.encoder is None
    assert f1.decoder is None
    assert f1.mm_field is None

    # test non-default values
    f2 = FieldOverride(lambda x: x, str.lower, lambda x: x, lambda x: x, lambda x: x)
    assert f2.exclude(1) == 1
    assert f2.letter_case('aAa') == 'aaa'
    assert f2.encoder('aAa') == 'aAa'
    assert f2.decoder('aAa') == 'aAa'
    assert f2.mm_field('aAa') == 'aAa'


# Unit test

# Generated at 2022-06-23 16:46:04.711365
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    assert e.default(()) == []
    assert e.default((1, 2, 3)) == [1, 2, 3]
    assert e.default([]) == []
    assert e.default([1, 2, 3]) == [1, 2, 3]
    assert e.default({}) == {}
    assert e.default({"one": 1, "two": 2}) == {"one": 1, "two": 2}
    now = datetime.now()
    assert e.default(now) == now.timestamp()
    d = Decimal("123.456")
    assert e.default(d) == "123.456"
    u = UUID('550e8400-e29b-41d4-a716-446655440000')

# Generated at 2022-06-23 16:46:16.756652
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(dict(a=1)) == dict(a=1)
    assert _ExtendedEncoder().default(set([1, 2, 3])) == [1, 2, 3]
    assert _ExtendedEncoder().default(list([1, 2, 3])) == [1, 2, 3]
    assert _ExtendedEncoder().default(datetime(2020, 1, 1, 0, 0, 0)) == 1577836800.0
    assert _ExtendedEncoder().default(UUID('d1b50281-6e5f-4ab3-bafc-f673efb6ead5')) == 'd1b50281-6e5f-4ab3-bafc-f673efb6ead5'
    assert _ExtendedEncoder().default(1) == 1


# Generated at 2022-06-23 16:46:25.006905
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import date, datetime, time, timedelta
    # noinspection PyUnresolvedReferences
    from decimal import Decimal

    assert _ExtendedEncoder().default({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(None) == None

# Generated at 2022-06-23 16:46:31.049481
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(UUID('6b3f6b1a-c483-4b49-9fe9-0083b6a3e6e3')) == '"6b3f6b1a-c483-4b49-9fe9-0083b6a3e6e3"'



# Generated at 2022-06-23 16:46:38.145121
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default('')
    _ExtendedEncoder().default(0)
    _ExtendedEncoder().default(0.0)
    _ExtendedEncoder().default(None)
    _ExtendedEncoder().default(True)
    _ExtendedEncoder().default(False)
    _ExtendedEncoder().default({})
    _ExtendedEncoder().default([])
    _ExtendedEncoder().default(defaultdict())
    _ExtendedEncoder().default(UUID(int=0))
    _ExtendedEncoder().default(datetime(2020, 1, 1))
    _ExtendedEncoder().default(Decimal('-0.9'))
    _ExtendedEncoder().default(object)
    _ExtendedEncoder().default(Exception)


# noinspection PyTypeHints

# Generated at 2022-06-23 16:46:47.910525
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    class TestEnum(Enum):
        FIRST = 1
        SECOND = 2
    assert _ExtendedEncoder().default({"a": "b"}) == {"a": "b"}
    assert _ExtendedEncoder().default({"a": 3}) == {"a": 3}
    assert _ExtendedEncoder().default({5: 5}) == {5: 5}
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(datetime.now(tz=timezone.utc)) ==\
        datetime.now(tz=timezone.utc).timestamp()

# Generated at 2022-06-23 16:46:55.052610
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    # Mapping
    assert encoder.default({1: 2}) == {1: 2}
    # dict
    assert encoder.default(dict()) == dict()
    # List
    assert encoder.default([1,2,3]) == [1,2,3]
    # datetime
    now = datetime.now(timezone.utc)
    assert encoder.default(now) == now.timestamp()
    # uuid
    uuid_v = UUID('2e8f7d0d-5d55-41a5-873e-c0d488647d70')
    assert encoder.default(uuid_v) == str(uuid_v)
    # Enum

# Generated at 2022-06-23 16:47:05.847796
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.encode({1, 2, 3, 4}) == '[1, 2, 3, 4]'
    assert encoder.encode([1, 2, 3, 4]) == '[1, 2, 3, 4]'
    assert encoder.encode({"1": "1"}) == '{"1": "1"}'
    assert encoder.encode(MappingProxyType({1: 2})) == '{"1": 2}'
    assert encoder.encode(datetime(2019, 12, 31, 23, 59, 59, tzinfo=timezone.utc)) == '1577750399.0'

# Generated at 2022-06-23 16:47:07.937089
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().encode({})
    _ExtendedEncoder().encode([])
    _ExtendedEncoder().encode(2)



# Generated at 2022-06-23 16:47:15.848289
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    dt = datetime(2018, 5, 18, 21, 0, 0)
    dt_tz = dt.replace(tzinfo=timezone.utc)
    assert encoder.default({1: "a", 2: 4}) == {1: "a", 2: 4}
    assert encoder.default([1, "a", 3]) == [1, "a", 3]
    assert encoder.default(dt) == dt.timestamp()
    assert encoder.default(dt_tz) == dt.timestamp()

# Generated at 2022-06-23 16:47:24.286644
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from datetime import datetime
    from uuid import UUID
    from enum import Enum
    from decimal import Decimal

    @dataclass
    class User(DataClassJsonMixin):
        id: int
        first_name: str
        last_name: str
        email: str
        password: str
        created_at: datetime

    @dataclass
    class Address(DataClassJsonMixin):
        id: int
        user_id: str
        address: str
        created_at: datetime

    @dataclass
    class UUIDStr(DataClassJsonMixin):
        id: UUID


# Generated at 2022-06-23 16:47:29.006304
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    for arg in [
        [1, 2, 3],
        {'hello': 'world', 'some': 'value'},
        datetime(2019, 10, 7, 8, 0, 0, tzinfo=timezone.utc),
        datetime(2019, 10, 7, 8, 0, 0),
        UUID('0b0ba9ff-e942-45f4-a4b1-23c8104dd5d5'),
        cfg.LetterCase.CAMEL,
        Decimal('1.1'),
        1.0
    ]:
        assert _ExtendedEncoder().default(arg) == json.dumps(arg)



# Generated at 2022-06-23 16:47:39.161270
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import copy
    import json
    import datetime
    import uuid
    from decimal import Decimal
    from dataclasses import dataclass, asdict
    from enum import Enum

    class _ExtendedEncoder(json.JSONEncoder):
        def default(self, o):
            result = o
            if isinstance(o, datetime.datetime):
                result = o.timestamp()
            elif isinstance(o, uuid.UUID):
                result = str(o)
            else:
                result = json.JSONEncoder.default(self, o)
            return result

    class Color(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3

    @dataclass
    class Data:
        number: int
        uuid: uuid.UUID
        time: datetime

# Generated at 2022-06-23 16:47:43.090515
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(exclude=lambda x: True,
                      letter_case=None,
                      encoder=None,
                      decoder=None)
    assert f.exclude(True)
    assert f.letter_case is None
    assert f.encoder is None
    assert f.decoder is None


# Generated at 2022-06-23 16:47:44.566908
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(None, None, None) is not None

# Generated at 2022-06-23 16:47:49.242112
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.utcnow())
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}'))


# Generated at 2022-06-23 16:47:52.323287
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    foo = FieldOverride()
    assert foo.letter_case is None
    assert foo.encoder is None
    assert foo.decoder is None
    assert foo.exclude is None



# Generated at 2022-06-23 16:47:56.024186
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(TypeError):
        FieldOverride()

    FieldOverride(exclude=lambda x: True)
    FieldOverride(letter_case=lambda x: x.upper())

# Generated at 2022-06-23 16:47:59.472629
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    exclude = lambda x: x is None
    encode_json = True
    override = FieldOverride(exclude=exclude,
                             letter_case=camel_case,
                             encode_json=encode_json)

    assert override.exclude == exclude
    assert override.letter_case == camel_case
    assert override.encode_json == encode_json



# Generated at 2022-06-23 16:48:00.469436
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(None, None, None, None)

# Generated at 2022-06-23 16:48:04.993839
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"foo": 123}) == '{"foo": 123}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(Decimal("3.14")) == '"3.14"'


# noinspection PyProtectedMember

# Generated at 2022-06-23 16:48:16.555361
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    simple_data = {'a':1, 'b':2}
    assert _ExtendedEncoder().default(simple_data) == simple_data
    assert _ExtendedEncoder().default(dict()) == dict()
    assert _ExtendedEncoder().default(list()) == list()
    assert _ExtendedEncoder().default(list(range(5))) == list(range(5))
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('9c858901-8a57-4791-81fe-4c455b099bc9')) == '9c858901-8a57-4791-81fe-4c455b099bc9'
    assert _

# Generated at 2022-06-23 16:48:23.575922
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test with exclude method that takes no argument
    exclude_method = lambda x: True
    obj = FieldOverride(exclude=exclude_method)
    assert callable(obj.exclude)
    assert obj.exclude()

    # Test with exclude method that takes one argument
    def exclude_method(x, y):
        return x == y
    obj = FieldOverride(exclude=exclude_method)
    assert callable(obj.exclude)
    assert not obj.exclude(1, 2)



# Generated at 2022-06-23 16:48:32.518841
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # case 1: exclude=None, letter_case=None, encoder=None
    field_override = FieldOverride()
    assert field_override.exclude is None
    assert field_override.letter_case is None
    assert field_override.encoder is None

    # case 2: exclude=None/not None, letter_case=None/not None, encoder=
    # None/not None
    def exclude(value):
        return True

    def letter_case(name):
        return name

    def encoder(value):
        return value

    field_override = FieldOverride(exclude=exclude, letter_case=letter_case,
                                   encoder=encoder)
    assert field_override.exclude == exclude
    assert field_override.letter_case == letter_case
    assert field_

# Generated at 2022-06-23 16:48:41.730270
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """Test constructor of class FieldOverride"""
    decoder = lambda x: x
    encoder = lambda x: x
    exclude = lambda x: x
    letter_case = lambda x: x
    field_override = FieldOverride(decoder, encoder, exclude, letter_case)
    assert field_override.decoder == decoder
    assert field_override.encoder == encoder
    assert field_override.exclude == exclude
    assert field_override.letter_case == letter_case


# Unit tests for _user_overrides_or_exts

# Generated at 2022-06-23 16:48:49.727792
# Unit test for constructor of class FieldOverride
def test_FieldOverride():

    with pytest.raises(TypeError):
        FieldOverride()
    with pytest.raises(TypeError):
        FieldOverride(1, 2, 3)
    with pytest.raises(TypeError):
        FieldOverride("a", "b", "c", "d")

    # No optional parameter given
    assert FieldOverride("a") == FieldOverride("a", exclude=None,
                                               letter_case=None,
                                               encoder=None,
                                               decoder=None)
    # All optional parameters given

# Generated at 2022-06-23 16:48:54.662756
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(decimal.Decimal('1')) == '1'

# Generated at 2022-06-23 16:49:01.839853
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride()
    assert f.exclude is None
    assert f.encoder is None
    assert f.decoder is None
    assert f.letter_case is None
    assert f.mm_field is None
    assert f.mm_field_kwargs is None

    def my_exclude(x):
        return x

    def my_letter_case(x):
        return x

    def my_encoder(x):
        return x

    def my_decoder(x):
        return x

    f = FieldOverride(exclude=my_exclude, letter_case=my_letter_case,
                      encoder=my_encoder, decoder=my_decoder,
                      mm_field=("field_name", {}))
    assert f.exclude is my_exclude

# Generated at 2022-06-23 16:49:09.456650
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    override = FieldOverride(exclude=lambda x: True,
                             decoder=None,
                             letter_case=None,
                             encoder=None)

    assert not override.exclude(None)
    override = FieldOverride(exclude=lambda x: False,
                             decoder=None,
                             letter_case=None,
                             encoder=None)
    assert override.exclude(None)
    override = FieldOverride(exclude=None,
                             decoder=lambda x: x + 1,
                             letter_case=None,
                             encoder=None)
    assert override.decoder(2) == 3
    override = FieldOverride(exclude=None,
                             decoder=None,
                             letter_case=lambda x: x.upper(),
                             encoder=None)

# Generated at 2022-06-23 16:49:14.185165
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class Foo:
        def f(x):
            return x
    
    foo = Foo()
    bar = FieldOverride(Foo.f, None, None, None)
    assert bar.exclude(foo) == foo

    assert bar.letter_case('aA') == 'aA'
    assert bar.encoder(foo) == foo
    assert bar.decoder(foo) == foo

# Generated at 2022-06-23 16:49:18.848169
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(exclude=None,
                                   encoder=None,
                                   decoder=None,
                                   letter_case=None,
                                   mm_field=None)
    assert field_override.exclude is None
    assert field_override.encoder is None
    assert field_override.decoder is None
    assert field_override.letter_case is None
    assert field_override.mm_field is None



# Generated at 2022-06-23 16:49:24.266307
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    def assertEqual(lhs, rhs):
        assert lhs == rhs

    assertEqual(_ExtendedEncoder(sort_keys=False,
                                  indent=None,
                                  separators=None,
                                  default=None,
                                  ensure_ascii=True).default(range(10)),
                 range(10))
    assertEqual(_ExtendedEncoder(sort_keys=False,
                                  indent=None,
                                  separators=None,
                                  default=None,
                                  ensure_ascii=True).default(range(10)),
                 list(range(10)))

# Generated at 2022-06-23 16:49:29.306383
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = datetime.utcnow().replace(tzinfo=timezone.utc)
    assert _ExtendedEncoder().default(o) == o.timestamp()

    o = UUID('00000000-0000-0000-0000-000000000000')
    assert _ExtendedEncoder().default(o) == '00000000-0000-0000-0000-000000000000'

_mm_fields_cache: Mapping[Any, Mapping[str, FieldOverride]] = {}

_default_predictor = _ExtendedEncoder().default



# Generated at 2022-06-23 16:49:38.441135
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from decimal import Decimal
    from uuid import UUID
    from datetime import datetime
    encode = _ExtendedEncoder().encode
    assert encode({1:2, 3:4}) == '{"1": 2, "3": 4}'
    assert encode([1, 2, 3, 4]) == '[1, 2, 3, 4]'
    assert encode(UUID(int=1)) == '"00000000-0000-0000-0000-000000000001"'
    assert encode(datetime.fromtimestamp(1, timezone.utc)) == '1'
    assert encode(Decimal('1.1')) == '"1.1"'

# Generated at 2022-06-23 16:49:48.304572
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    class TestType(object):
        def __init__(self, v):
            self.v = v

        def __repr__(self):
            return f'TestType({repr(self.v)})'

        def __eq__(self, other):
            if not isinstance(other, TestType):
                return NotImplemented
            return self.__dict__ == other.__dict__

        def __lt__(self, other):
            if not isinstance(other, TestType):
                return NotImplemented
            return self.__dict__ < other.__dict__

    test_datetime = datetime(2020,1,2,3,4,5,6,timezone.utc)

# Generated at 2022-06-23 16:49:52.023179
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Coverage to make sure it inherits from JSONEncoder
    encoder = _ExtendedEncoder()
    assert_equal(encoder.default('test'), 'test')



# Generated at 2022-06-23 16:50:01.141779
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder(sort_keys=True, indent=4)
    decoder = json.JSONDecoder()

# Generated at 2022-06-23 16:50:10.111569
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 'simple', 'list']) == '[1, "simple", "list"]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode(datetime.now(tz=timezone.utc)) == \
           str(datetime.now(tz=timezone.utc).timestamp())
    assert _ExtendedEncoder().encode(UUID('A0EEBC99-9C0B-4EF8-BB6D-6BB9BD380A11')) == \
           '"A0EEBC99-9C0B-4EF8-BB6D-6BB9BD380A11"'

# Generated at 2022-06-23 16:50:11.967548
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(exclude="excluder", encoder="encode", decoder="decode",
                       letter_case="letter_case")
    print(fo)

# Generated at 2022-06-23 16:50:20.668590
# Unit test for constructor of class FieldOverride
def test_FieldOverride():

    letter_case = snakecase
    # Configure a FieldOverride
    fo = FieldOverride(True, letter_case, False, None, None, None)
    # Setting the exclude function directly
    fo.exclude = False
    # Setting the include function directly
    fo.include = True
    # Setting the letter_case function directly
    fo.letter_case = None
    # Setting the mm_field directly
    fo.mm_field = True
    # Setting the encoder directly
    fo.encoder = letter_case
    # Setting the decoder directly
    fo.decoder = False
    return fo


# Generated at 2022-06-23 16:50:25.150063
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder(indent=4).encode([{'a': datetime(2019, 7, 3, 10, 0, 0)}]) == '[\n    {\n        "a": 1562119200.0\n    }\n]'


# Generated at 2022-06-23 16:50:34.875308
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Normal case
    override = FieldOverride()
    assert override.letter_case is None
    assert override.exclude is None
    assert override.encoder is None
    assert override.decoder is None

    def encoder(obj):
        return obj

    def decoder(obj):
        return obj

    def exclude(obj):
        return True

    override = FieldOverride(letter_case=str.upper, exclude=exclude,
                             encoder=encoder, decoder=decoder)
    assert override.letter_case == str.upper
    assert override.exclude == exclude
    assert override.encoder == encoder
    assert override.decoder == decoder

    # Exceptions
    with pytest.raises(AssertionError) as excinfo:
        override = FieldOverride(exclude='hello')

# Generated at 2022-06-23 16:50:38.722515
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default(None) is None



# Generated at 2022-06-23 16:50:45.359406
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # setup
    kwargs = {"exclude": None, "letter_case": str.lower, "encoder": lambda x: x, "decoder": lambda x: x}
    f = FieldOverride(**kwargs)
    # test
    assert f.exclude == None
    assert f.letter_case == str.lower
    assert f.encoder == kwargs["encoder"]
    assert f.decoder == kwargs["decoder"]


# Generated at 2022-06-23 16:50:55.826805
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    data = [
        {'list': ['a', 'b', 'c']},
        {'dict': {'a': 1, 'b': 2, 'c': 3}},
        {'datetime': datetime.now(tz=timezone.utc)},
        {'uuid': UUID('c9bf9e57-1685-4c89-b523-f55f2eeb7f0e')},
        {'decimal': Decimal('1234.5678')},
        {'enum': cfg.LetterCase.SNAKE_CASE},
    ]
    for d in data:
        json_str = json.dumps(d, cls=_ExtendedEncoder)
        result = json.loads(json_str)

# Generated at 2022-06-23 16:51:01.877054
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    """
    Testing JsonEncoder.default.
    """
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.1) == 1.1
    assert _ExtendedEncoder().default("abc") == "abc"
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()

# Generated at 2022-06-23 16:51:14.664312
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps({}, cls=_ExtendedEncoder) == '{}'
    assert json.dumps([], cls=_ExtendedEncoder) == '[]'
    assert json.dumps("", cls=_ExtendedEncoder) == '""'
    assert json.dumps(0, cls=_ExtendedEncoder) == '0'
    assert json.dumps(0.0, cls=_ExtendedEncoder) == '0.0'
    assert json.dumps(None, cls=_ExtendedEncoder) == 'null'
    assert json.dumps(True, cls=_ExtendedEncoder) == 'true'
    # Test for datetime.timestamp()

# Generated at 2022-06-23 16:51:16.602298
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-23 16:51:25.667129
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(exclude=lambda x: False,
                      letter_case=None,
                      encoder=lambda x: x,
                      decoder=lambda x: x)
    assert f.exclude(1) == False
    """
    assert f.letter_case("lower_cased") == "lower_cased"
    assert f.encoder(1) == 1
    assert f.decoder(1) == 1
    """


# Generated at 2022-06-23 16:51:26.286540
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    decoder = _ExtendedEncoder()



# Generated at 2022-06-23 16:51:29.891921
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(encoder=Json, exclude=False, letter_case=str.upper)
    assert field_override.encoder == Json
    assert field_override.exclude == False
    assert field_override.letter_case == str.upper
    # Test case for exception
    field_override = FieldOverride(encoder='WillError')


# Generated at 2022-06-23 16:51:39.235787
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1,2,3]) == [1,2,3]
    assert encoder.default(set([1,2,3])) == [1,2,3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime(2020, 1, 1, 12, 0, 0, tzinfo=timezone.utc)) == 1577836800
    assert encoder.default(UUID('0f8fad5b-d9cb-469f-a165-70867728950e')) == '0f8fad5b-d9cb-469f-a165-70867728950e'

# Generated at 2022-06-23 16:51:49.287532
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(
        [
            {'a': 1, 'b': 2},
            'cde',
            datetime(1970, 1, 1, tzinfo=timezone.utc),
            UUID('01234567-89ab-cdef-0123-456789abcdef')
        ]
    ) == '[{"a":1,"b":2},"cde",0.0,"01234567-89ab-cdef-0123-456789abcdef"]'


# noinspection PyProtectedMember

# Generated at 2022-06-23 16:51:56.274847
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test Case 1:
    #   - All fields are set to None
    field_override_1 = FieldOverride()
    assert field_override_1.exclude is None
    assert field_override_1.encoder is None
    assert field_override_1.decoder is None
    assert field_override_1.letter_case is None

    # Test Case 2:
    #   - All fields are set to non-None values
    field_override_2 = FieldOverride(exclude=None,
                                     encoder=None,
                                     decoder=None,
                                     letter_case=None)
    assert field_override_2.exclude is None
    assert field_override_2.encoder is None
    assert field_override_2.decoder is None
    assert field_override_

# Generated at 2022-06-23 16:52:05.882534
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == []
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime.now()) == datetime.now().timestamp()
    assert encoder.default(UUID('7d865e9b-7b91-4e49-b8a8-9e9b9a9e1f30')) == '7d865e9b-7b91-4e49-b8a8-9e9b9a9e1f30'
    assert encoder.default(cfg.MISSING_ERROR) == 'MISSING_ERROR'

# Generated at 2022-06-23 16:52:15.406136
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('aaf30451-f2c2-4dea-8bbe-f11b664f2e77')) == '"aaf30451-f2c2-4dea-8bbe-f11b664f2e77"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'
    assert _ExtendedEncoder().encode(None) == 'null'

# Generated at 2022-06-23 16:52:17.542349
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(object()) == MISSING



# Generated at 2022-06-23 16:52:26.826497
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Unit test for the constructor of class FieldOverride
    """
    FieldOverride(True, lambda x: x, None, lambda x: x)
    try:
        FieldOverride(True, None, lambda x: x, lambda x: x)
    except Exception:
        pass
    try:
        FieldOverride(True, lambda x: x, None, None)
    except Exception as error:
        return
    raise Exception(f"FieldOverride did not fail when it should have")



# Generated at 2022-06-23 16:52:32.665367
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(
        datetime(2018, 1, 1, tzinfo=timezone.utc)) == '1514764800.0'
    assert _ExtendedEncoder().encode(UUID('70f5c28ffdce415bbe350d6a8b6c9b3d')) == '"70f5c28f-fdce-415b-be35-0d6a8b6c9b3d"'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'



# Generated at 2022-06-23 16:52:42.070982
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # 1
    assert _ExtendedEncoder().default({1: 1}) == {1: 1}
    # 2
    c = datetime.now()
    assert _ExtendedEncoder().default(c) == c.timestamp()
    # 3
    c = timezone.utc
    assert _ExtendedEncoder().default(c) == 'UTC'
    # 4
    c = UUID('f6a0e6d7-6e27-4a8b-9beb-a1b6a9a6e3c3')
    assert _ExtendedEncoder().default(c) == 'f6a0e6d7-6e27-4a8b-9beb-a1b6a9a6e3c3'
    # 5
    c = Enum('a', 'b')


# Generated at 2022-06-23 16:52:44.641558
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    v = [1, 2, 3]
    assert _ExtendedEncoder().default(v) == v



# Generated at 2022-06-23 16:52:53.128625
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    expected_default = "expected_default"
    expected_letter_case = "expected_letter_case"
    expected_exclude = "expected_exclude"
    expected_encoder = "expected_encoder"
    expected_decoder = "expected_decoder"

    f = FieldOverride(default=expected_default,
                      letter_case=expected_letter_case,
                      exclude=expected_exclude,
                      encoder=expected_encoder,
                      decoder=expected_decoder)
    assert f == (expected_default, expected_letter_case, expected_exclude,
                 expected_encoder, expected_decoder)
    assert f.default == expected_default
    assert f.letter_case == expected_letter_case
    assert f.exclude == expected_exclude
    assert f.encoder == expected_encoder

# Generated at 2022-06-23 16:53:02.832151
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = _ExtendedEncoder().default
    assert o(17) == 17
    assert o('test') == 'test'
    assert o(1.5) == 1.5
    assert o(True) == True
    assert o(None) == None
    assert o(UUID('6e8bc430-9c3a-11d9-9669-0800200c9a66')) == '6e8bc430-9c3a-11d9-9669-0800200c9a66'

    assert o(datetime(2020, 1, 1)) == 1577836800.0
    assert o(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800.0

    assert o(Enum('Foo', 'foo')) == 'foo'
    assert o

# Generated at 2022-06-23 16:53:04.321673
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(TypeError):
        FieldOverride()

# Generated at 2022-06-23 16:53:15.046076
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'a': 1}) == {'a': 1}
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc)) == 0.0
    assert _ExtendedEncoder().default(UUID('6c0f6d22-a9f9-42f5-9ef8-80eab17aeefb')) == '6c0f6d22-a9f9-42f5-9ef8-80eab17aeefb'
    assert _ExtendedEncoder().default(Decimal('1.2')) == '1.2'


# Generated at 2022-06-23 16:53:18.482655
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(MISSING) == 'null'
    assert _ExtendedEncoder().encode(None) == 'null'



# Generated at 2022-06-23 16:53:21.048754
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    case = FieldOverride(None, None, None, None, None)
    assert case


# Generated at 2022-06-23 16:53:31.666262
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default({1:2, 3:4}) == {1:2, 3:4}
    assert _ExtendedEncoder().default([1,2,3,4]) == [1,2,3,4]
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.1) == 1.1
    assert _ExtendedEncoder().default(True) == True
    assert _

# Generated at 2022-06-23 16:53:41.753104
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    # datetime:
    dt = datetime(1970, 1, 1, 0, 0, 1, 0, tzinfo=timezone.utc)
    assert e.default(dt) == 1
    # Decimal:
    assert e.default(Decimal(1)) == "1"
    # UUID:
    uuid = UUID('2a283a4a-a4b4-46a8-a06c-b7e1e86f64b7')
    assert e.default(uuid) == '2a283a4a-a4b4-46a8-a06c-b7e1e86f64b7'
    # enum:
    enum = cfg.LetterCase.CAMEL

# Generated at 2022-06-23 16:53:46.402270
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(np.ndarray([])) is not None
    assert _ExtendedEncoder().default(np.int32()) is not None
    assert _ExtendedEncoder().default(np.int64()) is not None
    assert _ExtendedEncoder().default(np.float()) is not None
    assert _ExtendedEncoder().default(np.double()) is not None


# Generated at 2022-06-23 16:53:57.682252
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default({1: 2}) == {1: 2}
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default(tuple([1, 2])) == [1, 2]
    assert encoder.default({1, 2}) == [1, 2]
    assert encoder.default(frozenset({1, 2})) == [1, 2]
    now = datetime.now(timezone.utc)
    assert encoder.default(now) == now.timestamp()

# Generated at 2022-06-23 16:54:05.174851
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default('string') == 'string'
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default(True) == True
    assert encoder.default(None) == None
    assert encoder.default(datetime.utcnow()) == datetime.utcnow().timestamp()
    assert encoder.default(UUID('4e95c7b0-a5ef-4baf-af5e-35f26afb2084')) == '4e95c7b0-a5ef-4baf-af5e-35f26afb2084'
    assert encoder.default(set()) == []
    assert encoder.default(frozenset()) == []

# Generated at 2022-06-23 16:54:16.363898
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1, 2, 3}) == '{"1", "2", "3"}'
    assert _ExtendedEncoder().encode({1: 1, 2: 2}) == '{"1": 1, "2": 2}'
    assert _ExtendedEncoder().encode(
        datetime(1970, 1, 1, tzinfo=timezone.utc)
    ) == '0.0'
    assert _ExtendedEncoder().encode(UUID(int=0)) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().encode(Decimal(1)) == '"1"'
    assert _ExtendedEncoder().encode({'a': Decimal(1)}) == '{"a": "1"}'



# Generated at 2022-06-23 16:54:27.586358
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(True) == True
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default('Hello') == 'Hello'
    assert encoder.default([0, 1, 2]) == [0, 1, 2]
    assert encoder.default((0, '1', 2)) == [0, '1', 2]
    assert encoder.default(b'Hello') == 'SGVsbG8='
    assert encoder.default(42) == 42
    assert encoder.default(type) == '<class \'type\'>'
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert enc

# Generated at 2022-06-23 16:54:39.330477
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert (_ExtendedEncoder.default(None, []) == list())
    assert (_ExtendedEncoder.default(None, {}) == dict())
    assert (_ExtendedEncoder.default(None, datetime(2020, 1, 1)) == 1577836800)
    assert (_ExtendedEncoder.default(None, datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800)
    assert (_ExtendedEncoder.default(None, UUID("36a5c25f-90ed-46cd-8a93-765c79a0f927")) == "36a5c25f-90ed-46cd-8a93-765c79a0f927")
    assert (_ExtendedEncoder.default(None, Decimal("0.01")) == "0.01")
   

# Generated at 2022-06-23 16:54:52.261614
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    default_encoder = _ExtendedEncoder().default
    default_decoder = _ExtendedDecoder().default
    # testing FieldOverride with all possible combinations of parameters

# Generated at 2022-06-23 16:55:04.811008
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now()) == json.dumps(datetime.now(), cls=_ExtendedEncoder)
    assert _ExtendedEncoder().encode(UUID('8416e5d5-c0d1-49cb-8c3d-100e6ace4444')) == json.dumps(UUID('8416e5d5-c0d1-49cb-8c3d-100e6ace4444'), cls=_ExtendedEncoder)
    assert _ExtendedEncoder().encode(Decimal('55.5')) == json.dumps(Decimal('55.5'), cls=_ExtendedEncoder)

encoder = json.dumps
decoder = json.loads

