

# Generated at 2022-06-23 16:45:10.123495
# Unit test for method default of class _ExtendedEncoder

# Generated at 2022-06-23 16:45:15.583142
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    empty_encoder = True
    if empty_encoder is False:
        print("Correctly determined that empty_encoder is False")

    assert FieldOverride(exclude=None, encoder=None, decoder=None,
                         letter_case=None, mm_field=None) == \
           FieldOverride(exclude=lambda x: False, encoder=empty_encoder,
                         decoder=None, letter_case=None, mm_field=None)



# Generated at 2022-06-23 16:45:25.158782
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    def run_test(expected, **kwargs):
        field_override = FieldOverride(**kwargs)
        assert (field_override.letter_case == expected.letter_case
                and field_override.exclude == expected.exclude
                and field_override.encoder == expected.encoder)
    run_test(_FieldOverride(None, None, None),
             letter_case=None, exclude=None, encoder=None)
    run_test(_FieldOverride(None, None, None),
             letter_case=lambda x: x, exclude=lambda x: True, encoder=None)
    run_test(_FieldOverride(str.lower, None, None),
             letter_case=str.lower, exclude=None, encoder=None)

# Generated at 2022-06-23 16:45:31.898713
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3, 4]) == '[1, 2, 3, 4]'
    assert _ExtendedEncoder().encode({'key': 'value'}) == '{"key": "value"}'
    assert _ExtendedEncoder().encode('abc') == '"abc"'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.1) == '1.1'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(bytearray(b'data')) == '"data"'
    assert _ExtendedEncoder().encode({}) == '{}'
   

# Generated at 2022-06-23 16:45:39.350687
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    tests = [
        ('one', True, None, 'One'),
        ('one', False, None, 'one'),
        ('one', False, lambda x: x.capitalize(), 'One'),
        ('one', False, lambda x: x.upper(), 'ONE'),
        ('one', False, lambda x: x.lower(), 'one'),
        ('one', False, lambda x: x, 'one'),
    ]
    for name, exclude, letter_case, expected in tests:
        field_override = FieldOverride(exclude=exclude,
                letter_case=letter_case)
        assert field_override.letter_case(name) == expected
        assert field_override.exclude == exclude
    return True


# Generated at 2022-06-23 16:45:49.182601
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(year=2018, month=9, day=8)) == 1536331200.0
    assert _ExtendedEncoder().default(Decimal('12.34')) == '12.34'
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(dict()) == {}
    assert _ExtendedEncoder().default(UUID('d9855c92-6b45-4880-810e-6f59a6d22317')) == 'd9855c92-6b45-4880-810e-6f59a6d22317'
    assert _ExtendedEncoder().default(timezone.utc) == 'UTC'
    assert _ExtendedEncoder().default(True) == True

# Generated at 2022-06-23 16:45:57.670813
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    dt = datetime.now()
    u = UUID('0ad0e7cd-4582-11e7-a919-92ebcb67fe33')
    assert _ExtendedEncoder().default(dt) == dt.timestamp()
    assert _ExtendedEncoder().default(u) == str(u)
    assert _ExtendedEncoder().default(Decimal("10.2")) == "10.2"
    assert _ExtendedEncoder().default(Decimal("10")) == "10"
    assert _ExtendedEncoder().default(Decimal("10.0")) == "10.0"



# Generated at 2022-06-23 16:46:09.359188
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    data = {'a': 1, 'b': 2}
    assert json.dumps(data, cls=_ExtendedEncoder) == '{"a": 1, "b": 2}'

    data = [1, 2, 3]
    assert json.dumps(data, cls=_ExtendedEncoder) == '[1, 2, 3]'
    assert json.dumps(data, cls=_ExtendedEncoder) != [1, 2, 3]

    data = "{'a': 1, 'b': 2}"
    assert json.dumps(data, cls=_ExtendedEncoder) == '"{\'a\': 1, \'b\': 2}"'

    data = 1
    assert json.dumps(data, cls=_ExtendedEncoder) == '1'

    data = 1.1
   

# Generated at 2022-06-23 16:46:11.996718
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    s = _ExtendedEncoder().encode(1)
    assert s == '1'



# Generated at 2022-06-23 16:46:18.494234
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Initialize test environment
    # Initialize test subject
    sut = _ExtendedEncoder()
    # Check test subject
    assert sut._check_circular is False
    assert sut._allow_nan is False
    # Apply tests
    assert sut.default(None) is None
    assert sut.default(True) is True
    assert sut.default(False) is False
    assert sut.default(-42) == -42
    assert sut.default(42) == 42
    assert sut.default(3.14) == 3.14
    assert sut.default(float('nan')) == 'NaN'
    assert sut.default(float('inf')) == 'Infinity'
    assert sut.default(-float('inf')) == '-Infinity'

# Generated at 2022-06-23 16:46:25.985652
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import random
    from dataclasses import dataclass
    from enum import Enum
    from uuid import uuid4
    from dataclasses_json.utils import count_mappings

    encoder = _ExtendedEncoder()

    @dataclass
    class Perf:
        num: int
        dnum: Decimal
        dt: datetime
        uuid: UUID

    @dataclass
    class Data:
        num: int
        dnum: Decimal
        dt: datetime
        uuid: UUID
        str: str
        opt: Optional[int]
        perfs: List[Perf]
        enum: Enum
        enums: List[Enum]


# Generated at 2022-06-23 16:46:30.808253
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride()
    assert len(fo.mm_field) == 0
    assert len(fo.encoder) == 0
    assert len(fo.decoder) == 0
    assert len(fo.exclude) == 0
    assert len(fo.letter_case) == 0



# Generated at 2022-06-23 16:46:41.064949
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default({'a':1}) == {'a':1}
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default(datetime(2017,1,1)) == 1483228800
    assert encoder.default(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(EnumClass.a) == 'A'
    assert encoder.default(Decimal('1.23')) == '1.23'
    assert encoder.default(1.23) == 1.23


# Generated at 2022-06-23 16:46:49.822272
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default('a') == 'a'
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default({'a': 1}) == {'a': 1}
    assert _ExtendedEncoder().default({'a', 1}) == [1, 'a']
    assert _ExtendedEncoder().default(datetime(2019, 1, 1, 0, 0, 0, 0, tzinfo=timezone.utc)) == 1546300800.0

# Generated at 2022-06-23 16:47:01.917601
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    instance = _ExtendedEncoder()
    assert isinstance(instance, _ExtendedEncoder)

    test_object = [1,2,3]
    json_encoded = instance.default(test_object)
    assert isinstance(json_encoded, list)
    assert json_encoded == test_object

    test_object = {'a': 1, 'b': 2}
    json_encoded = instance.default(test_object)
    assert isinstance(json_encoded, dict)
    assert json_encoded == test_object

    test_object = Decimal('0.12345678')
    json_encoded = instance.default(test_object)
    assert isinstance(json_encoded, str)
    assert json_encoded == '0.12345678'


# Generated at 2022-06-23 16:47:07.297880
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses_json.tests.test_utils import TestClass
    td = TestClass(0, 1, 'x', True)
    result = _ExtendedEncoder().default(td)
    assert isinstance(result, dict)
    assert 'int_field' in result
    assert result['int_field'] == 0



# Generated at 2022-06-23 16:47:16.256865
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # test_return_value = 'NotInClass'
    e = _ExtendedEncoder()
    # assert e.default(test_return_value) == test_return_value
    # assert e.default(None) is None
    assert isinstance(e.default(True), bool)
    assert isinstance(e.default(1), int)
    assert isinstance(e.default('A'), str)
    assert isinstance(e.default(frozenset([1])), list)
    assert isinstance(e.default({'A': 1}), dict)
    d = datetime.now()
    assert isinstance(e.default(d), float)

# Generated at 2022-06-23 16:47:18.223129
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = [[1,2,3],[2,3,4]]
    assert _ExtendedEncoder().default(o) == o


# Generated at 2022-06-23 16:47:22.824011
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(UUID('3a7a95c3-233b-4ef8-8602-7e9e9c1a7a8d')) == '"3a7a95c3-233b-4ef8-8602-7e9e9c1a7a8d"'



# Generated at 2022-06-23 16:47:29.777463
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.loads(json.dumps(
        datetime(1979, 5, 27, 7, 14, 42, 622000, tzinfo=timezone.utc),
        cls=_ExtendedEncoder
    ))
    json.loads(json.dumps(
        UUID('84359888-90e7-11e8-8eb2-f2801f1b9fd1'),
        cls=_ExtendedEncoder
    ))
    json.loads(json.dumps(
        Decimal('3.14'),
        cls=_ExtendedEncoder
    ))


# Generated at 2022-06-23 16:47:39.689638
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert not FieldOverride().exclude
    assert FieldOverride().letter_case is None
    assert FieldOverride().encoder is None
    assert FieldOverride().decoder is None

    def test_field(m):
        return [m.field for m in inspect.stack()
                if m.function == "test_FieldOverride"]

    def exclude(value):
        return value == test_field(inspect.stack()[0])

    def letter_case(field):
        return field.upper()

    def encoder(value):
        return value.upper()

    def decoder(value):
        return value.lower()

    override = FieldOverride(exclude, letter_case, encoder, decoder)
    assert override.exclude
    assert override.letter_case
    assert override.encoder
    assert override.decoder



# Generated at 2022-06-23 16:47:47.060133
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default(UUID('8746ddc6-1b2e-11e7-93ae-92361f002671'))
    _ExtendedEncoder().default(datetime.now(timezone.utc))
    _ExtendedEncoder().default({'a': 1, 'b': 2})
    _ExtendedEncoder().default([1, 2, 3])
    _ExtendedEncoder().default(Decimal('3.1415'))
    exc = json.JSONEncoder()
    exc.default(Decimal('3.1415'))



# Generated at 2022-06-23 16:47:56.613632
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.encode({'a': [1, 2, 3]}) == '{"a": [1, 2, 3]}'
    assert encoder.encode({'a': {'x': 1, 'y': 2, 'z': 3}}) == '{"a": {"x": 1, "y": 2, "z": 3}}'
    assert encoder.encode(['a', 'b', 'c']) == '["a", "b", "c"]'
    assert encoder.encode(set([1, 2, 3])) == '[1, 2, 3]'
    assert encoder.encode(frozenset([1, 2, 3])) == '[1, 2, 3]'

# Generated at 2022-06-23 16:48:07.072180
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(None, None, None, None)
    assert FieldOverride(None, None, None, None).field_name is None
    assert FieldOverride(None, None, None, None).exclude is None
    assert FieldOverride(None, None, None, None).letter_case is None
    assert FieldOverride(None, None, None, None).encoder is None
    assert FieldOverride(None, None, None, None).decoder is None
    assert FieldOverride(None, None, None, None).mm_field is None
    assert FieldOverride(None, None, None, None).mm_field_kwargs is None
    assert FieldOverride(None, None, None, None).mm_field_meta is None
    assert FieldOverride(None, None, None, None).mm_schema_class is None

# Generated at 2022-06-23 16:48:10.514706
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert str(FieldOverride(True, 'abc', lambda x: x, lambda x: x)) == \
        "FieldOverride(exclude=True, letter_case='abc', encoder=<lambda>, decoder=<lambda>)"



# Generated at 2022-06-23 16:48:21.584102
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    from marshmallow.fields import UUID, Email
    from decimal import Decimal
    from uuid import uuid4
    from datetime import datetime

    def _decode_email(value):
        return value

    def _encode_decimal(v):
        return str(v)

    cls = new_class('cls', (object,), {
        'decimal_field': FieldOverride(
            mm_field=Decimal,
            encoder=_encode_decimal,
            exclude=lambda v: None),
        'uuid_field': FieldOverride(
            mm_field=UUID),
        'email_field': FieldOverride(
            mm_field=Email,
            decoder=_decode_email),
        'datetime_field': FieldOverride(
            mm_field=datetime),
    })

# Generated at 2022-06-23 16:48:26.666452
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps([1, 2], cls=_ExtendedEncoder)
    json.dumps({'a': 1, 'b': 2}, cls=_ExtendedEncoder)
    json.dumps(datetime.now(), cls=_ExtendedEncoder)
    json.dumps(u'\u2713', cls=_ExtendedEncoder)
    json.dumps(b'\xf0', cls=_ExtendedEncoder)
    json.dumps(2.5, cls=_ExtendedEncoder)
    json.dumps(None, cls=_ExtendedEncoder)
    json.dumps(True, cls=_ExtendedEncoder)
    json.dumps(False, cls=_ExtendedEncoder)



# Generated at 2022-06-23 16:48:33.537562
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda x: x
    decoder = lambda x: x
    exclude = lambda x: False

    try:
        FieldOverride(letter_case=None,
                      encoder=encoder,
                      decoder=decoder,
                      exclude=exclude)
        assert True
    except ImportError as e:
        assert False

    try:
        FieldOverride(letter_case=None,
                      encoder=encoder,
                      decoder=decoder,
                      exclude=exclude,
                      missing="Unknown")
        assert False
    except NotImplementedError as e:
        assert True

# Generated at 2022-06-23 16:48:43.568863
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings(record=True) as w:
        encoder = _ExtendedEncoder()
        no_default = {
            list: list,
            tuple: list,
            dict: dict,
            datetime: float,
            UUID: str,
            Enum: int,
            Decimal: str,
            str: str,
            int: int,
            float: float,
            bool: bool,
            type(None): type(None)
        }
        for t in no_default:
            expected = no_default[t]
            assert isinstance(encoder.default(t()), expected)
        assert not w



# Generated at 2022-06-23 16:48:44.730496
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-23 16:48:52.736426
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(None, None, None)
    assert fo.encoder is None
    assert fo.decoder is None
    assert fo.letter_case is None
    assert fo.exclude is None

    def encoder(x):
        return x

    def decoder(x):
        return x

    def lc(x):
        return x

    def exclude(x):
        return False

    fo = FieldOverride(lc, encoder, decoder, exclude)
    assert fo.encoder == encoder
    assert fo.decoder == decoder
    assert fo.letter_case == lc
    assert fo.exclude == exclude



# Generated at 2022-06-23 16:48:54.650527
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(dict()) is not None



# Generated at 2022-06-23 16:49:03.970056
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test accessor
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str

    field_override = FieldOverride()
    assert field_override.decoder is None
    assert field_override.encoder is None
    assert field_override.exclude is None
    assert field_override.letter_case is None

    # test init
    encoder = lambda x : x
    decoder = lambda x : x
    exclude = lambda x: True
    enc_dec = FieldOverride(encoder=encoder, decoder=decoder)
    assert enc_dec.encoder == encoder
    assert enc_dec.decoder == decoder
    assert enc_dec.exclude == None
    assert enc_

# Generated at 2022-06-23 16:49:14.266312
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def assert_result(x: Any, result: Json) -> None:
        assert json.dumps(x, cls=_ExtendedEncoder) == json.dumps(result)
    assert_result(dict(abc=1), dict(abc=1))
    assert_result([1, 2], [1, 2])
    assert_result(datetime(year=2019, month=4, day=1,
                          hour=23, minute=59, second=1,
                          tzinfo=timezone.utc),
                  datetime(year=2019, month=4, day=1,
                          hour=23, minute=59, second=1,
                          tzinfo=timezone.utc).timestamp())

# Generated at 2022-06-23 16:49:21.338645
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert json.dumps([1], cls=_ExtendedEncoder) == '[1]'
    assert json.dumps({'1': 'a'}, sort_keys=True, cls=_ExtendedEncoder) == '{"1": "a"}'
    assert json.dumps(datetime.now(timezone.utc), cls=_ExtendedEncoder)
    assert json.dumps(UUID('00000000-0000-0000-0000-000000000000'), cls=_ExtendedEncoder)
    assert json.dumps(Decimal('100.000'), cls=_ExtendedEncoder)
    assert json.dumps('a', cls=_ExtendedEncoder) == '"a"'
    assert json.dumps(99, cls=_ExtendedEncoder) == '99'

# Generated at 2022-06-23 16:49:30.227430
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode((1, 2, 3)) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"a": "b"}) == '{"a": "b"}'
    assert _ExtendedEncoder().encode({"a": "b"}) == '{"a": "b"}'
    assert _ExtendedEncoder().encode({"a": "b", (1, 2): [3, 4], 5: (6, 7)}) == '{"a": "b", "1, 2": [3, 4], "5": [6, 7]}'
    assert _ExtendedEncoder().encode(datetime(2011, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == '1293840000.0'
    assert _ExtendedEncoder().en

# Generated at 2022-06-23 16:49:40.636074
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    optional_type_int = Optional[int]
    optional_type_str = Optional[str]
    some_type = typing.List[Optional[int]]

    # list of tuples of each case with input and output

# Generated at 2022-06-23 16:49:44.377179
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = field(metadata={'dataclasses_json': {'letter_case': camelize}})
    fov = FieldOverride(letter_case=camelize, exclude=None)
    assert f.name in fov


# Generated at 2022-06-23 16:49:48.397650
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # was failing with AttributeError on case
    # assert isinstance(confs[k], collections.Callable)
    # and AttributeError: 'list' object has no attribute '__call__'
    # no idea if that is still failing
    pass



# Generated at 2022-06-23 16:49:59.744365
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(dict(a=1, b=2)) == {"a": 1, "b": 2}
    assert _ExtendedEncoder().default(list(range(3))) == [0, 1, 2]
    assert _ExtendedEncoder().default(datetime(2001, 2, 3, 4, 5, 6, 7)) == 982307706.0007
    assert _ExtendedEncoder().default(UUID('4a9eec4c-8edb-4a2c-9b99-a7d8a1e14b72')) == '4a9eec4c-8edb-4a2c-9b99-a7d8a1e14b72'
    assert _ExtendedEncoder().default(Decimal('3.14')) == '3.14'


# Generated at 2022-06-23 16:50:08.274513
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    def assert_equal(obj, expected):
        actual = _ExtendedEncoder().default(obj)
        assert actual == expected

    assert_equal(1, 1)
    assert_equal(dict(x=1), {'x': 1})
    assert_equal((1,), [1])
    assert_equal([1], [1])
    assert_equal({'name': 'John'}, {'name': 'John'})
    assert_equal({'name': 'John', 'age': 20}, {'name': 'John', 'age': 20})
    assert_equal(datetime.now(timezone.utc), _ExtendedEncoder().default(datetime.now(timezone.utc)))



# Generated at 2022-06-23 16:50:19.192537
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(True) is True
    assert isinstance(_ExtendedEncoder().default({1: "a"}), dict)
    assert _ExtendedEncoder().default({1: "a"}) == {"1": "a"}
    assert _ExtendedEncoder().default([1, "a"]) == [1, "a"]
    assert isinstance(_ExtendedEncoder().default(datetime.now()), float)
    assert isinstance(_ExtendedEncoder().default(UUID('4b0c4b37-f480-4f84-98b1-97c5a5a5a5a5')), str)
    assert isinstance(_ExtendedEncoder().default(Decimal('1.5')), str)

# Generated at 2022-06-23 16:50:19.802604
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    pass

# Generated at 2022-06-23 16:50:27.837366
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    letter_case = lambda x: x
    encoder = lambda x: x
    decoder = lambda x: x
    exclude = lambda x: x

    FieldOverride(letter_case, encoder, decoder, exclude)
    FieldOverride(letter_case, encoder, decoder, exclude, include)
    FieldOverride(letter_case, encoder, decoder, exclude, include,
                  mm_fields)



# Generated at 2022-06-23 16:50:38.049325
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride()
    assert None == field_override.exclude
    assert None == field_override.encoder
    assert None == field_override.decoder
    assert None == field_override.letter_case
    assert None == field_override.mm_fields
    assert None == field_override.mm_field

    field_override = FieldOverride(
        exclude=lambda x: True,
        encoder=lambda x: x,
        decoder=lambda x: x,
        letter_case=lambda x: x,
        mm_fields=lambda x: x,
        mm_field=lambda x: x)
    assert isinstance(field_override.exclude, collections.abc.Callable)
    assert isinstance(field_override.encoder, collections.abc.Callable)


# Generated at 2022-06-23 16:50:48.367985
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test with explicit keys
    fo1 = FieldOverride(True, "a", "b", "c")
    assert fo1.exclude(None)
    assert fo1.letter_case("test") == "test"
    assert fo1.encoder("test") == "test"
    assert fo1.decoder("test") == "test"
    assert fo1.mm_field is None
    # Test with implicit keys
    fo2 = FieldOverride(exclude=True, letter_case="a", encoder="b",
                        decoder="c", mm_field="d")
    assert fo2.exclude(None)
    assert fo2.letter_case("test") == "test"
    assert fo2.encoder("test") == "test"
    assert fo2.decoder("test") == "test"
    assert fo2

# Generated at 2022-06-23 16:51:00.337902
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert(_ExtendedEncoder().default(True) == True)
    assert(_ExtendedEncoder().default(1) == 1)
    assert(_ExtendedEncoder().default(1.0) == 1.0)
    assert(_ExtendedEncoder().default('a') == 'a')
    assert(_ExtendedEncoder().default(datetime(2020, 1, 1, 0, 0, 0)) == 1577836800.0)
    assert(_ExtendedEncoder().default(Decimal(1.0)) == '1')
    assert(_ExtendedEncoder().default(UUID('8b13789a-4637-4828-b453-db06c8f58829')) == '8b13789a-4637-4828-b453-db06c8f58829')

# Generated at 2022-06-23 16:51:07.555311
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    class Foo:
        def __init__(self, a, b=MISSING, int_val=0, float_val=0.0, string_val="",
                     list_val=[], dict_val={}):
            self.a = a
            self.b = b
            self.int_val = int_val
            self.float_val = float_val
            self.string_val = string_val
            self.list_val = list_val
            self.dict_val = dict_val

        def __str__(self):
            return "Foo"

        def __repr__(self):
            return "Foo"

    class Bar:
        def __init__(self, a, b=MISSING):
            self.a = a
            self.b = b


# Generated at 2022-06-23 16:51:18.163203
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_str = json.dumps([1, 2, 3], cls=_ExtendedEncoder)
    assert "[1, 2, 3]" == json_str

    json_str = json.dumps({'foo': 1, 'bar': 2}, cls=_ExtendedEncoder)
    assert '{"bar": 2, "foo": 1}' == json_str

    json_str = json.dumps(True, cls=_ExtendedEncoder)
    assert "true" == json_str

    json_str = json.dumps(Decimal("1.2"), cls=_ExtendedEncoder)
    assert '"1.2"' == json_str

    json_str = json.dumps({'foo': Decimal('1.2')}, cls=_ExtendedEncoder)

# Generated at 2022-06-23 16:51:28.036195
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder is not None
    assert encoder.default([]) == []
    assert encoder.default({}) == {}
    assert encoder.default(datetime.now()) is not None
    assert encoder.default(UUID('b0a22f66-9c9b-4430-9b09-2b8de0e6849b')) == 'b0a22f66-9c9b-4430-9b09-2b8de0e6849b'
    assert encoder.default(Decimal(10.9)) == '10.9'



# Generated at 2022-06-23 16:51:32.277270
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(None, None, None) == FieldOverride(
        None, None, None), "should be able to create instance of FieldOverride"


# Generated at 2022-06-23 16:51:41.498557
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    import unittest
    from dataclasses import dataclass

    @dataclass
    class MyData:
        x: int = 5
        y: str = 'foo'
        z: bool = False

    kwargs1 = {'letter_case': camel_case,
               'exclude': lambda v: v == 5}
    kwargs2 = {'letter_case': None,
               'exclude': lambda v: v == 'foo'}
    f_let_case1 = FieldOverride(**kwargs1)
    f_let_case2 = FieldOverride(**kwargs2)

    # Test that the value passed to constructor is correct
    assert f_let_case1.letter_case == camel_case
    assert f_let_case1.exclude(5) == True
    assert f_let_case1

# Generated at 2022-06-23 16:51:52.769450
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from types import SimpleNamespace
    from datetime import datetime


# Generated at 2022-06-23 16:52:04.001285
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    #basic test
    override = FieldOverride(exclude=lambda x: True,
                             letter_case=_to_snake,
                             encoder=lambda x: x * 3,
                             decoder=lambda x: int(x))
    assert override.exclude(1)
    assert override.letter_case('SomeFieldName') == 'some_field_name'
    assert override.encoder(1) == 3
    assert override.decoder(1) == 1
    # test override with None
    override = FieldOverride(exclude=None,
                             letter_case=None,
                             encoder=None,
                             decoder=None)
    assert not override.exclude
    assert override.letter_case
    assert not override.encoder
    assert not override.decoder
    # test override with None at some positions

# Generated at 2022-06-23 16:52:12.909646
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    assert e.default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert e.default([1, 2, 3]) == [1, 2, 3]
    assert e.default(datetime.now()) == datetime.now().timestamp()
    assert e.default(UUID('da2b2f36-a22a-48b0-a9e0-b9d3a235a373')) == 'da2b2f36-a22a-48b0-a9e0-b9d3a235a373'
    assert e.default(Decimal('123.45')) == '123.45'



# Generated at 2022-06-23 16:52:16.375793
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    r = FieldOverride
    assert r(exclude=None,
             encoder=None,
             decoder=None,
             letter_case=None) == r()


# Unit tests: _apply_field_overrides

# Generated at 2022-06-23 16:52:25.917939
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now()) is not None
    assert _ExtendedEncoder().default(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'


# Generated at 2022-06-23 16:52:29.584770
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps({'a': 1, 'b': 2}, cls=_ExtendedEncoder) == '{"a": 1, "b": 2}'


# Generated at 2022-06-23 16:52:39.566826
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict(a=1, b=2)) == '{"b": 2, "a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(set([1, 2, 3])) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == json.dumps(datetime.now(timezone.utc).timestamp())

# Generated at 2022-06-23 16:52:46.920865
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

    assert encoder.default({}) == {}
    assert encoder.default([]) == []
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default(datetime.now(tz=timezone.utc)) == datetime.now(tz=timezone.utc).timestamp()
    assert encoder.default(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('0.01')) == '0.01'

# Generated at 2022-06-23 16:53:00.357524
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """Test for the constructor of the _ExtendedEncoder class."""
    encoder = _ExtendedEncoder().default(None)
    assert encoder is None
    encoder = _ExtendedEncoder().default(1)
    assert encoder == 1
    encoder = _ExtendedEncoder().default(False)
    assert encoder == False
    encoder = _ExtendedEncoder().default('1')
    assert encoder == '1'
    encoder = _ExtendedEncoder().default(())
    assert encoder == ()
    encoder = _ExtendedEncoder().default([])
    assert encoder == []
    encoder = _ExtendedEncoder().default({})
    assert encoder == {}
    encoder = _ExtendedEncoder().default({"HelloWorld"})
    assert encoder == {"HelloWorld"}
   

# Generated at 2022-06-23 16:53:11.624715
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Tests the constructor of FieldOverride. This should be tested in case
    the ordering of the class attributes is changed.
    """
    field_override = FieldOverride(exclude=lambda x: True,
                                   encoder=lambda x: x+'1',
                                   decoder=lambda x: int(x),
                                   letter_case=lambda x: x.lower())
    assert isinstance(field_override.letter_case, Callable)
    assert isinstance(field_override.encoder, Callable)
    assert isinstance(field_override.decoder, Callable)
    assert isinstance(field_override.exclude, Callable)


# Generated at 2022-06-23 16:53:19.393126
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps({'x': 1}, cls=_ExtendedEncoder)
    json.dumps([1], cls=_ExtendedEncoder)
    json.dumps(1, cls=_ExtendedEncoder)
    json.dumps(False, cls=_ExtendedEncoder)
    json.dumps(None, cls=_ExtendedEncoder)
    json.dumps(timezone.utc, cls=_ExtendedEncoder)
    json.dumps(datetime.utcnow(), cls=_ExtendedEncoder)



# Generated at 2022-06-23 16:53:23.012670
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now()) is not None



# Generated at 2022-06-23 16:53:28.640237
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(None, lambda x: x)
    assert field_override.__dict__ == dict(
        letter_case=None, decoder=lambda x: x, encoder=None, exclude=None)
    assert field_override.letter_case is None

# Generated at 2022-06-23 16:53:32.092207
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_text = _ExtendedEncoder().encode(Decimal('1.1'))
    assert json_text == '"1.1"'

_dumps_defaults = {'ensure_ascii': False,
                   'indent': 2,
                   'sort_keys': True,
                   'cls': _ExtendedEncoder}


# Generated at 2022-06-23 16:53:39.715332
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder_func = lambda x: x
    decoder_func = lambda x: x
    letter_case_func = lambda x: x
    exclude_func = lambda x: False
    f_override = FieldOverride(encoder_func, decoder_func, letter_case_func,
                               exclude_func)
    assert f_override.encoder == encoder_func
    assert f_override.decoder == decoder_func
    assert f_override.letter_case == letter_case_func
    assert f_override.exclude == exclude_func



# Generated at 2022-06-23 16:53:46.320659
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # decoder and letter_case are None
    assert FieldOverride(decoder=None, letter_case=None, exclude=None) is not None
    # decoder is defined
    assert FieldOverride(decoder=lambda x: x, letter_case=None, exclude=None) is not None
    # letter_case is defined
    assert FieldOverride(decoder=None, letter_case=lambda x: x, exclude=None) is not None
    # exclude is defined
    assert FieldOverride(decoder=None, letter_case=None, exclude=lambda x: True) is not None



# Generated at 2022-06-23 16:53:49.164822
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    d1 = _ExtendedEncoder().default(Decimal('12.34'))
    assert d1 == '12.34'



# Generated at 2022-06-23 16:53:52.226557
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ClassType = namedtuple('ClassType', ['val'])
    assert _ExtendedEncoder().encode(ClassType(val=1)) == '{"val":1}'



# Generated at 2022-06-23 16:54:00.709198
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    for obj in (1, 2.0, True, "3", None, [4, 5, 6], {7: 8, 9: 10},
                {'11': [12, 13]},
                datetime(2019, 1, 2, 3, 4, 5, 6, tzinfo=timezone.utc),
                UUID('1dd71772-e3bf-4589-bdfc-32e9616c9251'),
                Decimal('123.4'),
                MyEnum.MEMBER):
        assert _ExtendedEncoder().default(obj) == obj
    assert _ExtendedEncoder().default(1j) == json.JSONEncoder().default(1j)



# Generated at 2022-06-23 16:54:13.115480
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # test simple case
    json.dumps(12, cls=_ExtendedEncoder)

    # test for datetime
    json.dumps(datetime(2001, 12, 12, 13, 13, 13, 13, ), cls=_ExtendedEncoder)

    # test for Enum
    e = Enum("Test", "A")
    json.dumps(e, cls=_ExtendedEncoder)

    # test for UUID
    u = UUID("6bdbd6b8-f792-49f5-a6e2-9d20d2c5bdac")
    json.dumps(u, cls=_ExtendedEncoder)

    # test for Decimal
    d = Decimal("0.5")
    json.dumps(d, cls=_ExtendedEncoder)

# Generated at 2022-06-23 16:54:21.151369
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    The constructor of class FieldOverride creates a FieldOverride object.
    """
    # Test 1: test constructor when given valid inputs
    assert FieldOverride(exclude=lambda x: x < 0,
                         letter_case=lambda x: x.upper(),
                         encoder=lambda x: x*2,
                         decoder=lambda x: x*3,
                         mm_field='mm_field') is not None
    # Test 2: test constructor when exclude input is not a callable
    with pytest.raises(TypeError):
        FieldOverride(exclude=23, letter_case=lambda x: x.upper(),
                      encoder=lambda x: x*2, decoder=lambda x: x*3,
                      mm_field='mm_field')
    # Test 3: test constructor when letter_case input is not a callable

# Generated at 2022-06-23 16:54:31.956144
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    decoder = _ExtendedEncoder()
    assert decoder.default(None) == None
    assert decoder.default(False) == False
    assert decoder.default(True) == True
    assert decoder.default(1) == 1
    assert decoder.default(0.1) == 0.1
    assert decoder.default(1.1) == 1.1
    assert decoder.default('abc') == 'abc'
    assert decoder.default(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert decoder.default({'a': 'b', 'c': 'd'}) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-23 16:54:36.515750
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(True, 'CamelCase', None, None)
    assert field_override.exclude is True
    assert field_override.letter_case == 'CamelCase'
    assert field_override.encoder is None
    assert field_override.decoder is None


# Generated at 2022-06-23 16:54:40.629128
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    exclude_fn = lambda x: x == None
    override = FieldOverride(exclude_fn, None, None)
    assert override.exclude == exclude_fn
    assert override.letter_case == None
    assert override.encoder == None
    assert override.decoder == None


# Generated at 2022-06-23 16:54:43.138669
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now()) is not None


# Generated at 2022-06-23 16:54:49.589748
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    exp = """{"m": {"a": [1, 2, 3], "b": {"1": 1, "2": 2}}}"""
    data = {"a": (1, 2, 3), "b": {1: 1, 2: 2}}
    assert json.dumps(data, cls=_ExtendedEncoder) == exp


# noinspection PyProtectedMember

# Generated at 2022-06-23 16:54:57.014945
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    class _TestClass():
        def __init__(self, o):
            self.o = o
        def __hash__(self):
            return hash(self.o)
        def __eq__(self, other):
            return self.o == other.o
        def __lt__(self, other):
            return self.o < other.o
        def __repr__(self):
            return f"TestClass({self.o})"

# Generated at 2022-06-23 16:55:02.472260
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(exclude=lambda x: x is None,
                      letter_case=lambda x: x.upper(),
                      encoder=lambda x: f"i am encoded: {x}")

    assert f.exclude is not None
    assert f.letter_case is not None
    assert f.encoder is not None

# Generated at 2022-06-23 16:55:05.374693
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride() == FieldOverride(
        letter_case=None,
        decoder=None,
        encoder=None,
        exclude=None,
        mm_field=None)

