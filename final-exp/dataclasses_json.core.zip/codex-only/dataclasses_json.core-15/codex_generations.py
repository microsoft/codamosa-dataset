

# Generated at 2022-06-23 16:45:08.708095
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import date
    from dataclasses_json.test.test_test.test_test_test import DummyEnum
    json.loads(json.dumps([0], cls=_ExtendedEncoder)) == 0
    json.loads(json.dumps([[0]], cls=_ExtendedEncoder)) == [[0]]
    json.loads(json.dumps([{0: 1}], cls=_ExtendedEncoder)) == {0: 1}
    json.loads(json.dumps([{0: [1]}], cls=_ExtendedEncoder)) == {0: [1]}
    _, micsec = divmod(int(datetime.now(timezone.utc).timestamp() * 1000000), 1000000)

# Generated at 2022-06-23 16:45:17.429372
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # type: () -> None
    from datetime import datetime, timedelta
    from decimal import Decimal
    from uuid import UUID

    encoder = _ExtendedEncoder()

    assert encoder.default(datetime.now()) == datetime.now().timestamp()
    assert encoder.default(datetime.now() + timedelta(seconds=10)) == (datetime.now() + timedelta(seconds=10)).timestamp()

    test_uuid = UUID('3a7a13a6-f5b5-4dd5-a766-14d45e8ad08d')
    assert encoder.default(test_uuid) == str(test_uuid)

    assert encoder.default(Decimal(1)) == '1'


# Generated at 2022-06-23 16:45:22.895001
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class Encoder:
        def __call__(self, x):
            print("encoder called")
            return None

    class Decoder:
        def __call__(self, x):
            print("decoder called")
            return None

    def exclude(x):
        print("exclude predicate called")
        return False

    def letter_case(x):
        print("letter case called")
        return x

    # Test simple constructions
    Override = FieldOverride()
    assert Override.exclude is None and Override.letter_case is None \
        and Override.encoder is None and Override.decoder is None

    Override = FieldOverride(exclude=exclude)
    assert Override.exclude(None) is False and Override.letter_case is None \
        and Override.encoder is None and Over

# Generated at 2022-06-23 16:45:29.430243
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride()
    assert f.exclude is None
    assert f.encoder is None
    assert f.decoder is None
    assert f.letter_case is None

    f = FieldOverride(exclude=lambda x: True, encoder=lambda x: str(x),
                      decoder=lambda x: float(x),
                      letter_case=lambda x: x.upper())

    assert f.exclude(1)
    assert f.encoder(1) == "1"
    assert f.decoder("1") == 1
    assert f.letter_case("name") == "NAME"



# Generated at 2022-06-23 16:45:41.139047
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default(3.14) == 3.14
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(None) is None
    assert encoder.default(datetime.now().replace(tzinfo=timezone.utc)) == \
           datetime.now().timestamp()
    assert encoder.default(UUID('16fd2706-8baf-433b-82eb-8c7fada847da')) == \
           '16fd2706-8baf-433b-82eb-8c7fada847da'
    assert encoder.default('hello world') == 'hello world'

# Generated at 2022-06-23 16:45:43.382332
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default('a') == 'a'

# Generated at 2022-06-23 16:45:50.987030
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _json_encoder = _ExtendedEncoder()
    assert _json_encoder.default(UUID('a4d92a1a-87b4-4d53-a5e5-05634efb638a')) == 'a4d92a1a-87b4-4d53-a5e5-05634efb638a'

    assert _json_encoder.default(Decimal('0.00000000000000000')) == '0'
    assert _json_encoder.default(Decimal('0.0000000000000001')) == '0.0000000000000001'
    assert _json_encoder.default(Decimal('0.00000000000000010')) == '0.0000000000000001'


# Generated at 2022-06-23 16:46:01.125269
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Arrange
    encoder = _ExtendedEncoder()

# Generated at 2022-06-23 16:46:08.261370
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode([1]) == '[1]'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == \
        '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder

# Generated at 2022-06-23 16:46:18.668041
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    # Mapping
    assert enc.default({"a": 1}) == {"a": 1}
    # Collection
    assert enc.default([1]) == [1]
    # datetime
    dt = datetime(1970, 1, 1, tzinfo=timezone.utc)
    assert enc.default(dt) == 0.0
    # UUID
    assert enc.default(UUID("00000000-0000-0000-0000-000000000000")) == "00000000-0000-0000-0000-000000000000"
    # Enum
    assert enc.default(cfg.KeyTransform.camel) == cfg.KeyTransform.camel.value
    # Decimal
    assert enc.default(Decimal('-0.13')) == '-0.13'
    # Other
    assert enc.default

# Generated at 2022-06-23 16:46:27.949249
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000'))
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000'))
    assert _ExtendedEncoder().encode(Enum('A', 'b'))
    assert _ExtendedEncoder().encode(Decimal('0.0'))
    assert _ExtendedEncoder().encode(Decimal('0'))
    assert _ExtendedEncoder().encode([1, 2, 3])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2})



# Generated at 2022-06-23 16:46:37.699041
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    import pytest
    # Test constructor with no parameters
    override = FieldOverride()
    assert override.exclude is None
    assert override.letter_case is None
    assert override.encoder is None
    assert override.decoder is None
    assert override.mm_field is None

    # Test constructor with parameter exclude
    # is a valid callable
    def valid_exclude(x):
        return True
    override = FieldOverride(exclude=valid_exclude)
    assert override.exclude == valid_exclude
    assert override.letter_case is None
    assert override.encoder is None
    assert override.decoder is None
    assert override.mm_field is None

    # is not a valid callable

# Generated at 2022-06-23 16:46:42.886034
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc))
    assert _ExtendedEncoder().default(uuid.uuid4())
    assert _ExtendedEncoder().default(Decimal('100.0'))
    assert _ExtendedEncoder().default(TestEnum.test1)


# Generated at 2022-06-23 16:46:51.362964
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(1234) == 1234
    assert _ExtendedEncoder().default('1234') == '1234'
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(UUID('1429fa84-92d2-4a63-a641-d3649d5e2cc5')) == '1429fa84-92d2-4a63-a641-d3649d5e2cc5'
    assert _ExtendedEncoder().default(Decimal('3.14159265358979323846')) == '3.14159265358979323846'

# Generated at 2022-06-23 16:47:02.760331
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # setup
    from random import Random
    from uuid import uuid4
    from enum import Enum
    from dataclasses import dataclass, field
    from typing import List, Dict, Set, Optional, Tuple

    class TestEnum(Enum):
        A = 0
        B = 1

    @dataclass
    class TestClass:
        a: str
        b: int = field(default=0)

    @dataclass
    class TestClass2:
        a: str
        b: Optional[int] = field(default=None)

    @dataclass
    class TestClass3:
        a: str
        b: int = 1
        c: float = 1.0
        d: bool = True

# Generated at 2022-06-23 16:47:07.569278
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj = dict(date=datetime(year=2019, month=1, day=1, tzinfo=timezone.utc))
    s = json.dumps(obj, cls=_ExtendedEncoder)
    assert s == '{"date": 1546300800.0}'



# Generated at 2022-06-23 16:47:14.919433
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """Test FieldOverride constructor."""
    fo = FieldOverride('camelCase', None, None)
    assert fo.letter_case is None
    assert fo.encoder is None
    assert fo.exclude is None
    fo = FieldOverride('camelCase', lambda x: x, None)
    assert fo.letter_case is camelize
    assert fo.encoder is not None
    assert fo.exclude is None
    fo = FieldOverride('camelCase', None, lambda x: True)
    assert fo.letter_case is None
    assert fo.encoder is None
    assert fo.exclude(True)


# Generated at 2022-06-23 16:47:21.465176
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([3, 1, 4]) == '[3, 1, 4]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode({"a": [1, 2, 3], "b": 4, "c": 5}) == '{"a": [1, 2, 3], "b": 4, "c": 5}'


# noinspection PyUnresolvedReferences

# Generated at 2022-06-23 16:47:31.170735
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default([1, 2]) == [1, 2]
    assert enc.default(['a', 'b']) == ['a', 'b']
    assert enc.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert enc.default(datetime(2019, 1, 1, tzinfo=timezone.utc)) == 1546300800.0
    assert enc.default(UUID('b0569840-90e6-4063-8b96-fe7bb6327b0d')) == 'b0569840-90e6-4063-8b96-fe7bb6327b0d'
    assert enc.default(Decimal('3.14')) == '3.14'


# Generated at 2022-06-23 16:47:40.912289
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.loads(json.dumps([1, 2, 3], cls=_ExtendedEncoder)) == [1, 2, 3]
    assert json.loads(json.dumps(datetime.now(), cls=_ExtendedEncoder)) == datetime.now().timestamp()
    assert json.loads(json.dumps(UUID('{12345678-1234-5678-1234-567812345678}'), cls=_ExtendedEncoder)) == '12345678-1234-5678-1234-567812345678'
    assert json.loads(json.dumps(Decimal('1.234'), cls=_ExtendedEncoder)) == '1.234'

# Generated at 2022-06-23 16:47:46.412071
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Normal instantiation cases
    assert FieldOverride('dash', exclude=lambda x: x is None)
    assert FieldOverride(exclude=lambda x: x is None, letter_case='dash')
    assert FieldOverride(exclude=lambda x: x is None, letter_case='dash',
                         encoder=datetime.utcnow, decoder=lambda x: x)
    assert FieldOverride('dash', exclude=lambda x: x is None,
                         encoder=datetime.utcnow, decoder=lambda x: x)

    # Test an illegal case
    try:
        FieldOverride(1, exclude=lambda x: x is None)
        assert False
    except TypeError:
        pass

    # Test that letter_case is a string

# Generated at 2022-06-23 16:47:56.487489
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(list(range(5)))\
        == list(range(5))
    assert _ExtendedEncoder().default(set(range(5)))\
        == list(range(5))
    assert _ExtendedEncoder().default(tuple(range(5)))\
        == list(range(5))
    assert _ExtendedEncoder().default({'a': 1, 'b': 2})\
        == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default({'a', 'b', 'b'})\
        == list(['a', 'b', 'b'])
    assert _ExtendedEncoder().default(datetime(2018, 3, 4, 11, 12, 13))\
        == 1520157333.0

# Generated at 2022-06-23 16:47:58.630258
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert type(FieldOverride(exclude=lambda x: x == 1,
                              letter_case=lambda k: k.upper(),
                              encoder=lambda x: x,
                              decoder=lambda x: x)) is FieldOverride



# Generated at 2022-06-23 16:48:08.433761
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({1: 2}) == {1: 2}
    assert encoder.default(datetime.now(timezone.utc)) == 1587079584.4398423
    assert encoder.default(UUID("097a98a2-e1c2-4d04-a742-a07c64e8b19d")) == "097a98a2-e1c2-4d04-a742-a07c64e8b19d"
    assert encoder.default(Decimal('2.5')) == "2.5"
    assert encoder.default(None) is None
    assert encoder.default(True) is True
   

# Generated at 2022-06-23 16:48:19.105605
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc))
    assert _ExtendedEncoder().default(datetime.now(timezone.utc).isoformat())
    assert _ExtendedEncoder().default(UUID(hex='0e0aa8e9-4b08-4f58-98a1-cffb2eae5a5a'))
    assert _ExtendedEncoder().default(UUID(hex='0e0aa8e9-4b08-4f58-98a1-cffb2eae5a5a').hex)
    assert _ExtendedEncoder().default(datetime.now(timezone.utc))
    assert _ExtendedEncoder().default(datetime.now(timezone.utc).isoformat())

# Generated at 2022-06-23 16:48:21.875279
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default({'key': 1}) == {'key': 1}


# Generated at 2022-06-23 16:48:26.925574
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default(1+1j) == str(1+1j)
    assert _ExtendedEncoder().default("") == ""
    assert _ExtendedEncoder().default(b"") == "AQ=="
    assert _ExtendedEncoder().default(["1", "2"]) == ["1", "2"]
    assert _ExtendedEncoder().default({"1": "2"}) == {"1": "2"}

# Generated at 2022-06-23 16:48:37.734517
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(None) == None
    assert encoder.default(1.1) == 1.1
    assert encoder.default(datetime(2019, 1, 1)) == 1546300800.0
    assert encoder.default('hello') == 'hello'
    assert encoder.default(UUID('ed3d0c3c-3c8f-40cf-b02f-d2a9ac8c834e')) == 'ed3d0c3c-3c8f-40cf-b02f-d2a9ac8c834e'

# Generated at 2022-06-23 16:48:47.403593
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default((1, 2)) == [1, 2]
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default({'a': 1, 'b': 2.0}) == {'a': 1, 'b': 2.0}
    assert encoder.default(['a', 1, 2.0]) == ['a', 1, 2.0]
    assert encoder.default(Decimal('1.0')) == '1.0'
    assert encoder.default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'

# Generated at 2022-06-23 16:48:53.855613
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.loads(json.dumps([1, 2, 3], cls=_ExtendedEncoder)) == [1, 2, 3]
    assert json.loads(json.dumps({1: 2, 3: 4}, cls=_ExtendedEncoder)) == {1: 2, 3: 4}
    assert json.loads(json.dumps({1, 2, 3}, cls=_ExtendedEncoder)) == [1, 2, 3]
    assert isinstance(json.loads(json.dumps(datetime(2018, 4, 3, 4, 5, 6, 7), cls=_ExtendedEncoder)), float)

# Generated at 2022-06-23 16:49:03.404975
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def test_msg(o, result) -> str:
        return '_ExtendedEncoder.default({}) == {} (expected {})'.format(o,
                                                                         result,
                                                                         o if o is result else o)
    encoder = _ExtendedEncoder()

    assert encoder.default(None) is None, test_msg(None, encoder.default(None))
    assert encoder.default(True) is True, test_msg(True, encoder.default(True))
    assert encoder.default(False) is False, test_msg(False, encoder.default(False))
    assert encoder.default(1) == 1, test_msg(1, encoder.default(1))

# Generated at 2022-06-23 16:49:14.068282
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    decoder = _ExtendedEncoder()
    assert decoder.default(123) == 123
    assert decoder.default('abc') == 'abc'
    assert decoder.default(True) is True
    assert decoder.default(False) is False
    assert decoder.default(None) is None
    assert decoder.default([1, 2, 3]) == [1, 2, 3]
    assert decoder.default({'a': 'b'}) == {'a': 'b'}
    assert decoder.default(UUID('a2907e3c-d9e3-4b11-bff7-632d4730d263')) == 'a2907e3c-d9e3-4b11-bff7-632d4730d263'

# Generated at 2022-06-23 16:49:21.207605
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    # Collecion
    assert e.default([1, 2]) == [1, 2]
    assert e.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # datetime
    assert e.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    # UUID
    assert e.default(UUID('01234567-89ab-cdef-0123-456789abcdef')) == '01234567-89ab-cdef-0123-456789abcdef'
    # Enum
    class DummyEnum(Enum):
        a = 1
    assert e.default(DummyEnum.a) == 1
    # Dec

# Generated at 2022-06-23 16:49:25.708774
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test 1 no args
    field = FieldOverride()
    assert field.encoder is None
    assert field.decoder is None
    assert field.exclude is None
    assert field.mm_field is None
    assert field.letter_case is None

    # Test 2 encoder defined
    encoder = _ExtendedEncoder().default
    field = FieldOverride(encoder=encoder, mm_field=None)
    assert field.encoder is encoder
    assert field.decoder is None
    assert field.exclude is None
    assert field.mm_field is None
    assert field.letter_case is None

    # Test 3 decoder defined
    decoder = _ExtendedDecoder().default
    field = FieldOverride(encoder=None, decoder=decoder)
    assert field.encoder is None

# Generated at 2022-06-23 16:49:37.492248
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    inp = ['a', 'b', 'c']
    out = encoder.default(inp)
    assert inp == out

    inp = ['a', 'b', 'c']
    out = encoder.default(inp)
    assert inp == out

    inp = {'a': 1, 'b': 2, 'c': 3}
    out = encoder.default(inp)
    assert inp == out

    inp = UUID('00000000-0000-0000-0000-000000000000')
    out = encoder.default(inp)
    assert str(inp) == out

    inp = Enum('TestEnum', {'A': 1})
    out = encoder.default(inp)
    assert 1 == out

    inp = dat

# Generated at 2022-06-23 16:49:42.419203
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride()
    assert(field_override.field_name == None)
    assert(field_override.letter_case == None)
    assert(field_override.exclude == None)
    assert(field_override.encoder == None)



# Generated at 2022-06-23 16:49:43.455446
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(object()) == '{}'



# Generated at 2022-06-23 16:49:45.135112
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default('') == ''
test__ExtendedEncoder_default()



# Generated at 2022-06-23 16:49:57.434610
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(int(-10)) == -10
    assert _ExtendedEncoder().default(float(-10.1)) == -10.1
    assert _ExtendedEncoder().default('abc') == 'abc'
    assert _ExtendedEncoder().default(list(range(3))) == [0, 1, 2]
    assert _ExtendedEncoder().default(tuple(range(3))) == [0, 1, 2]
    assert _ExtendedEncoder().default(dict(a=1, b=2)) == {'a': 1, 'b': 2}

# Generated at 2022-06-23 16:50:07.745901
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None
    assert encoder.default(False) is False
    assert encoder.default(True) is True
    assert encoder.default(0) == 0
    assert encoder.default(-1) == -1
    assert encoder.default(1) == 1
    assert encoder.default(0.0) == 0.0
    assert encoder.default(1.1) == 1.1
    assert encoder.default(-1.1) == -1.1
    assert encoder.default('str') == 'str'
    assert encoder.default('True') == 'True'
    assert encoder.default(['a', 'b']) == ['a', 'b']
    assert encoder.default(()) == []

# Generated at 2022-06-23 16:50:15.283797
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import dataclass
    from datetime import date

    @dataclass
    class MyType:
        pass

    assert _ExtendedEncoder().default(date.today()) is not NotImplemented
    assert _ExtendedEncoder().default(UUID('6cd78d6a-c6b3-4cc2-8b3d-c7e6a9f9d856')) is not NotImplemented
    assert _ExtendedEncoder().default(MyType) is NotImplemented
    assert _ExtendedEncoder().default(MyType()) is NotImplemented

# Generated at 2022-06-23 16:50:19.801363
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(exclude=None, letter_case=None, encoder=None,
                         decoder=None)
    assert FieldOverride(exclude=None, letter_case=None, encoder=None,
                         decoder=None)



# Generated at 2022-06-23 16:50:27.302762
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test with an int
    field_overide = FieldOverride(letter_case=lambda x: "".join(x))
    actual_value = field_overide.letter_case(1)
    expected_value = "1"
    assert expected_value == actual_value

    # test with a str
    field_overide = FieldOverride(letter_case=lambda x: "".join(x))
    actual_value = field_overide.letter_case("abc")
    expected_value = "abc"
    assert expected_value == actual_value

    # test with a tuple
    field_overide = FieldOverride(letter_case=lambda x: "".join(x))
    actual_value = field_overide.letter_case((1, "a", ["x", "y"]))

# Generated at 2022-06-23 16:50:38.012775
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode(datetime(2020, 2, 1, 17, 56, 28, 715481)) == '1580518388.715481'
    assert _ExtendedEncoder().encode(UUID('3de3cc41-c51a-473e-86fd-8182074a23a6')) == '"3de3cc41-c51a-473e-86fd-8182074a23a6"'
    assert _ExtendedEncoder().encode(Enum('Enum', 'val1 val2 val3')('val1')) == '"val1"'

# Generated at 2022-06-23 16:50:47.578284
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(set([1, 2, 3])) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 0, 1, tzinfo=timezone.utc)) == '1577881060.0'
    assert _ExtendedEncoder().encode(UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8')) == '6ba7b810-9dad-11d1-80b4-00c04fd430c8'
    assert _ExtendedEncoder().encode(bool(1)) == 'true'

# Generated at 2022-06-23 16:50:53.841475
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    @dataclass
    class TestFieldOverride:
        letter_case: str = None
        exclude: callable = None
        encoder: callable = None
        decoder: callable = None
        mm_field: callable = None

    a = TestFieldOverride()
    assert a.letter_case == None
    assert a.exclude == None
    assert a.encoder == None
    assert a.decoder == None
    assert a.mm_field == None


# Generated at 2022-06-23 16:51:01.210303
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import datetime
    from uuid import uuid4
    from enum import Enum
    from decimal import Decimal
    from dataclasses import dataclass
    example = [uuid4(), datetime.now(timezone.utc), Enum('Test', 'a b'), Decimal('1.23')]
    assert _ExtendedEncoder().encode(example) == json.dumps(example, cls=_ExtendedEncoder)


# Generated at 2022-06-23 16:51:03.849766
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride() == FieldOverride(exclude=None,
                                            letter_case=None, encoder=None, decoder=None,
                                            field_name=None)



# Generated at 2022-06-23 16:51:09.380184
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(None, None, None, None)
    assert FieldOverride('lower', None, None, None)
    assert FieldOverride(None, 'repr', None, None)
    assert FieldOverride(None, None, lambda x: True, None)
    assert FieldOverride(None, None, None, lambda x: x)


# Unit tests for constructors of optional types

# Generated at 2022-06-23 16:51:19.589246
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(dict(a=1, b=2)) == {'a': 1, 'b': 2}
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default(frozenset([1, 2, 3])) == [1, 2, 3]
    assert encoder.default(datetime(2019, 6, 4, 13, 37, 0, tzinfo=timezone.utc)) == 1562267620.0
    assert encoder.default(UUID('01234567-89ab-cdef-0123-456789abcdef')) == '01234567-89ab-cdef-0123-456789abcdef'

# Generated at 2022-06-23 16:51:28.109904
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(set()) == []
    dt = datetime.now(timezone.utc)
    assert _ExtendedEncoder().default(dt) == dt.timestamp()
    assert _ExtendedEncoder().default(UUID(int=0)) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().default(Decimal(0)) == '0'
    assert _ExtendedEncoder().default(Enum) == 'Enum'
    assert _ExtendedEncoder().default(TypeError) == 'TypeError'



# Generated at 2022-06-23 16:51:31.117808
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    FieldOverride(letter_case=None,
                  exclude=None,
                  encoder=None,
                  decoder=None)

# Generated at 2022-06-23 16:51:38.660175
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.default(Decimal('5')) == '5'
    assert extended_encoder.default(UUID('25769c6c-d34d-4bfe-ba98-e0ee856f3e7a')) == '25769c6c-d34d-4bfe-ba98-e0ee856f3e7a'
    assert extended_encoder.default({'a': 2}) == {'a': 2}



# Generated at 2022-06-23 16:51:47.762144
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Expected behavior
    fields_test = {'exclude': lambda x: x > 2,
                   'encoder': lambda x: x * 2,
                   'decoder': lambda x: x / 3,
                   'mm_field': str,
                   'letter_case': str.lower,
                   }
    FieldOverride(fields_test['exclude'],
                  fields_test['encoder'],
                  fields_test['decoder'],
                  fields_test['mm_field'],
                  fields_test['letter_case'])

    # Missing parameter
    # Default parameter of exclude is None
    # This case should not throw an error

# Generated at 2022-06-23 16:52:01.333291
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test_value_none
    assert FieldOverride() == FieldOverride(None, None, None)
    # test_value_lettercase_none
    assert FieldOverride(letter_case=None) == FieldOverride(None, None, None)
    # test_value_exclude_none
    assert FieldOverride(exclude=None) == FieldOverride(None, None, None)
    # test_value_encoder_none
    assert FieldOverride(encoder=None) == FieldOverride(None, None, None)
    # test_value_none_all
    assert FieldOverride() == FieldOverride(None, None, None, None)
    # test_value_all_none
    assert FieldOverride(None, None, None, None) == FieldOverride(None, None, None)

    def a(x):
        return str(x)


# Generated at 2022-06-23 16:52:08.497405
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test empty case
    FieldOverride()

    # Test full field
    FieldOverride(exclude=lambda obj: True,
                  letter_case=lambda obj: obj+"1",
                  encoder=lambda obj: obj+"2",
                  decoder=lambda obj: obj+"3"
                  )

    # Test context manager
    with FieldOverride(exclude=lambda obj: False) as field_override:
        assert not field_override.exclude
    assert field_override.exclude



# Generated at 2022-06-23 16:52:12.869629
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Given
    o = datetime(year=2019, month=3, day=4, hour=5, minute=6, second=7)
    e = _ExtendedEncoder()

    # When
    actual = e.default(o)

    # Then
    assert actual == 1551717367.0



# Generated at 2022-06-23 16:52:19.266526
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    data_in = {
        'a': 3.14159265359,
        'b': 123456789,
        'c': 123456789.123456789,
        'd': 'test',
        'e': ['test1', 'test2', 'test3'],
        'f': [{'test': 'test1'}, {'test': 'test2'}],
        'g': {'test': 'test1'},
        'h': datetime.now(timezone.utc),
        'i': UUID('1b4e28ba-2fa1-11d2-883f-0016d3cca427')
    }

# Generated at 2022-06-23 16:52:24.510742
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(None, None, None)
    assert f.exclude is None
    assert f.letter_case is None
    assert f.encoder is None
    assert f.decoder is None


# Generated at 2022-06-23 16:52:32.857563
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == []
    assert encoder.default({}) == {}
    assert encoder.default(datetime(2019, 2, 15, 16, 0, 0)) == 1550223200.0
    assert encoder.default(timezone.utc) == "UTC"
    assert encoder.default(UUID('f47ac10b-58cc-4372-a567-0e02b2c3d479')) == 'f47ac10b-58cc-4372-a567-0e02b2c3d479'
    assert encoder.default(Enum('E1', [('A', 'a'), ('B', 'b')])) == 'a'

# Generated at 2022-06-23 16:52:42.217674
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = _ExtendedEncoder().default(MISSING)
    assert o is None
    o = _ExtendedEncoder().default('abc')
    assert o == 'abc'
    o = _ExtendedEncoder().default([1, 2, 3])
    assert o == [1, 2, 3]
    o = _ExtendedEncoder().default([1, 2, 3])
    assert o == [1, 2, 3]
    o = _ExtendedEncoder().default((1, 2, 3))
    assert o == [1, 2, 3]
    o = _ExtendedEncoder().default({1:'a', 2:'b', 3:'c'})
    assert o == {1: 'a', 2: 'b', 3: 'c'}

# Generated at 2022-06-23 16:52:48.525123
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.1) == 1.1
    assert _ExtendedEncoder().default("hi") == "hi"
    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default({1: 2}) == {1: 2}
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, 0, 0, 0, tzinfo=None)) == 0

# Generated at 2022-06-23 16:53:01.095150
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(['foo', 1, True]) == ['foo', 1, True]
    assert encoder.default(('foo', 1, True)) == ['foo', 1, True]
    assert encoder.default({'foo': 1, 2: 'bar', 3: True}) == {'foo': 1, 2: 'bar', 3: True}
    assert encoder.default({'foo', 1, True}) == [True, 1, 'foo']
    dt = datetime(2018, 12, 11, 15, 29, 43, 123456, timezone.utc)
    assert encoder.default(dt) == 1544602983.123456

# Generated at 2022-06-23 16:53:13.227701
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    class A(Enum):
        a = 1
    assert encoder.default({1: 2}) == {1: 2}
    assert encoder.default((1, 2)) == [1, 2]
    assert encoder.default(datetime(year=2020, month=9, day=1, tzinfo=timezone.utc)) == 1598918400.0
    assert encoder.default(UUID('39b037b6-737c-47de-8028-ed86cef6a7b8')) == '39b037b6-737c-47de-8028-ed86cef6a7b8'
    assert encoder.default(A.a) == 1

# Generated at 2022-06-23 16:53:19.000994
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder().default(datetime.now())
    assert result == 0.0
    result = _ExtendedEncoder().default(1)
    assert result == 1
    result = _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000'))
    assert result == "00000000-0000-0000-0000-000000000000"


# Generated at 2022-06-23 16:53:22.641200
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    _ = FieldOverride(exclude=lambda v: True, encoder=lambda v: v,
                    decoder=lambda v: v, letter_case='snake')



# Generated at 2022-06-23 16:53:33.116936
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(datetime(year=2019, month=1, day=1, hour=1, minute=1, second=1), cls=_ExtendedEncoder) == '1546344461'
    assert json.dumps(UUID('ff9089aa-b27c-11e8-a355-529269fb1459'), cls=_ExtendedEncoder) == '"ff9089aa-b27c-11e8-a355-529269fb1459"'
    assert json.dumps(Decimal('1.1'), cls=_ExtendedEncoder) == '"1.1"'
    assert json.dumps(None, cls=_ExtendedEncoder) == 'null'

# Generated at 2022-06-23 16:53:40.479323
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    test = FieldOverride(exclude=None, encoder=None, decoder=None,
                         mm_field=None)
    assert test.exclude == FieldOverride.exclude
    assert FieldOverride.exclude == None
    assert test.encoder == FieldOverride.encoder
    assert FieldOverride.encoder == None
    assert test.decoder == FieldOverride.decoder
    assert FieldOverride.decoder == None
    assert test.mm_field == FieldOverride.mm_field
    assert FieldOverride.mm_field == None
    assert test._asdict() == FieldOverride._asdict()

# Generated at 2022-06-23 16:53:41.455671
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-23 16:53:49.344834
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride()
    assert f.exclude == None
    assert f.encoder == None
    assert f.decoder == None
    assert f.letter_case == None
    assert f.mm_field == None
    assert f.validator == None
    assert f.required == False
    assert f.allow_none == False
    assert f.allow_extra == False

    f = FieldOverride(exclude=lambda x: x > 0)

# Generated at 2022-06-23 16:53:59.768996
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(dict()) == dict()
    assert _ExtendedEncoder().default(list()) == list()
    assert _ExtendedEncoder().default(UUID('d9e9fe4b-df8d-4a7a-b242-c7f1b878a0bb')) == 'd9e9fe4b-df8d-4a7a-b242-c7f1b878a0bb'
    assert _ExtendedEncoder().default(datetime(2020, 2, 20, 2, 20, 20, tzinfo=timezone.utc)) == 1582212220.0
    assert _ExtendedEncoder().default(datetime(2020, 2, 20, 2, 20, 20)) == 1582212220.0

# Generated at 2022-06-23 16:54:12.015141
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import date, datetime
    from decimal import Decimal as D
    from uuid import UUID
    from unittest import TestCase

    class ExampleEnum(Enum):
        A = 1
        B = 2

    class TestJsonEncoder(TestCase):
        def test__ExtendedEncoder_default__datetimes(self):
            dt = datetime.now(timezone.utc)
            self.assertEqual(_ExtendedEncoder().default(dt), dt.timestamp())

        def test__ExtendedEncoder_default__dates(self):
            d = date.today()
            self.assertEqual(_ExtendedEncoder().default(d), d.strftime('%Y-%m-%d'))


# Generated at 2022-06-23 16:54:20.630125
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert json.loads(json.dumps({}, cls=_ExtendedEncoder)) == {}
    assert json.loads(json.dumps([], cls=_ExtendedEncoder)) == []
    assert json.loads(json.dumps("", cls=_ExtendedEncoder)) == ""
    assert json.loads(json.dumps(1, cls=_ExtendedEncoder)) == 1
    assert json.loads(json.dumps(1.0, cls=_ExtendedEncoder)) == 1.0
    assert json.loads(json.dumps(True, cls=_ExtendedEncoder)) is True
    assert json.loads(json.dumps(None, cls=_ExtendedEncoder)) is None

# Generated at 2022-06-23 16:54:29.990834
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime(2020, 5, 27)) == 1590585600.0
    assert _ExtendedEncoder().default(UUID('6f152ae6-9cc6-4d75-b99f-7f8cc1eae7d1')) == '6f152ae6-9cc6-4d75-b99f-7f8cc1eae7d1'
    assert _ExtendedEncoder().default(Decimal('0.01')) == '0.01'
    assert _ExtendedEncoder().default(Decimal('1')) == '1'



# Generated at 2022-06-23 16:54:35.764202
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == []
    assert encoder.default(frozenset()) == []
    assert encoder.default(tuple()) == []
    assert encoder.default(dict()) == {}
    assert encoder.default(datetime(2020, 1, 1)) == 1577825200


# noinspection PyProtectedMember

# Generated at 2022-06-23 16:54:43.416505
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode(['a']) == '["a"]'
    assert _ExtendedEncoder().encode([1]) == '[1]'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode('a') == '"a"'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(False) == 'false'
    assert _ExtendedEncoder().encode({1, 2, 3}) == '[1, 2, 3]'

# Generated at 2022-06-23 16:54:54.244847
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert json.loads((_ExtendedEncoder().encode(
        datetime(year=2011, month=7, day=23, hour=5, minute=43, second=22, microsecond=12345, tzinfo=timezone.utc)
    ))) == 1311410602.012345
    assert json.loads((_ExtendedEncoder().encode([1, 2, 3]))) == [1, 2, 3]
    assert json.loads((_ExtendedEncoder().encode({"a": 1, "b": 2}))) == {"a": 1, "b": 2}

# Generated at 2022-06-23 16:55:06.816254
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Without value
    assert FieldOverride(None, None, None, None) == FieldOverride()
    assert FieldOverride(None, "", lambda x: x, None) == FieldOverride("", lambda x: x)
    assert FieldOverride(None, "", None, lambda x: x) == FieldOverride("", None, lambda x: x)
    assert FieldOverride(None, "", lambda x: x, lambda x: x) == FieldOverride("", lambda x: x, lambda x: x)
    assert FieldOverride(None, "lower", None, None) == FieldOverride("lower")
    assert FieldOverride(None, "lower", lambda x: x, None) == FieldOverride("lower", lambda x: x)
    assert FieldOverride(None, "lower", None, lambda x: x) == FieldOverride("lower", None, lambda x: x)
    assert FieldOverride