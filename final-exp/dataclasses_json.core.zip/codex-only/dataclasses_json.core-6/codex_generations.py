

# Generated at 2022-06-23 16:45:08.150541
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(exclude=None, encoder=None, decoder=None, letter_case=None)
    assert (f.exclude is None
            and f.encoder is None
            and f.decoder is None
            and f.letter_case is None)
    f = FieldOverride(exclude=str, encoder=str, decoder=str, letter_case=str)
    assert (type(f.exclude) is type
            and type(f.encoder) is type
            and type(f.decoder) is type
            and type(f.letter_case) is type)

# Generated at 2022-06-23 16:45:17.089875
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    d = {'a': 1, 'b': 2}
    assert enc.default({}) == {}
    assert enc.default([]) == []
    assert enc.default(d) == d
    assert enc.default(1) == 1
    assert enc.default(1.1) == 1.1
    assert enc.default(1j) == 1j
    assert enc.default('a') == 'a'
    assert enc.default(True) == True
    assert enc.default(False) == False
    assert enc.default({1, 2}) == [1, 2]
    assert enc.default((1, 2)) == [1, 2]
    assert enc.default(set([1, 2])) == [1, 2]
    assert enc.default(None) is None

# Generated at 2022-06-23 16:45:18.155910
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder() # this line plays role for pytest


# Generated at 2022-06-23 16:45:25.069604
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test with no arguments
    no_arg_field_override = FieldOverride()
    assert no_arg_field_override.exclude is None
    assert no_arg_field_override.letter_case is None
    assert no_arg_field_override.encoder is None
    assert no_arg_field_override.decoder is None
    assert no_arg_field_override.mm_field is None
    assert no_arg_field_override.mm_field_kwargs is None
    assert no_arg_field_override.mm_field_cls_kwargs is None



# Generated at 2022-06-23 16:45:33.227499
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import datetime
    from decimal import Decimal
    from uuid import uuid4
    from unittest import TestCase
    from enum import Enum

    class TestEnum(Enum):
        TEST = 'test'


# Generated at 2022-06-23 16:45:43.481577
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    json.dumps(1, cls=enc)
    json.dumps('a', cls=enc)
    json.dumps(1.1, cls=enc)
    json.dumps({'a': 1}, cls=enc)
    json.dumps([1, 2], cls=enc)
    json.dumps(Enum('A', 'a'), cls=enc)
    json.dumps(datetime.fromtimestamp(0, tz=timezone.utc), cls=enc)
    json.dumps(Decimal("1.00"), cls=enc)
    json.dumps(UUID("0506d9e6-880f-44a7-8f0d-a7a0c00ece80"), cls=enc)

# Generated at 2022-06-23 16:45:47.618203
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(Decimal('0.1')) == '0.1'


# noinspection PyMethodMayBeStatic

# Generated at 2022-06-23 16:45:50.492820
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({datetime.utcnow()}) == json.dumps({datetime.utcnow().timestamp()})



# Generated at 2022-06-23 16:45:59.497514
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    default = _ExtendedEncoder().default
    assert default([1, 2, 3]) == [1, 2, 3]
    assert default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert default(datetime(2020, 8, 8, 0, 0, 0)) == 1596816000.0
    assert default(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678123456781234567812345678'
    assert default(Decimal('1.23')) == '1.23'
    assert default(Enum('A', names={'A': 0})) == 0



# Generated at 2022-06-23 16:46:11.424754
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder: _ExtendedEncoder = _ExtendedEncoder()
    test_list = [1, 2, 3]
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_datetime = datetime.now(timezone.utc)
    test_uuid = UUID('{12345678-1234-5678-1234-567812345678}')
    test_decimal = Decimal('3.1415')
    result = encoder.default(test_list)
    assert result == test_list
    result = encoder.default(test_dict)
    assert result == test_dict
    result = encoder.default(test_datetime)
    assert result == test_datetime.timestamp()
    result = encoder.default(test_uuid)


# Generated at 2022-06-23 16:46:14.903758
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(TypeError):
        FieldOverride(exclude=lambda x: x == 1,
                      letter_case=str.lower)
    assert FieldOverride().exclude is None
    assert FieldOverride().encoder is None
    assert FieldOverride().decoder is None
    assert FieldOverride().letter_case is None



# Generated at 2022-06-23 16:46:24.525096
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    Ext = _ExtendedEncoder()
    assert Ext.default([1, 2, 3]) == [1, 2, 3]
    assert Ext.default([1.1, 2.2, 3.3]) == [1.1, 2.2, 3.3]
    assert Ext.default(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert Ext.default([True, False, True]) == [True, False, True]
    assert Ext.default([]) == []
    assert Ext.default(datetime.now(timezone.utc)) == 1575148016.0
    assert Ext.default(UUID('123456-123456-123456-123456')) == '123456-123456-123456-123456'
    class Enum1(Enum):
        a=1


# Generated at 2022-06-23 16:46:27.342203
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    letter_case = 'snake_case'
    encoder = int
    decoder = str
    exclude = lambda x: x == 1
    FieldOverride(letter_case, encoder, decoder, exclude)



# Generated at 2022-06-23 16:46:37.151550
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import date
    from decimal import Decimal as D
    from uuid import UUID
    from enum import Enum
    class MyEnum(Enum):
        A = 1
        B = 2
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default(range(5)) == list(range(5))
    assert _ExtendedEncoder().default(date.today()) == 0.0
    assert _ExtendedEncoder().default(D('0.5')) == '0.5'

# Generated at 2022-06-23 16:46:40.690327
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

    assert encoder.default(datetime.now()) is not None
    assert encoder.default(datetime.now(tz=timezone.utc)) is not None



# Generated at 2022-06-23 16:46:49.591987
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    override = FieldOverride("key", letter_case="snake_case")
    assert override.key_name == "key"
    assert override.letter_case == "snake_case"
    assert override.exclude is None
    assert override.encoder is None
    assert override.decoder is None

    override = FieldOverride("key", exclude="value")
    assert override.key_name == "key"
    assert override.letter_case is None
    assert override.exclude == "value"
    assert override.encoder is None
    assert override.decoder is None

    override = FieldOverride("key", encoder="encoder", decoder="decoder")
    assert override.key_name == "key"
    assert override.letter_case is None
    assert override.exclude is None
    assert override.encoder == "encoder"

# Generated at 2022-06-23 16:47:01.567950
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test for a datetime object
    datetime_obj = datetime(2019, 12, 31, tzinfo=timezone.utc)
    assert _ExtendedEncoder().default(datetime_obj) == datetime_obj.timestamp()
    # Test for an Enum object
    class EnumColor(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3
    assert _ExtendedEncoder().default(EnumColor.GREEN) == 2
    # Test for a custom class that cannot be converted to JSON
    class CustomObject:
        def __init__(self, a, b):
            self.a = a
            self.b = b
    with pytest.raises(TypeError):
        assert _ExtendedEncoder().default(CustomObject(1, 2))


# Generated at 2022-06-23 16:47:04.980748
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder(indent=4).encode(datetime(2019, 12, 16, 11, 25, 0)) \
           == "1586865700.0000"



# Generated at 2022-06-23 16:47:06.327953
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import pytest
    _ExtendedEncoder().default(datetime(2020, 12, 12))



# Generated at 2022-06-23 16:47:14.001027
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    uuid_obj = UUID('01234567-89ab-cdef-0123-456789abcdef')
    uuid_str = '01234567-89ab-cdef-0123-456789abcdef'
    dec_obj = Decimal('1.0')
    dec_str = '1.0'
    tz = timezone.utc
    date_obj = datetime(2018, 10, 30, 10, 30, 30, 0, tzinfo=tz)

    assert _ExtendedEncoder().default(uuid_obj) == uuid_str
    assert _ExtendedEncoder().default(dec_obj) == dec_str
    assert _ExtendedEncoder().default(date_obj) == date_obj.timestamp()
    assert _ExtendedEncoder().default(10) == 10



# Generated at 2022-06-23 16:47:24.479250
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    from dataclasses_json._config import CustomType
    from dataclasses_json.api import encoder, decoder, mm_field
    from dataclasses_json.mm_types import MMDict
    import pydantic
    import marshmallow

    # Data class to be used as a type for CustomType
    @dataclass
    class TestType:
        x: int
        y: str

    type_config = {
        "encoder": encoder(lambda x: x.x),
        "decoder": decoder(lambda x: TestType(x, "test")),
        "mm_field": mm_field(lambda: marshmallow.fields.Str())
    }


# Generated at 2022-06-23 16:47:32.772972
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class Foo(NamedTuple):
        a: int

    class Config:
        json_module = None
        encode_unexpected_types = None
        encode_unexpected_types_as_str = None

    conf = Config()
    conf.json_module = "json"
    conf.encode_unexpected_types = False
    conf.encode_unexpected_types_as_str = False

    o = FieldOverride.from_config(Foo, conf)
    assert o.letter_case == None
    assert o.exclude == None



# Generated at 2022-06-23 16:47:42.077443
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert [1, 2, 3] == encoder.default([1, 2, 3])
    assert {"a": 1, "b": 2} == encoder.default({"a": 1, "b": 2})
    assert {"a": 1, "b": 2} == encoder.default({"a": 1, "b": 2})
    assert '2018-01-02T03:04:05.678Z' == encoder.default(datetime(2018, 1, 2, 3, 4, 5, 678000, tzinfo=timezone.utc))

# Generated at 2022-06-23 16:47:43.825360
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))


# Generated at 2022-06-23 16:47:48.968681
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now()) is not None
    assert _ExtendedEncoder().default(UUID('8a5862e2-fef3-4656-80fd-8b53f9c9fb0d')) is not None
    assert _ExtendedEncoder().default([]) is not None
    assert _ExtendedEncoder().default({}) is not None
    assert _ExtendedEncoder().default(Enum) is not None



# Generated at 2022-06-23 16:47:57.426252
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class Foo:
        @dataclass
        class Bar:
            s: str
        my_bar = Bar("bar")
        @dataclass
        class Baz:
            my_bar: Bar

        baz: Baz

    letter_case = ItemGetter(0)
    exclude = lambda x: isinstance(x, dict) and x.get("a") != "a"
    encoder = lambda x: x.a if isinstance(x, dict) else x
    decoder = lambda x: Foo.Baz(Foo.Bar(x))
    f = FieldOverride(letter_case, exclude, encoder, decoder)
    assert(f.letter_case == ItemGetter(0))
    assert(f.exclude({"a": "a"}) == False)

# Generated at 2022-06-23 16:48:00.027166
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride() == FieldOverride(
        exclude=None,
        encoder=None,
        decoder=None,
        letter_case=None)



# Generated at 2022-06-23 16:48:09.752948
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    cls = _ExtendedEncoder()
    test_datetime = datetime.now(timezone.utc)
    test_obj = {
        'a': 1,
        'b': 2,
        'c': [1, 2, 3],
        'd': {'a': 1, 'b': 2, 'c': [1, 2, 3]},
        'e': test_datetime,
        'f': '1',
        'g': None,
        'h': UUID('00000000-0000-0000-0000-000000000000'),
        'i': Enum('TestEnum', {'a': 1})('a'),
        'j': Decimal('0.1'),
    }
    res = cls.default(test_obj)

# Generated at 2022-06-23 16:48:13.382205
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    from datetime import datetime
    datetime_ = datetime(1970, 1, 1)
    assert FieldOverride(exclude=None, letter_case=None,
                         encoder=None, decoder=None) is not None
    assert FieldOverride(exclude=lambda x: x == datetime_,
                         letter_case=str.upper,
                         encoder=str, decoder=str) is not None

# Generated at 2022-06-23 16:48:20.293233
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    @dataclass
    class A:
        a: Optional[str] = None

    test_o = FieldOverride(exclude=a_predicate,
                           encoder=encode_a,
                           decoder=decode_a)

    assert isinstance(test_o.exclude, Predicate)
    assert callable(test_o.encoder)
    assert callable(test_o.decoder)
    assert test_o.letter_case is None



# Generated at 2022-06-23 16:48:29.913442
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

    for datetime_part in ['microsecond', 'second', 'minute', 'hour', 'day', 'month', 'year', 'tzinfo']:
        dt_parts = {datetime_part: 1234}
        dt = datetime(**dt_parts)

        dt_parts['tzinfo'] = timezone.utc
        assert encoder.default(dt) == datetime(**dt_parts).timestamp()

        dt_parts['tzinfo'] = timezone(datetime.min.tzinfo.utcoffset(dt))
        assert encoder.default(dt) == datetime(**dt_parts).timestamp()


# Generated at 2022-06-23 16:48:31.840590
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(exclude=lambda x: x, letter_case=str.upper,
                         encoder=lambda y: y, decoder=lambda y: y)



# Generated at 2022-06-23 16:48:41.761160
# Unit test for constructor of class _ExtendedEncoder

# Generated at 2022-06-23 16:48:45.611493
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(None, None, None)
    assert FieldOverride(None, None, lambda x: x > 0)
    assert FieldOverride(str.upper, lambda x: float(x), lambda x: x > 0)
    with pytest.raises(TypeError):
        FieldOverride()


# Generated at 2022-06-23 16:48:57.327269
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test with all fields explicitly defined
    fo = FieldOverride(exclude=lambda v: v == None,
                       letter_case=lambda x: x.upper(),
                       encoder=lambda x: x,
                       decoder=lambda x: x)
    assert fo.exclude is not None
    assert fo.letter_case is not None
    assert fo.encoder is not None
    assert fo.decoder is not None

    # test with all fields defined, but None
    fo = FieldOverride(exclude=None,
                       letter_case=None,
                       encoder=None,
                       decoder=None)
    assert fo.exclude is None
    assert fo.letter_case is None
    assert fo.encoder is None
    assert fo.decoder is None

    # test with all fields not defined, hence defaulting to None
    fo

# Generated at 2022-06-23 16:49:06.236546
# Unit test for constructor of class _ExtendedEncoder

# Generated at 2022-06-23 16:49:11.356800
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(exclude=None, encoder=None, decoder=None,
                                   letter_case=None)
    assert field_override.exclude is None
    assert field_override.encoder is None
    assert field_override.decoder is None
    assert field_override.letter_case is None



# Generated at 2022-06-23 16:49:15.306067
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
   class ClassWithUUID(object):
       def __init__(self, uuid):
           self.uuid = uuid
   _ExtendedEncoder().default(ClassWithUUID(UUID('a1116f57-b7e1-4a58-b2ef-69a3a33a31d3')))



# Generated at 2022-06-23 16:49:24.297472
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(dict()) == dict()
    assert encoder.default(list()) == list()
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(None) == None
    assert encoder.default(0) == 0
    assert encoder.default(0.0) == 0.0
    assert encoder.default('') == ''
    assert encoder.default(tuple()) == list()
    assert encoder.default(set()) == list()
    assert encoder.default(frozenset()) == list()
    assert encoder.default(1 + 1j) == json.JSONEncoder.default(encoder, 1 + 1j)
    assert encoder.default(object()) == json.JSON

# Generated at 2022-06-23 16:49:32.981180
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(exclude=lambda x: True,
                      encoder=lambda x: x+1,
                      decoder=lambda x: x-1,
                      letter_case=lambda x: x+"_")
    assert f.exclude(x=1)
    assert f.encoder(x=1) == 2
    assert f.decoder(x=1) == 0
    assert f.letter_case(x="x") == "x_"



# Generated at 2022-06-23 16:49:42.088920
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    dt = datetime(2020, 10, 7, 23, 0, 0, tzinfo=timezone.utc)
    assert e.default(dt) == dt.timestamp()
    en = MyEnum.A
    assert e.default(en) == en.value
    u = UUID("f5707823-8232-4517-a090-98c0f2932d8e")
    assert e.default(u) == str(u)
    class MyClass():
        def __str__(self):
            return "MyClass"
    assert e.default(MyClass()) == "MyClass"
    d = Decimal("3.14")
    assert e.default(d) == str(d)


# Generated at 2022-06-23 16:49:49.820820
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    dt = datetime.now(timezone.utc)
    t = cfg.typemapping[UUID]

# Generated at 2022-06-23 16:49:54.219564
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoding = json.JSONEncoder()
    decode = json.JSONDecoder()
    letter = lambda s: s.lower()
    ex_pred = lambda x: x > 3

    x = 1
    y = "hello"
    z = FieldOverride(letter, ex_pred, encoding, decode)
    print(z)


# Generated at 2022-06-23 16:50:00.373186
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    types: Collection[Any] = [
        [1, 2, 3], {'a': 1, 'b': 2},
        UUID('{12345678-1234-5678-1234-567812345000}'),
        datetime(2018, 1, 1, 12, 10, 9, 0, timezone.utc),
        Decimal('3.14'),
        Enum('SimpleEnum', ['a', 'b'])('a')
    ]
    for o in types:
        assert _ExtendedEncoder().default(o) == o



# Generated at 2022-06-23 16:50:04.246577
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(
        exclude=lambda x: x == 'foo',
        encoder=int,
        decoder=float,
        mm_field=int,
        letter_case=lambda x: x.upper()
    )


# Generated at 2022-06-23 16:50:12.080000
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import datetime
    import uuid
    from enum import Enum
    from decimal import Decimal

    class Ticket(Enum):
        ONEWAY = 1
        ROUNDTRIP = 2

    o = {"time": datetime.datetime.now(timezone.utc), "uuid": uuid.uuid4(), "enumm": Ticket.ONEWAY, "decimal": Decimal('3.14')}
    a = _ExtendedEncoder().encode(o)
    e = json.dumps(o)
    assert a == e


# Generated at 2022-06-23 16:50:16.098345
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default([1, 2, 3])
    _ExtendedEncoder().default({'a': 1, 'b': 2, 'c': 3})
    _ExtendedEncoder().default(datetime.now())
    _ExtendedEncoder().default(UUID('12345678123456781234567812345678'))
    _ExtendedEncoder().default(Enum('test', 'ABC'))
    _ExtendedEncoder().default(Enum(1, {1: 'a', 2: 'b', 3: 'c'}))
    _ExtendedEncoder().default(Decimal('1.1'))
    _ExtendedEncoder().default(object())
    _ExtendedEncoder().default(MISSING)


# Generated at 2022-06-23 16:50:25.922710
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default("") == ""
    assert _ExtendedEncoder().default("abc") == "abc"
    assert _ExtendedEncoder().default(123) == 123
    assert _ExtendedEncoder().default(123.456) == 123.456
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default((1, 2, 3)) == [1, 2, 3]

# Generated at 2022-06-23 16:50:36.024999
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    enc = lambda x: x*3
    dec = lambda x: x*3

    def excl(x):
        return x == 0

    letter = lambda s: s.upper()
    override = FieldOverride(exclude=excl,
                             letter_case=letter,
                             encoder=enc,
                             decoder=dec)
    assert override.exclude(0) == True
    assert override.decoder(5) == 15
    assert override.encoder(5) == 15
    assert override.letter_case("hello") == "HELLO"


# Generated at 2022-06-23 16:50:47.358194
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = "abcd123"
    assert _ExtendedEncoder().default(o) == o

    o = [1, 2, 3]
    assert _ExtendedEncoder().default(o) == list(o)

    o = (1, 2, 3)
    assert _ExtendedEncoder().default(o) == list(o)

    o = {1: 2, 3: 4}
    assert _ExtendedEncoder().default(o) == dict(o)

    o = {1, 2, 3}
    assert _ExtendedEncoder().default(o) == list(o)

    o = frozenset({1, 2, 3})
    assert _ExtendedEncoder().default(o) == list(o)

    o = set()
    assert _ExtendedEncoder().default(o) == list(o)

   

# Generated at 2022-06-23 16:50:55.790391
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import datetime
    from decimal import Decimal
    from enum import Enum
    from uuid import UUID

    class Example(Enum):
        ONE = 1

    ex = Example.ONE

    for o in (frozenset([1, 2, 3]),
              {1: 2, 3: 4},
              (1, 2, 3),
              [1, 2, 3],
              datetime.now(timezone.utc),
              UUID('123e4567-e89b-12d3-a456-426655440000'),
              ex,
              Decimal('12.345667890123456789')):
        assert _ExtendedEncoder().default(o)



# Generated at 2022-06-23 16:51:05.460935
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps([datetime.now(timezone.utc)], cls=_ExtendedEncoder) == json.dumps([datetime.now(timezone.utc).timestamp()])
    json.dumps({datetime.now(timezone.utc):datetime.now(timezone.utc)}, cls=_ExtendedEncoder) == json.dumps({datetime.now(timezone.utc).timestamp():datetime.now(timezone.utc).timestamp()})
    json.dumps({2.0:2.0}, cls=_ExtendedEncoder) == json.dumps({2.0:2.0})

# Generated at 2022-06-23 16:51:16.590379
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Test FieldOverride constructor
    :return: 0 success, 1 fail
    """

# Generated at 2022-06-23 16:51:28.600356
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.utcnow())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678'))
    assert _ExtendedEncoder().encode(Enum('TestEnum', [('A', 1), ('B', 2)]))
    assert _ExtendedEncoder().encode(Decimal('1.0000'))
    assert _ExtendedEncoder().encode(set())
    assert _ExtendedEncoder().encode({})
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2})
    assert _ExtendedEncoder().encode(None)
    assert _ExtendedEncoder().encode(1)
    assert _ExtendedEncoder().encode(1.0)
    assert _ExtendedEncoder

# Generated at 2022-06-23 16:51:33.365242
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(exclude=lambda x: True,
                         encoder=json.dumps,
                         decoder=json.loads,
                         letter_case=lambda x: x.lower())



# Generated at 2022-06-23 16:51:41.605245
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = _ExtendedEncoder(strict=True)
    assert o.default(set([1, 2])) == [1, 2]
    assert o.default({1: {}}) == {1: {}}
    assert o.default(datetime.now()) == datetime.now().timestamp()
    assert o.default(UUID('0' * 32, version=4)) == '00000000-0000-0000-0000-000000000000'
    assert o.default(Decimal('1.0')) == '1.0'



# Generated at 2022-06-23 16:51:52.562130
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # it should be able to dump all types which json.JSONEncoder can dump
    json.dumps(1, cls=_ExtendedEncoder)
    json.dumps('hello', cls=_ExtendedEncoder)
    json.dumps(True, cls=_ExtendedEncoder)
    json.dumps(None, cls=_ExtendedEncoder)
    # it should be able to dump dataclass
    @dataclass
    class MyClass:
        a: int
        b: str

    assert len(json.dumps(MyClass(a=1, b='hello'), cls=_ExtendedEncoder)) > 0
    # it should be able to dump datetime
    assert len(json.dumps(datetime.utcnow(), cls=_ExtendedEncoder)) > 0
    # it

# Generated at 2022-06-23 16:52:03.871441
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEncoder().encode(UUID('5a5ec5fa-1c2c-452a-a2bd-bc3f15c63eec')) == '"5a5ec5fa-1c2c-452a-a2bd-bc3f15c63eec"'

# Generated at 2022-06-23 16:52:08.285472
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import datetime
    from uuid import uuid4
    encoder = _ExtendedEncoder()

    assert encoder.default(datetime.now(timezone.utc)) == datetime.now().timestamp()
    assert encoder.default(uuid4()) == str(uuid4())  # type: ignore



# Generated at 2022-06-23 16:52:16.837658
# Unit test for method default of class _ExtendedEncoder

# Generated at 2022-06-23 16:52:28.101326
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    obj = FieldOverride("a", "b", "c")
    assert obj.letter_case == "a"
    assert obj.exclude == "b"
    assert obj.encoder == "c"
    assert obj.decoder == None
    assert obj.mm_field == None

    obj = FieldOverride("a", "b", "c", "d", "e")
    assert obj.letter_case == "a"
    assert obj.exclude == "b"
    assert obj.encoder == "c"
    assert obj.decoder == "d"
    assert obj.mm_field == "e"


# Generated at 2022-06-23 16:52:33.845674
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """Test the FieldOverride constructor creates an expected object."""
    exclude=lambda v: isinstance(v, int) and v == 0
    override = FieldOverride(exclude=exclude)
    assert override.exclude is not None and callable(override.exclude)
    assert override.exclude(0)
    assert not override.exclude(False)


# Generated at 2022-06-23 16:52:40.782098
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default(datetime.now()) is not None
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().default(Enum('Foo', ('a', 'b'))(1)) == 'b'
    assert _ExtendedEncoder().default(Decimal('0.1')) == '0.1'



# Generated at 2022-06-23 16:52:50.459722
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import json
    encoder = _ExtendedEncoder()
    for type in [int, str, float, bool, None, '', [], {}, ()]:
        assert encoder.default(type) == type
    for type in [datetime.now(), UUID('a3d3b4a4-8f02-4f9d-a701-76b0355cae38')]:
        assert encoder.default(type) == type
    assert encoder.default(Decimal('10.1')) == '10.1'
    assert encoder.default(Decimal('10.01')) == '10.01'
    assert encoder.default(Decimal('10.001')) == '10.001'



# Generated at 2022-06-23 16:52:51.185276
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = {}
    _ExtendedEncoder().default(o)


# Generated at 2022-06-23 16:52:56.031323
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert encoder.default(datetime(1988, 11, 2, 0, 0, 0, tzinfo=timezone.utc)) \
           == 562739200.0
    assert encoder.default(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(('a', 'b')) == ['a', 'b']



# Generated at 2022-06-23 16:53:02.291719
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import datetime
    from uuid import UUID
    from enum import Enum
    from decimal import Decimal

    class MyDict(dict):
        pass

    class MyList(list):
        pass

    class MyDatetime(datetime):
        pass

    class MyUUID(UUID):
        pass

    class MyEnum(Enum):
        pass

    class MyDecimal(Decimal):
        pass

    class MyString(str):
        pass

    class MyInt(int):
        pass

    class MyFloat(float):
        pass

    class MyBool(bool):
        pass

    class MyNone(None):
        pass

    assert _ExtendedEncoder().default(MyDict()) == dict()
    assert _ExtendedEncoder().default(MyList()) == list()
    assert _

# Generated at 2022-06-23 16:53:04.537744
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(
        exclude=None, letter_case=None, encoder=None, decoder=None,
        mm_field=None)



# Generated at 2022-06-23 16:53:09.574360
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = json.JSONEncoder()
    x = _ExtendedEncoder()
    result = x.default(Enum('Enum', 'a b c'))
    expect = e.default(Enum('Enum', 'a b c'))
    assert result == expect



# Generated at 2022-06-23 16:53:16.563096
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([datetime(1969, 5, 20)]) == '[1969]'
    assert _ExtendedEncoder().encode([UUID('29d0cab3-95ba-4a2e-8fcc-a4a07f9b9d9c')]) == '["29d0cab3-95ba-4a2e-8fcc-a4a07f9b9d9c"]'
    assert _ExtendedEncoder().encode([Decimal('42')]) == '["42"]'

# unit test for encode

# Generated at 2022-06-23 16:53:27.642760
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({1, 2, 3}) == [1, 2, 3]
    assert encoder.default(set((1, 2, 3))) == [1, 2, 3]
    assert encoder.default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert encoder.default(tuple((1, 2, 3))) == [1, 2, 3]
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()

# Generated at 2022-06-23 16:53:38.412331
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class FOO(dataclass):
        a: str
        b: str

    class BAR(dataclass):
        a: FOO
        c: int = dataclasses_json.config(mm_field=fields.Integer())
        d: str = dataclasses_json.field(metadata={'exclude': lambda x: x is ''})

    d = BAR(a=FOO(a='a', b='b'), c=4, d='')

    overrides = _user_overrides_or_exts(d)
    assert overrides['a'].encoder == _encode_dataclass
    assert overrides['a'].decoder == _decode_dataclass
    assert overrides['c'].encoder == int
    assert overrides['c'].decoder == int

# Generated at 2022-06-23 16:53:47.966152
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    obj = _ExtendedEncoder()
    assert obj.default((1, 2, 3)) == [1, 2, 3]
    assert obj.default([1, 2, 3]) == [1, 2, 3]
    assert obj.default({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert obj.default(datetime(1970, 1, 1, 0, 0, 0, 0, timezone.utc)) == 0.0
    assert obj.default(UUID("f47ac10b-58cc-4372-a567-0e02b2c3d479")) == "f47ac10b-58cc-4372-a567-0e02b2c3d479"
    assert obj.default(Decimal("1.23")) == "1.23"
   

# Generated at 2022-06-23 16:53:58.823464
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert not FieldOverride(exclude=None, letter_case=None, encoder=None, decoder=None).exclude(None)
    assert FieldOverride(exclude=lambda x: x is not None, letter_case=None, encoder=None, decoder=None).exclude(None)
    assert not FieldOverride(exclude=lambda x: x is not None, letter_case=None, encoder=None, decoder=None).exclude(object)
    assert FieldOverride(exclude=None, letter_case=str.upper, encoder=None, decoder=None).letter_case("") == "", "letter_case ignored"

# Generated at 2022-06-23 16:54:00.389426
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder(default=_ExtendedEncoder.default) is not None


# Generated at 2022-06-23 16:54:12.717145
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

    tzinfo = timezone.utc
    now = datetime.now(tzinfo)
    later = now + timedelta(seconds=10)
    diff = later - now
    assert isinstance(diff, timedelta)

    assert encoder.encode(now) == str(now.timestamp())

    assert encoder.encode(set()) == '[]'
    assert encoder.encode(set('abc')) == '["a", "b", "c"]'
    assert encoder.encode({'x': 'y'}) == '{"x": "y"}'
    assert encoder.encode({'x', 'y'}) == '["x", "y"]'


# Generated at 2022-06-23 16:54:20.951904
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default('a') == 'a'
    assert _ExtendedEncoder().default(9) == 9
    assert _ExtendedEncoder().default(9.01) == 9.01
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default({'a': 1}) == {'a': 1}

# Generated at 2022-06-23 16:54:21.587543
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default(): pass



# Generated at 2022-06-23 16:54:31.023161
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().encode([1, 2, 3])
    _ExtendedEncoder().encode([1, 2, 3])
    _ExtendedEncoder().encode({"a": 2})
    _ExtendedEncoder().encode({"a": 2})
    _ExtendedEncoder().encode(datetime.now(timezone.utc))
    _ExtendedEncoder().encode(UUID('b5d5c5f5-f8b6-4a4f-b6f4-b4c7f57d6c98'))
    _ExtendedEncoder().encode(Decimal('0.5'))



# Generated at 2022-06-23 16:54:37.141410
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({1, 2, 3}) == [1, 2, 3]
    assert _ExtendedEncoder().default({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default(UUID(int=0x12345)) == '00000000-0000-0000-0000-000000001234'
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'



# Generated at 2022-06-23 16:54:43.912228
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """Make sure constructor of FieldOverride works as expected."""
    # test with the default value of kwargs
    field_override = FieldOverride()
    assert field_override.exclude is None
    assert field_override.letter_case is None
    assert field_override.encoder is None
    assert field_override.decoder is None

    # test with inputted kwargs
    def e(x):
        return x
    def d(x):
        return x
    field_override = FieldOverride(exclude=e, letter_case=lambda x: x,
                                   encoder=e, decoder=d)
    assert field_override.exclude == e

# Generated at 2022-06-23 16:54:54.524391
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    r"""
    Test for method default of class _ExtendedEncoder
    """
    # _ExtendedEncoder.default(o)
    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default({1: 2}) == {1: 2}
    assert _ExtendedEncoder().default(datetime(2000, 1, 1)) == \
           datetime(2000, 1, 1).timestamp()
    assert _ExtendedEncoder().default(UUID('eecb8a12-400d-4462-9726-6b62d8c1120a')) \
           == 'eecb8a12-400d-4462-9726-6b62d8c1120a'
    assert _ExtendedEncoder().default(Enum) == 0


# Generated at 2022-06-23 16:55:00.405294
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride() == FieldOverride(None, None, None)
    assert FieldOverride(1) == FieldOverride(1, None, None)
    assert FieldOverride(None, 2) == FieldOverride(None, 2, None)
    assert FieldOverride(None, None, 3) == FieldOverride(None, None, 3)



# Generated at 2022-06-23 16:55:08.126292
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default([0, 1, 2]) == [0, 1, 2]
    assert _ExtendedEncoder().default({'a': 1}) == {'a': 1}
    assert _ExtendedEncoder().default(datetime(2020, 1, 1)) == 1577836800.0
    assert _ExtendedEncoder().default(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(Decimal('1.1')) == str(Decimal('1.1'))

