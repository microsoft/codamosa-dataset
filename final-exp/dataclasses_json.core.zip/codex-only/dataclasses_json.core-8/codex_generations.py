

# Generated at 2022-06-23 16:45:14.804326
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    tim = datetime(2020, 1, 1, tzinfo=timezone.utc)
    dec = Decimal('0.01')
    uid = '116bd838-3f3e-11ea-90c3-a50f9a3ebf0e'
    uid = UUID(uid)
    enu = ExampleEnum.two
    ext = _ExtendedEncoder()
    assert ext.default(tim) == tim.timestamp()
    assert ext.default(dec) == str(dec)
    assert ext.default(uid) == uid.hex
    assert ext.default(enu) == enu.value
    assert ext.default(10) == 10



# Generated at 2022-06-23 16:45:24.559242
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert _ExtendedEncoder().default({'a': 'b', 'c': 'd'}) == {'a': 'b', 'c': 'd'}
    assert _ExtendedEncoder().default(datetime.now()) > 0
    assert _ExtendedEncoder().default(UUID('d65502a6-314e-4f0c-9161-6935c6b32a6b')) == 'd65502a6-314e-4f0c-9161-6935c6b32a6b'
    assert _ExtendedEncoder().default(Decimal('12.34')) == '12.34'

# Generated at 2022-06-23 16:45:29.538529
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    def exclude_func(val):
        return val == 1

    encoder_func = lambda val: val + 1

    override = FieldOverride(letter_case=lambda val: val.upper(),
                             exclude=exclude_func,
                             encoder=encoder_func)

    assert override.letter_case("test") == "TEST"
    assert override.exclude(1) == True
    assert override.encoder(2) == 3



# Generated at 2022-06-23 16:45:31.594207
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    pass


# Generated at 2022-06-23 16:45:41.920913
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    def my_encoder(x):
        return x

    def my_decoder(x):
        return x

    mm_field = MMField()

    # Test letter case
    assert FieldOverride(letter_case=my_letter_case).letter_case(
        "helloWorld") == "HelloWorld"
    assert FieldOverride(letter_case=None).letter_case("helloWorld") == "helloWorld"

    # Test exclude
    assert FieldOverride(exclude=my_exclude).exclude("test") == False
    assert FieldOverride(exclude=None).exclude("test") == False

    # Test encoder
    assert FieldOverride(
        encoder=my_encoder).encoder("test") == "test"
    assert FieldOverride(encoder=None).encoder("test") == "test"

    # Test decoder


# Generated at 2022-06-23 16:45:44.260575
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    pass


_decimal_from_str = Decimal.from_float
_fromtimestamp_utc_convert = timezone.utc.localize



# Generated at 2022-06-23 16:45:45.483478
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _ExtendedEncoder().default(1) == 1


# Generated at 2022-06-23 16:45:56.053237
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert '{"value": 1}' == json.dumps(dict(value=1), cls=_ExtendedEncoder)
    assert '{"value": [1, 2]}' == json.dumps(dict(value=[1, 2]), cls=_ExtendedEncoder)
    assert '{"value": {"inner": [1, 2]}}' == json.dumps(dict(value=dict(inner=[1, 2])), cls=_ExtendedEncoder)
    assert '{"value": "abc"}' == json.dumps(dict(value="abc"), cls=_ExtendedEncoder)
    assert '{"value": 42}' == json.dumps(dict(value=42), cls=_ExtendedEncoder)

# Generated at 2022-06-23 16:46:06.801364
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    from dataclasses_json.core import FieldOverride
    from dataclasses import field
    from typing import Optional
    class C:
        t = field(default=None, metadata={"dataclasses_json": {"exclude":
                                                               "True"}})
        x = field(default=None, metadata={"dataclasses_json": {"exclude":
                                                               "False"}})
        # This is the same as above since the key is missing:
        y = field(default=None, metadata={"dataclasses_json": {}})
        # This is the same as above since the defaults are used:
        z = field(default=None)

# Generated at 2022-06-23 16:46:17.955538
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class MyClass:
        def __init__(self, x=1):
            self.x = x

    # A typed function for the marker of `_FieldOverride.exclude`
    def is_x_one(value):
        return value.x == 1

    # Create a new instance of `FieldOverride`
    override = FieldOverride(exclude=is_x_one, letter_case=str.lower,
                             encoder=lambda x: x + 1, decoder=lambda x: x - 1)

    # Test the `FieldOverride.exclude` method
    assert override.exclude(MyClass(x=1))
    assert not override.exclude(MyClass(x=2))

    # Test the `FieldOverride.letter_case` method
    assert override.letter_case("MyName") == "myname"

    #

# Generated at 2022-06-23 16:46:28.031036
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(TypeError):
        FieldOverride()
    with pytest.raises(TypeError):
        FieldOverride(exclude=True)
    with pytest.raises(TypeError):
        FieldOverride(letter_case=lambda x: x)
    with pytest.raises(TypeError):
        FieldOverride(encoder=lambda x: x)
    with pytest.raises(TypeError):
        FieldOverride(decoder=lambda x: x)
    with pytest.raises(TypeError):
        FieldOverride(exclude=True,
                      letter_case=lambda x: x,
                      encoder=lambda x: x,
                      decoder=lambda x: x)
    FieldOverride(exclude=True, encoder=lambda x: x)

# Generated at 2022-06-23 16:46:34.420720
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    override = FieldOverride(
        'snake_case',
        lambda x: x + 1,
        lambda x: x - 1,
        lambda x: True,
        {'mm_field': 1}
    )
    assert override.letter_case == 'snake_case'
    assert override.encoder(2) == 3
    assert override.decoder(3) == 2
    assert override.exclude(5) is True
    assert override.mm_field == {'mm_field': 1}



# Generated at 2022-06-23 16:46:41.380690
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode({'b': [1, 2], 'a': {1: 2, 3: 4}}) == '{"a": {"1": 2, "3": 4}, "b": [1, 2]}'



# Generated at 2022-06-23 16:46:50.658149
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test case 1: Check that default values are assigned for all attributes
    field_override = FieldOverride()
    override_attrs = dir(FieldOverride.__init__)
    for attr in dir(field_override):
        if attr not in override_attrs:
            assert attr == 'exclude'
            assert field_override.exclude is None
        if attr not in override_attrs:
            assert attr == 'letter_case'
            assert field_override.letter_case is None
        if attr not in override_attrs:
            assert attr == 'encoder'
            assert field_override.encoder is None
        if attr not in override_attrs:
            assert attr == 'decoder'
            assert field_override.decoder is None

# Generated at 2022-06-23 16:47:00.188863
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(exclude=lambda x: x is None,
                                   letter_case='lower',
                                   encoder=json.dumps,
                                   decoder=json.loads,
                                   mm_field=fields.Str())
    assert field_override.exclude is not None
    assert field_override.letter_case is not None
    assert field_override.encoder is not None
    assert field_override.decoder is not None
    assert field_override.mm_field is not None
    assert field_override.mm_field.__class__.__name__ == 'Str'

# Generated at 2022-06-23 16:47:08.012505
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import date
    from decimal import Decimal

    def func(o: Any) -> bool:
        e = _ExtendedEncoder()
        try:
            json_str = e.encode(o)
        except TypeError:
            return False
        return json.loads(json_str)

    assert func(list()) == list()
    assert func(set()) == list()
    assert func(dict()) == dict()
    assert func(range(3)) == [0, 1, 2]
    assert func(True) is True
    assert func(1) == 1
    assert func(1.2) == 1.2
    assert func(Decimal('1.3')) == '1.3'
    assert func('a') == 'a'
    assert func(date(2019, 1, 1)) == 1546426000

# Generated at 2022-06-23 16:47:15.939232
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _to_json({1, 2, 3}) == [1, 2, 3]
    assert _to_json({1: 1, 2: 2, 3: 3}) == {"1": 1, "2": 2, "3": 3}
    assert _to_json([1, 2, 3]) == [1, 2, 3]
    assert _to_json([1, [2, 3]]) == [1, [2, 3]]
    assert _to_json((1, 2, 3)) == [1, 2, 3]
    assert _to_json(frozenset({1, 2, 3})) == [1, 2, 3]
    assert _to_json(False) is False
    assert _to_json(1) == 1
    assert _to_json(1.111) == 1.111
    assert _to

# Generated at 2022-06-23 16:47:20.822501
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field = FieldOverride(exclude=None, decoder=None, encoder=None,
                          letter_case=None)
    assert field.exclude is None
    assert field.decoder is None
    assert field.encoder is None
    assert field.letter_case is None

    field = FieldOverride(exclude=bool, decoder=object, encoder=object,
                          letter_case=str.upper)
    assert field.exclude is bool
    assert field.decoder is object
    assert field.encoder is object
    assert field.letter_case is str.upper



# Generated at 2022-06-23 16:47:30.951944
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

    assert encoder.default(list(range(3))) == [0, 1, 2]
    assert encoder.default(dict(zip(range(3), range(3)))) == {x: x for x in range(3)}
    assert encoder.default(datetime(1970, 1, 1, tzinfo=timezone.utc)) == 0
    assert encoder.default(UUID('59a3a142-3cae-47d7-81a0-f902f52c2aee')) == '59a3a142-3cae-47d7-81a0-f902f52c2aee'
    # assert encoder.default(Trafaret(lambda x: True)) == 'Trafaret'  # issue #34
    assert encoder.default

# Generated at 2022-06-23 16:47:40.741773
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Normal case:
    json.loads(json.dumps(1, cls=_ExtendedEncoder))
    json.loads(json.dumps(1.0, cls=_ExtendedEncoder))
    json.loads(json.dumps(True, cls=_ExtendedEncoder))
    json.loads(json.dumps("hello", cls=_ExtendedEncoder))

    # Collection:
    json.loads(json.dumps([1, 2, 3], cls=_ExtendedEncoder), list)
    json.loads(json.dumps({1: 2}, cls=_ExtendedEncoder), dict)

    # Datetime and UUID:
    now = datetime.now(tz=timezone.utc)

# Generated at 2022-06-23 16:47:41.565405
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-23 16:47:46.727132
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fl = FieldOverride(exclude=lambda x: True)
    assert fl.exclude(1)
    assert fl.letter_case is None
    assert fl.encoder is None
    assert fl.decoder is None

    tc = FieldOverride(letter_case=str.upper)
    assert tc.letter_case("a") == "A"
    assert tc.exclude is None
    assert tc.encoder is None
    assert tc.decoder is None

    ec = FieldOverride(encoder=str)
    assert ec.encoder(1) == "1"
    assert ec.letter_case is None
    assert ec.exclude is None
    assert ec.decoder is None

    dc = FieldOverride(decoder=str)
    assert dc.decoder(1) == "1"
    assert dc.letter_case is None

# Generated at 2022-06-23 16:47:56.613169
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from unittest.mock import MagicMock
    from datetime import datetime
    from enum import Enum
    from decimal import Decimal

    obj = MagicMock()
    obj.__json__ = MagicMock(return_value=10)
    assert _ExtendedEncoder().default(obj) == 10

    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default({1, 2, 3}) == list(set([1, 2, 3]))
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

    dt = datetime(2001,1,1, tzinfo=timezone.utc)
    assert _ExtendedEncoder().default(dt) == 980985600.0


# Generated at 2022-06-23 16:48:02.638585
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    d = datetime(1970, 1, 1, tzinfo=timezone.utc)
    assert _ExtendedEncoder().default(d) == 0
    assert _ExtendedEncoder().default(UUID('2e2a6f28-2cc2-4d05-b0e1-84c1b8d9eed0')) \
        == '2e2a6f28-2cc2-4d05-b0e1-84c1b8d9eed0'
    assert _ExtendedEncoder().default(Decimal('1.0')) == '1.0'


# Generated at 2022-06-23 16:48:14.790014
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import date, time
    e = _ExtendedEncoder()
    assert e.encode([1, 2, 3]) == '[1, 2, 3]'
    assert e.encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert e.encode(datetime(2010, 1, 1, 12, 0, 0, tzinfo=timezone.utc)) == '1262268800.0'
    assert e.encode(date(2010, 1, 1)) == '1262268800.0'
    assert e.encode(time(12, 0, 0)) == '43200.0'

# Generated at 2022-06-23 16:48:24.943817
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert not _is_dataclass_instance(1)
    assert not _is_dataclass_instance(1.1)
    assert not _is_dataclass_instance('1')
    assert not _is_dataclass_instance(True)
    assert not _is_dataclass_instance((1, 2))
    assert not _is_dataclass_instance([1, 2])
    assert not _is_dataclass_instance({'a': 1, 'b': 2})
    assert not _is_dataclass_instance(UUID('11111111-1111-1111-1111-111111111111'))
    assert not _is_dataclass_instance(datetime.now())
    assert not _is_dataclass_instance(datetime.now(timezone.utc))
    assert not _is_datac

# Generated at 2022-06-23 16:48:33.634195
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    decoder = _ExtendedEncoder()
    assert decoder.default(1) == 1
    assert decoder.default(1.2) == 1.2
    assert decoder.default("string") == "string"
    assert decoder.default([1, 2]) == [1, 2]
    assert decoder.default({'a': 1}) == {'a': 1}
    assert decoder.default(datetime.now(timezone.utc))
    assert decoder.default(UUID('{12345678-1234-5678-1234-567812345678}'))
    assert decoder.default(cfg.preserve_order)
    with pytest.raises(TypeError):
        decoder.default(object())



# Generated at 2022-06-23 16:48:37.773027
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # create FieldOverride for a given string key name
    default_override = FieldOverride("name")
    # test whether the name is valid or not
    assert default_override.name == "name"

    # create FieldOverride with a name, exclude, letter_case, encoder, decoder
    field_override = FieldOverride("name", lambda x: False, str.lower,
                                   lambda x: "encoded", lambda x: "decoded")
    # test whether the name is valid or not
    assert field_override.name == "name"
    # test whether the exclude returns false
    assert not field_override.exclude("value")
    # test whether letter_case return the lower case of a string
    assert field_override.letter_case("NAME") == "name"
    # test whether the encoder returns "encoded"

# Generated at 2022-06-23 16:48:47.404515
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():

    encoder = _ExtendedEncoder()

    # Test with different types
    d = defaultdict(str)
    assert encoder.default(d) == {}
    assert encoder.default(list(range(5))) == [0, 1, 2, 3, 4]
    assert encoder.default(dict(zip([0, 1, 2], [4, 3, 2]))) == {0: 4, 1: 3, 2: 2}
    assert encoder.default(set(range(5))) == list(range(5))
    dt = datetime(2001, 1, 1, tzinfo=timezone.utc)
    assert encoder.default(dt) == 978307200.0
    u = UUID('{12345678-1234-5678-1234-567812345678}')

# Generated at 2022-06-23 16:48:59.596602
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import  datetime
    from pytz import timezone
    from uuid import UUID
    @dataclass_json
    @dataclass
    class C(object):
        z: int = 1
    jp = _ExtendedEncoder()
    assert jp.default([1,2,3]) == [1,2,3]
    assert jp.default({1:2,3:4}) == {1:2,3:4}
    assert jp.default(datetime(2020,2,2,1,1,1,tzinfo=timezone.utc)) == 1580652061.0
    assert jp.default(UUID(int=1)) == '00000000-0000-0000-0000-000000000001'
    assert jp.default(C()) == {'z': 1}

# Generated at 2022-06-23 16:49:05.557609
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda x: x
    decoder = lambda y: y
    f = FieldOverride(True, lambda z: z, "snake_case", encoder, decoder)
    assert f.exclude == True
    assert f.letter_case("foo") == "foo"
    assert f.encoder == encoder
    assert f.decoder == decoder


# Generated at 2022-06-23 16:49:10.700572
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(exclude=any) is not None
    assert FieldOverride(letter_case=lowercase) is not None
    assert FieldOverride(encoder=partial(str.upper)) is not None
    assert FieldOverride(decoder=lambda x: x) is not None
    assert FieldOverride(mm_field=lambda x: x) is not None



# Generated at 2022-06-23 16:49:18.913300
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(42) == 42
    assert encoder.default(42.42) == 42.42
    assert encoder.default('42') == '42'
    assert encoder.default(datetime(2020, 1, 1)) == 1577854400
    assert encoder.default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577854400

# Generated at 2022-06-23 16:49:29.006146
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == "null"
    assert _ExtendedEncoder().encode(False) == "false"
    assert _ExtendedEncoder().encode(123) == "123"
    assert _ExtendedEncoder().encode(["a", "b"]) == '["a", "b"]'
    assert _ExtendedEncoder().encode({"a": 123}) == '{"a": 123}'
    assert _ExtendedEncoder().encode({"a": [1, 2]}) == '{"a": [1, 2]}'
    assert _ExtendedEncoder().encode({'a': [{'b': 1}, {'b': 2}]}) == '{"a": [{"b": 1}, {"b": 2}]}'

# Generated at 2022-06-23 16:49:36.659164
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(exclude=lambda x : True,
                                   letter_case=upper_camelcase,
                                   encoder = lambda x : "abcd1234")
    assert field_override.exclude(1234) == True
    assert field_override.letter_case("abCd") == "ABCD"
    assert field_override.encoder("abcd") == "abcd1234"


# Generated at 2022-06-23 16:49:40.320841
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps(UUID('f47ac10b-58cc-4372-a567-0e02b2c3d479'), cls=_ExtendedEncoder)


# Generated at 2022-06-23 16:49:49.039379
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    import datetime
    dict_ = dict(a=1, b=1.1, c='c', d=datetime.datetime(2019, 10, 11, 22, 16, 30), e=datetime.datetime(2019, 10, 11, 22, 16, 30, tzinfo=datetime.timezone(datetime.timedelta(hours=9), 'JST')), f=datetime.date(2019, 10, 11), g=[1, 'a', 1.5], h=['a', 'b', 'c'], i=True, j=False, k=None, l=dict(a=1, b=2, c=3))
    print(dict_)
    json_str = encoder.encode(dict_)
    print(json_str)
    js

# Generated at 2022-06-23 16:49:54.686734
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    j = _ExtendedEncoder().encode({'a': datetime.utcnow(), 'b': {'c': {'d': 'e'}}, 'c': [1, 2]})
    # print(j)
    assert len(j) > 0


# noinspection PyProtectedMember

# Generated at 2022-06-23 16:50:01.148036
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = _ExtendedEncoder().default({1, 2, 3})
    assert o == [1, 2, 3]
    o = _ExtendedEncoder().default({1: 2, 3: 4})
    assert o == {1: 2, 3: 4}
    o = _ExtendedEncoder().default(datetime(2020, 1, 1, tzinfo=timezone.utc))
    assert o == 1577836800.0
    o = _ExtendedEncoder().default(UUID('b883a339-faf5-4f95-a4d0-2b4ea4bd4b0f'))
    assert o == 'b883a339-faf5-4f95-a4d0-2b4ea4bd4b0f'
    class E(Enum):
        A = 3


# Generated at 2022-06-23 16:50:10.110497
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime(2000, 1, 1)) == 946684800.0
    assert encoder.default(datetime(2000, 1, 1, tzinfo=timezone.utc)) == 946684800.0
    assert encoder.default(UUID('1e096f72-c7e1-11e8-b0a2-0242ac120004')) == '1e096f72-c7e1-11e8-b0a2-0242ac120004'
    assert encoder.default(1) == 1


# Generated at 2022-06-23 16:50:14.588058
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    """
    >>> test__ExtendedEncoder_default()
    """
    encoder = _ExtendedEncoder()
    for v in [dict(), list(), str(), int(), float(), bool(), None]:
        assert encoder.default(v) == v

    class C: pass
    now = datetime.now(timezone.utc)
    uid = UUID(int=1)
    for v in [C(), now, uid, Enum('UID', (('ONE', uid),)), Decimal(1.1)]:
        assert encoder.default(v) != v


# Generated at 2022-06-23 16:50:20.356620
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test bare minimum usage
    FieldOverride()
    # test all options
    exclude = lambda x: x
    encoder = lambda x: x
    decoder = lambda x: x
    FieldOverride(exclude=exclude, encoder=encoder, decoder=decoder)


# Unit tests for `_letter_case_overrides`

# Generated at 2022-06-23 16:50:32.429254
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(1) == 1
    assert encoder.default(1.5) == 1.5
    assert encoder.default('a') == 'a'
    assert encoder.default(('a',)) == ['a']
    assert encoder.default(('a', 'b')) == ['a', 'b']
    assert encoder.default(['a']) == ['a']
    assert encoder.default(('a', ['b'])) == ['a', ['b']]
    assert encoder.default({'a': 'b'}) == {'a': 'b'}

# Generated at 2022-06-23 16:50:37.276464
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    result = _ExtendedEncoder().default(
        # Use a set to test the default-method.
        set([1, 2, 3])
    )
    assert isinstance(result, list)
    assert result == [1, 2, 3]



# Generated at 2022-06-23 16:50:48.088552
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == 1589519223.568834
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(Decimal('3.14')) == '3.14'
    assert _ExtendedEncoder().default(cfg.NaN) == 'NaN'
    assert _ExtendedEncoder().default(cfg.Infinity) == 'Infinity'

# Generated at 2022-06-23 16:50:57.402182
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # pylint: disable=missing-docstring
    import pytest
    from .common import TestDataClass

    Test1 = TestDataClass('Test1')

    @dataclass
    class Test2(TestDataClass):
        pass

    @dataclass
    class Test3(TestDataClass):
        a_field: TestDataClass

    Test4 = TestDataClass('Test4')
    Test5 = TestDataClass('Test5')
    Test6 = TestDataClass('Test6')

    @dataclass
    class Test7(TestDataClass):
        a_field: TestDataClass

    Test8 = TestDataClass('Test8')

    with pytest.raises(TypeError):
        # Cannot construct without a required parameter `letter_case`
        FieldOverride()  # type: ignore


# Generated at 2022-06-23 16:51:01.595670
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(exclude=False,decoder='me',encoder='you',letter_case=None)
    assert fo.exclude == False
    assert fo.decoder == 'me'
    assert fo.encoder == 'you'
    assert fo.letter_case == None

# Generated at 2022-06-23 16:51:14.431031
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder().default
    assert encoder(Decimal('123')) == '123'
    assert encoder(123) == 123
    assert encoder(5.5) == 5.5
    assert encoder('123') == '123'
    assert encoder(True) == True
    assert encoder(False) == False
    assert encoder(None) == None
    assert encoder({'x': 1, 'y': 2}) == {'x': 1, 'y': 2}
    assert encoder([1, 2, 3]) == [1, 2, 3]
    assert encoder(set([1, 2, 3])) == [1, 2, 3]
    datetime_obj = datetime(2012, 10, 29, 12, 23, 0, 0, timezone.utc)
    assert encoder

# Generated at 2022-06-23 16:51:27.815236
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime(2018, 12, 10, 0, 0, 0)) == dict(__dataclass_json__=1544325600)
    assert encoder.default(dict(a=1)) == dict(a=1)
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default(UUID('123e4567-e89b-12d3-a456-426655440000')) == str(UUID('123e4567-e89b-12d3-a456-426655440000'))
    assert encoder.default(Decimal('12.0')) == str(Decimal('12.0'))
    assert encoder.default(None) is None

# Generated at 2022-06-23 16:51:39.621225
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    enc = lambda x: x + 1
    dec = lambda x: x - 1
    f1 = FieldOverride(exclude=lambda x: x > 3,
                       letter_case=lambda x: x.upper(),
                       encoder=enc,
                       decoder=dec)
    assert f1.exclude(4) is True
    assert f1.exclude(3) is False
    assert f1.exclude(2) is False
    assert f1.letter_case('a') == 'A'
    assert f1.letter_case('A') == 'A'
    assert f1.letter_case('m') == 'M'
    assert f1.encoder(1) == 2
    assert f1.encoder(2) == 3
    assert f1.encoder(3) == 4

# Generated at 2022-06-23 16:51:50.199408
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(encoder=1, exclude=2, letter_case=3) == {'encoder': 1, 'exclude': 2, 'letter_case': 3}
    assert FieldOverride(encoder=1, exclude=2) == {'encoder': 1, 'exclude': 2}
    assert FieldOverride(encoder=1, exclude=2, letter_case=None) == {'encoder': 1, 'exclude': 2}
    assert FieldOverride(exclude=2, letter_case=3) == {'exclude': 2, 'letter_case': 3}
    assert FieldOverride(letter_case=3) == {'letter_case': 3}

# Generated at 2022-06-23 16:52:02.278682
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Encode
    # Test1: Test all the 3 parameters:
    #        letter_case,exclude,encoder
    letter = lambda obj: "test"
    exclude = lambda obj: True
    encoder = _encode_json_type
    field_override = FieldOverride(letter_case=letter, exclude=exclude, encoder=encoder)
    assert(field_override.letter_case == letter)
    assert(field_override.exclude == exclude)
    assert(field_override.encoder == encoder)

    # Test2: Test only 1 parameter: exclude
    exclude = lambda obj: False
    field_override2 = FieldOverride(exclude=exclude)
    assert(field_override2.exclude == exclude)

    # Test3: Test only 1 parameter: letter_case
    letter

# Generated at 2022-06-23 16:52:08.768463
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    x = FieldOverride(encoder=1, decoder=2, exclude=3, letter_case=4)
    assert x.encoder == 1
    assert x.decoder == 2
    assert x.exclude == 3
    assert x.letter_case == 4

    y = FieldOverride()
    assert y.encoder is None
    assert y.decoder is None
    assert y.exclude is None
    assert y.letter_case is None

# Generated at 2022-06-23 16:52:18.564622
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default(()) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(frozenset()) == []
    assert _ExtendedEncoder().default(
        datetime(2019, 12, 31, 23, 59, 59, tzinfo=timezone.utc)) == 1577780799.0
    assert _ExtendedEncoder().default(UUID('e2e4d8a6-e0ed-4fc6-b08d-8e6bbaa6b006')) == 'e2e4d8a6-e0ed-4fc6-b08d-8e6bbaa6b006'


# Generated at 2022-06-23 16:52:30.693223
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    o = object()
    assert o == encoder.default(o)

    o = [1, 2, 3]
    assert o == encoder.default(o)
    o = tuple(o)
    assert [1, 2, 3] == encoder.default(o)
    o = set(o)
    assert [1, 2, 3] == encoder.default(o)
    o = frozenset(o)
    assert [1, 2, 3] == encoder.default(o)

    o = dict(a=1, b=2, c=3)
    assert o == encoder.default(o)

    o = datetime.now(timezone.utc)
    # noinspection PyTypeChecker

# Generated at 2022-06-23 16:52:35.764056
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(exclude=lambda x: True,
                      letter_case=lambda x: "foo",
                      encoder=str)
    assert f.exclude(1)
    assert f.letter_case("foo") == "foo"
    assert f.encoder(1) == "1"

# Generated at 2022-06-23 16:52:49.126637
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _assert_default(o={}, result={})
    _assert_default(o={'a': 1}, result={'a': 1})
    _assert_default(o=[], result=[])
    _assert_default(o=[1, 2, 3], result=[1, 2, 3])
    _assert_default(o=(), result=[])
    _assert_default(o=(1, 2, 3), result=[1, 2, 3])
    _assert_default(o=str(), result=str())
    _assert_default(o=str('sdfsdf'), result=str('sdfsdf'))
    _assert_default(o=int(), result=int())
    _assert_default(o=int(123), result=int(123))
    _assert_default(o=float(), result=float())
    _assert

# Generated at 2022-06-23 16:53:01.418178
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field = FieldOverride("A")
    assert isinstance(field, FieldOverride)
    assert field.letter_case == "A"
    assert field.decoder is None
    assert field.encoder is None
    assert field.exclude is None
    field = FieldOverride("A", "B")
    assert field.letter_case == "A"
    assert field.decoder == "B"
    assert field.encoder is None
    assert field.exclude is None
    field = FieldOverride("A", "B", "C")
    assert field.letter_case == "A"
    assert field.decoder == "B"
    assert field.encoder == "C"
    assert field.exclude is None
    field = FieldOverride("A", "B", "C", "D")
    assert field.letter_case == "A"

# Generated at 2022-06-23 16:53:04.589655
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoded_result = json.dumps(list(range(3)), cls=_ExtendedEncoder)
    assert encoded_result == '[0,1,2]'


# noinspection PyProtectedMember

# Generated at 2022-06-23 16:53:14.101484
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    o1 = FieldOverride()
    assert o1.mm_field is None
    assert o1.exclude is None
    assert o1.letter_case is None
    assert o1.encoder is None
    assert o1.decoder is None
    o2 = FieldOverride(Integer(), lambda x: x, lambda x: x, lambda x: x, lambda x: x)
    assert o2.mm_field == Integer()
    assert callable(o2.exclude)
    assert callable(o2.letter_case)
    assert callable(o2.encoder)
    assert callable(o2.decoder)


# Generated at 2022-06-23 16:53:19.434863
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    g = FieldOverride(
        exclude=lambda x: True,
        letter_case=identity,
        encoder=identity,
        decoder=identity
    )
    g.exclude = lambda x: True
    g.letter_case = identity
    g.encoder = identity
    g.decoder = identity



# Generated at 2022-06-23 16:53:30.592175
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    json.dumps(1, cls=_ExtendedEncoder)
    json.dumps([1, 2], cls=_ExtendedEncoder)
    json.dumps({'a': 1}, cls=_ExtendedEncoder)
    json.dumps(UUID('1' * 36), cls=_ExtendedEncoder)
    json.dumps(datetime(2019, 1, 1, 0, 0, 0, tzinfo=timezone.utc), cls=_ExtendedEncoder)
    json.dumps(Enum('A', 'a'), cls=_ExtendedEncoder)
    json.dumps(Decimal(2), cls=_ExtendedEncoder)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')

# Generated at 2022-06-23 16:53:33.806719
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Local variables.
    test_value = _ExtendedEncoder().default(NoDict())
    assert type(test_value) is str
    assert test_value == 'NoDict()'


# Generated at 2022-06-23 16:53:38.542020
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now())
    assert encoder.default(UUID('a1486b69-c03e-4bfb-a1f3-d67c8b36e0e9'))
    assert encoder.default(Decimal(1.1))



# Generated at 2022-06-23 16:53:47.966612
# Unit test for method default of class _ExtendedEncoder

# Generated at 2022-06-23 16:53:58.777246
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from decimal import Decimal
    from uuid import UUID
    @dataclass
    @dataclass_json
    class X:
        v: int
    assert _ExtendedEncoder().default(X(1)) == {'v': 1}
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default(frozenset()) == []
    assert _ExtendedEncoder().default(datetime.now(
        timezone.utc)) == 1562474153.8170912

# Generated at 2022-06-23 16:54:10.837769
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """Test construction of class FieldOverride"""

    def test_exclude(value):
        return value

    def test_letter_case(value):
        return value

    def test_encoder(value):
        return value

    def test_decoder(value):
        return value

    overrides = FieldOverride(test_exclude, test_letter_case, test_encoder,
                              test_decoder)

    assert overrides.exclude is test_exclude
    assert overrides.letter_case is test_letter_case
    assert overrides.encoder is test_encoder
    assert overrides.decoder is test_decoder

    overrides = FieldOverride()

    assert overrides.exclude is None
    assert overrides.letter_case is None
    assert overrides.encoder is None
    assert overrides.decoder

# Generated at 2022-06-23 16:54:19.893395
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": [1, 2]}) == '{"a": [1, 2]}'
    assert _ExtendedEncoder().encode({datetime(2018, 1, 1): [1, 2]}) == '{"2018-01-01T00:00:00+00:00": [1, 2]}'
    assert _ExtendedEncoder().encode({UUID("123e4567-e89b-12d3-a456-426655440000"): [1, 2]}) == '{"123e4567-e89b-12d3-a456-426655440000": [1, 2]}'

# Generated at 2022-06-23 16:54:30.075310
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    n = FieldOverride()
    assert n.exclude is None
    assert n.encoder is None
    assert n.decoder is None
    assert n.letter_case is None

    exclude = lambda x: x is not None
    encoder = lambda x: x + 1
    decoder = lambda x: x - 1
    letter_case = lambda x: x.upper()

    n = FieldOverride(exclude=exclude, letter_case=letter_case,
                      encoder=encoder, decoder=decoder)
    assert n.exclude == exclude
    assert n.letter_case == letter_case
    assert n.encoder == encoder
    assert n.decoder == decoder


# Generated at 2022-06-23 16:54:40.302325
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses_json.tests.base import CustomObj
    from dataclasses import dataclass

    @dataclass
    class B:
        l: list
        d: dict
        s: str
        i: int

    @dataclass
    class A:
        b: B
        datetime: datetime
        uuid: UUID
        enum: Enum
        decimal: Decimal

    obj = A(B([1, 2, 3], {"one": 1, "two": 2}, "s", 2),
            datetime(2017, 9, 18, 15, 10, 20),
            UUID('{12345678-1234-5678-1234-567812345678}'),
            CustomObj.y,
            Decimal('3.5'))

    assert _ExtendedEncoder().default(obj)

# Generated at 2022-06-23 16:54:44.942785
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    data = {"Field1": "Field1_val", "Field2": ["Field2_val"]}
    jsonData = json.dumps(data)
    assert data == json.loads(jsonData, cls=_ExtendedEncoder)



# Generated at 2022-06-23 16:54:55.029770
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Arrange
    encoder = _ExtendedEncoder()
    datetime_original = datetime.now(timezone.utc)
    uuid_original = UUID('123e4567-e89b-12d3-a456-426655440000')
    decimal_original = Decimal('12.34')

# Generated at 2022-06-23 16:55:06.934670
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class TestClass:
        pass

    test_class = TestClass()

    no_args = FieldOverride()
    assert no_args.exclude == FieldOverride.default_exclude
    assert no_args.encoder == FieldOverride.default_encoder
    assert no_args.decoder == FieldOverride.default_decoder
    assert no_args.letter_case == FieldOverride.default_letter_case

    with_args = FieldOverride(exclude=lambda x: x == 1,
                              encoder=lambda x: x,
                              decoder=lambda x: x,
                              letter_case=lambda x: x)