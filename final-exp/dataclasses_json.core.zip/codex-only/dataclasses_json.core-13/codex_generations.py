

# Generated at 2022-06-23 16:45:04.302497
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.fromtimestamp(1, tz=timezone.utc)) == '1.0'



# Generated at 2022-06-23 16:45:15.734555
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'1': 1, '2': 2, '3': 3}) == '{"1": 1, "2": 2, "3": 3}'
    assert _ExtendedEncoder().encode(datetime(2000, 2, 4, 2, 0, 0, tzinfo=timezone.utc)) == "954105600.0"
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal(1)) == '"1"'
   

# Generated at 2022-06-23 16:45:21.855958
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    obj = _ExtendedEncoder().default(
        [{1, 2}, {3, 4}, 4, datetime.now(), datetime.now(timezone.utc), UUID('00000000-0000-0000-0000-000000000000').hex,
         'jjj', datetime.now(), Decimal(10), Decimal('NaN'), Decimal('Infinity'), Decimal('-Infinity')])
    assert obj == [[1, 2], [3, 4], 4, o.timestamp(), o.timestamp(), UUID('00000000-0000-0000-0000-000000000000').hex,
        'jjj', o.timestamp(), Decimal(10), Decimal('NaN'), Decimal('Infinity'), Decimal('-Infinity')]


# Generated at 2022-06-23 16:45:30.078778
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import dataclass, field
    from itertools import chain
    from uuid import uuid4

    @dataclass
    class Embedded:
        embedded_int: int = 0
        embedded_str: str = "embedded_str"
    @dataclass
    class Test:
        date: datetime = datetime(2020, 2, 4, tzinfo=timezone.utc)
        uuid: UUID = uuid4()
        enum: Color = Color.RED
        dec: Decimal = Decimal('1.1')
        embedded: Embedded = None

    e = _ExtendedEncoder()

    for obj in [e.default(obj) for obj in chain(
        [Embedded()],
        fields(Embedded)
    )]:
        assert isinstance(obj, Mapping)

# Generated at 2022-06-23 16:45:41.396503
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default({"a": 1}) == {"a": 1}
    assert encoder.default(datetime(2019, 10, 1, 12, 17, 41, tzinfo=timezone.utc)) == 1569856261.0
    assert encoder.default(UUID("861293c8-c9b9-4aeb-a7d7-cb8f2a16e3a3")) == '861293c8-c9b9-4aeb-a7d7-cb8f2a16e3a3'
    assert encoder.default(Decimal("3.14159")) == '3.14159'
    assert encoder.default

# Generated at 2022-06-23 16:45:49.806799
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    str_b = b'foo'
    str_u = '\u00B5'
    dict_ = {1: 2}
    list_ = [1]
    set_ = {1}
    frozenset_ = frozenset({2})
    datetime_ = datetime.now(tz=timezone.utc)
    uuid_ = UUID('{12345678-1234-5678-1234-567812345678}')
    enum_ = Enum('MyEnum', {})
    enum_._value_ = 1
    decimal_ = Decimal('1.0')
    int_ = 1
    float_ = 1.0
    bool_ = True
    None_ = None

# Generated at 2022-06-23 16:45:58.610883
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert '{"x": 1}' == json.dumps({'x': 1}, cls=_ExtendedEncoder)
    # Test some collections
    t1 = namedtuple('z', ('x', 'y'))(1, 2)
    d1 = {'a': 1, 'b': 2}
    l1 = [1, 2, 3]
    assert self.encoder.encode(t1) == '{"x": 1, "y": 2}'
    assert self.encoder.encode(d1) == '{"a": 1, "b": 2}'
    assert self.encoder.encode(l1) == '[1, 2, 3]'
    # Test datetime

# Generated at 2022-06-23 16:46:10.693874
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """Test that FieldOverride constructor works as expected"""
    with pytest.raises(ValueError, match="""
        Wrong number of keyword arguments
        Required keywords: ['exclude', 'encoder', 'decoder', 'letter_case']
    """):
        FieldOverride(1, 2)
    with pytest.raises(ValueError, match="""
        Wrong number of keyword arguments
        Required keywords: ['exclude', 'encoder', 'decoder', 'letter_case']
    """):
        FieldOverride(1, 2, 3, 4, 5)
    # Catch TypeError for exclude, encoder, decoder and letter_case
    # and ensure that the error message is correct

# Generated at 2022-06-23 16:46:20.172952
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Testing JSONEncoder.default
    encoder = Encoder()
    decoder = Decoder()
    encoder2 = Encoder()
    decoder2 = Decoder()

    letter_case = snake_case  # Used for testing

    # Case 1: default case
    override = FieldOverride()
    assert override.letter_case is None
    assert override.encoder is None
    assert override.decoder is None
    assert override.exclude is None
    assert override.default is None

    # Case 2: letter_case is set
    override = FieldOverride(letter_case=letter_case)
    assert override.letter_case == letter_case
    assert override.encoder is None
    assert override.decoder is None
    assert override.exclude is None
    assert override.default is None

    # Case 3: encoder & decoder are

# Generated at 2022-06-23 16:46:26.926576
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(True)  == True
    assert encoder.default(False) == False
    assert encoder.default(None)  == None
    assert encoder.default(123)   == 123
    assert encoder.default(12.3)  == 12.3
    assert encoder.default("s") == "s"
    assert encoder.default({"a": 1, "b":2}) == {"a": 1, "b":2}
    assert encoder.default((1,2,3)) == [1,2,3]
    assert encoder.default([1,2,3]) == [1,2,3]
    assert encoder.default(set([1,2,3])) == [1,2,3]

# Generated at 2022-06-23 16:46:35.065601
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default(datetime.now(timezone.utc)) == 1563181188
    assert encoder.default(UUID('{12345678-1234-5678-1234-567812345678}')) == \
        '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('2.3')) == '2.3'



# Generated at 2022-06-23 16:46:45.167900
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    dec0 = Decimal('-49.91')
    encoder = _ExtendedEncoder()

# Generated at 2022-06-23 16:46:53.124878
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Valid cases
    with pytest.warns(None) as warns:
        field_override = FieldOverride(exclude = None)
        assert len(warns) == 0

    with pytest.warns(None) as warns:
        field_override = FieldOverride(letter_case = None)
        assert len(warns) == 0

    with pytest.warns(None) as warns:
        field_override = FieldOverride(encoder = None)
        assert len(warns) == 0

    with pytest.warns(None) as warns:
        field_override = FieldOverride(decoder = None)
        assert len(warns) == 0


# Generated at 2022-06-23 16:47:04.076069
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder: _ExtendedEncoder
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(set(['a', 'b', 'c'])) == ['a', 'b', 'c']
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(UUID('1234a678-1234-abcd-efab-cdef12345678')) == '1234a678-1234-abcd-efab-cdef12345678'
    assert encoder.default(datetime(2020, 1, 1, 12, 0, 0, 0, tzinfo=timezone.utc)) == 1577836800.0

# Generated at 2022-06-23 16:47:13.891897
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride()
    assert(not field_override.exclude)
    assert(field_override.encoder is None)
    assert(field_override.letter_case is None)

    field_override = FieldOverride(exclude=lambda x: True)
    assert(field_override.exclude)
    assert(field_override.encoder is None)
    assert(field_override.letter_case is None)

    def to_upper(x: str) -> str:
        return x.upper()
    field_override = FieldOverride(letter_case=to_upper)
    assert(not field_override.exclude)
    assert(field_override.encoder is None)
    assert(field_override.letter_case is to_upper)



# Generated at 2022-06-23 16:47:24.273111
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert isinstance(e.default("string"), str)
    assert isinstance(e.default(dict()), dict)
    assert isinstance(e.default([]), list)
    assert isinstance(e.default(123), int)
    assert isinstance(e.default(1.1), float)
    assert isinstance(e.default(True), bool)
    assert isinstance(e.default(None), type(None))
    tz = timezone.utc
    dt = datetime(2000, 1, 1, tzinfo=tz)
    dt_json = e.default(dt)
    assert isinstance(dt_json, int)
    assert dt_json == 946684800

# Generated at 2022-06-23 16:47:32.397691
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.default({'a': 1}) == {'a': 1}
    assert extended_encoder.default([1, 2, 3]) == [1, 2, 3]
    now = datetime.now(timezone.utc)
    assert extended_encoder.default(now) == now.timestamp()
    assert extended_encoder.default(UUID('d51fdb8c-f5dd-11e9-b5d5-6c40088a38a9')) == 'd51fdb8c-f5dd-11e9-b5d5-6c40088a38a9'
    assert extended_encoder.default(Decimal(1.1)) == '1.1'

# Generated at 2022-06-23 16:47:41.839997
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Empty constructor
    override = FieldOverride()
    assert override.exclude is None
    assert override.encoder is None
    assert override.decoder is None
    assert override.letter_case is None

    # Argument exclude
    exclude_callback = lambda x: False
    override = FieldOverride(exclude=exclude_callback)
    assert override.exclude == exclude_callback
    assert override.encoder is None
    assert override.decoder is None
    assert override.letter_case is None

    # Argument encoder
    encoder_callback = lambda x: x
    override = FieldOverride(encoder=encoder_callback)
    assert override.exclude is None
    assert override.encoder == encoder_callback
    assert override.decoder is None
    assert override.letter_case is None

    # Argument decoder
    decoder

# Generated at 2022-06-23 16:47:53.764208
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert encoder.default({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert encoder.default(Decimal('1.23')) == '1.23'
    assert encoder.default(UUID('7b18c1e0-7d79-4d8b-a042-fa03b2fa8f91')) == '7b18c1e0-7d79-4d8b-a042-fa03b2fa8f91'

# Generated at 2022-06-23 16:48:00.910309
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default([])
    _ExtendedEncoder().default({})
    _ExtendedEncoder().default(datetime.now())
    _ExtendedEncoder().default(UUID(hex='7d5795ac-a06f-4637-aa3d-d04b847bbbd7'))
    _ExtendedEncoder().default(Enum)
    _ExtendedEncoder().default('str')


# Generated at 2022-06-23 16:48:02.796822
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field = FieldOverride(True, upper, '', lambda x: x, None, None)
    assert field.exclude(None) is True



# Generated at 2022-06-23 16:48:15.080496
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    a = [1, 2]
    b = dict(a=1, b=2)
    c = datetime(1, 1, 1, tzinfo=timezone.utc)
    d = UUID("12345678123456781234567812345678")
    e = Decimal("1.234")
    f = [datetime(1, 1, 1, tzinfo=timezone.utc)]
    g = [dict(a=1, b=2)]
    h = [UUID("12345678123456781234567812345678")]
    j = [Decimal("1.234")]
    k = [1, datetime(1, 1, 1, tzinfo=timezone.utc)]
    l = [1, dict(a=1, b=2)]

# Generated at 2022-06-23 16:48:18.909310
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride('test_field', 'default_value')
    assert field_override.name == 'test_field'
    assert field_override.value == 'default_value'


# Generated at 2022-06-23 16:48:28.703572
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_name = 'field_name'
    # Default case
    field_override = FieldOverride(field_name)
    assert field_override.exclude is None
    assert field_override.letter_case is None
    assert field_override.encoder is None
    assert field_override.decoder is None

    # Use a lambda function to test exclude
    field_override = FieldOverride(field_name, exclude=lambda x: False)
    assert not field_override.exclude(0)

    # Use a lambda function to test letter_case
    field_override = FieldOverride(field_name, letter_case=lambda x: x.upper())
    assert field_override.letter_case(field_name) == field_name.upper()

    # Use a lambda function to test encoder
    field_over

# Generated at 2022-06-23 16:48:32.854891
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # 1. Test parameters with valid value
    # 1.1 all parameters are True, then the result should be True
    f1 = FieldOverride(True, True, True, None, None, None)
    assert f1.exclude is True
    assert f1.letter_case is True
    assert f1.encoder is True
    assert f1.decoder is None
    assert f1.mm_field is None
    # 1.2 all parameter are False, then the result should be False
    f2 = FieldOverride(False, False, False, None, None, None)
    assert f2.exclude is False
    assert f2.letter_case is False
    assert f2.encoder is False
    assert f2.decoder is None
    assert f2.mm_field is None

    # 2. Test parameters with invalid value
   

# Generated at 2022-06-23 16:48:42.954415
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(()) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(frozenset()) == []
    assert _ExtendedEncoder().default('string') == 'string'
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(None) == None

# Generated at 2022-06-23 16:48:50.407567
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    # noinspection PyTypeChecker
    encoder.encode([1, 2, 3]) == '[1, 2, 3]'
    # noinspection PyTypeChecker
    encoder.encode({'a': 'b'}) == '{"a": "b"}'
    # noinspection PyTypeChecker
    encoder.encode(datetime.now(timezone.utc)) == '1568787633.063069'
    # noinspection PyTypeChecker
    encoder.encode(UUID('d6116697-32f8-4060-8f23-1f7e6b907854')) == '"d6116697-32f8-4060-8f23-1f7e6b907854"'


# Generated at 2022-06-23 16:48:55.729487
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fldOvr = FieldOverride("foo", lambda x: x)
    assert( fldOvr.action == "foo")
    assert( fldOvr.mode == "copy")
    assert( fldOvr.exclude is None)
    assert( fldOvr.letter_case is None)

# Generated at 2022-06-23 16:49:02.174691
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert encoder.default(datetime(2020, 12, 2, 12, 45, 0, 0, timezone.utc)) == 1606987100.0



# Generated at 2022-06-23 16:49:09.309007
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    class MyEnum(Enum):
        first = 1
        second = 2
    my_json = _ExtendedEncoder().encode({'my_datetime': datetime(2019, 1, 1, 10, 30, tzinfo=timezone.utc),
                                         'my_enum': MyEnum.first})
    assert my_json == '{"my_datetime": 1546300200.0, "my_enum": 1}'



# Generated at 2022-06-23 16:49:15.856143
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2010, 1, 1, tzinfo=timezone.utc)) == '1262322000.0'
    assert _ExtendedEncoder().encode(UUID('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11')) == '"a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11"'
    assert _ExtendedEncoder().encode(Decimal('10.25')) == '"10.25"'



# Generated at 2022-06-23 16:49:20.981077
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1,2,3]) == [1,2,3]
    assert encoder.default(dict(a=1, b=2)) == dict(a=1, b=2)
    assert encoder.default([1.1,2,3]) == [1.1,2,3]
    assert encoder.default(set([1,2,3])) == [1,2,3]

    class MyClass:
        pass

    assert encoder.default(MyClass()) == {}
    


# Generated at 2022-06-23 16:49:24.734504
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime(2017, 11, 21, 1, 34, 56)) == 1511296296.0
    assert encoder.default(datetime(2017, 11, 21, 1, 34, 56, 0, timezone.utc)) == 1511296296.0



# Generated at 2022-06-23 16:49:36.196769
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Given
    encoder = _ExtendedEncoder()
    # When
    result1 = encoder.default(datetime(2020, 1, 1, 12, tzinfo=timezone.utc))
    result2 = encoder.default(set())
    result3 = encoder.default(UUID('{12345678-1234-5678-1234-567812345678}'))
    result4 = encoder.default(Decimal('123.456'))
    # Then
    assert result1 == 1577836800
    assert result2 == []
    assert result3 == '12345678-1234-5678-1234-567812345678'
    assert result4 == '123.456'



# Generated at 2022-06-23 16:49:46.957134
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default([1, 2, [3, 4, 5]]) == [1, 2, [3, 4, 5]]
    assert encoder.default({"a": 1, "b": {"c": 2}}) == {"a": 1, "b": {"c": 2}}
    assert encoder.default(datetime.now(tz=timezone.utc)) == 1579127720.704085
    assert encoder.default(UUID("00000000-0000-0000-0000-000000000000")) == "00000000-0000-0000-0000-000000000000"
    assert encoder.default(cfg.ENUM_MODULE.ABC) == 1

# Generated at 2022-06-23 16:49:59.048808
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert enc.default(MappingProxyType({})) == {}
    assert enc.default(Set()) == []
    assert enc.default(FrozenSet()) == []
    assert enc.default(datetime(2020, 1, 2, 3, 4, 5, tzinfo=timezone(timedelta(hours=9), 'JST'))) == 1577983845
    assert enc.default(UUID('dfe6f35d-a1a6-4fe0-b2cf-4f4e0c3b0c32')) == 'dfe6f35d-a1a6-4fe0c3b0c32-4f4e0c3b0c32'
    assert enc.default(Decimal('1.1')) == '1.1'
   

# Generated at 2022-06-23 16:50:05.574100
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    override = FieldOverride(True, '_test_exclude_', '_test_letter_case_', '_test_encoder_', '_test_decoder_')
    assert override.exclude(1) == True
    assert override.letter_case('test') == '_test_letter_case_'
    assert override.encoder(1) == '_test_encoder_'
    assert override.decoder(1) == '_test_decoder_'

# Generated at 2022-06-23 16:50:12.286355
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    for o in [datetime.now(), UUID('{12345678-1234-5678-1234-567812345678}'),
              Decimal('56.78'), tuple(['a', 'b', 'c']),
              set(['d', 'e', 'f']), {'g':'h', 'i':'j'}, object()]:
        assert _ExtendedEncoder().encode(o) == json.dumps(o)



# Generated at 2022-06-23 16:50:22.922788
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from collections import namedtuple
    from decimal import Decimal
    from enum import Enum
    from uuid import UUID

    class TestJsonEnum(Enum):
        JSON = 'json'

    TestJsonType = namedtuple('TestJsonType', ['a', 'b', 'c'])

    json_obj = [
        TestJsonType(a=1, b='foo', c='bar'),
        dict(k1=1, k2=2)
    ]
    json_obj.append(UUID('3fa85f64-5717-4562-b3fc-2c963f66afa6'))
    json_obj.append(TestJsonEnum.JSON)
    json_obj.append(Decimal('100.1'))


# Generated at 2022-06-23 16:50:33.467690
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(['as', 1,2]) == ['as', 1,2]
    assert encoder.default(('as', 1,2)) == ['as', 1,2]
    assert encoder.default({'as': 1,2: 's'}) == {'as': 1,2: 's'}
    assert encoder.default('s') == 's'
    assert encoder.default(1) == 1
    assert encoder.default(1.2) == 1.2
    assert encoder.default(None) == None
    assert encoder.default([datetime.now()]) == [datetime.now().timestamp()]
    assert encoder.default({datetime.now()}) == {datetime.now().timestamp()}
    assert encoder.default

# Generated at 2022-06-23 16:50:45.643191
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default({1: 2}) == {1: 2}
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default("test") == "test"
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.1) == 1.1
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()

# Generated at 2022-06-23 16:50:48.247754
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) != None



# Generated at 2022-06-23 16:50:57.503953
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default('abc') == 'abc'
    assert encoder.default(1) == 1
    assert encoder.default(True) is True
    assert encoder.default(None) is None
    assert encoder.default([1, 'a', True]) == [1, 'a', True]
    assert encoder.default({'a': 1, 'b': 'c'}) == {'a': 1, 'b': 'c'}
    assert encoder.default(datetime.fromtimestamp(100, tz=timezone.utc)) == 100

# Generated at 2022-06-23 16:51:02.325676
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_encoder = _ExtendedEncoder()
    with open("test_files/test_json_encoder.json", 'r') as f:
        data = json.load(f)
    for k, v in data.items():
        assert json_encoder.default({k: v}) == {k: v}


# Generated at 2022-06-23 16:51:07.614479
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(
        exclude=None, encoder=None, decoder=None, mm_field=None,
        letter_case=None
    ) is not None


# Generated at 2022-06-23 16:51:18.245694
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    for i in range(0, 3):
        if i == 0:
            default = None
            expected = {"exclude": None, "letter_case": None,
                        "encoder": None, "decoder": None}
            field_override = FieldOverride(default)
            if field_override.__dict__ != expected:
                print(f"FAILED: FieldOverride constructor with "
                      f"default={default}")
            else:
                print(f"SUCCEED: FieldOverride constructor with "
                      f"default={default}")
        elif i == 1:
            exclude = lambda x: x == "None"
            letter_case = lambda x: x.lower()
            encoder = lambda x: x + 2
            decoder = lambda x: x - 2

# Generated at 2022-06-23 16:51:29.251639
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder.default(None, [1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder.default(None, {"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert _ExtendedEncoder.default(None, datetime.now(timezone.utc)) == \
           datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder.default(None,
                                    UUID('343bd062-3d1a-4a7a-a75e-601c0b320ecc')) == \
           '343bd062-3d1a-4a7a-a75e-601c0b320ecc'

# Generated at 2022-06-23 16:51:33.938166
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    class Dummy:
        def __init__(self, value: Any = MISSING):
            self.value = value

        def __repr__(self):
            return f'Dummy({self.value!r})'

    encoder = _ExtendedEncoder()
    assert encoder.default(Dummy(True)) == True
    assert encoder.default(Dummy(False)) == False
    assert encoder.default(Dummy('string')) == 'string'
    assert encoder.default(Dummy(42)) == 42
    assert encoder.default(Dummy(3.5)) == 3.5
    assert encoder.default(Dummy(3.4 + 0j)) == complex(3.4)

# Generated at 2022-06-23 16:51:44.189329
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    assert e.default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert e.default([1, 2, 3]) == [1, 2, 3]
    assert e.default(datetime.now(timezone.utc)) == int(datetime.now(timezone.utc).timestamp())
    assert e.default(UUID('2f3a189f-a6c3-4b81-8cfe-dd9267429e06')) == "2f3a189f-a6c3-4b81-8cfe-dd9267429e06"
    assert e.default(Decimal('1.2')) == '1.2'
    assert e.default(Decimal('NaN')) == 'NaN'

# Generated at 2022-06-23 16:51:52.499606
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.min) == 62135596800.0
    assert encoder.default(UUID('28bc9c8a-7aac-44e2-9543-540defc16a32')) == '28bc9c8a-7aac-44e2-9543-540defc16a32'
    assert encoder.default(Decimal('NaN')) == 'NaN'
    assert encoder.default(Decimal('Infinity')) == 'Infinity'
    assert encoder.default(Decimal('-Infinity')) == '-Infinity'



# Generated at 2022-06-23 16:51:54.043866
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    s = json.dumps(datetime.now(), cls=_ExtendedEncoder)
    assert isinstance(s, str)
    assert s != ""

global_decoder_objs: Collection[Any] = set()


# This class is used to handle recursive data structures

# Generated at 2022-06-23 16:51:59.357713
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test call
    assert FieldOverride() == FieldOverride()
    # Test letter_case
    assert FieldOverride(letter_case=lambda i: i) == FieldOverride(
        letter_case=lambda i: i)
    assert FieldOverride(letter_case=lambda o: o) != FieldOverride(
        letter_case=lambda i: i)
    # Test encoder
    assert FieldOverride(encoder=lambda i: i) == FieldOverride(
        encoder=lambda i: i)
    assert FieldOverride(encoder=lambda o: o) != FieldOverride(
        encoder=lambda i: i)
    # Test decoder
    assert FieldOverride(decoder=lambda i: i) == FieldOverride(
        decoder=lambda i: i)

# Generated at 2022-06-23 16:52:08.665822
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    # Check that the encoder can serialize datetime.datetime
    assert encoder.encode(datetime.now(timezone.utc)) != None
    # Check that the encoder can serialize UUID
    assert encoder.encode(UUID('123e4567-e89b-12d3-a456-426655440000')) != None
    # Check that the encoder can serialize Decimal
    assert encoder.encode(Decimal('3.1415')) != None
    # Check that the encoder can serialize Enum
    assert encoder.encode(cfg.LetterCase.PASCAL) != None

_ExtendedDecoder = json.JSONDecoder


# Generated at 2022-06-23 16:52:12.256911
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    result = FieldOverride(encoder="", exclude="", letter_case="")
    expected = FieldOverride(encoder="", exclude="", letter_case="")
    assert result == expected

# Generated at 2022-06-23 16:52:18.909628
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses_json.utils import is_collection, _isinstance_safe
    from collections import OrderedDict
    result = _ExtendedEncoder().default([1, 2])
    assert result == [1, 2]
    result = _ExtendedEncoder().default((1, 2))
    assert result == [1, 2]
    result = _ExtendedEncoder().default({1, 2})
    assert result == [1, 2]
    result = _ExtendedEncoder().default({1: 2, 3: 4})
    assert result == {1: 2, 3: 4}
    result = _ExtendedEncoder().default(OrderedDict(((1, 2), (3, 4))))
    assert result == {1: 2, 3: 4}
    # if a dict is in a dict, the dict will be converted to a

# Generated at 2022-06-23 16:52:30.889118
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class User(Dataclass):
        name: str

    field_override = FieldOverride(exclude=lambda x: x is None,
                                   letter_case=lambda x: x.lower(),
                                   encoder=lambda x: x.upper(),
                                   decoder=lambda x: "default")

    assert field_override.exclude == (lambda x: x is None)
    assert field_override.letter_case == (lambda x: x.lower())
    assert field_override.encoder == (lambda x: x.upper())
    assert field_override.decoder == (lambda x: "default")
    assert str(field_override) == "FieldOverride(exclude=<lambda>, letter_case=<lambda>, encoder=<lambda>, decoder=<lambda>)"



# Generated at 2022-06-23 16:52:36.894526
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    result1 = _ExtendedEncoder(indent=4).default(datetime.now(timezone.utc))
    result2 = _ExtendedEncoder(indent=4).default(UUID('{12345678-1234-5678-1234-567812345678}'))
    result3 = _ExtendedEncoder(indent=4).default(Decimal('1.234'))


# Generated at 2022-06-23 16:52:49.569173
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encode_function = lambda x: x
    decode_function = lambda x: x
    exclude_function = lambda x: True
    letter_case_function = lambda x: x
    # Test encode function
    override = FieldOverride(encode_function)
    assert override.encoder == encode_function
    # Test decode function
    override = FieldOverride(decode_function=decode_function)
    assert override.decoder == decode_function
    # Test exclude function
    override = FieldOverride(exclude_function=exclude_function)
    assert override.exclude == exclude_function
    # Test letter case function
    override = FieldOverride(letter_case_function=letter_case_function)
    assert override.letter_case == letter_case_function


# Unit tests for function for overriding field names for encoding

# Generated at 2022-06-23 16:53:01.653401
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test the constructor of class FieldOverride
    print('Test constructor of class FieldOverride')
    # 1. Test default values of the constructor
    #   1.1 test default value of exclude
    fo = FieldOverride()
    assert fo.exclude is None
    #   1.2 test default value of letter_case
    assert fo.letter_case is None
    #   1.3 test default value of encoder
    assert fo.encoder is None
    #   1.4 test default value of decoder
    assert fo.decoder is None
    #   1.5 test default value of mm_field
    assert fo.mm_field is None
    # 2. Test non-default values of the constructor

# Generated at 2022-06-23 16:53:03.885907
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    try:
        # Constructor without any attributes
        FieldOverride()
    except TypeError:
        return True
    return False


# Generated at 2022-06-23 16:53:15.111861
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test all fields
    x = FieldOverride("abc", True, "lower", lambda x: 1, lambda x: 2)
    assert x.letter_case("Abc") == "abc"
    assert x.exclude("a") is True
    assert x.encoder("a") == 1
    assert x.decoder("a") == 2

    # test all None for fields
    x = FieldOverride(None, None, None, None, None)
    assert x.letter_case("Abc") == "Abc"
    assert x.exclude("a") is False
    assert x.encoder("a") == "a"
    assert x.decoder("a") == "a"

    # test one field
    x = FieldOverride(exclude=lambda x: True)

# Generated at 2022-06-23 16:53:17.669585
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': datetime.now()})


# Generated at 2022-06-23 16:53:22.641465
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    constructor = FieldOverride(exclude=lambda x: True,
                                letter_case=lambda x: x.upper(),
                                encoder=lambda x: str(x),
                                decoder=lambda x: int(x))
    assert constructor.exclude(False)
    assert constructor.letter_case("ABC") == "ABC"
    assert constructor.encoder(True) == "True"
    assert constructor.decoder("10") == 10



# Generated at 2022-06-23 16:53:31.079388
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(3) == 3
    assert _ExtendedEncoder().default(3.2) == 3.2
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default('a') == 'a'
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default((1, 2)) == [1, 2]
    assert _ExtendedEncoder().default(set((3, 4))) == [3, 4]
    assert _ExtendedEncoder().default({1: 2}) == {1: 2}

# Generated at 2022-06-23 16:53:41.342500
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    E = _ExtendedEncoder()
    assert E.default('string') == 'string'
    assert E.default(1) == 1
    assert E.default(1.2) == 1.2
    assert E.default(1 == 1) == True
    assert E.default(False) == False
    assert E.default(None) == None
    assert E.default([1, 2]) == [1, 2]
    assert E.default(['a', 'b']) == ['a', 'b']
    assert E.default([]) == []
    assert E.default(range(3)) == [0, 1, 2]
    assert E.default(tuple(range(3))) == [0, 1, 2]
    assert E.default({}) == {}

# Generated at 2022-06-23 16:53:48.864131
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    letter_case = 'letter_case'
    exclude = 'exclude'
    encoder = 'encoder'
    decoder = 'decoder'
    field_name = 'field_name'
    fo = FieldOverride(letter_case, exclude, encoder, decoder)
    assert fo.letter_case == letter_case
    assert fo.exclude == exclude
    assert fo.encoder == encoder
    assert fo.decoder == decoder
    assert not fo.mm_field
    fo = FieldOverride(letter_case, exclude, encoder, decoder, True)
    assert fo.mm_field
    fo = FieldOverride(letter_case, exclude, encoder, decoder)
    assert not fo.mm_field


# Generated at 2022-06-23 16:53:59.500169
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(frozenset()) == []
    assert _ExtendedEncoder().default(deque()) == []
    assert _ExtendedEncoder().default(defaultdict()) == {}
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, 1, 0, tzinfo=timezone.utc)) == 3600
    assert _ExtendedEncoder().default(Enum("MyEnum", "A B")) == "A"
    assert _ExtendedEncoder().default(Enum("MyEnum", (("A", 1), ("B", 2)))) == 1

# Generated at 2022-06-23 16:54:04.906108
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    res = encoder.default([1,2,3])
    assert res == [1,2,3]
    res = encoder.default({1:2,3:4})
    assert res == {1:2,3:4}


# Generated at 2022-06-23 16:54:06.714980
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(exclude=lambda x: x is None,
                         letter_case=lambda x: x.upper(),
                         encoder=lambda x: x.upper(),
                         decoder=lambda x: x.upper())



# Generated at 2022-06-23 16:54:12.313978
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride() == FieldOverride(exclude=None, letter_case=None, encoder=None, decoder=None, mm_field=None)
    assert FieldOverride(exclude=lambda x: x > 2, letter_case=str.upper) == \
        FieldOverride({
            'exclude': lambda x: x > 2,
            'letter_case': str.upper
        })

# Generated at 2022-06-23 16:54:18.980111
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_name = 'field_name'
    exclude = None
    letter_case = None
    encoder = None
    decoder = None
    t = FieldOverride(exclude, letter_case, encoder, decoder)
    assert (t.field_name == field_name)
    assert (t.exclude == exclude)
    assert (t.letter_case == letter_case)
    assert (t.encoder == encoder)
    assert (t.decoder == decoder)

# Generated at 2022-06-23 16:54:29.603910
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime(2000, 1, 1)) == 946656000.0
    assert encoder.default(UUID('12345678-1234-5678-1234-567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('1.2')) == '1.2'
    assert encoder.default(Enum('Enum', ('Foo', 'Bar'))(0)) == 0
    assert encoder.default(Enum('Enum', ('Foo', 'Bar'))(1)) == 1


# noinspection PyUnusedLocal,PyProtectedMember,PyUnresolvedReferences

# Generated at 2022-06-23 16:54:36.685887
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.encode(None) == 'null'
    assert encoder.encode({'key': 'value'}) == '{"key": "value"}'
    assert encoder.encode(["val1", "val2"]) == '["val1", "val2"]'
    assert encoder.encode(True) == 'true'
    assert encoder.encode(1) == '1'
    assert encoder.encode(1.1) == '1.1'
    assert encoder.encode({1: "value"}) == '{"1": "value"}'

# Generated at 2022-06-23 16:54:44.438365
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride()

# Generated at 2022-06-23 16:54:54.723877
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default('str') == 'str'
    assert _ExtendedEncoder().default(42) == 42
    assert _ExtendedEncoder().default(42.2) == 42.2
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(['a', 1]) == ['a', 1]
    assert _ExtendedEncoder().default({'a': 1}) == {'a': 1}
    assert _ExtendedEncoder().default(set('abc')) == ['a', 'b', 'c']
    assert _ExtendedEncoder().default({1, 2, 3}) == [1, 2, 3]
    assert _ExtendedEncoder

# Generated at 2022-06-23 16:55:02.609020
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    letter_case = lambda x: x
    encoder = lambda x: x
    decoder = lambda x: x
    exclude = lambda x: x
    field_override = FieldOverride(
        letter_case, encoder, decoder, exclude)
    assert field_override.letter_case is letter_case
    assert field_override.encoder is encoder
    assert field_override.decoder is decoder
    assert field_override.exclude is exclude