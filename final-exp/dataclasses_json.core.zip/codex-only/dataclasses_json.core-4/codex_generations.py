

# Generated at 2022-06-23 16:45:04.522515
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ext = _ExtendedEncoder()
    assert ext.default(1) == 1
    assert ext.default(True) == True
    assert ext.default([1, 2]) == [1, 2]
    assert ext.default({'a': 1}) == {'a': 1}

_extended_encoder = _ExtendedEncoder()



# Generated at 2022-06-23 16:45:07.692434
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default(["asd", 1, 2, 3])



# Generated at 2022-06-23 16:45:16.928038
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default(range(4)) == [0, 1, 2, 3]
    assert encoder.default(1) == 1
    assert encoder.default('hello') == 'hello'
    assert encoder.default(float(1.1)) == 1.1
    assert encoder.default(True) is True
    assert encoder.default(None) is None
    assert enc

# Generated at 2022-06-23 16:45:26.832822
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import date


# Generated at 2022-06-23 16:45:38.645039
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.loads(_ExtendedEncoder(skipkeys=False).encode([1, 2, 3])) == [1, 2, 3]
    assert json.loads(_ExtendedEncoder(skipkeys=False).encode(dict())) == {}
    assert json.loads(_ExtendedEncoder(skipkeys=False).encode([1, '2', [3, 4], {'5': 6}])) == [1, '2', [3, 4], {'5': 6}]
    assert json.loads(_ExtendedEncoder(skipkeys=False).encode(Decimal('1.2'))) == '1.2'
    assert json.loads(_ExtendedEncoder(skipkeys=False).encode(datetime(2017, 5, 19, 20, 50, 5, tzinfo=timezone.utc))) == 1495229

# Generated at 2022-06-23 16:45:47.908814
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = ['a', 'b']
    assert _ExtendedEncoder().default(o) == ['a', 'b']

    o = {'a': 'b'}
    assert _ExtendedEncoder().default(o) == {'a': 'b'}

    o = datetime(2020, 1, 1, 12, 0, 0, tzinfo=timezone.utc).timestamp()
    assert _ExtendedEncoder().default(o) == o

    o = Decimal(1) / Decimal(3)
    assert _ExtendedEncoder().default(o) == str(o)

    o = ('a', 'b')
    assert _ExtendedEncoder().default(o) == ['a', 'b']



# Generated at 2022-06-23 16:45:57.202641
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    value = 1
    exclude = lambda x: x == value
    letter_case = lambda x: x.upper()

    fo = FieldOverride()
    assert fo.exclude is None
    assert fo.letter_case is None
    assert fo.encoder is None
    assert fo.decoder is None
    assert fo.mm_field is None

    fo = FieldOverride(exclude, letter_case)
    assert fo.exclude is exclude
    assert fo.letter_case is letter_case
    assert fo.encoder is None
    assert fo.decoder is None
    assert fo.mm_field is None

    fo = FieldOverride(exclude)
    assert fo.exclude is exclude
    assert fo.letter_case is None
    assert fo.encoder is None
    assert fo.decoder is None
    assert fo.mm_field

# Generated at 2022-06-23 16:46:08.906748
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert enc.default(1) == 1
    assert enc.default(1.2) == 1.2
    assert enc.default(True) == True
    assert enc.default("a") == "a"
    assert enc.default(None) == None
    assert enc.default(1+2j) == {"__complex__": True, "real": 1, "imag": 2}
    assert enc.default(frozenset({1, 2, 3})) == [1, 2, 3]
    assert enc.default(set({1, 2, 3})) == [1, 2, 3]
    assert enc.default(datetime.fromtimestamp(0)) == 0
    assert enc.default(datetime.fromtimestamp(0, tz=timezone.utc)) == 0

# Generated at 2022-06-23 16:46:19.102909
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    decoder = lambda obj: obj
    f = FieldOverride(decoder=decoder, exclude=lambda x: x == 2)
    assert f == (decoder, None, None, False, lambda x: x == 2)
    f1 = FieldOverride(decoder=decoder, exclude=lambda x: x == 2,
                       letter_case=lambda x: x.upper())
    assert f1 == (decoder, lambda x: x.upper(), None, False, lambda x: x == 2)
    f2 = FieldOverride(decoder=decoder, exclude=lambda x: x == 2,
                       letter_case=lambda x: x.upper(),
                       mm_field='int')
    assert f2 == (decoder, lambda x: x.upper(), 'int', False, lambda x: x == 2)

    # test encode with override

# Generated at 2022-06-23 16:46:28.531173
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # TODO: Move to unit tests module
    foo_baz = FieldOverride()
    assert foo_baz.exclude is None
    assert foo_baz.letter_case is None
    assert foo_baz.encoder is None

    foo_bar = FieldOverride(exclude=None, letter_case=lambda x: x.upper(),
                            encoder=lambda x: x + x)
    assert foo_bar.exclude is None
    assert foo_bar.letter_case(x='x') == 'X'
    assert foo_bar.encoder(x='foo') == 'foofoo'

    # If a value is missing, the default value is assigned to the attribute
    # TODO: Add a test where the value is missing.

# Generated at 2022-06-23 16:46:30.488554
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.fromtimestamp(1, timezone.utc)) == 1.0



# Generated at 2022-06-23 16:46:41.118919
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({"a": 1}) == {"a": 1}
    assert _ExtendedEncoder().default(
        datetime(year=2019, month=12, day=27, hour=23, second=41)) == 1577508801.0
    assert _ExtendedEncoder().default(UUID('4d3bd0f4-e82f-4a1d-9f6c-f7d8c55d6e98')
                                     ) == '4d3bd0f4-e82f-4a1d-9f6c-f7d8c55d6e98'

# Generated at 2022-06-23 16:46:42.177027
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder()



# Generated at 2022-06-23 16:46:50.331820
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = frozenset([1])
    e = _ExtendedEncoder()
    assert e.default(o) == [1]
    assert e.default({'a': 1}) == {'a': 1}
    assert e.default(UUID('3e8e7d6a-8460-4c4d-99e0-a4f626a4c4e4')) == \
        '3e8e7d6a-8460-4c4d-99e0-a4f626a4c4e4'
    assert e.default(datetime(2020, 2, 22, 2, 22, 2)) == 1582345722.0
    assert e.default(Decimal('0.1')) == '0.1'



# Generated at 2022-06-23 16:46:54.939712
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride() == FieldOverride()


# Unit tests for dataclass_asdict
# This will only work if you have pytest installed for your version of Python.
# TODO add pytest option to run these when the user does '--with-doctest'.
# The test case should be added after each defintion.

# Generated at 2022-06-23 16:46:58.392380
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    obj = object()
    assert _ExtendedEncoder().default(obj) == obj
    assert _ExtendedEncoder().default(object()) != obj


# Generated at 2022-06-23 16:47:07.203719
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

    assert encoder.default(None) is None

    assert encoder.default('') == ''
    assert encoder.default("test") == "test"

    assert encoder.default(0) == 0
    assert encoder.default(1) == 1

    assert encoder.default(True)
    assert not encoder.default(False)

    assert encoder.default(0.0) == 0.0
    assert encoder.default(1.0) == 1.0

    assert encoder.default(datetime.now(tz=timezone.utc))

    assert encoder.default(UUID('{12345678-1234-5678-1234-567812345678}'))

    assert encoder.default(Decimal('0.003141'))


# Generated at 2022-06-23 16:47:16.178501
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default("abc") == 'abc'
    assert encoder.default(datetime.now()) > 0.0
    assert encoder.default(UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")) == "6ba7b810-9dad-11d1-80b4-00c04fd430c8"
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default(cfg.NaN(1)) == 1
    assert encoder.default(cfg.NaN("a")) == "a"

# Generated at 2022-06-23 16:47:24.005657
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode('hello world') == '"hello world"'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'



# Generated at 2022-06-23 16:47:32.112277
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    current_time = datetime.now(timezone.utc)

# Generated at 2022-06-23 16:47:41.655062
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import datetime
    from decimal import Decimal
    from uuid import UUID
    from enum import Enum

    class TestEnum(Enum):
        ONE = 1

    JSONEncoder = json.JSONEncoder

    text = '{"a": 123, "b": { "b1": "b1", "b2": [1, 2, 3] }, "c": [{"c1": "c1", "c2": "c2"}, {"c3": "c3", "c4": "c4"}], "d": {"d1": "d1", "d2": "d2"}, "e": ["e1", "e2", "e3"], "f": ["f1", "f2", "f3"], "g": "¡Hola, mundo!"}'

# Generated at 2022-06-23 16:47:51.324059
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert [1,2,3] == json.loads(json.dumps([1,2,3], cls=_ExtendedEncoder))
    assert {1:2,3:4} == json.loads(json.dumps({1:2, 3:4}, cls=_ExtendedEncoder))
    assert "2019-07-24T16:27:09.507566" == json.loads(json.dumps(datetime.now(), cls=_ExtendedEncoder))
    assert 1 == json.loads(json.dumps(1, cls=_ExtendedEncoder))



# Generated at 2022-06-23 16:47:59.102523
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now())
    assert _ExtendedEncoder().default(UUID('f47ac10b-58cc-4372-a567-0e02b2c3d479'))
    assert _ExtendedEncoder().default(Decimal('3.141592'))
    assert _ExtendedEncoder().default(AnyEnum(42))
    assert _ExtendedEncoder().default(AnyEnum(None))



# Generated at 2022-06-23 16:48:09.042218
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder.default(None, '1') == '1'
    assert _ExtendedEncoder.default(None, 1) == 1
    assert _ExtendedEncoder.default(None, [1]) == [1]
    assert _ExtendedEncoder.default(None, "abc") == "abc"
    assert _ExtendedEncoder.default(None, {}) == {}
    assert _ExtendedEncoder.default(None, [1, 'a', {}]) == [1, 'a', {}]
    assert _ExtendedEncoder.default(None, (_ for _ in range(2))) == [0, 1]
    assert _ExtendedEncoder.default(None, (1, 2, 3)) == [1, 2, 3]

# Generated at 2022-06-23 16:48:13.887493
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    test_field_override = FieldOverride('decoder', 'encoder', '', '')
    assert all([test_field_override.decoder == 'decoder',
                test_field_override.encoder == 'encoder',
                test_field_override.exclude == '',
                test_field_override.letter_case == ''])


# Generated at 2022-06-23 16:48:23.175808
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(dict(a=1, b=2)) == dict(a=1, b=2)
    assert encoder.default(list(range(5))) == list(range(5))
    assert encoder.default(datetime.now(timezone.utc)) == \
        datetime.now(timezone.utc).timestamp()
    assert encoder.default(cfgy.UUID()) == str(cfgy.UUID())
    assert encoder.default(cfgy.Enum()) == cfgy.Enum().value
    assert encoder.default(Decimal('1.05')) == '1.05'



# Generated at 2022-06-23 16:48:32.609287
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2]) in ('[1, 2]', '[2, 1]')
    assert _ExtendedEncoder().encode(dict(a=2, b=3)) in ('{"a": 2, "b": 3}', '{"b": 3, "a": 2}')
    assert _ExtendedEncoder().encode(UUID(int=11223344)) == '"00000000-0000-0000-0000-7b9a4b4c4d4c"'
    assert _ExtendedEncoder().encode(Enum('test', {'a': 1, 'b': 2})('a')) == '1'
    assert _ExtendedEncoder().encode(Decimal(3.14)) == '"3.14"'



# Generated at 2022-06-23 16:48:37.782894
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(decoder=lambda x: x + 1, encoder=lambda x: x - 1)
    assert fo.decoder(1) == 2
    assert fo.encoder(2) == 1


# Unit tests for function _preprocess_override

# Generated at 2022-06-23 16:48:40.285562
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(None, from_json=None, to_json=None, exclude=None,
                         letter_case=None) is not None



# Generated at 2022-06-23 16:48:48.420179
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    def predicate(value):
        return True

    def encoder(value):
        return value

    def decoder(value):
        return value

    def letter_case(value):
        return value

    assert FieldOverride(True, encoder, decoder, letter_case)(1) == 1
    assert FieldOverride(True, encoder, decoder, letter_case)(1) == 1

    override = FieldOverride(True, encoder, decoder, letter_case)
    assert override.exclude(1)
    assert override.encoder(1) == 1
    assert override.decoder(1) == 1
    assert override.letter_case(1) == 1

if __name__ == "__main__":
    test_FieldOverride()

# Generated at 2022-06-23 16:49:00.467312
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    @dataclass(init=False)
    class F:
        n: int = field(metadata={'dataclasses_json': {'exclude_if': None}})
        n1: int = field(metadata={'dataclasses_json': {'exclude_if': None,
                                                       'letter_case': None}})
        n2: int = field(metadata={'dataclasses_json': {'exclude_if': None,
                                                       'letter_case': str}})

    # only provide exclude_if
    t = FieldOverride(lambda x: False)
    assert t.exclude_if is not None
    # provide everything
    t = FieldOverride(lambda x: False, str, lambda x: x)
    assert t.exclude_if is not None
    assert t.letter_case is not None

# Generated at 2022-06-23 16:49:05.774834
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(letter_case=str.lower, exclude=None, encoder=None,
                      decoder=None)
    assert f.letter_case == str.lower
    assert f.exclude == None
    assert f.encoder == None
    assert f.decoder == None



# Generated at 2022-06-23 16:49:08.138903
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(exclude=None, encoder=None, decoder=None,
                         letter_case=None)



# Generated at 2022-06-23 16:49:12.582550
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import dataclass

    @dataclass(frozen=True)
    class DataWithDefault:
        x: int

    @dataclass(frozen=True)
    class DataWithJSONEncoder:
        x: int

        def default(self) -> int:
            return 3

    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3], 'List is unchanged'
    assert _ExtendedEncoder().default((1, 2, 3)) == [1, 2, 3], 'Tuple is unchanged'
    assert _ExtendedEncoder().default({1: 2, 3: 4, 5: 6}) == {1: 2, 3: 4, 5: 6}, 'Dict is unchanged'

# Generated at 2022-06-23 16:49:19.460288
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    result = encoder.default('a')
    assert result=='a'

_pop_keys = ('object_hook', 'object_pairs_hook', 'parse_float', 'parse_int', 'parse_constant',
             'strict', 'cls', 'indent', 'separators', 'skipkeys', 'allow_nan')



# Generated at 2022-06-23 16:49:25.395840
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = _ExtendedEncoder().default(1.1)
    assert o == 1.1
    o = _ExtendedEncoder().default(set())
    assert o == []
    o = _ExtendedEncoder().default(frozenset())
    assert o == []
    o = _ExtendedEncoder().default(datetime(1970, 1, 1))
    assert o == 0.0
    o = _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc))
    assert o == 0.0



# Generated at 2022-06-23 16:49:37.280721
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(set()) == list(set())
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default(tuple()) == list(tuple())
    assert _ExtendedEncoder().default((1,)) == [1]
    assert _ExtendedEncoder().default([1]) == [1]
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == json.loads(json.dumps(datetime.now(timezone.utc)))

# Generated at 2022-06-23 16:49:47.568484
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

    d = {'byte': b'123', 'datetime': datetime(1970, 1, 1, 0, 0, 0, 0, timezone.utc),
         'int': 1, 'float': 1.0, 'str': '1', 'bool': True, 'none': None}

    assert encoder.default(d) == d
    assert encoder.default(UUID(int=1)) == '00000000-0000-0000-0000-000000000001'
    assert encoder.default(set(d)) == ['bool', 'byte', 'datetime', 'float', 'int', 'none', 'str']
    assert encoder.default(frozenset(d)) == ['bool', 'byte', 'datetime', 'float', 'int', 'none', 'str']
    assert encoder.default

# Generated at 2022-06-23 16:49:56.407742
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    conf = FieldOverride(letter_case=lambda x: x.upper(), exclude=lambda x: x > 2, encoder=lambda x: x+1, decoder=lambda x: x-1)

# Generated at 2022-06-23 16:50:06.171034
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # pylint: disable=W0123
    assert json.dumps(bytearray(b'foobar'), cls=_ExtendedEncoder) == "\"foobar\""  # noqa
    assert json.dumps(bytearray([97]), cls=_ExtendedEncoder) == "\"a\""  # noqa
    assert json.dumps(bytearray([33]), cls=_ExtendedEncoder) == "\"!\""  # noqa
    assert json.dumps(DataclassWithDefaultFactory(), cls=_ExtendedEncoder) == '{"default_value": "42"}'  # noqa


# Generated at 2022-06-23 16:50:12.378078
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # tests
    test_case = [
        # test fields
        "exclude", "encoder", "decoder", "letter_case", "mm_field"
    ]

    # expected results
    exp = FieldOverride(exclude = None, encoder=None, decoder=None,
    letter_case=None, mm_field=None)

    # assert
    assert FieldOverride() == exp



# Generated at 2022-06-23 16:50:15.105668
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = datetime(2020, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    assert _ExtendedEncoder().default(o) == 1577836800.0



# Generated at 2022-06-23 16:50:16.084668
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # pylint: disable=unused-variable
    _ExtendedEncoder()



# Generated at 2022-06-23 16:50:21.161542
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    foo = FieldOverride()
    print(foo)
    foo = FieldOverride("exclude")
    print(foo)
    foo = FieldOverride("letter_case")
    print(foo)
    foo = FieldOverride("exclude", "letter_case")
    print(foo)

# Generated at 2022-06-23 16:50:23.292729
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder()

_extended_encoder = _ExtendedEncoder()



# Generated at 2022-06-23 16:50:24.632394
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(TypeError):
        FieldOverride()

# Generated at 2022-06-23 16:50:28.138186
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(0.2) == 0.2
    assert _ExtendedEncoder().default('string') == 'string'



# Generated at 2022-06-23 16:50:34.031385
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder(indent=4,
                                        separators=(',', ': '),
                                        sort_keys=True)
    base_json = extended_encoder.encode({'a': 1, 'b': 2})
    assert base_json == '{"a": 1, "b": 2}'



# Generated at 2022-06-23 16:50:45.916244
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(list()) == []
    assert encoder.default(tuple()) == []
    assert encoder.default(set()) == []
    assert encoder.default(dict()) == {}
    assert encoder.default(list(range(4))) == list(range(4))
    assert encoder.default(tuple(range(4))) == list(range(4))
    assert encoder.default({2: 6, 3: 9}) == {2: 6, 3: 9}
    now = datetime.now()
    assert encoder.default(now) == now.timestamp()

# Generated at 2022-06-23 16:50:56.440172
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    xe = _ExtendedEncoder
    assert xe.default(xe, []) == []
    assert xe.default(xe, {}) == {}
    assert xe.default(xe, datetime.now(tz=timezone.utc)) == datetime.now(tz=timezone.utc).timestamp()
    assert xe.default(xe, UUID('55665566-6655-5566-6655-556655665566')) == '55665566-6655-5566-6655-556655665566'
    assert xe.default(xe, Decimal(0.1)) == '0.1'
    assert xe.default(xe, Decimal('0.1')) == '0.1'
    assert xe.default(xe, Decimal('NaN'))

# Generated at 2022-06-23 16:51:04.640015
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder()
    assert json.JSONEncoder.default(result, datetime(2016, 1, 1)) == 1451606400
    assert json.JSONEncoder.default(result, UUID("06655ee9-ea5d-486d-a32f-cb2c1b00eba5")) == \
        "06655ee9-ea5d-486d-a32f-cb2c1b00eba5"
    assert json.JSONEncoder.default(result, Enum) == Enum
    assert json.JSONEncoder.default(result, Decimal("1.1")) == "1.1"


# Generated at 2022-06-23 16:51:14.715334
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == json.dumps({})
    assert _ExtendedEncoder().encode([1,2]) == json.dumps([1,2])
    assert _ExtendedEncoder().encode({"a":1}) == json.dumps({"a":1})
    now = datetime.now(timezone.utc)
    assert _ExtendedEncoder().encode(now) == json.dumps(now.timestamp())
    assert _ExtendedEncoder().encode(Enum) == json.dumps(Enum.value)
    assert _ExtendedEncoder().encode(Decimal(1)) == json.dumps(str(Decimal(1)))



# Generated at 2022-06-23 16:51:26.795338
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert json.loads(json.dumps(datetime.now(), cls=_ExtendedEncoder)) >= 0
    assert json.loads(json.dumps(datetime.now(timezone.utc), cls=_ExtendedEncoder)) >= 0
    assert json.loads(json.dumps(Decimal(1), cls=_ExtendedEncoder)) == '1'
    assert json.loads(json.dumps(UUID('deadbeef-face-cafe-babec0de-c0de1234'), cls=_ExtendedEncoder)) == 'deadbeef-face-cafe-babec0de-c0de1234'



# Generated at 2022-06-23 16:51:39.012762
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default('a') == 'a'
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default(()) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default((1,)) == [1]
    assert _ExtendedEncoder().default((1, 2)) == [1, 2]
    assert _ExtendedEncoder().default(
        {'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert _Extended

# Generated at 2022-06-23 16:51:42.835332
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now())
    assert _ExtendedEncoder().default(UUID(int=0))
    assert _ExtendedEncoder().default(Decimal('123E+5'))


# Generated at 2022-06-23 16:51:53.076847
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test normal case: construct with passing all parameters
    f = FieldOverride(
        exclude=lambda val: True,
        encoder=lambda val: val,
        decoder=lambda val: val,
        letter_case=lambda val: val
    )
    assert f.exclude(1) == True
    assert f.encoder(1) == 1
    assert f.decoder(1) == 1
    assert f.letter_case(1) == 1

    # Test omit infer_missing - it will be set to False

# Generated at 2022-06-23 16:52:04.095938
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(bytearray()) == []
    assert _ExtendedEncoder().default(frozenset()) == []
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(tuple()) == []
    assert _ExtendedEncoder().default(dict()) == {}
    assert _ExtendedEncoder().default(datetime(2019, 2, 1, 2, 3, 4)) == 1548974584.0
    assert _ExtendedEncoder().default(datetime(2019, 2, 1, 2, 3, 4, tzinfo=timezone.utc)) == 1548974584.0

# Generated at 2022-06-23 16:52:04.653942
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass



# Generated at 2022-06-23 16:52:14.459488
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default(None) is None
    assert enc.default(1) == 1
    assert enc.default(1.2) == 1.2
    assert enc.default(True) is True
    assert enc.default(False) is False
    assert enc.default('') == ''
    assert enc.default({}) == {}
    assert enc.default([]) == []
    assert enc.default(set([])) == []
    assert enc.default(set([1])) == [1]
    assert enc.default((1)) == 1
    assert enc.default(()) == []
    assert enc.default({'a': 1}) == {'a': 1}
    assert enc.default({1, 2}) == [1, 2]
    assert enc.default(set({1, 2}))

# Generated at 2022-06-23 16:52:20.168123
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """Unit test for constructor of class _ExtendedEncoder"""
    assert(_ExtendedEncoder().default(datetime.now()) \
           == datetime.now(timezone.utc).timestamp())
    assert(_ExtendedEncoder().default(Decimal('1.1')) == '1.1')
    assert(_ExtendedEncoder().default(UUID('12345678123456781234567812345678',
                                           version=4)) == '12345678-1234-5678-1234-567812345678')



# Generated at 2022-06-23 16:52:29.314883
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda x: 3
    decoder = lambda x: 4
    field_overrides = FieldOverride({'key': 'value'}, {}, {}, {},
                                    encoder=encoder, decoder=decoder)
    assert field_overrides.metadata == {'key': 'value'}
    assert field_overrides.exclude == {}
    assert field_overrides.encoder == encoder
    assert field_overrides.decoder == decoder
    assert field_overrides.letter_case == {}



# Generated at 2022-06-23 16:52:39.349753
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = _ExtendedEncoder()
    assert isinstance(o.default(Decimal('0')), str)
    assert isinstance(o.default(Decimal('0')), str)
    assert isinstance(o.default(datetime.now(tz=timezone.utc)), float)
    assert isinstance(o.default(datetime.now()), float)
    assert isinstance(o.default(datetime.utcnow()), float)
    assert isinstance(o.default(datetime.now(tz=timezone.utc)), float)
    assert isinstance(o.default(datetime.now()), float)
    assert isinstance(o.default(datetime.utcnow()), float)

# Generated at 2022-06-23 16:52:41.727873
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == "null"


# Generated at 2022-06-23 16:52:51.245752
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(0) == '0'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(-1) == '-1'
    assert _ExtendedEncoder().encode(0.0) == '0.0'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _ExtendedEncoder().encode(-1.0) == '-1.0'
    assert _ExtendedEncoder().encode('str') == '"str"'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(False) == 'false'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _Ext

# Generated at 2022-06-23 16:52:55.130755
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # validate override construction when using non-default values
    target_letter_case = lambda x: x
    target_exclude = None
    target_encoder = lambda x: x
    target_decoder = lambda x: x
    FieldOverride(target_letter_case, target_exclude, target_encoder,
                  target_decoder)
    # validate override construction when using the implicit defaults
    FieldOverride()



# Generated at 2022-06-23 16:52:57.260692
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(key_transformer=None, exclude=None,
                                   encoder=None, decoder=None,
                                   mm_field=None)
    assert (field_override.key_transformer is None)
    assert (field_override.exclude is None)


# Generated at 2022-06-23 16:53:06.526398
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert {} == json.loads(json.dumps({}, cls=_ExtendedEncoder))
    assert [1, 2, 3] == json.loads(json.dumps([1, 2, 3], cls=_ExtendedEncoder))
    assert None == json.loads(json.dumps(None, cls=_ExtendedEncoder))
    assert '0123456789' == json.loads(json.dumps(123456789, cls=_ExtendedEncoder))
    assert 5.5 == json.loads(json.dumps(5.5, cls=_ExtendedEncoder))
    assert True == json.loads(json.dumps(True, cls=_ExtendedEncoder))
    assert 'str' == json.loads(json.dumps('str', cls=_ExtendedEncoder))


# Generated at 2022-06-23 16:53:16.820901
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default({'x': 1}) == {'x': 1}
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default(datetime(2014, 3, 8, 12, 30, 0, 0, timezone.utc)) == 1396812200
    assert encoder.default(UUID('74168388-a2a2-4fc0-a98f-46da1b77c8b2')) == '74168388-a2a2-4fc0-a98f-46da1b77c8b2'
    assert encoder.default(Decimal('3.1415926535897932384626433832')) == '3.1415926535897932384626433832'
    assert encoder

# Generated at 2022-06-23 16:53:26.108227
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import date, datetime, time, timezone
    from decimal import Decimal
    from uuid import UUID
    enum_value = enum.Enum('Foo', 'bar baz')

# Generated at 2022-06-23 16:53:31.295614
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """Test constructor of class FieldOverride."""
    obj = FieldOverride()

    # Test attributes
    assert obj.exclude == (lambda _: False), f'Expected False, got {obj.exclude}'
    assert obj.letter_case == (lambda x: x), f'Expected lambda x: x, got {obj.letter_case}'
    assert obj.encoder == None, f'Expected None, got {obj.encoder}'

# Unit tests for function _user_overrides_or_exts

# Generated at 2022-06-23 16:53:41.522360
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    config1 = {
        'exclude': None,
        'letter_case': None,
        'encoder': None,
        'decoder': None,
        'mm_field': None
    }
    config2 = {
        'exclude': lambda x: x == 2,
        'letter_case': lambda x: x.upper(),
        'encoder': 'encoder',
        'decoder': 'decoder',
        'mm_field': 'mm_field'
    }
    override1 = FieldOverride(*map(config1.get, confs))
    override2 = FieldOverride(*map(config2.get, confs))
    assert override1.exclude is None
    assert override1.letter_case is None
    assert override1.encoder is None
    assert override1.decoder is None
    assert override1

# Generated at 2022-06-23 16:53:47.144766
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert e.default(object()) == '<object object at 0x7f0e04bafdb0>'
    assert e.default(datetime(2010, 10, 12, tzinfo=timezone.utc)) == 1286851200.0
    assert e.default('test') == '"test"'
    assert e.default([1, 2]) == [1, 2]
    assert e.default({'a': 1}) == {'a': 1}


# Generated at 2022-06-23 16:53:57.765346
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"abc": 123}) == '{"abc": 123}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(datetime.now()) == _ExtendedEncoder().encode(datetime.now().timestamp())
    assert _ExtendedEncoder().encode(
        cfg.environ_compliant_datetime_now()) == _ExtendedEncoder().encode(datetime.now().timestamp())
    assert _ExtendedEncoder().encode(cfg.environ_compliant_datetime_now()) == _ExtendedEncoder().encode(
        datetime.now().replace(tzinfo=timezone.utc).timestamp())



# Generated at 2022-06-23 16:54:01.706508
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(lambda x: x, lambda x: x, lambda x: x, lambda x: False)
    assert isinstance(f.letter_case, Callable)
    assert isinstance(f.encoder, Callable)
    assert isinstance(f.decoder, Callable)
    assert isinstance(f.exclude, Callable)

# Generated at 2022-06-23 16:54:07.716653
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Check valid cases
    # All three functions
    assert FieldOverride(
        exclude=lambda x: True, encoder=lambda x: x,
        decoder=lambda x: x,
        letter_case=lambda x: x,
    )
    # only exclude function
    assert FieldOverride(
        exclude=lambda x: True,
    )
    # only encoder function
    assert FieldOverride(
        encoder=lambda x: x,
    )
    # only decoder functions
    assert FieldOverride(
        decoder=lambda x: x,
    )
    # only letter_case function
    assert FieldOverride(
        letter_case=lambda x: x,
    )
    # no function
    assert FieldOverride()

    # Check invalid cases
    # both exclude and encoder functions

# Generated at 2022-06-23 16:54:17.369033
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f1 = FieldOverride(None, None, None)
    assert f1.encoder == None
    assert f1.decoder == None
    assert f1.exclude == None
    assert f1.letter_case == None

    f1 = FieldOverride(exclude=True)
    assert f1.exclude == True

    f1 = FieldOverride(encoder=lambda x: x.lower())
    f2 = FieldOverride(decoder=lambda x: x.upper())
    f3 = FieldOverride(letter_case=str.title)
    assert f1.encoder("TEST") == "test"
    assert f2.decoder("TEST") == "TEST"
    assert f3.letter_case("test title") == "Test Title"

# Generated at 2022-06-23 16:54:28.606996
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

# Generated at 2022-06-23 16:54:39.446741
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(set([1, 2, 3])) == [1, 2, 3]
    assert _ExtendedEncoder().default(tuple([1, 2, 3])) == [1, 2, 3]
    assert _ExtendedEncoder().default(['a', 'b']) == ['a', 'b']
    assert _ExtendedEncoder().default(dict(a='a', b='b')) == {'a': 'a', 'b': 'b'}
    assert _ExtendedEncoder().default(UUID('a844d4c4-0e0b-4eee-8b65-75cdce1f9f17')) == 'a844d4c4-0e0b-4eee-8b65-75cdce1f9f17'
    assert _

# Generated at 2022-06-23 16:54:52.302418
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from operator import itemgetter
    from collections import OrderedDict

    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({"a": 1}) == {"a": 1}
    assert encoder.default(OrderedDict((("a", 1), ("b", 2)))) == {"a": 1, "b": 2}
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default(frozenset([1, 2, 3])) == [1, 2, 3]
    assert encoder.default(datetime(2018, 9, 19, 12, 34, 56, tzinfo=timezone.utc)) == 1537329560

# Generated at 2022-06-23 16:55:01.809993
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Arrange
    letter_case = lambda x: x.lower()
    exclude = lambda x: x is None
    encoder = lambda x: x + 1
    decoder = lambda x: x - 1

    # Act
    field_override = FieldOverride(letter_case, exclude, encoder, decoder)

    # Assert
    assert field_override.letter_case == letter_case
    assert field_override.exclude == exclude
    assert field_override.encoder == encoder
    assert field_override.decoder == decoder
