

# Generated at 2022-06-23 16:45:15.805878
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    oo: Json = _ExtendedEncoder().default(bytearray('abc', 'utf-8'))
    assert oo == 'abc'
    oo = _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc))
    assert oo == 0.0
    oo = _ExtendedEncoder().default(UUID(bytes=b'1234'))
    assert oo == '00000000-0000-0000-0000-000000123400'
    oo = _ExtendedEncoder().default(Decimal(1))
    assert oo == '1'
    oo = _ExtendedEncoder().default(set([1, 2]))
    assert oo == [1, 2]

# Generated at 2022-06-23 16:45:25.686207
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1,2]) == [1,2]
    assert encoder.default(dict()) == {}
    assert encoder.default(1) == 1
    assert encoder.default(True) == True
    assert encoder.default(None) == None
    assert encoder.default(12.3) == 12.3
    import datetime
    dt = datetime.datetime(2020, 2, 21, 3, 22, 35)
    assert encoder.default(dt) == 1582291755.0 # timestamp
    from enum import Enum
    class TestEnum(Enum):
        A = 1
        B = 2
    assert encoder.default(TestEnum.A) == 1

# Generated at 2022-06-23 16:45:33.708991
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    @dataclass
    class _Dummy:
        pass
    encoder = _ExtendedEncoder()
    assert datetime.now(timezone.utc).timestamp() == encoder.default(datetime.now(timezone.utc))
    assert [1, 2, 3] == encoder.default([1, 2, 3])
    assert {'one': 1, 'two': 2} == encoder.default({'one': 1, 'two': 2})
    assert Decimal('0.0001') == Decimal(str(encoder.default(Decimal('0.0001'))))
    with pytest.raises(TypeError):
        assert Decimal('0.0001') == Decimal(str(encoder.default(_Dummy())))


_encoder: _ExtendedEncoder = _ExtendedEncoder()



# Generated at 2022-06-23 16:45:39.161599
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    json_str = encoder.encode(tuple({'a': 1}))
    assert json_str == '[[["a", 1]]]'
    json_str = encoder.encode(tuple({1: 'a'}))
    assert json_str == '[[[1, "a"]]]'



# Generated at 2022-06-23 16:45:46.660040
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda x: x
    decoder = lambda x: x
    exclude = lambda x: True if x is None else False
    letter_case = lambda x: x.upper()
    field_override = FieldOverride(encoder=encoder, decoder=decoder,
                                   exclude=exclude, letter_case=letter_case)
    assert field_override.__dict__ == dict(encoder=encoder, decoder=decoder,
                                           exclude=exclude,
                                           letter_case=letter_case)



# Generated at 2022-06-23 16:45:56.331089
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.1) == 1.1
    assert _ExtendedEncoder().default("a") == "a"
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default({"a":1}) == {"a":1}
    assert _ExtendedEncoder().default([1,2]) == [1,2]
    assert _ExtendedEncoder().default(datetime(2000, 1, 1)) == datetime(2000, 1, 1).timestamp()

# Generated at 2022-06-23 16:46:04.996972
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # noinspection PyArgumentList
    encoder = _ExtendedEncoder()
    assert encoder.default([]) == []
    assert encoder.default({}) == {}
    assert encoder.default(datetime(2018, 12, 3, 17, 24, 55,
                                    tzinfo=timezone.utc)) == 1543809895.0
    assert encoder.default(UUID('77ac519d-28f0-4b75-8fa2-d0e76f78b7ab')) == str(UUID('77ac519d-28f0-4b75-8fa2-d0e76f78b7ab'))
    assert encoder.default(Decimal('3.14')) == '3.14'


# Generated at 2022-06-23 16:46:17.006011
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(1) == json.dumps(1)
    assert _ExtendedEncoder().encode(True) == json.dumps(True)
    assert _ExtendedEncoder().encode(1.1) == json.dumps(1.1)
    assert _ExtendedEncoder().encode('str') == json.dumps('str')
    assert _ExtendedEncoder().encode(None) == json.dumps(None)
    assert _ExtendedEncoder().encode([1, 2, 3]) == json.dumps([1, 2, 3])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == json.dumps({'a': 1, 'b': 2})

# Generated at 2022-06-23 16:46:22.358637
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    enc = lambda s: s
    dec = lambda s: s
    ex = lambda s: False
    f = FieldOverride(letter_case=str.upper,
                      encoder=enc,
                      decoder=dec,
                      exclude=ex)
    assert f.letter_case is str.upper
    assert f.encoder is enc
    assert f.decoder is dec
    assert f.exclude is ex



# Generated at 2022-06-23 16:46:24.626470
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode({1:2}) == '{1: 2}'



# Generated at 2022-06-23 16:46:31.728307
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    def func(x, y, z):
        return x, y, z

    v = FieldOverride(exclude=func, letter_case=func, encoder=func, decoder=func)
    assert v.exclude(1, 2, 3) == (1, 2, 3)

    v = FieldOverride()
    v._set_exclude(func)
    assert v.exclude(1, 2, 3) == (1, 2, 3)

    v = FieldOverride()
    v._set_letter_case(func)
    assert v.letter_case(1, 2, 3) == (1, 2, 3)

    v = FieldOverride()
    v._set_encoder(func)
    assert v.encoder(1, 2, 3) == (1, 2, 3)

    v = FieldOverride()
   

# Generated at 2022-06-23 16:46:35.370685
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    class Foo:
        pass

    class Bar:
        def __repr__(self):
            return 'Bar'

    class TupleBar(tuple):
        pass

    cases: Collection[Any] = [
        [1, 2, 3],
        {1: 1, 2: 2, 3: 3},
        (1, 2, 3),
        datetime(2020, 1, 1).astimezone(timezone.utc),
        UUID('{12345678-1234-5678-1234-567812345678}'),
        Enum('Color', ['RED', 'GREEN', 'BLUE'])('GREEN'),
        Decimal(123.45),
        Foo(),
        Bar(),
        TupleBar(1, 2, 3),
    ]

    e = _ExtendedEncoder()

# Generated at 2022-06-23 16:46:39.783479
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
        # Test case 1: use default values
        override = FieldOverride()
        # Test case 2: use non-default value
        override = FieldOverride(exclude=lambda _: True, encoder=lambda _: None,
                                 decoder=lambda _: None, letter_case="snake",
                                 mm_field="Nested")
        assert override.exclude is None
        assert override.encoder is None
        assert override.decoder is None
        assert override.letter_case is None
        assert override.mm_field is None

# Generated at 2022-06-23 16:46:47.937994
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': 12}) == '{"a": 12}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(Decimal('1234.5678')) == '"1234.5678"'


# Generated at 2022-06-23 16:46:55.074557
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import date, datetime, time, timedelta
    from uuid import uuid4
    from decimal import Decimal
    from enum import IntEnum
    class TestEnum(IntEnum):
        TEST = 1
    @dataclass(frozen=True)
    class TestDc:
        dt: datetime
        d: date
        t: time
        td: timedelta
        uuid: UUID
        dec: Decimal
        enum: TestEnum

# Generated at 2022-06-23 16:47:05.881011
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(datetime(2018, 5, 17, 9, 10, 11, 1234)) == 1526553411.0012

# Generated at 2022-06-23 16:47:09.669956
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(exclude=lambda x: x is None,
                      letter_case=str.upper,
                      encoder=str.upper,
                      decoder=str.lower)
    assert f.exclude(None)
    assert not f.exclude(1)
    assert f.letter_case("test") == "TEST"
    assert f.encoder("test") == "TEST"
    assert f.decoder("TEST") == "test"

# Generated at 2022-06-23 16:47:18.278907
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class Foo:
        pass

    default_field_override = FieldOverride()
    assert default_field_override.encoder is None
    assert default_field_override.decoder is None
    assert default_field_override.mm_field is None
    assert default_field_override.exclude is None
    assert default_field_override.letter_case is None

    encoder_decoder_field_override = FieldOverride(encoder=Foo,
                                                   decoder=Foo,
                                                   mm_field=Foo)
    assert encoder_decoder_field_override.encoder == Foo
    assert encoder_decoder_field_override.decoder == Foo
    assert encoder_decoder_field_override.mm_field == Foo
    assert encoder_decoder_field

# Generated at 2022-06-23 16:47:29.167939
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride('snake', lambda val: val, None, lambda val: True, True) == FieldOverride('snake', lambda val: val, None, lambda val: True, True)
    assert FieldOverride('snake', lambda val: val, None, lambda val: True, True) != FieldOverride('snake', lambda val: val, None, lambda val: False, True)
    assert FieldOverride('snake', lambda val: val, lambda val: val, lambda val: True, True) != FieldOverride('snake', lambda val: val, None, lambda val: True, True)
    assert FieldOverride('snake', lambda val: val, lambda val: val, lambda val: True, True) != FieldOverride('snake', lambda val: val, lambda val: val, lambda val: False, True)

# Generated at 2022-06-23 16:47:39.318547
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(TypeError):
        FieldOverride()
    with pytest.raises(TypeError):
        FieldOverride(1)
    with pytest.raises(TypeError):
        FieldOverride(1, None)
    with pytest.raises(TypeError):
        FieldOverride(1, None, None)
    with pytest.raises(TypeError):
        FieldOverride(1, None, None, None)
    with pytest.raises(TypeError):
        FieldOverride(1, None, None, None, None)
    with pytest.raises(TypeError):
        FieldOverride(1, None, None, None, None, None)
    with pytest.raises(TypeError):
        FieldOverride(1, None, None, None, None, None, None)

# Generated at 2022-06-23 16:47:48.806667
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    letter_case = lambda x: x.upper()
    decode = lambda x: x.upper()
    encode = lambda x: x.upper()
    exclude = lambda x: x.upper()
    f1 = FieldOverride(letter_case, decode, encode, exclude)
    assert hasattr(f1, 'letter_case')
    assert hasattr(f1, 'decoder')
    assert hasattr(f1, 'encoder')
    assert hasattr(f1, 'exclude')
    assert f1.letter_case is letter_case
    assert f1.decoder is decode
    assert f1.encoder is encode
    assert f1.exclude is exclude

    f2 = FieldOverride(decode=decode)
    assert f2.letter_case is None
    assert f2.decoder is decode
    assert f2

# Generated at 2022-06-23 16:47:52.987963
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Test collection
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test datetime
    assert _ExtendedEncoder().default(
        datetime(2020, 2, 19, 12, 1, 2, 123456, timezone.utc)) == 1582101662.123456
    # Test UUID
    assert _ExtendedEncoder().default(UUID('48ff7b38-40fa-4ac6-b5db-ad4530377483')) == '48ff7b38-40fa-4ac6-b5db-ad4530377483'
    # Test Enum

# Generated at 2022-06-23 16:47:53.569517
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass


# Generated at 2022-06-23 16:48:04.658629
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(('1', 2, 3)) == ['1', 2, 3]
    assert _ExtendedEncoder().default({'1': 2, 3: 4}) == {'1': 2, '3': 4}
    assert _ExtendedEncoder().default(datetime.now()) > 10000000000
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(
        Decimal('0.1') + Decimal('0.2') + Decimal('0.3')) == '0.6'
    assert _Extended

# Generated at 2022-06-23 16:48:16.553554
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default('1') == '1'
    assert encoder.default('a') == 'a'
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(float('inf')) == float('inf')
    assert encoder.default(float('nan')) == float('nan')
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default(frozenset({'a', 'b'})) == frozenset({'a', 'b'})
    assert enc

# Generated at 2022-06-23 16:48:21.202447
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default('') == ''
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(set()) == []



# Generated at 2022-06-23 16:48:30.494461
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    @dataclass
    class Person:
        id: int
        name: str
        age: int = 0
        hobbies: List[str] = field(default_factory=list)
        meta: Dict[str, str] = field(default_factory=dict)

        @classmethod
        def from_json(cls, json):
            return _decode_dataclass(cls, json, False)

        def to_json(self):
            return _asdict(self, encode_json=True)

    d = Person.from_json({
        "id": 1,
        "name": "svetty",
        "age": 30,
        "hobbies": ["hiking", "movies"],
        "meta": {"mood": "happy"},
    })

    assert d.id == 1

# Generated at 2022-06-23 16:48:42.370561
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(Decimal(1)) == '1'
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('d63a7f3c-b379-42e5-872b-10a0a35da306')) == 'd63a7f3c-b379-42e5-872b-10a0a35da306'
    assert _ExtendedEncoder().default(set()) == list()
    assert _ExtendedEncoder().default(frozenset()) == list()
    assert _ExtendedEncoder().default(tuple()) == list()
    assert _ExtendedEncoder().default(list()) == list()

Numeric

# Generated at 2022-06-23 16:48:49.174778
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    config = FieldOverride(exclude=lambda x: x == 0,
                           letter_case=lambda x: x.upper(),
                           encoder=lambda x: x[::-1],
                           decoder=lambda x: x[::-1],
                           mm_field=lambda x: x)
    assert config.exclude(0)
    assert not config.exclude(1)
    assert config.letter_case('test') == 'TEST'
    assert config.encoder('test') == 'tset'
    assert config.decoder('test') == 'tset'
    assert config.mm_field('test') == 'test'


# Generated at 2022-06-23 16:49:00.766615
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder(indent=4, sort_keys=True).encode(
        datetime(2018, 1, 1, tzinfo=timezone.utc)) == '"1514764800.0"'
    assert _ExtendedEncoder(indent=4, sort_keys=True).encode(
        datetime(2018, 1, 1)) == '"1514764800.0"'
    assert _ExtendedEncoder(indent=4, sort_keys=True).encode(
        {"a": 1}) == '{\n    "a": 1\n}'
    assert _ExtendedEncoder(indent=4, sort_keys=True).encode(
        [1, 2, 3]) == '[\n    1,\n    2,\n    3\n]'



# Generated at 2022-06-23 16:49:02.484376
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-23 16:49:12.010729
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc))
    assert result == 0, 'datetime.timestamp() function is not supported'
    result = _ExtendedEncoder().default(UUID('12345678123456781234567812345678'))
    assert result == '12345678123456781234567812345678', 'UUID has not been converted to a string'
    result = _ExtendedEncoder().default(Decimal('1.1'))
    assert result == '1.1', 'decimal.Decimal has not been converted to a string'


# Generated at 2022-06-23 16:49:16.366541
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = [0, 1]
    e = _ExtendedEncoder()
    assert e.default(o) == o



# Generated at 2022-06-23 16:49:17.696574
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": datetime.utcnow()})


# Generated at 2022-06-23 16:49:25.897860
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

    assert encoder.default(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime(2017, 12, 13, 13, 13)) == 1513162380.0
    assert encoder.default(datetime(2017, 12, 13, 13, 13, 0, 0, timezone.utc)) == 1513162380.0

# Generated at 2022-06-23 16:49:32.011914
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(None, None, None, None)
    assert field_override.exclude is None
    assert field_override.letter_case is None
    assert field_override.encoder is None
    assert field_override.decoder is None
    assert field_override.mm_field is None



# Generated at 2022-06-23 16:49:37.206053
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('f3b2a3b6-d0d3-40ed-b923-a7eec9b1a828'))
    assert _ExtendedEncoder().encode(Decimal('3.14'))



# Generated at 2022-06-23 16:49:47.506134
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import datetime
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.datetime.now()) == 1548781475.307707
    assert encoder.default(UUID('4a26b6a5-d4d8-4c0e-9b2a-cddf879e303e')) == '4a26b6a5-d4d8-4c0e-9b2a-cddf879e303e'
    assert encoder.default(datetime.timezone.utc) == 'UTC'

    class TestEnum(Enum):
        ONE = 1
        TWO = 2

    assert encoder.default(TestEnum.ONE) == 1
    assert encoder.default(Decimal('1.1')) == '1.1'
   

# Generated at 2022-06-23 16:49:52.022666
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class TestClass:
        def __init__(self, x):
            self.x = x
    test_class = TestClass(x=10)
    assert test_class.x == 10



# Generated at 2022-06-23 16:50:01.148605
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default(dict(a='b')) == {'a': 'b'}
    assert encoder.default(b'abc') == 'abc'
    assert encoder.default(bytearray(b'abc')) == 'abc'
    assert encoder.default(frozenset([1, 2, 3])) == [1, 2, 3]
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-23 16:50:03.732599
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"foo": [[1], [2]]}) == '{"foo": [[1], [2]]}'



# Generated at 2022-06-23 16:50:14.382521
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Tests the constructor of FieldOverride class with different types
    """
    # test with None
    override = FieldOverride(None, None, None)
    assert override.encoder is None
    assert override.decoder is None
    assert override.exclude is None
    assert override.letter_case is None
    assert override.mm_field is None
    # test with a lambda
    override = FieldOverride(lambda x: x, lambda x: x, lambda x: x)
    assert override.encoder is not None
    assert override.decoder is not None
    assert override.exclude is not None
    assert override.letter_case is None
    assert override.mm_field is None
    # test with a string
    override = FieldOverride("", "", "")
    assert override.encoder is not None

# Generated at 2022-06-23 16:50:16.065150
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert e.default(Decimal(1)) == '1'


# Generated at 2022-06-23 16:50:25.891986
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(10.5) == 10.5
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default('foo') == 'foo'
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(set([1, 2, 3])) == [1, 2, 3]
    assert _ExtendedEncoder().default({1:2, 3:4}) == {1:2, 3:4}
    assert _ExtendedEncoder().default(Decimal('1.234')) == '1.234'

# Generated at 2022-06-23 16:50:34.997767
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default([1, 2, 3]) == [1, 2, 3]
    assert enc.default({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert enc.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert enc.default(UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")) == "6ba7b810-9dad-11d1-80b4-00c04fd430c8"
    assert enc.default(Enum("Enum", "a b")) == "a"
    assert enc.default(Decimal("1.5")) == "1.5"

# Generated at 2022-06-23 16:50:46.888382
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    # Default behaviour:
    # - default should fallback to _ExtendedEncoder.default
    # - if user wants a custom behaviour, he must provide its own `encoder`
    assert isinstance(e.default(None), type(None))
    assert isinstance(e.default(True), type(True))
    assert isinstance(e.default(1), int)
    assert isinstance(e.default(1.0), float)
    assert isinstance(e.default("string"), str)
    assert isinstance(e.default([]), list)
    assert isinstance(e.default({}), dict)
    # New behaviour:
    # - default should convert UUID to string

# Generated at 2022-06-23 16:50:53.399695
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj = _ExtendedEncoder()

    assert obj.default([]) == []
    assert obj.default({"x": "y"}) == {"x": "y"}
    assert obj.default(datetime.now()) == datetime.now().timestamp()
    assert obj.default(UUID(int=1)) == "00000000-0000-0000-0000-000000000001"
    assert obj.default(Decimal('1.5')) == "1.5"



# Generated at 2022-06-23 16:51:00.642684
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoding = str
    decoding = str
    letter_case = str.lower
    exclude = lambda _: True
    field_override = FieldOverride(encoding, decoding, letter_case, exclude)

    assert(field_override.encoder == str)
    assert(field_override.decoder == str)
    assert(field_override.letter_case == str.lower)
    assert(field_override.exclude(1) == True)

# Generated at 2022-06-23 16:51:13.875719
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Define a FieldOverride object with parameter in order.
    # Note that encode/decode are None, by default.
    f1 = FieldOverride(False, None, None)
    # Test that the values of f1 are False, None, None
    assert f1.exclude is False
    assert f1.letter_case is None
    assert f1.encoder is None
    assert f1.decoder is None
    # Test that the object f1 is instance of FieldOverride.
    assert isinstance(f1, FieldOverride)

    # Define a FieldOverride object with parameter in order.
    # Note that encode/decode are None, by default.
    f2 = FieldOverride(True, _decamel, None, None)
    # Test that the values of f2 are True, _decamel, None, None

# Generated at 2022-06-23 16:51:22.378767
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    result = _ExtendedEncoder().default(None)
    assert result is None
    result = _ExtendedEncoder().default([])
    assert isinstance(result, list)
    assert len(result) == 0
    result = _ExtendedEncoder().default({})
    assert isinstance(result, dict)
    assert len(result) == 0
    result = _ExtendedEncoder().default("")
    assert isinstance(result, str)
    assert result == ""
    result = _ExtendedEncoder().default(0)
    assert isinstance(result, int)
    assert result == 0
    result = _ExtendedEncoder().default(0.0)
    assert isinstance(result, float)
    assert result == 0.0
    result = _ExtendedEncoder().default(True)

# Generated at 2022-06-23 16:51:32.353752
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o1 = datetime.now()
    o2 = datetime.utcnow().replace(microsecond=0)
    o3 = datetime.now(timezone.utc).replace(microsecond=0)
    assert _ExtendedEncoder().default(o1) == o1.timestamp()
    assert _ExtendedEncoder().default(o2) == o2.timestamp()
    assert _ExtendedEncoder().default(o3) == o3.timestamp()

# Test for method default of class _ExtendedEncoder
test__ExtendedEncoder_default()

CUSTOM_HOOKS_MAP: Mapping[type, Any] = {}



# Generated at 2022-06-23 16:51:42.870189
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    o1 = [1, 2, 3]
    o2 = {'a': 1, 'b': 2}
    o3 = datetime(2020, 1, 1, 12, 0, 0)
    o4 = datetime(2020, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    o5 = datetime(2020, 1, 1, 12, 0, 0, 4523)
    o6 = UUID('123e4567-e89b-12d3-a456-426655440000')
    o7 = Enum('Foo', {'bar': 1})
    o7.bar
    o8 = Decimal('12.345')
    assert encoder.default(o1) == o1

# Generated at 2022-06-23 16:51:53.076760
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        encoder = _ExtendedEncoder()
        encoder.default(set([1, 2, 3])) # pragma: no cover
        assert len(w) == 1
        assert issubclass(w[-1].category, DeprecationWarning)
        assert "Bad collection type" in str(w[-1].message)
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default({1, 2, 3}) == [1, 2, 3]
    assert encoder.default(frozenset([1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-23 16:52:04.126421
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    @dataclass
    class MyDataClass:
        a: int
        b: str = 'b'

    # First test case, exclude
    @dataclass
    class MyDataClass1:
        a: int
        b: str = 'b'
        c: str = dataclasses_json.config(exclude_if_none=True)

    # Second test case, decoder
    @dataclass
    class MyDataClass2:
        a: int
        b: str = 'b'
        c: str = dataclasses_json.config(decoder=lambda x: x * 2)

    # Third test case, letter_case
    @dataclass
    class MyDataClass3:
        a: int
        b: str = 'b'

# Generated at 2022-06-23 16:52:09.193144
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride("json", "snake_case", "foo", "bar", "baz")
    assert f.letter_case("foo") == "snake_case"
    assert f.exclude(1) == "bar"
    assert f.encoder(2) == "foo"
    assert f.decoder(3) == "baz"



# Generated at 2022-06-23 16:52:14.434946
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # type: () -> None
    res = FieldOverride(None, True, None, None)
    # res.mm_fields should be a list
    assert isinstance(res.mm_fields, list)
    assert len(res.mm_fields) == 0



# Generated at 2022-06-23 16:52:20.329844
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == []
    assert encoder.default(frozenset()) == []
    assert encoder.default(dict()) == {}
    assert encoder.default(datetime(2020, 1, 1, 1, 1, 1, tzinfo=timezone.utc)) == 1577886261.0
    assert encoder.default(UUID('93e04b1f-196c-4e0c-b76d-5eb548620d5e')) == '93e04b1f-196c-4e0c-b76d-5eb548620d5e'
    assert encoder.default(Decimal('0.01')) == '0.01'
    assert encoder.default(Exception()) == "<class 'Exception'>"



# Generated at 2022-06-23 16:52:31.339594
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = Mapper(from_json=lambda x: x)
    decoder = Mapper(from_json=lambda x: x)
    field_override = FieldOverride(encoder=encoder, decoder=decoder)
    assert field_override.exclude is None
    assert field_override.letter_case is None
    assert field_override.encoder is encoder
    assert field_override.decoder is decoder

    encoder = Mapper(from_json=lambda x: x)
    decoder = Mapper(from_json=lambda x: x)
    field_override = FieldOverride(encoder=encoder, decoder=decoder)
    assert field_override.exclude is None
    assert field_override.letter_case is None
    assert field_override.encoder is enc

# Generated at 2022-06-23 16:52:33.552205
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with raises(AssertionError):
        FieldOverride(None, None, None, None, None)


# Generated at 2022-06-23 16:52:42.813320
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": [1, 2, 3]}) == '{"a": [1, 2, 3]}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.1) == '1.1'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'

# Generated at 2022-06-23 16:52:46.379527
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    e = lambda x: x
    d = lambda x: x
    c = 1
    f = FieldOverride(exclude=e, encoder=e, decoder=d, letter_case=c)
    assert f.exclude == e
    assert f.encoder == e
    assert f.decoder == d
    assert f.letter_case == c

# Unit tests for _handle_undefined_parameters

# Generated at 2022-06-23 16:52:59.985628
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from typing import Any, Dict
    from uuid import UUID

    from datetime import datetime, timedelta

    from decimal import Decimal

    from enum import Enum

    from dataclasses_json.utils import _is_mapping


    class DummyEnum(Enum):
        a = 1
        b = 2


# Generated at 2022-06-23 16:53:04.109801
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    result = encoder.default(datetime(2010, 10, 10, 0, 0))
    assert result == 1286294400.0



# Generated at 2022-06-23 16:53:07.700577
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(exclude=None,
                         letter_case=None,
                         encoder=None,
                         decoder=None) is not None



# Generated at 2022-06-23 16:53:17.196810
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    # test for collections
    # test all Collection types and others

# Generated at 2022-06-23 16:53:26.345177
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    E = _ExtendedEncoder()
    assert E.default([1, 2, 3]) == [1, 2, 3]
    assert E.default((1, 2, 3)) == [1, 2, 3]
    assert E.default({'a': 1}) == {'a': 1}
    assert E.default(set([1, 2, 3])) == [1, 2, 3]
    assert E.default({1, 2, 3}) == [1, 2, 3]
    assert E.default(frozenset([1, 2, 3])) == [1, 2, 3]
    assert E.default(datetime(2020, 1, 1, 0, 0, tzinfo=timezone.utc)) == 157787200

# Generated at 2022-06-23 16:53:30.150450
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(lambda x: x)
    assert fo.letter_case(lambda x: x) == fo.letter_case
    assert fo.encoder(lambda x: x) == fo.encoder
    assert fo.exclude(lambda x: x) == fo.exclude
    assert fo.mm_field(lambda x: x) == fo.mm_field


# Generated at 2022-06-23 16:53:36.025872
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    lst = [1, 2, 3]
    assert _ExtendedEncoder().default(lst) == lst
    dct = {'aa': 1, 'bb': 2}
    assert _ExtendedEncoder().default(dct) == dct
    dt = datetime.fromtimestamp(0, tz=timezone.utc)
    assert _ExtendedEncoder().default(dt) == 0



# Generated at 2022-06-23 16:53:38.966745
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """Test FieldOverride construction when passed objects of type str and
    Callable."""
    assert FieldOverride('lowercase') is not None
    assert FieldOverride(lambda x: x) is not None



# Generated at 2022-06-23 16:53:48.182625
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from uuid import uuid4
    from datetime import datetime
    from decimal import Decimal
    from enum import Enum
    from dataclasses import dataclass
    from typing import Optional

    @dataclass
    class EnumData:
        enum_type: Enum

    @dataclass
    class DecimalData:
        decimal_type: Decimal

    @dataclass
    class DatetimeData:
        datetime_type: datetime

    @dataclass
    class UuidData:
        uuid_type: UUID

    @dataclass
    class TestData:
        id: int
        data: dict
        str_data: Union[str, int, float, bool, None]
        optional_str_data: Optional[str]
        enum_data: EnumData

# Generated at 2022-06-23 16:53:58.980337
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert json.dumps(set([1]), cls=_ExtendedEncoder) == '[1]'
    assert json.dumps(frozenset([1]), cls=_ExtendedEncoder) == '[1]'

    assert json.dumps(set([1, "foo"]), cls=_ExtendedEncoder) == '[1, "foo"]'
    assert json.dumps(frozenset([1, "foo"]), cls=_ExtendedEncoder) == '[1, "foo"]'

    assert json.dumps({1: 2}, cls=_ExtendedEncoder) == '{"1": 2}'
    assert json.dumps(dict.fromkeys([1, "foo"], 2), cls=_ExtendedEncoder) == '{"1": 2, "foo": 2}'

    assert json.dumps

# Generated at 2022-06-23 16:54:06.077405
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    instance = FieldOverride(
        exclude=lambda x: x is None,
        encoder=_encode_null,
        decoder=_decode_null
    )
    assert (isinstance(instance, FieldOverride))
    assert (instance.exclude is not None)
    assert (instance.encoder is not None)
    assert (instance.decoder is not None)
    assert (instance.letter_case is None)



# Generated at 2022-06-23 16:54:16.921860
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    This is a unit test for the class FieldOverride
    """
    # Test exclude is a method and not None
    def is_string(val):
        if isinstance(val, str):
            return True
        else:
            return False

    # Test for letter_case is None and decoder is not None
    def decoder(val):
        if isinstance(val, str):
            return val + " - decoded"
        else:
            return val

    test_override = FieldOverride(is_string, None, decoder)
    assert type(test_override.exclude) == types.FunctionType
    assert test_override.letter_case == None
    assert type(test_override.decoder) == types.FunctionType

    # Test to_str() method
    assert test_override.to_str

# Generated at 2022-06-23 16:54:28.176138
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = _ExtendedEncoder()
    r = o.default(1.1)
    assert r == 1.1
    r = o.default([1, 2, 3])
    assert r == [1, 2, 3]
    r = o.default((1, 2, 3))
    assert r == [1, 2, 3]
    r = o.default({'a': 1})
    assert r == {'a': 1}
    r = o.default(datetime.now())
    assert isinstance(r, float)
    r = o.default(datetime.now(timezone.utc))
    assert isinstance(r, float)
    r = o.default(set([1, 2, 3]))
    assert r == [1, 2, 3]

# Generated at 2022-06-23 16:54:30.637338
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default(MappingProxyType({'a': 1}))



# Generated at 2022-06-23 16:54:33.484611
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc) +
                                      datetime.now(timezone.utc).resolution) == pytest.approx(
        _ExtendedEncoder().default(datetime.now(timezone.utc)))



# Generated at 2022-06-23 16:54:42.433662
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = _ExtendedEncoder()
    assert o.default(datetime.now(timezone.utc)) is not None
    assert o.default(UUID("deadbeef-dead-dead-dead-deaddeaddead")) is not None
    assert o.default(Decimal("1.234")) == "1.234"
    assert o.default(cfg.ENV) == "<Environment(dev)>"
    assert o.default(ClassWithDefaults) == {}
    assert o.default([1,2,3]) == [1,2,3]
    assert o.default({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-23 16:54:53.930640
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    assert _isinstance_safe(e.default([]), list)
    assert _isinstance_safe(e.default(()), list)
    assert _isinstance_safe(e.default({}), dict)
    assert e.default(datetime.now()) > 0
    assert _isinstance_safe(e.default(datetime.now(tz=timezone.utc)), (int, float))
    assert _isinstance_safe(e.default(UUID('00000000-0000-0000-0000-000000000000')), str)
    assert _isinstance_safe(e.default(Decimal('1')), str)
    e = _ExtendedEncoder()
    class MyEnum(Enum):
        a = 'a'

# Generated at 2022-06-23 16:55:04.761274
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    c = FieldOverride(
        exclude=lambda v: v==None,
        letter_case=lambda a: a.lower(),
        encoder=lambda v: v+10,
        decoder=lambda v: v*10,
        mm_field=lambda v: (v, 'value')
    )
    assert c.exclude(0) == False
    assert c.exclude(None) == True
    assert c.letter_case('Foo') == 'foo'
    assert c.encoder(1) == 11
    assert c.decoder(1) == 10
    assert c.mm_field(True) == (True, 'value')