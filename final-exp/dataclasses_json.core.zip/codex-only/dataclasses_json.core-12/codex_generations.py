

# Generated at 2022-06-23 16:45:03.408002
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now(tz=timezone.utc)) == datetime.now(tz=timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('590bcd0d-10f7-4d28-9c9c-4414f5323d2c')) == '590bcd0d-10f7-4d28-9c9c-4414f5323d2c'
    assert _ExtendedEncoder().default(Decimal('12.345')) == '12.345'

# Generated at 2022-06-23 16:45:08.185523
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(True, letter_case=None)
    assert f.exclude is True
    assert f.letter_case is None
    assert f.encoder is None
    assert f.decoder is None

    f = FieldOverride(False, letter_case=None, encoder=int)
    assert f.exclude is False
    assert f.letter_case is None
    assert f.encoder(3) == 3
    assert f.decoder is None



# Generated at 2022-06-23 16:45:18.411242
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Testing default FieldOverride
    field_override = FieldOverride(None, None, None, None)
    assert field_override.encoder is None
    assert field_override.decoder is None
    assert field_override.letter_case is None
    assert field_override.exclude is None

    # Testing a complete FieldOverride
    def encoder(x):
        return x
    def decoder(x):
        return x
    field_override = FieldOverride(encoder=encoder, decoder=decoder,
                                   letter_case=lambda x: x.upper(),
                                   exclude=lambda x: x == "b")
    assert field_override.encoder == encoder
    assert field_override.decoder == decoder

# Generated at 2022-06-23 16:45:28.279600
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a":1}'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a":1,"b":2}'
    assert _ExtendedEncoder().encode(datetime(2019, 1, 1)) == '1546300800.0'
    assert _ExtendedEncoder().encode(UUID('0ae6db65-6fbf-4fd2-afd3-0f7b6cae1d71')) == '"0ae6db65-6fbf-4fd2-afd3-0f7b6cae1d71"'

# Generated at 2022-06-23 16:45:34.275094
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # This should be true for every FieldOverride object
    assert all(f.__class__ == FieldOverride for f in (
                FieldOverride(),
                FieldOverride(decoder=lambda x: x, encoder=lambda x: x),
                FieldOverride(exclude=lambda x: x, encoder=lambda x: x)))


# Generated at 2022-06-23 16:45:44.349421
# Unit test for method default of class _ExtendedEncoder

# Generated at 2022-06-23 16:45:55.706197
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert '2018-10-20T18:20:12.13-05:00' == json.dumps(datetime(2018, 10, 20, 18, 20, 12, 130000, timezone(timedelta(hours=-5))), cls=_ExtendedEncoder, allow_nan=False)
    assert '[1, 2, 3]' == json.dumps([1, 2, 3], cls=_ExtendedEncoder, allow_nan=False)
    assert '{"a": 1, "b": 2}' == json.dumps({'a': 1, 'b': 2}, cls=_ExtendedEncoder, allow_nan=False)
    assert '2' == json.dumps(Decimal(2), cls=_ExtendedEncoder, allow_nan=False)
    assert '"2"' == json.dumps

# Generated at 2022-06-23 16:46:04.839924
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == "[1, 2, 3]"
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(Decimal('2.2')) == '"2.2"'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 12, 0)) == '1577836800.0'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1, 12, 0, tzinfo=timezone.utc)) == '1577852600.0'

# Generated at 2022-06-23 16:46:05.459352
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass



# Generated at 2022-06-23 16:46:17.374518
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default('foo') == 'foo'
    assert _ExtendedEncoder().default(b'foo') == 'foo'
    assert _ExtendedEncoder().default([1,2]) == [1,2]
    assert _ExtendedEncoder().default(('a',1)) == ['a',1]
    assert _ExtendedEncoder().default({'a':1}) == {'a':1}

# Generated at 2022-06-23 16:46:25.299356
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    def _assert(actual, expected):
        assert json.dumps(actual, cls=_ExtendedEncoder) == expected

    _assert(dict(a=1), '{"a": 1}')
    _assert(dict(a=1, b=2), '{"a": 1, "b": 2}')
    _assert({1, 2, 3}, '[1, 2, 3]')
    _assert([1, 2, 3], '[1, 2, 3]')
    _assert(UUID('dc7c1b46-182d-11eb-adc1-0242ac120002'), '"dc7c1b46-182d-11eb-adc1-0242ac120002"')

# Generated at 2022-06-23 16:46:36.690528
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', DeprecationWarning)
        assert encoder.encode(set()) == '[]'
    assert encoder.encode(frozenset()) == '[]'
    assert encoder.encode(1) == '1'
    assert encoder.encode(-1) == '-1'
    assert encoder.encode(1.1) == '1.1'
    assert encoder.encode(True) == 'true'
    assert encoder.encode(False) == 'false'
    assert encoder.encode(None) == 'null'
    assert encoder.encode('A') == '"A"'
    assert encoder.encode(b'A') == '"A"'

# Generated at 2022-06-23 16:46:46.637957
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        assert _ExtendedEncoder().default(b'blabla') == 'blabla'
        assert _ExtendedEncoder().default(decimal.Decimal('3.14')) == '3.14'
        assert _ExtendedEncoder().default(datetime(2018, 10, 2, 13, 31, 30, tzinfo=timezone.utc)) == 1538448690.0
        assert _ExtendedEncoder().default(uuid.UUID(hex='5ff6e569d87a11e9b0d5254002d2afc6')) == '5ff6e569-d87a-11e9-b0d5-254002d2afc6'

# Generated at 2022-06-23 16:46:53.438258
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    assert e.default(datetime(2020,1,1, tzinfo=timezone.utc)) == 1577836800
    assert e.default(datetime(2020,1,1, tzinfo=timezone(timedelta(hours=1)))) == 1577596000
    assert e.default(UUID('0917f742-b0ab-4c63-ae4e-bc1af07ad786')) == '0917f742-b0ab-4c63-ae4e-bc1af07ad786'
    assert e.default(Decimal(42)) == '42'
    assert e.default(1.2) == 1.2


# Generated at 2022-06-23 16:46:54.719683
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().encode(list(tuple('abc')))



# Generated at 2022-06-23 16:47:05.632701
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class Foo:
        pass

    assert FieldOverride() == FieldOverride()
    assert FieldOverride() != FieldOverride(exclude=bool)
    assert FieldOverride(exclude=bool) != FieldOverride()
    assert FieldOverride(decoder=Foo) != FieldOverride()
    assert FieldOverride() != FieldOverride(decoder=Foo)
    assert FieldOverride(exclude=bool, decoder=Foo) == FieldOverride(
        exclude=bool, decoder=Foo)
    assert FieldOverride(exclude=bool, decoder=Foo) != FieldOverride(
        exclude=bool, decoder=(lambda x: x))
    assert FieldOverride(exclude=bool, decoder=Foo) != FieldOverride(
        exclude=bool, decoder="test")
    assert FieldOverride(exclude=bool, decoder=Foo) != FieldOverride

# Generated at 2022-06-23 16:47:12.585576
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    o = FieldOverride()
    assert o.exclude is None
    assert o.letter_case is None
    assert o.encoder is None
    assert o.decoder is None

    o = FieldOverride(exclude=lambda x: True,
                      letter_case=lambda x: x.lower(),
                      encoder=lambda x: x,
                      decoder=lambda x: x)
    assert o.exclude(True)
    assert o.letter_case('EXAMPLE') == 'example'
    assert o.encoder(True)
    assert o.decoder(True)

# Generated at 2022-06-23 16:47:15.490104
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride('exclude_predicate')
    assert f.exclude == 'exclude_predicate'
    assert f.encoder is None
    assert f.decoder is None
    assert f.letter_case is None



# Generated at 2022-06-23 16:47:24.633312
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class C:
        def __eq__(self, other):
            return isinstance(other, C)

    non_callable_obj = C()
    codec = _ExtendedEncoder().default
    overrides = FieldOverride(letter_case=lambda x: x.upper(), exclude=True,
                              encoder=codec, decoder=codec)
    assert overrides.letter_case('hi') == 'HI'
    assert overrides.exclude('hi') == True
    assert overrides.encoder(non_callable_obj) == non_callable_obj
    assert overrides.decoder(non_callable_obj) == non_callable_obj



# Generated at 2022-06-23 16:47:32.628568
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    dut = _ExtendedEncoder()
    assert dut.default(Decimal('1.0')) == '1.0'
    assert dut.default(True) is True
    # noinspection PyProtectedMember
    assert dut.default(dut.encode) is not None
    assert dut.default(set([1, 2, 3])) == list([1, 2, 3])
    assert dut.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert dut.default(datetime.now(tz=timezone.utc)) is not None
    assert dut.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'




# Generated at 2022-06-23 16:47:42.001984
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.default(['a']) == ['a']
    assert extended_encoder.default({'a': 1}) == {'a': 1}
    assert extended_encoder.default({'a': datetime(2019, 1, 2, 3, 4, 5, tzinfo=timezone.utc)}) == {'a': 1546382645.0}
    assert extended_encoder.default({'a': UUID('c8bf9d2d-c572-4a38-8ad8-b5bd19efa1e6')}) == {'a': 'c8bf9d2d-c572-4a38-8ad8-b5bd19efa1e6'}

# 'test_' prefix is not necessary in Python

# Generated at 2022-06-23 16:47:50.410361
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert encoder.encode((1, 2, '3', [4, 5, (6, 7)])) == '[1, 2, "3", [4, 5, [6, 7]]]'
    assert encoder.encode([1, 2, '3', [4, 5, [6, 7]]]) == '[1, 2, "3", [4, 5, [6, 7]]]'
    assert encoder.encode((1, 2, '3', [4, 5, (6, 7)])) == '[1, 2, "3", [4, 5, [6, 7]]]'

# Generated at 2022-06-23 16:47:53.997456
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert (FieldOverride(
        exclude=lambda x: isinstance(x, str),
        letter_case=camelize,
        encoder=lambda x: int(x) + 1,
        decoder=lambda x: int(x) - 1))



# Generated at 2022-06-23 16:48:04.703149
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode(datetime(2019, 10, 2, 12, 11, 10, tzinfo=timezone.utc)) == '1570030970.0'
    assert _ExtendedEncoder().encode(UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8')) == '"6ba7b810-9dad-11d1-80b4-00c04fd430c8"'
    assert _ExtendedEncoder().encode(Decimal('5.5')) == '"5.5"'
    assert _ExtendedEncoder().encode(str('str')) == '"str"'



# Generated at 2022-06-23 16:48:13.050099
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default({"a": 1}) == {"a": 1}
    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default(datetime(2017, 1, 1)) == 1483228800.0
    assert _ExtendedEncoder().default(Decimal('1.23456789')) == "1.23456789"
    assert _ExtendedEncoder().default(UUID('123e4567-e89b-12d3-a456-426655440000')) == "123e4567-e89b-12d3-a456-426655440000"
    assert _ExtendedEncoder().default(Enum('a')) == 'a'


# Generated at 2022-06-23 16:48:16.846647
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

    @dataclass
    class TestEncoder:
        a: str

    a = TestEncoder("abc")
    assert encoder.default(a) == {"a": "abc"}



# Generated at 2022-06-23 16:48:27.002975
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default("") == ""
    assert _ExtendedEncoder().default("abc") == "abc"
    assert _ExtendedEncoder().default(5) == 5
    assert _ExtendedEncoder().default(True)
    assert not _ExtendedEncoder().default(False)
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(dict(a=1, b=2)) == dict(a=1, b=2)
    assert _ExtendedEncoder().default(set([1, 2, 3])) == [1, 2, 3]
    assert _ExtendedEncoder().default((1, 2, 3)) == [1, 2, 3]
   

# Generated at 2022-06-23 16:48:37.880604
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(
        exclude=1,
        letter_case=2,
        encoder=3,
        decoder=4) == (1, 2, 3, 4)
    for x in [
            FieldOverride(
                exclude=None,
                letter_case=None,
                encoder=None,
                decoder=None),
            FieldOverride(
                exclude='',
                letter_case=None,
                encoder=None,
                decoder=None),
            FieldOverride(
                exclude=False,
                letter_case=None,
                encoder=None,
                decoder=None),
            FieldOverride(
                exclude=True,
                letter_case=None,
                encoder=None,
                decoder=None),
    ]:
        assert x == (None, None, None, None)



# Generated at 2022-06-23 16:48:46.560549
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(2021, 1, 1)) == 1609372800
    assert _ExtendedEncoder().default(datetime(2021, 1, 1, tzinfo=timezone.utc)) == 1609372800
    assert _ExtendedEncoder().default(UUID('067e6162-3b6f-4ae2-a171-2470b63dff00')) == '067e6162-3b6f-4ae2-a171-2470b63dff00'
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'


# Generated at 2022-06-23 16:48:47.543537
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-23 16:48:53.950133
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode(tuple()) == '[]'
    assert _ExtendedEncoder().encode(bytes()) == '""'
    assert _ExtendedEncoder().encode(bytearray()) == '""'
    assert _ExtendedEncoder().encode(memoryview(b'')) == '""'
    assert _ExtendedEncoder().encode(datetime(2002, 12, 25,
                                              tzinfo=timezone.utc)) == '1040639600.0'

# Generated at 2022-06-23 16:48:58.357815
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    r = FieldOverride(exclude=None, letter_case=None, encoder=None, decoder=None)
    assert r.exclude == None
    assert r.letter_case == None
    assert r.encoder == None
    assert r.decoder == None



# Generated at 2022-06-23 16:49:10.021407
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test default constructor
    field_override = FieldOverride()
    assert field_override.exclude is None
    assert field_override.letter_case is None
    assert field_override.encoder is None
    assert field_override.decoder is None

    # test non-default constructor
    def exclude(x):
        if x == 'exclude':
            return True
        else:
            return False
    def letter_case(x):
        return x.upper()
    def encoder(x):
        return x + 1
    def decoder(x):
        return x - 1
    field_override = FieldOverride(exclude=exclude, letter_case=letter_case,
                                   encoder=encoder, decoder=decoder)
    assert field_override.exclude is exclude
    assert field

# Generated at 2022-06-23 16:49:18.487934
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = _ExtendedEncoder()
    assert o.default([1]) == [1]
    assert o.default([1]) == [1]
    assert o.default((1, 2)) == [1, 2]
    assert o.default([1]) == [1]
    assert o.default(set()) == []
    assert o.default(frozenset()) == []
    assert o.default({1: 2}) == {1: 2}
    assert o.default(datetime(2000, 1, 2, 3, 4, 5, 6, timezone.utc)) == 946688145.0
    assert o.default(datetime(2000, 1, 2, 3, 4, 5, 6)) == 946688145.0

# Generated at 2022-06-23 16:49:26.402493
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import timedelta
    from uuid import UUID

    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default(0.2) == 0.2
    assert _ExtendedEncoder().default(0) == 0
    assert _ExtendedEncoder().default({1: 2, 3: 4}) == {'1': 2, '3': 4}
    assert _ExtendedEncoder().default([1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-23 16:49:37.997994
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(10) == 10
    assert _ExtendedEncoder().default(10.5) == 10.5

# Generated at 2022-06-23 16:49:41.760257
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    date = datetime.now(timezone.utc)
    assert encoder.encode(date) == '{"__dataclass__": "datetime", "value": ' + str(date.timestamp()) + '}'



# Generated at 2022-06-23 16:49:43.326434
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(1) == '1'


# Generated at 2022-06-23 16:49:50.592428
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    exclude = FieldOverride()
    assert exclude.exclude is None
    assert exclude.letter_case is None
    assert exclude.encoder is None
    assert exclude.decoder is None
    assert exclude.mm_field is None

    exclude = FieldOverride(exclude=lambda x: x)
    assert exclude.exclude is not None
    assert exclude.letter_case is None
    assert exclude.encoder is None
    assert exclude.decoder is None
    assert exclude.mm_field is None

    exclude = FieldOverride(letter_case=lambda x: x)
    assert exclude.exclude is None
    assert exclude.letter_case is not None
    assert exclude.encoder is None
    assert exclude.decoder is None
    assert exclude.mm_field is None

    exclude = FieldOverride(encoder=lambda x: x)
    assert exclude

# Generated at 2022-06-23 16:50:00.425128
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    json_encoder = _ExtendedEncoder()
    assert json_encoder.default([]) == []
    assert json_encoder.default({}) == {}
    assert json_encoder.default([1, 2]) == [1, 2]
    assert json_encoder.default({1: 2}) == {1: 2}
    assert json_encoder.default(datetime(2020, 7, 22, 13, 24, 34)) == 1595501074
    dt = datetime(2020, 7, 22, 13, 24, 34, tzinfo=timezone.utc)
    assert json_encoder.default(dt) == 1595501074
    assert json_encoder.default(UUID('a05f3472-e85d-4535-9a66-f7c6b1a11b62'))

# Generated at 2022-06-23 16:50:03.968152
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    json_str = json.dumps({'foo': {'bar': 123}, 'zoo': [234, 345, 456]},
                          cls=_ExtendedEncoder)
    assert json_str == '{"foo": {"bar": 123}, "zoo": [234, 345, 456]}'



# Generated at 2022-06-23 16:50:05.488632
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(MISSING) == "null"



# Generated at 2022-06-23 16:50:15.731034
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode(tuple([1, 2, 3])) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(list([1, "2", 3.0])) == '[1, "2", 3.0]'
    assert _ExtendedEncoder().encode(frozenset({1, 2})) == '[1, 2]'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '{}'

# Generated at 2022-06-23 16:50:19.030851
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(dict(hello="world"), cls=_ExtendedEncoder) == \
        '{"hello": "world"}'



# Generated at 2022-06-23 16:50:22.328283
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():  # type: () -> None
    encoder = _ExtendedEncoder()
    o = [1, 2, 3]
    s = 'x'
    assert encoder.default(o) == o
    assert encoder.default(s) == s



# Generated at 2022-06-23 16:50:27.417434
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(exclude=None, letter_case=None, encoder=None, decoder=None)
    assert f.exclude is None
    assert f.letter_case is None
    assert f.encoder is None
    assert f.decoder is None



# Generated at 2022-06-23 16:50:37.997149
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # collection classes
    for klass in [list, dict, set, tuple]:
        assert _ExtendedEncoder().default(klass([3, 1, 4])) == [3, 1, 4]
    # datetime
    dt = datetime(2030, 12, 12, 12, 12, 12, 0, timezone.utc)
    assert _ExtendedEncoder().default(dt) == dt.timestamp()
    # UUID
    uuid = UUID('123e4567-e89b-12d3-a456-426655440000')
    assert _ExtendedEncoder().default(uuid) == '123e4567-e89b-12d3-a456-426655440000'
    # Enum
    class Foo(Enum):
        BAR = 1

# Generated at 2022-06-23 16:50:48.301407
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(40) == 40
    assert _ExtendedEncoder().default(40.0) == 40.0
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default('test') == 'test'
    assert _ExtendedEncoder().default(datetime(2019, 12, 31, 12)) == 1577836800.0  # type: ignore

# Generated at 2022-06-23 16:50:57.532541
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(0) == 0
    assert encoder.default(-0.) == -0.
    assert encoder.default(-0j) == -0j
    assert encoder.default(0j) == 0j
    assert encoder.default(5.1) == 5.1
    assert encoder.default('foobar') == 'foobar'
    assert encoder.default(dict(a=1, b=2)) == dict(a=1, b=2)
    assert encoder.default(set(['a', 'b'])) == ['a', 'b']

# Generated at 2022-06-23 16:51:03.091896
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(TypeError):
        _ = FieldOverride(exclude=lambda x: x > 2)
    with pytest.raises(TypeError):
        _ = FieldOverride(letter_case=lambda x: x > 2)
    with pytest.raises(TypeError):
        _ = FieldOverride(encoder=lambda x: x > 2)
    with pytest.raises(TypeError):
        _ = FieldOverride(decoder=lambda x: x > 2)

    _ = FieldOverride(letter_case=lambda x : x.lower())
    _ = FieldOverride(exclude=lambda x : False)
    _ = FieldOverride(encoder=lambda x: x+1)
    _ = FieldOverride(decoder=lambda x: x+1)



# Generated at 2022-06-23 16:51:14.846693
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default({1:2}) == {1:2}
    assert encoder.default(set()) == []
    assert encoder.default('Test') == 'Test'
    assert encoder.default(True) == True
    assert encoder.default(1.0) == 1.0
    assert encoder.default(2) == 2
    assert encoder.default(None) == None
    dt = datetime.now(timezone.utc)
    assert encoder.default(dt) == dt.timestamp()
    uuid_value = UUID('8be5caf7-0f70-44d2-8e24-44f7a0216f63')

# Generated at 2022-06-23 16:51:28.073554
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(list()) == []
    assert _ExtendedEncoder().default(dict()) == dict()
    assert _ExtendedEncoder().default(datetime(2019, 1, 1, 0, 0, 0, 0, tzinfo=timezone.utc)) == 1546300800
    assert _ExtendedEncoder().default(UUID('ef3eab2a-4a77-4b52-a4a6-c9e9e1ce629b')) == 'ef3eab2a-4a77-4b52-a4a6-c9e9e1ce629b'
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'
    assert _ExtendedEncoder().default(True) == True


# Generated at 2022-06-23 16:51:37.943475
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'
    assert _ExtendedEncoder().encode(1.23) == '1.23'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(datetime(1970, 1, 1, tzinfo=timezone.utc)) == '0'



# Generated at 2022-06-23 16:51:47.244855
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride() == FieldOverride(exclude=None,
                                            letter_case=None,
                                            encoder=None,
                                            decoder=None)
    assert FieldOverride(exclude=lambda v: True) == FieldOverride(
        exclude=lambda v: True,
        letter_case=None,
        encoder=None,
        decoder=None)
    assert FieldOverride(exclude=lambda v: True,
                         letter_case=lambda v: 'captain',
                         encoder=lambda v: v + 1,
                         decoder=lambda v: v - 1) == FieldOverride(
                             exclude=lambda v: True,
                             letter_case=lambda v: 'captain',
                             encoder=lambda v: v + 1,
                             decoder=lambda v: v - 1)

# Generated at 2022-06-23 16:52:01.251985
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(set()) == list(set())
    assert _ExtendedEncoder().default({1, 2, 3}) == list({1, 2, 3})
    assert _ExtendedEncoder().default({1:2, 3:4}) == {1: 2, 3: 4}
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc)) == 0.0
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc) + datetime.timedelta(days=1)) == 86400.0
    assert _ExtendedEncoder().default(UUID(int=1)) == '00000000-0000-0000-0000-000000000001'


# Notation for _new_from_dict()


# Generated at 2022-06-23 16:52:07.696687
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1,2,3]) == [1,2,3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime.utcnow().replace(tzinfo=timezone.utc))
    assert encoder.default(Decimal('1.23')) == '1.23'



# Generated at 2022-06-23 16:52:16.664425
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.default(
        [1, 2, 3]) == json.JSONEncoder().default([1, 2, 3])
    assert extended_encoder.default(
        set([1, 2, 3])) == json.JSONEncoder().default(set([1, 2, 3]))
    assert extended_encoder.default(
        {'1': 1, '2': 2, '3': 3}) == json.JSONEncoder().default({'1': 1, '2': 2, '3': 3})
    assert extended_encoder.default(
        frozenset([1, 2, 3])) == json.JSONEncoder().default(frozenset([1, 2, 3]))

    # Test for datetime

# Generated at 2022-06-23 16:52:28.752330
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

    @dataclass
    class A:
        a: int
        b: str

    assert encoder.default(A(1, "a")) == {'a': 1, 'b': 'a'}
    assert encoder.default(['a']) == ['a']
    assert encoder.default({"a": "a"}) == {"a": "a"}
    assert encoder.default(int(1)) == 1
    assert encoder.default(None) is None
    assert encoder.default(1.23) == 1.23
    assert encoder.default(True) == True

test__ExtendedEncoder()



# Generated at 2022-06-23 16:52:39.374741
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({1: 'a', 2: 'b', 3: 'c'}) == '{"1": "a", "2": "b", "3": "c"}'
    assert _ExtendedEncoder().encode(datetime(2018, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == '1514764800.0'

# Generated at 2022-06-23 16:52:49.955979
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc)) == 0.0
    assert _ExtendedEncoder().default(UUID('3fa85f64-5717-4562-b3fc-2c963f66afa6')) == '3fa85f64-5717-4562-b3fc-2c963f66afa6'
    assert _ExtendedEncoder().default(Decimal('0.1')) == '0.1'
    assert _ExtendedEncoder().default(Exception('error')) == 'error'


# Generated at 2022-06-23 16:53:00.939240
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(datetime(2020, 7, 3, 20, 24, 7, tzinfo=timezone.utc), cls=_ExtendedEncoder) == '"1593993847.0"'
    assert json.dumps(UUID('7df8a5d4-4f4b-4aa3-8c47-bd5f2a5d9307'), cls=_ExtendedEncoder) == '"7df8a5d4-4f4b-4aa3-8c47-bd5f2a5d9307"'
    assert json.dumps(Decimal('12.34'), cls=_ExtendedEncoder) == '"12.34"'


# Generated at 2022-06-23 16:53:03.270081
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    r = FieldOverride()
    _test_FieldOverride(r, None, None, None, None)



# Generated at 2022-06-23 16:53:09.256148
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    r = FieldOverride(lambda x: str(x), lambda x: int(x), lambda x: x)
    assert r.encoder(1) == "1"
    assert r.decoder("1") == 1
    assert r.letter_case(lambda x: x)("abcd") == "abcd"



# Generated at 2022-06-23 16:53:18.532723
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('{12345678-9abc-def0-1234-567890abcdef}')) == '12345678-9abc-def0-1234-567890abcdef'
    assert encoder.default(Enum('Enum', 'a b c')) == 'a'
    assert encoder.default(Decimal('123.456')) == '123.456'
    assert encoder.default(1) == 1
    assert encoder.default('<>') == '<>'
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder

# Generated at 2022-06-23 16:53:29.860499
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(Decimal('0.1')) == '0.1'
    assert encoder.default(set()) == []
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default((1, 2)) == [1, 2]
    assert encoder.default(datetime(1970, 1, 1, 0, 0, 0, 0, timezone.utc)) == 0
    assert encoder.default(UUID('12345678-1234-5678-1234-567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(1) == 1
    assert encoder.default('abc') == 'abc'

# Generated at 2022-06-23 16:53:38.840919
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoded = _ExtendedEncoder(indent=2).encode([1, 2, 3])
    assert encoded == '[\n  1,\n  2,\n  3\n]'
    encoded = _ExtendedEncoder().encode(datetime(2020, 1, 1, tzinfo=timezone.utc))
    assert encoded == '1577836800.0'
    encoded = _ExtendedEncoder().encode(UUID(int=42))
    assert encoded == '00000000-0000-0000-0000-00000000002a'
    encoded = _ExtendedEncoder().encode(Decimal(42))
    assert encoded == '"42"'



# Generated at 2022-06-23 16:53:48.153160
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': set([1])}) == '{"a": [1]}'
    assert _ExtendedEncoder().encode([{'a': set([1])}]) == '[{"a": [1]}]'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': {1: 1}}) == '{"a": {"1": 1}}'
    assert _ExtendedEncoder().encode({1: {'a': [1]}}) == '{"1": {"a": [1]}}'
    assert _ExtendedEncoder().encode((1, 2, 3)) == '[1, 2, 3]'

# Generated at 2022-06-23 16:53:50.814506
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert repr(FieldOverride(None, None, None)) == f"FieldOverride(exclude=None, letter_case=None, encoder=None)"

# Generated at 2022-06-23 16:54:00.673683
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    for o in [{}, [], '', 1, 1.0, True, None, object()]:
        assert enc.default(o) == o

    # datetime
    o = datetime(2000, 12, 31, 23, 59, 59, 999999, timezone.utc)
    assert enc.default(o) == o.timestamp()

    # UUID
    o = UUID('01234567-89ab-cdef-0123-456789abcdef')
    assert enc.default(o) == str(o)

    # Decimal
    o = Decimal('1.0')
    assert enc.default(o) == str(o)

    # Enum
    class E(Enum):
        X = 1
        Y = 2

# Generated at 2022-06-23 16:54:13.113927
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({3: "3", 1: "1", 2: "2"}) == '{"1": "1", "2": "2", "3": "3"}'
    assert _ExtendedEncoder().encode([3, 1, 2]) == '[3, 1, 2]'
    assert _ExtendedEncoder().encode(datetime.now()) == '0.0'
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Enum('Enum', 'a c b')('a')) == "'a'"
    assert _ExtendedEncoder().encode(Decimal('2.1'))

# Generated at 2022-06-23 16:54:20.234062
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(['abc', 1, 2.2, 3, ('a', 'b', None)]) == '["abc", 1, 2.2, 3, ["a", "b", null]]'
    assert _ExtendedEncoder().encode({'1': 'abc', '2': 2, 3: 2.2}) == '{"1": "abc", "2": 2, "3": 2.2}'
    assert (
        _ExtendedEncoder().encode(
            datetime(2018, 7, 24, 0, 0, 0, 0, timezone.utc)
        ) == '1532373200'
    )



# Generated at 2022-06-23 16:54:27.770778
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert isinstance(_ExtendedEncoder().encode([]), str)
    assert isinstance(_ExtendedEncoder().encode({}), str)
    assert isinstance(_ExtendedEncoder().encode(UUID('11111111-1111-1111-1111-111111111111')), str)
    assert isinstance(_ExtendedEncoder().encode(datetime.utcnow()), str)
    # TODO(Jozef): find any Enum class and use it here


# Generated at 2022-06-23 16:54:33.486320
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    o1 = FieldOverride(exclude=lambda x: True)
    o2 = FieldOverride(
        exclude=lambda x: True,
        letter_case='lower',
        encoder=lambda x: x,
        decoder=lambda x: x)
    print(o1)
    print(o2)



# Generated at 2022-06-23 16:54:42.434447
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().encode(_ExtendedEncoder()) == json.dumps(_ExtendedEncoder())  # type: ignore
    assert _ExtendedEncoder().encode(tuple()) == json.dumps(list())
    assert _ExtendedEncoder().encode(set()) == json.dumps(list())
    assert _ExtendedEncoder().encode(datetime.now()) == str(datetime.now().timestamp())
    assert _ExtendedEncoder().encode(UUID('12345678123456781234567812345678')) == '"12345678-1234-5678-1234-567812345678"'

# Generated at 2022-06-23 16:54:53.954624
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test instantiation
    fo = FieldOverride()

# Generated at 2022-06-23 16:55:06.366914
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Test for collections
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(frozenset()) == []
    assert _ExtendedEncoder().default(tuple()) == []
    assert _ExtendedEncoder().default((1,)) == [1]
    assert _ExtendedEncoder().default({'a': 1}) == {'a': 1}
    assert _ExtendedEncoder().default({'a', 'b'}) == ['a', 'b']
    # Test for other types
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == json.JSONEncoder().default(datetime.now(timezone.utc))
   