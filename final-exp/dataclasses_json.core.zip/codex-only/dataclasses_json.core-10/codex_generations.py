

# Generated at 2022-06-23 16:45:15.840723
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """Equivalence Class Test for f1 == f2 is f1.exclude == f2.exclude"""
    def pred(x):
        return x == 1

    f1 = FieldOverride(encoder=None, decoder=None, letter_case=None,
                       exclude=pred)
    f2 = FieldOverride(encoder=None, decoder=None, letter_case=None,
                       exclude=pred)
    assert f1 == f2
    assert f1 <= f2
    assert f1 >= f2
    assert not f1 < f2

    f3 = FieldOverride(encoder=None, decoder=None, letter_case=None)
    assert f1 != f3
    assert f3 > f1
    assert f3 >= f1
    assert f1 < f3
    assert f1 <= f3


# Generated at 2022-06-23 16:45:20.878671
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) is not None
    assert _ExtendedEncoder().encode([]) is not None
    assert _ExtendedEncoder().encode(()) is not None
    assert _ExtendedEncoder().encode(b'') is not None
    assert _ExtendedEncoder().encode('') is not None
    assert _ExtendedEncoder().encode(5) is not None
    assert _ExtendedEncoder().encode(5.5) is not None
    assert _ExtendedEncoder().encode(True) is not None
    assert _ExtendedEncoder().encode(None) is not None



# Generated at 2022-06-23 16:45:29.609835
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) == None
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(0) == 0
    assert encoder.default(0.0) == 0.0
    assert encoder.default("") == ""
    assert encoder.default([]) == []
    assert encoder.default({}) == {}

    assert encoder.default("test") == "test"
    assert encoder.default("test") == "test"
    assert encoder.default(["t", "e", "s", "t"]) == ["t", "e", "s", "t"]

# Generated at 2022-06-23 16:45:41.177397
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default('abc') == 'abc'
    assert _ExtendedEncoder().default(['abc', 'acb']) == ['abc', 'acb']
    assert _ExtendedEncoder().default(['abc', 'acb', ['a', 'b', 'c']]) == ['abc', 'acb', ['a', 'b', 'c']]
    assert _ExtendedEncoder().default({'abc': 123, 'acb': True}) == {'abc': 123, 'acb': True}
    assert _ExtendedEncoder().default(123) == 123
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(None) == None

# Generated at 2022-06-23 16:45:48.881288
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    def exclude(value):
        pass
    def letter_case(value):
        pass
    def encoder(value):
        pass
    def decoder(value):
        pass

    a = FieldOverride(exclude, letter_case, encoder, decoder)
    assert a.exclude == exclude
    assert a.letter_case == letter_case
    assert a.encoder == encoder
    assert a.decoder == decoder

# Generated at 2022-06-23 16:45:57.912474
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([]) == []
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()

# Generated at 2022-06-23 16:46:00.968804
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fieldOverride = FieldOverride()
    assert fieldOverride.encoder is None
    assert fieldOverride.exclude is None
    assert fieldOverride.letter_case is None
    assert fieldOverride.mm_field is None
    assert fieldOverride.mm_field_label is None



# Generated at 2022-06-23 16:46:08.069324
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # field_name = 'field_name'
    # exclude = lambda x: x > 0
    # letter_case = lambda x: x.lower()
    # encoder = lambda x: x + 100
    # decoder = lambda x: x - 100

    # field_override = FieldOverride(field_name, exclude, letter_case,
    #                                encoder, decoder)
    #
    # assert field_override.field_name == field_name
    # assert field_override.exclude(100) is False
    # assert field_override.letter_case(field_name) == field_name.lower()
    # assert field_override.encoder(1) == 101
    # assert field_override.decoder(101) == 1
    pass



# Generated at 2022-06-23 16:46:13.606830
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Encoding of a dataclass
    assert _ExtendedEncoder().encode(
        Point(x=3, y=5)) == '{"x": 3, "y": 5}'
    # Encoding of a dataclass with a datetime field
    assert _ExtendedEncoder().encode(
        PointTime(x=3, y=5, t=datetime.now())) == '{"x": 3, "y": 5, "t": ' + str(datetime.now().timestamp()) + '}'
    # Encoding of a dataclass with a string field
    assert _ExtendedEncoder().encode(
        PointString(x=3, y=5, s='a')) == '{"x": 3, "y": 5, "s": "a"}'



# Generated at 2022-06-23 16:46:24.461160
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import date, time
    from decimal import Decimal
    import json
    from uuid import UUID

# Generated at 2022-06-23 16:46:30.947903
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    for input in [
        [1, 2, 3], {'a': 1, 'b': 2}, # Collection
        datetime(2018, 12, 19, 15, 51, 44, 489000, tzinfo=timezone.utc),
        UUID('98d7ec14-2af9-4e8b-8eec-7d2e48b8f739'), # Json serializable python objects
        Decimal('1.23')
    ]:
        assert encoder.default(input) == input
        # test for str, for example
        assert type(encoder.default(input)) == type(input)



# Generated at 2022-06-23 16:46:37.101291
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    d: Json = _ExtendedEncoder().default(Decimal(1))
    assert isinstance(d, str)
    assert d == '1'
    d: Json = _ExtendedEncoder().default(1)
    assert isinstance(d, int)
    assert d == 1
    try:
        _ExtendedEncoder().default(datetime.utcnow())
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-23 16:46:47.015530
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import json
    import time
    import datetime
    import uuid
    import decimal

    def assert_json_equal(json_str, json_value):
        assert json_str == json.dumps(
            json_value, sort_keys=True, separators=(',', ':'))


# Generated at 2022-06-23 16:46:54.448821
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(MappingProxyType(dict())) == dict()
    assert _ExtendedEncoder().default(frozenset()) == []
    assert _ExtendedEncoder().default(frozenset({1, 2, 3})) == [1, 2, 3]
    assert _ExtendedEncoder().default(OrderedDict((('a', 1), ('b', 2)))) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default(datetime(2015, 8, 12, 12, 12, 12, 0, timezone.utc)) == 1439382332
    assert _ExtendedEncoder().default(datetime(2015, 8, 12, 12, 12, 12, 0, timezone(timedelta(hours=8)))) == 1439382332
    assert _Extended

# Generated at 2022-06-23 16:47:05.380960
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default([1]) == [1]
    assert _ExtendedEncoder().default((1,)) == [1]
    assert _ExtendedEncoder().default({1: 10}) == {1: 10}
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(frozenset()) == []
    assert _ExtendedEncoder().default(datetime(2019, 11, 27)) > 1574802000
    assert _ExtendedEncoder().default(datetime(2019, 11, 27, tzinfo=timezone.utc)) > 1574802000
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'

# Generated at 2022-06-23 16:47:08.823075
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    ff = FieldOverride(letter_case=lambda x: x.lower(),
                       exclude=lambda x: x == "test",
                       encoder=lambda x: x,
                       decoder=lambda x: x)

    assert ff.letter_case is not None
    assert ff.exclude is not None
    assert ff.encoder is not None
    assert ff.decoder is not None



# Generated at 2022-06-23 16:47:15.615533
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default(datetime.now(tz=timezone.utc)) == datetime.now(tz=timezone.utc).timestamp()
    assert _ExtendedEncoder().default(Enum) == Enum.value
    assert _ExtendedEncoder().default(UUID) == str(UUID)
    assert _ExtendedEncoder().default(Decimal) == str(Decimal)
    assert _ExtendedEncoder().default(None) == None



# Generated at 2022-06-23 16:47:24.118346
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(range(10)) == '[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode({'a': 'a', 'b': 'b', 'c': 'c'}) == '{"a": "a", "b": "b", "c": "c"}'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '[%d, 0]' % datetime.now(timezone.utc).timestamp()
    assert _

# Generated at 2022-06-23 16:47:27.384635
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    expected = {'dict': {}, 'list': [], 'datetime': 1588291200,
                'UUID': '00000000-0000-0000-0000-000000000000',
                'Enum': 'foo', 'Decimal': '1.234', 'plain old string': 'foo'}
    actual = _ExtendedEncoder().default(expected)
    assert actual == expected



# Generated at 2022-06-23 16:47:36.932757
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda x: x
    decoder = lambda x: x
    exclude = lambda x: x
    letter_case = lambda x: x

    fo = FieldOverride(exclude, encoder, decoder, letter_case)
    assert fo.exclude is exclude
    assert fo.encoder is encoder
    assert fo.decoder is decoder
    assert fo.letter_case is letter_case

    fo = FieldOverride()
    assert fo.exclude is None
    assert fo.encoder is None
    assert fo.decoder is None
    assert fo.letter_case is None

# Unit tests for _encode_overrides

# Generated at 2022-06-23 16:47:41.437548
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(False, None, None, None)
    assert field_override
    assert not field_override.exclude
    assert not field_override.letter_case
    assert not field_override.encoder
    assert not field_override.decoder



# Generated at 2022-06-23 16:47:49.523216
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(UUID('00000000-0000-0000-0000-000000000000')) == '"00000000-0000-0000-0000-000000000000"'
    assert _ExtendedEncoder().encode(datetime(1970, 1, 1, 0, 0, 1, tzinfo=timezone.utc)) == '1.0'
    assert _ExtendedEncoder().encode(list((1, 2, 3))) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(Decimal('1.0')) == '"1.0"'


# Generated at 2022-06-23 16:47:57.735068
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(2018, 2, 13, 2, 37, 50, 766638, tzinfo=timezone.utc)) == 1518487470.076664
    assert _ExtendedEncoder().default(UUID('a7863c03-d70a-4f39-afeb-1c8a8e5904cf')) == 'a7863c03-d70a-4f39-afeb-1c8a8e5904cf'
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default('string') == 'string'
    assert _ExtendedEnc

# Generated at 2022-06-23 16:48:04.751815
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default(datetime.now())
    assert encoder.default(Enum)
    assert encoder.default(UUID('f16141d1-2aa2-4610-8643-c3e11d6695c7'))
    assert encoder.default(bool)
    assert encoder.default(Decimal('1.0'))


# Generated at 2022-06-23 16:48:13.300954
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    import pytest
    # Test that construction and default values work as expected
    with pytest.raises(TypeError):
        FieldOverride(None, None, None, None)

    with pytest.raises(TypeError):
        FieldOverride(letter_case='hey', exclude=None, encoder=None,
                      decoder=None)

    with pytest.raises(TypeError):
        FieldOverride(letter_case=None, exclude='hey', encoder=None,
                      decoder=None)

    with pytest.raises(TypeError):
        FieldOverride(letter_case=None, exclude=None, encoder='hey',
                      decoder=None)

    with pytest.raises(TypeError):
        FieldOverride(letter_case=None, exclude=None, encoder=None,
                      decoder='hey')

   

# Generated at 2022-06-23 16:48:24.433792
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(TypeError):
        # noinspection PyArgumentList
        FieldOverride()
    with pytest.raises(TypeError):
        # noinspection PyArgumentList
        FieldOverride(exclude=None)
    with pytest.raises(TypeError):
        # noinspection PyArgumentList
        FieldOverride(letter_case=None)
    with pytest.raises(TypeError):
        # noinspection PyArgumentList
        FieldOverride(encoder=None)
    with pytest.raises(TypeError):
        # noinspection PyArgumentList
        FieldOverride(decoder=None)
    with pytest.raises(TypeError):
        # noinspection PyArgumentList
        FieldOverride(exclude=None, letter_case=None)

# Generated at 2022-06-23 16:48:30.649329
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.loads(json.dumps(
        {'x': datetime.fromtimestamp(0, tz=timezone.utc)}, cls=_ExtendedEncoder)
    )
    json.loads(json.dumps(
        {'x': UUID('7d2e1bab-7a40-484e-8c3f-3d69b72664b1')}, cls=_ExtendedEncoder)
    )


# Generated at 2022-06-23 16:48:38.424352
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(datetime(2020, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == 1577836800.0

Field = namedtuple('Field', confs)



# Generated at 2022-06-23 16:48:48.155394
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    dt = datetime.now()
    uuid = UUID('00000000-0000-0000-0000-000000000000')
    class X:
        pass
    class MY_Enum(Enum):
        ONE = 1
        TWO = 2
    my_enum = MY_Enum.TWO
    d = Decimal('1.1')
    x = X()
    s = set()
    l = [x, s]
    v = (1, 2)
    t = (1, (2, 3))
    n = None
    e = _ExtendedEncoder()
    assert e.default(s) == []
    assert e.default(l) == [x, []]
    assert e.default(v) == list(v)
    assert e.default(t) == list(t)

# Generated at 2022-06-23 16:48:53.971841
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(Mapping.__args__) == Mapping.__args__
    assert _ExtendedEncoder().default(Collection.__args__) == Collection.__args__
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().default(Enum('Enum', 'A')) == 'A'
    assert _ExtendedEncoder().default(Decimal('1.234')) == '1.234'


# Generated at 2022-06-23 16:48:55.004546
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ = _ExtendedEncoder()


# Generated at 2022-06-23 16:49:04.162070
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    globals()  # Placeholder to prevent false positives in PyCharm.

    o = {
        'collection': [1, 2],
        'mapping': {'A': 1, 'B': 2},
        'string': 'string',
        'int': 1,
        'float': 1.1,
        'boolean': True,
        'none': None,
        'datetime': datetime.now(timezone.utc),
        'decimal': Decimal(1) / Decimal(2),
        'enum': cfg.datetime_format,
        'uuid': UUID('c9bf9e57-1685-4c89-bafb-ff5af830be8a')
    }

# Generated at 2022-06-23 16:49:05.775370
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default(1)

# Generated at 2022-06-23 16:49:07.735065
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    expected = json.JSONEncoder
    assert encoder == expected


# Generated at 2022-06-23 16:49:16.811453
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({1: 'a'}) == {1: 'a'}
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('e24d1b96-a725-4a5f-b5c2-c4eff16ddc4e')) == 'e24d1b96-a725-4a5f-b5c2-c4eff16ddc4e'
    from dataclasses_json.tests.test_examples import Gender
    assert _ExtendedEncoder().default(Gender.OTHER) == Gender.OTHER.value

# Generated at 2022-06-23 16:49:22.037423
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    from dataclasses_json.config import Config
    cfg= Config.from_config(None, True, False)
    fo=FieldOverride("test_name", "test_exclude", "test_encoder", "test_decoder", "test_letter_case", "test_mm_field")
    assert fo.name == "test_name"
    assert fo.exclude == "test_exclude"
    assert fo.encoder == "test_encoder"
    assert fo.decoder == "test_decoder"
    assert fo.letter_case == "test_letter_case"
    assert fo.mm_field == "test_mm_field"

# Generated at 2022-06-23 16:49:30.335594
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():

    o = (1, 2, 3)
    assert _ExtendedEncoder().default(o) == list(o)

    o = {'name': 'jack'}
    assert _ExtendedEncoder().default(o) == o

    o = datetime(year=2016, month=12, day=24, tzinfo=timezone.utc)
    assert _ExtendedEncoder().default(o) == o.timestamp()

    o = UUID('{12345678-1234-5678-1234-567812345678}')
    assert _ExtendedEncoder().default(o) == str(o)

    class MyEnum(Enum):
        value = 'value'
    o = MyEnum.value
    assert _ExtendedEncoder().default(o) == 'value'


# Generated at 2022-06-23 16:49:37.204958
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    expected_1 = FieldOverride(True, True, None, None, None)
    res_1 = FieldOverride(exclude=True, exclude_unset=True)
    assert expected_1 == res_1

    expected_2 = FieldOverride(True, True, None, None, None, None)
    res_2 = FieldOverride(
        exclude=True, exclude_unset=True, encode_as_str=None)
    assert expected_2 == res_2


# Generated at 2022-06-23 16:49:46.378527
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test default
    assert FieldOverride() == FieldOverride(exclude=None, encoder=None, decoder=None, letter_case=None)
    # Test exclude
    exclude = lambda x: x == 3
    assert FieldOverride(exclude=exclude) == FieldOverride(exclude=exclude)
    # Test encoder
    encoder = lambda x: x + 3
    assert FieldOverride(encoder=encoder) == FieldOverride(encoder=encoder)
    # Test decoder
    decoder = lambda x: x + 3
    assert FieldOverride(decoder=decoder) == FieldOverride(decoder=decoder)
    # Test letter_case
    letter_case = lambda x: x.upper()
    assert FieldOverride(letter_case=letter_case) == FieldOverride(letter_case=letter_case)

#

# Generated at 2022-06-23 16:49:58.107496
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Unit test for constructor of class FieldOverride
    """
    field_override = FieldOverride(exclude=lambda x: x == x,
                                   letter_case=lambda x: x.upper(),
                                   encoder=lambda x: x,
                                   decoder=lambda x: x,
                                   mm_field=lambda x: x)

    assert field_override.exclude(field_override)
    assert field_override.letter_case(field_override)
    assert field_override.encoder(field_override)
    assert field_override.decoder(field_override)
    assert field_override.mm_field(field_override)
# End of unit test for constructor of class FieldOverride



# Generated at 2022-06-23 16:50:08.275045
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    collection = [1, 2, 3, 4]
    mapping = {'k': 1, 'u': 2}
    o = _ExtendedEncoder()
    assert o.default(collection) == [1, 2, 3, 4]
    assert o.default(mapping) == {'k': 1, 'u': 2}
    assert o.default(u"asdfasdf") == "asdfasdf"
    assert o.default(5) == 5.0
    assert o.default(True) is True
    assert o.default(Enum('SomeEnum', 'value1 value2')('value1')) == 'value1'

# Generated at 2022-06-23 16:50:19.192641
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(2019, 1, 1, tzinfo=timezone.utc)) == 1546300800.0
    assert _ExtendedEncoder().default(datetime(2019, 1, 1)) == 1546300800.0
    assert _ExtendedEncoder().default(UUID('2b44f0c6-2e6e-449b-bfd0-089045ff80b6')) == '2b44f0c6-2e6e-449b-bfd0-089045ff80b6'
    assert _ExtendedEncoder().default(['a', 1, True, None]) == ['a', 1, True, None]
    assert _ExtendedEncoder().default({'key': 'value'}) == {'key': 'value'}
    # assert _Ext

# Generated at 2022-06-23 16:50:27.021639
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(b'123') == '123'
    assert _ExtendedEncoder().default(3) == 3
    assert _ExtendedEncoder().default(3.0) == 3.0
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(3+3j) == '[3.0,3.0]'
    assert _ExtendedEncoder().default(set([1, 2, 3])) == [1, 2, 3]
    assert _ExtendedEncoder().default(frozenset([1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-23 16:50:37.997046
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.loads(json.dumps([1, 2, 3, 4], cls=_ExtendedEncoder)) == [1, 2, 3, 4]
    assert json.loads(json.dumps(1, cls=_ExtendedEncoder)) == 1
    assert json.loads(json.dumps(1.0, cls=_ExtendedEncoder)) == 1.0
    assert json.loads(json.dumps('s', cls=_ExtendedEncoder)) == 's'
    assert json.loads(json.dumps(True, cls=_ExtendedEncoder)) == True
    assert json.loads(json.dumps(False, cls=_ExtendedEncoder)) == False
    assert json.loads(json.dumps(None, cls=_ExtendedEncoder)) == None

# Generated at 2022-06-23 16:50:45.854636
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().encode(dict(a=1)) == '{"a": 1}'
    assert _ExtendedEncoder().encode(set(range(3))) == '[0, 1, 2]'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '{}'
    assert _ExtendedEncoder().encode(UUID("00010203-0405-0607-0809-0a0b0c0d0e0f")) == '"00010203-0405-0607-0809-0a0b0c0d0e0f"'
    # assert _ExtendedEncoder().encode(Decimal("0.1")) == '"0.1"'



# Generated at 2022-06-23 16:50:53.153985
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(
        exclude=None,
        encoder=None,
        decoder=None,
        letter_case=None,
    ) == FieldOverride(
        exclude=None,
        encoder=None,
        decoder=None,
        letter_case=None,
    )
    assert FieldOverride(
        exclude=None,
        encoder=None,
        decoder=None,
        letter_case=None,
    ) == FieldOverride()


# Generated at 2022-06-23 16:51:04.243001
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    @dataclass
    class TestCls:
        my_field1: str = field(metadata=
        {'dataclasses_json': {
            'encode': lambda x: x[::-1],
            'exclude': lambda x: x == '',
            'letter_case': 'kebab_case'
        }})
        my_field2: str = field(metadata=
        {'dataclasses_json': {
            'encode': lambda x: x[::-1]
        }})

    @dataclass
    class _TestClsWithNoFields:
        pass

    @dataclass
    class _TestClsWithFieldWithNoMetadata:
        my_field: str


# Generated at 2022-06-23 16:51:14.333528
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([1,2,3]) == [1,2,3]
    assert _ExtendedEncoder().default({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert _ExtendedEncoder().default(datetime(2019, 7, 24, 18, 35, 7, tzinfo=timezone.utc)) == 1563978527.0
    assert _ExtendedEncoder().default(UUID(int=11)) == "00000000-0000-0000-0000-00000000000b"
    assert _ExtendedEncoder().default(Decimal('3.4')) == "3.4"
    assert _ExtendedEncoder().default(None) == None


# Generated at 2022-06-23 16:51:26.565015
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now()) is not None
    assert _ExtendedEncoder().default(UUID('0e8ce33c-3aeb-4f7c-8d8e-7a19f22dbbb1')) == '0e8ce33c-3aeb-4f7c-8d8e-7a19f22dbbb1'
    assert _ExtendedEncoder().default(Decimal("1.001")) == "1.001"
    assert _ExtendedEncoder().default(Decimal("-1.001")) == "-1.001"
    assert _ExtendedEncoder().default(False) == False


# Generated at 2022-06-23 16:51:31.205430
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    letter_case = "lower"
    exclude = lambda x: True
    encoder = lambda x: x
    decoder = lambda x: x
    target_field = "id"
    field_override = FieldOverride(letter_case,
                                   exclude,
                                   encoder, decoder,
                                   target_field)
    assert field_override.letter_case == "lower"
    assert field_override.exclude(1) == True
    assert field_override.encoder(1) == 1
    assert field_override.decoder(1) == 1
    assert field_override.mm_field == "id"



# Generated at 2022-06-23 16:51:40.982119
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o: Any
    o = {1: 2, 3: 4}
    assert isinstance(_ExtendedEncoder().default(o), dict)
    assert _ExtendedEncoder().default(o) == o
    o = (1, 2, 3, 4)
    assert isinstance(_ExtendedEncoder().default(o), list)
    assert _ExtendedEncoder().default(o) == list(o)
    o = (1, 2, 3, 4)
    assert isinstance(_ExtendedEncoder().default(o), list)
    assert _ExtendedEncoder().default(o) == list(o)
    o = datetime.now(timezone.utc)
    assert isinstance(_ExtendedEncoder().default(o), float)
    assert _ExtendedEncoder().default(o) == o.timestamp()
    o

# Generated at 2022-06-23 16:51:51.780404
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda x: f"encoded_value {x}"
    decoder = lambda x: f"decoded_value {x}"
    exclude = lambda x: x % 2 == 0
    letter_case = lambda x: x.lower()

    fo = FieldOverride(encoder, decoder, exclude, letter_case)
    assert fo is not None
    assert encoder == fo.encoder
    assert decoder == fo.decoder
    assert exclude == fo.exclude
    assert letter_case == fo.letter_case
    assert fo.to_dict() == {
        "encoder": encoder,
        "decoder": decoder,
        "exclude": exclude,
        "letter_case": letter_case
    }



# Generated at 2022-06-23 16:52:01.489695
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f1 = FieldOverride(exclude=lambda x: True, letter_case=lambda x: x.upper(),
                       encoder=lambda x: x, decoder=lambda x: x)
    assert f1.exclude(None) == True
    assert f1.letter_case('a') == 'A'
    assert f1.encoder(None) is None
    assert f1.decoder(None) is None

    f2 = FieldOverride()
    assert f2.exclude is None
    assert f2.letter_case is None
    assert f2.encoder is None
    assert f2.decoder is None


# Generated at 2022-06-23 16:52:09.687324
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    ncr = NonCallable('')
    assert ncr() == NonCallable('')

    assert (FieldOverride(exclude=lambda x: x is None)
            == FieldOverride(exclude=NonCallable(lambda x: x is None)))
    assert (FieldOverride(letter_case=underscore)
            == FieldOverride(letter_case=NonCallable(underscore)))
    assert (FieldOverride(encoder=lambda x: x)
            == FieldOverride(encoder=NonCallable(lambda x: x)))
    assert (FieldOverride(decoder=lambda x: x)
            == FieldOverride(decoder=NonCallable(lambda x: x)))
    assert (FieldOverride(mm_field=lambda x: x)
            == FieldOverride(mm_field=NonCallable(lambda x: x)))


# Generated at 2022-06-23 16:52:16.160839
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride() == FieldOverride(None, None, None)
    assert FieldOverride(None, lambda x: x, None) == FieldOverride(None,
                                                                   lambda x: x,
                                                                   None)
    assert FieldOverride(None, lambda x: x, None) != FieldOverride(None,
                                                                   lambda x: x,
                                                                   lambda x: x)



# Generated at 2022-06-23 16:52:27.272823
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride()
    assert f.exclude is None
    assert f.letter_case is None
    assert f.encoder is None
    assert f.decoder is None

    # Test that a TypeError is raised in case of wrong type for exclude and
    # letter_case.
    try:
        f = FieldOverride(exclude=10, letter_case=10, encoder=10, decoder=10)
    except TypeError:
        pass
    else:
        raise Exception("Expected TypeError exception was not raised")


# Unit tests for validate_config_cls()

# Generated at 2022-06-23 16:52:37.475466
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert '42' == _ExtendedEncoder().default(42)
    assert '42' == _ExtendedEncoder().default(Decimal('42.0'))
    assert '4.2' == _ExtendedEncoder().default(4.2)
    assert '"lorem" == "ipsum"' == _ExtendedEncoder().default('lorem == ipsum')
    # noinspection PyUnresolvedReferences
    assert 'true' == _ExtendedEncoder().default(True)
    # noinspection PyUnresolvedReferences
    assert 'false' == _ExtendedEncoder().default(False)
    assert 'null' == _ExtendedEncoder().default(None)
    now = datetime.now(timezone.utc)
    assert str(now.timestamp()) == _ExtendedEncoder().default(now)


# Generated at 2022-06-23 16:52:45.196973
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f_ovr = FieldOverride(exclude=True,
                          encoder=int,
                          decoder=int,
                          letter_case=None)
    assert f_ovr.exclude == True
    assert f_ovr.encoder == int
    assert f_ovr.decoder == int
    assert f_ovr.letter_case == None

# Generated at 2022-06-23 16:52:53.101194
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    override = FieldOverride('exclude', 'letter_case', 'encoder', 'decoder')
    # If a value is missing, it will be assigned to the default value
    assert override.exclude is None
    assert override.letter_case is None
    assert override.encoder is None
    assert override.decoder is None
    override = FieldOverride('exclude', 'letter_case', 'encoder', 'decoder',
                             extra=True)
    # If extra keyword is specified, a TypeError will be raised
    with pytest.raises(TypeError):
        assert override.exclude is None
        assert override.letter_case is None
        assert override.encoder is None
        assert override.decoder is None
        assert override.extra is True


# Generated at 2022-06-23 16:52:58.457610
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ex = _ExtendedEncoder(sort_keys=True)
    x = ex.default(Decimal('1200.00'))
    assert x == '1200.00'
    x = ex.default(EnumClass.A)
    assert x == EnumClass.A.value
    x = ex.default(datetime.now())
    assert x == x
    x = ex.default(UUID('01234567-89ab-cdef-0123-456789abcdef'))
    assert x == '01234567-89ab-cdef-0123-456789abcdef'



# Generated at 2022-06-23 16:53:04.480178
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default([1, 2, 3]) != ['1', '2', '3']
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default('test') == 'test'
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(Decimal('0.0')) == '0'
    assert _ExtendedEncoder().default(Decimal('0.0')) != 0
    assert _ExtendedEncoder().default(datetime.now(timezone.utc))

# Generated at 2022-06-23 16:53:15.886738
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import datetime
    from uuid import UUID
    from dataclasses_json.api import load
    from dataclasses_json.tests.test_decoder import Point

    e = _ExtendedEncoder()
    # Test 1: _ExtendedEncoder.default
    e.default(Point(2,3))
    """
    {
      "Point": {
        "x": 2,
        "y": 3,
      }
    }
    """

    # Test 2: _ExtendedEncoder.default
    e.default(datetime.now())
    # Float value
    """
    1578173278.252463
    """

    # Test 3: _ExtendedEncoder.default
    e.default(UUID(int=1))
    # String value

# Generated at 2022-06-23 16:53:25.573390
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()

# Generated at 2022-06-23 16:53:32.693271
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    # Use default method to encode the given obj
    assert e.default(byte_converted_string) == byte_converted_string
    # Check for JSONEncoder methods
    for meth in [
            'encode',
            'iterencode',
            '__init__',
            '__repr__',
            '_make_iterencode',
            ]: assert meth in dir(e)
    # Check for function encode of module json
    assert 'encode' in dir(json)
    # Check for function dumps of module json
    assert 'dumps' in dir(json)
    # Check for function loads of module json
    assert 'loads' in dir(json)
    # Check for function json with argument string
    assert 'json' in globals()

# Generated at 2022-06-23 16:53:36.127208
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field = FieldOverride(exclude=lambda x: True)
    assert field.exclude is not None
    assert field.letter_case is None
    assert field.encoder is None
    assert field.decoder is None

# Generated at 2022-06-23 16:53:37.297355
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-23 16:53:47.257803
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.default(None) is None
    assert extended_encoder.default(True) is True
    assert extended_encoder.default(False) is False
    assert extended_encoder.default(123) == 123
    assert extended_encoder.default(123.4) == 123.4
    assert extended_encoder.default(Decimal('123.4')) == '123.4'
    assert extended_encoder.default('abc') == 'abc'
    assert extended_encoder.default([1, 2, 3]) == [1, 2, 3]
    assert extended_encoder.default({'x': 1}) == {'x': 1}
    assert extended_encoder.default(datetime.utcnow()) == datetime.utcnow().timestamp

# Generated at 2022-06-23 16:53:58.099589
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import date, time, timedelta
    from decimal import Decimal
    from typing import NamedTuple, Optional
    from uuid import UUID

    class _ExtendedEncoder_test(NamedTuple):
        a: UUID
        b: datetime
        c: date
        d: time
        e: timedelta
        f: Decimal
        g: Optional[UUID] = None

    e = _ExtendedEncoder()

# Generated at 2022-06-23 16:54:05.457902
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default('hello') == 'hello'
    assert _ExtendedEncoder().default(123) == 123
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'hello': 'world'}) == {'hello': 'world'}
    assert _ExtendedEncoder().default(datetime.utcnow(tz=timezone.utc)) == \
        _ExtendedEncoder().default(datetime.utcnow(tz=timezone.utc).timestamp())

# Generated at 2022-06-23 16:54:16.612774
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default('foo') == 'foo'
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default({'a': 1}) == {'a': 1}
    assert _ExtendedEncoder().default(datetime(2018, 10, 20, 9, 24, tzinfo=timezone.utc)) == 1540025440.0

# Generated at 2022-06-23 16:54:27.861652
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(serializer=bool,
                         letter_case=bytes,
                         exclude=lambda x: not bool(x),
                         is_optional=False).exclude(1)
    assert not FieldOverride(serializer=bool,
                             letter_case=bytes,
                             exclude=lambda x: not bool(x),
                             is_optional=False).exclude(0)
    assert not FieldOverride(serializer=bool,
                             letter_case=bytes,
                             exclude=lambda x: not bool(x),
                             is_optional=False).is_optional
    assert FieldOverride(serializer=bool,
                         letter_case=bytes,
                         exclude=lambda x: not bool(x),
                         is_optional=True).is_optional

# Generated at 2022-06-23 16:54:34.705265
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = dict()
    encoder = json.JSONEncoder()
    encoder.default(o)
    encoder = _ExtendedEncoder()
    encoder.default(o)
    # Would raise TypeError if method default of class _ExtendedEncoder is broken
    __ = json.dumps(o, cls=_ExtendedEncoder)
    return True

###
#
# Encoder
#
###



# Generated at 2022-06-23 16:54:36.059132
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-23 16:54:43.531461
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(0) == 0
    assert _ExtendedEncoder().default(0.0) == 0.0
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(2.2) == 2.2
    assert _ExtendedEncoder().default(float('nan')) == float('nan')
    assert _ExtendedEncoder().default(float('inf')) == float('inf')
    assert _ExtendedEncoder().default(-float('inf')) == -float('inf')
    assert _ExtendedEncoder().default(2**30) == 2**30
    assert _

# Generated at 2022-06-23 16:54:52.820364
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1}) == b'{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2]) == b'[1, 2]'
    assert _ExtendedEncoder().encode("abc") == b'"abc"'
    assert _ExtendedEncoder().encode(1) == b'1'
    assert _ExtendedEncoder().encode(3.14) == b'3.14'
    assert _ExtendedEncoder().encode(True) == b'true'
    assert _ExtendedEncoder().encode(None) == b'null'



# Generated at 2022-06-23 16:55:04.955520
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, 0, 0, 1, tzinfo=timezone.utc)) == 1
    assert _ExtendedEncoder().default(datetime(1970, 1, 1)) == 0
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, 0, 0, 2)) == 2
    # assert _ExtendedEncoder().default(datetime.utcnow()) > 0
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().default(Decimal('0.0')) == '0.0'

