

# Generated at 2022-06-23 16:45:09.948549
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(frozenset()) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default(datetime.utcnow()) == datetime.utcnow().timestamp()
    assert _ExtendedEncoder().default(UUID('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11')) == 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11'
    assert _ExtendedEncoder().default(Decimal('1')) == '1'
    assert _ExtendedEncoder().default(Exception()) == {}
    assert _ExtendedEncoder().default(Exception) == 'Exception'

# Generated at 2022-06-23 16:45:16.014790
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(Decimal(12.34)) == '12.34'
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().default(Decimal('nan')) == 'nan'
    assert _ExtendedEncoder().default(Decimal('inf')) == 'inf'
    assert _ExtendedEncoder().default(Decimal('-inf')) == '-inf'



# Generated at 2022-06-23 16:45:22.539329
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

    o = {'a': 1, 'b': 2}
    assert encoder.default(o) == json.loads(json.dumps(o))

    o = [1, 2, 3]
    assert encoder.default(o) == json.loads(json.dumps(o))

    o = datetime.now()
    assert encoder.default(o) == o.timestamp()

    o = Decimal(1)
    assert encoder.default(o) == '1'



# Generated at 2022-06-23 16:45:30.463145
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': datetime.now(timezone.utc)})
    assert _ExtendedEncoder().encode({'a': UUID('5b0c7510-1c62-4984-8e0a-3fab76f473ce')})
    assert _ExtendedEncoder().encode({'a': cfg.encode_dataclasses})
    assert _ExtendedEncoder().encode({'a': cfg.ignore_wrappers})
    assert _ExtendedEncoder().encode({'a': cfg.skip_defaults})
    encoder = _ExtendedEncoder()
    assert encoder.encode({'a': Decimal(2)}) == '{"a": "2"}'
    # By default the encoder will not encode datetime, UUID, and En

# Generated at 2022-06-23 16:45:33.138539
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class Dummy: pass
    f = Dummy()
    assert FieldOverride(f, f, f, f) is not None

# Generated at 2022-06-23 16:45:43.440425
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Define a function to check a FieldOverride instance
    def check(fo, field_name, encoder, decoder, exclude, letter_case):
        assert(fo.field_name == field_name)
        assert(fo.encoder == encoder)
        assert(fo.decoder == decoder)
        assert(fo.exclude == exclude)
        assert(fo.letter_case == letter_case)

    # Test the constructor of FieldOverride with a name
    fo = FieldOverride('field_1')
    check(fo, 'field_1', None, None, None, None)

    # Test the constructor of FieldOverride with a name and encoder
    encoder = lambda x: x
    fo = FieldOverride('field_1', encoder=encoder)

# Generated at 2022-06-23 16:45:49.930523
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = _ExtendedEncoder()
    assert o.default(dict(a=1)) == {'a':1}

# Generated at 2022-06-23 16:45:54.372649
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({"x": 1}) == {"x": 1}



# Generated at 2022-06-23 16:46:04.291357
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    The dataclass_json module contains a class FieldOverride that is constructed
    by the user_overrides_or_exts.
    """
    # test if the values that are not provided to constructor are initialized
    # as None
    field_override = FieldOverride()
    assert field_override.letter_case is None
    assert field_override.exclude is None
    assert field_override.encoder is None
    assert field_override.decoder is None
    # test if the values are set accordingly in constructor
    field_override = FieldOverride(letter_case=snake_case, exclude=abs,
                                   encoder=lambda x: x+1,
                                   decoder=lambda x: x-1)
    assert field_override.letter_case == snake_case
    assert field_override

# Generated at 2022-06-23 16:46:05.515097
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now()) >= 1567160769.0


# Generated at 2022-06-23 16:46:17.373398
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fld_override_instance1 = FieldOverride(
    letter_case=lambda x: x.upper()
    )
    assert fld_override_instance1.letter_case("lower") == "LOWER"
    assert fld_override_instance1.encoder is None
    assert fld_override_instance1.decoder is None
    assert fld_override_instance1.exclude is None

    fld_override_instance2 = FieldOverride(
    letter_case=lambda x: x.upper(),
    encoder=lambda x: x+1,
    decoder=lambda x: x-1,
    exclude=lambda x: x+1 < 2
    )
    assert fld_override_instance2.letter_case("lower") == "LOWER"
    assert fld_override_instance

# Generated at 2022-06-23 16:46:25.300978
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default('str') == 'str'
    assert encoder.default(1.0) == 1.0
    assert encoder.default(True) == True
    assert encoder.default(None) == None
    assert encoder.default([]) == []
    assert encoder.default(()) == []
    assert encoder.default(set()) == []
    assert encoder.default({}) == {}
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default(datetime(year=2019, month=1, day=2)) == 1556736000.0

# Generated at 2022-06-23 16:46:36.690391
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().encode({'1': [1,2,3]}) == '{"1": [1, 2, 3]}'
    assert _ExtendedEncoder().encode({"1": [1,2,3]}) == '{"1": [1, 2, 3]}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(set([1, 2, 3])) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == f'{datetime.now(timezone.utc).timestamp()}'
    assert _ExtendedEncoder().encode(Decimal('1.23')) == '"1.23"'



# Generated at 2022-06-23 16:46:46.677565
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride() == FieldOverride()
    assert FieldOverride(letter_case=None) == FieldOverride()
    assert FieldOverride(letter_case=None, exclude=None, encoder=None) == FieldOverride()
    assert FieldOverride(letter_case=None, exclude=None, encoder=None) != FieldOverride(letter_case=None, exclude=None,
                                                                                       encoder=None, decoder=lambda x:x)
    assert str(FieldOverride(letter_case=None, exclude=None, encoder=None)) == 'FieldOverride(letter_case=None, exclude=None, encoder=None)'

# Generated at 2022-06-23 16:46:54.213810
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default(1) == 1
    assert enc.default(None) is None
    assert enc.default(1.) == 1.
    assert enc.default('string') == 'string'
    assert enc.default(True) is True
    assert enc.default(False) is False
    assert enc.default([1, 2, 3]) == [1, 2, 3]
    assert enc.default((1, 2, 3)) == [1, 2, 3]
    assert enc.default({1, 2, 3}) == [1, 2, 3]
    assert enc.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert enc.default(['a', 'b']) == ['a', 'b']

# Generated at 2022-06-23 16:47:05.194868
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fe = FieldOverride(exclude)
    assert fe.letter_case is None
    assert_equal(fe.exclude, exclude)
    assert fe.encoder is None

    fe = FieldOverride(letter_case=snakecase, exclude=exclude)
    assert_equal(fe.letter_case, snakecase)
    assert_equal(fe.exclude, exclude)
    assert fe.encoder is None

    fe = FieldOverride(letter_case=snakecase, encoder=int)
    assert_equal(fe.letter_case, snakecase)
    assert fe.exclude is None
    assert_equal(fe.encoder, int)

    fe = FieldOverride(letter_case=snakecase, exclude=exclude, encoder=int)
    assert_equal(fe.letter_case, snakecase)
    assert_

# Generated at 2022-06-23 16:47:14.485010
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o1 = [0, 1]
    assert _ExtendedEncoder().encode(o1) == json.dumps(o1)
    o2 = {"a": "b"}
    assert _ExtendedEncoder().encode(o2) == json.dumps(o2)
    ts = 1574292024.983
    assert _ExtendedEncoder().encode(datetime.fromtimestamp(ts)) == json.dumps(ts)
    uid = UUID('2c6db71c-be9d-4e40-bbc4-7b99fbf63f6e')
    assert _ExtendedEncoder().encode(uid) == '"' + str(uid) + '"'

# Generated at 2022-06-23 16:47:20.484844
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # case 1: test_with_no_parameters
    field_override = FieldOverride()
    assert field_override.decoder is None
    assert field_override.encoder is None
    assert field_override.exclude is None
    assert field_override.letter_case is None

    # case 2: test_with_decoder
    def decoder_fn(obj):
        return obj

    field_override2 = FieldOverride(decoder=decoder_fn)
    assert field_override2.decoder is decoder_fn
    assert field_override2.encoder is None
    assert field_override2.exclude is None
    assert field_override2.letter_case is None

    # case 3: test_with_encoder
    def encoder_fn(obj):
        return obj

# Generated at 2022-06-23 16:47:30.889628
# Unit test for method default of class _ExtendedEncoder

# Generated at 2022-06-23 16:47:37.436914
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert enc.default([]) == []
    assert enc.default({}) == {}
    assert enc.default(UUID('68b32a74-c859-4863-a69c-a65e1d7ca9fe')) == '68b32a74-c859-4863-a69c-a65e1d7ca9fe'
    assert enc.default(datetime(2020, 2, 20)) == 1582214400.0


# Generated at 2022-06-23 16:47:48.221324
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import datetime
    from decimal import Decimal
    from uuid import UUID
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode(Decimal(1) / Decimal(3)) == '"0.3333333333333333333333333333"'
    assert _ExtendedEncoder().encode(datetime(2000, 1, 1, tzinfo=timezone.utc)) == '946684800.0'

# Generated at 2022-06-23 16:47:54.074545
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(exclude=lambda x: True,
                       letter_case=camelcase,
                       encoder={},
                       decoder={},
                       mm_field={})
    assert fo.exclude(1) is True
    assert fo.letter_case('a') == 'a'
    assert fo.encoder == {}
    assert fo.decoder == {}
    assert fo.mm_field == {}


# Generated at 2022-06-23 16:48:02.359988
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1]) == '1'
    assert _ExtendedEncoder().encode({'a': 'b'}) == '{"a":"b"}'
    assert _ExtendedEncoder().encode(b'byte string') == '"byte string"'
    assert _ExtendedEncoder().encode(datetime.now()) == '0.0'
    assert _ExtendedEncoder().encode(uuid.uuid4()) == '"uuid string"'
    assert _ExtendedEncoder().encode(1.1) == '1.1'



# Generated at 2022-06-23 16:48:11.666597
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(letter_case=lambda n: n,
                         exclude=lambda v: v,
                         encoder=lambda v: v,
                         decoder=lambda v: v).letter_case(
        "a") == "a" and FieldOverride(
        letter_case=lambda n: n, exclude=lambda v: v,
        encoder=lambda v: v, decoder=lambda v: v).exclude(2) == 2 and \
           FieldOverride(letter_case=lambda n: n, exclude=lambda v: v,
                         encoder=lambda v: v, decoder=lambda v: v).encoder(
               3) == 3 and FieldOverride(letter_case=lambda n: n,
                                         exclude=lambda v: v,
                                         encoder=lambda v: v,
                                         decoder=lambda v: v).dec

# Generated at 2022-06-23 16:48:22.900589
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test case 1 with exclude as None and letter_case as None
    f_o = FieldOverride(
        **{"exclude": None, "letter_case": None, "encoder": None,
           "decoder": None})
    assert f_o.exclude is None
    assert f_o.letter_case is None
    assert f_o.encoder is None
    assert f_o.decoder is None

    # test case 2 with exclude is set to a function and letter_case, encoder,
    # decoder as None
    f_o = FieldOverride(
        **{"exclude": lambda x: True if x > 5 else False, "letter_case": None,
           "encoder": None, "decoder": None})
    assert callable(f_o.exclude) is True
    assert f_o.letter_

# Generated at 2022-06-23 16:48:31.662261
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Create a FieldOverride instance with each of the four parameters
    #   set to a different value each time.
    for exclude, letter_case, encoder, decoder in permutations([None, int],
                                                               repeat=4):
        assert FieldOverride(exclude, letter_case, encoder, decoder)
        assert (FieldOverride(exclude,
                              None,
                              encoder,
                              decoder) ==
                FieldOverride(exclude, None, encoder, decoder))
        assert (FieldOverride(exclude, None,
                              encoder,
                              decoder) !=
                FieldOverride(exclude, None, encoder=int, decoder=int))

# Generated at 2022-06-23 16:48:43.888108
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(UUID('12345678123456781234567812345678'), cls=_ExtendedEncoder) == '"12345678-1234-5678-1234-567812345678"'
    assert json.dumps(datetime(2019, 1, 1, 0, 0, 1, tzinfo=timezone.utc), cls=_ExtendedEncoder) == '1.0'
    assert json.dumps(datetime(2019, 1, 1, 0, 0, 0, 1, tzinfo=timezone.utc), cls=_ExtendedEncoder) == '1.000000001'
    assert json.dumps({'a': 1, 'b': 2}, cls=_ExtendedEncoder) == '{"a": 1, "b": 2}'
    assert json.d

# Generated at 2022-06-23 16:48:51.544742
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    t = datetime.now(timezone.utc)
    d = Decimal('12.3')
    u = UUID('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11')
    assert e.default(t) == t.timestamp()
    assert e.default(d) == '12.3'
    assert e.default(u) == 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11'
    assert e.default(Enum('TestEnum', {'A': 'a', 'B': 2})) == 2
    assert e.default(('dummy', 1, 2)) == ['dummy', 1, 2]


# Generated at 2022-06-23 16:49:02.213873
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import datetime, timezone
    from uuid import UUID
    from enum import Enum
    from decimal import Decimal

    class Color(Enum):
        red = 1
        green = 2
        blue = 3
    json_color = json.dumps(Color.red, cls=_ExtendedEncoder)
    assert json_color == '1'
    json_color = json.dumps(Color.green, cls=_ExtendedEncoder)
    assert json_color == '2'
    json_color = json.dumps(Color.blue, cls=_ExtendedEncoder)
    assert json_color == '3'

    json_color = json.dumps({Color.red: Color.green}, cls=_ExtendedEncoder)
    assert json_color == '{"red": 2}'

# Generated at 2022-06-23 16:49:13.545096
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ee = _ExtendedEncoder()
    assert ee.default(datetime(2020, 9, 1, 0, 8, 3, tzinfo=timezone.utc)) == 1598932143.0
    assert ee.default(UUID("01234567-89ab-cdef-89ab-cdef01234567")) == "01234567-89ab-cdef-89ab-cdef01234567"
    assert ee.default([1, 2.4, "3"]) == [1, 2.4, "3"]
    assert ee.default({1: 2.4, "3": 4, 5: [6, 7]}) == {1: 2.4, "3": 4, 5: [6, 7]}

# Generated at 2022-06-23 16:49:21.052422
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Confirm that default encoder returns input
    assert FieldOverride().encoder(True)

    # Confirm that default exclude predicate always returns False
    assert FieldOverride().exclude(True) is False

    # Confirm that default letter case conversion is None
    assert FieldOverride().letter_case is None

    # Confirm that constructor works as expected
    f = _user_overrides_or_exts(Person)
    assert f['name'].decoder is not None
    assert f['name'].encoder is not None



# Generated at 2022-06-23 16:49:27.805907
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(2.5) == 2.5
    assert _ExtendedEncoder().default("a") == "a"
    assert _ExtendedEncoder().default(dict(a=1)) == dict(a=1)
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(datetime(2020, 2, 1, 12, 0, 0)) == 1580525600.0
    assert _ExtendedEnc

# Generated at 2022-06-23 16:49:37.635814
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_inputs = [
        1, 'string', True, None, [1, "string"], {'foo': 1, 'bar': 'string'},
        [{'foo': 1, 'bar': 'string'}],
        datetime.now(timezone.utc),
        UUID('{12345678-1234-5678-1234-567812345678}'),
        Decimal('1.0')
    ]
    for i in test_inputs:
        json_str = json.dumps(i, cls=_ExtendedEncoder)
        assert json.loads(json_str) == i



# Generated at 2022-06-23 16:49:43.631252
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default(None)
    _ExtendedEncoder().default(Decimal("3.14"))
    _ExtendedEncoder().default([])
    _ExtendedEncoder().default({})
    _ExtendedEncoder().default({'a': 1})
    _ExtendedEncoder().default(datetime(2020, 1, 1, 12, 0, 0))



# Generated at 2022-06-23 16:49:46.935602
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder(indent=4).encode({'a': [1, 2, 3]}) == \
           """{\n    "a": [\n        1,\n        2,\n        3\n    ]\n}"""



# Generated at 2022-06-23 16:49:59.049098
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.2) == 1.2
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == \
           datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('{12345678-1234-5678-1234-567812345678}')) == \
           '12345678-1234-5678-1234-567812345678'

# Generated at 2022-06-23 16:50:08.927494
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

    data = {1: [2, 3], 4: '5'}
    serialized = encoder.default(data)
    js_data = json.dumps(data, cls=_ExtendedEncoder)
    assert serialized == json.loads(js_data)

    data = {'a': datetime.now(timezone.utc), 'b': UUID('00000000-0000-0000-0000-000000000000')}
    serialized = encoder.default(data)
    js_data = json.dumps(data, cls=_ExtendedEncoder)
    assert serialized == json.loads(js_data)

    class EnumTest(Enum):
        A = 1
        B = 2


# Generated at 2022-06-23 16:50:12.651763
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert e.default([1, 2, 3]) == [1, 2, 3]
    assert e.default({3: 4}) == {3: 4}


_extended_encoder = _ExtendedEncoder()



# Generated at 2022-06-23 16:50:23.231242
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def _test_default(_default, value, expected):
        if expected is None:
            expected = value
        result = _ExtendedEncoder().encode(value)
        assert result == json.dumps(expected)

    _test_default('default', {}, {})
    _test_default('default', [], [])
    _test_default('default', {'a': 1}, {'a': 1})
    _test_default('default', [1], [1])
    _test_default('default', {'a': 1}, {'a': 1})
    _test_default('default', [1], [1])

    # datetime, timestamp
    dt = datetime.utcnow()
    _test_default('default', dt, dt.timestamp())

    # UUID, str

# Generated at 2022-06-23 16:50:27.940384
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(exclude=lambda x: True, encoder=lambda x: x,
                       decoder=lambda x: x, mm_fields=lambda x: x)
    check_annotations(fo)


# Generated at 2022-06-23 16:50:36.488806
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(encoder=lambda x: "foo",
                                   decoder=lambda x: "bar",
                                   exclude=lambda x: True,
                                   letter_case=str.lower,
                                   mm_field="dob")
    assert field_override.encoder(1) == "foo"
    assert field_override.decoder(1) == "bar"
    assert field_override.exclude(1) == True
    assert field_override.letter_case("FOO") == "foo"
    assert field_override.mm_field == "dob"

# Generated at 2022-06-23 16:50:47.571388
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode(()) == '[]'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEncoder().encode((1, 2)) == '[1, 2]'
    assert _ExtendedEncoder().encode(list((1, 2))) == '[1, 2]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
   

# Generated at 2022-06-23 16:50:51.094802
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    example_json_string = '{"a": {"str_attr": "str", "int_attr": 1}, "b": 2}'
    example_obj = json.loads(example_json_string)
    assert example_obj == json.loads(_ExtendedEncoder().encode(example_obj))



# Generated at 2022-06-23 16:51:02.723704
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(bool()) is False
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(set([1, 2])) == [1, 2]
    assert _ExtendedEncoder().default(list([1, 2, 3])) == [1, 2, 3]
    assert _ExtendedEncoder().default(tuple([1, 2, 3])) == [1, 2, 3]
    assert _ExtendedEncoder().default(dict(x=1, y=2)) == {'x': 1, 'y': 2}
    now = datetime.now()
   

# Generated at 2022-06-23 16:51:12.221885
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(2000, 1, 1, tzinfo=timezone.utc)) == 946684800.0
    assert _ExtendedEncoder().default(UUID(int=0x1c6edf36b4bc4bc4bc4bc4bc4bc4bc4b)) == '36df6e1c-4bc4-11e9-9b84-b827ebc26992'
    assert _ExtendedEncoder().default(Decimal(100.02)) == '100.02'
    assert _ExtendedEncoder().default(None) is None



# Generated at 2022-06-23 16:51:21.413537
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(UUID('899ffd27-8722-48fe-8e18-cc272f628ce3')) == '899ffd27-8722-48fe-8e18-cc272f628ce3'
    assert _ExtendedEncoder().default(datetime(2020, 9, 15, 12, 34, 56, tzinfo=timezone.utc)) == 1600923696.0
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default(Enum('TestEnum', {'A': 'a', 'B': 'b'})) == 'a'

# Generated at 2022-06-23 16:51:22.906084
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder(indent=True, ensure_ascii=False).encode(datetime.now())



# Generated at 2022-06-23 16:51:29.890727
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    override = FieldOverride(letter_case=lambda el: el + "a",
                             exclude=(lambda el: True),
                             encoder=(lambda el: el+1),
                             decoder=(lambda el: el+2))
    assert _is_callable(override.exclude)
    assert _is_callable(override.letter_case)
    assert _is_callable(override.encoder)
    assert _is_callable(override.decoder)



# Generated at 2022-06-23 16:51:39.235847
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    expected = dict(a=1, b=[1, 2, 3], c=[4, 5], d=dict(a=7), e=dict(b=8),
                    f=datetime.now(timezone.utc), g=datetime.utcnow(),
                    h=datetime.now(),
                    i=UUID('1c36f3d0-a59f-11e7-9a86-0e858bcdc0c9'),
                    j=UUID('1c36f3d0-a59f-11e7-9a86-0e858bcdc0n9'),
                    k=UUID('1c36f3d0-a59f-11e7-9a86-0e858bcdc0c9'))

# Generated at 2022-06-23 16:51:41.131736
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default(): ...
#########################################



# Generated at 2022-06-23 16:51:47.370538
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Check if the required parameters are set correctly
    # case 1: kwargs = {"exclude": lambda x: x, "letter_case": str.lower}
    exclude = lambda x: x
    letter_case = str.lower
    assert (FieldOverride(exclude, letter_case).exclude == exclude)


# Generated at 2022-06-23 16:51:56.262920
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    import pytest
    with pytest.raises(TypeError):
        FieldOverride(1, 2, 3)
    test_object = FieldOverride(True, 'snake_case', None)
    assert test_object.exclude == True
    assert test_object.letter_case == 'snake_case'
    assert test_object.encoder == None


# Generated at 2022-06-23 16:52:00.766039
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) == '12345678123456781234567812345678'
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(['1', '2', '3']) == ['1', '2', '3']
    assert _ExtendedEncoder().default(['1', 2, '3']) == ['1', 2, '3']
    assert _ExtendedEncoder().default({1, 2, 3}) == [1, 2, 3]
    assert _ExtendedEncoder().default

# Generated at 2022-06-23 16:52:07.849082
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().encode(datetime.now())
    assert _ExtendedEncoder().encode(UUID('b2f5ff474369467e8d1338675e7a5f94'))
    assert _ExtendedEncoder().encode(Decimal('-9.9'))
    assert _ExtendedEncoder().encode(Decimal('0.1'))
    assert _ExtendedEncoder().encode(Decimal('0.11'))


# Generated at 2022-06-23 16:52:16.486838
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    o = {'foo': 'bar', 'spam': 'eggs'}
    assert enc.default(o)[0][0] == 'spam'
    assert enc.default(o)[0][1] == 'eggs'
    assert enc.default(o)[1][0] == 'foo'
    assert enc.default(o)[1][1] == 'bar'
    assert isinstance(enc.default(o), dict)
    assert enc.default(o)['spam'] == 'eggs'
    assert enc.default(o)['foo'] == 'bar'
    assert enc.default(set(['a', 'b', 'c', 'd'])) == ['a', 'b', 'c', 'd']



# Generated at 2022-06-23 16:52:27.448812
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    x = FieldOverride(letter_case=lambda x: x.upper(),
                      exclude=lambda x: x == "foo",
                      encoder=lambda x: x,
                      decoder=lambda x: x)
    assert(x.letter_case(x="foo") == "FOO")
    assert(x.exclude(x="foo") == True)
    assert(x.exclude(x="bar") == False)
    assert(x.encoder(x=1) == 1)
    assert(x.decoder(x=1) == 1)



# Generated at 2022-06-23 16:52:28.898581
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.loads(_ExtendedEncoder().encode(datetime(2020, 1, 1))) == \
           {"__dataclass_json__": "datetime", "epoch_ms": 1577836800000}



# Generated at 2022-06-23 16:52:35.826931
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(
            exclude=lambda x: x > 5,
            letter_case=lambda s: s + "2",
            encoder=lambda x: x + 1,
            decoder=lambda x: x - 1).__eq__(
                FieldOverride(
                    exclude=lambda x: x > 5,
                    letter_case=lambda s: s + "2",
                    encoder=lambda x: x + 1,
                    decoder=lambda x: x - 1))



# Generated at 2022-06-23 16:52:49.163239
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default(()) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(frozenset()) == []
    assert _ExtendedEncoder().default(timezone.utc) == "UTC"
    assert _ExtendedEncoder().default(datetime(1, 1, 1, 1, 1, 1, 1, timezone.utc)) == -621355968001.0

# Generated at 2022-06-23 16:53:01.418782
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

    def test_default(o):
        return encoder.default(o)

    assert test_default([1, 2, 3]) == [1, 2, 3]
    assert test_default((1, 2, 3)) == [1, 2, 3]
    assert test_default(range(3)) == [0, 1, 2]
    assert test_default({1, 2, 3}) == [1, 2, 3]
    assert test_default({1:2, 3:4}) == {1:2, 3:4}
    assert test_default(frozenset((1, 2))) == [1, 2]
    assert test_default(defaultdict(int)) == {}

# Generated at 2022-06-23 16:53:09.411502
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert '{"test": "test"}' == encoder.encode({'test': 'test'})
    assert '["test"]' == encoder.encode(['test'])
    assert '3.456' == encoder.encode(3.456)
    assert '3' == encoder.encode(3)
    assert 'false' == encoder.encode(False)
    assert 'true' == encoder.encode(True)



# Generated at 2022-06-23 16:53:17.927150
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps([1, 2, 3], cls=_ExtendedEncoder) == json.dumps([1, 2, 3])
    assert json.dumps(set([1, 2, 3]), cls=_ExtendedEncoder) == json.dumps([1, 2, 3])
    assert json.dumps({'a': 1, 'b': 2}, cls=_ExtendedEncoder) == json.dumps({'a': 1, 'b': 2})
    now = datetime.now(timezone.utc)
    # noinspection PyTypeChecker
    assert json.dumps(now, cls=_ExtendedEncoder) == json.dumps(now.timestamp())

# Generated at 2022-06-23 16:53:21.049184
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    result = encoder.default(Decimal('0.1'))
    assert result == '0.1'



# Generated at 2022-06-23 16:53:24.052926
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(
        exclude=lambda x:x,
        letter_case=to_camel,
        encoder=str,
        decoder=str
    )



# Generated at 2022-06-23 16:53:32.007188
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode({1, 2, 3}) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode('2') == '"2"'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '{"__dataclass_json__": 1568170519.47}'


# Generated at 2022-06-23 16:53:41.972730
# Unit test for constructor of class FieldOverride
def test_FieldOverride():

    # Case 1: with default parameters
    overrides = FieldOverride()
    assert overrides.exclude is None
    assert overrides.letter_case is None
    assert overrides.encoder is None
    assert overrides.decoder is None
    assert overrides.mm_field is None


    # Case 2: with non-default parameters
    exclude = lambda x: x < 0
    letter_case = camel_to_snake
    encoder = lambda x: x + 1
    decoder = lambda x: x - 1
    mm_field = mm.Int()

    overrides = FieldOverride(
        exclude=exclude,
        letter_case=letter_case,
        encoder=encoder,
        decoder=decoder,
        mm_field=mm_field
    )

    assert overrides.exclude == exclude
   

# Generated at 2022-06-23 16:53:44.972529
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(True, True, True, decoder=bool)
    assert f.exclude is True
    assert f.letter_case is True
    assert f.encoder is True
    assert f.decoder is bool


# Generated at 2022-06-23 16:53:54.293827
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class D:
        a = Field(type=int, default=10)

    class C:
        a = Field(type=int, default=10)
        b = Field(type=D, default=D())

    config = {}
    c = C()
    overrides = _user_overrides_or_exts(C)
    fields_result = _decode_dataclass(C, c.__dict__, infer_missing=True)
    assert fields_result.a == 10
    assert fields_result.b.a == 10


if __name__ == '__main__':
    test_FieldOverride()

# Generated at 2022-06-23 16:54:02.945541
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(42) == 42
    assert _ExtendedEncoder().default("text") == "text"
    assert _ExtendedEncoder().default(3.14) == 3.14
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default(UUID('1b4e28ba-2fa1-11d2-883f-b9a761bde3fb')) == "1b4e28ba-2fa1-11d2-883f-b9a761bde3fb"
    assert _ExtendedEncoder().default(datetime(2019, 1, 1, tzinfo=timezone.utc)) == 1546300800

# Generated at 2022-06-23 16:54:13.687759
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(1) == json.dumps(1)
    assert _ExtendedEncoder().encode(True) == json.dumps(True)
    assert _ExtendedEncoder().encode([1]) == json.dumps([1])
    dt = datetime(2020, 1, 2, 3, 4, 5, 6, timezone.utc)
    assert _ExtendedEncoder().encode(dt) == json.dumps(dt.timestamp())
    # TODO: test encode(Enum())
    assert _ExtendedEncoder().encode(Decimal(1.2)) == json.dumps("1.2")



# Generated at 2022-06-23 16:54:17.682707
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    test_override = FieldOverride(letter_case=camelcase)
    assert test_override.letter_case == camelcase
    assert test_override.encoder == None
    assert test_override.decoder == None
    assert test_override.exclude == None


# Generated at 2022-06-23 16:54:28.849605
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(['test']) == ['test']
    assert encoder.default({'test': 'test'}) == {'test': 'test'}
    assert encoder.default(datetime.now(timezone.utc)), [0, "+0000"]
    assert encoder.default(UUID('f47ac10b-58cc-4372-a567-0e02b2c3d479')) == 'f47ac10b-58cc-4372-a567-0e02b2c3d479'
    assert encoder.default(Decimal('12.34')) == '12.34'


# https://github.com/jeffknupp/sandman2/blob/master/sandman2/model.py

# Generated at 2022-06-23 16:54:36.349757
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # return o & o.__dict__ would be a valid default implementation
    assert _ExtendedEncoder().default("string") == "string"
    assert _ExtendedEncoder().default(5) == 5
    assert _ExtendedEncoder().default(True) is True
    # assert ExtendedEncoder().default(b"string_byte") == b"string_byte"
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({1: "a", 2: "b"}) == {1: "a", 2: "b"}
    assert _ExtendedEncoder().default({"a": "b"}) == {"a": "b"}


# noinspection PyProtectedMember

# Generated at 2022-06-23 16:54:43.687615
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    from dataclasses import dataclass, field

    @dataclass
    class Person:
        id: int = field(default=1)
        name: str = field(default='Raul')
        age: int = field(default=30)

        def get_id(self):
            return self.id

        def get_age(self):
            return self.age

        def get_name(self):
            return self.name

    person = Person()

    @dataclass
    class Student:
        student_id: int = field(default=1)
        student_name: str = field(default='Raul')
        student_age: int = field(default=30)

        def get_student_id(self):
            return self.student_id


# Generated at 2022-06-23 16:54:54.396775
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # type: () -> None
    o = (1, 2, 3)
    obj = _ExtendedEncoder()
    assert (obj.default(o) == list(o)), "A list object should have been returned"
    o = {'a': 'a', 'b': 'b'}
    obj = _ExtendedEncoder()
    assert (obj.default(o) == dict(o)), "A dictionary object should have been returned"
    o = Decimal('3.14')
    obj = _ExtendedEncoder()
    assert (obj.default(o) == "3.14"), "A string object should have been returned"
    o = datetime.now(timezone.utc)
    obj = _ExtendedEncoder()

# Generated at 2022-06-23 16:55:06.879205
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None
    assert encoder.default(1.1) == 1.1
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({"a": "b"}) == {"a": "b"}
    assert encoder.default(UUID("6ba7b814-9dad-11d1-80b4-00c04fd430c8")) == "6ba7b814-9dad-11d1-80b4-00c04fd430c8"
    assert encoder.default(datetime(2019, 1, 1, tzinfo=timezone.utc)) == 1546