

# Generated at 2022-06-23 16:45:06.874430
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """Cover the class _ExtendedEncoder"""
    json.dumps(MyList([1, 2, 3]), cls=_ExtendedEncoder)
    json.dumps(MyDict({1: 'a', 2: 'b', 3: 'c'}), cls=_ExtendedEncoder)
    json.dumps(MyTuple((1, 2, 3)), cls=_ExtendedEncoder)
    json.dumps(MyUUID(uuid.uuid4()), cls=_ExtendedEncoder)
    json.dumps(MyDateTime(datetime.utcnow()), cls=_ExtendedEncoder)
    json.dumps(MyEnum(MyEnum.a), cls=_ExtendedEncoder)

# Generated at 2022-06-23 16:45:11.325767
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    @dataclass_json
    @dataclass
    class A:
        a: str
        b: int
        c: Optional[int]
    a = A('a', 2, None)
    assert a.a == 'a'
    assert a.b == 2
    assert a.c is None

# Generated at 2022-06-23 16:45:22.297943
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(ValueError) as err:
        FieldOverride(1, 2, 3, 4, 5, 6)
    assert str(err.value) == "__init__() takes from 1 to 6 positional arguments but 7 were given"

    with pytest.raises(ValueError) as err:
        FieldOverride(True, None, None, None, None)
    assert str(err.value) == "exclude and letter_case cannot both be None"

    with pytest.raises(ValueError) as err:
        FieldOverride(True, 'tuple_letter_case', None, None, None)
    assert str(err.value) == "letter_case must be a function or None"

    with pytest.raises(ValueError) as err:
        FieldOverride(True, lower, None, None, None)
   

# Generated at 2022-06-23 16:45:27.758019
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    data = [
        (dict(a=1, b=2), {'a': 1, 'b': 2}),
        (set([1, 2]), [1, 2]),
        (datetime(2020, 1, 1, 12, 0, 0, 0, timezone.utc), 1577836800.0)
    ]
    for d, expected_result in data:
        assert _ExtendedEncoder().default(d) == expected_result


# Generated at 2022-06-23 16:45:35.347133
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from ..tests.fixtures import User, users, Users
    result = json.dumps(users, cls=_ExtendedEncoder)
    assert result == '''[{"id": 1, "name": "Miguel Gonzalez", "age": 30}, \
{"id": 2, "name": "Juan Ortega", "age": 20}]'''
    result = json.dumps(Users(users), cls=_ExtendedEncoder)
    assert (result ==
            '''{"Users": [{"id": 1, "name": "Miguel Gonzalez", "age": 30}, \
{"id": 2, "name": "Juan Ortega", "age": 20}]}''')
    result = json.dumps(User(name="Miguel", age=30), cls=_ExtendedEncoder)
    assert result

# Generated at 2022-06-23 16:45:45.934308
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    s = _ExtendedEncoder().default(datetime.now())
    assert isinstance(s, float)
    s = _ExtendedEncoder().default(UUID('ad86b1a9-1e48-4e59-bab2-d596420f2ea8'))
    assert isinstance(s, str)
    time = timezone(datetime.now().timetz(), name="dt")
    s = _ExtendedEncoder().default(time)
    assert isinstance(s, str)
    s = _ExtendedEncoder().default({"a": 1, "b": 2, "c": 3})
    assert isinstance(s, dict)
    s = _ExtendedEncoder().default([1, 2, 3])
    assert isinstance(s, list)
    s = _ExtendedEncoder().default

# Generated at 2022-06-23 16:45:55.026521
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def _check_method(obj: Any) -> None:
        assert _ExtendedEncoder().default(obj) == json.JSONEncoder().default(obj)
    _check_method(1)
    _check_method("foo")
    _check_method(True)
    _check_method(None)
    _check_method(Decimal("1.23"))
    _check_method(set())
    _check_method(set([1, 2]))
    _check_method([1, 2])
    _check_method({})
    _check_method({1: "foo"})
    _check_method(datetime.now(timezone.utc))



# Generated at 2022-06-23 16:45:58.479196
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # None for each parameter, defaults for each parameter
    a = FieldOverride()
    assert a.encoder is None
    assert a.letter_case is None
    assert a.exclude is None



# Generated at 2022-06-23 16:46:00.264834
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'1': 2, 1: 2}) == json.dumps({'1': 2, 1: 2})



# Generated at 2022-06-23 16:46:09.454763
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder_instance = _ExtendedEncoder()
    extended_encoder_instance.default(3)
    extended_encoder_instance.default(['hello', 3])
    extended_encoder_instance.default({'hello': 3})
    extended_encoder_instance.default(UUID('a02d6718-fe2a-4cba-9dae-f05c1cc2f8c3'))
    extended_encoder_instance.default(datetime.now(timezone.utc))
    extended_encoder_instance.default(Decimal('1.0'))


# Generated at 2022-06-23 16:46:19.474472
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    sample_dict = {
        'list': [1, 2, 3],
        'dict': {
            'name': 'Kiwi',
            'type': 'bird'
        }
    }
    sample_datetime = datetime.now()
    sample_uuid = UUID('3c0d56b5-5b5a-4f97-b444-4c4c68e4e250')
    sample_enum = FileType.MARKDOWN
    sample_decimal = Decimal('123.456')
    sample_combined = [
        sample_dict,
        sample_datetime,
        sample_uuid,
        sample_enum,
        sample_decimal,
    ]
    res = json.dumps(sample_combined, cls=_ExtendedEncoder)
    reversed_tuple

# Generated at 2022-06-23 16:46:22.400530
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert (FieldOverride(
        None, None, None
    ) == FieldOverride(
        None, None, None
    ))



# Generated at 2022-06-23 16:46:30.335426
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoding = Encoder()

    # Test with some basic defaults
    field_override = FieldOverride()
    assert field_override.exclude is None
    assert field_override.letter_case is None
    assert field_override.encoder is None
    assert field_override.decoder is None

    # Test with override
    field_override = FieldOverride(exclude=lambda name: name == 'exclude',
                                   letter_case=str.swapcase,
                                   encoder=encoding,
                                   decoder=str.lower)
    assert field_override.exclude is not None
    assert field_override.letter_case is not None
    assert field_override.encoder is not None
    assert field_override.decoder is not None

# Generated at 2022-06-23 16:46:40.960138
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """ Test FieldOverride() constructor """

    from dataclasses_json.api import _class_to_dict

    # Tests
    # All fields provided
    try:
        fo = FieldOverride(exclude=lambda x: True,  # noqa: F841
                           letter_case='snake',
                           encoder=lambda x: x,
                           decoder=lambda x: x,
                           mm_field=lambda x: x,
                           )
    except Exception as e:
        print(e)
        exit(1)
    # Good, it worked

    # But should not accept an invalid field

# Generated at 2022-06-23 16:46:49.745355
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    # noinspection PyTypeChecker
    assert enc.default([1, 2, 3]) == [1, 2, 3]
    # noinspection PyTypeChecker
    assert enc.default({'a': 3.14}) == {'a': 3.14}
    # noinspection PyTypeChecker
    assert isinstance(enc.default(datetime.now()), float)
    # noinspection PyTypeChecker
    assert isinstance(enc.default(UUID('97b3de3e-9791-4b24-b6a4-3d2ab6c8f7ac')), str)
    # noinspection PyTypeChecker
    assert enc.default(Decimal('3.14')) == '3.14'



# Generated at 2022-06-23 16:46:51.718946
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(set([1])) == [1]
    assert _ExtendedEncoder().default(frozenset([1])) == [1]



# Generated at 2022-06-23 16:46:54.935989
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now()) == datetime.now().timestamp()
    assert encoder.default((1,2)) == [1,2]
    assert encoder.default({"x":1}) == {"x":1}

# No unit test for Encoder and Decoder because it is not used directly by users

# Generated at 2022-06-23 16:47:01.298494
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    conf = FieldOverride(exclude=lambda x: x is True,
                         decoder=lambda x: x + 1,
                         letter_case=lambda x: x.upper())
    assert conf.exclude(True) is True
    assert conf.decoder(1) == 2
    assert conf.letter_case('abc') == 'ABC'



# Generated at 2022-06-23 16:47:12.315361
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(['a', 'b']) == ['a', 'b']
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('a17adc41-b763-48e5-8a5a-84e2ce744a16')) == 'a17adc41-b763-48e5-8a5a-84e2ce744a16'
    assert _ExtendedEncoder().default(DateType.DATE) == DateType.DATE.value

# Generated at 2022-06-23 16:47:17.148108
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride()
    assert f.exclude is None
    assert f.letter_case is None
    assert f.encoder is None
    assert f.decoder is None

    f = FieldOverride(exclude=lambda x: True)
    assert f.exclude(True) is True
    assert f.letter_case is None
    assert f.encoder is None
    assert f.decoder is None

    f = FieldOverride(letter_case=lambda x: x.lower())
    assert f.exclude is None
    assert f.letter_case('ABC') == 'abc'
    assert f.encoder is None
    assert f.decoder is None

    f = FieldOverride(encoder=lambda x: x, decoder=lambda x: x)
    assert f.exclude is None

# Generated at 2022-06-23 16:47:25.264087
# Unit test for method default of class _ExtendedEncoder

# Generated at 2022-06-23 16:47:32.990607
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict(a=1)) == '{"a": 1}'
    assert _ExtendedEncoder().encode(list(1)) == '[1]'
    assert _ExtendedEncoder().encode(str('1')) == '"1"'
    assert _ExtendedEncoder().encode(int(1)) == '1'
    assert _ExtendedEncoder().encode(float(1)) == '1.0'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(datetime(2000, 1, 1)) == '946684800.0'
    d = datetime(2000, 1, 1, tzinfo=timezone.utc)


# Generated at 2022-06-23 16:47:42.270733
# Unit test for method default of class _ExtendedEncoder

# Generated at 2022-06-23 16:47:54.151143
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(1.0) == "1.0"
    assert _ExtendedEncoder().encode(datetime(2020, 1, 1)) == "1577836800.0"
    assert _ExtendedEncoder().encode(UUID("d22a2939-a96a-4fb4-a4e4-d4f1b42d4159")) == "d22a2939-a96a-4fb4-a4e4-d4f1b42d4159"
    assert _ExtendedEncoder().encode([1, 2, 4]) == "[1, 2, 4]"
    assert _ExtendedEncoder().encode({"x": 1, "y": 2}) == '{"x": 1, "y": 2}'

# Generated at 2022-06-23 16:47:57.135910
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = object()
    result = _ExtendedEncoder().default(o)
    assert result is o



# Generated at 2022-06-23 16:48:01.890501
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """Tests for FieldOverride constructor."""
    fo = FieldOverride("exclude", "letter_case", "encoder", "decoder")
    assert fo.exclude == "exclude"
    assert fo.letter_case == "letter_case"
    assert fo.encoder == "encoder"
    assert fo.decoder == "decoder"



# Generated at 2022-06-23 16:48:06.713196
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride().exclude is None
    assert FieldOverride().mm_field is None
    assert FieldOverride().letter_case is identity
    assert FieldOverride(exclude=None).exclude is None
    assert FieldOverride(mm_field=None).mm_field is None
    assert FieldOverride(letter_case=None).letter_case is None



# Generated at 2022-06-23 16:48:13.617971
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default({1, 2}) == [1, 2]
    assert _ExtendedEncoder().default({1: 2}) == {1: 2}
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default([None]) == [None]
    assert _ExtendedEncoder().default(None) == 'null'
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default('1') == '1'
# end unit test



# Generated at 2022-06-23 16:48:24.217293
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def test(o):
        return _ExtendedEncoder().default(o)
    class MyEnum(Enum):
        One = 1
        Two = 2
    assert test(MyEnum.One) == 1
    assert test({1, 2, 3}) == [1, 2, 3]
    assert test([1, 2, 3]) == [1, 2, 3]
    assert test({1: 2, 3: 4}) == {"1": 2, "3": 4}
    dt = datetime.now(timezone.utc)
    assert test(dt) == dt.timestamp()
    assert test(UUID("12345678-1234-1234-1234-123456789012")) == "12345678-1234-1234-1234-123456789012"

# Generated at 2022-06-23 16:48:33.526047
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import datetime as DT
    from decimal import Decimal as D
    from enum import IntEnum

    assert _ExtendedEncoder().encode([]) == "[]"
    assert _ExtendedEncoder().encode({}) == "{}"
    assert _ExtendedEncoder().encode(True) == "true"
    assert _ExtendedEncoder().encode(False) == "false"
    assert _ExtendedEncoder().encode(None) == "null"
    assert _ExtendedEncoder().encode(0) == "0"
    assert _ExtendedEncoder().encode(1) == "1"
    assert _ExtendedEncoder().encode(0.0) == "0.0"
    assert _ExtendedEncoder().encode(1.0) == "1.0"
    assert _ExtendedEnc

# Generated at 2022-06-23 16:48:45.020986
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f_default = FieldOverride()
    assert isinstance(f_default.letter_case, str)
    assert f_default.letter_case == "upper"
    assert f_default.exclude == False

    f_lower = FieldOverride(letter_case="lower", exclude=True)
    assert f_lower.letter_case == "lower"
    assert f_lower.exclude == True

    f_upper = FieldOverride(letter_case="upper", exclude=False)
    assert f_upper.letter_case == "upper"
    assert f_upper.exclude == False

    with pytest.raises(ValueError) as excinfo:
        FieldOverride(letter_case="not_a_valid_letter_case", exclude=False)
    assert "not_a_valid_letter_case" in str(excinfo.value)

# Generated at 2022-06-23 16:48:52.470813
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _ = _ExtendedEncoder(indent=2)
    assert _.default(['a']) == ['a']
    assert _.default([1]) == [1]
    assert _.default(set()) == []
    assert _.default(dict(a=1)) == {'a': 1}
    assert _.default(UUID('a7a55d66-f950-4d21-b42c-9f9c0ef791a8')) == 'a7a55d66-f950-4d21-b42c-9f9c0ef791a8'
    assert _.default(datetime(1970, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == 0.0

# Generated at 2022-06-23 16:49:02.790369
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(0) == 0
    assert _ExtendedEncoder().default(0.0) == 0.0
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default('') == ''
    assert _ExtendedEncoder().default(dict(a=0, b=1)) == dict(a=0, b=1)
    assert _ExtendedEncoder().default(list((0, 1))) == [0, 1]
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, 0, 0, 0)) == 0.0

# Generated at 2022-06-23 16:49:13.291887
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    dataclasses_json.as_json()
    """

    # Create json data
    json_str = '{"name":"Jane Doe","age":115,"score":80.5,"active":true}'

    # Define dataclass
    @dataclass_json
    @dataclass
    class Person:
        name: str
        age: int
        score: float
        active: bool

    # Load json string into dataclass
    jane = Person.from_json(json_str)

    if jane.name == 'Jane Doe' and jane.age == 115 and jane.active == True \
            and jane.score == 80.5:
        assert True
    else:
        assert False


# Generated at 2022-06-23 16:49:23.257346
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    d = _ExtendedEncoder().default
    assert d([1, 2, 3]) == [1, 2, 3]
    assert d({1: 23}) == {1: 23}
    assert d(datetime(2016, 1, 1)) == 1451606400
    assert d(timezone(timedelta(hours=9))) is not None
    assert d(UUID('201b69ff-7592-4e8c-88a5-b19c921d601e')) == str(UUID('201b69ff-7592-4e8c-88a5-b19c921d601e'))
    assert d(Decimal('1.23')) == '1.23'
    assert d(Mapping) is not None



# Generated at 2022-06-23 16:49:35.494807
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # None values for all the parameters
    with pytest.raises(TypeError):
        FieldOverride()

    with pytest.raises(TypeError):
        FieldOverride(exclude=lambda a: True)

    with pytest.raises(TypeError):
        FieldOverride(letter_case=lambda x: x.upper())

    with pytest.raises(TypeError):
        FieldOverride(encoder=lambda x: x)

    with pytest.raises(TypeError):
        FieldOverride(decoder=lambda x: x)

    # None values for exclude, letter_case and encoder
    with pytest.raises(TypeError):
        FieldOverride(decoder=lambda x: x)

    # None values for exclude, letter_case, encoder and decoder
    with pytest.raises(TypeError):
        Field

# Generated at 2022-06-23 16:49:38.570760
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    actual = json.dumps(datetime.now(timezone.utc)
                        , cls=_ExtendedEncoder)
    assert actual is not None



# Generated at 2022-06-23 16:49:42.758535
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2012, 1, 14, 22, 32, 54, tzinfo=timezone.utc)) == '1326503974.0'


# Generated at 2022-06-23 16:49:50.144329
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    expected = {
        list: list(range(5)),
        dict: dict(),
        datetime: datetime.now(timezone.utc),
        UUID: UUID('ffffffff-ffff-ffff-ffff-ffffffffffff'),
        int: 5,
        str: 'abc',
        bool: True,
        Decimal: Decimal(5),
    }
    assert encoder.default(expected.get(list)) == expected[list]
    assert encoder.default(expected.get(dict)) == expected[dict]
    assert encoder.default(expected.get(datetime)) == expected[datetime].timestamp()
    assert encoder.default(expected.get(UUID)) == str(expected[UUID])
    assert encoder.default(expected.get(int))

# Generated at 2022-06-23 16:49:54.360726
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps({'key': 'val'}, cls=_ExtendedEncoder) == json.dumps({'key': 'val'})
    assert json.dumps([1, 2, 3], cls=_ExtendedEncoder) == json.dumps([1, 2, 3])



# Generated at 2022-06-23 16:49:56.672405
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    value = 1.2
    expected = 1.2
    assert _ExtendedEncoder().default(value) == expected



# Generated at 2022-06-23 16:50:07.522828
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(True, False, "name", encoder=None, decoder=None)

    assert field_override.exclude(3) == True
    assert field_override.letter_case("name") == "name"
    assert field_override.encoder == None
    assert field_override.decoder == None

    field_override = FieldOverride(None, None, None, None, None)

    assert field_override.exclude(3) == False
    assert field_override.letter_case("name") == "name"
    assert field_override.encoder == None
    assert field_override.decoder == None

    field_override = FieldOverride(None, None, None, encoder=None, decoder=None)

    # Without exclude and letter_case, keep the user

# Generated at 2022-06-23 16:50:18.332102
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder.default(None, []) == []
    assert _ExtendedEncoder.default(None, [1, 2]) == [1, 2]
    assert _ExtendedEncoder.default(None, (1, 2)) == [1, 2]
    assert _ExtendedEncoder.default(None, {1: 2}) == {1: 2}
    assert _ExtendedEncoder.default(None, {'1': '2'}) == {'1': '2'}
    assert _ExtendedEncoder.default(None, {(1, 2): (3, 4)}) == {(1, 2): (3, 4)}
    assert _ExtendedEncoder.default(None, {(1, 2): {3: 4}}) == {(1, 2): {3: 4}}
    assert _ExtendedEnc

# Generated at 2022-06-23 16:50:26.647964
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import date, time
    from enum import IntEnum

    class AnyEnum(IntEnum):
        ANY = 1

    def check(o):
        encoded = json.dumps(o, cls=_ExtendedEncoder)
        decoded = json.loads(encoded)
        assert o == decoded

    check(list(range(5)))
    check(dict(a=1, b=2))
    check(date(2017, 12, 1))
    check(time())
    check(AnyEnum.ANY)
    check(Decimal(1e1))
    try:
        check(datetime.now(timezone.utc))
    except TypeError:
        pass
    assert json.dumps(None, cls=_ExtendedEncoder) == 'null'



# Generated at 2022-06-23 16:50:37.999248
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(cfg.NaT) == None
    assert _ExtendedEncoder().default(datetime(1970, 1, 1)) == 0
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == 0
    assert _ExtendedEncoder().default(datetime(2020, 4, 4, 17, 3, 10)) == 1586028890
    assert _ExtendedEncoder().default(datetime(2020, 4, 4, 17, 3, 10, tzinfo=timezone.utc)) == 1586028890
    assert _ExtendedEncoder().default(datetime(2020, 4, 4, 10, 3, 10, tzinfo=timezone(timedelta(hours=-7)))) == 1586028890
    assert _

# Generated at 2022-06-23 16:50:47.576870
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default([])
    _ExtendedEncoder().default(())
    _ExtendedEncoder().default({})
    _ExtendedEncoder().default(set())
    _ExtendedEncoder().default(defaultdict(str))
    _ExtendedEncoder().default(1)
    _ExtendedEncoder().default('a')
    _ExtendedEncoder().default(True)
    _ExtendedEncoder().default(False)
    _ExtendedEncoder().default(datetime.now(timezone.utc))
    _ExtendedEncoder().default(datetime.now())
    _ExtendedEncoder().default(UUID('{12345678-1234-5678-1234-567812345678}'))
    _ExtendedEncoder().default(Decimal('1.00000'))
    _

# Generated at 2022-06-23 16:50:58.626977
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime(2020, 1, 31, 3, 45, tzinfo=timezone.utc)) == 1580395900.0
    assert encoder.default(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default({'a': 3, 'b': 2}) == {'a': 3, 'b': 2}
    assert encoder.default([2, 3]) == [2, 3]
    assert encoder.default(Decimal('1.23')) == '1.23'
    assert encoder.default(None) is None



# Generated at 2022-06-23 16:51:05.238415
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Test the constructor of FieldOverride.
    """
    # Create a FieldOverride instance with no letter case.
    field_override = FieldOverride(None, None, None)
    assert field_override is not None
    assert field_override.letter_case is None

    # Create a FieldOverride instance with a letter case (snake case).
    field_override = FieldOverride(to_snake_case, None, None)
    assert field_override is not None
    assert field_override.letter_case == to_snake_case


# Generated at 2022-06-23 16:51:09.428273
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(ul.UnexpectedLetterCaseError):
        FieldOverride("invalid_letter_case")
    assert FieldOverride("lower") == FieldOverride("lower")
    assert FieldOverride("lower") != FieldOverride("snake")
    assert FieldOverride("lower") != \
        FieldOverride("lower", exclude=lambda x: True)
    assert FieldOverride("lower") != \
        FieldOverride("lower", encoder=lambda x: x + 1)
    assert FieldOverride("lower") != \
        FieldOverride("lower", decoder=lambda x: x)
    assert FieldOverride("lower") != \
        FieldOverride("lower", mm_fields=lambda x: x)



# Generated at 2022-06-23 16:51:18.033184
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # pylint: disable=unused-variable
    # pylint: disable=invalid-name
    # pylint: disable=unused-argument
    FieldOverride("a", lambda x: x, lambda x: x, lambda x: x, lambda x: x,
                  lambda x: x)
    FieldOverride("a", lambda x: x, lambda x: x, lambda x: x, lambda x: x)
    FieldOverride("a", exclude=lambda x: x)
    FieldOverride("a", exclude=lambda x: x, letter_case=lambda x: x)
    FieldOverride("a", letter_case=lambda x: x)



# Generated at 2022-06-23 16:51:29.198910
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8')) == '6ba7b810-9dad-11d1-80b4-00c04fd430c8'
    assert encoder.default(Enum) == 'Enum'
    assert encoder.default(Decimal('1.2')) == '1.2'
    assert encoder.default(datetime(2020, 1, 31, 12, 30, 45, 799)) == 1580463245
    assert encoder.default([1, 2.3, True, None]) == [1, 2.3, True, None]
    assert encoder.default(()) == []
    assert encoder.default({'key': 'value'})

# Generated at 2022-06-23 16:51:40.168251
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    decoder = _ExtendedEncoder()
    assert decoder.default(range(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert decoder.default(dict(a=1, b=2)) == {'a': 1, 'b': 2}
    assert decoder.default(Decimal('1.23')) == '1.23'
    assert decoder.default(Enum("A", 1)) == 1
    assert decoder.default(UUID("2d8b9a59-9e49-4e18-b8d3-ea3cc3a3b1f1")) == "2d8b9a59-9e49-4e18-b8d3-ea3cc3a3b1f1"

# Generated at 2022-06-23 16:51:51.638353
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime(2019, 1, 1, 12, 30, 30, 30)) == 1546319230.03
    assert encoder.default(datetime(2019, 1, 1, 12, 30, 30, 30, timezone.utc)) == 1546319230.03
    assert encoder.default(UUID('f20c7ad1-2c89-11e9-b210-d663bd873d93')) == 'f20c7ad1-2c89-11e9-b210-d663bd873d93'
    assert encoder.default(decimal.Decimal('0.3')) == '0.3'
    assert encoder.default(1) == 1


# Generated at 2022-06-23 16:52:03.452402
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    type_input = [None, True, False, 0, 1, 1.2, 'hello world',
                  datetime.now(timezone.utc), UUID("856b0cba-38d9-468c-9c17-f56c3b3d0b04"),
                  Enum('Enum', {'value' : 1}), Decimal('1.2')]
    type_expected = [None, True, False, 0, 1, 1.2, 'hello world', 0, '856b0cba-38d9-468c-9c17-f56c3b3d0b04',
                     1, '1.2']
    for i, _ in enumerate(type_input):
        assert _ExtendedEncoder().default(type_input[i]) == type_expected[i]
   

# Generated at 2022-06-23 16:52:13.388154
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps({"foo": []}, cls=_ExtendedEncoder)
    json.dumps({"foo": {}}, cls=_ExtendedEncoder)
    json.dumps({"foo": datetime.now()}, cls=_ExtendedEncoder)
    json.dumps({"foo": datetime.utcnow()}, cls=_ExtendedEncoder)
    json.dumps({"foo": datetime.now().astimezone(timezone.utc)}, cls=_ExtendedEncoder)
    json.dumps({"foo": UUID("123e4567-e89b-12d3-a456-426655440000")}, cls=_ExtendedEncoder)

# Generated at 2022-06-23 16:52:17.822329
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime(2010, 1, 1, 1, 1, 1, 1, timezone.utc)) == 1262304261.000001
    assert encoder.default(UUID(int=1)) == '00000000-0000-0000-0000-000000000001'
    assert encoder.default(Decimal('1')) == '1'



# Generated at 2022-06-23 16:52:28.554038
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    kwargs = dict(
        exclude=lambda x: x == 1,
        letter_case=lambda x: x.upper(),
        encoder=int,
        decoder=str,
        mm_field=Mock()
    )
    fo = FieldOverride(**kwargs)
    assert fo.exclude(1)
    assert not fo.exclude(0)
    assert fo.letter_case("str") == "STR"
    assert fo.encoder(1) == 1
    assert fo.decoder("1") == "1"
    assert fo.mm_field is kwargs["mm_field"]

# Generated at 2022-06-23 16:52:39.280476
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test FieldOverride.__init__() with no arguments
    fo = FieldOverride()
    assert fo.decoder is None
    assert fo.encoder is None
    assert fo.exclude is None
    assert fo.letter_case is None

    # Test FieldOverride.__init__() with all arguments
    def dummy_decoder(x):
        return 2 * x

    def dummy_encoder(x):
        return 2 * x

    def dummy_exclude(x):
        return x % 2 == 0

    def dummy_letter_case(x):
        return x.upper()

    fo = FieldOverride(dummy_decoder, dummy_encoder,
                       dummy_exclude, dummy_letter_case)
    assert fo.decoder is dummy_decoder
    assert fo.encoder is dummy_encoder

# Generated at 2022-06-23 16:52:50.424962
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    def _assert(v, expected):
        assert encoder.default(v) == expected
    _assert([1, 'a'], [1, 'a'])
    _assert({'k': 'v'}, {'k': 'v'})
    _assert(datetime(2020, 4, 15, tzinfo=timezone.utc), 1586992400)
    _assert(UUID('6432a02a-2cba-4469-9c02-b3106b7a3b1e'), '6432a02a-2cba-4469-9c02-b3106b7a3b1e')
    _assert(Decimal('1.2'), '1.2')
    _assert(Exception(), '{}')


# Generated at 2022-06-23 16:52:54.984760
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    foo = FieldOverride(exclude=None, letter_case=None, encoder=None, decoder=None, mm_field=None)
    assert foo.exclude == None
    assert foo.letter_case == None
    assert foo.encoder == None
    assert foo.decoder == None
    assert foo.mm_field == None

    foo = FieldOverride(exclude=lambda x: True, letter_case=lambda x: x.lower(),
                        encoder=lambda x: x, decoder=lambda x: x, mm_field=lambda x: x)
    assert foo.exclude != None
    assert foo.letter_case != None
    assert foo.encoder != None
    assert foo.decoder != None
    assert foo.mm_field != None

# Generated at 2022-06-23 16:53:02.205803
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    expected_result = {
        "exclude": None,
        "letter_case": None,
        "encoder": None,
        "decoder": None,
    }
    actual_result = FieldOverride()
    assert actual_result == expected_result

    expected_result = {
        "exclude": None,
        "letter_case": None,
        "encoder": None,
        "decoder": lambda x: x.strip(),
    }
    actual_result = FieldOverride(decoder=lambda x: x.strip())
    assert actual_result == expected_result



# Generated at 2022-06-23 16:53:13.798723
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(object(), cls=_ExtendedEncoder) == '{}'
    assert json.dumps(42, cls=_ExtendedEncoder) == '42'
    assert json.dumps(42.5, cls=_ExtendedEncoder) == '42.5'
    assert json.dumps([42, 42.5], cls=_ExtendedEncoder) == '[42, 42.5]'
    assert json.dumps({'foo': 42, 'bar': 42.5}, cls=_ExtendedEncoder) == '{"foo": 42, "bar": 42.5}'
    assert json.dumps(set([42, 42.5]), cls=_ExtendedEncoder) == '[42, 42.5]'

# Generated at 2022-06-23 16:53:22.640697
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default(set()) == []
    assert enc.default({'a': 2}) == {'a': 2}
    assert enc.default((3, 4)) == [3, 4]
    assert enc.default(datetime(1984, 1, 24, 10, 10, 10)) == 466534010.0
    assert enc.default(UUID('1c7b816f-c6f9-4e97-a6b8-a2c7e1b70c1b')) == '1c7b816f-c6f9-4e97-a6b8-a2c7e1b70c1b'



# Generated at 2022-06-23 16:53:27.426780
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    now = datetime.now(timezone.utc)
    assert enc.default(now).startswith(str(now.timestamp()))


_t = TypeVar('_t')
_s = TypeVar('_s')
_ut = Union[Type[Json], Type[None]]



# Generated at 2022-06-23 16:53:31.594734
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    test_config = {"letter_case": "camel",
                   "encoder": None,
                   "decoder": None,
                   "exclude": None,
                   "mm_field": None}
    fo = FieldOverride(**test_config)
    assert fo.letter_case == "camel"
    assert fo.encoder is None
    assert fo.decoder is None
    assert fo.exclude is None
    assert fo.mm_field is None

# Generated at 2022-06-23 16:53:37.968689
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    try:
        f = FieldOverride(None, True)
    except ValueError as e:
        assert "exclude must be callable if provided" == str(e)
    try:
        f = FieldOverride(lambda x: x, "wrong type")
    except ValueError as e:
        assert "exclude must be a callable object or None" == str(e)

# Unit tests for _user_overrides_or_exts

# Generated at 2022-06-23 16:53:47.831899
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test letter_case
    a = FieldOverride(None, None, None, None, None)
    assert(a.letter_case == None)
    b = FieldOverride(lambda x:x.lower(), None, None, None, None)

# Generated at 2022-06-23 16:53:58.777385
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(Decimal('1.0')) == '1.0'
    assert encoder.default(UUID('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa')) == 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
    assert encoder.default(datetime(2019, 1, 1, tzinfo=timezone.utc)) == 1546300800.0
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

# Generated at 2022-06-23 16:54:09.628297
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(True, cls=_ExtendedEncoder) == str(True)
    assert json.dumps([1, 2, 3], cls=_ExtendedEncoder) == str([1, 2, 3])
    assert json.dumps((1, 2, 3), cls=_ExtendedEncoder) == str([1, 2, 3])
    assert json.dumps({1: 2, 3: 4}, cls=_ExtendedEncoder) == str({1: 2, 3: 4})
    assert json.dumps(datetime.now(timezone.utc), cls=_ExtendedEncoder) == str(datetime.now(timezone.utc).timestamp())



# Generated at 2022-06-23 16:54:12.313565
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    _ = FieldOverride(True, False, str.lower, str)
    _ = FieldOverride(True, False, str.lower, Json('string'))


# Generated at 2022-06-23 16:54:16.653751
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Test the constructor of class FieldOverride
    """
    # without any parameter
    f1 = FieldOverride()
    assert f1.letter_case is None

    # with parameters
    f2 = FieldOverride(letter_case="upper")
    assert f2.letter_case == "upper"

# Generated at 2022-06-23 16:54:27.865083
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from collections.abc import Mapping, Sequence
    from datetime import datetime
    from uuid import UUID
    from unittest.mock import ANY
    import json

    encoder = _ExtendedEncoder()

    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

    assert encoder.default(datetime(2000, 1, 1)) == 946684800.0
    assert encoder.default(datetime(2000, 1, 1, tzinfo=timezone.utc)) == 946684800.0

    assert encoder.default(UUID(int=0))

# Generated at 2022-06-23 16:54:39.372061
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    default_init_kwargs = {
        "letter_case": None,
        "exclude": None,
        "encoder": None,
        "decoder": None,
        "mm_fields": None,
    }
    assert FieldOverride() == FieldOverride(**default_init_kwargs)
    assert FieldOverride() == FieldOverride(None, None, None, None, None)

    assert FieldOverride(
        letter_case=camelcase,
        encoder=str,
        decoder=str,
    ) == FieldOverride(
        letter_case=camelcase,
        exclude=None,
        encoder=str,
        decoder=str,
        mm_fields=None,
    )


# Generated at 2022-06-23 16:54:42.031399
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(set([1, 2])) == [1, 2]

# Generated at 2022-06-23 16:54:53.662582
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now(timezone.utc))
    assert encoder.default(UUID('01234567-89ab-cdef-0123-456789abcdef'))
    assert encoder.default(Decimal('0.1'))
    assert encoder.default(Decimal('-0.1'))
    assert encoder.default(Decimal('1.1'))

    assert encoder.default(list())
    assert encoder.default(list([1, 2, 3]))
    assert encoder.default(tuple('abc'))
    assert encoder.default(set(['1', 2, 3.0]))

    assert encoder.default(dict())
    assert encoder.default(dict(a=1))
    assert enc

# Generated at 2022-06-23 16:55:00.939430
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    def f1(x):
        return x + 1

    def f2(x):
        return x - 1

    fo = FieldOverride(exclude=f1, letter_case=f2, decoder=f1, encoder=f2)
    assert fo.exclude == f1
    assert fo.letter_case == f2
    assert fo.decoder == f1
    assert fo.encoder == f2