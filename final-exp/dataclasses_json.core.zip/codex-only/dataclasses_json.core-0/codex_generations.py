

# Generated at 2022-06-23 16:45:04.302973
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    output = encoder.default(bytearray(b"abc"))
    assert output == "abc"
    output = encoder.default(memoryview(b"abc"))
    assert output == "abc"
    output = encoder.default(UUID(int=0))
    assert output == "00000000-0000-0000-0000-000000000000"
    output = encoder.default(UUID(int=12345678))
    assert output == "00000000-0000-0000-0000-00bc614e"
    output = encoder.default(datetime.now(timezone.utc))
    assert isinstance(output, float)



# Generated at 2022-06-23 16:45:15.734811
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # simple
    assert json.dumps(None, cls=_ExtendedEncoder) == 'null'
    assert json.dumps(123, cls=_ExtendedEncoder) == '123'
    assert json.dumps('foo', cls=_ExtendedEncoder) == '"foo"'
    assert json.dumps(True, cls=_ExtendedEncoder) == 'true'
    assert json.dumps(False, cls=_ExtendedEncoder) == 'false'
    assert json.dumps(1.23, cls=_ExtendedEncoder) == '1.23'
    assert json.dumps(1.23 + 4j, cls=_ExtendedEncoder) == 'null'

    # collections

# Generated at 2022-06-23 16:45:19.730099
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(ValueError):
        FieldOverride(exclude=1)
    with pytest.raises(ValueError):
        FieldOverride(letter_case="Foo")
    with pytest.raises(ValueError):
        FieldOverride(encoder="Foo")
    with pytest.raises(ValueError):
        FieldOverride(mm_field=1)
    with pytest.raises(ValueError):
        FieldOverride(decoder=1)

# Generated at 2022-06-23 16:45:28.090911
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    from unittest import TestCase, main
    from decimal import Decimal
    from datetime import datetime, timezone
    from uuid import UUID

    class TestFieldOverride(TestCase):
        def test_default_constructor(self):
            field_override = FieldOverride()
            self.assertEqual(field_override.letter_case, None)
            self.assertEqual(field_override.exclude, None)
            self.assertEqual(field_override.encoder, None)
            self.assertEqual(field_override.decoder, None)

        def test_custom_constructor_letter_case(self):
            field_override = FieldOverride(letter_case=str.lower)
            self.assertEqual(field_override.letter_case, str.lower)


# Generated at 2022-06-23 16:45:39.796546
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # create a FieldOverride with default value
    fo = FieldOverride()
    assert fo.letter_case is None
    assert fo.exclude is None
    assert fo.encoder is None
    assert fo.decoder is None

    # create a new FieldOverride with given value
    fo = FieldOverride(letter_case="lower", exclude=None, encoder=None,
                       decoder=None)
    assert fo.letter_case == "lower"
    assert fo.exclude is None
    assert fo.encoder is None
    assert fo.decoder is None

    # create a new FieldOverride with a new value
    fo.letter_case = "upper"
    fo.exclude = None
    fo.encoder = None
    fo.decoder = None
    assert fo.letter_case == "upper"

# Generated at 2022-06-23 16:45:48.296157
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime(2019, 2, 1)) == 1548979200.0
    assert _ExtendedEncoder().default(Enum('MyEnum', values={'A': 1, 'B': 2})) == 'A'
    assert _ExtendedEncoder().default(Decimal(1)) == '1'
    assert _ExtendedEncoder().default(UUID('ebf7b4d4-3a7a-4e9e-9c20-1f5508d02a60')) == 'ebf7b4d4-3a7a-4e9e-9c20-1f5508d02a60'



# Generated at 2022-06-23 16:45:59.456834
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Test the constructor of class FieldOverride
    """
    @dataclass
    class Data:
        to_lower: str
        to_lower_1: str
        to_upper: str
        to_upper_1: str
        snake: str
        snake_1: str
        camel: str
        camel_1: str
        kabob: str
        kabob_1: str
        pascal: str
        pascal_1: str
        exclude: str
        exclude_1: str
        exclude_2: str
        exclude_3: str

    config = {}
    config["letter_case"] = "lower"
    config["exclude"] = lambda x: x == "to_lower"

# Generated at 2022-06-23 16:46:00.689939
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# Generated at 2022-06-23 16:46:07.472468
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ee = _ExtendedEncoder()
    assert type(ee.default(10)) == int
    assert type(ee.default(10.0)) == float
    assert type(ee.default(True)) == bool
    assert type(ee.default('ten')) == str
    assert type(ee.default(datetime.utcnow())) == float
    assert type(ee.default(UUID('12345678123456781234567812345678'))) == str
    assert type(ee.default(Decimal('10.5'))) == str
    assert type(ee.default([1, 2, 3])) == list
    assert type(ee.default({'foo': 10, 'bar': 20})) == dict



# Generated at 2022-06-23 16:46:09.827493
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():  # noqa: F811
    assert _ExtendedEncoder().encode(datetime.now()) is not None



# Generated at 2022-06-23 16:46:12.987444
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Constructor that takes no arguments
    assert FieldOverride() == FieldOverride(None, None, None)
    # Constructor with arguments
    assert FieldOverride(lambda x: x, lambda x: x, lambda x: x)

# Generated at 2022-06-23 16:46:21.492244
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    json.dumps(dict(a=0), cls=_ExtendedEncoder)
    json.dumps(set([1, 2]), cls=_ExtendedEncoder)
    json.dumps(set(['a', 'b']), cls=_ExtendedEncoder)
    dtm = datetime.now(tz=timezone.utc)
    json.dumps(dtm, cls=_ExtendedEncoder)
    uuid = UUID('04d4b9c2-4e01-4d50-b5bc-e80b6a5bcd4f')
    json.dumps(uuid, cls=_ExtendedEncoder)
    e = Enum('Color', 'red green blue')
    json.dumps(e.red, cls=_ExtendedEncoder)
   

# Generated at 2022-06-23 16:46:29.805912
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    str(datetime(year=2019, month=1, day=1, tzinfo=timezone.utc))
    dummy = _ExtendedEncoder()
    assert dummy.default(datetime(year=2019, month=1, day=1, tzinfo=timezone.utc)) == 1546300800.0
    assert dummy.default(UUID('11112222-3333-4444-5555-666677778888')) == '11112222-3333-4444-5555-666677778888'
    assert dummy.default(Decimal('100.00')) == '100.00'
    assert dummy.default([1, 2, 3]) == [1, 2, 3]
    assert dummy.default({'abc': 123}) == {'abc': 123}



# Generated at 2022-06-23 16:46:33.484394
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(exclude=lambda x: False,
                       encoder=lambda x: x,
                       decoder=lambda x: x,
                       letter_case=lambda x: x,
                       mm_field=lambda x: x)
    assert id(fo.exclude) == id(lambda x: False)
    assert id(fo.encoder) == id(lambda x: x)
    assert id(fo.decoder) == id(lambda x: x)
    assert id(fo.letter_case) == id(lambda x: x)
    assert id(fo.mm_field) == id(lambda x: x)



# Generated at 2022-06-23 16:46:44.107390
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    class _UserId(str):
        pass
    class _Id(str):
        pass
    class _Id2(str):
        pass

    class _User:
        def __init__(self, user_id: _Id, screen_name: str, age: int,
                     is_bot: bool, bd: datetime, friends: _Id2):
            self.user_id = user_id
            self.screen_name = screen_name
            self.age = age
            self.is_bot = is_bot
            self.bd = bd
            self.friends = friends
    
    user_id = _UserId('user1')
    id1 = _Id('id1')
    id2 = _Id2('id2')
    dt = datetime.now(tz=timezone.utc)
   

# Generated at 2022-06-23 16:46:51.705546
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # _FieldOverride:
    #     def __init__(self, *, letter_case=None,
    #                  exclude=None, decoder=None, encoder=None):
    print("Testing creation of FieldOvernride")
    x = FieldOverride(letter_case=lambda x: x.upper(), decoder=None, encoder=_encode_json_type)
    print(x.letter_case, x.exclude, x.decoder, x.encoder)
    assert x.letter_case('abc') == 'ABC'
    assert x.exclude is None
    assert x.decoder is None
    assert x.encoder is _encode_json_type
    print("Finished testing FieldOvernride instances")



# Generated at 2022-06-23 16:47:01.439415
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda x : x.__len__()
    decoder = lambda x : '*' * x
    fo1 = FieldOverride()
    assert fo1.letter_case is None
    assert fo1.exclude is None
    assert fo1.encoder is None
    assert fo1.decoder is None

    fo2 = FieldOverride(letter_case=str.upper, encoder=encoder,
                        decoder=decoder)
    assert fo2.letter_case is str.upper
    assert fo2.exclude is None
    assert fo2.encoder is encoder
    assert fo2.decoder is decoder


# Generated at 2022-06-23 16:47:04.625448
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    c = _ExtendedEncoder()
    assert c is not None

EXTENDED_JSON_ENCODER = _ExtendedEncoder()


# Generated at 2022-06-23 16:47:10.710750
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert not FieldOverride(None, None, None).exclude(None)

    f = FieldOverride(None, None, None)
    f.exclude = lambda x: True
    assert f.exclude(None)

    assert FieldOverride(None, None, None).letter_case(None) == None

    f = FieldOverride(None, None, None)
    f.letter_case = lambda x: x+1
    assert f.letter_case(2) == 3


# Generated at 2022-06-23 16:47:18.843110
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class XYZ:
        pass
    m = {1:2, 3:4}
    def f(x):
        return x
    def g(x):
        return x
    field_override = FieldOverride(f, g, m, True, XYZ)
    assert field_override.encoder == f
    assert field_override.decoder == g
    assert field_override.mm_field == m
    assert field_override.exclude == True
    assert field_override.letter_case == XYZ
    assert field_override.obj2dict() == {"encoder": f,
                                         "decoder": g,
                                         "mm_field": m,
                                         "exclude": True,
                                         "letter_case": XYZ}


# Generated at 2022-06-23 16:47:28.205590
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(exclude=lambda o: o == 0)
    assert fo.exclude(0) is True
    assert fo.exclude(1) is False
    assert fo.letter_case is None
    assert fo.encoder is None
    assert fo.decoder is None
    assert fo.mm_field is None

    fo = FieldOverride(letter_case=camelcase,
                       encoder=lambda x: x + 1,
                       mm_field=1)
    assert fo.letter_case is camelcase
    assert fo.encoder(0) == 1
    assert fo.mm_field == 1
    assert fo.decoder is None

# Generated at 2022-06-23 16:47:38.847772
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == list(set())
    assert encoder.default(set('abc')) == list(set('abc'))
    assert encoder.default(frozenset('1')) == list(frozenset('1'))
    assert encoder.default(frozenset([2, 3, 4])) == list(frozenset([2, 3, 4]))
    assert encoder.default(dict()) == dict()
    assert encoder.default(dict(a='a', b=1)) == dict(a='a', b=1)
    dt = datetime(2020, 2, 1, 1, 0, 0,
                  tzinfo=timezone.utc)
    assert encoder.default(dt) == dt.timestamp()

# Generated at 2022-06-23 16:47:46.383912
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert e.default(datetime(2017, 1, 1, 11, 0, 0, tzinfo=timezone.utc)) == 1483274800.0
    assert e.default(Decimal(1.0)) == "1.0"
    assert e.default(UUID("d18b11e5-a120-4a2b-b992-1b3f2e9b8797")) == "d18b11e5-a120-4a2b-b992-1b3f2e9b8797"


# Generated at 2022-06-23 16:47:56.454251
# Unit test for constructor of class _ExtendedEncoder

# Generated at 2022-06-23 16:47:57.677034
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1,2, 3}) == '[1, 2, 3]'



# Generated at 2022-06-23 16:48:07.506451
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default('test_string') == 'test_string'
    assert _ExtendedEncoder().default(100) == 100
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(1.25) == 1.25
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(['test_string']) == ['test_string']
    assert _ExtendedEncoder().default(('test_string', 'test_string2')) == \
           ['test_string', 'test_string2']

# Generated at 2022-06-23 16:48:14.454784
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Notice that the 2nd argument is a callable
    override_callable = FieldOverride(exclude=lambda x: True,
                                      encoder=lambda x: x+1,
                                      decoder=lambda x: x+2,
                                      letter_case=lambda x: x.lower())
    override_non_callable = FieldOverride(exclude=False,
                                          encoder=lambda x: x+1,
                                          decoder=lambda x: x+2,
                                          letter_case=lambda x: x.lower())
    assert override_callable.exclude(0)
    assert not override_non_callable.exclude(0)
    assert override_callable.encoder(0) == 1
    assert override_callable.decoder(0) == 2
    assert override_callable.letter_

# Generated at 2022-06-23 16:48:25.470671
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test that an InvalidFieldOverride exception is raised when an invalid
    # combination of arguments is passed into the constructor.
    invalid_args = (
        [None, None, None, lambda x: True],
        [None, None, None, lambda x: False],
        [None, None, lambda x: True, lambda x: False]
    )
    for args in invalid_args:
        with pytest.raises(InvalidFieldOverride):
            FieldOverride(*args)

    # Test that the default value of `mm_field` is None
    field_override = FieldOverride(exclude=lambda x: True,
                                   letter_case=lambda x: x.upper(),
                                   encoder=lambda x: x.upper(),
                                   decoder=lambda x: x.upper())
    assert field_override.mm_field is None




# Generated at 2022-06-23 16:48:34.593928
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    test_dict = {'a': ['sd', 'ff', 'qq'],
                 'b': {'c': None, 'd': 'e'},
                 'f': None,
                 'g': 5}
    res = _ExtendedEncoder().default(test_dict)
    assert res == {'a': ['sd', 'ff', 'qq'],
                   'b': {'c': None, 'd': 'e'},
                   'f': None,
                   'g': 5}

    test_list = ['sd', 'ff', 'qq']
    res = _ExtendedEncoder().default(test_list)
    assert res == ['sd', 'ff', 'qq']

    assert _ExtendedEncoder().default(None) is None

    assert _ExtendedEncoder().default(True) is True
    assert _Extended

# Generated at 2022-06-23 16:48:41.141789
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default({'x': 1}) == {'x': 1}
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default(datetime.now()) == datetime.now().timestamp()
    assert encoder.default(Enum('x', ['y'])) == 'y'
    assert encoder.default(Decimal('2.2')) == '2.2'



# Generated at 2022-06-23 16:48:47.334380
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # empty one
    assert FieldOverride() == FieldOverride(None, None, None, None)
    assert FieldOverride().exclude is None
    assert FieldOverride().letter_case is None
    assert FieldOverride().encoder is None
    assert FieldOverride().decoder is None

    # all fields to be set
    a = FieldOverride(None, None, None, None)
    assert a.exclude is None
    assert a.letter_case is None
    assert a.encoder is None
    assert a.decoder is None



# Generated at 2022-06-23 16:48:53.404429
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default(datetime.now(tz=timezone.utc)) == datetime.now(tz=timezone.utc).timestamp()
    assert encoder.default(UUID('{123e4567-e89b-12d3-a456-426655440000}')) == '123e4567-e89b-12d3-a456-426655440000'
    assert encoder.default(Decimal('1.23')) == '1.23'



# Generated at 2022-06-23 16:49:03.159080
# Unit test for constructor of class _ExtendedEncoder

# Generated at 2022-06-23 16:49:13.990994
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(encoder=None, decoder=None, exclude=None,
                         letter_case=None).encoder is None
    assert FieldOverride(encoder=None, decoder=None, exclude=None,
                         letter_case=None).decoder is None
    assert FieldOverride(encoder=None, decoder=None, exclude=None,
                         letter_case=None).exclude is None
    assert FieldOverride(encoder=None, decoder=None, exclude=None,
                         letter_case=None).letter_case is None

    assert FieldOverride(encoder=1, decoder=None, exclude=None,
                         letter_case=None).encoder == 1
    assert FieldOverride(encoder=1, decoder=None, exclude=None,
                         letter_case=None).decoder is None

# Generated at 2022-06-23 16:49:21.156236
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import dataclass

    @dataclass
    class MyDT:
        sub: str

    from datetime import datetime, timezone
    from uuid import UUID
    from enum import Enum
    from decimal import Decimal
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class Data(DataClassJsonMixin):
        dt: datetime
        u: UUID
        dc: Decimal
        co: Collection
        mp: Mapping
        en: Enum
        child: MyDT = None

    dt = datetime.utcnow().replace(tzinfo=timezone.utc)
    u = UUID('033bce6c-124d-4c6d-87ca-825b0e8de749')

# Generated at 2022-06-23 16:49:25.362920
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    overrides = {'a': 1, 'b': 2, 'c': 3}
    field_override = FieldOverride(**overrides)

    assert(field_override.exclude == 1)
    assert(field_override.letter_case == 2)
    assert(field_override.encoder == 3)
    assert(field_override.mm_field is None)
    assert(field_override.decoder is None)

    wf_config = {
        'exclude': None,
        'letter_case': None,
        'encoder': None
    }
    field_override = FieldOverride(**wf_config)
    assert(field_override.encoder is None)



# Generated at 2022-06-23 16:49:35.674561
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    def __init__(self):
        self.field_override = FieldOverride(
            exclude=lambda x: x == 2,
            letter_case=lambda x: x.upper(),
            encoder=lambda x: x + 1,
            decoder=lambda x: x - 1)

    assert self.field_override.exclude(2) == True
    assert self.field_override.exclude(3) == False
    assert self.field_override.letter_case('test') == 'TEST'
    assert self.field_override.encoder(2) == 3
    assert self.field_override.decoder(1) == 0

# Generated at 2022-06-23 16:49:41.161314
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field = FieldOverride(exclude=None, encoder=None,
                          decoder=None, letter_case=None)
    assert field.exclude is None
    assert field.encoder is None
    assert field.decoder is None
    assert field.letter_case is None



# Generated at 2022-06-23 16:49:49.479256
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    def assertJsonEqual(obj1: Json, obj2: Json) -> None:
        if not isinstance(obj1, type(obj2)):
            raise AssertionError('{} is not {}'.format(obj1, obj2))
        if isinstance(obj1, list):
            if len(obj1) != len(obj2):
                raise AssertionError('{} is not {}'.format(obj1, obj2))
            for o1, o2 in zip(obj1, obj2):
                assertJsonEqual(o1, o2)
        elif isinstance(obj1, dict):
            if len(obj1) != len(obj2):
                raise AssertionError('{} is not {}'.format(obj1, obj2))
            for k in obj1:
                assert k

# Generated at 2022-06-23 16:49:59.895334
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    conf_pred = 'exclude'
    FieldOverride(exclude=str)
    field = Field(name='name', type=str, default=None, init=False,
                  metadata={'exclude': str})
    assert getattr(FieldOverride(exclude=str), conf_pred) is str
    assert getattr(
        create_override_from_field(field, conf_pred), conf_pred) is str
    assert not FieldOverride(exclude=str).exclude('hi')

    conf_pred = 'letter_case'
    FieldOverride(letter_case=lambda x: x.upper())
    field = Field(name='name', type=str, default=None, init=False,
                  metadata={'letter_case': lambda x: x.upper()})

# Generated at 2022-06-23 16:50:09.245228
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    ret = encoder.default({})
    assert isinstance(ret, dict)
    ret = encoder.default([])
    assert isinstance(ret, list)
    ret = encoder.default('s')
    assert isinstance(ret, str)
    ret = encoder.default(1)
    assert isinstance(ret, int)
    ret = encoder.default(1.1)
    assert isinstance(ret, float)
    ret = encoder.default(True)
    assert isinstance(ret, bool)
    ret = encoder.default(None)
    assert isinstance(ret, type(None))
    ret = encoder.default(datetime.now(timezone.utc))
    assert isinstance(ret, float)

# Generated at 2022-06-23 16:50:20.138608
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    expected = [
        (object(), NotImplemented),
        ([], []),
        ({}, {}),
        (1, 1),
        (1.0, 1.0),
        (True, True),
        (False, False),
        (None, None),
        (datetime.now(timezone.utc), NotImplemented),
        (UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8'), '6ba7b810-9dad-11d1-80b4-00c04fd430c8'),
    ]
    encoder = _ExtendedEncoder()

# Generated at 2022-06-23 16:50:27.099842
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # pylint: disable=missing-function-docstring
    def f(): ...

    def g(): ...

    def h(): ...

    # ensure that constructor of class FieldOverride works by calling it # noqa: S107
    FieldOverride(exclude=f, encoder=g, decoder=h, letter_case=lambda x: x)



# Generated at 2022-06-23 16:50:37.999621
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj_dict = dict()
    obj_list = list()
    obj_str = ''
    obj_int = 0
    obj_float = 0.0
    obj_bool = False
    obj_none = None
    obj_datetime = datetime.utcnow()
    obj_uuid = UUID('b4ee7fef-04b4-4c07-9f4f-99ed4f305d68')
    obj_decimal = Decimal('1.0')

    encoder = _ExtendedEncoder()
    assert encoder.default(obj_dict) == obj_dict
    assert encoder.default(obj_list) == obj_list
    assert encoder.default(obj_str) == obj_str
    assert encoder.default(obj_int) == obj_int

# Generated at 2022-06-23 16:50:47.576817
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ext_encoder = _ExtendedEncoder()
    assert ext_encoder.default({'key':'value'}) == {'key':'value'}
    assert ext_encoder.default([1,2,3]) == [1,2,3]
    assert ext_encoder.default('a_string') == 'a_string'
    assert ext_encoder.default(123) == 123
    assert ext_encoder.default(1.23) == 1.23
    assert ext_encoder.default(True) == True
    assert ext_encoder.default(None) == None
    assert ext_encoder.default(datetime(2019, 11, 1, 4, 34, tzinfo=timezone.utc)) == 1572546240.0

# Generated at 2022-06-23 16:50:56.934292
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    result = _ExtendedEncoder().default(datetime.fromisoformat('2019-04-26T10:31:00.000000+00:00'))
    assert result == 1556302260.0
    result = _ExtendedEncoder().default(datetime.fromisoformat('2019-04-26T10:31:00-08:00'))
    assert result == 1556329060.0
    result = _ExtendedEncoder().default(datetime.fromisoformat('2019-04-26T10:31:00+09:00'))
    assert result == 1556293460.0
    result = _ExtendedEncoder().default(UUID('d513438f-6e35-4a2c-b97f-48d16c9b9f05'))

# Generated at 2022-06-23 16:51:00.744248
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride()
    assert field_override.letter_case is None
    assert field_override.exclude is None
    assert field_override.encoder is None
    assert field_override.decoder is None



# Generated at 2022-06-23 16:51:10.892939
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f1 = FieldOverride(letter_case=letter_case_camel, exclude=None, encoder=None, decoder=None)
    f2 = FieldOverride(letter_case=letter_case_camel, exclude=None, encoder=None, decoder=None)
    f3 = FieldOverride(letter_case=letter_case_snake, exclude=None, encoder=None, decoder=None)
    assert f1==f2, 'f1==f2 should be True'
    assert f1!=f3, 'f1!=f3 should be True'



# Generated at 2022-06-23 16:51:18.828577
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # init
    name = 'name'
    exclude_pred = lambda x: True
    encoder = None
    decoder = None
    letter_case = None
    field_override = FieldOverride(exclude=exclude_pred, encoder=encoder,
                                   decoder=decoder, letter_case=letter_case)
    # getter
    assert field_override.exclude == exclude_pred
    assert field_override.encoder == encoder
    assert field_override.decoder == decoder
    assert field_override.letter_case == letter_case



# Generated at 2022-06-23 16:51:25.907485
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(exclude=None, letter_case=None,
                                   encoder=None, decoder=None)
    assert field_override.exclude is None
    assert field_override.letter_case is None
    assert field_override.encoder is None
    assert field_override.decoder is None


# Generated at 2022-06-23 16:51:38.626444
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    a = FieldOverride()
    b = FieldOverride(1, 2, 3)
    c = FieldOverride(exclude=lambda x: x == 3)
    d = FieldOverride(letter_case=lambda x: x)
    e = FieldOverride(encoder=lambda x: x+1)
    f = FieldOverride(decoder=lambda x: x+1)
    assert a.exclude is None
    assert a.letter_case is None
    assert a.encoder is None
    assert a.decoder is None
    assert b.exclude == 1
    assert b.letter_case == 2
    assert b.encoder == 3
    assert b.decoder is None
    assert c.exclude is not None
    assert c.letter_case is None
    assert c.encoder is None
    assert c.decoder is None


# Generated at 2022-06-23 16:51:40.869687
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(None, None, None, None, None) is not None

# Generated at 2022-06-23 16:51:52.250048
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default('1') == '1'
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default((1, 2, 3)) == [1, 2, 3]
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default({1, 2, 3}) == [1, 2, 3]

# Generated at 2022-06-23 16:51:58.281606
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(UUID("6ba7b811-9dad-11d1-80b4-00c04fd430c8")
            ) == "6ba7b811-9dad-11d1-80b4-00c04fd430c8"


# Generated at 2022-06-23 16:52:07.359901
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(['a', 'b']) == ['a', 'b']
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default(UUID(hex='12345678901234567890'*2)) == '12345678-9012-3456-7890-123456789012'
    assert _ExtendedEncoder().default(Enum(value='a')) == 'a'
    assert _ExtendedEncoder().default(2) == 2




# Generated at 2022-06-23 16:52:18.027862
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Example 1
    assert (_ExtendedEncoder().default(datetime.now(timezone.utc))) == (datetime.now(timezone.utc)).timestamp()

    # Example 2
    import uuid
    uid = uuid.uuid4()
    assert (_ExtendedEncoder().default(uid)) == str(uid)

    # Example 3
    assert (_ExtendedEncoder().default(Decimal('2.345'))) == '2.345'

    # Example 4
    assert (_ExtendedEncoder().default(list(range(5)))) == list(range(5))

    # Example 5
    assert (_ExtendedEncoder().default(range(5))) == list(range(5))

    # Example 6
    assert (_ExtendedEncoder().default(set(range(5)))) == list(range(5))

   

# Generated at 2022-06-23 16:52:30.443030
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1, 2, 3}) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({1, 2, 3}).encode() == b'[1, 2, 3]'
    assert _ExtendedEncoder().encode([1, {"test": [1, 2, 3]}, 3]) == '[1, {"test": [1, 2, 3]}, 3]'
    assert _ExtendedEncoder().encode([1, {"test": [1, 2, 3]}, 3]).encode() == b'[1, {"test": [1, 2, 3]}, 3]'
    assert _ExtendedEncoder().encode({1: 2, 3: 4}) == '{"1": 2, "3": 4}'

# Generated at 2022-06-23 16:52:39.865119
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    """Test Json Encoder"""
    se1 = set(range(5))
    se2 = {'d': 2.0, 'i': 1, 's': 'test'}
    se3 = {'test_bool': True, 'test_int': 1, 'test_string': 'test'}
    se4 = ['test_bool', True, 'test_int', 1, 'test_string', 'test']
    se5 = 'test'
    se6 = [True, 1, 'test']
    se7 = [False, 1, 'test']
    se8 = (True, 1, 'test')
    se9 = {True, 1, 'test'}
    se10 = Decimal('2.00000')
    se11 = Decimal('2.00001')
    se12 = Decimal('2.99998')

# Generated at 2022-06-23 16:52:47.043118
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses_json._extended_encoder import test_cases
    for tc in test_cases:
        encoder = _ExtendedEncoder(skipkeys=True, ensure_ascii=False)
        result_json = encoder.encode(tc.input_obj)
        expected_json = json.dumps(tc.expected)
        assert result_json == expected_json



# Generated at 2022-06-23 16:53:00.398926
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(123) == 123
    assert encoder.default(123.0) == 123.0
    assert encoder.default("Hi") == "Hi"
    assert encoder.default({'a':1}) == {'a':1}
    assert encoder.default([1,2,3,4]) == [1,2,3,4]
    assert encoder.default(datetime(2020,1,1)) == datetime(2020,1,1).timestamp()

# Generated at 2022-06-23 16:53:07.700562
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda x: x
    decoder = lambda x: x
    exclude = lambda x: True
    letter_case = lambda x: x
    f = FieldOverride(exclude, encoder, decoder, letter_case)
    assert f.exclude == exclude
    assert f.encoder == encoder
    assert f.decoder == decoder
    assert f.letter_case == letter_case

# Generated at 2022-06-23 16:53:17.196089
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    o = None
    assert encoder.default(o) == o

    o = 1
    assert encoder.default(o) == o

    o = 1.5
    assert encoder.default(o) == o

    o = b'1.5'
    assert encoder.default(o) == o

    o = 'hello'
    assert encoder.default(o) == o

    o = True
    assert encoder.default(o) == o

    o = (1, 2)
    assert encoder.default(o) == o

    o = [1, 2]
    assert encoder.default(o) == o

    o = {'a': 1, 'b': 2}
    assert encoder.default(o) == o


# Generated at 2022-06-23 16:53:28.009911
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

    assert 'abc' == encoder.default('abc')
    assert 123 == encoder.default(123)
    assert 0.456 == encoder.default(0.456)
    assert True == encoder.default(True)
    assert None == encoder.default(None)
    assert [1, 2, 3] == encoder.default([1, 2, 3])
    assert {'a': 1, 'b': 2, 'c': 3} == encoder.default({'a': 1, 'b': 2, 'c': 3})

    from datetime import datetime
    assert 1362164728.123 == encoder.default(datetime(2013, 2, 27, 17, 22, 8, 123000, timezone.utc))


# Generated at 2022-06-23 16:53:34.324506
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(0) == 0
    assert _ExtendedEncoder().default('a string') == 'a string'
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(slice(3, 9, 2)) == {'start': 3, 'stop': 9, 'step': 2}
    assert _ExtendedEncoder().default(complex(1.2, 5.6)) == {'real': 1.2, 'imag': 5.6}
    assert _ExtendedEnc

# Generated at 2022-06-23 16:53:37.458538
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default(Decimal('1')) == "1"


# Generated at 2022-06-23 16:53:47.331319
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

    assert encoder.default(['abc']) == ['abc']
    assert encoder.default(('abc',)) == ['abc']
    assert encoder.default({'abc': 1}) == {'abc': 1}
    assert encoder.default(set('abc')) == ['a', 'b', 'c']
    assert encoder.default(frozenset('abc')) == ['a', 'b', 'c']

    assert encoder.default(datetime(2019, 1, 1, 12, 34, 56, 0, timezone.utc)) == 1546384496.0

# Generated at 2022-06-23 16:53:58.143499
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Check whether conversion of basic data types works.
    encoder = _ExtendedEncoder()
    assert encoder.default(None) == None
    assert encoder.default(1) == 1
    assert encoder.default('1') == '1'
    assert encoder.default(True) == True
    assert encoder.default(1.1) == 1.1

    # Check whether conversion of a collection works.
    col = [1, 2, 3]
    assert encoder.default(col) == col
    assert encoder.default(tuple(col)) == col
    assert encoder.default(set(col)) == col
    assert encoder.default(bytes(col)) == col
    assert encoder.default(bytearray(col)) == col
    assert encoder.default((1, 2, 3)) == col


# Generated at 2022-06-23 16:54:05.484040
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert (_ExtendedEncoder().encode({"a": [1, 2]}) ==
            '{"a": [1, 2]}')
    assert (_ExtendedEncoder().encode(dict(a=[1, 2])) ==
            '{"a": [1, 2]}')
    assert (_ExtendedEncoder().encode([1, 2]) == '[1, 2]')
    assert (_ExtendedEncoder().encode(list([1, 2])) == '[1, 2]')
    assert (_ExtendedEncoder().encode(set([1, 2])) == '[1, 2]')
    assert (_ExtendedEncoder().encode(range(3)) == '[0, 1, 2]')
    assert (_ExtendedEncoder().encode({1, 2, 3}) == '[1, 2, 3]')

# Generated at 2022-06-23 16:54:16.653764
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(False) == 'false'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(UUID('0000003c-0000-0000-0000-000000000001')) == '"0000003c-0000-0000-0000-000000000001"'

# Generated at 2022-06-23 16:54:18.105682
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().encode(MISSING) == 'null'



# Generated at 2022-06-23 16:54:20.403245
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(Decimal('1')).__class__.__name__ == 'str'


# Generated at 2022-06-23 16:54:22.942323
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps({"hello": "world"}, cls=_ExtendedEncoder)


# Generated at 2022-06-23 16:54:25.063034
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(Decimal('0.1')) == '"0.1"'


# Generated at 2022-06-23 16:54:34.033331
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert e.default([[1, 2], [0]]) == [[1, 2], [0]]  # type: ignore
    assert e.default({'a': True, 'b': False}) == {'a': True, 'b': False}  # type: ignore
    dt = datetime(2010, 1, 1, 0, 0, tzinfo=timezone.utc)
    assert e.default(dt) == dt.timestamp()  # type: ignore
    assert e.default(UUID('12341234-1234-1234-1234-123412341234')) == '12341234-1234-1234-1234-123412341234'  # type: ignore

# Generated at 2022-06-23 16:54:42.675007
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert enc.default(int) == int
    assert enc.default(1) == 1
    assert enc.default(1.1) == 1.1
    assert enc.default('a') == 'a'
    assert enc.default(True) == True
    assert enc.default(False) == False
    assert enc.default(None) == None
    assert enc.default(()) == []
    assert enc.default(set()) == []
    assert enc.default(frozenset()) == []
    assert enc.default([]) == []
    assert enc.default({}) == {}
    assert enc.default({'a': 1, 'b': 'm'}) == {'a': 1, 'b': 'm'}
    assert enc.default(defaultdict(str)) == {}

# Generated at 2022-06-23 16:54:54.093844
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps([1, 2, 3], cls=_ExtendedEncoder) == "[1, 2, 3]"
    assert json.dumps({'key': 'value'}, cls=_ExtendedEncoder) == '{"key": "value"}'
    assert json.dumps(123, cls=_ExtendedEncoder) == "123"
    assert json.dumps("abc", cls=_ExtendedEncoder) == '"abc"'
    assert json.dumps(True, cls=_ExtendedEncoder) == "true"
    assert json.dumps(None, cls=_ExtendedEncoder) == "null"

    class C:
        pass


# Generated at 2022-06-23 16:55:02.699190
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    try:
        FieldOverride()
    except TypeError:
        pass
    else:
        assert False, 'Should throw TypeError'

    try:
        FieldOverride(1, 2, 3, 4, 5)
    except TypeError:
        pass
    else:
        assert False, 'Should throw TypeError'

    try:
        FieldOverride(1, 2, 3, 4)
    except Exception:
        assert False, 'Should not throw TypeError'
    else:
        assert True
