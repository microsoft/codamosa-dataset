

# Generated at 2022-06-23 16:45:02.875715
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    m_conf = FieldOverride(exclude=True, letter_case=lambda x: x.upper(),
                           encoder='encoder',decoder='decoder')
    assert m_conf.exclude == True
    assert m_conf.letter_case('test123') == 'TEST123'
    assert m_conf.encoder == 'encoder'
    assert m_conf.decoder == 'decoder'



# Generated at 2022-06-23 16:45:04.504475
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    dec = _ExtendedEncoder().default(None)
    assert not dec


# Generated at 2022-06-23 16:45:15.873893
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test for single uppercase type
    field_override = FieldOverride("A", "B", "C")
    assert field_override.letter_case("hello") == "A"
    assert field_override.exclude("hello") == "B"
    assert field_override.encoder("hello") == "C"
    # test for camel case type
    field_override = FieldOverride("camel", "dromedary", "elephant")
    assert field_override.letter_case("hello") == "camel"
    assert field_override.exclude("hello") == "dromedary"
    assert field_override.encoder("hello") == "elephant"
    # test for snake case type
    field_override = FieldOverride("snake", "python", "rattle")
    assert field

# Generated at 2022-06-23 16:45:17.342963
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# noinspection PyProtectedMember

# Generated at 2022-06-23 16:45:22.891201
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Test the constructor of class FieldOverride
    """
    # All three arguments
    assert FieldOverride(False, None, None)
    # None and a function
    assert FieldOverride(False, lambda x: x, None)
    # Missing the second argument
    with pytest.raises(TypeError):
        assert FieldOverride(False, None)
    # Missing the third argument
    with pytest.raises(TypeError):
        assert FieldOverride(False)



# Generated at 2022-06-23 16:45:27.582898
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj = _ExtendedEncoder()
    assert obj.default({"a": 1}) == {"a": 1}
    assert obj.default([1, 2, 3]) == [1, 2, 3]
    assert obj.default(1) == 1
    assert obj.default(1.0) == 1.0
    assert obj.default(True) == True
    assert obj.default(None) == None



# Generated at 2022-06-23 16:45:30.161001
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder(indent=4).encode([1, 2, 3]) == '[\n    1,\n    2,\n    3\n]', \
        "Error encoder default method"



# Generated at 2022-06-23 16:45:41.394964
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert json.dumps([Decimal(1)], cls=_ExtendedEncoder) == '["1"]'
    assert json.dumps({Decimal(1): 1}, cls=_ExtendedEncoder) == '{"1": 1}'
    assert json.dumps(Decimal(1), cls=_ExtendedEncoder) == '1'
    assert json.dumps(datetime.now(timezone.utc),
                      cls=_ExtendedEncoder) == '{}'.format(datetime.now(timezone.utc).timestamp())

# Generated at 2022-06-23 16:45:49.773469
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEncoder().encode(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(UUID('8a4b4e89-6c9e-4e8b-bb71-3d3e2e3d46bc')) == '"8a4b4e89-6c9e-4e8b-bb71-3d3e2e3d46bc"'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '1583024583.238837'

# Generated at 2022-06-23 16:45:58.611578
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default(b'hello') == 'hello'
    assert encoder.default(True) is True
    assert encoder.default(None) is None

    # JSONEncoder.py uses repr() for datetime and UUID
    assert encoder.default(datetime(2018, 1, 1, 0, 0, 1)) == 1514764401.0

# Generated at 2022-06-23 16:46:02.400607
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(UUID('6bf98a6d-0eaf-11ea-8d71-362b9e155667')) == '6bf98a6d-0eaf-11ea-8d71-362b9e155667'


# Generated at 2022-06-23 16:46:12.429438
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Missing encoder
    f = FieldOverride(exclude=None,
                      letter_case=None,
                      encoder=None,
                      decoder=None)
    assert f.exclude == None
    assert f.letter_case == None
    assert f.encoder == None
    assert f.decoder == None
    # Missing decoder
    f = FieldOverride(exclude=None,
                      letter_case=None,
                      encoder=None,
                      decoder=None)
    assert f.exclude == None
    assert f.letter_case == None
    assert f.encoder == None
    assert f.decoder == None

# Generated at 2022-06-23 16:46:21.132814
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default('str')
    _ExtendedEncoder().default(123)
    _ExtendedEncoder().default(True)
    _ExtendedEncoder().default(list())
    _ExtendedEncoder().default(dict())
    _ExtendedEncoder().default(tuple())
    _ExtendedEncoder().default(set())
    # TODO: move test to functional test?
    _ExtendedEncoder().default(frozenset())
    _ExtendedEncoder().default(bytearray())
    _ExtendedEncoder().default(bytes())
    _ExtendedEncoder().default(memoryview())
    _ExtendedEncoder().default(object())
    _ExtendedEncoder().default(timezone.utc)
# END



# Generated at 2022-06-23 16:46:23.287534
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(1,2,3)
    assert field_override.letter_case == 1
    assert field_override.exclude == 2
    assert field_override.encoder == 3

# Generated at 2022-06-23 16:46:28.709440
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default([]) == []

    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'
    assert _ExtendedEncoder().default(cfg.LetterCase.CAMEL) == cf

# Generated at 2022-06-23 16:46:31.048852
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():   # noqa
    result = _ExtendedEncoder().encode([1, 2, 3])
    assert result == '''[1, 2, 3]'''



# Generated at 2022-06-23 16:46:41.720777
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([]) == []
    assert encoder.default({}) == {}
    assert encoder.default('abc') == 'abc'
    assert encoder.default(123) == 123
    assert encoder.default(123.4) == 123.4
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(None) == None
    assert encoder.default(datetime.now().replace(tzinfo=timezone.utc)) == datetime.now().replace(tzinfo=timezone.utc).timestamp()

# Generated at 2022-06-23 16:46:43.692940
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"sample": Decimal(0)}) == json.dumps({"sample": "0"})



# Generated at 2022-06-23 16:46:51.508299
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()

# Generated at 2022-06-23 16:47:02.916827
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    assert e.default([]) == []
    assert e.default(()) == []
    assert e.default({}) == {}
    assert e.default({'a': 'aa'}) == {'a': 'aa'}
    assert e.default(set()) == []
    assert e.default(frozenset()) == []
    assert e.default(datetime(2011, 1, 1, 0, 0, 0)) == 1293756800.0
    assert e.default(datetime(2011, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == 1293756800.0
    assert e.default(Decimal('1')) == '1'

# Generated at 2022-06-23 16:47:06.975893
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    exc = FieldOverride(exclude, None, None)
    assert exc.exclude is exclude
    assert exc.letter_case  is None
    assert exc.encoder is None
    assert exc.decoder is None
    assert isinstance(exc, FieldOverride)

# Generated at 2022-06-23 16:47:14.914761
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default("abc") == "abc"
    assert encoder.default(None) is None
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default([1, None, 3]) == [1, None, 3]

# Generated at 2022-06-23 16:47:22.186257
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _ExtendedEncoder().default(dict(a=1, b=2))
    _ExtendedEncoder().default([1, 2, 3])
    _ExtendedEncoder().default(UUID('0c7aee64-a060-4e31-8c6f-8ebb62c53dfd'))
    _ExtendedEncoder().default(datetime.now(timezone.utc))
    _ExtendedEncoder().default(Decimal(3.1415))
    _ExtendedEncoder().default(None)
    _ExtendedEncoder().default(False)
    _ExtendedEncoder().default(4)



# Generated at 2022-06-23 16:47:28.220117
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Basic types
    assert _ExtendedEncoder().default('hello') == 'hello'
    assert _ExtendedEncoder().default(123) == 123
    assert _ExtendedEncoder().default(12.3) == 12.3
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(None) == None
    # Collections
    assert _ExtendedEncoder().default(dict(a=1)) == dict(a=1)
    assert _ExtendedEncoder().default(list(range(5))) == list(range(5))
    # Named tuples
    nt_Point = namedtuple('Point', ['x', 'y'])
    point = nt_Point(x=1, y=2)

# Generated at 2022-06-23 16:47:35.084507
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    tup = ('', False, 'some_hook', True, str.lower, str.upper)
    field_override = FieldOverride(*tup)
    assert field_override.exclude == tup[1]
    assert field_override.letter_case == tup[3]
    assert field_override.encoder == tup[4]
    assert field_override.decoder == tup[5]


# Generated at 2022-06-23 16:47:40.199189
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    tz = datetime.now(timezone.utc).astimezone().tzinfo
    dt = datetime.fromtimestamp(1595311347.59069, tz=tz)
    test_data = [
        ("letter_case", [("lower", "lower"), ("snake_case", "snake_case"),
                         ("camelcase", "camelCase")]),
        ("exclude",
         [("exclude", lambda x: True if x else False)],
         ),
        ("encoder",
         [("encode_dt",
           datetime_adapter(encode_timestamp))],
         ),
        ("decoder",
         [("decode_dt",
           datetime_adapter(decode_timestamp))],
         ),
    ]

# Generated at 2022-06-23 16:47:43.962444
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # set up
    encoder = lambda x: x
    exclude = lambda x: False
    letter_case = lambda x: x

    # function under test
    foo = FieldOverride(encoder, exclude, letter_case)
    assert foo.encoder == encoder
    assert foo.exclude == exclude
    assert foo.letter_case == letter_case


# Generated at 2022-06-23 16:47:54.925258
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert encoder.default({'a': [{'b': [{'c': 3}]}]}) == {'a': [{'b': [{'c': 3}]}]}
    assert encoder.default(UUID('067e6162-3b6f-4ae2-a171-2470b63dff00')) == \
        '067e6162-3b6f-4ae2-a171-2470b63dff00'

# Generated at 2022-06-23 16:48:06.198284
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(['a']) == ['a']
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default(datetime(2000, 1, 1)) == 946684800.0
    assert encoder.default(datetime(2000, 1, 1, tzinfo=timezone(0))) == 946684800.0
    assert encoder.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'

# Generated at 2022-06-23 16:48:11.080564
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride()
    assert f.exclude is None
    assert f.letter_case is None
    assert f.encoder is None
    assert f.decoder is None
    f = FieldOverride(lambda x: True, default, default)
    assert f.exclude is not None
    assert f.letter_case is not None
    assert f.encoder is not None
    assert f.decoder is not None



# Generated at 2022-06-23 16:48:22.216937
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert e.default({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert e.default((1, 2)) == [1, 2]
    assert e.default([1, 2]) == [1, 2]
    assert e.default({"a": 1}) == {"a": 1}
    assert e.default("xyz") == '"xyz"'
    assert e.default(123) == 123
    assert e.default(1.23) == 1.23
    assert e.default(True) == True
    assert e.default(None) == None
    assert e.default(datetime(2018, 5, 11, 3, 34, 6, 999999, tzinfo=timezone.utc)) == 1526016446.999999
   

# Generated at 2022-06-23 16:48:25.513469
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Size of _ExtendedEncoder.default(...) changed from original.
    # But the code in default(...) was copied from the original.
    assert _ExtendedEncoder.default._code_.co_argcount == 2


# Generated at 2022-06-23 16:48:34.594040
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    le = _ExtendedEncoder().encode(list(range(10)))
    assert le == '[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]'

    le = _ExtendedEncoder().encode(tuple(range(10)))
    assert le == '[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]'

    le = _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3})
    assert le == '{"a": 1, "b": 2, "c": 3}'

    le = _ExtendedEncoder().encode(set(range(10)))
    assert le == '[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]'

    le_d = _ExtendedEncoder().encode

# Generated at 2022-06-23 16:48:40.181295
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert not _isinstance_safe(  # type: ignore
        _ExtendedEncoder().default([1, 2, 3]), list)
    assert _isinstance_safe(  # type: ignore
        _ExtendedEncoder().default([1, 2, 3]), Json)

_extended_encoder = _ExtendedEncoder(default=lambda o: o)
del _ExtendedEncoder



# Generated at 2022-06-23 16:48:42.121041
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride()
    assert field_override is not None


# Generated at 2022-06-23 16:48:44.317602
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    json_ = json.dumps([], cls=_ExtendedEncoder)
    assert isinstance(json_, str)



# Generated at 2022-06-23 16:48:45.558522
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj = _ExtendedEncoder()
    assert obj.default(datetime.now()) is not MISSING


# Generated at 2022-06-23 16:48:57.136919
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    actual = _ExtendedEncoder().default
    assert actual(list(range(5))) == list(range(5))
    assert actual(dict(a=1, b=2)) == dict(a=1, b=2)
    assert actual(True) == True
    assert actual(False) == False
    assert actual(1) == 1
    assert actual(1.0) == 1.0
    assert actual(1.0 + 1.0j) == [1.0, 1.0]
    assert actual(None) == None
    assert actual('hoge') == 'hoge'
    assert actual(datetime(2018, 4, 4, 0, 0, tzinfo=timezone.utc)) == 1522758400.0

# Generated at 2022-06-23 16:49:06.126919
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import dataclass
    from enum import IntEnum
    from uuid import uuid4
    from decimal import Decimal

    @dataclass
    class User:
        user_id: int

    @dataclass
    class Comment:
        user: User
        comment_id: int
        body: str

    @dataclass
    class Comment2:
        comment_id: int
        body: str

    @dataclass
    class Post:
        user: User
        post_id: int
        title: str
        body: str
        comments: Collection[Comment]
        likes: Collection[int]
        data: Mapping[str, Any]
        tags: Mapping[str, bool]

    @dataclass
    class Post2:
        user: User
        post_id: int


# Generated at 2022-06-23 16:49:15.639995
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(set()) == "[]"
    assert _ExtendedEncoder().encode(set((1,2,3))) == "[1,2,3]"
    assert _ExtendedEncoder().encode(dict(a=7)) == '{"a":7}'
    assert _ExtendedEncoder().encode(datetime(2017,5,5).timestamp()) == "1494010800.0"
    assert _ExtendedEncoder().encode(UUID('01234567-89ab-cdef-0123-456789abcdef')) == '"01234567-89ab-cdef-0123-456789abcdef"'

# Generated at 2022-06-23 16:49:17.102110
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ext_json.dumps(object(), cls=_ExtendedEncoder)


# Generated at 2022-06-23 16:49:25.460797
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(['foo', 'bar']) == ['foo', 'bar']
    assert _ExtendedEncoder().default(5) == 5
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default({'foo': 'bar'}) == {'foo': 'bar'}
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()

# Generated at 2022-06-23 16:49:37.368294
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == json.dumps([1, 2, 3])
    assert _ExtendedEncoder().encode({1: 2, 3: 4}) == json.dumps({1: 2, 3: 4})
    assert _ExtendedEncoder().encode(UUID('e2d1389a-4066-4c31-a6af-8c81aec1c9a9')) == json.dumps('e2d1389a-4066-4c31-a6af-8c81aec1c9a9')

# Generated at 2022-06-23 16:49:39.375351
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(Decimal('3.14')) == '3.14'


# Generated at 2022-06-23 16:49:48.658646
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default(UUID('01234567-89ab-cdef-0123-456789abcdef')) == '01234567-89ab-cdef-0123-456789abcdef'
    assert _ExtendedEncoder().default(Decimal(1.1)) == '1.1'
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default('a') == 'a'
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.1) == 1.1

# Generated at 2022-06-23 16:49:51.249275
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode((1, 2)) == '[1, 2]'



# Generated at 2022-06-23 16:49:57.850533
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'x': 1, 'y': 2, 'z': 3}) == '{"x": 1, "y": 2, "z": 3}'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000'))
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(1.2) == '1.2'


# Generated at 2022-06-23 16:50:08.133636
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    test_case = FieldOverride(exclude=lambda x: x == 0,
                              letter_case=lambda x: x.upper())
    assert test_case.is_excluded(0) is True
    assert test_case.is_excluded(1) is False
    assert test_case.is_excluded(None) is False
    assert test_case.is_excluded(True) is True
    assert test_case.is_excluded(False) is False
    assert test_case.is_excluded('') is True
    assert test_case.is_excluded('abc') is False
    assert test_case.is_excluded({}) is True
    assert test_case.is_excluded({1: 2}) is False
    assert test_case.letter_case('abc') == 'ABC'
    assert test_

# Generated at 2022-06-23 16:50:19.193094
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # test for all class in json.JSONEncoder.default
    from dataclasses import dataclass
    from dataclasses_json.utils import (SimpleNamespace,
                                        SimpleTypedNamespace)
    from datetime import date
    from uuid import uuid4
    from decimal import Decimal
    from enum import Enum as _Enum
    from operator import attrgetter

    T3 = _Enum('T3', 'a b')
    T3_a, T3_b = T3.a, T3.b
    T5 = get_type_hints(cfg)['mm_field']
    T6 = get_type_hints(cfg)['letter_case']
    T7 = get_type_hints(cfg)['exclude']

# Generated at 2022-06-23 16:50:26.673411
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Tests that the `FieldOverride` keyword arguments are set properly.
    """
    f = FieldOverride(exclude=None, letter_case=None, encoder=None, decoder=None)
    assert f.exclude is None
    assert f.letter_case is None
    assert f.encoder is None
    assert f.decoder is None
    assert f.mm_field is None

    f = FieldOverride(exclude=lambda x: True, letter_case=lambda x: x.upper())
    assert f.exclude(None) is True
    assert f.letter_case('foo') == 'FOO'
    assert f.encoder is None
    assert f.decoder is None
    assert f.mm_field is None


# Generated at 2022-06-23 16:50:37.996623
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime(2020, 1, 29, 1, 2, 3, 0, timezone(timedelta(hours=1)))) == 1580349723.0
    assert encoder.default(datetime(2020, 1, 29, 1, 2, 3, 0)) == 1580349723.0
    assert encoder.default(UUID('39f14bef-46b8-4d5d-8569-6e527f9a4ee4')) == '39f14bef-46b8-4d5d-8569-6e527f9a4ee4'
    assert encoder.default(Decimal('1234567890.0123456789')) == '1234567890.0123456789'
    assert enc

# Generated at 2022-06-23 16:50:39.454485
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = {'a': 1, 'b': [1, 3, 4]}
    print(json.dumps(o, cls=_ExtendedEncoder))



# Generated at 2022-06-23 16:50:49.810739
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():  # noqa: E302,E501
    encoder = _ExtendedEncoder()
    assert encoder.default(set) == set
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default((x for x in (1, 2, 3))) == [1, 2, 3]
    assert encoder.default([]) == []
    assert encoder.default(frozenset([1, 2, 3])) == [1, 2, 3]
    assert encoder.default({1, 2, 3}) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder

# Generated at 2022-06-23 16:50:55.477143
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(letter_case='capitalize', exclude=None, encoder=None, decoder=None)
    assert field_override.letter_case == 'capitalize'
    assert field_override.exclude is None
    assert field_override.encoder is None
    assert field_override.decoder is None



# Generated at 2022-06-23 16:51:04.803926
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(123) == 123
    assert _ExtendedEncoder().default(datetime(2020, 1, 1, 0, 0, 0, 0)) == 1577836800.0
    assert _ExtendedEncoder().default(UUID('123e4567-e89b-12d3-a456-426614174000')) == '123e4567-e89b-12d3-a456-426614174000'
    assert _ExtendedEncoder().default(Decimal('1.23')) == '1.23'
    assert _ExtendedEncoder().default(Decimal('-1.23')) == '-1.23'
test__ExtendedEncoder_default()


# Generated at 2022-06-23 16:51:15.895670
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(123) == 123
    assert _ExtendedEncoder().default(Decimal('1.23')) == '1.23'
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc)) == 0
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, 0, 0, 0, 1, tzinfo=timezone.utc)) == 1e-06
    assert _ExtendedEncoder().default((1,2,3)) == [1,2,3]
    assert _ExtendedEncoder().default({1:2}) == {1:2}

# Generated at 2022-06-23 16:51:24.821475
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    t1 = datetime.now(timezone.utc)
    t1_json = json.dumps(t1)
    t2 = datetime.fromtimestamp(json.loads(t1_json), timezone.utc)

    # assert  t1 == t2
    assert  t1.timestamp() == t2.timestamp()



# Generated at 2022-06-23 16:51:38.234281
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import decimal, enum
    from datetime import date
    from uuid import UUID, uuid4

    from dataclasses import dataclass, field
    from dataclasses_json.mm_field import mm_field

    @dataclass
    class Descendant:
        string: str

    @dataclass
    class Child:
        d1: Descendant
        d2: Descendant = field(metadata=mm_field(encode=False))
        d3: Descendant = field(metadata=mm_field(encode=False, decoder_module='descendant_decoder.module'))

    @dataclass
    class Custom:
        string: str
        int: int
        uuid: UUID
        datetime: datetime
        timezone: timezone
        date: date
        boolean: bool

# Generated at 2022-06-23 16:51:51.144372
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime(2017, 1, 2, 3, 4, 5)) == 1483447445.0
    assert _ExtendedEncoder().default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().default(Decimal('12.344')) == '12.344'
    assert _ExtendedEncoder().default(cfg.NaN(Decimal('12.344'))) == 'NaN'
    assert _ExtendedEncoder().default({1:2}) == {1:2}
    assert _ExtendedEncoder().default([1,2]) == [1,2]
    assert _ExtendedEncoder().default(cfg.Infinity(1)) == 'Infinity'
    assert _ExtendedEncoder

# Generated at 2022-06-23 16:52:01.568993
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder(ensure_ascii=True, indent=2).encode(
            {'4': 4, 'list': [1, 2, 3], 'datetime': datetime.now(timezone.utc), 'uuid': UUID('01234567-89ab-cdef-0123-456789abcdef')}) == '''{
  "4": 4,
  "list": [
    1,
    2,
    3
  ],
  "datetime": 0.0,
  "uuid": "01234567-89ab-cdef-0123-456789abcdef"
}'''



# Generated at 2022-06-23 16:52:04.864803
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(list()) == '[]'
    assert _ExtendedEncoder().encode(dict()) == '{}'
    assert _ExtendedEncoder().encode(1) == '1'



# Generated at 2022-06-23 16:52:14.680234
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert_equal(_ExtendedEncoder().default(
        [1, 2, 3]), [1, 2, 3])
    assert_equal(_ExtendedEncoder().default(
        {'a': 1, 'b': 2}), {'a': 1, 'b': 2})
    assert_equal(_ExtendedEncoder().default(
        datetime.now(timezone.utc)),
        datetime.now(timezone.utc).timestamp())
    assert_equal(_ExtendedEncoder().default(
        UUID('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11')), 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11')

# Generated at 2022-06-23 16:52:23.688250
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # GIVEN
    d = datetime(2019, 1, 1)
    u = UUID('8f8a8b86-acd5-49e2-8e38-9ea931d23c06')
    dc = Decimal('12.34')
    enum = Enum(value='test', names='test')
    li = [d, u, dc, enum]
    dic = {'date': d, 'uuid': u, 'dec': dc, 'enum': enum}
    set_a = {d, u, dc, enum}
    tc = _ExtendedEncoder()

    # WHEN
    result = tc.default(li)

    # THEN

# Generated at 2022-06-23 16:52:32.616943
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default("abc") == "abc"
    assert encoder.default(123) == 123
    assert encoder.default(1.23) == 1.23
    # for bools True and False, the result is the same
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(None) == None

    assert encoder.default(b"abc") == "abc"
    assert encoder.default(bytearray(b"abc")) == "yWJj"
    assert encoder.default(bytearray(range(10))) == "AAECAwQFBgcICQ=="
    dt = datetime.now(tz=timezone.utc)

# Generated at 2022-06-23 16:52:37.101730
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc))
    assert _ExtendedEncoder().default(UUID('123e4567-e89b-12d3-a456-426655440000'))
    assert _ExtendedEncoder().default(cfg.Foo)


# Generated at 2022-06-23 16:52:46.397973
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda x: x
    decoder = lambda x: x
    exclude = lambda x: False
    letter_case = lambda x: x
    field_override = FieldOverride(exclude, encoder, decoder, letter_case)
    assert field_override.exclude == exclude
    assert field_override.encoder == encoder
    assert field_override.decoder == decoder
    assert field_override.letter_case == letter_case


# Generated at 2022-06-23 16:52:59.943502
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(range(10)) == list(range(10))
    assert encoder.default({"foo": "bar"}) == {"foo": "bar"}
    assert encoder.default(dict({"foo": "bar"})) == {"foo": "bar"}
    assert encoder.default(datetime.utcnow().replace(tzinfo=timezone.utc)) == \
           datetime.utcnow().replace(tzinfo=timezone.utc).timestamp()

# Generated at 2022-06-23 16:53:12.918879
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from pytest import raises

    enc = _ExtendedEncoder()
    assert enc.default(1) == 1
    assert enc.default(float(1)) == 1.0
    assert enc.default(None) is None
    assert enc.default(True) is True
    assert enc.default(False) is False
    assert enc.default('2019-07-03T12:15:00') == '2019-07-03T12:15:00'
    assert enc.default('2019-07-03T12:15:00Z') == '2019-07-03T12:15:00Z'
    assert enc.default({}) == {}
    assert enc.default([1, 2, 3]) == [1, 2, 3]
    assert enc.default(set([1, 2, 3])) == [1, 2, 3]


# Generated at 2022-06-23 16:53:22.192220
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    data = {'a': 1, 'b': 2}
    assert encoder.default(data) == data
    assert encoder.default(1) == 1
    assert encoder.default('a') == 'a'
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    dt = datetime.now()
    assert encoder.default(dt) == dt.timestamp()
    assert encoder.default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert encoder.default(Decimal('10.1')) == '10.1'


# Generated at 2022-06-23 16:53:30.696036
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Arrange
    data = [
        1, 2.3, False, True, None, [1, 2, 3], {'a': 1, 'b': 2},
        [1, 2.3, False, True, None, [1, 2, 3], {'a': 1, 'b': 2}],
        {'a': 1, 'b': 2, 'c': [1, 2, 3], 'd': {'a': 1, 'b': 2}},
        datetime(2020, 1, 1, tzinfo=timezone.utc),
        UUID('3c83e0a3-5f5c-4d53-a5a2-e2c7d789ad2c'),
        Decimal('1.23'),
        Enum('A', 'B C')('B')
    ]


# Generated at 2022-06-23 16:53:38.191326
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    obj = _ExtendedEncoder().default
    assert obj([1, 2, 3]).__class__ is list
    assert obj({'a': 1, 'b': 2}).__class__ is dict
    assert obj('test').__class__ is str
    assert obj(1).__class__ is int
    assert obj(1.1).__class__ is float
    assert obj(True).__class__ is bool
    assert obj(None) is None
    assert obj(Decimal('1.1')).__class__ is str



# Generated at 2022-06-23 16:53:47.934037
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == []
    assert encoder.default(frozenset()) == []
    assert encoder.default(dict()) == {}
    assert encoder.default(list()) == []
    assert encoder.default(tuple()) == []
    assert encoder.default(1) == 1
    assert encoder.default('abc') == 'abc'
    assert encoder.default(True) == True
    assert encoder.default(None) is None
    assert encoder.default(set(list())) == []
    assert encoder.default(frozenset(list())) == []
    assert encoder.default(dict(list())) == {}
    assert encoder.default(list(list())) == []

# Generated at 2022-06-23 16:53:58.777109
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(set([])) == []
    assert _ExtendedEncoder().default(frozenset([])) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(0.) == 0.
    assert _ExtendedEncoder().default(1.) == 1.
    assert _ExtendedEncoder().default('1') == '1'
    assert _ExtendedEncoder().default(datetime(2000, 1, 1, 10, 10, tzinfo=timezone.utc)) == 946682200.0


# Generated at 2022-06-23 16:54:10.836868
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None  # noqa: S101
    assert encoder.default(1) == 1  # noqa: S101
    assert encoder.default(True) is True  # noqa: S101
    assert encoder.default(False) is False  # noqa: S101
    assert encoder.default(1.2) == 1.2  # noqa: S101
    assert encoder.default(1 + 2j) == [1, 2]  # noqa: S101
    assert encoder.default(1.2e2) == 1.2e2  # noqa: S101
    assert encoder.default('föo') == 'föo'  # noqa: S101

# Generated at 2022-06-23 16:54:19.925352
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(set([1, 2, 3])).replace(" ", "") == '[1,2,3]'
    assert _ExtendedEncoder().encode(frozenset([1, 2, 3])).replace(" ", "") == '[1,2,3]'
    assert _ExtendedEncoder().encode({1: 'a', 2: 'b'}).replace(" ", "") == '{"1":"a","2":"b"}'
    assert _ExtendedEncoder().encode(datetime(2020, 12, 25, 19, 10, 10)).replace(" ", "") == '1609043810.0'

# Generated at 2022-06-23 16:54:31.144048
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Test constructor of class FieldOverride
    """
    field_override = FieldOverride(exclude=lambda x: x is None, letter_case=str.lower, mm_field=str, encoder=str, decoder=str)
    try:
        assert field_override is not None
        assert field_override.exclude(None)
        assert field_override.exclude(False)
        assert not field_override.exclude(0)
        assert field_override.letter_case("TEST") == "test"
        assert field_override.mm_field == str
        assert field_override.encoder == str
        assert field_override.decoder == str
    except AssertionError as e:
        pytest.fail(f"test_FieldOverride(): {e}")

# Generated at 2022-06-23 16:54:41.247368
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test field_override.decoder
    @decoder(int)
    def decode_int(value):
        return int(value)

    @decoder(str)
    def decode_str(value):
        return str(value)

    field_override = FieldOverride(
        decoder=decode_int)

    assert field_override.decoder(4) == 4
    assert field_override.decoder('4') == 4

    field_override = FieldOverride(
        decoder=decode_str)

    assert field_override.decoder(4) == '4'
    assert field_override.decoder('4') == '4'
    # Test field_override.encoder
    @encoder(int)
    def encode_int(value):
        return int(value)

   

# Generated at 2022-06-23 16:54:50.678631
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(UUID("6e8bc430-9c3a-11d9-9669-0800200c9a66")) == "6e8bc430-9c3a-11d9-9669-0800200c9a66"
    assert encoder.default(datetime(2010, 10, 10, 0, 0, 0)) == 1286310400.0
    assert encoder.default(bool(True)) == True
    assert encoder.default(Decimal('10')) == "10"



# Generated at 2022-06-23 16:54:57.507862
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    a_type_str = "A Type String"
    an_int = 123
    a_bool = True

    a1 = FieldOverride(a_type_str, an_int, a_bool)
    assert a1.letter_case == a_type_str
    assert a1.decoder == an_int
    assert a1.exclude == a_bool

    a2 = FieldOverride(letter_case=a_type_str, decoder=an_int, exclude=a_bool)
    assert a1 == a2
    assert a1.__dict__ == a2.__dict__

    a3 = FieldOverride(letter_case=a_type_str)
    assert a3.letter_case == a_type_str
    assert a3.decoder is None
    assert a3.exclude is None

    a4

# Generated at 2022-06-23 16:55:08.271969
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import dataclasses
    @dataclasses.dataclass()
    class DC(object):
        x: int
    assert _ExtendedEncoder().encode(DC(x=1)) == '{"x": 1}'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode((1, 2)) == '[1, 2]'
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode(set([1, 2])) == '[1, 2]'
    assert _ExtendedEncoder().encode({1, 2}) == '[1, 2]'
    assert _ExtendedEncoder().encode