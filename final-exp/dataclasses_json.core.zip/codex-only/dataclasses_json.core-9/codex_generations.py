

# Generated at 2022-06-23 16:45:05.455182
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # type: () -> None
    import datetime
    import json
    import pytest
    import dataclasses

    @dataclasses.dataclass
    class O(object):
        m: str = 'test'

    @dataclasses.dataclass
    class N(object):
        o: O = O()

    @dataclasses.dataclass
    class I(object):
        f: float = 1.0
        n: N = N()

    @dataclasses.dataclass
    class E(object):
        i: int = 1
        s: str = 'test'
        a: Collection[int] = dataclasses.field(
            default_factory=lambda: [1, 2, 3, 4]
        )

# Generated at 2022-06-23 16:45:13.639676
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(set()) == '[]'
    assert json.dumps(set(), cls=_ExtendedEncoder) == '{}'
    assert json.dumps(frozenset()) == '[]'
    assert json.dumps(frozenset(), cls=_ExtendedEncoder) == '[]'
    assert json.dumps(Decimal('1.1')) == '{}'
    assert json.dumps(Decimal('1.1'), cls=_ExtendedEncoder) == '"1.1"'


# Generated at 2022-06-23 16:45:23.337462
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default(): # noqa: E302
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default(1.1) == 1.1
    assert encoder.default(True) is True
    assert encoder.default(None) is None
    assert encoder.default('') == ''
    assert encoder.default([]) == []
    assert encoder.default({}) == {}
    assert encoder.default(set()) == []
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(()) == []
    assert encoder.default((1, 2, 3)) == [1, 2, 3]

# Generated at 2022-06-23 16:45:27.573120
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    obj = FieldOverride(exclude=lambda x: x == "abc", letter_case=str.upper,
                        encoder=lambda x: x * 2)
    assert obj.exclude("abc") == True
    assert obj.letter_case("abc") == "ABC"
    assert obj.encoder("abc") == "abcabc"


# Generated at 2022-06-23 16:45:31.254438
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from .utils import _is_dataclass

    assert _is_dataclass(json.JSONEncoder)
    assert _is_dataclass(_ExtendedEncoder)

    # noinspection PyAbstractClass
    class Sub(_ExtendedEncoder):
        def default(self, o) -> Json:
            return 10

    assert Sub(sort_keys=True).encode([1, 2, 3]) == '[10, 10, 10]'



# Generated at 2022-06-23 16:45:41.671679
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder(indent=2)
    dt = datetime(2017, 2, 5, 2, 36, 45, 536000)
    dt_tz = datetime(2017, 2, 5, 2, 36, 45, 536000, timezone.utc)
    e = UUID('{01234567-89ab-cdef-0123456789ab}')
    dec = Decimal('0.1')

# Generated at 2022-06-23 16:45:49.992309
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        j = _ExtendedEncoder().encode({"1": [1, 3, [2, 3, 4], {'u': 'v'}]})
    assert j == '{"1": [1, 3, [2, 3, 4], {"u": "v"}]}'
    assert _ExtendedEncoder().encode(datetime(day=1, month=2, year=2000)) == '946684800.0'
    assert _ExtendedEncoder().encode(UUID('d63c4547-0025-49a0-8a41-b7c76ac28af9')) == '"d63c4547-0025-49a0-8a41-b7c76ac28af9"'
    assert _ExtendedEnc

# Generated at 2022-06-23 16:45:58.773284
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default(1) == 1
    assert enc.default([1, 2, 3]) == [1, 2, 3]
    assert enc.default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert enc.default(None) is None
    assert enc.default(True) is True
    assert enc.default(False) is False
    assert enc.default(0.0) == 0.0
    assert enc.default(0.5) == 0.5
    assert enc.default(-0.5) == -0.5
    assert enc.default(1.2e-5) == 1.2e-5
    assert enc.default(-1.2e-5) == -1.2e-5

# Generated at 2022-06-23 16:46:10.784918
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ee = _ExtendedEncoder()
    assert ee.default(1) == 1
    assert ee.default('1') == '1'
    assert ee.default(['1']) == ['1']
    assert ee.default(b'1') == '1'
    assert ee.default(bytearray(b'1')) == ['1']
    assert ee.default(Enum('Foo', {'foo': 'bar'})) == 'bar'

    assert ee.default(datetime(2018, 1, 1, 1, 0, 0)) == 1514764800.0
    assert ee.default(datetime(2018, 1, 1, 1, 0, 0, tzinfo=timezone.utc)) == 1514764800.0


# Generated at 2022-06-23 16:46:20.198868
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Arrange
    ext_encoder = _ExtendedEncoder()
    test_model = DataClassMapping()
    test_model.dict_attr = {'a': 1, 'b': 2}
    test_model.list_attr = [1, 2, 3]
    test_model.string_attr = 'string_attr_value'
    test_model.dict_attr_with_type = {'c': 3, 'd': 4}
    test_model.list_attr_with_type = [4, 5]

    # Act
    res = ext_encoder.default(test_model)

    # Assert
    assert res['dict_attr'] == {'a': 1, 'b': 2}
    assert res['list_attr'] == [1, 2, 3]

# Generated at 2022-06-23 16:46:26.947659
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default({}) == {}
    assert encoder.default([]) == []
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default("1") == "1"
    assert encoder.default(UUID("9a6fc7a2-e74f-47a6-a89f-1fd6fd68a6a1")) == "9a6fc7a2-e74f-47a6-a89f-1fd6fd68a6a1"
    assert encoder.default(datetime(2019, 11, 6, tzinfo=timezone.utc)) == 1573020800.0


_types = (
    set,
    frozenset,
)

# Generated at 2022-06-23 16:46:36.923723
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    conf_default = FieldOverride()
    assert conf_default.letter_case is None
    assert conf_default.encoder is None
    assert conf_default.exclude is None
    assert conf_default.mm_field is None

    conf_default_letter_case = FieldOverride(letter_case=camelcase)
    assert conf_default_letter_case.letter_case == camelcase
    assert conf_default_letter_case.encoder is None
    assert conf_default_letter_case.exclude is None
    assert conf_default_letter_case.mm_field is None

    conf_default_encoder = FieldOverride(encoder=camelcase)
    assert conf_default_encoder.letter_case is None
    assert conf_default_encoder.encoder == camelcase
    assert conf_default_encoder.exclude

# Generated at 2022-06-23 16:46:45.823932
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import pytest

    json_str = '{"a": 1, "b": "bbb", "c": {"cc": "ccc"}}'
    json_dict = {"a": 1, "b": "bbb", "c": {"cc": "ccc"}}
    json_list = [{"a": 1, "b": "bbb", "c": {"cc": "ccc"}}]

    encoder = _ExtendedEncoder()

    assert json_str == encoder.encode(json_dict)
    assert json_str == encoder.encode(json_list)

    with pytest.raises(TypeError):
        encoder.default(datetime.now())



# Generated at 2022-06-23 16:46:49.119008
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(False, lambda x: x, lambda x: x)
    assert field_override.exclude == False
    assert field_override.encoder(None) is None
    assert field_override.decoder(None) is None

# Generated at 2022-06-23 16:46:54.721654
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(42) == 42
    assert _ExtendedEncoder().default(timezone.utc) == 'UTC'
    assert _ExtendedEncoder().default({1: [2, 3, 4]}) == {1: [2, 3, 4]}
    assert _ExtendedEncoder().default([1, 2, 3, 4]) == [1, 2, 3, 4]


# Generated at 2022-06-23 16:47:05.046198
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Test to verify constructor is working correctly
    """
    overrides = FieldOverride()
    assert overrides.decoder is None
    assert overrides.encoder is None
    assert overrides.exclude is None
    assert overrides.letter_case is None

    override = FieldOverride(decoder=lambda x: x,
                             encoder=lambda x: x,
                             exclude=lambda obj: obj is not None,
                             letter_case=lambda x: x.upper())
    assert override.decoder is not None
    assert override.encoder is not None
    assert override.exclude is not None
    assert override.letter_case is not None
    assert override.letter_case("lower") == "LOWER"


test_FieldOverride()

# Generated at 2022-06-23 16:47:07.841008
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(exclude=None, encoder=None, decoder=None,
                       letter_case=None)
    assert fo.exclude is None
    assert fo.encoder is None
    assert fo.decoder is None
    assert fo.letter_case is None



# Generated at 2022-06-23 16:47:13.051443
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = json.dumps(12.35, cls=_ExtendedEncoder)
    assert result == '12.35'
    result = json.dumps([1, 2, 3], cls=_ExtendedEncoder)
    assert result == '[1, 2, 3]'
    result = json.dumps({'a': 1, 'b': 2}, cls=_ExtendedEncoder)
    assert result == '{"a": 1, "b": 2}'
    result = json.dumps(datetime(1970, 1, 1), cls=_ExtendedEncoder)
    assert result == '0.0'
    result = json.dumps(UUID('c9bf9e57-1685-4c89-bafb-ff5af830be8a'), cls=_ExtendedEncoder)

# Generated at 2022-06-23 16:47:19.977853
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(
        letter_case="snake_case",
        exclude=lambda x: x == "",
        encoder=lambda x: "encoded",
        decoder=lambda x: "decoded",
        mm_field="MM_FIELD"
    )
    assert field_override.letter_case == "snake_case"
    assert field_override.exclude(0) == False
    assert field_override.encoder("not encoded") == "encoded"
    assert field_override.decoder("not decoded") == "decoded"
    assert field_override.mm_field == "MM_FIELD"


# Generated at 2022-06-23 16:47:23.561789
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    json.dumps([1, 2, 3, "ab"], cls=_ExtendedEncoder)



# Generated at 2022-06-23 16:47:31.851420
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    """Unit test for method default of class _ExtendedEncoder."""
    encoder = _ExtendedEncoder(indent=2, sort_keys=True)
    dt = datetime(2020, 7, 21, tzinfo=timezone.utc)
    dec = Decimal('1.2')
    assert encoder.default(dt) == dt.timestamp()
    assert encoder.default(dec) == dec.to_eng_string()
    assert encoder.default(set()) == list(set())
    assert encoder.default(frozenset()) == list(frozenset())
    assert encoder.default({}) == dict({})
    assert encoder.default(()) == list(())
    assert encoder.default(list()) == list()
    assert encoder.default(1) == 1

# Generated at 2022-06-23 16:47:40.122602
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import asdict
    from uuid import uuid4
    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json.utils import dataclass_json_config

    @dataclass_json_config(letter_case=LetterCase.CAMEL)
    @dataclass
    class Test(DataClassJsonMixin):
        lst: list
        dct: dict
        uuid: UUID

    ret = Test(lst=[1, 2, 3], dct={'a': 1}, uuid=uuid4())

    assert asdict(ret) == json.loads(json.dumps(ret, cls=_ExtendedEncoder))



# Generated at 2022-06-23 16:47:41.679504
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    obj = _ExtendedEncoder.default(None, cfg.NaT)
    assert obj == 'null'


# Generated at 2022-06-23 16:47:49.387849
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert json.loads(_ExtendedEncoder().encode(datetime(1970, 1, 1))) == 0
    assert json.loads(_ExtendedEncoder().encode(datetime(1970, 1, 1, tzinfo=timezone.utc))) == 0
    assert json.loads(_ExtendedEncoder().encode(Decimal('1.1'))) == '1.1'
    assert json.loads(_ExtendedEncoder().encode(UUID('9ece8198-b8d1-4e65-a2c0-f7cabdccb177'))) == '9ece8198-b8d1-4e65-a2c0-f7cabdccb177'


# Generated at 2022-06-23 16:47:57.676484
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # TypeError: Object of type set is not JSON serializable
    # json.dumps(set(), cls=_ExtendedEncoder)
    assert json.dumps([set()], cls=_ExtendedEncoder) == '[[]]'
    assert json.dumps({set(): 123}, cls=_ExtendedEncoder) == '{}'
    assert json.dumps({set(): [123]}, cls=_ExtendedEncoder) == '{}'
    assert json.dumps({123: set()}, cls=_ExtendedEncoder) == '{}'
    assert json.dumps([123, {'k': set()}], cls=_ExtendedEncoder) == '[123, {}]'

# Generated at 2022-06-23 16:48:07.589589
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import dataclass
    from enum import Enum
    from decimal import Decimal
    from uuid import uuid4
    from typing import List, Optional, Tuple, Union
    import datetime
    # noinspection PyProtectedMember
    from dataclasses_json._types import datetime_to_dto
    from dataclasses_json import DataClassJsonMixin

    # FIXME: Make tests for JSONDecoder.decode
    class CustomType(object):
        def __init__(self, val, a=None):
            self.val = val
            self.a = a
        def __eq__(self, other):
            if not isinstance(other, CustomType):
                return False
            return self.val == other.val and self.a == other.a

    # noinspection PyTypeCheck

# Generated at 2022-06-23 16:48:16.314343
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Ensure datetime is converted to timestamp
    d: datetime = datetime(2019, 1, 1, 0, 0, 0, 0, tzinfo=timezone.utc)
    assert _ExtendedEncoder().default(d) == 1546300800.0

    # Ensure Enum is converted to value
    class Days(Enum):
        Mon = 0
        Tues = 1
        Wed = 2
    day: Days = Days.Mon
    assert _ExtendedEncoder().default(day) == 0

    # Ensure Decimal is converted to string
    assert _ExtendedEncoder().default(Decimal('12.34')) == '12.34'

    # Ensure dataclass is handled fine
    @dataclass
    class Test:
        a: datetime
        b: Days
        c: Decimal

# Generated at 2022-06-23 16:48:20.287020
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()



# Generated at 2022-06-23 16:48:30.097103
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == "[1, 2, 3]"
    assert _ExtendedEncoder().encode({1: 2}) == '{"1": 2}'
    assert _ExtendedEncoder().encode(
        datetime(2020, 1, 1, tzinfo=timezone.utc)) == '1577836800.0'
    assert _ExtendedEncoder().encode(UUID('b4c4b3a4-656e-4ed5-a44a-7b74e48d0e54')) == '"b4c4b3a4-656e-4ed5-a44a-7b74e48d0e54"'

# Generated at 2022-06-23 16:48:41.779572
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([]) == []
    assert encoder.default({}) == {}
    assert encoder.default(datetime.fromtimestamp(0, timezone.utc)) == 0.0
    assert encoder.default(UUID(int=0)) == '00000000-0000-0000-0000-000000000000'
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(None) == None
    assert encoder.default(0) == 0
    assert encoder.default(0.0) == 0.0
    assert encoder.default(()) == ()
    assert encoder.default(set()) == set()
    assert encoder.default('abc') == 'abc'



# Generated at 2022-06-23 16:48:45.109358
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder_test = _ExtendedEncoder(indent=4)
    from datetime import datetime
    from decimal import Decimal
    from uuid import UUID
    from enum import Enum

    class TestEnum(Enum):
        test_one = 1
        test_two = 2

    list_test = ['list_test1', 'list_test2', 'list_test3']
    dict_test = {'dict_test1': '1', 'dict_test2': '2', 'dict_test3': '3'}
    datetime_test = datetime.now().replace(tzinfo=timezone.utc)
    uuid_test = UUID('123e4567-e89b-12d3-a456-426655440000')
    decimal_test = Decimal('101.01')


# Generated at 2022-06-23 16:48:56.131974
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class MyObj(dataclass):
        x: Union[str, int]
        y: UUID

    field_override = FieldOverride(letter_case='upper', mm_field='uuid')
    assert field_override.mm_field == 'uuid'
    assert field_override.letter_case == 'upper'
    assert field_override.decoder is None
    assert field_override.encoder is None
    assert field_override.exclude is None
    assert field_override == FieldOverride(mm_field='uuid',
                                           letter_case='upper')
    assert field_override != FieldOverride(exclude=lambda x: x is None)
    assert str(field_override) == ("FieldOverride(letter_case='upper', "
                                   "mm_field='uuid')")


# Generated at 2022-06-23 16:49:00.636126
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride('exclude', 'letter_case', 'encoder', 'decoder')
    assert f.exclude == 'exclude'
    assert f.letter_case == 'letter_case'
    assert f.encoder == 'encoder'
    assert f.decoder == 'decoder'

# Generated at 2022-06-23 16:49:05.018929
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # type: () -> None
    assert _ExtendedEncoder().encode({'a': 1, 'b': None, 'c': '3'}) == '{"a": 1, "b": null, "c": "3"}'



# Generated at 2022-06-23 16:49:14.888662
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride()
    assert f.exclude is None
    assert f.encoder is None
    assert f.decoder is None
    assert f.letter_case is None
    assert f.mm_field is None

    # Only set __args__
    f = FieldOverride("foo")
    assert f.exclude is None
    assert f.encoder is None
    assert f.decoder is None
    assert f.letter_case is None
    assert f.mm_field is None

    # Set exclude and __args__
    f = FieldOverride("foo", exclude=lambda x: True)
    assert f.exclude(0)

    # Set encoder, __args__ and exclude
    f = FieldOverride("foo", exclude=lambda x: True, encoder=lambda x: 2 * x)

# Generated at 2022-06-23 16:49:19.416197
# Unit test for constructor of class FieldOverride
def test_FieldOverride():

    expected = {'encoder': 'encoder', 'decoder': 'decoder',
                'exclude': 'exclude', 'letter_case': 'letter_case'}
    assert FieldOverride(exclude='exclude',
                         letter_case='letter_case',
                         encoder='encoder',
                         decoder='decoder') == expected

# Generated at 2022-06-23 16:49:26.922988
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.default(5) == 5
    assert extended_encoder.default([1, 2]) == [1, 2]
    assert extended_encoder.default(['a', 1]) == ['a', 1]
    assert extended_encoder.default(datetime(2010, 1, 1, 12, 0, 0)) == \
        datetime(2010, 1, 1, 12, 0, 0).timestamp()
    uuid = UUID(int=1)
    assert extended_encoder.default(uuid) == str(uuid)
    assert extended_encoder.default(Decimal('1.1')) == '1.1'
    assert extended_encoder.default({'key': 'value'}) == \
        {'key': 'value'}


# Generated at 2022-06-23 16:49:34.422949
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    overrides = _user_overrides_or_exts(BlockHeader)
    # A FieldOverride is created
    assert isinstance(overrides[0][1], FieldOverride)
    # Attributes are set as expected
    assert overrides[0][1].exclude is None
    assert overrides[0][1].encoder is None
    assert overrides[0][1].letter_case is None


# Generated at 2022-06-23 16:49:46.049296
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(datetime(2020, 1, 1), cls=_ExtendedEncoder) == '15778368'
    assert json.dumps(datetime(2020, 1, 1, tzinfo=timezone.utc), cls=_ExtendedEncoder) == '1577836800'
    assert json.dumps(UUID('12345678123456781234567812345678'), cls=_ExtendedEncoder) == '"12345678-1234-5678-1234-567812345678"'
    assert json.dumps(Decimal(0.5), cls=_ExtendedEncoder) == '"0.5"'
    assert json.dumps(frozenset([1, 2]), cls=_ExtendedEncoder) == '[1, 2]'
    assert json.dumps

# Generated at 2022-06-23 16:49:58.384096
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test for int/float/string
    assert json.dumps(10, cls=_ExtendedEncoder) == '10'
    assert json.dumps(10.5, cls=_ExtendedEncoder) == '10.5'
    assert json.dumps("test", cls=_ExtendedEncoder) == '"test"'

    # Test for list/dict
    assert json.dumps([1, 2, 3], cls=_ExtendedEncoder) == '[1, 2, 3]'
    assert json.dumps({'a': 1, 'b': 2}, cls=_ExtendedEncoder) == '{"a": 1, "b": 2}'

    # Test for datetime
    dt = datetime(2020, 7, 4, 13, 22, tzinfo=timezone.utc)
   

# Generated at 2022-06-23 16:50:07.695731
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test constructor with equal default values used
    assert (FieldOverride(exclude=lambda _: False,
                          letter_case=str.upper,
                          encoder=lambda _: _,
                          decoder=lambda _: _,
                          mm_field=lambda _: _)
            == FieldOverride())

    # Test constructor with different default values used

# Generated at 2022-06-23 16:50:17.912530
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Set up test data
    e = _ExtendedEncoder()
    obj = {
        'a': 1,
        'b': 'b',
        'c': datetime.now(timezone.utc),
        'd': UUID('dee82c34-0591-4ca9-b06a-b6a58e4552de'),
        'e': 1
    }

    # Perform the test
    result = e.default(obj)

    # Check the result
    assert result == {'a': 1, 'b': 'b', 'c': obj['c'].timestamp(), 'd': 'dee82c34-0591-4ca9-b06a-b6a58e4552de', 'e': 1}



# Generated at 2022-06-23 16:50:21.245920
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # pylint: disable=C0103
    o = cfg.CustomDatetime(datetime.now(timezone.utc))
    _ExtendedEncoder().encode(o)


# Generated at 2022-06-23 16:50:32.548119
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == list(set())
    assert encoder.default(frozenset()) == list(frozenset())
    assert encoder.default(()) == list(())
    assert encoder.default(tuple()) == list(tuple())
    assert encoder.default({}) == dict({})
    assert encoder.default(dict()) == dict({})
    assert encoder.default([]) == list([])
    assert encoder.default(list()) == list([])
    assert encoder.default(datetime.utcnow()) == datetime.utcnow().timestamp()

# Generated at 2022-06-23 16:50:43.229221
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class A:
        pass
    class B:
        pass
    a = A()
    b = B()
    # Test constructor with no arguments
    x = FieldOverride()
    assert x.exclude is None
    assert x.encoder is None
    assert x.decoder is None
    assert x.letter_case is None
    # Test constructor with all arguments
    x = FieldOverride(exclude=a, encoder=b, decoder=a, letter_case=b)
    assert x.exclude == a
    assert x.encoder == b
    assert x.decoder == a
    assert x.letter_case == b


# Generated at 2022-06-23 16:50:54.118799
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    sut = _ExtendedEncoder()
    from datetime import datetime
    from uuid import uuid4
    from decimal import Decimal
    from enum import Enum
    from dataclasses_json.tests.sample_dtos import Color
    assert sut.default(datetime.now(timezone.utc))
    assert sut.default(True)
    assert sut.default(False)
    assert sut.default(None)
    assert sut.default(sut)
    assert sut.default(uuid4())
    assert sut.default(Color.GREEN)
    assert sut.default(Decimal('1234.5678'))
    assert sut.default([])
    assert sut.default({})



# Generated at 2022-06-23 16:51:04.544397
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    '''Unit test for method default of class _ExtendedEncoder'''
    # Initialize a encoder
    encoder = _ExtendedEncoder()
    # Test datetime
    date = datetime.utcnow().replace(tzinfo=timezone.utc)
    assert encoder.default(date) == date.timestamp()
    # Test UUID
    uuid = UUID('19e1ca3f-3b02-49bf-b21f-5cfc8e95e57d')
    assert encoder.default(uuid) == str(uuid)
    # Test Enum
    class Color(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3
    assert encoder.default(Color.BLUE) == 3
    # Test Decimal

# Generated at 2022-06-23 16:51:15.724900
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(decoder=datetime.fromisoformat,
                                   encoder=datetime.isoformat)
    assert field_override.decoder == datetime.fromisoformat
    assert field_override.encoder == datetime.isoformat
    assert field_override.letter_case is None
    assert field_override.exclude is None
    field_override2 = FieldOverride(decoder=datetime.fromisoformat,
                                    letter_case=camelcase)
    assert field_override2.letter_case == camelcase
    assert field_override2.encoder is None
    assert field_override2.exclude is None
    field_override6 = FieldOverride(encoder=to_upper)
    assert field_override6.encoder == to_upper
    assert field

# Generated at 2022-06-23 16:51:28.480399
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    def f1(x):
        return x
    def f2(x):
        return x
    def g1(x):
        return x
    f = FieldOverride("snake_case", None, None, None, None)
    assert isinstance(f, FieldOverride)
    f = FieldOverride("snake_case", f1, f2, g1, None)
    assert isinstance(f, FieldOverride)
    # Test simple equalities
    assert f == FieldOverride("snake_case", f1, f2, g1, None)
    assert not f == FieldOverride("snake_case", f2, f2, g1, None)
    assert not f == FieldOverride("snake_case", f1, f1, g1, None)
    # Test attribuetwise equalities
    assert f == FieldOverride

# Generated at 2022-06-23 16:51:39.012680
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    name = 'name'
    letter_case = 'letter_case'
    exclude = 'exclude'
    encoder = 'encoder'
    decoder = 'decoder'
    mm_field = 'mm_field'

    field_override = FieldOverride(name, letter_case, exclude, encoder, decoder,
                                   mm_field)
    assert field_override.name == name
    assert field_override.letter_case == letter_case
    assert field_override.exclude == exclude
    assert field_override.encoder == encoder
    assert field_override.decoder == decoder
    assert field_override.mm_field == mm_field



# Generated at 2022-06-23 16:51:48.797926
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now()) == '"2020-10-18T21:28:42.607145"'
    assert _ExtendedEncoder().default(UUID('fb67c533-d8fc-49c3-a3a3-9eb948315f1a')) == '"fb67c533-d8fc-49c3-a3a3-9eb948315f1a"'
    assert _ExtendedEncoder().default(Decimal("1.01")) == '"1.01"'



# Generated at 2022-06-23 16:52:01.781557
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(set({'a', 'b'})) == ['a', 'b']
    assert _ExtendedEncoder().default({'a': 'b'}) == {'a': 'b'}
    assert _ExtendedEncoder().default(frozenset({'a', 'b'})) == ['a', 'b']
    assert _ExtendedEncoder().default(datetime(1994, 8, 18, 9, 30, 0, tzinfo=timezone.utc)) == 786648600.0

# Generated at 2022-06-23 16:52:13.753858
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps([[1, 2], 3], cls=_ExtendedEncoder) == '[[1, 2], 3]'
    assert json.dumps({1: 2, 3: 4}, cls=_ExtendedEncoder) == '{"1": 2, "3": 4}'
    assert json.dumps(UUID('1f81231a-bb55-4e62-80ef-27851532eeb1'), cls=_ExtendedEncoder) == \
           '"1f81231a-bb55-4e62-80ef-27851532eeb1"'
    assert json.dumps(Enum('TestEnum', {'A': 1, 'B': 2}), cls=_ExtendedEncoder) == '1'

# Generated at 2022-06-23 16:52:17.946453
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder() is not None

# Unit tests for _get_type_cons, _issubclass_safe, _isinstance_safe and _handle_undefined_parameters_safe
from typing import TypeVar
from dataclasses import dataclass, field
from dataclasses_json import DataClassJsonMixin

T = TypeVar('T')


# Generated at 2022-06-23 16:52:30.408290
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Mapping
    o = {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default(o) == o
    # Collection
    o = [1, 2, 3]
    assert _ExtendedEncoder().default(o) == o
    # datetime
    o = datetime.now(timezone.utc)
    assert _ExtendedEncoder().default(o) == o.timestamp()
    # UUID
    o = UUID(int=1)
    assert _ExtendedEncoder().default(o) == str(o)
    # Enum
    o = Enum('test', [('A', 1), ('B', 2)])
    assert _ExtendedEncoder().default(o) == 1
    # Decimal
    o = Decimal(1)
    assert _ExtendedEnc

# Generated at 2022-06-23 16:52:35.698675
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder().encode
    assert encoder([1, 2, 3]) == '[1, 2, 3]'
    assert encoder({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'



# Generated at 2022-06-23 16:52:48.777449
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1,2,3]) == [1,2,3]
    assert encoder.default({'i':1,'j':2}) == {'i': 1, 'j': 2}
    assert encoder.default(set([1,2,3])) == [1,2,3]
    assert encoder.default(datetime.utcnow()) == datetime.utcnow().timestamp()
    assert encoder.default(UUID(int=42)) == '00000000-0000-0000-0000-00000000002a'
    assert encoder.default(Enum('Foo', [('foo', 1)])) == 1
    assert encoder.default(Decimal(1)) == '1'



# Generated at 2022-06-23 16:52:50.220470
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _ExtendedEncoder().default(None)



# Generated at 2022-06-23 16:53:01.873323
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(bytearray(b'\x00\xff')) == r'"\u0000\xff"'
    assert _ExtendedEncoder().encode({1: 2, 3: 4}) == '{"1": 2, "3": 4}'
    assert _ExtendedEncoder().encode(set([1, 2, 3, 2])) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(frozenset([1, 2, 3, 2])) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(Decimal(1.2345)) == '"1.2345"'

# Generated at 2022-06-23 16:53:13.559477
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(range(3)) == [0, 1, 2]
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default(dict(a=1, b=2)) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default(set('abc')) == ['a', 'b', 'c']
    assert _ExtendedEncoder().default(frozenset('abc')) == ['a', 'b', 'c']

# Generated at 2022-06-23 16:53:19.991949
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    exc = FieldOverride(a=1, exclude=None, letter_case=None, encoder=None, decoder=None, mm_fields=None)
    assert(exc.a == 1)
    assert(exc.exclude is None)
    assert(exc.letter_case is None)
    assert(exc.encoder is None)
    assert(exc.decoder is None)
    assert(exc.mm_fields is None)



# Generated at 2022-06-23 16:53:25.748601
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(exclude=lambda x: True, encoder=lambda x: x,
                      letter_case=lambda x: x, decoder=lambda x: x)
    assert f.exclude is not None
    assert f.encoder is not None
    assert f.letter_case is not None
    assert f.decoder is not None



# Generated at 2022-06-23 16:53:32.599659
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f1 = FieldOverride()
    f2 = FieldOverride(exclude=None)
    f3 = FieldOverride(letter_case=None)
    f4 = FieldOverride(encoder=None)
    f5 = FieldOverride(decoder=None)
    f6 = FieldOverride(mm_field=None)
    assert f1.exclude is None
    assert f1.mm_field is None
    assert f1.letter_case is None
    assert f1.encoder is None
    assert f1.decoder is None



# Generated at 2022-06-23 16:53:36.932488
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime(2019, 1, 1)) == 1546300800
    assert encoder.default(UUID("00000000-0000-0000-0000-000000000000")) == "00000000-0000-0000-0000-000000000000"


# Generated at 2022-06-23 16:53:42.958543
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now())
    assert _ExtendedEncoder().default(UUID('d63a275a-b656-4c5d-a5a5-5a7b5ee21090'))
    assert _ExtendedEncoder().default(Enum('test','test'))
    assert _ExtendedEncoder().default(Decimal('1.1'))



# Generated at 2022-06-23 16:53:55.261967
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Check that encode/decode function are the same when not passed
    test_data = FieldOverride()
    assert test_data.exclude == None
    assert test_data.letter_case == None
    assert test_data.encoder == None
    assert test_data.mm_field == None
    assert test_data.decoder == None
    # Check that encode/decode function are the same when passed
    test_data = FieldOverride(lambda x: x.upper(),
                              lambda x: x.lower(),
                              lambda x: x * 2,
                              lambda x: x * 4,
                              lambda x: x * 8)
    assert test_data.exclude(str) == str.upper()
    assert test_data.letter_case(str) == str.lower()
    assert test_data.encoder(str)

# Generated at 2022-06-23 16:53:56.872916
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(Decimal('0.01')) == '0.01'



# Generated at 2022-06-23 16:54:08.274316
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    examples = [
        [1, 2, 3],
        [4, 5, 6],
        'spam',
        42,
        12.3,
        True,
        {'spam': 42},
        {42},
        None,
        [],
        {},
        datetime(2005, 12, 30, 15, 30, 30, tzinfo=timezone.utc),
        UUID('6d4e6f24-7583-4d4a-8d5f-95a57e0bb0c8'),
    ]

# Generated at 2022-06-23 16:54:18.325772
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

    assert encoder.default({"a": "b"}) == {"a": "b"}
    assert encoder.default({"a": 1}) == {"a": 1}
    assert encoder.default(set()) == []
    assert encoder.default(set((1, 2))) == [1, 2]
    assert encoder.default(set((1, {"a": "b"}))) == [1, {"a": "b"}]
    assert encoder.default(datetime.now()) == datetime.now().timestamp()
    assert encoder.default(UUID('550e8400-e29b-41d4-a716-446655440000')) == '550e8400-e29b-41d4-a716-446655440000'
    assert enc

# Generated at 2022-06-23 16:54:29.455010
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # no override
    assert FieldOverride() == FieldOverride(None, None, None, None)
    # with different override
    assert FieldOverride(
        letter_case=lambda x: x.title()) == FieldOverride(
        letter_case=lambda x: x.title(),
        exclude=None,
        encoder=None,
        decoder=None)
    assert FieldOverride(
        exclude=lambda x: x == 0) == FieldOverride(
        letter_case=None,
        exclude=lambda x: x == 0,
        encoder=None,
        decoder=None)
    assert FieldOverride(
        encoder=lambda x: x + 1) == FieldOverride(
        letter_case=None,
        exclude=None,
        encoder=lambda x: x + 1,
        decoder=None)

# Generated at 2022-06-23 16:54:36.658228
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = _ExtendedEncoder()
    assert o.default([1, 2]) == [1, 2]
    assert o.default({1, 2}) == [1, 2]
    assert o.default({1: 2, 3: 4}) == {1: 2, 3: 4}

    d = datetime.now(timezone.utc)
    assert o.default(d) == d.timestamp()

    u = UUID('a6ac66d6-9a6c-47a7-b64f-5d5bbe8c57b7')
    assert o.default(u) == str(u)

    e = IntEnum.A
    assert o.default(e) == e.value

    d = Decimal('1234567')
    assert o.default(d) == '1234567'



# Generated at 2022-06-23 16:54:45.985108
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(['a', 1]) == ['a', 1]
    assert _ExtendedEncoder().default({'a': 'b'}) == {'a': 'b'}
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(datetime.now(tz=timezone.utc)) == 1553467678.0
    assert _ExtendedEncoder().default(Enum('Pending', 'pending')) == 'pending'



# Generated at 2022-06-23 16:54:50.034764
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    o = FieldOverride()
    assert o.exclude is None
    assert o.letter_case is None
    assert o.encoder is None
    assert o.decoder is None
    assert o.mm_field is None

# Generated at 2022-06-23 16:55:02.336251
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride()
    assert field_override.exclude is None
    assert field_override.letter_case is None
    assert field_override.encoder is None
    assert field_override.decoder is None

    exclude = lambda x: x > 0
    assert field_override._update_exclude(exclude) == exclude

    lc = lambda x: x.upper()
    assert field_override._update_letter_case(lc) == lc

    encoder = lambda x: x + 1
    assert field_override._update_encoder(encoder) == encoder

    decoder = lambda x: x - 1
    assert field_override._update_decoder(decoder) == decoder