

# Generated at 2022-06-23 16:45:08.708366
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoding = _ExtendedEncoder()
    assert encoding.default([1, 2]) == [1, 2]
    assert encoding.default({"1": 2}) == {"1": 2}
    assert encoding.default(datetime.now()) == None
    assert encoding.default(UUID('4ed1d2af-90e4-4247-8ba5-5c5a5b5d7c26')) == '4ed1d2af-90e4-4247-8ba5-5c5a5b5d7c26'
    class Color(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3
    assert encoding.default(Color.RED) == 1
    assert encoding.default(Decimal('10.999')) == '10.999'
    assert encoding.default([]) == []

# Generated at 2022-06-23 16:45:17.459103
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    d1 = {'exclude': lambda val: val == None, 'letter_case': 'snake_case'}
    d2 = {'exclude': lambda val: val == None, 'letter_case': None}
    d3 = {'exclude': None, 'letter_case': 'snake_case'}
    d4 = {}

    assert FieldOverride(**d1).exclude.__name__ == '<lambda>'
    assert FieldOverride(**d1).letter_case == 'snake_case'
    assert FieldOverride(**d2).exclude.__name__ == '<lambda>'
    assert FieldOverride(**d2).letter_case is None
    assert FieldOverride(**d3).exclude is None
    assert FieldOverride(**d3).letter_case == 'snake_case'
    assert Field

# Generated at 2022-06-23 16:45:22.592396
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    try:
        FieldOverride()
        pytest.fail('FieldOverride should be constructed with args')
    except TypeError as e:
        assert "FieldOverride takes at least 1 argument" in str(e)

    encoder = lambda x: x
    decoder = lambda x: x
    foo = FieldOverride(encoder, decoder)
    assert foo.encoder == encoder
    assert foo.decoder == decoder

    exclude = lambda x: True
    foo = FieldOverride(encoder, decoder, exclude)
    assert foo.exclude == exclude

    letter_case = lambda x: x
    foo = FieldOverride(encoder, decoder, exclude, letter_case)
    assert foo.letter_case == letter_case



# Generated at 2022-06-23 16:45:24.967244
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride() == FieldOverride(exclude=None, letter_case=None,
                                            encoder=None, decoder=None)



# Generated at 2022-06-23 16:45:31.792149
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # test if Collection type is used
    test_object = [1, 2, 3]
    test_result = json.dumps(test_object, cls=_ExtendedEncoder)
    assert test_result == '[1, 2, 3]'

    # test if Mapping type is not used
    test_object = {1: 2, 3: 4}
    test_result = json.dumps(test_object, cls=_ExtendedEncoder)
    assert test_result == '{"1": 2, "3": 4}'

    # test if datetime object is used
    test_object = datetime.now(tz=timezone.utc)
    test_result = json.dumps(test_object, cls=_ExtendedEncoder)
    assert test_result == str(test_object.timestamp())
    

# Generated at 2022-06-23 16:45:36.726724
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default(100.5) == 100.5
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(None) is None
    assert encoder.default(['a', 'b']) == ['a', 'b']
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default(datetime(2020, 2, 1, 2, 10, 30)) == 1580522230.0
    assert encoder.default(datetime(2020, 2, 1, 2, 10, 30,
                                    tzinfo=timezone.utc)) == 1580522230.0

# Generated at 2022-06-23 16:45:44.512168
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(list('abc')) == '["a", "b", "c"]'
    assert _ExtendedEncoder().encode(dict(a=1, b=2, c=3)) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '"12345678-1234-5678-1234-567812345678"'  # noqa



# Generated at 2022-06-23 16:45:55.817279
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    case = lambda x: x.lower()

    exclude = lambda x: x is None or x == 0

    encoder = lambda x: x if x else 'None'

    decoder = lambda x: x if x else None

    # Test an override with no properties
    o1 = FieldOverride()
    assert(o1.letter_case is None)
    assert(o1.exclude is None)
    assert(o1.encoder is None)
    assert(o1.decoder is None)

    # Test an override with all properties
    o2 = FieldOverride(letter_case=case, exclude=exclude,
                       encoder=encoder, decoder=decoder)
    assert(o2.letter_case==case)
    assert(o2.exclude==exclude)
    assert(o2.encoder==encoder)

# Generated at 2022-06-23 16:46:04.936213
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fr = FieldOverride()
    assert fr.letter_case == None
    assert fr.exclude == None
    assert fr.mm_field == None
    assert fr.encoder == None
    assert fr.decoder == None

    from dataclasses_json.letter_case import camelCase
    from dataclasses_json.letter_case import snake_case
    from dataclasses_json.letter_case import PascalCase

    exclude = "yes"
    mm_field = "mm_field"
    encoder = "encoder"
    decoder = "decoder"

    # Test camelCase
    fr = FieldOverride(camelCase, exclude, mm_field, encoder, decoder)
    assert fr.letter_case == camelCase
    assert fr.exclude == exclude
    assert fr.mm_field == mm_field

# Generated at 2022-06-23 16:46:16.926588
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # type: (...) -> None
    e = _ExtendedEncoder()

    @dataclass
    class Foo:
        a: Any = 1

    assert e.default(Foo()) == 1

    assert e.default({'a': 1}) == {'a': 1}

    assert e.default((1,)) == [1]

    now = datetime.now(timezone.utc)
    now_st = now.replace(microsecond=0).timestamp()
    assert e.default(now) == int(now_st)

    assert e.default(UUID('a22b6c40-6d62-42cb-a21a-e1f95aa116e9')) == 'a22b6c40-6d62-42cb-a21a-e1f95aa116e9'

   

# Generated at 2022-06-23 16:46:20.589952
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([5, 6, 7]) == [5, 6, 7]
    assert encoder.default({'f':6, 'g':7}) == {'f':6, 'g':7}


# Generated at 2022-06-23 16:46:24.835073
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Setup
    enc = _ExtendedEncoder(indent=4)
    # Exercise
    res = enc.default(
        datetime.fromtimestamp(0, tz=timezone.utc)
    )
    # Verify
    assert res == 0.0
    # Cleanup - done automatically


# noinspection PyProtectedMember

# Generated at 2022-06-23 16:46:36.552955
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(datetime.now(), cls=_ExtendedEncoder)
    assert json.dumps([1, 2, 3], cls=_ExtendedEncoder)
    assert json.dumps({1: 2}, cls=_ExtendedEncoder)
    assert json.dumps(UUID('b2aeebca-8e53-4b33-a9d9-bc8c2b8ada8d'), cls=_ExtendedEncoder)
    assert json.dumps(Decimal(1), cls=_ExtendedEncoder)
    assert json.dumps(Enum('Test', {'a': 'b'}), cls=_ExtendedEncoder)
    assert json.dumps(datetime.now(), cls=_ExtendedEncoder)

# Generated at 2022-06-23 16:46:38.358092
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    json.JSONEncoder().default == _ExtendedEncoder.default

# TODO: add unit test for this class

# Generated at 2022-06-23 16:46:48.036762
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    result = encoder.default(1)
    assert result == 1
    result = encoder.default(1.0)
    assert result == 1.0
    result = encoder.default(1.0 + 0j)
    assert result == 1.0
    result = encoder.default('1')
    assert result == '1'
    result = encoder.default([1, 2, 3])
    assert result == [1, 2, 3]
    result = encoder.default((1, 2, 3))
    assert result == [1, 2, 3]
    result = encoder.default({'a': 1, 'b': 2})
    assert result == {'a': 1, 'b': 2}

# Generated at 2022-06-23 16:46:51.079169
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    ovr = FieldOverride('none')
    assert ovr.exclude == 'none'
    assert ovr.letter_case == 'none'
    assert ovr.encoder == 'none'
    assert ovr.decoder == 'none'
    assert ovr.mm_field == 'none'


# Test custom encoders/decoders

# Generated at 2022-06-23 16:46:57.030849
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default({1, 2, 3}) == [1, 2, 3]
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default(datetime(2018, 4, 11, 8, 0, 0)) == 1523411600
    dt_naive = datetime(2018, 4, 11, 8, 0, 0, tzinfo=None)
    assert _ExtendedEncoder().default(dt_naive) == 1523411600
    assert _ExtendedEncoder().default(dt_naive.replace(tzinfo=timezone.utc)) == 1523411600
    assert _

# Generated at 2022-06-23 16:47:06.066650
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride()
    assert str(field_override) == ("<FieldOverride("
                                   "exclude=<function FieldOverride."
                                   "<locals>._noop at 0x10ece5440>, "
                                   "encoder=<function FieldOverride.<locals>."
                                   "_noop at 0x10ece5488>, "
                                   "decoder=<function FieldOverride.<locals>."
                                   "_noop at 0x10ece54d0>, "
                                   "letter_case=<function FieldOverride.<"
                                   "locals>._noop at 0x10ece5518>)>")


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 16:47:13.942613
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(list(range(10)), cls=_ExtendedEncoder) == '[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]'
    assert json.dumps(dict(zip(range(5), range(5))), cls=_ExtendedEncoder) == '{"0": 0, "1": 1, "2": 2, "3": 3, "4": 4}'
    assert json.dumps(datetime(2020, 1, 2, 3, 4, 5, tzinfo=timezone.utc), cls=_ExtendedEncoder) == '1577936245.0'

# Generated at 2022-06-23 16:47:24.324162
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from decimal import Decimal
    from datetime import datetime
    from uuid import UUID
    from enum import Enum
    import json
    class TestEnum(Enum):
        a = 1
    assert _ExtendedEncoder().default(TestEnum.a) == "a"
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default((1, 2, 3)) == [1, 2, 3]
    assert _ExtendedEncoder().default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert _ExtendedEncoder().default(datetime.utcnow()) == datetime.utcnow().timestamp()

# Generated at 2022-06-23 16:47:27.953201
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.JSONEncoder().default({})
    json.JSONEncoder().default([])
    json.JSONEncoder().default(UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8'))
    json.JSONEncoder().default(Enum('TestEnum', {'a': 1}))
    json.JSONEncoder().default(Decimal('1.1'))



# Generated at 2022-06-23 16:47:38.732593
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class D1(DataclassJsonMixin):
        a: int = field(metadata=dict(dataclasses_json={'exclude': lambda x: x > 10}))
        b: int = field(metadata=dict(dataclasses_json={'letter_case': str.title}))
        c: int = field(metadata=dict(dataclasses_json={'encoder': lambda x: x * 2}))
        d: int = field(metadata=dict(dataclasses_json={'decoder': lambda x: x / 2}))
    d1 = D1()
    assert d1.to_dict() == {'a': 0, 'b': 0, 'c': 0, 'd': 0}
    d1 = D1(a=100, b=100, c=100, d=100)
    assert d

# Generated at 2022-06-23 16:47:43.732958
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_name = 'test_name'
    ex = lambda x: x
    en = lambda x: x
    ignore = lambda x: x
    f = FieldOverride(field_name, letter_case=ex, exclude=ignore,
                      encode=en, decode=en)
    assert f.field_name == field_name
    assert f.letter_case == ex
    assert f.exclude == ignore
    assert f.encode == en
    assert f.decode == en



# Generated at 2022-06-23 16:47:44.937091
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    FieldOverride()

# Generated at 2022-06-23 16:47:52.164205
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(...) is Ellipsis
    assert _ExtendedEncoder().default(1.1) == 1.1
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default('text') == 'text'
    assert _ExtendedEncoder().default({'c': 'd'}) == {'c': 'd'}
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == \
           datetime.now(timezone.utc).timestamp()

# Generated at 2022-06-23 16:48:03.530222
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    a = _ExtendedEncoder().encode(123)
    b = json.dumps(123)
    assert a == b

    a = _ExtendedEncoder().encode({"uuid": UUID('123e4567-e89b-12d3-a456-426655440000')})
    b = json.dumps({"uuid": str(UUID('123e4567-e89b-12d3-a456-426655440000'))})
    assert a == b

    a = _ExtendedEncoder().encode(Decimal('1.1'))
    b = json.dumps(str(Decimal('1.1')))
    assert a == b


# Generated at 2022-06-23 16:48:15.176573
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj = {
        "name": "John",
        "age": 30,
        "cars": [
            {"model": "Maza", "mpg": 27.5},
            {"model": "Ford", "mpg": 24.1},
            {"model": "BMW", "mpg": 28.4}
        ],
        "dct": {"a": "A", "b": "B"},
        "dt": datetime(2020, 1, 1, tzinfo=timezone.utc),
        "uuid": UUID('12345678123456781234567812345678'),
        "enum_value": Color.red,
        "decimal_value": Decimal('1.2')
    }
    result = json.dumps(obj, cls=_ExtendedEncoder)

# Generated at 2022-06-23 16:48:26.069125
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class A:
        pass

    class B:
        pass

    # Test FieldOverride with all None attributes
    fo = FieldOverride()
    assert fo.exclude is None
    assert fo.letter_case is None
    assert fo.encoder is None
    assert fo.decoder is None

    # Test FieldOverride with custom attributes
    fo = FieldOverride(exclude=lambda x: x > 2,
                       letter_case=lambda s: s.upper(),
                       encoder=lambda x: x * 2,
                       decoder=lambda x: x * x)
    assert fo.exclude is not None
    assert fo.letter_case is not None
    assert fo.encoder is not None
    assert fo.decoder is not None

    # Test all methods of `FieldOverride`
    # Test exclude
    assert fo.exclude(3)

# Generated at 2022-06-23 16:48:34.952049
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert e.default({}) == {}
    assert e.default([]) == []
    assert e.default(MappingProxyType({})) == {}
    assert e.default(datetime(1, 1, 1, tzinfo=timezone.utc)) == -62135596800.0
    assert e.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert e.default(Enum('MyEnum', (('A', 1), ('B', 2)))) == 1
    assert e.default(Decimal('0.1')) == '0.1'
    assert e.default(0.1) == 0.1

# Generated at 2022-06-23 16:48:45.694021
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(TypeError, match="'exclude' must be a callable"):
        FieldOverride(exclude='a string')
    with pytest.raises(TypeError, match="'exclude' must be a callable"):
        FieldOverride(exclude=True)
    with pytest.raises(TypeError, match="'letter_case' must be a callable"):
        FieldOverride(letter_case='a string')
    with pytest.raises(TypeError, match="'letter_case' must be a callable"):
        FieldOverride(letter_case=True)
    with pytest.raises(TypeError, match="'encoder' must be a callable"):
        FieldOverride(encoder='a string')

# Generated at 2022-06-23 16:48:57.419126
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict()) == "{}"
    assert _ExtendedEncoder().encode([]) == "[]"
    assert _ExtendedEncoder().encode("") == "\"\""
    assert _ExtendedEncoder().encode(True) == "true"
    assert _ExtendedEncoder().encode(None) == "null"

    assert _ExtendedEncoder().encode(datetime(2020, 1, 2, 3, 4, 5, tzinfo=timezone.utc)) == "1577936845.0"
    assert _ExtendedEncoder().encode([{}]) == "[{}]"

# Generated at 2022-06-23 16:49:06.265930
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

# Generated at 2022-06-23 16:49:15.749456
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import datetime
    from uuid import uuid4
    from decimal import Decimal
    from enum import Enum

    class MyEnum(Enum):
        A = 'A1'
        B = 'B2'

    encoder = _ExtendedEncoder()
    result1 = json.loads(json.dumps(MyEnum.A, cls=encoder))
    result2 = json.loads(json.dumps(uuid4(), cls=encoder))
    result3 = json.loads(json.dumps(Decimal('0.001'), cls=encoder))
    result4 = json.loads(json.dumps(datetime.now(timezone.utc), cls=encoder))
    assert result1 == MyEnum.A.value

# Generated at 2022-06-23 16:49:24.552570
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """Unit test for class _ExtendedEncoder"""
    sample_dict = {
        'obj': _ExtendedEncoder
    }
    sample_list = [
        _ExtendedEncoder,
    ]
    sample_str = 'abc'
    sample_int = 123
    sample_float = 1.23
    sample_bool = True
    sample_none = None
    sample_datetime = datetime.now(tz=timezone.utc)
    sample_uuid = UUID('123e4567-e89b-12d3-a456-426655440000')
    sample_enum = SampleEnum.VALUE_2
    sample_decimal = Decimal('123.45')
    sample_object = SampleObject()


# Generated at 2022-06-23 16:49:36.820054
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # All None
    field_override = FieldOverride(None, None, None)
    assert(field_override.encoder is None)
    assert(field_override.letter_case is None)
    assert(field_override.exclude is None)

     # All except exclude
    field_override = FieldOverride(lambda x: x, lambda x: x, None)
    assert(field_override.encoder is not None)
    assert(field_override.letter_case is not None)
    assert(field_override.exclude is None)

    # All except letter_case
    field_override = FieldOverride(lambda x: x, None, lambda x: True)
    assert(field_override.encoder is not None)
    assert(field_override.letter_case is None)

# Generated at 2022-06-23 16:49:47.277211
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    test_cases = (
        (1, 1),
        ('a', 'a'),
        (True, True),
        ({'k': 'v'}, {'k': 'v'}),
        (Enum('TestEnum', [('A', 'a'), ('B', 'b')]), 'a'),
        (UUID('12345678-1234-5678-1234-567812345678'), '12345678-1234-5678-1234-567812345678'),
        (datetime(1970, 1, 1, tzinfo=timezone.utc), 0.0),
        (Decimal('3.14'), '3.14'),
    )
    for case, result in test_cases:
        assert _ExtendedEncoder().default(case) == result



# Generated at 2022-06-23 16:49:56.090990
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test case 1
    field_override = FieldOverride(
        exclude=lambda x: x is None,
        letter_case=lambda x: x[1:],
        encoder=lambda x: str(x),
        decoder=lambda x: int(x),
        mm_field=lambda x: fields.Str()
    )

    # test case 2
    field_override = FieldOverride()
    assert field_override is not None


# Generated at 2022-06-23 16:50:06.401344
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([]) == "[]"
    assert _ExtendedEncoder().encode({}) == "{}"
    assert _ExtendedEncoder().encode(1) == "1"
    assert _ExtendedEncoder().encode(datetime.fromtimestamp(1234567890, tz=timezone.utc)) == '1234567890.0'
    assert _ExtendedEncoder().encode(Decimal('3.14')) == '"3.14"'
    assert _ExtendedEncoder().encode(UUID('44445555-6666-7777-8888-99990000AAAA')) == '"44445555-6666-7777-8888-99990000aaaa"'



# Generated at 2022-06-23 16:50:12.441498
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test default value of all class members
    fo = FieldOverride()
    assert fo.letter_case is None
    assert fo.exclude is None
    assert fo.encoder is None
    assert fo.decoder is None
    assert fo.mm_field is None
    # Test initialization
    fo = FieldOverride(str.lower, None, None, None, None)
    assert fo.letter_case is str.lower
    assert fo.exclude is None
    assert fo.encoder is None
    assert fo.decoder is None
    assert fo.mm_field is None


# Unit tests for user_overrides_or_exts()

# Generated at 2022-06-23 16:50:23.041060
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from uuid import uuid4
    from enum import Enum
    from datetime import datetime
    from decimal import Decimal
    from collections import namedtuple

    class MyEnum(Enum):
        A = 1
        B = 2
        C = 3

    MyTuple = namedtuple('MyTuple', 'val')

    assert _ExtendedEncoder().default(MyEnum.A) == 1
    assert _ExtendedEncoder().default(MyEnum.B) == 2
    assert _ExtendedEncoder().default(MyEnum.C) == 3
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default('a') == 'a'
    assert _ExtendedEncoder().default(None) is None

# Generated at 2022-06-23 16:50:33.757711
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    import pytest
    from dataclasses_json.api import M, Mm, DataclassesJsonMixin, config

    @config
    class Cfg(object):
        mm_fields: Mm = Mm()

    class MyType(DataclassesJsonMixin):
        x: int
        y: int = 0
        z: M(str) = M(None)

        def __post_init__(self):
            self.z = "po"

        @classmethod
        def from_json(cls, kvs, **kwargs):
            kwargs["z"] = "from"
            return super().from_json(kvs, **kwargs)

    def test_field_name():
        res = FieldOverride("hi", None, None)
        assert res.field_name == "hi"

# Generated at 2022-06-23 16:50:37.276933
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Test case for constructor of class FieldOverride
    """
    field_override = FieldOverride("", "", "")



# Generated at 2022-06-23 16:50:38.722605
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-23 16:50:49.168859
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test basic construction behavior
    f = FieldOverride("test", True)
    assert f.name == "test"
    assert f.letter_case(f.name) == "Test"

    # test alias behavior
    f = FieldOverride("test", alias="test_alias")
    assert f.name == "test_alias"

    # test letter_case behavior
    f = FieldOverride("test", alias="Test")
    assert f.name == "Test"
    assert f.letter_case(f.name) == "test"

    # test exclude behavior
    f = FieldOverride("test", exclude=lambda x: True)
    assert callable(f.exclude)
    assert f.exclude(1) is True

    # test function mapping behavior
    f = FieldOverride("test", encoder=lambda x: x * 2)

# Generated at 2022-06-23 16:50:54.486923
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now()) == datetime.now().timestamp()
    assert encoder.default(uuid.uuid4()) == str(uuid.uuid4())
    dec = Decimal(10)
    assert encoder.default(dec) == '10'



# Generated at 2022-06-23 16:51:04.741230
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert e.default([1, 2, 3]) == [1, 2, 3]
    assert e.default({"a": 1}) == {"a": 1}
    assert e.default((1, 2, 3)) == [1, 2, 3]
    assert e.default(set([1, 2, 3])) == [1, 2, 3]
    assert e.default(frozenset([1, 2, 3])) == [1, 2, 3]
    assert e.default(bytearray([1, 2, 3])) == [1, 2, 3]
    assert e.default({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    now = datetime.now()
    assert e.default(now) == now.timestamp()

# Generated at 2022-06-23 16:51:15.906060
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(['a', 'b']) == '["a", "b"]'
    assert _ExtendedEncoder().encode({'a': '3', 'b': 'h'}) == '{"a": "3", "b": "h"}'
    assert _ExtendedEncoder().encode(UUID('de305d54-75b4-431b-adb2-eb6b9e546014')) == '"de305d54-75b4-431b-adb2-eb6b9e546014"'
    assert _ExtendedEncoder().encode(datetime(2020, 5, 3, 4, 6, 5, 8787)) == '1588520365.008878'

# Generated at 2022-06-23 16:51:18.304255
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(datetime.now()) == "{}"



# Generated at 2022-06-23 16:51:29.250643
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ext_encoder = _ExtendedEncoder()
    # Test for dict
    assert ext_encoder.default({}) == {}
    assert ext_encoder.default({1:2}) == {1:2}
    # Test for list
    assert ext_encoder.default([1, 2]) == [1, 2]
    assert ext_encoder.default(()) == []
    # Test for datetime
    assert ext_encoder.default(datetime.now()) - datetime.now().timestamp() < 0.01
    # Test for UUID

# Generated at 2022-06-23 16:51:33.920055
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEncoder().encode("123") == '"123"'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.5) == '1.5'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode({1, 2, 3}) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode((1, 2, 3)) == '[1, 2, 3]'
    assert _Extended

# Generated at 2022-06-23 16:51:44.188068
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False

    assert _ExtendedEncoder().default(0) == 0
    assert _ExtendedEncoder().default(0.0) == 0.0

    assert _ExtendedEncoder().default('') == ''
    assert _ExtendedEncoder().default('abc') == 'abc'
    assert _ExtendedEncoder().default('a1_') == 'a1_'

    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}


# Generated at 2022-06-23 16:51:50.436822
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_encoder_obj = _ExtendedEncoder()
    x = json_encoder_obj.default('2')
    assert x == '2'
    x = json_encoder_obj.default({'key':'value'})
    assert x == {'key':'value'}
    x = json_encoder_obj.default(2)
    assert x == 2
    x = json_encoder_obj.default(['a', 'b'])
    assert x == ['a', 'b']
    my_datetime = datetime.now(timezone.utc)
    y = json_encoder_obj.default(my_datetime)
    assert y == my_datetime.timestamp()

# Generated at 2022-06-23 16:52:02.383087
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        test_str = 'test_str'
        test_list = [1, 2, 3]
        test_dict = {'a': 1, 'b': 2, 'c': 3}
        test_datetime = datetime(2019, 3, 6, 14, 22, 19, 0, timezone.utc)
        test_uuid = UUID(int=1234567890)
        test_enum = cfg.ENUM(AutoType.ValueA)
        test_decimal = Decimal('0.1')
        result1 = json.dumps(test_str, cls=_ExtendedEncoder)
        result2 = json.dumps(test_list, cls=_ExtendedEncoder)

# Generated at 2022-06-23 16:52:14.914637
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # basic types
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.1) == 1.1
    assert _ExtendedEncoder().default("str") == "str"
    assert _ExtendedEncoder().default(None) == None

    # collections
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default((True, 1, 1.1, "str", None)) == [True, 1, 1.1, "str", None]
    assert _ExtendedEncoder().default((True,)) == [True]

# Generated at 2022-06-23 16:52:23.722604
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = _ExtendedEncoder()
    assert o.encode([]) == "[]"
    assert o.encode({}) == "{}"
    assert o.encode('') == '""'
    assert o.encode(1) == '1'
    assert o.encode(True) == 'true'
    assert o.encode(None) == 'null'
    dt = datetime.now(timezone.utc)
    assert o.encode(dt) == f'"{dt.isoformat()}Z"'
    uuid = UUID('12345678123456781234567812345678')
    assert o.encode(uuid) == f'"{uuid}"'
    class myEnum(Enum):
        a = 1

# Generated at 2022-06-23 16:52:32.458812
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    from dataclasses import dataclass
    from typing import Optional

    @dataclass
    class Foo:
        bar: Optional[str]

    f = Foo(bar="baz")
    override = FieldOverride(exclude=lambda x: True)
    try:
        assert f.bar
        assert override.exclude(f)
    except AssertionError:
        print("FieldOverride did not exclude field")
        raise
    else:
        print("FieldOverride exclusion worked as expected")
    finally:
        print("Test complete")



# Generated at 2022-06-23 16:52:34.477197
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default('abc') == 'abc'



# Generated at 2022-06-23 16:52:43.311481
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from decimal import Decimal
    from enum import IntEnum
    from uuid import uuid4
    from dataclasses import dataclass

    class Color(IntEnum):
        RED = 1
        GREEN = 2
        BLUE = 3

    @dataclass
    class Data:
        a: Collection[str]
        b: Mapping[str, int]
        c: datetime
        d: Enum
        e: Decimal
        f: UUID

    data = Data(
        a=['abc', 'def'],
        b={'abc': 1, 'def': 2},
        c=datetime.now(timezone.utc),
        d=Color.RED,
        e=Decimal(0.1),
        f=uuid4(),
    )


# Generated at 2022-06-23 16:52:52.601039
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert (_ExtendedEncoder().default({'one': 1, 'two': 2, 'three': 3}) ==
            {'one': 1, 'two': 2, 'three': 3})
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False
    assert _ExtendedEncoder().default(None) is None
    assert (_ExtendedEncoder().default(datetime.fromtimestamp(1234.56,
                                                              timezone(3700))) ==
            1234.56)

# Generated at 2022-06-23 16:53:02.674204
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from uuid import UUID  # noqa
    from decimal import Decimal  # noqa

    dt = datetime.now(tz=timezone.utc)
    s = 's'
    # noinspection PyUnresolvedReferences
    u = UUID('123e4567-e89b-12d3-a456-426655440000')
    e = cfg.DemoEnum.a
    d = Decimal('3.14')
    l = [dt, s, u, e, d]
    e = _ExtendedEncoder()
    # noinspection PyProtectedMember

# Generated at 2022-06-23 16:53:07.868778
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    exp = UUID('3b5f5eaf-f7ef-4ce5-a9ef-2b5f75b2e2d4')
    obs = json.loads(json.dumps(exp, cls=_ExtendedEncoder))
    assert obs == str(exp)



# Generated at 2022-06-23 16:53:14.323610
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    override = FieldOverride(True, None, None, False)
    assert override.letter_case is None
    assert override.exclude is None
    assert override.encoder is None
    assert override.decoder is None
    assert override.mm_field is False
    assert override.__dict__ == {'letter_case': None, 'exclude': None,
                                 'encoder': None, 'decoder': None,
                                 'mm_field': False}



# Generated at 2022-06-23 16:53:24.067429
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(
        {1: 'a', 2: 'b', 3: 'c'}) == '{"1": "a", "2": "b", "3": "c"}'
    assert _ExtendedEncoder().encode(
        [1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(
        datetime(year=2019, month=12, day=8, hour=15, minute=30, second=0)) == '1575742200.0'

# Generated at 2022-06-23 16:53:33.807605
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # no exclude predicate, no encoder
    fo = FieldOverride()
    assert fo.exclude is None
    assert fo.encoder is None
    # no encoder
    fo = FieldOverride(exclude=lambda x: True)
    assert fo.exclude(1)
    assert fo.encoder is None
    # no exclude predicate
    fo = FieldOverride(encoder=lambda x: x+1)
    assert fo.exclude is None
    assert fo.encoder(1) == 2
    # with exclude predicate, with encoder
    fo = FieldOverride(exclude=lambda x: True, encoder=lambda x: x+1)
    assert fo.exclude(1)
    assert fo.encoder(1) == 2


# Generated at 2022-06-23 16:53:42.829244
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    dict_check = {'a': 1, 'b': 2, 'c': 3}
    set_check = {1, 2, 3}
    list_check = [1, 2, 3]
    json_check = ['a', 1]
    datetime_check = datetime.now(timezone.utc)
    uuid_check = UUID('c9bf9e57-1685-4c89-b623-92b2d6a26260')
    decimal_check = Decimal('1234567.8')

# Generated at 2022-06-23 16:53:55.256568
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().encode([(1,2,3), ['a','b','c']]) == '[1, 2, 3, ["a", "b", "c"]]'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode([1, 'a']) == '[1, "a"]'
    assert _ExtendedEncoder().encode({1, 2, 3}) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({1, 'a'}) == '["a", 1]'
    assert _ExtendedEncoder().encode((1, 2, 3)) == '[1, 2, 3]'

# Generated at 2022-06-23 16:54:03.627583
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    obj = [1, 2, 3]
    result = _ExtendedEncoder().default(obj)
    expected = [1, 2, 3]
    assert result == expected, 'Expected result was not returned'
    obj = {'a': 1, 'b': 2}
    result = _ExtendedEncoder().default(obj)
    expected = {'a': 1, 'b': 2}
    assert result == expected, 'Expected result was not returned'
    obj = datetime(2018, 2, 15, 2, 3, 4, tzinfo=timezone.utc)
    result = _ExtendedEncoder().default(obj)
    expected = '1518652984.0'
    assert result == expected, 'Expected result was not returned'
    obj = UUID('00000000-0000-0000-0000-000000000000')


# Generated at 2022-06-23 16:54:09.876851
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2018, 1, 1)) == '1514764800.0'
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'


# Generated at 2022-06-23 16:54:19.269050
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert enc.default(True) == True
    assert enc.default(False) == False
    assert enc.default(1.2) == 1.2
    assert enc.default(5) == 5
    assert enc.default(None) == None
    assert enc.default(1) == 1
    assert enc.default(3.0) == 3.0
    assert enc.default({'a':'a', 'b':'b'}) == {"a": "a", "b": "b"}
    assert enc.default(['a','b','c']) == ['a','b','c']

# Generated at 2022-06-23 16:54:30.396849
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default('1') == '1'
    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default((1, 2)) == [1, 2]
    assert _ExtendedEncoder().default({'1': 1}) == {'1': 1}
    assert _ExtendedEncoder().default(set([1, 2])) == [1, 2]
    assert _ExtendedEncoder().default(set([1, 2])) == [1, 2]
    assert _ExtendedEncoder().default(frozenset([1, 2])) == [1, 2]

# Generated at 2022-06-23 16:54:40.547122
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'a': 1, 1: 2}) == {'a': 1, 1: 2}
    now = datetime.now(timezone.utc)
    assert _ExtendedEncoder().default(now) == now.timestamp()
    uuid = UUID('d9bea409-bf3b-480a-b5f5-5eebd25b2c40')
    assert _ExtendedEncoder().default(uuid) == str(uuid)
    class T(Enum):
        a = 1
        b = 2
    assert _ExtendedEncoder().default(T.a) == 1

# Generated at 2022-06-23 16:54:49.100067
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"@type": "Turtle"}) == '{"@type": "Turtle"}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"@type": "Turtle", "a":1, "b":2, "c":3}) == '{"@type": "Turtle", "a": 1, "b": 2, "c": 3}'


# Generated at 2022-06-23 16:54:53.206947
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # when
    result = _ExtendedEncoder().default(
        datetime(2015, 3, 14, 21, 5, 38, 344000, timezone.utc))
    # then
    assert result == 1426363538.344

_extended_json_encoder = _ExtendedEncoder()



# Generated at 2022-06-23 16:55:05.977397
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == []
    assert encoder.default({'test': 'test'}) == {'test': 'test'}
    assert encoder.default(datetime(2000, 5, 1, tzinfo=timezone.utc)) \
        == 956328800.0
    assert encoder.default(UUID('5c5af846-5884-4873-921e-7c9a12a1f7e0')) \
        == '5c5af846-5884-4873-921e-7c9a12a1f7e0'
    assert encoder.default(MockEnum.foo) == 'foo'
    assert encoder.default(Decimal('12.345')) == '12.345'