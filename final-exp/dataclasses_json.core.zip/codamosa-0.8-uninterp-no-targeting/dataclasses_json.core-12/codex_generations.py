

# Generated at 2022-06-21 11:24:28.752994
# Unit test for constructor of class FieldOverride
def test_FieldOverride():

    @dataclass
    class Test:
        x: int = 1

    class TestEncoder:
        def __init__(self, a):
            self.a = a

        def __call__(self, value):
            return value.x + self.a

    class TestDecoder:
        def __init__(self, b):
            self.b = b

        def __call__(self, value):
            return Test(value - self.b)

    def exclude_func(value):
        return value.x > 1

    def upper_fn(value):
        return value.upper()


# Generated at 2022-06-21 11:24:34.481130
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ee = _ExtendedEncoder()
    assert ee.default(datetime.now()) == datetime.now().timestamp()
    assert ee.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert ee.default(False) == False


# Generated at 2022-06-21 11:24:35.907113
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-21 11:24:46.471813
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test invalid arguments to FieldOverride
    with pytest.raises(ValueError):
        FieldOverride(1, f, 2)

    with pytest.raises(ValueError):
        FieldOverride(f, 1, 2)

    with pytest.raises(ValueError):
        FieldOverride(f, f, 1)

    with pytest.raises(ValueError):
        FieldOverride(True, f, f)

    with pytest.raises(ValueError):
        FieldOverride(f, "", f)

    with pytest.raises(ValueError):
        FieldOverride(f, f, "")

    with pytest.raises(ValueError):
        FieldOverride(f, f, f, "")

    # Test valid arguments to FieldOverride
    assert FieldOverride(None, f, f).exclude == None

# Generated at 2022-06-21 11:24:55.931141
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder(indent=4)
    encoded = encoder.encode({'a': [1, 2, {'b': 'c'}], 'd': datetime(1986, 10, 26, 1, 21, 0), 'e': UUID(int=0), 'f': TestEnum.A, 'g': Decimal('3.14')})
    assert encoded == '''{
    "a": [
        1,
        2,
        {
            "b": "c"
        }
    ],
    "d": 530484060.0,
    "e": "00000000-0000-0000-0000-000000000000",
    "f": 0,
    "g": "3.14"
}'''



# Generated at 2022-06-21 11:24:58.857470
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(exclude=_default_exclude_predicate,
                         letter_case=_default_letter_case,
                         encoder=None,
                         decoder=None) is not None

# Generated at 2022-06-21 11:25:03.844449
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(None, None, None)
    assert FieldOverride("a", "b", "c")
    assert str(FieldOverride("a", "b", "c")) == "FieldOverride(encoder='a', exclude=<function 'b'>, letter_case=<function 'c'>, mm_fields=None)"


# Unit tests for _asdict

# Generated at 2022-06-21 11:25:08.598051
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(exclude=lambda x: x=='foo', letter_case=lambda x: x.upper())

# Generated at 2022-06-21 11:25:15.232918
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(cfg.NaN) == float('nan')
    assert _ExtendedEncoder().default(cfg.PosInf) == float('inf')
    assert _ExtendedEncoder().default(cfg.NegInf) == float('-inf')
    assert _ExtendedEncoder().default(cfg.NaNT) == float('nan')
    assert _ExtendedEncoder().default(cfg.PosInfT) == float('inf')
    assert _ExtendedEncoder().default(cfg.NegInfT) == float('-inf')



# Generated at 2022-06-21 11:25:24.869506
# Unit test for method default of class _ExtendedEncoder

# Generated at 2022-06-21 11:25:57.176216
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.2) == 1.2

# Generated at 2022-06-21 11:26:10.300497
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    a= dict(a=1,b=2)
    b= set(a)
    c= [1,2,3]
    d= (1,2,3)
    e= datetime.now()
    f= UUID('00000000-0000-0000-0000-000000000000')
    g= Decimal('1.1')
    h= Decimal('12e-4')
    i= cfg.Encoder(datetime_unit= 's')
    j= cfg.Encoder(datetime_unit= 'ms')
    k= cfg.Encoder(datetime_unit= 'ns')

    assert _ExtendedEncoder().default(a) == a
    assert _ExtendedEncoder().default(b) == list(b)
    assert _ExtendedEncoder().default(c) == c
    assert _

# Generated at 2022-06-21 11:26:18.250381
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    json_encoder = _ExtendedEncoder()
    assert json_encoder.default(None) is None
    assert json_encoder.default(True) is True
    assert json_encoder.default(1) == 1
    assert json_encoder.default(2.2) == 2.2
    assert json_encoder.default("str") == "str"
    assert json_encoder.default([1, "2"]) == [1, "2"]
    assert json_encoder.default({"1": 2}) == {"1": 2}
    assert json_encoder.default(datetime.now(timezone.utc)) == datetime.now(
        timezone.utc).timestamp()

# Generated at 2022-06-21 11:26:26.557292
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()

    assert extended_encoder.default(set()) == []
    assert extended_encoder.default(frozenset()) == []
    assert extended_encoder.default({'a': 'b'}) == {'a': 'b'}
    assert extended_encoder.default([]) == []
    assert extended_encoder.default(()) == []
    assert extended_encoder.default(datetime.now()) > 0
    assert extended_encoder.default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert extended_encoder.default(Decimal('1')) == '1'



# Generated at 2022-06-21 11:26:31.886231
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default({}) == {}
    assert encoder.default([]) == []
    assert encoder.default(datetime(1980, 1, 1)) == 315532800.0
    assert encoder.default(UUID('4a3f4c27-e42c-4d00-8c63-945f1c14d2d2')) == '4a3f4c27-e42c-4d00-8c63-945f1c14d2d2'
    assert encoder.default(Enum('D', 'DEF')) == 'DEF'
    assert encoder.default(Decimal('12.34')) == '12.34'
    assert encoder.default(1) == 1


# Generated at 2022-06-21 11:26:43.621189
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    import json_dataclass_config as jdc
    jdc.configure(
        decoders={
            str: lambda x: x * 2,
            int: lambda x: x + 100,
        },
        encoders={
            str: lambda x: x + '?',
            int: lambda x: x + 500,
        },
        letter_cases={
            str: str.lower,
        },
        mm_fields={
            MyCustomType_With_MM: {'field1': fields.Str(load_from='field2'),
                                   'field3': fields.Int(default=0)},
        },
    )

    class MyCustomType_With_MM(jdc.JsonMixin, mm.Schema):
        field1 = mm.fields.Str(missing='abc')
        field2 = mm

# Generated at 2022-06-21 11:26:54.421094
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    class TestClass:
        pass
    o = TestClass()
    o.dict = {'key': 'value'}
    o.list = [i for i in range(1000)]
    o.set = {i for i in range(100)}
    o.datetime = datetime(2018, 2, 27, 2, 12, 21)
    o.uuid = UUID('8f434346-8551-11e4-b4a9-0800200c9a66')
    class TestEnum(Enum):
        A = 'a'
        B = 'b'
    o.enum = TestEnum.A
    o.decimal = Decimal(1.1)

    result = encoder.default(o)
    assert len(result) == 9

# Generated at 2022-06-21 11:27:04.879191
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class Foo:
        def __call__(self):
            pass

    foo = Foo()

    # Tests for normal cases
    r = FieldOverride("")
    assert not r.exclude
    assert r.letter_case is None
    assert r.encoder is None
    assert r.decoder is None

    r = FieldOverride("", exclude=1)
    assert r.exclude == 1
    assert r.letter_case is None
    assert r.encoder is None
    assert r.decoder is None

    r = FieldOverride("", letter_case=1)
    assert not r.exclude
    assert r.letter_case == 1
    assert r.encoder is None
    assert r.decoder is None

    r = FieldOverride("", encoder=1)
    assert not r.exclude
    assert r.letter

# Generated at 2022-06-21 11:27:15.775132
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from operator import attrgetter
    # Python 3.6
    from collections import OrderedDict
    from functools import total_ordering

    @total_ordering
    class D:
        def __init__(self, x, y):
            self.x = x
            self.y = y

        def __eq__(self, other):
            if not isinstance(other, D):
                return False
            return other.x == self.x and other.y == self.y

        def __lt__(self, other):
            return (self.x, self.y) < (other.x, other.y)
    e = _ExtendedEncoder()
    cmpr = attrgetter('x', 'y')

# Generated at 2022-06-21 11:27:23.561045
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default([1,2,3]) == [1,2,3]
    assert enc.default(['a','b','c']) == ['a','b','c']
    assert enc.default(('a','b','c')) == ['a','b','c']
    assert enc.default((1,2,3)) == [1,2,3]
    assert enc.default(['a','b','c']) == ['a','b','c']
    assert enc.default({1,2,3}) == [1,2,3]
    assert enc.default({'a','b','c'}) == ['a','b','c']
    assert enc.default({'a':1,'b':2,'c':3}) == {'a':1,'b':2,'c':3}

# Generated at 2022-06-21 11:28:17.181455
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # noinspection PyTypeChecker
    json.dumps([1, 2, 3], cls=_ExtendedEncoder)
    # noinspection PyTypeChecker
    json.dumps({"a": 1, "b": 2}, cls=_ExtendedEncoder)
    assert datetime.now(timezone.utc).isoformat() == '2019-01-22T01:19:00.004040+00:00'
    js = json.dumps(datetime.now(timezone.utc), cls=_ExtendedEncoder)
    assert js == '1548146740.004040'

# Generated at 2022-06-21 11:28:27.212642
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    cases = [([], list()),
             ({}, dict()),
             (datetime.now(), 0),
             (datetime.now(timezone.utc), 0),
             (datetime.now(timezone.utc).timestamp(), 0),
             (UUID('2aab13ce-e5e5-4beb-875c-ba5d5223e02f'), '2aab13ce-e5e5-4beb-875c-ba5d5223e02f'),
             (Enum(field='a', name='A'), 'a'),
             (Decimal(10), '10'),
             (Decimal('10.12'), '10.12')]
    for c in cases:
        assert _ExtendedEncoder().encode(c[0]) == json.dumps(c[1])

# Generated at 2022-06-21 11:28:39.342100
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    def get_json(obj) -> str:
        return _ExtendedEncoder(cfg.encoder.NAMEDTUPLE_AS_OBJECT,
                                cfg.encoder.TUPLE_AS_ARRAY).encode(obj).decode('utf-8')

    assert get_json({'i': 1, 'j': 2}) == '{"i":1,"j":2}'
    assert get_json([3, 4, 5]) == '[3,4,5]'
    assert get_json('str') == '"str"'
    assert get_json(1) == '1'
    assert get_json(1.1) == '1.1'
    assert get_json(True) == 'true'
    assert get_json(None) == 'null'

# Generated at 2022-06-21 11:28:42.804297
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(exclude=None, encoder=None, letter_case=None)
    assert f.exclude is None
    assert f.encoder is None
    assert f.letter_case is None
    f = FieldOverride(exclude=lambda x: x == "me",
                      encoder=lambda x: str(x) + "!")
    assert f.exclude(1) is False
    assert f.exclude("me") is True
    assert f.encoder(1) == "1!"



# Generated at 2022-06-21 11:28:43.838011
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass


# Generated at 2022-06-21 11:28:44.940345
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    FieldOverride(False, str.title, None, None, None)

# Generated at 2022-06-21 11:28:50.422664
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config as cfg
    from datetime import datetime

    @dataclass
    class IgnoreFooType:
        foo: str

    @dataclass
    class IgnoreTime:
        time: datetime

    @dataclass
    class UpperTime:
        time: datetime

    cfg.global_config.datetime_format = '%Y-%m-%d'

    decoders = {**cfg.global_config.decoders, datetime: lambda v: datetime.strptime(v, '%Y-%m-%d')}
    decoder_config = cfg.Config(decoders=decoders)

# Generated at 2022-06-21 11:28:51.975824
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = json.dumps([], cls=_ExtendedEncoder)
    assert result == '[]'



# Generated at 2022-06-21 11:28:59.413738
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    instance = _ExtendedEncoder()
    assert instance.default([1, 2, 3]) == [1, 2, 3]
    assert instance.default(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert instance.default({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert instance.default(set([1, 2, 3])) == [1, 2, 3]
    assert instance.default(frozenset(['a', 'b', 'c'])) == ['a', 'b', 'c']

    # test datetime
    dt = datetime(2019, 1, 1, 0, 0, tzinfo=timezone.utc)
    assert instance.default(dt) == 1546300

# Generated at 2022-06-21 11:29:10.168994
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    a = 1
    assert _ExtendedEncoder().default(a) == a

    b = [1,2,3]
    assert _ExtendedEncoder().default(b) == b

    c = {"a": 1, "b": 2}
    assert _ExtendedEncoder().default(c) == c

    d = datetime.now(timezone.utc)
    e = json.loads(json.dumps(d, cls=_ExtendedEncoder))
    assert e == d.timestamp()

    f = UUID("a36c2b5e-0020-4a66-8b3c-1f0bfe717b2f")
    g = json.loads(json.dumps(f, cls=_ExtendedEncoder))
    assert g == f.hex

    h = Decimal

# Generated at 2022-06-21 11:30:40.971232
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default(datetime.now(tz=timezone.utc)) == datetime.now(tz=timezone.utc).timestamp()
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({1: 2}) == {1: 2}

# Generated at 2022-06-21 11:30:49.882968
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test defaults
    fo = FieldOverride()
    assert fo.do_include
    assert fo.letter_case is None
    assert fo.encoder is None
    assert fo.decoder is None

    # Test false exclude
    exclude = lambda x: False
    fo = FieldOverride(exclude=exclude)
    assert not fo.do_include
    # Test true include
    include = lambda x: True
    fo = FieldOverride(include=include)
    assert fo.do_include

    # Test letter_case
    lc = lambda s: s + '_bar'
    fo = FieldOverride(letter_case=lc)
    assert fo.letter_case is lc

    # Test encoder
    enc = lambda s: s + '_bar'
    fo = FieldOverride(encoder=enc)
    assert fo.encoder

# Generated at 2022-06-21 11:30:58.713430
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    k = "foo"
    exc = lambda x: x
    dec = lambda x: x
    fn = lambda x: x
    typ = int
    lc = encase_pascal
    conf = Config()
    conf.global_config.default_exclude=exc
    conf.global_config.default_decoder=dec
    conf.global_config.default_encoder=fn
    conf.global_config.default_mm_field=typ
    conf.global_config.default_letter_case=lc
    overrides = FieldOverride(None, None, None, None, None)
    assert overrides.exclude == exc
    assert overrides.decoder == dec
    assert overrides.encoder == fn
    assert overrides.mm_field == typ
    assert overrides.letter_case == lc

# Generated at 2022-06-21 11:31:00.184697
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    a: Json = _ExtendedEncoder().encode([1, 2])
    b: Json = json.dumps([1, 2])
    assert a == b



# Generated at 2022-06-21 11:31:08.781143
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default('foo') == 'foo'
    assert encoder.default(123) == 123
    assert encoder.default(True) == True
    assert encoder.default(None) is None
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    utc = timezone.utc
    assert encoder.default(datetime.utcnow().replace(tzinfo=utc)) is not None
    assert encoder.default(UUID(int=123)) == '00000000-0000-0000-0000-00000000007b'
    assert encoder.default(Decimal('2.5')) == '2.5'

# Generated at 2022-06-21 11:31:21.162863
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(['a', 'b']) == ['a', 'b']
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default(2) == json.JSONEncoder().default(2)
    assert encoder.default(UUID('123e4567-e89b-12d3-a456-426655440000')) == str(
        UUID('123e4567-e89b-12d3-a456-426655440000'))
    assert encoder.default(datetime.now()) == json.JSONEncoder().default(datetime.now())
    assert encoder.default(Decimal('2.718281828459045')) == json.JSONEncoder().default

# Generated at 2022-06-21 11:31:28.804418
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test each of the three constructor arguments
    test_exclude = FieldOverride(exclude=lambda x: True)
    assert test_exclude.exclude(1)
    assert test_exclude.encoder is None
    assert test_exclude.decoder is None
    assert test_exclude.letter_case is None

    test_encoder = FieldOverride(encoder=lambda x: json.dumps(x))
    assert test_encoder.encoder(1) != 1
    assert test_encoder.exclude is None
    assert test_encoder.decoder is None
    assert test_encoder.letter_case is None

    test_decoder = FieldOverride(decoder=lambda x: json.loads(x))
    assert test_decoder.decoder(1) == 1
    assert test_decoder.exclude

# Generated at 2022-06-21 11:31:35.188862
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    o = {'a': 1, 'b': 2}
    assert e.default(o) == o
    assert e.default(None) == None
    assert e.default(True) == True
    assert e.default(False) == False
    assert e.default(1) == 1
    assert e.default(1.0) == 1.0
    assert e.default('str') == 'str'
    print('test_ExtendedEncoder done')



# Generated at 2022-06-21 11:31:45.994324
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class Test1:
        pass

    class Test2:
        pass

    field_override = FieldOverride(exclude=lambda val: val == 'skip',
                                   letter_case=lambda s: s.upper(),
                                   encoder=lambda val: 'test',
                                   decoder=lambda val: Test1(),
                                   mm_field=lambda val: Test2())
    assert field_override.exclude('skip')
    assert not field_override.exclude('test')
    assert field_override.letter_case('test_letter_case') == 'TEST_LETTER_CASE'
    assert field_override.encoder('test') == 'test'
    assert isinstance(field_override.decoder(0), Test1)
    assert isinstance(field_override.mm_field(), Test2)

# Generated at 2022-06-21 11:31:57.012435
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    foo = FieldOverride("")
    assert(foo.letter_case is None
           and foo.exclude is None
           and foo.encoder is None
           and foo.decoder is None)

    bar = FieldOverride(lambda: "")