

# Generated at 2022-06-21 11:24:25.531184
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(dict(a=1)) == {"a": 1}
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default(set([1, 2])) == [1, 2]
    assert encoder.default(UUID(int=1)) == "00000000-0000-0000-0000-000000000001"
    assert encoder.default(DummyEnum.a) == 0
    assert encoder.default(datetime(2000, 1, 1)) == 946684800.0
    assert encoder.default(DummyClass()) == {"a": 1}
    assert encoder.default(1.234) == 1.234
    assert encoder.default(Decimal('1.234')) == "1.234"
    assert encoder

# Generated at 2022-06-21 11:24:33.503570
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default("") == ""
    assert _ExtendedEncoder().default(1) == 1.0
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('9d9e2b1f-a0c5-41a8-8c2a-2080fcd9f7d9')) == '9d9e2b1f-a0c5-41a8-8c2a-2080fcd9f7d9'
    assert _ExtendedEncoder().default(None) is None
    assert _Extended

# Generated at 2022-06-21 11:24:38.401660
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import date
    from uuid import UUID
    from decimal import Decimal
    from enum import Enum
    class TestDateTime(date):
        def timestamp(self):
            return "yes"
    def __init__(self, word):
        self.word = word
    result = _ExtendedEncoder().default(TestDateTime.today())
    assert result == "yes"
    result = _ExtendedEncoder().default(dict([(1,2)]))
    assert result == {1:2}
    result = _ExtendedEncoder().default(list([1,2]))
    assert result == [1,2]
    result = _ExtendedEncoder().default(UUID(hex="3b3c1494b6514c1fa2dff0e81c2b9c9b"))

# Generated at 2022-06-21 11:24:40.773572
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride()
    assert f.exclude is None
    assert f.letter_case is None
    assert f.encoder is None
    assert f.decoder is None

# Generated at 2022-06-21 11:24:46.278723
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    now = datetime.now()
    lst = [now, now]
    assert encoder.default(lst) == [now.timestamp(), now.timestamp()]
    dct = {'now': now, 'lst': lst}
    assert encoder.default(dct) == {'now': now.timestamp(), 'lst': [now.timestamp(), now.timestamp()]}    # noqa: E501



# Generated at 2022-06-21 11:24:56.730930
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # note: we are testing the functionality of json.JSONEncoder.default()
    #       we do this by checking for the default type conversions (which we want to override)
    #       the expected result can be found in the json library

    # the following test cases are taken from the Python 3.6 documentation
    # https://docs.python.org/3/library/json.html#encoders-and-decoders

    # collections
    collection_expected = [1, 2, 3, {"four": 5, "six": 7}]
    collection_result = _ExtendedEncoder().encode(set(collection_expected))
    assert collection_result == json.JSONEncoder().encode(collection_expected)

    # datetime
    # note: in Python 3.7 this test fails since the timestamp to datetime conversion changed
    #       see https://

# Generated at 2022-06-21 11:25:00.146405
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fv = FieldOverride(letter_case=lambda x: x, decoder=lambda x: x)
    assert fv.letter_case is not None
    assert fv.decoder is not None
    assert fv.decoder(1) == 1


# Generated at 2022-06-21 11:25:05.401323
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test all optional attributes.
    fo = FieldOverride(
        exclude=lambda v: v == 1,
        letter_case=str.lower,
        encoder=lambda v: v,
        decoder=lambda v: v,
    )
    assert fo.exclude(1)
    assert fo.letter_case('Z') == 'z'
    assert fo.encoder(1) == 1
    assert fo.decoder(1) == 1


# Generated at 2022-06-21 11:25:10.040073
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(exclude=None, letter_case="default", encoder=None, decoder=None)
    assert fo.exclude is None
    assert fo.letter_case == "default"
    assert fo.encoder is None
    assert fo.decoder is None


# Generated at 2022-06-21 11:25:20.610630
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

    assert encoder.default(None) is None
    assert encoder.default(True) is True
    assert encoder.default(1) == 1
    assert encoder.default(1.2) == 1.2
    assert encoder.default('abc') == 'abc'
    assert encoder.default(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert encoder.default(('a', 'b', 'c')) == ['a', 'b', 'c']
    assert encoder.default({1, 2, 3, 4}) == [1, 2, 3, 4]
    assert encoder.default({1: 2, 3: 4}) == {1: 2, 3: 4}

# Generated at 2022-06-21 11:25:44.094033
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    class Test:
        pass

    assert _ExtendedEncoder().encode({Test(): 'test'}) == '{}'
    assert _ExtendedEncoder().encode([Test()]) == '[null]'
    assert _ExtendedEncoder().encode(1) == '1'



# Generated at 2022-06-21 11:25:53.998006
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import pytest
    from collections import Counter, OrderedDict
    from datetime import datetime
    from uuid import uuid4, UUID
    from decimal import Decimal

    t = datetime.utcnow().replace(tzinfo=timezone.utc).timestamp()

    class TestEnum(Enum):
        val1 = 'dummy value 1'
        val2 = 'dummy value 2'

    test_uuid = uuid4()


# Generated at 2022-06-21 11:26:05.303828
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    from dataclasses import dataclass
    from typing import Optional

    @dataclass_json
    @dataclass(frozen=True)
    class A:
        a: int
        b: str
        c: Optional[int] = ...

    a = A(a=1, b="2", c=3)

    assert a.a == 1
    assert a.b == "2"
    assert a.c == 3
    assert hasattr(a, '__dataclass_json__')

    a_encoded = a.__dataclass_json__
    a_decoded = A.from_dict(a_encoded)

    assert a.a == a_decoded.a
    assert a.b == a_decoded.b
    assert a.c == a_decoded.c


# Unit test

# Generated at 2022-06-21 11:26:10.474276
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fe = FieldOverride(exclude=lambda x: x < 0,
                       letter_case=lambda s: s.upper())
    assert fe.exclude(2) == False
    assert fe.exclude(-2) == True
    assert fe.letter_case("a") == "A"

# Generated at 2022-06-21 11:26:17.920370
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test default values
    assert FieldOverride().letter_case is None
    assert FieldOverride().exclude is None
    assert FieldOverride().encoder is None
    assert FieldOverride().decoder is None
    assert FieldOverride().mm_field is None

    # Test initialization with arguments
    assert FieldOverride(letter_case=uncapitalize).letter_case == uncapitalize

# Generated at 2022-06-21 11:26:23.491429
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(
        encoder=lambda x: x,
        decoder=lambda x: x,
        exclude=lambda x: x is None,
        letter_case=lambda x: x.upper())
    assert fo.encoder is not None
    assert fo.decoder is not None
    assert fo.exclude is not None
    assert fo.letter_case is not None



# Generated at 2022-06-21 11:26:30.607184
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Test FieldOverride method
    """
    field = FieldOverride(None, None, None, None)
    assert field.encoder == None and field.decoder == None \
        and field.exclude == None and field.letter_case == None
    field = FieldOverride(str, None, None, None)
    assert field.encoder == str and field.decoder == None \
        and field.exclude == None and field.letter_case == None
    field = FieldOverride(None, str, None, None)
    assert field.encoder == None and field.decoder == str \
        and field.exclude == None and field.letter_case == None
    field = FieldOverride(None, None, str, None)
    assert field.encoder == None and field.decoder == None \
        and field.exclude == str

# Generated at 2022-06-21 11:26:42.756340
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    data = [
            [1, 2, "hi", [1, 2, "hi"], {1:2, 3:4}],
            datetime(year=2015, month=6, day=4, hour=1, minute=2, second=5, tzinfo=timezone.utc),
            {
                "a": 1,
                "b": datetime(year=2015, month=6, day=4, hour=1, minute=2, second=5, tzinfo=timezone.utc),
            },
            UUID('123e4567-e89b-12d3-a456-426655440000'),
            Decimal('0.1'),
            ]

    enc = _ExtendedEncoder()

# Generated at 2022-06-21 11:26:53.608728
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'
    assert _ExtendedEncoder().default(UUID('d2e7b2f6-8f58-11e9-84f7-acde48001122')) == 'd2e7b2f6-8f58-11e9-84f7-acde48001122'
    assert _ExtendedEncoder().default(datetime(2099, 12, 31, 23, 59, 59, 999999, timezone.utc)) == 4102444799.999999

    # in py37, when str(datetime) we'll get AttributeError: module 'datetime' has no attribute 'timezone'
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=Warning)
        assert _

# Generated at 2022-06-21 11:26:57.642300
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(set(['a', 'b', 'c'])) == ['a', 'b', 'c']
    assert _ExtendedEncoder().default({'1': 1}) == {'1': 1}
    now = datetime.now(timezone.utc)
    assert _ExtendedEncoder().default(now) == now.timestamp()


# Generated at 2022-06-21 11:27:34.070120
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    try:
        FieldOverride(None, lambda x: x, 'lower', None)
    except TypeError:
        print("Function FieldOverride is correct")
    except:
        print("Something has gone wrong in FieldOverride")



# Generated at 2022-06-21 11:27:43.213183
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride()
    assert field_override.exclude is None, "Field exclude default is wrong."
    assert field_override.letter_case is None, "Field letter case default is wrong."
    assert field_override.encoder is None, "Field encoder default is wrong."
    assert field_override.decoder is None, "Field exclude default is wrong."
    assert field_override.mm_field is None, "Field mm_field default is wrong."
    field_override = FieldOverride(exclude=is_even, letter_case=camelcase,
                                   encoder=triple, decoder=triple, mm_field=Integer)
    assert field_override.exclude is is_even, "Field exclude is wrong."

# Generated at 2022-06-21 11:27:54.927738
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(list(range(10))) == list(range(10))
    assert _ExtendedEncoder().default(set(range(10))) == list(range(10))
    assert _ExtendedEncoder().default(tuple(range(10))) == list(range(10))
    assert _ExtendedEncoder().default(iter(range(10))) == list(range(10))
    assert _ExtendedEncoder().default(range(10)) == list(range(10))
    assert _ExtendedEncoder().default(dict(a=1, b=2)) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default(datetime.utcnow()) == datetime.utcnow().timestamp()

# Generated at 2022-06-21 11:28:05.836662
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    r = {'a': 1, 'b': -1, 'c': 0, 'd': 'str', 'e': [1, 2, 3], 'f': (1, 2, 3),
         'g': {'h': 1, 'i': [1, 2, 3]}, 'j': datetime.today(timezone.utc),
         'k': UUID('c8e25ddd-f22e-44ec-b08c-8ecec6a7b948'), 'l': Decimal('1.23'),
         'm': {'n': {'o': {'p': 1}}}, 'q': cfg.RAISE}
    er = _ExtendedEncoder()
    re = er.encode(r)

# Generated at 2022-06-21 11:28:18.566121
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    @dataclass_json
    @dataclass
    class User:
        username: str
        email: str

    from_dict = {'username': 'foo', 'email': 'bar'}
    f = FieldOverride(None, None, None, None)

    # No encoder
    assert f.encoder == def_encoder
    # No decoder
    assert f.decoder == def_decoder
    # No exclude predicate
    assert f.exclude == def_exclude
    # No letter case modification
    assert f.letter_case == def_letter_case

    u = User(**from_dict)
    # No decoder
    assert f.decode(False, u) == u
    # No encoder
    assert f.encode(None, False) is None

# Generated at 2022-06-21 11:28:28.550279
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Test FieldOverride() constructor.
    """
    try:
        FieldOverride()
    except TypeError:
        pass
    else:
        raise AssertionError('No exception thrown.')
    try:
        FieldOverride(exclude={})
    except TypeError:
        pass
    else:
        raise AssertionError('No exception thrown.')
    try:
        FieldOverride(letter_case={})
    except TypeError:
        pass
    else:
        raise AssertionError('No exception thrown.')
    try:
        FieldOverride(encoder={})
    except TypeError:
        pass
    else:
        raise AssertionError('No exception thrown.')
    try:
        FieldOverride(decoder={})
    except TypeError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-21 11:28:29.596817
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()

# Generated at 2022-06-21 11:28:41.591925
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default(datetime.fromtimestamp(100000)) == 100000
    assert _ExtendedEncoder().default(UUID('9F1150FD-7B66-49B6-AC21-C8B9C7BF9C13')) == '9f1150fd-7b66-49b6-ac21-c8b9c7bf9c13'
    assert _ExtendedEncoder().default(Decimal('1.234')) == '1.234'
    assert _ExtendedEncoder().default(Enum('A', 'A')) == 'A'

# Generated at 2022-06-21 11:28:43.064772
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now())


# base class of Encoder & Decoder

# Generated at 2022-06-21 11:28:49.002396
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default(42) == 42
    assert enc.default(3.14) == 3.14
    assert enc.default('abc') == 'abc'
    assert enc.default(True) == True
    assert enc.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert enc.default([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-21 11:29:31.578727
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(2015, 12, 31, 23, 59, 59, 999999)) == 1451554999.999999
    assert _ExtendedEncoder().default(datetime(2015, 12, 31)) == 1451520000.0
    assert _ExtendedEncoder().default(datetime(2015, 12, 31, 23, 59, 59, 999999, timezone.utc)) == 1451554999.999999
    assert _ExtendedEncoder().default(datetime(2015, 12, 31, 0, 0, 0, tzinfo=timezone.utc)) == 1451520000.0

# Generated at 2022-06-21 11:29:34.507803
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = _ExtendedEncoder().default(User('name', [1, 2, 3], {1: 2, 3: 4}))
    assert o == {'name': 'name', 'num_list': [1, 2, 3], \
                 'num_dict': {'1': 2, '3': 4}}



# Generated at 2022-06-21 11:29:42.549338
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from decimal import Decimal
    from uuid import UUID
    from datetime import datetime, timezone
    # defined outside of the method to have a reference object and not the them when they are mutable

# Generated at 2022-06-21 11:29:46.357353
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Intended to test the constructor of the FieldOverride class.
    """
    fo_dict = {"exclude": True, "letter_case": None, "encoder": None,
               "decoder": None}
    fo = FieldOverride(**fo_dict)

    assert fo.exclude == True
    assert fo.letter_case == None
    assert fo.encoder == None
    assert fo.decoder == None



# Generated at 2022-06-21 11:29:52.662687
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # given
    encoder = _ExtendedEncoder()
    value = UUID('9d006cd4-4cb4-4dc8-aae4-7313b2d20dd2')
    # when
    result = encoder.default(value)
    # then
    assert result == '9d006cd4-4cb4-4dc8-aae4-7313b2d20dd2'


# Generated at 2022-06-21 11:30:03.148517
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    print(_ExtendedEncoder().encode({"a": {"b": 1, "c": None}, "d": [[1, 2], [3, 4]]}))
    print(_ExtendedEncoder().encode({"a": [1, 2], "b": [3, 4]}))
    print(_ExtendedEncoder().encode({"a": datetime(2020, 4, 19, 0, 0, 0, 0, tzinfo=timezone.utc), "b": datetime.now()}))
    print(_ExtendedEncoder().encode({"a": Decimal("1.2345"), "b": Decimal("5.4321")}))


# Generated at 2022-06-21 11:30:12.767256
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_to_check = {}
    a = _ExtendedEncoder().encode(json_to_check)
    assert json.loads(a) == json_to_check

    # Test lists
    json_to_check = [1, 2]
    a = _ExtendedEncoder().encode(json_to_check)
    assert json.loads(a) == json_to_check

    # Test tuples
    json_to_check = (1, 2)
    a = _ExtendedEncoder().encode(json_to_check)
    assert json.loads(a) == list(json_to_check)

    # Test sets
    json_to_check = set([1, 2])
    a = _ExtendedEncoder().encode(json_to_check)
    assert json.loads(a) == sorted

# Generated at 2022-06-21 11:30:17.497131
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # The construtor should raise ValueError if at least one of these
    # arguments is specified, but the others are not.
    e1 = "exclude and letter_case are mutually exclusive"
    e2 = "exclude and encoder are mutually exclusive"
    e3 = "exclude and decoder are mutually exclusive"
    e4 = "letter_case and encoder are mutually exclusive"
    e5 = "letter_case and decoder are mutually exclusive"
    e6 = "encoder and decoder are mutually exclusive"
    e7 = "letter_case, encoder and decoder are mutually exclusive"

    # With exclude=None and letter_case=None,
    # it should raise a TypeError,
    # because the constructor should be called with two or more arguments.
    with pytest.raises(TypeError) as excinfo:
        Field

# Generated at 2022-06-21 11:30:27.732023
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.default(None) is None
    assert extended_encoder.default(dict([[1,2]])) == {1:2}
    assert extended_encoder.default([1, 2]) == [1, 2]
    assert extended_encoder.default(1) == 1
    assert extended_encoder.default(1.0) == 1.0
    assert extended_encoder.default(True) is True
    assert extended_encoder.default(False) is False
    assert extended_encoder.default(datetime(2010, 1, 2, 3, 4, 5, 6)) == 1262304245.006

# Generated at 2022-06-21 11:30:34.736348
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', category=DeprecationWarning)
        obj = _ExtendedEncoder()
        assert type(obj.default({})) is dict
        assert type(obj.default([])) is list
        assert type(obj.default('')) is str
        assert type(obj.default(0)) is int
        assert type(obj.default(0.0)) is float
        assert type(obj.default(False)) is bool
        assert obj.default(None) is None
        now = datetime.now(timezone.utc)
        assert obj.default(now) == now.timestamp()
        assert type(obj.default(UUID('b0f3cc3c-59cd-4d58-8b69-44e1c9216f86'))) is str

# Generated at 2022-06-21 11:32:03.874699
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    j = json.dumps(Decimal('0.12'), cls=_ExtendedEncoder)
    assert j == '"0.12"'

    j = json.dumps(datetime(2019, 1, 1, 1, 1, 1, tzinfo=timezone.utc), cls=_ExtendedEncoder)
    assert j == '1546344461.0'

    j = json.dumps(UUID('d50da8e8-93b7-11e9-a2a3-2a2ae2dbcce4'), cls=_ExtendedEncoder)
    assert j == '"d50da8e8-93b7-11e9-a2a3-2a2ae2dbcce4"'



# Generated at 2022-06-21 11:32:08.229238
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    def foo(x): return x

    exact_match = FieldOverride(foo, "foo", False)
    assert exact_match.exclude == foo
    assert exact_match.letter_case == "foo"
    assert exact_match.encoder is None
    assert exact_match.decoder is None
    assert exact_match.mm_field is None
    assert exact_match.encode_json is False

    encode_json = FieldOverride(None, None, True)
    assert encode_json.encode_json is True



# Generated at 2022-06-21 11:32:16.297467
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([]) == []
    assert encoder.default({'a': 'a'}) == {'a': 'a'}
    assert encoder.default(UUID(int=0)) == "00000000-0000-0000-0000-000000000000"
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(Decimal("2.4")) == "2.4"
    assert encoder.default(2) == 2



# Generated at 2022-06-21 11:32:26.987220
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({1: 'a', 2: 'b', 3: 'c'}) == {1: 'a', 2: 'b', 3: 'c'}
    assert encoder.default(datetime(2005, 7, 14, 12, 30, 45, tzinfo=timezone.utc)) == 1121415245.0
    assert encoder.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal("10.1")) == "10.1"

# Generated at 2022-06-21 11:32:33.688237
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride().exclude is None
    assert FieldOverride().encoder is None
    assert FieldOverride().decoder is None
    assert FieldOverride(exclude=lambda x: x is None,
                         encoder=lambda x: x + 1,
                         decoder=lambda x: x + 1).exclude(None) is None
    assert FieldOverride(exclude=lambda x: x is None,
                         encoder=lambda x: x + 1,
                         decoder=lambda x: x + 1).encoder(1) == 2
    assert FieldOverride(exclude=lambda x: x is None,
                         encoder=lambda x: x + 1,
                         decoder=lambda x: x + 1).decoder(1) == 2

# Generated at 2022-06-21 11:32:41.522693
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride()
    assert(field_override.exclude is None)
    assert(field_override.encoder is None)
    assert(field_override.letter_case is None)

    exclude = lambda v: True
    encoder = lambda v: v
    letter_case = lambda s: s
    field_override = FieldOverride(exclude, encoder, letter_case)
    assert(field_override.exclude is exclude)
    assert(field_override.encoder is encoder)
    assert(field_override.letter_case is letter_case)

# Generated at 2022-06-21 11:32:53.084219
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import decimal
    import uuid

    class MyEnum(Enum):
        foo = 'foo'

    assert _ExtendedEncoder().default(list(range(3))) == [0, 1, 2]
    assert _ExtendedEncoder().default(tuple(range(3))) == [0, 1, 2]
    assert _ExtendedEncoder().default(dict(a=1)) == {'a': 1}
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == \
        datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(uuid.uuid4()) == str(uuid.uuid4())
    assert _ExtendedEncoder().default(MyEnum.foo) == 'foo'
    assert _ExtendedEncoder().default

# Generated at 2022-06-21 11:32:57.909352
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2020, 3, 1, 11, 21, 12)) == '1583118672.0'
    assert _ExtendedEncoder().encode(UUID('12345678-1234-1234-1234-123456789012')) == '12345678-1234-1234-1234-123456789012'
    assert _ExtendedEncoder().encode(Decimal('1.11')) == '"1.11"'



# Generated at 2022-06-21 11:33:00.109872
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder().encode(set([1, 2, 3]))
    assert json.loads(result) == [1, 2, 3]



# Generated at 2022-06-21 11:33:05.559526
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fi = FieldOverride(encoder=None,
                       decoder=None,
                       letter_case=str.upper,
                       exclude=None,
                       mm_field=None)
    assert fi.encoder == None
    assert fi.decoder == None
    assert fi.letter_case == str.upper
    assert fi.exclude == None
    assert fi.mm_field == None
