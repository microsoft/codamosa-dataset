

# Generated at 2022-06-21 11:24:24.094945
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import date, datetime, time

    assert _ExtendedEncoder().default(date(2018, 1, 1)) == '2018-01-01'
    assert _ExtendedEncoder().default(time(2, 3, 4, 5)) == '02:03:04.000005'
    assert _ExtendedEncoder().default(datetime(2018, 1, 1, 2, 3, 4, 5)) == 1514747384.000005
    assert _ExtendedEncoder().default(datetime(1899, 12, 30, 0, 0, 0, 0)) == -2208988800.0  # type: ignore # Windows bug: https://bugs.python.org/issue29092



# Generated at 2022-06-21 11:24:36.174292
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """Test that dataclasses_json can accept a FieldOverride object with
    any attribute values, and still construct an object out of them.
    """
    field_override = FieldOverride()
    assert field_override.exclude is None
    assert field_override.decoder is None
    assert field_override.encoder is None
    assert field_override.letter_case is None

    field_override = FieldOverride(lambda x: True)
    assert callable(field_override.exclude)
    assert field_override.decoder is None
    assert field_override.encoder is None
    assert field_override.letter_case is None

    field_override = FieldOverride(decoder=lambda x: True)
    assert field_override.exclude is None

# Generated at 2022-06-21 11:24:46.545941
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    @dataclass
    class TestClass:
        a: str

    @dataclass
    class Test:
        val: TestClass

    # test with empty dict
    d = {}
    print(type(d))
    fo = FieldOverride(**d)
    assert fo.letter_case == None
    assert fo.exclude == None
    assert fo.encoder == None
    assert fo.decoder == None

    # test with excluded
    d = {'exclude': lambda x: False}
    fo = FieldOverride(**d)
    assert fo.letter_case == None
    assert fo.exclude == (lambda x: False)
    assert fo.encoder == None
    assert fo.decoder == None

    # test with excluded and letter case

# Generated at 2022-06-21 11:24:56.777562
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert json.loads(_ExtendedEncoder().encode({"t": tuple((1, 2))})) == {"t": [1, 2]}
    assert json.loads(_ExtendedEncoder().encode({"s": set((1, 2))})) == {"s": [1, 2]}
    assert json.loads(_ExtendedEncoder().encode({"d": datetime.now(timezone.utc)})) == {"d": datetime.now(timezone.utc).timestamp()}

# Generated at 2022-06-21 11:25:06.913749
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    def assert_json_roundtrip_encode_decode(o, expected_type=None):
        if expected_type is None:
            expected_type = type(o)
        s = json.dumps(o, cls=_ExtendedEncoder)
        o_decoded = json.loads(s)
        assert isinstance(o_decoded, expected_type), f"Failed to decode {type(o)} {o} into {expected_type} o_decoded={o_decoded} s={s}"
    assert_json_roundtrip_encode_decode(1, int)
    assert_json_roundtrip_encode_decode(1.1, float)
    assert_json_roundtrip_encode_decode(True, bool)
    assert_json_

# Generated at 2022-06-21 11:25:17.298079
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings(record=True):
        encoder = _ExtendedEncoder()
        for o in [NamedTuple('a', 1),
                  defaultdict(lambda: 'a', {'a': 'b'}),
                  [1, 2, 3],
                  (1, 2, 3),
                  set((1, 2, 3)),
                  frozenset((1, 2, 3)),
                  datetime.now(),
                  int(123)]:
            encoder.default(o)
        assert encoder.default(EnumExt('a')) == EnumExt.a
        assert encoder.default(NamedTupleExt('a', 1)) == {'a': 'a', 'b': 1}
        assert encoder.default(NewTypeExt('a')) == 'a'



# Generated at 2022-06-21 11:25:25.464854
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(letter_case=lambda x: x.upper(),
                       exclude=lambda v: v > 0,
                       decoder=lambda v: v.lower(),
                       encoder=lambda v: v.upper())
    assert fo.letter_case(
        "hello") == "HELLO", "FieldOverride.letter_case does not work correctly"
    assert fo.exclude(
        1) == True, "FieldOverride.exclude does not work correctly"
    assert fo.decoder(
        "Hello") == "hello", "FieldOverride.decoder does not work correctly"
    assert fo.encoder(
        "hello") == "HELLO", "FieldOverride.encoder does not work correctly"



# Generated at 2022-06-21 11:25:29.611411
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    data = [{'a': 1, 'b': 2},
            ['c', 'd'],
            datetime(year=1, month=1, day=1, tzinfo=timezone.utc),
            Decimal('10.00001'),
            UUID('f0f59c41-93fa-4ea7-b0b6-d9dab9bc6c74')
            ]
    assert data == json.loads(json.dumps(data, cls=_ExtendedEncoder))



# Generated at 2022-06-21 11:25:31.990485
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(letter_case=camelcase)
    assert field_override.letter_case == camelcase
    assert field_override.exclude is None
    assert field_override.encoder is None
    assert field_override.decoder is None


# Generated at 2022-06-21 11:25:34.352612
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(TypeError) as pe:
        # Just call the constructor without any argument and it should raise
        # a TypeError
        FieldOverride()
    assert pe.value.args[0] == "__new__() missing 4 required positional arguments: 'letter_case', 'exclude', 'encoder', and 'decoder'"


# Generated at 2022-06-21 11:26:13.332961
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import datetime
    from dataclasses_json.tests.base import C  # pylint: disable=import-outside-toplevel
    dataclass_json = cfg.new_config()
    dataclass_json.register(C,
                            encoder=cfg.encoder,
                            decoder=cfg.decoder,
                            letter_case=LetterCase.LowerCamel,
                            mm_field=cfg.mm_field)

# Generated at 2022-06-21 11:26:24.537579
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert e.default([1, 2, 3]) == [1, 2, 3]
    assert e.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert e.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert e.default(UUID('b1e5b0c8-8fc1-4bf9-9cbd-cb24cf6c0b6d')) == 'b1e5b0c8-8fc1-4bf9-9cbd-cb24cf6c0b6d'
    assert e.default(Decimal('0.12345')) == '0.12345'
    assert e.default(None)

# Generated at 2022-06-21 11:26:34.566579
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    d = {'k': 'v'}
    l = [1, 2, 3]
    s = '{"a": "b"}'
    o = object()
    t = datetime.now(timezone.utc)
    u = UUID('0c74f13f-fa83-4c48-9b33-68921dd72463')
    n = None
    i = 12345
    f = 1.2345
    b = True
    e = cfg.EnumABCEncoder.REPR
    e2 = cfg.EnumABCEncoder.VALUE
    E = namedtuple('E', 'a b')
    e = E(1, 2)
    d2 = Decimal('1.2345')

# Generated at 2022-06-21 11:26:46.567671
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    """
    Unit test for method default of class _ExtendedEncoder
    """
    encoder = _ExtendedEncoder()
    timestamp_utc = datetime.utcfromtimestamp(0).replace(tzinfo=timezone.utc)
    decoded_json: Json = {'list': [1, 'a', timestamp_utc],
                          'dict': {'a': 1},
                          'int': 0,
                          'float': 0.0,
                          'str': '0',
                          'bool': True,
                          'none': None,
                          'datetime': timestamp_utc,
                          'enum': ExampleEnum.value,
                          'decimal': Decimal('3.14'),
                          'conditional': [None,
                                          ExampleEnum.value.value]}

# Generated at 2022-06-21 11:26:56.533448
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(UUID('9b0c58a6-3b21-45dd-a0c6-b1f3f3d3d13c')) == '9b0c58a6-3b21-45dd-a0c6-b1f3f3d3d13c'
    assert encoder.default(Decimal(1)) == '1'
    assert encoder.default(datetime.fromtimestamp(123456, tz=timezone.utc)) == 123456
    assert encoder.default(datetime(1992, 3, 2, 3, 2, 0)) == 679361200.0
    assert encoder.default([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-21 11:26:58.492671
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(exclude=None, encoder=None, decoder=None, letter_case=None)

# Generated at 2022-06-21 11:27:09.092025
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default({'a': 1, 'b': '2'}) == {'a': 1, 'b': '2'}
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    epoch_time = datetime(1970, 1, 1, tzinfo=timezone.utc)
    assert encoder.default(epoch_time) == 0
    uuid_str = '0a3e3a91-7273-4d1c-97a0-9b37d7e2c1f2'
    uuid = UUID(uuid_str)
    assert encoder.default(uuid) == uuid_str
    assert encoder.default(True) is True



# Generated at 2022-06-21 11:27:19.551324
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f1 = FieldOverride()
    f2 = FieldOverride(None, None, None)
    f3 = FieldOverride("lower", lambda v: v, lambda v: v)
    f4 = FieldOverride(exclude=lambda v: v)

    assert str(f1) == "FieldOverride(letter_case=None, exclude=None, encoder=None)"
    assert str(f2) == "FieldOverride(letter_case=None, exclude=None, encoder=None)"
    assert str(f3) == "FieldOverride(letter_case='lower', exclude=<function lambda_ at 0x7fa4c1d7e0d0>, encoder=<function FieldOverride.<lambda> at 0x7fa4c1d7e158>)"

# Generated at 2022-06-21 11:27:20.500619
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(letter_case=snakecase)

# Generated at 2022-06-21 11:27:33.174136
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Success case
    with_encoder_decoder = FieldOverride(
        allow_none=False,
        exclude=None,
        hook=None,
        letter_case=None,
        encoder=int,
        decoder=str
    )

    # Success case
    with_encoder_decoder_format = FieldOverride(
        allow_none=False,
        exclude=None,
        hook=None,
        letter_case=None,
        encoder=lambda x: int(x),
        decoder=lambda x: str(x),
        format=lambda x: '{:.2f}'.format(x)
    )

    # Success case

# Generated at 2022-06-21 11:28:02.072653
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default(datetime.now(tz=timezone.utc)) == datetime.now().timestamp()
    assert enc.default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert enc.default(Decimal('0.0')) == "0.0"
    assert enc.default(Decimal(0)) == "0"
    assert enc.default(Decimal(0.0)) == "0.0"



# Generated at 2022-06-21 11:28:09.895895
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Set the default value
    field_override = FieldOverride(
        exclude=None,
        letter_case=None,
        encoder=None,
        decoder=None,
        mm_field=None,
    )

    if field_override.exclude is not None:
        raise Exception("FieldOverride default value for exclude is not null")
    if field_override.letter_case is not None:
        raise Exception(
            "FieldOverride default value for letter_case is not null")
    if field_override.encoder is not None:
        raise Exception("FieldOverride default value for encoder is not null")
    if field_override.decoder is not None:
        raise Exception("FieldOverride default value for decoder is not null")

# Generated at 2022-06-21 11:28:22.208740
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import pytest
    from datetime import datetime

    @cfg
    class _ObjectEncoder:
        obj: Any

    enc = _ObjectEncoder(obj='hello')
    encoder = _ExtendedEncoder()
    json_encode = json.dumps(enc, cls=encoder.__class__).encode()
    assert encoder.default('hello') == json.loads(json_encode)

    @cfg
    class _ListEncoder:
        list_: list

    lis = _ListEncoder(list_=[1, 2, 3])
    encoder = _ExtendedEncoder()
    json_encode = json.dumps(lis, cls=encoder.__class__).encode()
    assert encoder.default([1, 2, 3]) == json.loads(json_encode)

# Generated at 2022-06-21 11:28:27.212219
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    for field_name in ["int_1", "float_2", "str_3", "int_4", "int_5"]:
        overrides = _user_overrides_or_exts(TestDataclass)
        assert isinstance(overrides.get(field_name), FieldOverride)
        assert overrides[field_name].name == field_name


# Generated at 2022-06-21 11:28:34.025487
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # type: () -> None
    class MyEncoder(_ExtendedEncoder):
        # pylint: disable=unused-argument
        def __init__(self, *args, **kwargs):
            json.JSONEncoder.__init__(self, *args, **kwargs)
        def default(self, o):
            # type: (Any) -> Json
            raise TypeError('Unknown type: {}'.format(type(o)))

# Generated at 2022-06-21 11:28:38.293867
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    global_config = Config(encoders={int: int, float: float},
                           decoders={Decimal: Decimal},
                           mm_fields={Decimal: mm.Decimal})
    cfg.global_config = global_config
    overrides = {
        'bar': FieldOverride(exclude=lambda x: x is None,
                             letter_case=lambda x: x.upper()),
        'baz': FieldOverride(encoder=float),
        'qux': FieldOverride(decoder=Decimal),
        'quux': FieldOverride(mm_field=mm.Decimal)
    }
    cls = type('A', (), overrides)
    assert _user_overrides_or_exts(cls) == overrides
    foo = DataclassField('foo', type=int)
   

# Generated at 2022-06-21 11:28:48.187168
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Decimal
    assert _ExtendedEncoder().default(Decimal()) == ''
    assert _ExtendedEncoder().default(Decimal(1)) == '1'
    assert _ExtendedEncoder().default(Decimal(1.1)) == '1.1'
    assert _ExtendedEncoder().default(Decimal(1.11)) == '1.11'
    # datetime
    assert _ExtendedEncoder().default(datetime(2020, 1, 2, 12, 12, 12, 1234)) == 1578011132.001234
    # Enum
    class TestEnum(Enum):
        a = 'a'
        b = 'b'
    assert _ExtendedEncoder().default(TestEnum.a) == 'a'
    # UUID

# Generated at 2022-06-21 11:28:57.207690
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    d = datetime(year=1970, month=1, day=1, tzinfo=timezone.utc)
    assert encoder.encode([]) == "[]"
    assert encoder.encode({}) == "{}"
    assert encoder.encode([d]) == "[0.0]"
    assert encoder.encode((d,)) == "[0.0]"
    # assert encoder.encode(set([d])) == "[0.0]" # Does not work. Why?
    assert encoder.encode({d: d}) == "{0.0: 0.0}"

# Generated at 2022-06-21 11:29:06.307537
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    FieldOverride(None, False, None)
    FieldOverride(None, True, None)
    FieldOverride(lambda x: x, False, None)
    FieldOverride(lambda x: x, True, None)
    FieldOverride(None, False, lambda x: x)
    FieldOverride(None, True, lambda x: x)
    FieldOverride(lambda x: x, False, lambda x: x)
    FieldOverride(lambda x: x, True, lambda x: x)
    FieldOverride(None, False, is_dataclass)
    FieldOverride(None, True, is_dataclass)
    FieldOverride(lambda x: x, False, is_dataclass)
    FieldOverride(lambda x: x, True, is_dataclass)
    FieldOverride(None, False, lambda x: x)

# Generated at 2022-06-21 11:29:15.681839
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now())
    assert _ExtendedEncoder().default(UUID('d43d0c75-8f0e-40af-9e4b-4f05b34f2bde'))
    assert _ExtendedEncoder().default(Decimal('1.1'))
    assert _ExtendedEncoder().default(MappingProxyType({'a': 'b'}))
    assert _ExtendedEncoder().default(ChainMap(a='b'))
    assert _ExtendedEncoder().default(Counter('ab'))
    assert _ExtendedEncoder().default(OrderedDict([('a', 'b')]))
    assert _ExtendedEncoder().default(defaultdict(int, {'a': 1}))

# Generated at 2022-06-21 11:29:43.356247
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    global _ExtendedEncoder

    assert 'foobar' == _ExtendedEncoder().default('foobar')
    assert 42 == _ExtendedEncoder().default(42)
    assert 42 == _ExtendedEncoder().default(Decimal('42'))
    assert 42 == _ExtendedEncoder().default(Decimal('42.0000000000'))
    assert 42.0 == _ExtendedEncoder().default(42.0)
    assert True == _ExtendedEncoder().default(True)
    assert False == _ExtendedEncoder().default(False)
    assert None is _ExtendedEncoder().default(None)
    assert ['foo', 'bar'] == _ExtendedEncoder().default(['foo', 'bar'])

# Generated at 2022-06-21 11:29:55.251909
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    res = e.default(set())
    assert res == []
    res = e.default(tuple([1, 2, 3]))
    assert res == [1, 2, 3]
    res = e.default(frozenset([1, 2, 3]))
    assert res == [1, 2, 3]
    res = e.default(dict(x=1, y=2, z=3))
    assert res == {'x': 1, 'y': 2, 'z': 3}
    res = e.default(datetime(2019, 1, 1, 12, 0, 0, 0, timezone.utc))
    assert res == 1546314800.0

# Generated at 2022-06-21 11:30:07.102518
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # fmt: off
    source = [
        True, False, None,
        1, 2, 3, 1.0, 2.0, 3.0,
        [1, 2, 3], [1, 2, [3, 4]],
        { "a": 1, "b": 2 }, { "a": 1, "b": [2, 3] },
        { "a": 1, "b": { "c": 2 } },
        set([1, 2, 3]),
        datetime(2020, 5, 12, 12, 30, 0, 0, timezone.utc),
        {"ms": 123, "time": datetime(2020, 5, 12, 12, 30, 0, 0, timezone.utc)},
        UUID('00000000-0000-0000-0000-000000000001'),
    ]

# Generated at 2022-06-21 11:30:08.399275
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    try:
        FieldOverride()
    except:
        print('Constructor of class FieldOverride does not exist')


# Generated at 2022-06-21 11:30:12.311332
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    @dataclass
    class Foo:
        bar:str = field(metadata={"dataclasses_json": {
            "letter_case": letter_case,
            "exclude": exclude,
            "encoder": encoder,
            "decoder": decoder,
        }})
    field = _user_overrides_or_exts(Foo)['bar']
    assert field.letter_case == letter_case
    assert field.exclude == exclude
    assert field.encoder == encoder
    assert field.decoder == decoder

# Generated at 2022-06-21 11:30:12.902355
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Reserved for future
    pass


# Generated at 2022-06-21 11:30:17.595162
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    test_inputs = [
        (None,'pascal',lambda x: x, lambda x: x),
        (None,'snake',lambda x: x, lambda x: x),
        (None,'camel',lambda x: x, lambda x: x),
        (lambda x: True,'pascal',lambda x: x, lambda x: x),
        (lambda x: True,'snake',lambda x: x, lambda x: x),
        (lambda x: True,'camel',lambda x: x, lambda x: x)
    ]
    for (exclude,letter_case,encoder,decoder) in test_inputs:
        test_override = FieldOverride(exclude,letter_case,encoder,decoder)
        assert test_override.exclude == exclude
        assert test_override.letter_case == letter_

# Generated at 2022-06-21 11:30:27.770184
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default(UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8')) == '6ba7b810-9dad-11d1-80b4-00c04fd430c8'
    assert _ExtendedEncoder().default(Decimal('1.0')) == '1.0'
    assert _ExtendedEncoder().default(Decimal(1)) == '1'  # decimal is a subtype of int
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(False) is False

# Generated at 2022-06-21 11:30:29.236328
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _ExtendedEncoder().default(set())
    _ExtendedEncoder().default(frozenset())



# Generated at 2022-06-21 11:30:35.787226
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(1970, 1, 1, 0, 0, 0, 0, timezone.utc)) == '0'
    assert _ExtendedEncoder().encode('foo') == '"foo"'
    assert _ExtendedEncoder().encode((1, 2, 3)) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({ 'a': 1, 'b': 2 }) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(UUID("f006da26-f2ba-4db2-9c7a-e979adb7ff55")) == '"f006da26-f2ba-4db2-9c7a-e979adb7ff55"'

# Generated at 2022-06-21 11:31:30.658858
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == 1585055322.996747
    assert _ExtendedEncoder().default({'a':1}) == {'a':1}
    assert _ExtendedEncoder().default([1,2,3]) == [1,2,3]
    assert _ExtendedEncoder().default(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'

"""
Encoder
"""

# Generated at 2022-06-21 11:31:41.191034
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(42) == 42
    assert _ExtendedEncoder().default('spam') == 'spam'
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default((1, 2)) == [1, 2]
    assert _ExtendedEncoder().default({'spam': 42}) == {'spam': 42}
    assert _ExtendedEncoder().default({'spam': 42, 'spam2': 43}) == {'spam': 42, 'spam2': 43}
    assert _ExtendedEncoder().default(set([1, 2])) == [1, 2]
   

# Generated at 2022-06-21 11:31:46.721687
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from enum import IntEnum
    from decimal import Decimal
    from uuid import UUID

    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now())
    assert encoder.default(UUID('00000000-0000-0000-0000-000000000000'))
    assert encoder.default(IntEnum('Foo', {'foo': 1}))
    assert encoder.default(Decimal('1.23'))



# Generated at 2022-06-21 11:31:57.402382
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1: [1, 2, 3]}) == '{"1": [1, 2, 3]}'
    assert _ExtendedEncoder().encode(['a', 'b']) == '["a", "b"]'
    assert _ExtendedEncoder().encode(UUID('f9598763-a628-49f0-b46d-b8eab5b1c0a5')) == '"f9598763-a628-49f0-b46d-b8eab5b1c0a5"'
    assert _ExtendedEncoder().encode(datetime(2017, 1, 1, 12, 0, tzinfo=timezone.utc)) == '{"$datetime": 1483246800}'

# Generated at 2022-06-21 11:31:59.262330
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    obj = _ExtendedEncoder()  # type: ignore
    assert obj.encode([1, 2]) == '[1, 2]'



# Generated at 2022-06-21 11:32:01.821642
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    print('test_FieldOverride')
    data_cls = FieldOverride(exclude=None, letter_case=None,
                             encoder=None, decoder=None)


# Generated at 2022-06-21 11:32:10.430762
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Test the field override constructor, which generates a class
    instance containing the override information.
    """
    # A dummy function which returns the input
    f = lambda x: x

    field_override = FieldOverride()
    assert field_override.letter_case == None
    assert field_override.exclude == None
    assert field_override.encoder == None
    assert field_override.decoder == None

    # TODO: Note that since the encoder and decoder can be anything,
    # we cannot check for correctness, only for whether or not the
    # constructor correctly assigns the data.
    field_override = FieldOverride(letter_case=f, exclude=f,
                                   encoder=f, decoder=f)
    assert field_override.letter_case == f

# Generated at 2022-06-21 11:32:18.728312
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(exclude=lambda v: v is not None,
                                   letter_case=lambda n: n.upper(),
                                   encoder=lambda v: v*2,
                                   decoder=lambda v: v*2)

    assert field_override.exclude == (lambda v: v is not None)
    assert field_override.letter_case == (lambda n: n.upper())
    assert field_override.encoder == (lambda v: v*2)
    assert field_override.decoder == (lambda v: v*2)



# Generated at 2022-06-21 11:32:19.671705
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-21 11:32:22.763725
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps({'a': 1, 'b': [1, 2]}, cls=_ExtendedEncoder)


# Generated at 2022-06-21 11:33:12.239693
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2]) == json.dumps([1, 2])
    assert _ExtendedEncoder().encode({'a': 1}) == json.dumps({'a': 1})
    assert _ExtendedEncoder().encode(
        datetime(2000, 1, 1, 0, 0, 1, 1000, timezone.utc)) == '946688401.001'
    assert _ExtendedEncoder().encode(UUID('{123e4567-e89b-12d3-a456-426655440000}')) == '"123e4567-e89b-12d3-a456-426655440000"'
    assert _ExtendedEncoder().encode(Decimal('0.00000000004')) == '"0.00000000004"'


# Generated at 2022-06-21 11:33:18.643075
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now().replace(tzinfo=timezone.utc))
    assert _ExtendedEncoder().encode(UUID('ea6ec935-9d2c-4d7f-a4c4-a5c2a5e5d5fe'))
    assert _ExtendedEncoder().encode(Decimal('0.1'))
    assert _ExtendedEncoder().encode({})
    assert _ExtendedEncoder().encode([])



# Generated at 2022-06-21 11:33:24.667890
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    empty_list = []
    empty_dict = {}
    empty_range = range(0)
    empty_set = set([])
    empty_frozenset = frozenset([])
    empty_tuple = tuple()
    from datetime import datetime

    # TODO: Add named tuple/frozen set/Iterable to UT
    ee = _ExtendedEncoder()

    assert ee.default(empty_list) == []
    assert ee.default(empty_dict) == {}
    assert ee.default(empty_range) == []
    assert ee.default(empty_set) == []
    assert ee.default(empty_frozenset) == []
    assert ee.default(empty_tuple) == []

    date = datetime(2010, 10, 10, 10, 10)
   

# Generated at 2022-06-21 11:33:31.364666
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import dataclasses_json #noqa
    assert _ExtendedEncoder(sort_keys=True, indent=4).encode({"value": dataclasses_json.decode({"value": "1"}, cfg.MM_FIELD), "name": "name"}) == '{\n    "name": "name",\n    "value": {\n        "number": 1,\n        "type": {}\n    }\n}' #noqa



# Generated at 2022-06-21 11:33:40.954340
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default([3, '3', {3: 3.0}]) == [3, '3', {3: 3.0}]
    assert _ExtendedEncoder().default({3: 3.0, 2: 2.0, 1: 1.0}) == {3: 3.0, 2: 2.0, 1: 1.0}
    assert _ExtendedEncoder().default(UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8')) == '6ba7b810-9dad-11d1-80b4-00c04fd430c8'
    assert _ExtendedEncoder().default(datetime(2019, 5, 14, 14, 20)) == datetime(2019, 5, 14, 14, 20).timestamp()
    assert _

# Generated at 2022-06-21 11:33:51.069317
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(123) == 123
    assert _ExtendedEncoder().default(12.3) == 12.3
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default('abc') == 'abc'
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default(range(3)) == [0, 1, 2]
    assert _ExtendedEncoder().default({'abc': 4, 'def': 7}) == {'abc': 4, 'def': 7}
    assert _ExtendedEncoder().default(datetime(2020, 3, 4, 5, 0, 0)) == 1583337600.0