

# Generated at 2022-06-21 11:24:23.534699
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(True, _ascii_upper_case, _repr)
    assert field_override.exclude == True
    assert field_override.letter_case == _ascii_upper_case
    assert field_override.encoder == _repr



# Generated at 2022-06-21 11:24:32.798909
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(0) == 0
    assert encoder.default(0.5) == 0.5
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(None) is None
    assert encoder.default('') == ''
    assert encoder.default('a') == 'a'
    assert encoder.default(b'a') == 'a'
    assert encoder.default([0, 1]) == [0, 1]
    assert encoder.default((0, 1)) == [0, 1]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

# Generated at 2022-06-21 11:24:40.247815
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps(list(range(10)), cls=_ExtendedEncoder)
    json.dumps(dict(zip(list(range(10)), list(range(10)))), cls=_ExtendedEncoder)
    d = datetime.now(tz=timezone.utc)
    json.dumps(d, cls=_ExtendedEncoder)
    json.dumps(UUID('e8e561c1-f5cc-4735-8d0f-9f941b1a0441'), cls=_ExtendedEncoder)
    json.dumps(Decimal('3.1415926535'), cls=_ExtendedEncoder)



# Generated at 2022-06-21 11:24:48.874592
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test default values
    assert (FieldOverride() ==
            FieldOverride(letter_case=None, exclude=None,
                          encoder=None, decoder=None) ==
            FieldOverride(letter_case=None, exclude=None,
                          encoder=lambda x: x, decoder=lambda x: x))

    # Letter case: If a string is provided, convert it to a function
    assert (FieldOverride(letter_case='snake') ==
            FieldOverride(letter_case=lambda x: x.lower()))
    assert (FieldOverride(letter_case='snake', exclude=lambda x: True) ==
            FieldOverride(letter_case=lambda x: x.lower(),
                          exclude=lambda x: True))

    # Exclude: If True is provided, convert it to a lambda

# Generated at 2022-06-21 11:24:58.814797
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test creating a field override with no args
    field_override = FieldOverride()
    assert field_override.letter_case is None
    assert field_override.exclude is None
    assert field_override.encoder is None
    assert field_override.decoder is None
    
    # Test creating a field override with args
    field_override = FieldOverride(
        letter_case=lambda x: x.lower(),
        exclude=lambda x: x,
        encoder=lambda x: x,
        decoder=lambda x: x
    )
    assert field_override.letter_case is not None
    assert field_override.exclude is not None
    assert field_override.encoder is not None
    assert field_override.decoder is not None
    
    # Test creating a field override with

# Generated at 2022-06-21 11:25:07.009936
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(set([1])) == [1]  # type: ignore
    assert _ExtendedEncoder().default(frozenset([1])) == [1]  # type: ignore
    assert _ExtendedEncoder().default({1: 2}) == {1: 2}
    assert _ExtendedEncoder().default(datetime.now()) == \
        _ExtendedEncoder().default(datetime.now(tz=timezone.utc))

# Generated at 2022-06-21 11:25:13.164112
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    type_ = str
    letter_case = None
    exclude = None
    encoder = None
    decoder = None
    field_override = FieldOverride(letter_case, exclude, encoder, decoder)
    assert field_override.letter_case is None
    assert field_override.exclude is None
    assert field_override.encoder is None
    assert field_override.decoder is None



# Generated at 2022-06-21 11:25:23.429282
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(None, None, str) is not None
    assert FieldOverride(None, lambda x: True, str) is not None
    assert FieldOverride('ENV_', None, str) is not None
    assert FieldOverride('ENV_', lambda x: True, str) is not None
    assert FieldOverride(None, None, _camel_case) is not None
    assert FieldOverride(None, lambda x: True, str) is not None
    assert FieldOverride('ENV_', None, str) is not None
    assert FieldOverride('ENV_', lambda x: True, str) is not None

    assert FieldOverride(None, None, str).letter_case == str

# Generated at 2022-06-21 11:25:31.805832
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    class MyClass:
        pass
    assert _ExtendedEncoder().default(MyClass) is MyClass
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(set([1, 2])) == [1, 2]
    assert _ExtendedEncoder().default(frozenset()) == []
    assert _ExtendedEncoder().default(frozenset([1, 2])) == [1, 2]
    assert _ExtendedEncoder().default(MyClass) is MyClass
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(1.1) == 1.1
    assert _ExtendedEncoder().default(b"") == ""
    assert _ExtendedEncoder

# Generated at 2022-06-21 11:25:43.797332
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Arrange
    encoder = _ExtendedEncoder()
    # Act
    json.dumps(set(), cls=encoder)
    json.dumps({0: set()}, cls=encoder)
    json.dumps(dict(), cls=encoder)
    json.dumps([0, 1, 2], cls=encoder)
    json.dumps({0: 1, 1: 2}, cls=encoder)
    json.dumps(datetime.now(timezone.utc), cls=encoder)
    json.dumps(UUID('91e7f46c-aa54-49f5-92de-29eb8e20c2a2'), cls=encoder)
    json.dumps(Decimal('0.1'), cls=encoder)



# Generated at 2022-06-21 11:26:15.993528
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'
    assert _ExtendedEncoder().encode({1, 2, 3}) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({1: 'a', 2: 'b', 3: 'c'}) == '{"1": "a", "2": "b", "3": "c"}'
    dt = datetime(1900, 8, 29, 17, 19, 50, 500000, timezone(timedelta(hours=-5)))
    assert _ExtendedEncoder().encode(dt) == '-2117967400'

# Generated at 2022-06-21 11:26:26.712903
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encode_parameters = {'indent': 4, 'ensure_ascii': False, 'default': _ExtendedEncoder().default}  # type: ignore
    encode_parameters = dict(encode_parameters, separators=(',', ': '))
    source_json = '{"a": 1, "b": {"c": [2, 3], "d": [{"e": [4, 5], "f": {"g": 6, "h": [7, 8, 9]}}], "i":"j"}, "k": true, "l":{"m":false, "n": null, "o": 1.0, "p":-1.0, "q":-1.0e-10, "r":-0.0e-1}}'

# Generated at 2022-06-21 11:26:37.653046
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(None, None, None) == FieldOverride.__defaults__
    assert FieldOverride(exclude=lambda x: x == 1, letter_case=str.lower,
                         encoder=None, decoder=None) == (
        FieldOverride(exclude=lambda x: x == 1, letter_case=str.lower,
                      encoder=None, decoder=None))
    assert FieldOverride(exclude=lambda x: x == 1, letter_case=None,
                         encoder=None, decoder=None) == (
        FieldOverride(exclude=lambda x: x == 1, letter_case=None,
                      encoder=None, decoder=None))

# Generated at 2022-06-21 11:26:44.700563
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(None, None, None, None).exclude is None
    assert FieldOverride(None, None, None, None).letter_case is None
    assert FieldOverride(None, None, None, None).encoder is None
    assert FieldOverride(None, None, None, None).decoder is None
    assert FieldOverride(None, None, None, None).mm_field is None

    assert FieldOverride(None, None, None, 'name').mm_field == 'name'



# Generated at 2022-06-21 11:26:55.424647
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    json_encoder = _ExtendedEncoder()
    result = json_encoder.default(set())
    assert type(result) is list
    json_encoder = _ExtendedEncoder()
    result = json_encoder.default(1.0)
    assert type(result) is float
    json_encoder = _ExtendedEncoder()
    result = json_encoder.default([1, 2, 3])
    assert type(result) is list
    json_encoder = _ExtendedEncoder()
    result = json_encoder.default({"a": 1, "b": 2})
    assert type(result) is dict
    json_encoder = _ExtendedEncoder()

# Generated at 2022-06-21 11:26:58.016203
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    override = FieldOverride()
    assert override.exclude is None
    assert override.encoder is None
    assert override.decoder is None
    assert override.letter_case is None

# Generated at 2022-06-21 11:27:00.598396
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(set([1, 2]), cls=_ExtendedEncoder) == '[1, 2]'



# Generated at 2022-06-21 11:27:11.363888
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()

    assert e.default([1,2,3]) == [1,2,3]
    assert e.default([1,2,3]) is not [1,2,3]

    assert e.default(defaultdict(lambda: 'a', {1: 2})) == {1: 2}
    assert e.default(defaultdict(lambda: 'a', {1: 2})) is not {1: 2}

    assert e.default(datetime.now(tz=timezone.utc)) == datetime.now(tz=timezone.utc).timestamp()

    assert e.default(UUID('123123123')) == '123123123'

    assert e.default(Decimal('0.03')) == '0.03'


_orig_obj_dict = dict

#

# Generated at 2022-06-21 11:27:21.161697
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default(): # type: () -> None
    extended_encoder = _ExtendedEncoder()

    original = [True, False, None, {'a': 1, 'b': 2},
                ['a', 'b'], ('a', 'b'), 'abc', 1, 2, 3.1]
    assert extended_encoder.encode(original) == json.dumps(original)

    original = {'a': 1, 'b': 2}
    assert extended_encoder.encode(original) == json.dumps(original)

    original = {'a': 1, 'b': 2}
    assert extended_encoder.encode(original) == json.dumps(original)


# Generated at 2022-06-21 11:27:33.882775
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(dict(a=1), cls=_ExtendedEncoder) == json.dumps(dict(a=1))
    assert json.dumps([1, 2, 3], cls=_ExtendedEncoder) == json.dumps([1, 2, 3])
    assert json.dumps("abc", cls=_ExtendedEncoder) == json.dumps("abc")
    assert json.dumps(1, cls=_ExtendedEncoder) == json.dumps(1)
    assert json.dumps(1.0, cls=_ExtendedEncoder) == json.dumps(1.0)
    assert json.dumps(True, cls=_ExtendedEncoder) == json.dumps(True)

# Generated at 2022-06-21 11:28:03.289618
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    foo = FieldOverride()
    assert foo.letter_case() == 'foo'

    bar = FieldOverride(letter_case=camelcase)
    assert bar.letter_case() == "fooBar"

    foobar = FieldOverride(letter_case=camelcase, exclude=lambda x: x == 'foo')
    assert foobar.letter_case() == "fooBar"
    assert foobar.exclude('foo') == True
    assert foobar.exclude('bar') == False

    class Foo:
        pass

    foo = Foo()
    bar = FieldOverride(letter_case=camelcase, exclude=lambda x: x == foo)
    assert bar.letter_case() == "fooBar"
    assert bar.exclude(foo) == True
    assert bar.exclude('bar') == False



# Generated at 2022-06-21 11:28:13.826428
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test the constructor of FieldOverride
    field_override = FieldOverride(exclude=lambda x: False,
                                   letter_case=lambda x: x.lower(),
                                   encoder=lambda x: x.upper(),
                                   decoder=lambda x: x.lower(),
                                   mm_field=None)
    assert field_override is not None, "Failed to instantiate FieldOverride"
    # Test the encoder option
    result = field_override.encoder("TEST")
    assert result == "test", f"Encoder failed: expected 'test' but got '{result}'"
    # Test the decoder option
    result = field_override.decoder("Test")
    assert result == "test", f"Decoder failed: expected 'test' but got '{result}'"
    # Test the letter_case option

# Generated at 2022-06-21 11:28:24.638925
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default(1.1) == 1.1
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(None) == None
    assert encoder.default('abc') == 'abc'
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    class A(object):
        a = 1
    a = A()
    assert encoder.default(a) == a
    assert encoder.default(set()) == []
    assert encoder.default({1, 2, 3}) == [1, 2, 3]
    assert encoder

# Generated at 2022-06-21 11:28:32.550146
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default(None) is None
    assert enc.default(False) is False
    assert enc.default(True) is True
    assert enc.default(0) == 0
    assert enc.default(1.1) == 1.1
    assert enc.default('') == ''
    assert enc.default('abc') == 'abc'
    assert enc.default(b'abc') == 'abc'
    assert enc.default([]) == []
    assert enc.default({}) == {}
    assert enc.default(['abc', 1, False]) == ['abc', 1, False]
    assert enc.default({'a': 'b', 'c': 1, 'd': False}) == {'a': 'b', 'c': 1, 'd': False}

# Generated at 2022-06-21 11:28:44.158508
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert  _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc)) == 0
    assert _ExtendedEncoder().default(datetime(2019, 3, 22, 18, 34, 32, tzinfo=timezone.utc)) == 15533144172
    assert _ExtendedEncoder().default(datetime(2019, 3, 22, 18, 34, 32)) == 15533144172
    assert _ExtendedEncoder().default(datetime(2019, 3, 22, 18, 34, 32, 123, tzinfo=timezone.utc)) == 15533144172.123
    assert _ExtendedEncoder().default(datetime(2019, 3, 22, 18, 34, 32, 123)) == 15533144172.123
# End of unit test for method default of class _ExtendedEnc

# Generated at 2022-06-21 11:28:53.557293
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(
        [1, 2, 3],
        cls=_ExtendedEncoder
    ) == '[1, 2, 3]'
    assert json.dumps(
        {'foo': [{'bar': ['baz', None, 1.0, 2]}]},
        cls=_ExtendedEncoder
    ) == '''{"foo": [{"bar": ["baz", null, 1.0, 2]}]}'''
    assert json.dumps(
        datetime(2012, 1, 1, 18, 21, 59, tzinfo=timezone.utc),
        cls=_ExtendedEncoder
    ) == '1325376019.0'

# Generated at 2022-06-21 11:28:55.643087
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    override = FieldOverride(exclude=lambda x: x == 'pinky', decoder=str)
    assert override.exclude('pinky') is True
    assert override.exclude('brain') is False
    assert override.decoder('to me to you') == 'to me to you'


# Generated at 2022-06-21 11:29:01.743074
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import date, time
    from decimal import Decimal
    from enum import Enum
    from uuid import UUID

    class Color(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3

    test_data = [
        (["a", "b"], [1, 2], dict(a=1, b=2), set([1, 2]), frozenset([1, 2]),
         date.today(), time(), datetime.now(), UUID('56f6e4f6-4bc6-4f3a-a6aa-821b7c6e3fde'),
         Decimal('3.1415926535'), Color.RED),
    ]

    for data in test_data:
        json_str = json.dumps(data, cls=_ExtendedEncoder)
       

# Generated at 2022-06-21 11:29:12.378814
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test_1()
    # field_override = FieldOverride(exclude=lambda: True,
    #                                letter_case='snake',
    #                                encoder=lambda x: x,
    #                                decoder=lambda x: x)
    # test_2()
    # field_override = FieldOverride(exclude=None,
    #                                letter_case=None,
    #                                encoder=None,
    #                                decoder=None)
    # test_3()
    field_override = FieldOverride(exclude=None,
                                   letter_case=None,
                                   encoder=str,
                                   decoder=str)
    # test_4()
    # field_override = FieldOverride(exclude=lambda x: False,
    #                                letter_case=lambda

# Generated at 2022-06-21 11:29:22.072170
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    input_list = [1, 2, 3]
    input_dict = {"1" : 1, "2" : 2, "3" : 3}
    input_datetime = datetime.now()
    input_uuid = UUID("{7f0f5e5e-1405-4cb5-a7e3-3a3e12a42d8c}")
    input_enum = Enum('number', {'one': 1, 'two': 2, 'three': 3})
    input_decimal = Decimal("1.1")

    json.dumps(input_list, cls=_ExtendedEncoder)
    json.dumps(input_dict, cls=_ExtendedEncoder)
    json.dumps(input_datetime, cls=_ExtendedEncoder)
    json.d

# Generated at 2022-06-21 11:29:45.813734
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    d = datetime.now()
    assert encoder.default(d) == d.timestamp()
    assert encoder.default(Enum('Enum', 'a b c')) == 'a'
    assert encoder.default(Decimal('3.14')) == '3.14'



# Generated at 2022-06-21 11:29:50.796893
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    test_data = [{ 'exclude': True, 'letter_case': True,
                   'encoder': True, 'decoder': True},
                 { 'exclude': False, 'letter_case': False,
                   'encoder': False, 'decoder': False},
                 { 'exclude': None, 'letter_case': None,
                   'encoder': None, 'decoder': None}]
    for t in test_data:
        f = FieldOverride(**t)
        assert t['exclude'] == f.exclude
        assert t['letter_case'] == f.letter_case
        assert t['encoder'] == f.encoder
        assert t['decoder'] == f.decoder

# Generated at 2022-06-21 11:30:02.964263
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    assert e.default({1, 2, 3}) == [1, 2, 3]
    assert e.default(range(3)) == [0, 1, 2]  # It is a list, not a range
    assert e.default(set(range(3))) == [0, 1, 2]  # It is a list, not a set
    assert e.default(datetime.now(timezone.utc)) == 1549131764.702145
    assert e.default(UUID('5d846f67-d611-47a1-8301-8d0b49f6b751')) == '5d846f67-d611-47a1-8301-8d0b49f6b751'

# Generated at 2022-06-21 11:30:12.606008
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(Decimal('0.1')) == '"0.1"'
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEncoder().encode({1: 2}) == '{"1": 2}'
    assert _ExtendedEncoder().encode(datetime(2020, 8, 13, 13, 30, 30, tzinfo=timezone.utc)) == '1597307430.0'
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000')) == '"123e4567-e89b-12d3-a456-426655440000"'

# Generated at 2022-06-21 11:30:23.188342
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test = _ExtendedEncoder()
    assert test.default(set([1, 2, 3, 1])) == [1, 2, 3]
    assert test.default({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}
    now = datetime.now(timezone.utc)
    assert test.default(now) == now.replace(tzinfo=None).timestamp()
    uuid = UUID('d7d3c0ec-25e3-411f-9d9d-60d67a0b8df8')
    assert test.default(uuid) == "d7d3c0ec-25e3-411f-9d9d-60d67a0b8df8"

# Generated at 2022-06-21 11:30:32.067989
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps({"key": None}, cls=_ExtendedEncoder) == '{"key": null}'
    assert json.dumps({"key": []}, cls=_ExtendedEncoder) == '{"key": []}'
    assert json.dumps({"key": {}}, cls=_ExtendedEncoder) == '{"key": {}}'
    assert json.dumps({"key": datetime.now(tz=timezone.utc)}, cls=_ExtendedEncoder)
    assert json.dumps({"key": UUID("{00000000-0000-0000-0000-000000000000}")}, cls=_ExtendedEncoder)
    assert json.dumps({"key": Decimal("0.000001")}, cls=_ExtendedEncoder)

# Generated at 2022-06-21 11:30:41.010629
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime.now(timezone.utc)) == 1575761600.0
    assert encoder.default(UUID("7f2d19e8-58a9-4c07-ae1f-89c8a537f66c")) == "7f2d19e8-58a9-4c07-ae1f-89c8a537f66c"
    assert encoder.default(Decimal("3.14")) == "3.14"
    assert encoder.default("hello") == "hello"
    assert encoder

# Generated at 2022-06-21 11:30:47.793630
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """Test for constructor of class _ExtendedEncoder"""
    assert _ExtendedEncoder() is not None

_extended_encoder = _ExtendedEncoder()

# noinspection PyProtectedMember
# pylint: disable=W0212
_extended_encoder.register(datetime, lambda x: x.timestamp())
_extended_encoder.register(Decimal, lambda x: str(x))
_extended_encoder.register(Enum, lambda x: x.value)
_extended_encoder.register(UUID, lambda x: x.hex)



# Generated at 2022-06-21 11:30:52.499089
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(exclude=lambda x: True,
                       letter_case=None,
                       encoder=None,
                       decoder=None)
    assert fo.exclude(42)
    assert fo.letter_case(42) == 42
    assert fo.encoder(42) == 42
    assert fo.decoder(42) == 42


# Generated at 2022-06-21 11:31:00.519773
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) == None
    assert encoder.default(True) == True
    assert encoder.default(123) == 123
    assert encoder.default(12.3) == 12.3
    assert encoder.default("abc") == "abc"
    assert encoder.default({"abc": "def"}) == {"abc": "def"}
    assert encoder.default(["abc", "def"]) == ["abc", "def"]
    assert encoder.default(UUID("12345678-1234-5678-1234-567812345678")) == "12345678-1234-5678-1234-567812345678"

# Generated at 2022-06-21 11:31:32.458153
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """
    test _ExtendedEncoder class by using it to encode some objects
    """
    list1 = [1,2,3]
    list1_result = '[1, 2, 3]'

    int1 = 1
    int1_result = '1'

    str1 = 'asd'
    str1_result = '"asd"'

    dict1 = {'a': 1, 'b': 2, 'c': 3}
    dict1_result = '{"a": 1, "b": 2, "c": 3}'

    enum1 = cfg.LetterCase.LOWERCASE
    enum1_result = '"lowercase"'

    dt1 = datetime(year=2020, month=1, day=2, hour=3, minute=4, second=5, tzinfo=timezone.utc)

# Generated at 2022-06-21 11:31:37.925627
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field = FieldOverride(x=None)
    assert field.exclude is None
    assert field.letter_case is None
    assert field.encoder is None
    assert field.decoder is None
    assert field.mm_field is None

    format_specifiers = [
        'exclude={}, letter_case={}, '
        'encoder={}, decoder={}, mm_field={}',
        'letter_case={}, encoder={}, decoder={}, mm_field={}, exclude={}',
        'encoder={}, decoder={}, mm_field={}, exclude={}, letter_case={}',
        'decoder={}, mm_field={}, exclude={}, letter_case={}, encoder={}',
        'mm_field={}, exclude={}, letter_case={}, encoder={}, decoder={}'
        ]



# Generated at 2022-06-21 11:31:46.564749
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    uuid = UUID(int=0)
    timestamp = datetime.now(timezone.utc).timestamp()

    encoder = _ExtendedEncoder()
    assert encoder.default(timestamp) == timestamp
    assert encoder.default({8: 9}) == {8: 9}
    assert encoder.default([8, 9]) == [8, 9]
    assert encoder.default(uuid) == str(uuid)
    assert encoder.default(Decimal('1.234')) == '1.234'
    assert encoder.default(1.234) == 1.234
    assert encoder.default(True) is True
    assert encoder.default(None) is None



# Generated at 2022-06-21 11:31:57.365880
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    data = [1, 2, {'key': (3, 4, 5)}]
    data_json = json.dumps(data)
    assert data_json == extended_encoder.encode(data)
    # test convert datetime
    date = datetime(2019, 7, 28, 15, 28, 24, tzinfo=timezone.utc)
    date_json = json.dumps(date.timestamp())
    assert date_json == extended_encoder.encode(date)
    # test convert enum
    class MyEnum(Enum):
        a = 1
    my_enum = MyEnum.a
    my_enum_json = json.dumps(my_enum.value)
    assert my_enum_json == extended_encoder.encode

# Generated at 2022-06-21 11:32:02.669676
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_dict = {'a': 'a', 'b': 1, 'c': [1, 2, 3], 'd': datetime(2020, 1, 1, 0, 0, tzinfo=timezone.utc)}
    assert json.dumps(test_dict, cls=_ExtendedEncoder) == '{"a": "a", "b": 1, "c": [1, 2, 3], "d": 1577836800.0}'



# Generated at 2022-06-21 11:32:10.996680
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default(1.2) == 1.2
    assert encoder.default('1') == '1'
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default(frozenset([1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-21 11:32:22.561262
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Given
    instance_1 = FieldOverride(
        exclude=lambda x: x is None,
        letter_case=camelize,
        encoder=lambda x: x.isoformat(),
        decoder=lambda x: dt.datetime.fromisoformat(x),
        mm_field=(
            lambda x: fields.DateTime(missing=None), lambda x: x.isoformat())
    )

    # Then
    assert isinstance(instance_1.exclude, Callable)
    assert isinstance(instance_1.letter_case, Callable)
    assert isinstance(instance_1.encoder, Callable)
    assert isinstance(instance_1.decoder, Callable)
    assert isinstance(instance_1.mm_field, Tuple)

    # Given

# Generated at 2022-06-21 11:32:30.814936
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(2016, 12, 25, 12, 34,
                                               56)) == datetime(2016, 12, 25, 12, 34,
                                                                56).timestamp()
    assert _ExtendedEncoder().default(datetime(2016, 12, 25, 12, 34,
                                               56,
                                               timezone.utc)) == datetime(2016, 12, 25, 12, 34,
                                                                          56,
                                                                          timezone.utc).timestamp()

# Generated at 2022-06-21 11:32:41.950310
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([_ExtendedEncoder()]) == '[null]'
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(range(10)) == '[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]'
    assert _ExtendedEncoder().encode({'one': 1, 'two': 2}) == '{"one": 1, "two": 2}'
    assert _ExtendedEncoder().encode({True, False}) == '[false, true]'
    assert _ExtendedEncoder().encode(datetime(year=2018, month=1, day=1)) == '1514764800.0'

# Generated at 2022-06-21 11:32:53.413780
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode([0, 1, 2]) == '[0, 1, 2]'
    assert _ExtendedEncoder().encode([[], []]) == '[[], []]'
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'

    # test for datetime.date
    dt_obj = datetime(2020, 4, 17, 8, 21, 20, 344000, tzinfo=timezone.utc)
    assert _ExtendedEncoder().encode(dt_obj) == "158709068.0"

# Generated at 2022-06-21 11:33:39.193420
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default({1: 2}) == {'1': 2}
    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default(datetime(2018, 10, 10, 12, 0, 0, tzinfo=timezone.utc)) == 1539154400.0



# Generated at 2022-06-21 11:33:48.740239
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # as init order is different than field order, ensure that init order is
    # respected and is not changed
    with pytest.raises(TypeError):
        FieldOverride(exclude=lambda x: x, letter_case=lambda x: x,
                      encoder=lambda x: x)
    with pytest.raises(TypeError):
        FieldOverride(exclude=lambda x: x, encoder=lambda x: x,
                      letter_case=lambda x: x)
    with pytest.raises(TypeError):
        FieldOverride(letter_case=lambda x: x, exclude=lambda x: x,
                      encoder=lambda x: x)
    with pytest.raises(TypeError):
        FieldOverride(letter_case=lambda x: x, encoder=lambda x: x,
                      exclude=lambda x: x)
