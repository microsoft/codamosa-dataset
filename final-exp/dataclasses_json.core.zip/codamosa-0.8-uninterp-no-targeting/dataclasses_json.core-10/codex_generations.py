

# Generated at 2022-06-21 11:24:30.134962
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now(timezone.utc)) is not None
    assert encoder.default(Decimal('10.99')) is not None
    assert encoder.default(UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8')) is not None
    assert encoder.default(Enum('Enum', 'a b')) is not None
    assert encoder.default([1, 2]) is not None
    assert encoder.default({1: 'a'}) is not None



# Generated at 2022-06-21 11:24:34.620144
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride()
    assert f.letter_case == None
    assert f.exclude == None
    assert f.encoder == None
    assert f.decoder == None
    assert f.mm_field == None
    assert f.mm_fields == None


# Generated at 2022-06-21 11:24:41.082285
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(set([1, 2, 3]), cls = _ExtendedEncoder) == '[1, 2, 3]'
    assert json.dumps(dict(one=1), cls = _ExtendedEncoder) == '{"one": 1}'
    assert json.dumps(123, cls = _ExtendedEncoder) == '123'


# Generated at 2022-06-21 11:24:43.391566
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert json.loads(json.dumps(['foo', 42], cls=_ExtendedEncoder)) == ['foo', 42]



# Generated at 2022-06-21 11:24:51.279073
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test constructor with a single input arg 'exclude',
    # other params should be None in the result.
    fo = FieldOverride(exclude=lambda x: x == 'exclude')
    assert fo.letter_case is None
    assert fo.encoder is None
    assert fo.decoder is None
    assert fo.exclude('') is False
    assert fo.exclude('exclude') is True
    # The object should be equal to itself
    assert fo == fo
    # The object should be equal to a copy of itself with same args
    assert fo == FieldOverride(exclude=lambda x: x == 'exclude')
    # The object should not be equal to a copy of itself with different args
    assert fo != FieldOverride(exclude=lambda x: x == '')
    # The object should not be equal to another object of different type

# Generated at 2022-06-21 11:25:00.973392
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default('') == ''
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default([None]) == [None]
    assert _ExtendedEncoder().default(0) == 0
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(Decimal('3.14')) == '3.14'
    assert _ExtendedEncoder().default(Enum) == Enum.__

# Generated at 2022-06-21 11:25:03.680439
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride()
    assert f.letter_case is None
    assert f.exclude is None
    assert f.encoder is None
    assert f.decoder is None



# Generated at 2022-06-21 11:25:13.533301
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    """
    Unit test for the JSONEncoder.default method of _ExtendedEncoder
    """
    class TestClass:
        """
        A simple test class that json.dumps does not know how to handle
        """
        def __init__(self, value):
            self.value = value


# Generated at 2022-06-21 11:25:18.114725
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    def f():
        pass  # noqa: E731

    overrides = FieldOverride(f, f, f, f)
    d = {'exclude': f, 'letter_case': f, 'encoder': f, 'decoder': f}
    assert overrides.__dict__ == d

# Generated at 2022-06-21 11:25:24.369879
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(True, True, lambda x: x, lambda x: x)
    assert FieldOverride(False, True, lambda x: x, lambda x: x)
    assert FieldOverride(True, False, lambda x: x, lambda x: x)
    assert FieldOverride(False, False, lambda x: x, lambda x: x)
    assert FieldOverride(False, False, None, lambda x: x)
    assert FieldOverride(False, False, lambda x: x, None)
    assert FieldOverride(False, False, None, None)


# Generated at 2022-06-21 11:25:51.556257
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    test_inst = FieldOverride(decoder=lambda x: x,
                              exclude=lambda x: x,
                              letter_case=lambda x: x,
                              encoder=lambda x: x,
                              mm_fields=lambda x: x)
    assert test_inst is not None

# Generated at 2022-06-21 11:26:00.635124
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test the constructor of FieldOverride class
    conf = {'letter_case': str.lower,
            'encoder': str.lower,
            'decoder': str.swapcase}
    # Test all valid arguments
    field_override = FieldOverride(*map(conf.get, confs))
    assert field_override.letter_case == conf['letter_case']
    assert field_override.encoder == conf['encoder']
    assert field_override.decoder == conf['decoder']

    # Test all valid arguments with default values
    field_override = FieldOverride(None, None, None)
    assert not field_override.letter_case
    assert not field_override.encoder
    assert not field_override.decoder

    # Test a tuple of arguments with default values

# Generated at 2022-06-21 11:26:13.037147
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_object = {
        "a": [1, 2, 3, {"b": (1, 2, 3)}],
        "dt_local": datetime(year=2020, month=4, day=4, hour=13, minute=30, second=0),
        "dt_utc": datetime(year=2020, month=4, day=4, hour=13, minute=30, second=0, tzinfo=timezone.utc),
        "decimal": Decimal("1.1"),
        "undef": Decimal("10.011") ** Decimal("1000.001"),
        "uuid": UUID("3a3fe2f1-7f33-4941-b4bf-2c8b6b4c6254"),
        "enum": cfg.enforce_enum.always
    }


# Generated at 2022-06-21 11:26:24.233796
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = object()
    j = json.JSONEncoder()
    e = _ExtendedEncoder()
    assert j.default(o) == e.default(o)
    assert e.default('') == ''
    assert e.default('a') == 'a'
    assert e.default(1) == 1
    assert e.default(1.1) == 1.1
    assert e.default(True) == True
    assert e.default(False) == False
    assert e.default(None) == None
    assert e.default([]) == []
    assert e.default([1]) == [1]
    assert e.default(set()) == []
    assert e.default(set([1])) == [1]
    assert e.default((1,)) == [1]
    assert e.default((1, 2))

# Generated at 2022-06-21 11:26:25.925834
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now()) == datetime.now().timestamp()



# Generated at 2022-06-21 11:26:29.855947
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default({"a": "b"}) == {"a": "b"}
    assert _ExtendedEncoder().default({"a": [1]}) == {"a": [1]}
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-21 11:26:32.983845
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder(cfg.indent)
    result = encoder.encode({'a': 1})
    assert isinstance(result, str)


# Generated at 2022-06-21 11:26:44.467516
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # coverage does not count lines in a string
    '''
    Test basic structures for serialization.
    These structures include:
        - list
        - tuple
        - set
        - dictionary
        - datetime
        - UUID
        - Decimal
        - enumerations (str, int)
        - string, int, float, bool
    '''

    term = datetime.now(tz=timezone.utc)

# Generated at 2022-06-21 11:26:55.210949
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps('test', cls=_ExtendedEncoder) == '"test"'
    assert json.dumps(1, cls=_ExtendedEncoder) == '1'
    assert json.dumps(1.1, cls=_ExtendedEncoder) == '1.1'
    assert json.dumps(True, cls=_ExtendedEncoder) == 'true'
    assert json.dumps(None, cls=_ExtendedEncoder) == 'null'
    assert json.dumps([1, 2, 3], cls=_ExtendedEncoder) == '[1, 2, 3]'
    assert json.dumps((1, 2, 3), cls=_ExtendedEncoder) == '[1, 2, 3]'

# Generated at 2022-06-21 11:27:05.710078
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Note that our ExtendedEncoder does not yet take care of JSON-DSL-based
    # classes that are not native to Python.
    # In this test, we check behavious for native Python classes only.
    encoder = _ExtendedEncoder()
    assert encoder.default(MappingProxyType({'x': 3})) == {'x': 3}
    assert encoder.default(FrozenSet({'x', 'y'})) == ['x', 'y']
    assert encoder.default(defaultdict(list, {1: 'x'})) == {1: 'x'}
    assert encoder.default(OrderedDict([('x', 3)])) == {'x': 3}
    class L(list):
        pass

# Generated at 2022-06-21 11:27:28.882148
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    instance = FieldOverride()
    assert instance.letter_case is None
    assert instance.exclude is None
    assert instance.encoder is None
    assert instance.decoder is None

# Unit tests for function _get_attributes

# Generated at 2022-06-21 11:27:40.048803
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    extended_encoder_default = encoder.default

    from datetime import date, time, timedelta
    from decimal import Decimal

    assert extended_encoder_default(1) == 1
    assert extended_encoder_default(True) is True
    assert extended_encoder_default(1.1) == 1.1
    assert extended_encoder_default(None) is None
    assert extended_encoder_default('abc') == 'abc'

    assert extended_encoder_default([1,2,3]) == [1,2,3]
    assert extended_encoder_default((1,2,3)) == [1,2,3]
    assert extended_encoder_default({'a':1,'b':2}) == {'a':1,'b':2}

    now

# Generated at 2022-06-21 11:27:52.137757
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f1 = FieldOverride()
    assert f1.encoder is None and f1.exclude is None \
            and f1.letter_case is None and f1.decoder is None

    test_encoder = lambda x: x+1
    test_decoder = lambda x: x-1
    test_exclude = lambda x: x > 3
    test_letter_case = lambda x: x.lower()

    f2 = FieldOverride(encoder=test_encoder, exclude=test_exclude,
                       letter_case=test_letter_case, decoder=test_decoder)
    assert f2.encoder == test_encoder and f2.exclude == test_exclude \
            and f2.letter_case == test_letter_case and f2.decoder == test_decoder


# Unit tests for

# Generated at 2022-06-21 11:28:03.860339
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default(None) is None
    assert enc.default(1) == 1
    assert enc.default(1.0) == 1.0
    assert enc.default(True) is True
    assert enc.default('abc') == 'abc'
    assert enc.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert enc.default([None, 1, 1.0, True, 'abc']) == [None, 1, 1.0, True, 'abc']
    assert enc.default(Enum('TestEnum', 'a b c')) == 'a'
    assert enc.default(Decimal('1.234')) == '1.234'

# Generated at 2022-06-21 11:28:10.728036
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc)) == 0
    assert _ExtendedEncoder().default(UUID('b4f90e23-eeb4-4ab4-9a1a-37faf1c5b717')) == 'b4f90e23-eeb4-4ab4-9a1a-37faf1c5b717'
    assert _ExtendedEncoder().default(Decimal('0.1')) == '0.1'

# Generated at 2022-06-21 11:28:17.463619
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now()) is not None
    assert _ExtendedEncoder().encode(dict()) is not None
    assert _ExtendedEncoder().encode(UUID('{123e4567-e89b-12d3-a456-426655440000}')) is not None



# Generated at 2022-06-21 11:28:20.606517
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([{'a': 1}, (2, 3, 4), datetime.now(timezone.utc),
                                      UUID(int=4), Decimal(4), set(), MyEnum.a])



# Generated at 2022-06-21 11:28:25.190199
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    x = FieldOverride('a', 'b', True, None, dict)
    assert x.letter_case == 'a'
    assert x.encoder == 'b'
    assert x.decoder == True
    assert x.exclude == None
    assert x.mm_field == dict



# Generated at 2022-06-21 11:28:29.232637
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Check that the constructor works with valid parameters
    assert FieldOverride("a", "b", lambda x: x, lambda x: x, True)
    # Check that the constructor throws TypeError when a parameter is invalid
    with pytest.raises(TypeError):
        FieldOverride("a", "b", [], [], "foo")



# Generated at 2022-06-21 11:28:32.211452
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    o = {'a': 1}
    oo = encoder.default(o)
    assert isinstance(oo, dict)



# Generated at 2022-06-21 11:28:52.232654
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder().default(Decimal('3.14'))
    assert result == '3.14'


# Generated at 2022-06-21 11:28:59.516947
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1,2,3}) == "[1, 2, 3]"
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")) == '"6ba7b810-9dad-11d1-80b4-00c04fd430c8"'
    assert _ExtendedEncoder().encode(datetime(2019, 10, 2, 3, 4)) == "1570026240.0"
    assert _ExtendedEncoder().encode(Decimal("1.1")) == '"1.1"'
    assert _ExtendedEncoder().encode

# Generated at 2022-06-21 11:29:10.169068
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride()
    assert(fo.exclude is None)
    assert(fo.letter_case is None)
    assert(fo.encoder is None)
    assert(fo.decoder is None)
    f1 = lambda x: x
    f2 = lambda x: x
    f3 = lambda x: x
    fo = FieldOverride(f1, f2, f3, f3)
    assert(fo.exclude is f1)
    assert(fo.letter_case is f2)
    assert(fo.encoder is f3)
    assert(fo.decoder is f3)
    fo = FieldOverride(exclude=f1, letter_case=f2, encoder=f3, decoder=f3)
    assert(fo.exclude is f1)

# Generated at 2022-06-21 11:29:15.713857
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc))
    assert _ExtendedEncoder().encode(datetime(2018, 4, 26, 8, 35, 49, 801000, timezone.utc))
    assert _ExtendedEncoder().encode(UUID('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'))
    assert _ExtendedEncoder().encode(Enum)



# Generated at 2022-06-21 11:29:24.965214
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import decimal
    from uuid import UUID
    from datetime import datetime
    from enum import Enum

    class MyEnum(Enum):
        a = 'a'


# Generated at 2022-06-21 11:29:34.160153
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([usd]).startswith('"<Currency')
    assert _ExtendedEncoder().encode(datetime.now(tz=timezone.utc)) == str(datetime.now(tz=timezone.utc).timestamp())
    assert _ExtendedEncoder().encode(UUID("{12345678-1234-5678-1234-567812345678}")) == '"12345678-1234-5678-1234-567812345678"'
    assert _ExtendedEncoder().encode(LoanType.Refinance) == '1'

# Generated at 2022-06-21 11:29:42.194408
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.default([1, 'two']) == [1, 'two']
    abs_time = datetime.now(tz=timezone.utc)
    assert extended_encoder.default(abs_time) == abs_time.timestamp()
    uuid = UUID('f2c54832-0c8c-40b9-b42c-99a8f813e7ba')
    assert extended_encoder.default(uuid) == 'f2c54832-0c8c-40b9-b42c-99a8f813e7ba'
    enum_value = Color.RED
    assert extended_encoder.default(enum_value) == 0
    decimal = Decimal(0.01)
    assert extended_enc

# Generated at 2022-06-21 11:29:48.526781
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import date, time
    from decimal import Decimal
    from uuid import UUID
    from collections import deque, Counter, OrderedDict, ChainMap
    from enum import Enum
    class _TestEnum(Enum):
        one = 1
        two = 2

# Generated at 2022-06-21 11:29:51.173473
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(list()) == list()
    assert _ExtendedEncoder().default(dict()) == dict()



# Generated at 2022-06-21 11:30:03.286082
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    x = _ExtendedEncoder().default([1,2,3])
    assert x == [1,2,3]

    x = _ExtendedEncoder().default({'a':1, 'b':2, 'c':3})
    assert x == {'a':1, 'b':2, 'c':3}

    x = _ExtendedEncoder().default(UUID('4b4c0b08-9f2c-43e9-9d79-e0e19898aa48'))
    assert x == '4b4c0b08-9f2c-43e9-9d79-e0e19898aa48'

    x = _ExtendedEncoder().default(datetime(2020,3,5,5,5,5,5,timezone.utc))
    assert x == 15834

# Generated at 2022-06-21 11:30:30.571501
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({1, 2, 3}) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime(2019, 1, 2, 3, 4, 5, 67890, timezone.utc)) == 1546807845

# Generated at 2022-06-21 11:30:36.362022
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test: FieldOverride()
    r = FieldOverride()
    assert r.letter_case is None
    assert r.exclude is None
    assert r.encoder is None
    assert r.decoder is None
    # Test: FieldOverride([1,2,3])
    with pytest.raises(TypeError):
        r = FieldOverride([1,2,3])


# Generated at 2022-06-21 11:30:38.351009
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    class TestClass: pass
    assert encoder.default(TestClass()) == TestClass()



# Generated at 2022-06-21 11:30:42.940325
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    a = _ExtendedEncoder().default(datetime.now())
    assert a >= 0
    a = _ExtendedEncoder().default(UUID('d2e2b22f-1fa5-4c50-9b4a-4f7e1e6c2607'))
    assert a == 'd2e2b22f-1fa5-4c50-9b4a-4f7e1e6c2607'

# Code for unit test.

# Generated at 2022-06-21 11:30:48.888681
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.loads(json.dumps({'now': datetime.now(timezone.utc), 'uuid': UUID('01234567-89ab-cdef-0123-456789abcdef')},
                                 cls=_ExtendedEncoder)) == {
                                     'now': 1516416736.724018,
                                     'uuid': '01234567-89ab-cdef-0123-456789abcdef'
                                 }



# Generated at 2022-06-21 11:30:56.027488
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda obj: obj + 1
    decoder = lambda obj: obj - 1
    exclude = lambda obj: obj == 1
    letter_case = lambda txt: txt.upper()
    mm_field = 'mm_field'
    fo = FieldOverride(encoder=encoder, decoder=decoder, exclude=exclude,
                       letter_case=letter_case, mm_field=mm_field)

    assert fo.encoder == encoder
    assert fo.decoder == decoder
    assert fo.exclude == exclude
    assert fo.letter_case == letter_case
    assert fo.mm_field == mm_field



# Generated at 2022-06-21 11:31:03.233841
# Unit test for constructor of class FieldOverride
def test_FieldOverride():  # type: ignore
    f = FieldOverride()  # noqa: F741
    f = FieldOverride(None)
    f = FieldOverride(snake_case)
    f = FieldOverride(None, lambda x: True)
    f = FieldOverride(None, lambda x: True, lambda x: x+1)
    f = FieldOverride(None, None, lambda x: x+1)
    f = FieldOverride(None, None, None)
    f = FieldOverride(None, None, None, lambda x: x+1)
    f = FieldOverride(None, None, None, None)
    f = FieldOverride(None, None, None)
    k = FieldOverride(None, None, None, None)
    f = FieldOverride(None, None, None)

# Generated at 2022-06-21 11:31:14.283505
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default({"a": 1}) == {"a": 1}
    assert encoder.default(1) == 1
    assert encoder.default(1.2) == 1.2
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(None) is None
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default(["a", 2, 3]) == ["a", 2, 3]
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-21 11:31:16.425807
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"foo": datetime.now(timezone.utc)})



# Generated at 2022-06-21 11:31:21.270638
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(True, "exclude", "camel", "encode", "decode")
    assert f.exclude == True
    assert f.letter_case == "camel"
    assert f.encoder == "encode"
    assert f.decoder == "decode"


# Generated at 2022-06-21 11:31:56.971447
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a":1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode([1,2,3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode("a") == '"a"'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(False) == 'false'
    assert _ExtendedEncoder().encode(None) == 'null'

# Generated at 2022-06-21 11:32:01.473483
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(None, None, None)
    assert FieldOverride(lambda x: True, None, None)
    assert FieldOverride(exclude=lambda x: True, letter_case=lambda x: x,
                         encoder=lambda x: x)
    assert FieldOverride(exclude=lambda x: True, letter_case=lambda x: x,
                         encoder=lambda x: x, decoder=lambda x: x)

# Generated at 2022-06-21 11:32:05.334707
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    dt = datetime(2019, 1, 1, tzinfo=timezone.utc)
    assert _ExtendedEncoder().default(dt) == 1546300800
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(True)



# Generated at 2022-06-21 11:32:08.618204
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, tzinfo=timezone.utc)) == 0
    assert _ExtendedEncoder().default(UUID(hex='0' * 32)) == '00000000-0000-0000-0000-000000000000'


# Generated at 2022-06-21 11:32:18.950889
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    extended_encoder.default('foo')
    extended_encoder.default(1)
    extended_encoder.default(0.5)
    extended_encoder.default(True)
    extended_encoder.default(None)
    extended_encoder.default([1, 2, 3])
    extended_encoder.default({'k': 1, 'v': 2})
    extended_encoder.default([1, 'foo', True, None])
    extended_encoder.default({'k': [1, 2, 3], 'v': [4, 5, 6]})
    extended_encoder.default(datetime.now(timezone.utc))

# Generated at 2022-06-21 11:32:28.878258
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(['a']) == ['a']
    assert _ExtendedEncoder().default(('a',)) == ['a']
    assert _ExtendedEncoder().default({'a':'b'}) == {'a':'b'}
    assert _ExtendedEncoder().default(set('a')) == list('a')
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == 1569405362.0
    assert _ExtendedEncoder().default(UUID('7e1342a8-f7c1-11e9-a2a3-2a2ae2dbcce4')) == '7e1342a8-f7c1-11e9-a2a3-2a2ae2dbcce4'
    assert _Extended

# Generated at 2022-06-21 11:32:40.293094
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ee = _ExtendedEncoder()
    assert ee.default(['a', 'b']) == ['a', 'b']
    assert ee.default({'a': 'b'}) == {'a': 'b'}
    assert (
        ee.default(datetime.now(timezone.utc))
        == datetime.now(timezone.utc).timestamp()
    )
    assert ee.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert ee.default(Decimal(13)) == '13'
    assert ee.default(True) is True
    assert ee.default(False) is False


# Generated at 2022-06-21 11:32:52.087669
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == list(range(4))
    assert encoder.default(dict(x=1, y=2)) == {'x': 1, 'y': 2}
    assert encoder.default(datetime.now(timezone.utc)) == 1558431383.245977
    assert encoder.default(UUID('5ceb40d3-ae78-4c2d-8d3b-3f4cc4c4eaa1')) == '5ceb40d3-ae78-4c2d-8d3b-3f4cc4c4eaa1'
    assert encoder.default(Decimal('11.23')) == '11.23'



# Generated at 2022-06-21 11:32:57.738344
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    sets = (
        ({"a": 0}, '{"a": 0}'),
        ({'a', }, '["a"]'),
        ((0, 1), '[0, 1]'),
        ({"0": 0}, '{"0": 0}'),
        (['a', ], '["a"]'),
        (("a", ), '["a"]'),
        ((0, 1), '[0, 1]'),
        ((('a', ), ), '[["a"]]'),
    )
    for d, s in sets:
        assert _ExtendedEncoder().encode(d) == s



# Generated at 2022-06-21 11:33:04.652850
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(bool) == 'true'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == '0'
    assert _ExtendedEncoder().encode(UUID('b1e6b8e6-eeab-11e9-b56e-0800200c9a66')) == '"b1e6b8e6-eeab-11e9-b56e-0800200c9a66"'
    assert _ExtendedEncoder().encode(Decimal('1.1')) == '"1.1"'


# Generated at 2022-06-21 11:33:54.194418
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.1) == 1.1
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(frozenset()) == []
    assert _ExtendedEncoder().default(bytearray(b'abc')) == [97, 98, 99]
    assert _ExtendedEncoder().default(b'abc') == "abc"
    assert _ExtendedEncoder().default(u'abc') == "abc"
    assert _ExtendedEncoder().default(list([1])) == [1]