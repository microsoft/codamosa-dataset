

# Generated at 2022-06-21 11:24:29.784894
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default('foo') == 'foo'
    assert encoder.default(123) == 123
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(None) == None
    assert encoder.default(set()) == list(set())
    assert encoder.default(tuple()) == list(tuple())
    assert encoder.default({}) == dict({})
    assert encoder.default([{}, {}]) == [{}, {}]

# Generated at 2022-06-21 11:24:39.570898
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    output = _ExtendedEncoder().encode({1, 2, 3})
    assert output == '[1,2,3]'
    output = _ExtendedEncoder().encode({1: 2, 3: 4})
    assert output == '{"1":2,"3":4}'
    output = _ExtendedEncoder().encode(datetime.now(), )
    assert isinstance(output, float)
    output = _ExtendedEncoder().encode(UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8'))
    assert output == '"6ba7b810-9dad-11d1-80b4-00c04fd430c8"'
    class MyEnum(Enum):
        a = 1

# Generated at 2022-06-21 11:24:48.299458
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.loads(_ExtendedEncoder().encode('hello')) == 'hello'
    assert json.loads(_ExtendedEncoder().encode(b'hello')) == b'hello'
    assert json.loads(_ExtendedEncoder().encode(1)) == 1
    assert json.loads(_ExtendedEncoder().encode([1, 2, 3])) == [1, 2, 3]
    assert json.loads(_ExtendedEncoder().encode({'a': 'b'})) == {'a': 'b'}
    assert json.loads(_ExtendedEncoder().encode(set([1, 2, 3]))) == [1, 2, 3]
    assert json.loads(_ExtendedEncoder().encode(frozenset([1, 2, 3]))) == [1, 2, 3]

# Generated at 2022-06-21 11:24:58.283126
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert encoder.default(('a', 'b', 'c')) == ['a', 'b', 'c']
    assert encoder.default({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert encoder.default(frozenset(['a', 'b', 'c'])) == ['a', 'b', 'c']
    assert encoder.default(set(['a', 'b', 'c'])) == ['a', 'b', 'c']

# Generated at 2022-06-21 11:25:01.759160
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(exclude=str.isspace, letter_case=None)
    assert callable(field_override.exclude)
    assert field_override.letter_case is None


# Generated at 2022-06-21 11:25:09.100048
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(set([1, 2])) is list([1, 2])
    assert _ExtendedEncoder().default(frozenset([1, 2])) is list([1, 2])
    assert _ExtendedEncoder().default(datetime(2000, 12, 12, 12, 12, 12,
                                               timezone.utc)) \
           is datetime(2000, 12, 12, 12, 12, 12, timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('a-b-c')) is 'a-b-c'
    assert _ExtendedEncoder().default(Enum('ABC', 'A B C')) is 'A'
    assert _ExtendedEncoder().default(Decimal('12.345')) is '12.345'

# Generated at 2022-06-21 11:25:19.443855
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(exclude=lambda x: True,
                      letter_case=lambda x: x,
                      encoder=lambda x: x,
                      decoder=lambda x: x)
    assert f.exclude(None) == True
    assert f.letter_case('test') == 'test'
    assert f.encoder(None) == None
    assert f.decoder(None) == None
    f = FieldOverride(exclude=False,
                      letter_case=None,
                      encoder=None,
                      decoder=None)
    assert f.exclude(None) == False
    assert f.letter_case('test') == 'test'
    assert f.encoder(None) == None
    assert f.decoder(None) == None



# Generated at 2022-06-21 11:25:27.206413
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert enc.default({1: 2}) == {1: 2}
    assert enc.default([1, 2]) == [1, 2]
    assert '"' + enc.default(datetime.now(timezone.utc)) + '"' == enc.default(datetime.now(timezone.utc))
    assert '"' + enc.default(UUID('12345678123456781234567812345678')) + '"' == enc.default(UUID('12345678123456781234567812345678'))
    assert enc.default(Decimal('1.0')) == "1.0"
    assert enc.default("1") == '1'
    assert enc.default(1) == 1
    assert enc.default(None) == None

# Generated at 2022-06-21 11:25:38.021647
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():  # pylint: disable=too-many-branches
    expected_json_from_dict: Json = {'test': 'test'}
    assert _ExtendedEncoder().default({'test': 'test'}) == expected_json_from_dict
    expected_json_from_list: Json = ['test']
    assert _ExtendedEncoder().default(['test']) == expected_json_from_list
    date_time = datetime.fromtimestamp(123, timezone.utc)
    assert _ExtendedEncoder().default(date_time) == 123
    uuid = UUID('1b4e28ba-2fa1-11d2-883f-b9a761bde3fb')

# Generated at 2022-06-21 11:25:48.511907
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'a': 'b'}) == {'a': 'b'}
    assert _ExtendedEncoder().default(datetime(2020, 5, 1, tzinfo=timezone.utc)) == 1585798400.0
    assert _ExtendedEncoder().default(UUID('0c7e2f1d-7707-4a0b-99d7-fe0eaf7f8b81')) == '0c7e2f1d-7707-4a0b-99d7-fe0eaf7f8b81'
    assert _ExtendedEnc

# Generated at 2022-06-21 11:26:17.340400
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    data = {'en': 'A', 'cn': '你好', 'numbers': [1, 2, 3], 'nothing': None,
            'a_date': datetime(year=2020, month=8, day=7, hour=1, minute=2, second=3, tzinfo=timezone.utc),
            'a_uuid': UUID('00000000-0000-0000-0000-000000000000'),
            'a_decimal': Decimal('2010.0807'),
            'enum': MyEnum.Foo,
            }

    encoder = _ExtendedEncoder()
    decoded = encoder.encode(data)
    assert decoded == json.dumps(data, cls=encoder)

# Generated at 2022-06-21 11:26:27.225717
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(list(range(0, 3))) == [0, 1, 2]
    assert encoder.default(dict(zip(list(range(0, 3)), list('abc')))) == {0: 'a', 1: 'b', 2: 'c'}
    now = datetime.now(timezone.utc)
    assert encoder.default(now) == now.timestamp()
    uuid_ = UUID('{12345678-1234-5678-1234567890ab}')
    assert encoder.default(uuid_) == '12345678123456781234567890ab'
    assert encoder.default(cfg.EN) == 'en'

# Generated at 2022-06-21 11:26:34.056992
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([3,2,1]) == '[3, 2, 1]'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode(UUID('c71533de-f9bb-11ea-96b5-acde48001122')) == '"c71533de-f9bb-11ea-96b5-acde48001122"'


# Generated at 2022-06-21 11:26:40.033945
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fields_config = [[None, None, True],
                     [None, None, False],
                     [None, None, None],
                     ['encoder', 'decoder', None]]

    for config in fields_config:
        ex = FieldOverride(*config)
        assert ex.encoder is None
        assert ex.decoder is None
        assert ex.exclude is None

# Generated at 2022-06-21 11:26:49.176802
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(exclude=lambda x: x == 2,
                                   letter_case=str.upper,
                                   encoder=str,
                                   decoder=int,
                                   mm_field=None)
    assert field_override.exclude(2) is True
    assert field_override.exclude(3) is False
    assert field_override.letter_case('abc') == 'ABC'
    assert field_override.encoder(1) == '1'
    assert field_override.decoder('2') == 2
    assert field_override.mm_field is None



# Generated at 2022-06-21 11:26:58.190243
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()

    assert e.default(123) == 123
    assert e.default(123.12) == 123.12
    assert e.default(True) is True
    assert e.default("a") == "a"
    assert e.default(None) is None
    assert e.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert e.default(UUID("12345678-1234-5678-1234-567812345678")) == "12345678-1234-5678-1234-567812345678"
    assert e.default(Decimal("1234.5678")) == "1234.5678"

    @dataclass
    class DC:
        a: str
    assert e.default

# Generated at 2022-06-21 11:27:09.258792
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default([1, 2, 3, 'a', 'b', 'c']) == [1, 2, 3, 'a', 'b', 'c']
    assert encoder.default(datetime(2020, 1, 2, 3, 4, 5, tzinfo=timezone.utc)) == \
        datetime(2020, 1, 2, 3, 4, 5, tzinfo=timezone.utc).timestamp()

# Generated at 2022-06-21 11:27:11.924825
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import time
    import datetime
    assert _ExtendedEncoder().default(
        datetime.datetime.utcnow()) == time.time()



# Generated at 2022-06-21 11:27:21.481906
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    a = _ExtendedEncoder()
    assert a.default([1, 2, 3]) == [1, 2, 3]
    assert a.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert a.default(UUID('0c7b1cd3-3ff7-4b0e-8c17-c07af79ec9c9')) == '0c7b1cd3-3ff7-4b0e-8c17-c07af79ec9c9'
    assert a.default(datetime(2020, 9, 16, 15, 4, 9, 400000)) == 1600231049.4
    assert a.default(datetime(2020, 9, 16, 15, 4, 9, 400000, tzinfo=timezone.utc))

# Generated at 2022-06-21 11:27:32.407816
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class Foo:
        x: int = MISSING
    a = (lambda x: x, Foo(), Foo.x)
    b = (Foo(), Foo.x, lambda x: x)
    c = (a, b)
    d = [a, b]
    e = {'a': a, 'b': b}
    f = {a, b}
    g = {a: a, b: b}
    for p in [a, b, c, d, e, f, g]:
        FieldOverride(*p)
    try:
        FieldOverride()
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 11:27:54.837167
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert (_ExtendedEncoder().default(datetime.now()) ==
            datetime.now().timestamp())



# Generated at 2022-06-21 11:28:05.757696
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert encoder.default(datetime(2018, 1, 1, 12, 0, 0)) == 1514784000.0
    assert encoder.default(UUID('b2c7ee65-d091-4f49-9ca9-a48e1a890973')) == 'b2c7ee65-d091-4f49-9ca9-a48e1a890973'
    assert encoder.default(cfg.LetterCase(0)) == 'lower'
    assert encoder.default(Decimal('1.23')) == '1.23'

# Generated at 2022-06-21 11:28:14.972851
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default('a') == 'a'
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default(dict(a=1)) == {'a': 1}
    assert encoder.default(datetime(2020, 6, 24, 16, 12, 1, tzinfo=timezone.utc)) == 1592997521


##############
# Decoders
##############



# Generated at 2022-06-21 11:28:17.655311
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(TypeError):
        FieldOverride(exclude=True)
        assert True  # pragma: no cover


# Generated at 2022-06-21 11:28:27.721511
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import datetime
    import uuid
    import enum
    import decimal
    encoder = _ExtendedEncoder()
    # JSONEncoder.default would raise an error if o is not serializable
    o_dict = {"key1": "value1", "key2": "value2"}
    o_list = [1, 2, 3, 4]
    o_datetime = datetime.datetime(2019, 2, 6, 12, tzinfo=timezone.utc)
    o_date = datetime.date(2017, 4, 11)
    o_time = datetime.time(8, 23, 45)
    o_uuid = uuid.UUID(int=1234)
    o_decimal = decimal.Decimal(4.3)

# Generated at 2022-06-21 11:28:39.658197
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(b'foo') == 'foo'
    assert _ExtendedEncoder().default(set([1, 2])) == [1, 2]
    assert _ExtendedEncoder().default({3: 4}) == {3: 4}
    assert _ExtendedEncoder().default(datetime(2000, 1, 1, tzinfo=timezone.utc).timestamp()) == 946684800.0
    assert _ExtendedEncoder().default(UUID('5a5c5a5f-2d9e-40d9-9000-1fd900fd2ff8')) == '5a5c5a5f-2d9e-40d9-9000-1fd900fd2ff8'

# Generated at 2022-06-21 11:28:49.080211
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from decimal import Decimal
    import json
    class Test(json.JSONEncoder):
        def default(self, o):
            return json.JSONEncoder.default(self, o)

    assert _ExtendedEncoder().default(MappingProxyType({})) == {}
    assert _ExtendedEncoder().default(set()) == list(set())
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('d2414fd9-dc59-48b8-8f72-ddb0630d6736')) == "d2414fd9-dc59-48b8-8f72-ddb0630d6736"

# Generated at 2022-06-21 11:28:57.765980
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default('str') == 'str'
    # datetime object
    now = datetime.now()
    assert _ExtendedEncoder().default(now) == now.timestamp()
    # datetime object with timezone
    nowtz = datetime.now(timezone.utc)
    assert _ExtendedEncoder().default(nowtz) == nowtz.timestamp()
    # UUID object
    uuid = UUID('01234567-89ab-cdef-0123-456789abcdef')

# Generated at 2022-06-21 11:29:03.966577
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    d = {'a': [1, 2],
         'b': {'c': 3},
         'c': datetime.utcnow().replace(tzinfo=timezone.utc),
         'd': UUID('604690d9-f9f4-4ae4-b7f1-f374d4a89b5c'),
         'e': MyEnum.value_1,
         'f': Decimal('0.1')}
    e = _ExtendedEncoder()
    assert d == json.loads(e.encode(d))



# Generated at 2022-06-21 11:29:09.637133
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda x: 10
    exclude = lambda x: x < 5
    letter_case = lambda x: x.upper()
    c = FieldOverride(exclude, letter_case, encoder)
    assert c.exclude == exclude
    assert c.letter_case == letter_case
    assert c.encoder == encoder


# Generated at 2022-06-21 11:29:33.637236
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride("a", "b", "c")
    assert f.letter_case == "a"
    assert f.encoder == "b"
    assert f.decoder == "c"



# Generated at 2022-06-21 11:29:40.462875
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

    assert encoder.default([]) == []
    assert encoder.default(tuple()) == []
    assert encoder.default(set()) == []
    assert encoder.default({}) == {}
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('7b865aee-0a75-4481-97df-d64fda1a86b7')) == '7b865aee-0a75-4481-97df-d64fda1a86b7'
    assert encoder.default(Decimal('1.2')) == '1.2'
    class DummyEnum(Enum):
        VAL1 = 1


# Generated at 2022-06-21 11:29:43.481437
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(
        lambda name: name.upper(),
        lambda name: name.lower(),
        lambda value: True if len(value) < 5 else False,
        int
    )
    assert field_override.letter_case('abc') == 'ABC'
    assert field_override.decoder('ABC') == 'abc'
    assert field_override.exclude('abcd') == True
    assert field_override.encoder(5) == 5



# Generated at 2022-06-21 11:29:55.251674
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert json.loads(encoder.encode({'a': 1})) == {'a': 1}
    assert json.loads(encoder.encode([1])) == [1]
    assert json.loads(encoder.encode('abc')) == 'abc'
    assert json.loads(encoder.encode(1)) == 1
    assert json.loads(encoder.encode(None)) is None
    assert json.loads(encoder.encode(1.1)) == 1.1
    assert json.loads(encoder.encode(True)) is True
    assert json.loads(encoder.encode({'a': datetime.now()}))['a']
    assert json.loads(encoder.encode({'a': UUID('A' * 32)}))

# Generated at 2022-06-21 11:29:56.922806
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    inst = _ExtendedEncoder()
    assert inst.default(Enum)



# Generated at 2022-06-21 11:29:58.936367
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(exclude=lambda x, y: None,
                         letter_case=lambda x: x,
                         encoder=lambda x: x,
                         decoder=lambda x: x)


# Unit tests for function _handle_undefined_parameters_safe

# Generated at 2022-06-21 11:30:09.141364
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import datetime
    import uuid
    from enum import Enum
    from decimal import Decimal

    # Test datetime.
    json.dumps(datetime.datetime.now(), cls=_ExtendedEncoder)

    # Test UUID.
    json.dumps(uuid.uuid1(), cls=_ExtendedEncoder)

    # Test Enum.
    class Weekday(Enum):
        Mon = 1
        Tue = 2
        Wed = 3
        Thu = 4
        Fri = 5
    json.dumps(Weekday.Mon, cls=_ExtendedEncoder)

    # Test Decimal.
    json.dumps(Decimal(2.999), cls=_ExtendedEncoder)



# Generated at 2022-06-21 11:30:14.502732
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(
        exclude=None,
        letter_case=title,
        encoder=str,
        decoder=str,
        mm_field=str,
    )
    assert fo.exclude is None
    assert fo.letter_case == title
    assert fo.encoder == str
    assert fo.decoder == str
    assert fo.mm_field == str

    fo2 = FieldOverride(
        exclude=lambda x: x == 10,
        letter_case=lower,
        encoder=lambda x: str(x),
        decoder=lambda x: str(x),
        mm_field=lambda x: str(x),
    )
    assert fo2.exclude(10) is True
    assert fo2.letter_case == lower
    assert fo2.encoder(10) == str(10)

# Generated at 2022-06-21 11:30:17.340537
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = json.dumps(set([1]), cls=_ExtendedEncoder)
    assert encoder == '[1]'



# Generated at 2022-06-21 11:30:27.571867
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _Encoder = _ExtendedEncoder()
    assert _Encoder.default(1) == 1
    assert _Encoder.default(None) is None
    assert _Encoder.default('1') == '1'
    assert _Encoder.default(b'1') == b'1'
    assert _Encoder.default(True) is True
    assert _Encoder.default(False) is False
    assert _Encoder.default(0.1) == 0.1
    assert _Encoder.default(1.1) == 1.1
    assert _Encoder.default([1]) == [1]
    assert _Encoder.default({1: 1}) == {1: 1}

# Generated at 2022-06-21 11:31:24.066151
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) == json.JSONEncoder().default(None)
    assert _ExtendedEncoder().default(10) == json.JSONEncoder().default(10)
    assert _ExtendedEncoder().default('test') == json.JSONEncoder().default('test')
    assert _ExtendedEncoder().default(10.1) == json.JSONEncoder().default(10.1)
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()

# Generated at 2022-06-21 11:31:33.100734
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import datetime
    from decimal import Decimal
    from uuid import uuid4
    from enum import Enum

    class Fruit(Enum):
        apple = 1
        banana = 2

    e = _ExtendedEncoder()
    assert e.default({"a": 1}) == {"a": 1}
    assert e.default([1, 2]) == [1, 2]
    assert e.default(datetime.datetime(2018, 3, 7, 13, 50, 30,
                                       tzinfo=timezone.utc)) == 1520421030.0
    assert e.default(uuid4()) == str(uuid4())
    assert e.default(Fruit.apple) == Fruit.apple.value
    assert e.default(Decimal("1.2")) == "1.2"



# Generated at 2022-06-21 11:31:40.577490
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    data = None
    assert json.dumps(data, cls=_ExtendedEncoder).strip() == 'null'

    data = [b'\xff', b'\x00']
    assert json.dumps(data, cls=_ExtendedEncoder) == '["\\\\uffff", "\\\\x00"]'

    data = dict(a=b'\xff', b=b'\x00')
    assert json.dumps(data, cls=_ExtendedEncoder) == '{"a": "\\\\uffff", "b": "\\\\x00"}'



# Generated at 2022-06-21 11:31:48.688424
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    # noinspection PyTypeChecker
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    # noinspection PyTypeChecker
    assert encoder.default(tuple((1, 2, 3))) == [1, 2, 3]
    # noinspection PyTypeChecker
    assert encoder.default(set((1, 2, 3))) == [1, 2, 3]
    assert encoder.default(datetime(1970, 1, 1, tzinfo=timezone.utc)) == 0.0

# Generated at 2022-06-21 11:31:58.644787
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(1) == 1
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default({1: 2}) == {1: 2}
    assert encoder.default(b"123") == "123"
    assert encoder.default({"now": datetime.now(timezone.utc)}) == {
        "now": datetime.now(timezone.utc).timestamp()
    }

# Generated at 2022-06-21 11:32:03.277342
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert (_ExtendedEncoder().encode([1, 2, 3, 4])
            == '[1, 2, 3, 4]')
    assert (_ExtendedEncoder().encode({"a": 1, "b": 2}) ==
            '{"a": 1, "b": 2}')
    assert _ExtendedEncoder().encode(datetime.now()) == str(datetime.now().timestamp())



# Generated at 2022-06-21 11:32:09.134864
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Check the constructor
    # args = (exclude, encoder, decoder, letter_case)
    # each element is a function which returns the element itself
    # expect the same for FieldOverride
    override = FieldOverride(*(lambda x: x for _ in range(4)))
    assert override.exclude(False) == False
    assert override.encoder(1) == 1
    assert override.decoder(2) == 2
    assert override.letter_case(3) == 3


# Generated at 2022-06-21 11:32:10.348878
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.JSONEncoder.default(json.JSONEncoder, None)



# Generated at 2022-06-21 11:32:20.869523
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o1 = {1: 2, 3: 4}
    o2 = [1, 2, 3, 4]
    o3 = datetime.now()
    o4 = UUID('a28b8a8f-32b1-4cb1-9d56-e8b9a9b2a4bf')
    o5 = Decimal('1.2')
    o6 = Decimal('3.4')
    o7 = Decimal('5.6')
    class A(Enum):
        A = 'a'
    a = A.A

    encoder = _ExtendedEncoder()
    assert encoder.default(o1) == o1
    assert encoder.default(o2) == o2
    assert encoder.default(o3) == o3.timestamp()
    assert encoder.default

# Generated at 2022-06-21 11:32:29.661105
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().encode({'a': datetime(2000, 1, 1, tzinfo=timezone.utc)}
                                     ) == '{"a": 946684800.0}'
    assert _ExtendedEncoder().encode(set('xy')) == '["x", "y"]'
    assert _ExtendedEncoder().encode(UUID('17f6b9a6-95f6-11e6-beb8-9e71128cae77')) == '"17f6b9a6-95f6-11e6-beb8-9e71128cae77"'
    assert _ExtendedEncoder().encode(Decimal('0.1')) == '"0.1"'


# Generated at 2022-06-21 11:33:18.720554
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_str = json.dumps(['foo', {'bar': ('baz', None, 1.0, 2)}], cls=_ExtendedEncoder)
    assert json_str == '["foo", {"bar": ["baz", null, 1.0, 2]}]'
    from datetime import datetime
    datetime_json = json.dumps(datetime(2020, 9, 18, 2, 33, 22, tzinfo=timezone.utc), cls=_ExtendedEncoder)
    assert datetime_json == '1600520602'
    assert json.dumps(Decimal('1.2'), cls=_ExtendedEncoder) == '"1.2"'



# Generated at 2022-06-21 11:33:23.277127
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    args = [lambda x: x, lambda x: x, lambda x: False, False, False]
    f_override = FieldOverride(*args)
    assert f_override.encoder is args[0]
    assert f_override.decoder is args[1]
    assert f_override.exclude is args[2]
    assert f_override.encode_json is args[3]
    assert f_override.decode_json is args[4]

# Unit tests for _user_overrides_or_exts()

# Generated at 2022-06-21 11:33:30.947946
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.loads(json.dumps(['foo', {'bar': ('baz', None, 1.0, 2)}], cls=_ExtendedEncoder))
    json.loads(json.dumps(['foo', {'bar': ('baz', None, 1.0, 2)}], cls=_ExtendedEncoder))
    json.loads(json.dumps(['foo', {'bar': ('baz', None, 1.0, 2)}], cls=_ExtendedEncoder))


# Generated at 2022-06-21 11:33:32.633789
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    FieldOverride(exclude=None, encoder=None, decoder=None, letter_case=None)


# Generated at 2022-06-21 11:33:41.847280
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    assert e.default([3,2,1]) == [3,2,1]
    assert e.default(dict(a=3,b=2,c=1)) == dict(a=3,b=2,c=1)
    assert e.default(set([3,2,1])) == [3,2,1]
    assert e.default(frozenset([3,2,1])) == [3,2,1]
    assert e.default(datetime(2000,1,1, tzinfo=timezone.utc)) == 946684800
    assert e.default(UUID('11111111-2222-3333-4444-555555555555')) == '11111111-2222-3333-4444-555555555555'
   

# Generated at 2022-06-21 11:33:48.243328
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # pylint: disable=attribute-defined-outside-init
    class Foo:
        def __init__(self, a):
            self.a = a

    @dataclass
    class Bar:
        a: Foo

    test_bar = Bar(Foo(1))

    assert Bar.__name__ == 'Bar'
    assert Bar.__module__ == __name__
    assert test_bar.a.a is 1

