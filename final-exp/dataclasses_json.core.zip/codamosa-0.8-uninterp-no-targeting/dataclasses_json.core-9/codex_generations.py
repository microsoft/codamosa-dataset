

# Generated at 2022-06-21 11:24:25.656986
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class Dummy:
        def __init__(self):
            pass
    a = None
    b = lambda x: x
    c = a
    d = a
    e = a
    f = b
    g = a
    h = a
    field_override = FieldOverride(a, b, c, d, e, f, g, h)
    assert field_override.encoder is None
    assert field_override.decoder is None
    assert field_override.exclude is None
    assert field_override.letter_case is None
    assert field_override.to_marshmallow is None
    assert field_override.from_marshmallow is None
    assert field_override.mm_field is None

    a = lambda x: x
    b = a
    c = a
    d

# Generated at 2022-06-21 11:24:30.687000
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(lambda a: a.lower(), lambda a: a.upper(), None, lambda a: a == 'exclude')
    assert field_override.letter_case('TEST_CASE') == 'test_case'
    assert field_override.decoder('TEST_CASE') == 'TEST_CASE'
    assert field_override.exclude('exclude') == True


# Generated at 2022-06-21 11:24:40.317257
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import timedelta
    from decimal import Decimal
    from enum import Enum
    from uuid import UUID

    class TestEnum(Enum):
        enum_val = 1


# Generated at 2022-06-21 11:24:45.720443
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # arrange
    obj = {
        'u': UUID('5e5e5e5e-5e5e-5e5e-5e5e-5e5e5e5e5e5e'),
        'e': Color.RED,
        'd': Decimal('0.123456789012345678901234567890'),
        'dt': datetime(2020, 1, 1, tzinfo=timezone.utc),
    }
    # act
    json.dumps(obj, cls=_ExtendedEncoder)



# Generated at 2022-06-21 11:24:49.550608
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().encode(datetime.utcnow()) is not None
    # test default
    assert _ExtendedEncoder().encode({"a": ""}) == '{"a": ""}'



# Generated at 2022-06-21 11:24:52.680671
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(include, exclude, encoder, decoder)
    assert fo.include
    assert fo.exclude
    assert fo.encoder
    assert fo.decoder



# Generated at 2022-06-21 11:24:55.608268
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    from_json = dict
    to_json = dict
    exclude = False
    letter_case = str
    FieldOverride(from_json, to_json, exclude, letter_case)


# Generated at 2022-06-21 11:25:01.763047
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    test_data = "test data"
    FieldOverride_obj = FieldOverride(None, None,tuple(test_data))
    assert_equals(FieldOverride_obj.exclude, None)
    assert_equals(FieldOverride_obj.letter_case, None)
    assert_equals(FieldOverride_obj.encoder, None)
    assert_equals(FieldOverride_obj.decoder, None)
    assert_equals(FieldOverride_obj.mm_field, tuple(test_data))

# Generated at 2022-06-21 11:25:05.999192
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    override = FieldOverride(letter_case="lower", exclude=lambda x: True,
                             encoder=lambda x: "encoded",
                             decoder=lambda x: "decoded")
    assert override.letter_case == "lower"
    assert override.exclude(None)
    assert override.encoder("test") == "encoded"
    assert override.decoder("test") == "decoded"



# Generated at 2022-06-21 11:25:16.293179
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def default(o: Any) -> Json:
        return _ExtendedEncoder().default(o)

    assert default(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert default(datetime.utcnow()) == datetime.utcnow().timestamp()
    assert default(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'

    class MyEnum(Enum):
        foo = 1
        bar = 2
    assert default(MyEnum.foo) == 1
    assert default(MyEnum.bar) == 2

   

# Generated at 2022-06-21 11:25:55.188910
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(UUID('6e2b1a05-6fc7-48d9-9f11-6c55dc6d6491')) == '"6e2b1a05-6fc7-48d9-9f11-6c55dc6d6491"'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({1: 'a', 2: 'b'}) == '{"1": "a", "2": "b"}'
    assert _ExtendedEncoder().encode(datetime(year=2019, month=12, day=31, hour=23, minute=59, second=59, tzinfo=timezone.utc)) == '"1577729999.0"'

# Generated at 2022-06-21 11:26:07.618581
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Need to instantiate FieldOverride with arguments that can be
    #  passed to fields(), where each argument is a function
    # For 'exclude', need to pass in a lambda because can't pass in
    #  a function directly
    exclude_func = lambda x: type(x) == str and x.startswith("Exclude")
    letter_case_func = lambda x: x.lower()
    encoder_func = lambda x: len(x)
    decoder_func = lambda x: x * 2
    field_override = FieldOverride(exclude=exclude_func,
                                   letter_case=letter_case_func,
                                   encoder=encoder_func,
                                   decoder=decoder_func)
    assert field_override.exclude == exclude_func

# Generated at 2022-06-21 11:26:15.403095
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == []
    assert encoder.default(frozenset()) == []
    assert encoder.default(tuple()) == []
    assert encoder.default(deque(('1', '2', 3))) == ['1', '2', 3]
    assert encoder.default(dict(a=1, b=2)) == {'a': 1, 'b': 2}
    assert encoder.default(dict(a=1, b=2).items()) == [('a', 1), ('b', 2)]
    assert encoder.default(datetime.now()) == datetime.now().timestamp()
    assert encoder.default(UUID(int=0)) == '00000000-0000-0000-0000-000000000000'

# Generated at 2022-06-21 11:26:24.581277
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set(['a'])) == ['a']
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default(datetime(1970, 1, 1, tzinfo=timezone.utc)) == 0.0
    assert encoder.default(UUID('de305d54-75b4-431b-adb2-eb6b9e546014')) == 'de305d54-75b4-431b-adb2-eb6b9e546014'


# Generated at 2022-06-21 11:26:33.589268
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert (
        FieldOverride(letter_case=camelcase, exclude=None, encoder=None,
                      decoder=None).letter_case \
        == camelcase
    )
    assert (
        FieldOverride(letter_case=camelcase, exclude=None, encoder=None,
                      decoder=None).exclude == None
    )
    assert (
        FieldOverride(letter_case=camelcase, exclude=None, encoder=None,
                      decoder=None).encoder == None
    )
    assert (
        FieldOverride(letter_case=camelcase, exclude=None, encoder=None,
                      decoder=None).decoder == None
    )



# Generated at 2022-06-21 11:26:37.493761
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([Decimal('0.5')]) == '[0.5]'
    assert _ExtendedEncoder().encode({'a': Decimal('0.5')}) == '{"a": "0.5"}'



# Generated at 2022-06-21 11:26:48.990526
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Test Collection, namedList, namedTuple and their sub-class.
    # Test Collection: list, tuple
    assert _ExtendedEncoder().encode([1, 2]) == '\u0001\u0002'
    assert _ExtendedEncoder().encode((1, 2)) == '[1, 2]'
    # Test namedList
    from typing import NamedTuple
    class namedList(NamedTuple):
        a: int
        b: str
    assert _ExtendedEncoder().encode(namedList(1, 'b')) == '{"a": 1, "b": "b"}'
    # Test namedTuple
    namedTuple = namedtuple('namedTuple', ['a', 'b'])

# Generated at 2022-06-21 11:26:53.101874
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder(indent=4).encode([1, 2, 3]) == '[\n    1,\n    2,\n    3\n]'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'



# Generated at 2022-06-21 11:26:56.455253
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(exclude=None)
    assert f.exclude == None
    assert f.encoder == None
    assert f.decoder == None
    assert f.letter_case == None
    assert f.mm_field == None



# Generated at 2022-06-21 11:27:01.784600
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    foo = FieldOverride("lower", lambda x: x + "_lower", None, lambda x: False)
    assert foo.letter_case("TEST") == "test"
    assert foo.encoder("TEST") == "TEST_lower"
    assert foo.decoder is None
    assert foo.exclude("TEST") == False
    assert foo.mm_field() is None



# Generated at 2022-06-21 11:27:31.932320
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    m = {'b': 1, 'a': 2}
    n = [1, 2, 3]
    p = {1: [1, 2, 3]}
    q = ('a', 'b', 'c')
    r = (1, 2, 3, 4)
    s = tuple([1, 2, 3, 4])
    t = tuple({'a': 1, 'b': 2})
    u = {'a': 1, 'b': 2}
    v = {'a': 1, 'b': u}
    w = {'a': 1, 'b': v}
    o = datetime.utcnow()
    oo = o.replace(tzinfo=timezone.utc)
    ooo = o.replace(tzinfo=timezone.utc).isoformat()
    oooo = o.isoformat

# Generated at 2022-06-21 11:27:35.758669
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2019,1,1,0,0,0,0,timezone.utc)) == '1546300800.0'
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'
    assert _ExtendedEncoder().encode(Enum('x', 'y')) == 'x'
    assert _ExtendedEncoder().encode(Decimal('12.34')) == '12.34'



# Generated at 2022-06-21 11:27:41.385023
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda s: s
    decoder = lambda s: s
    exclude = lambda s: False
    letter_case = lambda s: s

    # Test 1: All params are default values
    assert FieldOverride(None, None, None, None) == \
        FieldOverride(encoder, decoder, exclude, letter_case)



# Generated at 2022-06-21 11:27:52.562310
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    obj = {
        'list': [1, 2, 3],
        'dict': {'a': 1, 'b': 2},
        'datetime': datetime(2019, 3, 14, 16, 2, 22, tzinfo=timezone.utc),
        'uuid': UUID('3c3f2a2b-a33e-4ddb-8c89-d405c9d489f1'),
        'enum': FieldOverride,
        'decimal': Decimal('10.4'),
        'none': None,
        'other': object(),
    }

# Generated at 2022-06-21 11:27:56.135454
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(set([1])) == [1]
    assert _ExtendedEncoder().default(dict(a='a')) == {'a': 'a'}



# Generated at 2022-06-21 11:28:06.720988
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.1) == 1.1
    assert _ExtendedEncoder().default("a") == "a"
    assert _ExtendedEncoder().default("a" * 100) == "a" * 100
    assert _ExtendedEncoder().default([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert _ExtendedEncoder().default([1.1, 2.2, 3.3, 4.4]) == [1.1, 2.2, 3.3, 4.4]
    assert _ExtendedEncoder().default([]) == []

# Generated at 2022-06-21 11:28:19.425320
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default('string') == 'string', \
        'string should have returned unaltered'
    assert _ExtendedEncoder().default(123) == 123, \
        'int should have returned unaltered'
    assert _ExtendedEncoder().default(123.4) == 123.4, \
        'float should have returned unaltered'
    assert _ExtendedEncoder().default(True) == True, \
        'bool should have returned unaltered'
    assert _ExtendedEncoder().default(None) is None, \
        'None should have returned unaltered'
    assert _ExtendedEncoder().default([]) == [], \
        'list should have returned unaltered'
    assert _ExtendedEncoder().default({}) == {}, \
        'dict should have returned unaltered'


# Generated at 2022-06-21 11:28:24.164956
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default(None)
    _ExtendedEncoder().default(True)
    _ExtendedEncoder().default(1)
    _ExtendedEncoder().default(1.1)
    _ExtendedEncoder().default('a')
    _ExtendedEncoder().default([])
    _ExtendedEncoder().default({})



# Generated at 2022-06-21 11:28:32.250359
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import dataclass, field
    from dataclasses_json import config
    from dataclasses_json.core import Encoder
    from dataclasses_json.utils import _ExtendedEncoder

    encoder = Encoder(config(encoder=_ExtendedEncoder))
    assert encoder.encode(set([1,2,3]))
    assert encoder.encode({set():set()})
    assert encoder.encode({1:1})
    assert encoder.encode({1:[]})
    assert encoder.encode({1:{}})
    assert encoder.encode([1,2,3])
    assert encoder.encode(datetime.now())
    assert encoder.encode(UUID(int=0))

# Generated at 2022-06-21 11:28:34.562740
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    d = {"exclude": None, "letter_case": None, "encoder": None,
         "decoder": None}

    # test the constructor against each of the keys
    for k, v in d.items():
        f = FieldOverride(**{k: v})
        assert f.__dict__ == d



# Generated at 2022-06-21 11:29:11.155187
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(TypeError):
        FieldOverride()



# Generated at 2022-06-21 11:29:12.738653
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(TypeError):
        FieldOverride()



# Generated at 2022-06-21 11:29:22.522739
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder().encode({"key": Decimal("1")})
    # result must be "{'key': '1'}"
    assert set(result) == set("{'key': '1'}")
    assert set(result) == set(json.dumps({"key": Decimal("1")}))
    result = _ExtendedEncoder().encode({"key": Decimal()})
    # result must be "{'key': '0'}"
    assert set(result) == set("{'key': '0'}")
    assert set(result) == set(json.dumps({"key": Decimal()}))
    result = _ExtendedEncoder().encode([Decimal("1")])
    # result must be "['1']"
    assert set(result) == set("['1']")

# Generated at 2022-06-21 11:29:26.956094
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    expected_value = {
        'exclude': lambda x: x is None,
        'encoder': lambda x: x * 2,
        'decoder': lambda x: x / 2,
        'letter_case': lambda x: x.upper(),
        'mm_field': fields.Int(**{'missing': None}),
    }
    result = FieldOverride(**expected_value)
    assert vars(result) == expected_value

# Generated at 2022-06-21 11:29:36.148021
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda val: val + 1
    decoder = lambda val: val - 1
    letter_case = lambda val: val.upper()
    exclude = lambda val: val > 10

    field_override = FieldOverride(encoder=encoder, decoder=decoder,
                                   letter_case=letter_case, exclude=exclude)
    assert encoder == field_override.encoder
    assert decoder == field_override.decoder
    assert letter_case == field_override.letter_case
    assert exclude == field_override.exclude

    field_override = FieldOverride(encoder=encoder, decoder=decoder,
                                   letter_case=letter_case)
    assert encoder == field_override.encoder
    assert decoder == field_override.decoder
    assert letter_

# Generated at 2022-06-21 11:29:37.617926
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert not encoder.encode({'a': [1, 2], 'b': {'h': 1}})



# Generated at 2022-06-21 11:29:45.004475
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class DummyClass:
        exclude = None
        encoder = None
        decoder = None
        letter_case = None

    dummy_class = DummyClass()

    # Test for default constructor
    default_config = FieldOverride()
    assert default_config.exclude is None
    assert default_config.encoder is None
    assert default_config.decoder is None
    assert default_config.letter_case is None

    # Test for constructor will all parameters are given
    config = FieldOverride(exclude=dummy_class.exclude,
                           encoder=dummy_class.encoder,
                           decoder=dummy_class.decoder,
                           letter_case=dummy_class.letter_case)
    assert config.exclude == dummy_class.exclude
    assert config.encoder == dummy_class

# Generated at 2022-06-21 11:29:46.929536
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(True, 'underscore', None, None)
    assert fo.exclude == True
    assert fo.letter_case == 'underscore'
    assert fo.encoder == None
    assert fo.decoder == None

# Generated at 2022-06-21 11:29:51.131180
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride("test")
    assert fo.letter_case == "test"
    assert fo.exclude is None
    assert fo.encoder is None
    assert fo.decoder is None

    fo = FieldOverride("test", exclude=lambda x: True)
    assert fo.exclude(None)

    fo = FieldOverride("test", encoder=lambda x: "encoded")
    assert fo.encoder("test") == "encoded"

    fo = FieldOverride("test", decoder=lambda x: "decoded")
    assert fo.decoder("test") == "decoded"



# Generated at 2022-06-21 11:30:03.285583
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.default([]) == []
    assert extended_encoder.default({}) == {}
    assert extended_encoder.default(1) == 1
    assert extended_encoder.default('') == ''
    assert extended_encoder.default([1, 2]) == [1, 2]
    assert extended_encoder.default([]) == []
    assert extended_encoder.default({1: 2}) == {1: 2}
    assert extended_encoder.default(Decimal('0')) == '0'
    assert extended_encoder.default(datetime(1970, 1, 1, 0, 0, 1,
                                             tzinfo=timezone.utc)) == 1


# noinspection PyTypeChecker

# Generated at 2022-06-21 11:30:42.648267
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    override = FieldOverride(exclude=None, letter_case=None, encoder=None, decoder=None)
    assert override.exclude is None
    assert override.letter_case is None
    assert override.encoder is None
    assert override.decoder is None



# Generated at 2022-06-21 11:30:48.619543
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    args = ("XX", "YY", None, None, None, None)
    field_override = FieldOverride(*args)
    assert field_override.letter_case == "XX"
    assert field_override.exclude == "YY"
    assert field_override.encoder is None
    assert field_override.decoder is None
    assert field_override.json_tool is None
    assert field_override.mm_field is None

# Generated at 2022-06-21 11:30:50.576601
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    data = [1, 2, 3]
    j = enc.encode(data)
    assert j == '[1, 2, 3]'



# Generated at 2022-06-21 11:30:52.156938
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(None, None, None) is not None

# Generated at 2022-06-21 11:31:00.166754
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import date, datetime
    from enum import IntEnum, Enum
    from uuid import uuid4

    class Fruit(Enum):
        apple = 'apple'

    class Year(IntEnum):
        first = 1
        second = 2

    assert _ExtendedEncoder().default(Fruit.apple) == Fruit.apple.value
    assert _ExtendedEncoder().default(Year.first) == Year.first.value
    assert _ExtendedEncoder().default(date.today()) == str(date.today())
    assert _ExtendedEncoder().default(uuid4()) == str(uuid4())
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == int(datetime.now(timezone.utc).timestamp())



# Generated at 2022-06-21 11:31:08.774614
# Unit test for method default of class _ExtendedEncoder

# Generated at 2022-06-21 11:31:21.202352
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Order matters as we are testing defaults
    confs = ("letter_case", "exclude", "encoder", "decoder")
    def_vals = (None, None, None, None)
    assert FieldOverride(*def_vals) == FieldOverride(*confs)
    assert isinstance(FieldOverride(*def_vals), FieldOverride)
    assert FieldOverride(*def_vals) == FieldOverride(*def_vals)
    assert FieldOverride(*def_vals) != object()
    with pytest.raises(TypeError, match="Only keyword arguments"):
        FieldOverride(1, 2, 3, 4, 5)
    with pytest.raises(TypeError, match="Too few arguments provided"):
        FieldOverride()

# Generated at 2022-06-21 11:31:21.868196
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Implicitly test all public methods.
    _ExtendedEncoder()



# Generated at 2022-06-21 11:31:27.912241
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder: Callable[[Any], Any] = lambda x: x
    decoder: Callable[[Any], Any] = lambda x: x
    exclude: Callable[[Any], bool] = lambda x: False
    letter_case: Callable[[str], str] = lambda x: x
    field_override = FieldOverride(exclude, encoder, decoder, letter_case)
    assert field_override.exclude == exclude
    assert field_override.encoder == encoder
    assert field_override.decoder == decoder
    assert field_override.letter_case == letter_case


# Generated at 2022-06-21 11:31:38.871906
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert json.dumps(dict(), cls=_ExtendedEncoder) == '{}'
    assert json.dumps(set(), cls=_ExtendedEncoder) == '[]'
    assert json.dumps(datetime.now(tz=timezone.utc), cls=_ExtendedEncoder) # type: ignore
    assert json.dumps(UUID('1fdf307e-8efb-2174-9fbe-e3d3b8f92ed2'), cls=_ExtendedEncoder) == '"1fdf307e-8efb-2174-9fbe-e3d3b8f92ed2"'
    from enum import IntEnum
    class MyEnum(IntEnum):
        VALUE1 = 1
        VALUE2 = 2
    assert json.dumps

# Generated at 2022-06-21 11:32:28.325774
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    deserialize_func = lambda x: x
    serialize_func = lambda x: x
    exclude_func = lambda x: x
    letter_case_func = lambda x: x
    letter_case_func_factory = lambda: letter_case_func

    field_override = FieldOverride(
        serialize_func,
        deserialize_func,
        exclude_func,
        letter_case_func_factory)
    assert field_override.encoder == serialize_func
    assert field_override.decoder == deserialize_func
    assert field_override.exclude == exclude_func
    assert field_override.letter_case == letter_case_func
    field_override.encoder = None
    field_override.decoder = None
    field_override.exclude = None

# Generated at 2022-06-21 11:32:34.338559
# Unit test for method default of class _ExtendedEncoder

# Generated at 2022-06-21 11:32:36.296157
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'



# Generated at 2022-06-21 11:32:47.899216
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f_decoder = lambda a: "s" + a
    f_encoder = lambda a: a + "s"
    f_exclude = lambda a: a == "a"
    f_letter_case = lambda a: a.upper()
    fo = FieldOverride(exclude=f_exclude,
                       decoder=f_decoder,
                       encoder=f_encoder,
                       letter_case=f_letter_case)
    assert fo.decoder == f_decoder
    assert fo.encoder == f_encoder
    assert fo.exclude == f_exclude
    assert fo.letter_case == f_letter_case
    fo = FieldOverride()
    assert fo.decoder is None
    assert fo.encoder is None
    assert fo.exclude is None

# Generated at 2022-06-21 11:32:56.831667
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1, 2}) == json.dumps([1, 2])
    assert _ExtendedEncoder().encode({1: 2, 3: 4}) == json.dumps({1: 2, 3: 4})
    assert _ExtendedEncoder().encode(datetime.now(tz=timezone.utc)) == json.dumps(datetime.now(tz=timezone.utc).timestamp())
    assert _ExtendedEncoder().encode(UUID('afb0d6c5-6b3f-4bce-8f71-e28f613410e6')) == json.dumps('afb0d6c5-6b3f-4bce-8f71-e28f613410e6')
    assert _ExtendedEncoder().encode

# Generated at 2022-06-21 11:33:00.412923
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(frozenset('a')) == ['a']
    assert _ExtendedEncoder().default(frozenset([1, 0])) == [1, 0]
    assert _ExtendedEncoder().default(Enum('Color', 'white black')('black')) == 'black'



# Generated at 2022-06-21 11:33:02.630426
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder().encode(datetime.utcnow())
    assert type(result) == str



# Generated at 2022-06-21 11:33:12.630421
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ec = _ExtendedEncoder()
    assert ec.default(set([1, 2, 3])) == [1, 2, 3]
    assert ec.default(frozenset([1, 2, 3])) == [1, 2, 3]
    assert ec.default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert ec.default([1, 2, 3]) == [1, 2, 3]
    dt = datetime.now(timezone.utc)
    assert ec.default(dt) == dt.timestamp()
    assert ec.default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert ec.default(cfg.enums.by_value) == 'by_value'
    assert ec

# Generated at 2022-06-21 11:33:20.022120
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride()
    assert(f.exclude is None)
    assert(f.letter_case is None)
    assert(f.encoder is None)
    assert(f.decoder is None)

    f = FieldOverride(exclude=(lambda x: bool(x)),
                      letter_case=str.capitalize,
                      encoder=str,
                      decoder=int)
    assert(f.exclude is not None)
    assert(f.letter_case is not None)
    assert(f.encoder is not None)
    assert(f.decoder is not None)



# Generated at 2022-06-21 11:33:31.531802
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    d = datetime.now(timezone.utc)
    uuid = UUID('12345678123456781234567812345678')
    enum = Enum('TestEnum', 'one two')
    dec = Decimal('123.45')