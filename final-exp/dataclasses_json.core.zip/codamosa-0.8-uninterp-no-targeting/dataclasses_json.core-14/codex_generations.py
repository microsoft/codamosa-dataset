

# Generated at 2022-06-21 11:24:23.536614
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == "{}"
    assert _ExtendedEncoder().encode([]) == "[]"
    assert _ExtendedEncoder().encode({1,2,3}) == "[1, 2, 3]"
    assert _ExtendedEncoder().encode({"1":1, "2":2}) == '{"1": 1, "2": 2}'
    assert _ExtendedEncoder().encode(datetime.now()) == \
        '{"__dataclasses_json__": ' \
        '"datetime", "timestamp": "' + str(datetime.now().timestamp()) + '"}'
    assert _ExtendedEncoder().encode(set([1,2])) == "[1, 2]"

# Generated at 2022-06-21 11:24:32.800855
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(set([1, 2])) == '[1, 2]'
    assert _ExtendedEncoder().encode({1: 2, 3: 4}) == '{"1": 2, "3": 4}'
    assert _ExtendedEncoder().encode(datetime(2017, 1, 1)) == '1483228800.0'
    assert _ExtendedEncoder().encode(UUID(int=1)) == '00000000-0000-0000-0000-000000000001'
    assert _ExtendedEncoder().encode(UUID(int=0)) == '00000000-0000-0000-0000-000000000000'
    assert _ExtendedEncoder().encode(UUID(int=123456789)) == '000bc614-0000-0000-0000-000000000017'

# Generated at 2022-06-21 11:24:35.783091
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder().default(Decimal('1.1'))
    assert(result == '1.1')

_ExtendedEncoder = _ExtendedEncoder.__getstate__()



# Generated at 2022-06-21 11:24:45.082599
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = datetime(1970, 1, 5, 14, 3, 17, 516000, timezone.utc)
    assert _ExtendedEncoder().default(o) == o.timestamp()
    o = UUID('2d9f8e3e-fd3c-4a95-b465-8f81abf1a902')
    assert _ExtendedEncoder().default(o) == '2d9f8e3e-fd3c-4a95-b465-8f81abf1a902'
    o = Decimal('1.5')
    assert _ExtendedEncoder().default(o) == '1.5'



# Generated at 2022-06-21 11:24:55.883883
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # case 1:
    d = FieldOverride(
        exclude=lambda x: False,
        decoder=None,
        encoder=None,
        letter_case=None,
    )

# Generated at 2022-06-21 11:25:04.856671
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder(indent=4, sort_keys=True).encode(
        {"c": 0, "b": 0, "a": 0}) == '''{
    "a": 0,
    "b": 0,
    "c": 0
}'''
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(False) == 'false'
    assert _ExtendedEncoder().encode((1, 2, 3)) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(int) == '"int"'

# Generated at 2022-06-21 11:25:14.007123
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo1 = FieldOverride()
    assert not fo1.exclude
    assert fo1.encoder == None
    assert fo1.letter_case == None

    neg_predicate = lambda x: x < 0
    def neg_encoder(x): return -x
    def neg_decoder(x): return -x
    def identity_letter_case(x): return x

    fo2 = FieldOverride(exclude=neg_predicate,
                        encoder=neg_encoder,
                        letter_case=identity_letter_case)

    assert fo2.exclude == neg_predicate
    assert fo2.encoder == neg_encoder
    assert fo2.letter_case == identity_letter_case



# Generated at 2022-06-21 11:25:22.756355
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(0.0) == 0.0
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(2.3) == 2.3
    assert _ExtendedEncoder().default('foo') == 'foo'
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'dict': 1}) == {'dict': 1}


# Generated at 2022-06-21 11:25:31.511427
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert list(_ExtendedEncoder().iterencode([1, 2, 'a', 'b'])) == \
        ['[1, 2, "a", "b"]']
    assert list(_ExtendedEncoder().iterencode((1, 2, 'a', 'b'))) == \
        ['[1, 2, "a", "b"]']
    assert list(_ExtendedEncoder().iterencode({1: 'a', 2: 'b'})) == \
        ['{"1": "a", "2": "b"}']
    assert list(_ExtendedEncoder().iterencode(
        datetime.now(timezone.utc))) == \
        ['[2019, 0, 17, 3, 42, 39, 749425, "UTC"]']

# Generated at 2022-06-21 11:25:34.854894
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    exclusions = lambda v: v == 'sup'
    encoder = lambda v: '~' + v
    decoder = lambda v: v[1:]
    overrides = FieldOverride(exclude=exclusions,
                              encoder=encoder,
                              decoder=decoder)
    assert overrides.exclude(value='sup') == True
    assert overrides.encoder('how') == '~how'
    assert overrides.decoder('~how') == 'how'

# Generated at 2022-06-21 11:26:03.175174
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride("letter_case", "exclude", "encoder", "decoder")
    assert f.letter_case == "letter_case"
    assert f.exclude == "exclude"
    assert f.encoder == "encoder"
    assert f.decoder == "decoder"
    f = FieldOverride("lc")
    assert f.letter_case == "lc"
    assert f.exclude == noop
    assert f.encoder == noop
    assert f.decoder == noop
    f = FieldOverride("lc", "e")
    assert f.letter_case == "lc"
    assert f.exclude == "e"
    assert f.encoder == noop
    assert f.decoder == noop
    f = FieldOverride("lc", "e", "en")
    assert f.letter

# Generated at 2022-06-21 11:26:12.652627
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class ExampleClass(object):
        def __init__(self):
            self.type = str
            self.name = 'asdf'

    f = FieldOverride(encoder=lambda x: x,
                      decoder=lambda x: x,
                      exclude=lambda x: x,
                      letter_case=lambda x: x)
    assert f.encoder(ExampleClass()) is not None
    assert f.decoder(ExampleClass()) is not None
    assert f.exclude(ExampleClass()) is not None
    assert f.letter_case(ExampleClass()) is not None

# Generated at 2022-06-21 11:26:15.088605
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride().exclude is None
    assert FieldOverride().encoder is None
    assert FieldOverride().decoder is None
    assert FieldOverride().letter_case is None
    assert FieldOverride().mm_field is None

# Generated at 2022-06-21 11:26:21.575059
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_name = "test"
    field_override = FieldOverride()
    assert field_override.encoder == None
    assert field_override.decoder == None
    assert field_override.exclude == None
    assert field_override.letter_case == None

    with pytest.raises(Exception) as exception_info:
        # Should raise an exception of an unknown parameter
        FieldOverride(unknown_param=None)
    assert (str(exception_info.value) ==
            "unknown_param is not a valid parameter for FieldOverride")

    field_override = FieldOverride(encoder=lambda a: "encoded")
    assert field_override.encoder(field_name) == "encoded"
    field_override = FieldOverride(decoder=lambda a: "decoded")
    assert field_

# Generated at 2022-06-21 11:26:23.755173
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert list(encoder.default([1, 2, 3])) == [1, 2, 3]



# Generated at 2022-06-21 11:26:30.724072
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    # Mapping
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(dict(a=1, b=2)) == {'a': 1, 'b': 2}
    # List
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    # Datetime
    assert encoder.default(datetime(2020, 1, 1, 0, 0, 0)) == 1577836800.0
    assert encoder.default(datetime(2020, 1, 1, 0, 0, 0, 0, timezone.utc)) \
        == 1577836800.0

# Generated at 2022-06-21 11:26:37.035702
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """Test FieldOverride() constructor."""
    fo = FieldOverride(exclude=None,
                       letter_case=None,
                       encoder=None,
                       decoder=None,
                       mm_field=None)
    assert fo.exclude is None
    assert fo.letter_case is None
    assert fo.encoder is None
    assert fo.decoder is None
    assert fo.mm_field is None



# Generated at 2022-06-21 11:26:48.667585
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert isinstance(encoder.default([]), list)
    assert isinstance(encoder.default({}), dict)
    assert isinstance(encoder.default(set()), list)
    assert isinstance(encoder.default(frozenset()), list)
    assert isinstance(encoder.default(range(0)), list)
    assert isinstance(encoder.default(datetime.utcnow()), float)
    assert isinstance(encoder.default(datetime(1970, 1, 1, tzinfo=timezone.utc)), float)
    assert isinstance(encoder.default(UUID('5a182093-6cdc-47b4-bfb7-08686a0c920f')), str)

# Generated at 2022-06-21 11:26:53.514499
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    pd = _ExtendedEncoder().default(datetime.now(timezone.utc))
    assert isinstance(pd, float)
    pd = _ExtendedEncoder().default(UUID('{00000000-0000-0000-0000-000000000000}'))
    assert isinstance(pd, str)
    pass



# Generated at 2022-06-21 11:27:00.227503
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode((1,2,3)) == "[1, 2, 3]"
    assert _ExtendedEncoder().encode({"a":1,"b":2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode([1,2,"3"]) == "[1, 2, \"3\"]"
    assert _ExtendedEncoder().encode({"a":1,"b":{"c":3}}) == '{"a": 1, "b": {"c": 3}}'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == json.dumps(datetime.now(timezone.utc).timestamp(), allow_nan=False)

# Generated at 2022-06-21 11:27:43.119043
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    '''
    >>> test__ExtendedEncoder()
    True
    '''
    assert _ExtendedEncoder().encode({ 'adict': [ 1, 2, 3 ] }) == '{"adict": [1, 2, 3]}'
    assert _ExtendedEncoder().encode([ 1, 2, 3 ]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode('string') == '"string"'
    assert _ExtendedEncoder().encode(10) == '10'
    assert _ExtendedEncoder().encode(10.01) == '10.01'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'

# Generated at 2022-06-21 11:27:49.953965
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test the case: both of the variables are defined
    test_1 = FieldOverride(True, "snake")
    assert test_1.exclude == True
    assert test_1.letter_case == "snake"

    # Test the case: None is given
    test_2 = FieldOverride(None, None)
    assert test_2.exclude == False
    assert test_2.letter_case == None



# Generated at 2022-06-21 11:27:53.634743
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # type: () -> None
    assert json.dumps([1, 2, 3], cls=_ExtendedEncoder) == '[1, 2, 3]'
    assert json.dumps({'foo': 'bar'}, cls=_ExtendedEncoder) == '{"foo": "bar"}'
    assert json.dumps(123, cls=_ExtendedEncoder) == '123'
    assert json.dumps(True, cls=_ExtendedEncoder) == 'true'


# Generated at 2022-06-21 11:28:05.320003
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import datetime
    from uuid import uuid4
    from enum import IntEnum
    from decimal import Decimal
    from decimal import InvalidOperation
    from decimal import DecimalException

    def assert_encode_equal(o: Any, expected: Any) -> None:
        assert _ExtendedEncoder().default(o) == expected

    assert_encode_equal(datetime.now(), 1565826666.195529)
    assert_encode_equal(uuid4(), 'e95b2d37-98f5-4119-a5fc-df5117d8e3a7')
    assert_encode_equal(
        IntEnum('Sample', {'A': 1, 'B': 2}).A,
        1
    )

# Generated at 2022-06-21 11:28:17.879127
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class Test:
        @dataclass_json
        @dataclass
        class TestSub:
            nested_field: int
            nested_field_not_init: int = field(init=False)
            nested_field_ignore: int = field(metadata={'dataclasses_json': {'mm_field': mm.fields.Constant("constant_value")}})
            nested_field_define_field_type: int = field(metadata={'dataclasses_json': {'mm_field': mm.fields.String()}})
        
        int_field: int
        init_field: str = field(init=False, metadata={'dataclasses_json': {
                                                          'decoder': str.lower,
                                                          'exclude': str.upper}})
        float_field: float
        nested

# Generated at 2022-06-21 11:28:18.832988
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-21 11:28:19.786552
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now())



# Generated at 2022-06-21 11:28:29.490067
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from collections import UserDict
    from enum import Enum, auto
    from decimal import Decimal
    encoder = _ExtendedEncoder()
    # test with Collection but not Mapping
    assert encoder.default(set()) == []
    assert encoder.default(frozenset()) == []
    assert encoder.default(tuple()) == []
    assert encoder.default(list()) == []
    assert encoder.default(deque([])) == []
    assert encoder.default(UserDict({})) == {}
    # test with Mapping
    assert encoder.default({}) == {}
    assert encoder.default(dict()) == {}
    assert encoder.default(UserDict({'key': 'value'})) == {'key': 'value'}
    # test with datetime object
    utc_

# Generated at 2022-06-21 11:28:41.553133
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()
    assert e.default([1, 2, 3]) == [1, 2, 3]
    assert e.default((1, 2, 3)) == [1, 2, 3]
    assert e.default({'z': 1, 'y': 2, 'x': 3}) == {'z': 1, 'y': 2, 'x': 3}
    assert e.default(set([1, 2, 3])) == [1, 2, 3]
    assert e.default(frozenset([1, 2, 3])) == [1, 2, 3]
    assert e.default({frozenset([1]): 1}) == {'1': 1}
    assert e.default({set([1]): 1}) == {'1': 1}
    assert e.default(datetime.now())


# Generated at 2022-06-21 11:28:51.285016
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(['a', 'b', 'c']) == '["a", "b", "c"]'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert _ExtendedEncoder().encode(datetime(2020, 1, 2, 3, 4, 5, 6)) == 1577947245.000006
    assert _ExtendedEncoder().encode(datetime(2020, 1, 2, 3, 4, 5, 60000, tzinfo=timezone.utc)) == 1577945245.06
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}'))

# Generated at 2022-06-21 11:29:33.380388
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Default constructor
    field_override = FieldOverride()
    assert field_override.letter_case is None
    assert field_override.exclude is None
    assert field_override.encoder is None
    assert field_override.decoder is None
    # Constructor with letter_case
    field_override = FieldOverride(letter_case=lambda x: x.upper())
    assert field_override.letter_case(
        "some_string") == "SOME_STRING", "Upper case not working"
    assert field_override.exclude is None
    assert field_override.encoder is None
    assert field_override.decoder is None
    # Constructor with exclude
    predicate = lambda x: True
    field_override = FieldOverride(exclude=predicate)
    assert field_

# Generated at 2022-06-21 11:29:34.397702
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().encode(None)



# Generated at 2022-06-21 11:29:38.611448
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(exclude=None,
                                   encoder=None,
                                   decoder=None,
                                   letter_case=None)
    assert field_override.exclude is None
    assert field_override.encoder is None
    assert field_override.decoder is None
    assert field_override.letter_case is None



# Generated at 2022-06-21 11:29:45.530997
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class Foo:
        pass

    foobar = Foo()
    # NoneType test
    result = FieldOverride(exclude=None, letter_case=None, encoder=None,
                           decoder=None, mm_field=None)
    assert result.exclude == exclude
    assert result.letter_case == letter_case
    assert result.encoder == encoder
    assert result.decoder == decoder
    assert result.mm_field == mm_field

    # Function test
    result = FieldOverride(exclude=exclude, letter_case=letter_case,
                           encoder=encoder, decoder=decoder,
                           mm_field=mm_field)
    assert result.exclude == exclude
    assert result.letter_case == letter_case
    assert result.encoder == encoder
    assert result.dec

# Generated at 2022-06-21 11:29:56.558542
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import math
    import pytest

    o = [1, 2, 3]
    enc = _ExtendedEncoder()
    res = enc.default(o)
    assert isinstance(res, list)
    assert res == [1, 2, 3]

    o = {'1': 1, '2': 2}
    res = enc.default(o)
    assert isinstance(res, dict)
    assert res == {'1': 1, '2': 2}

    o = {'1': 1, '2': 2, 3: '3'}
    res = enc.default(o)
    assert isinstance(res, dict)
    assert res == {'1': 1, '2': 2, '3': '3'}


# Generated at 2022-06-21 11:30:01.272078
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    orig_dataclasses_json_config = dataclass_config.__dict__['dataclasses_json_config']

# Generated at 2022-06-21 11:30:05.820795
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride("a", "b", "c")
    assert f.encoder == "a"
    assert f.decoder == "b"
    assert f.exclude == "c"
    f = FieldOverride(exclude=lambda x: True,
                      letter_case=str.lower,
                      encoder=lambda x: x,
                      decoder=lambda x: x)
    assert f.encoder(4) == 4
    assert f.decoder(4) == 4
    assert isinstance(f.exclude, Callable)
    assert f.letter_case(4) == "4"

# Generated at 2022-06-21 11:30:10.793971
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda x: x + 1
    decoder = lambda x: x - 1
    exclude = lambda x: x > 1
    letter_case = lambda x: x.lower()
    cls = FieldOverride(encoder=encoder,
                        decoder=decoder,
                        exclude=exclude,
                        letter_case=letter_case,
                        mm_field=False)
    assert cls.encoder == encoder
    assert cls.decoder == decoder
    assert cls.exclude == exclude
    assert cls.letter_case == letter_case
    assert not cls.mm_field

# Unit tests for _encode_json_type

# Generated at 2022-06-21 11:30:11.727972
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()



# Generated at 2022-06-21 11:30:13.822226
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(json.dumps) == 'null'
# End of unit test



# Generated at 2022-06-21 11:31:46.877215
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default(datetime.now()) == datetime.now(
        timezone.utc
    ).timestamp()  # type: ignore
    assert encoder.default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert encoder.default(Enum('test', ('a', 'b'))) == 'a'
    assert encoder.default(Decimal('1.234')) == '1.234'

# Generated at 2022-06-21 11:31:57.478666
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    def test_default(o):
        return json.dumps(o, cls=_ExtendedEncoder, sort_keys=True) == json.dumps(o, cls=json.JSONEncoder, sort_keys=True)
    assert test_default(list(range(5)))
    assert test_default(tuple(range(5)))
    assert test_default(set(range(5)))
    assert test_default({1:2, 3:4, 5:6})
    assert test_default(frozenset(range(5)))
    assert test_default(datetime(2020, 6, 8, 15, 0, tzinfo=timezone.utc))
    assert test_default(UUID('40087f00-8da1-11d1-9ab0-000c2965ae27'))

# Generated at 2022-06-21 11:32:06.591972
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Arrange
    encoder = _ExtendedEncoder()

    # Act, Assert
    assert encoder.default(10) == 10
    assert encoder.default(10.5) == 10.5
    assert encoder.default(True) == True
    assert encoder.default(None) == None
    assert encoder.default('Hello') == 'Hello'

    assert encoder.default([10, 20]) == [10, 20]
    assert encoder.default((10, 20)) == (10, 20)
    assert encoder.default({10, 20}) == [10, 20]
    assert encoder.default({'a': 10, 'b': 20}) == {'a': 10, 'b': 20}

    utc = timezone.utc

# Generated at 2022-06-21 11:32:16.252470
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    import decimal
    import uuid
    from enum import Enum
    from datetime import date, datetime, time, timedelta

    class MyEnum(Enum):
        FIRST = 1

    class MyClass:
        def __init__(self, name):
            self.name = name

    my_list = [
        date.today(),
        datetime.now(),
        time(),
        timedelta(hours=1),
        decimal.Decimal(1.23),
        uuid.UUID(int=1),
        MyEnum.FIRST,
        MyClass('World'),
    ]

    encoder = _ExtendedEncoder()
    result = encoder.encode(my_list)
    assert result == json.dumps(my_list)



# Generated at 2022-06-21 11:32:17.673388
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(True) == "true"


# Generated at 2022-06-21 11:32:26.328690
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    for exclude in [None, lambda x: True, lambda x: False]:
        for decoder in [None, lambda x: x]:
            for letter_case in [None, lambda x: x, lambda x: 'upper']:
                for encoder in [None, lambda x: x]:
                    f = FieldOverride(exclude=exclude,
                                      decoder=decoder,
                                      letter_case=letter_case,
                                      encoder=encoder)
                    assert f.exclude == exclude
                    assert f.decoder == decoder
                    assert f.letter_case == letter_case
                    assert f.encoder == encoder


# Generated at 2022-06-21 11:32:32.992246
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(list([1, 2, 3])) == [1, 2, 3]
    assert _ExtendedEncoder().default({"a": "b"}) == {"a": "b"}
    assert _ExtendedEncoder().default(datetime(2000, 1, 1)) == 946684800.0
    assert _ExtendedEncoder().default(UUID('b74a1bff-d713-4562-b23f-b57ec8d2dab5')) == 'b74a1bff-d713-4562-b23f-b57ec8d2dab5'
    assert _ExtendedEncoder().default(Decimal('1.234567')) == '1.234567'


# Generated at 2022-06-21 11:32:40.071612
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride()
    assert f.exclude is None
    assert f.letter_case is None
    assert f.encoder is None
    assert f.decoder is None

    f = FieldOverride(
        lambda x: True,
        None,
        lambda x: x,
        lambda x: x
    )
    assert f.exclude(1)
    assert f.letter_case is None
    assert f.encoder(1) == 1
    assert f.decoder(1) == 1

# Generated at 2022-06-21 11:32:51.788097
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # datetime
    assert _isinstance_safe(
        _ExtendedEncoder.default(_ExtendedEncoder(), datetime.now()), float)
    assert _isinstance_safe(
        _ExtendedEncoder.default(_ExtendedEncoder(), datetime.now(timezone.utc)), float)
    # UUID
    assert _isinstance_safe(
        _ExtendedEncoder.default(_ExtendedEncoder(), UUID('8914f759-08cf-4ed3-b0d6-3f0e93988653')), str)
    # Enum
    class EnumExample(Enum):
        A = 'a'
        B = 'b'
    assert _isinstance_safe(
        _ExtendedEncoder.default(_ExtendedEncoder(), EnumExample.A), str)
    # Dec

# Generated at 2022-06-21 11:32:58.951152
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # collection
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # datetime
    assert _ExtendedEncoder().default(datetime(2020, 8, 19, 10, 10, 0)) == 1597809400
    # uuid
    uuid_ = UUID('389f3242-e39d-4d56-9a42-80ff31d6f8e7')
    assert _ExtendedEncoder().default(uuid_) == '389f3242-e39d-4d56-9a42-80ff31d6f8e7'
    # enum value 'a'