

# Generated at 2022-06-21 11:24:30.610747
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert _ExtendedEncoder().default(["a", "b"]) == ["a", "b"]
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default(range(10)) == list(range(10))
    assert _ExtendedEncoder().default(datetime(1970, 1, 1)) == 0
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, 0, 0, 0, 0, timezone.utc)) == 0
    assert _ExtendedEncoder().default(Decimal("1.5")) == "1.5"
    assert _ExtendedEncoder().default(None) is None



# Generated at 2022-06-21 11:24:35.738616
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    d = {'a':[1,2,3],'b':{'aa':1,'bb':2.23}}
    s = json.dumps(d, cls=_ExtendedEncoder)
    assert s == '{"a": [1, 2, 3], "b": {"aa": 1, "bb": 2.23}}'


# Generated at 2022-06-21 11:24:46.317877
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(set('123')) == list('123')
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime.now(timezone.utc)) == encoder.default(datetime.now())
    assert encoder.default(UUID('12345678-1234-5678-1234-567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Enum('Enum', 'ABC')('A')) == 'A'

# Generated at 2022-06-21 11:24:52.021631
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    init_kwargs = {'letter_case': str.upper, 'encoder': 'test encoder',
                   'decoder': 'test decoder', 'exclude': lambda x: x == "v1"}
    field_override = FieldOverride(**init_kwargs)
    for k, v in init_kwargs.items():
        assert getattr(field_override, k, None) == v


# Generated at 2022-06-21 11:25:01.601575
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # initialization test
    encoder = _ExtendedEncoder()
    assert encoder.default(None) == None
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({'a': [1, 2, 3]}) == {'a': [1, 2, 3]}
    assert encoder.default(datetime(2020, 1, 1)) == 1577836800
    assert encoder.default(Decimal('1.1')) == '1.1'
    assert encoder.default(Enum('test', 'A')) == 'A'
    assert encoder.default(UUID('01234567-89ab-cdef-0123-456789abcdef'))

# Generated at 2022-06-21 11:25:09.008001
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
  encoder = _ExtendedEncoder()
  JSONEncoder = json.JSONEncoder
  assert encoder.default([1, 2]) == JSONEncoder.default(encoder, [1, 2])
  assert encoder.default({'a': 1, 'b': 2}) == JSONEncoder.default(encoder, {'a': 1, 'b': 2})
  assert encoder.default(1) == JSONEncoder.default(encoder, 1)
  assert encoder.default(1.1) == JSONEncoder.default(encoder, 1.1)
  assert encoder.default('s') == JSONEncoder.default(encoder, 's')
  assert encoder.default(True) == JSONEncoder.default(encoder, True)

# Generated at 2022-06-21 11:25:10.393022
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(1) == '1'


# Generated at 2022-06-21 11:25:19.850215
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride()
    assert(f.exclude is None)
    assert(f.encoder is None)
    assert(f.decoder is None)
    assert(f.letter_case is None)
    assert(f.mm_field is None)
    f = FieldOverride(exclude=lambda x: False, encoder=None, decoder=None,
                      letter_case=None, mm_field=None)
    assert(f.exclude(0) is False)
    assert(f.encoder is None)
    assert(f.decoder is None)
    assert(f.letter_case is None)
    assert(f.mm_field is None)



# Generated at 2022-06-21 11:25:26.216794
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    unwanted_fields = ['as_dict', 'decoder', 'exclude', 'letter_case',
                       '__dict__', '__weakref__', '__doc__', '__module__']
    all_fields = (['encoder'] + unwanted_fields)

    @dataclass
    class FieldOverrideStub(FieldOverride):
        pass

    assert [f.name for f in fields(FieldOverrideStub)] == all_fields

    unwanted_fields.extend(all_fields)

    @dataclass
    class FieldOverrideStub(FieldOverride):
        pass

    assert [f.name for f in fields(FieldOverrideStub)] == all_fields

# Generated at 2022-06-21 11:25:33.283697
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps([], cls=_ExtendedEncoder) == '[]'
    assert json.dumps({"a": 2, "b": 3}, cls=_ExtendedEncoder) == '{"a": 2, "b": 3}'
    assert json.dumps({1, 2, 3}, cls=_ExtendedEncoder) == '[1, 2, 3]'
    assert json.dumps([1, {2: 3}, 4], cls=_ExtendedEncoder) == '[1, {"2": 3}, 4]'
    assert json.dumps(datetime.now(), cls=_ExtendedEncoder) != 'null'



# Generated at 2022-06-21 11:26:01.915492
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(
        {'a': {1, 2}, 'b': datetime(2020, 7, 1, 11, 10, 9)}) == '{"a": [1, 2], "b": 1593643009.0}'
    assert _ExtendedEncoder().encode(
        {'a': {'c': 1, 'b': 2}, 'b': datetime(2020, 7, 1, 11, 10, 9)}) == '{"a": {"b": 2, "c": 1}, "b": 1593643009.0}'



# Generated at 2022-06-21 11:26:13.249505
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = {'key': _ExtendedEncoder(indent=2)}
    assert o['key'](1) == '1'
    assert o['key']([1, 2]) == '[\n  1,\n  2\n]'
    assert o['key']({'a': 1}) == '{\n  "a": 1\n}'
    assert o['key'](datetime.now()) == str(datetime.now().timestamp())
    assert o['key'](UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert o['key'](Decimal('1.1')) == '1.1'



# Generated at 2022-06-21 11:26:24.494805
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    obj = _ExtendedEncoder().default(set('a'))
    assert obj == ['a']
    obj = _ExtendedEncoder().default({'foo': 'bar'})
    assert obj == {'foo': 'bar'}
    obj = _ExtendedEncoder().default(datetime(1, tzinfo=timezone.utc))
    assert obj == -62135596800.0
    obj = _ExtendedEncoder().default(UUID('{12345678-1234-5678-1234-567812345678}'))
    assert obj == '12345678-1234-5678-1234-567812345678'
    @cfg(encoder=lambda o: o.upper())
    class EnumExample(Enum):
        FOO = 'bar'
    obj = _ExtendedEnc

# Generated at 2022-06-21 11:26:25.356651
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass



# Generated at 2022-06-21 11:26:30.102701
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    a = FieldOverride(True, None, None, 'snake_case')
    eq_(a.exclude, True)
    eq_(a.letter_case, 'snake_case')
    assert not a.encoder and not a.decoder

    # constructor with missing arg "exclude"
    b = FieldOverride(None, None, None, 'snake_case')
    eq_(b.exclude, None)
    eq_(b.letter_case, 'snake_case')
    assert not b.encoder and not b.decoder

# Generated at 2022-06-21 11:26:39.717008
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test default None, None, None
    obj = FieldOverride()
    assert obj.letter_case == None
    assert obj.exclude == None
    assert obj.encoder == None
    assert obj.decoder == None

    # test default __str__
    assert str(obj) == "FieldOverride(letter_case=None, exclude=None, encoder=None, decoder=None)"

    # test default __str__
    assert repr(obj) == "FieldOverride(letter_case=None, exclude=None, encoder=None, decoder=None)"


if __name__ == "__main__":
    test_FieldOverride()

# Generated at 2022-06-21 11:26:41.544585
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
  assert isinstance(_ExtendedEncoder(), json.JSONEncoder)


# Generated at 2022-06-21 11:26:50.026019
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json import Undefined

    @dataclass_json
    @dataclass
    class TestClass(DataClassJsonMixin):
        a: int
        b: str

        @classmethod
        def from_json(cls, json_dict):
            return TestClass(json_dict.get('a'), json_dict.get('b'))

        def to_json(self):
            return {"a": self.a, "b": self.b}

    TestClass(a=Undefined, b=1)

# Generated at 2022-06-21 11:26:52.822538
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(
        exclude=None, letter_case=None, encoder=None, decoder=None)
    assert field_override is not None

# Generated at 2022-06-21 11:26:59.964332
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = object()
    assert 'null' == json.dumps(o, cls=_ExtendedEncoder)
    assert '[1, 2, 3]' == json.dumps(iter([1, 2, 3]), cls=_ExtendedEncoder)
    assert '{"a": 1, "b": 2}' == json.dumps({"a": 1, "b": 2}.items(), cls=_ExtendedEncoder)
    now = datetime.now(timezone.utc)
    assert str(now.timestamp()) == json.dumps(now, cls=_ExtendedEncoder)
    u = UUID('{12345678-1234-5678-1234-567812345678}')

# Generated at 2022-06-21 11:27:28.074004
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    dict_ = dict(a=1, b=2)
    list_ = [1, 2, 3]
    datetime_ = datetime(2018, 4, 21, 13, 19, 1, tzinfo=timezone.utc)
    uuid_ = UUID('647dee66-9e9a-44f1-8454-7f13a2b2c74a')
    enum_ = cfg.LetterCase.camel
    decimal_ = Decimal('1.0')
    result = _ExtendedEncoder().default([dict_, list_, datetime_, uuid_, enum_,
                                         decimal_])

# Generated at 2022-06-21 11:27:33.315606
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fld = FieldOverride()
    assert fld.encoder is None
    assert fld.decoder is None
    assert fld.letter_case is None
    assert fld.exclude is None
    assert fld.mm_field is None



# Generated at 2022-06-21 11:27:38.520969
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test for correct creation of FieldOverride
    f1 = FieldOverride(True, 'snake_case')
    assert f1.exclude == True
    assert f1.letter_case == 'snake_case'

    # Test for default constructor with no arguments
    f2 = FieldOverride()
    assert f2.exclude == False
    assert f2.letter_case is None

# Generated at 2022-06-21 11:27:45.545554
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from uuid import UUID
    from datetime import datetime
    from enum import Enum
    from decimal import Decimal
    class TestEnum(Enum):
        A = 'a'
        B = 'b'
    assert json.loads(json.dumps(TestEnum.A, cls=_ExtendedEncoder)) == 'a'
    assert json.loads(json.dumps(TestEnum.B)) == 'b'
    assert json.loads(json.dumps(UUID('d3a1a2a7-f25d-4d98-9bb0-8fb7f124a3d3'))) == 'd3a1a2a7-f25d-4d98-9bb0-8fb7f124a3d3'

# Generated at 2022-06-21 11:27:50.794583
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(exclude=(lambda x: True), letter_case=str.upper,
                       encoder=str, decoder=int)
    assert fo.exclude(1)
    assert fo.letter_case("abc") == "ABC"
    assert fo.encoder(123) == "123"
    assert fo.decoder("123") == 123

# Generated at 2022-06-21 11:28:02.829163
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == "{\"a\": 1, \"b\": 2}"
    assert _ExtendedEncoder().encode([1, 2]) == "[1, 2]"
    assert _ExtendedEncoder().encode("a") == "\"a\""
    assert _ExtendedEncoder().encode(1) == "1"
    assert _ExtendedEncoder().encode(1.1) == "1.1"
    assert _ExtendedEncoder().encode(True) == "true"
    assert _ExtendedEncoder().encode(None) == "null"
    assert _ExtendedEncoder().encode(datetime(2020, 10, 5, 12, 0, 0, 0, timezone.utc)) == "1601903600.0"

# Generated at 2022-06-21 11:28:03.228090
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    pass



# Generated at 2022-06-21 11:28:05.561704
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    letter_case = None
    encoder = None
    decoder = None
    exclude = None
    assert FieldOverride(letter_case, encoder, decoder, exclude)


# Generated at 2022-06-21 11:28:11.425651
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default(frozenset([1, 2, 3])) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(defaultdict(int, {'a': 1, 'b': 2})) == {'a': 1, 'b': 2}
    assert encoder.default(
        datetime(2020, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == 1577836800

# Generated at 2022-06-21 11:28:23.553059
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.encode(tuple([1, 2, 3])) == '[1, 2, 3]'
    assert encoder.encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert encoder.encode(datetime(2000, 1, 1, 0, 0, 0)) == '946684800.0'
    assert encoder.encode(UUID('9a9f7749-b5d5-40a5-ab6c-95f62b41f1b8')) == '"9a9f7749-b5d5-40a5-ab6c-95f62b41f1b8"'

# Generated at 2022-06-21 11:29:09.136337
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(['1', 2, 3]) == ['1', 2, 3]
    assert encoder.default({'x': '1', 'y': 2}) == {'x': '1', 'y': 2}
    assert encoder.default({'x': '1', 'y': 2}.items()) == {'x': '1', 'y': 2}
    assert encoder.default(datetime(2018, 12, 29, 12, 0, 0)) == 1546144800.0
    assert encoder.default(datetime(2018, 12, 29, 12, 0, 0, tzinfo=timezone.utc)) == 1546144800.0

# Generated at 2022-06-21 11:29:12.338094
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(True, None, "lower", None)
    assert f.exclude == True
    assert f.letter_case == "lower"
    assert f.encoder == None
    assert f.decoder == None


# Generated at 2022-06-21 11:29:21.998155
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Arrange
    data = [set(), 'test', 1, 1.23, True, False, None, {'1': 1}, [1, 2, 3],
            datetime(2020, 5, 29, 12, 30, tzinfo=timezone.utc), UUID('65a2c63b-2b6c-4a2b-aafc-6e3b41d8f6e0'),
            get_type_hints(FieldOverride)]
    encoder = _ExtendedEncoder()

# Generated at 2022-06-21 11:29:31.546431
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEncoder().encode({'key': 'value'}) == '{"key": "value"}'
    assert _ExtendedEncoder().encode(datetime(2020, 4, 4)) == '1586099200.0'
    assert _ExtendedEncoder().encode(UUID('1a0b7c4d-5e6f-8190-a2b3-c4d5e6f7a8b9')) ==\
        '"1a0b7c4d-5e6f-8190-a2b3-c4d5e6f7a8b9"'
    A = Enum('A', (('A1', 'a1'), ('A2', 'a2')))


# Generated at 2022-06-21 11:29:38.901011
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(Exception()) == Exception().__repr__()
    assert encoder.default(set()) == list(set())
    assert encoder.default(frozenset()) == list(frozenset())
    d = datetime.now().replace(tzinfo=timezone.utc)
    assert encoder.default(d) == d.timestamp()
    assert encoder.default(UUID('067e6162-3b6f-4ae2-a171-2470b63dff00')) == '067e6162-3b6f-4ae2-a171-2470b63dff00'
    assert encoder.default(Decimal('0.1')) == '0.1'
test__ExtendedEncoder_default()



# Generated at 2022-06-21 11:29:45.717297
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def test(o, expected: Json):
        result = _ExtendedEncoder().default(o)
        assert result == expected

    test_dt = datetime(2021, 12, 12, tzinfo=timezone.utc)
    test_uuid = UUID('00000000-0000-0000-0000-000000000000')
    test_enum = cfg.LetterCase.LOWER()
    test_decimal = Decimal('3.14')
    test(None, None)
    test(True, True)
    test('hello', 'hello')
    test(1, 1)
    test(1.2, 1.2)
    test([], [])
    test({}, {})
    test({'a': 1}, {'a': 1})
    test([1, 2], [1, 2])

# Generated at 2022-06-21 11:29:56.794508
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import date
    from decimal import Decimal
    from uuid import UUID
    from collections import OrderedDict
    from enum import Enum
    class E(Enum):
        a = 1
    e = E.a
    enc = _ExtendedEncoder()
    assert enc.default(date(1901,1,1)) == datetime(1901,1,1,0,0).timestamp()
    assert enc.default(UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8')) == '6ba7b810-9dad-11d1-80b4-00c04fd430c8'

# Generated at 2022-06-21 11:30:08.363021
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    # assert encoder.default(3.1415) == 3.1415
    # assert encoder.default(True) is True
    # assert encoder.default(False) is False
    # assert encoder.default(None) is None
    # assert encoder.default("a string here") == "a string here"
    # assert encoder.default({"a": 1, "b": "2", "c": [1, 2], "d": {"e": 3}}) == \
    #     {"a": 1, "b": "2", "c": [1, 2], "d": {"e": 3}}
    # assert encoder.default([1, "2", [3, 4], {"a": 1, "b": "2"}]) == \
    #     [1, "2

# Generated at 2022-06-21 11:30:18.566626
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

    error_message = 'Invalid JSON serialization'

    assert encoder.default(None) is None
    assert encoder.default('abcde') == 'abcde'
    assert encoder.default(12345) == 12345
    assert encoder.default(3.14) == 3.14
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(datetime.strptime("2010-05-04T21:45:00", "%Y-%m-%dT%H:%M:%S")) == 1273137700

# Generated at 2022-06-21 11:30:19.534596
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    pass


# Generated at 2022-06-21 11:31:57.209462
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(exclude=lambda *args: True,
                                   letter_case=lambda x: x,
                                   encoder=lambda x: x,
                                   decoder=lambda x: x)
    assert callable(field_override.exclude)
    assert callable(field_override.letter_case)
    assert callable(field_override.encoder)
    assert callable(field_override.decoder)

    field_override = FieldOverride(exclude=None,
                                   letter_case=None,
                                   encoder=None,
                                   decoder=None)
    assert field_override.exclude is None
    assert field_override.letter_case is None
    assert field_override.encoder is None
    assert field_override.decoder is None



# Generated at 2022-06-21 11:32:06.272867
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder.default(None, []) == []
    assert _ExtendedEncoder.default(None, (1, 2, 3)) == [1, 2, 3]
    assert _ExtendedEncoder.default(None, {1: 2}) == {1: 2}
    assert _ExtendedEncoder.default(None, Decimal('1.0E-3')) == '0.001'
    assert _ExtendedEncoder.default(None, datetime(2018, 1, 1, 0, 0, 0, tzinfo=timezone.utc)) == 1514764800

# Generated at 2022-06-21 11:32:09.570211
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(exclude=None, decoder=None, encoder=None,
                       letter_case=None)
    assert fo.exclude == None
    assert fo.decoder == None
    assert fo.encoder == None
    assert fo.letter_case == None



# Generated at 2022-06-21 11:32:19.840491
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({1: 2, 3: 4}) == '{"1": 2, "3": 4}'
    assert _ExtendedEncoder().encode(datetime(2020, 3, 9, 15, 1, 24, 940203)) == '1583727284.940203'
    assert _ExtendedEncoder().encode(UUID('01234567-89ab-cdef-0123-456789abcdef')) == '"01234567-89ab-cdef-0123-456789abcdef"'
    assert _ExtendedEncoder().encode(Decimal('0.12345678')) == '"0.12345678"'


# Generated at 2022-06-21 11:32:29.587850
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode({1: 'x'}) == '{"1": "x"}'
    # noinspection PyUnresolvedReferences
    assert _ExtendedEncoder().encode('x') == '"x"'
    assert _ExtendedEncoder().encode(datetime(2020, 9, 8, 7, 6, 5, 4, timezone.utc)) == '1600047765.000004'
    assert _ExtendedEncoder().encode(UUID('01234567-89ab-cdef-fedc-ba9876543210')) == '"01234567-89ab-cdef-fedc-ba9876543210"'
    assert _ExtendedEncoder().encode(Decimal('12345.67'))

# Generated at 2022-06-21 11:32:34.415923
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    import datetime

    date_time: datetime.datetime = datetime.datetime(2020, 1, 1, 12, 0, 0)
    assert _ExtendedEncoder().default(date_time) == 1577836800.0



# Generated at 2022-06-21 11:32:45.300181
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def check(o):
        return json.loads(json.dumps(o, cls=_ExtendedEncoder))
    assert check({"a": "b"}) == {"a": "b"}
    assert check({"a": 1}) == {"a": 1}
    assert check({"a": {"b": 1}}) == {"a": {"b": 1}}
    assert check({"a": 1.1}) == {"a": 1.1}
    assert check({"a": True}) == {"a": True}
    assert check({"a": False}) == {"a": False}
    assert check({"a": None}) == {"a": None}
    assert check({"a": {"b": True}}) == {"a": {"b": True}}

# Generated at 2022-06-21 11:32:55.460901
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": [1, 2, 3]}) == '{"a": [1, 2, 3]}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({"a": {'b': {"c": [{'d': 200}, 100]}}}) == '{"a": {"b": {"c": [{"d": 200}, 100]}}}'
    assert _ExtendedEncoder().encode({"a": {"b": {"c": [{"d": 200}, 100]}}}) == '{"a": {"b": {"c": [{"d": 200}, 100]}}}'

# Generated at 2022-06-21 11:33:00.185287
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(letter_case=str.lower,
                                   exclude=None,
                                   encoder=None,
                                   decoder=None,
                                   mm_field=None,
                                   field_class=None)
    assert field_override.letter_case == str.lower
    assert field_override.exclude is None
    assert field_override.encoder is None
    assert field_override.decoder is None
    assert field_override.mm_field is None
    assert field_override.field_class is None


# Generated at 2022-06-21 11:33:01.870237
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # TODO: test for the constructor of class FieldOverride
    pass
