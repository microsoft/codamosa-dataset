

# Generated at 2022-06-21 11:24:24.853851
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride() == FieldOverride(None, None, None, None)
    assert FieldOverride("encoder") == FieldOverride("encoder", None, None, None)
    assert FieldOverride("encoder", "letter_case") == FieldOverride("encoder", "letter_case", None, None)
    assert FieldOverride("encoder", "letter_case", "exclude") == FieldOverride("encoder", "letter_case", "exclude", None)
    assert FieldOverride("encoder", "letter_case", "exclude", "decoder") == FieldOverride("encoder", "letter_case", "exclude", "decoder")


# Generated at 2022-06-21 11:24:33.040713
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) is None
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert (
        _ExtendedEncoder().encode({'a': 'valueofa'})
        == '{\"a\": \"valueofa\"}'
    )
    assert _ExtendedEncoder().encode({1, 3, 5}) == '[1, 3, 5]'
    assert _ExtendedEncoder().encode([1, 3, 5]) == '[1, 3, 5]'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(3.14) == '3.14'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(False)

# Generated at 2022-06-21 11:24:42.290614
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class MyClass:
        pass
    o = FieldOverride()
    assert o.letter_case is None
    assert o.exclude is None
    assert o.encoder is None
    assert o.decoder is None
    assert o.mm_field is None

    o = FieldOverride(lambda x: x.lower())
    assert o.letter_case(MyClass()) == 'myclass'

    def blip_predicate(x):
        return x == 'blip'
    o = FieldOverride(blip_predicate=blip_predicate)
    assert o.exclude('blip')

    def blop_reconstructor(x):
        return x + 'blop'
    o = FieldOverride(blop_reconstructor=blop_reconstructor)

# Generated at 2022-06-21 11:24:50.469674
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default('lalala') == 'lalala'
    assert encoder.default(['lalala']) == ['lalala']
    assert encoder.default({'lalala': 'lilili'}) == {'lalala': 'lilili'}
    assert isinstance(encoder.default(datetime(2019, 1, 2, 3, 4, 5, 6, timezone.utc)), float)
    assert encoder.default(UUID(int=42)) == '00000000-0000-0000-0000-00000000002a'
    assert encoder.default(Decimal('0.1')) == '0.1'
    assert encoder.default(None) == None
    assert encoder.default(NotImplemented) == NotImplemented
   

# Generated at 2022-06-21 11:24:54.821673
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default(dict())
    _ExtendedEncoder().default({})
    _ExtendedEncoder().default([1, 2, 3])
    _ExtendedEncoder().default(set())
    _ExtendedEncoder().default(True)


# noinspection PyProtectedMember

# Generated at 2022-06-21 11:24:57.724705
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == list(set())
    assert encoder.default(frozenset()) == list(frozenset())



# Generated at 2022-06-21 11:25:08.419512
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    @dataclass_json
    @dataclass
    class User:
        name: str
        friends: List = field(default_factory=list)

    assert User.dataclass_json_config == {'letter_case': LetterCase.CAMEL}
    assert User.dataclass_json_config == User('test', 'test').dataclass_json_config

    @dataclass_json
    @dataclass
    class User:
        name: str
        friends: List = field(default_factory=list)

    assert User.dataclass_json_config == {'letter_case': LetterCase.CAMEL}
    assert User.dataclass_json_config == User('test', 'test').dataclass_json_config


# Generated at 2022-06-21 11:25:19.096342
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    from uuid import UUID
    from operator import methodcaller, attrgetter
    from functools import partial
    from typing import Optional

    from dataclasses_json.config import FieldOverride, FieldOverrideStrategy, \
        LetterCase, Undefined
    from dataclasses_json.decoder import JsonDecoder
    from dataclasses_json.encoder import JsonEncoder

    mm_strategy = FieldOverrideStrategy(JsonEncoder, JsonDecoder)
    mm_strategy_chain = FieldOverrideStrategy(JsonEncoder, JsonDecoder,
                                              attrgetter('__supertype__'))
    mm_strategy_meth = FieldOverrideStrategy(JsonEncoder, JsonDecoder,
                                             methodcaller('__supertype__'))

    uuid_str

# Generated at 2022-06-21 11:25:26.975027
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    args = ('field1', 'encoder', 'decoder', 'exclude', 'letter_case')
    kwargs = {'encoder': 'encoder', 'decoder': 'decoder',
              'exclude': 'exclude', 'letter_case': 'letter_case'}
    f = FieldOverride('field1')
    assert f.field == 'field1'
    assert f.fieldname == 'field1'
    assert f.asdict() == {'field': 'field1', 'fieldname': 'field1'}
    assert f.encoder is None
    assert f.decoder is None
    assert f.exclude is None
    assert f.letter_case is None
    f = FieldOverride('field2', 'encoder2', 'decoder2', 'exclude2',
                      'letter_case2')
   

# Generated at 2022-06-21 11:25:29.431058
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder(): # type: ignore
    assert _ExtendedEncoder().encode(datetime(2020, 2, 5, 16, 17, 12, 557)) == '"2020-02-05T16:17:12.000557"'



# Generated at 2022-06-21 11:26:02.192304
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default('a') == 'a'
    assert _ExtendedEncoder().default(3) == 3
    assert _ExtendedEncoder().default(3.4) == 3.4
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default({'a': 3}) == {'a': 3}
    assert _ExtendedEncoder().default(['a', 3, 3.4]) == ['a', 3, 3.4]
    assert _ExtendedEncoder().default((3, 'a', 3.4)) == [3, 'a', 3.4]

# Generated at 2022-06-21 11:26:07.617833
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride() == FieldOverride()
    assert FieldOverride(1, 2, 3) == \
           FieldOverride(1, 2, 3)
    assert FieldOverride(1, 2, 3) != \
           FieldOverride(1, 2, 4)


# Generated at 2022-06-21 11:26:16.937798
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda x: x
    decoder = lambda x: x
    assert FieldOverride(letter_case=None,
                         exclude=None,
                         encoder=None,
                         decoder=None) == \
        FieldOverride(letter_case=None,
                      exclude=None,
                      encoder=None,
                      decoder=None)
    assert FieldOverride(letter_case=None,
                         exclude=None,
                         encoder=encoder,
                         decoder=None) == \
        FieldOverride(letter_case=None,
                      exclude=None,
                      encoder=encoder,
                      decoder=None)

# Generated at 2022-06-21 11:26:26.243978
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class MyObj:
        def test_func(self, val):
            return val
    obj = MyObj()
    obj.test_func = MyObj.test_func
    fo = FieldOverride(
        letter_case=lambda x: x.upper(),
        encoder=lambda x: MyObj().test_func(x),
        exclude=lambda x: False,
        decoder=lambda x: MyObj().test_func(x),
    )
    assert fo.letter_case("abc") == "ABC"
    assert fo.encoder("abc") == "abc"
    assert fo.exclude("abc") == False
    assert fo.decoder("abc") == "abc"



# Generated at 2022-06-21 11:26:36.988801
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    d = datetime.strptime('2000-01-01 00:00:00', '%Y-%m-%d %H:%M:%S')
    assert _ExtendedEncoder().default(d) == 946684800.0
    assert _ExtendedEncoder().default(Decimal(42)) == "42"
    assert _ExtendedEncoder().default(UUID('b04d6eac-ac46-11e9-9f06-005056a68e30')) == 'b04d6eac-ac46-11e9-9f06-005056a68e30'

# Generated at 2022-06-21 11:26:48.667174
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(b"") == b""
    assert _ExtendedEncoder().default(bytearray(b"abc")) == bytearray(b"abc")
    assert _ExtendedEncoder().default(memoryview(b"abc")) == memoryview(b"abc")
    assert _ExtendedEncoder().default(datetime(2018, 1, 2, 3, 4, 5, 6)) == 1514896645.000006
    assert _ExtendedEncoder().default(Enum('TestEnum', {'A': 1})('A')) == 1
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default

# Generated at 2022-06-21 11:26:57.929802
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from collections import OrderedDict
    from datetime import date, datetime, time
    from decimal import Decimal
    from enum import Enum
    from uuid import uuid4
    from dataclasses_json.utils import _isinstance_safe
    encoder = _ExtendedEncoder()

# Generated at 2022-06-21 11:27:08.928377
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_encoder = json.JSONEncoder()
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.default(dict(foo=1))                       == json_encoder.default(dict(foo=1))
    assert extended_encoder.default(list(range(10)))                   == json_encoder.default(list(range(10)))
    assert extended_encoder.default(timezone.utc)                      == json_encoder.default(timezone.utc)
    assert extended_encoder.default(datetime(2019, 1, 1, 0, 0, 0))     == json.dumps(1546300800.0)

# Generated at 2022-06-21 11:27:12.485137
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = json.JSONEncoder(default=lambda x: x.__dict__)
    encoder = _ExtendedEncoder().encode(datetime(1970, 1, 1, 0, 0, 0, 0, timezone.utc))



# Generated at 2022-06-21 11:27:18.242521
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    class Foo:
        def __init__(self, bar):
            self.bar = bar

    encoder = _ExtendedEncoder()
    assert encoder.default(Foo(42)) == {'bar': 42}
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default(set((1, 2, 3))) == [1, 2, 3]
    assert encoder.default(frozenset((1, 2, 3))) == [1, 2, 3]
    assert encoder.default({'foo': 3}) == {'foo': 3}
    assert encoder.default((3, 'foo')) == [3, 'foo']

# Generated at 2022-06-21 11:27:38.999132
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(1.2) == 1.2



# Generated at 2022-06-21 11:27:50.936353
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode(datetime(2019, 11, 11, 1, 1, 1)) == '1573461661.0'
    assert _ExtendedEncoder().encode(datetime(2019, 11, 11, 1, 1, 1, tzinfo=timezone.utc)) == '1573461661.0'
    assert _ExtendedEncoder().encode(UUID('cc7cddb4-4ba1-4d95-b5c7-c49d50b76461')) == '"cc7cddb4-4ba1-4d95-b5c7-c49d50b76461"'

# Generated at 2022-06-21 11:28:01.363220
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Case 1, parameter `letter_case` is None
    override = FieldOverride(exclude=None, letter_case=None, encoder=None, decoder=None)
    assert override.exclude == None
    assert override.letter_case == None
    assert override.encoder == None
    assert override.decoder == None

    # Case 2, parameter `encoder` is None
    override = FieldOverride(exclude=None, letter_case=None, encoder=None, decoder=lambda x: None)
    assert override.exclude == None
    assert override.letter_case == None
    assert override.encoder == None
    assert override.decoder != None


# Generated at 2022-06-21 11:28:09.492783
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Type of arguments
    assert(FieldOverride(exclude=None).exclude == None)
    assert(FieldOverride(letter_case=None).letter_case == None)
    assert(FieldOverride(encoder=None).encoder == None)
    assert(FieldOverride(decoder=None).decoder == None)
    # Type of arguments

# Generated at 2022-06-21 11:28:19.777189
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert _ExtendedEncoder().default(UUID('dddddddd-dddd-dddd-dddd-dddddddddddd')) == 'dddddddd-dddd-dddd-dddd-dddddddddddd'
    assert _ExtendedEncoder().default(Decimal('1.23')) == '1.23'



# Generated at 2022-06-21 11:28:21.114052
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default('abc') is 'abc'



# Generated at 2022-06-21 11:28:28.162946
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # GIVEN
    # Instance of ExtendedEncoder
    extended_encoder = _ExtendedEncoder()

    # WHEN
    # default method is called with a datetime object
    datetime_obj = datetime.now()
    json_obj = extended_encoder.default(datetime_obj)
    json_obj2 = extended_encoder.default(datetime_obj)

    # THEN
    # The result is as expected
    assert json_obj == json_obj2
    assert isinstance(json_obj, float)



# Generated at 2022-06-21 11:28:39.395331
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', category=DeprecationWarning)
        assert _ExtendedEncoder().default(datetime(1971, 1, 1)) == 31536000.0
        assert _ExtendedEncoder().default(datetime.now(timezone.utc)) ==\
               datetime.now(timezone.utc).timestamp()
        assert _ExtendedEncoder().default(Decimal(1)) == '1'
        assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) ==\
               '12345678-1234-5678-1234-567812345678'


# noinspection PyUnusedLocal

# Generated at 2022-06-21 11:28:47.378531
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Act
    encoder = _ExtendedEncoder()

    # Assert
    assert encoder.default(['a', 'b']) == ['a', 'b']
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default(datetime.utcnow()) == datetime.utcnow().timestamp()
    assert encoder.default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert encoder.default(Decimal('12.34')) == '12.34'


# Generated at 2022-06-21 11:28:50.819792
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride('snake', None, None)
    assert field_override.letter_case('fooBar') == 'foo_bar'

    def exclude(x):
        return True
    field_override = FieldOverride(None, exclude, None)
    assert field_override.exclude('fooBar') == True

    field_override = FieldOverride(None, None, lambda x: int(x))
    assert field_override.decoder('123') == 123



# Generated at 2022-06-21 11:29:17.561688
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(False) == 'false'
    assert _ExtendedEncoder().encode(0) == '0'
    assert _ExtendedEncoder().encode(0.0) == '0.0'
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode('') == '""'
    assert _ExtendedEncoder().encode("") == '""'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode(()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'

# Generated at 2022-06-21 11:29:19.086430
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(1988, 12, 12)) == "632854000.0"



# Generated at 2022-06-21 11:29:22.729977
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    """
    Verify round-tripping a dictionary.
    """
    assert _ExtendedEncoder().default({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}



# Generated at 2022-06-21 11:29:24.125275
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o: Json = _ExtendedEncoder().default('abc')
    assert o == 'abc'

# Generated at 2022-06-21 11:29:31.280636
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride().decoder is None
    assert FieldOverride().encoder is None
    assert FieldOverride().exclude is None
    assert FieldOverride().letter_case is None

    # test all possible combinations
    assert FieldOverride(decoder=True).decoder is True
    assert FieldOverride(encoder=True).encoder is True
    assert FieldOverride(exclude=True).exclude is True
    assert FieldOverride(letter_case=True).letter_case is True

    assert FieldOverride(decoder=True).encoder is None
    assert FieldOverride(decoder=True).exclude is None
    assert FieldOverride(decoder=True).letter_case is None

    assert FieldOverride(encoder=True).decoder is None
    assert FieldOverride(encoder=True).exclude is None
    assert FieldOverride(encoder=True).letter_case

# Generated at 2022-06-21 11:29:38.685075
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Default constructor
    cfg = FieldOverride()
    assert cfg is not None

    # Partial constructor specifying the predicate
    cfg = FieldOverride(exclude=lambda x: isinstance(x, str))
    assert cfg is not None
    assert cfg.letter_case is None
    assert cfg.encoder is None
    assert cfg.decoder is None
    assert cfg.exclude(None) is False
    assert cfg.exclude("") is True

    # Partial constructor specifying the case converter
    cfg = FieldOverride(letter_case=lambda x: x.upper())
    assert cfg is not None
    assert cfg.exclude is None
    assert cfg.encoder is None
    assert cfg.decoder is None
    assert cfg.letter_case("test") == "TEST"

    #

# Generated at 2022-06-21 11:29:45.557508
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import timedelta
    import datetime
    from uuid import uuid4
    from decimal import Decimal

    encoder = _ExtendedEncoder()

    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default(datetime.datetime(2018, 1, 1)) == 1514764800.0
    assert encoder.default(datetime.datetime(2018, 1, 1, tzinfo=datetime.timezone.utc)) == 1514764800.0
    assert encoder.default(datetime.date(2018, 1, 1)) == 1514764800.0
    assert encoder.default(timedelta(seconds=1)) == 1.0
    assert encoder

# Generated at 2022-06-21 11:29:47.427345
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(exclude=None, letter_case=None,
                         encoder=None, decoder=None) is not None


# Unit tests for constructor of class _ExtendedEncoder

# Generated at 2022-06-21 11:29:49.604004
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fieldOverride = FieldOverride(False, False, str.upper, None)
    assert fieldOverride.exclude == False
    assert fieldOverride.letter_case == str.upper
    assert fieldOverride.encoder == None
    assert fieldOverride.decoder == None


# Generated at 2022-06-21 11:30:00.622242
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import date, datetime, time
    from decimal import Decimal, ROUND_HALF_UP
    from fractions import Fraction
    import decimal
    import io
    import json
    import uuid
    from dataclasses import astuple, fields, make_dataclass, dataclass
    from enum import Enum
    from dataclasses_json.utils import _is_dataclass_instance, _isinstance_safe, _is_optional, _get_type_cons

    x = [True, False, None, 1, 2.3, 3.5e5, 'string', object(), [1, 2, 3], {'a': 'b'}]
    y = _ExtendedEncoder().default(x)
    assert x == y


# Generated at 2022-06-21 11:30:45.596172
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2001, 1, 2, 13, 46, 11)) == '978317771.0'



# Generated at 2022-06-21 11:30:54.907848
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(1.1) == 1.1
    assert _ExtendedEncoder().default('1') == '1'
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default(datetime(1970, 1, 1)) == 0.0
    assert _ExtendedEncoder().default(Enum('name', [])) == 'name'
    assert _ExtendedEncoder().default(UUID('2d9d0c4a-4cbc-4100-a423-cdbf4792e5f5')) == '2d9d0c4a-4cbc-4100-a423-cdbf4792e5f5'
    assert _ExtendedEncoder().default(Decimal('1.1')) == '1.1'
    assert _

# Generated at 2022-06-21 11:30:57.823916
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(
        {UUID("0c0e2bca-1d07-4f98-b768-6811b9bf9fad"),
         Decimal("0.0")}) == '["0c0e2bca-1d07-4f98-b768-6811b9bf9fad", "0.0"]'



# Generated at 2022-06-21 11:31:02.496153
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    json_encoder = _ExtendedEncoder()
    # noinspection PyArgumentList
    assert json_encoder.default(123) == 123
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=DeprecationWarning)
        assert json_encoder.default(Decimal('1.1')) == '1.1'
    # noinspection PyArgumentList
    assert json_encoder.default(Decimal('1.1')) == '1.1'


# Generated at 2022-06-21 11:31:04.141563
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # Coverage test
    # noinspection PyUnresolvedReferences
    str(_ExtendedEncoder())



# Generated at 2022-06-21 11:31:14.823416
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_name = "test_field"
    test_conf = {"exclude": True,
                 "letter_case": lambda x: x.upper(),
                 "encoder": lambda x: f"encoded_x_{x}",
                 "decoder": lambda x: f"decoded_x_{x}"}
    test_override = FieldOverride(test_conf["exclude"],
                                  test_conf["letter_case"],
                                  test_conf["encoder"],
                                  test_conf["decoder"])
    # Check the parameter of class FieldOverride
    check_override_params(test_override, test_conf)
    # Check the `to_dict` method of class FieldOverride
    check_override_to_dict(test_override, test_conf)


# Generated at 2022-06-21 11:31:24.789967
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ee = _ExtendedEncoder()
    assert ee.default([1, 2, 3]) == [1, 2, 3]
    assert ee.default({"one": 1, "two": 2}) == {"one": 1, "two": 2}
    assert ee.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert ee.default(UUID('146b64b6-f623-46f1-a3c6-936e9a0a8a70')) == '146b64b6-f623-46f1-a3c6-936e9a0a8a70'
    assert ee.default(Decimal('42.42')) == '42.42'

# Generated at 2022-06-21 11:31:27.211293
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = datetime.now(tz=timezone.utc)
    assert isinstance(o, datetime)
    assert _ExtendedEncoder().default(o) == o.timestamp()



# Generated at 2022-06-21 11:31:32.512884
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([UUID(int=1), UUID(int=10)]) == '[null,null]'
    assert json.loads(_ExtendedEncoder().encode([UUID(int=1), UUID(int=10)])) == [None, None]

    assert _ExtendedEncoder().encode([UUID(int=1), UUID(int=10)]) == '[null,null]'
    assert json.loads(_ExtendedEncoder().encode([UUID(int=1), UUID(int=10)])) == [None, None]

    assert json.loads(_ExtendedEncoder().encode(['a', 'b'])) == ['a', 'b']

    assert json.loads(_ExtendedEncoder().encode([1, 2])) == [1, 2]


# Generated at 2022-06-21 11:31:38.024039
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.utcnow())
    assert _ExtendedEncoder().default(datetime.utcnow())
    assert _ExtendedEncoder().default(UUID('f4cc2cf4-4c0e-11ea-b77f-2e728ce88125'))
    assert _ExtendedEncoder().default(UUID('f4cc2cf4-4c0e-11ea-b77f-2e728ce88125'))
    assert _ExtendedEncoder().default(Decimal('3.141592653589793238462643383279502884197169399375105820974944592307816406286208998628034825342117067'))

# Generated at 2022-06-21 11:33:18.130948
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(exclude=None, letter_case=None, encoder=None, decoder=None)
    assert fo.exclude == None
    assert fo.letter_case == None
    assert fo.encoder == None
    assert fo.decoder == None
    # Infer missing parameters
    fo1 = FieldOverride(exclude=lambda x:x, encoder=_int)
    assert fo1.letter_case == None
    assert fo1.decoder == None
    fo2 = FieldOverride(letter_case=_decode_upper)
    assert fo2.exclude == None
    assert fo2.encoder == None
    assert fo2.decoder == None
    fo3 = FieldOverride(decoder=_decode_int)
    assert fo3.exclude == None

# Generated at 2022-06-21 11:33:24.405986
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(None) is None
    assert encoder.default({1: 'a'}) == {1: 'a'}
    assert encoder.default((1,)) == [1]
    assert encoder.default('a') == 'a'
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default(True) == True
    assert encoder.default(datetime(2000, 1, 1, 12, 0, 0, tzinfo=timezone.utc)) == 946684800.0
    assert encoder.default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'

# Generated at 2022-06-21 11:33:35.837001
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ee = _ExtendedEncoder()
    assert ee.default(set([1, 2, 3])) == [1, 2, 3]
    assert ee.default(tuple({1: 2, 3: 4})) == {1: 2, 3: 4}
    assert ee.default({1, 2, 3}) == [1, 2, 3]
    assert ee.default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert ee.default(123) == 123
    assert ee.default("1.23") == "1.23"
    assert ee.default(set()) == set()
    assert ee.default("") == ""
    assert ee.default(None) is None


# Generated at 2022-06-21 11:33:43.599013
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import dataclass
    from decimal import Decimal

    @dataclass
    class Test:
        dt: datetime
        uuid: UUID
        enum: Enum
        dec: Decimal
        other: object

    e = _ExtendedEncoder()


# Generated at 2022-06-21 11:33:53.947823
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default({'a': 'b'}) == {'a': 'b'}
    assert enc.default([1, 2, 3]) == [1, 2, 3]
    assert enc.default(datetime(2017, 1, 1, tzinfo=timezone.utc)) == \
        datetime(2017, 1, 1, tzinfo=timezone.utc).timestamp()
    assert enc.default(UUID('a904b494-cdeecfde-a84d-f0cbb2545763')) == \
        'a904b494-cdeecfde-a84d-f0cbb2545763'
    assert enc.default(Decimal('2.5')) == '2.5'