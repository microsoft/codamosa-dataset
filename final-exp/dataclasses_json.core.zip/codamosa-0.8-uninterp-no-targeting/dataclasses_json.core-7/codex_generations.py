

# Generated at 2022-06-21 11:24:21.819329
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(exclude=None, letter_case=None, encoder=None,
                      decoder=None)
    # FIXME this should assert False
    f.letter_case = lambda s: s.lower()
    f.exclude = lambda v: True
    f.encoder = lambda v: v + 1
    f.decoder = lambda v: v + 1



# Generated at 2022-06-21 11:24:31.683714
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    for obj in (
        [1, 2, 3],
        [],
        {'a': 1, 'b': 2},
        {},
        datetime(2020, 1, 1, 1, 1, 1, tzinfo=timezone.utc),
        datetime(2020, 1, 1, 1, 1, 1),
        Decimal('1.1'),
        UUID('00000000-0000-0000-0000-000000000000'),
        Enum('E', {'a': 1, 'b': 2}),
        Enum('E', {'a': 1, 'b': {}}),
        Enum('E', {'a': 1, 'b': []}),
    ):
        assert _ExtendedEncoder().default(obj) == obj
    assert _ExtendedEncoder().default(1) == 1
    assert _Ext

# Generated at 2022-06-21 11:24:35.478370
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    c1 = FieldOverride(letter_case='snake',
                       exclude=lambda x: x == 1)
    c2 = FieldOverride(letter_case=None,
                       exclude=lambda x: x == 1)

    assert c1.letter_case == 'snake' and c1.exclude(1) and not c1.exclude(0)
    assert c2.letter_case == None and c2.exclude(1) and not c2.exclude(0)


# Generated at 2022-06-21 11:24:45.203012
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([1, 2]) == [1, 2]
    assert _ExtendedEncoder().default(dict(a=1, b=2)) == {"a": 1, "b": 2}
    assert _ExtendedEncoder().default(datetime(2020,2,2,2,2,2,2,timezone.utc)) == 1583101122.000002
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(Decimal('1.2')) == '1.2'



# Generated at 2022-06-21 11:24:47.728408
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ = _ExtendedEncoder()



# Generated at 2022-06-21 11:24:49.118144
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    o = _ExtendedEncoder()
    assert o


# Generated at 2022-06-21 11:24:51.818469
# Unit test for constructor of class FieldOverride

# Generated at 2022-06-21 11:24:54.773304
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    for cls in [tuple, set, frozenset, Decimal, datetime, Enum]:
        assert encoder.default(cls()) is None


# Generated at 2022-06-21 11:25:05.408965
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import dataclass
    from typing import Iterable

    @dataclass
    class Foo:
        a: int
        b: float
        c: str
        d: Iterable[Foo]
        e: Mapping[str, int]
        f: datetime


# Generated at 2022-06-21 11:25:11.389322
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test default values
    override = FieldOverride()
    assert override.exclude is None
    assert override.encoder is None
    assert override.decoder is None
    assert override.letter_case is None
    # Test argument passing
    excl_func = lambda x: x < 2
    enc_func = lambda x: x + 2
    dec_func = lambda x: x - 2
    let_func = lambda x: x.upper()
    override = FieldOverride(excl_func, enc_func, dec_func, let_func)
    assert override.exclude == excl_func
    assert override.encoder == enc_func
    assert override.decoder == dec_func
    assert override.letter_case == let_func



# Generated at 2022-06-21 11:25:50.838285
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    cons = FieldOverride(exclude=lambda x: x == 1)
    assert cons.exclude(1)
    assert not cons.exclude(0)

    cons = FieldOverride(letter_case=lambda x: x.upper())
    assert cons.letter_case('abc') == 'ABC'

    cons = FieldOverride(encoder=lambda x: x ** 2)
    assert cons.encoder(2) == 4

    cons = FieldOverride(decoder=lambda x: x * 2)
    assert cons.decoder(4) == 8

    cons = FieldOverride(
        exclude=lambda x: x == 1,
        letter_case=lambda x: x.upper(),
        encoder=lambda x: x ** 2,
        decoder=lambda x: x * 2)



# Generated at 2022-06-21 11:25:52.903859
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride()
    assert FieldOverride(None)
    assert FieldOverride(None, None)
    assert FieldOverride(None, None, None)
    assert FieldOverride(None, None, None, None)
    assert FieldOverride(None, lambda x: x, None, None)


# Generated at 2022-06-21 11:25:59.526564
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses_json.utils import is_namedtuple_instance
    from dataclasses_json.types_ import _MISSING_
    from datetime import date, time
    import decimal

    encoder = _ExtendedEncoder()

    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default((1, 2)) == [1, 2]
    assert encoder.default({1: 2}) == {1: 2}
    assert encoder.default(set([1, 2])) == [1, 2]

    assert encoder.default(datetime.now()) == datetime.now().timestamp()
    assert encoder.default(date.today()) == date.today().timestamp()
    assert encoder.default(time(1, 2)) == time(1, 2).isoformat()

# Generated at 2022-06-21 11:26:12.128419
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert e.default(set()) == list(set())
    assert e.default({}) == dict({})
    assert e.default(1) == 1
    assert e.default(1.0) == 1.0
    assert e.default("") == ""
    assert e.default(True) == True
    assert e.default(None) == None
    assert e.default(datetime(2020, 1, 1, 12, 1, 1, tzinfo=timezone.utc)) == 1577872861

# Generated at 2022-06-21 11:26:19.534973
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import dataclass

    class CustomEnum(Enum):
        MyValue = 'MyValue'

    @dataclass
    class MyClass:
        value: str = 'value'

    @dataclass
    class MyClass2:
        value: str = 'value'
        my_class: MyClass = MyClass()

    class MyClass3(dict):
        def __init__(self, list_value=None, **kwargs):
            super().__init__(**kwargs)
            self['list_value'] = list_value


# Generated at 2022-06-21 11:26:28.163965
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import datetime
    from uuid import UUID
    from decimal import Decimal
    from enum import Enum
    class TestEnum(Enum):
        TEST = 'test'
    obj1 = 1
    obj2 = 'a'
    obj3 = {'a': 1}
    obj4 = [1, 2]
    obj5 = datetime.now()
    obj6 = UUID('7b2d5c67-a2ef-4c9d-8e77-1c7dfe1626a6')
    obj7 = Decimal('1.11')
    obj8 = TestEnum.TEST
    obj9 = object()
    test_data = [obj1, obj2, obj3, obj4, obj5, obj6, obj7, obj8, obj9]

# Generated at 2022-06-21 11:26:39.663990
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test default value
    override = FieldOverride()
    assert override.encoder == identity
    assert override.decoder == identity
    assert override.exclude == always_false
    assert override.letter_case == snake_case

    # test new instance with one given value
    def custom_letter_case(text):
        return text.upper()

    override = FieldOverride(letter_case = custom_letter_case)
    assert override.encoder == identity
    assert override.decoder == identity
    assert override.exclude == always_false
    assert override.letter_case == custom_letter_case

    # test new instance with all given values
    def custom_exclude(value):
        return True if value is None else False

    def custom_encode(value):
        return value

    def custom_decode(value):
        return value

# Generated at 2022-06-21 11:26:46.787540
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    exclude = lambda value: isinstance(value, str)
    encoder = id
    decoder = id
    letter_case = lower
    override = FieldOverride(exclude, letter_case, encoder, decoder)
    assert override.exclude(1) == False
    assert override.exclude('1') == True
    assert override.letter_case('A') == 'a'
    assert override.encoder(2) == 2
    assert override.decoder(3) == 3

# Generated at 2022-06-21 11:26:56.716567
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import datetime
    from uuid import UUID
    from decimal import Decimal

    str1 = json.dumps([1, 2, 3])
    str2 = json.dumps({'a': 1, 'b': 2, 'c': 3})
    str3 = json.dumps(datetime.now())
    str4 = json.dumps(UUID(int=1))
    str5 = json.dumps(Decimal(15))
    str6 = json.dumps(Decimal("NaN"))

    assert str1 == _ExtendedEncoder().encode([1, 2, 3])
    assert str2 == _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3})
    assert str3 != _ExtendedEncoder().encode(datetime.now())
   

# Generated at 2022-06-21 11:26:59.134621
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(TypeError):
        FieldOverride(None, None, None)


# Generated at 2022-06-21 11:27:45.012542
# Unit test for constructor of class FieldOverride
def test_FieldOverride():

    # Test constructor: is optional, has no default args
    field_override = FieldOverride()
    assert field_override.letter_case is None
    assert field_override.exclude is None
    assert field_override.encoder is None
    assert field_override.decoder is None

    # Test constructor: is optional, has all args
    field_override = FieldOverride(letter_case=_lowercase_underscore,
                                   exclude=lambda v: v is not None,
                                   encoder=lambda v: v,
                                   decoder=lambda v: v)
    assert field_override.letter_case == _lowercase_underscore
    assert field_override.exclude is not None
    assert field_override.encoder is not None
    assert field_override.decoder is not None

    #

# Generated at 2022-06-21 11:27:53.168443
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride("A", "B", True)
    assert f.name == "A"
    assert f.exclude is True
    assert f.letter_case == "B"
    assert f.encoder is None
    assert f.decoder is None
    f = FieldOverride("A", "B", "C", "D")
    assert f.name == "A"
    assert f.exclude is False
    assert f.letter_case == "B"
    assert f.encoder == "C"
    assert f.decoder == "D"


# Generated at 2022-06-21 11:28:04.902837
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({datetime.now(): 'a', UUID('123e4567-e89b-12d3-a456-426655440000'): 1}) == '{"1539756940.841461": "a", "123e4567-e89b-12d3-a456-426655440000": 1}'

# Generated at 2022-06-21 11:28:11.175247
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(b'foo') == '"foo"'
    assert _ExtendedEncoder().encode(b'123') == '"123"'
    assert _ExtendedEncoder().encode(b'{"a": "b"}') == '"{\\"a\\": \\"b\\"}"'
    assert _ExtendedEncoder().encode(b'[1, 2, 3]') == '"[1, 2, 3]"'

    # Test datetime.datetime()
    assert _ExtendedEncoder().encode(datetime.strptime('2018-01-01 00:00:00', '%Y-%m-%d %H:%M:%S')) == '1514764800.0'

    # Test Decimal()

# Generated at 2022-06-21 11:28:22.124424
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default({'a': 1}) == {'a': 1}
    assert _ExtendedEncoder().default(datetime(2018, 4, 13, 13, 15, tzinfo=timezone.utc)) == 1523622700.0
    assert _ExtendedEncoder().default(UUID('ee0a0814-e242-4e63-af01-b734816b8a87')) == 'ee0a0814-e242-4e63-af01-b734816b8a87'
    assert _ExtendedEncoder().default(Decimal('3.14')) == '3.14'



# Generated at 2022-06-21 11:28:26.505139
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = datetime.now(timezone.utc)
    # noinspection PyTypeChecker
    assert _ExtendedEncoder().default(o) == o.timestamp()
    # noinspection PyTypeChecker
    assert _ExtendedEncoder().default(o.timestamp()) == o.timestamp()



# Generated at 2022-06-21 11:28:28.699164
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Arrange

    # Act
    res = json.dumps([], cls=_ExtendedEncoder)

    # Assert
    assert res == "[]"



# Generated at 2022-06-21 11:28:34.963498
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test 1: constructor with no arguments (defaults passed)
    test_fieldoverride_noarg = FieldOverride()
    # Test 2: constructor with all arguments defined
    test_fieldoverride_allargs = FieldOverride(exclude, letter_case, encoder,
                                               decoder, mm_field)
    # Test 3: constructor with incomplete args
    test_fieldoverride_inc = FieldOverride(exclude=exclude, encoder=encoder,
                                           mm_field=mm_field)
    # Test 4: constructor with invalid args

# Generated at 2022-06-21 11:28:45.791003
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    jsonObj = json.loads(json.dumps([1, 2, 3], cls=_ExtendedEncoder))
    jsonObj == [1, 2, 3]
    jsonObj = json.loads(json.dumps({'a': 1, 'b': 2}, cls=_ExtendedEncoder))
    jsonObj == {'a': 1, 'b': 2}
    jsonObj = json.loads(json.dumps({'a': datetime.now(
        timezone.utc), 'b': 2}, cls=_ExtendedEncoder))
    jsonObj

# Generated at 2022-06-21 11:28:54.768730
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_obj = {'a': set([1, 2, 3]),
                'b': dict(a=1, b=2),
                'c': datetime.utcnow(),
                'd': datetime.utcnow(timezone.utc),
                'e': UUID('087776c8-a7d5-11e8-9f32-f2801f1b9fd1'),
                'f': Decimal('1.7'),
                'g': Decimal('3.5e5')}
    output = json.dumps(test_obj, cls=_ExtendedEncoder)

# Generated at 2022-06-21 11:30:13.091551
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Test the constructor of the class FieldOverride.
    """
    # Test the initialization of an object
    @dataclass
    class BasicData:
        a: int
        b: str
        c: float

    f_name = "a"
    letter_case = lambda x: x + "1"
    exclude = lambda x: x == 100
    encoder = lambda x: x + 1
    decoder = lambda x: x - 1

    field_ctrl = FieldOverride(letter_case=letter_case,
                               exclude=exclude,
                               encoder=encoder,
                               decoder=decoder)

    assert field_ctrl.letter_case == letter_case
    assert field_ctrl.exclude == exclude
    assert field_ctrl.encoder == encoder
    assert field_ctrl.decoder == decoder

# Generated at 2022-06-21 11:30:23.868172
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    extended_encoder = _ExtendedEncoder()
    assert extended_encoder.default([1, 2, 3]) == [1, 2, 3]
    assert extended_encoder.default([1, {'hello': 'world'}, 3]) == [1, {'hello': 'world'}, 3]
    assert extended_encoder.default({'hello': 'world'}) == {'hello': 'world'}
    assert extended_encoder.default(datetime(2020, 10, 1, 12, 0, 0, 0, tzinfo=timezone.utc)) == 1606822000.0

# Generated at 2022-06-21 11:30:32.458167
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(dict(key=1)) == '{"key": 1}'
    now = datetime.now(timezone.utc)
    assert _ExtendedEncoder().encode(now) == '{0:.6f}'.format(now.timestamp())
    assert _ExtendedEncoder().encode(UUID('{12345678-1234-5678-1234-567812345678}')) == '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().encode(Decimal('.123456')) == '0.123456'
    assert _ExtendedEncoder().encode(Missing) == 'null'
    assert _ExtendedEncoder().encode(cfg.letter_case.upper) == 'upper'


# Generated at 2022-06-21 11:30:34.320838
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": datetime.now()})


# Generated at 2022-06-21 11:30:42.289621
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default({'x': 1, 'y': 2}) == {'x': 1, 'y': 2}
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('{123e4567-e89b-12d3-a456-426655440001}')) == '123e4567-e89b-12d3-a456-426655440001'
    assert encoder.default(Decimal('1.2')) == '1.2'



# Generated at 2022-06-21 11:30:49.737875
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Tests for parameter override
    override = FieldOverride(exclude=lambda x: True)
    assert override.exclude(2) == True

    # Tests for parameter letter_case
    override = FieldOverride(letter_case=lambda x: x.upper())
    assert override.letter_case('a') == 'A'

    # Tests for parameter encoder
    override = FieldOverride(encoder=lambda x: '1')
    assert override.encoder(2) == '1'

    # Tests for parameter decoder
    override = FieldOverride(decoder=lambda x: '2')
    assert override.decoder(2) == '2'


# Generated at 2022-06-21 11:30:58.528830
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(('x', 'y')) == ['x', 'y']
    assert encoder.default(['x', 'y']) == ['x', 'y']
    assert encoder.default({'x': 'y'}) == {'x': 'y'}
    assert encoder.default(set(('x', 'y'))) == ['x', 'y']
    assert encoder.default(frozenset(('x', 'y'))) == ['x', 'y']
    assert encoder.default(123) == 123
    assert encoder.default(123.45) == 123.45
    assert encoder.default(True)
    assert encoder.default(Enum)
    assert encoder.default(datetime.utcnow())

# Generated at 2022-06-21 11:31:00.063394
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    msg = "Constructor of FieldOverride should take a tuple of tuples"
    with pytest.raises(TypeError, match=msg):
        FieldOverride(None)



# Generated at 2022-06-21 11:31:01.379406
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride()
    assert field_override.letter_case is None



# Generated at 2022-06-21 11:31:11.658591
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert (FieldOverride(letter_case=str.upper,
          exclude=lambda x: x == 'exclude',
          encoder=lambda x: x + 1,
          decoder=lambda x: x - 1)
    == FieldOverride(letter_case=str.upper,
          exclude=lambda x: x == 'exclude',
          encoder=lambda x: x + 1,
          decoder=lambda x: x - 1))