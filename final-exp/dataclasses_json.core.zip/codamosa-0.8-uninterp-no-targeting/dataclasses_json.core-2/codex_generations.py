

# Generated at 2022-06-21 11:24:29.128761
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    en = _ExtendedEncoder()
    # Check dict
    o = {'foo': 'bar'}
    result = en.default(o)
    assert result == o
    # Check list
    o = ['foo', 'bar']
    result = en.default(o)
    assert result == o
    # Check datetime
    o = datetime(2019, 1, 1, tzinfo=timezone.utc)
    result = en.default(o)
    assert result == o.timestamp()
    # Check UUID
    o = UUID('123e4567-e89b-12d3-a456-426655440000')
    result = en.default(o)
    assert result == '123e4567-e89b-12d3-a456-426655440000'
    # Check

# Generated at 2022-06-21 11:24:32.844097
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # TODO: Add docstring and examples
    assert _ExtendedEncoder().encode({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'



# Generated at 2022-06-21 11:24:36.794290
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default('dataclasses_json') == 'dataclasses_json'
    assert _ExtendedEncoder().default(5) == 5
    assert _ExtendedEncoder().default(5.5) == 5.5
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(False) == False
    assert _ExtendedEncoder().default(None) == None

# Generated at 2022-06-21 11:24:43.980341
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(Decimal('1.2')) == '1.2'
    assert _ExtendedEncoder().default(Decimal('1.2E16')) == '1200000000000000'
    assert _ExtendedEncoder().default(Decimal('1.2E-16')) == '0.00000000000000012000000000000000001'
    assert _ExtendedEncoder().default(Decimal('1.2E-17')) == '0.0'

# Add toNum() function to _ExtendedEncoder

# Generated at 2022-06-21 11:24:47.378460
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride() == FieldOverride(None, None, None)

# Generated at 2022-06-21 11:24:54.487261
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_data = {
        'foo': list(range(2)),
        'bar': dict(baz='qux', quxx='corge'),
        'grault': datetime(year=2018, month=12, day=25, tzinfo=timezone.utc),
        'waldo': UUID('3a752c04-57d4-4a39-8f19-2d03cb9a0e72'),
        'fred': Enum('Meta', 'x y z', start=42),
        'plugh': Decimal('42'),
    }

# Generated at 2022-06-21 11:25:03.766592
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # TODO: test datetime.timestamp()
    original = {'a': 1, 'b': {'c': [1, 2, 3]}, 'd': [[[4, 5, 6]]]}
    expected = {'a': 1, 'b': {'c': [1, 2, 3]}, 'd': [[[4, 5, 6]]]}
    assert _ExtendedEncoder().default(original) == expected
    original = (1, 2, 3)
    expected = [1, 2, 3]
    assert _ExtendedEncoder().default(original) == expected
    original = (1, '2', 3.3)
    expected = [1, '2', 3.3]
    assert _ExtendedEncoder().default(original) == expected

# Generated at 2022-06-21 11:25:11.140276
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
  assert _ExtendedEncoder().default(UUID('c3e71340-7b6d-11ea-bc55-0242ac130003')) == 'c3e71340-7b6d-11ea-bc55-0242ac130003'
  assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == 1587136963.444464
  assert _ExtendedEncoder().default({1: 'a', 2: 'b'}) == {'1': 'a', '2': 'b'}



# Generated at 2022-06-21 11:25:19.147542
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoding_value = "encoding_value"
    decoding_value = lambda x: x
    letter_case = str.lower
    exclude_value = lambda x: True
    field_override = FieldOverride(encoding_value, decoding_value, letter_case, exclude_value)
    assert(field_override.encoder == encoding_value)
    assert(field_override.decoder == decoding_value)
    assert(field_override.letter_case == letter_case)
    assert(field_override.exclude == exclude_value)



# Generated at 2022-06-21 11:25:23.310531
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(AssertionError) as exc_info:
        FieldOverride(exclude=1, letter_case=1, encoder=1, decoder=1)
    assert 'a function' in str(exc_info.value)

    with pytest.raises(AssertionError) as exc_info:
        FieldOverride(exclude=False, letter_case=1, encoder=1, decoder=1)
    assert 'a function' in str(exc_info.value)

    with pytest.raises(AssertionError) as exc_info:
        FieldOverride(exclude=None, letter_case=1, encoder=1, decoder=1)
    assert 'a function' in str(exc_info.value)


# Generated at 2022-06-21 11:25:52.992624
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    c = _ExtendedEncoder()
    assert c.default([]) == []
    assert c.default({}) == {}
    assert c.default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800
    assert c.default(UUID(int=0)) == '00000000-0000-0000-0000-000000000000'
    assert c.default(Decimal('0')) == '0'
    assert c.default(None) is None



# Generated at 2022-06-21 11:25:59.578060
# Unit test for constructor of class _ExtendedEncoder

# Generated at 2022-06-21 11:26:12.173582
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    from datetime import date, datetime, time
    from decimal import Decimal

    enc = _ExtendedEncoder()

    assert enc.default({}) == {}
    assert enc.default([]) == []
    assert enc.default(datetime(2017, 1, 2, 3, 4, 5, tzinfo=timezone.utc)) == 1483283845.0
    assert enc.default(date(2016, 6, 23)) == '2016-06-23'
    assert enc.default(time()) == '00:00:00'

# Generated at 2022-06-21 11:26:23.143606
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():

    assert _ExtendedEncoder().encode(_ExtendedEncoder()) == '[]'
    assert _ExtendedEncoder().encode([-1, 0, 1]) == '[-1, 0, 1]'
    assert _ExtendedEncoder().encode({1: 'a', 2: 'b'}) == '{"1": "a", "2": "b"}'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode('a') == '"a"'

# Generated at 2022-06-21 11:26:31.889292
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(5) == 5
    assert _ExtendedEncoder().default('abc') == 'abc'
    assert _ExtendedEncoder().default(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert _ExtendedEncoder().default(('a', 'b', 'c')) == ['a', 'b', 'c']
    assert _ExtendedEncoder().default({'a': 'b', 'c': 'd'}) == {'a': 'b', 'c': 'd'}
    assert _ExtendedEncoder().default({'a'}) == ['a']
    assert _ExtendedEncoder().default(set({'a'})) == ['a']
    assert _ExtendedEncoder().default(frozenset({'a'})) == ['a']


# Generated at 2022-06-21 11:26:34.981232
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride()._fields == ('encoder', 'decoder',
                                       'exclude',
                                       'letter_case')

    assert isinstance(FieldOverride().encoder, IntEncoder)

# Generated at 2022-06-21 11:26:35.726917
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default(): pass



# Generated at 2022-06-21 11:26:46.358686
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    name = "test_name"
    renamer = lambda s: "new" + s
    encoder = lambda s: s + 'A'
    decoder = lambda s: s + 'B'
    excluder = lambda s: True

    item = FieldOverride(name, renamer, encoder, decoder, excluder)
    assert item.name == name
    assert item.letter_case(item.name) == renamer(item.name)
    assert item.encoder(item.name) == encoder(item.name)
    assert item.decoder(item.name) == decoder(item.name)
    assert item.exclude(item.name) == excluder(item.name)



# Generated at 2022-06-21 11:26:56.417345
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    try:
        FieldOverride()
        assert False, "Should not get here"
    except TypeError:
        assert True

    assert FieldOverride(encoder=lambda x: x,
                         letter_case=lambda x: x,
                         mm_field=lambda x: x,
                         exclude=lambda x: x).encoder is not None
    assert FieldOverride(encoder=lambda x: x,
                         letter_case=lambda x: x,
                         mm_field=lambda x: x,
                         exclude=lambda x: x).letter_case is not None
    assert FieldOverride(encoder=lambda x: x,
                         letter_case=lambda x: x,
                         mm_field=lambda x: x,
                         exclude=lambda x: x).mm_field is not None

# Generated at 2022-06-21 11:27:07.091158
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime(2019, 4, 1, 21, 15, 0, 0, tzinfo=timezone.utc)) == 1554137700.0

# Generated at 2022-06-21 11:27:40.333713
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()

# Generated at 2022-06-21 11:27:43.002142
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default({"a": "b"}) == {"a": "b"}


# Generated at 2022-06-21 11:27:44.818693
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(None, None, None, None) is not None

# Generated at 2022-06-21 11:27:56.393537
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    from dataclasses_json.config import _default_encode_json_type
    from dataclasses_json.config import _default_encode_kwargs
    o = FieldOverride(None, None, None, None, None)
    assert o.letter_case == _default_encode_json_type
    assert o.exclude == _default_encode_kwargs
    assert o.encoder == _default_encode_kwargs
    assert o.decoder == _default_encode_kwargs
    assert o.mm_fields == _default_encode_kwargs
    assert o == FieldOverride(None, None, None, None, None)
    assert not (o != FieldOverride(None, None, None, None, None))
    assert o != FieldOverride(None, lambda x: x, None, None, None)
   

# Generated at 2022-06-21 11:28:04.029587
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(
        exclude=lambda x: True,
        letter_case=lambda x: x.lower(),
        encoder=lambda x: x + 1,
        decoder=lambda x: x / 2,
    )
    assert field_override.exclude('not a number')
    assert field_override.letter_case('ABcd') == 'abcd'
    assert field_override.encoder(1) == 2
    assert field_override.decoder(2) == 1


# Generated at 2022-06-21 11:28:15.539461
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.0) == 1.0
    assert _ExtendedEncoder().default('1') == '1'
    assert _ExtendedEncoder().default([1]) == [1]
    assert _ExtendedEncoder().default({'1': 2}) == {'1': 2}
    assert _ExtendedEncoder().default(timezone.utc) == 0
    assert _ExtendedEncoder().default(datetime(2005, 1, 1)) == 1104537600.0

# Generated at 2022-06-21 11:28:26.194666
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Case 1: No letter_case, exclude and encoder is provided
    result = FieldOverride.__new__(FieldOverride)
    assert(result.letter_case == None)
    assert(result.exclude == None)
    assert(result.encoder == None)
    assert(result.decoder == None)

    # Case 2: letter_case, exclude and encoder is provided
    result = FieldOverride(letter_case, exclude, encoder, decoder)
    assert(result.letter_case == letter_case)
    assert(result.exclude == exclude)
    assert(result.encoder == encoder)
    assert(result.decoder == decoder)

    # Case 3: letter_case, exclude and encoder is not provided
    result = FieldOverride()
    assert(result.letter_case == None)

# Generated at 2022-06-21 11:28:33.372298
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():  # noqa
    encoder = _ExtendedEncoder()
    assert encoder.default(list()) == []
    assert encoder.default(dict()) == {}
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('f47ac10b-58cc-4372-a567-0e02b2c3d479')) == 'f47ac10b-58cc-4372-a567-0e02b2c3d479'
    assert encoder.default(Decimal('1')) == '1'
    assert encoder.default('a') == 'a'
    assert isinstance(encoder.default(None), type(None))

# Generated at 2022-06-21 11:28:42.412618
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = json.dumps(
        [{'a': 'a', 'b': 'b'}, 1],
        cls=_ExtendedEncoder,
        # sort_keys=True,
        # ensure_ascii=False,
        indent=2
    )
    assert o == '[\n' \
                '  {\n' \
                '    "a": "a",\n' \
                '    "b": "b"\n' \
                '  },\n' \
                '  1\n' \
                ']'
test__ExtendedEncoder_default()



# Generated at 2022-06-21 11:28:52.177278
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = _ExtendedEncoder().default(datetime.now(timezone.utc))
    assert isinstance(o, float)
    o = _ExtendedEncoder().default(UUID('911312bf-844e-413f-b715-27b507cee8f2'))
    assert isinstance(o, str)
    o = _ExtendedEncoder().default({'a': 1})
    assert isinstance(o, dict)
    assert o == {'a': 1}
    o = _ExtendedEncoder().default([1, 2])
    assert isinstance(o, list)
    assert o == [1, 2]
    o = _ExtendedEncoder().default(Decimal('1'))
    assert isinstance(o, str)
    assert o == '1'

# Generated at 2022-06-21 11:29:37.603784
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f_o = FieldOverride(exclude=None,
                        letter_case=None,
                        encoder=None,
                        decoder=None)
    assert f_o.exclude is None
    assert f_o.letter_case is None
    assert f_o.encoder is None
    assert f_o.decoder is None



# Generated at 2022-06-21 11:29:43.965107
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    t = type('FieldOverrideTest', (object,), {'__annotations__':{"a": str}})
    assert fields(t)
    assert fields(t)[0].__class__.__name__ == 'Field'
    f = fields(t)[0]
    override = FieldOverride(exclude=lambda v: False,
                             encoder=None,
                             decoder=None,
                             letter_case=str.capitalize,
                             mm_field=None)
    assert override.exclude(1) is False
    assert override.encoder is None
    assert override.decoder is None
    assert override.letter_case(f.name) == 'A'
    assert override.mm_field is None

# Generated at 2022-06-21 11:29:46.669621
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now(tz=timezone.utc))


# noinspection PyProtectedMember

# Generated at 2022-06-21 11:29:57.818510
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    def try_assert(obj, assert_obj):
        assert json.dumps(obj, cls=_ExtendedEncoder) == \
            json.dumps(assert_obj, cls=_ExtendedEncoder)
    try_assert([1, 2, 3], '[1, 2, 3]')
    try_assert({'abc': 123, 'd': [4, 5, 6]}, '{"abc": 123, "d": [4, 5, 6]}')
    from datetime import datetime
    now = datetime.now(timezone.utc)
    try_assert(now, str(now.timestamp()))
    from uuid import uuid4
    try_assert(uuid4(), str(uuid4()))
    from enum import Enum
    class E(Enum):
        A = 1
       

# Generated at 2022-06-21 11:29:59.463079
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder()


# noinspection PyBroadException

# Generated at 2022-06-21 11:30:04.695381
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test initializer
    assert FieldOverride(exclude=True,
                         letter_case=str.lower,
                         encoder=str,
                         decoder=str)

    # test _replace
    assert (FieldOverride(exclude=True,
                          letter_case=str.lower,
                          encoder=str,
                          decoder=str)._replace(letter_case=str.upper))
    assert (FieldOverride(exclude=True,
                          letter_case=str.lower,
                          encoder=str,
                          decoder=str)._replace(exclude=False))
    assert (FieldOverride(exclude=True,
                          letter_case=str.lower,
                          encoder=str,
                          decoder=str)._replace(encoder=int))

# Generated at 2022-06-21 11:30:14.595298
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from dataclasses import dataclass
    from decimal import Decimal
    from datetime import datetime
    from uuid import UUID

    @dataclass
    class Foo:
        id: int
        name: str
    foo = Foo(id=1, name="foo")
    assert _ExtendedEncoder().default(foo) == {'id': 1, 'name': 'foo'}

    class Bar:
        def __init__(self, id, name):
            self.id = id
            self.name = name

    bar = Bar(1, "bar")
    assert _ExtendedEncoder().default(bar) == {'id': 1, 'name': 'bar'}

    assert _ExtendedEncoder().default(datetime.now(tz=timezone.utc)) == 1584671353.708541



# Generated at 2022-06-21 11:30:18.869704
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(TypeError):
        FieldOverride()
    assert FieldOverride(exclude=lambda x: True,
                         encoder=lambda x: x,
                         decoder=lambda x: x,
                         letter_case=lambda x: x) is not None


# Generated at 2022-06-21 11:30:28.931297
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(exclude=None, letter_case=None, encoder=None,
                         decoder=None)
    assert FieldOverride(exclude=None, letter_case=None, encoder=None,
                         decoder=lambda x: x)
    assert FieldOverride(exclude=None, letter_case=None, encoder=lambda x: x,
                         decoder=lambda x: x)
    assert FieldOverride(exclude=lambda x: x is None, letter_case=None,
                         encoder=lambda x: x, decoder=lambda x: x)
    assert FieldOverride(exclude=lambda x: x is None, letter_case=None,
                         encoder=None, decoder=lambda x: x)

# Generated at 2022-06-21 11:30:35.570380
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1: 2}) == '{"1": 2}'
    assert _ExtendedEncoder().encode([1, 2]) == '[1, 2]'
    assert _ExtendedEncoder().encode(set([1, 2])) == '[1, 2]'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(Decimal('2.3')) == '"2.3"'
    assert _ExtendedEncoder().encode(datetime(2020, 6, 30, tzinfo=timezone.utc)) == '1593524800.0'
    assert _ExtendedEncoder().encode(datetime(2020, 6, 30)) == '1593524800.0'

# Generated at 2022-06-21 11:32:23.365879
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps(None, cls=_ExtendedEncoder) == 'null'
    assert json.dumps(True, cls=_ExtendedEncoder) == 'true'
    assert json.dumps(False, cls=_ExtendedEncoder) == 'false'
    assert json.dumps(1, cls=_ExtendedEncoder) == '1'
    assert json.dumps(1234567890, cls=_ExtendedEncoder) == '1234567890'
    assert json.dumps(1234567890.1, cls=_ExtendedEncoder) == '1234567890.1'
    assert json.dumps('abc', cls=_ExtendedEncoder) == '"abc"'

# Generated at 2022-06-21 11:32:27.782314
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result: Json = _ExtendedEncoder().default(UUID('55b2a5b5-5382-47f0-be1b-a5f6cc8f2c84'))
    assert result == '55b2a5b5-5382-47f0-be1b-a5f6cc8f2c84'



# Generated at 2022-06-21 11:32:39.078409
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime(2020, 1, 2, 3, 4, 5)) == 1577968245.0
    assert encoder.default(UUID('3fac8efc-095e-41d2-992e-f623e55b958f')) == '3fac8efc-095e-41d2-992e-f623e55b958f'

# Generated at 2022-06-21 11:32:50.866091
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Check default values of constructor
    f = FieldOverride()
    assert f.exclude is None
    assert f.letter_case is None
    assert f.encoder is None
    assert f.decoder is None

    # Check keyword arguments are assigned to fields
    exclude = lambda x: False
    letter_case = lambda x: x
    encoder = "some encoder"
    decoder = "some decoder"
    f = FieldOverride(exclude=exclude, letter_case=letter_case,
                      encoder=encoder, decoder=decoder)
    assert f.exclude is exclude
    assert f.letter_case is letter_case
    assert f.encoder is encoder
    assert f.decoder is decoder

    # Check positional arguments are assigned to fields

# Generated at 2022-06-21 11:32:58.492044
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ec = _ExtendedEncoder()
    assert ec.default(1) == 1
    assert ec.default('a') == 'a'
    assert ec.default(1.0) == 1.0
    assert ec.default(None) is None
    assert ec.default(True) is True
    assert ec.default(False) is False
    assert ec.default({'a': 1}) == {'a': 1}
    assert ec.default([1, 2]) == [1, 2]
    assert ec.default(datetime(2017, 1, 1)) == 1483228800.0
    assert ec.default(datetime(2017, 1, 1, tzinfo=timezone.utc)) == 1483228800.0

# Generated at 2022-06-21 11:33:08.608204
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(1) == FieldOverride(1)
    assert FieldOverride(1, letter_case=None) == FieldOverride(1, letter_case=None)
    assert FieldOverride(1, letter_case=lambda x: x.upper()) == FieldOverride(1, letter_case=lambda x: x.upper())
    assert FieldOverride(1, letter_case=lambda x: x.upper()) != FieldOverride(1, letter_case=lambda x: x.lower())
    assert FieldOverride(1, exclude=None) == FieldOverride(1, exclude=None)
    assert FieldOverride(1, exclude=lambda x: x == 5) == FieldOverride(1, exclude=lambda x: x == 5)
    assert FieldOverride(1, exclude=lambda x: x == 5) != FieldOverride(1, exclude=lambda x: x == 4)
   

# Generated at 2022-06-21 11:33:18.328603
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """
    Unit testing for default method of class _ExtendedEncoder,
    testing for different types of information:
    1. datetime
    2. dictionary
    3. union type
    4. enum
    5. Decimal
    :return:
    """
    _ExtendedEncoder().default(datetime(2020, 12, 15, 12, 20)) == 1607940800.0 == \
    _ExtendedEncoder().default(datetime(2020, 12, 15, 12, 20, tzinfo=timezone.utc))
    # Dict will be return as same as input
    _ExtendedEncoder().default({'a': 1}) == {'a': 1}
    # list will be return as same as input
    _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    #

# Generated at 2022-06-21 11:33:21.021950
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(None, None, None)
    assert (f.exclude, f.encoder, f.decoder, f.mm_field,
            f.letter_case) == (None, None, None, None, None)


# Generated at 2022-06-21 11:33:31.941096
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(**{
        'letter_case': lambda k: k,
        'encoder': lambda v: v,
        'decoder': lambda v: v,
        'exclude': lambda v: True,
    })
    assert field_override.letter_case is not None
    assert field_override.encoder is not None
    assert field_override.decoder is not None
    assert field_override.exclude is not None
    field_override = FieldOverride(**{'exclude': lambda v: True})
    assert field_override.letter_case is None
    assert field_override.encoder is None
    assert field_override.decoder is None
    assert field_override.exclude is not None
    field_override = FieldOverride(**{})

# Generated at 2022-06-21 11:33:35.381406
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    a = FieldOverride(exclude=None, letter_case=None, encoder=None)
    assert (a.exclude, a.letter_case, a.encoder) == (None, None, None)
