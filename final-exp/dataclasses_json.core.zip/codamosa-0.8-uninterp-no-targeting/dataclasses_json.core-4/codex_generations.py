

# Generated at 2022-06-21 11:24:29.255351
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    s = set([1, 2, 3])
    assert _ExtendedEncoder().encode(s) == "[1, 2, 3]"
    d = {"one": 1, "two": 2}
    assert _ExtendedEncoder().encode(d) == '{"one": 1, "two": 2}'
    l = [1, 2, 3]
    assert _ExtendedEncoder().encode(l) == "[1, 2, 3]"
    dt = datetime(2020, 1, 2, 3, 4, 5, 6, timezone.utc)
    assert _ExtendedEncoder().encode(dt) == "1577948245.000006"
    uid = UUID("a4f4a4e4-3c56-4d3b-acd5-8e48566c9f1d")

# Generated at 2022-06-21 11:24:39.387904
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # 1. Only 'exclude' field
    f1 = FieldOverride(exclude=lambda v: v is None)

    assert f1.exclude(None) == True
    assert f1.exclude(1) == False
    assert f1.letter_case is None
    assert f1.encoder is None
    assert f1.decoder is None
    assert f1.mm_fields is None

    # 2. Only 'letter_case' field
    f2 = FieldOverride(letter_case=lambda s: s.upper())

    assert f2.letter_case('abcde') == 'ABCDE'
    assert f2.exclude is None
    assert f2.encoder is None
    assert f2.decoder is None
    assert f2.mm_fields is None


# Generated at 2022-06-21 11:24:41.474166
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(exclude=None, encoder=None, decoder=None,
                         letter_case=None) is not None



# Generated at 2022-06-21 11:24:49.787909
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    e = encoder.default(datetime.now())
    assert isinstance(e, int)
    d = datetime.now(timezone.utc)
    e = encoder.default(d)
    assert isinstance(e, int)
    e = encoder.default(UUID('00000000-0000-0000-0000-000000000000'))
    assert isinstance(e, str)
    assert e == '00000000-0000-0000-0000-000000000000'
    e = encoder.default(Decimal('1.23'))
    assert isinstance(e, str)
    assert e == '1.23'

    class NewType:
        def __init__(self, data):
            self._data = data


# Generated at 2022-06-21 11:24:55.613183
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class MyClass:
        def __init__(self, x, y):
            self.x = x
            self.y = y

    f = FieldOverride(letter_case=upper, exclude=lambda x: x % 2 == 0)
    assert f.letter_case is upper
    assert f.exclude(1) is False
    assert f.exclude(2)
    assert f.exclude(MyClass) is False


# Generated at 2022-06-21 11:25:03.765878
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    conf = 'exclude'
    pred = lambda x: True
    letter_case = 'lower'
    encoder = lambda x: x
    decoder = lambda x: x
    mm_field = lambda x: x
    fo = FieldOverride(conf, pred, letter_case,
                       encoder, decoder, mm_field)
    assert fo.exclude(None)
    assert fo.letter_case('FOO') == 'foo'
    assert fo.encoder('foo') == 'foo'
    assert fo.decoder('Foo') == 'Foo'

# Generated at 2022-06-21 11:25:13.841952
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Test dataclass_json.FieldOverride class
    """
    # test constructor
    fo = FieldOverride(exclude=lambda x: True, letter_case=lambda x: x)
    assert fo.exclude is not None
    assert fo.letter_case is not None
    assert fo.mm_field is None
    fo = FieldOverride(mm_field=lambda x: x)
    assert fo.mm_field is not None
    # test has_encoder/decoder/exclude predicate
    fo = FieldOverride(encoder=lambda x: x, exclude=lambda x: x)
    assert fo.has_encoder()
    assert fo.has_exclude()
    fo = FieldOverride(encoder=None, exclude=None)
    assert not fo.has_encoder()
    assert not fo.has_exclude()

# Generated at 2022-06-21 11:25:23.860863
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda x: x
    decoder = lambda x: x
    exclude = lambda x: x
    assert FieldOverride(encoder=encoder, decoder=decoder,
                         exclude=exclude, letter_case='snake') == \
        FieldOverride(encoder, decoder, exclude, 'snake')
    assert FieldOverride(encoder=encoder, decoder=decoder, letter_case=None) == \
        FieldOverride(encoder, decoder, None, None)
    assert FieldOverride(encoder, None, None, None) == \
        FieldOverride(encoder, None, None, None)
    assert FieldOverride(encoder, None, None, None) == \
        FieldOverride(encoder=encoder, letter_case=None)

# Generated at 2022-06-21 11:25:32.105135
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode({1: 'a'}) == '{"1": "a"}'
    assert _ExtendedEncoder().encode([1]) == '[1]'
    assert _ExtendedEncoder().encode({'a': [1]}) == '{"a": [1]}'
    assert _ExtendedEncoder().encode({'a': [1], 'b': ['1']}) == '{"a": [1], "b": ["1"]}'
    assert _ExtendedEncoder().encode([1,2,3]) == '[1, 2, 3]'

# Generated at 2022-06-21 11:25:33.712002
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Type: (bool, Callable[[Any], Any], Callable[[str], str],
    # Callable[[Any], bool]) -> None

    FieldOverride(True, None, None, None)



# Generated at 2022-06-21 11:25:57.957751
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    o = dict(a=1)
    assert _ExtendedEncoder().default(o) is o


_ENCODERS: Mapping[type, Mapping[str, Any]] = {}  # type: ignore



# Generated at 2022-06-21 11:26:04.166086
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default({1: 2, 'a': 'b', 'x': [1, 2, 3]}) == {1: 2, 'a': 'b', 'x': [1, 2, 3]}
    assert encoder.default([1, 'a', {1: 2}]) == [1, 'a', {1: 2}]



# Generated at 2022-06-21 11:26:15.233335
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # Arrange
    e = _ExtendedEncoder()
    # Act
    r0 = e.default('s')
    r1 = e.default(['a', 'b', 'c'])
    r2 = e.default({'a': 1, 'b': 2, 'c': 3})
    r3 = e.default(datetime(2002, 10, 27, 6, 0, 0, 0, timezone.utc))
    r4 = e.default(UUID('12345678-1234-5678-1234-567812345678'))
    r5 = e.default(Decimal('2.3'))
    # Assert
    assert r0 == 's'
    assert r1 == ['a', 'b', 'c']

# Generated at 2022-06-21 11:26:18.853353
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Make sure FieldOverride can be constructed with 4 arguments.
    field_override = FieldOverride(True, True, None, None)
    assert(field_override.exclude is True)
    assert(field_override.letter_case is True)
    assert(field_override.encoder is None)
    assert(field_override.decoder is None)

# Generated at 2022-06-21 11:26:27.644104
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    obj_test = EnumTest(value=2)
    # noinspection PyProtectedMember
    assert obj_test._value_ == 2
    assert obj_test.value == 2
    assert obj_test.name == 'b'
    assert obj_test.value == obj_test.b
    assert obj_test.value == obj_test['b']
    assert obj_test.value == obj_test[1]
    assert _ExtendedEncoder().default(obj_test) == 2
    assert _ExtendedEncoder().default(obj_test) == obj_test.value
    assert _ExtendedEncoder().default(obj_test) == obj_test.b
    assert _ExtendedEncoder().default(obj_test) == obj_test['b']
    assert _ExtendedEncoder().default(obj_test) == obj_

# Generated at 2022-06-21 11:26:38.881118
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default(set([1, 2])) == [1, 2]
    assert enc.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    dt = datetime(2019, 3, 3, 16, 7, 42, 12345, timezone.utc)
    assert enc.default(dt) == 1551655462.12345
    assert enc.default(UUID("4e58dc24-fcb8-4d3b-a3d9-9fdcfb8db74f")) == \
        "4e58dc24-fcb8-4d3b-a3d9-9fdcfb8db74f"
    # noinspection PyProtectedMember
    assert enc.default(cfg._NONE)

# Generated at 2022-06-21 11:26:41.593639
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    a = _ExtendedEncoder().default(Decimal("3.14"))
    assert a == '3.14'



# Generated at 2022-06-21 11:26:43.530057
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(object()) == json.JSONEncoder().default(object())



# Generated at 2022-06-21 11:26:54.332983
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class Foo:
        pass

    # Create a FieldOverride object only with exclude parameter
    f1 = FieldOverride(exclude=lambda x: x == 'bar')

    # Create a FieldOverride object only with letter_case parameter
    f2 = FieldOverride(letter_case=str.lower)

    # Create a FieldOverride object only with encoder parameter
    f3 = FieldOverride(encoder=lambda x: x)

    # Create a FieldOverride object only with decoder parameter
    f4 = FieldOverride(decoder=lambda x: Foo())

    # Create a FieldOverride object with decoder and letter_case parameters
    f5 = FieldOverride(decoder=lambda x: x, letter_case=str.lower)
    assert (f1.decoder is None and f1.letter_case is None and
            f1.encoder is None)
   

# Generated at 2022-06-21 11:26:55.380213
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride() == FieldOverride()



# Generated at 2022-06-21 11:27:52.139088
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    x = _ExtendedEncoder()
    assert x.default('test') == 'test'
    assert x.default(1) == 1
    assert x.default(3.14) == 3.14
    assert x.default(True) == True
    assert x.default(False) == False
    assert x.default(None) == None
    assert x.default([1, 2, 3]) == [1, 2, 3]
    now = datetime.now()
    assert x.default(now) == now.timestamp()
    assert x.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    uuid_object = UUID('f47ac10b-58cc-4372-a567-0e02b2c3d479')

# Generated at 2022-06-21 11:28:03.915574
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json_encoder = _ExtendedEncoder()
    assert json_encoder.default(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert json_encoder.default({'a': '1', 'b': '2'}) == {'a': '1', 'b': '2'}
    assert json_encoder.default(Decimal('12.345')) == '12.345'
    assert (json_encoder.default(datetime(2018, 7, 24, 16, 14, 17, 511000,
                                          timezone.utc)) ==
            1532437557.511)

# Generated at 2022-06-21 11:28:06.470621
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride()
    assert f.exclude is None
    assert f.encoder is None
    assert f.decoder is None
    assert f.letter_case is None



# Generated at 2022-06-21 11:28:19.163821
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # empty
    f = FieldOverride()
    assert f.letter_case is None
    assert f.exclude is None
    assert f.encoder is None
    assert f.decoder is None

    # with types of letter_case, exclude, encoder, decoder
    f = FieldOverride(letter_case=str.upper, exclude=lambda x: x is None,
                      encoder=str, decoder=str)
    assert f.letter_case == str.upper
    assert f.exclude == (lambda x: x is None)
    assert f.encoder == str
    assert f.decoder == str

    # without types of letter_case, exclude, encoder, decoder
    f = FieldOverride(None, None, None, None)
    assert f.letter_case is None
    assert f.exclude is None
   

# Generated at 2022-06-21 11:28:21.349038
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'a': 'a'}) == '{"a": "a"}'
    now = datetime.now()
    assert _ExtendedEncoder().encode(now) == now.isoformat()
    assert _ExtendedEncoder().encode(Decimal('1')) == '1'


# Generated at 2022-06-21 11:28:30.674710
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

    assert encoder.default(UUID('6c4ed6d0-effe-4c5c-be1e-4ae4d4d8a3e2')) == '6c4ed6d0-effe-4c5c-be1e-4ae4d4d8a3e2'

# Generated at 2022-06-21 11:28:42.176046
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1, 2, 3}) == 'null'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode((1, 2, 3)) == 'null'
    assert _ExtendedEncoder().encode({1: '1', 2: '2', 3: '3'}) == '{"1": "1", "2": "2", "3": "3"}'
    assert _ExtendedEncoder().encode(datetime(2020, 2, 20, 10, 10, 10, 10, tzinfo=timezone.utc)) == '1582211010.000001'

# Generated at 2022-06-21 11:28:49.425826
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default([1]) == [1]
    assert _ExtendedEncoder().default(MappingProxyType({'a': 1})) == {'a': 1}
    assert _ExtendedEncoder().default(datetime(2019, 1, 1)) == 1546300800.0
    assert _ExtendedEncoder().default(UUID('9d4e106d-775b-4cbf-a43b-06f8fe8fde34')) == '9d4e106d-775b-4cbf-a43b-06f8fe8fde34'



# Generated at 2022-06-21 11:28:57.984219
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(set()) == list()
    assert _ExtendedEncoder().default(frozenset()) == list()
    assert _ExtendedEncoder().default(dict()) == dict()
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default(UUID('56efa7bc-12c5-4b4e-9a4a-d24c553f8a10')) == '56efa7bc-12c5-4b4e-9a4a-d24c553f8a10'
    assert _ExtendedEncoder().default(Enum('Foo', [('foo', 1)])) == 1
    assert _ExtendedEncoder().default(Decimal(1)) == '1'

# Generated at 2022-06-21 11:29:07.264652
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    o: Any
    o = [1, 2, 3]
    assert encoder.default(o) == o
    o = (1, 2, 3)
    assert encoder.default(o) == list(o)
    o = {1: 2, 3: 4}
    assert encoder.default(o) == dict(o)
    o = {1, 2, 3}
    assert encoder.default(o) == list(o)
    o = datetime.now()
    assert isinstance(encoder.default(o), (int, float))
    o = UUID('d6cb4f4e-3e3f-4d97-92a4-6b45f6bcdd29')
    assert encoder.default(o) == str(o)
   

# Generated at 2022-06-21 11:30:02.258723
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    d1 = datetime.now()
    d2 = datetime.now(timezone.utc)
    d3 = datetime.fromtimestamp(0)
    d4 = datetime.fromtimestamp(0, timezone.utc)
    def fn(_: Any) -> Json:
        raise TypeError(f'Object of type {type(_)} is not JSON serializable')
    encoder = _ExtendedEncoder(ensure_ascii=False, indent=2, sort_keys=True,
                               default=fn)
    json.dumps(d1, cls=encoder)
    json.dumps(d2, cls=encoder)
    json.dumps(d3, cls=encoder)
    json.dumps(d4, cls=encoder)
    uuid_v

# Generated at 2022-06-21 11:30:05.112694
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    override = FieldOverride(exclude=lambda x: True,
                             letter_case=str.lower,
                             encoder=str,
                             decoder=str,
                             mm_field=str)
    assert override.exclude is not None
    assert override.letter_case is not None
    assert override.encoder is not None
    assert override.decoder is not None
    assert override.mm_field is not None

# Generated at 2022-06-21 11:30:14.801980
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(1.1) == 1.1
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default([]) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default(datetime(2020, 7, 15, 12, 30, tzinfo=timezone.utc)) == 1594767400.0
    assert _ExtendedEncoder().default(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'
    assert _Extended

# Generated at 2022-06-21 11:30:23.786390
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test normal case
    f = FieldOverride(letter_case=camel_case, exclude=lambda x: x == "test")
    assert f.letter_case == camel_case
    assert f.exclude == (lambda x: x == "test")
    assert f.encoder is None
    assert f.mm_field is None
    assert f.decoder is None

    # test case with missing arguments
    f = FieldOverride(letter_case=camel_case)
    assert f.letter_case == camel_case
    assert f.exclude is None
    assert f.encoder is None
    assert f.mm_field is None
    assert f.decoder is None


# Generated at 2022-06-21 11:30:32.395139
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": "foo"}) == '{"a": "foo"}'
    assert _ExtendedEncoder().encode(["a", "foo"]) == '["a", "foo"]'
    assert _ExtendedEncoder().encode("a") == '"a"'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode(1.0) == '1.0'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode({"a": datetime.now(timezone.utc)}) == '{"a": %s}' % datetime.now(timezone.utc).tim

# Generated at 2022-06-21 11:30:41.230772
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # test_1
    o = 'foo'
    x = _ExtendedEncoder().default(o)
    assert x == '"foo"'

    # test_2
    o = 3.14
    x = _ExtendedEncoder().default(o)
    assert x == 3.14

    # test_3
    o = {'a': 3.14, 'b': 'foo'}
    x = _ExtendedEncoder().default(o)
    assert x == {'a': 3.14, 'b': 'foo'}

    # test_4
    o = [3.14, 'foo']
    x = _ExtendedEncoder().default(o)
    assert x == [3.14, 'foo']

    # test_5

# Generated at 2022-06-21 11:30:50.103355
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEncoder().default(1.2) == 1.2
    assert _ExtendedEncoder().default("abc") == "abc"
    assert _ExtendedEncoder().default([1,2,3]) == [1,2,3]
    assert _ExtendedEncoder().default({"a":"b"}) == {"a":"b"}
    assert _ExtendedEncoder().default(UUID("01234567-89ab-cdef-0123-456789abcdef")) == "01234567-89ab-cdef-0123-456789abcdef"

# Generated at 2022-06-21 11:30:58.895191
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    ee = _ExtendedEncoder()
    assert ee.default(datetime.now(timezone.utc)) == 1529976952.433009
    assert ee.default(UUID('3d3232b3-a6b3-4b54-8c96-14d920a57c28')) == '3d3232b3-a6b3-4b54-8c96-14d920a57c28'
    assert ee.default(Decimal('15.299769')) == '15.299769'
    assert ee.default(set([1,2,3])) == [1,2,3]
    assert ee.default(tuple([1,2,3])) == [1,2,3]
    assert ee.default(dict(key=1))

# Generated at 2022-06-21 11:30:59.973275
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) > 0


# Generated at 2022-06-21 11:31:08.514079
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(42) == 42
    assert _ExtendedEncoder().default(["a", 1, None, True, {}]) == ['a', 1, None, True, {}]
    assert _ExtendedEncoder().default({"a": 3}) == {"a": 3}
    assert _ExtendedEncoder().default(datetime(1997, 8, 29, 22, 14, tzinfo=timezone.utc)) == 874924440.0
    assert _ExtendedEncoder().default(UUID("1e2f35d2-d9a2-4c66-8b8d-a1f7e1c12a38")) == "1e2f35d2-d9a2-4c66-8b8d-a1f7e1c12a38"
    assert _Extended

# Generated at 2022-06-21 11:32:18.681978
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == [1, 2, 3]
    assert encoder.default({1, 2, 3}) == [1, 2, 3]
    assert encoder.default({'1': 2, '2': 3, '3': 4}) == {'1': 2, '2': 3, '3': 4}
    assert encoder.default(UUID(int=0)) == '00000000-0000-0000-0000-000000000000'
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(1234567890) == 1234567890



# Generated at 2022-06-21 11:32:28.659693
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    the_encoder = _ExtendedEncoder()
    assert the_encoder.default([1, 2, 3]) == [1, 2, 3]
    assert the_encoder.default([1, 2, set()]) is None
    assert the_encoder.default([1, 2, "abc"]) == [1, 2, "abc"]
    assert the_encoder.default({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert the_encoder.default({'a': 1, 'b': 2, 'c': set()}) is None
    assert the_encoder.default({'a': 1, 'b': 2, 'c': "abc"}) == {'a': 1, 'b': 2, 'c': "abc"}
   

# Generated at 2022-06-21 11:32:34.479259
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import date, time, datetime
    from decimal import Decimal
    from uuid import UUID
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == list()
    assert encoder.default(frozenset()) == list()
    assert encoder.default(bytearray()) == list()
    assert encoder.default(range(0)) == list()
    assert encoder.default(dict()) == dict()
    assert encoder.default(date.today()) == datetime.fromordinal(date.today().toordinal()).timestamp()
    assert encoder.default(time()) == time().timestamp()
    assert encoder.default(datetime.utcnow()) == datetime.utcnow().timestamp()

# Generated at 2022-06-21 11:32:37.266371
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime(1970, 1, 1, 0, 0, 1,
                                               tzinfo=timezone.utc)) == 1.0



# Generated at 2022-06-21 11:32:48.794024
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    foo = FieldOverride()
    assert foo.exclude is None
    assert foo.encoder is None
    assert foo.decoder is None
    assert foo.letter_case is None

    # test user override
    foo = FieldOverride(exclude=lambda x: x.startswith('foo'),
                        encoder=lambda x: str(x) + 'foo', decoder=lambda x: x + 2,
                        letter_case=lambda x: x.upper())
    assert foo.exclude('foo1') == True
    assert foo.exclude('foo2') == True
    assert foo.exclude('bar') == False
    assert foo.encoder('foo') == 'foo' + 'foo'
    assert foo.decoder('bar') == 'bar' + 2
    assert foo.letter_case('bar') == 'bar'.upper()



# Generated at 2022-06-21 11:32:57.484211
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Test case 1:
    #   letter_case is None, exclude and encoder is None
    fo1 = FieldOverride(None, None, None)
    assert isinstance(fo1, FieldOverride)
    assert fo1.letter_case is None
    assert fo1.exclude is None
    assert fo1.encoder is None

    # Test case 2:
    #   letter_case is not None, exclude and encoder is None
    def letter_case(name):
        return name.upper()
    fo2 = FieldOverride(letter_case, None, None)
    assert isinstance(fo2, FieldOverride)
    assert fo2.letter_case is not None
    assert fo2.exclude is None
    assert fo2.encoder is None

    # Test case 3:
    #   letter_case is None, exclude is not

# Generated at 2022-06-21 11:33:07.045603
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode(set()) == '[]'
    assert _ExtendedEncoder().encode(frozenset()) == '[]'
    assert _ExtendedEncoder().encode(()) == '[]'
    assert _ExtendedEncoder().encode(13) == '13'
    assert _ExtendedEncoder().encode(datetime.now()) == '{}'
    assert _ExtendedEncoder().encode(timezone.utc) == '{}'

# Generated at 2022-06-21 11:33:17.163292
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    e = _ExtendedEncoder()

# Generated at 2022-06-21 11:33:23.899797
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_override = FieldOverride(encoder=lambda x: x, decoder=lambda x: x,
                                   exclusion_predicate=lambda x: False,
                                   change_case_to=lambda x: x)
    assert field_override.encoder(2)
    assert field_override.decoder(2)
    assert field_override.exclude(2) is False
    assert field_override.letter_case(2)

# Unit tests for function _user_overrides_or_exts
f1 = Field(name='f1', type=str, default='str',
           metadata={'dataclasses_json': {'encoder': lambda x: x}})

# Generated at 2022-06-21 11:33:26.873643
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    with pytest.raises(ValueError):
        FieldOverride(letter_case="lower", exclude=lambda x: x > 0)