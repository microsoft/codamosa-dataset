

# Generated at 2022-06-21 11:24:21.582614
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(None, None, None)
    assert f.exclude == None
    assert f.letter_case == None
    assert f.encoder == None
    assert f.decoder == None


# Generated at 2022-06-21 11:24:31.650023
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    """Test for ExtendedEncoder default method.
    """
    encoder = _ExtendedEncoder()
    for klass in [int, float, bool, str, tuple, None,
                  [int, float, bool, str, tuple, None],
                  {'a': 1, 'b': 2.0, 'c': True, 'd': None},
                  datetime(2019, 3, 3, tzinfo=timezone.utc)]:
        encoder.default(klass)
    for klass in [dict, list, set]:
        assert {'a': 1, 'b': 2.0, 'c': True, 'd': None} == encoder.default({'a': 1, 'b': 2.0, 'c': True, 'd': None})
        assert [1, 2.0, True, None] == encoder

# Generated at 2022-06-21 11:24:40.629547
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    con_1 = FieldOverride(exclude=lambda x: x == "", encoder=str)
    exp_1 = ("{'exclude': <function FieldOverride.__init__.<locals>."
             "<lambda> at 0x7f6af4b4a0d0>, 'encoder': <class 'str'>}")
    assert repr(con_1) == exp_1

    con_2 = FieldOverride(exclude=lambda x: x == "", encoder=str,
                          letter_case=to_camelcase)

# Generated at 2022-06-21 11:24:49.123462
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().encode({1, 2, 3}) == json.dumps({1, 2, 3})
    assert _ExtendedEncoder().encode(['a', 'b', 'c']) == json.dumps(['a', 'b', 'c'])
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2, 'c': 3}) == json.dumps({'a': 1, 'b': 2, 'c': 3})
    assert _ExtendedEncoder().encode(datetime(2019, 9, 1, tzinfo=timezone.utc)) == \
           json.dumps(1567296800.0)

# Generated at 2022-06-21 11:24:51.345916
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    o = FieldOverride(lambda x: x, exclude=lambda x: x < 2)
    assert o.letter_case(1) == 1
    assert o.exclude(1) == True



# Generated at 2022-06-21 11:24:57.279030
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test constructor with all None args
    test_override = FieldOverride(exclude=None,
                                  letter_case=None,
                                  encoder=None,
                                  decoder=None)
    # test constructor with all args
    test_override = FieldOverride(exclude=str,
                                  letter_case=str.upper,
                                  encoder=str,
                                  decoder=str)
    return test_override



# Generated at 2022-06-21 11:25:02.911490
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(exclude=lambda x: x > 10,
                      decoder=from_json,
                      encoder=to_json,
                      letter_case=to_snake_case)
    assert f.exclude(9) == False
    assert f.exclude(11) == True
    assert f.decoder == from_json
    assert f.encoder == to_json
    assert f.letter_case == to_snake_case
# End Unit test


# Generated at 2022-06-21 11:25:09.911082
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(0) == 0
    assert _ExtendedEncoder().default(0.0) == 0.0
    assert _ExtendedEncoder().default(True) is True
    assert _ExtendedEncoder().default(None) is None
    assert _ExtendedEncoder().default('str') == 'str'
    assert _ExtendedEncoder().default(b'str') == 'str'
    assert _ExtendedEncoder().default(b'\xff') == '\xff'
    assert _ExtendedEncoder().default(b'\xc3\xa9') == 'é'
    assert _ExtendedEncoder().default(['list']) == ['list']
    assert _ExtendedEncoder().default((1, 2)) == [1, 2]
    assert _ExtendedEncoder().default({'dict'})

# Generated at 2022-06-21 11:25:20.523357
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    @dataclass_json
    @dataclass
    class Student:
        name: str
        grade: int

    s = Student('Alice', 3)

    assert not FieldOverride.ttl.exclude(s)
    assert not FieldOverride.ttl.exclude(s.name)
    assert FieldOverride.ttl.exclude(s.grade)

    assert not FieldOverride.ttl.encoder(s)
    assert FieldOverride.ttl.encoder(s.name) == 'name'
    assert FieldOverride.ttl.encoder(s.grade) == None

    assert not FieldOverride.ttl.decoder(s)
    assert FieldOverride.ttl.decoder(s.name) == None
    assert FieldOverride.ttl.decoder(s.grade) == None


# Generated at 2022-06-21 11:25:24.834267
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo = FieldOverride(encoder=None, decoder=None,
                       letter_case=None, exclude=None, mm_field=None)
    assert fo.encoder is None
    assert fo.decoder is None
    assert fo.letter_case is None
    assert fo.exclude is None
    assert fo.mm_field is None


# Unit tests for function _user_overrides_or_exts

# Generated at 2022-06-21 11:25:52.641742
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    _extended_encoder = _ExtendedEncoder()
    assert _extended_encoder.default(set([1, 2, 3])) == [1, 2, 3]
    assert _extended_encoder.default(dict(a=1)) == {"a": 1}
    # datetime
    assert _extended_encoder.default(datetime.now(timezone.utc)) == (
        datetime.now(timezone.utc).timestamp()
    )
    # UUID
    assert _extended_encoder.default(UUID('12345678123456781234567812345678')) == "12345678-1234-5678-1234-567812345678"
    # Enum
    class MyEnum(Enum):
        A = 0
        B = 1

# Generated at 2022-06-21 11:26:02.398425
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == "[1, 2, 3]"
    assert _ExtendedEncoder().encode({1, 2, 3}) == "[1, 2, 3]"
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode(UUID('00010203-0405-0607-0809-0a0b0c0d0e0f')) == '"00010203-0405-0607-0809-0a0b0c0d0e0f"'

# Generated at 2022-06-21 11:26:09.708819
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f1 = FieldOverride(exclude=lambda x: x is None, encoder=str)
    f2 = FieldOverride(decoder=lambda y: y.strip('"'))
    assert f1.exclude is not None
    assert f1.encoder is not None
    assert f2.exclude is None
    assert f2.decoder is not None



# Generated at 2022-06-21 11:26:12.173444
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    x = json.dumps({'now': datetime.now()}, cls=_ExtendedEncoder)
    y = json.loads(x)
    assert y



# Generated at 2022-06-21 11:26:23.142128
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    # type: () -> None
    assert _ExtendedEncoder().default(set()) == list(set())
    assert _ExtendedEncoder().default(frozenset()) == list(frozenset())
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default(()) == []
    assert _ExtendedEncoder().default([]) == []
    assert (
        _ExtendedEncoder().default(datetime.now(tz=timezone.utc)) ==
        datetime.now(tz=timezone.utc).timestamp()
    )

# Generated at 2022-06-21 11:26:30.177525
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc_obj = _ExtendedEncoder()
    assert enc_obj.default([]) == []
    assert enc_obj.default({}) == {}
    assert enc_obj.default(datetime.now(tz=timezone.utc)) == datetime.now(tz=timezone.utc).timestamp()
    assert enc_obj.default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    assert enc_obj.default(Decimal('0.0')) == '0.0'
    assert enc_obj.default(Enum('EnumTest', {'x': 1})) == 1
    assert enc_obj.default("") == ""
    assert enc_obj.default(0) == 0



# Generated at 2022-06-21 11:26:38.353370
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride.__init__.__annotations__['exclude'].__args__[0] == Callable[[Any], bool]
    assert FieldOverride.__init__.__annotations__['decoder'].__args__[0] == Callable[[Any], Any]
    assert FieldOverride.__init__.__annotations__['encoder'].__args__[0] == Callable[[Any], Any]
    assert FieldOverride.__init__.__annotations__['letter_case'].__args__[0] == Callable[[str], str]

# Generated at 2022-06-21 11:26:43.761543
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    def func(x):
        return x
    field_override = FieldOverride(func, lambda x: False)
    assert field_override.exclude == func
    assert field_override.encoder == func
    assert field_override.decoder == func
    assert field_override.letter_case == func



# Generated at 2022-06-21 11:26:53.791590
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    e = _ExtendedEncoder()
    assert(e.default({'key': 'value'}) == {'key': 'value'})
    assert(e.default(['key', 'value']) == ['key', 'value'])
    assert(e.default(datetime.now(tz=timezone.utc)) == 1578205923.921903)
    assert(e.default(UUID('c9bf9e57-1685-4c89-bafb-ff5af830be8a')) == 'c9bf9e57-1685-4c89-bafb-ff5af830be8a')
    assert(e.default(Decimal('1.1')) == '1.1')



# Generated at 2022-06-21 11:27:03.759343
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    default_encoder = json.JSONEncoder().default
    _o = [datetime(1970, 1, 1, tzinfo=timezone.utc), {1: 2}, [3, 4], True, 9.99]

    o = copy.deepcopy(_o)
    result = _ExtendedEncoder().default(o)
    assert default_encoder(o) == result

    o = copy.deepcopy(_o)
    result = _ExtendedEncoder().default(o)
    assert default_encoder(o) == result

    o = copy.deepcopy(_o)
    result = _ExtendedEncoder().default(o)
    assert default_encoder(o) == result

    o = copy.deepcopy(_o)
    result = _ExtendedEncoder().default(o)

# Generated at 2022-06-21 11:27:38.783512
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    #Case where using 'encoder' argument, which is a callable
    def my_encoder(x):
        return str(x)

    encoder = my_encoder
    fo = FieldOverride(encoder=encoder)
    assert fo.encoder is encoder
    assert fo.decoder is None
    assert fo.exclude is None
    assert fo.letter_case is None

    #Case where using 'decoder' argument, which is a callable
    def my_decoder(y):
        return int(y)

    decoder = my_decoder

    fo = FieldOverride(decoder=decoder)
    assert fo.encoder is None
    assert fo.decoder is decoder
    assert fo.exclude is None
    assert fo.letter_case is None

    #Case where using 'exclude' argument,

# Generated at 2022-06-21 11:27:50.855594
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Maintainer note: if FieldOverride is refactored, the test
    should be rewritten accordingly.
    """
    # Test with no override
    field_override = FieldOverride(None, None, None, None)
    assert field_override.letter_case is None
    assert field_override.decoder is None
    assert field_override.encoder is None
    assert field_override.exclude is None

    # Test with override with various callables
    letter_case = str.lower
    decoder = lambda x: x
    encoder = lambda x: x
    exclude = lambda x: False

    field_override = FieldOverride(letter_case, decoder, encoder, exclude)
    assert field_override.letter_case is letter_case
    assert field_override.decoder is decoder


# Generated at 2022-06-21 11:27:59.548052
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    enc = lambda x: x
    dec = lambda x: x
    def lc(x):
        return x.lower()
    def ex(x):
        return x is not None

    override = FieldOverride(letter_case=lc,
                             encoder=enc,
                             decoder=dec,
                             exclude=ex,
                             mm_field=None)

    assert override.letter_case == lc
    assert override.encoder == enc
    assert override.decoder == dec
    assert override.exclude == ex
    assert override.mm_field is None


# Generated at 2022-06-21 11:28:08.391957
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    enc = _ExtendedEncoder()
    assert enc.default(datetime.now()) < 1500000000
    assert enc.default(UUID('5cc5e5a5-5ef8-4099-b231-944077aec7d9')) == '5cc5e5a5-5ef8-4099-b231-944077aec7d9'
    assert enc.default({'abc': 1}) == {'abc': 1}
    assert enc.default(['abc', 1]) == ['abc', 1]
    assert enc.default(100) == 100
    assert enc.default('abc') == 'abc'
    assert enc.default(False) is False
    assert enc.default(Decimal('1.2')) == '1.2'



# Generated at 2022-06-21 11:28:15.325935
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    pass

# class Codec(object):
#     def __init__(self):
#         self.encoder = _ExtendedEncoder

#     def dumps(self, o):
#         return json.dumps(o, cls=self.encoder)

#     def loads(self, s):
#         return json.loads(s)

# codec = Codec()



# Generated at 2022-06-21 11:28:21.581437
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert not FieldOverride().exclude
    assert FieldOverride(exclude=True).exclude

    assert FieldOverride().letter_case is None
    assert FieldOverride(letter_case=lambda x: x).letter_case('') == ''

    assert FieldOverride().encoder is None
    assert FieldOverride(encoder=lambda x: x).encoder('') == ''

    assert FieldOverride().decoder is None
    assert FieldOverride(decoder=lambda x: x).decoder('') == ''

# Generated at 2022-06-21 11:28:30.836592
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from uuid import UUID
    from enum import Enum
    import decimal
    class MyEnum(Enum):
        val = 1
    x = _ExtendedEncoder().default
    assert x(1) == 1
    assert x(False) is False
    assert x('1') == '1'
    assert x({1:2}) == {1:2}
    assert x([1,2]) == [1,2]
    assert x(set([1,2])) == [1,2]
    assert x(frozenset([1,2])) == [1,2]
    assert isinstance(x({1,2}), list)
    assert x(UUID('1'*32)) == '11111111111111111111111111111111'
    assert x(MyEnum.val) == 1 
    assert x

# Generated at 2022-06-21 11:28:34.365279
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fo1 = FieldOverride()
    fo2 = FieldOverride(exclude=bool, decoder=int, encoder=int)
    fo3 = FieldOverride(encoder=int)
    assert fo1.decoder is None
    assert fo1.encoder is None
    assert fo1.exclude is None
    assert fo2.decoder == int
    assert fo2.encoder == int
    assert fo2.exclude == bool
    assert fo3.decoder is None
    assert fo3.encoder == int
    assert fo3.exclude is None


# Generated at 2022-06-21 11:28:39.600559
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_config = {}
    field_config['exclude'] = lambda v: True
    field_config['letter_case'] = lambda s: s.upper()
    field_config['encoder'] = lambda v: 'encoded:'+v
    field_config['decoder'] = lambda v: 'decoded:'+v
    field_config['mm_field'] = lambda v: 'mm_field:'+v

    assert FieldOverride(*map(field_config.get, confs)) == FieldOverride(
        lambda v: True, lambda s: s.upper(),
        lambda v: 'encoded:'+v, lambda v: 'decoded:'+v, lambda v: 'mm_field:'+v
    )

# Generated at 2022-06-21 11:28:49.042241
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.loads(json.dumps(1, cls=_ExtendedEncoder)) == 1
    assert json.loads(json.dumps('test', cls=_ExtendedEncoder)) == 'test'
    assert json.loads(json.dumps(1.5, cls=_ExtendedEncoder)) == 1.5
    assert json.loads(json.dumps(True, cls=_ExtendedEncoder)) is True
    assert json.loads(json.dumps(False, cls=_ExtendedEncoder)) is False
    assert json.loads(json.dumps(None, cls=_ExtendedEncoder)) is None

# Generated at 2022-06-21 11:29:36.229235
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Case 1: only exclude
    exclude = lambda v: v == "fake"
    field_override = FieldOverride(exclude=exclude)
    assert field_override.exclude == exclude
    assert field_override.encoder is None
    assert field_override.decoder is None
    assert field_override.letter_case is None

    # Case 2: only encoder
    encoder = lambda v: v * 2
    field_override = FieldOverride(encoder=encoder)
    assert field_override.encoder == encoder
    assert field_override.exclude is None
    assert field_override.decoder is None
    assert field_override.letter_case is None

    # Case 3: only decoder
    decoder = lambda v: v * 2
    field_override = FieldOverride

# Generated at 2022-06-21 11:29:43.140261
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    import json

    assert FieldOverride._fields == ('letter_case', 'exclude',
                                     'encoder', 'decoder')

    @dataclass_json
    @dataclass
    class Struct:
        xyz: int = 1

    def decoder(value):
        decoded = json.loads(value)
        return Struct(**decoder)

    def encoder(value):
        encoded = json.dumps(_asdict(value))
        return encoded

    s = Struct(xyz=2)
    f = FieldOverride(letter_case='lower', exclude=lambda x: x == 1,
                      encoder=encoder, decoder=decoder)
    assert f.letter_case == 'lower'
    assert f.exclude(1) is True
    assert f.exclude(2) is False
    assert f

# Generated at 2022-06-21 11:29:48.416655
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f = FieldOverride(decoder=int, encoder=int, letter_case=camelcase)
    assert Hashable(f)
    assert Representable(f)
    assert f.encoder == int
    assert f.decoder == int
    assert f.letter_case == camelcase
    override = FieldOverride(exclude=lambda v: v == 0,
                             decoder=int,
                             encoder=int,
                             letter_case=camelcase)
    assert override.exclude == (lambda v: v == 0)
    assert override.decoder == int
    assert override.encoder == int
    assert override.letter_case == camelcase



# Generated at 2022-06-21 11:29:59.964521
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(set()) == []
    assert encoder.default(frozenset()) == []
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime.fromtimestamp(100, timezone.utc)) == 100
    assert encoder.default(UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8')) == '6ba7b810-9dad-11d1-80b4-00c04fd430c8'
    assert encoder.default(Decimal('3.14')) == '3.14'

# Generated at 2022-06-21 11:30:04.979033
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    test_ExtendedEncoder_ = _ExtendedEncoder().encode( {'a': [1,2,3]} )
    assert test_ExtendedEncoder_ == '{"a": [1, 2, 3]}'
    print ('test__ExtendedEncoder() passed')

test__ExtendedEncoder()


# Generated at 2022-06-21 11:30:10.870674
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    out = _ExtendedEncoder()
    assert out.encode(['a', 'b']) == '["a", "b"]'
    assert out.encode({'a': 'b'}) == '{"a": "b"}'
    assert out.encode(UUID('e8b2276d-f3da-4399-9baf-c8f0aaf7c0d3')) == '"e8b2276d-f3da-4399-9baf-c8f0aaf7c0d3"'
    assert out.encode(datetime.now(timezone.utc)) == '{:.18f}'.format(datetime.now(timezone.utc).timestamp())
    assert out.encode(Decimal('1.5')) == '"1.5"'

# Generated at 2022-06-21 11:30:21.292243
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(set()) == []
    assert _ExtendedEncoder().default(tuple()) == []
    assert _ExtendedEncoder().default(frozenset()) == []
    assert _ExtendedEncoder().default(bytearray()) == []
    assert _ExtendedEncoder().default({}) == {}
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert type(_ExtendedEncoder().default(datetime.now())) is float
    assert _ExtendedEncoder().default(UUID('12345678123456781234567812345678')) == \
        '12345678-1234-5678-1234-567812345678'
    assert _ExtendedEncoder().default(1) == 1
    assert _ExtendedEnc

# Generated at 2022-06-21 11:30:30.793220
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    field_name = "name"
    field_override = FieldOverride(encoder=None, decoder=None, exclude=None,
                                   letter_case=None, mm_field=None)
    assert field_override.encoder is None
    assert field_override.decoder is None
    assert field_override.mm_field is None
    assert field_override.exclude is None
    assert field_override.letter_case is None
    assert field_override.mm_field is None
    assert field_override.encoder is None
    assert field_override.decoder is None
    assert field_override.mm_field is None
    assert field_override.exclude is None
    assert field_override.letter_case is None
    assert field_override.mm_field is None




# Generated at 2022-06-21 11:30:40.386840
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps([datetime.now()], cls=_ExtendedEncoder)
    assert json.dumps({datetime.now(): datetime.now()}, cls=_ExtendedEncoder)
    assert json.dumps(Enum('Enum', {'A': 3}).A, cls=_ExtendedEncoder)
    assert json.dumps(UUID('96f0a9a9-c62b-4a0a-8e5e-ca86b89c5b33'), cls=_ExtendedEncoder)
    assert json.dumps(Decimal('1.0'), cls=_ExtendedEncoder)
    assert json.dumps('string', cls=_ExtendedEncoder)
    assert json.dumps(1, cls=_ExtendedEncoder)
    assert json

# Generated at 2022-06-21 11:30:49.301081
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    """
    Tests that the FieldOverride constructor initializes the expected fields.
    """
    field_name = 'test_field'
    config = {
        'exclude': lambda v: False,
        'letter_case': None,
        'encoder': lambda v: v,
        'decoder': lambda v: v,
    }
    field_override = FieldOverride(**config)
    assert field_override.__getattribute__('exclude') == config['exclude']
    assert field_override.__getattribute__('letter_case') == \
        config['letter_case']
    assert field_override.__getattribute__('encoder') == config['encoder']
    assert field_override.__getattribute__('decoder') == config['decoder']

# Generated at 2022-06-21 11:32:28.950163
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    def some_encoder(x: Any) -> Dict:
        return {x: "some_encoder"}

    def some_decoder(x: Dict) -> Any:
        return x

    def some_exclude(x: Any) -> bool:
        return x == "exclude"

    f_override = FieldOverride(
        letter_case=lambda x: x.lower(),
        encoder=some_encoder,
        decoder=some_decoder,
        exclude=some_exclude)

    assert f_override.letter_case("ABC") == "abc"
    assert f_override.encoder("a") == {"a": "some_encoder"}
    assert f_override.decoder({"b": "some_encoder"}).keys() == {"b"}

# Generated at 2022-06-21 11:32:37.126624
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(set('foo')) == ['f', 'o']
    assert _ExtendedEncoder().default({'x': 'y'}) == {'x': 'y'}
    assert _ExtendedEncoder().default(datetime.now()) == \
        datetime.now().timestamp()
    assert _ExtendedEncoder().default(Enum) == Enum.value
    assert _ExtendedEncoder().default(UUID('myUUID')) == 'myUUID'



# Generated at 2022-06-21 11:32:48.605878
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    obj = _ExtendedEncoder().default
    assert obj(1) == 1
    assert obj('str') == 'str'
    assert obj(Json) == json.JSONEncoder().default(Json)
    assert obj(set(['a', 'b'])) == ['b', 'a']
    assert obj(frozenset(['a', 'b'])) == ['b', 'a']
    assert obj({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert obj(('a', 'b')) == ['a', 'b']
    assert obj([1, 2, 3]) == [1, 2, 3]
    assert obj(slice(1, 2)) == 'slice'
    assert obj(range(1, 2)) == 'range'
    assert obj(dict) == 'dict'
   

# Generated at 2022-06-21 11:32:57.321245
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([]) == "[]"
    assert _ExtendedEncoder().encode({}) == "{}"
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode(datetime.now()) == json.dumps(datetime.now().timestamp())
    assert _ExtendedEncoder().encode(UUID('c650060b-8da1-4a1a-ae34-05d8ebad61e7')) == '"c650060b-8da1-4a1a-ae34-05d8ebad61e7"'
    assert _ExtendedEncoder().encode(Enum) == json.dumps(Enum.value)

# Generated at 2022-06-21 11:33:07.044000
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def _t(o, expected):
        assert _ExtendedEncoder().default(o) == expected
    _t([], [])
    _t((), [])
    _t({}, {})
    _t({1: 2, 3: 4}, {1: 2, 3: 4})
    _t({1, 2, 3}, [1, 2, 3])
    _t(set(), [])
    _t(frozenset(), [])
    _t(datetime(2017, 1, 1, 12, 0, 1), 1483220401.0)
    _t(datetime(2017, 1, 1, 12, 0, 1, tzinfo=timezone.utc), 1483220401.0)

# Generated at 2022-06-21 11:33:17.202535
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # if all the arguments are omitted
    assert FieldOverride() == FieldOverride(None, None, None)

    # if "exclude" is the first argument and the rest of them are omitted
    exclude_fn = lambda x: True
    assert FieldOverride(exclude=exclude_fn) == FieldOverride(exclude_fn, None, None)

    # if "letter_case" is the first argument and the rest of them are omitted
    letter_case_fn = lambda x: x.lower()
    assert FieldOverride(letter_case=letter_case_fn) == FieldOverride(None, letter_case_fn, None)

    # if "encoder" is the first argument and the rest of them are omitted
    encoder_fn = lambda x: x

# Generated at 2022-06-21 11:33:20.709550
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoding = 0
    decoding = 1
    letter_case = "lower"
    exclude = True
    fo = FieldOverride(encoding, decoding, letter_case, exclude)
    assert fo.encoder == encoding
    assert fo.decoder == decoding
    assert fo.letter_case == letter_case
    assert fo.exclude == exclude

# Generated at 2022-06-21 11:33:23.257152
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(
        'AttrDict', None, None, None, None, None, 'camelcase').letter_case == \
           camelCase


# Generated at 2022-06-21 11:33:24.791313
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([]) == '[]'



# Generated at 2022-06-21 11:33:35.912233
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({datetime(2019, 3, 3, 12, 12, 12, tzinfo=timezone.utc): 'value'}) == '{"2019-03-03T12:12:12+00:00": "value"}'
    assert _ExtendedEncoder().encode({UUID('{12345678-1234-5678-1234-567812345678}'): 'value'}) == '{"12345678-1234-5678-1234-567812345678": "value"}'
    assert _ExtendedEncoder().encode({datetime(2019, 3, 3, 12, 12, 12): 'value'}) == '{"2019-03-03T12:12:12": "value"}'