

# Generated at 2022-06-21 11:24:23.464150
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps([1, "a"], cls=_ExtendedEncoder)
    json.dumps({'a': 2}, cls=_ExtendedEncoder)
    json.dumps(datetime.now(timezone.utc), cls=_ExtendedEncoder)
    json.dumps(UUID('{12345678-1234-5678-1234-567812345678}'), cls=_ExtendedEncoder)
    json.dumps(Decimal('123.45'), cls=_ExtendedEncoder)



# Generated at 2022-06-21 11:24:28.233833
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    constructor = FieldOverride("default", "exclude")
    assert constructor.decoder == "default"
    assert constructor.exclude == "exclude"
    assert constructor.encoder == "default"
    assert constructor.letter_case == None
    assert constructor.mm_field == "default"



# Generated at 2022-06-21 11:24:38.639587
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test without passing any arguments
    field_override = FieldOverride()
    assert field_override.exclude is None
    assert field_override.letter_case is None
    assert field_override.encoder is None
    assert field_override.decoder is None
    assert field_override.mm_field is None

    # test passing values to constructor
    field_override_2 = FieldOverride(lambda x: x,
                                     lambda x: x,
                                     lambda x: x,
                                     lambda x: x,
                                     lambda x: x)

    assert field_override_2.exclude(None) is None
    assert field_override_2.letter_case('name') == 'name'
    assert field_override_2.encoder('name') == 'name'
    assert field_override

# Generated at 2022-06-21 11:24:47.442520
# Unit test for constructor of class _ExtendedEncoder

# Generated at 2022-06-21 11:24:54.558550
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    def test_case(test_data: dict):
        decoded = {'foo': {'bar': 1, 'baz': 2}, 'qux': 123, 'zoo': 'koo'}
        encoded = _ExtendedEncoder().encode(decoded)
        assert json.dumps(test_data) == encoded

    test_case({'foo': [('bar', 1), ('baz', 2)], 'qux': 123, 'zoo': 'koo'})
    test_case({'foo': {'bar': 1, 'baz': 2}, 'qux': [1, 2, 3], 'zoo': 'koo'})
    test_case({'foo': [('bar', 1), ('baz', 2)], 'qux': [1, 2, 3], 'zoo': 'koo'})



# Generated at 2022-06-21 11:25:03.186689
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    d0 = FieldOverride(exclude=lambda x: x is None)
    d1 = FieldOverride(decoder=lambda x: UnvalidatedValue(x))
    d2 = FieldOverride()
    assert d0.exclude is not None
    assert d0.encoder is None
    assert d0.decoder is None
    assert d0.letter_case is None
    assert d1.exclude is None
    assert d1.encoder is None
    assert d1.decoder is not None
    assert d1.letter_case is None
    assert d2.exclude is None
    assert d2.encoder is None
    assert d2.decoder is None
    assert d2.letter_case is None



# Generated at 2022-06-21 11:25:13.022141
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # type: () -> None
    assert _ExtendedEncoder().encode(object=['a', 1, {'b': 'abcd'}, [False, [0.5]]]) == '["a", 1, {"b": "abcd"}, [false, [0.5]]]'
    assert _ExtendedEncoder().encode(object={'a': 1.1,
                                             'b': {'c': 2.2,
                                                   'd': 'abcd'},
                                             'e': [False, [0.5]]}) == '{"a": 1.1, "b": {"c": 2.2, "d": "abcd"}, "e": [false, [0.5]]}'

# Generated at 2022-06-21 11:25:23.282252
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    class TestEnum(Enum):
        E1 = 1
    decimal1 = Decimal('1.2')
    decimal2 = Decimal('1234')
    uuid1 = UUID('1F9B56C7-8E72-49D7-A6A2-6E8D6C3A9D40')
    uuid2 = UUID('1F9B56C7-8E72-49D7-A6A2-6E8D6C3A9D41')
    o = [uuid1, uuid2, decimal1, decimal2, TestEnum.E1]
    j = json.dumps(o, cls=_ExtendedEncoder)

# Generated at 2022-06-21 11:25:31.678269
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(True) == True
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default("1") == "1"
    assert encoder.default(None) == None
    assert encoder.default([1,2,3]) == [1,2,3]
    assert encoder.default([{'a': 1}, {'b': 2}]) == [{'a': 1}, {'b': 2}]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime(2018, 1, 1)) == 1514764800.0

# Generated at 2022-06-21 11:25:43.609075
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default({'a': 'b'}) == {'a': 'b'}
    assert _ExtendedEncoder().default({'a': 1}) == {'a': 1}
    assert _ExtendedEncoder().default({'a': 0.1}) == {'a': 0.1}
    assert _ExtendedEncoder().default({'a': True}) == {'a': True}
    assert _ExtendedEncoder().default({'a': None}) == {'a': None}
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default((1, 2, 3)) == [1, 2, 3]
    assert _ExtendedEncoder().default(set((1, 2, 3))) == [1, 2, 3]

# Generated at 2022-06-21 11:26:43.956109
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    expected_o = FieldOverride(exclude=lambda x: False,
                               encoder=None,
                               decoder=lambda x: x,
                               letter_case=lambda x: x,
                               mm_field=fields.Integer())
    o = FieldOverride(
        exclude=lambda x: False,
        encoder=None,
        decoder=lambda x: x,
        letter_case=lambda x: x,
        mm_field=fields.Integer()
    )
    assert o == expected_o
    assert o is not expected_o
    assert o.exclude is not expected_o.exclude
    assert o.encoder == expected_o.encoder
    assert o.decoder is not expected_o.decoder
    assert o.letter_case is not expected_o.letter_case
    assert o.mm

# Generated at 2022-06-21 11:26:49.593547
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    fname = 'test_field'
    encoder = 'encoder'
    decoder = 'decoder'
    letter_case = 'upper'
    fo = FieldOverride(exclude, encoder, decoder, letter_case, fname)
    assert fo.encoder == encoder
    assert fo.decoder == decoder
    assert fo.letter_case == letter_case

# Generated at 2022-06-21 11:26:58.384546
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2]) == [1, 2]
    assert encoder.default({1: 2}) == {1: 2}
    dt = datetime(2020, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    assert encoder.default(dt) == 1577836800.0
    uuid = UUID('87c8e927-b02e-42c2-afb8-62b3f3d1c881')
    assert encoder.default(uuid) == '87c8e927-b02e-42c2-afb8-62b3f3d1c881'
    assert encoder.default(Decimal('1.23')) == '1.23'



# Generated at 2022-06-21 11:27:09.519032
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    letters = 'nhvtj'
    initial_values = 3, 2.2, '5', (2, 6, 4), ['x', 'y', 'z']
    for letter_case in ['lower', 'upper', 'capitalize', None]:
        for e in [None, int, float, str]:
            for d in [None, int, float, str]:
                for f in [None, lambda x: x]:
                    for exclude in [None, lambda x: x]:
                        for inject in [None, lambda x: x]:
                            for i in range(len(letters)):
                                kwargs = {letters[j]: initial_values[j] for j
                                          in range(i)}

# Generated at 2022-06-21 11:27:11.479989
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    FieldOverride(letter_case=None, exclude=None, encoder=None, decoder=None)



# Generated at 2022-06-21 11:27:17.714681
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    attrs = {
        'exclude': None,
        'encoder': None,
        'decoder': None,
        'letter_case': None
    }
    f = FieldOverride(**attrs)
    assert f.exclude is attrs['exclude']
    assert f.encoder is attrs['encoder']
    assert f.decoder is attrs['decoder']
    assert f.letter_case is attrs['letter_case']

# Generated at 2022-06-21 11:27:24.429951
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.loads(json.dumps([1, 2, 3], cls=_ExtendedEncoder)) == [1, 2, 3]
    assert json.loads(json.dumps({"key": "value"}, cls=_ExtendedEncoder)) == {"key": "value"}
    assert json.loads(json.dumps("1", cls=_ExtendedEncoder)) == "1"
    assert json.loads(json.dumps(1, cls=_ExtendedEncoder)) == 1
    assert json.loads(json.dumps(1.0, cls=_ExtendedEncoder)) == 1.0
    assert json.loads(json.dumps(True, cls=_ExtendedEncoder)) == True
    assert json.loads(json.dumps(None, cls=_ExtendedEncoder)) == None

# Generated at 2022-06-21 11:27:36.613179
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # type: () -> None
    assert _ExtendedEncoder().encode({}) == '{}'
    assert _ExtendedEncoder().encode([]) == '[]'
    assert _ExtendedEncoder().encode({'key': 'value'}) == '{"key": "value"}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({'key1': 1, 'key2': [2, 3], 'key3': '4'}) == '{"key3": "4", "key1": 1, "key2": [2, 3]}'
    assert _ExtendedEncoder().encode(datetime(2018, 12, 18)) == '1545102800.0'

# Generated at 2022-06-21 11:27:44.324844
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1,2,3]) == [1,2,3]
    assert encoder.default({'k': 'v'}) == {'k': 'v'}
    assert encoder.default(datetime.now(tz=timezone.utc)) == 1582699318.0
    assert encoder.default(UUID('2f3b8cf9-e5c5-4a38-80ff-8c6f388541d4')) == '2f3b8cf9-e5c5-4a38-80ff-8c6f388541d4'
    assert encoder.default(Decimal('45')) == '45'



# Generated at 2022-06-21 11:27:56.044611
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    default_field_override = FieldOverride(exclude=None,
                                           letter_case=None,
                                           encoder=None,
                                           decoder=None)
    assert default_field_override.exclude is None
    assert default_field_override.letter_case is None
    assert default_field_override.encoder is None
    assert default_field_override.decoder is None

    exclude_callable = lambda x: True
    letter_case_callable = lambda x: x.lower()
    encoder_callable = lambda x: str(x)
    decoder_callable = lambda x: x


# Generated at 2022-06-21 11:28:33.021600
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    v = _ExtendedEncoder().default('12')
    assert v == '12'


# Generated at 2022-06-21 11:28:34.948235
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    opt = FieldOverride(letter_case=None, exclude=None,
                        encoder=None, decoder=None)
    assert opt.letter_case is None
    assert opt.encoder is None
    assert opt.decoder is None
    assert opt.exclude is None



# Generated at 2022-06-21 11:28:45.791402
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({1:2, 3:4}) == '{"1": 2, "3": 4}'
    assert _ExtendedEncoder().encode(datetime.fromtimestamp(1528394717.979)) == str(1528394717.979)
    assert _ExtendedEncoder().encode(UUID('123e4567-e89b-12d3-a456-426655440000')) == '123e4567-e89b-12d3-a456-426655440000'
    assert _ExtendedEncoder().encode(Decimal(0.5)) == '0.5'

# Generated at 2022-06-21 11:28:51.124524
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    from ledger.util import F
    # field encode/decoder functions
    def encoder(x):
        return x.replace('_', '-')
    def decoder(x):
        return x.replace('-', '_')

    # test exclude
    exclude = lambda name: name == "ex"
    # test letter_case
    letter_case = lambda x: x.capitalize()

    # test empty constructor
    fo = FieldOverride()
    assert fo.encoder is None
    assert fo.decoder is None
    assert fo.exclude is None
    assert fo.letter_case is None

    # test keyword constructor
    fo = FieldOverride(encoder=encoder, decoder=decoder,
                       exclude=exclude, letter_case=letter_case)
    assert fo.encoder is encoder

# Generated at 2022-06-21 11:28:53.398002
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    x = FieldOverride(exclude=None, encoder=lambda x: x,
                      decoder=lambda x: x, convert_case=lambda x: x)
    assert x.exclude is None
    assert x.encoder(1) == 1
    assert x.decoder(2) == 2
    assert x.letter_case("test") == "test"


# Generated at 2022-06-21 11:28:56.674707
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    test_input = {'encoder': 'encode',
    'decoder': 'decode',
    'exclude': 'exclude',
    'letter_case': 'case'}
    field_override = FieldOverride(**test_input)
    assert field_override.encoder == 'encode'
    assert field_override.decoder == 'decode'
    assert field_override.exclude == 'exclude'
    assert field_override.letter_case == 'case'

# Generated at 2022-06-21 11:29:05.828369
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # test exclude
    assert not FieldOverride(exclude=lambda x: x == 1).exclude(1)
    assert FieldOverride(exclude=lambda x: x > 0).exclude(0)
    assert not FieldOverride(exclude=lambda x: x > 0).exclude(-1)
    assert FieldOverride(exclude=lambda x: x == 1).exclude(2)

    # test letter_case
    assert FieldOverride(letter_case=lambda x: x.upper()).letter_case('lower') == 'LOWER'
    assert FieldOverride(letter_case=lambda x: x.lower()).letter_case('UPPER') == 'upper'

    # test encoder
    encoder = lambda x: x + 1
    assert FieldOverride(encoder=encoder).encoder(1) == 2

# Generated at 2022-06-21 11:29:13.608589
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime(2020, 11, 15, 16, 53, 12, tzinfo=timezone.utc)) == 1602836592.0
    assert _ExtendedEncoder().default(UUID("388c6f1a-8ad3-4b3f-bc32-dfd0d836f7c4")) == "388c6f1a-8ad3-4b3f-bc32-dfd0d836f7c4"
    assert _ExtendedEncoder().default(Decimal("1.2")) == "1.2"



# Generated at 2022-06-21 11:29:22.972888
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.encode(range(10)) == '{"__class__": "range", "__value__": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]}'
    assert encoder.encode({1, 2}) == '{"__class__": "set", "__value__": [1, 2]}'
    assert encoder.encode({1: 'a', 2: 'b'}) == '{1: "a", 2: "b"}'
    assert encoder.encode(datetime(2020, 1, 1)) == '1577880000.0'
    assert encoder.encode(Decimal('12.3')) == '"12.3"'

# Generated at 2022-06-21 11:29:30.083437
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import datetime
    from enum import Enum
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(datetime.now(timezone.utc)) == datetime.now(timezone.utc).timestamp()
    assert encoder.default(UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'
    class MyEnum(Enum):
        a = 1
        b = 2
    assert encoder.default(MyEnum.a) == 1



# Generated at 2022-06-21 11:30:50.251306
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({'key': {'subkey': 1}}) == '{"key": {"subkey": 1}}'
    assert _ExtendedEncoder().encode(dict(key=dict(subkey=1))) == '{"key": {"subkey": 1}}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode([1, 2, [3, 4]]) == '[1, 2, [3, 4]]'
    assert _ExtendedEncoder().encode(datetime.now(timezone.utc)) == str(datetime.now(timezone.utc).timestamp())

# Generated at 2022-06-21 11:30:58.218552
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    @dataclass
    class Test:
        test: str
    test = Test("test")

    enc = lambda x: len(x)
    dec = lambda x: "*" * x
    override = FieldOverride(exclude=lambda x: False,
                             letter_case=lambda x: x.upper(),
                             encoder=enc,
                             decoder=dec)
    assert not override.exclude(test.test)
    assert override.letter_case(test.test) == test.test.upper()
    assert override.encoder(test.test) == len(test.test)
    assert override.decoder(len(test.test)) == "*" * len(test.test)


# Generated at 2022-06-21 11:31:04.549796
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(UUID('3d3d2a1d-8e08-4b3f-88d2-14e0b824d933')) == '"3d3d2a1d-8e08-4b3f-88d2-14e0b824d933"'
    assert _ExtendedEncoder().encode({'a': 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode(datetime.fromtimestamp(1594523403.088858)) == '1594523403.088858'
    assert _ExtendedEncoder().encode(Decimal('1.0000')) == '"1.0000"'

# Generated at 2022-06-21 11:31:16.006814
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()

    json_data = encoder.default({'test': 123, 'test2': 234})
    assert isinstance(json_data, dict) and json_data == {'test': 123, 'test2': 234}

    json_data = encoder.default([1, 2, 3])
    assert isinstance(json_data, list) and json_data == [1, 2, 3]

    json_data = encoder.default(('1', 2, 3))
    assert isinstance(json_data, list) and json_data == ['1', 2, 3]

    json_data = encoder.default('12345')
    assert isinstance(json_data, str) and json_data == '12345'

    json_data = encoder.default(12345)

# Generated at 2022-06-21 11:31:25.627528
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({1, 2, 3}) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode(set([1, 2, 3])) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode({1: 'a', 2: 'b', 3: 'c'}) == '{"1": "a", "2": "b", "3": "c"}'
    assert _ExtendedEncoder().encode(datetime(2000, 1, 1, tzinfo=timezone.utc)) == '946684800.0'

# Generated at 2022-06-21 11:31:28.131103
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(dict(a=1)) == {'a': 1}
    class Dummy:
        pass
    assert encoder.default(Dummy()) == "null"


# Generated at 2022-06-21 11:31:36.477088
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    sut = _ExtendedEncoder()
    dt = datetime(2000, 1, 1, tzinfo=timezone.utc).replace(microsecond=123456)
    uid = UUID('707f1497-477c-47ee-8af2-42e91fa16f2c')
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        with pytest.raises(json.JSONEncodeError):
            sut.default([dt, uid])
    expected = [dt.timestamp(), str(uid)]
    actual = sut.default([dt, uid])
    assert expected == actual



# Generated at 2022-06-21 11:31:46.877405
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride() == FieldOverride(None)
    assert FieldOverride(False) == FieldOverride(None, None, False)
    assert FieldOverride(None, None, False) == FieldOverride(None, None, False)
    assert FieldOverride(None, None, False) != FieldOverride(None, None, True)
    assert FieldOverride(None, None, False) == FieldOverride(None, None, False)
    assert FieldOverride() != FieldOverride.exclude_always()
    assert FieldOverride() != FieldOverride.exclude_empty()
    assert FieldOverride() != FieldOverride.exclude_missing()
    assert FieldOverride.exclude_always() == FieldOverride(
        exclude=lambda x: True)
    assert FieldOverride.exclude_empty() == FieldOverride(
        exclude=lambda x: x == "")
    assert FieldOverride.exclude_

# Generated at 2022-06-21 11:31:57.441318
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert enc.default(None) is None
    assert enc.default(True) is True
    assert enc.default(1) == 1
    assert enc.default(1.0) == 1.0
    assert enc.default('abc') == 'abc'
    assert enc.default([]) == []
    assert enc.default({}) == {}
    assert enc.default([1, 2, 3]) == [1, 2, 3]
    assert enc.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

    # We _can_ serialize datetime objects, yay!
    dt = datetime.now(timezone.utc)
    dt_s = enc.default(dt)
    assert isinstance(dt_s, float)

   

# Generated at 2022-06-21 11:32:06.592185
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    def func():
        pass

    with pytest.raises(NotImplementedError):
        FieldOverride(exclude=1)
    with pytest.raises(NotImplementedError):
        FieldOverride(letter_case=1)
    with pytest.raises(NotImplementedError):
        FieldOverride(encoder=1)
    with pytest.raises(NotImplementedError):
        FieldOverride(decoder=1)

    assert FieldOverride(exclude=None) == FieldOverride(exclude=None)
    assert FieldOverride(letter_case=None) == FieldOverride(
        letter_case=None)
    assert FieldOverride(encoder=None) == FieldOverride(encoder=None)
    assert FieldOverride(decoder=None) == FieldOverride(decoder=None)
