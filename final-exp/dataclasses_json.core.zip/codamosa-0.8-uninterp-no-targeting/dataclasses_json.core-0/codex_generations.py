

# Generated at 2022-06-21 11:24:26.030253
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert json.dumps([], cls=_ExtendedEncoder) == '[]'
    assert json.dumps({}, cls=_ExtendedEncoder) == '{}'
    assert json.dumps(datetime.now(timezone.utc), cls=_ExtendedEncoder) == str(datetime.now(timezone.utc).timestamp())
    assert json.dumps(UUID('00000000-0000-0000-0000-000000000000'), cls=_ExtendedEncoder) == '"00000000-0000-0000-0000-000000000000"'
    assert json.dumps(Decimal('1'), cls=_ExtendedEncoder) == '"1"'
    assert json.dumps(None, cls=_ExtendedEncoder) == 'null'

_ENCODER = _ExtendedEncoder()




# Generated at 2022-06-21 11:24:37.664788
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # Simple case
    test_dict = {'exclude': 'test_exclude',
                 'letter_case': 'test_letter_case',
                 'encoder': 'test_encoder',
                 'decoder': 'test_decoder',
                 'mm_field': 'test_mm_field'}
    result = FieldOverride(**test_dict)
    assert result.exclude == 'test_exclude'
    assert result.letter_case == 'test_letter_case'
    assert result.encoder == 'test_encoder'
    assert result.decoder == 'test_decoder'
    assert result.mm_field == 'test_mm_field'

    # Simple case with some missing values

# Generated at 2022-06-21 11:24:46.729255
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(set([1, 2, 1, 2])) == [1, 2, 1, 2]
    assert encoder.default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert encoder.default(datetime(year=2020, month=1, day=1, hour=0, minute=0, second=0, microsecond=0,
                                     tzinfo=timezone.utc)) == 1577836800
    assert encoder.default(UUID('{12345678-1234-5678-1234-567812345678}')) == \
           '12345678-1234-5678-1234-567812345678'

# Generated at 2022-06-21 11:24:49.343724
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().encode({"not_a_class": "ignore_me"}) == '{"not_a_class": "ignore_me"}'



# Generated at 2022-06-21 11:24:59.198696
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(1) == 1
    assert encoder.default(1.1) == 1.1
    assert encoder.default('foo') == 'foo'
    assert encoder.default(True) == True
    assert encoder.default(None) == None
    assert encoder.default(datetime(2020, 1, 1, tzinfo=timezone.utc)) == 1577836800.0

# Generated at 2022-06-21 11:25:09.771966
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    result = _ExtendedEncoder().encode(
        {
            'dict': {
                'key': 'value'
            },
            'list': [1, 2, 3, 4],
            'datetime': datetime(year=2020, month=3, day=3,
                tzinfo=timezone.utc),
            'uuid': UUID('65f4f0c5-ef9e-490c-aee3-909e7ae6b2ab'),
            'enum': cfg.NaN,
            'decimal': Decimal('0.50000'),
        }
    )

# Generated at 2022-06-21 11:25:15.275135
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(12) == '12'
    assert _ExtendedEncoder().encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert _ExtendedEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert json.loads(_ExtendedEncoder().encode(datetime(2018, 6, 12, 12, 46, 5))) == 1528767365.0
    assert _ExtendedEncoder().encode(UUID('d2a1ed6c-b9fa-4cef-8d57-d5f5df6a5a6a')) == '"d2a1ed6c-b9fa-4cef-8d57-d5f5df6a5a6a"'



# Generated at 2022-06-21 11:25:24.903887
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    from datetime import date
    from decimal import Decimal
    from uuid import UUID
    from enum import Enum
    class LetterCase(Enum):
        lower = 1
        upper = 2
    assert {'a': 1} == _ExtendedEncoder().default({'a': 1})
    assert ['a', 1] == _ExtendedEncoder().default(['a', 1])
    assert 'abc' == _ExtendedEncoder().default('abc')
    assert {'a': 1} == _ExtendedEncoder().default({'a': 1})
    assert 0 == _ExtendedEncoder().default(0)
    assert 1 == _ExtendedEncoder().default(1)
    assert 0.1 == _ExtendedEncoder().default(0.1)

# Generated at 2022-06-21 11:25:31.133770
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    enc = _ExtendedEncoder()
    assert json.dumps(datetime(2019, 6, 23, tzinfo=timezone.utc), cls=enc) == "1561302800.0"
    assert json.dumps(datetime(2019, 6, 23), cls=enc) == "\"2019-06-23 00:00:00\""
    assert json.dumps(UUID('b3ef6c3f-2bb8-45c9-a128-c7a0a0dd8de7'), cls=enc) == "\"b3ef6c3f-2bb8-45c9-a128-c7a0a0dd8de7\""
    assert json.dumps(Decimal('0.1'), cls=enc) == "\"0.1\""

# Generated at 2022-06-21 11:25:33.701499
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    """
    Tests the constructor of class _ExtendedEncoder
    """
    assert _ExtendedEncoder()


# Generated at 2022-06-21 11:26:15.088506
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(True) == True
    assert _ExtendedEncoder().default(10) == 10
    assert _ExtendedEncoder().default(10.2) == 10.2
    assert _ExtendedEncoder().default("ABC") == "ABC"
    assert _ExtendedEncoder().default(None) == None
    assert _ExtendedEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert _ExtendedEncoder().default({'key': 'value'}) == {'key': 'value'}
    assert _ExtendedEncoder().default(datetime.now()) == datetime.now().timestamp()
    assert _ExtendedEncoder().default(datetime.now().timestamp()) == datetime.now().timestamp()

# Generated at 2022-06-21 11:26:25.964997
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default(datetime.now()) == datetime.now().timestamp()
    assert encoder.default(UUID(int=0)) == '00000000-0000-0000-0000-000000000000'
    assert encoder.default(set()) == list(set())
    assert encoder.default({}) == dict()
    assert encoder.default(dict()) == dict()
    assert encoder.default(Enum) == Enum.value
    assert encoder.default(Decimal("1.0")) == "1.0"
    assert encoder.default("") == ""
    assert encoder.default([]) == []
    assert encoder.default(True) == True

    class DefaultEncodedDummy:
        def __init__(self, value):
            self.value = value


# Generated at 2022-06-21 11:26:36.686397
# Unit test for method default of class _ExtendedEncoder

# Generated at 2022-06-21 11:26:48.389459
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    my_encoder = StrFunc(lambda x: x)
    my_decoder = StrFunc(lambda x: x)

    # Tests for encoding only
    encoders1 = FieldOverride(exclude=None, letter_case=None, encoder=None)
    encoders2 = FieldOverride(exclude=None, letter_case=None, encoder=my_encoder)
    assert encoders1.encoder is not encoders2.encoder
    assert encoders1.decoder is encoders2.decoder

    # Tests for decoding only
    decoders1 = FieldOverride(exclude=None, letter_case=None, decoder=None)
    decoders2 = FieldOverride(exclude=None, letter_case=None, decoder=my_decoder)
    assert decoders1

# Generated at 2022-06-21 11:26:57.744754
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    assert encoder.default([4]) == [4]
    assert encoder.default({4: 5}) == {4: 5}
    assert encoder.default(datetime.utcnow()) == datetime.utcnow().timestamp()
    assert encoder.default(datetime.utcnow().timestamp()) == datetime.utcnow().timestamp()
    assert encoder.default(None) is None
    assert encoder.default(True) is True
    assert encoder.default(1) == 1
    assert encoder.default('abc') == 'abc'
    assert encoder.default(UUID('11112222-3333-4444-5555-666677778888')) == '11112222-3333-4444-5555-666677778888'




# Generated at 2022-06-21 11:27:05.663415
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    class test_type(NamedTuple):
        a: int

    test_decoder = lambda x: 'x'
    test_encoder = lambda x: 'x'
    test_case_func = lambda x: True
    test_overrides = FieldOverride(test_decoder, None, test_case_func,
                                   test_encoder)
    assert test_overrides.decoder == test_decoder
    assert test_overrides.exclude == test_case_func
    assert test_overrides.encoder == test_encoder

# Generated at 2022-06-21 11:27:16.586300
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    @dataclass
    class A:
        a: str

    @dataclass_json
    @dataclass
    class B:
        a: A
        b: str
        c: int
        d: str = "d"
        e: bool = True
        f: bool = False
        g: int = 10
        h: int = 40
        i: int = 50


# Generated at 2022-06-21 11:27:23.993705
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    override = FieldOverride()
    kv = {'exclude': 'exclude', 'letter_case': 'letter_case',
          'encoder': 'encoder', 'decoder': 'decoder'}
    assert override.exclude == kv['exclude']
    assert override.letter_case == kv['letter_case']
    assert override.encoder == kv['encoder']
    assert override.decoder == kv['decoder']

    def test_func(val):
        return val

    override = FieldOverride(exclude=test_func, letter_case=test_func,
                             encoder=test_func, decoder=test_func)
    assert override.exclude == test_func
    assert override.letter_case == test_func
    assert override.encoder == test_func
    assert override.dec

# Generated at 2022-06-21 11:27:36.255061
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(['abc']) == ['abc'], \
        "_ExtendedEncoder().default(['abc'])"
    assert _ExtendedEncoder().default({'abc': 123}) == {'abc': 123}, \
        "_ExtendedEncoder().default({'abc': 123})"
    assert _ExtendedEncoder().default(None) == None, \
        "_ExtendedEncoder().default(None)"
    assert _ExtendedEncoder().default(123) == 123, \
        "_ExtendedEncoder().default(123)"
    assert _ExtendedEncoder().default(123.4) == 123.4, \
        "_ExtendedEncoder().default(123.4)"
    assert _ExtendedEncoder().default(True) == True, \
        "_ExtendedEncoder().default(True)"
   

# Generated at 2022-06-21 11:27:41.747569
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    temp = FieldOverride(None, None, None)
    assert temp.letter_case == None
    assert temp.encoder == None
    assert temp.decoder == None
    assert temp.exclude == None
    temp = FieldOverride(None, None, None, None)
    assert temp.letter_case == None
    assert temp.encoder == None
    assert temp.decoder == None
    assert temp.exclude == None


# Generated at 2022-06-21 11:28:09.750477
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    json.dumps([1, 2, 3], cls=_ExtendedEncoder)
    json.dumps({'a':1, 'b':2}, cls=_ExtendedEncoder)
    json.dumps(datetime.now(timezone.utc) + datetime.timedelta(hours=9))
    json.dumps(UUID('550e8400-e29b-41d4-a716-446655440000'))
    json.dumps(cfg.enums.Names)
    json.dumps(Decimal('0.1'))
    json.dumps(Decimal('0.2'))
    
test__ExtendedEncoder()


# Generated at 2022-06-21 11:28:22.123427
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = json.dumps({'a':[1,2,3]}, cls=_ExtendedEncoder)
    assert '{"a":[1,2,3]}' == encoder
    encoder = json.dumps({'a':[1,2,3], 'b':3}, cls=_ExtendedEncoder)
    assert '{"a":[1,2,3], "b":3}' == encoder
    encoder = json.dumps({'a':[1,2,3], 'b':3, 'c':'123'}, cls=_ExtendedEncoder)
    assert '{"a":[1,2,3], "b":3, "c":"123"}' == encoder

# Generated at 2022-06-21 11:28:31.026845
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode({"a": None}) == '{"a": null}'
    assert _ExtendedEncoder().encode([1, "a"]) == '[1, "a"]'
    assert _ExtendedEncoder().encode({"a": 1}) == '{"a": 1}'
    assert _ExtendedEncoder().encode(1) == '1'
    assert _ExtendedEncoder().encode("a") == '"a"'
    assert _ExtendedEncoder().encode(1.1) == '1.1'
    assert _ExtendedEncoder().encode(True) == 'true'
    assert _ExtendedEncoder().encode(None) == 'null'
    assert _ExtendedEncoder().encode(cfg.NaN) == 'null'
    assert _ExtendedEncoder

# Generated at 2022-06-21 11:28:32.594249
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    _ExtendedEncoder().default(tuple())


# Generated at 2022-06-21 11:28:44.198068
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():  # type: ignore
    # Assert for case 1: Collection
    a: Collection[str] = [1, 2, 3]
    assert _ExtendedEncoder().default(  # type: ignore
        a) == ['1', '2', '3']
    a = {1, 2, 3}
    assert _ExtendedEncoder().default(  # type: ignore
        a) == ['1', '2', '3']
    a = {1: 'a', 2: 'b', 3: 'c'}
    assert _ExtendedEncoder().default(  # type: ignore
        a) == {'1': 'a', '2': 'b', '3': 'c'}
    # Assert for case 2: datetime
    a = datetime.fromtimestamp(1)

# Generated at 2022-06-21 11:28:49.886710
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert(
        str(FieldOverride("turtle", exclude=None,
                          encoder=None, decoder=None, letter_case=None)) ==
        "FieldOverride(letter_case=turtle, exclude=None, encoder=None, decoder=None)")
    assert(
        str(FieldOverride("turtle", exclude=None,
                          encoder=lambda x: x, decoder=lambda x: x,
                          letter_case=lambda x: x)) ==
        "FieldOverride(letter_case=<function <lambda> at 0x...>, exclude=None, encoder=<function <lambda> at 0x...>, decoder=<function <lambda> at 0x...>)")

# Generated at 2022-06-21 11:28:58.282382
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    "Unit test for constructor of class _ExtendedEncoder"
    o = 1
    o_str = _ExtendedEncoder().encode(o)
    assert o_str == '1'
    assert _ExtendedEncoder().encode([1,2,3]) == '[1, 2, 3]'
    assert _ExtendedEncoder().encode([1,{'a':1},3]) == '[1, {"a": 1}, 3]'
    d = datetime(2019,10,18,0,0,0,tzinfo=timezone.utc)
    d_str = _ExtendedEncoder().encode(d)
    assert d_str == '"1571307200.0"'
    d = datetime(2019,10,18,23,15,0,tzinfo=timezone.utc)
    d_str

# Generated at 2022-06-21 11:29:03.601127
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder.default(None, 1) == 1
    assert _ExtendedEncoder.default(None, [1, 2]) == [1, 2]
    assert _ExtendedEncoder.default(None, {'x': 1}) == {'x': 1}
    o = 'abc'
    assert _ExtendedEncoder.default(None, o) == o


_extended_encoder = _ExtendedEncoder()

#noinspection PyProtectedMember

# Generated at 2022-06-21 11:29:14.011031
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(
        set((1, 2, 3))) == "[1,2,3]"  # type: ignore
    assert _ExtendedEncoder().encode(
        {'one': 1, 'two': 2}) == '{"one":1,"two":2}'
    assert _ExtendedEncoder().encode(
        datetime.now(timezone.utc)) == '{"$datetime": "2019-10-14T08:36:03.476482+00:00"}'

# Generated at 2022-06-21 11:29:23.375329
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride(decoder=str.upper, encoder=str.lower,
                         letter_case=str.title, exclude=lambda _: True)\
        == FieldOverride(decoder=str.upper, encoder=str.lower,
                         letter_case=str.title, exclude=lambda _: True)
    assert FieldOverride(decoder=None, encoder=None, letter_case=None,
                         exclude=None) == FieldOverride()
    assert FieldOverride(decoder=None, encoder=None, letter_case=None,
                         exclude=None) == FieldOverride(None)
    assert FieldOverride() == FieldOverride(None)
    assert FieldOverride(decoder=None, encoder=None, letter_case=None,
                         exclude=lambda _: True) == FieldOverride()

# Generated at 2022-06-21 11:30:11.899622
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.encode({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert encoder.encode([1, 2, 'a']) == '[1, 2, "a"]'
    assert encoder.encode({}) == '{}'
    assert encoder.encode([]) == '[]'



# Generated at 2022-06-21 11:30:14.958548
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    encoder = lambda x: x
    decoder = lambda x: x
    exclude = lambda x: False
    letter_case = lambda x: x

    FieldOverride(encoder, decoder, exclude, letter_case)

    FieldOverride(None, None, None, None)

    FieldOverride(None, decoder, None, None)

    FieldOverride(None, None, None, letter_case)

    FieldOverride(None, None, exclude, None)


# Generated at 2022-06-21 11:30:25.071478
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    e = _ExtendedEncoder(allow_nan=True)
    a = _ExtendedDecoder()

    # call of constructor with the default parameters
    fieldOverride = FieldOverride()
    assert fieldOverride.exclude is None
    assert fieldOverride.letter_case is None
    assert fieldOverride.encoder is None
    assert fieldOverride.decoder is None

    # call of constructor with the non-default parameters
    fieldOverride = FieldOverride(lambda x: True, lambda x: x, encodingFunc,
                                  decodingFunc)

# Generated at 2022-06-21 11:30:29.140571
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    assert FieldOverride().exclude is None
    assert FieldOverride(exclude=lambda x: True).exclude is not None

    assert FieldOverride().letter_case is None
    assert FieldOverride(letter_case=lambda x: x.lower()).letter_case is not None

    assert FieldOverride().encoder is None
    assert FieldOverride(encoder=lambda x: x+1).encoder is not None

    assert FieldOverride().decoder is None
    assert FieldOverride(decoder=lambda x: x+1).decoder is not None



# Generated at 2022-06-21 11:30:30.538353
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(None) == "null"


# noinspection PyProtectedMember

# Generated at 2022-06-21 11:30:32.482112
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(Enum(value=1)) == 1



# Generated at 2022-06-21 11:30:41.263553
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    # GIVEN
    j = _ExtendedEncoder()
    # WHEN
    # THEN
    assert j.encode({'a': 'b'}) == '{"a": "b"}'
    assert j.encode(['a', 'b']) == '["a", "b"]'
    assert j.encode('abc') == '"abc"'
    assert j.encode(123) == '123'
    assert j.encode(123.4) == '123.4'
    assert j.encode(True) == 'true'
    assert j.encode(False) == 'false'
    assert j.encode(None) == 'null'
    assert j.encode(datetime.fromtimestamp(0, tz = timezone.utc)) == '0.0'
    assert j.encode

# Generated at 2022-06-21 11:30:49.262789
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    ee = _ExtendedEncoder()
    assert ee.default({'a': 1}) == {'a': 1}
    assert ee.default([1, 2, 3]) == [1, 2, 3]
    assert ee.default(datetime(2020, 2, 2, 1, 1, 1, tzinfo=timezone.utc)) == 1583230521.0
    assert ee.default(UUID('01234567-89ab-cdef-fedc-ba9876543210')) == '01234567-89ab-cdef-fedc-ba9876543210'
    assert ee.default(Decimal('10.1')) == '10.1'



# Generated at 2022-06-21 11:30:57.879412
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    assert _ExtendedEncoder().default(datetime.now(timezone.utc)) == 1595044258.0
    assert _ExtendedEncoder().default(Enum('_TestEnum', 'a b')('b')) == 'b'
    assert _ExtendedEncoder().default(UUID('5f5ba5d5-0c35-4622-bb6e-15b698530a1a')) == '5f5ba5d5-0c35-4622-bb6e-15b698530a1a'
    assert _ExtendedEncoder().default(Decimal('1234567890.1234567890')) == '1234567890.1234567890'
    assert _ExtendedEncoder().default(range(3)) == [0, 1, 2]


DictMapping

# Generated at 2022-06-21 11:31:04.429617
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert encoder.default(('a', 'b', 'c')) == ['a', 'b', 'c']
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default(set(['a', 'b', 'c'])) == ['a', 'b', 'c']
    dt = datetime(2020, 3, 3, tzinfo=timezone.utc)
    assert encoder.default(dt) == 1583210400
    uuid1 = UUID('12345678123456781234567812345678')
    assert encoder.default(uuid1)

# Generated at 2022-06-21 11:32:10.969298
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert isinstance(_ExtendedEncoder().default({'a': 'a'}), dict)
    assert isinstance(_ExtendedEncoder().default(['a']), list)
    assert isinstance(_ExtendedEncoder().default(datetime.now(timezone.utc)), float)
    assert isinstance(_ExtendedEncoder().default(UUID('1e82aa7e-d343-11e7-8b1a-16408ebd2800')), str)
    assert isinstance(_ExtendedEncoder().default(Decimal('1.00')), str)
    assert isinstance(_ExtendedEncoder().default((1, 2, 3)), tuple)
    assert isinstance(_ExtendedEncoder().default('test'), str)



# Generated at 2022-06-21 11:32:20.415875
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    expected_outcome = '{"exclude": <function _test_exclude at 0x10e14f840>, "letter_case": <function lower at 0x10ffbfc80>, "encoder": <function _test_encoder at 0x10e14f7b8>, "decoder": <function _test_decoder at 0x10e14f950>, "mm_fields": _test_mm_fields}'

    test_override = FieldOverride(_test_exclude, _test_encoder,
                                  _test_decoder, lower, _test_mm_fields)

    actual_outcome = str(test_override)

    assert actual_outcome == expected_outcome



# Generated at 2022-06-21 11:32:23.494519
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()
    result = encoder.default(object())
    assert isinstance(result, type(object()))


# Generated at 2022-06-21 11:32:26.946813
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().default(datetime.now())
    assert _ExtendedEncoder().default(UUID(int=0))
    assert _ExtendedEncoder().default(Decimal('12.0'))



# Generated at 2022-06-21 11:32:35.722634
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    encoder = _ExtendedEncoder()
    assert encoder.default([1]) == [1]
    assert encoder.default({'aaa': 'bbb'}) == {'aaa': 'bbb'}
    assert encoder.default(datetime.now()) == datetime.now().timestamp()
    assert encoder.default(UUID('717e8d4c-7fca-11e9-bf4b-926989988213')) == '717e8d4c-7fca-11e9-bf4b-926989988213'


# Generated at 2022-06-21 11:32:47.312788
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    def _check(o, result):
        encoder = _ExtendedEncoder()
        assert encoder.default(o) == result
    # noinspection PyUnresolvedReferences
    # NOTE: deprecated warning expected
    _check([1, 2, 3], [1, 2, 3])
    # noinspection PyUnresolvedReferences
    _check([1, [2, 3]], [1, [2, 3]])
    _check({'a': 1, 'b': 2}, {'a': 1, 'b': 2})
    _check(Decimal("1.1"), "1.1")
    _check(Enum("Enum", {'a': 1}), 1)

# Generated at 2022-06-21 11:32:56.403112
# Unit test for method default of class _ExtendedEncoder
def test__ExtendedEncoder_default():
    encoder = _ExtendedEncoder()

    # Standard types
    assert encoder.default('foo') == 'foo'
    assert encoder.default(123) == 123
    assert encoder.default(123.4) == 123.4
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(None) is None
    assert encoder.default(['foo', 123, None]) == ['foo', 123, None]
    assert encoder.default({'foo': 'bar', 'abc': 123, 'xyz': [1, 2, 3]}) == {'foo': 'bar', 'abc': 123, 'xyz': [1, 2, 3]}
    assert encoder.default({}) == {}

    # Collection types
    assert encoder.default(set()) == []

# Generated at 2022-06-21 11:33:03.389720
# Unit test for constructor of class _ExtendedEncoder
def test__ExtendedEncoder():
    assert _ExtendedEncoder().encode(datetime(2019, 12, 6, 19, 59, 41, tzinfo=timezone.utc)) == '"15756547810"'
    assert _ExtendedEncoder().encode(UUID('0f9868e7-cbbe-4e1f-a789-47a0b33131c2')) == '"0f9868e7-cbbe-4e1f-a789-47a0b33131c2"'
    assert _ExtendedEncoder().encode(Enum) == '"Enum"'
    assert _ExtendedEncoder().encode(Decimal(1)) == '"1"'


# Generated at 2022-06-21 11:33:10.499379
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    f_or_e = _FieldOverride(exclude="x",
                            encoder="y",
                            decoder="z",
                            letter_case="A",
                            mm_field="p")
    assert f_or_e.exclude == "x"
    assert f_or_e.encoder == "y"
    assert f_or_e.decoder == "z"
    assert f_or_e.letter_case == "A"
    assert f_or_e.mm_field == "p"



# Generated at 2022-06-21 11:33:20.177540
# Unit test for constructor of class FieldOverride
def test_FieldOverride():
    # try invalid constructors
    with pytest.raises(TypeError):
        # not enough arguments
        FieldOverride()

    with pytest.raises(AttributeError):
        # invalid argument types
        FieldOverride(dict(), "exclude", "letter_case")

    with pytest.raises(TypeError):
        # too many arguments
        FieldOverride(lambda x: True, "exclude", "letter_case", "encoder")

    # try valid constructors
    FieldOverride(None, "exclude", "letter_case", "encoder")
    FieldOverride(lambda x: True, "exclude", "letter_case", "encoder")

    # test that class variables values are what they're supposed to be