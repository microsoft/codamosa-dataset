

# Generated at 2022-06-24 03:03:52.607787
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/path/to/', ['hoge.txt', 'foo'])) == [
        '/path/to/hoge.txt',
        '/path/to/foo',
    ]



# Generated at 2022-06-24 03:03:54.440153
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']


# Mock os.walk as mock_walk

# Generated at 2022-06-24 03:03:57.469682
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/foo", ["bar", "baz"])) == ["/foo/bar", "/foo/baz"]


join_each_v2 = partial(map, os.path.join)



# Generated at 2022-06-24 03:03:59.127557
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:04:01.319454
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c", "d"])) == ["a/b", "a/c", "a/d"]

# Generated at 2022-06-24 03:04:04.594196
# Unit test for function join_each
def test_join_each():
    parent = '/usr/local'
    children = ['bin', 'lib', 'share']
    expected = ['/usr/local/bin', '/usr/local/lib', '/usr/local/share']
    assert list(join_each(parent, children)) == expected



# Generated at 2022-06-24 03:04:10.137291
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each("foo", ["bar", "baz"])) \
        == ("foo/bar", "foo/baz")

# Generated at 2022-06-24 03:04:12.869112
# Unit test for function join_each
def test_join_each():
    parent = '/example/path'
    iterable = ['one', 'two', 'three']

    exp = ['/example/path/one', '/example/path/two', '/example/path/three']

    assert list(join_each(parent, iterable)) == exp




# Generated at 2022-06-24 03:04:18.503246
# Unit test for function join_each
def test_join_each():
    exeped = ['a/b/c', 'a/b/d', 'a/b/e']
    result = list(join_each('a/b', ['c', 'd', 'e']))
    assert exeped == result


#1: find '.py' files recursively in given directory.

# Generated at 2022-06-24 03:04:24.638822
# Unit test for function join_each
def test_join_each():
    assert_equal(tuple(join_each('/path/to/dir', ('a', 'b', 'c'))),
        ('/path/to/dir/a', '/path/to/dir/b', '/path/to/dir/c'))



# Generated at 2022-06-24 03:04:27.568315
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:04:33.305948
# Unit test for function join_each
def test_join_each():
    my_files = ['file1.py', 'file2.py']
    my_joined_files = ['path/to/file1.py', 'path/to/file2.py']
    assert list(join_each('path/to', my_files)) == my_joined_files



# Generated at 2022-06-24 03:04:38.112443
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:04:42.440460
# Unit test for function join_each
def test_join_each():
    parent, join_set = "parent/", ["child1", "child2"]
    assert list(join_each(parent, join_set)) == [
        "parent/child1", "parent/child2"]

# Generated at 2022-06-24 03:04:45.044878
# Unit test for function join_each
def test_join_each():
    parent = 'testing'
    iterable = ['1', '2']
    expected = ['testing/1', 'testing/2']
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-24 03:04:46.976109
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-24 03:04:52.438426
# Unit test for function join_each
def test_join_each():
    my_list = ['a', 'b', 'c']
    assert list(join_each('root', my_list)) == ['root/a', 'root/b', 'root/c']



# Generated at 2022-06-24 03:04:54.146740
# Unit test for function join_each
def test_join_each():
    assert [v for v in join_each("/", ["foo", "bar"])] == ["/foo", "/bar"]

# Generated at 2022-06-24 03:04:56.666794
# Unit test for function join_each
def test_join_each():
    assert list(join_each('p', ['a', 'b'])) == ['p/a', 'p/b']



# Generated at 2022-06-24 03:05:01.488485
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('', ['b', 'c'])) == ['b', 'c']
    assert list(join_each('a', (''))) == ['a']

# Generated at 2022-06-24 03:05:08.465488
# Unit test for function join_each
def test_join_each():
    assert '/tmp' == next(join_each('/', ['tmp']))
    assert '/tmp/a/b' == next(join_each('/tmp', ['a/b']))
    assert '/tmp/a/b/c' == next(join_each('/tmp/a', ['b/c']))
    assert '/tmp/a/b/c' == next(join_each('/tmp/a/b', ['c']))



# Generated at 2022-06-24 03:05:09.675094
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['etc', 'usr'])) == ['/etc', '/usr']


# Exercise 6

# Generated at 2022-06-24 03:05:12.630628
# Unit test for function join_each
def test_join_each():
    assert list(join_each("dir", ["file1", "file2"])) == [os.path.join("dir", "file1"), os.path.join("dir", "file2")]



# Generated at 2022-06-24 03:05:15.472473
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/bin', ['python', 'perl'])) == ['/usr/bin/python', '/usr/bin/perl']



# Generated at 2022-06-24 03:05:17.949564
# Unit test for function join_each
def test_join_each():
    assert [x for x in join_each('/asdf', ['a', 'b'])] == [
        '/asdf/a',
        '/asdf/b',
    ]



# Generated at 2022-06-24 03:05:25.525042
# Unit test for function join_each
def test_join_each():
    cases = [
        ('/a', ('b', 'c'), ('/a/b', '/a/c')),
        ('/a/', ('b', 'c'), ('/a/b', '/a/c')),
        ('/a', ('/b', '/c'), ('/b', '/c')),
    ]
    for parent, iterable, expect in cases:
        actual = list(join_each(parent, iterable))
        assert actual == expect, (parent, iterable, expect, actual)



# Generated at 2022-06-24 03:05:31.757282
# Unit test for function join_each
def test_join_each():
    parent = 'C:/Users/User/Documents/Python Scripts'
    iterable = ['Workspace', 'Experiments']
    assert (list(join_each(parent, iterable))
            == ['C:/Users/User/Documents/Python Scripts/Workspace',
                'C:/Users/User/Documents/Python Scripts/Experiments'])


# Unit test

# Generated at 2022-06-24 03:05:37.470408
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', ['passwd', 'group'])) == [
        '/etc/passwd', '/etc/group']

# Generated at 2022-06-24 03:05:41.549511
# Unit test for function join_each
def test_join_each():
    p1 = 'this/is/a/path'

    it = ['one', 'two', 'three']
    jit = join_each(p1, it)
    assert jit == ['this/is/a/path/one',
                   'this/is/a/path/two',
                   'this/is/a/path/three']



# Generated at 2022-06-24 03:05:43.164019
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", [("bar", "baz")])) == ['foo/bar/baz']



# Generated at 2022-06-24 03:05:47.238386
# Unit test for function join_each
def test_join_each():
    import os.path
    assert list(join_each("A", "BCD")) == [os.path.join("A", p) for p in "BCD"]



# Generated at 2022-06-24 03:05:55.802059
# Unit test for function join_each
def test_join_each():
    from collections import Iterable
    from nose.tools import assert_equal

    dir_base = os.path.join(
        os.path.dirname(__file__),
        '..',  # Top-level directory
        '..',  # Biocore
    )
    # At the top level of a repo
    assert_equal(
        next(join_each(dir_base, ['some', 'paths'])),
        os.path.join(dir_base, 'some')
    )
    assert_equal(
        list(join_each(dir_base, ['some', 'paths'])),
        [os.path.join(dir_base, path) for path in ['some', 'paths']]
    )



# Generated at 2022-06-24 03:06:01.117857
# Unit test for function join_each
def test_join_each():

    test_parent = 'foo'
    iterable = ['bar', 'baz', 'qux']
    test_result = list(join_each(test_parent, iterable))

    assert test_result[0] == 'foo/bar'
    assert test_result[1] == 'foo/baz'
    assert test_result[2] == 'foo/qux'

# Generated at 2022-06-24 03:06:04.696381
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a", "/b")) == ["/a/b"]
    assert list(join_each("/a", ["/b"])) == ["/a/b"]
    assert list(join_each("/a", ["/b", "/c"])) == ["/a/b", "/a/c"]



# Generated at 2022-06-24 03:06:13.274313
# Unit test for function join_each
def test_join_each():
    assert list(join_each('usr', 'local', 'bin')) == ['usr/local/bin']
    assert list(join_each('usr', ['local', 'bin'])) == ['usr/local', 'usr/bin']
    assert list(join_each('usr', ['local', 'bin', 'henk'])) == ['usr/local', 'usr/bin', 'usr/henk']
    assert list(join_each('', 'henk')) == ['henk']
    assert list(join_each('', 'h', 'e', 'n', 'k')) == ['h/e/n/k']


if __name__ == '__main__':
    print(list(join_each('usr', 'local', 'bin')))
    print(list(join_each('usr', ['local', 'bin'])))
    print

# Generated at 2022-06-24 03:06:20.311265
# Unit test for function join_each
def test_join_each():
    parent = os.path.abspath(os.path.join(__file__, ".."))
    children = list(join_each(parent, ["foo", "bar", "baz"]))
    assert os.path.join(parent, "foo") in children
    assert os.path.join(parent, "bar") in children
    assert os.path.join(parent, "baz") in children



# Generated at 2022-06-24 03:06:25.776737
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a/b", ["c", "d"])) == ["/a/b/c", "/a/b/d"]

# Generated at 2022-06-24 03:06:28.973198
# Unit test for function join_each
def test_join_each():
    values = list(join_each('/var', ['log', 'tmp']))
    assert values == ['/var/log', '/var/tmp']



# Generated at 2022-06-24 03:06:36.671131
# Unit test for function join_each
def test_join_each():
    print(list(join_each('/usr/local/lib', ('python', 'perl', 'lua'))))
    assert list(join_each('/usr/local/lib', ('python', 'perl', 'lua'))) == ['/usr/local/lib/python', '/usr/local/lib/perl', '/usr/local/lib/lua']


if __name__ == "__main__":
    import nose
    nose.runmodule(exit=False)

    # join_each('/usr/local/lib', ('python', 'perl', 'lua'))
    # test_join_each()

# Generated at 2022-06-24 03:06:39.988162
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/foo", ["bar", "baz"])) == [
        os.path.join("/home/foo", "bar"),
        os.path.join("/home/foo", "baz"),
    ]



# Generated at 2022-06-24 03:06:41.958303
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == [
        os.path.join('/', 'a'), os.path.join('/', 'b')
    ]

# Generated at 2022-06-24 03:06:43.619416
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', 'hello world'.split())) == ['/tmp/hello', '/tmp/world']



# Generated at 2022-06-24 03:06:46.334582
# Unit test for function join_each
def test_join_each():
    p = "C:"
    iterable = ["file", "folder", "root"]
    for each in join_each(p, iterable):
        print(each)

# Generated at 2022-06-24 03:06:48.901055
# Unit test for function join_each
def test_join_each():
    parent = '/foo'
    paths = ['/bar', '/baz']
    result = list(join_each(parent, paths))
    assert result == ['/foo/bar', '/foo/baz']

# Generated at 2022-06-24 03:06:50.494168
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each("/home/user", ("movies", "pictures"))) == (
        "/home/user/movies",
        "/home/user/pictures",
    )



# Generated at 2022-06-24 03:06:52.141078
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each("/", ("var", "lib", "hello"))) == ("/var", "/lib", "/hello")



# Generated at 2022-06-24 03:06:55.445687
# Unit test for function join_each
def test_join_each():
    parent = "my_directory"
    iterable = ["a.txt", "b.txt", "c.txt"]

    assert list(join_each(parent, iterable)) == [os.path.join(parent, iterable[0]),
                                                 os.path.join(parent, iterable[1]),
                                                 os.path.join(parent, iterable[2])]

# Generated at 2022-06-24 03:07:00.639505
# Unit test for function join_each
def test_join_each():
    res = list(join_each(os.path.sep, ['home', 'user1', 'temp']))
    assert res == ['/home', '/user1', '/temp'], 'Function join_each() has failed.'



# Generated at 2022-06-24 03:07:05.381537
# Unit test for function join_each
def test_join_each():
    #assert join_each("/root/", ["home", "yus", "gits"]) == "/root/home"
    #assert join_each("/root/", ["home", "yus", "gits"]) == "/root/yus"
    #assert join_each("/root/", ["home", "yus", "gits"]) == "/root/gits"
    for each in join_each("/tmp", ["home", "yus", "gits"]):
        print(each)



# Generated at 2022-06-24 03:07:07.806240
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', 'bar')) == ['foo/bar']
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:07:10.700268
# Unit test for function join_each
def test_join_each():
    assert list(join_each("dir", ["a", "b"])) == ["dir/a", "dir/b"]
    assert list(join_each("dir", ["a", "b", "c"])) == ["dir/a", "dir/b", "dir/c"]



# Generated at 2022-06-24 03:07:16.207880
# Unit test for function join_each
def test_join_each():
    test_cases = [
        ('/tmp', []),
        ('/tmp', ['foo', 'bar']),
    ]
    for parent, paths in test_cases:
        paths = [p.encode('utf-8') for p in paths]
        expected = [os.path.join(parent, p).encode('utf-8') for p in paths]
        assert list(join_each(parent, paths)) == expected


if __name__ == '__main__':
    from test_utils import main
    main(__file__)

# Generated at 2022-06-24 03:07:20.649993
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', [1, 2, 3])) == ['foo/1', 'foo/2', 'foo/3']
    assert list(join_each('foo', [])) == []



# Generated at 2022-06-24 03:07:22.577419
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/lib', ['bin', 'sbin'])) == ['/usr/lib/bin', '/usr/lib/sbin']



# Generated at 2022-06-24 03:07:24.182394
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['bin', 'usr'])) == ['/home/bin', '/home/usr']



# Generated at 2022-06-24 03:07:28.093741
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/darth", ["vader", "leia", "luke"])) == [
        "/home/darth/vader",
        "/home/darth/leia",
        "/home/darth/luke",
    ]


# Generated at 2022-06-24 03:07:29.536685
# Unit test for function join_each
def test_join_each():
    """
    Test join_each function.
    """
    assert list(join_each('/a/b', ['c', 'd'])) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-24 03:07:31.074885
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:07:36.927148
# Unit test for function join_each
def test_join_each():
    assert list(join_each('path/to/dir', 'a b c'.split())) == \
           ['path/to/dir/a', 'path/to/dir/b', 'path/to/dir/c']



# Generated at 2022-06-24 03:07:42.400393
# Unit test for function join_each
def test_join_each():
    x = join_each("/tmp", ["a", "b", "c"])
    assert list(x) == ["/tmp/a", "/tmp/b", "/tmp/c"]



# Generated at 2022-06-24 03:07:46.289515
# Unit test for function join_each
def test_join_each():
    """
    The function should yield joined paths in the iterable.
    """
    assert list(join_each('/home', ['foo', 'bar'])) == [
        '/home/foo',
        '/home/bar'
    ]

# Generated at 2022-06-24 03:07:50.756273
# Unit test for function join_each
def test_join_each():
    data = [
        (["/", "foo/bar", "foo"], "bar"),
        (["/", "foo/bar", "bar"], "/foo/bar"),
        (["/", "foo/bar"], ""),
        (["/", "foo/bar"], "baz"),
    ]
    for (parent, iterable), expected in data:
        assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:07:56.036293
# Unit test for function join_each
def test_join_each():
    path = '/usr/bin'
    result = join_each(path, ['python', 'python2', 'python3'])
    for r in result:
        print(r)
    print('----------')
    for r in result:
        print(r)



# Generated at 2022-06-24 03:07:58.809602
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo/bar', ['baz', 'quux'])) == ['/foo/bar/baz',
                                                           '/foo/bar/quux']

# Generated at 2022-06-24 03:08:01.675990
# Unit test for function join_each
def test_join_each():
    assert set(join_each("/my/path", ["file1", "file2"])) == {
        "/my/path/file1",
        "/my/path/file2",
    }

# Generated at 2022-06-24 03:08:05.063948
# Unit test for function join_each
def test_join_each():
    assert [os.path.join("path/to/", i) for i in ["a", "b", "c"]] == \
           list(join_each("path/to/", ["a", "b", "c"]))


# unit test for function get_filtered_file

# Generated at 2022-06-24 03:08:07.083924
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    paths = ['test', 'foo', 'bar']
    joined_paths = [os.path.join(parent, path) for path in paths]
    assert list(join_each(parent, paths)) == joined_paths


# Unit test

# Generated at 2022-06-24 03:08:13.472948
# Unit test for function join_each
def test_join_each():
    parent = "/home/user"
    children = ["foo", "bar", "baz"]
    expected = ["/home/user/foo", "/home/user/bar", "/home/user/baz"]
    assert list(join_each(parent, children)) == expected

# Generated at 2022-06-24 03:08:16.254807
# Unit test for function join_each
def test_join_each():
    parent = "some/directory"
    iterable = ["subdir", "subdir2"]
    res = join_each(parent, iterable)
    assert res[0] == os.path.join(parent, iterable[0])
    assert res[1] == os.path.join(parent, iterable[1])



# Generated at 2022-06-24 03:08:20.850795
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['user1', 'user2', 'user3'])) == ['/home/user1', '/home/user2', '/home/user3']



# Generated at 2022-06-24 03:08:26.500504
# Unit test for function join_each
def test_join_each():
    pairs = [('/usr', 'bin'),
             ('/usr', 'local'),
             ('/usr/lib', 'x86_64-linux-gnu')]
    assert list(join_each(*zip(*pairs))) == list(map(os.path.join, *zip(*pairs)))



# Generated at 2022-06-24 03:08:27.697255
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ('bin', 'local'))) == [
        '/usr/bin',
        '/usr/local',
    ]

# Generated at 2022-06-24 03:08:32.396788
# Unit test for function join_each
def test_join_each():
    """
    Check that join_each works as intended
    """
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']

    # Check that it raises a TypeError if the parent is not a string
    with pytest.raises(TypeError):
        list(join_each([], ['a', 'b']))



# Generated at 2022-06-24 03:08:33.433509
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", "bc")) == ["a/b", "a/c"]



# Generated at 2022-06-24 03:08:41.757500
# Unit test for function join_each
def test_join_each():
    # Test 1
    parent = "/User/test"
    iterable = ["test", "test2"]
    expected = ["/User/test/test", "/User/test/test2"]
    assert list(join_each(parent, iterable)) == expected

    # Test 2
    parent = ""
    iterable = ["test", "test2"]
    expected = ["test", "test2"]
    assert list(join_each(parent, iterable)) == expected

    # Test 3
    parent = "test"
    iterable = ["test", "test2"]
    expected = ["test/test", "test/test2"]
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-24 03:08:43.734632
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['a', 'b', 'c'])) == ['foo/a', 'foo/b', 'foo/c'], 'Test failed'



# Generated at 2022-06-24 03:08:47.913692
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['Documents', 'Music'])) == ['/Documents', '/Music']

# Generated at 2022-06-24 03:08:51.515418
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["john", "doe"])) == [
        "/home/john",
        "/home/doe",
    ]



# Generated at 2022-06-24 03:08:56.471687
# Unit test for function join_each
def test_join_each():
    from vcstool.vcs_base import VcsRepo
    from vcstool.vcs_git import VcsGit
    from vcstool.vcs_svn import VcsSvn

    root = os.path.dirname(__file__)
    packages = [
        VcsRepo("a_package", "", VcsGit("https://github.com/a/a.git")),
        VcsRepo("b_package", "", VcsSvn("http://b.com/svn/b")),
    ]
    expected = [os.path.join(root, "packages", "a_package"),
                os.path.join(root, "packages", "b_package")]

# Generated at 2022-06-24 03:09:01.802841
# Unit test for function join_each
def test_join_each():
    orig_iterable = ['file', 'dir/']
    result = join_each('/somepath', orig_iterable)
    assert list(result) == [
        '/somepath/file', '/somepath/dir/'
    ], "Got wrong result"



# Generated at 2022-06-24 03:09:07.291568
# Unit test for function join_each
def test_join_each():
    actual = ["/foo/bar", "/foo/baz", "/foo/qux", "/foo/quux"]
    expected = list(join_each("/foo", ["bar", "baz", "qux", "quux"]))
    assert actual == expected

# Generated at 2022-06-24 03:09:13.032400
# Unit test for function join_each
def test_join_each():
    p = "/home/tarkus"

    ip = join_each(p, ["foo", "bar"])
    print(list(ip))

    ip = join_each(p, ["foo", "bar", "", "baz"])
    print(list(ip))


# Filter out files that don't match wildcard

# Generated at 2022-06-24 03:09:20.970242
# Unit test for function join_each
def test_join_each():
    from functools import partial
    from operator import eq
    from parameters import param
    from itertools import product, islice
    from goody import irange

    print('Testing join_each')
    jee = partial(list, map(partial(os.path.join, 'par'), ['one','two','three']))
    for i in irange(10):
        assert eq(list(join_each('par', ['one','two','three'])),jee())


    # Feel free to add additional tests
    
    


# Generated at 2022-06-24 03:09:27.509664
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['foo', 'bar'])) == ['/tmp/foo', '/tmp/bar']



# Generated at 2022-06-24 03:09:35.398009
# Unit test for function join_each
def test_join_each():
    """
    Test join_each
    """
    # Test with a list
    child = ['child1', 'child2', 'child3']
    result = join_each('parent', child)
    res = ["parent" + os.sep + 'child1',
           "parent" + os.sep + 'child2',
           "parent" + os.sep + 'child3']
    assert res == list(result)

    # Test with a empty list
    child = []
    result = join_each('parent', child)
    res = []
    assert res == list(result)


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:09:37.298230
# Unit test for function join_each
def test_join_each():
    assert list(join_each('base', 'abc')) == ['base/a', 'base/b', 'base/c']



# Generated at 2022-06-24 03:09:40.639276
# Unit test for function join_each
def test_join_each():
    expected = [
        "a/b/c",
        "a/b/d"
    ]
    assert list(join_each("a/b", ["c", "d"])) == expected



# Generated at 2022-06-24 03:09:42.988904
# Unit test for function join_each
def test_join_each():
    assert list(join_each(
        "path",
        ["a", "b", "c"]
    )) == ["path/a", "path/b", "path/c"]

# Generated at 2022-06-24 03:09:44.706153
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']

# Generated at 2022-06-24 03:09:46.288461
# Unit test for function join_each
def test_join_each():
    assert os.path.join('a', 'b') in join_each('a', ['b', 'c'])



# Generated at 2022-06-24 03:09:49.865998
# Unit test for function join_each
def test_join_each():
    parent = '/some/path'
    iterable = ['/child1', '/child2/child1', '/child2/child2']
    expected = ['/some/path/child1', '/some/path/child2/child1', '/some/path/child2/child2']
    assert expected == list(join_each(parent, iterable))

# Generated at 2022-06-24 03:09:57.326451
# Unit test for function join_each
def test_join_each():
    parent = os.path.dirname(__file__)
    iterable = ('test_join_each.py', 'non-existing.py')
    expected = ('test_join_each.py', 'non-existing.py')
    for i, j in zip(join_each(parent, iterable), iterable):
        assert i == os.path.join(parent, j)
    else:
        assert j == expected[-1]

# Generated at 2022-06-24 03:10:00.144453
# Unit test for function join_each
def test_join_each():
    parent = 'temp'
    iterable = ['1.txt', '2.txt', '3.txt']
    expected = [os.path.join(parent, it) for it in iterable]
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:10:09.091232
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each(None, tuple())) == tuple()
    assert tuple(join_each(None, tuple((None, None)))) == tuple((None, None))
    assert tuple(join_each(None, tuple(('a', 'b')))) == tuple(('a', 'b'))
    assert tuple(join_each('', tuple(('a', 'b')))) == tuple(('a', 'b'))
    assert tuple(join_each('a', tuple(('a', 'b')))) == tuple(('a/a', 'a/b'))
    assert tuple(join_each('a', tuple(('', '')))) == tuple(('a/', 'a/'))
    assert tuple(join_each(1, tuple((1, 1)))) == tuple((1/1, 1/1))

# Generated at 2022-06-24 03:10:14.898173
# Unit test for function join_each
def test_join_each():
    home_folder = os.path.abspath(os.path.expanduser('~'))
    x, y, z = join_each(home_folder, ['a', 'b', 'c'])

    assert os.path.join(home_folder, 'a') == x
    assert os.path.join(home_folder, 'b') == y
    assert os.path.join(home_folder, 'c') == z



# Generated at 2022-06-24 03:10:17.235805
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-24 03:10:18.872345
# Unit test for function join_each
def test_join_each():
    assert list(join_each("./", ["foo", "bar"])) == ["./foo", "./bar"]



# Generated at 2022-06-24 03:10:25.136830
# Unit test for function join_each
def test_join_each():
    parent = 'home'
    iterable = ['usr', 'local', 'bin']
    assert list(join_each(parent, iterable)) == [
        'home/usr', 'home/local', 'home/bin']


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:10:28.764524
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['home', 'user'])) == [
        '/home', '/user'
    ]


# Since we're going to use both in our tests, let's wrap this in a fixture

# Generated at 2022-06-24 03:10:31.779425
# Unit test for function join_each
def test_join_each():
    assert list(join_each("", [])) == []
    assert list(join_each("asdf", ["ert", "rty"])) == ["asdf/ert", "asdf/rty"]



# Generated at 2022-06-24 03:10:35.567474
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['a', 'b', 'c']
    result = list(join_each(parent, iterable))
    assert result == ['parent\\a', 'parent\\b', 'parent\\c']



# Generated at 2022-06-24 03:10:36.944196
# Unit test for function join_each
def test_join_each():
    assert list(join_each('1', [2, 3])) == ['1/2', '1/3']

# Generated at 2022-06-24 03:10:39.267605
# Unit test for function join_each
def test_join_each():
    iterable = (('a', 'b'), ('c', 'd'))

    assert list(join_each('/tmp/', iterable)) == [
        '/tmp/a/b', '/tmp/c/d'
    ]



# Generated at 2022-06-24 03:10:41.515542
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b"])) == ["/tmp/a", "/tmp/b"]



# Generated at 2022-06-24 03:10:43.206648
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-24 03:10:58.672503
# Unit test for function join_each
def test_join_each():
    assert list(join_each('./foo', ['./bar', 'baz'])) == ['./foo/./bar', './foo/baz']


patterns = [
    ['./', ['../', '././', './']],
    ['../', ['.././', '../', '.././']],
    ['./tmp', ['../tmp']],
    ['../tmp/', ['../tmp/']],
    ['tmp/', ['tmp/']],
    ['../tmp', ['../tmp']],
    ['tmp', ['tmp']],
]



# Generated at 2022-06-24 03:11:01.668679
# Unit test for function join_each
def test_join_each():
    a = join_each("some_path", ("a", "b", "c"))
    print(a)
    assert list(a) == ["some_path/a", "some_path/b", "some_path/c"]
    b = join_each("some_path/", ("a", "b", "c"))
    assert list(b) == ["some_path/a", "some_path/b", "some_path/c"]



# Generated at 2022-06-24 03:11:02.934922
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['tmp', 'var'])) == list((os.path.join('/', 'tmp'), os.path.join('/', 'var')))



# Generated at 2022-06-24 03:11:05.732948
# Unit test for function join_each
def test_join_each():
    parent = "tmp"
    iterable = ["bar", "baz", "qux"]
    actual = list(join_each(parent, iterable))
    expected = map(lambda p: os.path.join(parent, p), iterable)

    assert actual == list(expected)



# Generated at 2022-06-24 03:11:11.896328
# Unit test for function join_each
def test_join_each():
    parent = b"blah"
    iterable = (b"hi", b"hey")
    result = join_each(parent, iterable)
    assert isinstance(result, abc.Iterable)
    assert list(result) == [b"blah\\hi", b"blah\\hey"]

# Generated at 2022-06-24 03:11:17.154460
# Unit test for function join_each
def test_join_each():
    assert list(join_each("test", ("1", "2", "3"))) == [
        os.path.join("test", "1"),
        os.path.join("test", "2"),
        os.path.join("test", "3"),
    ]



# Generated at 2022-06-24 03:11:18.791259
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:11:24.650178
# Unit test for function join_each
def test_join_each():
    print()
    print(list(join_each("parent", ["child1", "child2", "child3", "child4"])))
    print()


# Main function
if __name__ == "__main__":
    # test_join_each()
    
    pass
else:
    pass

# Generated at 2022-06-24 03:11:25.990754
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/', ('etc', 'usr', 'local'))) == ('/etc', '/usr', '/local')

# Generated at 2022-06-24 03:11:33.011705
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['/etc', '/var'])) == ['/usr/etc', '/usr/var']
    assert list(join_each('/usr', ['/etc/bashrc', '/var/syslog'])) == ['/usr/etc/bashrc', '/usr/var/syslog']



# Generated at 2022-06-24 03:11:37.563857
# Unit test for function join_each
def test_join_each():
    from nose.tools import eq_
    a = list(join_each('a', ('b', 'c')))
    eq_(a[0], 'a/b')
    eq_(a[1], 'a/c')



# Generated at 2022-06-24 03:11:40.070246
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/usr', ('bin', 'lib')))
    assert result == ['/usr/bin', '/usr/lib']



# Generated at 2022-06-24 03:11:42.679584
# Unit test for function join_each
def test_join_each():
    assert join_each('A', ['B', 'C']) == ['A/B', 'A/C']



# Generated at 2022-06-24 03:11:47.657088
# Unit test for function join_each
def test_join_each():
    parent = '/a/b/c'
    iterable = ['a', 'b', 'c' ]
    expect = ['/a/b/c/a', '/a/b/c/b', '/a/b/c/c' ]

    expect_gen = (e for e in expect)

    for observed, expect in zip(join_each(parent, iterable), expect_gen):
        assert observed == expect




# Generated at 2022-06-24 03:11:52.346058
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['test1', 'test2', 'test3', 'test4']
    expected_return = [
        'parent/test1',
        'parent/test2',
        'parent/test3',
        'parent/test4'
    ]
    assert(
        list(join_each(parent, iterable)) == expected_return
    )

# Generated at 2022-06-24 03:11:55.745047
# Unit test for function join_each
def test_join_each():
    test_string = os.path.join("a", "b")
    assert [test_string] == list(join_each("a", ["b"]))



# Generated at 2022-06-24 03:11:59.293222
# Unit test for function join_each
def test_join_each():
    parent = 'test'
    iterable = ('a', 'b', 'c')
    expected = ('test/a', 'test/b', 'test/c')
    assert list(join_each(parent, iterable)) == expected
# ---- end of join_each ----



# Generated at 2022-06-24 03:12:04.684025
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/user", ["data", "logs"])) == [
        "/home/user/data",
        "/home/user/logs",
    ]



# Generated at 2022-06-24 03:12:09.301270
# Unit test for function join_each
def test_join_each():
    parent = 'test'
    iterable = ('a', 'b', 'c')
    tuples = map(lambda x: (parent, x), iterable)
    assert set(join_each(parent, iterable)) == set(map(lambda t: os.path.join(*t), tuples))



# Generated at 2022-06-24 03:12:12.233619
# Unit test for function join_each
def test_join_each():
    assert list(join_each('C:\\', ['tmp', 'temp', 'tm'])) == [
        'C:\\tmp',
        'C:\\temp',
        'C:\\tm',
    ]



# Generated at 2022-06-24 03:12:14.035773
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c', 'd'])) == ['/a/b', '/a/c', '/a/d']



# Generated at 2022-06-24 03:12:17.777053
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/mrk/", ["projects", "programming", "gitlab/", "flask-restful/"])) == [
        "/home/mrk/projects", "/home/mrk/programming",
        "/home/mrk/gitlab/", "/home/mrk/flask-restful/"
    ]


if __name__ == "__main__":
    from sys import argv
    test_join_each()
    print("Tests Passed")

# Generated at 2022-06-24 03:12:18.831587
# Unit test for function join_each
def test_join_each():
    joined = list(join_each('foo', ['bar', 'baz']))
    assert joined == ['foo\\bar', 'foo\\baz']

# Generated at 2022-06-24 03:12:20.686721
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/ubuntu", ["a", "b", "c"])) == ["/home/ubuntu/a", "/home/ubuntu/b", "/home/ubuntu/c"]



# Generated at 2022-06-24 03:12:30.399422
# Unit test for function join_each
def test_join_each():
    iterable = join_each('data', ['a', 'b', 'c'])
    assert list(iterable) == ['data/a', 'data/b', 'data/c']
    iterable = join_each('data/', ['a', 'b', 'c'])
    assert list(iterable) == ['data/a', 'data/b', 'data/c']

# Generated at 2022-06-24 03:12:33.316819
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/root/', ['a', 'b', 'c'])) == ['/root/a', '/root/b', '/root/c']



# Generated at 2022-06-24 03:12:36.754370
# Unit test for function join_each
def test_join_each():
    assert list(join_each('path/to', ['file1', 'file2'])) == ['path/to/file1', 'path/to/file2']



# Generated at 2022-06-24 03:12:41.978044
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/bin", ["ls", "cp", "mv"])) == [
        "/bin/ls",
        "/bin/cp",
        "/bin/mv",
    ]



# Generated at 2022-06-24 03:12:45.894596
# Unit test for function join_each
def test_join_each():
    parent = os.path.dirname(os.path.abspath(__file__))
    for i, p in enumerate(join_each(parent, ["module1.py", "module2.py"])):
        assert p == os.path.join(parent, [
            "module1.py", "module2.py"][i])


if __name__ == "__main__":
    import sys
    import inspect

    if "--test" in sys.argv:
        test_join_each()
    else:
        print(os.path.abspath(inspect.getfile(inspect.currentframe())))

# Generated at 2022-06-24 03:12:49.782669
# Unit test for function join_each
def test_join_each():
    import pytest
    assert list(join_each('/tmp', ['foo', 'bar', 'baz'])) == ['/tmp/foo', '/tmp/bar', '/tmp/baz']
    with pytest.raises(TypeError):
        list(join_each('/tmp', 'spam'))
    with pytest.raises(TypeError):
        list(join_each(['spam', 'eggs'], 'foo'))

# Generated at 2022-06-24 03:12:52.102294
# Unit test for function join_each
def test_join_each():
    parent_path = "C:/Project"
    test_iterable = ["Tools", "Editor"]
    test_expected_list = ["C:/Project/Tools", "C:/Project/Editor"]

    test_result_list = list(join_each(parent_path, test_iterable))

    assert test_expected_list == test_result_list

    pass

# Generated at 2022-06-24 03:12:54.324049
# Unit test for function join_each
def test_join_each():
    assert [p for p in join_each('dir1', ['dir2', 'dir3'])] == ['dir1/dir2', 'dir1/dir3']

# Generated at 2022-06-24 03:12:56.288449
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['usr', 'share', 'man'])) == ['/usr', '/share', '/man']

# Generated at 2022-06-24 03:12:57.756027
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/x', ['a', 'b'])) == ['/x/a', '/x/b']

# Generated at 2022-06-24 03:13:00.701724
# Unit test for function join_each
def test_join_each():
    input: Iterable[str] = ["a", "b"]
    result: Iterable[str] = join_each("base", ["a", "b"])
    assert result == ["base/a", "base/b"]


# Reads version information from a version file

# Generated at 2022-06-24 03:13:07.174062
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/bin', ['python', 'python3'])) == \
        ['/usr/bin/python', '/usr/bin/python3']
    assert list(join_each('/usr/bin', [])) == []
    assert list(join_each('/usr/bin', ['python'])) == ['/usr/bin/python']



# Generated at 2022-06-24 03:13:10.008303
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b", "c"])) == [
        "/tmp/a",
        "/tmp/b",
        "/tmp/c",
    ]

# Generated at 2022-06-24 03:13:14.989418
# Unit test for function join_each
def test_join_each():
    # Arrange
    parent_directory = 'test_path'
    test_paths = ('path', os.path.join('path', 'to'))

    # Act
    result = list(join_each(parent_directory, test_paths))

    # Assert
    expected_result = [
        'test_path/path',
        'test_path/path/to'
    ]
    assert result == expected_result



# Generated at 2022-06-24 03:13:18.015345
# Unit test for function join_each
def test_join_each():
    parent = os.path.abspath(__file__)
    iterable = ['aaa', 'bbb', 'ccc']
    actual = list(join_each(parent, iterable))
    expected = [os.path.join(parent, p) for p in iterable]
    assert actual == expected

# Generated at 2022-06-24 03:13:23.116340
# Unit test for function join_each
def test_join_each():
    parent = "/home/user"
    children = ["bin", "lib", "var"]
    expected = [
        "/home/user/bin",
        "/home/user/lib",
        "/home/user/var",
    ]
    assert list(join_each(parent, children)) == expected

# Generated at 2022-06-24 03:13:25.509295
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar'])) == ['/foo', '/bar']



# Generated at 2022-06-24 03:13:29.474793
# Unit test for function join_each
def test_join_each():

    assert list(join_each('/tmp', ['a', 'b'])) == ['/tmp/a', '/tmp/b']

    paths = ('/a/b/c', '/a/b/d', 'e/f')

    assert list(join_each('/tmp', paths)) == ['/tmp/' + x
                                              for x in paths]

# Generated at 2022-06-24 03:13:31.187371
# Unit test for function join_each
def test_join_each():
    assert list(join_each("h", ["el", "ell"])) == ["hel", "hell"]

# Generated at 2022-06-24 03:13:37.463808
# Unit test for function join_each
def test_join_each():
    parent = os.path.abspath(os.path.curdir)
    children = ["a", "b", "c"]
    assert list(join_each(parent, children)) == \
        [os.path.join(parent, c) for c in children]



# Generated at 2022-06-24 03:13:40.717895
# Unit test for function join_each
def test_join_each():
    assert list(join_each('one', ('two', 'three'))) == ['one/two', 'one/three']



# Generated at 2022-06-24 03:13:43.666085
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['.', '..', 'usr'])) == [
        '/.', '/..', '/usr']
    assert list(join_each('/', [])) == []



# Generated at 2022-06-24 03:13:48.285097
# Unit test for function join_each
def test_join_each():
    tests = [
        {'parent': '/foo', 'iterable': ['bar', 'baz'],
         'expected': ['/foo/bar', '/foo/baz']},
        {'parent': 'foo', 'iterable': [],
         'expected': []},
    ]
    for test in tests:
        assert list(join_each(test['parent'], iter(test['iterable']))) == \
            test['expected']



# Generated at 2022-06-24 03:13:52.847853
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/opt/foo/bar', ['a', 'b', 'c'])) == [
        '/opt/foo/bar/a', '/opt/foo/bar/b', '/opt/foo/bar/c']

    assert list(join_each('/opt', ['a', 'b', 'c'])) == [
        '/opt/a', '/opt/b', '/opt/c']