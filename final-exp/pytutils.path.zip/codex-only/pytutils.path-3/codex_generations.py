

# Generated at 2022-06-24 03:03:50.647704
# Unit test for function join_each
def test_join_each():
    test_path = '/temp/dir'
    test_iterable = ['a', 'b', 'c']

    test_result = [
        '/temp/dir/a',
        '/temp/dir/b',
        '/temp/dir/c'
    ]

    assert [x for x in join_each(test_path, test_iterable)] == test_result



# Generated at 2022-06-24 03:03:53.967268
# Unit test for function join_each
def test_join_each():
    # Arrange
    parent = os.path.dirname(__file__)
    expected = [__file__]

    # Act
    actual = list(join_each(parent, os.path.basename(__file__)))

    # Assert
    assert expected == actual



# Generated at 2022-06-24 03:03:56.201850
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child'])) == ['parent/child']



# Generated at 2022-06-24 03:03:57.574454
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['bin', 'lib'])) == ['/usr/bin', '/usr/lib']



# Generated at 2022-06-24 03:04:02.396857
# Unit test for function join_each
def test_join_each():
    parent = "foo"
    iterable = ["bar", "baz"]
    assert [os.path.join(parent, p) for p in iterable] == list(join_each(parent, iterable))



# Generated at 2022-06-24 03:04:04.542212
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['1', '2', '3'])) == [
        'foo/1', 'foo/2', 'foo/3']



# Generated at 2022-06-24 03:04:11.581982
# Unit test for function join_each
def test_join_each():
    parent = 'root'
    iterable = ['child1', 'child2']

    result = list(join_each(parent, iterable))

    assert result[0] == os.path.join(parent, iterable[0])
    assert result[1] == os.path.join(parent, iterable[1])

# Generated at 2022-06-24 03:04:17.820161
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child1', 'child2'])) == ['parent/child1', 'parent/child2']
    assert list(join_each('parent', [])) == []
    assert list(join_each('', ['child1', 'child2'])) == ['child1', 'child2']
    assert list(join_each('', [])) == []

# Generated at 2022-06-24 03:04:20.501471
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == [
        '/tmp/a',
        '/tmp/b',
        '/tmp/c'
    ]

# Generated at 2022-06-24 03:04:22.240196
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('/', [''])) == ['/'])



# Generated at 2022-06-24 03:04:27.351219
# Unit test for function join_each
def test_join_each():
    def join(parent, child):
        return os.path.join(parent, child)
    parent = os.path.dirname(__file__)
    children = ['a.txt', 'b.txt', 'c.txt']
    assert list(join_each(parent, children)) == [join(parent, c) for c in children]



# Generated at 2022-06-24 03:04:32.284628
# Unit test for function join_each
def test_join_each():
    assert list(join_each("parent", ["a", "b", "c"])) == \
           ["parent/a", "parent/b", "parent/c"]



# Generated at 2022-06-24 03:04:37.736841
# Unit test for function join_each
def test_join_each():
    iterable = [
        'a',
        'b',
        'c',
    ]
    expected = [
        '/home/a',
        '/home/b',
        '/home/c',
    ]
    actual = list(join_each('/home', iterable))
    assert expected == actual

# Generated at 2022-06-24 03:04:41.446049
# Unit test for function join_each
def test_join_each():
    parent = os.getcwd()
    last = os.path.join(os.path.basename(parent), 'build.py')
    basename = os.path.basename(parent)
    assert list(join_each(parent, ['build.py'])) == [last]
    assert list(join_each(basename, [])) == []



# Generated at 2022-06-24 03:04:44.956999
# Unit test for function join_each
def test_join_each():
    parent = "test/test_parent"
    children = ["todd", "todd", "todd", "todd", "todd"]
    join_list = ["test/test_parent/todd", "test/test_parent/todd",
                 "test/test_parent/todd", "test/test_parent/todd",
                 "test/test_parent/todd"]
    assert list(join_each(parent, children)) == join_list

# Generated at 2022-06-24 03:04:46.881799
# Unit test for function join_each
def test_join_each():
    assert list(join_each(None, [1, 2, 3])) == [1, 2, 3]



# Generated at 2022-06-24 03:04:53.171205
# Unit test for function join_each
def test_join_each():
    assert isinstance(join_each('/', ['a']), types.GeneratorType)
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']

# Generated at 2022-06-24 03:05:01.314916
# Unit test for function join_each
def test_join_each():
    # Test with invalid parent argument
    assert next(join_each(None, ['a', 'b', 'c'])) is None
    assert next(join_each('', ['a', 'b', 'c'])) is None
    assert next(join_each(' ', ['a', 'b', 'c'])) is None
    assert next(join_each(1, ['a', 'b', 'c'])) is None

    # Test with invalid child argument
    assert next(join_each('/etc', None)) is None
    assert next(join_each('/etc', [])) is None
    assert next(join_each('/etc', 1)) is None
    assert next(join_each('/etc', '')) is None
    assert next(join_each('/etc', ' ')) is None

    # Test with invalid parent and child arguments

# Generated at 2022-06-24 03:05:05.084092
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/var/log', ['foo', 'bar'])) == [
        '/var/log/foo',
        '/var/log/bar'
    ]



# Generated at 2022-06-24 03:05:06.869579
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/lhawthorn', ['Documents', 'Downloads'])) == \
            ['/home/lhawthorn/Documents', '/home/lhawthorn/Downloads']



# Generated at 2022-06-24 03:05:16.307836
# Unit test for function join_each
def test_join_each():
    # Create a temporary working directory
    with TemporaryDirectory() as d:
        # Navigate to the temporary directory
        with cd(d):
            # Check if test directory is empty:
            files_list = [f for f in os.listdir('.') if os.path.isfile(f)]
            assert files_list == []

            # Create a folder with some files inside:
            folder1 = 'folder1'
            path1 = 'path1'
            path2 = 'path2'
            os.mkdir(folder1)
            open(os.path.join(folder1, path1), 'a').close()
            open(os.path.join(folder1, path2), 'a').close()

            # Change current working directory

# Generated at 2022-06-24 03:05:18.100386
# Unit test for function join_each
def test_join_each():
    assert list(join_each('./', ['test', 'test2'])) == ['./test', './test2']



# Generated at 2022-06-24 03:05:22.088331
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) 

# Generated at 2022-06-24 03:05:26.454187
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', ['a'])) == ['/a']
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']
    assert list(join_each('/a', [])) == []


# Convert path to prefix and index
# path = '/a/b/c'
# prefix = '/a/b'
# index = 'c'

# Generated at 2022-06-24 03:05:34.736436
# Unit test for function join_each
def test_join_each():
    assert list(join_each("",""))==[]
    assert list(join_each("","a"))== ["a"]
    assert list(join_each("","a","b"))== ["a", "b"]
    assert list(join_each("","a","b","c"))== ["a", "b", "c"]
    assert list(join_each("a",""))==["a"]
    assert list(join_each("a","b"))== ["a/b"]
    assert list(join_each("a","b","c"))== ["a/b", "a/c"]
    assert list(join_each("a","b","c","d"))== ["a/b", "a/c", "a/d"]



# Generated at 2022-06-24 03:05:45.366578
# Unit test for function join_each

# Generated at 2022-06-24 03:05:50.890713
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/bin', ['a', 'b', 'c'])) == [
        '/usr/bin/a',
        '/usr/bin/b',
        '/usr/bin/c',
    ]



# Generated at 2022-06-24 03:05:56.838768
# Unit test for function join_each
def test_join_each():
    parent = "etc"
    iterable = ("passwd", "group")
    paths = join_each(parent, iterable)
    assert next(paths) == "etc/passwd"
    assert next(paths) == "etc/group"


iterable = ("passwd", "group")
paths = join_each("etc", iterable)
print(list(paths))  # Output: ['etc/passwd', 'etc/group']

# ----------------------------
print()



# Generated at 2022-06-24 03:06:00.407370
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ('b', 'c', 'd'))) == ['a/b', 'a/c', 'a/d']


# Text file generator (can be used together with join_each)

# Generated at 2022-06-24 03:06:03.660246
# Unit test for function join_each
def test_join_each():
    assert join_each('/', ['/b']) == '/b'



# Generated at 2022-06-24 03:06:12.091039
# Unit test for function join_each
def test_join_each():
    def join(parent, child):
        # builtin function os.path.join to check results
        return os.path.join(parent, child)

    parent = '/usr'
    for child in ['bin', 'local', 'lib']:
        assert join(parent, child) == next(join_each(parent, [child]))

    children = ['bin', 'local', 'lib']
    it = join_each(parent, children)
    for child in children:
        assert join(parent, child) == next(it)

# Generated at 2022-06-24 03:06:18.414714
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar', 'baz'])) == ['/foo', '/bar', '/baz']
    assert list(join_each('/foo', ['bar', 'baz'])) == ['/foo/bar', '/foo/baz']
    assert list(join_each('/foo/bar', ['baz', 'qux'])) == ['/foo/bar/baz', '/foo/bar/qux']



# Generated at 2022-06-24 03:06:23.836219
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    paths = ['one', 'two', 'three']
    assert list( join_each(parent, paths) ) == [
            '/home/one', '/home/two', '/home/three']



# Generated at 2022-06-24 03:06:26.588186
# Unit test for function join_each
def test_join_each():
    parent = '/Users/jeffreymiller'
    names = ['foo', 'bar']

    expected = [
        '/Users/jeffreymiller/foo',
        '/Users/jeffreymiller/bar',
    ]

    result = list(join_each(parent, names))

    assert expected == result



# Generated at 2022-06-24 03:06:29.728881
# Unit test for function join_each
def test_join_each():
    assert ['/path/to/foo', '/path/to/bar'] == list(join_each('/path/to', ['foo', 'bar']))

# Generated at 2022-06-24 03:06:36.995480
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', 'bar')) == ['foo/bar']
    assert list(join_each('foo/bar/baz', ['quux', 'qux'])) == ['foo/bar/baz/quux', 'foo/bar/baz/qux']
    assert list(join_each('foo/bar/baz', ['quux', 'qux'], 'blarg')) == ['foo/bar/baz/quux/blarg',
                                                                        'foo/bar/baz/qux/blarg']



# Generated at 2022-06-24 03:06:45.747234
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', ['file1', 'file2'])) == ['/home/user/file1', '/home/user/file2']
    assert list(join_each('/home/user/', ['file1', 'file2'])) == ['/home/user/file1', '/home/user/file2']
    assert list(join_each('/home/user', ['file1', 'file2', 'dir'])) == ['/home/user/file1', '/home/user/file2', '/home/user/dir']
    assert list(join_each('/', ['file1', 'file2', 'dir'])) == ['/file1', '/file2', '/dir']
    assert list(join_each('/', [])) == []

# Generated at 2022-06-24 03:06:47.783985
# Unit test for function join_each
def test_join_each():
    assert (list(join_each('/tmp', ('a', 'b'))) ==
            ['/tmp/a', '/tmp/b'])



# Generated at 2022-06-24 03:06:51.638124
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/', ['etc', 'dev']))
    assert result == ['/etc', '/dev']

    result = list(join_each('/', []))
    assert result == []

    result = list(join_each('/', ['etc/dev']))
    assert result == ['/etc/dev']



# Generated at 2022-06-24 03:06:52.932218
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr", ['local', 'bin'])) == ['/usr/local', '/usr/bin']



# Generated at 2022-06-24 03:06:55.985700
# Unit test for function join_each
def test_join_each():
    data = (
        'a',
        'b',
        'c'
    )
    parent = 'd'
    expected = (
        'd/a',
        'd/b',
        'd/c'
    )

    actual = join_each(parent, data)

    assert tuple(actual) == expected

# Generated at 2022-06-24 03:06:59.789989
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['tmp', 'var'])) == [
        '/tmp',
        '/var'
    ]



# Generated at 2022-06-24 03:07:03.134840
# Unit test for function join_each
def test_join_each():
    test_paths = ('test', 'test/test.txt', 'test/test.txt', '')
    result_paths = ('test', 'test/test.txt', 'test/test.txt', '')
    result = join_each('test', test_paths)
    assert list(result) == result_paths



# Generated at 2022-06-24 03:07:05.634259
# Unit test for function join_each
def test_join_each():
    iterable = ('1', '2', '3')
    parent = '.'
    expected = [os.path.join(parent, p) for p in iterable]
    assert expected == list(join_each(parent, iterable))

# Generated at 2022-06-24 03:07:07.422584
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['bar', 'baz'])) == ['/foo/bar', '/foo/baz']



# Generated at 2022-06-24 03:07:10.037130
# Unit test for function join_each
def test_join_each():
    parent = ''
    iterable = ['a', 'b', 'c']
    actual = join_each(parent, iterable)
    for each in actual:
        assert each in ['a', 'b', 'c']



# Generated at 2022-06-24 03:07:13.346888
# Unit test for function join_each
def test_join_each():
    parent = '/'
    assert list(join_each(parent, ['', 'usr', 'bin'])) == \
        ['/', '/usr', '/bin']
    assert list(join_each(parent, ['', 'home', 'imants'])) == \
        ['/', '/home', '/imants']

# Generated at 2022-06-24 03:07:14.297656
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ('bar', 'baz'))) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-24 03:07:19.880591
# Unit test for function join_each
def test_join_each():
    # test empty generator
    assert list(join_each('', [])) == []

    assert list(join_each('/', ['/a', '/b'])) == ['/a', '/b']
    assert list(join_each('/usr', ['local', 'include'])) == ['/usr/local', '/usr/include']

    assert list(join_each('/usr/local', ['..', 'bin'])) == ['/usr/local/..', '/usr/local/bin']
    with pytest.raises(ValueError):
        list(join_each('/usr/local', ['..', '..', 'bin']))



# Generated at 2022-06-24 03:07:24.669944
# Unit test for function join_each
def test_join_each():
    parent = "/foo/bar"
    listA = ["a", "b", "c"]
    listB = ["a", "", "c"]
    listC = []
    assert list(join_each(parent, listA)) == ["/foo/bar/a", "/foo/bar/b", "/foo/bar/c"]
    assert list(join_each(parent, listB)) == ["/foo/bar/a", "/foo/bar/c"]
    assert list(join_each(parent, listC)) == []

# Generated at 2022-06-24 03:07:27.970489
# Unit test for function join_each
def test_join_each():
	assert list(join_each('/tmp', ('/foo', '/bar/baz'))) == [
		'/tmp/foo',
		'/tmp/bar/baz'
	]



# Generated at 2022-06-24 03:07:29.187635
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', ['spam', 'eggs'])) == \
        ['/home/user/spam', '/home/user/eggs']

# Generated at 2022-06-24 03:07:35.857136
# Unit test for function join_each
def test_join_each():
    # Test case 1
    assert list(join_each('/home/', ['tomoaki', 'tetsuro'])) \
        == ['/home/tomoaki', '/home/tetsuro']

    # Test case 2
    assert list(join_each('.', ['a', 'b', 'c'])) \
        == ['./a', './b', './c']

# Generated at 2022-06-24 03:07:37.508880
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["etc", "passwd"])) == ["/etc", "/passwd"]

# Generated at 2022-06-24 03:07:48.151764
# Unit test for function join_each
def test_join_each():
    first = os.path.join(os.environ['HOME'], "Desktop")
    second = os.path.join(os.environ['HOME'], "Documents")
    iterable = ["tmp", "test"]
    assert list(join_each(first, iterable)) == [
        os.path.join(first, "tmp"), os.path.join(first, "test")
    ]
    assert list(join_each(second, iterable)) == [
        os.path.join(second, "tmp"), os.path.join(second, "test")
    ]


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-24 03:07:55.546695
# Unit test for function join_each
def test_join_each():
    assert next(iter(join_each('/home', []))) == '/home'
    assert next(iter(join_each('/home', ['.bashrc']))) == '/home/.bashrc'
    files = ['.bashrc', '.bash_profile']
    for idx, f in enumerate(join_each('/home', files)):
        assert f == os.path.join('/home', files[idx])



# Generated at 2022-06-24 03:08:00.432807
# Unit test for function join_each
def test_join_each():
    parent_dir = "/home/steve"
    paths = ["dir1", "dir2", "dir3"]
    
    expected = ["/home/steve/dir1", "/home/steve/dir2", "/home/steve/dir3"]
    actual = list(join_each(parent_dir, paths))
        
    assert(expected==actual)



# Generated at 2022-06-24 03:08:05.315283
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', ['test', 'file.txt'])) == \
        ['/home/user/test', '/home/user/file.txt']



# Generated at 2022-06-24 03:08:06.810929
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['1', '2', '3'])) == ['foo/1', 'foo/2', 'foo/3']



# Generated at 2022-06-24 03:08:14.788333
# Unit test for function join_each
def test_join_each():
    parent = '/path/to/parent'
    children = ['child1', 'child2/child2-1']
    expected = ['/path/to/parent/child1',
                '/path/to/parent/child2/child2-1']

    result = list(join_each(parent, children))

    assert len(result) == len(expected)
    assert all(el1 == el2
               for el1, el2 in zip(result, expected))

# Generated at 2022-06-24 03:08:24.716755
# Unit test for function join_each
def test_join_each():
    # Test 1
    test_join_each1 = ""
    assert next(join_each("", [""])) == test_join_each1  # expected "". Actual: "".
    assert next(join_each("", [""])) != ""  # expected "". Actual: "".

    # Test 2
    test_join_each2 = ""
    assert next(join_each("", [""])) == test_join_each2  # expected "". Actual: "".
    assert next(join_each("", [""])) != ""  # expected "". Actual: "".

    # Test 3
    test_join_each3 = ""
    assert next(join_each("", [""])) == test_join_each3  # expected "". Actual: "".
    assert next(join_each("", [""])) != ""  # expected "".

# Generated at 2022-06-24 03:08:30.625909
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ('child1', 'child2', 'child3')
    actual = tuple(join_each(parent, iterable))
    expected = tuple(os.path.join(parent, p) for p in iterable)
    assert actual == expected



# Generated at 2022-06-24 03:08:34.654340
# Unit test for function join_each
def test_join_each():
    assert list(join_each(u's', [u'a', u'b'])) == [u's/a', u's/b']

# Generated at 2022-06-24 03:08:38.283475
# Unit test for function join_each
def test_join_each():
    path = '/home/dummy'
    assert list(join_each(path, ['/etc', '/var'])) == ['/home/dummy/etc',
                                                       '/home/dummy/var']
    assert list(join_each(path, ['../bin', '..', '/boot'])) \
        == ['/home/dummy/../bin', '/home/dummy/..', '/home/dummy/boot']



# Generated at 2022-06-24 03:08:41.572729
# Unit test for function join_each
def test_join_each():
    path = "test/test_file/path"
    paths = ["1.txt", "2.txt", "3.txt"]
    for p, true_path in zip(join_each(path, paths),
                            [os.path.join(path, p) for p in paths]):
        assert p == true_path

# Generated at 2022-06-24 03:08:43.261180
# Unit test for function join_each
def test_join_each():
    assert (list(join_each('/', ('a', 'b'))) ==
            ['/a', '/b'])



# Generated at 2022-06-24 03:08:47.883504
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["abc", "def"])) == ["/abc", "/def"]

# Generated at 2022-06-24 03:08:50.929767
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['part1', 'part2'])) == [
        '/tmp/part1',
        '/tmp/part2'
    ]



# Generated at 2022-06-24 03:08:55.629050
# Unit test for function join_each
def test_join_each():
    parent = utils.get_random_string()
    paths = [(utils.get_random_string(), utils.get_random_string())
             for _ in range(3)]
    joined = list(join_each(parent, [p for p, _ in paths]))
    for j, (_, path) in zip(joined, paths):
        assert parent in j
        assert path in j



# Generated at 2022-06-24 03:08:59.902809
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child1', 'child2'])) == [
        'parent/child1', 'parent/child2']

# Generated at 2022-06-24 03:09:02.947746
# Unit test for function join_each
def test_join_each():
    assert list(join_each(os.path.abspath(os.sep), ['a', 'b'])) == [
        os.path.join(os.path.abspath(os.sep), 'a'),
        os.path.join(os.path.abspath(os.sep), 'b')
    ]



# Generated at 2022-06-24 03:09:07.776736
# Unit test for function join_each
def test_join_each():
    assert list(join_each("", ["a", "b"])) == ["a", "b"]
    assert list(join_each("", ["", "", ""])) == ["", "", ""]
    assert list(join_each("x", ["a", "b"])) == ["x\\a", "x\\b"]



# Generated at 2022-06-24 03:09:11.375239
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['home', 'daniele'])) == [
        '/home', '/daniele'
    ]

# Generated at 2022-06-24 03:09:15.297812
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['path1', 'path2'])) == ['/path1', '/path2']
    assert list(join_each('c:/', ['path1', 'path2'])) == ['c:/path1',
                                                         'c:/path2']



# Generated at 2022-06-24 03:09:18.182288
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/path', ['dir1', 'dir2'])) == \
            ['/path/dir1', '/path/dir2']
    assert list(join_each('/path', [])) == []

# Generated at 2022-06-24 03:09:28.410625
# Unit test for function join_each
def test_join_each():
    assert list(join_each('', ['', '1', '2'])) == ['', '1', '2']
    assert list(join_each('/', ['/', '1', '2'])) == ['/', '/1', '/2']
    assert list(join_each('/', ['1', '2'])) == ['/1', '/2']
    assert list(join_each('/', ['1/', '2'])) == ['/1/', '/2']
    assert list(join_each('/', ['1/', '2/'])) == ['/1/', '/2/']
    assert list(join_each('/', ['/1/', '2/'])) == ['/1/', '/2/']

# Generated at 2022-06-24 03:09:32.111835
# Unit test for function join_each
def test_join_each():
    parent_folder = os.path.join(os.getcwd(), 'data')
    file_names = ['test1.txt', 'test2.txt']
    res = join_each(parent_folder, file_names)
    assert res

# Generated at 2022-06-24 03:09:36.236331
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["usr", "bin"])) == [
        "/usr",
        "/bin",
    ]
    assert list(join_each("/", ["usr", "bin/"])) == ["/usr", "/bin"]
    assert list(join_each("/", ["usr", "/bin"])) == ["/usr", "/bin"]



# Generated at 2022-06-24 03:09:38.138722
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == ['/tmp/a', '/tmp/b', '/tmp/c']


# Generated at 2022-06-24 03:09:43.707101
# Unit test for function join_each
def test_join_each():
    parent = 'foo'
    iterable = ['bar', 'baz', 'qux']

    expected = iter(['foo/bar', 'foo/baz', 'foo/qux'])
    result = join_each(parent, iterable)
    assert all(p1 == p2 for (p1, p2) in zip(expected, result))



# Generated at 2022-06-24 03:09:48.000300
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/a', ('b', 'c', 'd')))
    assert result == ['/a/b', '/a/c', '/a/d']
    result = list(join_each('a', ('b', 'c', 'd')))
    assert result == ['a/b', 'a/c', 'a/d']



# Generated at 2022-06-24 03:09:52.714953
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['/a', '/b', '/c'])) == ['/a', '/b', '/c']
    assert \
        list(join_each('/', ['/a', '/b', '/c'])) == ['/a', '/b', '/c']

# Generated at 2022-06-24 03:10:00.211052
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ['c', 'd'])) == ['/a/b/c', '/a/b/d']
    assert list(join_each('/a/b', ['c'])) == ['/a/b/c']
    assert list(join_each('/a/b', [])) == []
    assert list(join_each('/a/b', ['c/d'])) == ['/a/b/c/d']
    assert list(join_each('/a/b', ['c', 'd/e'])) == ['/a/b/c', '/a/b/d/e']



# Generated at 2022-06-24 03:10:04.159343
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', 'b')) == ['a/b']
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:10:09.943435
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["d1", "d2", "d3"])) == ['/tmp/d1', '/tmp/d2', '/tmp/d3']



# Generated at 2022-06-24 03:10:13.978874
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/tmp', ['a', 'b', 'c']))
    print(result)
    assert result == ['/tmp/a', '/tmp/b', '/tmp/c']
    print('test pass')


test_join_each()

# Generated at 2022-06-24 03:10:17.539237
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/guido', ['foo', 'bar', 'qux'])) == [
        '/home/guido/foo',
        '/home/guido/bar',
        '/home/guido/qux']

# Generated at 2022-06-24 03:10:19.336953
# Unit test for function join_each
def test_join_each():
    seq = ['a', 'b', 'c']
    assert list(join_each('A', seq)) == ['A/a', 'A/b', 'A/c']



# Generated at 2022-06-24 03:10:26.057811
# Unit test for function join_each
def test_join_each():
    parent = 'foo'
    relpaths = ['bar', 'baz', 'buzz']
    nt.assert_list_equal(list(join_each(parent, relpaths)),
                         ['foo/bar', 'foo/baz', 'foo/buzz'])


# Generated at 2022-06-24 03:10:28.888319
# Unit test for function join_each
def test_join_each():
    sample = 'test'
    assert list(join_each(sample, [sample])) == ['test/test']


# --- Functions for finding files and directories ---

# Generated at 2022-06-24 03:10:33.130168
# Unit test for function join_each
def test_join_each():
    parent = '/etc'
    iterable = [
        'hosts',
        'resolv.conf',
        'localtime',
    ]

    assert sorted(join_each(parent, iterable)) == [
        '/etc/hosts',
        '/etc/localtime',
        '/etc/resolv.conf',
    ]



# Generated at 2022-06-24 03:10:35.672131
# Unit test for function join_each
def test_join_each():
    actual = list(join_each("dir", ["f1", "f2", "f3"]))
    expected = ["dir/f1", "dir/f2", "dir/f3"]
    assert actual == expected



# Generated at 2022-06-24 03:10:43.006791
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', 'abc')) == ['parent/a', 'parent/b', 'parent/c']
    assert list(join_each('parent', 'ab')) == ['parent/a', 'parent/b']
    assert list(join_each('parent', '')) == []



# Generated at 2022-06-24 03:10:55.290789
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child1', 'child2'])) == ['parent/child1', 'parent/child2']

# Generated at 2022-06-24 03:10:57.315215
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['bin', 'usr'])) == ['/home/bin', '/home/usr']



# Generated at 2022-06-24 03:11:02.190176
# Unit test for function join_each
def test_join_each():
    tests = [
        ["/a/b/c", ["d", "e"]],
        ["/a/b/c", ["d"]],
        ["/a/b/c", []],
        ["", ["d", "e"]],
        ["", ["d"]],
        ["", []]
    ]
    expected = [
        ["/a/b/c/d", "/a/b/c/e"],
        ["/a/b/c/d"],
        [],
        ["/d", "/e"],
        ["/d"],
        []
    ]

# Generated at 2022-06-24 03:11:03.740213
# Unit test for function join_each
def test_join_each():
    assert [p for p in join_each("/test", [
        "a", "b", "c"
    ])] == [
        "/test/a",
        "/test/b",
        "/test/c",
    ]



# Generated at 2022-06-24 03:11:06.058506
# Unit test for function join_each
def test_join_each():
    parent = 'blah'
    iterable = ['a', 'b', 'c']
    expected = ['blah/a', 'blah/b', 'blah/c']
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-24 03:11:08.112721
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == [
        '/tmp/a', '/tmp/b', '/tmp/c'
    ]



# Generated at 2022-06-24 03:11:10.089478
# Unit test for function join_each
def test_join_each():
    dir_name = "/path/to/some/dir"

    for f in join_each(dir_name, ["file1", "file2"]):
        assert f.startswith(dir_name)



# Generated at 2022-06-24 03:11:12.029493
# Unit test for function join_each
def test_join_each():
    iterable = ["good", "bad", "ugly"]
    path = "/home"
    joineach = join_each(path, iterable)
    assert "/home/good" in joineach
    assert "/home/bad" in joineach

# Generated at 2022-06-24 03:11:15.238386
# Unit test for function join_each
def test_join_each():
    parent = pathlib.Path("/foo/bar")
    iterable = ["a", "b", "c", "d", "e"]
    expected = join_each("/foo/bar", ["a", "b", "c", "d", "e"])
    actual = [item for item in join_each(parent, iterable)]
    assert len(expected) == len(actual)
    assert all(
        x == y for x, y in zip(
            expected, actual
            )
        )

# Generated at 2022-06-24 03:11:19.766729
# Unit test for function join_each
def test_join_each():
    assert list(join_each("test", ["a", "b", "c"])) == ["test/a", "test/b", "test/c"]



# Generated at 2022-06-24 03:11:24.310352
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["foo", "bar"])) == [
        "/tmp/foo", "/tmp/bar"
    ]



# Generated at 2022-06-24 03:11:28.116843
# Unit test for function join_each
def test_join_each():
    assert list(join_each(".", [''])) == ['.' + os.sep]
    assert list(join_each("/", ['/'])) == ["/"]
    assert list(join_each("..", ['a', 'b', 'c'])) == ['..' + os.sep + 'a', '..' + os.sep + 'b', '..' + os.sep + 'c']

# Generated at 2022-06-24 03:11:29.254004
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/', ['local', 'bin'])) == ['/usr/local', '/usr/bin']



# Generated at 2022-06-24 03:11:30.599088
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', [])) == []
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-24 03:11:33.320413
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b/c"])) == ['/tmp/a', '/tmp/b/c']



# Generated at 2022-06-24 03:11:37.109910
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child1', 'child2', 'child3'])) == ['parent/child1', 'parent/child2', 'parent/child3']



# Generated at 2022-06-24 03:11:40.827938
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/alice", ["aa", "bb", "cc"])) == [
        "/home/alice/aa",
        "/home/alice/bb",
        "/home/alice/cc",
    ]



# Generated at 2022-06-24 03:11:42.740383
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/graham', ['foo', 'bar'])) == ['/home/graham/foo', '/home/graham/bar']



# Generated at 2022-06-24 03:11:47.670972
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]



# Generated at 2022-06-24 03:11:52.040107
# Unit test for function join_each
def test_join_each():
    parent = "some/folder"
    iterable = ['foo', 'bar']
    result = join_each(parent, iterable)

    assert isinstance(result, types.GeneratorType)
    assert list(result) == [
        os.path.join(parent, "foo"),
        os.path.join(parent, "bar"),
    ]

# Generated at 2022-06-24 03:11:57.541820
# Unit test for function join_each
def test_join_each():
    examples = (
        ("/parent/", ("one", "two", "three")),
        ("", ("one", "two", "three")),
        ("/parent/", ()),
        ("", ()),
    )
    for parent, children in examples:
        assert list(join_each(parent, children)) == [
            os.path.join(parent, child) for child in children
        ]



# Generated at 2022-06-24 03:11:59.823790
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:12:04.683876
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b'])) == ['/tmp/a', '/tmp/b']
    assert list(join_each('/tmp/a/b', [])) == []



# Generated at 2022-06-24 03:12:09.696969
# Unit test for function join_each
def test_join_each():
    parent = "images"
    iterable = ["happy.png", "sad.png"]
    actual = list(join_each(parent, iterable))
    assert len(actual) == 2
    assert actual[0] == "images/happy.png"
    assert actual[1] == "images/sad.png"



# Generated at 2022-06-24 03:12:16.132014
# Unit test for function join_each
def test_join_each():
    iterable = ['s1', 's2', 's3']
    parent = 'parent'
    expected = ['parent/s1', 'parent/s2', 'parent/s3']
    result = list(join_each(parent, iterable))
    assert result == expected



# Generated at 2022-06-24 03:12:21.389681
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/parent', ['a', 'b', 'c'])) == [
        '/parent/a', '/parent/b', '/parent/c']



# Generated at 2022-06-24 03:12:24.180567
# Unit test for function join_each
def test_join_each():
    dirs = ['dir1', 'dir2', 'dir3']
    assert list(join_each('parent', dirs)) == ['parent/dir1', 'parent/dir2', 'parent/dir3']


# Returns number of files in the given path

# Generated at 2022-06-24 03:12:31.008507
# Unit test for function join_each
def test_join_each():
    assert list(join_each('', [])) == []
    assert list(join_each('a', [])) == []
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a/b', [])) == []
    assert list(join_each('a/b', ['c', 'd'])) == ['a/b/c', 'a/b/d']



# Generated at 2022-06-24 03:12:37.442597
# Unit test for function join_each
def test_join_each():
    p = "/tmp"
    i = ["foo", "bar"]
    assert os.path.join(p, i[0]) in join_each(p, i)
    assert os.path.join(p, i[1]) in join_each(p, i)

# Generated at 2022-06-24 03:12:42.010325
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/bin', ['ls', 'cat', 'cp'])) == ['/usr/bin/ls', '/usr/bin/cat', '/usr/bin/cp']



# Generated at 2022-06-24 03:12:43.027224
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:12:44.951196
# Unit test for function join_each
def test_join_each():
    actual = list(join_each('parent', 'child1 child2'.split(' ')))
    expected = 'parent/child1 parent/child2'.split(' ')
    assert expected == actual, 'Expected %s, got %s' % (expected, actual)



# Generated at 2022-06-24 03:12:48.865868
# Unit test for function join_each
def test_join_each():
    base_dir = os.getcwd()
    dirs = ['dir1', 'dir2']
    std = [
        os.path.join(base_dir, 'dir1'),
        os.path.join(base_dir, 'dir2')
    ]
    test = list(join_each(os.getcwd(), dirs))
    assert test == std



# Utility function to make a directory tree

# Generated at 2022-06-24 03:12:54.183633
# Unit test for function join_each
def test_join_each():
    # Make sure this works as expected with a list
    assert list(join_each('.', ['a', 'b', 'c'])) == ['a', 'b', 'c']
    assert list(join_each(None, ['a', 'b', 'c'])) == ['a', 'b', 'c']
    assert list(join_each('.', [])) == []
    # Make sure it works as expected with a generator
    assert list(join_each('.', (x for x in 'abc'))) == ['a', 'b', 'c']
    assert list(join_each(None, (x for x in 'abc'))) == ['a', 'b', 'c']
    assert list(join_each('.', (x for x in ''))) == []



# Generated at 2022-06-24 03:12:56.771285
# Unit test for function join_each
def test_join_each():
    iterable = ('a', 'b', 'c')
    result = join_each('/', iterable)
    expected = ('/a', '/b', '/c')
    assert tuple(result) == expected



# Generated at 2022-06-24 03:12:59.366284
# Unit test for function join_each
def test_join_each():
    a = ['b', 'c', 'd']
    parent = 'a'
    iterable = ['b', 'c', 'd']
    assert list(join_each(parent, iterable)) == a



# Generated at 2022-06-24 03:13:05.754513
# Unit test for function join_each
def test_join_each():
    from nose.tools import assert_equals
    assert_equals(
        list(join_each('/usr/lib',
            ['python', 'python3', 'pypy'])),
        ['/usr/lib/python', '/usr/lib/python3', '/usr/lib/pypy'])

# Generated at 2022-06-24 03:13:07.267709
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]



# Generated at 2022-06-24 03:13:16.114688
# Unit test for function join_each
def test_join_each():
    # Create a temp directory
    temp_dir = tempfile.mkdtemp()
    with open(os.path.join(temp_dir, 'file1'), 'w') as fd:
        pass
    with open(os.path.join(temp_dir, 'file2'), 'w') as fd:
        pass
    with open(os.path.join(temp_dir, 'file3'), 'w') as fd:
        pass
    with open(os.path.join(temp_dir, 'file4'), 'w') as fd:
        pass

    joined_paths = list(join_each(temp_dir, ['file1', 'file2', 'file3', 'file4']))
    for path in joined_paths:
        assert os.path.exists(path)
        os.remove(path)

# Generated at 2022-06-24 03:13:21.878735
# Unit test for function join_each
def test_join_each():
    assert join_each("/usr/local/bin", ["ls", "rm", "cat"]) == ["/usr/local/bin/ls", "/usr/local/bin/rm", "/usr/local/bin/cat"]


if __name__ == '__main__':
    path = "/usr/bin"
    files = os.listdir(path)

    # Print the content of /usr/bin directory
    print("ls /usr/bin")
    print("\n".join(files))

    print("\nls /usr/bin/")
    print("\n".join(list(map(lambda x: "/usr/bin/" + x, files))))

    print("\nls /usr/bin/ w/ join_each")
    print("\n".join(list(join_each("/usr/bin", files))))

    print

# Generated at 2022-06-24 03:13:27.879337
# Unit test for function join_each
def test_join_each():
    sample = join_each('foo', ['a', 'b', 'c'])
    assert next(sample) == 'foo/a'
    assert next(sample) == 'foo/b'
    assert next(sample) == 'foo/c'
    try:
        next(sample)
    except StopIteration:
        pass
    else:
        assert False, 'Expecting a StopIteration exception'



# Generated at 2022-06-24 03:13:31.269307
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', [b, c])) == ['/usr/b', '/usr/c']



# Generated at 2022-06-24 03:13:36.499039
# Unit test for function join_each
def test_join_each():
    parent = "directory"
    assert list(join_each(parent, ["foo", "bar"])) == ["directory/foo",
                                                      "directory/bar"]



# Generated at 2022-06-24 03:13:41.923384
# Unit test for function join_each
def test_join_each():
    test_cases = [
        ("foo", ["bar", "baz"], ["foo/bar", "foo/baz"])
    ]

    for parent, iterable, expected in test_cases:
        assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:13:45.585566
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/test", ["a", "b", "c"])) == ["/home/test/a", "/home/test/b", "/home/test/c"]


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-24 03:13:49.372396
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", [])) == []
    assert list(join_each("a", ["b"])) == ["a/b"]
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]
    assert list(join_each("a", [("b", "c", "d")])) == ["a/b/c/d"]

