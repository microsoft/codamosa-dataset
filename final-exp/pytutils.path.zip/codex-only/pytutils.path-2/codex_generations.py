

# Generated at 2022-06-24 03:03:53.364607
# Unit test for function join_each
def test_join_each():
    import unittest

    class TestJoinEach(unittest.TestCase):
        def test_join_each(self):
            self.assertEqual(
                list(join_each('/path/to', ('file1', 'file2'))),
                ['/path/to/file1', '/path/to/file2'],
            )

    unittest.main()



# Generated at 2022-06-24 03:03:57.359001
# Unit test for function join_each
def test_join_each():
    parent = 'c:/aaa'
    iterable = ('bbb', 'ccc')
    expected = ('c:/aaa/bbb', 'c:/aaa/ccc')
    actual = list(join_each(parent, iterable))
    assert actual == expected

# Generated at 2022-06-24 03:04:00.978508
# Unit test for function join_each
def test_join_each():
    parent = '/foo/bar'
    iterable = ('/baz', 'roger/')
    joined = list(join_each(parent, iterable))
    assert joined == [
        '/foo/bar/baz',
        '/foo/bar/roger/'
    ]



# Generated at 2022-06-24 03:04:08.408836
# Unit test for function join_each
def test_join_each():
    folder = os.path.join(os.path.dirname(__file__), 'data')
    list_of_files = ['file1.txt', 'file2.txt', 'file3.txt']
    expected = [os.path.join(folder, 'file1.txt'),
                os.path.join(folder, 'file2.txt'),
                os.path.join(folder, 'file3.txt')]
    assert expected == list(join_each(folder, list_of_files))



# Generated at 2022-06-24 03:04:12.092955
# Unit test for function join_each
def test_join_each():
    parent = r"C:\aa\bb\cc"
    iterable = ["dd", "ee", "ff"]
    assert list(join_each(parent, iterable)) == ['C:\\aa\\bb\\cc\\dd', 'C:\\aa\\bb\\cc\\ee', 'C:\\aa\\bb\\cc\\ff']



# Generated at 2022-06-24 03:04:17.368719
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['a', 'b', 'c', 'd']
    expected = ['parent/a', 'parent/b', 'parent/c', 'parent/d']
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:04:20.342705
# Unit test for function join_each
def test_join_each():
    joined = list(join_each('/path/to/', ['a', 'b', 'c']))
    expected = ['/path/to/a', '/path/to/b', '/path/to/c']
    assert(joined == expected)



# Generated at 2022-06-24 03:04:24.712817
# Unit test for function join_each
def test_join_each():
    assert list(join_each('test', [
        'test1',
        'test2',
        'test3'
    ])) == [
        'test/test1',
        'test/test2',
        'test/test3'
    ]



# Generated at 2022-06-24 03:04:27.918722
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a', [])) == []



# Generated at 2022-06-24 03:04:33.537332
# Unit test for function join_each
def test_join_each():
    pwd = os.getcwd()
    assert list(join_each(pwd, ['a', 'b', 'c'])) == [
        os.path.join(pwd, 'a'),
        os.path.join(pwd, 'b'),
        os.path.join(pwd, 'c')
    ]



# Generated at 2022-06-24 03:04:37.502107
# Unit test for function join_each
def test_join_each():
    files = ['test1.py', 'test2.py']
    assert list(join_each('/tmp', files)) == ['/tmp/test1.py', '/tmp/test2.py']

# Generated at 2022-06-24 03:04:39.239569
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b/', 'c'])) == ['/a', '/b/', '/c']



# Generated at 2022-06-24 03:04:44.108696
# Unit test for function join_each
def test_join_each():
    parent = 'c:/bin'
    iterable = ['/usr', '/usr/bin', '/home']
    expected = [
        'c:/bin\\usr',
        'c:/bin\\usr\\bin',
        'c:/bin\\home'
    ]
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-24 03:04:47.069384
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c', 'd'])) == ['a/b', 'a/c', 'a/d']



# Generated at 2022-06-24 03:04:52.872294
# Unit test for function join_each
def test_join_each():
    assert ['dir1/a', 'dir1/b', 'dir1/c'] == list(join_each("dir1", ["a", "b", "c"]))
    assert [] == list(join_each("dir2", []))



# Generated at 2022-06-24 03:04:56.287299
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('home', tuple('abcd'))) == (
        'home/a',
        'home/b',
        'home/c',
        'home/d',
    )



# Generated at 2022-06-24 03:05:00.016289
# Unit test for function join_each
def test_join_each():
    assert join_each('foo', ['bar', 'baz']) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:05:01.648065
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-24 03:05:08.474684
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['bin', 'boot'])) == ['/bin', '/boot']
    assert list(join_each('/etc', ['passwd', 'shadow'])) == ['/etc/passwd', '/etc/shadow']
    assert list(join_each('/root', ['bin', 'boot'])) == ['/root/bin', '/root/boot']
    assert list(join_each('/root', [])) == []



# Generated at 2022-06-24 03:05:10.279433
# Unit test for function join_each
def test_join_each():
    base = "/user/home"
    path_list = ["test1", "test2", os.path.join("a", "b")]
    for p in join_each(base, path_list):
        print(p)

# Generated at 2022-06-24 03:05:12.542695
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-24 03:05:16.889221
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["child1", "child2"]
    actual_result = list(join_each(parent, iterable))
    expected_result = [
        os.path.join(parent, "child1"),
        os.path.join(parent, "child2")
    ]
    assert actual_result == expected_result



# Generated at 2022-06-24 03:05:23.621036
# Unit test for function join_each
def test_join_each():
    parent = 'a/'
    iterable = [1, 2]
    expected = ['a/1', 'a/2']
    actual = list(join_each(parent, iterable))

    assert actual == expected



# Generated at 2022-06-24 03:05:25.848807
# Unit test for function join_each
def test_join_each():

    iterable = ['foo', 'bar', 'baz']
    parent = 'parent'

    expected = ['parent/foo', 'parent/bar', 'parent/baz']

    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-24 03:05:29.118034
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']



# Generated at 2022-06-24 03:05:31.243032
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/test', ['bin', 'lib'])) == ['/test/bin', '/test/lib']



# Generated at 2022-06-24 03:05:34.146421
# Unit test for function join_each
def test_join_each():
    parent = os.getcwd()
    files = [f for f in join_each(parent, os.listdir(parent))
             if os.path.isfile(f)]
    assert os.path.isfile(files[0])
    assert len(files) > 0

# Generated at 2022-06-24 03:05:40.453431
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/loca/bin', ['ls', 'cd', 'cat'])) == ['/usr/loca/bin/ls',
                                                                    '/usr/loca/bin/cd',
                                                                    '/usr/loca/bin/cat']



# Generated at 2022-06-24 03:05:43.232185
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['jr', 'ud', 'jr'])) == [
        '/tmp/jr', '/tmp/ud', '/tmp/jr']


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-24 03:05:51.090691
# Unit test for function join_each
def test_join_each():
    # GIVEN a list of files and a folder
    files0 = ["test1.txt", "test2.txt"]
    folder = "folder/"

    # WHEN we pass them to join_each
    result = join_each(folder, files0)

    # THEN we see the result is a list of the files joined
    expected = [os.path.join(folder, "test1.txt"),
                os.path.join(folder, "test2.txt")]
    assert list(result) == expected

# Generated at 2022-06-24 03:05:53.140495
# Unit test for function join_each
def test_join_each():
    parent = '/home/yourname/'
    children = ['Pictures', 'Music', 'Videos']
    result = list(join_each(parent, children))
    expected = ['/home/yourname/Pictures', '/home/yourname/Music', '/home/yourname/Videos']
    assert result == expected



# Generated at 2022-06-24 03:06:03.560279
# Unit test for function join_each
def test_join_each():
    assert None is join_each(None, None)
    assert [] == list(join_each(None, []))
    assert [] == list(join_each('', []))
    assert [] == list(join_each('/', []))
    assert [] == list(join_each('/foo/bar/baz', []))

    assert ['/foo/bar/baz/a/b/c'] == list(join_each('/foo/bar/baz', ['a/b/c']))
    assert ['/foo/bar/baz/a/b/c', '/foo/bar/baz/d/e/f'] == \
        list(join_each('/foo/bar/baz', ['a/b/c', 'd/e/f']))


if __name__ == "__main__":
    test_

# Generated at 2022-06-24 03:06:09.565276
# Unit test for function join_each
def test_join_each():
    p = "a/b/c"
    assert list(join_each(p, [])) == []
    assert list(join_each(p, ["d", "e", "f"])) == ["a/b/c/d", "a/b/c/e", "a/b/c/f"]
    assert list(join_each(p, [""])) == ["a/b/c/"]
    assert list(join_each(p, ["", ""])) == ["a/b/c/", "a/b/c/"]

# Generated at 2022-06-24 03:06:11.593884
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/home', ['user', 'program']))

    assert result == [
        '/home/user',
        '/home/program'
    ]

# Generated at 2022-06-24 03:06:15.264357
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['bob', 'dan'])) == \
        ['/tmp/bob', '/tmp/dan']



# Generated at 2022-06-24 03:06:16.779376
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['etc', 'var'])) == ['/etc', '/var']



# Generated at 2022-06-24 03:06:19.557430
# Unit test for function join_each
def test_join_each():
    assert list(join_each('~', ['a', 'b'])) == ['~/a', '~/b']
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each(None, ['a', 'b'])) == ['a', 'b']



# Generated at 2022-06-24 03:06:26.232436
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = [
        "dir_a",
        "dir_b",
        "dir_c"
        ]

    expected_result = [
        "parent/dir_a",
        "parent/dir_b",
        "parent/dir_c"
        ]

    result = list(join_each(parent, iterable))

    assert expected_result == result


###############################################################################

# Generated at 2022-06-24 03:06:29.729692
# Unit test for function join_each
def test_join_each():
    assert list(join_each('f', ['a', 'b', 'c'])) == ['f/a', 'f/b', 'f/c']



# Generated at 2022-06-24 03:06:32.199601
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ('c', 'd'))) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-24 03:06:35.869031
# Unit test for function join_each
def test_join_each():
    assert [i for i in join_each('/home/user', ['dir1', 'dir2', 'dir3'])] == \
           ['/home/user/dir1', '/home/user/dir2', '/home/user/dir3']



# Generated at 2022-06-24 03:06:38.149598
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/var', ['foo', 'bar'])) == ['/var/foo', '/var/bar']



# Generated at 2022-06-24 03:06:41.196424
# Unit test for function join_each
def test_join_each():
    p = "/some/path"
    iterable = ["foo", "bar", "baz"]
    assert list(join_each(p, iterable)) == [os.path.join(p, f) for f in iterable]



# Generated at 2022-06-24 03:06:46.755188
# Unit test for function join_each
def test_join_each():
    files = ["file1.txt", "file2.txt", "file3.txt"]
    expected = ["/home/A/file1.txt", "/home/A/file2.txt", "/home/A/file3.txt"]
    actual = list(join_each("/home/A", files))
    assert expected == actual



# Generated at 2022-06-24 03:06:49.332126
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr/bin", ("decode", "encode"))) == ["/usr/bin/decode", "/usr/bin/encode"]

# Generated at 2022-06-24 03:06:53.219614
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    parent = 'parent'
    result = [os.path.join(parent, item) for item in iterable]
    for x, y in zip(join_each(parent, iterable), result):
        if x != y:
            raise AssertionError


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:06:57.499101
# Unit test for function join_each
def test_join_each():
    assert list(join_each('name', ['first', 'second', 'third'])) == [
        os.path.join('name', 'first'),
        os.path.join('name', 'second'),
        os.path.join('name', 'third'),
    ]

# Generated at 2022-06-24 03:07:00.108499
# Unit test for function join_each
def test_join_each():
    result = list(join_each('parent', ['/foo/bar/baz']))
    assert result == ['/foo/parent/bar/baz']



# Generated at 2022-06-24 03:07:06.332245
# Unit test for function join_each
def test_join_each():

    assert list(join_each('/usr/local', ['bin', 'lib'])) == ['/usr/local/bin', '/usr/local/lib']

    assert list(join_each('/usr/local', ['bin', '', '', '', 'lib'])) == ['/usr/local/bin', '/usr/local/lib']

    assert list(join_each('', ['bin', 'lib'])) == ['bin', 'lib']

    assert list(join_each('/usr/local', [])) == []

    assert list(join_each('/usr/local', ['', '', '', '', '', ''])) == []

test_join_each()



# Generated at 2022-06-24 03:07:13.675987
# Unit test for function join_each
def test_join_each():
    # We'll use path to test the function
    p = os.path
    # Create a path
    a = "/var/www/baz"
    # Contains the paths we'll join with a
    join_these = [
        "a/foo/bar",
        "/b/bar/baz/../baz",  # Note the baz/../baz
        "baz/baz/baz",
        "../../../../c/foo",
        "/"
    ]
    # Join each of the paths and pass them to the function
    joined_paths = join_each(a, join_these)

    results = [
        p.join(a, pth) for pth in join_these
    ]

    for r in results:
        assert r in joined_paths


#
# os.path.ab

# Generated at 2022-06-24 03:07:14.900295
# Unit test for function join_each
def test_join_each():
    assert [os.path.join('a', i) for i in 'ab'] == \
        list(join_each('a', 'ab'))



# Generated at 2022-06-24 03:07:20.958137
# Unit test for function join_each
def test_join_each():
    lst = ["a", "b"]
    gen = join_each("c", lst)
    assert next(gen) == "c/a"
    assert next(gen) == "c/b"
    with pytest.raises(StopIteration):
        next(gen)



# Generated at 2022-06-24 03:07:22.507768
# Unit test for function join_each
def test_join_each():
    root = "c:/tmp"
    files = ["a.txt", "b.txt", "c.txt"]
    actual = list(join_each(root, files))

    assert len(actual) == len(files)



# Generated at 2022-06-24 03:07:24.425864
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['usr', 'local'])) == [
        '/home/usr',
        '/home/local',
    ]



# Generated at 2022-06-24 03:07:28.973955
# Unit test for function join_each
def test_join_each():
    parent = "/a/b/c"
    iterable = ["foo", "bar", "baz"]

    assert list(join_each(parent, iterable)) == [
        "/a/b/c/foo",
        "/a/b/c/bar",
        "/a/b/c/baz",
    ]



# Generated at 2022-06-24 03:07:39.308309
# Unit test for function join_each
def test_join_each():
    with pytest.raises(TypeError) as excinfo:
        join_each(None, list("dummy"))
    assert "parent must be a str type" in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        join_each("dummy", None)
    assert "iterable must be an iterable type" in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        join_each("dummy", "str")
    assert "iterable must be an iterable type" in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        join_each("dummy", [1, 2, 3])
    assert "item in iterable must be a str type" in str(excinfo.value)



# Generated at 2022-06-24 03:07:42.320690
# Unit test for function join_each
def test_join_each():
    test_parent = "/home"
    test_paths = ["Users", "Downloads", "Documents"]
    result = list(join_each(test_parent, test_paths))
    assert result[0] == "/home/Users"
    assert result[1] == "/home/Downloads"
    assert result[2] == "/home/Documents"



# Generated at 2022-06-24 03:07:46.242289
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/p', ['a', 'b'])) == ['/p/a', '/p/b']
    assert list(join_each('', ['a', 'b'])) == ['a', 'b']



# Generated at 2022-06-24 03:07:49.551845
# Unit test for function join_each
def test_join_each():
    parent = '/Users/james'
    children = ('Desktop', 'Downloads')
    expected = ('/Users/james/Desktop', '/Users/james/Downloads')
    actual = join_each(parent, children)
    assert list(actual) == list(expected)

# Generated at 2022-06-24 03:07:55.556109
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']
    assert list(join_each('', ['b', 'c'])) == ['b', 'c']



# Generated at 2022-06-24 03:08:01.093742
# Unit test for function join_each
def test_join_each():
    parent = "parent_dir"
    child_dirs = ["child_dir1", "child_dir2", "child_dir3"]
    child_dirs_joined = ["parent_dir/child_dir1", "parent_dir/child_dir2",
                         "parent_dir/child_dir3"]

    for a, b in zip(join_each(parent, child_dirs), child_dirs_joined):
        assert a == b



# Generated at 2022-06-24 03:08:07.774284
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', 'local', 'bin')) == ['/usr/local', '/usr/bin']
    assert list(join_each('/', 'usr', 'local', 'bin')) == ['/usr', '/local', '/bin']
    assert list(join_each('', 'usr', 'local', 'bin')) == ['usr', 'local', 'bin']
    ass

# Generated at 2022-06-24 03:08:11.492121
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == ['/tmp/a', '/tmp/b', '/tmp/c']

# Generated at 2022-06-24 03:08:17.994744
# Unit test for function join_each
def test_join_each():
    # Ensure we're starting from a clean slate
    assert list(join_each("parent", ["child1", "child2"])) == \
        ["parent" + os.path.sep + "child1", "parent" + os.path.sep + "child2"]

# Generated at 2022-06-24 03:08:21.645131
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['user', 'bin'])) == ['/home/user', '/home/bin']


# Given strings representing filenames or directories, return an iterator
# that yields only the absolute paths that correspond to filenames

# Generated at 2022-06-24 03:08:27.580654
# Unit test for function join_each
def test_join_each():
    os_join = os.path.join

    assert list(join_each('/home', ['user', 'test'])) == [os_join('/home', 'user'), os_join('/home', 'test')]
    assert list(join_each('/home', 'user')) == [os_join('/home', 'u'), os_join('/home', 's'), os_join('/home', 'e'), os_join('/home', 'r')]

# Generated at 2022-06-24 03:08:29.880001
# Unit test for function join_each
def test_join_each():
    # Add your unit test here
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]

# Generated at 2022-06-24 03:08:32.261760
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', ['hosts', 'hosts.bak'])) == ['/etc/hosts', '/etc/hosts.bak']

# Generated at 2022-06-24 03:08:36.118307
# Unit test for function join_each
def test_join_each():
    os.path.join = lambda x, y: '/'.join((x, y))  # Note: 'join' must be defined in global scope
    files = ['a.txt', 'b.txt']
    assert list(join_each('/etc', files)) == ['/etc/a.txt', '/etc/b.txt']



# Generated at 2022-06-24 03:08:37.274359
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['hey', 'you'])) == ['./hey', './you']



# Generated at 2022-06-24 03:08:38.863035
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/foo", ["bar", "baz"])) == ["/foo/bar", "/foo/baz"]

# Generated at 2022-06-24 03:08:42.172856
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar'])) == ['/foo', '/bar']
    assert list(join_each('/', [])) == []

# Generated at 2022-06-24 03:08:44.702252
# Unit test for function join_each
def test_join_each():
    parent = "foo"
    iterable = ["bar", "baz"]
    result = join_each(parent, iterable)
    answer = ["foo/bar", "foo/baz"]
    assert list(result) == answer



# Generated at 2022-06-24 03:08:49.617696
# Unit test for function join_each
def test_join_each():
    parent = '/home/foo'
    children = ('bar', 'baz', 'qux')
    expected = ('/home/foo/bar', '/home/foo/baz', '/home/foo/qux')

    assert(list(join_each(parent, children)) == expected)



# Generated at 2022-06-24 03:08:54.109550
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', [])) == []
    assert list(join_each('/', [''])) == ['/']
    assert list(join_each('/', ['', 'usr'])) == ['/', '/usr']
    assert list(join_each('/', ['home', 'usr'])) == ['/home', '/usr']



# Generated at 2022-06-24 03:09:02.464907
# Unit test for function join_each
def test_join_each():
    test_dirs = [
        '/home/shin',
        '/home/shin/Downloads',
        '/home/shin/Pictures'
    ]
    test_path = '/home/shin'

    joined = join_each(test_path, test_dirs)

    assert test_dirs[0] == next(joined)
    assert test_dirs[1] == next(joined)
    assert test_dirs[2] == next(joined)

# Generated at 2022-06-24 03:09:06.838193
# Unit test for function join_each
def test_join_each():
    assert list(join_each('src', ['dir1', 'dir2', 'dir3', 'dir4'])) == ['src/dir1',
                                                                        'src/dir2',
                                                                        'src/dir3',
                                                                        'src/dir4']



# Generated at 2022-06-24 03:09:10.054013
# Unit test for function join_each
def test_join_each():
    assert(tuple(join_each('/base', ['a', 'b', 'c'])) == ('/base/a', '/base/b', '/base/c'))



# Generated at 2022-06-24 03:09:14.125084
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/c', ['d', 'e', 'f'])) == [
        '/a/b/c/d',
        '/a/b/c/e',
        '/a/b/c/f',
    ]



# Generated at 2022-06-24 03:09:20.740488
# Unit test for function join_each
def test_join_each():
    parent = '/home/jovyan'
    iterable = ['foo', 'bar', 'baz']
    joined_result_list = [
        os.path.join(parent, p) for p in iterable
    ]
    # Check if join_each and list comprehension produce the same output
    assert list(join_each(parent, iterable)) == joined_result_list


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:09:24.908055
# Unit test for function join_each
def test_join_each():
    p = '/home/dev'
    items = ['file1', 'file2']
    j = join_each(p, items)
    assert j.next() == '/home/dev/file1'
    assert j.next() == '/home/dev/file2'



# Generated at 2022-06-24 03:09:33.819700
# Unit test for function join_each
def test_join_each():
    from_path = "resources/from"
    from_subdir = "subdir"
    from_subdir_path = os.path.join(from_path, from_subdir)
    from_subdir_file1 = "subdir_file1.txt"
    from_subdir_file2 = "subdir_file2.txt"
    from_subdir_file_paths = frozenset([from_subdir_file1, from_subdir_file2])
    assert frozenset(join_each(from_subdir_path, from_subdir_file_paths)) == frozenset(
        map(
            lambda x: os.path.join(from_subdir_path, x), from_subdir_file_paths
        )
    )


from_path = "resources/from"


# Generated at 2022-06-24 03:09:36.315736
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    iterable = ('a', 'b', 'c')
    assert list(join_each(parent, iterable)) == ['/tmp/a', '/tmp/b', '/tmp/c']



# Generated at 2022-06-24 03:09:37.842657
# Unit test for function join_each
def test_join_each():
    actual = list(join_each('/', ['test', 'foo']))
    expected = ['/test', '/foo']
    assert actual == expected

# Generated at 2022-06-24 03:09:41.813826
# Unit test for function join_each
def test_join_each():
    p = '/home/stuff'
    l = ['a', 'b', 'c']
    result = [os.path.join(p, k) for k in l]
    assert list(join_each(p, l)) == result

# Generated at 2022-06-24 03:09:46.330145
# Unit test for function join_each
def test_join_each():
    # arrange
    parent = "c:\\windows"
    iterable = ["file1.txt", "file2.txt"]

    # act
    result = list(join_each(parent, iterable))

    # assert
    assert result == ["c:\\windows\\file1.txt", "c:\\windows\\file2.txt"]


# Save all files in the root folder

# Generated at 2022-06-24 03:09:47.964755
# Unit test for function join_each
def test_join_each():
    def path_generator():
        yield "/a"
        yield "/b"
        yield "/c"
    assert list(join_each("/", path_generator()) == ["/a", "/b", "/c"])



# Generated at 2022-06-24 03:09:50.311511
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['./foo.txt', './bar.txt'])) == ['./foo.txt', './bar.txt']


# Generated at 2022-06-24 03:09:55.387342
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == [
        '/tmp/a',
        '/tmp/b',
        '/tmp/c',
    ]

# Generated at 2022-06-24 03:09:58.499339
# Unit test for function join_each
def test_join_each():
    print(list(join_each('a', 'b')))
    assert list(join_each('a', 'b')) == ['a/b']
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-24 03:10:02.427104
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['james', 'rachel'])) == ['/home/james', '/home/rachel']

# Generated at 2022-06-24 03:10:05.672932
# Unit test for function join_each
def test_join_each():

    parent = '/home/user/'
    iterable = ['Docs', 'Projects', 'Downloads']
    result = [p for p in join_each(parent, iterable)]
    assert result == ['/home/user/Docs',
                      '/home/user/Projects',
                      '/home/user/Downloads']

# Generated at 2022-06-24 03:10:09.212403
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["a", "b", "c"]
    assert [
        os.path.join(parent, "a"),
        os.path.join(parent, "b"),
        os.path.join(parent, "c"),
    ] == list(join_each(parent, iterable))



# Generated at 2022-06-24 03:10:12.693587
# Unit test for function join_each
def test_join_each():
    assert 'hoge/hoge1' in list(join_each('hoge', ['hoge1']))
    assert 'hoge/hoge1' not in list(join_each('hoge', ['hoge2']))

# Generated at 2022-06-24 03:10:14.589783
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('foo', ('bar', 'baz'))) == ('foo/bar', 'foo/baz')



# Generated at 2022-06-24 03:10:19.791891
# Unit test for function join_each
def test_join_each():
    # Test with empty arguments
    empty = join_each('', [])
    assert list(empty) == [], 'join_each must return an empty list on empty arguments'

    # Test with regular arguments
    regular = join_each('parent', ['a', 'b', 'c'])
    assert list(regular) == ['parent/a', 'parent/b', 'parent/c'], 'join_each failed with regular arguments'



# Generated at 2022-06-24 03:10:26.374663
# Unit test for function join_each
def test_join_each():
    files = ['a.txt', 'b.txt', 'c.txt']
    dir_path = '/home/user/dir'
    for f, f_exp in zip(join_each(dir_path, files),
                        map(lambda f: os.path.join(dir_path, f),
                            files)):
        assert f == f_exp

# Generated at 2022-06-24 03:10:32.049771
# Unit test for function join_each
def test_join_each():
    # list of file paths
    files = ["a/b","a/c","a/d"]
    # list of file paths with 'search' prepended to it
    files_extended = ["search/"+file for file in files]
    assert list(join_each('search', files)) == files_extended


# Only run unit tests if __name__ is the main module
if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-24 03:10:36.272073
# Unit test for function join_each
def test_join_each():
    a = ['a', 'b', 'c']
    b = join_each('/home/foo', a)
    c = ['/home/foo/a', '/home/foo/b', '/home/foo/c']
    for i in range(len(a)):
        assert b[i] == c[i]

# Generated at 2022-06-24 03:10:43.308593
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['a/b', 'c/d']
    result = join_each(parent, iterable)
    expected_result = [
        os.path.join(parent, 'a/b'),
        os.path.join(parent, 'c/d')
    ]
    assert list(result) == expected_result

# Generated at 2022-06-24 03:10:55.320956
# Unit test for function join_each
def test_join_each():
    assert list(join_each('path', ['a', 'b'])) == ['path/a', 'path/b']



# Generated at 2022-06-24 03:11:02.553575
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    iterable = ['foo', 'bar']
    result = list(join_each(parent, iterable))
    expected_result = ['/home/foo', '/home/bar']
    assert result == expected_result, "unexpected result"
    assert result[0] == '/home/foo', "unexpected result[0]"
    assert result[1] == '/home/bar', "unexpected result[1]"
    assert result[0] == expected_result[0], "unexpected result[0]"
    assert result[1] == expected_result[1], "unexpected result[1]"
    # The objects pointed to by result[0] and result[1] are not the same
    # ... but that is ok because the content is the same
    #

# Generated at 2022-06-24 03:11:05.766909
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["foo", "bar"])) == [
        "/home/foo",
        "/home/bar",
    ]
    assert list(join_each("", ["foo", "bar"])) == ["foo", "bar"]
    assert list(join_each("/", ["foo", "bar"])) == ["/foo", "/bar"]



# Generated at 2022-06-24 03:11:11.261653
# Unit test for function join_each
def test_join_each():
    data = [1, 2, 3]
    result = list(join_each('/home/user', data))
    assert result == ['/home/user/1', '/home/user/2', '/home/user/3']

# Generated at 2022-06-24 03:11:21.168134
# Unit test for function join_each

# Generated at 2022-06-24 03:11:23.588371
# Unit test for function join_each
def test_join_each():
    parent = "/home/user"
    paths = ["file1", "file2", "file3"]
    expected = ["/home/user/file1", "/home/user/file2", "/home/user/file3"]
    actual = list(join_each(parent, paths))
    assert actual == expected

# Generated at 2022-06-24 03:11:26.112134
# Unit test for function join_each
def test_join_each():
    parent = '/home/user'
    files = ['test', 'file']
    expected = ['/home/user/test', '/home/user/file']

    actual = join_each(parent, files)

    for i in range(len(actual)):
        assert expected[i] == actual[i]



# Generated at 2022-06-24 03:11:32.016333
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/bin', ['apache2', 'mysql', 'python'])) == ['/usr/bin/apache2', '/usr/bin/mysql', '/usr/bin/python']



# Generated at 2022-06-24 03:11:37.406995
# Unit test for function join_each
def test_join_each():
    assert_list_equal(list(join_each('/a/b', ['1', '2', '3'])), ['/a/b/1', '/a/b/2', '/a/b/3'])


# Many unit tests for function is_in_folder

# Generated at 2022-06-24 03:11:42.401880
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', 'bc')) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:11:45.324902
# Unit test for function join_each
def test_join_each():
    p, c1, c2, c3 = 'parent', 'child1', 'child2', 'child3'
    assert tuple(join_each(p, (c1, c2, c3))) == (c1, c2, c3)

# Generated at 2022-06-24 03:11:47.888542
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a/b", ["c", "d", "e"])) == [
        "/a/b/c", "/a/b/d", "/a/b/e"
    ]

# Generated at 2022-06-24 03:11:52.471098
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/path", ["/a", "/b", "/c"])) == [
        "/path/a",
        "/path/b",
        "/path/c",
    ]
    assert list(join_each("/", ["a", "b", "c"])) == ["/a", "/b", "/c"]



# Generated at 2022-06-24 03:11:58.368027
# Unit test for function join_each
def test_join_each():
    parent = os.path.abspath(os.path.dirname(__file__))
    names = ["test1.txt", "test2.txt"]
    paths = [os.path.join(parent, n) for n in names]
    assert paths == list(join_each(parent, names))


# Iterate recursively over directories,
# listing each file as an absolute path name

# Generated at 2022-06-24 03:12:01.088087
# Unit test for function join_each
def test_join_each():
    test_iterable = join_each('test', ['this', 'is', 'a', 'test'])
    assert next(test_iterable) == 'test/this'
    assert list(test_iterable) == ['test/is', 'test/a', 'test/test']



# Generated at 2022-06-24 03:12:03.653204
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["foo", "bar"])) == ["/tmp/foo", "/tmp/bar"]

# Generated at 2022-06-24 03:12:10.258250
# Unit test for function join_each
def test_join_each():
    parent = "C:\\foo"
    filenames = ["foo.py", "bar.txt", "baz.py"]
    joined = list(join_each(parent, filenames))
    assert joined == [
        "C:\\foo\\foo.py",
        "C:\\foo\\bar.txt",
        "C:\\foo\\baz.py",
    ]



# Generated at 2022-06-24 03:12:15.921100
# Unit test for function join_each
def test_join_each():
    path = '/home/lenny'
    paths = ['file.txt', 'dir']
    result = list(join_each(path, paths))
    assert result == ['/home/lenny/file.txt', '/home/lenny/dir']



# Generated at 2022-06-24 03:12:24.244696
# Unit test for function join_each
def test_join_each():
    # Test input
    my_list = ['a', 'b', 'c']
    # Desired output
    desired_result = ['a/a', 'a/b', 'a/c', 'b/a', 'b/b', 'b/c', 'c/a',
                      'c/b', 'c/c']
    # Test output
    test_result = list(join_each('a', my_list))
    # Compare desired output with test output
    assert desired_result == test_result

# Generated at 2022-06-24 03:12:26.583866
# Unit test for function join_each
def test_join_each():
    assert list(join_each('usr', ['bin', 'local'])) == [os.path.join('usr', 'bin'), os.path.join('usr', 'local')]

# Generated at 2022-06-24 03:12:30.960277
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/takeyuki',
                          ['goto', 'gotoh'])) == ['/home/takeyuki/goto',
                                                  '/home/takeyuki/gotoh']

# Generated at 2022-06-24 03:12:35.637554
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b"])) == ["/tmp/a", "/tmp/b"]

# Generated at 2022-06-24 03:12:38.621079
# Unit test for function join_each
def test_join_each():
    parent, paths = 'a/b/c', ['d/e', 'f', 'g/h']
    assert list(join_each(parent, paths)) == ['a/b/c/d/e', 'a/b/c/f', 'a/b/c/g/h']



# Generated at 2022-06-24 03:12:40.508463
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", "b c d".split())) == ["a/b", "a/c", "a/d"]



# Generated at 2022-06-24 03:12:44.087227
# Unit test for function join_each
def test_join_each():
    parent = '/parent'
    iterable = ['child1', 'child2', 'child3']
    expected = [os.path.join(parent, i) for i in iterable]
    assert list(join_each(parent, iterable)) == expected
    assert list(join_each(parent, [])) == []

# Generated at 2022-06-24 03:12:47.988138
# Unit test for function join_each
def test_join_each():
    assert list(join_each('A', 'B')) == ['A/B']
    assert list(join_each('A', ('B', 'C'))) == ['A/B', 'A/C']
    assert list(join_each('A', ('B', 'C', 'D'))) == ['A/B', 'A/C', 'A/D']


if __name__ == '__main__':
    import nose
    nose.runmodule(argv=[__file__, '-vvs', '-x', '--pdb', '--pdb-failure'],
                   exit=False)

# Generated at 2022-06-24 03:12:57.402946
# Unit test for function join_each
def test_join_each():
    parent = '/home/bob/Desktop'
    assert list(join_each(parent, ['hello.txt', 'world.txt'])) == [
        '/home/bob/Desktop/hello.txt', '/home/bob/Desktop/world.txt']
    assert list(join_each(parent, [])) == []
    assert list(join_each(parent, ['hello.txt', 'world.txt', '', '..'])) == [
    '/home/bob/Desktop/hello.txt', '/home/bob/Desktop/world.txt',
    '/home/bob/Desktop/', '/home/bob/Desktop/..']



# Generated at 2022-06-24 03:12:58.772657
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['aa', 'bb'])) == ['/aa', '/bb']



# Generated at 2022-06-24 03:13:01.117191
# Unit test for function join_each
def test_join_each():
    iterable = ("c", "d", "e")
    result = list(join_each("foo", iterable))
    assert result == ['foo/c', 'foo/d', 'foo/e']



# Generated at 2022-06-24 03:13:06.659920
# Unit test for function join_each
def test_join_each():
    import string
    from random import choice
    from functools import partial

    genletters = lambda: ''.join(
            choice(string.ascii_lowercase) for _ in range(10))

    for _ in range(5):
        base = genletters()
        paths = [genletters() for _ in range(5)]

        expected = [os.path.join(base, p) for p in paths]
        actual = join_each(base, paths)
        assert list(actual) == expected

        join = partial(os.path.join, base)
        assert list(map(join, paths)) == expected

# Generated at 2022-06-24 03:13:09.035094
# Unit test for function join_each
def test_join_each():
    assert join_each("/home", ["a", "b"]) == ["/home/a", "/home/b"]



# Generated at 2022-06-24 03:13:13.158610
# Unit test for function join_each
def test_join_each():
    # Test behavior
    assert list(join_each('a', 'b')) == ['a/b']  # Test single item
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']  # Test multiple items

    # Test behavior if iterable is empty
    assert list(join_each('a')) == []  # Test empty iterable

# Generated at 2022-06-24 03:13:17.420592
# Unit test for function join_each
def test_join_each():
    expected = [
            'a/a',
            'a/b',
            'a/c',
            'b/a',
            'b/b',
            'b/c',
    ]
    actual = join_each('a', ['a', 'b', 'c'])
    assert expected == list(actual)
    assert [] == list(join_each('a', ()))



# Generated at 2022-06-24 03:13:18.947517
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ('a', 'b', 'c'))) == ['/tmp/a', '/tmp/b', '/tmp/c']

# Generated at 2022-06-24 03:13:24.771639
# Unit test for function join_each
def test_join_each():
    parent = "C:\\Program Files"
    iterable = ["Notepad++", "Python"]
    results = list(join_each(parent, iterable))
    expected = [
        r"C:\Program Files\Notepad++",
        r"C:\Program Files\Python",
    ]

    for result in results:
        assert result in expected



# Generated at 2022-06-24 03:13:26.092689
# Unit test for function join_each
def test_join_each():
    assert list(
        join_each("/usr/local", ["bin", "lib"])
    ) == ["/usr/local/bin", "/usr/local/lib"]



# Generated at 2022-06-24 03:13:32.258625
# Unit test for function join_each
def test_join_each():
    assert list(join_each(os.path.curdir, ['a', 'b', 'c'])) == [os.path.join(os.path.curdir, 'a'), os.path.join(os.path.curdir, 'b'), os.path.join(os.path.curdir, 'c')]



# Generated at 2022-06-24 03:13:41.907081
# Unit test for function join_each
def test_join_each():
    assert (list(join_each("xxx", "ab")) ==
            ['xxx\\a', 'xxx\\b'])
    assert (list(join_each("xxx", "ab", "cd")) ==
            ['xxx\\a\\c', 'xxx\\a\\d', 'xxx\\b\\c', 'xxx\\b\\d'])
    assert (list(join_each("xxx", "ab", "cd", "ef")) ==
            ['xxx\\a\\c\\e', 'xxx\\a\\c\\f',
             'xxx\\a\\d\\e', 'xxx\\a\\d\\f',
             'xxx\\b\\c\\e', 'xxx\\b\\c\\f',
             'xxx\\b\\d\\e', 'xxx\\b\\d\\f'])

    # This doesn't actually test join_each, but I don't know where

# Generated at 2022-06-24 03:13:45.870479
# Unit test for function join_each
def test_join_each():
    """Function join_each should join each member of the iterable with
    the parent."""

    parent = "."
    iterable = ["a", "b"]
    for i, value in enumerate(join_each(parent, iterable)):
        assert value == os.path.join(parent, iterable[i])

# Generated at 2022-06-24 03:13:51.314740
# Unit test for function join_each
def test_join_each():
    # Use temporary directory as parent
    with tempfile.TemporaryDirectory() as tmpdir:
        # construct list of paths to join with tempdir
        paths = ["path_one", "path_two"]

        # use function join_each
        out = join_each(tmpdir, paths)

        # Programatically check result
        assert next(out) == os.path.join(tmpdir, paths[0])
        assert next(out) == os.path.join(tmpdir, paths[1])
        with pytest.raises(StopIteration):
            next(out)


if __name__ == "__main__":
    # Run the unit test
    test_join_each()

    # Print the documentation
    print(join_each.__doc__)