

# Generated at 2022-06-24 03:03:48.315424
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c", "d"])) == ["a/b", "a/c", "a/d"]



# Generated at 2022-06-24 03:03:52.171590
# Unit test for function join_each
def test_join_each():
    paths = join_each("/etc", ["hosts", "group", "passwd"])
    assert isinstance(paths, collections.Iterable)
    assert list(paths) == [
        "/etc/hosts",
        "/etc/group",
        "/etc/passwd",
    ]



# Generated at 2022-06-24 03:03:56.656286
# Unit test for function join_each
def test_join_each():
    assert join_each('/root', ['a', 'b/c', 'd']) == [
        '/root/a', '/root/b/c', '/root/d']



# Generated at 2022-06-24 03:04:00.834453
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == [
        '/tmp/a',
        '/tmp/b',
        '/tmp/c',
    ]
    assert list(join_each('/tmp', ['a', '../b', '/c'])) == [
        '/tmp/a',
        '/b',
        '/c',
    ]

# Generated at 2022-06-24 03:04:04.542277
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', ['passwd', 'conf'])) == [
        '/etc/passwd',
        '/etc/conf',
        ]


# Output from `get_sha256sum_from_file` is passed as input to
# `check_sha256sum_of_file`.

# Generated at 2022-06-24 03:04:10.990826
# Unit test for function join_each
def test_join_each():
    results = list(join_each('a', ['b', 'c']))
    assert len(results) == 2
    assert results[0] == 'a/b'
    assert results[1] == 'a/c'



# Generated at 2022-06-24 03:04:14.435002
# Unit test for function join_each
def test_join_each():
    expected = (
        "abc/d",
        "abc/e",
        "xyz/f",
        "xyz/g",
        "xyz/h",
        "xyz/i",
    )
    actual = tuple(
        join_each("abc", ["d", "e"]) + join_each("xyz", ["f", "g", "h", "i"])
    )
    assert expected == actual



# Generated at 2022-06-24 03:04:17.348822
# Unit test for function join_each
def test_join_each():
    assert [os.path.join('a', 'b'), os.path.join('a', 'c')] == list(join_each('a', ['b', 'c']))



# Generated at 2022-06-24 03:04:21.879831
# Unit test for function join_each
def test_join_each():
    # construct a list of pairs to join
    pairs = [['/home', 'alice', 'test'], ['/usr', 'bin', 'python']]
    # join the paths
    dirs = [os.path.join(*d) for d in pairs]
    # test the results
    assert dirs == ['/home/alice/test', '/usr/bin/python']

# Generated at 2022-06-24 03:04:22.933531
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c', 'd'])) == ['a/b', 'a/c', 'a/d']

# Generated at 2022-06-24 03:04:27.034113
# Unit test for function join_each
def test_join_each():
    parent = 'foo/bar'
    iterable = ['baz', 'boz']
    list(join_each(parent, iterable)) == ['foo/bar/baz', 'foo/bar/boz']



# Generated at 2022-06-24 03:04:30.094688
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    parent = '/tmp'
    result = list(join_each(parent, iterable))
    assert result == [
        '/tmp/a',
        '/tmp/b',
        '/tmp/c',
    ]



# Generated at 2022-06-24 03:04:33.249644
# Unit test for function join_each
def test_join_each():
    parent = "C:\Python34"
    iterable = ["Lib", "Lib\site-packages"]
    assert list(join_each(parent, iterable)) == [
        "C:\Python34\\Lib", "C:\Python34\\Lib\site-packages"]



# Generated at 2022-06-24 03:04:38.915337
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/bin/', ['ls', 'mkdir', 'grep'])) == [
        '/bin/ls', '/bin/mkdir', '/bin/grep']



# Generated at 2022-06-24 03:04:42.970414
# Unit test for function join_each
def test_join_each():
    parent = '/home/a.out'
    expected = ['/home/a.out/a', '/home/a.out/b']
    assert expected == list(join_each(parent, ['a', 'b']))

# Generated at 2022-06-24 03:04:48.078466
# Unit test for function join_each
def test_join_each():
    class Dummy:
        def __init__(self, value):
            self.value = value

    paths = ['', '.', '..', join_each('/', ['a', 'b', '..']), join_each('/', ['c', 'd', '.../e']), Dummy('f')]

    for path in paths:
        for p in join_each('/', path):
            print(p)

# Generated at 2022-06-24 03:04:51.335049
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-24 03:04:56.590030
# Unit test for function join_each
def test_join_each():
    parent = '/home/username'
    child = ['Documents', 'Downloads', 'Pictures']
    expected = ['/home/username/Documents', '/home/username/Downloads',
                '/home/username/Pictures']
    output = list(join_each(parent, child))

    assert output == expected


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:05:02.455919
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/parent/path", [])) == []
    assert list(join_each("/parent/path", ["a"])) == [
        "/parent/path/a"]
    assert list(join_each("/parent/path", ["a", "b"])) == [
        "/parent/path/a", "/parent/path/b"]


# Generated at 2022-06-24 03:05:05.044116
# Unit test for function join_each
def test_join_each():
    test_parent = '/usr'
    test_iterable = ['local/bin', 'bin']

    assert ['/usr/local/bin', '/usr/bin'] == list(join_each(test_parent, test_iterable))



# Generated at 2022-06-24 03:05:10.118265
# Unit test for function join_each
def test_join_each():
    # Create two directories 'a' and 'b' in current directory
    if not os.path.exists('a'):
        os.mkdir('a')
    if not os.path.exists('b'):
        os.mkdir('b')

    # Create two files 'a/c' and 'a/d' in directory 'a'
    f = open('a/c', 'w')
    f.close()
    f = open('a/d', 'w')
    f.close()

    # Create three files 'b/c', 'b/d' and 'b/e' in directory 'b'
    f = open('b/c', 'w')
    f.close()
    f = open('b/d', 'w')
    f.close()
    f = open('b/e', 'w')

# Generated at 2022-06-24 03:05:12.759704
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['test', 'folder'])) == [
        '/tmp/test',
        '/tmp/folder'
    ]



# Generated at 2022-06-24 03:05:20.995291
# Unit test for function join_each
def test_join_each():
    # Setup
    test_dir = '.'
    test_names = ['.', '..', 'setup.py', 'test_utils.py']
    expected = [
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), '.'),
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), '..'),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), 'setup.py'),
        os.path.join(os.path.abspath(__file__))
    ]
    # Exercise
    result = list(join_each(test_dir, test_names))

    # Verify
   

# Generated at 2022-06-24 03:05:23.420192
# Unit test for function join_each
def test_join_each():
    iterable = 'foo', 'bar', 'woot'
    assert join_each('foo', iterable) == ('foo/foo', 'foo/bar', 'foo/woot')

# Generated at 2022-06-24 03:05:27.818144
# Unit test for function join_each
def test_join_each():
    assert list(join_each(
        "/home/david", ("Documents", "Downloads", "Pictures")
    )) == [
        "/home/david/Documents",
        "/home/david/Downloads",
        "/home/david/Pictures"
    ]


# ----------------------------------------------------------------------------
# """
# >>> from itertools import chain
# >>> list(chain.from_iterable(join_each(parent, items) for parent, items in ...))
# ['/home/david/Documents', '/home/david/Downloads', '/home/david/Pictures', '/etc/X11']
# """
# ----------------------------------------------------------------------------
# >>> from operator import itemgetter
# >>> list(chain(join_each(*parent_items) for parent_items in ...))
# ['/home/david/Documents', '/home/d

# Generated at 2022-06-24 03:05:30.428790
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/etc", ["passwd", "group"])) == [
        "/etc/passwd",
        "/etc/group",
    ]



# Generated at 2022-06-24 03:05:32.018235
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']

# Generated at 2022-06-24 03:05:36.710451
# Unit test for function join_each
def test_join_each():
    assert list(join_each('../', ('foo', 'bar', 'baz'))) == \
        ['../foo', '../bar', '../baz']

# Generated at 2022-06-24 03:05:38.323668
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/foo", ["bar", "baz"])) == ["/foo/bar", "/foo/baz"]



# Generated at 2022-06-24 03:05:40.693195
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b"])) == ["/tmp/a", "/tmp/b"]



# Generated at 2022-06-24 03:05:43.163870
# Unit test for function join_each
def test_join_each():
    p = 'parent'
    i = ('foo', 'bar', 'baz')
    j = join_each(p, i)
    assert j == [os.path.join(p, i) for i in i]



# Generated at 2022-06-24 03:05:46.648624
# Unit test for function join_each
def test_join_each():
    parent = "abc"
    iterable = ["d", "e"]
    expected = [os.path.join(parent, "d"), os.path.join(parent, "e")]
    actual = [i for i in join_each(parent, iterable)]
    assert expected == actual



# Generated at 2022-06-24 03:05:55.583227
# Unit test for function join_each
def test_join_each():
    """Unit test for join_each.
    """
    # Test empty
    assert list(join_each('.', [])) == []

    # Test single item
    assert list(join_each('.', ['a'])) == ['./a']

    # Test multiple items
    assert list(join_each('.', ['a', 'b', 'c'])) == ['./a', './b', './c']

    # Test iteration
    assert list(join_each('.', iter(['a', 'b']))) == ['./a', './b']

    # Test dups
    assert list(join('.', ['a', 'a'])) == ['./a', './a']



# Generated at 2022-06-24 03:05:57.877779
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-24 03:06:02.068966
# Unit test for function join_each
def test_join_each():
    p = os.getcwd()
    assert list(join_each(p, ['/home', '/', '/test'])) == \
           [os.path.join(p, '/home'), os.path.join(p, '/'), os.path.join(p, '/test')]



# Generated at 2022-06-24 03:06:04.765132
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']


# Returns the list of all subdirectories of the root directory

# Generated at 2022-06-24 03:06:07.206649
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    assert list(join_each(3, iterable)) == [3, 4, 5]

# Generated at 2022-06-24 03:06:09.663711
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/', ['c', 'd'])) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-24 03:06:11.986595
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['root', 'user'])) == ['/home/root', '/home/user']
    assert list(join_each('/home', [])) == []



# Generated at 2022-06-24 03:06:16.337345
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:06:18.925649
# Unit test for function join_each
def test_join_each():
    input_ = ['/a/b', 'c', 'd']
    expected = ['/a/b/c', '/a/b/d']
    actual = list(join_each('/a/b', input_))
    assert expected == actual



# Generated at 2022-06-24 03:06:22.642029
# Unit test for function join_each
def test_join_each():
    iterable = join_each('./path/to', ['a', 'b', 'c'])
    assert next(iterable) == './path/to/a'
    assert next(iterable) == './path/to/b'
    assert next(iterable) == './path/to/c'
    try:
        next(iterable)
        assert False
    except StopIteration:
        pass



# Generated at 2022-06-24 03:06:24.587461
# Unit test for function join_each
def test_join_each():
    files = 'ab cd ef'.split()
    assert list(join_each('dir', files)) == [
        os.path.join('dir', 'ab'),
        os.path.join('dir', 'cd'),
        os.path.join('dir', 'ef'),
    ]

# Generated at 2022-06-24 03:06:29.097901
# Unit test for function join_each
def test_join_each():
    parent = "/tmp/parent"
    result = join_each(parent, ["a", "b", "c"])
    assert next(result) == "/tmp/parent/a"
    n = next(result)
    assert n == "/tmp/parent/b"
    assert list(result) == ["/tmp/parent/c"]
    assert parent == "/tmp/parent"


# Generated at 2022-06-24 03:06:31.349691
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["user", "foobar"])) == ["/home/user", "/home/foobar"]



# Generated at 2022-06-24 03:06:32.978168
# Unit test for function join_each
def test_join_each():
    assert join_each('parent', ['child']) == ['parent/child']

    assert join_each('parent', ['child_1', 'child_2']) == ['parent/child_1', 'parent/child_2']



# Generated at 2022-06-24 03:06:37.189697
# Unit test for function join_each
def test_join_each():
    # Setup
    parent = '/parent'
    iterable = ['a', 'b', 'c']

    # Exercise
    it = join_each(parent, iterable)

    # Verify
    expected = [os.path.join(parent, c) for c in iterable]

    assert tuple(it) == tuple(expected)

# Generated at 2022-06-24 03:06:38.927298
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar'])) == ['/foo', '/bar']



# Generated at 2022-06-24 03:06:43.382107
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ('a', 'b'))) == ['/tmp/a', '/tmp/b']
    assert list(join_each('/tmp/', ('a', 'b'))) == ['/tmp/a', '/tmp/b']
    assert list(join_each('/tmp/', ['/a', '/b'])) == ['/tmp//a', '/tmp//b']



# Generated at 2022-06-24 03:06:47.150919
# Unit test for function join_each
def test_join_each():
    i = ["d1", "d2", "d3"]
    d = "/Users/me/base"
    j = [os.path.join(d, a) for a in i]
    print(j)
    assert j == list(join_each(d, i))

# Generated at 2022-06-24 03:06:50.958061
# Unit test for function join_each
def test_join_each():
    parent = '/etc'
    paths = ('nginx', 'mysql')

    joined = list(join_each(parent, paths))

    assert joined == [
        '/etc/nginx',
        '/etc/mysql',
    ]

# Generated at 2022-06-24 03:06:58.705731
# Unit test for function join_each
def test_join_each():
    parent = 'path'
    it = join_each(parent, ['a', 'b', 'c'])
    assert next(it) == os.path.join(parent, 'a')
    assert next(it) == os.path.join(parent, 'b')
    assert next(it) == os.path.join(parent, 'c')
    try:
        next(it)
    except StopIteration:
        pass
    else:
        assert False, 'join_each() did not stop when expected'

# Generated at 2022-06-24 03:07:00.826522
# Unit test for function join_each
def test_join_each():
    assert list(join_each(".", ["foo", "bar", "baz"])) == \
        ["./foo", "./bar", "./baz"]



# Generated at 2022-06-24 03:07:06.600636
# Unit test for function join_each
def test_join_each():
    path = '/home/to'
    files = ('file1', 'file2', 'file3')
    expected_result = ('/home/to/file1', '/home/to/file2', '/home/to/file3')

    assert tuple(join_each(path, files)) == expected_result



# Generated at 2022-06-24 03:07:08.986686
# Unit test for function join_each
def test_join_each():
    expected = ['c:/x/y', 'c:/x/z']
    result = list(join_each('c:/x', ['y', 'z']))
    assert expected == result



# Generated at 2022-06-24 03:07:10.565337
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:07:16.923095
# Unit test for function join_each
def test_join_each():
    assert list(join_each("x", ("a", "b"))) == ["x/a", "x/b"]
    assert list(join_each("x", ("a", "b", "c"))) == ["x/a", "x/b", "x/c"]
    assert list(join_each("x", ())) == []
    assert list(join_each("x", (""))) == ["x/"]
    assert list(join_each("x", ("a", ""))) == ["x/a", "x/"]
    assert list(join_each("x", "ab")) == ["x/a", "x/b"]



# Generated at 2022-06-24 03:07:19.842418
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]

# Generated at 2022-06-24 03:07:21.806414
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['file1', 'file2', 'file3'])) == ['/tmp/file1', '/tmp/file2', '/tmp/file3']

# Generated at 2022-06-24 03:07:26.340545
# Unit test for function join_each
def test_join_each():
    parent = '/usr'
    files = ['bin/sh', 'lib/libc.a']
    for i, file in zip(range(len(files)), join_each(parent, files)):
        expected = os.path.join(parent, files[i])
        assert file == expected, "Expected: %s, got %s" % (expected, file)


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:07:31.651741
# Unit test for function join_each
def test_join_each():
    '''
    Test the return value of join_each
    '''
    parent = '/'
    iterable_list = ['a', 'b']
    joined_list = list(join_each(parent, iterable_list))

    # Test if each item returned is as expected
    for idx, p_joined in enumerate(joined_list):
        p_expected = os.path.join(parent, iterable_list[idx])
        assert p_joined == p_expected



# Generated at 2022-06-24 03:07:38.043372
# Unit test for function join_each
def test_join_each():
    parent = '/home/fabio'
    iterable = ['test', 'path', 'test']
    expected = [
        '/home/fabio/test',
        '/home/fabio/path',
        '/home/fabio/test'
    ]
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:07:46.102748
# Unit test for function join_each
def test_join_each():
    files = ('var/www/index.html', 'var/www/test.php', 'var/www/404.html')
    assert list(join_each('/usr/local/share/', files)) == [
        '/usr/local/share/var/www/index.html',
        '/usr/local/share/var/www/test.php',
        '/usr/local/share/var/www/404.html'
    ]

# Generated at 2022-06-24 03:07:50.848026
# Unit test for function join_each
def test_join_each():
    parent = "p"
    iterable = ["a", "b", "c", "d", "e"]

    results = []

    for i in join_each(parent, iterable):
        results.append(i)

    assert results == [
        "p/a",
        "p/b",
        "p/c",
        "p/d",
        "p/e",
    ]


# Imports
from itertools import chain



# Generated at 2022-06-24 03:07:56.652942
# Unit test for function join_each
def test_join_each():
    test_parent = 'home'
    test_iterable = ['one', 'two', 'three']

    test_list = [os.path.join(test_parent, item) for item in test_iterable]

    assert list(join_each(test_parent, test_iterable)) == test_list

# Generated at 2022-06-24 03:08:01.747376
# Unit test for function join_each
def test_join_each():
    parent = "C:/Foo"
    children = ["Bar", "Wombat"]
    result = list(join_each(parent, children))
    assert result == [os.path.join(parent, "Bar"), os.path.join(parent, "Wombat")]



# Generated at 2022-06-24 03:08:07.045392
# Unit test for function join_each
def test_join_each():
    parent = os.path.dirname(__file__)
    iterable = ['test', 'this', 'function']
    expected = [os.path.join(parent, 'test'), os.path.join(parent, 'this'), os.path.join(parent, 'function')]
    actual = [o for o in join_each(parent, iterable)]
    assert expected == actual, 'Expected {}, got {}'.format(expected, actual)



# Generated at 2022-06-24 03:08:11.708433
# Unit test for function join_each
def test_join_each():
    head = "foo"
    tail = ["bar", "baz"]
    assert list(join_each(head, tail)) == ["foo/bar", "foo/baz"]



# Generated at 2022-06-24 03:08:13.781348
# Unit test for function join_each
def test_join_each():
    assert join_each("/home/alice", ["dir", "dir2"]) == ["/home/alice/dir", "/home/alice/dir2"]
    assert join_each("/home/alice", []) == []
    assert join_each("/home/alice", [""]) == ["/home/alice/"]



# Generated at 2022-06-24 03:08:15.063156
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ('b', 'c'))) == ['/a/b', '/a/c']



# Generated at 2022-06-24 03:08:20.309354
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/aaa', ['/bbb', '/ccc'])) == ['/aaa/bbb', '/aaa/ccc']


root_dir = 'H:/eclipse-workspace'
# print(list(join_each(root_dir, os.listdir(root_dir))))



# Generated at 2022-06-24 03:08:21.930406
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-24 03:08:24.540580
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['user1', 'user2', 'user3'])) == ['/home/user1',
                                                                     '/home/user2',
                                                                     '/home/user3']



# Generated at 2022-06-24 03:08:26.511167
# Unit test for function join_each
def test_join_each():
    parent = 'c:/'
    result = tuple(join_each(parent, 'xyz'))
    expected = ('c:/x', 'c:/y', 'c:/z')
    assert result == expected



# Generated at 2022-06-24 03:08:30.845655
# Unit test for function join_each
def test_join_each():
    # Pre-conditions
    parent = "/Users/lvb/PycharmProjects/PythonProjects/Python_Tutorial/Projects/ThinkPython/exercise/Chapter 2"
    iterable = ["test.py", "test1.py"]
    assert list(join_each(parent, iterable)) == [
        "/Users/lvb/PycharmProjects/PythonProjects/Python_Tutorial/Projects/ThinkPython/exercise/Chapter 2/test.py",
        "/Users/lvb/PycharmProjects/PythonProjects/Python_Tutorial/Projects/ThinkPython/exercise/Chapter 2/test1.py"
    ]


# Tested: Properly testing recursive functions is quite tricky.
# We’ll start with a simple case that we can test by hand.


# Generated at 2022-06-24 03:08:34.876204
# Unit test for function join_each
def test_join_each():
    assert list(join_each('./foo', ['bar', 'baz'])) == ['./foo/bar', './foo/baz']



# Generated at 2022-06-24 03:08:42.396544
# Unit test for function join_each
def test_join_each():
    p = os.path.dirname(os.path.abspath(__file__))
    r = list(join_each(p, ["a", "b", "c"]))
    assert len(r) == 3
    assert r[0] == os.path.join(p, "a")
    assert r[1] == os.path.join(p, "b")
    assert r[2] == os.path.join(p, "c")
    assert r[0] == os.path.abspath(p + "/a")
    assert r[1] == os.path.abspath(p + "/b")
    assert r[2] == os.path.abspath(p + "/c")

# Generated at 2022-06-24 03:08:48.381164
# Unit test for function join_each
def test_join_each():
    """The function join_each work as the function os.path.join but with the iterable of
    string as the right operand. For example:

    >>> list(join_each('/home/user/dir', ['file1.ext', 'file2.ext', 'file3.ext']))
    ['/home/user/dir/file1.ext', '/home/user/dir/file2.ext', '/home/user/dir/file3.ext']

    """

    assert list(join_each('/home/user/dir', ['file1.ext', 'file2.ext', 'file3.ext'])) == \
           ['/home/user/dir/file1.ext', '/home/user/dir/file2.ext', '/home/user/dir/file3.ext']

# Generated at 2022-06-24 03:08:52.752183
# Unit test for function join_each
def test_join_each():
    parent = '/tmp/foo'
    iterable = ['bar/baz', 'buz/biz']
    assert list(join_each(parent, iterable)) == [
        '/tmp/foo/bar/baz', '/tmp/foo/buz/biz']



# Generated at 2022-06-24 03:08:55.908829
# Unit test for function join_each
def test_join_each():
    parent = '/path/to'

    assert list(join_each(parent, ['a', 'b', 'c'])) == [
        '/path/to/a',
        '/path/to/b',
        '/path/to/c',
    ]



# Generated at 2022-06-24 03:08:59.108920
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']

# Generated at 2022-06-24 03:09:00.771592
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/var/log", ["syslog", "kernel.log"])) == \
        ["/var/log/syslog", "/var/log/kernel.log"]

# Generated at 2022-06-24 03:09:07.790212
# Unit test for function join_each

# Generated at 2022-06-24 03:09:11.394449
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['bio', 'bio.py'])) == ['/home/bio', '/home/bio.py']



# Generated at 2022-06-24 03:09:15.616280
# Unit test for function join_each
def test_join_each():
    result = join_each('/test', ['a', 'b'])
    result = list(result)
    assert result[0] == '/test/a'
    assert result[1] == '/test/b'


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:09:18.344840
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each("/var", ("log", "lock"))) == ('/var/log', '/var/lock')



# Generated at 2022-06-24 03:09:21.192207
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar', 'baz'])) == [
        '/foo', '/bar', '/baz']



# Generated at 2022-06-24 03:09:24.788107
# Unit test for function join_each
def test_join_each():
    p = 'parent'
    for i, j in zip(('a', 'b', 'c'), join_each(p, ('a', 'b', 'c'))):
        assert i == j

# Generated at 2022-06-24 03:09:27.659250
# Unit test for function join_each
def test_join_each():
    parent = '/path/to/parent'
    iterable = ['child1', 'child2']
    actual = list(join_each(parent, iterable))
    expected = [os.path.join(parent, c) for c in iterable]
    assert actual == expected



# Generated at 2022-06-24 03:09:31.305246
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/timmy", ["a", "b", "c"])) == \
           ["/home/timmy/a", "/home/timmy/b", "/home/timmy/c"]



# Generated at 2022-06-24 03:09:35.766150
# Unit test for function join_each
def test_join_each():
    parent = '/'
    child = ('home', 'pi', '.config', 'autokey', 'data', 'Sample Scripts',
             'Sample Script.py')
    assert list(join_each(parent, child)) == [
        '/home',
        '/pi',
        '/.config',
        'autokey',
        '/data',
        '/Sample Scripts',
        '/Sample Script.py']

# Generated at 2022-06-24 03:09:37.680040
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['f1', 'f2'])) == [
        '/tmp/f1', '/tmp/f2'
    ]



# Generated at 2022-06-24 03:09:41.204755
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/foo", ["", "tmp", ""])) == [
        "/home/foo",
        "/home/footmp",
        "/home/foo",
    ]

# Generated at 2022-06-24 03:09:46.739771
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ['c', 'd', 'e'])) == ['/a/b/c', '/a/b/d', '/a/b/e']
    assert list(join_each('/a/b/', ['c', 'd', 'e'])) == ['/a/b/c', '/a/b/d', '/a/b/e']
    assert list(join_each('/a/b', [])) == []

# Generated at 2022-06-24 03:09:47.881315
# Unit test for function join_each
def test_join_each():
    assert join_each("foo", ["bar", "baz"]) == ["foo/bar", "foo/baz"]



# Generated at 2022-06-24 03:09:49.871059
# Unit test for function join_each
def test_join_each():
    result = list(join_each(r"c:\program files", [r"Microsoft", "Office", "Word"]))
    target = [r"c:\program files\Microsoft", r"c:\program files\Office", r"c:\program files\Word"]
    assert result == target



# Generated at 2022-06-24 03:09:55.679869
# Unit test for function join_each
def test_join_each():
    import tempfile
    d = tempfile.mkdtemp()
    for joined_path in join_each(d, ['a', 'b', 'c']):
        assert os.path.isdir(joined_path)
        os.rmdir(joined_path)



# Generated at 2022-06-24 03:09:58.159065
# Unit test for function join_each
def test_join_each():
    assert list(
        join_each("/home/user", ["", "..", "usr"])
    ) == [
        "/home/user",
        "/home",
        "/home/usr"
    ]



# Generated at 2022-06-24 03:10:01.478051
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/', ['home', 'valentin'])) == (
        '/home', '/valentin')



# Generated at 2022-06-24 03:10:06.510133
# Unit test for function join_each
def test_join_each():
    parent = '/usr/'
    iterable = ['bin', 'lib']
    expected_result = ['/usr/bin/', '/usr/lib/']
    actual_result = list(join_each(parent, iterable))

    assert expected_result == actual_result


if __name__ == "__main__":
    test_join_each()
    print("Done!")

# Generated at 2022-06-24 03:10:07.944203
# Unit test for function join_each
def test_join_each():
    import pytest

    assert list(join_each('/usr', ['bin', 'lib'])) == ['/usr/bin', '/usr/lib']



# Generated at 2022-06-24 03:10:13.538974
# Unit test for function join_each
def test_join_each():
    parent1 = os.path.join("a", "b")
    iterable1 = [os.path.join("c", "d"), os.path.join("e", "f")]
    assert list(join_each(parent1, iterable1)) == [os.path.join("a", "b", "c", "d"),
                                                   os.path.join("a", "b", "e", "f")]

# Generated at 2022-06-24 03:10:16.768549
# Unit test for function join_each
def test_join_each():
    assert list(join_each("./", ["a", "b", "c"])) == [
        "./a",
        "./b",
        "./c",
    ]



# Generated at 2022-06-24 03:10:20.385429
# Unit test for function join_each
def test_join_each():
    parent = "/home/foo"
    children = ["bar", "baz", "quux"]
    expected = ["/home/foo/bar", "/home/foo/baz", "/home/foo/quux"]
    joined = join_each(parent, children)
    assert isinstance(joined, types.GeneratorType)
    assert list(joined) == expected



# Generated at 2022-06-24 03:10:24.649223
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["a", "b"])) == ["foo/a", "foo/b"]



# Generated at 2022-06-24 03:10:28.047982
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-24 03:10:33.603924
# Unit test for function join_each
def test_join_each():
    parent = 'C:/Users/Lenovo/Desktop/A2'
    iterable = ['a', 'b', 'c']
    assert list(join_each(parent, iterable)) == \
           ['C:/Users/Lenovo/Desktop/A2/a',
            'C:/Users/Lenovo/Desktop/A2/b',
            'C:/Users/Lenovo/Desktop/A2/c']


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:10:38.027372
# Unit test for function join_each
def test_join_each():
    assert list(join_each(parent='c:\\',
                          iterable=['dir1', 'dir2', 'dir3', 'dir4'])) == [
               'c:\\dir1', 'c:\\dir2', 'c:\\dir3', 'c:\\dir4']


# Function flatten_iterable flattens a single level iterable
# Given an iterable, it returns an iterable of the next level

# Generated at 2022-06-24 03:10:39.784509
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr/bin", ["python", "java"])) == [
        "/usr/bin/python",
        "/usr/bin/java",
    ]



# Generated at 2022-06-24 03:10:41.434053
# Unit test for function join_each
def test_join_each():
    assert [f for f in join_each('/home', ['user', 'bin', 'file'])] == ['/home/user', '/home/bin', '/home/file']

# Generated at 2022-06-24 03:10:42.868771
# Unit test for function join_each

# Generated at 2022-06-24 03:10:55.780127
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/scott', 'ann', 'bob')) == [
        '/home/scott/ann', '/home/scott/bob']



# Generated at 2022-06-24 03:10:59.936035
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", "spam")) == ["/home/spam"]
    assert list(join_each("/home", ["spam", "eggs"])) == ["/home/spam", "/home/eggs"]
    assert list(join_each("/home", [])) == []

# Generated at 2022-06-24 03:11:07.234352
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ('a', 'b', 'c')

    joined = list(join_each(parent, iterable))

    # Test number of elements in list
    assert len(joined) == len(iterable)
    # Test each element in list
    for f in joined:
        assert f in [os.path.join(parent, p) for p in iterable]


# Test function join_each when no elements in list

# Generated at 2022-06-24 03:11:09.439830
# Unit test for function join_each
def test_join_each():
    parent_dir = "parent"
    children = ["child1", "child2", "child3"]
    # Assert correct type of returned object
    assert isinstance(join_each(parent_dir, children), types.GeneratorType)
    # Assert correct number of yields
    assert len(list(join_each(parent_dir, children))) == len(children)



# Generated at 2022-06-24 03:11:15.804152
# Unit test for function join_each
def test_join_each():
    # GIVEN
    parent = '/foo/bar'
    iterable = ['waldo', 'bob', 'jill']
    # WHEN
    actual = list(join_each(parent, iterable))
    # THEN
    expected = [
        '/foo/bar/waldo',
        '/foo/bar/bob',
        '/foo/bar/jill',
    ]
    assert actual == expected



# Generated at 2022-06-24 03:11:18.084824
# Unit test for function join_each
def test_join_each():
    tuples = (('a', 'b'), ('c', 'd'))
    assert list(join_each('/', t) for t in tuples) == ['/a/b', '/c/d']



# Generated at 2022-06-24 03:11:20.341334
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/bin', ['python', 'python3', 'pip'])) == [
        '/usr/bin/python', '/usr/bin/python3', '/usr/bin/pip']



# Generated at 2022-06-24 03:11:26.082058
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    iterable = ('test.txt', 'test2.txt')
    result = list(join_each(parent, iterable))
    expected = [os.path.join(parent, fn) for fn in iterable]
    assert expected == result

# Generated at 2022-06-24 03:11:34.082362
# Unit test for function join_each
def test_join_each():
    assert list(join_each(None, [''])) == ['']
    assert list(join_each('test', [''])) == ['test']
    assert list(join_each('test', ['one'])) == ['test/one']
    assert list(join_each('test', ['one', 'two', 'three'])) == [
        'test/one', 'test/two', 'test/three'
    ]



# Generated at 2022-06-24 03:11:39.169433
# Unit test for function join_each
def test_join_each():
    iter = ["demo", "demo1", "demo2"]
    result = list(join_each("path", iter))
    assert result == ['path\\demo', 'path\\demo1', 'path\\demo2']



# Generated at 2022-06-24 03:11:42.617275
# Unit test for function join_each
def test_join_each():
    file = join_each('/', ['tmp', '1.txt'])
    assert next(file) == '/tmp'
    assert next(file) == '/tmp/1.txt'
    assert next(file) == '/tmp/1.txt'
    assert next(file) == '/tmp/1.txt'



# Generated at 2022-06-24 03:11:45.882062
# Unit test for function join_each
def test_join_each():
    parent = '/tmp/'
    children = ['foo.txt', 'bar', 'baz.txt']
    joined = [os.path.join(parent, p) for p in children]
    assert list(join_each(parent, children)) == joined



# Generated at 2022-06-24 03:11:47.810413
# Unit test for function join_each
def test_join_each():
    assert [x for x in join_each("foo", ["bar", "baz"])] == ["foo/bar", "foo/baz"]



# Generated at 2022-06-24 03:11:51.313303
# Unit test for function join_each
def test_join_each():

    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a', 'bcd')) == ['a/b', 'a/c', 'a/d']



# Generated at 2022-06-24 03:11:54.820674
# Unit test for function join_each
def test_join_each():
    temp = join_each('root', ['A', 'B', 'C'])
    assert list(temp) == ['root/A', 'root/B', 'root/C']



# Generated at 2022-06-24 03:11:57.563507
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b", "c"])) == ["/tmp/a", "/tmp/b", "/tmp/c"]

# Generated at 2022-06-24 03:12:00.620824
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["/tmp/usr/local/bin", "/tmp/etc/passwd"])) == ["/tmp/usr/local/bin",
                                                                                  "/tmp/etc/passwd"]

# Generated at 2022-06-24 03:12:05.045633
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ['c', 'd'])) == ['/a/b/c', '/a/b/d']
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('/a', ['b', '/c'])) == ['/a/b', '/a/c']
    assert list(join_each('/a', ['/b', '/c'])) == ['/a/b', '/a/c']



# Generated at 2022-06-24 03:12:09.834893
# Unit test for function join_each
def test_join_each():
    # Arrange
    p = 'c:\\a'
    i = ['b', 'd', 'e']

    e = ['c:\\a\\b', 'c:\\a\\d', 'c:\\a\\e']

    # Act
    r = list(join_each(p, i))

    # Assert
    assert r == e

# Generated at 2022-06-24 03:12:14.270237
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b'])) == ['/tmp/a', '/tmp/b']

# Generated at 2022-06-24 03:12:19.154687
# Unit test for function join_each
def test_join_each():
    import os.path

    parent = os.path.dirname(__file__)
    children = ["setup.cfg", "README.md", "DOCS.md"]
    paths = join_each(parent, children)
    for i, p in enumerate(paths):
        assert p == os.path.join(parent, children[i])


if __name__ == "__main__":
    print(list(join_each(os.path.dirname(__file__), ["setup.cfg", "README.md", "DOCS.md"])))
    assert False

# Generated at 2022-06-24 03:12:23.988397
# Unit test for function join_each
def test_join_each():
    # フィルターにはmock.Mockを使う
    parent = "c:/a/b/c"
    iterable = ["a", "b", "c"]
    result = join_each(parent, iterable)
    expect = ["c:/a/b/c/a", "c:/a/b/c/b", "c:/a/b/c/c"]
    assert_equal(result, expect)


# Generated at 2022-06-24 03:12:25.259923
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['asd', 'fgh', 'jkl'])) == ['/home/asd', '/home/fgh', '/home/jkl']

# Generated at 2022-06-24 03:12:26.662022
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['root', 'boot'])) == ['/root', '/boot']



# Generated at 2022-06-24 03:12:29.408960
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b"])) == ["/tmp/a", "/tmp/b"]

# Generated at 2022-06-24 03:12:33.534359
# Unit test for function join_each
def test_join_each():
    actual = list(join_each("/Users", ["", "Yue", "github", "crappybird"]))
    assert actual == [
        "/Users",
        "/Users/Yue",
        "/Users/github",
        "/Users/crappybird"
    ]



# Generated at 2022-06-24 03:12:36.296210
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['/abc', 'abc'])) == ['/tmp/abc', '/tmp/abc']

# Generated at 2022-06-24 03:12:41.655158
# Unit test for function join_each
def test_join_each():
    assert join_each('parent', ['a', 'b', 'c']) == [
        'parent/a', 'parent/b', 'parent/c']



# Generated at 2022-06-24 03:12:47.166111
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/c', ['d', 'e'])) == ['/a/b/c/d', '/a/b/c/e']


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:12:56.370037
# Unit test for function join_each
def test_join_each():
    test_data = ['test', 'data']
    test_parent = 'test_parent'
    ans = join_each(test_parent, test_data)
    for i in range(2):
        assert test_data[i] == ans.next()

    test_data = ['test', 'data']
    test_parent = 'test_parent'
    ans = join_each(test_parent, test_data)
    assert next(ans) == os.path.join(test_parent, test_data[0])

# Generated at 2022-06-24 03:13:06.834757
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["usr", "bin", "bin"])) == \
                          ["/home/usr", "/home/bin", "/home/bin"]

    assert list(join_each("", ["usr", "bin", "bin"])) == \
                          ["usr", "bin", "bin"]

    assert list(join_each("/", ["usr", "bin", "bin"])) == \
                          ["/usr", "/bin", "/bin"]

    assert list(join_each(None, ["usr", "bin", "bin"])) == \
                          [None, None, None]

    assert list(join_each("/home", [])) == \
                          []

    assert list(join_each(None, [])) == \
                          []


# Generated at 2022-06-24 03:13:13.452842
# Unit test for function join_each
def test_join_each():
    folder_structure = [(1, []),
                        (2, []),
                        (3, [(4, []),
                             (5, []),
                             (6, [(7, []),
                                  (8, []),
                                  (9, []),
                                  ])
                             ])
                        ]


# Generated at 2022-06-24 03:13:16.367486
# Unit test for function join_each
def test_join_each():
    assert type(join_each("a", ["b", "c"])) is types.GeneratorType
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]



# Generated at 2022-06-24 03:13:27.841861
# Unit test for function join_each
def test_join_each():
    from tempfile import mkdtemp
    from shutil import rmtree
    tmpdir = mkdtemp()

# Generated at 2022-06-24 03:13:32.521446
# Unit test for function join_each
def test_join_each():
    parent = '/usr/local'
    files = ['bin', 'include', 'lib']
    expected = ['/usr/local/bin', '/usr/local/include', '/usr/local/lib']
    assert list(join_each(parent, files)) == expected



# Generated at 2022-06-24 03:13:35.610500
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["test", "me"])) == ["/test", "/me"]

# Generated at 2022-06-24 03:13:38.097503
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['bar', 'baz'])) == ['/foo/bar', '/foo/baz']



# Generated at 2022-06-24 03:13:40.759735
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-24 03:13:45.090907
# Unit test for function join_each
def test_join_each():
    expected = [
        os.path.join('/', 'foo'),
        os.path.join('/', 'bar'),
        os.path.join('/', 'baz'),
    ]
    paths = join_each('/', ['foo', 'bar', 'baz'])

    for p in paths:
        assert p in expected

# Generated at 2022-06-24 03:13:46.261494
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']

# Generated at 2022-06-24 03:13:48.988027
# Unit test for function join_each
def test_join_each():
    l = ['/home/subham', 'subham', 'subham_utils']
    for i, item in enumerate(join_each('/subham', l)):
        assert item == os.path.join('/subham', l[i])

