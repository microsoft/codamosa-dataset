

# Generated at 2022-06-24 03:03:52.394622
# Unit test for function join_each
def test_join_each():
    parent = 'path1'
    iterable = ['p', 'a', 't', 'h']
    assert list(join_each(parent, iterable)) == ['path1/p', 'path1/a', 'path1/t', 'path1/h']

# Generated at 2022-06-24 03:03:56.666137
# Unit test for function join_each
def test_join_each():

    assert list(join_each("/tmp", ["file1", "file2"])) == [
        "/tmp/file1",
        "/tmp/file2",
    ]

# Generated at 2022-06-24 03:04:01.668997
# Unit test for function join_each
def test_join_each():
    from itertools import chain
    from pathlib import Path

    # p is a single path that would be the result of one iteration of the
    # generator.
    for p in join_each("/a/b/c/d", chain("e", "fg", "hi")):
        assert p == Path("/a/b/c/d", "e")


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-24 03:04:04.548206
# Unit test for function join_each
def test_join_each():

    # Test 1
    iterable = [".", "..", "test", "test/unit"]
    parent = "/usr"

    assert list(join_each(parent, iterable)) == [os.path.join(parent, p) for p in iterable]

# Generated at 2022-06-24 03:04:12.911977
# Unit test for function join_each
def test_join_each():
    tests = (
        (('foo', ['bar', 'baz']), ['foo/bar', 'foo/baz']),
        (('foo/bar', ['baz', 'boz']), ['foo/bar/baz', 'foo/bar/boz']),
        (('/foo', ['bar', 'baz']), ['/foo/bar', '/foo/baz']),
    )
    for args, output in tests:
        assert list(join_each(*args)) == output

# Generated at 2022-06-24 03:04:18.160746
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr/bin", ["ls", "mkdir"])) == [
        "/usr/bin/ls",
        "/usr/bin/mkdir"
    ]



# Generated at 2022-06-24 03:04:20.818463
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child_1', 'child_2', 'child_3'])) == ['parent/child_1', 'parent/child_2', 'parent/child_3']



# Generated at 2022-06-24 03:04:23.524647
# Unit test for function join_each
def test_join_each():
    assert list(join_each("base", ["file1.txt", "file2.txt"])) == [
        "base/file1.txt",
        "base/file2.txt",
    ]



# Generated at 2022-06-24 03:04:28.638464
# Unit test for function join_each
def test_join_each():
    parent = '/home/k'
    iterable = ['a', 'b', 'c']
    expected = {os.path.join(parent, 'a'),
                os.path.join(parent, 'b'),
                os.path.join(parent, 'c')}
    assert set(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:04:32.888789
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/prefix', ['a', 'b', 'c'])) == [
        '/prefix/a', '/prefix/b', '/prefix/c']
    assert list(join_each('/prefix', [])) == []



# Generated at 2022-06-24 03:04:38.060965
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["1", "2", "3"])) == [
        "/tmp/1",
        "/tmp/2",
        "/tmp/3",
    ]
    assert list(join_each("/tmp", [])) == []



# Generated at 2022-06-24 03:04:43.588694
# Unit test for function join_each
def test_join_each():
    parent = 'D:'
    files = ['File1.py', 'File2.py']
    expected = ['D:/File1.py', 'D:/File2.py']
    result = list(join_each(parent,files))
    assert result == expected


# Parallelize the function join_each
# http://www.winpdb.org/
# https://docs.python.org/2/library/multiprocessing.html
# Note:  On Windows operating systems, use multiprocessing.Queue instead of multiprocessing.JoinableQueue.
import multiprocessing
from multiprocessing import Process, Queue


# Generated at 2022-06-24 03:04:46.020856
# Unit test for function join_each
def test_join_each():
    result = list(join_each('a', 'bc'))
    assert result == ['a/b', 'a/c']



# Generated at 2022-06-24 03:04:49.034247
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = iter(["a", "b", "c", "d", "e"])
    assert list(join_each(parent, iterable)) == list(
        map(lambda p: os.path.join(parent, p), iterable))



# Generated at 2022-06-24 03:04:52.399555
# Unit test for function join_each
def test_join_each():
    p = '/usr'
    ps = ['home', 'bin']

    assert ['/usr/home', '/usr/bin'] == list(join_each(p, ps))



# Generated at 2022-06-24 03:05:00.923141
# Unit test for function join_each
def test_join_each():
    parent = '/usr/local'
    iterable = ['bin', 'share', 'etc']
    result = list(join_each(parent, iterable))
    expected = [
        '/usr/local/bin',
        '/usr/local/share',
        '/usr/local/etc',
    ]
    assert result == expected, "Should be {0} but was {1}".format(expected, result)

# Generated at 2022-06-24 03:05:02.384857
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['bin', 'usr'])) == ['/bin', '/usr']



# Generated at 2022-06-24 03:05:05.834680
# Unit test for function join_each
def test_join_each():
    """
    Test join_each function
    """
    parent = '/home'
    iterable = ['/usr', 'bin']
    results = ['/home/usr', '/home/bin']
    actual = list(join_each(parent, iterable))
    assert actual == results


# Unit Test for function join_all

# Generated at 2022-06-24 03:05:09.664510
# Unit test for function join_each
def test_join_each():
    p = '/home/'
    paths = ['/etc/passwd', '/etc', 'test/']
    result = join_each(p, paths)
    expected = ['/home/etc/passwd', '/home/etc', '/home/test/']

    for r in result:
        assert r in expected



# Generated at 2022-06-24 03:05:13.391668
# Unit test for function join_each
def test_join_each():
    dir_path = '/foo/bar'
    expected = ['/foo/bar/one', '/foo/bar/two', '/foo/bar/three']
    actual = list(join_each(dir_path, ['one', 'two', 'three']))
    assert expected == actual



# Generated at 2022-06-24 03:05:16.378057
# Unit test for function join_each
def test_join_each():
    parent = "/Users/tsuyoshi/Projects"
    iterable = ("One", "Two", "Three")
    result = list(join_each(parent, iterable))

    assert len(result) == 3
    assert result[0] == os.path.join(parent, "One")
    assert result[1] == os.path.join(parent, "Two")
    assert result[2] == os.path.join(parent, "Three")

# Generated at 2022-06-24 03:05:18.057316
# Unit test for function join_each
def test_join_each():
    parent = 'a'
    iterable = ['b.txt', 'c.txt']
    result = list(join_each(parent, iterable))
    assert result == ['a/b.txt', 'a/c.txt']



# Generated at 2022-06-24 03:05:23.189872
# Unit test for function join_each
def test_join_each():
    assert list(join_each('./', [
        'a', 'b', 'c'
    ])) == ['./a', './b', './c']



# Generated at 2022-06-24 03:05:25.061462
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user/dir', ('foo', 'bar'))) == ['/home/user/dir/foo', '/home/user/dir/bar']



# Generated at 2022-06-24 03:05:29.024210
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:05:35.202796
# Unit test for function join_each
def test_join_each():
    # Case 1: non-empty iterable elements
    expected = [os.path.join('/', 'home'),
                os.path.join('/', 'etc'),
                os.path.join('/', 'var')]
    path_iter = ['home', 'etc', 'var']
    actual = [p for p in join_each('/', path_iter)]
    assert actual == expected

    # Case 2: empty iterable elements
    expected = []
    path_iter = []
    actual = [p for p in join_each('/', path_iter)]
    assert actual == expected



# Generated at 2022-06-24 03:05:40.870999
# Unit test for function join_each
def test_join_each():
    p = "/home/user"
    x = ["first", "second", "third"]
    r = join_each(p, x)
    assert list(r) == [os.path.join(p, e) for e in x]
    r = [p for p in join_each(p, x)]
    assert r == [os.path.join(p, e) for e in x]
    # Empty iterable
    r = join_each(p, [])
    assert list(r) == []

# Generated at 2022-06-24 03:05:47.779802
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    iterables = [
        ('a', 'b', 'c'),
        ('a', 'b/c'),
        ('/a', 'c'),
        ('a', '/c'),
    ]
    answers = [
        '/tmp/a/b/c',
        '/tmp/a/b/c',
        '/a/c',
        '/c',
    ]
    for iterable, answer in zip(iterables, answers):
        assert next(join_each(parent, iterable)) == answer

# Generated at 2022-06-24 03:05:48.957119
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/user/home', ['/test', '/othertest'])) == ['/user/home/test', '/user/home/othertest']



# Generated at 2022-06-24 03:05:51.572208
# Unit test for function join_each
def test_join_each():
    parent = "/path"
    iterable = ["a", "b"]
    expected = ["/path/a", "/path/b"]
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:05:57.840335
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/my/parent', ['child', 'another-child'])) == [
        '/my/parent/child', '/my/parent/another-child'
    ]
 
 
# Function find_files_recursively

# Generated at 2022-06-24 03:06:00.767552
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a', [])) == []



# Generated at 2022-06-24 03:06:03.449703
# Unit test for function join_each
def test_join_each():
    parent = 'test_parent'
    iterable = ['test1', 'test2', 'test3']
    res = [os.path.join(parent, it) for it in iterable]
    assert list(join_each(parent, iterable)) == res

# Generated at 2022-06-24 03:06:06.792520
# Unit test for function join_each
def test_join_each():
    parent = '/a/b'
    iterable = ('c', 'd')
    actual = list(join_each(parent, iterable))
    expected = ['/a/b/c', '/a/b/d']
    assert actual == expected



# Generated at 2022-06-24 03:06:12.581019
# Unit test for function join_each
def test_join_each():
    root_path = os.path.dirname(os.path.abspath(__file__))
    print('root_path : %s' % root_path)
    paths = join_each(root_path, ['data', 'test'])
    print('paths : %s' % list(paths))



# Generated at 2022-06-24 03:06:15.881882
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b'])) == ['/tmp/a', '/tmp/b']



# Generated at 2022-06-24 03:06:18.942836
# Unit test for function join_each
def test_join_each():
    parent = '/usr'
    children = ['bin', 'share', 'lib', '..', 'sf']
    assert set(join_each(parent, children)) == {
        '/usr/bin',
        '/usr/share',
        '/usr/lib',
        '/usr/..',
        '/usr/sf',
    }

# Generated at 2022-06-24 03:06:25.968674
# Unit test for function join_each
def test_join_each():
    parent = os.path.expanduser('~')

    paths = ('Documents', 'Code', 'rsa', 'encoding.py')

    for p, a in zip(
            join_each(parent, paths),
            (os.path.join(parent, p) for p in paths)
    ):
        assert p == a


if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-24 03:06:31.020822
# Unit test for function join_each
def test_join_each():
    parent = "foo"
    iterable = ["bar", "baz", "qux"]
    joined = join_each(parent, iterable)
    assert isinstance(joined, types.GeneratorType)
    assert list(joined) == ["foo/bar", "foo/baz", "foo/qux"]

# Generated at 2022-06-24 03:06:35.468707
# Unit test for function join_each
def test_join_each():
    source_path = os.path.join('var', 'log', 'apache2')
    logs = ['access.log', 'error.log']
    expected = [os.path.join(source_path, l) for l in logs]
    assert list(join_each(source_path, logs)) == expected



# Generated at 2022-06-24 03:06:39.375344
# Unit test for function join_each
def test_join_each():
    pkg = "examples/myproject"
    assert list(join_each(pkg, ["a", "b"])) == [os.path.join(pkg, "a"),
                                                os.path.join(pkg, "b")]



# Generated at 2022-06-24 03:06:42.125697
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["a", "b", "c"]
    expected = ["parent/a", "parent/b", "parent/c"]

    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:06:45.303376
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    paths = ['a', 'b', 'c']
    joined = list(join_each(parent, paths))
    expected = ['/tmp/a', '/tmp/b', '/tmp/c']
    assert joined == expected

# Generated at 2022-06-24 03:06:48.555319
# Unit test for function join_each
def test_join_each():
    a = ["a", "b", "c"]
    b = ["d", "e", "f"]
    assert list(join_each(a, b)) == ["ad", "ae", "af", "bd", "be", "bf", "cd", "ce", "cf"]



# Generated at 2022-06-24 03:06:52.346952
# Unit test for function join_each
def test_join_each():
    parent = "/home/damonkohler/foo"
    path_list = ["bar", "baz"]
    expected = "/home/damonkohler/foo/bar\n/home/damonkohler/foo/baz"
    assert "\n".join(expected, join_each(parent, path_list))



# Generated at 2022-06-24 03:06:53.809158
# Unit test for function join_each
def test_join_each():
    result = list(join_each('.', ['a', 'b']))
    assert result == ['./a', './b']



# Generated at 2022-06-24 03:06:57.035760
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == ['/tmp/a', '/tmp/b', '/tmp/c']



# Generated at 2022-06-24 03:06:59.901386
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-24 03:07:01.601219
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-24 03:07:06.084028
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp/", ["foo", "bar", "baz"])) == [
        "/tmp/foo",
        "/tmp/bar",
        "/tmp/baz",
    ]



# Generated at 2022-06-24 03:07:09.746719
# Unit test for function join_each
def test_join_each():
    parent = '/home/felipe'
    iterable = ['github', 'lib', 'vendor']
    expected = ['/home/felipe/github', '/home/felipe/lib', '/home/felipe/vendor']
    result = list(join_each(parent, iterable))
    assert result == expected

# Generated at 2022-06-24 03:07:11.377766
# Unit test for function join_each
def test_join_each():
    for f in join_each("p", ["a", "b"]):
        print(f)


# Unit tests for os.path.abspath

# Generated at 2022-06-24 03:07:13.618698
# Unit test for function join_each
def test_join_each():
    #  print(list(join_each('foo', ['bar', 'baz'])))
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:07:15.462492
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz", "bletch"])) == \
        ['foo/bar', 'foo/baz', 'foo/bletch']


# test_join_each()


# Generated at 2022-06-24 03:07:20.320238
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['usr', 'bin'])) == [
        '/usr', '/bin'
    ]


# Function checks if a folder is empty

# Generated at 2022-06-24 03:07:22.825356
# Unit test for function join_each
def test_join_each():
    parent = u"c:\\"
    iterable = ["foo", "bar"]
    expected = [u"c:\\foo", u"c:\\bar"]
    actual = list(join_each(parent, iterable))
    assert actual == expected

# Generated at 2022-06-24 03:07:27.152472
# Unit test for function join_each
def test_join_each():
    assert list(join_each('', ['a', 'b'])) == ['a', 'b']
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:07:29.149046
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-24 03:07:35.273099
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', [])) == []
    assert list(join_each('a', ['b', os.path.join('c', 'd')])) == ['a/b', 'a/c/d']

# Generated at 2022-06-24 03:07:36.348945
# Unit test for function join_each
def test_join_each():
    parent = '/tmp/'
    iterable = ('a', 'b')
    assert list(join_each(parent, iterable)) == ['/tmp/a', '/tmp/b']

# Generated at 2022-06-24 03:07:37.473136
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['one', 'two'])) == ['/one', '/two']

# Generated at 2022-06-24 03:07:41.371350
# Unit test for function join_each
def test_join_each():
    parent = '../'
    next(join_each(parent, []))

# Generated at 2022-06-24 03:07:46.745942
# Unit test for function join_each
def test_join_each():
    p = '/foo/bar'
    it = ['baz', 'zyx']
    j = join_each(p, it)
    assert j.__next__() == '/foo/bar/baz'
    assert j.__next__() == '/foo/bar/zyx'



# Generated at 2022-06-24 03:07:50.447321
# Unit test for function join_each
def test_join_each():
    assert [os.path.join('aaa', x) for x in ['bbb', 'ccc']] == list(join_each('aaa', ['bbb', 'ccc']))


# 获取文件绝对路径，相对于当前目录

# Generated at 2022-06-24 03:07:58.584370
# Unit test for function join_each
def test_join_each():
    assert list(join_each("dir1", ["dir2", "dir3"])) == [
        "dir1/dir2",
        "dir1/dir3",
    ]
    assert list(join_each("dir1", [])) == []


# is_visible has the same interface and return value as the unix is_visible
# function. It is implemented here to avoid a dependency on pythons built-in
# os.walk which is not available in python<3.6

# Generated at 2022-06-24 03:08:00.930377
# Unit test for function join_each
def test_join_each():
    childs = ['b', 'c']
    parent = 'a'
    assert list(join_each(parent, childs)) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:08:06.021667
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', ['Alice', 'Bob', 'Jack'])) == \
        ['/home/user/Alice', '/home/user/Bob', '/home/user/Jack']



# Generated at 2022-06-24 03:08:07.796821
# Unit test for function join_each
def test_join_each():
    res = list(join_each("/home", ["users", "bin"]))
    assert res == [os.path.join("/home", "users"), os.path.join("/home", "bin")]



# Generated at 2022-06-24 03:08:11.492865
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c'])



# Generated at 2022-06-24 03:08:16.337346
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['a', 'b', 'c'])) == ['./a', './b', './c']



# Generated at 2022-06-24 03:08:22.284674
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['foo', 'bar', 'baz'])) == [
        '/tmp' + os.path.sep + 'foo',
        '/tmp' + os.path.sep + 'bar',
        '/tmp' + os.path.sep + 'baz'
    ]



# Generated at 2022-06-24 03:08:25.656566
# Unit test for function join_each
def test_join_each():
    test_iterable = ['file1.txt', 'file2.txt', 'file3.txt']
    test_parent = '/home/test/'

    test_result = join_each(test_parent, test_iterable)

    for p in test_result:
        assert test_parent in p
        assert p.endswith('.txt')

# Generated at 2022-06-24 03:08:30.880678
# Unit test for function join_each
def test_join_each():
    assert tuple(
        join_each("/home/moi", ("../toi", "../tssi", "../nous"))
    ) == ("/home/../toi", "/home/../tssi", "/home/../nous")



# Generated at 2022-06-24 03:08:32.736728
# Unit test for function join_each
def test_join_each():
    assert list(join_each('folder', ['file1', 'file2'])) == [
        'folder/file1', 'folder/file2'
    ]

# Generated at 2022-06-24 03:08:36.650297
# Unit test for function join_each
def test_join_each():
    """Assert that given parent directory and iterable with relative paths joined to correct full paths."""
    parent = os.path.abspath(__file__)
    paths = ["../", "../../" + os.path.relpath(__file__, start=os.getcwd())]

    for p in join_each(parent, paths):
        assert os.path.exists(p)

# Generated at 2022-06-24 03:08:39.818685
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]

# Generated at 2022-06-24 03:08:44.335217
# Unit test for function join_each
def test_join_each():
    paths = ['/home/user/lorem', '/home/user/ipsum', '/home/user/dolor']
    assert list(join_each('foo', paths)) == [
        os.path.join('foo', '/home/user/lorem'),
        os.path.join('foo', '/home/user/ipsum'),
        os.path.join('foo', '/home/user/dolor')
    ]

# Generated at 2022-06-24 03:08:53.539416
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["a", "b", "c"])) == \
        ['/home/a', '/home/b', '/home/c']
    assert list(join_each("/home/", ["a", "b", "c"])) == \
        ['/home/a', '/home/b', '/home/c']
    assert list(join_each("/home", ["/a", "/b", "/c"])) == \
        ['/a', '/b', '/c']
    assert list(join_each("/home/", ["/a", "/b", "/c"])) == \
        ['/a', '/b', '/c']

# Generated at 2022-06-24 03:08:57.300141
# Unit test for function join_each
def test_join_each():
    # Test case 1: True test
    assert list(join_each('C:/', ['folder1', 'folder2'])) == ['C:/folder1', 'C:/folder2']

    # Test case 2: False test
    assert list(join_each('C:/', ['folder1', 'folder2'])) == ['C:/folder3', 'C:/folder4']

# Generated at 2022-06-24 03:09:00.402840
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp/', ['file1.txt', 'file2.txt'])) == ['/tmp/file1.txt', '/tmp/file2.txt']

# Generated at 2022-06-24 03:09:01.278731
# Unit test for function join_each
def test_join_each():
    print(list(join_each("/home", ["usr", "lib"])))



# Generated at 2022-06-24 03:09:03.377156
# Unit test for function join_each
def test_join_each():
    parent = "foo"
    iterable = ["one", "two"]
    expected = [os.path.join("foo", "one"), os.path.join("foo", "two")]
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:09:05.189501
# Unit test for function join_each
def test_join_each():
    root_path = '.'
    files = os.listdir(root_path)
    result = list(join_each(root_path, files))
    assert result == [os.path.join('.', f) for f in files]

# Generated at 2022-06-24 03:09:09.952289
# Unit test for function join_each
def test_join_each():
    from unittest import mock
    test_cases = [
        {
            'paths': ['tmp'],
            'iterable': ['a', 'b', 'c'],
            'expected_paths': ['tmp/a', 'tmp/b', 'tmp/c'],
        },
        {
            'paths': ['tmp', 'a'],
            'iterable': ['a', 'b', 'c'],
            'expected_paths': ['tmp/a/a', 'tmp/a/b', 'tmp/a/c'],
        },
    ]
    for test_case in test_cases:
        expected_paths = test_case['expected_paths']
        paths = test_case['paths']
        iterable = test_case['iterable']

# Generated at 2022-06-24 03:09:17.482969
# Unit test for function join_each
def test_join_each():
    l = ["foo", "bar"]
    expected = [
        os.path.join("/", "foo"),
        os.path.join("/", "bar"),
    ]
    assert list(join_each("/", l)) == expected

    s = set(l)
    assert list(join_each("/", s)) == expected

    expected = [
        os.path.join("/", "foo"),
        os.path.join("/", "bar"),
    ]
    assert list(join_each("/", iter(l))) == expected



# Generated at 2022-06-24 03:09:19.564450
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['/opt', '/etc', '/var'])) == [
        '/home/opt', '/home/etc', '/home/var'
    ]



# Generated at 2022-06-24 03:09:24.891703
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ('a', 'b', 'c'))) == [
        '/a', '/b', '/c'
    ], 'Join a list of strings with a parent path'



# Generated at 2022-06-24 03:09:27.140011
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/path/to', ('a', 'b', 'c'))) == ('/path/to/a', '/path/to/b', '/path/to/c')



# Generated at 2022-06-24 03:09:33.658377
# Unit test for function join_each
def test_join_each():
    # prepare sample data
    P = os.path.normpath('C:/Users/XXX/Desktop')
    for _ in join_each(P, ['tmp', 'mail', 'calander']):
        print(_)

if __name__ == '__main__':
    test_join_each() # Execute unit test

# Generated at 2022-06-24 03:09:37.051835
# Unit test for function join_each
def test_join_each():
    files_list = list(join_each("/", "usr", "local", "bin"))
    assert len(files_list) == 3
    assert files_list[0] == os.path.join("/", "usr")
    assert files_list[2] == os.path.join("/", "bin")



# Generated at 2022-06-24 03:09:38.612107
# Unit test for function join_each
def test_join_each():
    assert list(join_each("F:", ["a", "b"])) == ["F:\\a", "F:\\b"]



# Generated at 2022-06-24 03:09:41.626446
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a/b', ['/c', '/d'])) == ['a/b/c', 'a/b/d']



# Generated at 2022-06-24 03:09:44.428468
# Unit test for function join_each
def test_join_each():
    parent = "folder"
    iterable = ["bar", "baz"]
    joined = list(join_each(parent, iterable))
    assert joined == ["folder/bar", "folder/baz"]

# Generated at 2022-06-24 03:09:48.280550
# Unit test for function join_each
def test_join_each():
    parent = '/home/root/'
    iterable = ['test1', 'test2', 'test3']

    joined = list(join_each(parent, iterable))
    assert joined == [
        '/home/root/test1',
        '/home/root/test2',
        '/home/root/test3'
    ]

# Generated at 2022-06-24 03:09:55.684801
# Unit test for function join_each
def test_join_each():
    parent = '/home/maurice'
    paths = ['foo', 'bar', 'baz']

    expected_result = ['/home/maurice/foo', '/home/maurice/bar',
                       '/home/maurice/baz']
    result = join_each(parent, paths)

    assert expected_result == list(result)


# Unit tests for the functions in the os module

# Generated at 2022-06-24 03:09:56.869185
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:09:59.801225
# Unit test for function join_each
def test_join_each():
    t = [os.path.join('a', 'b'),
         os.path.join('a', 'c'),
         os.path.join('a', 'd')]
    assert list(join_each('a', ['b', 'c', 'd'])) == t



# Generated at 2022-06-24 03:10:06.166344
# Unit test for function join_each
def test_join_each():
    current_dir = os.path.dirname(os.path.realpath(__file__))
    assert list(join_each(current_dir, ['a', 'b', 'c'])) == [
        os.path.join(current_dir, 'a'),
        os.path.join(current_dir, 'b'),
        os.path.join(current_dir, 'c')
    ]

    assert list(join_each(current_dir, [])) == []

# Generated at 2022-06-24 03:10:11.555203
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a/b', ['c', 'd'])) == ['a/b/c', 'a/b/d']
    assert list(join_each('/a/b', ['c', 'd'])) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-24 03:10:16.879347
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    child1 = 'child1'
    child2 = 'child2'
    child3 = 'child3'
    result = list(join_each(parent, [child1, child2, child3]))
    assert result == [os.path.join(parent, child1), os.path.join(parent, child2), os.path.join(parent, child3)]



# Generated at 2022-06-24 03:10:17.689419
# Unit test for function join_each

# Generated at 2022-06-24 03:10:23.503696
# Unit test for function join_each
def test_join_each():
    assert sum(1 for _ in join_each('/', ['home'])) == 1
    assert list(join_each('/', [])) == []
    assert sum(1 for _ in join_each('/', ['home', 'user'])) == 2



# Generated at 2022-06-24 03:10:28.320238
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    input = ["a", "b", "c"]
    output = list(join_each(parent, input))
    expected = ["parent" + os.path.sep + "a", "parent" + os.path.sep + "b", "parent" + os.path.sep + "c"]
    assert output == expected

# Generated at 2022-06-24 03:10:32.599125
# Unit test for function join_each
def test_join_each():
    parent = '/'
    iterable = ['root', 'home', 'usr']
    expected_result = ['/root', '/home', '/usr']
    result = list(join_each(parent, iterable))
    assert expected_result == result, "Should return the result as expected."


# Bench mark for code block in function join_each

# Generated at 2022-06-24 03:10:34.909250
# Unit test for function join_each
def test_join_each():
    parent = "/foo/bar"
    iterable = ["baz", "quux"]
    result = list(join_each(parent, iterable))
    assert "/foo/bar/baz" in result
    assert "/foo/bar/quux" in result
    assert len(result) == 2



# Generated at 2022-06-24 03:10:37.047258
# Unit test for function join_each
def test_join_each():
    assert list(join_each('base', ('one', 'two', 'three'))) == \
        ['base/one', 'base/two', 'base/three']



# Generated at 2022-06-24 03:10:39.368910
# Unit test for function join_each
def test_join_each():
    assert list(join_each('usr', ['lib', 'bin'])) == [
        'usr/lib',
        'usr/bin'
    ]


# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-24 03:10:40.571173
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/', ['a', 'b'])) == ('/a', '/b')

# Generated at 2022-06-24 03:10:41.927092
# Unit test for function join_each
def test_join_each():
    assert list(join_each("path", ["p", "p2"])) == ["path/p", "path/p2"]



# Generated at 2022-06-24 03:10:56.848430
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = iter(['child1', 'child2'])
    expected = set([os.path.join(parent, 'child1'), os.path.join(parent, 'child2')])
    actual = set(join_each(parent, iterable))

    assert actual == expected



# Generated at 2022-06-24 03:11:01.827684
# Unit test for function join_each
def test_join_each():
    cases = (
        ([], ['a', 'b', 'c']),
        ([0], ['a', 'b', 'c']),
        (['x'], ['a', 'b', 'c']),
        (['x', 'y'], ['a', 'b', 'c']),
        (['x', 'y', 'z'], ['a', 'b', 'c']),
        (['x'], []),
        (['x'], [0]),
        (['x'], ['y']),
        (['x'], ['y', 'z']),
        (['x', 'y'], [0]),
        (['x', 'y'], ['z']),
        (['x', 'y'], ['z', 'a']),
    )


# Generated at 2022-06-24 03:11:03.759426
# Unit test for function join_each
def test_join_each():
    assert join_each('/a/b', ['c', 'd', 'e']) == ['/a/b/c', '/a/b/d', '/a/b/e']



# Generated at 2022-06-24 03:11:05.571183
# Unit test for function join_each
def test_join_each():
    result = list(join_each("/root", ["1", "2", "3"]))
    assert result == ["/root/1", "/root/2", "/root/3"]



# Generated at 2022-06-24 03:11:12.928772
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', ('passwd', 'group'))) == [
        '/etc/passwd',
        '/etc/group'
    ]
    assert list(join_each('/usr/local', ('share/man', 'share/doc', 'bin'))) == [
        '/usr/local/share/man',
        '/usr/local/share/doc',
        '/usr/local/bin'
    ]



# Generated at 2022-06-24 03:11:15.934276
# Unit test for function join_each
def test_join_each():

    parent = 'parent'
    iterable = ['one', 'two', 'three']

    assert [
        os.path.join(parent, p)
        for p in iterable
    ] == [
        p
        for p in join_each(parent, iterable)
    ]

# Generated at 2022-06-24 03:11:21.458272
# Unit test for function join_each
def test_join_each():
    parent = '/foo/bar'
    iterable = ['hello', 'world']
    result = ';'.join(join_each(parent, iterable))
    assert result == '/foo/bar/hello;/foo/bar/world', 'Result did not equal expected'

# Generated at 2022-06-24 03:11:22.807068
# Unit test for function join_each
def test_join_each():
    paths = join_each('parent', ['child1', 'child2'])
    assert list(paths) == ['parent/child1', 'parent/child2']



# Generated at 2022-06-24 03:11:25.288591
# Unit test for function join_each
def test_join_each():
    parent = "foo/bar"
    items = ["1", "2", "3"]
    items = list(join_each(parent, items))
    assert items[0] == "foo/bar/1"
    assert items[1] == "foo/bar/2"
    assert items[2] == "foo/bar/3"

# Generated at 2022-06-24 03:11:29.153695
# Unit test for function join_each
def test_join_each():
    paths = ["foo/bar/baz", "blah", "asdf/qwer"]
    expected = ["foo/bar/baz", "blah", "asdf/qwer"]
    assert list(join_each("", paths)) == expected
    expected = ["foo/bar/baz", "foo/bar/blah", "foo/bar/asdf/qwer"]
    assert list(join_each("foo", paths)) == expected
    expected = ["foo/bar/baz", "blah/foo", "asdf/qwer/foo"]
    assert list(join_each("foo", paths, postfix="foo")) == expected



# Generated at 2022-06-24 03:11:32.932160
# Unit test for function join_each
def test_join_each():
    assert list(join_each(
        "/home",
        ["user1", "user2", "user3"])
    ) == [
        "/home/user1",
        "/home/user2",
        "/home/user3"
    ]

# Generated at 2022-06-24 03:11:36.499010
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/parent", ["hello", "world"])) == [
        "/parent/hello",
        "/parent/world",
    ]

# Generated at 2022-06-24 03:11:41.132362
# Unit test for function join_each
def test_join_each():
    parent = '/home/gabriel'
    iterable = ['Downloads', 'Documents', 'Documents/Python']
    expected = ['/home/gabriel/Downloads',
                '/home/gabriel/Documents',
                '/home/gabriel/Documents/Python']
    actual = join_each(parent, iterable)
    assert expected == actual



# Generated at 2022-06-24 03:11:45.542980
# Unit test for function join_each
def test_join_each():
    parent_path = "/home/user"
    paths = ["foo", "bar"]

    expected = [os.path.join(parent_path, p) for p in paths]
    actual = list(join_each(parent_path, paths))
    assert expected == actual



# Generated at 2022-06-24 03:11:55.783974
# Unit test for function join_each
def test_join_each():
    test_paths = [
        ("/foo/bar", ["test", "test2", "test3"]),
        ("/foo/bar/", ["test", "test2", "test3"]),
        ("/foo/bar/", [("test", "test2")]),
        ("/foo/bar", os.path.join("test", "test2")),
        ("/foo/bar", os.path.join("test", os.path.join("test2", "test3"))),
        ("/foo/bar", "test")
    ]

    for path, iterable in test_paths:
        b = join_each(path, iterable)

        assert(path == next(b, None))
        assert(os.path.join(path, "test") == next(b, None))

# Generated at 2022-06-24 03:11:59.722636
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', 'bcd')) == ['a/b', 'a/c', 'a/d']
    assert list(join_each('a', ['b', 'c', 'd'])) == ['a/b', 'a/c', 'a/d']
# -----------------------------------------------------------------------------



# Generated at 2022-06-24 03:12:05.609229
# Unit test for function join_each
def test_join_each():
    parent = '/home/'
    iterable = ['u1', 'u2', 'u3']

    joined = list(join_each(parent, iterable))
    assert len(joined) == 3
    for p in joined:
        assert p.startswith(parent)



# Generated at 2022-06-24 03:12:10.299461
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    list_iter = ['a.txt', 'b.txt', 'c.txt']
    joined_file_list = ['/tmp/a.txt', '/tmp/b.txt', '/tmp/c.txt']
    assert list(join_each(parent, list_iter)) == joined_file_list



# Generated at 2022-06-24 03:12:14.155300
# Unit test for function join_each
def test_join_each():
    iterable = ['file.txt', 'dir', 'other.txt']
    parent = '/home/someone'

    assert list(join_each(parent, iterable)) == [
        '/home/someone/file.txt',
        '/home/someone/dir',
        '/home/someone/other.txt'
    ]

# Generated at 2022-06-24 03:12:18.833097
# Unit test for function join_each
def test_join_each():
    p, l = '/home/foo', ['a', 'b', 'c']
    j = join_each(p, l)
    assert next(j) == '/home/foo/a'
    assert next(j) == '/home/foo/b'
    assert next(j) == '/home/foo/c'
    with pytest.raises(StopIteration):
        next(j)
    # test if StopIteration raised once list exhausted
    # (https://docs.python.org/3/tutorial/classes.html#iterators)



# Generated at 2022-06-24 03:12:24.525558
# Unit test for function join_each
def test_join_each():
    iterable = [
        ['a', 'b', 'c'],
        ['d', 'e', 'f'],
        ['g', 'h', 'i'],
    ]
    parent = '/tmp'
    expected = [
        '/tmp/a/b/c',
        '/tmp/d/e/f',
        '/tmp/g/h/i',
    ]
    actual = list(join_each(parent, iterable))
    assert expected == actual



# Generated at 2022-06-24 03:12:28.985580
# Unit test for function join_each
def test_join_each():
    x = ['1', '2']
    p = 'o'
    z = ['o/1', 'o/2']
    res = list(join_each(p, x))
    assert res == z


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:12:31.817609
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/a/b', ('c', 'd'))) == ('/a/b/c', '/a/b/d')

# Generated at 2022-06-24 03:12:35.836767
# Unit test for function join_each
def test_join_each():
    assert list(join_each(".", ["x", "y"])) == [".", "./x", "./y"]

# Generated at 2022-06-24 03:12:37.738967
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    iterable = ['a', 'b', 'c', 'd.txt']
    expected_output = ['/tmp/a', '/tmp/b', '/tmp/c', '/tmp/d.txt']
    assert list(join_each(parent, iterable)) == expected_output



# Generated at 2022-06-24 03:12:42.892081
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/lib', ['a', 'b', 'c'])) == [
        '/usr/lib/a',
        '/usr/lib/b',
        '/usr/lib/c']



# Generated at 2022-06-24 03:12:44.701605
# Unit test for function join_each
def test_join_each():
    # Assert for the function
    assert list(join_each("/home", ["roy", "marry"])) == [
        "/home/roy",
        "/home/marry",
    ]

# Generated at 2022-06-24 03:12:47.948877
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/u/s', 'abc')) == ['/u/s/a', '/u/s/b', '/u/s/c']
    assert list(join_each('/u/s', ['a', 'b', 'c'])) == ['/u/s/a', '/u/s/b', '/u/s/c']
    assert list(join_each('/u/s', [])) == []



# Generated at 2022-06-24 03:12:53.355290
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/krome", ["a", "b", "c"])) == [
        "/home/krome/a",
        "/home/krome/b",
        "/home/krome/c",
    ]



# Generated at 2022-06-24 03:12:55.682278
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc/', ('passwd', 'services'))) == [
        '/etc/passwd',
        '/etc/services',
    ]

# Generated at 2022-06-24 03:12:59.379565
# Unit test for function join_each
def test_join_each():
    parent = "/foo"
    iterable = [
        "/bar",
        "baz",
        "quux"
    ]
    result = [
        "/foo/bar",
        "/foo/baz",
        "/foo/quux"
    ]
    assert list(join_each(parent, iterable)) == result



# Generated at 2022-06-24 03:13:09.432875
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each(
        "/tmp/dir",
        ("test1", "test2")
    )) == ("/tmp/dir/test1", "/tmp/dir/test2")


if __name__ == "__main__":
    from argparse import ArgumentParser

    parser = ArgumentParser(description="""
    Merges multiple directories.
    """)
    parser.add_argument(
        "src_dirs", metavar="src_dirs", nargs="+",
        help="Source directories.",
    )
    parser.add_argument(
        "-d", "--dest-dir", default=".",
        help="Destination directory.",
    )
    parser.add_argument(
        "-v", "--verbose",
        help="Verbose output.",
        action="store_true",
    )


# Generated at 2022-06-24 03:13:12.294510
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["./child", "child2"]
    expected = ["parent/./child", "parent/child2"]
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-24 03:13:16.439803
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']


# Helper for parsing Dockerfiles
here = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(here, 'Dockerfile')) as f:
    dockerfile = f.readlines()



# Generated at 2022-06-24 03:13:20.085450
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['', '/'])) == ['/', '/']
    assert list(join_each('/', ['a', '/b'])) == ['/a', '/b']



# Generated at 2022-06-24 03:13:23.116658
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["file1", "file2", "file3"])) == ["/tmp/file1", "/tmp/file2", "/tmp/file3"]



# Generated at 2022-06-24 03:13:25.898878
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == [
        "foo/bar",
        "foo/baz",
    ]

# Generated at 2022-06-24 03:13:30.547895
# Unit test for function join_each
def test_join_each():
    l = ["./foo/bar", "./bar/baz"]
    assert join_each("./", l) == ["./foo/bar", "./bar/baz"]

# Generated at 2022-06-24 03:13:33.493429
# Unit test for function join_each
def test_join_each():
    parent = pathlib.Path('/home')
    iterable = ['a', 'b']
    assert list(join_each(parent, iterable)) == \
           [pathlib.Path(p) for p in ['/home/a', '/home/b']]



# Generated at 2022-06-24 03:13:36.748101
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c', 'd'])) == ['a/b', 'a/c', 'a/d']



# Generated at 2022-06-24 03:13:41.597606
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a/b/c", ["x", "y", "z"])) == [
        "a/b/c/x",
        "a/b/c/y",
        "a/b/c/z",
    ]

# Generated at 2022-06-24 03:13:44.229153
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == ['/tmp/a', '/tmp/b', '/tmp/c']



# Generated at 2022-06-24 03:13:48.899804
# Unit test for function join_each
def test_join_each():
    # DefaultCase: test when no params passed
    assert list(join_each('/tmp', ['bin', 'sbin'])) == ['/tmp/bin', '/tmp/sbin']

    # SpecificCase: test when 'parent' is blank
    assert list(join_each('', ['bin', 'sbin'])) == ['bin', 'sbin']

    # SpecificCase: test when 'iterable' is blank
    assert list(join_each('/tmp', [])) == []

    # SpecificCase: test when both of which are blank
    assert list(join_each('', [])) == []
    assert list(join_each('/tmp', [])) == []

