

# Generated at 2022-06-24 03:03:50.025992
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo/bar', ['baz', 'qux'])) == [
        'foo/bar/baz',
        'foo/bar/qux'
    ]

# Generated at 2022-06-24 03:03:55.946132
# Unit test for function join_each
def test_join_each():
    parent = 'foo'
    iterable = ['bar', 'baz', 'qux']

    result = join_each(parent, iterable)
    expected = ['foo/bar', 'foo/baz', 'foo/qux']
    previous = ['foo', 'foo', 'foo']

    for result_path, expected in zip(result, expected):
        previous_path = expected.replace('/', '', 1) if expected != parent else ''
        assert result_path == expected and expected not in previous_path, "result = {}, expected = {}, previous = {}".format(result_path, expected, previous_path)
        previous.append(expected)



# Generated at 2022-06-24 03:04:01.498135
# Unit test for function join_each
def test_join_each():
    expected = [
        os.path.join('foo', 'bar'),
        os.path.join('foo', 'baz'),
        os.path.join('foo', 'qux'),
    ]
    actual = list(join_each('foo', ['bar', 'baz', 'qux']))

    assert expected == actual

# Generated at 2022-06-24 03:04:06.759766
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/home/apophis', ['bin', 'Documents', 'Music']))
    expected = [
        '/home/apophis/bin',
        '/home/apophis/Documents',
        '/home/apophis/Music',
    ]
    assert result == expected



# Generated at 2022-06-24 03:04:10.819970
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/path/to", ["log", "alert", "debug"])) == [
        "/path/to/log", "/path/to/alert", "/path/to/debug"
    ]

# Generated at 2022-06-24 03:04:12.440068
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['bar', 'baz'])) == ['/foo/bar', '/foo/baz']



# Generated at 2022-06-24 03:04:21.258998
# Unit test for function join_each
def test_join_each():
    assert [p for p in join_each('/a', ['/b', '/c', '/d'])] == ['/a/b', '/a/c', '/a/d']
    assert [p for p in join_each('/a/b/c', ['d', 'e', 'f'])] == ['/a/b/c/d', '/a/b/c/e', '/a/b/c/f']
    assert [p for p in join_each('', ['1', '2', '3'])] == ['1', '2', '3']



# Generated at 2022-06-24 03:04:25.360019
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a/b', 'c/d'])) == ['/a/b', '/c/d']
    assert list(join_each('', ['a/b', 'c/d'])) == ['a/b', 'c/d']


# Recursive walk printing each path and filename

# Generated at 2022-06-24 03:04:28.942113
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each("/usr/local/bin", ("python", "python2.7"))) == ("/usr/local/bin/python",
                                                                           "/usr/local/bin/python2.7")



# Generated at 2022-06-24 03:04:31.411327
# Unit test for function join_each
def test_join_each():
    assert list(join_each("test", ["a", "b"])) == ["test/a", "test/b"]
    assert list(join_each("test", ["/a", "/b"])) == ["test/a", "test/b"]



# Generated at 2022-06-24 03:04:36.527552
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b'])) == ['a/b']
    assert list(join_each('a', [])) == []
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-24 03:04:40.392155
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    assert list(join_each(parent, ['/dev/null'])) == ['/dev/null']
    assert list(join_each(parent, ['dev', 'null'])) == ['/tmp/dev/null']
    assert list(join_each(parent, ['dev', 'null', 'test'])) == ['/tmp/dev/null/test']

# Generated at 2022-06-24 03:04:44.414944
# Unit test for function join_each
def test_join_each():
    i = ["one", "two", "three"]
    o = join_each("parent", i)
    for result, expect in zip(o, ["parent/one", "parent/two", "parent/three"]):
        assert result == expect


if __name__ == "__main__":
    pass

# Generated at 2022-06-24 03:04:46.975291
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child1', 'child2'])) == [
        'parent/child1', 'parent/child2']



# Generated at 2022-06-24 03:04:52.823158
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', 'abcdef'.split())) == \
           ['/tmp/a', '/tmp/b', '/tmp/c', '/tmp/d', '/tmp/e', '/tmp/f']



# Generated at 2022-06-24 03:05:01.120463
# Unit test for function join_each
def test_join_each():
    examples = (
        # Parent, children, expected results
        ('/one', ('two', 'three'), ('/one/two', '/one/three')),
        ('/one/', ('two', 'three'), ('/one/two', '/one/three')),
        ('/one', ('/two', 'three'), ('/two', '/one/three')),
        ('/one/', ('/two', 'three'), ('/two', '/one/three')),
    )

    # check each case
    for parent, children, expected_results in examples:
        actual_results = tuple(join_each(parent, children))
        assert actual_results == expected_results, \
            'join_each({0}, {1}) gives {2} but expected {3}'.\
            format(parent, children, actual_results, expected_results)



# Generated at 2022-06-24 03:05:02.613123
# Unit test for function join_each
def test_join_each():
    assert join_each('a', ['b', 'c']) == ['a/b', 'a/c']

# Generated at 2022-06-24 03:05:05.761970
# Unit test for function join_each
def test_join_each():
    parent = '/Users/username/applesauce/'
    iterable = ['woo', 'hoo']
    result = ['/Users/username/applesauce/woo', '/Users/username/applesauce/hoo']
    assert list(join_each(parent, iterable)) == result

# Generated at 2022-06-24 03:05:07.615426
# Unit test for function join_each
def test_join_each():
    assert list(join_each("abc", ["def", "ghi"])) == ["abc/def", "abc/ghi"]



# Generated at 2022-06-24 03:05:10.573129
# Unit test for function join_each
def test_join_each():
    assert [os.path.join('/home', '/etc'), os.path.join('/home', '/usr')] == list(join_each('/home', ['/etc', '/usr']))



# Generated at 2022-06-24 03:05:13.225181
# Unit test for function join_each
def test_join_each():
    assert (['join/each', 'join/each/path'] ==
            list(join_each('join', ['each', 'each/path'])))



# Generated at 2022-06-24 03:05:15.480689
# Unit test for function join_each
def test_join_each():
    assert list(join_each('data', ['a', 'b', 'c'])) == [
        'data/a', 'data/b', 'data/c']



# Generated at 2022-06-24 03:05:19.625518
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-24 03:05:21.368226
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]



# Generated at 2022-06-24 03:05:23.598956
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    base = ["child1", "child2"]
    expected = ["parent/child1", "parent/child2"]
    assert list(join_each(parent, base)) == expected



# Generated at 2022-06-24 03:05:26.032550
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['foo', 'bar'])) == ['./foo', './bar']
    assert list(join_each('dir', ['foo', 'bar'])) == ['./dir/foo', './dir/bar']



# Generated at 2022-06-24 03:05:29.171158
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:05:33.150672
# Unit test for function join_each
def test_join_each():
    expected = [
        "/home/user/doc/foo.txt",
        "/home/user/doc/bar.txt",
        "/home/user/doc/baz.txt",
    ]
    assert list(join_each("/home/user/doc", ["foo.txt", "bar.txt", "baz.txt"])) == expected

# Generated at 2022-06-24 03:05:39.862216
# Unit test for function join_each
def test_join_each():
    # Arrange
    parent = '..'
    iterable = ['..', 'test', '..']
    expected_valid = ['../../', '../test', '.././']

    # Act
    actual = list(join_each(parent, iterable))

    # Assert
    assert actual == expected_valid, "expected is {}, actual is {}".format(expected_valid, actual)



# Generated at 2022-06-24 03:05:42.353230
# Unit test for function join_each
def test_join_each():
    # parent = os.path.dirname(__file__)
    parent = os.getcwd()
    import sys
    print(sys.path)
    print(list(join_each(parent, sys.path)))



# Generated at 2022-06-24 03:05:46.894131
# Unit test for function join_each
def test_join_each():
    test_dir = 'dir1/dir2'
    test_result = ['dir1/dir2/file1.txt', 'dir1/dir2/file2.txt']
    assert list(join_each(test_dir, ['file1.txt', 'file2.txt'])) == test_result
    assert list(
        join_each(test_dir, iter(['file1.txt', 'file2.txt']))) == test_result



# Generated at 2022-06-24 03:05:53.168443
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/john', ['a', 'b', 'c'])) == [os.path.join('/home/john', 'a'),
                                                              os.path.join('/home/john', 'b'),
                                                              os.path.join('/home/john', 'c')]



# Generated at 2022-06-24 03:06:02.103665
# Unit test for function join_each
def test_join_each():
    # Test None, "" and None
    assert list(join_each(None, None)) == []

    # Test empty string, "" and "abc"
    assert list(join_each("", "abc")) == ["abc"]

    # Test string "abc", "" and "def"
    assert list(join_each("abc", ["", "def"])) == ["abc", "abc/def"]

    # Test string "abc", ["def", "ghi"] and empty string
    assert list(join_each("abc", ["def", "ghi", ""])) == [
        "abc/def", "abc/ghi", "abc/"
    ]



# Generated at 2022-06-24 03:06:04.391922
# Unit test for function join_each
def test_join_each():

    assert list(join_each("/tmp", ["a", "b", "c"])) == ["/tmp/a", "/tmp/b",
                                                        "/tmp/c"]



# Generated at 2022-06-24 03:06:06.831823
# Unit test for function join_each
def test_join_each():
    s = ["a", "b"]
    assert list(join_each("c", s)) == ["c/a", "c/b"]



# Generated at 2022-06-24 03:06:12.859289
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["foo", "bar", "baz"])) == [
        "/foo", "/bar", "/baz"
    ]
    assert list(join_each("/usr/lib", ["foo.so", "bar", "baz.so"])) == [
        "/usr/lib/foo.so", "/usr/lib/bar", "/usr/lib/baz.so"
    ]
    assert list(join_each("/lib64", ["libfoo.so", "libbar.so"])) == [
        "/lib64/libfoo.so", "/lib64/libbar.so"
    ]

# Generated at 2022-06-24 03:06:18.941741
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/bin", ["foo", "bar"])) == [
        "/bin/foo",
        "/bin/bar",
    ]

# Generated at 2022-06-24 03:06:24.430678
# Unit test for function join_each
def test_join_each():
    from itertools import product
    from operator import itemgetter

    # Create test set.
    test_set = list(product(
        ['', '', 'a', 'a', 'a'],
        ['', '', '/', '/', '/'],
        ['', '', 'b', 'b', 'b']
    ))
    # Remove special case
    test_set.remove(('a', '/', 'b'))

    parent, sep, p = itemgetter(0, 1, 2)
    expect = list(map(lambda t: os.path.join(parent(*t), p(*t)), test_set))

    result = list(join_each(parent, (p for p in iter(sep))))
    assert expect == result

# Generated at 2022-06-24 03:06:31.015558
# Unit test for function join_each
def test_join_each():
    parent = '/home/guillaume/Documents'
    file1 = 'tutorial.rst'
    file2 = 'tutorial'
    file3 = 'tutorial.rst.pdf'
    file4 = 'tutorial.pdf'
    paths_list = [file1, file2, file3, file4]

    result_list = ['/home/guillaume/Documents/tutorial.rst',
                   '/home/guillaume/Documents/tutorial',
                   '/home/guillaume/Documents/tutorial.rst.pdf',
                   '/home/guillaume/Documents/tutorial.pdf']

    result = list(join_each(parent, paths_list))

    assert result == result_list



# Generated at 2022-06-24 03:06:36.796976
# Unit test for function join_each
def test_join_each():
    paths = (("/a/b", ("c", "d", "e")), ("c:\\", ("d", "e", "f")))
    expected = ("/a/b/c", "/a/b/d", "/a/b/e", "c:\\d", "c:\\e", "c:\\f")
    join_output = join_each(*paths)
    assert expected == join_output



# Generated at 2022-06-24 03:06:39.815135
# Unit test for function join_each
def test_join_each():
    parent = ".."
    iterable = ["file1", "file2"]
    assert list(join_each(parent, iterable)) == [
        "../file1",
        "../file2",
    ]

# Generated at 2022-06-24 03:06:43.282766
# Unit test for function join_each
def test_join_each():
    joined = list(join_each('/', ['a', 'b']))
    assert joined == ['/a', '/b']

    joined = list(join_each('/', ['a', 'b/c']))
    assert joined == ['/a', '/b/c']

    joined = list(join_each('/', []))
    assert joined == []



# Generated at 2022-06-24 03:06:46.959911
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ('foo', 'bar'))) == ['/foo', '/bar']


# Function that takes a string, and returns a dict with each path
# in the string as a key, and a tuple of the corresponding filenames
# as the value of that key

# Generated at 2022-06-24 03:06:49.760964
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/pi/', ['bin', 'Desktop', 'Documents'])) == [
               '/home/pi/bin', '/home/pi/Desktop', '/home/pi/Documents']

# Generated at 2022-06-24 03:06:51.627499
# Unit test for function join_each
def test_join_each():
    parent = r"/abc"
    assert [r"/abc/x", r"/abc/y"] == list(join_each(parent, ["x", "y"]))



# Generated at 2022-06-24 03:06:53.148775
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/foo", ["bar", "baz"])) == [
        "/foo/bar",
        "/foo/baz",
    ]



# Generated at 2022-06-24 03:06:55.955182
# Unit test for function join_each
def test_join_each():
    path = os.path.abspath(os.path.join(__file__, os.pardir))
    result = list(join_each(path, ['a', 'b']))
    assert result == [os.path.join(path, 'a'), os.path.join(path, 'b')]



# Generated at 2022-06-24 03:07:01.604333
# Unit test for function join_each
def test_join_each():
    assert '/foo/bar' == next(join_each('/foo', ['bar']))
    assert '/foo/bar' == next(join_each('/foo', ['bar']))
    assert '/foo/bar' == list(join_each('/foo', ['bar']))[0]


# Generates a sequence of ancestor paths of the given path

# Generated at 2022-06-24 03:07:03.739503
# Unit test for function join_each
def test_join_each():
    parent = "/home"
    iterable = ["user", "user1"]
    assert list(join_each(parent, iterable)) == [
        "/home/user",
        "/home/user1"]

# Generated at 2022-06-24 03:07:05.628049
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/notroot', ['dev', 'usr'])) == ['/home/notroot/dev', '/home/notroot/usr']

# Generated at 2022-06-24 03:07:11.309266
# Unit test for function join_each
def test_join_each():
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_join_each = os.path.join(test_dir, "test_join_each")

    result = join_each(test_join_each, ["one", "two"])
    assert next(result) == os.path.join(test_join_each, "one")
    assert next(result) == os.path.join(test_join_each, "two")
    pytest.raises(StopIteration, lambda: next(result))



# Generated at 2022-06-24 03:07:15.145473
# Unit test for function join_each
def test_join_each():
    parent = "a"
    paths = join_each(parent, ["b", "c", "d"])
    assert next(paths) == os.path.join(parent, "b")
    assert next(paths) == os.path.join(parent, "c")
    assert next(paths) == os.path.join(parent, "d")
    with pytest.raises(StopIteration):
        next(paths)



# Generated at 2022-06-24 03:07:20.160478
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['a', 'b', 'c'])) == ['./a', './b', './c']

# Generated at 2022-06-24 03:07:22.406569
# Unit test for function join_each
def test_join_each():
    tests = (
        (('a', ['b']), 'a/b'),
    )
    for test, expect in tests:
        assert list(join_each(*test)) == expect



# Generated at 2022-06-24 03:07:27.971339
# Unit test for function join_each
def test_join_each():
    # Creating a string iterable for testing, for testing purposes
    class StringIterable:
        def __init__(self, array):
            self._array = array

        def __iter__(self):
            return iter(self._array)

    # Asserting that join_each produces the correct output
    assert list(join_each("path", StringIterable(["one", "two", "three"]))) == ["path/one", "path/two", "path/three"]



# Generated at 2022-06-24 03:07:30.869836
# Unit test for function join_each
def test_join_each():
    parent = os.path.dirname(__file__)
    children = ['test_join_each.py', 'test_join_each.pyc']
    assert list(join_each(parent, children)) == [os.path.join(parent, p) for p in children]

# Generated at 2022-06-24 03:07:36.926358
# Unit test for function join_each
def test_join_each():
    test_sequence = ['a', 'b', 'c']
    test_expected = ['path/to/a', 'path/to/b', 'path/to/c']

    assert list(join_each('path/to', test_sequence)) == test_expected

# Generated at 2022-06-24 03:07:42.929066
# Unit test for function join_each
def test_join_each():
    parent = "hello"
    iterable = ["world", "dolly", "bird"]

    result = list(join_each(parent, iterable))
    assert result == ["hello/world", "hello/dolly", "hello/bird"]


# Check if a particular directory is a Git repo

# Generated at 2022-06-24 03:07:46.520976
# Unit test for function join_each
def test_join_each():
    parent = "PATH/TO/"
    iterable = ("foo", "bar")
    assert list(join_each(parent, iterable)) == ["PATH/TO/foo", "PATH/TO/bar"]

# Generated at 2022-06-24 03:07:48.070882
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar'])) == ['/foo', '/bar']



# Generated at 2022-06-24 03:07:52.273258
# Unit test for function join_each
def test_join_each():
    join_each(os.path.expanduser('~'), ['tmp', 'foo', 'bar'])

# Generated at 2022-06-24 03:07:56.595674
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/base", ["/a", "/b", "/c"])) == [
            "/base/a", "/base/b", "/base/c"]



# Generated at 2022-06-24 03:08:02.071746
# Unit test for function join_each
def test_join_each():
    # list of the paths to join
    paths = ['test1', 'test2', 'test3']

    # join each path
    for path in join_each('/', paths):
        # make sure it's joined
        assert path == '/test1' or path == '/test2' or path == '/test3'

# Generated at 2022-06-24 03:08:04.021974
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]



# Generated at 2022-06-24 03:08:05.784101
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo/bar', ['spam', 'eggs'])) == ['foo/bar/spam', 'foo/bar/eggs']



# Generated at 2022-06-24 03:08:09.150229
# Unit test for function join_each
def test_join_each():
    for parent in ["/var/log", "https://www.google.com"]:
        for iterable in ["log.txt", ["file1", "file2"],
                         (t + ".txt" for t in ["file1", "file2"])]:
            print(parent, iterable)
            assert list(join_each(parent, iterable)) == \
                [os.path.join(parent, p) for p in iterable]

# Generated at 2022-06-24 03:08:10.065927
# Unit test for function join_each
def test_join_each():
    res = list(join_each("/some", ["one", "two"]))
    assert res == ["/some/one", "/some/two"]



# Generated at 2022-06-24 03:08:11.743888
# Unit test for function join_each
def test_join_each():
    assert list(join_each("spam", ["eggs", "bacon"])) == ["spam/eggs", "spam/bacon"]



# Generated at 2022-06-24 03:08:14.189629
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a'+i for i in ['\\b', '\\c']]



# Generated at 2022-06-24 03:08:23.676956
# Unit test for function join_each
def test_join_each():

    parent = "test_join_each"

    # Create a directory to test the function
    os.mkdir(parent)

    # In this case, the wanted outcome would be 4 files joined
    # to the parent directory
    for i in range(4):
        open(os.path.join(parent, str(i)), 'w').close()

    files_joined = list(join_each(parent, os.listdir(parent)))

    # Assert that the number of files joined = 4
    assert len(files_joined) == 4

    # Assert that all files are correctly joined to the parent
    for f in files_joined:
        assert os.path.exists(f)

    # Delete the directory we created
    shutil.rmtree(parent)



# Generated at 2022-06-24 03:08:29.424301
# Unit test for function join_each
def test_join_each():
    parent = 'data'
    iterable = ['1.txt', '2.txt', '3.txt']
    expected = ['data/1.txt', 'data/2.txt', 'data/3.txt']
    for actual, expect in zip(join_each(parent, iterable), expected):
        assert actual == expect



# Generated at 2022-06-24 03:08:32.502184
# Unit test for function join_each
def test_join_each():
    path = os.path.join
    assert tuple(join_each(path('a'), ('b', 'c', 'd'))) == (path('a', 'b'), path('a', 'c'), path('a', 'd'))



# Generated at 2022-06-24 03:08:33.935576
# Unit test for function join_each
def test_join_each():
    assert list(join_each('m', ['a', 'b'])) == ['m/a', 'm/b']

# Generated at 2022-06-24 03:08:35.920329
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('foo', ['bar', 'baz'])) == ('foo/bar', 'foo/baz')



# Generated at 2022-06-24 03:08:39.804273
# Unit test for function join_each
def test_join_each():
    assert list(join_each('dir', ['a', 'b'])) == ['dir/a', 'dir/b']



# Generated at 2022-06-24 03:08:41.831172
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/root', ['file1', 'file2'])) == [
        '/root/file1', '/root/file2'
    ]

# Generated at 2022-06-24 03:08:45.141133
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/foo/", ["a", "b"])) == ["/home/foo/a", "/home/foo/b"]
    assert list(join_each("/home/foo/", ["a", "b", ".."])) == ["/home/foo/a", "/home/foo/b", "/home/foo/.."]

# Generated at 2022-06-24 03:08:48.265656
# Unit test for function join_each
def test_join_each():
    p = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    ps = join_each(p, ['data', 'tests'])
    for name in ps:
        assert os.path.isfile(name)



# Generated at 2022-06-24 03:08:53.591614
# Unit test for function join_each
def test_join_each():
    path = "/home/user/folder1"
    assert list(join_each(path, ["file1", "file2", "file3"])) == [
        "/home/user/folder1/file1", "/home/user/folder1/file2", "/home/user/folder1/file3"
    ]
    assert list(join_each(path, [])) == []



# Generated at 2022-06-24 03:08:58.166529
# Unit test for function join_each
def test_join_each():
    # Test for empty iterable
    assert list(join_each("/tmp", [])) == []

    # Test for relative paths and single element iterable
    assert list(join_each("/tmp", ["file1.txt"])) == ["/tmp/file1.txt"]

    # Test for relative paths and multi element iterable
    assert list(join_each("/tmp", ["file1.txt", "file2.txt"])) == ["/tmp/file1.txt", "/tmp/file2.txt"]

    # Test for absolute paths and single element iterable
    assert list(join_each("/tmp", ["/file1.txt"])) == ["/file1.txt"]

    # Test for absolute paths and multi element iterable

# Generated at 2022-06-24 03:09:05.939113
# Unit test for function join_each
def test_join_each():
    dirs = ["dir1", "dir2", "dir3"]
    assert list(join_each("/tmp", dirs)) == ['/tmp/dir1', '/tmp/dir2', '/tmp/dir3']
    dirs = ["dir1"]
    assert list(join_each("/tmp", dirs)) == ['/tmp/dir1']
    dirs = []
    assert list(join_each("/tmp", dirs)) == []



# Generated at 2022-06-24 03:09:07.536236
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['x', 'y'])) == [
        'foo/x', 'foo/y']



# Generated at 2022-06-24 03:09:11.530121
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', [
        'child', 'child2', 'child3'
    ])) == ['parent/child', 'parent/child2', 'parent/child3']



# Generated at 2022-06-24 03:09:15.124953
# Unit test for function join_each
def test_join_each():
    rv = join_each('/a/b', ['c', 'd'])
    assert next(rv) == '/a/b/c'
    assert next(rv) == '/a/b/d'



# Generated at 2022-06-24 03:09:17.305006
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:09:25.107522
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    child1 = "child1"
    child2 = "child2"
    child3 = "child3"
    children = [child1, child2, child3]
    children_paths = list(join_each(parent, children))
    expected_paths = [os.path.join(parent, child1),
                      os.path.join(parent, child2),
                      os.path.join(parent, child3)]
    assert children_paths == expected_paths



# Generated at 2022-06-24 03:09:30.386986
# Unit test for function join_each
def test_join_each():
    # When parent is empty
    assert list(join_each('', ['01-Baby-It%27s-Cold-Outside.mp3',
                               '02-Frosty-The-Snowman.mp3'])) == \
           [os.path.join('', '01-Baby-It%27s-Cold-Outside.mp3'),
            os.path.join('', '02-Frosty-The-Snowman.mp3')]

# Generated at 2022-06-24 03:09:31.518270
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b'])) == ['/a/b']



# Generated at 2022-06-24 03:09:39.366912
# Unit test for function join_each
def test_join_each():
    path1 = '/home/thomas/Documents'
    path2 = '/home/thomas/Documents/subfolder1'
    path3 = '/home/thomas/Documents/subfolder1/subfolder2'
    path4 = '/home/thomas/Documents/subfolder1/subfolder2/subfolder3'
    path5 = '/home/thomas/Documents/subfolder1/subfolder2/subfolder3/subfolder4'
    path6 = '/home/thomas/Documents/subfolder1/subfolder2/subfolder3/subfolder4/subfolder5'
    path7 = '/home/thomas/Documents/subfolder1/subfolder2/subfolder3/subfolder4/subfolder5/subfolder6'

# Generated at 2022-06-24 03:09:41.945125
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["a", "b"])) == ["/a", "/b"]



# Generated at 2022-06-24 03:09:45.115224
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ['c', 'd', 'e'])) == [
        '/a/b/c',
        '/a/b/d',
        '/a/b/e',
    ]



# Generated at 2022-06-24 03:09:53.980553
# Unit test for function join_each
def test_join_each():
    # Create a temporary directory and move into it
    with TemporaryDirectory() as td:
        os.mkdir('a')
        os.mkdir('b')

        # Check that join_each works when the path doesn't exist
        assert list(join_each(td, ['a', 'b'])) == [os.path.join(td, 'a'), os.path.join(td, 'b')]

        # Check that join_each works when the path does exist
        os.mkdir('c')
        assert list(join_each(td, ['a', 'b', 'c'])) == [os.path.join(td, 'a'), os.path.join(td, 'b'), os.path.join(td, 'c')]

        # Check that it works with relative paths
        os.chdir('a')

# Generated at 2022-06-24 03:09:58.042693
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/boot', ['menu.lst', 'grub.conf'])) == \
           ('/boot/menu.lst', '/boot/grub.conf')
    assert tuple(join_each('/boot/grub', ['grub.conf'])) == \
           ('/boot/grub/grub.conf',)

# Generated at 2022-06-24 03:10:03.467428
# Unit test for function join_each
def test_join_each():
    paths = ['d0', 'd1', 'd2', 'd3']
    actual = list(join_each(os.curdir, paths))
    expect = [os.path.join(os.curdir, p) for p in paths]
    assert actual == expect

# Generated at 2022-06-24 03:10:05.435292
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']
    assert list(join_each('foo/', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:10:08.092723
# Unit test for function join_each
def test_join_each():
    assert list(join_each( "dir", ["a", "b", "c"] )) == [
        os.path.join("dir", "a"),
        os.path.join("dir", "b"),
        os.path.join("dir", "c")]

# Generated at 2022-06-24 03:10:09.607345
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar'])) == ['/foo', '/bar']

# Generated at 2022-06-24 03:10:13.215777
# Unit test for function join_each
def test_join_each():
    test_paths = [os.path.join(os.getcwd(), "make_dir_tests.py"),
                  os.path.join(os.getcwd(), "make_dir_tests.pyc"),
                  os.path.join(os.getcwd(), "make_dir_tests.pyo"),
                  ]
    assert list(join_each(os.getcwd(), ["make_dir_tests.py", "make_dir_tests.pyc", "make_dir_tests.pyo"])) == test_paths



# Generated at 2022-06-24 03:10:14.581132
# Unit test for function join_each
def test_join_each():
    it = join_each('/home', ['/user', '/lib64'])
    assert list(it) == ['/home/user', '/home/lib64']

# Generated at 2022-06-24 03:10:18.980325
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    assert list(join_each('/', iterable)) == \
           ['/a', '/b', '/c']
    assert list(join_each('/foo', iterable)) == \
           ['/foo/a', '/foo/b', '/foo/c']



# Generated at 2022-06-24 03:10:23.988828
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]



# Generated at 2022-06-24 03:10:24.961966
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-24 03:10:28.456019
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:10:32.123033
# Unit test for function join_each
def test_join_each():
    parent = 'apple'
    iterable = ['banana', 'cherry', 'durian']
    expected = ['apple/banana', 'apple/cherry', 'apple/durian']

    generated = list(join_each(parent, iterable))



# Generated at 2022-06-24 03:10:38.579508
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]
    assert list(join_each("", ["b", "c"])) == ["b", "c"]
    assert list(join_each("", [])) == []
    assert list(join_each("a", [])) == []
    assert list(join_each("a/b/c", ["d", "e"])) == ["a/b/c/d", "a/b/c/e"]
    assert list(join_each("a/b\\c", ["d", "e"])) == ["a/b/c/d", "a/b/c/e"]



# Generated at 2022-06-24 03:10:40.816134
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["a", "b"])) == ["/a", "/b"]
    assert list(join_each("/a", ["b", "c"])) == ["/a/b", "/a/c"]



# Generated at 2022-06-24 03:10:44.507283
# Unit test for function join_each
def test_join_each():
    assert list(join_each('root', [])) == []
    assert list(join_each('root', ['a'])) == ['root/a']
    assert list(join_each('root', ['a', 'b'])) == ['root/a', 'root/b']
    assert list(join_each('root/', ['0'])) == ['root/0']



# Generated at 2022-06-24 03:10:47.869092
# Unit test for function join_each
def test_join_each():
    """test_join_each()
    """
    assert list(join_each('/a/b', ('c', 'd', 'e'))) == ['/a/b/c', '/a/b/d', '/a/b/e']



# Generated at 2022-06-24 03:10:50.798300
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a/b', ['c', 'd'])) == ['a/b/c', 'a/b/d']


# Create a list of paths to all the files in `dirname` and its subdirectories

# Generated at 2022-06-24 03:10:52.794877
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['bar', 'baz'])) == ['/foo/bar', '/foo/baz']

# Generated at 2022-06-24 03:10:54.463003
# Unit test for function join_each
def test_join_each():
    assert(list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"])



# Generated at 2022-06-24 03:10:57.025065
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/home', ['user', 'guest', 'local/bin'])) == (
        '/home/user', '/home/guest', '/home/local/bin'
    )

# Generated at 2022-06-24 03:11:00.512277
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    assert list(join_each(parent, [])) == []
    assert list(join_each(parent, ['child1'])) == ['parent/child1']
    assert list(join_each(parent, ['child1', 'child2'])) == [
        'parent/child1',
        'parent/child2',
    ]



# Generated at 2022-06-24 03:11:01.675342
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-24 03:11:03.699708
# Unit test for function join_each
def test_join_each():
    parent = "foo"
    iterable = ["bar", "baz"]
    res = join_each(parent, iterable)
    assert res.next() == "foo/bar"
    assert res.next() == "foo/baz"



# Generated at 2022-06-24 03:11:04.988811
# Unit test for function join_each
def test_join_each():
    assert list(join_each('p', ('a', 'b'))) == ['p/a', 'p/b']

# Generated at 2022-06-24 03:11:07.021321
# Unit test for function join_each
def test_join_each():
    # Two tests
    assert list(join_each('parent', ['a', 'b'])) == ['parent/a', 'parent/b']
    assert list(join_each('parent', [])) == []

# Generated at 2022-06-24 03:11:11.578571
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo/bar', ['baz', 'quux', 'spam'])) == [
        '/foo/bar/baz', '/foo/bar/quux', '/foo/bar/spam'
    ]

# Generated at 2022-06-24 03:11:20.643704
# Unit test for function join_each
def test_join_each():
    # Test for multiple inputs
    inputs = ['a', 'b', 'c']
    parent = '/root'
    outputs = join_each(parent, inputs)
    outputs = list(outputs)
    assert outputs == [os.path.join(parent, inp) for inp in inputs]

    # Test for an empty input
    inputs = []
    outputs = join_each(parent, inputs)
    outputs = list(outputs)
    assert outputs == []

    # Test for an input with an empty string
    inputs = ['']
    outputs = join_each(parent, inputs)
    outputs = list(outputs)
    assert outputs == [parent]


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-24 03:11:25.830942
# Unit test for function join_each
def test_join_each():
    assert list(join_each('base', ('dir1', 'dir2', 'dir3'))) == ['base/dir1', 'base/dir2', 'base/dir3']



# Generated at 2022-06-24 03:11:30.021022
# Unit test for function join_each
def test_join_each():
    assert set(join_each("/a", ["b", "c"])) == {"/a/b", "/a/c"}

# Generated at 2022-06-24 03:11:33.965771
# Unit test for function join_each
def test_join_each():
    path = "/tmp/foo"
    paths = (path, "bar", "baz")
    expected = ("/tmp/foo/bar", "/tmp/foo/baz")

    output = join_each(*paths)

    assert tuple(output) == expected



# Generated at 2022-06-24 03:11:39.045871
# Unit test for function join_each
def test_join_each():
    paths = ['/path/a', '/path/b']
    parent = '/parent'
    result = [p for p in join_each(parent, paths)]
    assert result == ['/parent/path/a', '/parent/path/b']



# Generated at 2022-06-24 03:11:43.795225
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    iterable = ['usr', 'opt']
    joined_list = list(join_each(parent, iterable))

    assert joined_list == ['/home/usr', '/home/opt']



# Generated at 2022-06-24 03:11:48.631556
# Unit test for function join_each
def test_join_each():
    it = join_each('/root', ['x', 'y', 'z'])
    assert next(it) == '/root/x'
    assert next(it) == '/root/y'
    assert next(it) == '/root/z'



# Generated at 2022-06-24 03:11:51.501445
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    test_list = ['f1', 'f2', 'f3']
    actual_list = ['/tmp/f1', '/tmp/f2', '/tmp/f3']

    it = join_each(parent, test_list)

    for actual_join in actual_list:
        assert next(it) == actual_join



# Generated at 2022-06-24 03:12:01.054788
# Unit test for function join_each

# Generated at 2022-06-24 03:12:06.135269
# Unit test for function join_each
def test_join_each():
    assert list(join_each("file", ["A", "B"])) == [
        "file/A",
        "file/B",
    ]
    assert list(join_each("file", ["A/A", "A/B"])) == [
        "file/A/A",
        "file/A/B",
    ]

# Generated at 2022-06-24 03:12:10.838353
# Unit test for function join_each
def test_join_each():
    parent = "abc"

    def gen_test(iterable, expected_results):
        assert list(join_each(parent, iterable)) == expected_results

    gen_test([], [])
    gen_test(["d", "e", "f"], ["abc/d", "abc/e", "abc/f"])



# Generated at 2022-06-24 03:12:12.393740
# Unit test for function join_each
def test_join_each():
    parent = 'root'
    iterable = ['a', 'b', 'c']
    assert li

# Generated at 2022-06-24 03:12:14.275762
# Unit test for function join_each
def test_join_each():
    assert list(join_each('abc', 'def')) == ['abc/d', 'abc/e', 'abc/f']



# Generated at 2022-06-24 03:12:20.684698
# Unit test for function join_each
def test_join_each():
    test_cases = [
        ('/tmp', ('a', 'b', 'c')),
        ('/tmp/', ('a', 'b', 'c')),
        ('/tmp', ['a', 'b', 'c']),
        ('/tmp/', ['a', 'b', 'c']),
        ('/tmp', 'abc'),
        ('/tmp/', 'abc'),
    ]

# Generated at 2022-06-24 03:12:29.794634
# Unit test for function join_each
def test_join_each():
    p = os.path
    assert tuple(join_each('/a/b/c/', ('d', 'e', 'f'))) == (p.join('/a/b/c/', 'd'),
                                                             p.join('/a/b/c/', 'e'),
                                                             p.join('/a/b/c/', 'f'))

    assert tuple(join_each('/a/b/c', ('d', 'e', 'f'))) == (p.join('/a/b/c', 'd'),
                                                            p.join('/a/b/c', 'e'),
                                                            p.join('/a/b/c', 'f'))

# Generated at 2022-06-24 03:12:32.959541
# Unit test for function join_each
def test_join_each():
    ret = list(join_each('/', ['etc', 'var', 'usr']))
    assert ['/etc', '/var', '/usr'] == ret



# Generated at 2022-06-24 03:12:38.496343
# Unit test for function join_each
def test_join_each():
    first_test = [os.path.join('foo', 'bar'), os.path.join('baz', 'qux')]
    second_test = ['foo/bar', 'baz/qux']
    assert list(join_each('foo', ['bar', 'baz/qux'])) == first_test
    assert list(join_each('foo', first_test)) == second_test



# Generated at 2022-06-24 03:12:42.598106
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", "bc")) == ["a/b", "a/c"]
    assert list(join_each("/a", "bc")) == ["/a/b", "/a/c"]
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]



# Generated at 2022-06-24 03:12:45.076072
# Unit test for function join_each
def test_join_each():
    assert list(join_each('', 'abc')) == ['a', 'b', 'c']
    assert list(join_each('abc', 'def')) == ['abc/d', 'abc/e', 'abc/f']



# Generated at 2022-06-24 03:12:46.583559
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/', ['Anh', 'Binh'])) == ['/home/Anh', '/home/Binh']

# Generated at 2022-06-24 03:12:48.351174
# Unit test for function join_each
def test_join_each():
    parent = '/Users/bob'
    iterable = ['app', 'apples', 'applications']
    actual = tuple(join_each(parent, iterable))
    expected = (
        '/Users/bob/app',
        '/Users/bob/apples',
        '/Users/bob/applications'
    )
    assert actual == expected


# Demo using a generator to map names to paths

# Generated at 2022-06-24 03:12:52.727099
# Unit test for function join_each
def test_join_each():
    assert list(join_each('x', ['a', 'b', 'c'])) == ['x/a', 'x/b', 'x/c']



# Generated at 2022-06-24 03:12:59.760532
# Unit test for function join_each
def test_join_each():
    parent = '~'
    paths = ['a', 'b/c', '../d', '', None]
    joined = list(join_each(parent, paths))
    for p in paths:
        if p != '.':
            assert p in joined
    print("test_join_each() passed")


# Main function

# Generated at 2022-06-24 03:13:07.445048
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['bob'])) == ['/bob']
    assert list(join_each('/', ['/bob'])) == ['//bob']
    assert list(join_each('/', ['bob', 'jane'])) == ['/bob', '/jane']
    assert list(join_each('/', ['bob', '', 'jane'])) == ['/bob', '//jane']

# Generated at 2022-06-24 03:13:10.287264
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['abc', 'def', 'ghi'])) == [
        '/tmp/abc', '/tmp/def', '/tmp/ghi'
    ]



# Generated at 2022-06-24 03:13:12.521816
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/var', ['log', 'mail']))
    assert result == list(map(pathlib.Path, ['/var/log', '/var/mail']))

# Generated at 2022-06-24 03:13:16.875245
# Unit test for function join_each
def test_join_each():
    # Input
    parent = '/home/kdchiu'
    iterable = ['Documents', 'Downloads', 'Pictures']

    # Expected output
    output = ['/home/kdchiu/Documents',
              '/home/kdchiu/Downloads',
              '/home/kdchiu/Pictures']

    assert list(join_each(parent, iterable)) == output



# Generated at 2022-06-24 03:13:20.291430
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['a', 'b'])) == ['.', os.path.join('.', 'a'), os.path.join('.', 'b')]

# Generated at 2022-06-24 03:13:25.899789
# Unit test for function join_each
def test_join_each():
    paths = ['one', 'two', 'three']
    result = list(join_each('/base', paths))
    assert result == ['/base/one', '/base/two', '/base/three']

    paths = ['../one/two/three']
    result = list(join_each('/base', paths))
    assert result == ['/one/two/three']



# Generated at 2022-06-24 03:13:35.432342
# Unit test for function join_each
def test_join_each():
    parent_path = '/tmp/'
    paths = ('foo', 'bar', 'bux')

    expected_paths = ('/tmp/foo', '/tmp/bar', '/tmp/bux')

    for p1, p2 in zip(expected_paths, join_each(parent_path, paths)):
        assert p1 == p2


'''
Example of the above function:

list(join_each('/tmp/', ('foo', 'bar', 'bux')))
['/tmp/foo', '/tmp/bar', '/tmp/bux']
'''



# Generated at 2022-06-24 03:13:38.854172
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/path/to', ['a', 'b', 'c'])) == [
        '/path/to/a',
        '/path/to/b',
        '/path/to/c'
    ]



# Generated at 2022-06-24 03:13:42.571927
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a/b/c", [1, 2, 3])) == \
        [os.path.join("/a/b/c", 1), os.path.join("/a/b/c", 2), os.path.join("/a/b/c", 3)]



# Generated at 2022-06-24 03:13:45.872195
# Unit test for function join_each
def test_join_each():
    """
    Happily, Python provides us the os.path.join method to create the path
    to any file or directory
    """