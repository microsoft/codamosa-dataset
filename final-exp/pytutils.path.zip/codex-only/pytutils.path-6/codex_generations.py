

# Generated at 2022-06-24 03:03:50.200318
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["foo", "bar"])) == ["/tmp/foo", "/tmp/bar"]


# The main part of the script

# Generated at 2022-06-24 03:03:53.362295
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp/foo", "abcde")) == [
        "/tmp/foo/a", "/tmp/foo/b", "/tmp/foo/c", "/tmp/foo/d", "/tmp/foo/e"
    ]



# Generated at 2022-06-24 03:03:56.468823
# Unit test for function join_each
def test_join_each():
    result = list(join_each("x", "ab"))
    assert result == ["x/a", "x/b"]


# =============================================================================

# Generated at 2022-06-24 03:04:00.242862
# Unit test for function join_each
def test_join_each():
    parent = 'foo/bar'
    iterable = ['x', 'baz']
    assert list(join_each(parent, iterable)) == ['foo/bar/x', 'foo/bar/baz']

# Generated at 2022-06-24 03:04:02.427698
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['a', 'b', 'c'])) == ['./a', './b', './c']



# Generated at 2022-06-24 03:04:06.911425
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a/b', ['..', 'c'])) == ['a', 'a/b/c']



# Generated at 2022-06-24 03:04:12.036056
# Unit test for function join_each
def test_join_each():
    parent = "PATH"
    test = list(join_each(parent, ["a", "b", "c"]))
    assert test == [
        "PATH" + os.path.sep + "a",
        "PATH" + os.path.sep + "b",
        "PATH" + os.path.sep + "c",
    ]

# Generated at 2022-06-24 03:04:17.203471
# Unit test for function join_each
def test_join_each():
    parent = '.'
    iterable = ('a', 'b', 'c')

    expected_items = ('a', 'b', 'c')
    items = join_each(parent, iterable)

    for item in items:
        assert item in expected_items

# Generated at 2022-06-24 03:04:21.494762
# Unit test for function join_each
def test_join_each():
    input_ = ['foo.txt', 'bar.txt', 'baz.txt']
    expected = [os.path.join('src', 'foo.txt'),
                os.path.join('src', 'bar.txt'),
                os.path.join('src', 'baz.txt')]
    output = list(join_each('src', input_))
    assert output == expected



# Generated at 2022-06-24 03:04:27.126707
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", [])) == []
    assert list(join_each("a", ["b"])) == ["a/b"]
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]


# Recursively walk the filesystem starting from a path, yielding all files
# found.

# Generated at 2022-06-24 03:04:31.182233
# Unit test for function join_each
def test_join_each():
    test_cases = [
        ('root', ['a', 'b'], ['root/a', 'root/b']),
        ('root', ['a/b', 'c/d'], ['root/a/b', 'root/c/d']),
    ]
    for case in test_cases:
        assert [x for x in join_each(*case[:-1])] == case[-1]



# Generated at 2022-06-24 03:04:35.954837
# Unit test for function join_each
def test_join_each():
    parent = 'C:\\'
    iterable = ['a', 'b']

    assert list(join_each(parent, iterable)) == [
        os.path.join(parent, p) for p in iterable]



# Generated at 2022-06-24 03:04:38.098994
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/a/b', ['c', 'd', 'e'])) == ('/a/b/c', '/a/b/d', '/a/b/e')

# Generated at 2022-06-24 03:04:48.702224
# Unit test for function join_each
def test_join_each():
    parent = os.path.abspath(os.path.join(__file__, os.pardir))
    file_name = '__main__.py'
    # Iterable is a string
    try:
        list(join_each(parent, file_name))
    except Exception:
        pass
    else:
        assert False, "join_each test failed"
    # Iterable is a list
    try:
        assert list(join_each(parent, [file_name]))[0] == os.path.join(parent, file_name)
    except Exception:
        assert False, "join_each test failed"
    # No iterable
    try:
        list(join_each(parent, ''))
    except Exception:
        pass
    else:
        assert False, "join_each test failed"




# Generated at 2022-06-24 03:04:52.690574
# Unit test for function join_each
def test_join_each():
    print()
    print('test_join_each')
    assert ['a/b', 'a/c'] == list(join_each('a', ('b', 'c')))




# Generated at 2022-06-24 03:04:57.617839
# Unit test for function join_each
def test_join_each():
    assert list(join_each('./', ['/etc', '../usr/', None])) == [ '/etc', '../usr/', './None']
    assert list(join_each('..', ['/etc', '../usr/', None])) == [ '../etc', '../usr', '../None']

if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:05:00.217228
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', ['passwd', 'group'])) == ['/etc/passwd', '/etc/group']



# Generated at 2022-06-24 03:05:02.807171
# Unit test for function join_each
def test_join_each():
    a = join_each('a', ['b', 'c', 'd'])
    b = ['a/b', 'a/c', 'a/d']
    assert list(a) == b



# Generated at 2022-06-24 03:05:04.501826
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    result = list(join_each('parent', iterable))

# Generated at 2022-06-24 03:05:05.926272
# Unit test for function join_each
def test_join_each():
    path = r"C:\Windows"
    for p in join_each(path, ["temp", "usr"]):
        print(p)

# Generated at 2022-06-24 03:05:09.791076
# Unit test for function join_each
def test_join_each():
    ls = ["dir1", "dir2", "dir3"]
    assert list(join_each("/Users/sakurai/", ls)) == [
        "/Users/sakurai/dir1", "/Users/sakurai/dir2", "/Users/sakurai/dir3"
    ]



# Generated at 2022-06-24 03:05:12.027760
# Unit test for function join_each
def test_join_each():
    expected = ['.test', '.test', '.test']
    result = list(join_each('.', iter(expected)))
    assert result == expected



# Generated at 2022-06-24 03:05:13.684875
# Unit test for function join_each
def test_join_each():
    assert join_each('/a', ['b', 'c']) == ['/a/b', '/a/c']

# Generated at 2022-06-24 03:05:15.935193
# Unit test for function join_each
def test_join_each():
    parent = '/usr'
    iterable = ['bin', 'bin']
    assert list(join_each(parent, iterable)) == ['/usr/bin', '/usr/bin']



# Generated at 2022-06-24 03:05:24.131278
# Unit test for function join_each
def test_join_each():
    import os.path
    import pathlib

    # Test respect of parent type
    parent = "parent"
    children = ["child1", "child2"]
    result = [os.path.join(parent, c) for c in children]
    assert list(join_each(parent, children)) == result

    parent = pathlib.Path("parent")
    children = ["child1", "child2"]
    result = [parent.joinpath(c) for c in children]
    assert list(join_each(parent, children)) == result

# Generated at 2022-06-24 03:05:29.444585
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/var', ['log', 'lib', 'bin'])) == \
           ['/var/log', '/var/lib', '/var/bin']



# Generated at 2022-06-24 03:05:34.146469
# Unit test for function join_each
def test_join_each():
    parent = 'this/is/a'
    iterable = ['test', 'in', 'join_each']
    result = join_each(parent, iterable)
    result = list(result)
    assert result[0] == 'this/is/a/test'
    assert result[1] == 'this/is/a/in'
    assert result[2] == 'this/is/a/join_each'



# Generated at 2022-06-24 03:05:40.700969
# Unit test for function join_each
def test_join_each():
    join_each_result = list(join_each('parent', ['a', 'b', 'c']))
    assert join_each_result == ['parent/a', 'parent/b', 'parent/c']
    join_each_result = list(join_each('parent', ['a']))
    assert join_each_result == ['parent/a']



# Generated at 2022-06-24 03:05:42.917912
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c', 'd'])) == [
        'a/b',
        'a/c',
        'a/d'
    ]


# Generated at 2022-06-24 03:05:47.546458
# Unit test for function join_each
def test_join_each():
    files = ["f1.txt", "f2.txt", "f3.txt"]
    assert [os.path.join(".", f) for f in files] == [p for p in join_each(".", files)]



# Generated at 2022-06-24 03:05:50.838733
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/tmp', ['a', 'b', 'c']))
    expected = ['/tmp/a', '/tmp/b', '/tmp/c']
    assert result == expected



# Generated at 2022-06-24 03:05:57.245290
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a", ["b", "c"])) == ["/a/b", "/a/c"]
    assert list(join_each("/a/", ["b", "c"])) == ["/a/b", "/a/c"]
    assert list(join_each("/a", ["/b", "c"])) == ["/a/b", "/a/c"]
    assert list(join_each("/a", ["b", "/c"])) == ["/a/b", "/a/c"]



# Generated at 2022-06-24 03:06:02.668561
# Unit test for function join_each
def test_join_each():
    joinee = ['a.txt', 'b.txt', 'c.txt']
    joined = join_each('/home/pc', joinee)

    print(joined) # <generator object join_each at 0xb7555c34>

    print(list(joined))
    # ['/home/pc/a.txt', '/home/pc/b.txt', '/home/pc/c.txt']



# Generated at 2022-06-24 03:06:09.278938
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', ('foo', 'bar'))) == [
        '/home/user/foo',
        '/home/user/bar',
    ]


# The problem we're trying to solve is this:
#    Given a list of source file paths (src),
#    and a list of destination file paths (dst)
#    figure out which files need to be copied (created),
#    which files need to be overwritten,
#    and which files can be skipped.
#
# If your solution is correct, the asserts at the bottom
# of this file will pass.



# Generated at 2022-06-24 03:06:12.156021
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ('a', 'b', 'c'))) == [
        'foo/a', 'foo/b', 'foo/c']


# Assert whenever an unhandled exception is raised in a function
# responsible for handling other exceptions and logging them

# Generated at 2022-06-24 03:06:16.706512
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/c', ['x', 'y', 'z'])) == [
        '/a/b/c/x',
        '/a/b/c/y',
        '/a/b/c/z'
    ]



# Generated at 2022-06-24 03:06:17.146477
# Unit test for function join_each
def test_join_each():
    pass

# Generated at 2022-06-24 03:06:18.770504
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/', ['a', 'b']))
    assert result == ['/a', '/b']



# Generated at 2022-06-24 03:06:23.800762
# Unit test for function join_each
def test_join_each():
    assert join_each('/tmp', ['a.txt', 'b.txt']) == ['/tmp/a.txt', '/tmp/b.txt']



# Generated at 2022-06-24 03:06:26.205500
# Unit test for function join_each
def test_join_each():
    parent = 'c:/temp'
    children = ('a', 'b', 'c')

    expected = ('c:/temp/a', 'c:/temp/b', 'c:/temp/c')
    result = join_each(parent, children)
    assert tuple(result) == expected

# Generated at 2022-06-24 03:06:32.356688
# Unit test for function join_each
def test_join_each():
    parent = "some/path"
    tail1 = "a"
    tail2 = "b"
    tail3 = "c"
    result = list(join_each(parent, [tail1, tail2, tail3]))
    expected = [os.path.join(parent, tail1), os.path.join(parent, tail2), os.path.join(parent, tail3)]
    assert result == expected

# Generated at 2022-06-24 03:06:35.648278
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/mnt', ['file1', 'dir1', 'dir2'])) == ['/mnt/file1', '/mnt/dir1', '/mnt/dir2']



# Generated at 2022-06-24 03:06:42.531315
# Unit test for function join_each
def test_join_each():
    # Test case
    parent = os.path.split('parent/dir')[0]
    iterable = ['file1.txt', 'file2.txt', 'file3.txt']
    expected = ['parent/dir/file1.txt', 'parent/dir/file2.txt',
                'parent/dir/file3.txt']
    actual = list(join_each(parent, iterable))
    assert actual == expected
    print('Test passed')

# Comment out before submission
# test_join_each()


# Use appropriate function to find the file extensions

# Generated at 2022-06-24 03:06:49.202318
# Unit test for function join_each
def test_join_each():
    ps = ['/a', '/b', '/c']

    p1 = os.path.join('/e', '/a')
    p2 = os.path.join('/e', '/b')
    p3 = os.path.join('/e', '/c')

    assert [p1, p2, p3] == list(join_each('/e', ps))

    ps = ['a', 'b']
    p1 = os.path.join('e', 'a')
    p2 = os.path.join('e', 'b')

    assert [p1, p2] == list(join_each('e', ps))

# Generated at 2022-06-24 03:06:51.158782
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a", ["b", "c"])) == ["/a/b", "/a/c"]


# Examples of how to use join_each

# Generated at 2022-06-24 03:06:54.074012
# Unit test for function join_each
def test_join_each():
    root = os.path.normpath(os.path.join(os.path.dirname(__file__), ".."))
    for p in join_each(root, ("src", "validator")):
        assert os.path.isdir(p), ("The directory %s should exist." % p)



# Generated at 2022-06-24 03:06:57.271002
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('a', ('b', 'c', 'd'))) == ('a/b', 'a/c', 'a/d')



# Generated at 2022-06-24 03:06:58.567351
# Unit test for function join_each
def test_join_each():
    pass

# Generated at 2022-06-24 03:07:04.089525
# Unit test for function join_each
def test_join_each():
    from functools import reduce
    from operator import eq

    parent = '.'
    iterable = ['spam', 'eggs', 'foo']
    res = [os.path.join(parent, p) for p in iterable]

    assert reduce(eq, join_each(parent, iterable), True)


if __name__ == '__main__':
    print("I am the module {__name__}".format(__name__=__name__))
else:
    print("I am being imported as module {__name__}".format(__name__=__name__))

# Generated at 2022-06-24 03:07:05.698957
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar', 'baz'])) == ['/foo', '/bar', '/baz']



# Generated at 2022-06-24 03:07:07.187811
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each(1, [2, 3])) == (1+2, 1+3)



# Generated at 2022-06-24 03:07:10.701251
# Unit test for function join_each
def test_join_each():
    # Arrange
    iterable = ['a', 'b', 'c']
    parent = "d"
    expected = ["d/a", "d/b", "d/c"]
    # Act
    actual = [x for x in join_each(parent, iterable)]
    # Assert
    assert actual == expected



# Generated at 2022-06-24 03:07:14.379132
# Unit test for function join_each
def test_join_each():
    parent = '/my/path'
    iterable = ['a', 'b', 'c', 'd']
    expected = ['/my/path/a', '/my/path/b', '/my/path/c', '/my/path/d']
    actual = list(join_each(parent, iterable))
    assert actual == expected



# Generated at 2022-06-24 03:07:16.575140
# Unit test for function join_each
def test_join_each():
    join_each_test = ['hello', 'world']
    assert join_each('/', join_each_test) == ['/hello', '/world']
    assert list(join_each('/var/log/', join_each_test)) == ['/var/log/hello', '/var/log/world']



# Generated at 2022-06-24 03:07:20.386850
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['c', 'd'])) == [
        'parent/c',
        'parent/d',
    ]



# Generated at 2022-06-24 03:07:25.804157
# Unit test for function join_each
def test_join_each():
    DATA = [
        ('.', ['foo', 'bar'], ['./foo', './bar']),
        ('.', [], []),
        ('foo', ['bar', 'baz'], ['foo/bar', 'foo/baz']),
        ('foo', ['bar/baz'], ['foo/bar/baz'])
    ]
    for parent, iterable, expected_result in DATA:
        result = list(join_each(parent, iterable))
        assert result == expected_result

# Generated at 2022-06-24 03:07:30.311481
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']
    assert list(join_each('/a/b', ['c', 'd'])) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-24 03:07:36.926392
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a/b", ("x", "y", "z"))) == [
        "/a/b/x",
        "/a/b/y",
        "/a/b/z",
    ]



# Generated at 2022-06-24 03:07:42.593356
# Unit test for function join_each
def test_join_each():
    parent = 'a/b/'
    iterable = ['x', 'y', 'z']
    assert list(join_each(parent, iterable)) == ['a/b/x', 'a/b/y', 'a/b/z']



# Generated at 2022-06-24 03:07:46.477149
# Unit test for function join_each
def test_join_each():
    d = "."
    files = os.listdir(d)
    results = join_each(d, files)
    assert list(results) == [os.path.join(d, f) for f in files]



# Generated at 2022-06-24 03:07:47.947123
# Unit test for function join_each
def test_join_each():
    result = join_each('/root', ['.vimrc', 'foo.txt'])
    assert next(result) == '/root/.vimrc'
    assert next(result) == '/root/foo.txt'



# Generated at 2022-06-24 03:07:56.345393
# Unit test for function join_each
def test_join_each():
    test_data = {
        'a': ['a/b', 'a/c'],
        'abc': ['abc/d', 'abc/efg'],
        'path/to/': ['path/to/1', 'path/to/2'],
        '/path/to/3': ['/path/to/3', '/path/to/3'],
    }

    def _join_each(parent, items):
        return [os.path.join(parent, item) for item in items]

    for parent, items in test_data.items():
        assert list(join_each(parent, items)) == _join_each(parent, items)

# Generated at 2022-06-24 03:08:05.810217
# Unit test for function join_each
def test_join_each():
    parents = ['a', 'b']
    iterables = [
        ['c', 'd'],
        [],
        ['e', 'f', 'g']
    ]
    # Test each element in parents
    for p in parents:
        for iterable in iterables:
            j = join_each(p, iterable)
            assert type(j) == types.GeneratorType, "Wrong Return Type"
            # Test each element in iterable
            for i, r in enumerate(join_each(p, iterable)):
                assert r == os.path.join(p, iterable[i]), "Wrong Return Value"
            # Test empty case
            j = join_each(p, [])
            assert type(j) == types.GeneratorType, "Wrong Return Type for Empty Case"

# Generated at 2022-06-24 03:08:09.033151
# Unit test for function join_each
def test_join_each():
    parent = os.path.join('tmp', 'foo')
    iterable = ['bar', 'baz']
    expected = [os.path.join(parent, 'bar'), os.path.join(parent, 'baz')]
    actual = join_each(parent, iterable)
    assert actual == expected



# Generated at 2022-06-24 03:08:11.250356
# Unit test for function join_each
def test_join_each():
    parent = "B"
    iterable = ["A", "B", "C"]
    expected = ["BA", "BB", "BC"]
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:08:16.306276
# Unit test for function join_each
def test_join_each():
    p = '/tmp'
    iterable = ['a', 'b']
    assert tuple(join_each(p, iterable)) == ('/tmp/a', '/tmp/b')



# Generated at 2022-06-24 03:08:21.930674
# Unit test for function join_each
def test_join_each():
    values = ['a', 'b', 'c']
    results = list(join_each('top', values))
    expected = ['top' + os.sep + 'a', 'top' + os.sep + 'b', 'top' + os.sep + 'c']
    assert results == expected



# Generated at 2022-06-24 03:08:25.880580
# Unit test for function join_each
def test_join_each():
    parent = '/a/b/c'
    iterable = ['d', 'e', 'f']
    x = join_each(parent, iterable)

    assert(list(x) == ['/a/b/c/d', '/a/b/c/e', '/a/b/c/f'])


# make a list of files in directory that end in given extension
# no subdirectories are searched

# Generated at 2022-06-24 03:08:27.945893
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']



# Generated at 2022-06-24 03:08:30.005733
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:08:32.736620
# Unit test for function join_each
def test_join_each():
    # When
    result = join_each('foo', ['bar', 'baz'])
    # Then
    assert ['foo/bar', 'foo/baz'] == list(result)



# Generated at 2022-06-24 03:08:38.565182
# Unit test for function join_each
def test_join_each():
    parent = '/home/foo'
    pathnames = ['/home/foo/a.txt', '/home/foo/b.txt']

    result_list = list(join_each(parent, pathnames))

    assert list(result_list) == pathnames


if __name__ == '__main__':
    
    if os.path.exists('/home/foo'):
        pathnames = (
            f for f in os.listdir('/home/foo')
            if f.endswith('.txt'))
        filenames = list(join_each('/home/foo', pathnames))
        print(filenames)
    else:
        print("'home/foo' does not exist...")

# Generated at 2022-06-24 03:08:42.397533
# Unit test for function join_each
def test_join_each():
    parent = '/path/to'
    iterable = ['a', 'b/c']
    actual = list(join_each(parent, iterable))
    assert actual == ['/path/to/a', '/path/to/b/c']

# Generated at 2022-06-24 03:08:44.028018
# Unit test for function join_each
def test_join_each():
    iterable = ('file1', 'file2')
    actual = list(join_each('path', iterable))
    expected = ['path/file1', 'path/file2']
    assert actual == expected



# Generated at 2022-06-24 03:08:47.036271
# Unit test for function join_each
def test_join_each():
    parent = 'a'
    it = ['b', 'c', 'd']
    expected = ['a/b', 'a/c', 'a/d']
    actual = list(join_each(parent, it))
    assert expected == actual



# Generated at 2022-06-24 03:08:51.515082
# Unit test for function join_each
def test_join_each():
    test_out = list(join_each("parent", ["foo", "bar", "baz"]))
    assert test_out[0] == "parent/foo"
    assert test_out[1] == "parent/bar"
    assert test_out[2] == "parent/baz"



# Generated at 2022-06-24 03:08:56.969357
# Unit test for function join_each
def test_join_each():
    # GIVEN
    test_iterable = ["test", "example", "path"]
    test_parent = "C:\\Users\\MyName\\Documents\\"
    expected_output = ["C:\\Users\\MyName\\Documents\\test", "C:\\Users\\MyName\\Documents\\example",
                       "C:\\Users\\MyName\\Documents\\path"]

    # WHEN
    result = list(join_each(test_parent, test_iterable))

    # THEN
    assert result == expected_output

# Generated at 2022-06-24 03:08:57.996791
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c', 'd'])) == ['a/b', 'a/c', 'a/d']



# Generated at 2022-06-24 03:08:59.328679
# Unit test for function join_each
def test_join_each():
    paths = join_each('/root', ['/bin', '/usr', '/lib', '/var'])
    assert list(paths) == ['/root/bin', '/root/usr', '/root/lib', '/root/var']



# Generated at 2022-06-24 03:09:05.300072
# Unit test for function join_each
def test_join_each():
    actual = join_each("a", ["b", "c", "d"])
    expected = ["a/b", "a/c", "a/d"]
    assert list(actual) == expected


# Exercice 1

# Generated at 2022-06-24 03:09:13.666485
# Unit test for function join_each
def test_join_each():
    assert list(join_each('root', ['child1', 'child2', 'child3'])) == [
        'root/child1', 'root/child2', 'root/child3'
    ]
    assert list(join_each('root/', ['child1', 'child2', 'child3'])) == [
        'root/child1', 'root/child2', 'root/child3'
    ]
    assert list(join_each('root/', ['child1', '', 'child3'])) == [
        'root/child1', 'root/', 'root/child3'
    ]



# Generated at 2022-06-24 03:09:15.716219
# Unit test for function join_each
def test_join_each():
    # test a join
    assert list(join_each("foo", ("bar", "baz"))) == ["foo/bar", "foo/baz"]

# Generated at 2022-06-24 03:09:21.121849
# Unit test for function join_each
def test_join_each():
    """
    Test if the function returns correctly the result of the join
    """
    result = list(join_each('/tmp', ['file1', 'file2']))
    expected = ['/tmp/file1', '/tmp/file2']
    assert result == expected


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-24 03:09:23.850170
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', ['file', 'folder'])) == ['/home/user/file', '/home/user/folder']



# Generated at 2022-06-24 03:09:27.179150
# Unit test for function join_each
def test_join_each():
    actual = join_each('/home/test', ['file1.txt', 'file2.txt'])
    assert actual.next() == '/home/test/file1.txt'
    assert actual.next() == '/home/test/file2.txt'



# Generated at 2022-06-24 03:09:31.428757
# Unit test for function join_each
def test_join_each():
    parent = "/usr"
    iterable = ["bin", "share/man"]
    expected_result = ["/usr/bin", "/usr/share/man"]
    join_each_result = list(join_each(parent, iterable))
    assert(join_each_result == expected_result)



# Generated at 2022-06-24 03:09:33.896802
# Unit test for function join_each
def test_join_each():
    p = "home"
    paths = ["foo", "bar", "baz"]
    assert list(join_each(p, paths)) == [os.path.join(p, ch) for ch in paths]



# Generated at 2022-06-24 03:09:36.692666
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/some/path', ['a', 'b', 'c'])) == [
        '/some/path/a',
        '/some/path/b',
        '/some/path/c'
    ]



# Generated at 2022-06-24 03:09:38.000391
# Unit test for function join_each
def test_join_each():
    assert list(join_each(u'/tmp', ['.', '..'])) == ['/tmp', '/tmp/..']

# Generated at 2022-06-24 03:09:41.344233
# Unit test for function join_each
def test_join_each():
    assert set(join_each("test", ["a", "b"])) == {"test/a", "test/b"}
    assert set(join_each("", ["a", "b"])) == {"a", "b"}
    assert set(join_each("test", ["a", "b", ""])) == {"test/a", "test/b", "test"}
    assert set(join_each("test", [])) == set()

# Generated at 2022-06-24 03:09:43.707059
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["user", "local"])) == [
        "/home/user",
        "/home/local",
    ]



# Generated at 2022-06-24 03:09:47.025190
# Unit test for function join_each
def test_join_each():
    parent = '/foo/bar'
    s = ['a', 'b', 'c']
    expected = ['/foo/bar/a', '/foo/bar/b', '/foo/bar/c']
    assert list(join_each(parent, s)) == expected



# Generated at 2022-06-24 03:09:49.668435
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/root', 'usr lib bin'.split())) == ['/root/usr', '/root/lib', '/root/bin']
    assert list(join_each('/root', [])) == []


# main function

# Generated at 2022-06-24 03:10:00.365362
# Unit test for function join_each
def test_join_each():
    test_dir = os.path.dirname(__file__)
    tree = list(join_each(test_dir, ['..', 'python', 'data', 'test_tree']))
    assert tree == ['../python/data/test_tree']

    files = list(
            join_each(test_dir,
                ['..', 'python', 'data', 'test_tree', 'txt']))
    assert files == ['../python/data/test_tree/txt']

    files = list(
            join_each(test_dir,
                ['..', 'python', 'data', 'test_tree', 'txt', '*']))

# Generated at 2022-06-24 03:10:03.380157
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['a', 'b'])) == ['a', 'b']

# Generated at 2022-06-24 03:10:09.203539
# Unit test for function join_each
def test_join_each():
    import pytest
    with pytest.raises(TypeError):
        list(join_each(set([1, 2, 3]), [1, 3, 3]))
    test = [
        (["asdf"], ["asdf"], ["asdf"]),
        (["as", "df"], ["as", "df"], ["asdf"]),
        ([], ["asdf"], [])
    ]
    for parent, iterable, answer in test:
        print(join_each(parent, iterable))
        assert list(join_each(parent, iterable)) == answer

# Generated at 2022-06-24 03:10:12.732032
# Unit test for function join_each
def test_join_each():
    a = ["one", "two", "three"]
    b = ["uno/one", "dos/two", "tres/three"]
    assert list(join_each("some/path", a)) == b



# Generated at 2022-06-24 03:10:15.292539
# Unit test for function join_each
def test_join_each():
    a = [1, 2, 3]
    expected = ['a/1', 'a/2', 'a/3']
    result = list(join_each('a', a))
    assert expected == result

# Generated at 2022-06-24 03:10:18.910553
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:10:21.866665
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    parent = '/a/b/c'
    expected = ['/a/b/c/a', '/a/b/c/b', '/a/b/c/c']
    result = [join for join in join_each(parent, iterable)]
    assert result == expected

# Generated at 2022-06-24 03:10:24.308687
# Unit test for function join_each
def test_join_each():
    iter1 = ['a', 'b', 'c']
    iter2 = ['x', 'y', 'z']
    assert list(join_each(iter1, iter2)) == ['ax', 'ay', 'az', 'bx', 'by', 'bz', 'cx', 'cy', 'cz']



# Generated at 2022-06-24 03:10:28.228328
# Unit test for function join_each
def test_join_each():
    iterable = ("a", "b", "c")
    parent = "/"

    joind = list(join_each(parent, iterable))

    assert joind == ["/a", "/b", "/c"]

# Generated at 2022-06-24 03:10:30.491974
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:10:35.262948
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/root', ['bin', 'data', 'etc'])) == [
        '/root/bin',
        '/root/data',
        '/root/etc'
    ]

# Generated at 2022-06-24 03:10:42.014796
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']


slices = 'sl1 sl2 sl3 sl4 sl5'.split()

# Just some example slices, modify them to fit your setup

# Generated at 2022-06-24 03:10:55.779850
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b', 'c'])) == list(map(lambda x: 'parent/' + x, ['a', 'b', 'c']))



# Generated at 2022-06-24 03:10:59.368236
# Unit test for function join_each
def test_join_each():
    parent = 'p'
    iterable = ['a', 'b', 'c']
    expected = ['pa', 'pb', 'pc']
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:11:05.616916
# Unit test for function join_each
def test_join_each():
    a = join_each("/test/test2", ["test3", "test4", "test5"])
    assert list(a) == ["/test/test2/test3", "/test/test2/test4", "/test/test2/test5"]



# Generated at 2022-06-24 03:11:12.928950
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp/a/b', ['c', 'd/e'])) == [
        '/tmp/a/b/c', '/tmp/a/b/d/e']
    assert list(join_each('c:\\tmp\\a\\b', ['c', 'd\\e'])) == [
        'c:\\tmp\\a\\b\\c', 'c:\\tmp\\a\\b\\d\\e']



# Generated at 2022-06-24 03:11:19.728397
# Unit test for function join_each
def test_join_each():
    parent = 'some_parent'
    iterable = ['file_a', 'file_b', 'file_c']
    expected = [
        'some_parent/file_a',
        'some_parent/file_b',
        'some_parent/file_c'
    ]

    actual = list(join_each(parent, iterable))

    assert expected == actual



# Generated at 2022-06-24 03:11:25.469133
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["a", "b", "c"]
    result = join_each(parent, iterable)
    assert result
    assert "parent/a" in result
    assert "parent/b" in result
    assert "parent/c" in result

# Generated at 2022-06-24 03:11:35.995980
# Unit test for function join_each
def test_join_each():
    test_set = [
        {
        'parent': 'a',
        'iter': ['b', 'c'],
        'actual_results': ['a/b', 'a/c'],
        },
        {
        'parent': 'a/b/c',
        'iter': ['d', 'e'],
        'actual_results': ['a/b/c/d', 'a/b/c/e'],
        },
    ]
    for test in test_set:
        expected_results = test['actual_results']
        got_results = [i for i in join_each(test['parent'], test['iter'])]
        assert got_results == expected_results

# Generated at 2022-06-24 03:11:39.315334
# Unit test for function join_each
def test_join_each():
    # Create expected list
    expected = []
    expected.append('./a')
    expected.append('./b')
    expected.append('./c')
    expected.append('./d')

    # Test for a list
    assert list(join_each('./', ['a', 'b', 'c', 'd'])) == expected

    # Test for a tuple
    assert list(join_each('.', ('a', 'b', 'c', 'd'))) == expected

    # Test for a set
    assert list(join_each('.', {'a', 'b', 'c', 'd'})) == expected

# Generated at 2022-06-24 03:11:42.709573
# Unit test for function join_each
def test_join_each():
    parent = "a"
    iterable = [[1, 2], [3, 4], [5, 6]]
    expected = ["a/1", "a/2", "a/3", "a/4", "a/5", "a/6"]
    actual = list(join_each(parent, iterable))
    assert actual == expected



# Generated at 2022-06-24 03:11:48.098076
# Unit test for function join_each
def test_join_each():
    s = ['a', 'b', 'c']
    assert list(join_each('d', s)) == list(map(lambda x: os.path.join('d', x),
                                               s))



# Generated at 2022-06-24 03:11:53.342652
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["user", "documents", "test.txt"])) == [
        "/home/user",
        "/home/documents",
        "/home/test.txt",
    ]



# Generated at 2022-06-24 03:11:57.323280
# Unit test for function join_each
def test_join_each():
    parent = '/etc'
    iterable = ['passwd', 'group', 'sudoers']

    joined = list(join_each(parent, iterable))
    expected = [os.path.join('/etc', p) for p in iterable]

    assert joined == expected

# Generated at 2022-06-24 03:12:01.115833
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["bin", "usr"])) == ["/bin", "/usr"]
    assert list(join_each("/", ["/bin", "/usr"])) == [
        os.path.join(os.sep, "bin"),
        os.path.join(os.sep, "usr"),
    ]



# Generated at 2022-06-24 03:12:04.956817
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/var', ('lib', 'log'))) == (
        '/var/lib',
        '/var/log',
    )


# Unit test using pytest

# Generated at 2022-06-24 03:12:14.492708
# Unit test for function join_each
def test_join_each():
    assert('/i/am/parent' == '/i/am/parent/')
    assert('/i/am/parent' == '/i/am/parent')
    assert('/i/am/parent' == os.path.join('/i', 'am/parent'))
    assert('/i/am/parent' == os.path.join('/i', 'am/', 'parent'))
    assert('/i/am/parent' == os.path.join('/i', 'am/', 'parent', ''))
    assert('/i/am/parent' == os.path.join('/i', 'am/', 'parent', '/'))
    assert('/i/am/parent/' == os.path.join('/i', 'am/', 'parent', '/')[:-1])

# Generated at 2022-06-24 03:12:17.865535
# Unit test for function join_each
def test_join_each():
    cwd = os.getcwd()
    expected = ("/one", "/two", "/three")

    result = join_each(cwd, ("one", "two", "three"))
    assert tuple(result) == expected

    result = list(join_each(cwd, ("one", "two", "three")))
    assert result == list(expected)



# Generated at 2022-06-24 03:12:20.064800
# Unit test for function join_each
def test_join_each():
    """
    Unit test for join_each function
    """
    actual = list(join_each('/tmp', ('foo', 'bar', 'baz')))
    expected = ['/tmp/foo', '/tmp/bar', '/tmp/baz']
    assert actual == expected

# Generated at 2022-06-24 03:12:23.791353
# Unit test for function join_each
def test_join_each():
    # List of test cases. Each test case is a tuple of 2 strings:
    # - input: string to be tested
    # - expected: expected result of the function
    test_cases = [
        ('data', ['file1', 'file2'], ['data\\file1', 'data\\file2']),
        ('data', ['file1'], ['data\\file1']),
        ('data', ['dir1'], ['data\\dir1']),
    ]
    for parent, path, expected in test_cases:
        expected_result = list(join_each(parent, path))
        assert expected_result == expected

# Generated at 2022-06-24 03:12:27.496011
# Unit test for function join_each
def test_join_each():
    assert (os.path.join('a', 'b', 'c') ==
            list(join_each(os.path.join('a', 'b'), ['c']))[0])



# Generated at 2022-06-24 03:12:31.487384
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['a', 'b', 'c'])) == [
        './a', './b', './c'
    ]



# Generated at 2022-06-24 03:12:36.413228
# Unit test for function join_each
def test_join_each():
    parent = '/data'
    paths = ['/data/a', '/data/b', '/data/c']
    assert list(join_each(parent, paths)) == paths

# Generated at 2022-06-24 03:12:45.041325
# Unit test for function join_each
def test_join_each():
    base = "C:/Users/Public"
    paths = ["Documents", "Pictures", "Music", "Videos"]
    joined = join_each(base, paths)
    joined_expected = ["C:/Users/Public/Documents",
                       "C:/Users/Public/Pictures",
                       "C:/Users/Public/Music",
                       "C:/Users/Public/Videos"]
    print("TESTING join_each...")
    for e, a in zip(joined_expected, joined):
        assert (e == a)

# Generated at 2022-06-24 03:12:48.694098
# Unit test for function join_each
def test_join_each():

    parent = "some/parent/directory"
    child_list = [child1, child2, child3]
    expected = ("some/parent/directory/child1",
                "some/parent/directory/child2",
                "some/parent/directory/child3")
    actual = tuple(join_each(parent, child_list))
    assert expected == actual



# Generated at 2022-06-24 03:12:58.991045
# Unit test for function join_each
def test_join_each():
    from nose2.tools import params
    from os.path import join


# Generated at 2022-06-24 03:13:02.989548
# Unit test for function join_each
def test_join_each():
    """
    Ensure that join_each returns correct value for all inputs
    """

    p = "root"
    test_children = ["foo", "bar", "baz/a/b/c"]
    expected_results = [
        "root/foo",
        "root/bar",
        "root/baz/a/b/c",
    ]
    results = list(join_each(p, test_children))
    assert expected_results == results



# Generated at 2022-06-24 03:13:10.686293
# Unit test for function join_each
def test_join_each():
    parent = '.'
    assert list(join_each(parent, [f for f in os.listdir('.') if os.path.isfile(f)])) == ['.\\.coveragerc',
                                                                                         '.\\app.py',
                                                                                         '.\\config.py',
                                                                                         '.\\cover',
                                                                                         '.\\covhtml',
                                                                                         '.\\test_app.py',
                                                                                         '.\\test_config.py']



# Generated at 2022-06-24 03:13:12.600620
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ('child1', 'child2'))) == ['parent/child1', 'parent/child2']

# Generated at 2022-06-24 03:13:13.986512
# Unit test for function join_each
def test_join_each():
    actual = list(join_each('a/path', ['1', '2', '3']))
    assert ['a/path/1', 'a/path/2', 'a/path/3'] == actual

# Generated at 2022-06-24 03:13:17.717352
# Unit test for function join_each
def test_join_each():
    assert list(join_each("dir", ["file1.txt", "file2.txt"])) == ["dir\\file1.txt", "dir\\file2.txt"]
    assert list(join_each("dir", [])) == []
    assert [p for p in join_each("dir", ["sub", "sub2"])] == ["dir\\sub", "dir\\sub2"]



# Generated at 2022-06-24 03:13:22.073265
# Unit test for function join_each
def test_join_each():
    parent = 'a'
    children = ['b', 'c', 'd']
    expected = ['a/b', 'a/c', 'a/d']
    assert list(join_each(parent, children)) == expected



# Generated at 2022-06-24 03:13:26.860498
# Unit test for function join_each
def test_join_each():
    parent = '/home/user'
    iterable = ('test', 'test2')
    result = list(join_each(parent, iterable))
    assert result[0] == '/home/user/test'
    assert result[1] == '/home/user/test2'



# Generated at 2022-06-24 03:13:30.630322
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b"])) == ["/tmp/a", "/tmp/b"]

# Generated at 2022-06-24 03:13:32.742948
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a/b", ["c", "d"])) == [
        "/a/b/c",
        "/a/b/d",
    ]



# Generated at 2022-06-24 03:13:37.308269
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['a', 'b', 'c']
    result = join_each(parent, iterable)
    assert list(result) == ['parent/a', 'parent/b', 'parent/c']



# Generated at 2022-06-24 03:13:42.706265
# Unit test for function join_each
def test_join_each():

    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']
    assert list(join_each('', ['a', 'b'])) == ['a', 'b']

# Generated at 2022-06-24 03:13:44.674735
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-24 03:13:47.701016
# Unit test for function join_each
def test_join_each():
    path = b'foo'
    subs = [b'a', b'b']
    result = join_each(path, subs)
    assert result == [b'foo/a', b'foo/b']


# Find all files in the directory passed and return them all in a list