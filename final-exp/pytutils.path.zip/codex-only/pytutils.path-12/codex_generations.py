

# Generated at 2022-06-24 03:03:52.805093
# Unit test for function join_each
def test_join_each():
    test_path = "C:\\"
    test_list = ["a", "b", "c"]
    output = join_each(test_path, test_list)
    assert next(output) == "C:\\a"


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-24 03:03:59.113019
# Unit test for function join_each
def test_join_each():
    parent = '/home/fernando'
    iterable = ['/Downloads', '/Downloads/Games', '/Downloads/Python']

    expected = [
        '/home/fernando/Downloads',
        '/home/fernando/Downloads/Games',
        '/home/fernando/Downloads/Python'
    ]

    result = join_each(parent, iterable)
    assert list(result) == expected



# Generated at 2022-06-24 03:04:00.969257
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['home', 'foo'])) == ['/home', '/foo']



# Generated at 2022-06-24 03:04:07.621571
# Unit test for function join_each
def test_join_each():
    # Test case: expected
    expected = [
        "a/b",
        "a/c",
    ]
    assert list(join_each("a", ["b", "c"])) == expected

    # Test case: unexpected
    unexpected = [
        "a/b/c",
        "a/b",
    ]
    assert list(join_each("a", ["b", "c"])) != unexpected



# Generated at 2022-06-24 03:04:10.647889
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/user/", ["a.txt", "b.txt"])) == [
        "/home/user/a.txt",
        "/home/user/b.txt",
    ]



# Generated at 2022-06-24 03:04:14.202604
# Unit test for function join_each
def test_join_each():
    parent_dir = '/tmp'
    child_dirs = ['dir_1', 'dir_2', 'dir_3']
    expected = sorted(['/tmp/dir_1', '/tmp/dir_2', '/tmp/dir_3'])
    assert expected == sorted(join_each(parent_dir, child_dirs))


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:04:17.308507
# Unit test for function join_each
def test_join_each():
    parent = "/usr"
    iterable = ["bin", "local"]
    assert list(join_each(parent, iterable)) == ["/usr/bin", "/usr/local"]



# Generated at 2022-06-24 03:04:19.658482
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar'])) == [os.path.join('/', 'foo'), os.path.join('/', 'bar')]



# Generated at 2022-06-24 03:04:25.920077
# Unit test for function join_each
def test_join_each():
    assert join_each('/a', ['b', 'c']) == ['/a/b', '/a/c']



# Generated at 2022-06-24 03:04:31.913980
# Unit test for function join_each
def test_join_each():
    assert list(join_each('test', ['one', 'two'])) == ['test/one', 'test/two']



# Generated at 2022-06-24 03:04:37.702006
# Unit test for function join_each
def test_join_each():
    parent = '/home/hain'
    lst = ['Documents', 'Downloads', 'temp']
    join_list = list(join_each(parent, lst))
    for lst_item, join_list_item in zip(lst, join_list):
        assert os.path.join(parent, lst_item) == join_list_item

# Generated at 2022-06-24 03:04:38.597023
# Unit test for function join_each

# Generated at 2022-06-24 03:04:42.439382
# Unit test for function join_each
def test_join_each():
    assert list(join_each("root", ["child1", "child2"])) == [
        "root/child1", "root/child2",
    ]



# Generated at 2022-06-24 03:04:44.041200
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', 'a/b'.split('/'))) == ['a', 'a/b']



# Generated at 2022-06-24 03:04:47.649312
# Unit test for function join_each
def test_join_each():
    assert join_each("/", ["a", "b", "c"]) == ["/a", "/b", "/c"]

if __name__ == "__main__":
    import sys
    from .main import main
    main(sys.argv)

# Generated at 2022-06-24 03:04:57.618071
# Unit test for function join_each
def test_join_each():
    test_data = [
        (
            "parent_dir",
            ["child_dir_1", "child_dir_2"],
            ["parent_dir/child_dir_1", "parent_dir/child_dir_2"],
        ),
        ("", [], []),
        (
            "/",
            ["child_dir_1", "child_dir_2"],
            ["/child_dir_1", "/child_dir_2"],
        ),
    ]
    for (parent, iterable, expected) in test_data:
        actual = join_each(parent, iterable)
        assert actual == expected



# Generated at 2022-06-24 03:05:01.010342
# Unit test for function join_each
def test_join_each():
    result = list(join_each('foo/bar', ['a', 'b', 'c']))
    assert result == ['foo/bar/a', 'foo/bar/b', 'foo/bar/c']



# Generated at 2022-06-24 03:05:03.121564
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["a", "b", "c"])) == [
        "/home/a", "/home/b", "/home/c"]



# Generated at 2022-06-24 03:05:04.779795
# Unit test for function join_each
def test_join_each():
    l = ['a', 'b', 'c']
    assert list(join_each('root', l)) == ['root/a', 'root/b', 'root/c']



# Generated at 2022-06-24 03:05:07.981044
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/var", ["log",
                                   "lib"])) == ["/var/log", "/var/lib"]
    assert list(join_each("/var", ("log", "lib"))) == ["/var/log", "/var/lib"]
    s = set(("log", "lib"))
    assert list(join_each("/var", s)) == ["/var/log", "/var/lib"]



# Generated at 2022-06-24 03:05:11.070212
# Unit test for function join_each
def test_join_each():
    parent = os.path.abspath(__file__)
    for p in join_each(parent, ('.', '..')):
        assert isinstance(p, str) and os.path.isdir(p)

# Generated at 2022-06-24 03:05:12.926078
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', 'bc')) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:05:15.293840
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ('foo', 'bar'))) == ['/home/foo', '/home/bar']



# Generated at 2022-06-24 03:05:17.130859
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/a', ('b', 'c'))) == ('/a/b', '/a/c')



# Generated at 2022-06-24 03:05:22.718661
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["user", "public"])) == ["/home/user", "/home/public"]



# Generated at 2022-06-24 03:05:24.412122
# Unit test for function join_each
def test_join_each():
    assert list(join_each('aa', ['bb', 'cc'])) == ['aa/bb', 'aa/cc']



# Generated at 2022-06-24 03:05:31.049486
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each(None, ['foo', 'bar', 'baz'])) == ('foo', 'bar', 'baz')
    assert tuple(join_each(os.path.join('foo', 'bar'), ['baz', 'qux'])) == (
        os.path.join('foo', 'bar', 'baz'),
        os.path.join('foo', 'bar', 'qux')
    )
    assert tuple(
        join_each(os.path.join('home', os.path.join('foo', 'bar')), ['baz', 'qux'])) == (
            os.path.join('home', os.path.join('foo', 'bar', 'baz')),
            os.path.join('home', os.path.join('foo', 'bar', 'qux'))
        )




# Generated at 2022-06-24 03:05:32.861180
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', {'bar', 'baz'})) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:05:37.620398
# Unit test for function join_each
def test_join_each():
    iterable = bool, float, str
    parent = 'x'
    result = tuple(join_each(parent, iterable))
    assert result == tuple(os.path.join(parent, p) for p in iterable)



# Generated at 2022-06-24 03:05:38.928538
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:05:43.373507
# Unit test for function join_each
def test_join_each():
    parent = "/tmp"
    iterable = ["file1", "file2"]
    expected_output = ["/tmp/file1", "/tmp/file2"]
    assert list(join_each(parent, iterable)) == expected_output



# Generated at 2022-06-24 03:05:48.763707
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c', 'd'])) == \
        ['a' + os.path.sep + 'b', 'a' + os.path.sep + 'c', 'a' + os.path.sep + 'd']



# Generated at 2022-06-24 03:05:50.838880
# Unit test for function join_each
def test_join_each():
    assert list(join_each(
        '/var/cache',
        ['..', 'tmp'])) == ['/var/tmp']



# Generated at 2022-06-24 03:05:52.362020
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]



# Generated at 2022-06-24 03:05:57.297704
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-24 03:06:00.769222
# Unit test for function join_each
def test_join_each():
    input = ('foo', 'bar', 'baz')
    output = ('foo/bar', 'foo/baz')
    assert tuple(join_each('foo', input[1:])) == output



# Generated at 2022-06-24 03:06:03.154853
# Unit test for function join_each
def test_join_each():
    d = os.path.realpath(os.path.join(__file__, '..', '..', '..', 'tmp'))
    print(list(join_each(d, ['.git', 'models'])))

# Generated at 2022-06-24 03:06:07.435697
# Unit test for function join_each
def test_join_each():
    parent = "."
    expected = [".", "./a", "./b", "./a/c", "./a/d"]
    result = list(join_each(parent, (".", "a", "b", join_each(parent, ("a", "b")), "a/c", "a/d")))
    assert expected == result



# Generated at 2022-06-24 03:06:10.089254
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", [1, 2, 3, 4])) == [
        "/1", "/2", "/3", "/4"
    ], "join_each didn't work as expected. Might be a test problem."



# Generated at 2022-06-24 03:06:12.353546
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo/bar', ['baz', 'quux'])) == ['/foo/bar/baz', '/foo/bar/quux']


# Simple version of the iterator version

# Generated at 2022-06-24 03:06:16.848858
# Unit test for function join_each
def test_join_each():
    expected = [os.path.join(p, i) for p in ['a', 'b'] for i in ['1', '2']]
    result = list(join_each(['a', 'b'], ['1', '2']))
    assert expected == result



# Generated at 2022-06-24 03:06:23.412509
# Unit test for function join_each
def test_join_each():
    iterable = ["a", "b", "c"]
    expected = ["x/a", "x/b", "x/c"]
    actual = list(join_each("x", iterable))
    assert actual == expected


if __name__ == '__main__':
    file_path = [
        "../data/hightemp.txt", "../data/hightemp-col1-2.txt", "../data/hightemp-col1-2-3.txt",
        "../data/hightemp-col1.txt", "../data/hightemp-col2.txt", "../data/hightemp-col3.txt"
    ]

    # Read all files
    file_list = [open(file, "r") for file in file_path]

    # Print all files

# Generated at 2022-06-24 03:06:25.739855
# Unit test for function join_each
def test_join_each():
    parent = "/home"
    guests = ["User1", "User2"]
    users = list(join_each(parent, guests))
    assert len(users) == 2
    for user in users:
        assert user.startswith(parent)

# Generated at 2022-06-24 03:06:32.003519
# Unit test for function join_each
def test_join_each():
    example_dir = os.path.dirname(os.path.abspath(__file__))
    input = ["example", "example2"]
    expected_output = [os.path.join(example_dir, "example"),
                       os.path.join(example_dir, "example2")]
    output = list(join_each(example_dir, input))
    assert output == expected_output

# Generated at 2022-06-24 03:06:34.959531
# Unit test for function join_each
def test_join_each():
    root = '/tmp'
    paths = ['.bashrc', '..']
    for p in paths:
        assert(p in list(join_each(root, paths)))

# Generated at 2022-06-24 03:06:38.064829
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:06:44.782101
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    iterable = ('i', 'work', 'here')
    assert list(join_each(parent, iterable)) == [
        '/home/i',
        '/home/work',
        '/home/here'
    ]



# Generated at 2022-06-24 03:06:48.285531
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/root", ["file1", "file2"])) == ["/root/file1", "/root/file2"]
    assert list(join_each("/root", ["/file1", "/file2"])) == ["/root/file1", "/root/file2"]



# Generated at 2022-06-24 03:06:50.953127
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ('test1', 'test2', 'test3'))) == [
        '/tmp/test1', '/tmp/test2', '/tmp/test3']



# Generated at 2022-06-24 03:06:58.705512
# Unit test for function join_each
def test_join_each():
    l = ["/a", "b/", "/c/d", "e/", "f", "/g/h///i/j", "/k", "/l/m/n"]
    e = ["/a/b", "/a/c/d", "/a/e", "/a/f", "/a/g/h///i/j", "/a/k", "/a/l/m/n"]
    assert list(join_each("/a", l)) == e


# TODO: Unit test for function join_each

# Generated at 2022-06-24 03:07:00.238420
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/', ['usr', 'bin'])) == ('/usr', '/bin')

# Generated at 2022-06-24 03:07:05.203561
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('a', ['b', 'c', 'd'])) == ('a/b', 'a/c', 'a/d')



# Generated at 2022-06-24 03:07:06.623890
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]

# Generated at 2022-06-24 03:07:10.484984
# Unit test for function join_each
def test_join_each():
    parent = "c:/temp"
    iterable = ["file.txt", "hello.txt", "temp.py"]
    actual = list(join_each(parent, iterable))
    expected = [
        "c:/temp/file.txt",
        "c:/temp/hello.txt",
        "c:/temp/temp.py"
    ]
    assert actual == expected

# Generated at 2022-06-24 03:07:12.870515
# Unit test for function join_each
def test_join_each():
    assert (list(join_each('folder', ['abc.txt', 'def', 'ghi.doc']))
            == ['folder/abc.txt', 'folder/def', 'folder/ghi.doc'])



# Generated at 2022-06-24 03:07:15.146384
# Unit test for function join_each
def test_join_each():
    parent = "/tmp"
    iterable = ["file1", "file2", "file3"]
    assert set(join_each(parent, iterable)) == {
        "/tmp/file1",
        "/tmp/file2",
        "/tmp/file3",
    }

# Generated at 2022-06-24 03:07:19.950598
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:07:21.623023
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]



# Generated at 2022-06-24 03:07:27.710801
# Unit test for function join_each
def test_join_each():
    assert list(
        join_each('c:\\', ["a", "b", "c"])
    ) == ['c:\\a', 'c:\\b', 'c:\\c']



# Generated at 2022-06-24 03:07:29.418515
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:07:32.125913
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('a', ('b', 'c'))) == ('a/b', 'a/c')



# Generated at 2022-06-24 03:07:39.414604
# Unit test for function join_each
def test_join_each():
    parent = '/usr/bin'
    iter1 = ['pwd', 'ls']
    iter2 = ['/usr/bin/', '/usr/bin/less']
    assert list(join_each(parent, iter1)) == ['/usr/bin/pwd',
                                              '/usr/bin/ls']
    assert list(join_each(parent, iter2)) == ['/usr/bin//usr/bin/',
                                              '/usr/bin//usr/bin/less']

# Generated at 2022-06-24 03:07:41.552922
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/Users', ['alex', 'bob'])) == \
            ['/Users/alex', '/Users/bob']


# Function that takes a list of 3 integers and returns the sum of the largest two

# Generated at 2022-06-24 03:07:43.623293
# Unit test for function join_each
def test_join_each():
    l = [1, 2, 3]
    assert list(join_each(2, l)) == [2 * i for i in l]



# Generated at 2022-06-24 03:07:46.658622
# Unit test for function join_each
def test_join_each():
    assert join_each('/home/user', ['a', 'b']) == (
        '/home/user/a', '/home/user/b')



# Generated at 2022-06-24 03:07:51.949797
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', [])) == []
    assert list(join_each('a', [''])) == ['a/']
    assert list(join_each('a', ['/'])) == ['a/']
    assert list(join_each('a', ['b'])) == ['a/b']
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a', ['b/', 'c'])) == ['a/b/', 'a/c']
    assert list(join_each('a', ['b/c'])) == ['a/b/c']

# Generated at 2022-06-24 03:07:55.350388
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-24 03:07:59.201101
# Unit test for function join_each
def test_join_each():
    parent = 'a/path'
    iterable = ('b', 'c', 'd')
    expected = ('a/path/b', 'a/path/c', 'a/path/d')
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:08:00.806733
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-24 03:08:05.683172
# Unit test for function join_each
def test_join_each():
    r = list(join_each('a', ['b', 'c', 'd']))
    assert r == ['a/b', 'a/c', 'a/d']



# Generated at 2022-06-24 03:08:07.156782
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']

# Generated at 2022-06-24 03:08:11.708107
# Unit test for function join_each
def test_join_each():
    expected = ['/home/foo', '/home/bar', '/home/baz']
    assert list(join_each('/home', ['foo', 'bar', 'baz'])) == expected

# Generated at 2022-06-24 03:08:14.280185
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', [])) == []
    assert list(join_each('foo', ['bar'])) == ['foo/bar']
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:08:16.254673
# Unit test for function join_each
def test_join_each():
    import os

    assert list(join_each('/', ['usr', 'local'])) == [
        os.path.join('/', p) for p in ['usr', 'local']]



# Generated at 2022-06-24 03:08:20.489712
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == [
        "foo/bar",
        "foo/baz",
    ]



# Generated at 2022-06-24 03:08:25.787947
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ['c', '/d/e'])) == ['/a/b/c',
                                                      '/a/b/d/e']



# Generated at 2022-06-24 03:08:28.524404
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child1', 'child2'])) == \
        [os.path.join('parent', 'child1'),
         os.path.join('parent', 'child2')]

# Test for function join_each
if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:08:31.250184
# Unit test for function join_each
def test_join_each():
    parent = '/'
    iterable = ['home', '', 'bin']

    assert tuple(join_each(parent, iterable)) == ('/home', '/', '/bin')



# Generated at 2022-06-24 03:08:33.086748
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b'])) == ['parent/a', 'parent/b']

# Generated at 2022-06-24 03:08:39.232426
# Unit test for function join_each
def test_join_each():
    parent = 'myparent'
    child1 = 'child1'
    child2 = 'child2'
    child3 = 'child3'
    path1 = os.path.join(parent, child1)
    path2 = os.path.join(parent, child2)
    path3 = os.path.join(parent, child3)

    # flatten list
    children = [child1, child2, child3]
    children_joined_list = [os.path.join(parent, child) for child in children]
    assert list(join_each(parent, children)) == children_joined_list

    # flatten generator
    children = (child1, child2, child3)
    children_joined_generator = (os.path.join(parent, child) for child in children)

# Generated at 2022-06-24 03:08:42.455779
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr", ("bin", "sbin"))) == [
        "/usr/bin", "/usr/sbin"
    ]



# Generated at 2022-06-24 03:08:44.783092
# Unit test for function join_each
def test_join_each():
    parent = os.path.abspath('.')
    some_list = ['..', '..', '..', 'and', 'another', 'directory']
    expected = map(lambda x: os.path.abspath(x), some_list)
    actual = list(join_each(parent, some_list))
    assert actual == expected



# Generated at 2022-06-24 03:08:48.266998
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('X', ('a', 'b', 'c'))) == ('X/a', 'X/b', 'X/c')

# Generated at 2022-06-24 03:08:50.637692
# Unit test for function join_each

# Generated at 2022-06-24 03:08:54.786927
# Unit test for function join_each
def test_join_each():
    tests = [
        (os.path.join('foo', 'bar'), ['a', 'b', 'c'],
         ['foo\\bar\\a', 'foo\\bar\\b', 'foo\\bar\\c']),
    ]

    for p, l, o in tests:
        assert list(join_each(p, l)) == o



# Generated at 2022-06-24 03:09:01.771504
# Unit test for function join_each
def test_join_each():
    print("Test: join_each")
    parent = "C:\\Users"
    path_list = ["tqasez\\1", "tqasez\\2"]
    result = list(join_each(parent, path_list))
    assert result == ["C:\\Users\\tqasez\\1", "C:\\Users\\tqasez\\2"]



# Generated at 2022-06-24 03:09:06.753445
# Unit test for function join_each
def test_join_each():
    from tempfile import TemporaryDirectory
    from inspect import isgenerator

    with TemporaryDirectory(prefix='join_each-') as d:
        file1 = os.path.join(d, 'file1')
        file2 = os.path.join(d, 'file2')
        with open(file1, 'w'):
            pass
        with open(file2, 'w'):
            pass

        got = join_each(d, (file1, file2))
        assert isgenerator(got)
        assert next(got) == file1
        assert next(got) == file2
        try:
            next(got)
        except StopIteration:
            assert True
        else:
            assert False, 'Iteration should terminate after two items.'



# Generated at 2022-06-24 03:09:12.324614
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each(os.path.dirname(__file__), ('x', 'y'))) == (
        os.path.join(os.path.dirname(__file__), 'x'),
        os.path.join(os.path.dirname(__file__), 'y'),
    )


# Return a list of all the files rooted at 'path'

# Generated at 2022-06-24 03:09:17.648799
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', 'child')) == ['parentchild']
    assert list(join_each('parent', ['child'])) == ['parentchild']
    assert list(join_each('parent', iter(['child']))) == ['parentchild']
    assert list(join_each('parent', ['child1', 'child2'])) == ['parentchild1', 'parentchild2']



# Generated at 2022-06-24 03:09:23.053064
# Unit test for function join_each
def test_join_each():
    import closure.utils as utils

    parent = u'path/to/parent'
    iterable = [u'child1', u'child2', u'child3']

    result = list(utils.join_each(parent, iterable))
    expected = map(lambda c: os.path.join(parent, c), iterable)
    assert_equals(result, expected)



# Generated at 2022-06-24 03:09:25.528493
# Unit test for function join_each
def test_join_each():
    from os.path import join
    # Test when iterable just contain one element
    assert list(join_each("parent", ["child"])) == [join("parent", "child")]
    # Test when iterable just contain more than one element
    assert list(join_each("parent", ["child1", "child2"])) == \
        [join("parent", "child1"), join("parent", "child2")]

# Generated at 2022-06-24 03:09:34.281393
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each("/home", ("chris", "john", "bob"))) == (
        "/home/chris",
        "/home/john",
        "/home/bob",
    )


if __name__ == "__main__":
    import sys

    this_dir = os.path.dirname(sys.argv[0])
    if len(sys.argv) == 1:
        file_list = list(join_each(this_dir, os.listdir(this_dir)))
    else:
        file_list = list(join_each(this_dir, sys.argv[1:]))
    print("file_list is a list of", len(file_list), "files and directories")

    file_list = filter(os.path.isfile, file_list)

    size_

# Generated at 2022-06-24 03:09:36.120337
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['user1', 'user2'])) == ['/home/user1', '/home/user2']



# Generated at 2022-06-24 03:09:42.528685
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['.oh-my-zsh'])) == ['./.oh-my-zsh']
    assert list(join_each('./', ['.oh-my-zsh'])) == ['./.oh-my-zsh']
    assert list(join_each('.', ['.oh-my-zsh', 'custom'])) == [
        './.oh-my-zsh',
        './.oh-my-zsh/custom',
    ]
    assert list(join_each('./', ['.oh-my-zsh', 'custom'])) == [
        './.oh-my-zsh',
        './.oh-my-zsh/custom',
    ]

# Generated at 2022-06-24 03:09:44.663319
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('.', ['a', 'b', 'c'])) == ('./a', './b', './c')



# Generated at 2022-06-24 03:09:49.163725
# Unit test for function join_each
def test_join_each():
    parent = os.path.abspath(os.path.dirname(__file__))
    gen = join_each(parent, ('..', '..', '..', 'README.md'))
    assert os.path.join(parent, '..', '..', '..', 'README.md') == next(gen)
    with pytest.raises(StopIteration):
        next(gen)



# Generated at 2022-06-24 03:09:51.252747
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["abc", "def"])) == ["/tmp/abc", "/tmp/def"]

# Generated at 2022-06-24 03:09:55.388061
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]



# Generated at 2022-06-24 03:09:58.499579
# Unit test for function join_each
def test_join_each():
    p = 'parent_path'
    it = ['file1', 'file2', 'file3']
    result = list(join_each(p, it))
    for i in range(len(result)):
        assert result[i] == os.path.join(p, it[i])

# Generated at 2022-06-24 03:10:04.596275
# Unit test for function join_each
def test_join_each():
    parent = 'foo'
    iterable = ['bar', 'bas']
    assert list(join_each(parent, iterable)) == ['foo/bar', 'foo/bas']
    assert list(join_each(parent, [])) == []
    assert list(join_each('', [])) == []
    assert list(join_each('', iterable)) == ['bar', 'bas']



# Generated at 2022-06-24 03:10:12.098389
# Unit test for function join_each
def test_join_each():
    print(list(join_each("/","abc")))
    #assert list(join_each("/","abc")) == ["/a", "/b", "/c"]
    print(list(join_each("/","a/b/c")))
    #assert list(join_each("/","a/b/c")) == ["/a/b/c"]
    print(list(join_each("/","")))
    #assert list(join_each("/","")) == []


test_join_each()

# Generated at 2022-06-24 03:10:14.017324
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['a', 'b', 'c']

# Generated at 2022-06-24 03:10:17.874293
# Unit test for function join_each
def test_join_each():
    assert list(join_each('./tmp', ['a', 'b/c', 'd/../e'])) == [
        './tmp/a',
        './tmp/b/c',
        './tmp/d/../e',
    ]



# Generated at 2022-06-24 03:10:19.367376
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['dir1', 'dir2'])) == ['parent/dir1', 'parent/dir2']



# Generated at 2022-06-24 03:10:25.137010
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["1", "2", "3"]
    expected = ["parent/1", "parent/2", "parent/3"]
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-24 03:10:28.479238
# Unit test for function join_each
def test_join_each():
    p = '/tmp'
    it = ['a', 'b']
    assert list(join_each(p, it)) == ['/tmp/a', '/tmp/b']

# Generated at 2022-06-24 03:10:31.817556
# Unit test for function join_each
def test_join_each():
    got = join_each('/home', ('bob', 'linda', 'sam'))
    assert ['/home/' + f for f in ('bob', 'linda', 'sam')] == list(got)



# Generated at 2022-06-24 03:10:36.141316
# Unit test for function join_each
def test_join_each():

    parent = '/Users/Olivia/Desktop'
    p_list = ['cat.png', 'dog.png', 'bear.png', 'mouse.png']

    joined_list = [
        os.path.join(parent, p)
        for p in p_list
    ]

    assert joined_list == list(join_each(parent, p_list))
    assert parent == '/Users/Olivia/Desktop'

# Generated at 2022-06-24 03:10:42.479523
# Unit test for function join_each
def test_join_each():
    assert list(join_each('home', ['user'])) == ['home/user']


home = '/home/user'

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 03:10:57.916139
# Unit test for function join_each
def test_join_each():
    assert list(join_each(
        './test_root',
        [
            'test_dir',
            'test_dir2',
            'simple_file1.txt',
        ]
    )) == [
        os.path.join('./test_root', 'test_dir'),
        os.path.join('./test_root', 'test_dir2'),
        os.path.join('./test_root', 'simple_file1.txt'),
    ]



# Generated at 2022-06-24 03:11:08.278948
# Unit test for function join_each

# Generated at 2022-06-24 03:11:09.739169
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:11:11.907909
# Unit test for function join_each
def test_join_each():
    parent = 'd:/'
    iterable = ['1', '2']
    expected = ['d:/1', 'd:/2']
    actual = join_each(parent, iterable)
    assert list(actual) == expected

# Generated at 2022-06-24 03:11:19.607863
# Unit test for function join_each
def test_join_each():
    parent = os.path.join('home', 'bob')
    childs = ('folder', 'file.txt')
    paths = join_each(parent, childs)
    assert list(paths) == [os.path.join(parent, c) for c in childs]


###############################################################################
# Task 3: Create a generator function that returns every line from every file
# in a directory tree.


# Generated at 2022-06-24 03:11:24.716894
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', 'child')) == ['parent/child']
    assert list(join_each('parent', ('child1', 'child2'))) == ['parent/child1', 'parent/child2']

# Generated at 2022-06-24 03:11:26.976280
# Unit test for function join_each
def test_join_each():
    assert list(join_each('root', [])) == []
    assert list(join_each('root', ['a'])) == ['root/a']
    assert list(join_each('root', ['a', 'b'])) == ['root/a', 'root/b']



# Generated at 2022-06-24 03:11:31.584443
# Unit test for function join_each
def test_join_each():
    assert (
        list(join_each("/", ("a", "b", "c"))) == ["/a", "/b", "/c"]
    )  # normal case



# Generated at 2022-06-24 03:11:34.388715
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['home', 'john'])) == ['/home', '/john']



# Generated at 2022-06-24 03:11:37.806168
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ('bar', 'baz'))) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-24 03:11:40.588912
# Unit test for function join_each
def test_join_each():
    parent = '/'
    for x in ['/', 'bin', 'usr']:
        assert x in join_each(parent, ['/', 'bin', 'usr'])



# Generated at 2022-06-24 03:11:45.501546
# Unit test for function join_each
def test_join_each():
    expect = [
        os.path.join(os.getcwd(), os.path.basename(__file__)),
        os.path.join(os.getcwd(), 'invalid.mod')
    ]

    assert list(join_each(os.getcwd(), [os.path.basename(__file__), 'invalid.mod'])) == expect



# Generated at 2022-06-24 03:11:52.214943
# Unit test for function join_each
def test_join_each():
    parent = "/foo/bar"

    def _aux(xs):
        return [x for x in join_each(parent, xs)]

    assert _aux([]) == []
    assert _aux(["baz"]) == ["/foo/bar/baz"]
    assert _aux(["baz", "quux"]) == ["/foo/bar/baz", "/foo/bar/quux"]
    assert _aux(["/baz"]) == ["/foo/bar/baz"]
    assert _aux(["../baz"]) == ["/foo/baz"]

# Generated at 2022-06-24 03:11:55.627357
# Unit test for function join_each
def test_join_each():
    result = list(join_each('test', ['a.py', 'b.py']))
    assert result == ['test/a.py', 'test/b.py']



# Generated at 2022-06-24 03:11:58.432046
# Unit test for function join_each
def test_join_each():
    l = ['a', 'b', 'c']
    assert list(join_each('d', l)) == ['d/a', 'd/b', 'd/c']



# Generated at 2022-06-24 03:12:00.406141
# Unit test for function join_each
def test_join_each():
    f = join_each('/dir', ['dir2', 'dir3'])
    print(f)
    for i in f:
        print(i)


# Generated at 2022-06-24 03:12:05.686041
# Unit test for function join_each
def test_join_each():
    # Arrange
    parent = '/home'
    items = ['tmp', 'old']

    # Act
    gen = join_each(parent, items)

    # Assert
    assert next(gen) == '/home/tmp'
    assert next(gen) == '/home/old'



# Generated at 2022-06-24 03:12:09.695892
# Unit test for function join_each
def test_join_each():
    p = 'a'
    iterable = ('b', 'c', 'd')
    assertlist = list(join_each(p, iterable))
    expected_list = ['a/b', 'a/c', 'a/d']
    assert assertlist == expected_list

# Generated at 2022-06-24 03:12:14.508417
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['bar', 'baz'])) == \
        ['/foo/bar', '/foo/baz']



# Generated at 2022-06-24 03:12:17.372012
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/home/user', ('foo', 'bar'))) == ('/home/user/foo', '/home/user/bar')
    assert tuple(join_each('', ('foo', 'bar'))) == ('foo', 'bar')



# Generated at 2022-06-24 03:12:21.508884
# Unit test for function join_each
def test_join_each():
    li = join_each('/home/user', ['file1', 'file2', 'file3'])
    for i in li:
        assert(i == os.path.join('/home/user', i))



# Generated at 2022-06-24 03:12:26.454114
# Unit test for function join_each
def test_join_each():
    table = [
        (('cs',     ['111', '111L']),    ['cs/111', 'cs/111L']),
        (('/tmp',   ['foo', 'bar']),     ['/tmp/foo', '/tmp/bar']),
        (('/tmp/',  ['foo', 'bar']),     ['/tmp/foo', '/tmp/bar']),
        (('/',      ['tmp', 'tmp/']),    ['/tmp', '/tmp/']),
    ]

    for args, expected in table:
        assert join_each(*args) == expected



# Generated at 2022-06-24 03:12:35.410795
# Unit test for function join_each
def test_join_each():
    path = '~/git/'
    subpaths = ['foo', 'bar', 'baz', 'qux']
    joined = join_each(path, subpaths)
    assert next(joined) == '{}/{}'.format(path, subpaths[0])
    assert next(joined) == '{}/{}'.format(path, subpaths[1])
    assert next(joined) == '{}/{}'.format(path, subpaths[2])
    assert next(joined) == '{}/{}'.format(path, subpaths[3])



# Generated at 2022-06-24 03:12:40.979038
# Unit test for function join_each
def test_join_each():
    """
    Joins each of the iterable items to the parent
    """
    parent = 'c:\\test'
    iterable = ['first', 'second', 'third']
    joined_iterable = join_each(parent, iterable)
    joined_list = list(joined_iterable)
    assert joined_list[0] == os.path.join(parent, 'first')
    assert joined_list[1] == os.path.join(parent, 'second')
    assert joined_list[2] == os.path.join(parent, 'third')



# Generated at 2022-06-24 03:12:44.830415
# Unit test for function join_each
def test_join_each():
    """
    test join each
    :return:
    """
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo' + os.sep + 'bar', 'foo' + os.sep + 'baz']
    assert list(join_each('foo', [])) == []



# Generated at 2022-06-24 03:12:49.223563
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == [
        '/a',
        '/b',
        '/c',
    ]
    assert list(join_each('/home/jeroenn', [])) == []
    assert list(join_each('/home', ['jeroenn/', 'jeroen/'])) == [
        '/home/jeroenn/',
        '/home/jeroen/',
    ]



# Generated at 2022-06-24 03:12:51.517332
# Unit test for function join_each
def test_join_each():
    assert list(join_each('', ['foo', 'bar'])) == ['foo', 'bar']
    assert list(join_each('/home/user/src', ['foo', 'bar'])) == [
        '/home/user/src/foo',
        '/home/user/src/bar']



# Generated at 2022-06-24 03:12:54.082448
# Unit test for function join_each
def test_join_each():
    assert list(join_each('./app/templates', ['admin', 'patient'])) == \
        ["./app/templates/admin", "./app/templates/patient"]

# Generated at 2022-06-24 03:12:57.639557
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/foo', [])) == ()
    assert tuple(join_each('/foo', ['bar'])) == ('/foo/bar',)
    assert tuple(join_each('/foo', ['bar', 'baz'])) == ('/foo/bar', '/foo/baz')

# Generated at 2022-06-24 03:12:59.792538
# Unit test for function join_each
def test_join_each():
    itr = join_each(__file__, ["..", "data", "V1", "spk", "VAD", "S1"])
    print(itr)
    print(list(itr))



# Generated at 2022-06-24 03:13:04.262025
# Unit test for function join_each
def test_join_each():
    my_list = ["/Users", "/home", "/var"]
    assert list(join_each("/", my_list)) == ["/Users", "/home", "/var"]



# Generated at 2022-06-24 03:13:08.686165
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    iterable = ['one', 'two', 'three']
    result = ['/tmp/one', '/tmp/two', '/tmp/three']

    assert list(join_each(parent, iterable)) == result



# Generated at 2022-06-24 03:13:17.945566
# Unit test for function join_each
def test_join_each():
    test_input = join_each("/var/lib/test", ["info", "project"])

    next(test_input)
    test_input = join_each("/var/lib/test", ["info", "project"])
    assert next(test_input) == "/var/lib/test/info"
    assert next(test_input) == "/var/lib/test/project"
    test_input = join_each("/var/lib/test", ["info", "project"])
    assert list(test_input) == [
        "/var/lib/test/info",
        "/var/lib/test/project",
    ]



# Generated at 2022-06-24 03:13:23.064392
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/homer', ['Documents', 'Pictures', 'Documents'])) == ['/home/homer/Documents',
                                                                                      '/home/homer/Pictures',
                                                                                      '/home/homer/Documents']


# This function has to be written for the challenge

# Generated at 2022-06-24 03:13:26.286313
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/parent', ('a', 'b', 'c'))) == [
        '/parent/a', '/parent/b', '/parent/c']



# Generated at 2022-06-24 03:13:31.394602
# Unit test for function join_each
def test_join_each():
    assert join_each("/home", ["user", "..", "usr", "bin"]) == [
        "/home/user",
        "/home/..",
        "/home/usr",
        "/home/bin",
    ]



# Generated at 2022-06-24 03:13:35.959434
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c', 'd'])) == ['a/b', 'a/c', 'a/d']

# Generated at 2022-06-24 03:13:40.876262
# Unit test for function join_each
def test_join_each():
    assert list(join_each('abc', ['def', 'ghi', 'jkl'])) == ['abc\\def', 'abc\\ghi', 'abc\\jkl']



# Generated at 2022-06-24 03:13:45.871629
# Unit test for function join_each
def test_join_each():
    file_list = ['file1', 'file2', 'file3']
    parent = 'test_folder'
    joined_list = join_each(parent, file_list)
    test_list = [os.path.join(parent, f) for f in file_list]
    print(test_list)
    print(list(joined_list))
    assert test_list == list(joined_list)



# Generated at 2022-06-24 03:13:49.372133
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]
    assert list(join_each("foo/", ["bar", "baz"])) == ["foo/bar", "foo/baz"]
    assert list(join_each("foo", ["", "baz"])) == ["foo", "foo/baz"]