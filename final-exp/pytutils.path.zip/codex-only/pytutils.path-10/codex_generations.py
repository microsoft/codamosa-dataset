

# Generated at 2022-06-24 03:03:52.133781
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["ciao", "hey", "hello"])) == [os.path.join("/tmp", "ciao"), os.path.join("/tmp", "hey"), os.path.join("/tmp", "hello")]


# Return ALL the files with their absolute paths in the directory dir_name

# Generated at 2022-06-24 03:03:58.140372
# Unit test for function join_each
def test_join_each():
    parent = '/home/wxnacy'
    iterable = ['foo', 'bar', 'baz']
    result = list(join_each(parent, iterable))
    assert result == [
        '/home/wxnacy/foo',
        '/home/wxnacy/bar',
        '/home/wxnacy/baz'
    ]



# Generated at 2022-06-24 03:04:07.365528
# Unit test for function join_each
def test_join_each():
    parent = 'parent/path'
    iterable = ['foo/', 'bar/../bar', 'baz/qux']
    assert list(join_each(parent, iterable)) == [
        'parent/path/foo',
        'parent/path/bar',
        'parent/path/baz/qux',
    ]
    iterable = ('', '', '')
    assert list(join_each(parent, iterable)) == ['parent/path', 'parent/path', 'parent/path']
    iterable = ()
    assert list(join_each(parent, iterable)) == []


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-24 03:04:13.119816
# Unit test for function join_each
def test_join_each():
    # Test regular usage
    test_iterable = ['test1', 'test2']
    output = list(join_each('test_parent', test_iterable))
    expected = ['test_parent\\test1', 'test_parent\\test2']
    assert output == expected

    # Test with empty iterable
    test_iterable = []
    output = list(join_each('test_parent', test_iterable))
    expected = []
    assert output == expected



# Generated at 2022-06-24 03:04:16.908049
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ('/bar', 'baz'))) == [
        '/foo/bar', '/foo/baz']



# Generated at 2022-06-24 03:04:19.907759
# Unit test for function join_each
def test_join_each():
    parent = 'foo'
    iterable = ['a', 'b', 'c']
    expected_answer = ['foo/a', 'foo/b', 'foo/c']
    assert list(join_each(parent, iterable)) == expected_answer



# Generated at 2022-06-24 03:04:25.912159
# Unit test for function join_each
def test_join_each():
    assert list(join_each('X', ['Y', 'Z'])) == ['X/Y', 'X/Z']


#   Function to return a list of all the files in the directory passed to it

# Generated at 2022-06-24 03:04:33.411147
# Unit test for function join_each
def test_join_each():
    # Given
    parent = '/usr'
    iterable = ['bin', 'local', 'bin']

    # When
    j = join_each(parent, iterable)
    joined = [list(j)]

    # Then
    assert joined == [
        ['/usr/bin', '/usr/local', '/usr/bin']]



# Generated at 2022-06-24 03:04:36.533087
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]

# Generated at 2022-06-24 03:04:38.338128
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a/b", ["c", "d"])) == ["/a/b/c", "/a/b/d"]

# Generated at 2022-06-24 03:04:43.103075
# Unit test for function join_each
def test_join_each():
    import tempfile
    # create a temp directory and add a few files
    with tempfile.TemporaryDirectory() as d:
        files = ['a.py', 'b.txt', 'c.py']
        full_files = [os.path.join(d, f) for f in files]

        for f in full_files:
            with open(f, 'w') as f:
                pass

        # select only the .py files
        g = join_each(d, files)

        for f in full_files:
            assert next(g) == f

# Generated at 2022-06-24 03:04:46.557278
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == [
        '/tmp/a', '/tmp/b', '/tmp/c']

# TODO: write a test for unjoin_each



# Generated at 2022-06-24 03:04:48.410851
# Unit test for function join_each
def test_join_each():
    assert list(join_each("abc", ["def", "ghi"])) \
        == ["abc/def", "abc/ghi"]

# Generated at 2022-06-24 03:04:54.147800
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['childA', 'childB', 'childC']
    actual = join_each(parent, iterable)
    expected = ['parent\\childA', 'parent\\childB', 'parent\\childC']
    for actual_path, expected_path in zip(actual, expected):
        assert actual_path == expected_path

# Generated at 2022-06-24 03:04:59.392375
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', [])) == []
    assert list(join_each('a', ['b'])) == ['a/b']
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a', ['b/c', 'd/e'])) == ['a/b/c', 'a/d/e']



# Generated at 2022-06-24 03:05:07.158762
# Unit test for function join_each
def test_join_each():
    dir_ = tempfile.mkdtemp()
    # Files:
    #   dir/1
    #   dir/a
    #   dir/b
    #   dir/c
    #   dir/d
    #   dir/42
    files = [str(i) for i in range(5)] + ['42']

    for f in files:
        with open(os.path.join(dir_, f), 'w'):
            pass

    # Create dir/dir with subdirs/files
    subdir = os.path.join(dir_, 'dir')
    os.mkdir(subdir)
    # subdir:
    #   dir/dir/1
    #   dir/dir/a
    #   dir/dir/b
    #   dir/dir/c
    #   dir/dir/d

# Generated at 2022-06-24 03:05:11.746611
# Unit test for function join_each
def test_join_each():
    # arrange
    parent = "a"
    iterable = ["b", "c", "d"]
    expected = ["a/b", "a/c", "a/d"]

    # act
    actual = join_each(parent, iterable)

    # assert
    assert [a for a in actual] == expected



# Generated at 2022-06-24 03:05:13.087754
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == [
        '/a/b', '/a/c']



# Generated at 2022-06-24 03:05:14.733910
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['bar', 'baz'])) == ['/foo/bar', '/foo/baz']
    assert list(join_each('', [])) == []



# Generated at 2022-06-24 03:05:21.860990
# Unit test for function join_each
def test_join_each():
    iterable1 = ["one", "two", "three"]
    iterable2 = ["four", "five", "six"]
    expected = ["onefour", "twofive", "threesix"]
    result = join_each("", join_each("", iterable1, iterable2))
    for e, r in zip(expected, result):
        assert e == r



# Generated at 2022-06-24 03:05:25.025240
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('foo', [])) == [])
    assert(list(join_each('foo', ['bar'])) == ['foo/bar'])
    assert(list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz'])

# Generated at 2022-06-24 03:05:31.369867
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == [os.path.join('/', 'a'), '/b']
    assert list(join_each('/', ('a', 'b'))) == [os.path.join('/', 'a'), '/b']
    assert list(join_each('/', {})) == []



# Generated at 2022-06-24 03:05:35.011305
# Unit test for function join_each
def test_join_each():
    parent = '/home/user'
    iterable = ['file1.py', 'file2.py', 'file3.py']
    expected = ['/home/user/file1.py', '/home/user/file2.py',
                '/home/user/file3.py']
    actual = list(join_each(parent, iterable))
    assert actual == expected



# Generated at 2022-06-24 03:05:36.700396
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['home', 'joe'])) == ['/home', '/joe']



# Generated at 2022-06-24 03:05:39.602634
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', '/b/c'])) == ['/a', '/b/c']
    assert list(join_each('/', [])) == []



# Generated at 2022-06-24 03:05:41.538072
# Unit test for function join_each
def test_join_each():
    
    parent = "dir"
    iterable = ["a", "b", "c"]
    
    assert list(join_each(parent, iterable)) == ["dir/a", "dir/b", "dir/c"]



# Generated at 2022-06-24 03:05:44.282916
# Unit test for function join_each
def test_join_each():
    parent = '/prj'
    iterable = iter(['/tmp', '/mnt'])
    assert '/prj/tmp' in list(join_each(parent, iterable))
    assert '/prj/mnt' in list(join_each(parent, iterable))



# Generated at 2022-06-24 03:05:50.407448
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']

    assert list(join_each('/', [])) == []


# Generated at 2022-06-24 03:05:52.631435
# Unit test for function join_each
def test_join_each():
    assert isinstance(list(join_each("", [])), list)
    assert list(join_each("", [])) == []
    assert list(join_each("a", [])) == []
    assert list(join_each("", ["b"])) == ["b"]
    assert sorted(list(join_each("a", ["b"]))) == ["a/b"]



# Generated at 2022-06-24 03:06:02.442841
# Unit test for function join_each
def test_join_each():
    tests = (("/a/b/c", ('d', 'e', 'f')),
             ("/a/b/c", ('f/g', 'h', 'i')),
             ("/a/b/c", ('f/g/h', 'i', 'j')),
             ("/a/b/c", ('f/g/h/i', 'j', 'k')))
    for parent, iterable in tests:
        result = list(join_each(parent, iterable))
        expected = [os.path.join(parent, s) for s in iterable]
        assert result == expected, "{} != {}".format(result, expected)


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-24 03:06:06.340309
# Unit test for function join_each
def test_join_each():
    iterable = join_each('/hello/world', ['a', 'b', 'c'])

    assert next(iterable) == '/hello/world/a'
    assert next(iterable) == '/hello/world/b'
    assert next(iterable) == '/hello/world/c'



# Generated at 2022-06-24 03:06:11.456351
# Unit test for function join_each
def test_join_each():
    assert os.path.join('parent', 'a') in join_each('parent', ['a', 'b', 'c'])



# Generated at 2022-06-24 03:06:16.450390
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', [1, 2])) == ['a/1', 'a/2']
    assert list(join_each('/a/b', ['c', 'd'])) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-24 03:06:18.957689
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    parent = '/my/test'
    result = list(join_each(parent, iterable))
    assert result == [
        os.path.join(parent, 'a'),
        os.path.join(parent, 'b'),
        os.path.join(parent, 'c'),
    ]

# Generated at 2022-06-24 03:06:22.397657
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["a", "b"])) == ["foo/a", "foo/b"]

# Generated at 2022-06-24 03:06:30.192041
# Unit test for function join_each
def test_join_each():
    tests = [('/a', ['b', 'c']),
             ('a', ['b', 'c']),
             ('a/', ['b', 'c']),
             ('a/b/c', ['d', 'e']),
             ('a/b/c/', ['d', 'e']),
             ('', ['b', 'c']),
             ('/', ['b', 'c'])]
    for test in tests:
        assert list(join_each(*test)) == [os.path.join(*test)] * len(test[1])

# Generated at 2022-06-24 03:06:32.290212
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['bin', 'include'])) == ['/usr/bin', '/usr/include']



# Generated at 2022-06-24 03:06:34.821077
# Unit test for function join_each
def test_join_each():
    assert list(join_each("tmp", ["a", "b", "c"])) == ["tmp/a", "tmp/b", "tmp/c"]

# Generated at 2022-06-24 03:06:39.941879
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo/bar', ['1', '2', '3'])) == [
        os.path.join('/foo/bar', '1'),
        os.path.join('/foo/bar', '2'),
        os.path.join('/foo/bar', '3')
    ]

# Generated at 2022-06-24 03:06:42.049901
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/parent/', ['a', 'b/c/d'])) == [
        '/parent/a', '/parent/b/c/d']

# Generated at 2022-06-24 03:06:44.934287
# Unit test for function join_each
def test_join_each():
    exp = ['/root/bin', '/root/etc', '/root/var']
    obs = list(join_each('/root', ['bin', 'etc', 'var']))
    assert exp == obs



# Generated at 2022-06-24 03:06:49.411270
# Unit test for function join_each
def test_join_each():
    assert list(join_each(os.curdir, ['a', 'b', os.pardir])) == [
        os.path.join(os.curdir, 'a'),
        os.path.join(os.curdir, 'b'),
        os.path.join(os.curdir, os.pardir),
    ]



# Generated at 2022-06-24 03:06:51.135514
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('~', ['a', 'b', 'c'])) == ('~/a', '~/b', '~/c')

# Generated at 2022-06-24 03:06:52.450866
# Unit test for function join_each
def test_join_each():
    assert join_each("/one", ["two", "three"]) == ["/one/two", "/one/three"]

# Generated at 2022-06-24 03:06:57.437400
# Unit test for function join_each
def test_join_each():
    assert "one\ttwo" == os.path.join("one", "two")

    p = os.path.join("/", "etc", "passwd")
    parts = ["/", "etc", "passwd"]

    assert p == os.path.join(*parts)
    assert p == os.path.join("/", *parts[1:])
    assert p == os.path.join(*parts[:-1], parts[-1])
    assert p == os.path.join("/", *parts[1:])
    assert p == os.path.join("/", join_each("/", parts[1:]))



# Generated at 2022-06-24 03:07:05.776353
# Unit test for function join_each
def test_join_each():
    from pathlib import Path

    base_dir = os.path.join(os.path.dirname(__file__), 'data_join_each')

    # Stimulus
    files = ['data_a.csv', 'data_b.csv', Path('data_c.csv')]  # mix Path and string

    # Execution
    result = join_each(base_dir, files)

    # Evaluation
    result = list(result)
    assert len(result) == 3
    print(result)
    assert result[0] == os.path.join(base_dir, 'data_a.csv')
    assert result[1] == os.path.join(base_dir, 'data_b.csv')
    assert result[2] == os.path.join(base_dir, 'data_c.csv')

    return




# Generated at 2022-06-24 03:07:07.577896
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]



# Generated at 2022-06-24 03:07:13.589265
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', [])) == []
    assert list(join_each('a', ('b', 'c'))) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:07:15.644909
# Unit test for function join_each
def test_join_each():
    base_dir = 'C:'
    assert list(join_each(base_dir, ['dir1', 'dir2', 'dir3'])) == [
        'C:\\dir1',
        'C:\\dir2',
        'C:\\dir3'
    ]



# Generated at 2022-06-24 03:07:21.173365
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar'])) == [
        '/foo', '/bar'
    ]


# Returns all files in a directory, including subdirectories.
#
# Returns a generator of (path, filename) tuples.

# Generated at 2022-06-24 03:07:26.768537
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["", None, "b"])) == ["a", "ab"]
    assert list(join_each("a", [])) == []
    assert list(join_each("a", ["b", "c", "d"])) == ["ab", "ac", "ad"]
    assert list(join_each("a", ["1/2", "3", "4", "5/6"])) == ["a1/2", "a3", "a4", "a5/6"]



# Generated at 2022-06-24 03:07:29.308414
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/t', ['a', 'b', 'c'])) == [
        '/t/a',
        '/t/b',
        '/t/c'
    ]

# Generated at 2022-06-24 03:07:32.156084
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b", "c"])) == [
        "/tmp/a",
        "/tmp/b",
        "/tmp/c",
    ]


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-24 03:07:35.605078
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-24 03:07:38.684465
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr/bin", ["ls", "cat", "pwd"])) == ['/usr/bin/ls', '/usr/bin/cat', '/usr/bin/pwd']


# Problem 1

# Generated at 2022-06-24 03:07:41.873664
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-24 03:07:45.720396
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/c', ['d', 'e', 'f'])) == ['/a/b/c/d',
                                                         '/a/b/c/e',
                                                         '/a/b/c/f']

# Generated at 2022-06-24 03:07:47.707100
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]



# Generated at 2022-06-24 03:07:52.558464
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b"])) == ["/tmp/a", "/tmp/b"]
    assert list(join_each("/tmp", [])) == []

# Generated at 2022-06-24 03:07:57.978774
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["user", "log"])) == ["/home/user", "/home/log"]
    assert list(join_each(".", ["a", "b", "c"])) == ["./a", "./b", "./c"]



# Generated at 2022-06-24 03:07:59.727438
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-24 03:08:04.342707
# Unit test for function join_each
def test_join_each():
    iterable = ["a", "b", "c"]
    result = list(join_each("x", iterable))
    assert result == ["x/a", "x/b", "x/c"]


# Call join_each with "." as the parent, plus these
# strings:
#
#     a, b, c
#     1, 2, 3
#

# Generated at 2022-06-24 03:08:12.075795
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['foo', 'bar', 'baz'])) == \
        ['/tmp/foo', '/tmp/bar', '/tmp/baz']

    assert list(join_each('./tmp', ['foo', 'bar', 'baz'])) == \
        ['./tmp/foo', './tmp/bar', './tmp/baz']

    assert list(join_each('/tmp/', ['foo', 'bar', 'baz'])) == \
        ['/tmp/foo', '/tmp/bar', '/tmp/baz']

    assert list(join_each('/tmp/', ['foo/', 'bar/', 'baz/'])) == \
        ['/tmp/foo/', '/tmp/bar/', '/tmp/baz/']


# Generated at 2022-06-24 03:08:14.379576
# Unit test for function join_each
def test_join_each():
    cwd = os.getcwd()
    files = os.listdir(cwd)
    joined = list(join_each(cwd, files))
    for path in joined:
        assert os.path.isfile(path)



# Generated at 2022-06-24 03:08:16.898078
# Unit test for function join_each
def test_join_each():
    assert list(join_each("d", ["a", "b"])) == ["d/a", "d/b"]
    assert list(join_each("d", ("a", "b"))) == ["d/a", "d/b"]



# Generated at 2022-06-24 03:08:21.207163
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/tmp', ('a', 'b'))) == ('/tmp/a', '/tmp/b')
    assert tuple(join_each('/tmp', ())) == ()



# Generated at 2022-06-24 03:08:25.603524
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b', 'c'])) == ['parent/a', 'parent/b', 'parent/c']



# Generated at 2022-06-24 03:08:30.879950
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp/test', ('a', 'b', 'c'))) == [
        '/tmp/test/a',
        '/tmp/test/b',
        '/tmp/test/c',
    ]



# Generated at 2022-06-24 03:08:36.289731
# Unit test for function join_each
def test_join_each():
    expected = [
        'path/to/TARGET',
        'path/to/ABORT',
        'path/to/FAIL',
        'path/to/WARN',
        'path/to/IGNORE',
    ]
    targets = [
        'TARGET',
        'ABORT',
        'FAIL',
        'WARN',
        'IGNORE',
    ]
    actual = join_each('path/to', targets)
    assert list(actual) == expected



# Generated at 2022-06-24 03:08:42.517675
# Unit test for function join_each
def test_join_each():
    # Test a join_each with a single path element
    path_elements = ["foo"]
    for path in join_each("/", path_elements):
        assert path == "/foo"

    # Test a join_each with multiple path elements
    path_elements = ["foo", "bar"]
    for path in join_each("/", path_elements):
        assert path in ["/foo", "/foo/bar"]

# Generated at 2022-06-24 03:08:47.035603
# Unit test for function join_each
def test_join_each():
    # Create a temporary directory and change cwd there
    path = tempfile.mkdtemp()
    cwd = os.getcwd()
    os.chdir(path)

    # Create an example directory and subdirectory structure
    example_path = os.path.join(path, 'bar', 'foo')
    os.makedirs(example_path)

    # We can now use join_each to find the test structure
    assert list(join_each(path, os.listdir(path))) == \
        [os.path.join(path, 'bar')]

    assert list(join_each(os.path.join(path, 'bar'), os.listdir(os.path.join(path, 'bar')))) == \
        [os.path.join(path, 'bar', 'foo')]


# Generated at 2022-06-24 03:08:56.500792
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/var', ['log/syslog', 'log/process'])) == [
        '/var/log/syslog',
        '/var/log/process',
    ]
    assert list(join_each('/var', [])) == []

    assert list(join_each('/var', ('log/syslog', 'log/process'))) == [
        '/var/log/syslog',
        '/var/log/process',
    ]
    assert list(join_each('/var', tuple())) == []

    assert list(join_each('/var', 'log/syslog log/process'.split())) == [
        '/var/log/syslog',
        '/var/log/process',
    ]
    assert list(join_each('/var', [])) == []



# Generated at 2022-06-24 03:09:00.795814
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b'])) == [
        '/tmp/a',
        '/tmp/b'
    ]

# Generated at 2022-06-24 03:09:06.929142
# Unit test for function join_each
def test_join_each():
    parent = 'c:\\program files'
    iterable = ('Python', 'Python27')
    assert list(join_each(parent, iterable)) == ['c:\\program files\\Python',
                                                 'c:\\program files\\Python27']



# Generated at 2022-06-24 03:09:12.194857
# Unit test for function join_each
def test_join_each():
    path = ".."
    iterable = ["foo", "bar"]
    expected_result = ["../foo", "../bar"]
    res = list(join_each(path, iterable))
    assert res == expected_result
    assert res != expected_result[::-1]
    assert res + ["!"] == expected_result + ["!"]

# Generated at 2022-06-24 03:09:17.375928
# Unit test for function join_each
def test_join_each():
    parent = '/home/user'
    iterable = ['fileA', 'fileB']
    joined = join_each(parent, iterable)

    assert '/home/user/fileA' == next(joined)
    assert '/home/user/fileB' == next(joined)
    with pytest.raises(StopIteration):
        next(joined)



# Generated at 2022-06-24 03:09:20.903368
# Unit test for function join_each
def test_join_each():
    parent = 'parent'

    iterable = ['a', 'b']

    assert list(join_each(parent, iterable)) == ['parent/a', 'parent/b']



# Generated at 2022-06-24 03:09:26.522764
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['bob', 'china'])) == ['/bob', '/china']
    assert list(join_each('/test', ['bob', 'china'])) == [
        '/test/bob', '/test/china']
    assert list(join_each('/test/', ['bob', 'china'])) == [
        '/test/bob', '/test/china']



# Generated at 2022-06-24 03:09:31.576809
# Unit test for function join_each
def test_join_each():
    p = '/hello/world'
    j1 = join_each(p, ['one', 'two', 'three'])
    assert list(j1) == [
        '/hello/world/one',
        '/hello/world/two',
        '/hello/world/three',
        ]


# Convert string to bytes

# Generated at 2022-06-24 03:09:32.723372
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["a", "b"])) == ["/home/a", "/home/b"]

# Generated at 2022-06-24 03:09:36.193470
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', 'abc/def/ghi'.split('/'))) == [
        '/home',
        '/home/abc',
        '/home/abc/def',
        '/home/abc/def/ghi',
    ]



# Generated at 2022-06-24 03:09:37.680019
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:09:42.283193
# Unit test for function join_each
def test_join_each():
    expected = list(join_each(os.path.split(f)[0], os.path.split(f)[1:]))
    actual = list(join_each(os.path.split(f)[0], os.path.split(f)[1:]))

    assert actual == expected



# Generated at 2022-06-24 03:09:45.113142
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('/a/b', ['c', 'd/e'])) ==
           ['/a/b/c', '/a/b/d/e'])



# Generated at 2022-06-24 03:09:47.306608
# Unit test for function join_each
def test_join_each():
    tmp = list(join_each("/etc", ["passwd", "hosts"]))
    assert tmp == ["/etc/passwd", "/etc/hosts"]



# Generated at 2022-06-24 03:09:49.642907
# Unit test for function join_each
def test_join_each():
    p = '/home'
    assert list(join_each(p, ['foo', 'bar', 'baz'])) == ['/home/foo', '/home/bar', '/home/baz']



# Generated at 2022-06-24 03:09:54.751872
# Unit test for function join_each
def test_join_each():
    parent = 'a'
    iterable = ['a', 'b', 'c']
    assert list(join_each(parent, iterable)) == ['a/a', 'a/b', 'a/c']

# Generated at 2022-06-24 03:09:58.830415
# Unit test for function join_each
def test_join_each():
    parent = "one/two"
    children = ["three", "four", "five"]
    expected = [
        os.path.join(parent, "three"),
        os.path.join(parent, "four"),
        os.path.join(parent, "five"),
    ]
    assert list(join_each(parent, children)) == expected



# Generated at 2022-06-24 03:10:02.468546
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:10:06.304832
# Unit test for function join_each
def test_join_each():
    # Test 1
    expected = [
        './onefile',
        './onefile/textfile.txt',
        './onefile/new',
        './onefile/new/anotherfile.txt'
    ]
    result = [
        *join_each('./onefile', ['/'])
    ]
    assert expected == result



# Generated at 2022-06-24 03:10:07.835836
# Unit test for function join_each
def test_join_each():
    assert list(join_each('dir', ['a', 'b'])) == ['dir/a', 'dir/b']



# Generated at 2022-06-24 03:10:18.020594
# Unit test for function join_each
def test_join_each():
    test_list = ["hi", "bye"]
    expected_list = ["hi/bye"]
    joined_list = list(join_each("hi", test_list))
    assert joined_list == expected_list

# Generated at 2022-06-24 03:10:19.489243
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', 'bcd')) == ['a/b', 'a/c', 'a/d']



# Generated at 2022-06-24 03:10:24.552149
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["dev", "user"])) == [
        "/dev",
        "/user",
    ]



# Generated at 2022-06-24 03:10:27.908860
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/root', ['foo', 'bar'])) == ['/root/foo', '/root/bar']



# Generated at 2022-06-24 03:10:31.166760
# Unit test for function join_each
def test_join_each():
    result = list(join_each("/home/my_name/", ["desktop", "documents"]))
    assert result == [
        "/home/my_name/desktop",
        "/home/my_name/documents"]



# Generated at 2022-06-24 03:10:37.183337
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["etc", "var"])) == ['/etc', '/var']
    assert list(join_each("/abc/def", ["ghi", "jkl"])) == ['/abc/def/ghi', '/abc/def/jkl'], \
        "join_each with non-root path"
    assert list(join_each("/", [""])) == ['/'], \
        "join_each with empty suffix"



# Generated at 2022-06-24 03:10:43.406766
# Unit test for function join_each
def test_join_each():
    p = "/a/b/c"
    iterable = ["a", "b", "c"]
    expected = ["/a/b/c/a", "/a/b/c/b", "/a/b/c/c"]
    actual = [x for x in join_each(p, iterable)]
    assert actual == expected

# Generated at 2022-06-24 03:10:56.236726
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/c', ['/d', '/e', '/f'])) == [
        '/a/b/c/d', '/a/b/c/e', '/a/b/c/f']



# Generated at 2022-06-24 03:11:02.781151
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/path', ['to', 'here'])) == [os.path.join('/path', 'to'), os.path.join('/path', 'here')]
    assert list(join_each('path', ['to', 'here'])) == [os.path.join('path', 'to'), os.path.join('path', 'here')]
    assert list(join_each('', ['to', 'here'])) == [os.path.join('', 'to'), os.path.join('', 'here')]
    assert list(join_each('/path/to', ['here', 'there'])) == [os.path.join('/path/to', 'here'), os.path.join('/path/to', 'there')]



# Generated at 2022-06-24 03:11:06.823400
# Unit test for function join_each
def test_join_each():
    """Test if the function is able to return the correct joined results."""
    parent = '/home'
    iterable = ['a', 'b', 'c']
    res = join_each(parent, iterable)
    assert next(res) == os.path.join(parent, iterable[0])
    assert next(res) == os.path.join(parent, iterable[1])
    assert next(res) == os.path.join(parent, iterable[2])



# Generated at 2022-06-24 03:11:12.296852
# Unit test for function join_each
def test_join_each():
    iterator = join_each('/parents/path', ('first', 'second', 'third'))
    expected_list = [
        '/parents/path/first',
        '/parents/path/second',
        '/parents/path/third'
    ]
    assert list(iterator) == expected_list



# Generated at 2022-06-24 03:11:14.207997
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foobar", ("baz", "buz"))) == ["foobar/baz", "foobar/buz"]
    assert list(join_each("", ("baz", "buz"))) == ["baz", "buz"]

# Generated at 2022-06-24 03:11:16.808457
# Unit test for function join_each
def test_join_each():
    parent = "base"
    child_iterable = [["a", "b", "c"], ["d", "e", "f"]]
    to_join = parent, child_iterable
    expected = [
        os.path.join(parent, "a", "b", "c"),
        os.path.join(parent, "d", "e", "f"),
    ]
    assert list(join_each(*to_join)) == expected



# Generated at 2022-06-24 03:11:19.506602
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["a", "b", "c"])) == ["/a", "/b", "/c"]
    assert list(join_each("/foo", ["a", "b", "c"])) == ["/foo/a", "/foo/b", "/foo/c"]

# Generated at 2022-06-24 03:11:24.348559
# Unit test for function join_each
def test_join_each():
    assert [p for p in join_each('/tmp', ['a', 'b', 'c'])] == ['/tmp/a', '/tmp/b', '/tmp/c']



# Generated at 2022-06-24 03:11:26.480831
# Unit test for function join_each
def test_join_each():
    # Setup
    parent = "dir"
    iterable = ['a', 'b']
    # Exercise
    actual = list(join_each(parent, iterable))
    # Verify
    expected = ['dir/a', 'dir/b']
    assert actual == expected



# Generated at 2022-06-24 03:11:32.732854
# Unit test for function join_each
def test_join_each():
    fmt = _mkfmt('/', 'foo', 'bar')
    args = ['test', 'bar', 'test2']
    subject = join_each(*args)
    assert_equal(
        fmt(*args),
        next(subject),
    )



# Generated at 2022-06-24 03:11:34.605943
# Unit test for function join_each
def test_join_each():
    assert list(join_each('path', ['a', 'b'])) == ['path/a', 'path/b']

# Generated at 2022-06-24 03:11:38.961006
# Unit test for function join_each
def test_join_each():
    assert list(join_each('c:', 'a b c'.split())) == ['c:a', 'c:b', 'c:c']



# Generated at 2022-06-24 03:11:45.617366
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    iterable = 'path', 'to', 'file'
    expected = [os.path.join(parent, x) for x in iterable]
    assert list(join_each(parent, iterable)) == expected
    assert list(join_each(parent, iterable)) == expected


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:11:47.850102
# Unit test for function join_each
def test_join_each():
    gen = join_each('/usr', ['lib', 'local', 'bin'])
    assert list(gen) == ['/usr/lib', '/usr/local', '/usr/bin']

# Generated at 2022-06-24 03:11:52.569561
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["usr", "lib"])) == ["/usr", "/lib"]
    assert list(join_each("/usr", ["lib", "bin", "include"])) == ["/usr/lib", "/usr/bin", "/usr/include"]
    for p in join_each("/usr", ["include", "lib"]):
        print(p)



# Generated at 2022-06-24 03:11:56.509393
# Unit test for function join_each
def test_join_each():
    testParent = '/test'
    testIterable = ['a', 'b', 'c']
    assert list(join_each(testParent, testIterable)) == ['/test/a', '/test/b', '/test/c']

# Generated at 2022-06-24 03:11:59.653292
# Unit test for function join_each
def test_join_each():
    j = list(join_each("/usr", ["bin", "lib"]))
    assert j == ["/usr/bin", "/usr/lib"]
    j = list(join_each("/usr", []))
    assert j == []



# Generated at 2022-06-24 03:12:03.989049
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']

# Generated at 2022-06-24 03:12:09.623730
# Unit test for function join_each
def test_join_each():
    # base case
    assert list(join_each('', [])) == []
    assert list(join_each('foo', [])) == []
    assert list(join_each('foo', ['a'])) == ['foo/a']
    assert list(join_each('foo', ['a', 'b'])) == ['foo/a', 'foo/b']



# Generated at 2022-06-24 03:12:16.131948
# Unit test for function join_each
def test_join_each():
    assert set(join_each('path/to', ['one', 'two', 'three'])) == set([
        'path/to/one',
        'path/to/two',
        'path/to/three'
    ])


# Filter function to check if a path is a file

# Generated at 2022-06-24 03:12:21.389852
# Unit test for function join_each
def test_join_each():
    l = ["README.md", "requirements.txt"]
    assert list(join_each("/etc", l)) == ['/etc/README.md', '/etc/requirements.txt']



# Generated at 2022-06-24 03:12:23.922125
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == [
        os.path.join('foo', 'bar'),
        os.path.join('foo', 'baz')
    ]

# Generated at 2022-06-24 03:12:27.710946
# Unit test for function join_each
def test_join_each():
    a = ['a', 'b', 'c']
    expected = ['foo/a', 'foo/b', 'foo/c']
    result_yield = list(join_each('foo', a))
    assert expected == result_yield



# Generated at 2022-06-24 03:12:37.417036
# Unit test for function join_each
def test_join_each():
    test_dir = '/foo/bar'

    def check(expect, names):
        assert list(join_each(test_dir, names)) == expect

    check([], [])
    check([], [''])
    check(['/foo/bar/baz'], ['baz'])
    check(['/foo/bar/baz', '/foo/bar/quz'], ['baz', 'quz'])
    check(['/foo/bar/baz', '/foo/bar/quz'], ['', 'baz', 'quz'])
    check(['/foo/bar/baz', '/foo/bar/baz/quz'], ['baz', 'baz/quz'])

# Generated at 2022-06-24 03:12:47.396466
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each("", ("a", "b", "c"))) == ("a", "b", "c")
    assert tuple(join_each(".", ("a", "b", "c"))) == ("./a", "./b", "./c")
    assert tuple(join_each("/", ("a", "b", "c"))) == ("/a", "/b", "/c")
    assert tuple(join_each("/usr", ("a", "b", "c"))) == ("/usr/a", "/usr/b", "/usr/c")


# -*- coding: utf-8 -*-
#
# Copyright (c) 2010-2012 Peter Kropf. All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (

# Generated at 2022-06-24 03:12:52.605364
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["user", "flask"])) == [
        "/home/user",
        "/home/flask"
    ]

# Generated at 2022-06-24 03:13:01.116989
# Unit test for function join_each
def test_join_each():
    parent = '/Users/anjan/dev/nurse/test/parent'
    iterable = ['a', 'b', 'c']
    result = list(join_each(parent, iterable))
    expected = [
        '/Users/anjan/dev/nurse/test/parent/a',
        '/Users/anjan/dev/nurse/test/parent/b',
        '/Users/anjan/dev/nurse/test/parent/c'
    ]
    assert result == expected

# Generated at 2022-06-24 03:13:02.988647
# Unit test for function join_each
def test_join_each():
    parent_path = 'parent'
    children = ['child1', 'child2']
    joined = ['parent/child1', 'parent/child2']
    assert list(join_each(parent_path, children)) == joined



# Generated at 2022-06-24 03:13:09.437898
# Unit test for function join_each
def test_join_each():
    cwd = os.getcwd()
    iterable = ["foo", "bar", "baz"]
    result = join_each(cwd, iterable)
    assert list(result) == [
        os.path.join(cwd, "foo"),
        os.path.join(cwd, "bar"),
        os.path.join(cwd, "baz"),
    ]



# Generated at 2022-06-24 03:13:13.934340
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/var', ['log', 'lib', 'bin'])) == \
        ('/var/log', '/var/lib', '/var/bin')



# Generated at 2022-06-24 03:13:18.312271
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    child1 = "child1"
    child2 = "child2"
    child3 = "child3"
    iterable = [child1, child2, child3]
    expected = [parent + os.sep + child1,
                parent + os.sep + child2,
                parent + os.sep + child3]
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-24 03:13:24.081139
# Unit test for function join_each
def test_join_each():
    files = ["file1.txt", "file2.txt", "/etc/passwd", "../../etc/passwd"]
    assert not all(
        list(join_each("/home/my_user", files)) == list(map(lambda x: os.path.join("/home/my_user", x), files))
    )

# Generated at 2022-06-24 03:13:26.860310
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['me', 'you'])) == [
        '/home/me',
        '/home/you',
    ]



# Generated at 2022-06-24 03:13:32.258554
# Unit test for function join_each
def test_join_each():
    i = ['one', 'two', 'three']
    p = '/path/to/folder'
    expected = [os.path.join(p, f) for f in i]
    out = list(join_each(p, i))
    assert out == expected



# Generated at 2022-06-24 03:13:36.913051
# Unit test for function join_each
def test_join_each():
    parent = '/home/user'
    iterable = ['a', 'b', 'c', 'd']
    for p in join_each(parent, iterable):
        print(p)



# Generated at 2022-06-24 03:13:41.598062
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/a/b/c', ['x', 'y', 'z']))
    assert result == ['/a/b/c/x', '/a/b/c/y', '/a/b/c/z']



# Generated at 2022-06-24 03:13:44.967240
# Unit test for function join_each
def test_join_each():
    parent = '/some/dir'
    iterable = ['1.txt', '2.txt', '3.txt']
    assert list(join_each(parent, iterable)) == [os.path.join(parent, p) for p in iterable]

# Generated at 2022-06-24 03:13:47.073548
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ('aaa', 'bbb', 'ccc'))) == \
        ['./aaa', './bbb', './ccc']

