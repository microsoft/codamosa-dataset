

# Generated at 2022-06-24 03:03:50.286495
# Unit test for function join_each
def test_join_each():
    parent = "."
    iterable = ["documents", "bin"]
    assert list(join_each(parent, iterable)) == ["./documents", "./bin"]



# Generated at 2022-06-24 03:03:56.956325
# Unit test for function join_each
def test_join_each():
    import unittest
    from unittest import mock

    class JoinEachCase(unittest.TestCase):

        def test_windows(self):
            with mock.patch('os.path.sep', '\\'):
                self.assertEqual(
                    list(join_each('C:', ('foo', 'bar', 'baz'))),
                    ['C:\\foo', 'C:\\bar', 'C:\\baz'])
                self.assertEqual(list(join_each('C:\\', ('foo', 'bar', 'baz'))),
                                 ['C:\\foo', 'C:\\bar', 'C:\\baz'])

# Generated at 2022-06-24 03:03:58.671257
# Unit test for function join_each
def test_join_each():
    assert list(join_each('c:\\', ['test', 'dir'])) == [
        'c:\\test', 'c:\\dir'
    ]

# Generated at 2022-06-24 03:04:08.343440
# Unit test for function join_each
def test_join_each():
    current_dir = os.getcwd()
    assert list(join_each(current_dir, [".", "..", ".."])) == \
        [current_dir, os.path.abspath(os.path.join(current_dir, "..")),
         os.path.abspath(os.path.join(current_dir, "..", ".."))]

    from .._path import join_each
    assert list(join_each(current_dir, [".", "..", ".."])) == \
        [current_dir, os.path.abspath(os.path.join(current_dir, "..")),
         os.path.abspath(os.path.join(current_dir, "..", ".."))]



# Generated at 2022-06-24 03:04:10.580954
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('foo', ['a', 'b', 'c'])) == ('foo/a', 'foo/b', 'foo/c')



# Generated at 2022-06-24 03:04:12.340663
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-24 03:04:18.461719
# Unit test for function join_each
def test_join_each():
    parent = os.path.expanduser('~')
    assert list(join_each(parent, ['a', 'b', 'c'])) == [
        os.path.join(parent, 'a'),
        os.path.join(parent, 'b'),
        os.path.join(parent, 'c')
    ]

# Generated at 2022-06-24 03:04:27.747424
# Unit test for function join_each
def test_join_each():
    parent = 'one'
    iterable = ['two', 'three']
    i = 0
    for j in join_each(parent, iterable):
        assert j == os.path.join(parent, iterable[i])
        i += 1


# Test join_each
# parent = 'one'
# iterable = ['two', 'three']
# i = 0
# for j in join_each(parent, iterable):
#     print(j)


if __name__ == '__main__':
    import sys
    import os
    sys.path.insert(0, os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..')))
else:
    raise Exception(
        'This is a module and cannot be run by itself, try running tests.py')

# Generated at 2022-06-24 03:04:32.857234
# Unit test for function join_each
def test_join_each():
    parent = "C:/"
    iterable = ["a", "b"]
    result = ["C:/a", "C:/b"]
    assert (list(join_each(parent, iterable)) == result)


# Creates data list

# Generated at 2022-06-24 03:04:38.385605
# Unit test for function join_each
def test_join_each():
    l_of_str = ['a', 'b', 'c']
    assert list(join_each('', l_of_str)) == l_of_str
    assert list(join_each('x', l_of_str)) == ['x' + p for p in l_of_str]



# Generated at 2022-06-24 03:04:42.805084
# Unit test for function join_each
def test_join_each():
    parent = "/tmp"
    children = ['foo', 'bar', 'baz']

    result = list(join_each(parent, children))

    assert result == ["/tmp/foo", "/tmp/bar", "/tmp/baz"]



# Generated at 2022-06-24 03:04:45.167417
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == [
        '/tmp/a', '/tmp/b', '/tmp/c']



# Generated at 2022-06-24 03:04:49.521944
# Unit test for function join_each
def test_join_each():
    wd = os.getcwd()
    to_join = ["a", "b", "c"]
    result = list(join_each(wd, to_join))
    
    assert len(result) == 3
    assert os.path.join(wd, "a") in result
    assert os.path.join(wd, "b") in result
    assert os.path.join(wd, "c") in result

# Generated at 2022-06-24 03:04:52.487012
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/etc", ["passwd", "group"])) == ["/etc/passwd", "/etc/group"]



# Generated at 2022-06-24 03:04:57.152354
# Unit test for function join_each
def test_join_each():
    assert list(join_each('~/projects/tensorflow', ['a', 'b', 'c'])) == [
        '~/projects/tensorflow/a', '~/projects/tensorflow/b',
        '~/projects/tensorflow/c'
    ]


# Join a list of paths to a root path.

# Generated at 2022-06-24 03:04:59.773118
# Unit test for function join_each
def test_join_each():
    print(list(join_each('a/b/c', ['d', 'e', 'f'])))

# Generated at 2022-06-24 03:05:02.038263
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/c', ['d', 'e'])) == ['/a/b/c/d', '/a/b/c/e']



# Generated at 2022-06-24 03:05:07.780857
# Unit test for function join_each
def test_join_each():
    test_strs = ['abc', 'abcd', 'abcde']
    joined_strs = join_each('/home/timi/', test_strs)
    assert len(list(joined_strs)) == len(test_strs)



# Generated at 2022-06-24 03:05:16.265980
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['a', 'b'])) == ['.' + os.sep + 'a', '.' + os.sep + 'b']
    assert list(join_each('b', ['a', 'b'])) == ['b' + os.sep + 'a', 'b' + os.sep + 'b']
    assert list(join_each('b', ['a', 'b'])) == ['b' + os.sep + 'a', 'b' + os.sep + 'b']
    assert list(join_each('a', ['b', 'c'])) == ['a' + os.sep + 'b', 'a' + os.sep + 'c']



# Generated at 2022-06-24 03:05:20.168543
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', ['passwd', 'hosts', 'init'])) == [
        '/etc/passwd', '/etc/hosts', '/etc/init']
    assert tuple(join_each('/proc', ('1', '2', '3'))) == (
        '/proc/1', '/proc/2', '/proc/3')



# Generated at 2022-06-24 03:05:23.620610
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/var/lib', ['log', 'run', 'tmp'])) == [
        '/var/lib/log', '/var/lib/run', '/var/lib/tmp']



# Generated at 2022-06-24 03:05:25.594854
# Unit test for function join_each
def test_join_each():
    parent = '/foo/bar'
    iterable = ('home', 'guest')
    result = list(join_each(parent, iterable))
    assert result == ['/foo/bar/home', '/foo/bar/guest']



# Generated at 2022-06-24 03:05:31.074398
# Unit test for function join_each

# Generated at 2022-06-24 03:05:32.898124
# Unit test for function join_each
def test_join_each():
    assert [f for f in join_each('/tmp', ['/x', '/y'])] == ['/tmp/x', '/tmp/y']



# Generated at 2022-06-24 03:05:37.091378
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['matt', 'doug'])) == [
        '/home/matt', '/home/doug']



# Generated at 2022-06-24 03:05:39.752826
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["usr", "bin", "sh"])) == [
        "/usr",
        "/bin",
        "/sh",
    ]

# Generated at 2022-06-24 03:05:41.934613
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    parent = '/'
    expected = ['/a', '/b', '/c']
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-24 03:05:48.727257
# Unit test for function join_each
def test_join_each():
    # case 1
    parent = "D:\\"
    iterable = ["is", "my", "documents"]
    result = join_each(parent, iterable)
    assert next(result) == "D:\\is"
    assert next(result) == "D:\\my"
    assert next(result) == "D:\\documents"
    try:
        next(result)
    except StopIteration:
        assert True

# Generated at 2022-06-24 03:05:52.169671
# Unit test for function join_each
def test_join_each():
    p = os.path.join(os.path.dirname(__file__), 'data')
    assert list(join_each(p, ['dir1', 'dir2', 'dir3'])) == [os.path.join(p, d) for d in ['dir1', 'dir2', 'dir3']]

# Generated at 2022-06-24 03:05:54.750862
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/etc", ["foo.txt", "bar.zip"])) == [
        "/etc/foo.txt",
        "/etc/bar.zip",
    ]



# Generated at 2022-06-24 03:06:02.179065
# Unit test for function join_each
def test_join_each():
    assert [x for x in join_each('', [])] == []
    assert [x for x in join_each('/', ['/test_path'])] == ['/test_path']
    assert [x for x in join_each('/', ['/test_pa', 'th/'])] == ['/test_pa/th/']
    assert [x for x in join_each('/', ['/test_pa', 'th/', '/test_path'])] == ['/test_pa/th/', '/test_path']



# Generated at 2022-06-24 03:06:05.080336
# Unit test for function join_each
def test_join_each():
    p = '/foo/bar'
    iterable = ['baz', 'quux']
    expected = ['/foo/bar/baz', '/foo/bar/quux']
    result = list(join_each(p, iterable))
    assert result == expected



# Generated at 2022-06-24 03:06:10.452149
# Unit test for function join_each
def test_join_each():
    test_pairs = [
        ('/Users', ['x', 'y', 'z']),
        ('/Users', []),
        ('/Users', ['x', 'y/z', 'a/b/c']),
    ]
    for pair in test_pairs:
        result = join_each(pair[0], pair[1])
        expected = [os.path.join(pair[0], p) for p in pair[1]]
        assert result == expected

# Generated at 2022-06-24 03:06:11.602337
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/', ('a', 'b', 'c'))) == ('/a', '/b', '/c')

# Generated at 2022-06-24 03:06:15.252445
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['bar', 'baz'])) == ['/foo/bar', '/foo/baz']

# Generated at 2022-06-24 03:06:19.598868
# Unit test for function join_each
def test_join_each():
    expected = [
        'test/test_file.py',
        'test/test_file2.py',
        'test/test_file3.py',
    ]
    parent_dir = 'test'
    children = [
        'test_file.py',
        'test_file2.py',
        'test_file3.py',
    ]
    assert list(join_each(parent_dir, children)) == expected



# Generated at 2022-06-24 03:06:24.850500
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/zoo', ['x', 'y'])) == ['/zoo/x', '/zoo/y']


list_to_join = ['hello', 'world', '!', '!']



# Generated at 2022-06-24 03:06:27.257718
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["usr", "bin"])) == ["/usr", "/bin"]



# Generated at 2022-06-24 03:06:33.088480
# Unit test for function join_each
def test_join_each():
    a = ("a", "b", "c")
    b = ("d", "e", "f")
    assert list(join_each("", b)) == ["d", "e", "f"]
    assert list(join_each("t", a)) == ["t/a", "t/b", "t/c"]
    assert list(join_each("/", a)) == ["/a", "/b", "/c"]


# Folder Scanner

# Generated at 2022-06-24 03:06:35.648452
# Unit test for function join_each
def test_join_each():
    lst = ['a', 'b', 'c']
    assert list(join_each('/', lst)) == ['/a', '/b', '/c']

# Generated at 2022-06-24 03:06:39.373729
# Unit test for function join_each
def test_join_each():
    for a, b in ((['a', 'b'], ['a', 'b', 'c']),
                 (('a', 'b'), ('a', 'b', 'c'))):
        assert list(join_each('c', a)) == b

# Generated at 2022-06-24 03:06:43.306222
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr/bin", ("/", "/", "/"))) == ["/usr/bin/", "/usr/bin/", "/usr/bin/"]
    assert list(join_each("/usr/bin", ("ls", "cat", "echo"))) == ["/usr/bin/ls", "/usr/bin/cat", "/usr/bin/echo"]

# Generated at 2022-06-24 03:06:48.317447
# Unit test for function join_each
def test_join_each():
    iterable = ["f1.txt", "f2.txt", "f3.txt"]
    parent = '/home/username/Desktop'
    result = ['/home/username/Desktop/f1.txt',
              '/home/username/Desktop/f2.txt',
              '/home/username/Desktop/f3.txt']
    assert list(join_each(parent, iterable)) == result



# Generated at 2022-06-24 03:06:50.700671
# Unit test for function join_each
def test_join_each():
    assert list(join_each('user', ['a', 'b', 'c'])) == [
        'user/a', 'user/b', 'user/c']


# Solution 1

# Generated at 2022-06-24 03:06:52.312593
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr", ["local", "bin"])) == [
        "/usr/local",
        "/usr/bin",
    ]

# Generated at 2022-06-24 03:06:54.310040
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["foo", "bar", "baz"])) == [
        "/home/foo",
        "/home/bar",
        "/home/baz",
    ]



# Generated at 2022-06-24 03:06:58.862871
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/p1', ['v1', 'v2'])) == ['/p1/v1', '/p1/v2']
    assert list(join_each('/p1/p2', ['v1', 'v2'])) == ['/p1/p2/v1', '/p1/p2/v2']

# Generated at 2022-06-24 03:07:03.090661
# Unit test for function join_each
def test_join_each():
    assert "foo/bar/baz" == next(join_each("foo", ["bar", "baz"]))
    assert "foo/bar/baz" == next(join_each("foo", ["bar", "baz"]))

    try:
        next(join_each("foo", ["bar"]))
        assert False
    except StopIteration:
        pass

# Generated at 2022-06-24 03:07:05.767150
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == [
        '/a',
        '/b',
        '/c'
    ]



# Generated at 2022-06-24 03:07:07.266779
# Unit test for function join_each
def test_join_each():
    assert ('/a/b' == next(join_each('/', ['a', 'b'])))



# Generated at 2022-06-24 03:07:09.290041
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == [
        '/tmp/a', '/tmp/b', '/tmp/c']



# Generated at 2022-06-24 03:07:13.469598
# Unit test for function join_each
def test_join_each():
    parent = "/home/gabe"
    iterable = ["img1.jpg", "img2.jpg", "img3.jpg"]
    expected = [
        "/home/gabe/img1.jpg",
        "/home/gabe/img2.jpg",
        "/home/gabe/img3.jpg",
    ]
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:07:16.667680
# Unit test for function join_each
def test_join_each():
    parent = '/'
    iterables = ['a', 'b', 'c']
    actual_result = join_each(parent, iterables)
    expected_result = ['/a', '/b', '/c']
    assert actual_result == expected_result, \
        f'Expected {expected_result}, but got {actual_result}'
    print(f'Test for join_each function passed!')


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:07:22.724163
# Unit test for function join_each
def test_join_each():
    join_each_test_parent = 'parent'
    join_each_test_iterable = ['i1', 'i2', 'i3']
    join_each_test_expected = [os.path.join(join_each_test_parent, it) for it in join_each_test_iterable]

    assert list(join_each(join_each_test_parent, join_each_test_iterable)) == join_each_test_expected

# Generated at 2022-06-24 03:07:24.355207
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:07:27.280161
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ['c', 'd'])) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-24 03:07:30.557917
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', 'bar/foo')) == ['/bar/foo']
    assert list(join_each('bar', ['foo', 'baz'])) == ['bar/foo', 'bar/baz']
    assert list(join_each('bar', [])) == []



# Generated at 2022-06-24 03:07:37.296084
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["home", "chris"])) == \
           ["/home", "/chris"]
    assert list(join_each("/", ["", "home", "chris"])) == \
           ["//home", "//chris"]

# Generated at 2022-06-24 03:07:44.062465
# Unit test for function join_each
def test_join_each():
    parent_dir = "/tmp"
    iter = iter(["1", "2/3/4", "5/6/7/8/9"])
    assert [os.path.join(parent_dir, p) for p in iter] == list(join_each(parent_dir, iter))



# Generated at 2022-06-24 03:07:46.566732
# Unit test for function join_each
def test_join_each():
    for p in join_each('parent', ['a', 'b', 'c']):
        assert p.startswith('parent'), p



# Generated at 2022-06-24 03:07:48.653304
# Unit test for function join_each
def test_join_each():
    assert list(join_each('home/user', ['document', 'program'])) == ['home/user/document', 'home/user/program']



# Generated at 2022-06-24 03:07:54.762527
# Unit test for function join_each
def test_join_each():
    d = '/tmp'
    data = ['foo', 'bar', 'baz']
    result = list(join_each(d, data))
    expected = [os.path.join(d, p) for p in data]
    assert result == expected



# Generated at 2022-06-24 03:07:58.363723
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('abc/def', ('a', 'b', 'c'))) == (
        'abc/def/a',
        'abc/def/b',
        'abc/def/c',
    )



# Generated at 2022-06-24 03:08:03.675457
# Unit test for function join_each
def test_join_each():
    parent = r"C:/Projects/grit/src"
    assert list(join_each(parent, ["test.py"])) == [r"C:/Projects/grit/src/test.py"]
    assert list(join_each(parent, ["test.py", "test2.py"])) == [r"C:/Projects/grit/src/test.py", r"C:/Projects/grit/src/test2.py"]

# Generated at 2022-06-24 03:08:05.646798
# Unit test for function join_each
def test_join_each():
    assert [*join_each('a', 'bcd')] == ['a/b', 'a/c', 'a/d']



# Generated at 2022-06-24 03:08:08.500592
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["test1", "test2"])) == [
        "/test1",
        "/test2",
    ]
    assert list(join_each("/test/dir", ["test1", "test2"])) == [
        "/test/dir/test1",
        "/test/dir/test2",
    ]

# Generated at 2022-06-24 03:08:09.895149
# Unit test for function join_each
def test_join_each():
    assert 'a' == next(join_each('x', ['a']))



# Generated at 2022-06-24 03:08:12.089400
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    joined = ['p/a', 'p/b', 'p/c']
    assert list(join_each('p', iterable)) == joined



# Generated at 2022-06-24 03:08:14.728274
# Unit test for function join_each
def test_join_each():
    assert [*join_each('a', ['/p', 'v/f'])] == [
        os.path.join('a', '/p'), os.path.join('a', 'v/f')
    ]

# Generated at 2022-06-24 03:08:19.045070
# Unit test for function join_each
def test_join_each():
    iter1 = join_each('/home/szabo', ['test1', 'test2', 'test3'])
    iter2 = join_each('/home/szabo', iter1)
    for i in iter2:
        print(i)

# Generated at 2022-06-24 03:08:21.074368
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ('b', 'c'))) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:08:26.243842
# Unit test for function join_each
def test_join_each():
    cases = [
        (("/tmp/a/b", ["foo", "bar", "baz"]), ["/tmp/a/b/foo", "/tmp/a/b/bar", "/tmp/a/b/baz"]),
        (("/tmp/a/b", []), []),
    ]
    for (example, expected) in cases:
        result = list(join_each(*example))
        assert result == expected, "Failed: join_each(*{}) == {}, expected {}".format(example, result, expected)



# Generated at 2022-06-24 03:08:27.598658
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', ['passwd', 'shadow'])) == [
        '/etc/passwd', '/etc/shadow']

# Generated at 2022-06-24 03:08:29.881826
# Unit test for function join_each
def test_join_each():
    assert list(join_each('x', ['y', 'z'])) == ['x/y', 'x/z']



# Generated at 2022-06-24 03:08:31.925480
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:08:36.088933
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['etc', 'bin'])) == ['/etc', '/bin']
    assert list(join_each('home/', ['etc', 'bin'])) == ['home/etc', 'home/bin']
    assert list(join_each('//home/', ['etc', 'bin'])) == ['//home/etc', '//home/bin']

# Generated at 2022-06-24 03:08:41.318503
# Unit test for function join_each
def test_join_each():
    parent = "abc"
    iterable = [1, 2, 3]

    expected = ["abc/1", "abc/2", "abc/3"]
    actual = join_each(parent, iterable)
    assert expected == actual


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-24 03:08:43.875748
# Unit test for function join_each
def test_join_each():
    parent = '/hello'
    iterable = ['world', 'from', 'python']
    ret = ['/hello/world', '/hello/from', '/hello/python']
    assert list(join_each(parent, iterable)) == ret



# Generated at 2022-06-24 03:08:48.895313
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']
    assert list(join_each('foo', [])) == []



# Generated at 2022-06-24 03:08:51.799197
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/abc', ['c', 'd', 'e'])) == ['/abc/c', '/abc/d', '/abc/e']



# Generated at 2022-06-24 03:08:59.219946
# Unit test for function join_each
def test_join_each():
    # By default other tests create a temp directory, which does not get
    # cleaned up
    os.chdir(tempfile.gettempdir())

    # Create a file in a directory to use for testing
    os.makedirs('testdir', exist_ok=True)
    with open('testdir/file', 'w') as f:
        f.write('foobar')

    # Test the function
    tmp = []
    for p in join_each('testdir', ['file', 'missing']):
        tmp.append(p)
        assert os.path.exists(p)
    assert 'testdir/file' in tmp
    assert 'testdir/missing' not in tmp



# Generated at 2022-06-24 03:09:00.280439
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    iterable = ('user', 'tmp')
    assert tuple(join_each(parent, iterable)) == ('/home/user', '/home/tmp')



# Generated at 2022-06-24 03:09:04.255824
# Unit test for function join_each
def test_join_each():
    path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    expected_paths = [
        os.path.join(path, 'src'), os.path.join(path, 'test'),
        os.path.join(path, 'run.py')
    ]

    result = join_each(path, ['src', 'test', 'run.py'])
    for each in result:
        assert each in expected_paths
    for each in expected_paths:
        assert each in result



# Generated at 2022-06-24 03:09:07.643485
# Unit test for function join_each
def test_join_each():
    parent = '/'
    assert list(join_each(parent, [])) == []
    assert list(join_each(parent, ['a'])) == ['/a']
    assert list(join_each(parent, ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-24 03:09:12.018294
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', 'b')) == ['a/b']
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']


# Helper function to check is path exists

# Generated at 2022-06-24 03:09:14.669302
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]



# Generated at 2022-06-24 03:09:18.270657
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b'])) == ['/tmp/a', '/tmp/b']



# Generated at 2022-06-24 03:09:24.485323
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['foo', 'bar', 'baz'])) == [
        '/tmp/foo',
        '/tmp/bar',
        '/tmp/baz',
    ]

# Generated at 2022-06-24 03:09:26.207438
# Unit test for function join_each

# Generated at 2022-06-24 03:09:30.337344
# Unit test for function join_each
def test_join_each():
    assert list(join_each('tmp', ['a', 'b'])) == ['tmp/a', 'tmp/b']



# Generated at 2022-06-24 03:09:32.188433
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['bin', 'local'])) == ['/usr/bin', '/usr/local']



# Generated at 2022-06-24 03:09:34.653069
# Unit test for function join_each
def test_join_each():
    expected = [os.path.join('.', p) for p in ['a', 'b']]
    actual = list(join_each('.', ['a', 'b']))
    assert expected == actual



# Generated at 2022-06-24 03:09:38.439830
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['child1', 'child2', 'child3']
    expected = [os.path.join(parent, 'child1'),
                os.path.join(parent, 'child2'),
                os.path.join(parent, 'child3')]

    actual = list(join_each(parent, iterable))

    assert actual == expected

# Generated at 2022-06-24 03:09:42.782266
# Unit test for function join_each
def test_join_each():
    parent = '/home/username'
    iterable = ['laptop', 'phone']
    path_list = [os.path.join(parent, elem) for elem in iterable]
    assert path_list == list(join_each(parent, iterable))

# Generated at 2022-06-24 03:09:48.870639
# Unit test for function join_each
def test_join_each():
    # Test one-level directory
    join_iter = join_each('test', ['one', 'two', 'three'])
    lst = [name for name in join_iter]
    assert lst == ['test/one', 'test/two', 'test/three']

    # Test two-level directory
    join_iter = join_each('test', ['one/two', 'three/four'])
    lst = [name for name in join_iter]
    assert lst == ['test/one/two', 'test/three/four']

# Generated at 2022-06-24 03:09:57.726746
# Unit test for function join_each
def test_join_each():
    assert ['/home/joe/foo', '/home/joe/bar'] == list(join_each('/home/joe', ['foo', 'bar']))
    assert ['foo', 'bar'] == list(join_each('', ['foo', 'bar']))
    assert [] == list(join_each('', []))
    assert [] == list(join_each('/home/joe', []))
    assert ['/home/joe/foo'] == list(join_each('/home/joe', ['foo']))



# Generated at 2022-06-24 03:10:03.379949
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/jojo", ("jojo.txt", "jojo2.txt"))) == [
        "/home/jojo/jojo.txt",
        "/home/jojo/jojo2.txt",
    ]



# Generated at 2022-06-24 03:10:07.083988
# Unit test for function join_each
def test_join_each():

    l1 = ["a", "b", "c", "d"]
    l2 = ["e", "f", "g", "h"]

    # Create a generator to generate the parent, direct children for each parent
    for parent, children in zip(l1, l2):
        # print(parent, children)
        print(list(join_each(parent, children)))

# Generated at 2022-06-24 03:10:09.195089
# Unit test for function join_each
def test_join_each():
    path = '/home/'
    result = list(join_each(path, ['user1', 'user2', 'user3']))
    expected = [f"{path}user1", f"{path}user2", f"{path}user3"]
    assert result == expected


# Part 2

# Generated at 2022-06-24 03:10:15.013097
# Unit test for function join_each
def test_join_each():
    cases = [(
        ['/', '/', '/', '/'],
        ['/etc/', '/etc', '/etc/']
    ), (
        ['/', '/', '/'],
        ['/etc/', '/etc', '/etc/', '/etc']
    )]
    for base, pathes in cases:
        assert list(join_each(base, pathes)) == [b+p for b, p in zip(base, pathes)]



# Generated at 2022-06-24 03:10:17.727397
# Unit test for function join_each
def test_join_each():
    paths = list(join_each('/home', ['Documents', 'Code']))
    assert paths == ['/home/Documents', '/home/Code']



# Generated at 2022-06-24 03:10:24.864669
# Unit test for function join_each
def test_join_each():
    """
    Test case 1.
    """
    parent = os.path.abspath('.')
    iterable = [u'child1', u'child2', u'child3']
    expected = list(map(lambda p: os.path.join(parent, p), iterable))
    actual = list(join_each(parent, iterable))
    assert expected == actual



# Generated at 2022-06-24 03:10:29.292291
# Unit test for function join_each
def test_join_each():
    assert list(join_each("./images", ["image1.jpg", "image2.png"])) == [
        "./images/image1.jpg",
        "./images/image2.png",
    ]



# Generated at 2022-06-24 03:10:37.461995
# Unit test for function join_each
def test_join_each():
    # does it work for a single item?
    g = join_each('/', ['home'])
    assert next(g) == '/home'
    with pytest.raises(StopIteration):
        next(g)

    # it should work for a single item in an iterator
    g = join_each('/', iter(['home']))
    assert next(g) == '/home'
    with pytest.raises(StopIteration):
        next(g)

    # it should work for multiple items
    g = join_each('/', ['home', 'users', 'test'])
    assert list(g) == ['/home', '/users', '/test']



# Generated at 2022-06-24 03:10:40.262398
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['Users', 'Shared'])) == ['/Users', '/Shared']
    assert list(join_each('/home/me', ['name', 'age'])) == [
        '/home/me/name',
        '/home/me/age'
    ]



# Generated at 2022-06-24 03:10:42.537128
# Unit test for function join_each
def test_join_each():
    path = '/home/biopython/'
    files = ['test1.fasta', 'test2.fasta']
    res = join_each(path, files)
    for file in res:
        assert file == os.path.join(path, file)



# Generated at 2022-06-24 03:10:57.249369
# Unit test for function join_each
def test_join_each():
    parent = "/p/a/r/e/n/t"
    children = ["c1", "c2", "c3"]

    expected = ["/p/a/r/e/n/t/c1", "/p/a/r/e/n/t/c2", "/p/a/r/e/n/t/c3"]

    assert list(join_each(parent, children)) == expected

# Generated at 2022-06-24 03:11:00.190131
# Unit test for function join_each
def test_join_each():
    parent = "/usr"
    iterable = ["bin", "lib", "python", "env"]
    result = list(join_each(parent, iterable))
    assert result == [
        "/usr/bin",
        "/usr/lib",
        "/usr/python",
        "/usr/env",
    ]

# Generated at 2022-06-24 03:11:01.846805
# Unit test for function join_each
def test_join_each():
    assert list(join_each(
        '/a/b',
        ['/c', '/d']
    )) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-24 03:11:05.297815
# Unit test for function join_each
def test_join_each():
    input = ['/home', ['foo', 'bar']]
    expected = ['/home/foo', '/home/bar']
    assert list(join_each(*input)) == expected



# Generated at 2022-06-24 03:11:13.328987
# Unit test for function join_each
def test_join_each():
    print("Running unit test for function join_each")

    parent = os.path.join('home', 'user', 'name')
    child = ['desktop', 'documents', 'downloads', 'music']

    correct_result = [
        os.path.join(parent, 'desktop'), os.path.join(parent, 'documents'),
        os.path.join(parent, 'downloads'), os.path.join(parent, 'music')
    ]

    assert list(join_each(parent, child)) == correct_result



# Generated at 2022-06-24 03:11:15.173961
# Unit test for function join_each
def test_join_each():
    assert(list(join_each("/usr", ["bin", "local"])) ==
           ["/usr/bin", "/usr/local"])

# Generated at 2022-06-24 03:11:17.182455
# Unit test for function join_each
def test_join_each():
    assert list(join_each('x', ['a', 'b', 'c'])) == ['x/a', 'x/b', 'x/c']
    for p, q in join_each('x', ['a', 'b', 'c']):
        assert isinstance(p, str)
        assert isinstance(q, str)



# Generated at 2022-06-24 03:11:19.569578
# Unit test for function join_each
def test_join_each():
    parent = "/Users/User1/tmp"
    iterable = ["file1.txt", "file2.txt", "file3.txt"]

    expected = ["/Users/User1/tmp/file1.txt", "/Users/User1/tmp/file2.txt", "/Users/User1/tmp/file3.txt"]

    actual = list(join_each(parent, iterable))
    assert actual == expected



# Generated at 2022-06-24 03:11:26.929538
# Unit test for function join_each
def test_join_each():
    parent = '~/Desktop/test'
    iterable = ['file1', 'file2', 'file3']
    expected = ['~/Desktop/test/file1', '~/Desktop/test/file2', '~/Desktop/test/file3']
    actual = list(join_each(parent, iterable))
    assert actual == expected

# Usage example
list(join_each('~/Desktop/test', ['file1', 'file2', 'file3']))

# Generated at 2022-06-24 03:11:30.495777
# Unit test for function join_each
def test_join_each():
    assert list(join_each("dir", ["a", "b"])) == ["dir/a", "dir/b"]



# Generated at 2022-06-24 03:11:33.781855
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz', 'quux'])) == ['foo/bar', 'foo/baz', 'foo/quux']

# Generated at 2022-06-24 03:11:38.563148
# Unit test for function join_each
def test_join_each():
    parent = '/home/user/'
    parts = ['Documents', 'Downloads']
    assert list(join_each(parent, parts)) == ['/home/user/Documents',
                                              '/home/user/Downloads']



# Generated at 2022-06-24 03:11:45.882518
# Unit test for function join_each
def test_join_each():
    parent = '/home/logan/'
    iterable = ['Documents', 'Pictures', 'Work']
    paths_as_list = join_each(parent, iterable)
    for i in paths_as_list:
        assert isinstance(i, str), 'Value is not a string'


if __name__ == '__main__':
    test_join_each()
    print('All join_each tests passed.')


# Generated at 2022-06-24 03:11:49.427638
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['a', 'b', 'c']

    assert list(join_each(parent, iterable)) == [
        'parent/a', 'parent/b', 'parent/c',
    ]



# Generated at 2022-06-24 03:11:54.222182
# Unit test for function join_each
def test_join_each():
    p = '/home/foo'
    names = ['bar', 'baz']
    expected_paths = ['/home/foo/bar', '/home/foo/baz']
    paths = list(join_each(p, names))
    assert paths == expected_paths



# Generated at 2022-06-24 03:11:57.495000
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['name', 'Documents', 'Desktop'])) == ['/home/name', '/home/Documents', '/home/Desktop']

# Generated at 2022-06-24 03:12:00.277754
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b', 'c'])) == [
        'parent/a',
        'parent/b',
        'parent/c'
    ]



# Generated at 2022-06-24 03:12:02.446360
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a', [])) == []



# Generated at 2022-06-24 03:12:05.035676
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a", "b", "c"]



# Generated at 2022-06-24 03:12:07.261580
# Unit test for function join_each
def test_join_each():
    assert ["tmp/staging", "tmp/data"] == list(join_each("tmp", ["staging", "data"]))

# Generated at 2022-06-24 03:12:09.695839
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/path/to', ['dir', 'file.txt'])) == ['/path/to/dir', '/path/to/file.txt']



# Generated at 2022-06-24 03:12:15.891897
# Unit test for function join_each
def test_join_each():
    parent = 'A'
    iterable = ['B', 'C', 'D']
    result = list(join_each(parent, iterable))
    assert result == ['A/B', 'A/C', 'A/D']



# Generated at 2022-06-24 03:12:23.723065
# Unit test for function join_each
def test_join_each():
    paths = ['/a/b/c', '/a/d/c', '/a/e/c']
    new_paths = join_each('/a', ['b/c', 'd/c', 'e/c'])
    assert paths == list(new_paths)


if __name__ == "__main__":
    print(list(join_each('/a/b/c', ['d', 'e'])))

# Generated at 2022-06-24 03:12:27.019069
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:12:31.107833
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ('c', 'd', 'e'))) == ['/a/b/c', '/a/b/d', '/a/b/e']



# Generated at 2022-06-24 03:12:37.702237
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/jsquyres", ["fred", "zippy", "bob"])) == [
        "/home/jsquyres/fred",
        "/home/jsquyres/zippy",
        "/home/jsquyres/bob",
    ]



# Generated at 2022-06-24 03:12:42.600299
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child1', 'child2', 'child3'])) == ['parent/child1', 'parent/child2',
                                                                         'parent/child3']

# Generated at 2022-06-24 03:12:43.951876
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']

# Generated at 2022-06-24 03:12:45.819034
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr/bin", [".ssh", "passwd"])) == [
        "/usr/bin/.ssh",
        "/usr/bin/passwd",
    ]

# Generated at 2022-06-24 03:12:51.898559
# Unit test for function join_each
def test_join_each():
    iterable = ['foo', 'bar', 'baz', 'qux']
    actual = join_each('.', iterable)
    expected = ['./foo', './bar', './baz', './qux']
    assert list(actual) == expected


if __name__ == '__main__':
    test_join_each()

    watch_dir = '.'
    # watch_dir = os.path.expanduser('~/Desktop')

    root_filenames = set(os.listdir(watch_dir))
    files = {
        # file list on a specific day or time
        '2017-09-15': set(os.listdir(watch_dir)),
        '2017-09-16': set(join_each(watch_dir, ('foo', 'bar', 'baz'))),
    }

# Generated at 2022-06-24 03:12:55.230735
# Unit test for function join_each
def test_join_each():
    parts = ['/', 'usr', 'lib']
    assert ('/usr/lib/' == os.path.join('/', *parts))

    assert ('/usr/lib/' == os.path.join('/', *join_each('/', parts)))



# Generated at 2022-06-24 03:12:58.878966
# Unit test for function join_each
def test_join_each():
    parent = '/usr/local/'
    s = ['bin', 'lib', 'libexec', 'sbin']
    assert list(join_each(parent, s)) == [
        '/usr/local/bin',
        '/usr/local/lib',
        '/usr/local/libexec',
        '/usr/local/sbin'
    ]

# Generated at 2022-06-24 03:13:01.451476
# Unit test for function join_each
def test_join_each():
    parent = "/etc"
    iterable = ("passwd", "group")
    it = join_each(parent, iterable)
    assert it.next() == "/etc/passwd"
    assert it.next() == "/etc/group"



# Generated at 2022-06-24 03:13:04.419585
# Unit test for function join_each
def test_join_each():
    assert ["./data/file.txt", "./data/b/file.txt"] == list(
        join_each("./data", ["file.txt", "b/file.txt"])
    )

# Generated at 2022-06-24 03:13:09.518234
# Unit test for function join_each
def test_join_each():
    assert list(join_each('root', ['/a', 'b', 'c'])) == ['/a', '/root/b', '/root/c']
    assert tuple(join_each('root', ('/a', 'b', 'c'))) == ('/a', '/root/b', '/root/c')

# Generated at 2022-06-24 03:13:13.933716
# Unit test for function join_each
def test_join_each():
    assert join_each("/opt", ["a", "b", "c"]) == ["/opt/a", "/opt/b", "/opt/c"]



# Generated at 2022-06-24 03:13:15.521103
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']

# Generated at 2022-06-24 03:13:17.356584
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/some/parent', ['a', 'b'])) == [
        '/some/parent/a',
        '/some/parent/b',
    ]

# Generated at 2022-06-24 03:13:18.890567
# Unit test for function join_each
def test_join_each():
    assert list(join_each("p", ["a", "b"])) == ["p/a", "p/b"]



# Generated at 2022-06-24 03:13:24.381489
# Unit test for function join_each
def test_join_each():
    import pytest

    test_files = ['1.txt', '2.txt', '3.txt']
    test_dir = "testdir"
    res = list(join_each(test_dir, test_files))
    assert res == ['testdir\\1.txt', 'testdir\\2.txt', 'testdir\\3.txt']



# Generated at 2022-06-24 03:13:33.188877
# Unit test for function join_each
def test_join_each():
    # parent is list
    parent = ['/home/gyz/', '/usr/local/']
    iterable = ['project1', 'project2', 'project3']
    assert set(join_each(parent, iterable)) == \
        set(['/home/gyz/project1', '/home/gyz/project2', '/home/gyz/project3',
             '/usr/local/project1', '/usr/local/project2', '/usr/local/project3'])

    # parent is tuple
    parent = '/usr/local', '/home/gyz'
    iterable = 'project1', 'project2', 'project3'

# Generated at 2022-06-24 03:13:39.181006
# Unit test for function join_each
def test_join_each():
    parent = 'file://c:/users/mathias/'
    iterable = ['Desktop', 'Downloads', 'Documents']
    expected = ['file://c:/users/mathias/Desktop',
                'file://c:/users/mathias/Downloads',
                'file://c:/users/mathias/Documents']
    actual = list(join_each(parent, iterable))
    assert actual == expected

# Generated at 2022-06-24 03:13:41.113686
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['user1', 'user2'])) == ['/home/user1', '/home/user2']

# Generated at 2022-06-24 03:13:42.707757
# Unit test for function join_each
def test_join_each():
    assert join_each('parent', ['a', 'b']) == ['parent/a', 'parent/b']



# Generated at 2022-06-24 03:13:47.224408
# Unit test for function join_each
def test_join_each():
    expected_result = ("/etc/apache/file1.txt", "/etc/apache/file2.txt",
                       "/etc/apache/file3.txt")
    files = ("file1.txt", "file2.txt", "file3.txt")
    directory = "/etc/apache"
    result = join_each(directory, files)
    assert result == expected_result

# Generated at 2022-06-24 03:13:49.701683
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['a', 'b', 'c'])) == ['foo/a', 'foo/b', 'foo/c']

