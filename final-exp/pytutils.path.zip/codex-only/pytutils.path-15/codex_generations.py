

# Generated at 2022-06-24 03:03:54.966482
# Unit test for function join_each
def test_join_each():

    # Both of these should yield the same,
    # i.e., all elements should be absolute,
    # i.e., start with '/'

    p1 = '/home'
    p2 = '/var'

    res1 = list(join_each(p1, [p2, p1]))
    assert res1 == ['/home/var', '/home/home']

    res2 = list(join_each(p2, [p1, p2]))
    assert res2 == ['/var/home', '/var/var']



# Generated at 2022-06-24 03:03:59.582380
# Unit test for function join_each
def test_join_each():
    assert list(join_each('x', ['y'])) == ['x/y']
    assert list(join_each('x/', ['y', 'z'])) == ['x/y', 'x/z']
    assert list(join_each('', ['y', 'z'])) == ['y', 'z']


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])

# Generated at 2022-06-24 03:04:10.513433
# Unit test for function join_each

# Generated at 2022-06-24 03:04:12.709947
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child1', 'child2', 'child3'])) == [
        'parent/child1', 'parent/child2', 'parent/child3'
    ]

# Generated at 2022-06-24 03:04:18.502576
# Unit test for function join_each
def test_join_each():
    p = 'hello'
    l = ['stary', 'sky']
    result = iter([os.path.join(p, i) for i in l])
    assert result == join_each(p, l)


# Add all files in each directory supplied in iterable to a set
# and return the set.

# Generated at 2022-06-24 03:04:24.631472
# Unit test for function join_each
def test_join_each():
    assert list(join_each('here', ['a', 'b'])) == ['here/a', 'here/b']
    assert list(join_each('here', [])) == []
    assert list(join_each('here', ['.'])) == ['here/.']



# Generated at 2022-06-24 03:04:27.559532
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', ['hosts', 'passwd'])) == ['/etc/hosts', '/etc/passwd']



# Generated at 2022-06-24 03:04:34.462485
# Unit test for function join_each
def test_join_each():
    test_cases = [
        ([], '', []),
        ([], 'a', []),
        (['a'], '', ['a']),
        (['a'], 'b', ['ab']),
        (['a', 'b', 'c'], '', ['a', 'b', 'c']),
    ]

    for iterable, path, expected_result in test_cases:
        result = list(join_each(path, iterable))
        assert result == expected_result



# Generated at 2022-06-24 03:04:36.932951
# Unit test for function join_each
def test_join_each():
    actual = list(join_each('/', ['a', 'b']))
    expected = ['/a', '/b']
    assert actual == expected

# Generated at 2022-06-24 03:04:39.609502
# Unit test for function join_each
def test_join_each():
    path = join_each('path', ['a', 'b', 'c'])

    assert next(path) == os.path.join('path', 'a')
    assert next(path) == os.path.join('path', 'b')



# Generated at 2022-06-24 03:04:44.990835
# Unit test for function join_each
def test_join_each():
    p = "/some/path"

# Generated at 2022-06-24 03:04:48.518716
# Unit test for function join_each
def test_join_each():
    parent = '/root/'
    path = 'path'
    path_list = ['foo', 'bar', 'baz']

    assert tuple(join_each(path, path_list)) == \
        tuple(os.path.join(path, p) for p in path_list)

# Generated at 2022-06-24 03:04:53.010037
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'qux'])) == ['foo/bar', 'foo/qux']


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:04:57.918423
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('/tmp', ['a', 'b'])) == ['/tmp/a', '/tmp/b']


# Test script with import
if __name__ == '__main__':
    print(test_join_each())

# Generated at 2022-06-24 03:05:02.888988
# Unit test for function join_each
def test_join_each():
    test_paths = ['/home/kenny', '/home/jason', '/home/jack']
    expected = [os.path.join('/home', p) for p in test_paths]
    assert len(expected) == len(test_paths)
    assert list(join_each('/home', test_paths)) == expected



# Generated at 2022-06-24 03:05:06.453537
# Unit test for function join_each
def test_join_each():
    p = '/fict/root'
    ps = ['dir1', 'dir2', 'dir3', 'dir4']
    expected = [
        '/fict/root/dir1',
        '/fict/root/dir2',
        '/fict/root/dir3',
        '/fict/root/dir4',
    ]
    result = list(join_each(p, ps))
    assert expected == result
    print(result)

# Generated at 2022-06-24 03:05:13.308309
# Unit test for function join_each
def test_join_each():
    p = 'parent'
    i = ['abc', 'def']
    r = ['parent/abc', 'parent/def']
    assert list(join_each(p, i)) == r


# Sometimes we want to test a function under slightly different scenarios
# This function would do the job for you

# Generated at 2022-06-24 03:05:14.294006
# Unit test for function join_each
def test_join_each():
    assert list(join_each('p', ['foo', 'bar'])) == ['p/foo', 'p/bar']

# Generated at 2022-06-24 03:05:16.888027
# Unit test for function join_each
def test_join_each():
    l = ["data", "cmd", "try"]
    expected = ["data/cmd", "data/try"]
    assert list(join_each("data", l[1:])) == expected

# Generated at 2022-06-24 03:05:22.945848
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', [1, 2, 3])) == ['a/1', 'a/2', 'a/3']



# Generated at 2022-06-24 03:05:25.719037
# Unit test for function join_each
def test_join_each():
    example = join_each('dir', ('subdir1', 'subdir2'))
    assert next(example) == os.path.join('dir', 'subdir1')
    assert next(example) == os.path.join('dir', 'subdir2')


# In[4]:



# Generated at 2022-06-24 03:05:30.386660
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ("foo", "bar"))) == ["/foo", "/bar"]
    assert list(join_each("/", iter(["foo", "bar"]))) == ["/foo", "/bar"]



# Generated at 2022-06-24 03:05:32.921346
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'b/c', 'd'])) == [
        '/a/b',
        '/a/b/c',
        '/a/d',
    ]



# Generated at 2022-06-24 03:05:34.894761
# Unit test for function join_each
def test_join_each():
    path_list = ["path1", "path2"]
    expected = ["path/path1", "path/path2"]
    actual = list(join_each("path", path_list))
    assert expected == actual



# Generated at 2022-06-24 03:05:36.213935
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['user', 'bin'])) == [
        '/home/user', '/home/bin']



# Generated at 2022-06-24 03:05:37.723317
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/me", "abc")) == ["/home/me/a", "/home/me/b", "/home/me/c"]



# Generated at 2022-06-24 03:05:47.946884
# Unit test for function join_each
def test_join_each():
    def check(expected, *args):
        actual = list(join_each(*args))
        assert expected == actual

    check([], '', [])
    check([], '', ['something'])
    check([], '', ['something'])

    check(['/x', '/x/y'], '/', ['x', 'x/y'])

    check(['/x/a', '/x/b', '/x/c'], '/x/', ['a', 'b', 'c'])
    check(['/x/y/a', '/x/y/b', '/x/y/c'], '/x/y/', ['a', 'b', 'c'])

    check(['/x/a', '/x/b', '/x/c'], '/x', ['a', 'b', 'c'])

# Generated at 2022-06-24 03:05:53.266319
# Unit test for function join_each
def test_join_each():
    p = os.path.join("a", "b", "c")
    assert list(join_each(p, ["d", "e", "f"])) == [
        os.path.join(p, "d"),
        os.path.join(p, "e"),
        os.path.join(p, "f"),
    ]



# Generated at 2022-06-24 03:06:03.709440
# Unit test for function join_each
def test_join_each():
    from itertools import permutations

    d1, d2, d3 = 'd1', 'd2', 'd3'  # directories
    f1, f2, f3 = 'f1', 'f2', 'f3'  # files

    paths_in = [('.', d1, d2, f1), ('..', d2, d3, f2), (d1, d3, f3)]
    paths_out = [(d1, f1), (d1, d2, f1), (d1, d2, d3, f2),
                 (d1, d2, d3, f3), (d1, d3, f2), (d1, d3, f3)]
    assert list(join_each(d1, paths_in)) == paths_out



# Generated at 2022-06-24 03:06:07.056940
# Unit test for function join_each
def test_join_each():
    """Test that join_each(parent, iterable) generates the expected result."""
    assert (list(join_each('a', ['b', 'c'])) ==
            ['a/b', 'a/c'])



# Generated at 2022-06-24 03:06:12.020125
# Unit test for function join_each
def test_join_each():
    from collections import Iterator
    assert isinstance(join_each('/', ['a', 'b', 'c']), Iterator)

# Generated at 2022-06-24 03:06:20.506373
# Unit test for function join_each
def test_join_each():
    parent = r'C:\Program Files'
    iterable = ['Python', 'Python35', 'python.exe']
    result = list(join_each(parent, iterable))
    print(result)
    assert result == [
        os.path.join(parent, iterable[0], iterable[1], iterable[2]),
        os.path.join(parent, iterable[0], iterable[2]),
        os.path.join(parent, iterable[1], iterable[2]),
        os.path.join(parent, iterable[2])]
    assert result != [
        os.path.join(parent, iterable[1], iterable[2]),
        os.path.join(parent, iterable[2])]



# Generated at 2022-06-24 03:06:25.417049
# Unit test for function join_each
def test_join_each():
    p = '/foo'
    file_list = join_each(p, ['bar', 'baz'])
    print(list(file_list))
    assert list(file_list) == ['/foo/bar', '/foo/baz']



# Generated at 2022-06-24 03:06:30.879514
# Unit test for function join_each
def test_join_each():
    iterable = ["foo", "bar", "baz"]
    base = "data"
    results = [
        "data/foo",
        "data/bar",
        "data/baz",
    ]

    assert list(join_each(base, iterable)) == results



# Generated at 2022-06-24 03:06:34.058824
# Unit test for function join_each
def test_join_each():
    assert join_each("/a/b", ["c/d", "e/f"]) == [
        "/a/b/c/d",
        "/a/b/e/f"
    ]



# Generated at 2022-06-24 03:06:41.118296
# Unit test for function join_each
def test_join_each():
    for parent, children in [("foo", ["bar", "baz"]),
                             ("foo/bar", ["baz", "qux"]),
                             ("", ["foo", "bar"]),
                             ]:
        pchildren = list(join_each(parent, children))
        for child in children:
            assert any(pchild == os.path.join(parent, child)
                       for pchild in pchildren)



# Generated at 2022-06-24 03:06:45.802029
# Unit test for function join_each
def test_join_each():
    """ Unit test for function join_each """
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:06:47.859661
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['lib', 'bin'])) == [
        '/usr/lib',
        '/usr/bin'
    ]

# Generated at 2022-06-24 03:06:49.648135
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["a", "b"])) == ["/a", "/b"]



# Generated at 2022-06-24 03:06:51.322467
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']



# Generated at 2022-06-24 03:06:54.622101
# Unit test for function join_each
def test_join_each():
    a_dir = "a"
    b_dir = "b"
    contents = ("apple", "banana", "pear")

    expected = [os.path.join(a_dir, c) for c in contents]

    result = list(join_each(a_dir, contents))

    assert result == expected, "join_each should put the parent dir first"


# Performance test for function join_each

# Generated at 2022-06-24 03:07:00.207831
# Unit test for function join_each
def test_join_each():
    file = 'test_file'
    folder = 'test_folder'

    folder_path = os.path.join('..', folder)
    file_path = os.path.join('..', folder, file)

    assert file_path in join_each(folder_path, [file])


# Tests for function check_path_exists

# Generated at 2022-06-24 03:07:06.179818
# Unit test for function join_each
def test_join_each():
    assert list(join_each('path', ['a', 'b', 'c'])) == ['path/a', 'path/b', 'path/c']
    assert list(join_each('another/path', ['a', 'b', 'c'])) == ['another/path/a', 'another/path/b', 'another/path/c']



# Generated at 2022-06-24 03:07:09.557083
# Unit test for function join_each
def test_join_each():
    par = os.path.abspath('.')
    dirs = [
        'cfg',
        'gui',
        'gui/ui',
    ]
    assert list(join_each(par, dirs)) == [
        os.path.join(par, d) for d in dirs
    ]

# Generated at 2022-06-24 03:07:11.737030
# Unit test for function join_each
def test_join_each():
    begin = "begin/"
    end = ["end1", "end2"]
    actual = list(join_each(begin, end))
    expected = ["begin/end1", "begin/end2"]
    assert actual == expected

# Generated at 2022-06-24 03:07:12.969812
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', [1, '2'])) == ['/foo/1', '/foo/2']

# Generated at 2022-06-24 03:07:15.946424
# Unit test for function join_each
def test_join_each():
    iterable = join_each("foo", ["bar", "baz"])

    assert next(iterable) == "foo/bar"
    assert next(iterable) == "foo/baz"

    with pytest.raises(StopIteration):
        next(iterable)

# Generated at 2022-06-24 03:07:20.611202
# Unit test for function join_each
def test_join_each():
    p = '/foo'
    iterable = ['/bar', 'baz']
    expected = ['/foo/bar', '/foo/baz']
    assert list(join_each(p, iterable)) == expected



# Generated at 2022-06-24 03:07:21.987261
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-24 03:07:25.181544
# Unit test for function join_each
def test_join_each():
    path = '/home/'
    assert list(join_each(path, ['a', 'b', 'c'])) == [
        join_each(path, ['a', 'b', 'c'])
    ]

# Generated at 2022-06-24 03:07:27.151898
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['home', 'pi'])) == ['/home', '/pi']

# Generated at 2022-06-24 03:07:29.882964
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/Desktop", ["file1.txt", "file2.txt"])) == [
        "/home/Desktop/file1.txt",
        "/home/Desktop/file2.txt",
    ]

# Generated at 2022-06-24 03:07:30.931012
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar'])) == ['foo%sbar' % os.sep]
    assert lis

# Generated at 2022-06-24 03:07:39.860985
# Unit test for function join_each
def test_join_each():
    assert list(join_each('temp', 'abcdefg')) == [
        'temp/a',
        'temp/b',
        'temp/c',
        'temp/d',
        'temp/e',
        'temp/f',
        'temp/g',
    ]
    assert list(join_each('temp', ('a', 'b', 'c', 'd'))) == [
        'temp/a',
        'temp/b',
        'temp/c',
        'temp/d',
    ]



# Generated at 2022-06-24 03:07:42.840498
# Unit test for function join_each
def test_join_each():
    assert list(join_each("", ["a", "b", "c"])) == ["a", "b", "c"]
    assert list(join_each("/", ["a", "b", "c"])) == ["/a", "/b", "/c"]
    assert list(join_each("test", ["a", "b", "c"])) == ["test/a", "test/b", "test/c"]



# Generated at 2022-06-24 03:07:47.498303
# Unit test for function join_each
def test_join_each():
    new_iterable = join_each('/tmp', ['a', 'b', 'c'])

    assert next(new_iterable) == '/tmp/a'
    assert next(new_iterable) == '/tmp/b'
    assert next(new_iterable) == '/tmp/c'



# Generated at 2022-06-24 03:07:52.240636
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['a', 'b', 'c'])) == ['foo/a', 'foo/b', 'foo/c']

# Generated at 2022-06-24 03:07:56.921561
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr/bin", ["python", "yum"])) == [
        "/usr/bin/python",
        "/usr/bin/yum",
    ]



# Generated at 2022-06-24 03:08:03.102749
# Unit test for function join_each
def test_join_each():
    cwd = os.getcwd()
    assert join_each(cwd, ['helloworld.txt']) == ['{}/helloworld.txt'.format(cwd)]
    assert join_each(cwd, ['helloworld.txt', 'helloworld2.txt']) == [
        '{}/helloworld.txt'.format(cwd),
        '{}/helloworld2.txt'.format(cwd)
    ]

# Generated at 2022-06-24 03:08:06.381488
# Unit test for function join_each
def test_join_each():
    parent = 'test'

    for iterable in [['test1', 'test2'], ('test1', 'test2')]:
        assert utils.join_each(parent, iterable) == [os.path.join(parent, p) for p in iterable]



# Generated at 2022-06-24 03:08:13.087953
# Unit test for function join_each
def test_join_each():
    test = join_each("/Users/talic", ["Documents", "Desktop", "Downloads"])
    result = ["/Users/talic/Documents", "/Users/talic/Desktop",
              "/Users/talic/Downloads"]

    assert test == result

# Generated at 2022-06-24 03:08:20.984124
# Unit test for function join_each
def test_join_each():
    path = '.'

    # Test for os.listdir('.')
    for combined in join_each(path, os.listdir('.')):
        assert os.path.exists(combined)

    # Test for os.listdir('tests')
    for combined in join_each(path, os.listdir('tests')):
        assert os.path.exists(combined)

    # Test for os.listdir('.')
    for combined in join_each(path, [p for p in os.listdir('.') if os.path.isdir(p)]):
        assert os.path.exists(combined)
        assert os.path.isdir(combined)

# Generated at 2022-06-24 03:08:25.163610
# Unit test for function join_each
def test_join_each():
    d = dirname(__file__)
    assert list(join_each(d, [])) == []
    assert list(join_each(d, ["one"])) == [os.path.join(d, "one")]
    assert list(join_each(d, ("one", "two"))) == [os.path.join(d, "one"), os.path.join(d, "two")]



# Generated at 2022-06-24 03:08:30.752889
# Unit test for function join_each
def test_join_each():
    assert list(join_each('bar', ['foo', 'baz'])) == [
        os.path.join(os.path.sep, 'bar', 'foo'),
        os.path.join(os.path.sep, 'bar', 'baz')
    ]

# Generated at 2022-06-24 03:08:34.654424
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['foo', 'bar'])) == [
        '/tmp/foo', '/tmp/bar'
    ]



# Generated at 2022-06-24 03:08:36.690112
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b/c'])) == ['/a', '/b/c']
    assert list(join_each('/', [])) == []


# Generated at 2022-06-24 03:08:41.392860
# Unit test for function join_each
def test_join_each():
    iter_input = ["a", "b", "c"]
    parent = "/home/foo"
    expect = ["/home/foo/a", "/home/foo/b", "/home/foo/c"]
    actual = [p for p in join_each(parent, iter_input)]
    assert actual == expect



# Generated at 2022-06-24 03:08:45.074019
# Unit test for function join_each
def test_join_each():
    assert list(join_each('x', ['/y'])) == ['x/y']
    assert list(join_each('/x', ['/y'])) == ['/x/y']
    assert list(join_each('/x', ['y/'])) == ['/x/y/']
    assert list(join_each('x', ['y'])) == ['x/y']
    assert list(join_each('x', ['y', 'z'])) == ['x/y', 'x/z']
    assert list(join_each('x/y', ['z', 'w'])) == ['x/y/z', 'x/y/w']

# Generated at 2022-06-24 03:08:47.578178
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/foo/", ["bar", "baz"])) == ["/home/foo/bar", "/home/foo/baz"]


# Given a parent dir and a list of glob patterns return an iterator for all matching files.

# Generated at 2022-06-24 03:08:50.889404
# Unit test for function join_each
def test_join_each():
    parent = '/Users'
    iterable = ['audiowell', 'Desktop', 'Downloads']
    for path in join_each(parent, iterable):
        print(path)



# Generated at 2022-06-24 03:08:52.982159
# Unit test for function join_each
def test_join_each():
    joined = list(join_each('foo', 'bar baz'.split()))
    assert joined == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:08:55.189083
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['foo', 'bar'])) == [
        '/tmp/foo',
        '/tmp/bar',
    ]



# Generated at 2022-06-24 03:09:02.121208
# Unit test for function join_each
def test_join_each():
    path = os.path.dirname(__file__)

# Generated at 2022-06-24 03:09:06.295192
# Unit test for function join_each
def test_join_each():
    assert list(join_each('', ['a', 'b'])) == ['a', 'b']
    assert list(join_each('x', ['a', 'b'])) == ['xa', 'xb']
    assert list(join_each('y', [])) == []



# Generated at 2022-06-24 03:09:09.274465
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/dir1', ['dir2', 'dir3'])) == [
        '/dir1/dir2', '/dir1/dir3']



# Generated at 2022-06-24 03:09:11.575810
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['user', 'log'])) == ['/home/user', '/home/log']



# Generated at 2022-06-24 03:09:16.882671
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['1', '2', '3']
    # Note this is a list of paths, not a list of strings
    expected = [os.path.join(parent, p) for p in iterable]
    # List of paths must be equal to list of strings
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:09:21.780177
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user',
                          ['file1', 'file2', 'file3'])) == [
        '/home/user/file1',
        '/home/user/file2',
        '/home/user/file3',
    ]


# Tests for joinpath

# Generated at 2022-06-24 03:09:25.769383
# Unit test for function join_each
def test_join_each():
    paths = join_each('blah', [1, 2, 3])
    assert next(paths) == 'blah/1'
    assert next(paths) == 'blah/2'
    assert next(paths) == 'blah/3'



# Generated at 2022-06-24 03:09:28.945470
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["child1", "child2", "child3"]
    expected_children = [os.path.join(parent, p) for p in iterable]
    actual_children = list(join_each(parent, iterable))
    assert expected_children == actual_children



# Generated at 2022-06-24 03:09:31.345221
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-24 03:09:33.496373
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', 'usr', 'local', 'bin')) == [
        '/usr', '/local', '/bin']


# "example" unit test

# Generated at 2022-06-24 03:09:35.683843
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar', 'baz'])) == [
        '/foo', '/bar', '/baz']



# Generated at 2022-06-24 03:09:39.774136
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', ['passwd', 'shadow'])) == ['/etc/passwd', '/etc/shadow']
    assert list(join_each('/usr/local/bin/', os.listdir('/usr/local/bin/'))) == glob.glob('/usr/local/bin/*')
    assert list(join_each('.', os.listdir())) == glob.glob('./*')

# Generated at 2022-06-24 03:09:41.973543
# Unit test for function join_each
def test_join_each():

    # Given
    iterable = ['a', 'b', 'c']
    parent = 'foo'

    # When
    result = list(join_each(parent, iterable))

    # Then
    assert result == ['foo/a', 'foo/b', 'foo/c']

# Generated at 2022-06-24 03:09:49.330764
# Unit test for function join_each
def test_join_each():
    test_cases = [
        (
            [
                os.path.join(
                    '/home/foo/.config/nvim/plugged/youcompleteme'
                    '/third_party/ycmd/third_party/watchman',
                    '__init__.py'
                )
            ],
            join_each(
                '/home/foo/.config/nvim/plugged/youcompleteme'
                '/third_party/ycmd/third_party/watchman',
                [
                    '__init__.py'
                ]
            )
        )
    ]

    for expected, actual in test_cases:
        assert list(actual) == expected



# Generated at 2022-06-24 03:09:54.986703
# Unit test for function join_each
def test_join_each():
    paths = ['/tmp', '/usr/bin', '/etc']
    assert list(join_each('/sbin', paths)) == [
        '/sbin/tmp', '/sbin/usr/bin', '/sbin/etc']



# Generated at 2022-06-24 03:09:56.837822
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:09:58.903262
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('/tmp/', ['a','b','c'])) == ['/tmp/a', '/tmp/b', '/tmp/c'])


# Generated at 2022-06-24 03:10:00.672183
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]

# Generated at 2022-06-24 03:10:04.487453
# Unit test for function join_each
def test_join_each():
    actual = list(join_each("/path/to", ["foo.txt", "bar.txt"]))
    expected = ["/path/to/foo.txt", "/path/to/bar.txt"]
    assert actual == expected

# Generated at 2022-06-24 03:10:10.946537
# Unit test for function join_each
def test_join_each():
    parent_path = './parent_path'
    file_list = ['a', 'b']
    assert list(join_each(parent_path, file_list)) == [
        os.path.join(parent_path, 'a'),
        os.path.join(parent_path, 'b'),
    ]



# Generated at 2022-06-24 03:10:14.945930
# Unit test for function join_each
def test_join_each():
    def test_inner(parent, iterable, expected):
        actual = list(join_each(parent, iterable))
        assert actual == expected

    test_inner("/foo", ["bar", "baz"], ["/foo/bar", "/foo/baz"])



# Generated at 2022-06-24 03:10:18.639807
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    iterable = ['user', 'username']
    path_list = ['/home/user', '/home/username']
    paths = join_each(parent, iterable)
    assert paths == path_list

# Generated at 2022-06-24 03:10:20.706487
# Unit test for function join_each
def test_join_each():
    base = 'test'
    expected = ['test/foo', 'test/bar']
    actual = list(join_each(base, ['foo', 'bar']))
    assert expected == actual



# Generated at 2022-06-24 03:10:22.184423
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:10:24.281824
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/c', ['one', 'two', 'three'])) == [
        '/a/b/c/one',
        '/a/b/c/two',
        '/a/b/c/three',
    ]

# Generated at 2022-06-24 03:10:29.583597
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', 'alice bob charlie'.split())) == [
        '/home/alice',
        '/home/bob',
        '/home/charlie',
    ]


# Filters a list of paths. Removes any paths which are not regular files (directories, symlinks, etc.)

# Generated at 2022-06-24 03:10:34.754698
# Unit test for function join_each
def test_join_each():
    assert list(join_each("hello", ["A", "B", "C"])) == ["hello/A", "hello/B", "hello/C"]

# Generated at 2022-06-24 03:10:38.027188
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('parent', [])) == tuple()
    assert tuple(join_each('parent', ['child'])) == ('parent/child',)
    assert tuple(join_each('parent', ['child1', 'child2'])) == (
        'parent/child1', 'parent/child2')



# Generated at 2022-06-24 03:10:40.295049
# Unit test for function join_each
def test_join_each():
    parent = './folder'
    paths = ['a', 'b', 'c']
    expected = [os.path.join(parent, path) for path in paths]

    assert list(join_each(parent, paths)) == expected

# Generated at 2022-06-24 03:10:43.718602
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == [
        '/tmp/a', '/tmp/b', '/tmp/c']


# Unit Test
# parent, child = '/tmp', ['a', 'b', 'c']
# test_join_each(parent, child)



# Generated at 2022-06-24 03:10:55.569570
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == [
        '/tmp/a',
        '/tmp/b',
        '/tmp/c']

# Generated at 2022-06-24 03:10:57.879186
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/user", ["test", "lib"])) == \
        ["/home/user/test", "/home/user/lib"]



# Generated at 2022-06-24 03:11:04.554510
# Unit test for function join_each
def test_join_each():
    os.environ.setdefault('PYTHONPATH', '.')
    import test_join_each
    assert test_join_each.join_each('/etc', ('a', 'b')) == '/etc/a /etc/b'



# Generated at 2022-06-24 03:11:05.830187
# Unit test for function join_each
def test_join_each():
    assert list(join_each('path', ['a', 'b'])) == ['path/a', 'path/b']

# Generated at 2022-06-24 03:11:10.838992
# Unit test for function join_each
def test_join_each():
    assert join_each('foo', ['bar', 'baz']) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:11:16.151577
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/abc/', ['/b', '/c'])) == ['/abc/b', '/abc/c']
    assert list(join_each(
        '/abc/', ['b', 'c'])) == ['/abc/b', '/abc/c']

# Generated at 2022-06-24 03:11:17.831125
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:11:20.311804
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/Users/jokr/Desktop/", ["a", "b"])) == [
        "/Users/jokr/Desktop/a",
        "/Users/jokr/Desktop/b",
    ]



# Generated at 2022-06-24 03:11:26.082409
# Unit test for function join_each
def test_join_each():
    assert join_each('/opt/local/bin', ['test1', 'test2', 'test3']) == [
        '/opt/local/bin/test1',
        '/opt/local/bin/test2',
        '/opt/local/bin/test3',
    ]



# Generated at 2022-06-24 03:11:30.783336
# Unit test for function join_each
def test_join_each():
    eq_(list(join_each("/", ["usr", "local", "bin"])), [
        "/usr", "/local", "/bin",
    ])



# Generated at 2022-06-24 03:11:34.145506
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/', ['usr', 'bin']))
    assert result == ['/usr', '/bin']
    result = list(join_each('', ['usr', 'bin']))
    assert result == ['usr', 'bin']

# Generated at 2022-06-24 03:11:37.565109
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    
    

# Generated at 2022-06-24 03:11:41.200920
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['a', 'b', 'c', 'd']
    result = list(join_each(parent, iterable))
    expected = [os.path.join(parent, p) for p in iterable]
    assert result == expected

# Generated at 2022-06-24 03:11:46.763609
# Unit test for function join_each
def test_join_each():
    assert join_each("/", ["foo", "bar"]) == ["/foo", "/bar"]
    assert join_each("/", ["/foo", "/bar"]) == ["/foo", "/bar"]
    assert join_each("/foo", ["/bar", "/baz"]) == ["/foo/bar", "/foo/baz"]
    assert list(join_each("/foo", iter(["/bar", "/baz"]))) == ["/foo/bar", "/foo/baz"]



# Generated at 2022-06-24 03:11:48.475138
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['f1', 'f2'])) == ['/tmp/f1', '/tmp/f2']

# Generated at 2022-06-24 03:11:56.192603
# Unit test for function join_each
def test_join_each():
    path = 'C:\\Users\\Haydn\\Desktop'
    test_iterable = (path, 'test.txt', 'test2.txt', 'test3.txt')
    expect = ('C:\\Users\\Haydn\\Desktop\\test.txt',
              'C:\\Users\\Haydn\\Desktop\\test2.txt',
              'C:\\Users\\Haydn\\Desktop\\test3.txt')
    assert tuple(join_each(path, test_iterable)) == expect


# return a list of directories containing a given file in the current directory

# Generated at 2022-06-24 03:12:00.681396
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a/b/c', ['d', 'e'])) == ['a/b/c/d', 'a/b/c/e']



# Generated at 2022-06-24 03:12:03.184498
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/foo", ["bar", "baz"])) == [
        "/foo/bar",
        "/foo/baz"
    ]
    assert list(join_each("", ["bar", "baz"])) == [
        "/bar",
        "/baz"
    ]



# Generated at 2022-06-24 03:12:08.026835
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/c', ['d', 'e', 'f'])) == ['/a/b/c/d', '/a/b/c/e', '/a/b/c/f']

# Generated at 2022-06-24 03:12:10.751064
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/hello', ('there', 'curious', 'monkey'))) == [
        '/hello/there',
        '/hello/curious',
        '/hello/monkey',
    ]



# Generated at 2022-06-24 03:12:13.345633
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('/a/b', ['/c/d', '/e/f'])) ==
           ['/a/b/c/d', '/a/b/e/f'])



# Generated at 2022-06-24 03:12:15.931890
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a", ["b", "c"])) == ["/a/b", "/a/c"]
    assert list(join_each("/a", "bc")) == ["/a/b", "/a/c"]



# Generated at 2022-06-24 03:12:23.988447
# Unit test for function join_each
def test_join_each():
    # Setup
    parent = '/home/user'
    iterable = ['file1.txt', 'file2.txt', 'file3.txt']
    expected = [
        '/home/user/file1.txt',
        '/home/user/file2.txt',
        '/home/user/file3.txt'
    ]

    # Exercise
    result = list(join_each(parent, iterable))

    # Verify
    assert result == expected



# Generated at 2022-06-24 03:12:27.241951
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr", ["adm", "etc", "lib"])) == [
        "/usr/adm",
        "/usr/etc",
        "/usr/lib",
    ]
    assert list(join_each("/usr", [])) == []



# Generated at 2022-06-24 03:12:33.316861
# Unit test for function join_each
def test_join_each():
    parent = 'one'
    assert list(join_each(parent, ['two', 'three', 'four'])) == \
           [os.path.join(parent, 'two'),
            os.path.join(parent, 'three'),
            os.path.join(parent, 'four')]


# Gives a list of files

# Generated at 2022-06-24 03:12:39.215127
# Unit test for function join_each
def test_join_each():
    # Parent to join
    parent = os.path.abspath(".")
    # List of subpaths
    iterable = ["test_a", "test_b", "test_c"]
    # List of expected results
    expected_result = [
        os.path.join(parent, "test_a"),
        os.path.join(parent, "test_b"),
        os.path.join(parent, "test_c"),
    ]
    assert list(join_each(parent, iterable)) == expected_result



# Generated at 2022-06-24 03:12:41.561639
# Unit test for function join_each
def test_join_each():
    print('Testing join_each')

    assert ['a/b', 'a/c'] == list(join_each('a', ['b', 'c']))



# Generated at 2022-06-24 03:12:51.262870
# Unit test for function join_each
def test_join_each():
    folder = '/tmp'
    assert list(join_each('/tmp', [])) == []
    assert list(join_each(folder, ['a'])) == [
        os.path.join(folder, 'a')
    ]
    assert list(join_each(folder, 'a')) == [
        os.path.join(folder, 'a')
    ]
    assert list(join_each(folder, ('a', 'b', 'c'))) == [
        os.path.join(folder, 'a'), os.path.join(folder, 'b'),
        os.path.join(folder, 'c')
    ]

# Generated at 2022-06-24 03:12:53.833843
# Unit test for function join_each
def test_join_each():
    parent = '/parent'
    iterable = ['a', 'b', 'c']
    assert list(join_each(parent, iterable)) == ['/parent/a', '/parent/b', '/parent/c']

# Generated at 2022-06-24 03:12:56.126260
# Unit test for function join_each
def test_join_each():
    assert list(join_each('base', ['a', 'b', 'c'])) == [
        'base/a',
        'base/b',
        'base/c',
    ]

# Generated at 2022-06-24 03:12:58.804110
# Unit test for function join_each
def test_join_each():
    assert list(join_each('c:\\foo', ['bar', 'baz', 'qux'])) == ['c:\\foo\\bar', 'c:\\foo\\baz', 'c:\\foo\\qux']



# Generated at 2022-06-24 03:13:01.389230
# Unit test for function join_each
def test_join_each():
    parent = '/'
    iterable = ('dir1', 'dir2', 'dir3')
    expected = ['/dir1', '/dir2', '/dir3']
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:13:03.997277
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['usr', 'local', 'bin'])) == [
        '/usr', '/local', '/bin'
    ]

# Generated at 2022-06-24 03:13:07.178746
# Unit test for function join_each
def test_join_each():
    assert join_each('/', ['a', 'b', 'c']) == [
        '/a', '/b', '/c'
    ]



# Generated at 2022-06-24 03:13:12.330726
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['home', 'foo/bar'])) == ['/home', '/foo/bar']
    assert list(join_each('c:\\', ['home', 'foo\\bar'])) == ['c:\\home', 'c:\\foo\\bar']
    assert list(join_each('', ['home', 'bar'])) == ['home', 'bar']


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:13:14.371513
# Unit test for function join_each
def test_join_each():
    assert list(join_each("root", ["a", "b"])) == ["root/a", "root/b"]



# Generated at 2022-06-24 03:13:16.368391
# Unit test for function join_each
def test_join_each():
    print("join_each(/tmp, [home, bin])")
    print(list(join_each("/tmp", ["home", "bin"])))



# Generated at 2022-06-24 03:13:20.794910
# Unit test for function join_each
def test_join_each():
    assert join_each('/a', ['b']) == ['/a/b']
    assert join_each('/a', ['b', 'c']) == ['/a/b', '/a/c']


# Function to create a list of filenames in a directory

# Generated at 2022-06-24 03:13:26.033165
# Unit test for function join_each
def test_join_each():
    tbl = [
        ("/tmp", ["foo", "bar", "baz"], ["/tmp/foo", "/tmp/bar", "/tmp/baz"]),
        ("/mnt", [], [])
    ]

    for parent, children, wanted in tbl:
        assert list(join_each(parent, children)) == wanted



# Generated at 2022-06-24 03:13:30.969803
# Unit test for function join_each
def test_join_each():
    d = ('/usr/bin',)
    f = ('python', 'ruby')
    assert list(join_each(d, f)) == ['/usr/bin/python', '/usr/bin/ruby']



# Generated at 2022-06-24 03:13:33.301899
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/local/bin', ['python', 'ruby'])) == [
        '/usr/local/bin/python', '/usr/local/bin/ruby']



# Generated at 2022-06-24 03:13:36.706189
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    iterable = ['foo', 'bar']
    assert list(join_each(parent, iterable)) == ['/home/foo', '/home/bar']

# Generated at 2022-06-24 03:13:40.637734
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]



# Generated at 2022-06-24 03:13:45.950589
# Unit test for function join_each
def test_join_each():
    parent = r'C:\Windows\System32'
    iterable = ['calc.exe', 'notepad.exe', 'winword.exe']
    assert list(join_each(parent, iterable)) == [
        r'C:\Windows\System32\calc.exe',
        r'C:\Windows\System32\notepad.exe',
        r'C:\Windows\System32\winword.exe'
    ]



# Generated at 2022-06-24 03:13:48.486518
# Unit test for function join_each
def test_join_each():
    assert list(join_each("", ("a", "b"))) == ["a", "b"]
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]



# Generated at 2022-06-24 03:13:53.597876
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('.', ['a/b', 'c'])) == ['./a/b', './c']


# Regex for question mark
Q_REGEX = re.compile('\?')

# Regex for *
S_REGEX = re.compile('\*')


# Function to find all files in a directory with given wildcard