

# Generated at 2022-06-24 03:03:52.318315
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/user", ["name", "age"])) == [
        os.path.join("/home/user", path) for path in ["name", "age"]
    ]



# Generated at 2022-06-24 03:03:56.355187
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b/c'])) == [
        '/a', '/b/c'
    ]



# Generated at 2022-06-24 03:03:57.721002
# Unit test for function join_each
def test_join_each():
    result = list(join_each('.', ['test', 'directory']))
    assert result == ['./test', './directory']



# Generated at 2022-06-24 03:04:02.061125
# Unit test for function join_each
def test_join_each():
    assert ['a/b', 'a/c', 'a/d'] == list(join_each('a', ['b', 'c', 'd']))

# Generated at 2022-06-24 03:04:06.293290
# Unit test for function join_each
def test_join_each():
    files = ['a', 'b', 'c']
    files_with_parent = join_each('parent', files)
    assert list(files_with_parent) == ['parent/a', 'parent/b', 'parent/c']



# Generated at 2022-06-24 03:04:11.722244
# Unit test for function join_each
def test_join_each():
    assert list(join_each(os.path.expanduser('~'), ['.bashrc', '.bash_profile'])) == \
        [os.path.join(os.path.expanduser('~'), '.bashrc'), os.path.join(os.path.expanduser('~'), '.bash_profile')]

# Generated at 2022-06-24 03:04:17.392204
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc/ssl', ['mycert.pem', 'mykey.pem'])) == [
        '/etc/ssl/mycert.pem', '/etc/ssl/mykey.pem']

# Generated at 2022-06-24 03:04:21.014941
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["child1", "child2"]

    joined_pairs = join_each(parent, iterable)
    assert list(joined_pairs) == [os.path.join(parent, "child1"),
                                  os.path.join(parent, "child2")]



# Generated at 2022-06-24 03:04:25.466044
# Unit test for function join_each
def test_join_each():
    parent = "/root/path"
    iterable = ["a", "b", "c"]
    actual = []
    for p in join_each(parent, iterable):
        actual.append(p)
    expected = ["/root/path/a", "/root/path/b", "/root/path/c"]
    assert expected == actual

# Generated at 2022-06-24 03:04:28.160617
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child1', 'child2'])) == \
           ['parent/child1', 'parent/child2']



# Generated at 2022-06-24 03:04:34.840722
# Unit test for function join_each
def test_join_each():
    assert list(join_each(None, ["foo/bar.txt", "baz/quux.txt"])) == ["foo/bar.txt", "baz/quux.txt"]
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]
    assert list(join_each("foo", ("bar", "baz"))) == ["foo/bar", "foo/baz"]
    assert list(join_each("", ("bar", "baz"))) == ["bar", "baz"]



# Generated at 2022-06-24 03:04:37.622909
# Unit test for function join_each
def test_join_each():
    p = "/usr"
    files = ["local", "share"]

    for f in join_each(p, files):
        assert f == "/usr/" + files.pop(0)



# Generated at 2022-06-24 03:04:43.724334
# Unit test for function join_each
def test_join_each():
    parent = r"D:\Work\tung\projects\pythonLearning\learningPython"
    iterable = (r"filesystem\osFunctions\join_each.py",
                r"filesystem\osFunctions\join_each.pyc")
    expected_list = (r"D:\Work\tung\projects\pythonLearning\learningPython\filesystem\osFunctions\join_each.py",
                     r"D:\Work\tung\projects\pythonLearning\learningPython\filesystem\osFunctions\join_each.pyc")
    result_list = list(join_each(parent, iterable))
    for result, expected in zip(result_list, expected_list):
        assert result == expected



# Generated at 2022-06-24 03:04:47.325446
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/user/foo", ["bar", "baz", "quux"])) == \
        ["/home/user/foo/bar", "/home/user/foo/baz", "/home/user/foo/quux"]

# Generated at 2022-06-24 03:04:57.959468
# Unit test for function join_each
def test_join_each():
    assert list(join_each('', ()), ()) == []
    assert list(join_each('', ['']), ()) == ['.']
    assert list(join_each('', ['a']), ()) == ['./a']
    assert list(join_each('.', ['']), ()) == ['.']
    assert list(join_each('.', ['a']), ()) == ['./a']
    assert list(join_each('..', ['']), ()) == ['..']
    assert list(join_each('..', ['a']), ()) == ['../a']
    assert list(join_each('..', ['a', 'b']), ()) == ['../a', '../b']



# Generated at 2022-06-24 03:05:03.542316
# Unit test for function join_each
def test_join_each():
    base = '/a/b/c'
    names = ['foo', 'bar', 'zap']
    paths = list(join_each(base, names))
    assert len(paths) == len(names), "Join Each Length Error"
    for path in paths:
        assert path.startswith(base), "Path does not start with expected directory"
        assert os.path.basename(path) in names, "Path does not end with expected file name"

# Generated at 2022-06-24 03:05:05.186638
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:05:06.770283
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a", ["x", "y"])) == ["/a/x", "/a/y"]



# Generated at 2022-06-24 03:05:11.166082
# Unit test for function join_each
def test_join_each():
    expected = ["/home/user/foo/bar",
                "/home/user/foo/baz",
                "/home/user/foo/quux"]
    assert list(join_each("/home/user/foo", ["bar", "baz", "quux"])) == expected


# Exercise the join_each function against the filesystem

# Generated at 2022-06-24 03:05:13.010609
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['usr', 'bin'])) == ['/usr', '/bin']



# Generated at 2022-06-24 03:05:16.937266
# Unit test for function join_each
def test_join_each():
    base_path = os.path.join('base', 'path')
    paths = ['one', 'two', 'three', 'four']
    joined_paths = list(join_each(base_path, paths))
    for path in joined_paths:
        assert path.startswith(base_path)



# Generated at 2022-06-24 03:05:25.983472
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/c', 'def')) == ['/a/b/c/d', '/a/b/c/e', '/a/b/c/f']
    assert list(join_each('/a/b/c', [])) == []
    assert list(join_each('/a/b/c', [1, 2, 3])) == ['/a/b/c/1', '/a/b/c/2', '/a/b/c/3']
    assert list(join_each('a', 'b')) == ['a/b']



# Generated at 2022-06-24 03:05:28.812134
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['', 'a', 'b'])) == ['/', '/a', '/b']
    assert list(join_each('/a', ['', 'b', 'c'])) == \
        ['/a', '/a/b', '/a/c']



# Generated at 2022-06-24 03:05:32.775496
# Unit test for function join_each
def test_join_each():
    assert list(join_each("", [])) == []
    assert list(join_each("", ["/"])) == ["/"]
    assert list(join_each("/", ["/"])) == ["//"]
    assert list(join_each("/", [""])) == ["/"]
    assert list(join_each("/", ["", "/"])) == ["/", "//"]
    assert list(join_each("/root", ["a", "b"])) == ["/root/a", "/root/b"]

# Generated at 2022-06-24 03:05:38.182715
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['home', 'user', 'documents'])) == [
        '/home', '/user', '/documents']
    assert list(join_each('/home', ['user', 'documents'])) == [
        '/home/user', '/home/documents']



# Generated at 2022-06-24 03:05:41.699493
# Unit test for function join_each
def test_join_each():
    input_values = ('a', 'bb', 'ccc')
    expected_results = ('/a', '/bb', '/ccc')
    actual_results = list(join_each('/', input_values))
    assert actual_results == expected_results



# Generated at 2022-06-24 03:05:49.392433
# Unit test for function join_each
def test_join_each():
    parent = "parent"

    # Empty iterable case
    assert [] == list(join_each(parent, []))

    # Non-empty iterable case
    iterable = [os.path.sep + "child1", os.path.sep + "child2"]
    assert [os.path.join(parent, os.path.sep + "child1"), os.path.join(parent, os.path.sep + "child2")] == list(
        join_each(parent, iterable))



# Generated at 2022-06-24 03:05:52.267403
# Unit test for function join_each
def test_join_each():
    parent = '/tmp/'
    iterable = ['a', 'b', 'c']
    expected = ['/tmp/a', '/tmp/b', '/tmp/c']
    result = list(join_each(parent, iterable))
    assert result == expected

# Generated at 2022-06-24 03:05:58.369936
# Unit test for function join_each
def test_join_each():
    parent = '/home/user'
    iterable = ('dir1', 'dir2', 'dir3')
    print('parent = {}, iterable = {}'.format(parent, iterable))
    print('parent = {}, iterable = {}'.format(parent, list(iterable)))
    for p in join_each(parent, iterable):
        print(p)


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:06:01.907769
# Unit test for function join_each
def test_join_each():
    parent = '/bin'
    iterable = ['ls', 'cd']
    expected = ['/bin/ls', '/bin/cd']

    result = join_each(parent, iterable)
    assert expected == list(result)



# Generated at 2022-06-24 03:06:04.505813
# Unit test for function join_each
def test_join_each():
    parent = '.'
    children = ['a', 'b', 'c', 'd']
    assert list(join_each(parent, children)) == ['./a', './b', './c', './d']



# Generated at 2022-06-24 03:06:06.945045
# Unit test for function join_each
def test_join_each():
    assert list(join_each('./', ['a', 'b'])) == ['./a', './b']



# Generated at 2022-06-24 03:06:10.376483
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/usr/bin', [None, 'python', 'python2.7']))
    assert len(result) == 3
    assert result[0] == '/usr/bin'
    assert result[1] == '/usr/bin/python'
    assert result[2] == '/usr/bin/python2.7'



# Generated at 2022-06-24 03:06:14.927568
# Unit test for function join_each
def test_join_each():

    # Scenario: Join the path to each file in a list of files
    # Given a collection of files
    FILES = ['file1.txt', 'file2.txt', 'file3.txt']

    # When I join each file to a path
    RESULT = join_each('/tmp', FILES)

    # Then I expect it to work
    assert RESULT == [
        '/tmp/file1.txt',
        '/tmp/file2.txt',
        '/tmp/file3.txt',
    ]



# Generated at 2022-06-24 03:06:15.979780
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each("foo", ("bar", "baz"))) == ('foo/bar', 'foo/baz')



# Generated at 2022-06-24 03:06:17.921758
# Unit test for function join_each
def test_join_each():
    # Case 1
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']

    # Case 2
    assert list(join_each('/a/', ['b', 'c'])) == ['/a/b', '/a/c']

# Generated at 2022-06-24 03:06:19.945178
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    iterable = iter(['a.txt', 'b.txt', 'c.txt'])
    actual = join_each(parent, iterable)
    expected = ['/home/a.txt', '/home/b.txt', '/home/c.txt']
    assert list(actual) == expected

# Generated at 2022-06-24 03:06:24.882962
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/hello', ['a', 'b', 'c'])) == [
        '/hello/a',
        '/hello/b',
        '/hello/c'
    ]



# Generated at 2022-06-24 03:06:29.627468
# Unit test for function join_each
def test_join_each():
    result = map(partial(os.path.join, 'path'), ['a', 'b', 'c'])

    assert list(join_each('path', ('a', 'b', 'c'))) == list(result)

# Exercise

# Generated at 2022-06-24 03:06:32.082731
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('nowhere', ('there', 'here', 'everywhere'))) == \
           ('nowhere/there', 'nowhere/here', 'nowhere/everywhere')

# Generated at 2022-06-24 03:06:37.386182
# Unit test for function join_each
def test_join_each():
    parent = 'file'
    child1 = '1'
    child2 = '2'
    child3 = '3'
    child = [child1, child2, child3]

    assert list(join_each(parent, child)) == [parent + os.sep + child1,
                                              parent + os.sep + child2,
                                              parent + os.sep + child3]



# Generated at 2022-06-24 03:06:41.422973
# Unit test for function join_each
def test_join_each():
    # Set up fixture
    target = join_each(r'c:\my\parent', ['a', 'b', 'c'])

    # Exercise the function
    actual = next(target)

    # Verify the result
    expected = r'c:\my\parent\a'
    assert actual == expected

    # Clean up


# Test fixture

# Generated at 2022-06-24 03:06:48.556883
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    iterable = ('user1', 'user2', 'user3')
    paths = ('/home/user1', '/home/user2', '/home/user3')
    assert list(join_each(parent, iterable)) == paths


# Main function
if __name__ == '__main__':
    parent = '/home'
    users = ('user1', 'user2', 'user3')
    for path in join_each(parent, users):
        print(path)

# Generated at 2022-06-24 03:06:52.614197
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/foo/bar", ["baz", "dog"])) == \
        ["/foo/bar/baz", "/foo/bar/dog"]
    assert list(join_each('/home/dev', ['.vim', '.bashrc'])) == \
        ['/home/dev/.vim', '/home/dev/.bashrc']



# Generated at 2022-06-24 03:06:54.649124
# Unit test for function join_each
def test_join_each():
    assert list(join_each(r'C:\Users', [r'Alice', 'Bob\Carol'])) == \
        [r'C:\Users\Alice', r'C:\Users\Bob\Carol']

# Generated at 2022-06-24 03:07:00.207218
# Unit test for function join_each
def test_join_each():
    parent = os.path.dirname(__file__)
    assert os.path.join(parent, 'test.txt') in join_each(parent, ['test.txt'])
    assert os.path.join(parent, 'test.txt') in join_each(parent, ['test.txt', 'test2.txt'])



# Generated at 2022-06-24 03:07:08.550953
# Unit test for function join_each
def test_join_each():
    assert ['e:/r_c', 'e:/r_c/a', 'e:/r_c/b', 'e:/r_c/c'] == list(join_each('e:/r_c', 'abc'))
    assert ['e:/r_c/a', 'e:/r_c/b', 'e:/r_c/c'] == list(join_each('e:/r_c', 'abc', 'a'))
    assert ['e:/r_c/a', 'e:/r_c/b', 'e:/r_c/c'] == list(join_each('e:/r_c', 'abc', ''))

# Generated at 2022-06-24 03:07:10.857890
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/local', ['bin', 'lib'])) == [
        '/usr/local/bin',
        '/usr/local/lib'
    ]



# Generated at 2022-06-24 03:07:12.388803
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/foo", ["bar", "baz"])) == ["/foo/bar", "/foo/baz"]

# Generated at 2022-06-24 03:07:14.278997
# Unit test for function join_each
def test_join_each():
    result = list(join_each('s', 'ab'))
    assert [os.path.join('s', 'a'), os.path.join('s', 'b')] == result


# -----------------------------------------------------------------------------

# Generated at 2022-06-24 03:07:16.294887
# Unit test for function join_each
def test_join_each():
    parts = ['dir1', 'dir2', 'dir3', 'dir4']
    joined = list(join_each('/', parts))
    for i in range(len(parts)):
        assert joined[i] == os.path.join('/', parts[i])

# Generated at 2022-06-24 03:07:20.059806
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:07:23.713026
# Unit test for function join_each
def test_join_each():
    parent = 'c:\\'
    children = ['dir_1', 'dir_2', 'dir_3']
    expected = [
        'c:\\dir_1',
        'c:\\dir_2',
        'c:\\dir_3'
    ]
    result = list(join_each(parent, children))
    assert result == expected



# Generated at 2022-06-24 03:07:27.776484
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/path/to/', ['foo', 'bar', 'baz'])) == [
        '/path/to/foo', '/path/to/bar', '/path/to/baz'
    ]



# Generated at 2022-06-24 03:07:28.892735
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('/usr/local', ['bin', 'lib'])) ==
           ['/usr/local/bin', '/usr/local/lib'])



# Generated at 2022-06-24 03:07:33.231550
# Unit test for function join_each
def test_join_each():
    parent = r'C:\Users'
    iterable = ['user1', 'user2', 'user3']
    joined = list(join_each(parent, iterable))
    expected = [r'C:\Users\user1', r'C:\Users\user2', r'C:\Users\user3']
    assert joined == expected



# Generated at 2022-06-24 03:07:37.549822
# Unit test for function join_each
def test_join_each():
    assert join_each('/', ['dir1', 'dir2', 'dir3']) == \
           [os.path.join('/', 'dir1'), os.path.join('/', 'dir2'),
            os.path.join('/', 'dir3')]



# Generated at 2022-06-24 03:07:49.258388
# Unit test for function join_each
def test_join_each():
    examples = [
        (["/one/outside", "/one/inside", "/one/other/"], "/one", ["inside", "other"], ["inside", "other"]),
        (["/one/outside", "/one/inside", "/one/other/"], "/", ["one", "inside", "other"],
         ["/one", "/inside", "/other"]),
        (["/one/outside", "/one/inside", "/one/other/", "/one/other/something"], "/one", ["other"], ["other"]),
    ]
    for files, parent, children, expected in examples:
        assert list(join_each(parent, children)) == list(expected)


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-24 03:07:54.650710
# Unit test for function join_each
def test_join_each():
    assert ["a/b", "a/c", "a/d"] == list(join_each("a", ["b", "c", "d"]))



# Generated at 2022-06-24 03:08:02.330699
# Unit test for function join_each
def test_join_each():
    parent = "mama"
    iterator = ["mia", "mia", "ohhh"]
    # join_iter = join_each(parent, iterator)
    assert list(join_each(parent, iterator)) == [os.path.join(parent, "mia"), os.path.join(parent, "mia"), os.path.join(parent, "ohhh")]
    # assert list(join_iter) == ["mama/mia", "mama/mia", "mama/ohhh"]
    # assert join_iter == ["mama/mia", "mama/mia", "mama/ohhh"]

# Generated at 2022-06-24 03:08:04.295214
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a\\b', 'a\\c']



# Generated at 2022-06-24 03:08:07.045368
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == [
        '/tmp/a',
        '/tmp/b',
        '/tmp/c',
    ]



# Generated at 2022-06-24 03:08:15.048658
# Unit test for function join_each
def test_join_each():
    assert (list(join_each('/a/b', ('x', 'y', 'z'))) ==
            ['/a/b/x', '/a/b/y', '/a/b/z'])
    # Test if it works with relative paths.
    assert (list(join_each('a/b', ('x', 'y', 'z'))) ==
            ['a/b/x', 'a/b/y', 'a/b/z'])



# Generated at 2022-06-24 03:08:22.674072
# Unit test for function join_each
def test_join_each():
    assert [x for x in join_each('', ['a', 'b'])] == ['a', 'b']
    assert [x for x in join_each('a', ['b', 'c'])] == ['a' + os.sep + 'b', 'a' + os.sep + 'c']
    assert [x for x in join_each('a/b', ['c', 'd'])] == ['a/b' + os.sep + 'c', 'a/b' + os.sep + 'd']



# Generated at 2022-06-24 03:08:26.692479
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', 'bc')) == ['a/b', 'a/c']
    assert list(join_each('', 'ab')) == ['/a', '/b']
    assert list(join_each('a/b', 'c')) == ['a/b/c']
    assert list(join_each('', '')) == []
    assert list(join_each('a/', '')) == []



# Generated at 2022-06-24 03:08:28.855209
# Unit test for function join_each
def test_join_each():
    test_join_each.__test__ = False
    parent = os.path.realpath(__file__)  # this file
    iterable = ('..', '..', '..')
    assert list(join_each(parent, iterable)) == [
        os.path.join(parent, '..', '..', '..')
    ]



# Generated at 2022-06-24 03:08:32.581639
# Unit test for function join_each
def test_join_each():
    assert list(join_each(".", "hello")) \
        == ["./hello"]
    assert list(join_each(".", ["hello"])) \
        == ["./hello"]
    assert list(join_each(".", ["hello", "world"])) \
        == ["./hello", "./world"]



# Generated at 2022-06-24 03:08:33.568557
# Unit test for function join_each
def test_join_each():
    assert list(join_each('test', ['1', '2'])) == ['test\\1', 'test\\2']

# Generated at 2022-06-24 03:08:36.807116
# Unit test for function join_each
def test_join_each():
    parent = '/'
    dirs = ['foo', 'bar', 'baz']
    paths = join_each(parent, dirs)
    assert isinstance(paths, Iterator)
    assert list(paths) == [os.path.join(parent, dir) for dir in dirs]



# Generated at 2022-06-24 03:08:40.462574
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["usr", "bin", "local"])) == [
        "/home/usr",
        "/home/bin",
        "/home/local",
    ]



# Generated at 2022-06-24 03:08:43.373509
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == [
        '/a', '/b']



# Generated at 2022-06-24 03:08:48.835206
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['path1', 'path2']
    res = list(join_each(parent, iterable))

# Generated at 2022-06-24 03:08:51.413860
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:08:52.983494
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['etc', 'tmp'])) == ['/etc', '/tmp']



# Generated at 2022-06-24 03:08:58.011734
# Unit test for function join_each
def test_join_each():
    iterable = ["a", "b"]
    actual = list(join_each("prefix", iterable))
    expected = ["prefix/a", "prefix/b"]
    try:
        assert actual == expected
    except AssertionError:
        print("Expected:\n\t{}\nActual:\n\t{}".format(expected, actual))
    else:
        print("Success!")


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:09:00.102897
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/local', ['etc', 'bin', 'lib'])) == ['/usr/local/etc', '/usr/local/bin', '/usr/local/lib']



# Generated at 2022-06-24 03:09:05.626621
# Unit test for function join_each
def test_join_each():
    assert list(join_each('world', ['hello', 'python'])) == [os.path.join('world', 'hello'),
                                                             os.path.join('world', 'python')]



# Generated at 2022-06-24 03:09:09.954000
# Unit test for function join_each
def test_join_each():
    parent = 'foo'
    children = [
        'bar',
        'baz'
    ]
    expected = [
        'foo/bar',
        'foo/baz'
    ]
    actual = [
        x for x in join_each(parent, children)
    ]
    assert expected == actual

# Generated at 2022-06-24 03:09:13.263548
# Unit test for function join_each
def test_join_each():
    assert list(join_each(
        '/tmp', ['a', 'b', 'c'])) == [
            '/tmp/a',
            '/tmp/b',
            '/tmp/c'
        ]



# Generated at 2022-06-24 03:09:18.420274
# Unit test for function join_each
def test_join_each():
    r = list(join_each('/', ['usr', 'local', 'bin']))
    assert len(r) == 3
    assert r == ['/usr', '/local', '/bin']

# Generated at 2022-06-24 03:09:22.872282
# Unit test for function join_each
def test_join_each():

    cwd = os.getcwd()
    dirs = list(join_each(cwd, os.listdir(cwd)))
    assert len(dirs) == len(os.listdir(cwd))

    for d in dirs:
        assert os.path.exists(d)



# Generated at 2022-06-24 03:09:27.179025
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["a", "b/c/d", "e.f/g.h/i.j"])) == \
        ["/home/a", "/home/b/c/d", "/home/e.f/g.h/i.j"]



# Generated at 2022-06-24 03:09:30.385075
# Unit test for function join_each
def test_join_each():
    paths = join_each('foo', ['bar', 'baz'])
    assert paths[0] == 'foo/bar'
    assert paths[1] == 'foo/baz'



# Generated at 2022-06-24 03:09:32.722822
# Unit test for function join_each
def test_join_each():
    assert list(join_each(os.path.sep, [os.path.sep, 'var'])) == os.path.join(os.path.sep, os.path.sep), os.path.join(os.path.sep, 'var')

# Generated at 2022-06-24 03:09:34.308333
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/root", ["file1", "file2"])) == ["/root/file1",
                                                           "/root/file2"]

# Generated at 2022-06-24 03:09:37.201869
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a', [])) == []



# Generated at 2022-06-24 03:09:41.626384
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/a', ['b', None, 'c'])) == ['/a/b', '/a/c']
    assert list(join_each('/a', [])) == []



# Generated at 2022-06-24 03:09:44.428131
# Unit test for function join_each
def test_join_each():
    assert list(join_each("ab", [ "cd", "ef" ])) == [ "ab/cd", "ab/ef" ]
    assert list(join_each("abcd", [ ])) == [ ]



# Generated at 2022-06-24 03:09:45.663271
# Unit test for function join_each
def test_join_each():
    print(list(join_each('/var', ['bin', 'lib'])))



# Generated at 2022-06-24 03:09:47.526078
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', ['one', 'two', 'three'])) == ['/home/user/one', '/home/user/two', '/home/user/three']
    assert list(join_each('/home/user', [])) == []



# Generated at 2022-06-24 03:09:49.340750
# Unit test for function join_each
def test_join_each():
    assert ([os.path.join(parent, p) for p in iterable] ==
            list(join_each(parent, iterable)))


# Generator function displaying function join_each

# Generated at 2022-06-24 03:09:54.612453
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['bin', 'local', 'share'])) == [
        '/usr/bin',
        '/usr/local',
        '/usr/share',
    ]



# Generated at 2022-06-24 03:09:59.274332
# Unit test for function join_each
def test_join_each():
    assert [i for i in join_each('tester', 'abc')] == ['tester/a', 'tester/b', 'tester/c']



# Generated at 2022-06-24 03:10:04.846418
# Unit test for function join_each
def test_join_each():
    parent = '/a/b/c'
    iterable = '1', '2/3', '4/5/6'
    expected = ['/a/b/c/1', '/a/b/c/2/3', '/a/b/c/4/5/6']
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:10:06.785655
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ('user', 'kiptechie'))) == [
        '/home/user', '/home/kiptechie']



# Generated at 2022-06-24 03:10:09.210602
# Unit test for function join_each
def test_join_each():
    assert join_each("folder", ['file1', 'file2']) == [
        os.path.join("folder", 'file1'),
        os.path.join("folder", 'file2')
    ]



# Generated at 2022-06-24 03:10:13.139368
# Unit test for function join_each
def test_join_each():
    parent = "parent/path"
    child = "child/path"

    assert list(join_each(parent, [child])) == [os.path.join(parent, child)]
    assert list(join_each(parent, [])) == []

# Generated at 2022-06-24 03:10:21.378016
# Unit test for function join_each
def test_join_each():
    iterable = ['/dir/file1', '/dir/file2', '/dir/file3']
    parent = '/dir'
    new_list = []
    for p in iterable:
        new_list.append(join_each(parent, p))
    assert new_list == ['/dir/dir/file1', '/dir/dir/file2', '/dir/dir/file3']



# Generated at 2022-06-24 03:10:26.015893
# Unit test for function join_each
def test_join_each():
    parent = r'C:\Users\User\Documents'
    childs = ['test.ps1', 'test.py']
    assert list(join_each(parent, childs)) == [r'C:\Users\User\Documents\test.ps1',
                                              r'C:\Users\User\Documents\test.py']


# Python's default implementation of the glob function will work if the path is
# a directory. This function will, however, return an empty list if the path is not
# a directory. This function will instead return a list containing only the single
# path itself if it is not a directory, but still return a list of files within
# a directory if the path is a directory

# Generated at 2022-06-24 03:10:28.541000
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']



# Generated at 2022-06-24 03:10:32.488972
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    iterable = ['a', 'b', 'c']
    expected = ['/tmp/a', '/tmp/b', '/tmp/c']
    actual = list(join_each(parent, iterable))
    assert expected == actual, 'Bad join_each() result'



# Generated at 2022-06-24 03:10:35.186124
# Unit test for function join_each
def test_join_each():
    # Set up test data

    # Execute function
    test_data = join_each('/home', ['fo', 'bar'])

    # Asserts
    assert test_data == ['/home/fo', '/home/bar']



# Generated at 2022-06-24 03:10:37.426821
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    iterable = ['file1', 'file2']
    assert list(join_each(parent, iterable)) == ['/tmp/file1', '/tmp/file2']



# Generated at 2022-06-24 03:10:44.136232
# Unit test for function join_each
def test_join_each():
    parent = os.path.join('path', 'to', 'python')

    # join_each can also be used with a list comprehension
    # to create a list
    p_list = list(join_each(parent, ['python', 'scripts', 'pyz']))
    assert p_list == [os.path.join(parent, 'python'),
                      os.path.join(parent, 'scripts'),
                      os.path.join(parent, 'pyz')]

# Generated at 2022-06-24 03:10:55.068046
# Unit test for function join_each
def test_join_each():
    pass


if __name__ == "__main__":
    # Put test code here
    pass

# Generated at 2022-06-24 03:10:57.097363
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a\\b', 'a\\c']



# Generated at 2022-06-24 03:10:59.295389
# Unit test for function join_each
def test_join_each():

    parent = os.getcwd()

    for p in join_each(parent, ['.', '..']):
        if p == '.':
            assert p == parent
        else:
            assert p == os.path.split(parent)[0]



# Generated at 2022-06-24 03:11:00.787834
# Unit test for function join_each
def test_join_each():
    assert tuple(
        join_each("/home", ("me", "you", "others"))
    ) == ("/home/me", "/home/you", "/home/others")



# Generated at 2022-06-24 03:11:07.284106
# Unit test for function join_each
def test_join_each():
    parent = '/usr/local'
    iterable = ['bin', 'lib', 'libexec', 'sbin', 'share']
    tests = [
        '/usr/local/bin',
        '/usr/local/lib',
        '/usr/local/libexec',
        '/usr/local/sbin',
        '/usr/local/share',
    ]
    assert list(join_each(parent, iterable)) == tests



# Generated at 2022-06-24 03:11:09.133612
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/bin', ['a', 'b', 'c'])) == [
        '/usr/bin/a', '/usr/bin/b', '/usr/bin/c']



# Generated at 2022-06-24 03:11:18.686218
# Unit test for function join_each
def test_join_each():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    assert list(join_each("", ["foo", "bar"])) == ["foo", "bar"]
    # Use file name "test" to show that join_each works for relative paths
    assert list(join_each("", ["test", "test1", "test2"])) == [
        "test",
        "test1",
        "test2",
    ]
    assert list(join_each(current_dir, ["test", "test1", "test2"])) == [
        os.path.join(current_dir, "test"),
        os.path.join(current_dir, "test1"),
        os.path.join(current_dir, "test2"),
    ]

# Generated at 2022-06-24 03:11:20.480419
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each("/tmp", ["foo", "bar", "baz"])) == \
           ("/tmp/foo", "/tmp/bar", "/tmp/baz")



# Generated at 2022-06-24 03:11:26.518600
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    res = join_each('dir', iterable)
    expected = [os.path.join('dir', 'a'), os.path.join('dir', 'b'), os.path.join('dir', 'c')]
    assert list(res) == expected



# Generated at 2022-06-24 03:11:30.412055
# Unit test for function join_each
def test_join_each():
    assert list(join_each(
        "parent", ["child", "child2"])) == ["parent/child", "parent/child2"]



# Generated at 2022-06-24 03:11:36.121658
# Unit test for function join_each
def test_join_each():
    parent = "./data"
    childs = ["data.yaml", "data.csv"]

    result = join_each(parent, childs)

    for test in result:
        name = test.split('/')[-1]
        if name not in childs:
            raise AssertionError(
                f"Resulting value '{name}' is not in original list"
            )


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-24 03:11:36.964227
# Unit test for function join_each
def test_join_each():
    assert list(join_each(
        '/', ['var', 'lib'])) == ['/var', '/lib']

# Generated at 2022-06-24 03:11:38.133249
# Unit test for function join_each
def test_join_each():
    # Silly test, just to check that it works
    assert list(join_each("home", ["user", "bin"])) == ["home/user", "home/bin"]



# Generated at 2022-06-24 03:11:43.363405
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']


# Returns a string which is the given path after replacing all backslashes
# with forward slashes.

# Generated at 2022-06-24 03:11:49.067065
# Unit test for function join_each
def test_join_each():
    parent = "C:\\Users"
    iterable = ["Peter", "Katie", "Marisa"]
    expected = ["C:\\Users\\Peter", "C:\\Users\\Katie", "C:\\Users\\Marisa"]
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:11:54.608365
# Unit test for function join_each
def test_join_each():
    parent = '/usr/lib'
    path_list = ['libc.so', 'libmagic.so']
    expected_list = ['/usr/lib/libc.so', '/usr/lib/libmagic.so']
    actual_list = list(join_each(parent, path_list))
    assert actual_list == expected_list

# Generated at 2022-06-24 03:11:57.346326
# Unit test for function join_each
def test_join_each():
    p = os.path.dirname(__file__)
    assert ("tests/test_os.py" == next(join_each(p, ("tests", "test_os.py"))))
    assert ("tests/test_utils.py" == next(
        join_each(p, ("tests", "test_utils.py"))))

# Generated at 2022-06-24 03:11:59.190067
# Unit test for function join_each

# Generated at 2022-06-24 03:12:04.320536
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b', 'c'])) == \
           ['parent/a', 'parent/b', 'parent/c']

# Generated at 2022-06-24 03:12:08.527981
# Unit test for function join_each
def test_join_each():
    test_dir = "path/to/dir"
    filename = "filename"
    full_path = os.path.join(test_dir, filename)

    assert next(join_each(test_dir, [filename])) == full_path

# Generated at 2022-06-24 03:12:10.172888
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/abc', ['a', 'b'])) == ['/abc/a', '/abc/b']

# Generated at 2022-06-24 03:12:18.494480
# Unit test for function join_each
def test_join_each():
    test_set = [
        ((1, [1, 2, 3]), [os.path.join(1, 1), os.path.join(1, 2), os.path.join(1, 3)]),
        ((2, ['a', 'b']), [os.path.join(2, 'a'), os.path.join(2, 'b')]),
        ((3, [1, 'a']), [os.path.join(3, 1), os.path.join(3, 'a')]),
    ]

    for test_pair in test_set:
        assert list(join_each(*test_pair[0])) == test_pair[1]



# Generated at 2022-06-24 03:12:21.224729
# Unit test for function join_each
def test_join_each():
    assert list(join_each('c:\\Users\\Miao', ['foo', 'bar', 'baz'])) == [
               'c:\\Users\\Miao\\foo',
               'c:\\Users\\Miao\\bar',
               'c:\\Users\\Miao\\baz'
             ]



# Generated at 2022-06-24 03:12:24.540886
# Unit test for function join_each
def test_join_each():
    items = ['1', '2', '3']
    items_joined = list(join_each('parent', items))
    assert items_joined[0] == 'parent/1'
    assert items_joined[1] == 'parent/2'
    assert items_joined[2] == 'parent/3'


# Generated at 2022-06-24 03:12:30.760483
# Unit test for function join_each
def test_join_each():
    parent = '/home/bob'
    names = ('foo', 'bar', 'baz')
    result = list(join_each(parent, names))
    assert len(result) == 3
    assert result[0] == '/home/bob/foo'
    assert result[1] == '/home/bob/bar'
    assert result[2] == '/home/bob/baz'



# Generated at 2022-06-24 03:12:31.934666
# Unit test for function join_each
def test_join_each():
    parent = "foo"
    iterable = ["bar", "baz"]
    result = list(join_each(parent, iterable))
    assert result == ["foo/bar", "foo/baz"]



# Generated at 2022-06-24 03:12:38.248746
# Unit test for function join_each
def test_join_each():
    parent = "./"
    assert list(join_each(parent, ["child"])) == [os.path.join(parent, "child")]
    assert list(join_each(parent, ["child1", "child2"])) == [os.path.join(parent, "child1"),
                                                            os.path.join(parent, "child2")]

# Generated at 2022-06-24 03:12:41.848224
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/c', ['d', 'e'])) == ['/a/b/c/d', '/a/b/c/e']
    assert list(join_each('/a/b/c', [])) == []
    assert list(join_each('/a/b/c', None)) == []



# Generated at 2022-06-24 03:12:47.675508
# Unit test for function join_each
def test_join_each():
    p = "parent"
    iterable = ["child1", "child2", "child3"]
    expected = ["parent/child1",
                "parent/child2",
                "parent/child3"]
    actual = list(join_each(p, iterable))
    assert actual == expected



# Generated at 2022-06-24 03:12:53.633270
# Unit test for function join_each
def test_join_each():
    expected = ['/a', '/a/b', '/a/b/c']
    result = list(join_each('/a', ['.', 'b', 'b/c']))
    assert result == expected


# Test case for python -m doctest -v doctests.py

# Generated at 2022-06-24 03:12:56.969196
# Unit test for function join_each
def test_join_each():
    parent = 'foo'
    iterable = ['a', 'b', 'c']
    # Check that subsequent calls to join_each yield the same results
    assert(list(join_each(parent, iterable)) == list(join_each(parent, iterable)))



# Generated at 2022-06-24 03:12:58.898061
# Unit test for function join_each
def test_join_each():
    actual = list(join_each("dir", ["one", "two", "three"]))
    expected = ["dir/one", "dir/two", "dir/three"]
    assert actual == expected

# Generated at 2022-06-24 03:13:09.365308
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/src', ['/dst/1', 'dst/2'])) == ['/src/dst/1', '/src/dst/2']
    assert list(join_each('/src', ['dst/1', 'dst/2'])) == ['/src/dst/1', '/src/dst/2']
    assert list(join_each('/src/', ['/dst/1', 'dst/2'])) == ['/src/dst/1', '/src/dst/2']
    assert list(join_each('/src/', ['dst/1', 'dst/2'])) == ['/src/dst/1', '/src/dst/2']
    assert list(join_each('/src', [])) == []

# Generated at 2022-06-24 03:13:12.217811
# Unit test for function join_each
def test_join_each():
    parent = "one"
    iterable = ["two", "three"]
    expected = ["one/two", "one/three"]
    res = list(join_each(parent, iterable))
    assert res == expected



# Generated at 2022-06-24 03:13:16.397799
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []


# Given

# Generated at 2022-06-24 03:13:27.841015
# Unit test for function join_each
def test_join_each():
    dirname = os.path.dirname
    join = os.path.join
    def test(*args, **kwargs):
        pass

    # Simple case, single level
    result = list(join_each("/a/b/c", ("x", "y")))
    expected = ["/a/b/c/x", "/a/b/c/y"]
    assert result == expected

    # Nested dir, multiple items
    result = list(join_each("/d", ["x", "/a/b/c/y"]))
    expected = ["/d/x", "/d/a/b/c/y"]
    assert result == expected

    # Nested dir, duplicated items
    result = list(join_each("/d", ["x", "/d/x"]))

# Generated at 2022-06-24 03:13:31.269641
# Unit test for function join_each
def test_join_each():
    assert ['./a/b', './a/c'] == list(join_each('./a', 'b c'.split()))



# Generated at 2022-06-24 03:13:37.465269
# Unit test for function join_each
def test_join_each():
    l = ['a', 'b', 'c']

    actual = list(join_each('d', l))
    expected = ['d/a', 'd/b', 'd/c']

    assert actual == expected

# ----------------------------
#
# ----------------------------



# Generated at 2022-06-24 03:13:42.046670
# Unit test for function join_each
def test_join_each():
    parent = "C:/Users"
    actual = [os.path.join(parent, x) for x in ["", "bar", "foo.txt"]]
    assert list(join_each(parent, ["", "bar", "foo.txt"])) == actual



# Generated at 2022-06-24 03:13:45.049752
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["foo", "bar"])) == [os.path.join("/tmp", "foo"), os.path.join("/tmp", "bar")]



# Generated at 2022-06-24 03:13:47.447774
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["foo.txt", "bar.txt"])) == [
        "/tmp/foo.txt",
        "/tmp/bar.txt",
    ]



# Generated at 2022-06-24 03:13:50.075303
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['bar', 'baz'])) == [
        '/foo/bar',
        '/foo/baz',
    ]

