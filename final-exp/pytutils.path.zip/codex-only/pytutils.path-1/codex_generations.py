

# Generated at 2022-06-24 03:03:50.664314
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == ['/tmp/a', '/tmp/b', '/tmp/c']


# Generator function

# Generated at 2022-06-24 03:03:52.503214
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["a", "b"])) == ["/a", "/b"]



# Generated at 2022-06-24 03:03:55.258825
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', [])) == []
    assert list(join_each('/tmp', ['another'])) == ['/tmp/another']
    assert list(join_each('/tmp', ['another', 'dir'])) == ['/tmp/another', '/tmp/dir']



# Generated at 2022-06-24 03:03:57.506742
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/tmp', ['foo', 'bar', 'baz'])) == (
        '/tmp/foo', '/tmp/bar', '/tmp/baz')



# Generated at 2022-06-24 03:03:59.443804
# Unit test for function join_each
def test_join_each():
    iterator = join_each("/", "ABC")
    next(iterator)
    next(iterator)
    assert "/" + "C" == next(iterator)



# Generated at 2022-06-24 03:04:03.553361
# Unit test for function join_each
def test_join_each():
    iterable = ["a", "b", "c"]
    expected = ["f:/a", "f:/b", "f:/c"]
    assert list(join_each("f:/", iterable)) == expected


test_join_each()

# generator can be chained
# breadth-first search

# Generated at 2022-06-24 03:04:07.152481
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', ['passwd', 'group'])) == ['/etc/passwd', '/etc/group']



# Generated at 2022-06-24 03:04:14.997692
# Unit test for function join_each
def test_join_each():
    cwd = os.getcwd()
    files = ['temp1.log', 'temp2.log']
    expected = ['%s/temp1.log' % cwd, '%s/temp2.log' % cwd]
    result = list(join_each(cwd, files))
    assert result == expected
    expected = ['%s/temp1.log' % cwd, '%s/temp2.log' % cwd, '%s/temp2.log' % cwd]
    result = list(join_each(cwd, files + files))
    assert result == expected
    dirs = ['logs', 'temp']
    expected = ['%s/logs' % cwd, '%s/temp' % cwd]
    result = list(join_each(cwd, dirs))

# Generated at 2022-06-24 03:04:18.038093
# Unit test for function join_each
def test_join_each():
    p = "a"
    i = ["b", "c", "d"]
    expected = ["a/b", "a/c", "a/d"]
    assert list(join_each(p, i)) == expected



# Generated at 2022-06-24 03:04:21.015782
# Unit test for function join_each
def test_join_each():
    "Unit tests for function join_each"
    result = list(join_each('/foo', ['bar', 'baz']))
    expected = ['/foo/bar', '/foo/baz']
    assert result == expected



# Generated at 2022-06-24 03:04:23.048423
# Unit test for function join_each
def test_join_each():
    actual = list(join_each("/", ["a", "b"]))
    assert actual == ["/a", "/b"]



# Generated at 2022-06-24 03:04:29.053772
# Unit test for function join_each
def test_join_each():
    # Arrange
    parent_test = 'parent_directory'
    dir_list = ['dir1', 'dir2', 'dir3']
    dir_fully_qualified = ['parent_directory/dir1',
                           'parent_directory/dir2', 'parent_directory/dir3']

    # Act
    result = list(join_each(parent_test, dir_list))

    # Assert
    assert result == dir_fully_qualified



# Generated at 2022-06-24 03:04:31.924474
# Unit test for function join_each
def test_join_each():
    p = "/path/to/something"
    assert list(join_each(p, ["1", "2", "3"])) == [
        os.path.join(p, "1"),
        os.path.join(p, "2"),
        os.path.join(p, "3"),
    ]



# Generated at 2022-06-24 03:04:38.942499
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['a', 'b', 'c'])) == ['a', 'b', 'c']
    assert list(join_each(os.sep + '', ['a', 'b', 'c'])) == [
        os.path.join(os.sep, 'a'),
        os.path.join(os.sep, 'b'),
        os.path.join(os.sep, 'c')
    ]



# Generated at 2022-06-24 03:04:41.133835
# Unit test for function join_each
def test_join_each():
    assert list(join_each(
            'foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']


# TODO(pebaz): Not sure if this function is needed anymore

# Generated at 2022-06-24 03:04:44.513175
# Unit test for function join_each
def test_join_each():
    test_cases = [
        (
            ("/foo/bar", ["baz", "qux", "quux"]),
            ['/foo/bar/baz', '/foo/bar/qux', '/foo/bar/quux'],
        ),
    ]

    for test_case in test_cases:
        actual = join_each(*test_case[0])
        assert list(actual) == test_case[1]


# Generated at 2022-06-24 03:04:47.649070
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/root', ['a', 'b', 'c'])) == ['/root/a', '/root/b', '/root/c']
    assert list(join_each('/root', [])) == []

# Generated at 2022-06-24 03:04:51.738511
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ('bar', 'baz'))) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:04:53.906404
# Unit test for function join_each
def test_join_each():
    joined = list(join_each('/tmp', ['a', 'b']))
    assert joined == ['/tmp/a', '/tmp/b']

# Generated at 2022-06-24 03:04:58.354383
# Unit test for function join_each
def test_join_each():
    tests = [
        [
            'a',
            ['b', 'c', 'd'],
            ['a/b', 'a/c', 'a/d']
        ]
    ]

    for (p, it, expected) in tests:
        got = list(join_each(p, it))
        assert got == expected



# Generated at 2022-06-24 03:05:02.155451
# Unit test for function join_each
def test_join_each():
    parent = '/tmp/a'
    iterable = ('b', 'c', 'd')
    expected = ('/tmp/a/b', '/tmp/a/c', '/tmp/a/d')

    assert tuple(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:05:07.472083
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/pi", ["Downloads", "foo", "bar"])) == \
        ['/home/pi/Downloads', '/home/pi/foo', '/home/pi/bar']



# Generated at 2022-06-24 03:05:14.234402
# Unit test for function join_each
def test_join_each():
    # GIVEN
    parent = os.path.join("path", "to", "parent")
    iterable = ["file1.txt", "file2.txt", "file3.txt"]

    # WHEN
    actual = list(join_each(parent, iterable))

    # THEN
    expected = [
        os.path.join(parent, "file1.txt"),
        os.path.join(parent, "file2.txt"),
        os.path.join(parent, "file3.txt"),
    ]
    assert expected == actual

# Generated at 2022-06-24 03:05:18.362072
# Unit test for function join_each
def test_join_each():
    path = '/opt/data'
    files = ['path1', 'path2', 'path3']
    path_iter = join_each(path, files)
    for i, path in enumerate(path_iter):
        assert path == os.path.join(path, files[i])


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:05:20.707182
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/etc", ["sysconfig/", "cron.d/"])) == [
        "/etc/sysconfig/",
        "/etc/cron.d/"
    ]



# Generated at 2022-06-24 03:05:24.194035
# Unit test for function join_each
def test_join_each():
    p = "/a/b"
    expected = [os.path.join(p, "c"), os.path.join("/a/b", "d")]
    actual = list(join_each(p, ["c", "d"]))
    assert expected == actual

# Generated at 2022-06-24 03:05:28.931470
# Unit test for function join_each
def test_join_each():
    func = join_each
    assert func('u', ('a', 'b')) == ('u/a', 'u/b')



# Generated at 2022-06-24 03:05:36.376445
# Unit test for function join_each
def test_join_each():
    assert list(join_each(None, None)) == []
    assert list(join_each(None, [])) == []
    assert list(join_each(None, [None])) == [None]
    assert list(join_each(None, [None, '2', 3])) == [None, '2', '3']
    assert list(join_each(None, ['1', '2', '3'])) == ['1', '2', '3']
    assert list(join_each('p', None)) == []
    assert list(join_each('p', [])) == []
    assert list(join_each('p', [None])) == ['p']
    assert list(join_each('p', [None, '2', 3])) == ['p', 'p/2', 'p/3']

# Generated at 2022-06-24 03:05:40.442193
# Unit test for function join_each
def test_join_each():
    sut = join_each('a', ('b', 'c'))
    assert next(sut) == 'a/b'
    assert next(sut) == 'a/c'
    try:
        next(sut)
        assert False, 'expected StopIteration'
    except StopIteration:
        pass



# Generated at 2022-06-24 03:05:42.040810
# Unit test for function join_each
def test_join_each():
    assert list(join_each(1, (2, 3, 4))) == [1, 2, 1, 3, 1, 4]



# Generated at 2022-06-24 03:05:45.679841
# Unit test for function join_each
def test_join_each():
    parent = '/home/juan'
    iterable = ['scott', 'tiger']
    expected_result = ['/home/juan/scott', '/home/juan/tiger']
    assert list(join_each(parent, iterable)) == expected_result



# Generated at 2022-06-24 03:05:50.047207
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-24 03:05:54.091559
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/a', ['b/c', 'd'])) == ['/a/b/c', '/a/d']
    assert list(join_each('/a/b', ['c', 'd'])) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-24 03:05:57.067706
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a', [])) == []



# Generated at 2022-06-24 03:06:02.555323
# Unit test for function join_each
def test_join_each():
    path = '.'
    filenames = [
        'tst.md',
        'tst.md',
        'tst.md'
    ]
    expected = [
        './tst.md',
        './tst.md',
        './tst.md'
    ]
    actual = list(join_each(path, filenames))
    assert actual == expected

# Generated at 2022-06-24 03:06:04.133484
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-24 03:06:07.771625
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/home/pi', ['bin', 'lib', 'local', 'share']))
    assert result == [
        '/home/pi/bin', '/home/pi/lib',
        '/home/pi/local', '/home/pi/share']



# Generated at 2022-06-24 03:06:09.420975
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]



# Generated at 2022-06-24 03:06:11.738372
# Unit test for function join_each
def test_join_each():
    assert list(join_each("parent", ["a", "b"])) == [
        "parent" + os.path.sep + "a",
        "parent" + os.path.sep + "b",
    ]

# Generated at 2022-06-24 03:06:16.342420
# Unit test for function join_each
def test_join_each():
    iterable = join_each('/usr/local', 'bin', 'lib', 'include')
    assert list(iterable) == [
        "/usr/local/bin", "/usr/local/lib", "/usr/local/include"
    ]

# Generated at 2022-06-24 03:06:25.696585
# Unit test for function join_each
def test_join_each():
    # Given
    parent = '/home/user'
    iterable = ['dir1', 'dir2', 'dir3']
    # When
    result = join_each(parent, iterable)
    # Then
    assert list(result) == ['/home/user/dir1', '/home/user/dir2', '/home/user/dir3']


# class TestLogin(unittest.TestCase):
#     # Test Case 1 : "login@fail"
#     def test_login_fail(self):
#         user = User('admin', 'admin')
#         self.assertFalse(user.login('root', 'admin'), False)
# 
#     # Test Case 2 : "login@success"
#     def test_login_success(self):
#         user = User('root', 'admin')
#         self.assert

# Generated at 2022-06-24 03:06:30.503702
# Unit test for function join_each
def test_join_each():
    assert list(join_each("parent", ["one", "two", "three"])) == [os.path.join("parent", "one"),
                                                                  os.path.join("parent", "two"),
                                                                  os.path.join("parent", "three")]



# Generated at 2022-06-24 03:06:32.935077
# Unit test for function join_each
def test_join_each():
    assert list(join_each('home', ['user', 'bin', 'bashrc'])) \
        == ['home/user', 'home/bin', 'home/bashrc']



# Generated at 2022-06-24 03:06:35.513375
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-24 03:06:40.344434
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']
    assert list(join_each('/a', [])) == []



# Generated at 2022-06-24 03:06:46.531021
# Unit test for function join_each
def test_join_each():
    parent = 'folder'
    child = ['file1.txt', 'file2.txt', 'file3.txt']
    assert join_each(parent, child) == ['folder/file1.txt', 'folder/file2.txt', 'folder/file3.txt']
    print('test_join_each ok')



# Generated at 2022-06-24 03:06:48.162376
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']

# Generated at 2022-06-24 03:06:50.551148
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/data/', ['.gitignore', '.gitkeep'])) == [
        '/data/.gitignore',
        '/data/.gitkeep',
    ]



# Generated at 2022-06-24 03:06:57.456170
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ('bar', 'baz'))) == ['foo/bar', 'foo/baz']
    assert list(join_each('foo/', ('bar', 'baz'))) == ['foo/bar', 'foo/baz']
    assert list(join_each('foo', ('/bar', '/baz'))) == ['foo/bar', 'foo/baz']
    assert list(join_each('/foo', ('/bar', '/baz'))) == ['/foo/bar', '/foo/baz']



# Generated at 2022-06-24 03:07:00.731478
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    paths = ['file1.txt', 'file2.txt', 'file3.txt']
    for want, got in zip(paths, join_each(parent, paths)):
        assert want == got



# Generated at 2022-06-24 03:07:02.075898
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-24 03:07:03.949530
# Unit test for function join_each
def test_join_each():
    actual = list(join_each('parent', ['a', 'b']))
    expected = ['parent/a', 'parent/b']
    assert actual == expected



# Generated at 2022-06-24 03:07:07.148978
# Unit test for function join_each
def test_join_each():
    li = ["foo", "bar", "baz"]
    assert list(join_each("~", li)) == [
        os.path.join("~", "foo"),
        os.path.join("~", "bar"),
        os.path.join("~", "baz")
    ]



# Generated at 2022-06-24 03:07:13.277242
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/x', ['a', 'b'])) == ['/x/a', '/x/b']



# Generated at 2022-06-24 03:07:14.837541
# Unit test for function join_each
def test_join_each():
    f = join_each("foo", ["bar", "baz"])
    assert next(f) == "foo/bar"
    assert next(f) == "foo/baz"

# Generated at 2022-06-24 03:07:20.040809
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/data', ['file1', 'file2'])) == ['/data/file1', '/data/file2']
    assert list(join_each('', ['file1', 'file2'])) == ['file1', 'file2']
    assert list(join_each('/data/', ['file1', 'file2'])) == ['/data/file1', '/data/file2']
    assert list(join_each('/data', [])) == []
    assert list(join_each('', [])) == []
    assert list(join_each('/', [])) == []
    assert list(join_each('/data', ['', 'file2'])) == ['/data/', '/data/file2']

# Generated at 2022-06-24 03:07:22.023352
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ('c', 'd'))) == ['a/c', 'a/d']
    assert list(join_each('a', [])) == []



# Generated at 2022-06-24 03:07:24.495755
# Unit test for function join_each
def test_join_each():
    assert list(
        join_each("/home", ["me", "him", "her", "us"])) == [
        "/home/me",
        "/home/him",
        "/home/her",
        "/home/us",
    ]



# Generated at 2022-06-24 03:07:30.558009
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/mehdi', ['usr', 'local'])) == ['/home/mehdi/usr', '/home/mehdi/local']

    # Test case when parent is not a string
    assert list(join_each(5, ['usr', 'local'])) == [5, 'usr', 5, 'local']

    # Test case when iterable is not iterable
    assert list(join_each('home/mehdi', 5)) == ['home/mehdi', 5]



# Generated at 2022-06-24 03:07:34.205880
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/pi/Desktop', ['foo', 'bar'])) == [
        '/home/pi/Desktop/foo', '/home/pi/Desktop/bar']
    assert list(join_each('/home/pi/Desktop/', ['foo', 'bar'])) == [
        '/home/pi/Desktop/foo', '/home/pi/Desktop/bar']
    assert list(join_each('/home/pi/Desktop', [])) == []

# Generated at 2022-06-24 03:07:36.332680
# Unit test for function join_each
def test_join_each():
    paths = list(join_each('/', ['home', 'work']))
    assert paths == ['/home', '/work']



# Generated at 2022-06-24 03:07:38.263570
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['home', 'Documents', 'Python'])) == [
        '/home', '/Documents', '/Python']



# Generated at 2022-06-24 03:07:44.952102
# Unit test for function join_each
def test_join_each():
    parent = "path/to/foo"
    iterable = ["bar", "quux"]
    output = join_each(parent, iterable)
    assert next(output) == os.path.join(parent, iterable[0])
    assert next(output) == os.path.join(parent, iterable[1])



# Generated at 2022-06-24 03:07:48.111622
# Unit test for function join_each
def test_join_each():
    parent = '/foo/bar'
    iterable = ['one', 'two', 'three']
    joined = join_each(parent, iterable)
    assert len(joined) == 3
    assert next(joined) == '/foo/bar/one'

# Generated at 2022-06-24 03:07:54.860050
# Unit test for function join_each
def test_join_each():
    paths = ["/usr/bin", "/usr/sbin", "/etc/sysconfig"]
    res = []
    for x in join_each("/etc", paths):
        res.append(x)
    assert res == ["/etc/usr/bin", "/etc/usr/sbin", "/etc/etc/sysconfig"]

# Generated at 2022-06-24 03:07:58.451422
# Unit test for function join_each
def test_join_each():
    i = join_each("a", ["b", "c", "d"])
    assert next(i) == "a/b"
    assert next(i) == "a/c"
    assert next(i) == "a/d"



# Generated at 2022-06-24 03:08:01.675869
# Unit test for function join_each
def test_join_each():
    expected = [
        os.path.join(parent, p)
        for p in iterable
    ]
    actual = [
        p
        for p in join_each(parent, iterable)
    ]
    assert expected == actual



# Generated at 2022-06-24 03:08:04.341726
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    path_list = [os.path.join('/', p) for p in iterable]
    assert list(join_each('/', iterable)) == path_list

# Generated at 2022-06-24 03:08:10.754961
# Unit test for function join_each
def test_join_each():
    p = "/foo/bar"

    joined_expected = [
        "/foo/bar/baz",
        "/foo/bar/buzz",
        "/foo/bar/fizz"
    ]

    joined_actual = join_each(p, ["baz", "buzz", "fizz"])

    assert list(joined_expected) == list(joined_actual)



# Generated at 2022-06-24 03:08:18.108136
# Unit test for function join_each
def test_join_each():
    root = os.path.join('a', 'b', 'c')
    paths = list(join_each(root, ['d', 'e', 'f']))
    assert paths[0] == os.path.join(root, 'd')
    assert paths[1] == os.path.join(root, 'e')
    assert paths[2] == os.path.join(root, 'f')



# Generated at 2022-06-24 03:08:20.000452
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['one', 'two', 'three']
    expected = ['parent/one', 'parent/two', 'parent/three']

    result = list(join_each(parent, iterable))
    assert result == expected, 'Expected %s, got %s' % (str(expected), str(result))

# Generated at 2022-06-24 03:08:26.113909
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']


# Read all files in a directory recursively, yielding full paths.

# Generated at 2022-06-24 03:08:30.149485
# Unit test for function join_each
def test_join_each():
    tests = [
        # (parent, iterable, expected)
        ('', [], []),
        ('/', ['a'], ['/a']),
        ('/', ['a', 'b'], ['/a', '/b']),
        ('a', ['b', 'c'], ['a/b', 'a/c']),
        ('a', ['b', 'c/d'], ['a/b', 'a/c/d']),
    ]
    for parent, iterable, expected in tests:
        assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:08:34.626197
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:08:37.132934
# Unit test for function join_each
def test_join_each():
    paths = join_each(os.getcwd(), ('.', '.', '..'))
    assert next(paths) == os.getcwd()
    # We can't just compare the iterator to a list because it is generated
    # using generators and would never end



# Generated at 2022-06-24 03:08:41.127977
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    p1 = 'p1'
    p2 = 'p2'

    assert [os.path.join(parent, p1), os.path.join(parent, p2)] == list(join_each(parent, [p1, p2]))



# Generated at 2022-06-24 03:08:43.410376
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/foo', ['bar', 'baz'])) == [
        '/home/foo/bar', '/home/foo/baz']



# Generated at 2022-06-24 03:08:48.833086
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a', [])) == []



# Generated at 2022-06-24 03:08:50.888959
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['usr', 'bin'])) == ['/usr', '/bin']



# Generated at 2022-06-24 03:08:52.982369
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('foo', ['bar', 'baz'])) == ('foo/bar', 'foo/baz')



# Generated at 2022-06-24 03:08:57.681949
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('root', {'a', 'b', 'c'})) == \
        tuple(os.path.join('root', x) for x in {'a', 'b', 'c'})
    assert tuple(join_each('', {'a', 'b', 'c'})) == \
        tuple(os.path.join('', x) for x in {'a', 'b', 'c'})

# Generated at 2022-06-24 03:09:00.433601
# Unit test for function join_each
def test_join_each():
    expected = ['/home/blah/foo.txt', '/home/blah/bar.txt', '/home/blah/baz.txt']
    actual = list(join_each('/home', ['foo.txt', 'bar.txt', 'baz.txt']))
    assert expected == actual



# Generated at 2022-06-24 03:09:02.401242
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['1', '2', '3']
    assert list(join_each(parent, iterable)) == ['parent/1', 'parent/2', 'parent/3']

# Generated at 2022-06-24 03:09:04.482511
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', 'bcd')) == ['a/b', 'a/c', 'a/d']
    assert list(join_each('a', 'b')) == ['a/b']
    assert list(join_each('a', [])) == []



# Generated at 2022-06-24 03:09:06.804316
# Unit test for function join_each
def test_join_each():
    expected = ['/tmp/a', '/tmp/b', '/tmp/c']
    assert(list(join_each('/tmp', 'abc')) == expected)



# Generated at 2022-06-24 03:09:11.715321
# Unit test for function join_each
def test_join_each():
    parent_path = '/home/foo/bar'
    paths = ['a', 'b', 'c']
    assert list(join_each(parent_path, paths)) == ['/home/foo/bar/a', '/home/foo/bar/b', '/home/foo/bar/c']



# Generated at 2022-06-24 03:09:17.177173
# Unit test for function join_each
def test_join_each():
    assert list(join_each('abc', ['123', '456'])) == ['abc123', 'abc456']
    assert list(join_each('/home/foo', ['.', '..', 'd', '/', 'file'])) == \
        ['/home/foo', '/home', '/home/foo/d', '/', '/home/file']



# Generated at 2022-06-24 03:09:21.796177
# Unit test for function join_each
def test_join_each():
    assert [i for i in join_each("/path/to/directory", ["a", "b", "c"])] == [
        '/path/to/directory/a',
        '/path/to/directory/b',
        '/path/to/directory/c'
    ]



# Generated at 2022-06-24 03:09:25.480083
# Unit test for function join_each
def test_join_each():
    dirs = ['dir1', 'dir2']
    path = 'parent'

    result = [os.path.join(path, d) for d in dirs]
    assert list(join_each(path, dirs)) == result

# Generated at 2022-06-24 03:09:30.221836
# Unit test for function join_each
def test_join_each():
    assert list(join_each(u"D:\\", [u"foo", u"bar", u"baz"])) == [
        u"D:\\foo", u"D:\\bar", u"D:\\baz"
    ]



# Generated at 2022-06-24 03:09:32.543665
# Unit test for function join_each
def test_join_each():
    l = [
        "foo",
        "bar"
    ]
    expected = [
        "./foo",
        "./bar"
    ]
    test = list(join_each("./", l))
    assert test == expected



# Generated at 2022-06-24 03:09:35.685555
# Unit test for function join_each
def test_join_each():
    parent = '/usr/local'
    paths = ['bin', 'include', 'share']
    assert list(join_each(parent, paths)) == [
        '/usr/local/bin', '/usr/local/include', '/usr/local/share',
    ]



# Generated at 2022-06-24 03:09:39.775410
# Unit test for function join_each
def test_join_each():
    cases = [
        (('a', []), []),
        (('a', ['b']), ['a/b']),
        (('a', ['b', 'c']), ['a/b', 'a/c'])
    ]
    for case, expected in cases:
        result = list(join_each(case[0], case[1]))
        assert result == expected


# Define a function that outputs each word in a file

# Generated at 2022-06-24 03:09:42.398932
# Unit test for function join_each
def test_join_each():
    assert list(join_each("base", ["a", "b", "c"])) == ["base/a", "base/b", "base/c"]
    assert list(join_each("base", [])) == []


# Given a directory, finds all the PEM-encoded X.509 certificates contained in the directory or
# contained by any subdirectories.

# Generated at 2022-06-24 03:09:44.099401
# Unit test for function join_each
def test_join_each():
    path = '../'
    items = ['foo', 'bar']
    expected = ['../foo', '../bar']
    actual = list(join_each(path, items))
    assert expected == actual



# Generated at 2022-06-24 03:09:45.998294
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/root', ['foo', 'bar'])) \
           == ['/root/foo', '/root/bar']

# Generated at 2022-06-24 03:09:47.516152
# Unit test for function join_each
def test_join_each():
    assert list(join_each("parent", ["a", "b"])) == ["parent/a", "parent/b"]

# Generated at 2022-06-24 03:09:49.297851
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b'])) == ['parent/a', 'parent/b']



# Generated at 2022-06-24 03:09:56.013937
# Unit test for function join_each
def test_join_each():
    parent = '/home/path'
    paths = ['a', 'b', 'c']
    expected = ['/home/path/a', '/home/path/b', '/home/path/c']
    for i, p in enumerate(join_each(parent, paths)):
        assert p == expected[i]



# Generated at 2022-06-24 03:09:58.337337
# Unit test for function join_each
def test_join_each():
    p = '/some'
    l = ['a', 'b', 'c']

    expected = ['/some/a', '/some/b', '/some/c']
    result = [pth for pth in join_each(p, l)]

    assert expected == result

# Generated at 2022-06-24 03:10:02.773977
# Unit test for function join_each
def test_join_each():
    yield assert_equal, ['a/b', 'a/c', 'a/d'], list(join_each('a', ['b', 'c', 'd']))



# Generated at 2022-06-24 03:10:03.636036
# Unit test for function join_each
def test_join_each():
    assert not next(join_each('foo', []))

# Generated at 2022-06-24 03:10:07.800449
# Unit test for function join_each
def test_join_each():
    # Test that join_each works on a relative path and an absolute path
    current_working_directory = os.path.abspath(os.curdir)
    assert tuple(join_each(current_working_directory, [".vimrc", "setup.py"])) == (
        os.path.join(current_working_directory, ".vimrc"),
        os.path.join(current_working_directory, "setup.py"),
    )

# Generated at 2022-06-24 03:10:09.607046
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:10:12.608019
# Unit test for function join_each
def test_join_each():
    parent = '/home/david'
    iterable = ['projects', 'my_file.txt', 'my_folder']
    expected = ['/home/david/projects', '/home/david/my_file.txt', '/home/david/my_folder']

    for i, p in enumerate(join_each(parent, iterable)):
        assert p == expected[i]



# Generated at 2022-06-24 03:10:14.514152
# Unit test for function join_each
def test_join_each():
    parent = 'foo'
    assert join_each(parent, ['a', 'b']) == ['foo/a', 'foo/b']



# Generated at 2022-06-24 03:10:19.993023
# Unit test for function join_each
def test_join_each():
    sample_parent = '/path/to/parent'
    sample_iterable = (
        'file1',
        'folder1',
        'folder2',
        'file2',
    )

    assert list(join_each(sample_parent, sample_iterable)) == [
        '/path/to/parent/file1',
        '/path/to/parent/folder1',
        '/path/to/parent/folder2',
        '/path/to/parent/file2',
    ]

# Generated at 2022-06-24 03:10:24.356976
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-24 03:10:28.320144
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/foo", ["bar", "baz", "qux"])) == [
        "/foo/bar",
        "/foo/baz",
        "/foo/qux",
    ]

# Generated at 2022-06-24 03:10:32.024456
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['p1','p2','p3'])) == [
        'parent/p1',
        'parent/p2',
        'parent/p3'
    ]
    assert list(join_each('parent', [])) == []



# Generated at 2022-06-24 03:10:36.908461
# Unit test for function join_each
def test_join_each():
    
    # Test the empty case
    assert list(join_each('/', [])) == []
    
    # Test non-empty
    dpath = '/this/is/a/dir/path'
    assert list(join_each(dpath, ['file1.txt', 'file2.txt'])) == [
        '/this/is/a/dir/path/file1.txt',
        '/this/is/a/dir/path/file2.txt'
    ]

# Generated at 2022-06-24 03:10:41.593824
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/nate', ['foo', 'bar'])) == ['/home/nate/foo', '/home/nate/bar']

# Generated at 2022-06-24 03:10:44.457459
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', [])) == []
    assert list(join_each('a', ['b'])) == ['a/b']
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-24 03:10:55.567959
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/root', ['etc', 'bin', 'src'])) == \
        ('/root/etc', '/root/bin', '/root/src')



# Generated at 2022-06-24 03:10:59.022471
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr/local", ["bin"])) == ["/usr/local/bin"]
    assert list(join_each("/usr/local", ["bin", "lib"])) == ["/usr/local/bin",
                                                             "/usr/local/lib"]



# Generated at 2022-06-24 03:11:00.803013
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['foo', 'bar', 'baz'])) == [
        '/tmp/foo', '/tmp/bar', '/tmp/baz']



# Generated at 2022-06-24 03:11:05.790888
# Unit test for function join_each
def test_join_each():
    root = os.path.normpath('/root/path')
    paths = ['../some/path', '../another/path']
    result = join_each(root, paths)
    assert result and next(result) == '/some/path'



# Generated at 2022-06-24 03:11:10.579606
# Unit test for function join_each
def test_join_each():
    assert len(list(join_each(
        '/', ['/bin', '/etc']))) == 2



# Generated at 2022-06-24 03:11:19.103429
# Unit test for function join_each
def test_join_each():
    # Give one item
    assert list(join_each('/', ['/home/'])) == ['/home/']
    # Give two items
    assert list(join_each('/', ['/home', '/var'])) == ['/home', '/var']
    # Give three items
    assert list(join_each('/', ['/home', '/var', '/'])) == ['/home', '/var', '/']
    # Give one empty item
    assert list(join_each('/', [''])) == ['']
    # Give two empty items
    assert list(join_each('/', ['', ''])) == ['', '']



# Generated at 2022-06-24 03:11:22.587080
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/path', ['to', 'nowhere'])) == [
        '/path/to',
        '/path/nowhere'
    ]

# Generated at 2022-06-24 03:11:29.670333
# Unit test for function join_each
def test_join_each():
    # Prepare
    p = 'parent'
    assert list(join_each(p, [])) == []
    assert list(join_each(p, ['a'])) == [os.path.join(p, 'a')]
    assert list(join_each(p, ['a', 'b'])) == [os.path.join(p, 'a'),
                                              os.path.join(p, 'b')]



# Generated at 2022-06-24 03:11:33.423365
# Unit test for function join_each
def test_join_each():
    iterable = ['one', 'two', 'three']
    parent = 'parent'
    expected = ['parent/one', 'parent/two', 'parent/three']
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:11:39.210821
# Unit test for function join_each
def test_join_each():
    parent = '/foo/bar'
    f1 = 'a.txt'
    f2 = 'b.txt'
    assert join_each(
        parent, [f1, f2]) == (os.path.join(parent, f1),
                              os.path.join(parent, f2))



# Generated at 2022-06-24 03:11:43.096733
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == [
        '/a', '/b', '/c']
    assert list(join_each('/path', ['/'])) == ['/path/']
    assert list(join_each('/path/', ['/'])) == ['/path//']
    assert list(join_each('', ['/'])) == ['/']

# Generated at 2022-06-24 03:11:48.571046
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ('child1', 'child2')

    expected = ('parent/child1', 'parent/child2')
    result = tuple(join_each(parent, iterable))

    assert result == expected

# Generated at 2022-06-24 03:11:50.126948
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c", "d"])) == ["a/b", "a/c", "a/d"]



# Generated at 2022-06-24 03:11:52.028118
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('a', (1, 2))) == ('a/1', 'a/2')


filter_path_factory = lambda ignore: lambda path: not any(
    fnmatch.fnmatch(path, pattern)
    for pattern in ignore
)



# Generated at 2022-06-24 03:11:55.101703
# Unit test for function join_each
def test_join_each():
    assert list(join_each("data", ["sub1", "sub2"])) == ["data/sub1", "data/sub2"]



# Generated at 2022-06-24 03:11:58.656760
# Unit test for function join_each
def test_join_each():
    path = "dir"
    files = ["file1", "file2"]
    result = list(join_each(path, files))
    assert result == ["dir/file1", "dir/file2"]



# Generated at 2022-06-24 03:12:04.273144
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['/root', '/usr/local/bin'])) \
        == ['/home/root', '/home/usr/local/bin']

# Generated at 2022-06-24 03:12:07.816173
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["a", "b", "c"])) == [
        "/a", "/b", "/c"
    ]



# Generated at 2022-06-24 03:12:11.244010
# Unit test for function join_each
def test_join_each():
    parent = '/home/myself/something'
    iterable = ('something', 'another', 'one')
    for path in join_each(parent, iterable):
        print(path)


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:12:14.422124
# Unit test for function join_each
def test_join_each():
    a = [os.getcwd(), '..', '..']
    b = list(join_each(*a[:2]))
    print(a)
    print(b)
    assert b == [os.path.join(a[0], a[1]), ]



# Generated at 2022-06-24 03:12:15.994337
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', ('foo', 'bar'))) == ['/foo', '/bar']



# Generated at 2022-06-24 03:12:20.069903
# Unit test for function join_each
def test_join_each():
    # make sure it works with a single element list
    assert list(join_each('a', ['b'])) == ['a/b']
    # make sure it works with a multiple element list
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    # make sure it works with an empty list
    assert list(join_each('a', [])) == []

    # make sure it doesn't change the original list
    l = ['a', 'b']
    list(join_each('c', l))
    assert l == ['a', 'b']



# Generated at 2022-06-24 03:12:21.871823
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['a', 'b'])) == ['/home/a', '/home/b']



# Generated at 2022-06-24 03:12:23.519609
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-24 03:12:25.777475
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c", "d"])) == ["a/b", "a/c", "a/d"]

# Generated at 2022-06-24 03:12:31.156044
# Unit test for function join_each
def test_join_each():
    cwd = os.getcwd()

    assert list(join_each(cwd, ['a', 'b', 'c'])) == [
        os.path.join(cwd, 'a'),
        os.path.join(cwd, 'b'),
        os.path.join(cwd, 'c')
    ]

# Generated at 2022-06-24 03:12:40.721834
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', (''))) == ['.']
    assert list(join_each('.', ('',))) == ['.']
    assert list(join_each('.', ('.', ''))) == ['.', './.']
    assert list(join_each('.', ('.', '.'))) == ['./.', './.']
    assert list(join_each('.', ('.'))) == ['.']
    assert list(join_each('.', ('.',))) == ['.']
    assert list(join_each('.', ('./.'))) == ['./.']
    assert list(join_each('.', ('./.',))) == ['./.']
    assert list(join_each('.', ('foo'))) == ['foo']

# Generated at 2022-06-24 03:12:43.151851
# Unit test for function join_each
def test_join_each():
    assert list(join_each('C:/Windows', ['System', 'Users'])) == ['C:/Windows\\System', 'C:/Windows\\Users']



# Generated at 2022-06-24 03:12:49.194623
# Unit test for function join_each
def test_join_each():
    files = (u'file1.txt, file2.txt, file3.txt'.split(', '))
    expected = '/home/someuser/dir1/file1.txt, /home/someuser/dir1/file2.txt, /home/someuser/dir1/file3.txt'.split(', ')

    actual = join_each('/home/someuser/dir1', files)
    assert(actual == expected)

# Generated at 2022-06-24 03:12:52.808124
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/user/", ["Documents", "Downloads"])) == [
        "/home/user/Documents",
        "/home/user/Downloads",
    ]

# Generated at 2022-06-24 03:13:03.216368
# Unit test for function join_each
def test_join_each():
    # Test for expected result
    expected = [
        os.path.join(os.path.expanduser("~"), "a.png"),
        os.path.join(os.path.expanduser("~"), "b.png"),
        os.path.join(os.path.expanduser("~"), "c.png")
    ]
    result = list(join_each(os.path.expanduser("~"), ["a.png", "b.png", "c.png"]))
    assert expected == result

    # Test for iterable > 1
    assert len(list(join_each(os.path.expanduser("~"), ["a.png", "b.png", "c.png"]))) == 3

    # Test for iterable == 1

# Generated at 2022-06-24 03:13:06.815096
# Unit test for function join_each
def test_join_each():
    assert list(join_each("C", ["Windows", "temp"])) == [
        "C\\Windows",
        "C\\temp",
    ]



# Generated at 2022-06-24 03:13:09.197549
# Unit test for function join_each
def test_join_each():
    parent = '/parent'
    children = ['child1', 'child2', 'child3']

# Generated at 2022-06-24 03:13:10.999794
# Unit test for function join_each
def test_join_each():
    assert list(join_each('./', ['a', 'b', 'c'])) == ['./a', './b', './c']



# Generated at 2022-06-24 03:13:14.409812
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('a', ['b', 'c'])) == ('a/b', 'a/c')


if __name__ == '__main__':
    print('It is main!')
    import cProfile
    cProfile.run('test_join_each()')

# Generated at 2022-06-24 03:13:20.249663
# Unit test for function join_each
def test_join_each():
    test_1 = join_each('/tmp/test-dir', ['a', 'b', 'c'])
    expected_1 = ['/tmp/test-dir/a', '/tmp/test-dir/b', '/tmp/test-dir/c']
    assert test_1 == expected_1
    test_2 = join_each('/tmp/test-dir', ['a/b/c', 'a/b/d', 'a/b/e'])
    expected_2 = ['/tmp/test-dir/a/b/c', '/tmp/test-dir/a/b/d', '/tmp/test-dir/a/b/e']
    assert test_2 == expected_2



# Generated at 2022-06-24 03:13:26.286353
# Unit test for function join_each
def test_join_each():
    assert list(join_each('', [''])) == ['']
    assert list(join_each('', [])) == []
    assert list(join_each('', ['a', 'b'])) == ['a', 'b']


# Python program for Dijkstra's single
# source shortest path algorithm. The program is
# for adjacency matrix representation of the graph

# Library for INT_MAX
import sys



# Generated at 2022-06-24 03:13:30.715296
# Unit test for function join_each
def test_join_each():
    r = join_each('/foo', ['bar', 'baz'])
    assert list(r) == ['/foo/bar', '/foo/baz']



# Generated at 2022-06-24 03:13:36.682338
# Unit test for function join_each
def test_join_each():
    a = ('./filesystem.py', './filesystemTest.py', './log.cfg')
    b = ('./filesystem.py', './log.cfg')
    assert set(join_each('./', a)) == set(join_each('./', b))
    assert set(join_each('./', b)) == set(join_each('.', b))
    assert set(join_each('/home/tulio/', a)) == \
        set(join_each('/home/tulio', a))
    assert set(join_each('/home/tulio', a)) != \
        set(join_each('.', b))



# Generated at 2022-06-24 03:13:41.275636
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["user", "foo", "bar"])) == [
        "/home/user",
        "/home/foo",
        "/home/bar",
    ]



# Generated at 2022-06-24 03:13:43.583438
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ('hello', 'world'))) == [
        '/tmp/hello',
        '/tmp/world']



# Generated at 2022-06-24 03:13:48.739785
# Unit test for function join_each
def test_join_each():
    assert list(join_each('www.google.com', 'a/b/c')) == [
        'www.google.com/a',
        'www.google.com/b',
        'www.google.com/c',
    ]
    assert list(join_each('www.google.com/', 'a/b/c')) == [
        'www.google.com/a',
        'www.google.com/b',
        'www.google.com/c',
    ]

