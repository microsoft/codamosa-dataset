

# Generated at 2022-06-24 03:03:53.435469
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr/bin", ["/bin", "bash"])) == [
        "/usr/bin/bin",
        "/usr/bin/bash",
    ]
    assert list(join_each("usr", ["", "bin", ""])) == ["usr", "usr/bin", "usr"]
    assert list(join_each("./", ["", "bin", ""])) == ["./", "./bin", "./"]



# Generated at 2022-06-24 03:03:58.842487
# Unit test for function join_each
def test_join_each():
    file_list = ["a.txt", "b/c.txt", "d.txt"]
    parent_dir = "/home/user"
    expected = ["/home/user/a.txt", "/home/user/b/c.txt", "/home/user/d.txt"]
    actual = list(join_each(parent_dir, file_list))
    assert actual == expected



# Generated at 2022-06-24 03:04:02.510181
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-24 03:04:06.663682
# Unit test for function join_each
def test_join_each():
    parent = "/tmp/a"
    result = [os.path.join(parent, p) for p in ["b", "c"]]
    assert join_each(parent, ["b", "c"]) == result



# Generated at 2022-06-24 03:04:10.293955
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['file1', 'file2'])) == ['/tmp/file1', '/tmp/file2']



# Generated at 2022-06-24 03:04:14.345747
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ['c', 'd'])) == ['/a/b/c', '/a/b/d']
    assert list(join_each('/a/b', ['/c', 'd'])) == ['/a/b/c', '/a/b/d']
    assert list(join_each('/a/b', ['c', '/d'])) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-24 03:04:17.027358
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', ['passwd', 'group'])) == [
        '/etc/passwd', '/etc/group']




# Generated at 2022-06-24 03:04:22.532405
# Unit test for function join_each
def test_join_each():
    parent = '/this/is/the/parent'
    iterable = ['this', 'is', 'a', 'test']
    for p, expected in zip(join_each(parent, iterable),
                           ['/this/is/the/parent/this',
                            '/this/is/the/parent/is',
                            '/this/is/the/parent/a',
                            '/this/is/the/parent/test']):
        assert p == expected

# Generated at 2022-06-24 03:04:23.988850
# Unit test for function join_each
def test_join_each():
    assert list(join_each("base", ["first", "second"])) == ["base/first", "base/second"]

# Generated at 2022-06-24 03:04:26.879781
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']

# Generated at 2022-06-24 03:04:31.007971
# Unit test for function join_each
def test_join_each():
    assert join_each(1, [2]) == [1, 2]
    assert join_each(None, []) == []
    assert join_each(None, [None]) == [None]
    assert join_each(1, [None]) == [1, None]


if __name__ == '__main__':
    # pytest foo.py
    import pytest
    pytest.main(__name__)

# Generated at 2022-06-24 03:04:39.683022
# Unit test for function join_each
def test_join_each():
    # Test case 1
    parent = "/tmp"
    iterable = ["test1", "test2", "test3"]
    result = list(join_each(parent, iterable))
    expected = ["/tmp/test1", "/tmp/test2", "/tmp/test3"]
    assert result == expected

    # Test case 2
    parent = "/tmp"
    iterable = []
    result = list(join_each(parent, iterable))
    expected = []
    assert result == expected

    # Test case 3
    parent = "/tmp"
    iterable = None
    assert raises(TypeError, lambda: list(join_each(parent, iterable)))

# Generated at 2022-06-24 03:04:43.169055
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b', 'c'])) == (
        ['parent/a', 'parent/b', 'parent/c'])



# Generated at 2022-06-24 03:04:48.301835
# Unit test for function join_each
def test_join_each():
    p = '/a'
    list_of_paths = ['b', 'c', 'd']
    list_of_joined_paths = list(join_each(p, list_of_paths))
    assert list_of_joined_paths == [os.path.join(p, 'b'), os.path.join(p, 'c'), os.path.join(p, 'd')]



# Generated at 2022-06-24 03:04:55.896227
# Unit test for function join_each
def test_join_each():
    # Single item
    assert list(join_each('.', ['a'])) == ['.', os.path.join('.', 'a')]
    assert list(join_each('.', ['a', 'b', 'c'])) == ['.',
                                                     os.path.join('.', 'a'),
                                                     os.path.join('.', 'b'),
                                                     os.path.join('.', 'c')]



# Generated at 2022-06-24 03:05:02.690424
# Unit test for function join_each
def test_join_each():
    parent = '/path/to/parent'
    iterable = ['a', 'b', 'c']
    it = join_each(parent, iterable)
    assert next(it) == '/path/to/parent/a'
    assert next(it) == '/path/to/parent/b'
    assert next(it) == '/path/to/parent/c'
    assert next(it, None) is None



# Generated at 2022-06-24 03:05:06.876651
# Unit test for function join_each
def test_join_each():
    d = '/tmp'
    iter = ['f1', 'f2', 'f3']
    j = join_each(d, iter)
    assert d == '/tmp'
    assert next(j) == '/tmp/f1'
    assert next(j) == '/tmp/f2'
    assert next(j) == '/tmp/f3'
    try:
        next(j)
    except StopIteration:
        pass



# Generated at 2022-06-24 03:05:08.719519
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]

# Generated at 2022-06-24 03:05:11.980836
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/some/dir', ['a', 'b', 'c', 'd'])) == [
        '/some/dir/a', '/some/dir/b', '/some/dir/c', '/some/dir/d']



# Generated at 2022-06-24 03:05:15.348599
# Unit test for function join_each
def test_join_each():
    t1 = join_each(None, ['a', 'b', 'c'])
    assert next(t1) == 'a'

    t2 = join_each('abc', ['a', 'b', 'c'])
    assert next(t2) == 'abc/a'



# Generated at 2022-06-24 03:05:17.835528
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/opt', ('foo', 'bar', 'baz'))) == [
        '/opt/foo',
        '/opt/bar',
        '/opt/baz',
    ]



# Generated at 2022-06-24 03:05:24.196289
# Unit test for function join_each
def test_join_each():
    test_dir = '/usr/local/bin'
    test_in = ['bin', 'lib']
    test_out = list(join_each(test_dir, test_in))
    result = ['/usr/local/bin/bin', '/usr/local/bin/lib']
    assert test_out == result

# Generated at 2022-06-24 03:05:29.818061
# Unit test for function join_each
def test_join_each():
    parent = '/'
    iterable = ['bin', 'usr', 'local']
    expected = ['/bin', '/usr', '/local']

    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-24 03:05:32.444074
# Unit test for function join_each
def test_join_each():
    p = "/home/user"
    files = ["test.txt", "test.py"]
    assert list(join_each(p, files)) == [os.path.join(p, f) for f in files]

# Generated at 2022-06-24 03:05:40.333544
# Unit test for function join_each
def test_join_each():
    parent = '/users/samuel'
    files = ['file1.txt', 'file2.txt', 'file3.txt']
    full_paths = ['/users/samuel/file1.txt', '/users/samuel/file2.txt',
                  '/users/samuel/file3.txt']
    assert full_paths == list(join_each(parent, files))


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:05:42.813264
# Unit test for function join_each
def test_join_each():
    a_list = ["test1", "test2"]
    parent = "test0"
    b_list = list(join_each(parent, a_list))
    assert b_list == ["test0/test1", "test0/test2"]

# Generated at 2022-06-24 03:05:46.588289
# Unit test for function join_each
def test_join_each():
    assert list(join_each(os.path.sep, ['a', 'b', 'c'])) == [
        '/a', '/b', '/c'
    ]

if __name__ == "__main__":
    print(list(join_each(os.path.sep, ['a', 'b', 'c'])))

# Generated at 2022-06-24 03:05:50.970611
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr/bin", ["python", "sh", "rsync"])) == [
        "/usr/bin/python",
        "/usr/bin/sh",
        "/usr/bin/rsync",
    ]



# Generated at 2022-06-24 03:05:52.754097
# Unit test for function join_each
def test_join_each():
    assert sorted(join_each('hello', ['there', 'buddy'])) == sorted([
        'hello/there', 'hello/buddy'
    ])



# Generated at 2022-06-24 03:05:55.922902
# Unit test for function join_each
def test_join_each():
    assert list(join_each("base", ["a", "b", "c"])) == ["base/a", "base/b", "base/c"]



# Generated at 2022-06-24 03:05:59.937678
# Unit test for function join_each
def test_join_each():
    join_each_test = join_each('..', ['foo'])
    for (i, j) in enumerate(join_each_test):
        assert j.split('/')[1:] == ['..', 'foo'], i

# Generated at 2022-06-24 03:06:05.551075
# Unit test for function join_each
def test_join_each():
    # Test different paths
    paths = ['.', '..', '/', '.', '']

    # Test different parents
    parents = ['', '.', '..', '/', '.']
    for parent in parents:
        for path in paths:
            result = join_each(parent, paths)
            expected = [os.path.join(parent, p) for p in paths]
            assert list(result) == expected



# Generated at 2022-06-24 03:06:06.958101
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['', 'bin', 'usr'])) == [
        '/',
        '/bin',
        '/usr',
    ]



# Generated at 2022-06-24 03:06:09.782308
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['.', '..'])) == ['/.', '/..']
    assert list(join_each('/a/b', ['../', '.'])) == ['/a/b/..', '/a/b/.']



# Generated at 2022-06-24 03:06:14.926366
# Unit test for function join_each
def test_join_each():
    assert join_each('/', ['a', 'b', 'c']) == ['/a', '/b', '/c']
    #
    assert join_each('/', ['//a', '//b', '//c']) == ['/a', '/b', '/c']
    #
    assert join_each('/path', []) == []
    #
    assert join_each('/path/to/directory', ['a', 'b', 'c']) == ['/path/to/directory/a', '/path/to/directory/b',
                                                                '/path/to/directory/c']

# Generated at 2022-06-24 03:06:15.704768
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-24 03:06:16.852163
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/root', ['a', 'b', 'c'])) == [
        '/root/a', '/root/b', '/root/c']



# Generated at 2022-06-24 03:06:19.599135
# Unit test for function join_each
def test_join_each():
    """Should combine a parent directory with all elements of an iterable"""
    
    assert list(join_each('/foo', ['bar', 'baz', 'buzz'])) == [
        '/foo/bar', '/foo/baz', '/foo/buzz'
    ]



# Generated at 2022-06-24 03:06:25.630768
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    children = ['child1', 'child2', 'child3']
    result = ['parent/child1', 'parent/child2', 'parent/child3']

    assert list(join_each(parent, children)) == result


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:06:28.581023
# Unit test for function join_each

# Generated at 2022-06-24 03:06:34.060299
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a/b/c", ["x", "y"])) == ["/a/b/c/x", "/a/b/c/y"]
    assert list(join_each("/a", ["x", "y"])) == ["/a/x", "/a/y"]
    assert list(join_each("/", ["x", "y"])) == ["/x", "/y"]



# Generated at 2022-06-24 03:06:37.937576
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:06:40.383891
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/test', ['a', 'b', 'c'])) == [
        '/test/a', '/test/b', '/test/c'
    ]

# Generated at 2022-06-24 03:06:45.955323
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/test", ["a", "b", "c"])) == [
        "/test/a",
        "/test/b",
        "/test/c",
    ]



# Generated at 2022-06-24 03:06:48.554699
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz", "qux"])) == [
        "foo/bar",
        "foo/baz",
        "foo/qux",
    ]



# Generated at 2022-06-24 03:06:50.322698
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a", ["b", "c"])) == ["/a/b", "/a/c"]

# Generated at 2022-06-24 03:06:52.099357
# Unit test for function join_each
def test_join_each():
    parent = "Test"
    paths = ["path1", "path2"]
    joined = [os.path.join(parent, p) for p in paths]
    assert list(join_each(parent, paths)) == joined

# Generated at 2022-06-24 03:06:53.537278
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['local', 'bin'])) == [
        '/usr/local', '/usr/bin']



# Generated at 2022-06-24 03:06:55.346335
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar', 'baz'])) == [
        '/foo',
        '/bar',
        '/baz',
    ]



# Generated at 2022-06-24 03:07:01.281364
# Unit test for function join_each
def test_join_each():
    parent = 'root/level1'
    iterable = ['fileA', 'fileB']
    j = join_each(parent, iterable)
    assert j.__next__() == 'root/level1/fileA'
    assert j.__next__() == 'root/level1/fileB'



# Generated at 2022-06-24 03:07:07.653766
# Unit test for function join_each
def test_join_each():
    test_case_dir = os.path.dirname(os.path.realpath(__file__))
    expected_output = [os.path.join(test_case_dir, 'case1'), os.path.join(test_case_dir, 'case2')]
    actual_output = list(join_each(test_case_dir, ['case1', 'case2']))
    assert expected_output == actual_output


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:07:11.136195
# Unit test for function join_each
def test_join_each():
    parent = "foo"
    iter = ["a", "b", "c"]
    expected = ["foo/a", "foo/b", "foo/c"]

    result = join_each(parent, iter)

    assert isinstance(result, types.GeneratorType)

    actual = list(result)

    assert expected == actual



# Generated at 2022-06-24 03:07:14.560009
# Unit test for function join_each
def test_join_each():
    i = ['my', 'name', 'is', 'sam']
    parent = '/home/username/'
    ans = ['/home/username/my',
           '/home/username/name',
           '/home/username/is',
           '/home/username/sam']

    assert list(join_each(parent, i)) == ans


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:07:21.120967
# Unit test for function join_each
def test_join_each():
    import unittest
    from unittest import mock

    class TestJoinEach(unittest.TestCase):
        def setUp(self):
            self.patcher = mock.patch('os.path.join')
            self.addCleanup(self.patcher.stop)
            self.mock_join = self.patcher.start()
            self.parent = "/this/is/a/parent"
            self.iterable = ['/', 'this', 'is', 'another', 'path']

        def test_join_each_iterates_over_iterable_and_returns_result_of_join(self):
            result = list(join_each(self.parent, self.iterable))
            self.assertEqual(self.mock_join.call_count, len(self.iterable))

# Generated at 2022-06-24 03:07:22.175508
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["a", "b"])) == ["foo/a", "foo/b"]



# Generated at 2022-06-24 03:07:23.785395
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == [
        'foo/bar',
        'foo/baz'
    ]

# Generated at 2022-06-24 03:07:29.480034
# Unit test for function join_each
def test_join_each():
    # Test with string
    assert list(join_each('root', ['a', 'b', 'c'])) == ['root/a', 'root/b', 'root/c']

    # Test with non-string
    assert list(join_each(['root', 'a'], ['b', 'c'])) == [['root', 'a', 'b'], ['root', 'a', 'c']]


# Test for function join_each
# test_join_each()



# Generated at 2022-06-24 03:07:32.125378
# Unit test for function join_each
def test_join_each():
    EXPECTED = ['a/b', 'a/c', 'a/d', 'a/e']
    assert list(join_each('a', ['b', 'c', 'd', 'e'])) == EXPECTED



# Generated at 2022-06-24 03:07:37.061982
# Unit test for function join_each
def test_join_each():
    parent = "/tmp"
    paths = ["a", "b", "c"]
    actual = join_each(parent, paths)
    expected = ["/tmp/a", "/tmp/b", "/tmp/c"]
    assert list(actual) == expected

# Generated at 2022-06-24 03:07:44.579926
# Unit test for function join_each
def test_join_each():
    assert list(join_each(
        os.path.dirname(os.path.abspath(__file__)),
        ['__init__.py', 'test_join_each.py'])) == [
            os.path.join(os.path.dirname(
                os.path.abspath(__file__)), '__init__.py'),
            os.path.join(os.path.dirname(
                os.path.abspath(__file__)), 'test_join_each.py')
        ]

# Generated at 2022-06-24 03:07:49.552012
# Unit test for function join_each
def test_join_each():
    p = '/var/log'
    files = ['2020-12-31.log', '2020-12-30.log', '2020-12-29.log']
    assert list(join_each(p, files)) == ['/var/log/2020-12-31.log',
                                         '/var/log/2020-12-30.log',
                                         '/var/log/2020-12-29.log']



# Generated at 2022-06-24 03:07:51.221326
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/c', ['d', 'e', 'f'])) == ['/a/b/c/d', '/a/b/c/e', '/a/b/c/f']



# Generated at 2022-06-24 03:08:02.694260
# Unit test for function join_each
def test_join_each():
    parent = '/Users/hotoku/Dropbox/project/myproj'
    paths = [
        'content/china/history/001',
        'content/china/history/002',
        'content/japan/history/001',
        'content/japan/history/002',
    ]
    expected = [
        '/Users/hotoku/Dropbox/project/myproj/content/china/history/001',
        '/Users/hotoku/Dropbox/project/myproj/content/china/history/002',
        '/Users/hotoku/Dropbox/project/myproj/content/japan/history/001',
        '/Users/hotoku/Dropbox/project/myproj/content/japan/history/002',
    ]


# Generated at 2022-06-24 03:08:07.266495
# Unit test for function join_each
def test_join_each():
    # parent = x
    # iterable = [a, b, c]
    # result = [x/a, x/b, x/c]
    parent = 'x'
    iterable = ['a', 'b', 'c']
    result = join_each(parent, iterable)
    expected = ['x/a', 'x/b', 'x/c']

    assert list(result) == expected

# Generated at 2022-06-24 03:08:09.564790
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/parent/dir', ['child1', 'child2'])) == [
        '/parent/dir/child1',
        '/parent/dir/child2'
    ]



# Generated at 2022-06-24 03:08:10.844425
# Unit test for function join_each
def test_join_each():
    parent = "/foo/bar"
    iterable = ["a", "b", "c"]
    assert list(join_each(parent, iterable)) == [
        os.path.join(parent, p) for p in iterable
    ]



# Generated at 2022-06-24 03:08:15.882041
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['tmp', 't1', 't2'])) \
        == ["./tmp", "./t1", "./t2"]



# Generated at 2022-06-24 03:08:22.979151
# Unit test for function join_each
def test_join_each():
    # Create test case
    parent = '/usr/local/bin'
    iterable = ['vim', 'vi', 'emacs']
    expected = (
        '/usr/local/bin/vim',
        '/usr/local/bin/vi',
        '/usr/local/bin/emacs'
    )
    # Make assertion
    for e, a in zip(expected, join_each(parent, iterable)):
        assert e == a


# Tests for all FileIO functions

# Generated at 2022-06-24 03:08:26.253077
# Unit test for function join_each
def test_join_each():
    file_list = ['file1.txt', 'file2.txt', 'file3.txt']
    assert list(join_each('/home/user', file_list)) == [
        '/home/user/file1.txt',
        '/home/user/file2.txt',
        '/home/user/file3.txt',
    ]



# Generated at 2022-06-24 03:08:28.522665
# Unit test for function join_each
def test_join_each():
    assert set(join_each("/tmp/test",
                         ("foo.c", "bar\0.o", "baz.h"))) == set([
        "/tmp/test/foo.c",
        "/tmp/test/bar\0.o",
        "/tmp/test/baz.h",
    ])



# Generated at 2022-06-24 03:08:30.046885
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-24 03:08:34.358712
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']

# Generated at 2022-06-24 03:08:38.975777
# Unit test for function join_each
def test_join_each():
    assert list(join_each("C:/", ["Program Files", "Python"])) == ["C:/Program Files", "C:/Python"]
    assert list(
        join_each("C:/Program Files", ["Python 2.7", "Python 3.4"])
    ) == ["C:/Program Files/Python 2.7", "C:/Program Files/Python 3.4"]
    assert list(join_each("C:/Program Files/Python 2.7", ["Scripts"])) == [
        "C:/Program Files/Python 2.7/Scripts"
    ]

# Generated at 2022-06-24 03:08:42.022419
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c/d'])) == ['/a/b', '/a/c/d']

# Generated at 2022-06-24 03:08:44.536350
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == \
        [os.path.join('foo', 'bar'), os.path.join('foo', 'baz')]
    assert list(join_each('foo', [])) == []

# Generated at 2022-06-24 03:08:49.987185
# Unit test for function join_each
def test_join_each():
    parent = 'karl'
    p = join_each(parent, ['michael', 'eric', 'john'])
    assert next(p) == 'karl/michael'
    assert next(p) == 'karl/eric'
    assert next(p) == 'karl/john'
    with pytest.raises(StopIteration):
        next(p)



# Generated at 2022-06-24 03:08:56.107524
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ['c', 'd'])) == ['/a/b/c', '/a/b/d']
    assert list(join_each('b', ['c', 'd'])) == ['b/c', 'b/d']
    assert list(join_each('', ['c', 'd'])) == ['c', 'd']
    assert list(join_each('/', ['c', 'd'])) == ['/c', '/d']
    assert list(join_each('', [])) == []



# Generated at 2022-06-24 03:08:59.252805
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('parent', [])) == [])
    assert(list(join_each('parent', ['child'])) == ['parent/child'])
    assert(list(join_each('parent', ['child', 'child2'])) ==
           ['parent/child', 'parent/child2'])



# Generated at 2022-06-24 03:09:08.004874
# Unit test for function join_each
def test_join_each():
    parent = os.getcwd()
    assert list(join_each(parent, [])) == []
    assert list(join_each(parent, ["..", "..", "..", "test_join_each.py"])) == \
           [
               os.path.join(parent, ".."),
               os.path.join(parent, "..", ".."),
               os.path.join(parent, "..", "..", ".."),
               os.path.join(parent, "..", "..", "..", "test_join_each.py")
           ]

# Generated at 2022-06-24 03:09:10.422312
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['home', 'lib'])) == ['/home', '/lib']



# Generated at 2022-06-24 03:09:15.615540
# Unit test for function join_each
def test_join_each():
    # Empty list
    assert list(join_each('/tmp', [])) == []

    # One element
    assert list(join_each('/tmp', ['a'])) == ['/tmp/a']

    # Two elements
    assert list(join_each('/tmp', ['a', 'b'])) == ['/tmp/a', '/tmp/b']



# Generated at 2022-06-24 03:09:19.962723
# Unit test for function join_each
def test_join_each():
    expected = join_each('/a/b', ['c', 'd'])
    actual = ['/a/b/c', '/a/b/d']

    assert list(expected) == actual

# Generated at 2022-06-24 03:09:26.045744
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['/bar', 'baz', 'qux'])) == [
        '/foo/bar',
        '/foo/baz',
        '/foo/qux'
    ]
    assert list(join_each('/foo', [])) == []



# Generated at 2022-06-24 03:09:30.162067
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == [
        '/a', '/b', '/c',
    ]

# Generated at 2022-06-24 03:09:32.236896
# Unit test for function join_each
def test_join_each():
    expected_output = ['a/b', 'a/c', 'a/d']
    assert list(join_each('a', ['b', 'c', 'd'])) == expected_output


# Fetch all the paths

# Generated at 2022-06-24 03:09:34.734438
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz', 'qux'])) == \
        ['foo' + '/bar', 'foo' + '/baz', 'foo' + '/qux']



# Generated at 2022-06-24 03:09:36.548668
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['1', '2', '3'])) == ['parent/1', 'parent/2', 'parent/3']

# Generated at 2022-06-24 03:09:39.954180
# Unit test for function join_each
def test_join_each():
    file_names = ['hello.txt', 'world.txt']
    joined_file_names = join_each('/home/syang/tmp', file_names)
    assert next(joined_file_names) == '/home/syang/tmp/hello.txt'
    assert next(joined_file_names) == '/home/syang/tmp/world.txt'



# Generated at 2022-06-24 03:09:42.326280
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child', 'child2'])) == ['parent/child',
                                                              'parent/child2']



# Generated at 2022-06-24 03:09:44.429118
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/', ['user', 'tmp'])) == ['/home/user', '/home/tmp']
    assert list(join_each('/etc/', ['passwd', 'shadow'])) == ['/etc/passwd', '/etc/shadow']

# Generated at 2022-06-24 03:09:47.960598
# Unit test for function join_each
def test_join_each():
    test_parent = '/tmp'
    test_iterable = ('some_file.txt', 'some_folder')
    x = (os.path.join(test_parent, i) for i in test_iterable)
    y = join_each(test_parent, test_iterable)
    assert x == y



# Generated at 2022-06-24 03:09:51.252749
# Unit test for function join_each
def test_join_each():
    parent = '/home/michaels/Desktop/PythonProjects'
    iterable = ['DigitRecognition', 'MNIST', 'README']
    for path in join_each(parent, iterable):
        print(path)



# Generated at 2022-06-24 03:09:58.003675
# Unit test for function join_each
def test_join_each():
    path = '/tmp'
    expected = ['/tmp/file1', '/tmp/file2', '/tmp/file3']
    actual = list(join_each(path, ['file1', 'file2', 'file3']))
    assert expected == actual
    actual = list(join_each(path, iter(['file1', 'file2', 'file3'])))
    assert expected == actual



# Generated at 2022-06-24 03:10:03.422743
# Unit test for function join_each
def test_join_each():
    assert './a/b/c' == list(join_each('./a', ['b', 'c']))[1]
    assert './a/b/c' == list(join_each('./a', ('b', 'c')))[1]



# Generated at 2022-06-24 03:10:06.018073
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', 'bc')) == ['a/b', 'a/c']
    assert list(join_each('a', map(str, range(3)))) == ['a/0', 'a/1', 'a/2']
    assert list(join_each('a/', 'bc')) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:10:07.799841
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ("a", "b", "c"))) == [
        "/a", "/b", "/c"
    ]



# Generated at 2022-06-24 03:10:09.607906
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('a', ['d', 'e'])) == ['a\\d', 'a\\e'])



# Generated at 2022-06-24 03:10:13.216750
# Unit test for function join_each
def test_join_each():
    assert list(join_each(None, [])) == []
    assert list(join_each('', [])) == []
    assert list(join_each('', ['a'])) == ['a']
    assert list(join_each('', ['a', 'b'])) == ['a', 'b']
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', ['a/', '/b'])) == ['/a/', '/b']

# Generated at 2022-06-24 03:10:16.452772
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']


# Recursively walk into a directory and return an iterable of all the
# file paths

# Generated at 2022-06-24 03:10:20.125920
# Unit test for function join_each
def test_join_each():
    test_cases = [
        ('/', ['a', 'b', 'c'], ['/a', '/b', '/c']),
    ]

    for test_case in test_cases:
        assert list(join_each(test_case[0], test_case[1])) == test_case[2]


# Test for function join_each on tuples

# Generated at 2022-06-24 03:10:24.864688
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['a', 'b', 'c'])) == ['/usr/a', '/usr/b', '/usr/c']



# Generated at 2022-06-24 03:10:28.274149
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ('b', 'c'))) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:10:34.387772
# Unit test for function join_each
def test_join_each():
    assert [p for p in join_each("/foo/bar", ['1', '2', '3'])] == \
           ['/foo/bar/1', '/foo/bar/2', '/foo/bar/3']
    assert [p for p in join_each("", ['1', '2', '3'])] == \
           ['1', '2', '3']
    assert [p for p in join_each("/", ['1', '2', '3'])] == \
           ['/1', '/2', '/3']



# Generated at 2022-06-24 03:10:36.290021
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['file1', 'file2'])) == ['/tmp/file1', '/tmp/file2']



# Generated at 2022-06-24 03:10:42.479523
# Unit test for function join_each
def test_join_each():
    path_elements = ['foo', 'bar']
    expected = ['foo/bar', 'foo/baz']
    actual = list(join_each('foo', ['bar', 'baz']))
    assert actual == expected



# Generated at 2022-06-24 03:10:56.843132
# Unit test for function join_each
def test_join_each():
    parent = '/parent/directory'
    iterable = ['child1', 'child2', 'child3']
    actual = list(join_each(parent, iterable))
    expected = ['/parent/directory/child1',
                '/parent/directory/child2',
                '/parent/directory/child3']
    assert actual == expected



# Generated at 2022-06-24 03:10:59.285071
# Unit test for function join_each
def test_join_each():
    assert list(join_each("dummy/path", ["a", "b", "c"])) == [
        "dummy/path/a",
        "dummy/path/b",
        "dummy/path/c",
    ]



# Generated at 2022-06-24 03:11:00.803494
# Unit test for function join_each
def test_join_each():
    assert list(join_each(
        '/', ['foo', 'bar', 'baz'])) == ['/foo', '/bar', '/baz']



# Generated at 2022-06-24 03:11:05.195842
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/', ['c', 'd'])) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-24 03:11:08.316289
# Unit test for function join_each
def test_join_each():
    expected = [
        "Kak/Project.sublime-project",
        "Kak/test.py",
        "Kak/test_pytest.py",
    ]

    result = join_each("Kak", ["Project.sublime-project", "test.py", "test_pytest.py"])
    assert list(result) == expected

# Generated at 2022-06-24 03:11:09.850428
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:11:11.161728
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']

# Generated at 2022-06-24 03:11:16.190269
# Unit test for function join_each
def test_join_each():
    p = "/usr/local"
    i = ["bin", "lib", "include"]
    j = [os.path.join(p, e) for e in i]
    assert list(join_each(p, i)) == j

# Generated at 2022-06-24 03:11:23.458843
# Unit test for function join_each
def test_join_each():
    parent = '/usr/local'
    assert list(join_each(parent, ['bin', 'sbin', 'lib'])) == [
        '/usr/local/bin', '/usr/local/sbin', '/usr/local/lib']


# Your task for this week: given a sequence of paths joined with os.path.join,
# return a sequence of the same paths, but relative to a given parent directory.
# write a test for it in tasks/test_paths.py
# Bonus points if you can write it as a one-liner.


# Generated at 2022-06-24 03:11:28.738807
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", [
        "a", "b", "c"])) == [
        "/a", "/b", "/c"]

    assert list(join_each("/abc", [
        "a", "b", "c"])) == [
        "/abc/a", "/abc/b", "/abc/c"]

    assert list(join_each("/abc/", [
        "a", "b", "c"])) == [
        "/abc/a", "/abc/b", "/abc/c"]

    assert list(join_each("/abc/", [
        "a/b", "b/c", "c/d"])) == [
        "/abc/a/b", "/abc/b/c", "/abc/c/d"]

# Generated at 2022-06-24 03:11:31.969543
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr", ["bin", "lib"])) == [
        "/usr/bin",
        "/usr/lib",
    ]



# Generated at 2022-06-24 03:11:34.175293
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    test_file = '/test.py'
    assert list(join_each(parent, [test_file])) == [os.path.join(parent, test_file)]

# Generated at 2022-06-24 03:11:40.795770
# Unit test for function join_each
def test_join_each():
    parent = '/home/nathan'
    paths = ['/pictures/cat.jpg', '/documents/homework.doc']
    expected = ['/home/nathan/pictures/cat.jpg',
                '/home/nathan/documents/homework.doc']
    actual = join_each(parent, paths)
    for exp, act in zip(expected, actual):
        assert exp == act



# Generated at 2022-06-24 03:11:43.184984
# Unit test for function join_each
def test_join_each():
    parent = 'foo'
    iterable = ('a.txt', 'b.txt')
    expected = ('foo/a.txt', 'foo/b.txt')
    assert list(join_each(parent, iterable)) == list(expected)

# Generated at 2022-06-24 03:11:52.271199
# Unit test for function join_each
def test_join_each():
    assert set(
        join_each('foo', ['bar', 'baz', 'qux'])
    ) == set([
        os.path.join('foo', 'bar'),
        os.path.join('foo', 'baz'),
        os.path.join('foo', 'qux')
    ])



# Generated at 2022-06-24 03:11:55.705441
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp/", ["an", "array"])) == [
        "/tmp/an",
        "/tmp/array",
    ]



# Generated at 2022-06-24 03:12:00.246497
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/some/dir', ['a', 'b', 'c'])) == (
        '/some/dir/a',
        '/some/dir/b',
        '/some/dir/c',
    )
    assert tuple(join_each('', ['a', 'b', 'c'])) == ('a', 'b', 'c')



# Generated at 2022-06-24 03:12:04.035885
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b'])) == ['parent/a', 'parent/b']



# Generated at 2022-06-24 03:12:08.150996
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/u', ['1', '2', '3'])) == [
        '/u/1',
        '/u/2',
        '/u/3',
    ]

# Generated at 2022-06-24 03:12:16.551056
# Unit test for function join_each
def test_join_each():
    # Test 1
    path_parent = 'C:\Python'
    path_list = ['a', 'b', 'c.txt']
    result = join_each(path_parent, path_list)
    expected = ['C:\\Python\\a', 'C:\\Python\\b', 'C:\\Python\\c.txt']
    assert list(result) == expected
    # Test 2
    path_parent = ''
    path_list = []
    result = join_each(path_parent, path_list)
    expected = []
    assert list(result) == expected
    # Test 3
    path_parent = ''
    path_list = ['a', 'b', 'c.txt']
    result = join_each(path_parent, path_list)
    expected = ['a', 'b', 'c.txt']

# Generated at 2022-06-24 03:12:22.587889
# Unit test for function join_each
def test_join_each():
    p = '/usr/bin'
    iterator = join_each(p, ['ls', 'vim', 'cat'])
    assert next(iterator) == '/usr/bin/ls'
    assert next(iterator) == '/usr/bin/vim'
    assert next(iterator) == '/usr/bin/cat'



# Generated at 2022-06-24 03:12:29.165807
# Unit test for function join_each
def test_join_each():

    items = ["a", "b", "c"]
    expected = ["/a", "/b", "/c"]
    output = join_each("/", items)
    assert list(output) == expected

    items = ["a", "b", "c"]
    expected = ["/a/", "/b/", "/c/"]
    output = join_each("/", items, last_slash=True)
    assert list(output) == expected

# Generated at 2022-06-24 03:12:32.307526
# Unit test for function join_each
def test_join_each():
    parent = 'path'
    paths = ['a', 'b']
    assert list(join_each(parent, paths)) == [os.path.join(parent, p) for p in paths]



# Generated at 2022-06-24 03:12:35.160405
# Unit test for function join_each
def test_join_each():
    result = join_each('/home/filipe', ['Documents', 'Downloads'])
    assert next(result) == '/home/filipe/Documents'



# Generated at 2022-06-24 03:12:36.909526
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]



# Generated at 2022-06-24 03:12:41.976232
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/root", ["etc", "local", "bin"])) == [
        "/root/etc",
        "/root/local",
        "/root/bin",
    ]



# Generated at 2022-06-24 03:12:44.902428
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    iterable = ['a', 'b']
    expected = [os.path.join(parent, 'a'), os.path.join(parent, 'b')]
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-24 03:12:51.406260
# Unit test for function join_each
def test_join_each():
    """Test join_each"""
    test_path = [
            ('/usr/local', ['bin', 'include', 'lib']),
            ('/lib', ['a.out', 'libc.so.3']),
            ('/home/user', ['desktop', 'documents', 'downloads', 'music']),
            ('/usr/local/include', ['curl', 'freetype2', 'SDL2']),
            ('/usr/local/bin', ['aalib', 'autoconf', 'automake']),
            ]
    for test in test_path:
        path = test[0]
        dirs = test[1]
        assert list(join_each(path, dirs)) == [
                os.path.join(path, d) for d in dirs
                ]



# Generated at 2022-06-24 03:12:52.969625
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-24 03:12:56.611428
# Unit test for function join_each
def test_join_each():
    data = ["file1.txt", "file2.txt", "file3.txt"]
    assert join_each("/home/test", data) == \
            ["/home/test/file1.txt", "/home/test/file2.txt",
             "/home/test/file3.txt"]


# Generated at 2022-06-24 03:12:59.224565
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    iterable = ['user1', 'user2', 'user3']

    result = join_each(parent, iterable)

    assert result[0] == '/home/user1'
    assert result[1] == '/home/user2'
    assert result[2] == '/home/user3'


if __name__ == '__main__':
    print(test_join_each())

# Generated at 2022-06-24 03:13:04.262025
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == [
        '/tmp/a',
        '/tmp/b',
        '/tmp/c'
    ]



# Generated at 2022-06-24 03:13:09.035411
# Unit test for function join_each
def test_join_each():
    parent = '/tmp/foo'
    iterable = ['bar', 'baz']

    assert list(join_each(parent, iterable)) == [
        os.path.join(parent, 'bar'),
        os.path.join(parent, 'baz'),
    ]



# Generated at 2022-06-24 03:13:10.529081
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/', ('foo', 'bar'))) == ('/foo', '/bar')

# Generated at 2022-06-24 03:13:13.340311
# Unit test for function join_each
def test_join_each():
    paths = join_each('/home/bob', ['path1', 'path2'])

    for path in paths:
        assert path == '/home/bob/path1' or path == '/home/bob/path2'



# Generated at 2022-06-24 03:13:16.259579
# Unit test for function join_each
def test_join_each():
    paths = ["p1", "p2", "p3"]
    assert list(join_each("base", paths)) == [os.path.join("base", p) for p in paths]



# Generated at 2022-06-24 03:13:20.592905
# Unit test for function join_each
def test_join_each():
    parent = os.path.expanduser('~')
    children = ('test1', 'test2')
    expected = tuple(os.path.join(parent, child) for child in children)
    result = tuple(join_each(parent, children))
    assert expected == result

# Generated at 2022-06-24 03:13:30.316019
# Unit test for function join_each
def test_join_each():
    import subprocess
    import sys
    sample_dir = os.path.dirname(os.path.realpath(__file__))
    os.environ["PATH"] = os.pathsep.join(
        join_each(sample_dir, ["../src"])
    ) + os.pathsep + os.environ["PATH"]

    # prepare to run the test
    run_test_command = os.path.join(sample_dir, "run_test.sh")

    proc = subprocess.Popen(
        [sys.executable, run_test_command],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )
    out, err = proc.communicate()
    print(out.decode())
    print(err.decode())
    assert proc

# Generated at 2022-06-24 03:13:32.143088
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a/', 'b/'])) == ['/a/', '/b/']



# Generated at 2022-06-24 03:13:35.562395
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b'])) == ['/tmp/a', '/tmp/b']

# Generated at 2022-06-24 03:13:38.960066
# Unit test for function join_each
def test_join_each():
    parent = 'Parent'
    iterable = ['a', 'b', 'c']
    expected = ['Parent/a', 'Parent/b', 'Parent/c']
    actual = list(join_each(parent, iterable))
    assert actual == expected

# Generated at 2022-06-24 03:13:41.977487
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr/local", ["src", "bin", "include"])) == [
        "/usr/local/src",
        "/usr/local/bin",
        "/usr/local/include",
    ]

# Generated at 2022-06-24 03:13:48.319946
# Unit test for function join_each
def test_join_each():
    parent = os.getcwd()
    childs = (i for i in range(5))
    joined = join_each(parent, childs)
    for i in joined:
        print(i)
    else:
        print('-' * 30)

    parent = os.path.join(os.getcwd(), 'test')
    childs = ['a', 'b', 'c']
    joined = join_each(parent, childs)
    for i in joined:
        print(i)
    else:
        print('-' * 30)

