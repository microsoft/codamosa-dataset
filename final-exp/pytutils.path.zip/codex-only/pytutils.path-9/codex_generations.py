

# Generated at 2022-06-24 03:03:48.249734
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['foo', 'bar'])) == [
        '/tmp/foo', '/tmp/bar']



# Generated at 2022-06-24 03:03:49.098978
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', 'a', 'b')) == ['/home/a', '/home/b']

# Generated at 2022-06-24 03:03:50.128668
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:03:53.575070
# Unit test for function join_each
def test_join_each():
    assert [i for i in join_each("/", "abc")] == list("/a /b /c".split(" "))
    assert [i for i in join_each("/", "abc")] == list("/a /b /c".split(" "))



# Generated at 2022-06-24 03:03:57.966711
# Unit test for function join_each
def test_join_each():
    parent = "/home/karma"
    iterable = ["file1", "file2", "file3"]
    expected_result = ["/home/karma/file1", "/home/karma/file2", "/home/karma/file3"]
    assert list(join_each(parent, iterable)) == expected_result

# Generated at 2022-06-24 03:04:02.950993
# Unit test for function join_each
def test_join_each():
    parent = '/foo'
    iterable = ('bar', 'yoyo')
    expected = ('/foo/bar', '/foo/yoyo')

    actual = tuple(join_each(parent, iterable))

    assert actual == expected

# Generated at 2022-06-24 03:04:12.575939
# Unit test for function join_each
def test_join_each():
    # create a directory
    d = "test_data"
    if not os.path.isdir(d):
        os.makedirs(d)

    # Create files
    [open(os.path.join(d, f), 'a').close() for f in ["temp1.txt", "temp2.txt", "temp3.txt"]]

    # create a generator instance
    g = join_each(d, ["*.txt"])

    for i in g:
        assert os.path.isfile(i)

    # Delete files
    [os.remove(os.path.join(d, f)) for f in ["temp1.txt", "temp2.txt", "temp3.txt"]]

    # Delete directory
    os.rmdir(d)

# Generated at 2022-06-24 03:04:19.615951
# Unit test for function join_each
def test_join_each():
    parent = 'foo'
    child = ['bar', 'baz', 'qux']

    assert list(join_each(parent, child)) == [
        'foo/bar', 'foo/baz', 'foo/qux']


# find_files: recursive search of files
# @param path of directory that you would like to search
# @param file_names: iterable of strings
# @returns generator of file paths

# Generated at 2022-06-24 03:04:26.802528
# Unit test for function join_each
def test_join_each():
    # Simple join
    assert list(join_each("/a", ["b", "c"])) == ["/a/b", "/a/c"]

    # Trailing slash
    assert list(join_each("/a/", ["b/", "c/"])) == ["/a/b/", "/a/c/"]

    # Non-absolute paths
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]


# TODO: Make the test more robust

# Generated at 2022-06-24 03:04:31.549816
# Unit test for function join_each
def test_join_each():
    root = ['/', '/home', '/home/user']
    subs = ['a', 'b', 'c']
    result = ['//a', '//b', '//c', '/home/a', '/home/b', '/home/c',
              '/home/user/a', '/home/user/b', '/home/user/c']
    expected = list(join_each(root, subs))
    assert expected == result



# Generated at 2022-06-24 03:04:37.019328
# Unit test for function join_each
def test_join_each():
    """Tests join_each to make sure it produces the correct output.
    """
    parent = 'parent'
    iterable = ('child', 'child2')
    expected = ('parent/child', 'parent/child2')

    assert tuple(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:04:38.445580
# Unit test for function join_each
def test_join_each():
    assert os.path.join('a', 'b') in join_each('a', ['b'])



# Generated at 2022-06-24 03:04:43.133249
# Unit test for function join_each
def test_join_each():
    assert list(join_each(os.path.sep, ["home", "jw"])) == [
        os.path.join(os.path.sep, "home"),
        os.path.join(os.path.sep, "jw"),
    ]



# Generated at 2022-06-24 03:04:48.265273
# Unit test for function join_each
def test_join_each():
    ret = list(join_each('/root/path', [
        'a',
        'b/c/d',
        'e/',
        '/f/g/h',
    ]))
    assert ret == [
        '/root/path/a',
        '/root/path/b/c/d',
        '/root/path/e/',
        '/f/g/h',
    ]



# Generated at 2022-06-24 03:04:57.116120
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a/b', ['c'])) == ['a/b/c']
    assert list(join_each('.', [''])) == ['.']
    assert list(join_each('', [])) == []
    assert list(join_each('.', [])) == []
    assert list(join_each('a', [])) == []
    assert list(join_each('a/b', [])) == []



# Generated at 2022-06-24 03:05:03.432250
# Unit test for function join_each
def test_join_each():
    assert list(join_each("", ['a', 'b'])) == ['a', 'b']
    # The following tests are redundant in the sense that they test
    # the same as the above test.
    assert list(join_each("", ['a', 'b'])) != ['a', 'b', 'c']
    assert list(join_each("a", ['b', 'c'])) == ['a/b', 'a/c']


# Define par_map

# Generated at 2022-06-24 03:05:06.231423
# Unit test for function join_each
def test_join_each():
    parent = '/a/b'
    iterable = ['c', 'd', 'e']
    expected = ['/a/b/c', '/a/b/d', '/a/b/e']
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-24 03:05:09.492694
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/bin', ['python', 'ruby', 'perl'])) == [
        '/usr/bin/python',
        '/usr/bin/ruby',
        '/usr/bin/perl'
    ]

# Generated at 2022-06-24 03:05:16.316313
# Unit test for function join_each
def test_join_each():
    p = "parent"
    r = ['first', 'second']
    f = join_each(p, r)
    a = [os.path.join(p, e) for e in r]
    assert list(f) == a


# test
if __name__ == "__main__":
    print("test_join_each")
    test_join_each()

# Generated at 2022-06-24 03:05:23.316756
# Unit test for function join_each
def test_join_each():
    # First assign a value to parent
    parent = 'foo'
    # Then declare the iterable to be joined with parent
    iterable = ['bar', 'baz']
    # Assert that the function yields the correct values
    assert list(join_each(parent, iterable)) == [
        os.path.join(parent, 'bar'),
        os.path.join(parent, 'baz'),
    ]



# Generated at 2022-06-24 03:05:26.566440
# Unit test for function join_each
def test_join_each():
    r = tuple(join_each(sys.path[0], ('a', 'b', 'c')))
    assert r == (os.path.join(sys.path[0], 'a'), os.path.join(sys.path[0], 'b'), os.path.join(sys.path[0], 'c'))


import subprocess


# run_and_log: run command and log stdout to logfile
# return integer exit code of command

# Generated at 2022-06-24 03:05:35.419705
# Unit test for function join_each
def test_join_each():
    from itertools import product
    import random
    numtests = 1000
    abs_paths = [os.path.abspath(random.choice(os.listdir()))
                 for i in range(numtests)]
    almost_root_paths = [os.path.abspath(random.choice(os.listdir(a)))
                         for a in abs_paths]
    paths = [os.path.join(abs, almost_root_path)
             for abs, almost_root_path in zip(abs_paths, almost_root_paths)]
    for p, q in product(abs_paths, almost_root_paths):
        assert(os.path.join(p, q) in join_each(p, [q]))



# Generated at 2022-06-24 03:05:38.046072
# Unit test for function join_each
def test_join_each():
    expected = ["a/b", "a/c"]
    actual = list(join_each("a", ["b", "c"]))
    assert expected == actual



# Generated at 2022-06-24 03:05:43.858589
# Unit test for function join_each
def test_join_each():
    path = os.path.dirname(__file__)
    parent = os.path.join(path, 'join_each')
    result = [os.path.join(parent, 'a.png'),
              os.path.join(parent, 'b.png'),
              os.path.join(parent, 'c.png')]
    for i in zip(result, join_each(parent, ['a.png', 'b.png', 'c.png'])):
        assert i[0] == i[1]



# Generated at 2022-06-24 03:05:47.913966
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('parent', ['child1', 'child2', 'child3'])) ==
           ['parent\\child1', 'parent\\child2', 'parent\\child3'])

# Generated at 2022-06-24 03:05:49.731593
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['a', 'b', 'c']
    result = join_each(parent, iterable)
    assert isinstance(result, types.GeneratorType)
    assert list(result) == [os.path.join(parent, p) for p in iterable]



# Generated at 2022-06-24 03:05:51.286959
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['usr', 'local'])) == ['/usr', '/local']

# Generated at 2022-06-24 03:05:53.621550
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    children = ('a', 'b', 'c')
    children_joined = ('/home/a', '/home/b', '/home/c')
    assert list(join_each(parent, children)) == list(children_joined)

# Generated at 2022-06-24 03:06:01.703614
# Unit test for function join_each
def test_join_each():
    # case 1
    parent = 'movies'
    paths = ['action', 'comedy', 'sci-fi/']
    result = join_each(parent, paths)
    subpaths = list(result)
    assert subpaths[0] == 'movies/action'
    assert subpaths[1] == 'movies/comedy'
    assert subpaths[2] == 'movies/sci-fi/'

# Turn the script into a reusable module
if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:06:04.925296
# Unit test for function join_each
def test_join_each():
    assert list(join_each(None, (1, 2, 3))) == ['1', '2', '3']
    assert list(join_each('/tmp', ('a', 'b', 'c'))) == [
        '/tmp/a', '/tmp/b', '/tmp/c']

# Generated at 2022-06-24 03:06:07.957902
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/var/tmp/', ['one', 'two', 'three'])) == [
        '/var/tmp/one', '/var/tmp/two', '/var/tmp/three']



# Generated at 2022-06-24 03:06:09.970824
# Unit test for function join_each
def test_join_each():
    paths = join_each(r'C:\Users', [r'Chris', r'Tim'])
    assert ''.join(paths) == r'C:\Users\Chris\Tim'



# Generated at 2022-06-24 03:06:12.514744
# Unit test for function join_each
def test_join_each():
    parent = '/'
    iterable = ['/etc', 'boot']
    result = list(join_each(parent, iterable))
    assert result[0] == '/etc'
    assert result[1] == '/boot'


test_join_each()

# Generated at 2022-06-24 03:06:17.554249
# Unit test for function join_each
def test_join_each():
    parent = '/usr/lib/parent'
    iterable = [
        'child1',
        'child2'
    ]
    result = [
        '/usr/lib/parent/child1',
        '/usr/lib/parent/child2'
    ]

    assert list(join_each(parent, iterable)) == result

# Generated at 2022-06-24 03:06:20.015531
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b']
    for i, comma_i in zip(iterable, join_each('/path/to', iterable)):
        assert comma_i == '/path/to/{}'.format(i)



# Generated at 2022-06-24 03:06:25.203256
# Unit test for function join_each
def test_join_each():
    paths = ["etc", "bin", "lib"]
    parent = "/usr"
    expected = ["/usr/etc", "/usr/bin", "/usr/lib"]
    assert list(join_each(parent, paths)) == expected



# Generated at 2022-06-24 03:06:32.246370
# Unit test for function join_each
def test_join_each():
    # test with a empty iterable
    assert list(join_each('/etc', [])) == []
    # test with a single item iterable
    assert list(join_each('/etc', ['passwd'])) == ['/etc/passwd']
    # test with multiple item iterable
    assert list(join_each('/etc', ['passwd', 'group'])) == [
        '/etc/passwd', '/etc/group']

# Generated at 2022-06-24 03:06:35.557663
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['foo', 'bar', 'baz'])) == [
        'parent/foo',
        'parent/bar',
        'parent/baz'
    ]

# Generated at 2022-06-24 03:06:38.802919
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['x/y', 'z/', 'w'])) == [
        '/tmp/x/y',
        '/tmp/z/',
        '/tmp/w',
    ]

# Generated at 2022-06-24 03:06:41.459742
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['alex', 'john', 'dave'])) == [
        '/home/alex',
        '/home/john',
        '/home/dave'
    ]



# Generated at 2022-06-24 03:06:46.412198
# Unit test for function join_each
def test_join_each():
    parent = '.'
    children = ['a.txt', 'b.txt', 'c.txt']
    assert list(join_each(parent, children)) == [
        './a.txt', './b.txt', './c.txt']



# Generated at 2022-06-24 03:06:49.956050
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['tmp', 'home'])) == ['/tmp', '/home']
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == ['/tmp/a', '/tmp/b', '/tmp/c']



# Generated at 2022-06-24 03:06:53.908621
# Unit test for function join_each
def test_join_each():
    # Arrange
    parent = "/home/user"
    iterable = [
        "recordings",
        "invoices",
        "content",
    ]

    # Act
    result = list(join_each(parent, iterable))

    # Assert
    assert result == [
        "/home/user/recordings",
        "/home/user/invoices",
        "/home/user/content",
    ]

# Generated at 2022-06-24 03:06:57.192381
# Unit test for function join_each
def test_join_each():
    assert list(join_each("parent", ["a", "b", "c"])) == ["parent/a", "parent/b", "parent/c"]



# Generated at 2022-06-24 03:07:05.344245
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', 'b')) == ['a/b']
    assert list(join_each('/a', '/b')) == ['/a/b']
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('', ['b', 'c'])) == ['b', 'c']
    assert list(join_each(None, ['b', 'c'])) == ['b', 'c']
    assert list(join_each('', None)) == []
    assert list(join_each('', [None, 'c'])) == ['c']
    assert list(join_each('a/b', 'c')) == ['a/b/c']



# Generated at 2022-06-24 03:07:08.378919
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["a", "b"])) == ["/a", "/b"]
    assert list(join_each("/a/b", ["c", "d"])) == ["/a/b/c", "/a/b/d"]



# Generated at 2022-06-24 03:07:11.513072
# Unit test for function join_each
def test_join_each():
    parent = "/home/user/dir"
    children = ["a", "b", "c"]

    joined_children = list(join_each(parent, children))

    assert joined_children == ["/home/user/dir/a", "/home/user/dir/b", "/home/user/dir/c"]

# Generated at 2022-06-24 03:07:15.797945
# Unit test for function join_each
def test_join_each():
    p = "home"
    iterable = ["lib", "lib64", "share", "include"]
    joined = list(join_each(p, iterable))
    assert joined[0] == "/home/lib"
    assert joined[1] == "/home/lib64"
    assert joined[2] == "/home/share"
    assert joined[3] == "/home/include"



# Generated at 2022-06-24 03:07:20.159626
# Unit test for function join_each
def test_join_each():
    assert list(join_each('test', ['1', '2'])) == ['test/1', 'test/2']

# Generated at 2022-06-24 03:07:28.710264
# Unit test for function join_each
def test_join_each():
    assert set(join_each('', ['a', 'b'])) == set(['a', 'b'])
    assert set(join_each('/somepath/', ['a', 'b'])) == set(['/somepath/a', '/somepath/b'])
    assert set(join_each('', ['', 'b'])) == set(['', 'b'])
    assert set(join_each('/somepath/', ['', 'b'])) == set(['/somepath/', '/somepath/b'])
    assert set(join_each('/somepath', ['a', 'b'])) == set(['/somepath/a', '/somepath/b'])
    assert set(join_each('/somepath', ['', 'b'])) == set(['/somepath/', '/somepath/b'])




# Generated at 2022-06-24 03:07:30.000893
# Unit test for function join_each
def test_join_each():
    parent = '/home/'
    iterable = ['usr', 'bin']

    assert list(join_each(parent, iterable)) == ['/home/usr', '/home/bin']

# Generated at 2022-06-24 03:07:36.197587
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["a", "b", "c"])) == ["/home/a", "/home/b", "/home/c"]



# Generated at 2022-06-24 03:07:38.911705
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ('a', 'b', 'c'))) == [
        '/tmp/a',
        '/tmp/b',
        '/tmp/c'
    ]



# Generated at 2022-06-24 03:07:41.172261
# Unit test for function join_each
def test_join_each():
    parent = 'foo'
    current_directory = os.getcwd()
    expected = [os.path.join(current_directory, 'foo'),
                os.path.join(current_directory, 'foo_bar'),
                os.path.join(current_directory, 'foo_bar_baz')]
    actual = join_each(parent, ['', '_bar', '_bar_baz'])
    assert actual == expected



# Generated at 2022-06-24 03:07:47.831256
# Unit test for function join_each
def test_join_each():
    assert list(join_each("c:", ["abc", "xyz"])) == [
        "c:\\abc", "c:\\xyz"
    ]
    assert list(join_each("c:\\", ["abc", "xyz"])) == [
        "c:\\abc", "c:\\xyz"
    ]
    assert list(join_each("c:\\", ["\\abc", "\\xyz"])) == [
        "c:\\abc", "c:\\xyz"
    ]



# Generated at 2022-06-24 03:07:54.235175
# Unit test for function join_each
def test_join_each():
    parent = '/parent'
    iterable = ['child_one', 'child_two']
    joined = join_each(parent, iterable)
    assert '/parent/child_one' in joined
    assert '/parent/child_two' in joined



# Generated at 2022-06-24 03:08:00.116226
# Unit test for function join_each
def test_join_each():
    assert touple(join_each(path_a, iter_a)) == touple(path_join_a)


path_a = 'abc'
path_join_a = ('abc/def', 'abc/xyz')
iter_a = ('def', 'xyz')

# Generated at 2022-06-24 03:08:05.005665
# Unit test for function join_each
def test_join_each():
    l = ['a', 'b']
    joined = list(join_each('dir', l))
    correct = ['dir/a', 'dir/b']
    assert joined == correct



# Generated at 2022-06-24 03:08:06.295186
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:08:13.981888
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo/bar', 'bar/baz'])) == [
      '/foo/bar',
      '/bar/baz',
    ]
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['', ''])) == ['/', '/']



# Generated at 2022-06-24 03:08:20.764603
# Unit test for function join_each
def test_join_each():
    parent = os.path.join("foo", "bar")
    expected = [
        os.path.join("foo", "bar", "baz"),
        os.path.join("foo", "bar", "qux"),
        os.path.join("foo", "bar", "quux"),
    ]

    # Convert paths to strings because join_each returns a generator
    assert list(map(str, join_each(parent, ("baz", "qux", "quux")))) == expected


import unittest



# Generated at 2022-06-24 03:08:26.715939
# Unit test for function join_each
def test_join_each():
    parent_dir = '/foo'
    child_dirs = ['bar', 'baz', 'foobar']
    joined_dirs = list(join_each(parent_dir, child_dirs))
    assert [
        '/foo/bar',
        '/foo/baz',
        '/foo/foobar',
    ] == joined_dirs



# Generated at 2022-06-24 03:08:27.476219
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:08:31.372934
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('.', ('a', 'b', 'c'))) == ('./a', './b', './c')
    assert tuple(join_each('/', ('a', 'b', 'c'))) == ('/a', '/b', '/c')



# Generated at 2022-06-24 03:08:33.820656
# Unit test for function join_each
def test_join_each():
    parent = 1
    iterable = tuple(range(5))
    assert list(join_each(parent, iterable)) == [
        os.path.join(parent, p) for p in iterable
    ]



# Generated at 2022-06-24 03:08:38.073635
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar'])) == ['/foo', '/bar']
    assert list(join_each('/usr/local', ['bin', 'lib', 'include'])) == ['/usr/local/bin', '/usr/local/lib', '/usr/local/include']
    assert list(join_each('/usr/local/bin', ['tar', 'python', 'python2.7'])) == ['/usr/local/bin/tar', '/usr/local/bin/python', '/usr/local/bin/python2.7']

# Generated at 2022-06-24 03:08:39.883762
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']



# Generated at 2022-06-24 03:08:44.145688
# Unit test for function join_each
def test_join_each():
    assert join_each('/', ['foo', 'bar', 'baz']) == ['/foo', '/bar', '/baz']
    assert join_each('/', []) == []
    assert join_each('/', ['foo']) == ['/foo']
    assert join_each('/', ['foo/']) == ['/foo/']
    assert join_each('/foo/bar', ['baz', 'spam', 'eggs']) == \
        ['/foo/bar/baz', '/foo/bar/spam', '/foo/bar/eggs']



# Generated at 2022-06-24 03:08:47.710687
# Unit test for function join_each
def test_join_each():
    parent = os.path.join("12", "34", "56")
    iterable = ("a", "b", "c")
    expected = tuple(os.path.join(parent, p) for p in iterable)
    result = tuple(join_each(parent, iterable))
    assert result == expected

# Generated at 2022-06-24 03:08:54.664937
# Unit test for function join_each
def test_join_each():
    parent = '/usr/local/bin'
    children = ('ls', 'pwd', 'sh')
    path = join_each(parent, children)
    assert next(path) == '/usr/local/bin/ls'
    assert next(path) == '/usr/local/bin/pwd'
    assert next(path) == '/usr/local/bin/sh'
    try:
        next(path)
    except StopIteration:
        print('No more value returned')


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:08:57.906182
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/foo", ["bar", "/baz"])) == ["/foo/bar", "/foo/baz"]

# Generated at 2022-06-24 03:08:59.991815
# Unit test for function join_each
def test_join_each():
    parent = '/tmp/'
    assert list(join_each(parent, ('abc', 'def', 'ghi'))) == \
           ['/tmp/abc', '/tmp/def', '/tmp/ghi']



# Generated at 2022-06-24 03:09:01.493884
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ('a', '/b/', 'c'))) == ['/a', '/b', '/c']



# Generated at 2022-06-24 03:09:06.989648
# Unit test for function join_each
def test_join_each():
    assert [*join_each('/foo/bar', ['a', 'b', 'c'])] == \
        ['/foo/bar/a', '/foo/bar/b', '/foo/bar/c']



# Generated at 2022-06-24 03:09:10.236736
# Unit test for function join_each
def test_join_each():
    assert_equal(list(join_each('/usr', ['lib64', 'lib'])),
                 ['/usr/lib64', '/usr/lib'])



# Generated at 2022-06-24 03:09:13.544655
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/c', 'xyz')) == ['/a/b/c/x', '/a/b/c/y', '/a/b/c/z']



# Generated at 2022-06-24 03:09:18.747990
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/")) == ["/"]
    assert list(join_each("/test", ["a", "b"])) == ["/test/a", "/test/b"]



# Generated at 2022-06-24 03:09:25.355729
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["a", "b"])) == \
        ["foo" + os.sep + "a", "foo" + os.sep + "b"]
    assert list(join_each("foo", [])) == []



# Generated at 2022-06-24 03:09:29.682374
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == [
        '/tmp/a', '/tmp/b', '/tmp/c']

# Generated at 2022-06-24 03:09:38.037046
# Unit test for function join_each
def test_join_each():
    # Test case 1
    p = "C:/Users/Admin"
    iterable = ("Documents/Python/Python_Fundamentals",
                "Music/Twist and Shout.mp3")
    ans = ["C:/Users/Admin/Documents/Python/Python_Fundamentals",
           "C:/Users/Admin/Music/Twist and Shout.mp3"]
    assert list(join_each(p, iterable)) == ans

    # Test case 2
    p = "/Users/Admin"
    iterable = ("Documents/Python/Python_Fundamentals",
                "Music/Twist and Shout.mp3")
    ans = ["/Users/Admin/Documents/Python/Python_Fundamentals",
           "/Users/Admin/Music/Twist and Shout.mp3"]

# Generated at 2022-06-24 03:09:40.969870
# Unit test for function join_each
def test_join_each():
    assert list(join_each('data', ['foo', 'bar'])) == [
        'data/foo', 'data/bar']

# Generated at 2022-06-24 03:09:45.534728
# Unit test for function join_each
def test_join_each():
    parent = pathlib.Path('/some/path')
    iterable = ('a', 'b', 'c')

    assert list(join_each(parent, iterable)) == [
        pathlib.Path('/some/path/a'),
        pathlib.Path('/some/path/b'),
        pathlib.Path('/some/path/c'),
    ]

# Generated at 2022-06-24 03:09:50.002125
# Unit test for function join_each
def test_join_each():
    def test(args, expect):
        assert list(join_each(*args)) == expect

    test(("/tmp", ["/foo", "/bar"]), ["/tmp/foo", "/tmp/bar"])
    test(("/home/joe/foo/../bar", ["/foo", "/bar"]),
         ["/home/joe/foo/../bar/foo", "/home/joe/foo/../bar/bar"])



# Generated at 2022-06-24 03:09:53.779897
# Unit test for function join_each
def test_join_each():
    assert list(join_each('path', ['a', 'b'])) == ['path/a', 'path/b']

# Generated at 2022-06-24 03:09:56.950848
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/user", ["a", "b", "c"])) == [
        "/home/user/a",
        "/home/user/b",
        "/home/user/c",
    ]



# Generated at 2022-06-24 03:10:00.601804
# Unit test for function join_each
def test_join_each():
    res = list(join_each('/a/b', ['c', 'd', 'e']))
    expected = [
        '/a/b/c',
        '/a/b/d',
        '/a/b/e',
    ]
    assert res == expected



# Generated at 2022-06-24 03:10:03.900314
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == \
        ['foo/bar', 'foo/baz']



# Generated at 2022-06-24 03:10:09.518772
# Unit test for function join_each
def test_join_each():
    assert list(join_each("path", ["a", "b"])) == ["path/a", "path/b"]



# Generated at 2022-06-24 03:10:13.177500
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a/b", ["c", "d", "e"])) == ["/a/b/c", "/a/b/d", "/a/b/e"]



# Generated at 2022-06-24 03:10:16.728951
# Unit test for function join_each
def test_join_each():
    # Case: normal
    assert list(join_each('/foo', ['bar', 'baz'])) == ['/foo/bar', '/foo/baz']
    # Case: empty list
    assert list(join_each('/foo', [])) == []

# Generated at 2022-06-24 03:10:24.585317
# Unit test for function join_each
def test_join_each():
    parent_dir_1 = '/etc'
    list_dir_1 = ['one', 'two', 'three']
    expected_dirs_1 = ['/etc/one', '/etc/two', '/etc/three']
    returned_dirs_1 = list(join_each(parent_dir_1, list_dir_1))
    assert expected_dirs_1 == returned_dirs_1


# Test the function join_each on the os.listdir

# Generated at 2022-06-24 03:10:28.673405
# Unit test for function join_each
def test_join_each():
    print('Testing join_each_')
    assert list(join_each('/usr', ['bin', 'lib'])) == [
        '/usr/bin',
        '/usr/lib'
    ]



# Generated at 2022-06-24 03:10:32.010126
# Unit test for function join_each
def test_join_each():
    expected = ["/opt/google/a", "/opt/google/b", "/opt/google/c"]
    assert(list(join_each("/opt/google", ["a", "b", "c"])) == expected)



# Generated at 2022-06-24 03:10:36.290240
# Unit test for function join_each
def test_join_each():
    """
    Testing join_each function
    :return:
    """
    path = os.path.join("..", "..", "..", "..")
    elems = ["docs", "tools", "tests"]
    results = [os.path.join(path, name) for name in elems]
    for i, p in enumerate(join_each(path, elems)):
        assert p == results[i]

# Generated at 2022-06-24 03:10:41.242399
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-24 03:10:42.981807
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/tmp', ['foo', 'bar', 'baz']))
    assert result == ['/tmp/foo', '/tmp/bar', '/tmp/baz']



# Generated at 2022-06-24 03:10:58.885748
# Unit test for function join_each
def test_join_each():

    # Return empty list
    if list(join_each('/home', [])) != []:
        print('Test failed')
        exit(1)

    # Return
    if list(join_each('/home', ['a', 'b', 'c'])) != [
            '/home/a',
            '/home/b',
            '/home/c',
    ]:
        print('Test failed')
        exit(1)

    print('Test passed')
    exit(0)


test_join_each()

#https://stackoverflow.com/questions/6699360/python-equivalent-of-the-joi

# Generated at 2022-06-24 03:11:03.501407
# Unit test for function join_each
def test_join_each():
    assert list(join_each('./', ['a', 'b'])) == ['./a', './b']

# Generated at 2022-06-24 03:11:04.754269
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar'])) == ['/foo', '/bar']

# Generated at 2022-06-24 03:11:06.026017
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['etc', 'lib'])) == ['/etc', '/lib']

# Generated at 2022-06-24 03:11:08.601089
# Unit test for function join_each
def test_join_each():
    parent = '/usr/local/opt'
    iterable = ['git', 'python3']
    assert list(join_each(parent, iterable)) == [
        '/usr/local/opt/git', '/usr/local/opt/python3'
    ]



# Generated at 2022-06-24 03:11:10.293155
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['test1', 'test2'])) == ['/tmp/test1', '/tmp/test2']



# Generated at 2022-06-24 03:11:16.192028
# Unit test for function join_each
def test_join_each():
    p = dir
    iterable = ['a', 'b', 'c']
    expected_result = [
        os.path.join(dir, 'a'),
        os.path.join(dir, 'b'),
        os.path.join(dir, 'c')
    ]
    assert list(join_each(p, iterable)) == expected_result

# Generated at 2022-06-24 03:11:19.748243
# Unit test for function join_each
def test_join_each():
    parent = "/a/b/c"
    children = ["d", "e", "f"]
    joined = list(join_each(parent, children))
    assert len(joined) == 3
    assert "/a/b/c/d" in joined
    assert "/a/b/c/e" in joined
    assert "/a/b/c/f" in joined

# Generated at 2022-06-24 03:11:25.214088
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["a", "b", "c"]
    expected = ["parent/a", "parent/b", "parent/c"]

    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-24 03:11:26.771849
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b'])) == ['/tmp/a', '/tmp/b']



# Generated at 2022-06-24 03:11:33.089600
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    child = ['child1', 'child2', 'child3']
    actual = [p for p in join_each(parent, child)]
    expected = ['parent/child1', 'parent/child2', 'parent/child3']
    assert actual == expected



# Generated at 2022-06-24 03:11:39.877262
# Unit test for function join_each
def test_join_each():
    assert list(join_each(1, [1, 2, 3])) == [1, 2, 3]
    assert list(join_each([1, 2], [1, 2, 3])) == [[1, 2], [1, 2], [1, 2]]
    assert list(join_each([1, 2], [1, 2])) == [[1, 2], [1, 2]]



# Generated at 2022-06-24 03:11:42.989106
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c", "d"])) == ["a/b", "a/c", "a/d"]

# Generated at 2022-06-24 03:11:49.956898
# Unit test for function join_each
def test_join_each():
    with pytest.raises(TypeError):
        join_each(0, [])

    with pytest.raises(TypeError):
        join_each([], 0)

    assert list(join_each('pictures/', ['photo1.jpg', 'photo2.jpg'])) == \
           ['pictures/photo1.jpg', 'pictures/photo2.jpg']

    assert list(join_each('pictures/', [])) == []



# Generated at 2022-06-24 03:11:52.518926
# Unit test for function join_each
def test_join_each():
    assert list(join_each('./', ['a'])) == ['./a']
    assert list(join_each('/usr/local/bin', ['a', 'b', 'c'])) == [
        '/usr/local/bin/a', '/usr/local/bin/b', '/usr/local/bin/c'
    ]
    assert list(join_each('./usr/local/bin', [])) == []

# Generated at 2022-06-24 03:11:55.907122
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c', 'd'])) == ['a/b', 'a/c', 'a/d']



# Generated at 2022-06-24 03:12:01.009482
# Unit test for function join_each
def test_join_each():
    # create a pathlist
    pathlist = [os.path.join('path1', 'path2', 'path3', 'file'),
                os.path.join('path1', 'path2', 'path4')]
    assert set(join_each('path1', join_each('path2',    # noqa: E999
                                            join_each('path3', ['file']))))\
        == set(join_each('path1', join_each('path2', pathlist)))

# Generated at 2022-06-24 03:12:02.793956
# Unit test for function join_each
def test_join_each():
    p = '/tmp'
    print(list(join_each(p, ('foo', 'bar'))))



# Generated at 2022-06-24 03:12:07.982179
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ['/c', '/d', '/e'])) == ['/a/b/c', '/a/b/d', '/a/b/e']



# Generated at 2022-06-24 03:12:14.383310
# Unit test for function join_each
def test_join_each():
    assert list(join_each(os.path.curdir, ["a", "b", "c"])) == ['a', 'b', 'c']
    assert list(join_each("/", ["a", "b", "c"])) == ['/a', '/b', '/c']
    assert list(join_each("a", ["b", "c"])) == ['a/b', 'a/c']
    assert list(join_each("a", ["b", "c", ""])) == ['a/b', 'a/c', 'a/']



# Generated at 2022-06-24 03:12:15.694523
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ("home", "test"))) == ["/home", "/test"]



# Generated at 2022-06-24 03:12:17.223216
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['foo', 'bar'])) == ['/tmp/foo', '/tmp/bar']



# Generated at 2022-06-24 03:12:22.209794
# Unit test for function join_each
def test_join_each():
    inputs = [
        (os.path.abspath(''), ['test1', 'test2', 'test3']),
        (os.path.abspath('.'), ['test1', 'test2', 'test3']),
        (os.path.abspath('./'), ['test1', 'test2', 'test3']),
    ]

# Generated at 2022-06-24 03:12:23.138308
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b", "c"])) == ["/tmp/a", "/tmp/b", "/tmp/c"]

# Generated at 2022-06-24 03:12:27.201049
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c', 'd'])) == ['/a', '/b', '/c', '/d']



# Generated at 2022-06-24 03:12:37.879329
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["userA", "userB"])) == ["/home/userA", "/home/userB"]
    assert list(join_each("/home/userA", ["docs", "pics", "music"])) == ["/home/userA/docs", "/home/userA/pics",
                                                                         "/home/userA/music"]
    assert list(join_each("/etc/apache2", ["conf.d", "conf.d/other.conf", "sites-available"])) == ["/etc/apache2/conf.d",
                                                                                                  "/etc/apache2/conf.d/other.conf",
                                                                                                  "/etc/apache2/sites-available"]

# Generated at 2022-06-24 03:12:43.188773
# Unit test for function join_each
def test_join_each():
    d = ['a', 'b', 'c']
    l = join_each('/tmp', d)
    assert isinstance(l, types.GeneratorType)
    assert list(l) == ['/tmp/a', '/tmp/b', '/tmp/c']



# Generated at 2022-06-24 03:12:45.617172
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp/', ['foo', 'bar', 'baz.txt'])) == [
        '/tmp/foo',
        '/tmp/bar',
        '/tmp/baz.txt',
    ]



# Generated at 2022-06-24 03:12:47.458174
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/path', ['to', 'file'])) == ['/path/to', '/path/file']



# Generated at 2022-06-24 03:12:58.286892
# Unit test for function join_each
def test_join_each():
    p = "a/b/c"
    assert list(join_each(p, [])) == []
    assert list(join_each(p, [''])) == ['a/b/c']
    assert list(join_each(p, ['1', '2', '3'])) == ['a/b/c/1', 'a/b/c/2', 'a/b/c/3']
    # Now test with a different parent, this is still valid
    p = "/tmp"
    assert list(join_each(p, [''])) == ['/tmp']
    assert list(join_each(p, ['1', '2', '3'])) == ['/tmp/1', '/tmp/2', '/tmp/3']



# Generated at 2022-06-24 03:12:59.792471
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]



# Generated at 2022-06-24 03:13:09.536377
# Unit test for function join_each
def test_join_each():
    a = ['a', 'b', 'c']
    a_joined = ['a/a', 'a/b', 'a/c']
    b = ['a', 'b', 'c']
    b_joined = ['a/a', 'a/b', 'a/c']
    c = ['a', 'b', 'c']
    c_joined = ['a/a', 'a/b', 'a/c']

    assert ''.join(str(s) for s in join_each('a', a)) == ''.join(str(s) for s in a_joined)
    assert ''.join(str(s) for s in join_each('a', b)) == ''.join(str(s) for s in b_joined)
    assert ''.join(str(s) for s in join_each('a', c))

# Generated at 2022-06-24 03:13:17.259104
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]


# This recursive generator traverses a directory tree, yielding a 3-tuple of
# (path, names, files)
#
# path is the directory path
# names is a list of directories within this path
# files is a list of files within this path
#
# It is equivalent to the Python os.walk but yields a result for each directory
# instead of returning a result for the whole tree traversal.


# Generated at 2022-06-24 03:13:17.714616
# Unit test for function join_each

# Generated at 2022-06-24 03:13:22.455039
# Unit test for function join_each
def test_join_each():
    parent = '.'
    iterable = ['image1.jpg', 'image2.jpg', 'image3.jpg']
    for f in join_each(parent, iterable):
        print(f)


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-24 03:13:26.555958
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    parent = '/'
    result = [os.path.join(parent, p) for p in iterable]
    assert list(join_each(parent, iterable)) == result

# Generated at 2022-06-24 03:13:35.446216
# Unit test for function join_each
def test_join_each():
    tests = [
        ('/', ['etc', 'usr'], ['/etc', '/usr']),
        ('/usr', ['local', 'bin'], ['/usr/local', '/usr/bin']),
        ('.', ['usr', 'local'], [os.path.join('.', p) for p in ['usr', 'local']]),
        ('.', [], [])
    ]

    for parent, children, expected in tests:
        actual = list(join_each(parent, children))
        assert actual == expected, "Expected %s but got %s" % (expected, actual)

# Generated at 2022-06-24 03:13:40.921795
# Unit test for function join_each
def test_join_each():
    assert list(join_each('abc', 'def')) == ['abc/def']
    assert list(join_each('abc', iter('def'))) == ['abc/def']
    assert list(join_each('abc', ['def', 'ghi'])) == ['abc/def', 'abc/ghi']
    assert list(join_each('abc', (p for p in ['def', 'ghi']))) \
        == ['abc/def', 'abc/ghi']


# Invoked by Python 3.2 and later

# Generated at 2022-06-24 03:13:49.251833
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    from itertools import product