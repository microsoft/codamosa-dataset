

# Generated at 2022-06-18 04:26:48.182242
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-18 04:26:50.393112
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-18 04:26:52.152934
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["a", "b"])) == ["/a", "/b"]



# Generated at 2022-06-18 04:26:54.327999
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-18 04:26:57.074492
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == ['/tmp/a', '/tmp/b', '/tmp/c']



# Generated at 2022-06-18 04:27:01.236490
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['a'])) == ['/a']



# Generated at 2022-06-18 04:27:03.005567
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', ['a', 'b', 'c'])) == [
        '/home/user/a', '/home/user/b', '/home/user/c']



# Generated at 2022-06-18 04:27:10.961932
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', ['a', 'b', 'c', ''])) == ['/a', '/b', '/c', '/']
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['a', 'b', 'c', 'd'])) == ['/a', '/b', '/c', '/d']



# Generated at 2022-06-18 04:27:15.391012
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['a'])) == ['/a']



# Generated at 2022-06-18 04:27:16.142630
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']

