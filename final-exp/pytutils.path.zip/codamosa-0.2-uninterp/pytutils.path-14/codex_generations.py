

# Generated at 2022-06-18 04:26:48.135065
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []



# Generated at 2022-06-18 04:26:50.343963
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-18 04:26:52.103710
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-18 04:26:54.465519
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []



# Generated at 2022-06-18 04:26:56.366356
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-18 04:26:59.487983
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', [])) == []



# Generated at 2022-06-18 04:27:02.934337
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['a'])) == ['/a']



# Generated at 2022-06-18 04:27:04.659207
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']



# Generated at 2022-06-18 04:27:06.282858
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-18 04:27:09.370507
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']

