

# Generated at 2022-06-18 04:26:48.335944
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == [
        '/a', '/b', '/c']
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['a'])) == ['/a']
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-18 04:26:51.781712
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['a'])) == ['/a']



# Generated at 2022-06-18 04:26:53.647771
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == ['/tmp/a', '/tmp/b', '/tmp/c']



# Generated at 2022-06-18 04:26:56.674872
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-18 04:26:59.394967
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []



# Generated at 2022-06-18 04:27:04.139611
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['a'])) == ['/a']
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-18 04:27:07.882955
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == [
        '/a', '/b', '/c']
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['a'])) == ['/a']
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-18 04:27:09.177949
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-18 04:27:10.961733
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-18 04:27:13.916724
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']

