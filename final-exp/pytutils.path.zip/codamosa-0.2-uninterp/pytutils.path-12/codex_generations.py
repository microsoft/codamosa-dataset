

# Generated at 2022-06-18 04:26:51.193891
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['a'])) == ['/a']
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-18 04:26:57.662663
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', ['a', 'b', 'c', ''])) == ['/a', '/b', '/c', '/']
    assert list(join_each('/', ['a', 'b', 'c', '', 'd'])) == ['/a', '/b', '/c', '/', '/d']
    assert list(join_each('/', ['a', 'b', 'c', '', 'd', ''])) == ['/a', '/b', '/c', '/', '/d', '/']



# Generated at 2022-06-18 04:26:59.828535
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-18 04:27:02.819013
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']



# Generated at 2022-06-18 04:27:04.546074
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-18 04:27:06.489413
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []



# Generated at 2022-06-18 04:27:08.173806
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []



# Generated at 2022-06-18 04:27:11.393187
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', ['a', 'b', 'c'])) == [
        '/home/user/a', '/home/user/b', '/home/user/c']



# Generated at 2022-06-18 04:27:14.677633
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["user", "bin"])) == [
        "/home/user",
        "/home/bin",
    ]



# Generated at 2022-06-18 04:27:16.844616
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ['c', 'd'])) == ['/a/b/c', '/a/b/d']

