

# Generated at 2022-06-18 04:26:55.042159
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', ['a', 'b', 'c', 'd'])) == ['/a', '/b', '/c', '/d']
    assert list(join_each('/', ['a', 'b', 'c', 'd', 'e'])) == ['/a', '/b', '/c', '/d', '/e']
    assert list(join_each('/', ['a', 'b', 'c', 'd', 'e', 'f'])) == ['/a', '/b', '/c', '/d', '/e', '/f']

# Generated at 2022-06-18 04:26:56.719412
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-18 04:27:00.796689
# Unit test for function join_each
def test_join_each():
    parent = '/home/user'
    iterable = ['foo', 'bar', 'baz']
    expected = ['/home/user/foo', '/home/user/bar', '/home/user/baz']
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-18 04:27:03.015256
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []



# Generated at 2022-06-18 04:27:06.253199
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b'])) == ['/tmp/a', '/tmp/b']
    assert list(join_each('/tmp', [])) == []



# Generated at 2022-06-18 04:27:09.525856
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']
    assert list(join_each('/a/b', ['c', 'd'])) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-18 04:27:13.582235
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']



# Generated at 2022-06-18 04:27:16.551698
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', ['a', 'b', 'c'])) == [
        '/home/user/a',
        '/home/user/b',
        '/home/user/c',
    ]



# Generated at 2022-06-18 04:27:19.258193
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-18 04:27:20.950855
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']

