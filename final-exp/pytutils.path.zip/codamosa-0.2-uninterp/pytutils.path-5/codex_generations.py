

# Generated at 2022-06-18 04:26:49.482601
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['user', 'bin'])) == ['/home/user', '/home/bin']



# Generated at 2022-06-18 04:26:50.982463
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-18 04:26:53.169816
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', [])) == []



# Generated at 2022-06-18 04:26:55.704794
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-18 04:26:57.798126
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-18 04:27:03.090853
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['a'])) == ['/a']
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-18 04:27:06.321840
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', ['file1', 'file2'])) == [
        '/home/user/file1',
        '/home/user/file2'
    ]



# Generated at 2022-06-18 04:27:10.961727
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/user", ["a", "b", "c"])) == [
        "/home/user/a",
        "/home/user/b",
        "/home/user/c",
    ]



# Generated at 2022-06-18 04:27:14.682610
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', [])) == []



# Generated at 2022-06-18 04:27:16.513236
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b'])) == ['/tmp/a', '/tmp/b']

