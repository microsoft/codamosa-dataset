

# Generated at 2022-06-18 04:26:46.264625
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-18 04:26:48.677745
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []



# Generated at 2022-06-18 04:26:50.891954
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-18 04:26:54.383215
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['a'])) == ['/a']



# Generated at 2022-06-18 04:26:56.366499
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-18 04:26:58.402423
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == [
        '/a', '/b', '/c']



# Generated at 2022-06-18 04:27:01.073241
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['user', 'bin'])) == ['/home/user', '/home/bin']



# Generated at 2022-06-18 04:27:02.544456
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-18 04:27:06.582606
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['a'])) == ['/a']
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-18 04:27:08.029334
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']

