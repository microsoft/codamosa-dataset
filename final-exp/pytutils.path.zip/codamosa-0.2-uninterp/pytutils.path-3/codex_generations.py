

# Generated at 2022-06-18 04:26:49.785340
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']
    assert list(join_each('/a/b', ['c', 'd'])) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-18 04:26:51.966366
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']



# Generated at 2022-06-18 04:26:55.280618
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['a'])) == ['/a']



# Generated at 2022-06-18 04:26:59.117846
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['a'])) == ['/a']



# Generated at 2022-06-18 04:27:03.909179
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', ['a', 'b', 'c', 'd'])) == ['/a', '/b', '/c', '/d']



# Generated at 2022-06-18 04:27:05.574576
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-18 04:27:09.244700
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []



# Generated at 2022-06-18 04:27:11.436462
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-18 04:27:15.072351
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', ['file1', 'file2'])) == [
        '/home/user/file1',
        '/home/user/file2'
    ]



# Generated at 2022-06-18 04:27:16.552409
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['user', 'bin'])) == ['/home/user', '/home/bin']