

# Generated at 2022-06-21 22:07:44.185198
# Unit test for function join_each

# Generated at 2022-06-21 22:07:46.793969
# Unit test for function join_each
def test_join_each():
    parent = '..'
    iterable = ['..', '..']
    out = list(join_each(parent, iterable))
    exp = ['../..', '../..']
    assert out == exp

# Generated at 2022-06-21 22:07:50.286861
# Unit test for function join_each
def test_join_each():
    assert [i for i in join_each('/', ['tmp', 'usr'])] == ['/tmp', '/usr']
    assert [i for i in join_each('/', ['', 'usr'])] == ['/', '/usr']


# Function to return list of files with all depth in a given directory

# Generated at 2022-06-21 22:07:55.318941
# Unit test for function join_each
def test_join_each():
    p = join_each("/home/plouffe", ["foo", "bar", "qux"])
    assert next(p) == "/home/plouffe/foo"
    assert next(p) == "/home/plouffe/bar"
    assert next(p) == "/home/plouffe/qux"



# Generated at 2022-06-21 22:07:56.939296
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['local', 'bin'])) == ['/usr/local', '/usr/bin']

# Generated at 2022-06-21 22:07:59.126588
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz', 'quux'])) == [
        'foo/bar', 'foo/baz', 'foo/quux']

# Generated at 2022-06-21 22:08:01.850124
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["a", "b"])) == ["/a", "/b"]
    assert list(join_each("/a", ["b", "c"])) == ["/a/b", "/a/c"]


# Recursive method

# Generated at 2022-06-21 22:08:06.629141
# Unit test for function join_each
def test_join_each():
    file_path = join_each('/home', ['user', 'music'])
    assert next(file_path) == '/home/user'
    assert next(file_path) == '/home/music'
    with pytest.raises(StopIteration):
        next(file_path)



# Generated at 2022-06-21 22:08:10.169007
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['/a', '/b'])) == ['/tmp/a', '/tmp/b']


#---------- Other Functions ----------

# Generated at 2022-06-21 22:08:16.143697
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a/b", ["x", "y", "z"])) == [
        "/a/b/x",
        "/a/b/y",
        "/a/b/z",
    ]
    assert list(join_each("", ["/x", "/y", "/z"])) == ["/x", "/y", "/z"]

