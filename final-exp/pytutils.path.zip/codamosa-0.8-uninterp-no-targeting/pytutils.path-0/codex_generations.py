

# Generated at 2022-06-21 22:07:48.288717
# Unit test for function join_each
def test_join_each():
    parent = 'root'

    def test(input, output):
        result = list(join_each(parent, input))
        assert result == output

    test([], [])
    test(['a', 'b', 'c'], ['root/a', 'root/b', 'root/c'])



# Generated at 2022-06-21 22:07:51.204636
# Unit test for function join_each
def test_join_each():
    actual = list(join_each(os.curdir, ["a_file", "another_file"]))
    expected = [os.path.join(os.curdir, "a_file"),
                os.path.join(os.curdir, "another_file")]
    assert actual == expected

# Generated at 2022-06-21 22:07:54.355015
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["1", "2", "3"])) == ["a/1", "a/2", "a/3"]



# Generated at 2022-06-21 22:07:56.046192
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar'])) == ['foo/bar']



# Generated at 2022-06-21 22:07:59.831838
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/home/me', ['foo', 'bar', 'baz'])) == (
        '/home/me/foo', '/home/me/bar', '/home/me/baz')


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:08:04.782383
# Unit test for function join_each
def test_join_each():
    parent = os.path.abspath(".")
    iterable = ["a", "b", "c"]
    path_list = list(join_each(parent, iterable))
    assert path_list == [os.path.join(parent, p) for p in iterable]



# Generated at 2022-06-21 22:08:09.319756
# Unit test for function join_each
def test_join_each():
    assert list(join_each(u'foo', [u'bar', u'baz'])) == [u'foo/bar', u'foo/baz']
    assert list(join_each(u'', [u'', u''])) == [u'', u'']
    assert list(join_each(u'foo', [])) == []
    assert list(join_each(u'', [u'foo', u'bar'])) == [u'foo', u'bar']

# Generated at 2022-06-21 22:08:13.232816
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', ['.', '..', '.git'])) == [
        '/home/user',
        '/home',
        '/home/user/.git'
    ]



# Generated at 2022-06-21 22:08:15.529969
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]



# Generated at 2022-06-21 22:08:19.726901
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a/b/c', ['d', 'e'])) == ['a/b/c/d', 'a/b/c/e']