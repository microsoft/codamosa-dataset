

# Generated at 2022-06-21 22:07:45.442363
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    child = ['foo', 'bar', 'baz']
    expect = ['/tmp/foo', '/tmp/bar', '/tmp/baz']

    for i, p in enumerate(join_each(parent, child)):
        assert p == expect[i]

# Generated at 2022-06-21 22:07:47.895278
# Unit test for function join_each
def test_join_each():
    data = join_each('/', ['a', 'b', 'c'])
    assert data == ['/a', '/b', '/c']

# Generated at 2022-06-21 22:07:50.473090
# Unit test for function join_each
def test_join_each():
    parent = 'home'
    iterable = ['.', 'usr', '../opt']
    assert set(join_each(parent, iterable)) == set(
        os.path.join(parent, p) for p in iterable)

# Generated at 2022-06-21 22:07:53.453668
# Unit test for function join_each
def test_join_each():
    for x in join_each('foo', ['bar', 'baz']):
        pass
    assert x == os.path.join('foo', 'baz')



# Generated at 2022-06-21 22:08:03.021815
# Unit test for function join_each
def test_join_each():
    import shutil
    import tempfile
    from pyfakefs.fake_filesystem_unittest import TestCase
    from pyfakefs.pytest_plugin import pytest_funcarg__fs

    class FakeFileSystemTestCase(TestCase):
        def setUp(self):
            self.setUpPyfakefs()

        def tearDown(self):
            self.tearDownPyfakefs()

    class TestJoinEach(FakeFileSystemTestCase):
        def setUp(self):
            super().setUp()
            self.tmpdir = tempfile.mkdtemp()
            self.tmp_subdir = os.path.join(self.tmpdir, 'subdir')
            os.mkdir(self.tmp_subdir)

# Generated at 2022-06-21 22:08:05.400746
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['bob', 'alice'])) == ['/bob', '/alice']

# Generated at 2022-06-21 22:08:11.139892
# Unit test for function join_each
def test_join_each():
    j = join_each
    assert list(j(None, [])) == []
    assert list(j(None, [None])) == [None]
    assert list(j(None, [None, None])) == [None, None]
    assert list(j(None, ['a'])) == ['a']
    assert list(j(None, ['a', 'b'])) == ['a', 'b']

    assert list(j('', [])) == []
    assert list(j('', [None])) == ['']
    assert list(j('', [None, None])) == ['', '']
    assert list(j('', ['a'])) == ['a']
    assert list(j('', ['a', 'b'])) == ['a', 'b']

    assert list(j('', [''])) == ['']


# Generated at 2022-06-21 22:08:14.361059
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c', 'd'])) == ['a/b', 'a/c', 'a/d']



# Generated at 2022-06-21 22:08:22.504719
# Unit test for function join_each
def test_join_each():
    parent = "/Users/edellis"
    assert list(join_each(parent, ["a", "b", "c"])) == [
        "/Users/edellis/a",
        "/Users/edellis/b",
        "/Users/edellis/c",
    ]


DEFAULT_PROJECT_ROOT = os.path.join(
    os.path.expanduser("~"),
    ".cloudmesh",
    "cloudmesh-cmd5",
    "projects",
    "cloudmesh",
)



# Generated at 2022-06-21 22:08:26.124147
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/foo/bar", ["baz", "boo", "tee"])) == [
        "/foo/bar/baz",
        "/foo/bar/boo",
        "/foo/bar/tee",
    ]

