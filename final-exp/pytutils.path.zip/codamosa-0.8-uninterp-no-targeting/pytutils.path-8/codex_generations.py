

# Generated at 2022-06-21 22:07:43.973400
# Unit test for function join_each
def test_join_each():
    assert list(join_each('C:\\', ['Windows', 'Program Files'])) == [
        'C:\\Windows',
        'C:\\Program Files']
    assert list(join_each('C:\\', [])) == []

# Generated at 2022-06-21 22:07:47.562902
# Unit test for function join_each
def test_join_each():
    actual = list(join_each('/foo', ['bar', 'baz']))
    expected = ['/foo/bar', '/foo/baz']
    assert actual == expected



# Generated at 2022-06-21 22:07:50.793847
# Unit test for function join_each
def test_join_each():
    parent = "some_dir"
    iterable = ["item1", "item2"]
    assert list(join_each(parent, iterable)) == [
        os.path.join(parent, "item1"),
        os.path.join(parent, "item2"),
    ]



# Generated at 2022-06-21 22:07:53.027297
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['bin', 'var'])) == ['/home/bin', '/home/var']

# Generated at 2022-06-21 22:07:56.939998
# Unit test for function join_each
def test_join_each():
    path = join_each('/home/user', ['one', 'two', 'three'])
    assert next(path) == '/home/user/one'
    assert next(path) == '/home/user/two'
    assert next(path) == '/home/user/three'



# Generated at 2022-06-21 22:08:01.148550
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['./bar', './baz'])) == [
        'foo/./bar', 'foo/./baz']

    assert list(join_each('', ['./bar', './baz'])) == ['./bar', './baz']

    assert list(join_each('', [])) == []



# Generated at 2022-06-21 22:08:03.648114
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-21 22:08:07.669177
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a/b/c", ["d", "e", "f"])) == [
        "/a/b/c/d",
        "/a/b/c/e",
        "/a/b/c/f",
    ]



# Generated at 2022-06-21 22:08:10.068834
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']



# Generated at 2022-06-21 22:08:14.780244
# Unit test for function join_each
def test_join_each():
    test_paths = ['./', './', '../']
    expected = ['./default.cfg', './baz0.txt', '../foobar.txt']
    output = join_each('./', test_paths)
    assert output == expected