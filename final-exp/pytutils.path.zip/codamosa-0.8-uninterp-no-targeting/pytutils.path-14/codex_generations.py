

# Generated at 2022-06-21 22:07:45.094322
# Unit test for function join_each
def test_join_each():
    # Create some dummy test data
    parent = '/tmp/dir1'
    children = ['a', 'b', 'c']
    expected = ['/tmp/dir1/a', '/tmp/dir1/b', '/tmp/dir1/c']

    # Create a generator function with our function
    fn = partial(join_each, parent)

    # Compare results
    assert list(fn(children)) == expected



# Generated at 2022-06-21 22:07:47.822309
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['c', 'b'])) == ['parent/c', 'parent/b']
    assert list(join_each('parent', [])) == []

# Generated at 2022-06-21 22:07:50.934041
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/', ('tmp', 'foo', 'bar'))) \
        == ('/tmp', '/foo', '/bar')
    assert tuple(join_each('/tmp', ('foo', 'bar'))) \
        == ('/tmp/foo', '/tmp/bar')



# Generated at 2022-06-21 22:07:54.752291
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["a", "b", "c"]

    result = join_each(parent, iterable)
    expected = ["parent/a", "parent/b", "parent/c"]

    assert list(result) == expected

# Generated at 2022-06-21 22:07:56.727818
# Unit test for function join_each
def test_join_each():
    assert join_each('/', ['etc', 'bin']) == ['/etc', '/bin']


# n-ary

# Generated at 2022-06-21 22:07:59.244793
# Unit test for function join_each
def test_join_each():
    i = ['a', 'b', 'c']
    assert list(join_each('/', i)) == ['/a', '/b', '/c']



# Generated at 2022-06-21 22:08:01.148567
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/etc", "passwd group".split())) == [
        "/etc/passwd",
        "/etc/group",
    ]



# Generated at 2022-06-21 22:08:08.749785
# Unit test for function join_each
def test_join_each():
    dir_name = "test_dir"
    files = ["a.txt", "b.txt", "c.txt"]

    joined_paths = join_each(dir_name, files)
    assert next(joined_paths) == os.path.join(dir_name, "a.txt")
    assert next(joined_paths) == os.path.join(dir_name, "b.txt")
    assert next(joined_paths) == os.path.join(dir_name, "c.txt")
    with pytest.raises(StopIteration):
        next(joined_paths)



# Generated at 2022-06-21 22:08:12.282267
# Unit test for function join_each
def test_join_each():
    assert list(join_each("base", ["a", "b"])) == ["base/a", "base/b"]


#
# Recursive glob
#


# Generated at 2022-06-21 22:08:13.625413
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/home/user/', ('a', 'b', 'c'))) == \
           ('/home/user/a', '/home/user/b', '/home/user/c')

