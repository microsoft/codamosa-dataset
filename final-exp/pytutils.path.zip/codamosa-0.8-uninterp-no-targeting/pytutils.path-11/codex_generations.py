

# Generated at 2022-06-21 22:07:53.663897
# Unit test for function join_each
def test_join_each():
    parent_path = '/home/alex'
    iterable = ['a.txt', 'b.txt', 'c.txt']
    expected = [os.path.join(parent_path, p) for p in iterable]

    new = list(join_each(parent_path, iterable))
    assert new == expected

# Example usage:

# >>> import os
# >>> parent_path = '/home/alex'
# >>> iterable = ['a.txt', 'b.txt', 'c.txt']
# >>> result = list(join_each(parent_path, iterable))
# >>> print(result)
#['/home/alex/a.txt', '/home/alex/b.txt', '/home/alex/c.txt']
# >>>

# Generated at 2022-06-21 22:07:56.428620
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    parent = '/'
    assert list(join_each(parent, iterable)) == ['/a', '/b', '/c']



# Generated at 2022-06-21 22:07:59.598673
# Unit test for function join_each
def test_join_each():
    p = 'tmp'
    dirs = ['test1', 'test2', 'test3']

    expected = ['tmp/test1', 'tmp/test2', 'tmp/test3']
    actual = list(join_each(p, dirs))

    assert expected == actual

# Generated at 2022-06-21 22:08:03.326953
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["etc", "lib"])) == ["/etc", "/lib"]
    assert list(join_each("/", [])) == []


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-21 22:08:06.795446
# Unit test for function join_each
def test_join_each():
    parent = "/tmp"
    children = ["asdf", "qwerty"]
    assert list(
        join_each(parent, children)
    ) == ["/tmp/asdf", "/tmp/qwerty"]

# Generated at 2022-06-21 22:08:09.454007
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['usr', 'local'])) == ['/usr', '/local']



# Generated at 2022-06-21 22:08:17.040024
# Unit test for function join_each
def test_join_each():
    parent_dir = os.path.join(os.getcwd(), 'folder1', 'folder2')
    file_names = ['file1.txt', 'file2.txt']
    res = list(join_each(parent_dir, file_names))
    expected_res = [os.path.join(parent_dir, 'file1.txt'),
                    os.path.join(parent_dir, 'file2.txt')]
    assert res == expected_res



# Generated at 2022-06-21 22:08:23.046953
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['a', 'b', 'c']
    actual_result = list(join_each(parent, iterable))
    expected_result = [os.path.join(parent, 'a'),
                       os.path.join(parent, 'b'),
                       os.path.join(parent, 'c')]

    assert actual_result == expected_result



# Generated at 2022-06-21 22:08:28.619692
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['child1', 'child2', 'child3']
    actual = list(join_each(parent, iterable))
    expected = [os.path.join(parent, 'child1'),
                os.path.join(parent, 'child2'),
                os.path.join(parent, 'child3')]
    assert actual == expected


# Find all files in each of the input directories

# Generated at 2022-06-21 22:08:31.882350
# Unit test for function join_each
def test_join_each():
    base = 'parent_directory'
    iterable = ['A', 'B', 'C']
    exp_res = ['parent_directory/A', 'parent_directory/B',
               'parent_directory/C']
    res = list(join_each(base, iterable))
    assert res == exp_res