

# Generated at 2022-06-21 22:07:43.829649
# Unit test for function join_each
def test_join_each():
    expected = ['cwd/a', 'cwd/b', 'cwd/c']
    assert list(join_each(os.getcwd(), ['a', 'b', 'c'])) == expected



# Generated at 2022-06-21 22:07:47.784145
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['test1', 'test2'])) == [
        '/tmp/test1', '/tmp/test2']


# Definition of function longest_path

# Generated at 2022-06-21 22:07:49.596584
# Unit test for function join_each
def test_join_each():
    x = join_each('/', ['usr', 'bin'])
    x = list(x)
    assert x == ['/usr', '/bin']

# Generated at 2022-06-21 22:07:55.588710
# Unit test for function join_each
def test_join_each():
    # Given
    path = r'C:\Projects\Reservoir\Data\rms'
    files = ['rms_data.xls', 'rms_data.pkl']
    expected = [os.path.join(path, f) for f in files]

    # When
    joined = list(join_each(path, files))

    # Then
    assert joined == expected

# Generated at 2022-06-21 22:07:57.476919
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['.b', '.c'])) == ['a.b', 'a.c']



# Generated at 2022-06-21 22:07:59.396257
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ("some", "path"))) == ["/tmp/some", "/tmp/path"]



# Generated at 2022-06-21 22:08:02.464408
# Unit test for function join_each
def test_join_each():
    res = list(join_each('/usr/local', ['bin', 'share']))
    assert res == ['/usr/local/bin', '/usr/local/share']
    res = list(join_each('/usr/local', os.listdir('/usr/local')))
    assert os.path.exists(res[0])



# Generated at 2022-06-21 22:08:07.075198
# Unit test for function join_each
def test_join_each():
    parent = r'/home/user/'
    children = ['file.txt', 'file2.txt', 'file3.txt']

    result = list(join_each(parent, children))
    wanted = [os.path.join(parent, path) for path in children]

    assert result == wanted

# Generated at 2022-06-21 22:08:09.454878
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/', ['bin', 'usr'])) == ('/bin', '/usr')



# Generated at 2022-06-21 22:08:13.338572
# Unit test for function join_each
def test_join_each():
    assert (list(join_each("dir", ["dir2", "dir3"]))
            == ["dir/dir2", "dir/dir3"])


# This is the iterator that generates all test image paths.