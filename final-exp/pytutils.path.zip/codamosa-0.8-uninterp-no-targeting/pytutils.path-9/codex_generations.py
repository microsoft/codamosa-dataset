

# Generated at 2022-06-21 22:07:45.660556
# Unit test for function join_each
def test_join_each():
    parent = "/"
    iterable = ("home", "alison")
    output = "/home/alison"

    assert list(join_each(parent, iterable)) == [output]



# Generated at 2022-06-21 22:07:51.386336
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/c', ['d', 'e', 'f'])) == ['/a/b/c/d', '/a/b/c/e', '/a/b/c/f']
    assert list(join_each('/a/b/c', [])) == []
    assert list(join_each('/a/b/c', ('d', 'e', 'f'))) == ['/a/b/c/d', '/a/b/c/e', '/a/b/c/f']



# Generated at 2022-06-21 22:07:53.978122
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['foo', 'bar'])) == [
        'parent/foo', 'parent/bar']



# Generated at 2022-06-21 22:07:58.353899
# Unit test for function join_each
def test_join_each():
    p = '/home/erik/test'
    iterable = ['test', 'test']
    joined = join_each(p, iterable)
    assert len(list(joined)) == 2
    assert list(joined)[0] == '/home/erik/test/test'
    assert list(joined)[1] == '/home/erik/test/test'



# Generated at 2022-06-21 22:08:00.466573
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', iter('bcd'))) == ['a/b', 'a/c', 'a/d']



# Generated at 2022-06-21 22:08:06.544638
# Unit test for function join_each
def test_join_each():
    actual = list(join_each(os.sep, ["a", "b", "c"]))
    expect = [os.path.join(os.sep, "a"),
              os.path.join(os.sep, "b"),
              os.path.join(os.sep, "c")]
    assert actual == expect


if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-21 22:08:09.730219
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['.vimrc', '.bashrc'])) == ['/', '/.vimrc', '/.bashrc']

# Generated at 2022-06-21 22:08:13.596143
# Unit test for function join_each
def test_join_each():
    l = ['one', 'two', 'three', 'four']
    test = join_each('/test', l)
    for t in test:
        print(t)


# Test above code
test_join_each()

# Generated at 2022-06-21 22:08:17.080179
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/a/b', ('c', 'd')))
    assert result == ['/a/b/c', '/a/b/d']


# Create test data set

# Generated at 2022-06-21 22:08:24.578883
# Unit test for function join_each
def test_join_each():
    test_parent = 'some/parent/directory'
    test_iterable = ['first', 'second', 'third']
    test_result = join_each(test_parent, test_iterable)

    assert next(test_result) == 'some/parent/directory/first'
    assert next(test_result) == 'some/parent/directory/second'
    assert next(test_result) == 'some/parent/directory/third'
    with pytest.raises(StopIteration):
        next(test_result)

