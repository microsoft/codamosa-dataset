

# Generated at 2022-06-21 22:07:41.011069
# Unit test for function join_each
def test_join_each():
    actual = list(join_each('/root', ['a', 'b']))
    expected = ['/root/a', '/root/b']
    assert actual == expected



# Generated at 2022-06-21 22:07:46.541934
# Unit test for function join_each
def test_join_each():
    parent = '/path/to/'
    children = ['apple', 'banana', 'cherry']
    expected = ['/path/to/apple', '/path/to/banana', '/path/to/cherry']
    actual = list(join_each(parent, children))

    assert(expected == actual)



# Generated at 2022-06-21 22:07:53.252492
# Unit test for function join_each
def test_join_each():
    class DummyParent(object):
        def __init__(self, content):
            self.content = content

        def __getitem__(self, key):
            return self.content[key]

    d = DummyParent([
        '/usr/lib/python2.7',
        '/usr/lib/python2.7/plat-linux2',
        '/usr/lib/python2.7/lib-tk',
    ])

    assert tuple(join_each('/usr/local/bin', d)) == tuple(d)

# Generated at 2022-06-21 22:07:58.762580
# Unit test for function join_each
def test_join_each():
    assert list(join_each("root", [
        ])) == [
        ]
    assert list(join_each("root", [
        "file1.o",
        ])) == [
        "root/file1.o"
        ]
    assert list(join_each("root", [
        "file1.o",
        "file2.o",
        ])) == [
        "root/file1.o",
        "root/file2.o",
        ]

# Generated at 2022-06-21 22:08:00.866568
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-21 22:08:05.907306
# Unit test for function join_each
def test_join_each():
    files = ['foo', 'bar', 'baz']
    joined = list(join_each('/tmp', files))
    assert joined[0] == '/tmp/foo'
    assert joined[1] == '/tmp/bar'
    assert joined[2] == '/tmp/baz'



# Generated at 2022-06-21 22:08:10.643023
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo/bar', ('one', 'two', 'three'))) == [
        '/foo/bar/one', '/foo/bar/two', '/foo/bar/three'
    ]



# Generated at 2022-06-21 22:08:15.590645
# Unit test for function join_each
def test_join_each():
    assert tuple(
        join_each(
            'foo',
            ('b', 'a', 'r')
        )
    ) == (os.path.join('foo', 'b'), os.path.join('foo', 'a'), os.path.join('foo', 'r'))



# Generated at 2022-06-21 22:08:17.787783
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ('a', 'b'))) == ['/a', '/b']



# Generated at 2022-06-21 22:08:19.970526
# Unit test for function join_each
def test_join_each():
    assert list(join_each("path", ["one", "two"])) == ["path/one", "path/two"]

