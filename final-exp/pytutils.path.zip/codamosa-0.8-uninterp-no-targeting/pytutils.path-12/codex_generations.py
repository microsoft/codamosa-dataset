

# Generated at 2022-06-21 22:07:48.380348
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['a', 'b', 'c'])) == ['a', 'b', 'c']
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('.', ['.'])) == ['.']



# Generated at 2022-06-21 22:07:50.049638
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['user', 'bin'])) == \
        ['/home/user', '/home/bin']



# Generated at 2022-06-21 22:07:53.787980
# Unit test for function join_each
def test_join_each():
    expected = iter(["/a/b/c", "/a/b/d"])
    result = join_each("/a/b", ["c", "d"])
    assert list(expected) == list(result)

# Generated at 2022-06-21 22:07:56.906551
# Unit test for function join_each
def test_join_each():
    path = '/home/user'
    paths = ['usr', 'local', 'bin']
    assert list(join_each(path, paths)) == [
        '/home/user/usr', '/home/user/local', '/home/user/bin'
    ]

# Generated at 2022-06-21 22:07:59.085447
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/hello", ["world", "python"])) == [
        "/hello/world",
        "/hello/python",
    ]



# Generated at 2022-06-21 22:08:05.248384
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', ['', 'b'])) == ['/', '/b']
    assert list(join_each('/', ['c', ''])) == ['/c', '/']
    assert list(join_each('/', ['', ''])) == ['/', '/']



# Generated at 2022-06-21 22:08:07.232444
# Unit test for function join_each
def test_join_each():
    assert [p for p in join_each('/', ['tmp', 'usr'])] == ['/tmp', '/usr']



# Generated at 2022-06-21 22:08:09.918262
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['c', 'd', 'e'])) == ['/c', '/d', '/e']

# Generated at 2022-06-21 22:08:14.613670
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["home", "test"])) == ["/home", "/test"]
    assert list(join_each("/home", ["test", "test2"])) == [
        "/home/test",
        "/home/test2",
    ]



# Generated at 2022-06-21 22:08:17.283566
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('foo', ('bar', 'baz'))) == ('foo/bar', 'foo/baz')

