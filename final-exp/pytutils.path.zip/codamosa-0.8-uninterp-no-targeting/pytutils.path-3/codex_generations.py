

# Generated at 2022-06-21 22:07:43.486322
# Unit test for function join_each
def test_join_each():
    parent = "C:\\Users\\fazil"
    iter1 = ("Desktop", "Downloads")
    for p in join_each(parent, iter1):
        print(p)



# Generated at 2022-06-21 22:07:46.499668
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['/bar', '/baz'])) == ['/foo/bar', '/foo/baz']

# Generated at 2022-06-21 22:07:48.779831
# Unit test for function join_each
def test_join_each():
    assert join_each('/a/b', ('c', 'd')) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-21 22:07:59.085997
# Unit test for function join_each
def test_join_each():
    test_cases = [
        # case
        #   each, parent, expected list
        (['a'], 'b', ['b/a']),
        (['a', 'b'], 'c', ['c/a', 'c/b']),
        (['a', 'b', 'c'], 'd', ['d/a', 'd/b', 'd/c']),
        (['c', 'b', 'a'], 'd', ['d/c', 'd/b', 'd/a']),
        ([], 'whatever', []),
    ]
    for each, parent, expected in test_cases:
        actual = list(join_each(parent, each))

# Generated at 2022-06-21 22:08:01.215948
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["usr", "bin", "env"])) == ["/usr", "/bin", "/env"]



# Generated at 2022-06-21 22:08:05.144347
# Unit test for function join_each
def test_join_each():
    parent = '/tmp/'
    result = list(join_each(parent, ['foo', 'bar', 'baz']))
    assert result == ['/tmp/foo', '/tmp/bar', '/tmp/baz']

# Generated at 2022-06-21 22:08:07.155411
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ('bar', 'baz'))) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-21 22:08:12.275875
# Unit test for function join_each
def test_join_each():
    parent = '.'
    iterable = ['src', 'test', 'data']

    expected_list = ['./src', './test', './data']
    actual_list = list(join_each(parent, iterable))

    assert expected_list == actual_list

# Generated at 2022-06-21 22:08:18.685374
# Unit test for function join_each
def test_join_each():
    parent = "a/b"
    iterable = ("c", "d", "e")
    assert tuple(join_each(parent, iterable)) == ("a/b/c", "a/b/d", "a/b/e")

for item in join_each("a/b", ("c", "d", "e")):
    print(item)

"""
a/b/c
a/b/d
a/b/e
"""

# Generated at 2022-06-21 22:08:21.197181
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/var/www", ["foo", "bar"])) == [
        "/var/www/foo",
        "/var/www/bar",
    ]