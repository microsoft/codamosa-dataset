

# Generated at 2022-06-21 22:07:45.870687
# Unit test for function join_each
def test_join_each():
    assert take(3, join_each('a', 'bc')) == ('a/b', 'a/c', None)



# Generated at 2022-06-21 22:07:51.097046
# Unit test for function join_each
def test_join_each():
    test_dir = "dir_1"
    test_dir2 = "dir_2"
    test_dir3 = "dir_3"
    test_dir_list = [test_dir, test_dir2, test_dir3]
    joined_dir_list = [os.path.join(test_dir, d) for d in test_dir_list]
    assert list(join_each(test_dir, test_dir_list)) == joined_dir_list



# Generated at 2022-06-21 22:07:57.066594
# Unit test for function join_each
def test_join_each():
    temp = tempfile.TemporaryDirectory()
    temp_path = temp.name
    result = list(join_each(temp_path, ['a', 'b', 'c']))
    temp.cleanup()
    assert result == [
        os.path.join(temp_path, 'a'),
        os.path.join(temp_path, 'b'),
        os.path.join(temp_path, 'c'),
    ]

# Generated at 2022-06-21 22:08:00.193182
# Unit test for function join_each
def test_join_each():
    parent = '/home/ed/'
    children = ('myfile', 'mydir')
    expected = ('/home/ed/myfile', '/home/ed/mydir')
    assert list(join_each(parent, children)) == expected

# Generated at 2022-06-21 22:08:02.022689
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-21 22:08:05.252242
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-21 22:08:08.117611
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar"])) == ["foo/bar"]
    assert list(join_each("foo", ("bar", "quux"))) == ["foo/bar", "foo/quux"]


# Functional version of listdir

# Generated at 2022-06-21 22:08:16.680699
# Unit test for function join_each
def test_join_each():
    print("test_join_each")
    iter = ["a", "b", "c"]
    parent = "/"
    expected = ["/a", "/b", "/c"]
    result = list(join_each(parent, iter))
    if not result == expected:
        raise Exception("join_each() returned unexpected result: %s, expected %s" %
                        (str(result), str(expected)))
    print("test_join_each OK")

if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-21 22:08:21.196940
# Unit test for function join_each
def test_join_each():

    iterable = ["sub1", "sub2", "sub3"]
    joined_iterable = join_each("parent", iterable)
    expected_iterable = [
        "parent/sub1", "parent/sub2", "parent/sub3"
    ]
    assert list(joined_iterable) == expected_iterable



# Generated at 2022-06-21 22:08:25.987736
# Unit test for function join_each
def test_join_each():
    # Prepare test data
    parent = '/tmp'
    iterable = ['a', 'b/c', 'd/e/f']
    assert list(join_each(parent, iterable)) == ['/tmp/a', '/tmp/b/c', '/tmp/d/e/f']

