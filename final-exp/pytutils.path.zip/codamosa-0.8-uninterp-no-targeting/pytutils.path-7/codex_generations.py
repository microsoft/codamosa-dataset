

# Generated at 2022-06-21 22:07:45.513122
# Unit test for function join_each
def test_join_each():
    test_dir = os.path.dirname(__file__)
    for pth in join_each(test_dir, ['test_data', 'test_data']):
        assert pth == os.path.join(test_dir, 'test_data', 'test_data')



# Generated at 2022-06-21 22:07:52.869082
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['A', 'B', 'C'])) == ['/A', '/B', '/C']
    assert list(join_each('', ['A', 'B', 'C'])) == ['A', 'B', 'C']
    assert list(join_each('/A', ['B', 'C', 'D'])) == ['/A/B', '/A/C', '/A/D']
    assert list(join_each('/A', [])) == []



# Generated at 2022-06-21 22:07:57.151380
# Unit test for function join_each
def test_join_each():
    try:
        assert(list(join_each('folder', ['file1', 'file2'])) == ['folder/file1', 'folder/file2'])
    except Exception as e:
        print('Test join_each: error: {}'.format(e))
    else:
        print('Test join_each: pass')



# Generated at 2022-06-21 22:08:00.514357
# Unit test for function join_each
def test_join_each():
    parent = "./test"
    iterable = ["a", "b", "c"]
    expected_result = ["./test/a", "./test/b", "./test/c"]

    assert list(join_each(parent, iterable)) == expected_result



# Generated at 2022-06-21 22:08:02.862330
# Unit test for function join_each
def test_join_each():
    assert join_each('foo', ['a', 'b']) == ['foo/a', 'foo/b']



# Generated at 2022-06-21 22:08:06.754387
# Unit test for function join_each
def test_join_each():
    initial = ['home', 'user', 'Downloads']
    expected = [
        'home/user/Downloads',
        'home/user',
        'home'
    ]
    assert list(join_each('/', initial)) == expected

# Generated at 2022-06-21 22:08:13.125452
# Unit test for function join_each
def test_join_each():
    p = "/some/parent"
    iterable = ["child1", "child2", "child3"]
    assert list(join_each(p, iterable)) == [
        "/some/parent/child1",
        "/some/parent/child2",
        "/some/parent/child3",
    ]



# Generated at 2022-06-21 22:08:16.250613
# Unit test for function join_each
def test_join_each():
    assert list(
        join_each("/home/test", ["a", "b", "c"])
    ) == ["/home/test/a", "/home/test/b", "/home/test/c"]



# Generated at 2022-06-21 22:08:22.597932
# Unit test for function join_each
def test_join_each():
    parent = os.path.join('path', 'to')
    iterable = ('aaa', 'bbb', 'ccc')
    assert list(join_each(parent, iterable)) == \
        [os.path.join('path', 'to', 'aaa'),
         os.path.join('path', 'to', 'bbb'),
         os.path.join('path', 'to', 'ccc')]



# Generated at 2022-06-21 22:08:25.117343
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', ['passwd', 'group'])) == [
            '/etc/passwd',
            '/etc/group',
    ]

