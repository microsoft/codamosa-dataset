

# Generated at 2022-06-21 22:07:47.784116
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/c', ('d', 'e', 'f'))) == ['/a/b/c/d', '/a/b/c/e', '/a/b/c/f']
    assert list(join_each('/a', ('b', 'c', 'd'))) == ['/a/b', '/a/c', '/a/d']
    assert list(join_each('/a/b/c/d', ('e', 'f', 'g'))) == ['/a/b/c/d/e', '/a/b/c/d/f', '/a/b/c/d/g']



# Generated at 2022-06-21 22:07:49.597448
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/Users/', ['x', 'y'])) == ['/Users/x', '/Users/y']

# Generated at 2022-06-21 22:07:54.120982
# Unit test for function join_each
def test_join_each():
    parent = 'a/b'
    input = ['c', 'd']
    correct_answer = ['a/b/c', 'a/b/d']
    assert list(join_each(parent, input)) == correct_answer

# Generated at 2022-06-21 22:08:01.021062
# Unit test for function join_each
def test_join_each():
    parent = '/home/user'
    iterable = [
        'a.txt',
        'b.txt',
        'c.txt'
    ]

    # Expected list
    expected = [
        '/home/user/a.txt',
        '/home/user/b.txt',
        '/home/user/c.txt'
    ]

    for expected_path,path in zip(expected, join_each(parent, iterable)):
        assert expected_path == path

    for expected_path,path in zip(expected, join_each(parent, iterable)):
        assert expected_path == path

# Generated at 2022-06-21 22:08:03.928140
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ('c', 'b', 'e'))) == ['/a/c', '/a/b', '/a/e']



# Generated at 2022-06-21 22:08:06.588242
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/foo", ["bar", "baz"])) == ["/foo/bar", "/foo/baz"]



# Generated at 2022-06-21 22:08:09.712839
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['foo', 'bar'])) == ['/tmp/foo', '/tmp/bar']



# Generated at 2022-06-21 22:08:14.004169
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    children = ['subdir', 'subdir2']
    joined = list(join_each(parent, children))
    assert joined == ['/home/subdir', '/home/subdir2']



# Generated at 2022-06-21 22:08:16.734699
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-21 22:08:18.988209
# Unit test for function join_each
def test_join_each():

    assert list(join_each('.', ['foo', 'bar'])) == [
        './foo', './bar'
    ]

