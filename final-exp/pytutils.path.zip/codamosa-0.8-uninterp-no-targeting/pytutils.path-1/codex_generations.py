

# Generated at 2022-06-21 22:07:51.045751
# Unit test for function join_each
def test_join_each():
    # test on a list
    assert list(join_each('parent', ['a', 'b', 'c'])) == ['parent/a', 'parent/b', 'parent/c']

    # test on a set
    assert set(join_each('parent', ('a', 'b', 'c'))) == {'parent/a', 'parent/b', 'parent/c'}

    # test on a tuple
    assert set(join_each('parent', {'a', 'b', 'c'})) == {'parent/a', 'parent/b', 'parent/c'}

    # test on an iterator
    assert list(join_each('parent', (x for x in 'abc'))) == ['parent/a', 'parent/b', 'parent/c']

    # test on an iterator of mixed types

# Generated at 2022-06-21 22:07:57.355696
# Unit test for function join_each
def test_join_each():
    # Test with empty iterable
    assert list(join_each("parent", [])) == []

    # Test with iterable which contains just one element
    assert list(join_each("parent", ["child"])) == ["parent/child"]

    # Test with iterable which contains multiple elements
    assert list(join_each("parent", ["child1", "child2", "child3"])) == [
        "parent/child1", "parent/child2", "parent/child3"
    ]

# Generated at 2022-06-21 22:08:01.109713
# Unit test for function join_each
def test_join_each():
    parent = dirname
    iterable = ['1', '2']
    assert list(join_each(parent, iterable)) == [os.path.join(parent, '1'), os.path.join(parent, '2')]


# Check if file exists, whether it is readable and if it is not empty

# Generated at 2022-06-21 22:08:07.194326
# Unit test for function join_each
def test_join_each():
    parent = '/home/user'
    files = ['file1', 'file2', 'file3', 'file4']
    expect = [
        '/home/user/file1',
        '/home/user/file2',
        '/home/user/file3',
        '/home/user/file4',
    ]

    actual = list(join_each(parent, files))

    assert expect == actual



# Generated at 2022-06-21 22:08:09.923125
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ('b', 'c'))) == ['/a/b', '/a/c']



# Generated at 2022-06-21 22:08:18.291428
# Unit test for function join_each
def test_join_each():
    def assert_join(actual, expected):
        assert actual == expected

    def assert_join_each(parent, iterable, expected):
        assert_join(list(join_each(parent, iterable)), expected)

    assert_join_each('', [], [])
    assert_join_each('', ['abc', 'def'], ['abc', 'def'])
    assert_join_each('dir', [], ['dir'])
    assert_join_each('dir', ['abc', 'def'], ['dir/abc', 'dir/def'])

# Generated at 2022-06-21 22:08:21.898528
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) ==\
        [os.path.join('foo', 'bar'), os.path.join('foo', 'baz')]


# I/O function: write CSV

# Generated at 2022-06-21 22:08:25.118710
# Unit test for function join_each
def test_join_each():
    assert list(join_each(0, [1,2])) == [0,1,0,2]


# Check that the output directories of extract hash and extract audio hash
# are equal.

# Generated at 2022-06-21 22:08:30.338261
# Unit test for function join_each
def test_join_each():
    iterable = ["foo", "bar"]
    parent = "/home/user"

    gen = join_each(parent, iterable)
    assert gen.next() == "/home/user/foo"
    assert gen.next() == "/home/user/bar"

    # Re-initialize generator
    gen = join_each(parent, iterable)
    assert list(gen) == ["/home/user/foo", "/home/user/bar"]

# Generated at 2022-06-21 22:08:32.788788
# Unit test for function join_each
def test_join_each():
    assert list(join_each('./fixtures/dir0', ['./dir1', './dir2'])) == [
        './fixtures/dir0/./dir1',
        './fixtures/dir0/./dir2'
    ]

