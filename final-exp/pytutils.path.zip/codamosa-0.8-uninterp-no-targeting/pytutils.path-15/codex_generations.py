

# Generated at 2022-06-21 22:07:49.230140
# Unit test for function join_each
def test_join_each():
    parent = '/home/testuser/'
    iterable = ['/home', '/testuser']
    expected_result = ['/home/testuser/' + i for i in iterable]
    assert list(join_each(parent, iterable)) == expected_result


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-21 22:07:52.819218
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz', 'qux'])) == \
        ['foo/bar', 'foo/baz', 'foo/qux']



# Generated at 2022-06-21 22:07:54.620606
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["a", "b"])) == ["/a", "/b"]



# Generated at 2022-06-21 22:07:58.641111
# Unit test for function join_each
def test_join_each():
    # Provide a list of items to join
    actual = list(join_each('dir', ['a', 'b']))

    # We expect two results
    assert 2 == len(actual)

    # Check each result
    assert 'dir/a' == actual[0]
    assert 'dir/b' == actual[1]



# Generated at 2022-06-21 22:08:00.748155
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-21 22:08:06.211923
# Unit test for function join_each
def test_join_each():
    parent = '/some/path'
    children = ('foo', 'bar', 'baz')

    result = join_each(parent, children)
    for n, p in enumerate(result):
        assert p == os.path.join(parent, children[n])


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-21 22:08:09.611065
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', [])) == []
    assert list(join_each('foo', ['bar'])) == ['foo/bar']



# Generated at 2022-06-21 22:08:15.984532
# Unit test for function join_each
def test_join_each():
    assert list(join_each('', ['a', 'b', 'c'])) == ['a', 'b', 'c']
    assert list(join_each('a', ['', 'b', 'c'])) == ['a', 'ab', 'ac']
    assert list(join_each('/usr/local', ['bin', 'src'])) \
        == ['/usr/local/bin', '/usr/local/src']



# Generated at 2022-06-21 22:08:18.186771
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ("foo/bar", "foo/baz")

# Generated at 2022-06-21 22:08:21.103724
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b", "c"])) == [
        "/tmp/a",
        "/tmp/b",
        "/tmp/c",
    ]

