

# Generated at 2022-06-12 07:54:36.202770
# Unit test for function join_each
def test_join_each():
    tests = [
        (('/foo', 'bar'), '/foo/bar'),
        (('/foo', '.'), '/foo'),
        (('/foo', '..'), '/'),
        ((r'\foo', 'bar'), r'\foo\bar'),
    ]

    for parents, paths in tests:
        for parent, path in zip(parents, paths):
            assert path == next(join_each(parent, ['bar']))

# Generated at 2022-06-12 07:54:41.190531
# Unit test for function join_each
def test_join_each():
    cwd = os.getcwd()
    result = list(join_each(cwd, ['hello', 'hi']))
    assert '{}/hello'.format(cwd) in result
    assert '{}/hi'.format(cwd) in result
    result2 = list(join_each(cwd, ['hello', 'hi']))
    assert len(result) == len(result2)
    assert result == result2



# Generated at 2022-06-12 07:54:44.877732
# Unit test for function join_each
def test_join_each():
    assert [p for p in join_each('/test', ('a', 'b'))] ==\
           [os.path.join('/test', 'a'), os.path.join('/test', 'b')]

# Generated at 2022-06-12 07:54:49.038622
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["foo", "bar", "baz"]
    expected = [os.path.join(parent, s) for s in iterable]
    assert list(join_each(parent, iterable)) == expected


# Unit tests for function glob_all

# Generated at 2022-06-12 07:54:55.671503
# Unit test for function join_each
def test_join_each():
    expected_value_1 = 'howdy.doody/billy.joe'.split('/')
    actual_value_1   = join_each('howdy.doody', ['billy.joe'])
    expected_value_2 = ['howdy.doody', 'billy.joe']
    actual_value_2   = join_each('howdy.doody', ['billy.joe'])
    assert list(actual_value_1) == expected_value_1
    assert list(actual_value_2) == expected_value_2



# Generated at 2022-06-12 07:54:59.932094
# Unit test for function join_each
def test_join_each():
    parent = "/home"
    iterable = ["a", "b", "c"]
    expected = ["/home/a", "/home/b", "/home/c"]
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-12 07:55:07.358192
# Unit test for function join_each
def test_join_each():
    input_data = [
        ('dir1', ['dir2', 'dir3', 'dir4'], ['dir1/dir2', 'dir1/dir3', 'dir1/dir4']),
        ('dir1', [], []),
        (None, ['dir1', 'dir2', 'dir3'], ['dir1', 'dir2', 'dir3']),
        (None, [], []),
        ('dir1', None, [])
    ]
    for parent, iterable, expected_results in input_data:
        assert list(join_each(parent, iterable)) == expected_results



# Generated at 2022-06-12 07:55:11.504761
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ('bar', 'baz'))) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:55:13.142047
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-12 07:55:15.213217
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['foo', 'bar'])) == ['/tmp/foo', '/tmp/bar']



# Generated at 2022-06-12 07:55:19.907602
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/data', ['image1.png', 'image2.png'])) == ['/data/image1.png', '/data/image2.png']

# Generated at 2022-06-12 07:55:27.971254
# Unit test for function join_each
def test_join_each():
    parent = '/home/miro'
    paths = ["Documents", "Downloads", "Pictures"]
    result = join_each(parent, paths)
    assert(list(result) == ['/home/miro/Documents', '/home/miro/Downloads', '/home/miro/Pictures'])
    # Let's be user friendly!
    result = list(join_each(parent, paths))
    result = ", ".join(result)
    assert(result == '/home/miro/Documents, /home/miro/Downloads, /home/miro/Pictures')



# Generated at 2022-06-12 07:55:30.553623
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', ['dir1', 'dir2', 'dir3'])) == [
        '/etc/dir1', '/etc/dir2', '/etc/dir3']

# Generated at 2022-06-12 07:55:37.962778
# Unit test for function join_each
def test_join_each():
    print('start test')

    func_name = sys._getframe().f_code.co_name
    test_name = '{0} test1'.format(func_name)
    print(test_name)

    parent_path = r'.'
    iterable = ['./test', './test.txt']
    iterable02 = ('./test', './test.txt')
    for iterable_var in [iterable, iterable02]:
        for iterator in join_each(parent_path, iterable_var):
            print(iterator)

    print('result: OK')



# Generated at 2022-06-12 07:55:40.875929
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child1', 'child2', 'child3'])) == ['parent/child1', 'parent/child2',
                                                                         'parent/child3']



# Generated at 2022-06-12 07:55:44.664154
# Unit test for function join_each
def test_join_each():

    parent = '/home/fp'
    iterable = ['a', 'b', 'c']

    assert list(join_each(parent, iterable)) == [
    '/home/fp/a',
    '/home/fp/b',
    '/home/fp/c',
    ]

# Generated at 2022-06-12 07:55:48.801940
# Unit test for function join_each
def test_join_each():
    # Test with an empty iterable
    assert list(join_each("/", [])) == []
    # Test with a simple iterable
    assert list(
        join_each("/", ["python", "src", "dir"])
    ) == ["/python", "/src", "/dir"]

# Generated at 2022-06-12 07:55:52.290992
# Unit test for function join_each
def test_join_each():
    parent = "c:/a/b"
    iterable = ["c", "d"]
    result = list(join_each(parent, iterable))
    assert result == ["c:/a/b/c", "c:/a/b/d"]

# Generated at 2022-06-12 07:55:55.694614
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    joined = join_each('parent', iterable)

    assert type(joined) is types.GeneratorType
    assert list(joined) == ['parent/a', 'parent/b', 'parent/c']



# Generated at 2022-06-12 07:55:59.056369
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child1', 'child2'])) == [
        'parent/child1',
        'parent/child2'
    ]

# Generated at 2022-06-12 07:56:07.251525
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['1', '2', '3'])) == ['foo/1', 'foo/2', 'foo/3']

# Generated at 2022-06-12 07:56:10.686887
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo/bar', ['baz', 'qux'])) == [
        '/foo/bar/baz',
        '/foo/bar/qux'
    ]



# Generated at 2022-06-12 07:56:13.523711
# Unit test for function join_each
def test_join_each():
    assert list(join_each('root', ['sub1', 'sub2'])) == ['root/sub1', 'root/sub2']
    assert list(join_each('root', [])) == []



# Generated at 2022-06-12 07:56:16.855673
# Unit test for function join_each
def test_join_each():
    dirs = list(join_each('.', ['a', 'b', 'c']))
    print(dirs)
    assert dirs == ['./a', './b', './c']

test_join_each()

# Generated at 2022-06-12 07:56:21.160008
# Unit test for function join_each
def test_join_each():
    parent = os.path.abspath(os.getcwd())
    iterable = ["one", "two", "three"]
    assert list(join_each(parent, iterable)) == \
           [os.path.join(parent, p) for p in iterable]

# Generated at 2022-06-12 07:56:23.731683
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == [
        '/a', '/b', '/c'
    ]



# Generated at 2022-06-12 07:56:25.518594
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['bin', 'lib'])) == [
        '/usr/bin',
        '/usr/lib',
    ]

# Generated at 2022-06-12 07:56:27.926614
# Unit test for function join_each
def test_join_each():
    test_paths = ['/a', 'b', '/c']
    expected_paths = ['/a', '/a/b', '/a/c']
    assert list(join_each('/a', test_paths)) == expected_paths



# Generated at 2022-06-12 07:56:32.285392
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == [
        '/a', '/b', '/c'
    ]
    assert list(join_each('/', ['a'])) == [
        '/a'
    ]
    assert list(join_each('/', [])) == [
    ]

# Generated at 2022-06-12 07:56:35.088152
# Unit test for function join_each
def test_join_each():
    res = list(join_each("/var", ["a", "b", "c"]))
    assert res == ["/var/a", "/var/b", "/var/c"]



# Generated at 2022-06-12 07:56:51.500588
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/etc", ["passwd", "group"])) == ["/etc/passwd", "/etc/group"]
    assert list(join_each("/usr", [])) == []


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:56:53.653435
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-12 07:57:00.623307
# Unit test for function join_each
def test_join_each():
    assert len(list(join_each("/", []))) == 0
    assert len(list(join_each("/", ["a", "b", "c"]))) == 3
    assert list(join_each("/", ["a", "b", "c"])) == ["/a", "/b", "/c"]
    assert list(join_each("/", ["a", "", "c"])) == ["/a", "/", "/c"]

# Generated at 2022-06-12 07:57:03.009898
# Unit test for function join_each
def test_join_each():
    assert tuple(
        join_each("foo", ("bar", "baz"))
    ) == ("foo/bar", "foo/baz")



# Generated at 2022-06-12 07:57:09.638814
# Unit test for function join_each
def test_join_each():
    files = ['one.txt', 'two.txt', 'three.txt']
    paths = join_each(parent='~', iterable=files)
    assert next(paths) == '~/one.txt'
    assert next(paths) == '~/two.txt'
    assert next(paths) == '~/three.txt'
    try:
        next(paths)
    except (StopIteration):
        assert True
    else:
        assert False

# Generated at 2022-06-12 07:57:12.446514
# Unit test for function join_each
def test_join_each():
    assert ["./1.txt", "./2.txt", "./3.txt"] == list(join_each("./", ["1.txt", "2.txt", "3.txt"]))



# Generated at 2022-06-12 07:57:16.345042
# Unit test for function join_each
def test_join_each():
    test_cases = [
        ("foo", ["bar", "baz"], ["foo/bar", "foo/baz"]),
        ("nope/nope", ["bla", "bla"], ["nope/nope/bla", "nope/nope/bla"])
    ]
    for parent, iterable, expected in test_cases:
        actua

# Generated at 2022-06-12 07:57:19.708676
# Unit test for function join_each
def test_join_each():
    expected = [os.path.join('.', '..'), os.path.join('.', '.'),
                os.path.join('.', 'test')]
    assert list(join_each('.', ['..', '.', 'test'])) == expected



# Generated at 2022-06-12 07:57:22.987776
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ('bob', 'alice', 'joe'))) == [
        '/home/bob', '/home/alice', '/home/joe']



# Generated at 2022-06-12 07:57:26.486108
# Unit test for function join_each
def test_join_each():
    iterable = ["first", "second", "third"]
    assert list(join_each("path", iterable)) == ["path/first", "path/second", "path/third"]



# Generated at 2022-06-12 07:57:55.381875
# Unit test for function join_each
def test_join_each():
    parent = '/home/cisco'
    children = ['a', 'b', 'c']
    expected = ['/home/cisco/a', '/home/cisco/b', '/home/cisco/c']
    actual = list(join_each(parent, children))
    assert expected == actual



# Generated at 2022-06-12 07:57:57.048298
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-12 07:57:59.051469
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["x", "y", "z"])) == ["/x", "/y", "/z"]



# Generated at 2022-06-12 07:58:01.785036
# Unit test for function join_each
def test_join_each():
    assert [os.path.join('/home/users', f) for f in ['james', 'johnny']] == \
        list(join_each('/home/users', ['james', 'johnny']))



# Generated at 2022-06-12 07:58:04.315180
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c', 'd'])) == ['a/b', 'a/c', 'a/d']



# Generated at 2022-06-12 07:58:07.767067
# Unit test for function join_each
def test_join_each():
    assert list(join_each("base", ["a", "b", "c"])) == [
        "base/a",
        "base/b",
        "base/c",
    ]



# Generated at 2022-06-12 07:58:10.485159
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['bar', 'baz'])) \
        == ['/foo/bar', '/foo/baz']



# Generated at 2022-06-12 07:58:12.214633
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-12 07:58:20.831857
# Unit test for function join_each
def test_join_each():
    """
    Test join_each function
    :return:
    """
    join_1 = list(join_each("/home/bailey", ["trials", "ps1", "ps2", "ps3", "ps4"]))
    print(join_1)
    assert join_1 == ["/home/bailey/trials",
                      "/home/bailey/ps1",
                      "/home/bailey/ps2",
                      "/home/bailey/ps3",
                      "/home/bailey/ps4"]

    join_2 = list(join_each("/home/bailey", ["trials", "10", "20", "30", "40"]))
    print(join_2)

# Generated at 2022-06-12 07:58:22.974216
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['test1', 'test2'])) == \
        ['/tmp/test1', '/tmp/test2']



# Generated at 2022-06-12 07:59:15.772077
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ("foo", "bar"))) == ["/tmp/foo", "/tmp/bar"]



# Generated at 2022-06-12 07:59:18.983538
# Unit test for function join_each
def test_join_each():
    result = join_each('foo', ['bar', 'baz'])
    assert next(result) == 'foo/bar'
    assert next(result) == 'foo/baz'



# Generated at 2022-06-12 07:59:20.927702
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']



# Generated at 2022-06-12 07:59:25.914121
# Unit test for function join_each
def test_join_each():
    parent = '/home/user/'
    iterable = ['abc', 'def', 'ghi']
    expected = [
        '/home/user/abc',
        '/home/user/def',
        '/home/user/ghi'
    ]
    actual = list(join_each(parent, iterable))
    assert actual == expected
    # assert [os.path.join(parent, x) for x in iterable] == actual


test_join_each()

# Generated at 2022-06-12 07:59:30.889369
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["dev", "tmp"])) == ["/dev", "/tmp"]
    assert list(join_each("/dev", ["tty0", "tty1"])) == ["/dev/tty0", "/dev/tty1"]
    assert list(join_each("/home", ["dave", "paul", "john", "greg"])) == [
        "/home/dave", "/home/paul", "/home/john", "/home/greg"
    ]

# Generated at 2022-06-12 07:59:36.401616
# Unit test for function join_each
def test_join_each():
    parent = "."
    iterable = ["a", "b", "c"]
    res = list(join_each(parent, iterable))
    exp = [
        os.path.join(parent, "a"),
        os.path.join(parent, "b"),
        os.path.join(parent, "c"),
    ]
    assert res == exp



# Generated at 2022-06-12 07:59:38.498867
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    childs = ['a', 'b', 'c']
    assert len(list(join_each(parent, childs))) == 3

# Generated at 2022-06-12 07:59:47.103559
# Unit test for function join_each
def test_join_each():
    import unittest.mock as mock

    parent = object()
    iterable = [1, 2, 3]
    result = join_each(parent, iterable)
    mock_join = mock.Mock(side_effect=iterable)
    with mock.patch("os.path.join", mock_join):
        assert next(result) == mock_join.return_value
        assert mock_join.call_args_list[0][0] == (parent, iterable[0])
        assert next(result) == mock_join.return_value
        assert mock_join.call_args_list[1][0] == (parent, iterable[1])
        assert next(result) == mock_join.return_value
        assert mock_join.call_args_list[2][0] == (parent, iterable[2])

# Generated at 2022-06-12 07:59:50.014094
# Unit test for function join_each
def test_join_each():
    parent = "/usr"
    iterable = ["bin", "local", "bin"]

    assert list(join_each(parent, iterable)) == \
        ['/usr/bin', '/usr/local', '/usr/bin']

# Generated at 2022-06-12 07:59:53.377311
# Unit test for function join_each
def test_join_each():
    parent = "/bin"
    children = ['bash', 'zsh']

    assert list(join_each(parent, children)) == [
        '/bin/bash',
        '/bin/zsh'
    ]


"""
Time Complexity: O(n)
Space Complexity: O(n)
"""

# Generated at 2022-06-12 08:01:55.248953
# Unit test for function join_each
def test_join_each():
    results = [r for r in join_each('/tmp', ('a', 'b'))]
    assert results == [
        '/tmp/a',
        '/tmp/b',
    ]

# Generated at 2022-06-12 08:01:57.936540
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['home', 'user', 'data'])) == [
        '/home', '/user', '/data'
    ]



# Generated at 2022-06-12 08:02:04.099237
# Unit test for function join_each
def test_join_each():
    result = list(join_each(
        "D:/python/", ["1", "2", "3", "4", "5", "6"]))
    assert result == [
        "D:/python/1",
        "D:/python/2",
        "D:/python/3",
        "D:/python/4",
        "D:/python/5",
        "D:/python/6"
    ]


# Function to split a list into groups of a specified size

# Generated at 2022-06-12 08:02:12.685939
# Unit test for function join_each
def test_join_each():
    test_cases = [
        (["p"], ["c1", "c2"], ["p/c1", "p/c2"]),
        (["p1", "p2"], ["c1", "c2"], ["p1/c1", "p1/c2", "p2/c1", "p2/c2"]),
    ]
    for parent_list, child_list, expected_outcome in test_cases:
        actual_outcome = [p for p in join_each(parent_list, child_list)]
        try:
            assert actual_outcome == expected_outcome
        except AssertionError:
            print(f"{parent_list}: {child_list} should have been {expected_outcome} but is {actual_outcome}")

# Generated at 2022-06-12 08:02:16.337356
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['home', 'Pictures'])) == ['/home', '/Pictures']
    assert list(join_each('/', [])) == []
    assert list(join_each('/home', ['Pictures', 'Downloads'])) == ['/home/Pictures', '/home/Downloads']
    assert list(join_each('./', ['home', 'Pictures'])) == ['./home', './Pictures']

# Generated at 2022-06-12 08:02:19.550199
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['.git', '..', '.']

    assert join_each(parent, iterable) == [
        'parent/.git',
        'parent/..',
        'parent/.'
    ]

# Generated at 2022-06-12 08:02:30.312030
# Unit test for function join_each
def test_join_each():
    assert len(list(join_each("/usr/bin", ["ls", "cd", "python"]))) == 3
    assert list(join_each("/usr/bin", ["ls", "cd", "python"]))[0] == "/usr/bin/ls"
    assert list(join_each("/usr/bin", ["ls", "cd", "python"]))[1] == "/usr/bin/cd"
    assert list(join_each("/usr/bin", ["ls", "cd", "python"]))[2] == "/usr/bin/python"
    assert len(list(join_each("/home", ["", "usr", "local"]))) == 3
    assert list(join_each("/home", ["", "usr", "local"]))[0] == "/home/"

# Generated at 2022-06-12 08:02:32.965733
# Unit test for function join_each
def test_join_each():
    parent = "testing"
    iterable = ["a", "b", "c"]
    output = ["testing/a", "testing/b", "testing/c"]
    assert list(join_each(parent, iterable)) == output



# Generated at 2022-06-12 08:02:35.574640
# Unit test for function join_each
def test_join_each():
    testiter = ["a", "b", "c"]
    expected = [os.path.join(".", "a"), os.path.join(".", "b"), os.path.join(".", "c")]
    result = join_each(".", testiter)
    assert list(result) == expected



# Generated at 2022-06-12 08:02:40.742734
# Unit test for function join_each
def test_join_each():
    parent = os.path.abspath(".")
    test_paths = ("test", "test2")
    result_paths = join_each(parent, test_paths)
    assert os.path.join(parent, test_paths[0]) == next(result_paths)

