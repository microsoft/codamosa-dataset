

# Generated at 2022-06-12 07:54:39.322223
# Unit test for function join_each
def test_join_each():
    assert list(join_each(None, [None])) == [None]
    assert list(join_each(None, [])) == []
    assert list(join_each('', [])) == []
    assert list(join_each('a', [])) == []
    assert list(join_each('a', ['b'])) == ['a/b']
    assert list(join_each('', ['a'])) == ['a']
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('', ['a', 'b'])) == ['a', 'b']
    assert list(join_each(None, [None, 'a'])) == [None, 'a']

# Generated at 2022-06-12 07:54:46.135807
# Unit test for function join_each
def test_join_each():
    parent = '/home/stefan'
    iterable = ('dir1', 'dir2', 'dir3')

    # Result with lambda
    result_lambda = ('/home/stefan/dir1',
                     '/home/stefan/dir2',
                     '/home/stefan/dir3')

    assert list(join_each(parent, iterable)) == result_lambda



# Generated at 2022-06-12 07:54:52.010527
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['d1', 'd2'])) == ['/d1', '/d2']
    assert list(join_each('/', ['d1/', 'd2/'])) == ['/d1/', '/d2/']
    assert list(join_each('/', ['d1//', 'd2//'])) == ['/d1//', '/d2//']


# Display all files

# Generated at 2022-06-12 07:54:54.374858
# Unit test for function join_each
def test_join_each():
    paths = ["foo.jpg", "bar.jpg"]
    assert list(join_each("/", paths)) == ["/foo.jpg", "/bar.jpg"]



# Generated at 2022-06-12 07:55:04.700839
# Unit test for function join_each
def test_join_each():
    tests = (
        [('/nested', ['one', 'two', 'three']),
         ['/nested/one', '/nested/two', '/nested/three']],
        [('/nested', ['one/', 'two', 'three/']),
         ['/nested/one', '/nested/two', '/nested/three']])
    for (test, expected) in tests:
        print('INPUT: ' + str(test))
        print('EXPECTED: ' + str(expected))
        actual = list(join_each(*test))
        print('ACTUAL: ' + str(actual))


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-12 07:55:08.524751
# Unit test for function join_each
def test_join_each():
    source_path = 'foo/bar'
    file_paths = ['baz', 'qux', 'quux']
    expected_paths = ['foo/bar/baz', 'foo/bar/qux', 'foo/bar/quux']
    assert list(join_each(source_path, file_paths)) == expected_paths

# Generated at 2022-06-12 07:55:16.611356
# Unit test for function join_each
def test_join_each():
    # Test case 1, 2
    test_parent = 'parent'
    test_iterable = ['a', 'b']
    test_expect = ['parent/a', 'parent/b']
    assert list(join_each(test_parent, test_iterable)) == test_expect

    # Test case 3
    test_parent = 'parent/'
    test_iterable = ['/a', '/b']
    test_expect = ['parent//a', 'parent//b']
    assert list(join_each(test_parent, test_iterable)) == test_expect

# Generated at 2022-06-12 07:55:18.395426
# Unit test for function join_each
def test_join_each():
    parent = '/a/b'
    iterable = ['c', 'd', 'e']

# Generated at 2022-06-12 07:55:22.633909
# Unit test for function join_each
def test_join_each():
    iterable = ['dir1/', 'dir2/', 'dir3/']
    parent = 'home/user/'
    actual = list(join_each(parent, iterable))
    expect = ['home/user/dir1/', 'home/user/dir2/', 'home/user/dir3/']
    assert expect == actual

# Generated at 2022-06-12 07:55:26.073687
# Unit test for function join_each
def test_join_each():
    parent = "/tmp"
    iterable = (".profile", "bashrc")
    expected = (
        "/tmp/.profile",
        "/tmp/bashrc",
    )
    assert tuple(join_each(parent, iterable)) == expected



# Generated at 2022-06-12 07:55:34.235180
# Unit test for function join_each
def test_join_each():
    parent = '/home/amir/de_fuzz'
    iterable = ['this', 'that', 'other']
    expected_result = [
        '/home/amir/de_fuzz/this',
        '/home/amir/de_fuzz/that',
        '/home/amir/de_fuzz/other',
    ]
    for i, res in enumerate(join_each(parent, iterable)):
        assert res == expected_result[i]



# Generated at 2022-06-12 07:55:37.876045
# Unit test for function join_each
def test_join_each():
    parent = '/etc'
    iterable = ['passwd', 'groups', 'networks']
    expected = ['/etc/passwd', '/etc/groups', '/etc/networks']
    result = list(join_each(parent, iterable))
    assert result == expected



# Generated at 2022-06-12 07:55:40.051459
# Unit test for function join_each
def test_join_each():
    assert list(join_each('x', ['y', 'z'])) == ['x/y', 'x/z']



# Generated at 2022-06-12 07:55:43.874453
# Unit test for function join_each
def test_join_each():
    path = 'some/directory/'
    joined_paths = join_each(path, ['file', 'other_file'])
    first, second = joined_paths
    assert first == 'some/directory/file'
    assert second == 'some/directory/other_file'

# Generated at 2022-06-12 07:55:46.011539
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar/bat'])) == ['/foo', '/bar/bat']



# Generated at 2022-06-12 07:55:48.332690
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b"])) == ['/tmp/a', '/tmp/b']



# Generated at 2022-06-12 07:55:50.276884
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/', ['foo', 'bar'])) == ('/foo', '/bar')



# Generated at 2022-06-12 07:55:55.229888
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == [
        '/a',
        '/b',
        '/c'
    ]
    assert list(join_each('/home/', ['a', 'b', 'c'])) == [
        '/home/a',
        '/home/b',
        '/home/c'
    ]



# Generated at 2022-06-12 07:55:59.243754
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/bob', ('file1.txt', 'file2.txt'))) == [
        '/home/bob/file1.txt', '/home/bob/file2.txt'
    ]

# Generated at 2022-06-12 07:56:05.159078
# Unit test for function join_each
def test_join_each():
    # Test example from the function docstring
    expected = ("/home/user/bin", "/home/user/bin/python")
    assert tuple(join_each("/home/user", ("bin", "bin/python"))) == expected
    # Test an empty list
    assert tuple(join_each("/tmp", ())) == ()


if __name__ == "__main__":
    print("Running module tests")
    test_join_each()

# Generated at 2022-06-12 07:56:13.571573
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/jeff', ['test.txt', 'test2.txt'])) == [
        '/home/jeff/test.txt', '/home/jeff/test2.txt']

# Generated at 2022-06-12 07:56:15.674190
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', (1, 2, 3))) == ['foo/1', 'foo/2', 'foo/3']



# Generated at 2022-06-12 07:56:19.924018
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/a/b/c', ['d', 'e'])) == ['/a/b/c/d', '/a/b/c/e']

# Generated at 2022-06-12 07:56:24.215057
# Unit test for function join_each
def test_join_each():
    p1 = '/opt/detectron2'
    paths = ['a', 'b']
    actual = list(join_each(p1, paths))
    expected = ['/opt/detectron2/a', '/opt/detectron2/b']
    assert actual == expected



# Generated at 2022-06-12 07:56:26.274809
# Unit test for function join_each
def test_join_each():
    assert list(join_each("mydir", ["file1", "file2"])) == [
        "mydir/file1",
        "mydir/file2",
    ]



# Generated at 2022-06-12 07:56:29.936666
# Unit test for function join_each
def test_join_each():
    parent = "/home/user"
    iterable = ["test1", "test2", "test3"]
    expected = ["/home/user/test1", "/home/user/test2", "/home/user/test3"]
    results = list(join_each(parent, iterable))
    assert results == expected

# Generated at 2022-06-12 07:56:34.666877
# Unit test for function join_each
def test_join_each():
    parent = '/home/user'
    iterable = ['1', '2']
    assert list(join_each(parent, iterable)) == ['/home/user/1', '/home/user/2']
    assert list(join_each(parent, iterable)) != ['/home/user/1', '/home/user/3']

# Generated at 2022-06-12 07:56:38.429897
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["bin", "usr"])) == ["/bin", "/usr"]
    assert list(join_each("/", ["", "usr"])) == ["/", "/usr"]
    assert list(join_each("/", [])) == []



# Generated at 2022-06-12 07:56:41.791081
# Unit test for function join_each
def test_join_each():
    cases = [
        ('/a/b', ('c', 'd'), ['/a/b/c', '/a/b/d'])
    ]
    for case in cases:
        assert case[2] == list(join_each(*case[:2]))

# Generated at 2022-06-12 07:56:43.595727
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['', 'usr', 'bin'])) == ['/', '/usr', '/bin']

# Generated at 2022-06-12 07:56:57.656363
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['a', 'b'])) == ['./a', './b']

# Generated at 2022-06-12 07:57:02.071463
# Unit test for function join_each
def test_join_each():
    parent = 'D:/a/b'
    test_files = ['c', 'd/e']
    result = ['D:/a/b/c', 'D:/a/b/d/e']
    assert list(join_each(parent, test_files)) == result



# Generated at 2022-06-12 07:57:08.983173
# Unit test for function join_each
def test_join_each():
    parent = "/tmp/dir"
    files = ["a", "b", "c"]
    expected = ["/tmp/dir/a", "/tmp/dir/b", "/tmp/dir/c"]
    actual = list(join_each(parent, files))
    assert expected == actual


# Functionalize the following code. Transformation steps
# to get to the functional version:
# 1. Use map instead of list comprehensions.
# 2. Use filter instead of if.
# 3. Use reduce or functools.reduce.

# Generated at 2022-06-12 07:57:13.585659
# Unit test for function join_each
def test_join_each():
    input_str = 'abc'
    input_list = ['a', 'b', 'c']
    input_iterable = iter(input_list)
    output_list = list(join_each(input_str, input_iterable))
    expected_list = ['abc/a', 'abc/b', 'abc/c']
    assert output_list == expected_list

# Generated at 2022-06-12 07:57:15.023596
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['bc'])) == ['a/bc']



# Generated at 2022-06-12 07:57:17.392979
# Unit test for function join_each
def test_join_each():
    parent = 'foo'
    children = ['bar', 'baz']
    expected_join = [os.path.join(parent, p) for p in children]
    assert list(join_each(parent, children)) == expected_join



# Generated at 2022-06-12 07:57:20.039766
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', '/tmp', '/usr/local')) == \
        ['/home/tmp', '/home/usr/local']



# Generated at 2022-06-12 07:57:27.783295
# Unit test for function join_each
def test_join_each():
    test_iterable = ["a", "b/c", "d/e/f"]
    test_parent = "parent_dir"
    expected_output = [
        os.path.join("parent_dir", "a"),
        os.path.join("parent_dir", "b/c"),
        os.path.join("parent_dir", "d/e/f"),
    ]

    output = join_each(test_parent, test_iterable)
    assert expected_output == list(output)

# Generated at 2022-06-12 07:57:31.288876
# Unit test for function join_each
def test_join_each():
    assert list(join_each(os.path.join('hello', 'world'), ['a', 'b', 'c'])) == [
        os.path.join('hello', 'world', 'a'),
        os.path.join('hello', 'world', 'b'),
        os.path.join('hello', 'world', 'c'),
    ]



# Generated at 2022-06-12 07:57:34.425728
# Unit test for function join_each
def test_join_each():
    assert (list(join_each("/home/user", ["path", "file.txt"])) ==
            ["/home/user/path", "/home/user/file.txt"])



# Generated at 2022-06-12 07:58:02.216337
# Unit test for function join_each
def test_join_each():
    """
    join_each is a generator that take a parent directory and a list of
    items and yield the item joined with the parent directory
    """
    assert list(join_each('/', ['a', 'b', 'c'])) == [
        '/a', '/b', '/c'
    ]

# Generated at 2022-06-12 07:58:07.586493
# Unit test for function join_each
def test_join_each():
    parent = "/tmp"
    paths = ["a", "b"]
    # On macOS, the result is ["/tmp/a", "/tmp/b"]
    # On Windows, the result is ["\\tmp\\a", "\\tmp\\b"]
    assert list(join_each(parent, paths)) == [os.path.join(parent, p) for p in paths]

# Generated at 2022-06-12 07:58:11.520994
# Unit test for function join_each
def test_join_each():
    files = ['a.txt', 'b.txt', 'c.txt']
    assert list(join_each('/tmp', files)) == ['/tmp/a.txt', '/tmp/b.txt', '/tmp/c.txt']
    return True



# Generated at 2022-06-12 07:58:13.805230
# Unit test for function join_each
def test_join_each():
    asserts = list(join_each('spam', ['a', 'b', 'c']))
    assert len(asserts) == 3
    assert asserts[0] == 'spam/a'

# Generated at 2022-06-12 07:58:15.843695
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-12 07:58:22.769924
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', '.')) == ['/.']
    assert list(join_each('/', '..')) == ['/..']
    assert list(join_each('/', ['.', '..'])) == ['/.', '/..']
    assert list(join_each('/', {'.', '..'})) == ['/.', '/..']
    assert list(join_each('/', {'.': (), '..': ()})) == ['/.', '/..']
    assert list(join_each('/', ('.', '..'))) == ['/.', '/..']
    assert list(join_each('/', ('.', ('test',), '..'))) == ['/.', '/test', '/..']



# Generated at 2022-06-12 07:58:25.688336
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/local', ['bin', 'sbin'])) == ['/usr/local/bin', '/usr/local/sbin']
    assert list(join_each('/usr/local', [])) == []

# Generated at 2022-06-12 07:58:27.598018
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['user1', 'user2'])) == ['/home/user1', '/home/user2']

# Generated at 2022-06-12 07:58:31.498976
# Unit test for function join_each
def test_join_each():
    p = '/home/user'
    expected = ('/home/user/a', '/home/user/b', '/home/user/c')

    for i, e in zip(join_each(p, ('a', 'b', 'c')), expected):
        assert i == e



# Generated at 2022-06-12 07:58:38.801243
# Unit test for function join_each
def test_join_each():

    parent = '/a/b'
    iterable = ['', 'd', 'e']

    res = join_each(parent, iterable)
    expected_res = ['/a/b', '/a/b/d', '/a/b/e']

    assert len(res) == len(expected_res)

    for r, er in zip(res, expected_res):
        assert r == er


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-12 07:59:33.353457
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-12 07:59:35.718081
# Unit test for function join_each
def test_join_each():
    p = sys._getframe().f_code.co_name
    assert [p, p] == list(join_each(p, [p, p]))



# Generated at 2022-06-12 07:59:39.170876
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/a', ['', 'b', 'c'])) == ['/a', '/a/b', '/a/c']



# Generated at 2022-06-12 07:59:41.690998
# Unit test for function join_each
def test_join_each():
    iterable = join_each('/tmp', ['a', 'b'])
    assert next(iterable) == '/tmp/a'
    assert next(iterable) == '/tmp/b'



# Generated at 2022-06-12 07:59:45.464538
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', join_each('child', ['file', 'dir']))) == [
        'parent/child/file',
        'parent/child/dir'
    ]
    assert list(join_each('parent', ['/child/file'])) == [
        'parent/child/file'
    ]



# Generated at 2022-06-12 07:59:48.456747
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["usr", "local"])) == ["/usr", "/local"]

# Generated at 2022-06-12 07:59:53.333451
# Unit test for function join_each
def test_join_each():
    assert list(join_each("abc", ["def", "ghi"])) == ["abc/def", "abc/ghi"]
    assert list(join_each("abc/", ["def", "ghi"])) == ["abc/def", "abc/ghi"]
    assert list(join_each("abc/def", ["ghi", "jkl"])) == ["abc/def/ghi",
                                                          "abc/def/jkl"]



# Generated at 2022-06-12 07:59:55.506475
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a/b", ("c", "d"))) == ["/a/b/c", "/a/b/d"]

# Generated at 2022-06-12 07:59:57.607605
# Unit test for function join_each
def test_join_each():
    assert list(join_each('./', ['a', '/b', 'c'])) == ['./a', './b', './c']



# Generated at 2022-06-12 07:59:59.370970
# Unit test for function join_each
def test_join_each():
    assert ['a/b', 'a/c'] == list(join_each('a', ['b', 'c']))

# Generated at 2022-06-12 08:02:01.821180
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/bar', ('baz', 'buzz'))) == ('/bar/baz', '/bar/buzz')

# Generated at 2022-06-12 08:02:04.797401
# Unit test for function join_each
def test_join_each():
    x = ['a', 'b']
    assert list(join_each('/', x)) == ['/a', '/b']

if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:02:13.691225
# Unit test for function join_each
def test_join_each():
    parent = "C:\\Python\\"
    assert list(join_each(parent, ["file1.txt", "file2.txt", "file3.txt"])) == ["C:\\Python\\file1.txt", "C:\\Python\\file2.txt", "C:\\Python\\file3.txt"]
    assert list(join_each(parent, ["dir1", "dir2", "dir3"])) == ["C:\\Python\\dir1", "C:\\Python\\dir2", "C:\\Python\\dir3"]

# Generated at 2022-06-12 08:02:16.696181
# Unit test for function join_each
def test_join_each():
    iterable = join_each("/tmp", ["a", "b", "c"])
    assert iterable.__next__() == "/tmp/a"
    assert iterable.__next__() == "/tmp/b"
    assert iterable.__next__() == "/tmp/c"



# Generated at 2022-06-12 08:02:20.900271
# Unit test for function join_each
def test_join_each():
    base = u'/Users/foo/bar'
    paths = [u'a', u'b', u'c']
    expected = [u'/Users/foo/bar/a', u'/Users/foo/bar/b', u'/Users/foo/bar/c']
    joined = list(join_each(base, paths))
    assert joined == expected

# Generated at 2022-06-12 08:02:30.027819
# Unit test for function join_each
def test_join_each():
    import pytest
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']
    assert list(join_each(Path('foo'), ['bar', 'baz'])) == [Path('foo') / 'bar', Path('foo') / 'baz']
    assert list(join_each('foo', (Path('bar'), Path('baz')))) == ['foo/bar', 'foo/baz']
    assert list(join_each(Path('foo'), (Path('bar'), Path('baz')))) == [Path('foo') / 'bar', Path('foo') / 'baz']



# Generated at 2022-06-12 08:02:33.000027
# Unit test for function join_each
def test_join_each():
    parent = "/my/parent"
    iterable = ["a", "b", "c"]
    join_list = ["/my/parent/a", "/my/parent/b", "/my/parent/c"]
    assert list(join_each(parent, iterable)) == join_list

# Generated at 2022-06-12 08:02:39.120307
# Unit test for function join_each
def test_join_each():
    parent = "C:\\"
    paths = ["Users", "Administrator", "Desktop"]

    assert(list(join_each(parent, paths)) == [
           r"C:\Users", r"C:\Users\Administrator", r"C:\Users\Administrator\Desktop"])


# this is a generator function which generate
# all possible combinations in lexicographic order
# which are required to generate the permutations

# Generated at 2022-06-12 08:02:43.781952
# Unit test for function join_each
def test_join_each():
    parent = 'root'
    iterable = ['child1', 'child2', 'child3']
    expected = ['root/child1', 'root/child2', 'root/child3']
    result = list(join_each(parent, iterable))
    assert result == expected


# TODO: is there a better way to write this?
# 'walk' function that takes a directory path

# Generated at 2022-06-12 08:02:46.389514
# Unit test for function join_each
def test_join_each():
    p = 'parent'
    itr = ['one', 'two']
    assert list(join_each(p, itr)) == [os.path.join(p, x) for x in itr]