

# Generated at 2022-06-12 07:54:32.827448
# Unit test for function join_each
def test_join_each():
    assert list(
        join_each("/tmp", ["a", "b", "c"])
    ) == ["/tmp/a", "/tmp/b", "/tmp/c"]

# Generated at 2022-06-12 07:54:35.431241
# Unit test for function join_each
def test_join_each():
    assert ['/foo/bar', '/foo/baz'] == list(join_each('/foo', ['bar', 'baz']))



# Generated at 2022-06-12 07:54:40.173859
# Unit test for function join_each
def test_join_each():
    parent = 'c:\\temp'
    iterable = ('file1.txt', 'file2.txt', 'file3.txt')
    expected = ('c:\\temp\\file1.txt', 'c:\\temp\\file2.txt', 'c:\\temp\\file3.txt')
    assert list(join_each(parent, iterable)) == list(expected)



# Generated at 2022-06-12 07:54:44.167815
# Unit test for function join_each
def test_join_each():
    expected = ['/a/b/c', '/a/b/d', '/a/b/e']
    assert expected == list(join_each('/a/b', ['c', 'd', 'e']))



# Generated at 2022-06-12 07:54:47.865107
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ('a', 'b', 'c')
    expected = ('parent/a', 'parent/b', 'parent/c')
    assert tuple(join_each(parent, iterable)) == expected



# Generated at 2022-06-12 07:54:51.205025
# Unit test for function join_each
def test_join_each():
    # simple case
    seq = 'abc'
    assert list(join_each('/', seq)) == ['/a', '/b', '/c']

    # empty sequence
    assert list(join_each('/', '')) == []

# Generated at 2022-06-12 07:54:55.530662
# Unit test for function join_each
def test_join_each():
    parent = "hello"
    p = ["world", "how", "are", "you"]
    joined = []
    for j in join_each(parent, p):
        joined.append(j)
    assert joined == [
        "hello/world",
        "hello/how",
        "hello/are",
        "hello/you",
    ]

# Generated at 2022-06-12 07:55:03.373935
# Unit test for function join_each
def test_join_each():

    # Test 1: Simple join - join a value to a path
    p = Path("")
    iterable = ["dummy"]

    result = list(join_each(p, iterable))

    expected = ["dummy"]

    assert expected == result

    # Test 2: Join a list of values to a path
    p = Path("")
    iterable = ["dummy", "sub"]

    result = list(join_each(p, iterable))

    expected = ["dummy", "sub"]

    assert expected == result



# Generated at 2022-06-12 07:55:07.880259
# Unit test for function join_each
def test_join_each():
    parent = "/home/user"
    files = ["a", "b", "c"]
    j = join_each(parent, files)
    assert next(j) == "/home/user/a"
    assert next(j) == "/home/user/b"
    assert next(j) == "/home/user/c"


# End unit test


# Generated at 2022-06-12 07:55:12.247712
# Unit test for function join_each
def test_join_each():
    assert list(join_each('../..', ['file.txt', 'folder'])) == \
           ['../../file.txt', '../../folder']



# Generated at 2022-06-12 07:55:17.446069
# Unit test for function join_each
def test_join_each():
    parent = '/home/user'
    iterable = ['file1', 'file2']
    result = [x for x in join_each(parent, iterable)]
    assert result == ['/home/user/file1', '/home/user/file2']

# Generated at 2022-06-12 07:55:22.451303
# Unit test for function join_each
def test_join_each():
    test_parent_name = "test"
    test_entries = ["foo", "bar", "baz"]
    test_results = [
        os.path.join(test_parent_name, name) for name in test_entries]

    for result, test_result in zip(join_each(test_parent_name, test_entries),
                                   test_results):
        assert result == test_result



# Generated at 2022-06-12 07:55:25.351401
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', [])) == []
    assert list(join_each('/tmp', ['one', 'two'])) == ['/tmp/one', '/tmp/two']



# Generated at 2022-06-12 07:55:28.706491
# Unit test for function join_each
def test_join_each():
    assert list(join_each('src/', ['a', 'b'])) == ['src/a', 'src/b']
    assert list(join_each('', ['a', 'b'])) == ['a', 'b']

# Generated at 2022-06-12 07:55:30.883766
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['local', 'home'])) == [
        '/usr/local', '/usr/home']



# Generated at 2022-06-12 07:55:35.633460
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('/bar', ['foo'])) == ['/bar/foo'])
    assert(list(join_each('/bar', ['foo', 'bar'])) == ['/bar/foo', '/bar/bar'])
    assert(list(join_each('/bar', [])) == [])
    assert(list(join_each('', [])) == [])



# Generated at 2022-06-12 07:55:41.604652
# Unit test for function join_each
def test_join_each():
    parent = '/home/a/'
    childs = ['b', 'c', 'd']
    expected_res = ['/home/a/b', '/home/a/c', '/home/a/d']
    res = join_each(parent, childs)
    assert list(res) == expected_res


if __name__ == '__main__':
    # use test_join_each() to test function join_each.
    test_join_each()

# Generated at 2022-06-12 07:55:46.891790
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a/b/c", ["d", "e", "f"])) == [
        '/a/b/c/d',
        '/a/b/c/e',
        '/a/b/c/f',
    ]
    assert list(join_each("/", ["a", "b", "c"])) == ["/a", "/b", "/c"]

# Generated at 2022-06-12 07:55:50.699690
# Unit test for function join_each
def test_join_each():
    parent = "foo"
    iterable = ["bar", "baz"]

    result = join_each(parent, iterable)
    assert next(result) == os.path.join(parent, iterable[0])



# Generated at 2022-06-12 07:55:53.348976
# Unit test for function join_each
def test_join_each():
    assert list(
        join_each('/', ['one', 'two', 'three'])
    ) == ['/one', '/two', '/three']


# Algorithm 1

# Generated at 2022-06-12 07:56:01.900546
# Unit test for function join_each
def test_join_each():
    assert list(join_each('abc', ['def', 'ghi'])) == \
        ['abc/def', 'abc/ghi']



# Generated at 2022-06-12 07:56:04.639243
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo/', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']
    assert list(join_each('foo/', ['bar/qux'])) == ['foo/bar/qux']



# Generated at 2022-06-12 07:56:08.229654
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ['c', 'd', 'e'])) == [
        "/a/b/c", "/a/b/d", "/a/b/e"
    ]

# Generated at 2022-06-12 07:56:10.548694
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-12 07:56:13.996911
# Unit test for function join_each
def test_join_each():
    parent = "/tmp"
    items = ["foo", "bar", "baz"]
    expected = ["/tmp/foo", "/tmp/bar", "/tmp/baz"]
    actual = [path for path in join_each(parent, items)]
    assert expected == actual



# Generated at 2022-06-12 07:56:16.330694
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]



# Generated at 2022-06-12 07:56:19.388849
# Unit test for function join_each
def test_join_each():
    assert isinstance(join_each('a', 'bc'), types.GeneratorType)
    assert join_each('a', 'bc') == ['ab', 'ac']

# Generated at 2022-06-12 07:56:23.277752
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foodir", ["foo", "bar", "baz"])) == \
        ["foodir" + os.sep + "foo", "foodir" + os.sep + "bar", "foodir" + os.sep + "baz"]



# Generated at 2022-06-12 07:56:26.669413
# Unit test for function join_each
def test_join_each():
    parent = 'my/daddy'
    iterable = ['aaa', 'bbb', 'c.c']
    expect = ['my/daddy/aaa', 'my/daddy/bbb', 'my/daddy/c.c']
    assert list(join_each(parent, iterable)) == expect



# Generated at 2022-06-12 07:56:28.923490
# Unit test for function join_each
def test_join_each():
    assert os.path.join(
        '/home/user/foo', 'bar') == list(join_each('/home/user/foo', ['bar']))[0]

# Generated at 2022-06-12 07:56:45.633027
# Unit test for function join_each
def test_join_each():
    parent = "this"
    iterable = ["is", "a", "test"]
    for path, join in zip(join_each(parent, iterable),
                          map(os.path.join, [parent] * len(iterable), iterable)):
        assert path == join
    assert not list(join_each(parent, []))



# Generated at 2022-06-12 07:56:54.847421
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['bin', 'lib'])) == ['/bin', '/lib']
    assert list(join_each('/bin', ['lib', 'lib64'])) == ['/bin/lib',
                                                         '/bin/lib64']
    assert list(join_each('/bin', [])) == []
    assert list(join_each('/', ['bin', 'lib'])) != ['/bin', '/lib', '/usr']
    assert list(join_each('/', ['bin', 'lib'])) != ['/bin']
    assert list(join_each('/', ['bin', 'lib'])) != ['/lib']



# Generated at 2022-06-12 07:56:57.987173
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:57:03.836912
# Unit test for function join_each
def test_join_each():
    test_path = 'test_path'
    items = ['item', 'another_item']

    expected_results = []
    for item in items:
        expected_results.append(os.path.join(test_path, item))

    yielded_results = []
    for i in join_each(test_path, items):
        yielded_results.append(i)

    assert yielded_results == expected_results

# Generated at 2022-06-12 07:57:09.587606
# Unit test for function join_each
def test_join_each():

    paths = [
        "photon", "nucleus", "electron", "positron"
    ]
    result = join_each("/home/user", paths)
    assert list(result) == [
        "/home/user/photon",
        "/home/user/nucleus",
        "/home/user/electron",
        "/home/user/positron"
    ]

# Generated at 2022-06-12 07:57:13.342359
# Unit test for function join_each
def test_join_each():
    parent = '/home/user'
    children = ['Downloads', 'Documents', 'Desktop']
    result = join_each(parent, children)
    assert result == ['/home/user/Downloads',
                      '/home/user/Documents',
                      '/home/user/Desktop']

test_join_each()

# Generated at 2022-06-12 07:57:14.515780
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('x', [])) == ()



# Generated at 2022-06-12 07:57:16.177634
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-12 07:57:18.295440
# Unit test for function join_each
def test_join_each():
    assert list(join_each("root", "a b c".split())) == [
        "root/a",
        "root/b",
        "root/c",
    ]



# Generated at 2022-06-12 07:57:22.470959
# Unit test for function join_each
def test_join_each():
    i_sequence = (1, 2, 3, 4, 5)
    expected = tuple(os.path.join('parent', str(i)) for i in i_sequence)
    assert tuple(join_each('parent', i_sequence)) == expected

# Generated at 2022-06-12 07:57:36.837857
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']


# Find files with regex

# Generated at 2022-06-12 07:57:41.351741
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/local', 'bin', 'python', 'python2.6')) == [
        '/usr/local/bin', '/usr/local/python', '/usr/local/python2.6']
    assert list(join_each('/usr', 'bin', ['python', 'python2.6'])) == [
        '/usr/bin', '/usr/python', '/usr/python2.6']

# Generated at 2022-06-12 07:57:45.274584
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/user', ['bin', 'python'])) == ['/user/bin',
                                                           '/user/python']


# Find all absolute paths to Python files

# Generated at 2022-06-12 07:57:51.124991
# Unit test for function join_each
def test_join_each():

    parent = '/home/user'

    i1 = ['tmp', 'var', 'usr', 'local', 'bin']

    i2 = ['tmp', 'var', 'usr', 'local', 'bin']

    result = list(join_each(parent, i1))

    assert len(result) == len(i2)

    assert [os.path.join(parent, f) for f in i2] == result

    result = list(join_each(parent, i1))

    assert result == result


test_join_each()

# Generated at 2022-06-12 07:57:54.460229
# Unit test for function join_each
def test_join_each():
    iterable = ['1', '2', '3']
    parent = 'parent'

    result = list(join_each(parent, iterable))

    assert result == [os.path.join(parent, i) for i in iterable]



# Generated at 2022-06-12 07:57:57.623187
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/path/to/dir", ["file1.py", "file2.py"])) == \
        ["/path/to/dir/file1.py", "/path/to/dir/file2.py"]



# Generated at 2022-06-12 07:58:05.792325
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/local', ['bin', 'lib', 'include'])) == [
        '/usr/local/bin', '/usr/local/lib', '/usr/local/include']
    assert list(join_each('/tmp', ['.', '..', 'a', 'b'])) == [
        '/tmp/.', '/tmp/..', '/tmp/a', '/tmp/b']
    assert list(join_each('/a/b', ['/c', 'd', 'e/f'])) == [
        '/a/b/c', '/a/b/d', '/a/b/e/f']
    assert list(join_each('/', ['/'])) == ['/']



# Generated at 2022-06-12 07:58:08.365613
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']



# Generated at 2022-06-12 07:58:12.225109
# Unit test for function join_each
def test_join_each():
    parent = 'path'
    iterable = ['a', 'b']
    expected = iter(['path/a', 'path/b'])
    assert list(join_each(parent, iterable)) == list(expected)



# Generated at 2022-06-12 07:58:15.307853
# Unit test for function join_each
def test_join_each():
    parent = "C:/Users/Andy/Documents"
    iterable = ("Desk", "Laptop")
    result = join_each(parent, iterable)
    assert next(result) == "C:/Users/Andy/Documents\\Desk"



# Generated at 2022-06-12 07:58:42.720601
# Unit test for function join_each
def test_join_each():
    p = '/path/to'
    l = ['some', 'more', 'less']
    result = list(join_each(p, l))
    expect = [os.path.join(p, k) for k in l]
    assert result == expect


# TODO: add more tests

# Generated at 2022-06-12 07:58:49.499890
# Unit test for function join_each
def test_join_each():
    d = 'top dir'
    f = ['file1', 'file2', 'file3']
    expected = ['top dir/file1', 'top dir/file2', 'top dir/file3']
    # Generator should contain the same values
    assert list(join_each(d, f)) == expected
    # Generator should be exhausted
    assert list(join_each(d, f)) == []


# Read the contents of a file

# Generated at 2022-06-12 07:58:54.578764
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['home', 'user/bin'])) == [
        '/home', '/user/bin'
    ]
    assert list(join_each('/', [])) == []
    assert list(join_each('', ['home', 'user/bin'])) == [
        'home', 'user/bin'
    ]
    assert list(join_each('', [])) == []



# Generated at 2022-06-12 07:58:57.914490
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["1", "2", "3"])) == ["/1", "/2", "/3"]
    assert list(join_each("user", ["1", "2", "3"])) == ["user/1", "user/2", "user/3"]



# Generated at 2022-06-12 07:59:00.065991
# Unit test for function join_each
def test_join_each():
    joined = tuple(join_each("/some/path", ("a", "b", "c")))
    assert joined == ("/some/path/a", "/some/path/b", "/some/path/c")



# Generated at 2022-06-12 07:59:01.747761
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ("b", "c"))) == ["a/b", "a/c"]



# Generated at 2022-06-12 07:59:03.249083
# Unit test for function join_each
def test_join_each():
    a = ['a', 'b']

# Generated at 2022-06-12 07:59:08.185731
# Unit test for function join_each
def test_join_each():
    new_paths = list(join_each('/tmp/', ['a', 'b', 'c']))
    assert len(new_paths) == 3
    assert new_paths[0] == '/tmp/a'

# Generated at 2022-06-12 07:59:11.460585
# Unit test for function join_each
def test_join_each():
    assert join_each('~/tmp', ['a', 'b', 'c']) == ['~/tmp/a', '~/tmp/b', '~/tmp/c']


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-12 07:59:13.904533
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['p1', 'p2'])) == \
    [os.path.join('parent', 'p1'), os.path.join('parent', 'p2')]



# Generated at 2022-06-12 08:00:07.105086
# Unit test for function join_each
def test_join_each():
    assert join_each('abc', ['d', 'e', 'f']) ==\
        ['abc/d', 'abc/e', 'abc/f']



# Generated at 2022-06-12 08:00:09.976534
# Unit test for function join_each
def test_join_each():
    assert_equals(
        [os.path.join('/a/b', p) for p in ['ox.py', 'x.py']],
        list(join_each('/a/b', ['ox.py', 'x.py'])))

# Generated at 2022-06-12 08:00:21.625754
# Unit test for function join_each
def test_join_each():
    # Test 1
    test_parent = 'C:'
    test_iterable = ['Documents']
    expected_list = ['C:\\Documents']
    result_list = [i for i in join_each(test_parent, test_iterable)]
    assert expected_list == result_list

    # Test 2
    test_parent = 'C:\\'
    test_iterable = ['Documents', 'Images']
    expected_list = ['C:\\Documents', 'C:\\Images']
    result_list = [i for i in join_each(test_parent, test_iterable)]
    assert expected_list == result_list

    # Test 3
    test_parent = 'C:\\Document'
    test_iterable = ['s', 'Images']
    expected_list = ['C:\\Documents', 'C:\\Images']


# Generated at 2022-06-12 08:00:24.688439
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/path/to', ('a', 'b', 'c'))) == [
        '/path/to/a', '/path/to/b', '/path/to/c'
    ]



# Generated at 2022-06-12 08:00:26.330223
# Unit test for function join_each

# Generated at 2022-06-12 08:00:28.158686
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/bin', ('ls', 'python', 'gcc'))) == ['/bin/ls', '/bin/python', '/bin/gcc']

# Generated at 2022-06-12 08:00:31.252284
# Unit test for function join_each
def test_join_each():
    """
    Check that joining each element in a list to a parent path is done correctly
    """
    parent = 'C:/Users'
    l = ['myself', 'someone', 'somewhere']
    expected = ['C:/Users\\myself', 'C:/Users\\someone', 'C:/Users\\somewhere']
    result = list(join_each(parent, l))
    assert result == expected



# Generated at 2022-06-12 08:00:39.382755
# Unit test for function join_each
def test_join_each():
    paths = ['home/', 'movies/', 'moviename.mpg']

# Generated at 2022-06-12 08:00:42.968588
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', [])) == []
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 08:00:46.233237
# Unit test for function join_each
def test_join_each():
    assert list(join_each('data', ['test.csv', 'test.jpg', 'test.txt'])) == ['data/test.csv',
                                                                            'data/test.jpg',
                                                                            'data/test.txt']


# function join_each


# Generated at 2022-06-12 08:02:48.305051
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-12 08:02:51.772511
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    children = ["child1", "child2", "child3"]
    s = join_each(parent, children)
    for i in range(len(children)):
        assert s.next() == os.path.join(parent, children[i])


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-12 08:02:58.720926
# Unit test for function join_each
def test_join_each():
    from glob import glob
    from itertools import product as iterprod
    from itertools import combinations_with_replacement as itercombinations

    for path in itercombinations("../../", 2):
        path = "".join(path)
        paths = set(join_each(path, glob("*")))
        assert paths == set(glob("{}/*".format(path)))

    for path in iterprod("../../", "*"):
        path = os.path.join(*path)
        paths = set(join_each(path, glob("*")))
        assert paths == set(glob("{}/*".format(path)))



# Generated at 2022-06-12 08:03:00.522269
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-12 08:03:03.418520
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz", "quux"])) == [
        "foo/bar",
        "foo/baz",
        "foo/quux"
    ]

# Generated at 2022-06-12 08:03:05.276446
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp/', ['tmp', 'link', 'bin'])) == [
        '/tmp/tmp', '/tmp/link', '/tmp/bin']



# Generated at 2022-06-12 08:03:09.215185
# Unit test for function join_each
def test_join_each():
    import os
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == \
        [os.path.join('/tmp', 'a'), os.path.join('/tmp', 'b'), os.path.join('/tmp', 'c')]



# Generated at 2022-06-12 08:03:15.297157
# Unit test for function join_each
def test_join_each():
    parent = os.path.abspath(os.path.dirname(__file__))
    paths = [
        'test_attribute_filter.py',
        'test_coordinate_transformation.py',
        'test_network_filters.py'
    ]
    assert list(join_each(parent, paths)) == [
        os.path.join(parent, 'test_attribute_filter.py'),
        os.path.join(parent, 'test_coordinate_transformation.py'),
        os.path.join(parent, 'test_network_filters.py')
    ]



# Generated at 2022-06-12 08:03:16.814352
# Unit test for function join_each
def test_join_each():
    assert list(join_each('file', ['one', 'two'])) == ['file/one', 'file/two']

# Generated at 2022-06-12 08:03:20.281190
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['file1', 'file2'])) == \
        ['/home/file1', '/home/file2']


if __name__ == "__main__":
    test_join_each()
    print("Unit tests passed")

