

# Generated at 2022-06-12 07:54:30.589675
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b'])) == ['parent/a', 'parent/b']

# Generated at 2022-06-12 07:54:33.334442
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["bob", "stacy"])) == ['/home/bob', '/home/stacy']



# Generated at 2022-06-12 07:54:35.354830
# Unit test for function join_each
def test_join_each():
    path = 'C:\\'
    assert tuple(join_each(path, ('Windows', 'Program Files'))) == (
        r'C:\Windows', r'C:\Program Files')



# Generated at 2022-06-12 07:54:41.263394
# Unit test for function join_each
def test_join_each():
    path = 'data/parent'
    files = ['file1.csv', 'file2.csv', 'file3.csv']
    files = list(join_each(path, files))
    assert len(files) == 3
    assert files[0] == 'data/parent/file1.csv'
    assert files[1] == 'data/parent/file2.csv'
    assert files[2] == 'data/parent/file3.csv'

# Generated at 2022-06-12 07:54:44.554966
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == [
        'foo/bar', 'foo/baz'
    ]



# Generated at 2022-06-12 07:54:49.400634
# Unit test for function join_each
def test_join_each():
    """ Test if function join_each can join path correctly
    """
    assert list(join_each("root", ['a', 'b', 'c'])) == [
        os.path.join("root", 'a'),
        os.path.join("root", 'b'),
        os.path.join("root", 'c')
    ]

# Generated at 2022-06-12 07:54:53.141382
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    children = ['child1', 'child2']
    expected = [os.path.join(parent, 'child1'), os.path.join(parent, 'child2')]
    assert list(join_each(parent, children)) == expected



# Generated at 2022-06-12 07:54:55.318050
# Unit test for function join_each
def test_join_each():
    assert list(join_each('root', ['a', 'b'])) == [
        'root/a', 'root/b'
    ]
    return True



# Generated at 2022-06-12 07:54:58.763574
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/Users/user/", ["a", "b"])) \
        == ['/Users/user/a', '/Users/user/b']



# Generated at 2022-06-12 07:55:00.621097
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ("a", "b"))) == ["/a", "/b"]

# Generated at 2022-06-12 07:55:08.461352
# Unit test for function join_each
def test_join_each():
    dir1 = 'dir1'
    dir2 = 'dir2'
    subdir1 = 'subdir1'
    subdir2 = 'subdir2'

    joined_iter = join_each(dir1, [subdir1, subdir2])

    for joined, expected in zip(joined_iter, [os.path.join(dir1, subdir1),
                                              os.path.join(dir1, subdir2)]):
        assert joined == expected



# Generated at 2022-06-12 07:55:13.051378
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/etc", ["passwd", "fstab", "profile"])) == [
        "/etc/passwd",
        "/etc/fstab",
        "/etc/profile",
    ]



# Generated at 2022-06-12 07:55:17.372838
# Unit test for function join_each
def test_join_each():
    parent = os.path.expanduser("~/Desktop")
    childs = ["Python", "Perl", "R"]
    jc = list(join_each(parent, childs))
    assert len(childs) == len(jc)
    for i in range(len(childs)):
        assert os.path.join(parent, childs[i]) == jc[i]

# Generated at 2022-06-12 07:55:19.008829
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["home", "dir"])) == ["/home", "/dir"]



# Generated at 2022-06-12 07:55:21.814743
# Unit test for function join_each
def test_join_each():
    path = "test"
    res = [os.path.join(path, x) for x in ["a", "b"]]
    assert list(join_each(path, ["a", "b"])) == res

# Generated at 2022-06-12 07:55:27.049896
# Unit test for function join_each
def test_join_each():
    parent = '/home/jdoe'
    iterable = ['/bin', '/usr/bin', '/usr/local/bin']

    expected = ['/home/jdoe/bin',
                '/home/jdoe/usr/bin',
                '/home/jdoe/usr/local/bin']

    assert(list(join_each(parent, iterable)) == expected)

# Generated at 2022-06-12 07:55:31.932440
# Unit test for function join_each
def test_join_each():
    parent = "asdf"
    iterable = ["1", "2", "3"]
    expected = ["asdf/1", "asdf/2", "asdf/3"]

    assert list(join_each(parent, iterable)) == expected


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 07:55:34.094549
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/etc", ["passwd", "group"])) == [
                "/etc/passwd",
                "/etc/group",
            ]

# Generated at 2022-06-12 07:55:38.003823
# Unit test for function join_each
def test_join_each():
    p = 'C:/'
    c = ['/A.txt', '/B.py', '/C.c']
    assert list(join_each(p, c)) == [
        'C:/A.txt',
        'C:/B.py',
        'C:/C.c'
    ]



# Generated at 2022-06-12 07:55:43.364871
# Unit test for function join_each
def test_join_each():
    cwd = os.getcwd()
    in_and_expected = (('', ['a', 'b']),
      (cwd, ['a', 'b']),
      (cwd, ['a']))
    expected = [os.path.join(*p) for p in in_and_expected]
    actual = [path for path in join_each(*in_and_expected[0])]
    assert expected == actual

# Generated at 2022-06-12 07:55:51.178447
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('p', ('a', 'b'))) == ('p/a', 'p/b')



# Generated at 2022-06-12 07:55:56.130426
# Unit test for function join_each
def test_join_each():
    parent_ = os.path.dirname(__file__)
    actual = list(join_each(parent_, ('join_each.py', 'tests/test_util.py')))
    expected = [os.path.join(parent_, 'join_each.py'),
                os.path.join(parent_, 'tests/test_util.py')]
    assert actual == expected



# Generated at 2022-06-12 07:56:01.751191
# Unit test for function join_each
def test_join_each():
    actual = join_each('/a/b/c', ['.', '..', 'path'])
    expected = ['/a/b/c', '/a/b', '/a/b/c/path']
    for a, e in zip(actual, expected):
        print(a, e)
        assert a == e

# Generated at 2022-06-12 07:56:05.091127
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ['c', 'd'])) == ['/a/b/c', '/a/b/d']
    assert list(join_each('/v', [''])) == ['/v']
    assert list(join_each('/v', [])) == []



# Generated at 2022-06-12 07:56:08.673921
# Unit test for function join_each
def test_join_each():
    """Test for join_each function."""
    assert tuple(join_each('/var', ('log', 'cache', 'lib'))) == \
        ('/var/log', '/var/cache', '/var/lib')

# Generated at 2022-06-12 07:56:13.325644
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ('bin', 'local'))) == ['/usr/bin', '/usr/local']


if __name__ == '__main__':
    test_join_each()
    print(list(join_each(sys.argv[1], sys.argv[2:])))

# Generated at 2022-06-12 07:56:14.797479
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/root", ["a", "b"])) == [
        "/root/a", "/root/b"
    ]



# Generated at 2022-06-12 07:56:18.873914
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b", "c"])) == ["/tmp/a", "/tmp/b", "/tmp/c"]
    assert list(join_each("/tmp", "/")) == ["/tmp/", "/tmp/"]

# Generated at 2022-06-12 07:56:21.443273
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/foo/bar", ["apple", "orange"])) == [
        "/foo/bar/apple",
        "/foo/bar/orange",
    ]



# Generated at 2022-06-12 07:56:23.651771
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:56:38.466915
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each(".", ("data", "test_hmms", "test_model.hmm"))) == ("./data/test_hmms/test_model.hmm",)



# Generated at 2022-06-12 07:56:39.717522
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["a", "b"])) == ["/a", "/b"]



# Generated at 2022-06-12 07:56:42.540164
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['1', '2', '3'])) == [
        '/tmp/1', '/tmp/2', '/tmp/3']

# Generated at 2022-06-12 07:56:51.050719
# Unit test for function join_each
def test_join_each():
    test_join_each_cases = [
        {'parent': '/tmp', 'iterable': ['foo', 'bar', 'baz'], 'expected': ['/tmp/foo', '/tmp/bar', '/tmp/baz']},
        {'parent': '/tmp', 'iterable': ['foo'], 'expected': ['/tmp/foo']},
        {'parent': '/tmp', 'iterable': [], 'expected': []},
    ]

    for case in test_join_each_cases:
        actual = list(join_each(case['parent'], case['iterable']))
        assert actual == case['expected']

# Generated at 2022-06-12 07:56:58.160706
# Unit test for function join_each
def test_join_each():
    # Nothing to do
    if not hasattr(join_each, '__annotations__'):
        return

    # Check function arguments type annotation are valid
    from typing import Any, Iterable, Union, Callable, TypeVar
    TAny_co = TypeVar("TAny_co", covariant=True)
    TAny_contr = TypeVar("TAny_contr", contravariant=True)

    parent_type = type(join_each.__annotations__['parent'])
    assert parent_type == Any or issubclass(parent_type, Any)
    assert parent_type != TAny_co
    assert parent_type != TAny_contr

    iterable_type = type(join_each.__annotations__['iterable'])

# Generated at 2022-06-12 07:57:02.115557
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    p = os.path.join(parent, 'child')
    for i, j in zip(join_each(parent, ['child']), [p]):
        assert i == j



# Generated at 2022-06-12 07:57:04.788009
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/foo", ["bar", "baz"])) == [
        "/foo/bar",
        "/foo/baz",
    ]

# Generated at 2022-06-12 07:57:07.920388
# Unit test for function join_each
def test_join_each():
    paths = join_each('/etc', ['passwd', 'lols'])
    assert next(paths) == '/etc/passwd'
    assert next(paths) == '/etc/lols'

# Generated at 2022-06-12 07:57:13.380998
# Unit test for function join_each
def test_join_each():
    assert list(join_each("", ["a", "b"])) == ["a", "b"]
    assert list(join_each("a", ["", "b"])) == ["a", "ab"]
    assert list(join_each("a", ["b", "c"])) == ["ab", "ac"]
    assert list(join_each("a", ["", "b", "c"])) == ["a", "ab", "ac"]



# Generated at 2022-06-12 07:57:20.631564
# Unit test for function join_each
def test_join_each():
    print_test_header(join_each, "join_each")
    parent = os.path.abspath(os.path.dirname(__file__))
    test_paths = [
        ".",
        "..",
        "test.py",
        "a/b/c/d/e",
        "a/b/c/d",
        "a/b/c",
        "a/b",
        "a"
    ]
    for test_path in test_paths:
        print(test_path)
        print(parent)
        print(os.path.join(parent, test_path))
        print(join_each(parent, [test_path]))
        print(list(join_each(parent, [test_path])))

# Generated at 2022-06-12 07:57:37.202953
# Unit test for function join_each
def test_join_each():
    parent = 'parent'

    iterable = ['first', 'second', 'third']

    for i, j in zip(join_each(parent, iterable), map(os.path.join,
                                                     [parent] * len(iterable),
                                                     iterable)):
        assert i == j

# Generated at 2022-06-12 07:57:40.288998
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]
    assert list(join_each("a", ())) == []


# Tests that the given generator produces the expected output.

# Generated at 2022-06-12 07:57:43.164450
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp/', ['foo', 'bar'])) == \
        ['/tmp/foo', '/tmp/bar']



# Generated at 2022-06-12 07:57:47.076659
# Unit test for function join_each
def test_join_each():
    path = '/my/path'
    parts = ['a', 'b', 'c']
    expected = [os.path.join(path, part) for part in parts]
    result = list(join_each(path, parts))
    assert result == expected

# Generated at 2022-06-12 07:57:55.562215
# Unit test for function join_each
def test_join_each():
    print('Unit test for join_each:')
    parent = r'C:\temp'
    iterable = ['a.txt', 'b.txt', os.path.join('dir1', 'c.txt'),
                os.path.join('dir2', 'd.txt')]
    assert list(join_each(parent, iterable)) == \
           [os.path.join(parent, 'a.txt'),
            os.path.join(parent, 'b.txt'),
            os.path.join(parent, 'dir1', 'c.txt'),
            os.path.join(parent, 'dir2', 'd.txt')]
    print('Test passed!')


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-12 07:57:56.513771
# Unit test for function join_each

# Generated at 2022-06-12 07:57:57.373745
# Unit test for function join_each
def test_join_each():
    assert list(join_each("aa", ["bb", "cc"])) == ["aa/bb", "aa/cc"]



# Generated at 2022-06-12 07:57:58.249215
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['abc', 'def'])) == ['/abc', '/def']



# Generated at 2022-06-12 07:57:59.232136
# Unit test for function join_each
def test_join_each():
    l = list(join_each("dir", ["a", "b"]))
    assert l == ["dir/a", "dir/b"]

# Generated at 2022-06-12 07:58:01.638859
# Unit test for function join_each
def test_join_each():
    j = join_each('foo', ['a', 'b', '/', 'c'])
    assert list(j) == ['foo/a', 'foo/b', 'foo//', 'foo/c']



# Generated at 2022-06-12 07:58:26.147952
# Unit test for function join_each
def test_join_each():
    assert list(join_each('p', ['a', 'b'])) == ['p/a', 'p/b']

# Generated at 2022-06-12 07:58:28.029477
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-12 07:58:30.090803
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b'])) == ['parent/a', 'parent/b']



# Generated at 2022-06-12 07:58:31.958110
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ('b', 'c'))) == ['a/b', 'a/c']

# Generated at 2022-06-12 07:58:36.008747
# Unit test for function join_each
def test_join_each():
    assert list(join_each('Projects', ['Ex1', 'Ex2', 'Ex3'])) == ['Projects/Ex1', 'Projects/Ex2', 'Projects/Ex3']



# Generated at 2022-06-12 07:58:40.181660
# Unit test for function join_each
def test_join_each():
    assert os.path.join('/home', 'foo') == next(join_each('/home', ['foo']))
    assert list(join_each('/home', ['foo', 'bar'])) == [os.path.join('/home', 'foo'), os.path.join('/home', 'bar')]


# Generated at 2022-06-12 07:58:45.611908
# Unit test for function join_each
def test_join_each():
    examples = [
        {'parent': '.', 'iterable': ['a', 'b', 'c']},
        {'parent': 'foo', 'iterable': ['a', 'b', 'c']},
        {'parent': r'c:\foo', 'iterable': ['bar', 'baz']},
    ]
    expected = [
        ['.', 'a', 'b', 'c'],
        ['foo', 'a', 'b', 'c'],
        [r'c:\foo', r'c:\foo\bar', r'c:\foo\baz'],
    ]

    for i in range(len(examples)):
        assert list(join_each(**examples[i])) == expected[i]



# Generated at 2022-06-12 07:58:54.006635
# Unit test for function join_each
def test_join_each():
    assert list(join_each('p', ('a', 'b', 'c'))) == ['p/a', 'p/b', 'p/c']


# Create a directory tree that looks like this:
#
# .
# ├── a
# │   ├── b
# │   └── c
# └── d
#     └── e
#
# 4 directories, 0 files

# Make a new directory.
# Optionally pass a function to customize the name.
# The function must return a string.
# For example,
#
# def name():
#      return 'new-directory-name'

# Generated at 2022-06-12 07:59:00.262426
# Unit test for function join_each
def test_join_each():
    parent = os.path.normpath('/a/b')
    result = list(join_each(parent, ['f.txt', 'g.txt']))
    reference = [os.path.normpath('/a/b/f.txt'),
                 os.path.normpath('/a/b/g.txt')]
    assert result == reference
    result = list(join_each(parent, ['f.txt/g.txt']))
    assert result == [os.path.normpath('/a/b/f.txt/g.txt')]
    with pytest.raises(AssertionError):
        list(join_each(parent, ['/b/c.txt']))



# Generated at 2022-06-12 07:59:02.572916
# Unit test for function join_each
def test_join_each():
    words = 'foo bar baz'.split()

    assert list(join_each('/tmp', words)) == [
        '/tmp/foo',
        '/tmp/bar',
        '/tmp/baz',
    ]

# Generated at 2022-06-12 07:59:29.769620
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:59:31.185151
# Unit test for function join_each
def test_join_each():
    assert list(join_each('x', ['a', 'b'])) == ['x/a', 'x/b']

# Generated at 2022-06-12 07:59:34.234660
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b']
    assert list(join_each('/', iterable)) == ['/a', '/b']

# Generated at 2022-06-12 07:59:38.375721
# Unit test for function join_each
def test_join_each():
    root_dir = '/root/dir'
    sub_dirs = ['foo', 'bar']
    expected = ['/root/dir/foo', '/root/dir/bar']
    assert list(join_each(root_dir, sub_dirs)) == expected


# XXX: What's the relationship to join_each?

# Generated at 2022-06-12 07:59:42.995914
# Unit test for function join_each
def test_join_each():
    parent = '/a/b/c'
    iterable = ['a', 'b', 'c']

    expect = ['/a/b/c/a', '/a/b/c/b', '/a/b/c/c']
    actual = [p for p in join_each(parent, iterable)]
    assert expect == actual

# Generated at 2022-06-12 07:59:45.952990
# Unit test for function join_each
def test_join_each():
    assert isinstance(join_each('parent', 'abc'), type(iter('abc')))
    assert list(join_each('parent', 'abc')) == ['parent/a', 'parent/b', 'parent/c']
    assert list(join_each('parent', [])) == []



# Generated at 2022-06-12 07:59:50.097459
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/home/john', ['Documents', 'Downloads']))
    assert result == [os.path.join('/home/john', 'Documents'), os.path.join('/home/john', 'Downloads')]

# Generated at 2022-06-12 07:59:51.654066
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/root", ["a", "b"])) == ["/root/a", "/root/b"]

# Generated at 2022-06-12 07:59:55.375042
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/tmp', ['/plop', 'plip', 'plop']))
    expected = ['/tmp/plop', '/tmp/plip', '/tmp/plop']
    assert result == expected



# Generated at 2022-06-12 07:59:57.138864
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["etc", "bin"])) == ["/etc", "/bin"]



# Generated at 2022-06-12 08:00:54.336451
# Unit test for function join_each
def test_join_each():
    assert list(
        join_each(
            "/home/me/parent",
            ["child1", "child2"]
        )) == [
            "/home/me/parent/child1",
            "/home/me/parent/child2",
        ]



# Generated at 2022-06-12 08:00:56.791234
# Unit test for function join_each
def test_join_each():
    assert list(join_each('usr', ['bin', 'include'])) == [
        os.path.join('usr', 'bin'),
        os.path.join('usr', 'include')
    ]



# Generated at 2022-06-12 08:00:59.944172
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ['/c', 'd', 'e/f'])) == [
        '/a/b/c', '/a/b/d', '/a/b/e/f'
    ]

# Generated at 2022-06-12 08:01:04.398642
# Unit test for function join_each
def test_join_each():
    d = "."
    names = ["a", "b", "c"]
    for found, expected in zip(join_each(d, names), [x for x in map(lambda n: os.path.join(d, n), names)]):
        assert found == expected
    print("test_join_each passed")


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-12 08:01:07.549391
# Unit test for function join_each
def test_join_each():
    parent = '.'
    iterable = ['a', 'b', 'c']

    expected = ['./a', './b', './c']
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-12 08:01:11.218102
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ('child 1', 'child 2', 'child 3')
    expected_result = ('parent/child 1', 'parent/child 2', 'parent/child 3')
    actual_result = tuple(join_each(parent, iterable))
    assert expected_result == actual_result


if __name__ == '__main__':
    import logging
    logging.basicConfig(level=logging.INFO)
    test_join_each()

# Generated at 2022-06-12 08:01:13.046194
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ["bar", "baz"])) == ["foo/bar", "foo/baz"]

# Generated at 2022-06-12 08:01:23.403817
# Unit test for function join_each
def test_join_each():
    # Expected paths
    expected = [
        'my\\path\\file.exe',
        'my\\path\\file1.exe',
        'my\\path\\file2.exe',
    ]
    # Test paths
    paths = ['path', 'file.exe', 'file1.exe', 'file2.exe']
    # Assert
    assert (paths | join_each('my')) == expected


# Unit tests for function join_each
test_join_each()

# Generated at 2022-06-12 08:01:25.076272
# Unit test for function join_each
def test_join_each():
    print(list(join_each('a', ['b', 'c', 'd'])))



# Generated at 2022-06-12 08:01:27.482290
# Unit test for function join_each
def test_join_each():
    l = list(join_each('/home/user', ['.', '..', 'test']))
    assert l == ['/home/user/.', '/home/user/..', '/home/user/test']



# Generated at 2022-06-12 08:03:32.887926
# Unit test for function join_each
def test_join_each():
    parent = "C:\\"
    for j, v, f in os.walk("c:\\"):
        assert(list(join_each(j, f)) == [os.path.join(j, i) for i in f])

# Generated at 2022-06-12 08:03:35.959556
# Unit test for function join_each
def test_join_each():
    assert [
        os.path.join('/', p) for p in ['foo', 'bar', 'baz']
    ] == list(join_each('/', ['foo', 'bar', 'baz']))

# Generated at 2022-06-12 08:03:39.523119
# Unit test for function join_each
def test_join_each():
    try:
        assert list(join_each('/foo', ['a', 'b', 'c'])) == ['/foo/a', '/foo/b', '/foo/c']
    except AssertionError:
        print('test_join_each failed')



# Generated at 2022-06-12 08:03:40.919493
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-12 08:03:43.126707
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['home', 'ubuntu', 'bin'])) == ['/home', '/ubuntu', '/bin']
    assert list(join_each('/home', ['ubuntu', 'bin'])) == ['/home/ubuntu', '/home/bin']

# Generated at 2022-06-12 08:03:45.126591
# Unit test for function join_each
def test_join_each():
    assert list(join_each('test', ['a', 'b'])) == ['test/a', 'test/b']

# Generated at 2022-06-12 08:03:48.425148
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc/', ['opt', 'local', 'var'])) == [
        '/etc/opt', '/etc/local', '/etc/var']



# Generated at 2022-06-12 08:03:53.286510
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ('alpha', 'beta'))) == ['/tmp/alpha', '/tmp/beta']
    assert list(join_each('/tmp', iter(('alpha', 'beta')))) == ['/tmp/alpha', '/tmp/beta']
    assert list(join_each('/tmp', [])) == []
    assert list(join_each('/tmp', {})) == []



# Generated at 2022-06-12 08:03:58.084332
# Unit test for function join_each
def test_join_each():
    import tempfile
    tmp = tempfile.mkdtemp(prefix="join_each")
    try:
        test_item = ["a", "b", "c"]
        expect = [os.path.join(tmp, item) for item in test_item]
        actual = list(join_each(tmp, test_item))
        assert(expect == actual)
    finally:
        os.rmdir(tmp)



# Generated at 2022-06-12 08:03:59.903836
# Unit test for function join_each
def test_join_each():
    list(join_each('/foo', ['one', 'two', 'three'])) == [
        '/foo/one',
        '/foo/two',
        '/foo/three',
    ]