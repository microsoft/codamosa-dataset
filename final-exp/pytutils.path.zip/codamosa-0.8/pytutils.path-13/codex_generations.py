

# Generated at 2022-06-12 07:54:34.029538
# Unit test for function join_each
def test_join_each():
    p = '/home/marc'
    assert join_each(p, ['jupiter', 'saturn', 'neptun']) == [os.path.join(p, 'jupiter'), os.path.join(p, 'saturn'),
                                                             os.path.join(p, 'neptun')]



# Generated at 2022-06-12 07:54:37.337658
# Unit test for function join_each
def test_join_each():
    iter1 = join_each('/foo', ['bar', 'baz'])
    iter2 = map(lambda s: os.path.join('/foo', s), ['bar', 'baz'])
    assert iter1 == iter2



# Generated at 2022-06-12 07:54:42.178646
# Unit test for function join_each
def test_join_each():
    expected = [
        os.path.join('a', 'b'),
        os.path.join('a', 'c'),
        os.path.join('a', 'd')
    ]
    actual = list(join_each('a', ['b', 'c', 'd']))
    assert expected == actual



# Generated at 2022-06-12 07:54:46.091074
# Unit test for function join_each
def test_join_each():
    parent = '/a/b'
    iterable = ['c', 'd']
    assert list(join_each(parent, iterable)) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-12 07:54:48.815028
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/usr', ['local', 'bin']))
    assert '/usr/local' in result
    assert '/usr/bin' in result



# Generated at 2022-06-12 07:54:50.987334
# Unit test for function join_each
def test_join_each():
    parent = '/home/user/some_directory'
    filenames = ['filename1.txt', 'filename2.sh']
    actual_iterable = join_each(parent, filenames)
    expected_iterable = [
        '/home/user/some_directory/filename1.txt',
        '/home/user/some_directory/filename2.sh',
    ]
    assert list(actual_iterable) == expected_iterable



# Generated at 2022-06-12 07:54:54.113856
# Unit test for function join_each
def test_join_each():
    parent = "C:\\"
    children = ["Python27", "Python34"]
    expected = ["C:\\Python27", "C:\\Python34"]
    assert list(join_each(parent, children)) == expected



# Generated at 2022-06-12 07:54:56.078027
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr/bin", ["foo", "bar"])) == ["/usr/bin/foo", "/usr/bin/bar"]



# Generated at 2022-06-12 07:54:58.362748
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-12 07:55:00.260469
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["dev", "bin"])) == ["/dev", "/bin"]

# Generated at 2022-06-12 07:55:04.103321
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['/bar'])) == ['/foo/bar']



# Generated at 2022-06-12 07:55:10.734751
# Unit test for function join_each
def test_join_each():
    import itertools
    test_path = "/home/kyle/is/a/test/path"

    joined_paths = [
        "/home/kyle/is/a/test/path/one",
        "/home/kyle/is/a/test/path/two",
        "/home/kyle/is/a/test/path/three"
    ]

    test_iterable = ["one", "two", "three"]

    assert list(join_each(test_path, test_iterable)) == joined_paths

    test_iterable = itertools.count(0)

    assert list(join_each(test_path, test_iterable)) == []


test_join_each()



# Generated at 2022-06-12 07:55:15.389440
# Unit test for function join_each
def test_join_each():
    # Arrange
    import types
    import os

    # Act
    actual = join_each("Parent", ["Child1", "Child2"])

    # Assert
    assert type(actual) == types.GeneratorType
    assert list(actual) == [os.path.join("Parent", "Child1"), os.path.join("Parent", "Child2")]



# Generated at 2022-06-12 07:55:17.981382
# Unit test for function join_each
def test_join_each():
    parent = "/etc"
    path_divisions = ["var", "tmp"]
    expected = ["/etc/var", "/etc/tmp"]
    actual = list(join_each(parent, path_divisions))
    assert actual == expected



# Generated at 2022-06-12 07:55:24.409973
# Unit test for function join_each
def test_join_each():
    for i in range(1000):
        parent = str(randint(1, 10000))
        iterable = [str(randint(1, 10000)) for _ in range(randint(1, 100))]
        actual = list(join_each(parent, iterable))
        expected = list(map(lambda i: os.path.join(parent, i), iterable))
        try:
            assert actual == expected
        except AssertionError:
            print("Got:      ", actual)
            print("Expected: ", expected)



# Generated at 2022-06-12 07:55:27.359098
# Unit test for function join_each
def test_join_each():
    iterable = ["one", "two", "three"]
    assert list(join_each("./", iterable)) == ["./one", "./two", "./three"]

# Generated at 2022-06-12 07:55:29.117439
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['test', 'tmp'])) == ['./test', './tmp']



# Generated at 2022-06-12 07:55:31.337548
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-12 07:55:33.411540
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:55:36.706261
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", "bar baz".split())) == ['foo/bar', 'foo/baz']
    assert list(join_each("foo", ["bar", "baz"])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:55:45.136461
# Unit test for function join_each
def test_join_each():
    parent = '/foo'
    it = [['b', 'c'], ['d', 'e']]

    expected = ['/foo/b', '/foo/c', '/foo/d', '/foo/e']
    assert list(join_each(parent, it)) == expected

# Generated at 2022-06-12 07:55:46.489826
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', [''])) == ['/']

# Generated at 2022-06-12 07:55:56.378596
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/root', ['/dev', '/etc', '/lib'])) == [
        '/dev', '/etc', '/lib']
    assert list(join_each('/home', ['/juan/dev', '/michael/etc', '/michael/lib'])) == [
        '/juan/dev', '/michael/etc', '/michael/lib']
    assert list(join_each('/bin', ['/sbin/dev', '/sbin/etc', '/sbin/lib'])) == [
        '/bin/sbin/dev', '/bin/sbin/etc', '/bin/sbin/lib']


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-12 07:55:59.970821
# Unit test for function join_each
def test_join_each():
    parent = 'dummy'
    iterable = ['1', '2', '3']
    paths = list(join_each(parent, iterable))
    assert paths == ['dummy/1', 'dummy/2', 'dummy/3']

# Generated at 2022-06-12 07:56:04.249576
# Unit test for function join_each
def test_join_each():
    result = join_each('/', ['a', 'b'])
    assert isinstance(result, types.GeneratorType)
    result = list(result)
    assert len(result) == 2
    assert result[0] == '/a'
    assert result[1] == '/b'

# Generated at 2022-06-12 07:56:06.796231
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['home', 'user'])) == ['/home', '/user']



# Generated at 2022-06-12 07:56:10.255725
# Unit test for function join_each
def test_join_each():
    items = ['a', 'b', 'c', 'd']
    for i, item in enumerate(join_each('/', items)):
        assert item == os.path.join('/', items[i])



# Generated at 2022-06-12 07:56:16.522168
# Unit test for function join_each
def test_join_each():
    dir1 = "test"
    dir2 = "bogo"
    dir3 = "pizza"
    file1 = "test1.txt"
    file2 = "test2.txt"
    file3 = "test3.txt"

    # Create the files and their full paths
    test_tests = [os.path.join(dir1, file1)]
    test_bogo = [os.path.join(dir2, file1), os.path.join(dir2, file2)]
    test_pizza = [os.path.join(dir3, file1), os.path.join(dir3, file2), os.path.join(dir3, file3)]

    # Create the lists of these files
    dirs = [dir1, dir2, dir3]

# Generated at 2022-06-12 07:56:20.876157
# Unit test for function join_each
def test_join_each():
    parent = "/home/pkumar"
    iterable = ["test1", "test2"]
    expected = ["/home/pkumar/test1", "/home/pkumar/test2"]
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-12 07:56:23.127161
# Unit test for function join_each
def test_join_each():
    paths = join_each('/', ('a', 'b'))
    assert [p for p in paths] == ['/a', '/b']



# Generated at 2022-06-12 07:56:37.617563
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['bin', 'local'])) == ['/usr/bin', '/usr/local']


# Implementation for the following function requires knowledge of os module.

# Generated at 2022-06-12 07:56:41.393288
# Unit test for function join_each
def test_join_each():
    root = '/test/dir'
    files = ['a', 'b', 'c']

    pairs = join_each(root, files)
    pairs = list(pairs)

    assert len(pairs) == len(files), 'Length mismatch'
    for i, p in enumerate(pairs):
        assert p == os.path.join(root, files[i]), 'Path is incorrect'



# Generated at 2022-06-12 07:56:46.352165
# Unit test for function join_each
def test_join_each():
    result = list(join_each("a", ["b", "c"]))
    assert result == ["a/b", "a/c"]

    result = list(join_each("a", []))
    assert result == []

    result = list(join_each("/a", ["/b", "/c"]))
    assert result == ["/a/b", "/a/c"]



# Generated at 2022-06-12 07:56:50.632320
# Unit test for function join_each
def test_join_each():
    parent = '/foo/bar'
    iterable = ['baz', 'qux']

    for p in join_each(parent, iterable):
        print(p)


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-12 07:56:55.814335
# Unit test for function join_each
def test_join_each():
    # test single directory
    assert tuple(join_each('/', ('foo',))) == ('/foo',)

    # test multiple directories
    assert tuple(join_each('/', ('foo', 'bar', 'baz'))) == ('/foo',
                                                           '/foo/bar',
                                                           '/foo/bar/baz')

    # test empty iterable
    assert tuple(join_each('/', ())) == ()



# Generated at 2022-06-12 07:56:59.783226
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['bin', 'lib'])) == [
        '/usr/bin',
        '/usr/lib'
    ]


# Start with the parent directory and "yield" each subpath

# Generated at 2022-06-12 07:57:03.210922
# Unit test for function join_each
def test_join_each():
    iterable = ['./', '..']
    assert list(join_each(os.path.realpath('.'), iterable)) == [
        os.path.realpath('.'),
        os.path.realpath('..'),
    ]

# Generated at 2022-06-12 07:57:05.144095
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-12 07:57:07.976594
# Unit test for function join_each
def test_join_each():
    assert list(join_each('desktop', ['a', 'b', 'c'])) == ['desktop/a', 'desktop/b', 'desktop/c']



# Generated at 2022-06-12 07:57:11.130816
# Unit test for function join_each
def test_join_each():
    r = ['a/b/c', 'a/b/c', 'a/b/c']
    assert list(join_each('a', ['b/c', 'b/c', 'b/c'])) == r

# Generated at 2022-06-12 07:57:38.003699
# Unit test for function join_each
def test_join_each():
    assert list(join_each("some/parent", ["a", "b", "c"])) == [
        "some/parent/a",
        "some/parent/b",
        "some/parent/c",
    ]



# Generated at 2022-06-12 07:57:40.122538
# Unit test for function join_each
def test_join_each():
    expect(['tmp/foo', 'tmp/bar']).equal(
        list(join_each('tmp', ['foo', 'bar'])))

# Generated at 2022-06-12 07:57:44.593477
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each("/home/bob", ["foo", "bar", "baz"])) == \
           ("/home/bob/foo", "/home/bob/bar", "/home/bob/baz")



# Generated at 2022-06-12 07:57:51.163528
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/dev/shm', ('spam', 'and', 'eggs'))) == [
        '/dev/shm/spam',
        '/dev/shm/and',
        '/dev/shm/eggs',
    ]
    # check that nothing is joined when given an empty list,
    # (otherwise the result would always be the parent directory,
    #  which is probably not what the caller wanted)
    assert list(join_each('/dev/shm', [])) == []


# vim: ts=4:sw=4:et

# Generated at 2022-06-12 07:57:54.505630
# Unit test for function join_each
def test_join_each():
    list_a = ["one", "two"]
    list_b = ["three", "four"]
    assert list( join_each( "parent", list_a) ) == [ "parent/one", "parent/two"]



# Generated at 2022-06-12 07:57:57.668339
# Unit test for function join_each
def test_join_each():
    files = ['a', 'b', 'c']
    actual = list(join_each('/tmp', files))
    expect = ['/tmp/a', '/tmp/b', '/tmp/c']
    assert actual == expect



# Generated at 2022-06-12 07:58:02.140118
# Unit test for function join_each
def test_join_each():
    for (parent, iterable, expected) in [
        ('/', ['dirA', 'dirB', 'dirC'], ['/dirA', '/dirB', '/dirC']),
        ('/dirA', ['dirB', 'dirC'], ['/dirA/dirB', '/dirA/dirC']),
    ]:
        assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-12 07:58:06.080029
# Unit test for function join_each
def test_join_each():
    path = "a/b/c"
    dirs = ["d", "e", "f"]
    expected = [os.path.join(path, d) for d in dirs]
    actual = list(join_each(path, dirs))
    assert actual == expected

# Generated at 2022-06-12 07:58:10.278960
# Unit test for function join_each
def test_join_each():
    p = '/foo/bar'
    i = ['baz', 'qux']
    assert list(join_each(p, i)) == [os.path.join(p, 'baz'), os.path.join(p, 'qux')]

# Generated at 2022-06-12 07:58:14.889406
# Unit test for function join_each
def test_join_each():
    from pprint import pprint

    parent = '/a/b/c'
    iterable = ['d', 'e', 'f']
    results = list(join_each(parent, iterable))
    pprint(results)
    assert results == ['/a/b/c/d', '/a/b/c/e', '/a/b/c/f']



# Generated at 2022-06-12 07:59:07.904956
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]



# Generated at 2022-06-12 07:59:17.255038
# Unit test for function join_each
def test_join_each():
    parent = '/home/crazy'
    iterable = ['i', 'love', 'you', 'very', 'much']

    expected = ['/home/crazy/i', '/home/crazy/love', '/home/crazy/you',
                '/home/crazy/very', '/home/crazy/much']

    got = list(join_each(parent, iterable))

    assert expected == got
    # first argument is a generator expression
    assert expected == list(join_each(parent, (p for p in iterable)))

    # first argument is a generator
    assert expected == list(join_each(parent, (p for p in iterable)))

    # first argument is a generator function
    def gen():
        for p in iterable:
            yield p
    assert expected == list(join_each(parent, gen()))


# Test with a custom

# Generated at 2022-06-12 07:59:20.570602
# Unit test for function join_each
def test_join_each():
    parent = '/usr'
    iterable = ['/bin', 'lib', 'include']

    assert list(join_each(parent, iterable)) == ['/usr/bin', '/usr/lib', '/usr/include']

# Generated at 2022-06-12 07:59:28.300391
# Unit test for function join_each
def test_join_each():
    parent_dir = os.path.dirname(os.path.realpath(__file__))
    join_each_iterable = join_each(parent_dir,
                                   ['/temp', os.path.pardir, os.path.abspath(os.path.curdir)])
    join_each_list = []
    for p in join_each_iterable:
        join_each_list.append(p)
    assert join_each_list[0] == os.path.join(os.path.abspath(parent_dir), 'temp')
    assert join_each_list[1] == os.path.abspath(os.path.join(parent_dir, os.path.pardir))

# Generated at 2022-06-12 07:59:32.481231
# Unit test for function join_each
def test_join_each():
    path = '/test/'
    children = ['test1', 'test2', 'test3']
    expected_paths = ['/test/test1', '/test/test2', '/test/test3']
    for p in join_each(path, children):
        assert p in expected_paths

# Generated at 2022-06-12 07:59:41.380527
# Unit test for function join_each
def test_join_each():
    test_dirs = ["dir1", "dir2"]
    basepath = os.path.join(os.path.dirname(__file__), "temp")
    # Check that it yields absolute paths
    for test_dir in join_each(basepath, test_dirs):
        assert os.path.isabs(test_dir)

    # Check that it yields paths that exist
    for test_dir in join_each(basepath, test_dirs):
        assert os.path.exists(test_dir)

    # Check that nothing is included besides the paths we gave it
    assert not set(os.listdir(basepath)) - set(test_dirs)


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-12 07:59:43.936883
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['hello_file', 'world_file'])) == [
        '/tmp/hello_file',
        '/tmp/world_file'
    ]



# Generated at 2022-06-12 07:59:48.128707
# Unit test for function join_each
def test_join_each():
    parent = '/home/ubuntu'
    child = ['file1.txt', 'file2.txt', 'file3.txt']
    expected_output = ['/home/ubuntu/file1.txt', '/home/ubuntu/file2.txt', '/home/ubuntu/file3.txt']
    assert list(join_each(parent, child)) == expected_output
    assert list(join_each(parent, child)) != child


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-12 07:59:50.258902
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-12 07:59:53.560694
# Unit test for function join_each
def test_join_each():
    parent = "/home/user"
    children = ["Documents", "Pictures", "Downloads"]
    expected = ["/home/user/Documents", "/home/user/Pictures",
                "/home/user/Downloads"]
    actual = list(join_each(parent, children))
    assert expected == actual



# Generated at 2022-06-12 08:01:54.863851
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['bin', 'lib'])) == ['/usr/bin', '/usr/lib']



# Generated at 2022-06-12 08:01:59.875831
# Unit test for function join_each
def test_join_each():
    parent = '.'
    iterable = ['one', 'two', 'three']
    expected_output = [
        os.path.join(parent, p) for p in iterable
    ]
    output = join_each(parent, iterable)
    assert output == expected_output



# Generated at 2022-06-12 08:02:02.882644
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == ['/tmp/a', '/tmp/b',
                                                        '/tmp/c']


# vim:syntax=python:foldmethod=marker:foldlevel=0

# Generated at 2022-06-12 08:02:09.482849
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["a", "b", "c", "d"])) == [
        "/home/a",
        "/home/b",
        "/home/c",
        "/home/d",
    ]
    assert list(join_each("/", ["home", "home/a", "home/b", "home/c", "home/d"])) == [
        "/home",
        "/home/a",
        "/home/b",
        "/home/c",
        "/home/d",
    ]

# Generated at 2022-06-12 08:02:13.725761
# Unit test for function join_each
def test_join_each():
    parent = os.getcwd()
    iterable = ['calc_pi.py', 'tests_calc_pi.py']
    expected = [os.path.join(parent, 'calc_pi.py'),
                os.path.join(parent, 'tests_calc_pi.py')]
    actual = [e for e in join_each(parent, iterable)]
    assert actual == expected

# Generated at 2022-06-12 08:02:15.607775
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b", "c"])) == [os.path.join("/tmp", a) for a in ["a", "b", "c"]]



# Generated at 2022-06-12 08:02:18.917191
# Unit test for function join_each
def test_join_each():
    assert list(join_each("./folder1", ["file1", "file2", "file3"])) == [
        "./folder1/file1",
        "./folder1/file2",
        "./folder1/file3",
    ]



# Generated at 2022-06-12 08:02:23.045133
# Unit test for function join_each
def test_join_each():
    test_parent = 'parent'
    test_iterable = ['a', 'b', 'c']
    expected_result = [os.path.join('parent', x) for x in test_iterable]
    assert list(join_each(test_parent, test_iterable)) == expected_result

# Generated at 2022-06-12 08:02:27.447016
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# When the function was first written, it did not have an argument named parent
# This was causing a stack trace when running the unit test.

# Generated at 2022-06-12 08:02:28.701220
# Unit test for function join_each
def test_join_each():
    pass

# ------------------------------------------------------------------------------
# join_each
# ------------------------------------------------------------------------------

