

# Generated at 2022-06-12 07:54:36.342547
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp/foo", ["bar", "baz"])) == ["/tmp/foo/bar", "/tmp/foo/baz"]
    assert list(join_each("/tmp/foo/", ["bar", "baz"])) == ["/tmp/foo/bar", "/tmp/foo/baz"]
    assert list(join_each("/tmp","foo")) == ['/tmp/foo']

# Generated at 2022-06-12 07:54:38.485034
# Unit test for function join_each
def test_join_each():
    assert [*join_each('tmp', ['a.txt', 'b.txt'])] == ['tmp/a.txt', 'tmp/b.txt']

# Generated at 2022-06-12 07:54:40.739339
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/path', ['foo', 'bar'])) == [
        '/path/foo',
        '/path/bar',
    ]

# Generated at 2022-06-12 07:54:46.091074
# Unit test for function join_each
def test_join_each():
    l = ['a', 'b']
    a = os.path.join('/', 'home')
    res_list = list(join_each(a, l))
    res = ['/home/a', '/home/b']
    assert res_list == res


# Load the data and tokenize it

# Generated at 2022-06-12 07:54:51.158344
# Unit test for function join_each
def test_join_each():
    d = os.path.dirname(os.path.abspath(__file__))
    test = ["one", "two", "three"]
    assert list(join_each(d, test)) == [
        os.path.join(d, "one"),
        os.path.join(d, "two"),
        os.path.join(d, "three"),
    ]

# Generated at 2022-06-12 07:54:58.440757
# Unit test for function join_each
def test_join_each():
    # Test 1
    expected = [
        os.path.join('a', 'b'),
        os.path.join('a', 'c'),
        os.path.join('a', 'd'),
    ]
    actual = join_each('a', ('b', 'c', 'd'))
    assert list(actual) == expected

    # Test 2
    expected = [
        os.path.join('a', 'b', 'c'),
        os.path.join('a', 'b', 'd'),
        os.path.join('a', 'b', 'e'),
    ]
    actual = join_each(os.path.join('a', 'b'), ('c', 'd', 'e'))
    assert list(actual) == expected


#
# def join_paths(paths, mode=file_mode):

# Generated at 2022-06-12 07:55:00.839231
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/var', ['log', 'lib'])) == \
        ['/var/log', '/var/lib']

# Generated at 2022-06-12 07:55:06.720713
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a/b', ['c/d', 'e/f', 'g/h'])) == ['a/b/c/d', 'a/b/e/f', 'a/b/g/h']
    assert list(join_each('/a/b', ['c/d', 'e/f', 'g/h'])) == ['/a/b/c/d', '/a/b/e/f', '/a/b/g/h']



# Generated at 2022-06-12 07:55:12.059194
# Unit test for function join_each
def test_join_each():
    parent = 'test'
    iterable = ['test1', 'test2', 'test3']

    expect = ['test/test1', 'test/test2', 'test/test3']
    actual = list(join_each(parent, iterable))

    assert expect == actual



# Generated at 2022-06-12 07:55:17.148172
# Unit test for function join_each
def test_join_each():
    my_iterable = ['a', 'b', 'c']
    my_parent = '/'
    my_joined = join_each(my_parent, my_iterable)
    my_check = ['/a', '/b', '/c']
    assert next(my_joined) == my_check[0]
    assert next(my_joined) == my_check[1]
    assert next(my_joined) == my_check[2]

# Generated at 2022-06-12 07:55:26.074133
# Unit test for function join_each
def test_join_each():
    test_dir = os.path.dirname(os.path.abspath(__file__))
    parent = os.path.join(test_dir, "..")
    files = ["test_misc.py", "test_scan.py", "test_files.py"]

    expected = ["../test_misc.py", "../test_scan.py", "../test_files.py"]

    for i, j in zip(join_each(parent, files), expected):
        assert i == j

# Generated at 2022-06-12 07:55:31.293533
# Unit test for function join_each
def test_join_each():
    for parent, children, expected in [\
        ('/', ['etc', 'usr/local', 'dev/null'], ['/etc', '/usr/local', '/dev/null']),
        ('/opt', ['lib', 'bin/lib'], ['/opt/lib', '/opt/bin/lib']),
    ]:
        assert list(join_each(parent, children)) == expected

# Generated at 2022-06-12 07:55:33.978172
# Unit test for function join_each
def test_join_each():
    res = list(join_each('.', ['b', 'c', 'a']))
    expected = ['./b', './c', './a']
    assert res == expected



# Generated at 2022-06-12 07:55:37.875625
# Unit test for function join_each
def test_join_each():
    assert list(join_each("path", ["to", "file"])) == [
        "path/to", "path/file"
    ]
    assert list(join_each("/", ["more", "paths", "file"])) == [
        "/more", "/paths", "/file"
    ]



# Generated at 2022-06-12 07:55:41.604513
# Unit test for function join_each
def test_join_each():
    test_list = ['test', 'test1', 'test2']
    assert list(join_each('', test_list)) == test_list
    assert list(join_each('/', test_list)) == [
        '/test', '/test1', '/test2']



# Generated at 2022-06-12 07:55:43.832818
# Unit test for function join_each
def test_join_each():
    assert list(join_each("base", ["foo", "bar"])) == ["base/foo", "base/bar"]



# Generated at 2022-06-12 07:55:48.500605
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/a', ('b', 'c'))) == ('/a/b', '/a/c')
    assert tuple(join_each('', ('b', 'c'))) == ('/b', '/c')
    assert tuple(join_each('', ('/b', '/c'))) == ('/b', '/c')



# Generated at 2022-06-12 07:55:54.081879
# Unit test for function join_each
def test_join_each():
    # Test for absolute paths
    assert list(join_each('/', [os.pardir, os.curdir])) == ['/..', '/.']
    # Test for relative paths
    assert list(join_each(os.pardir, ['test', 'testing'])) == [
        os.path.join('..', 'test'),
        os.path.join('..', 'testing')
    ]



# Generated at 2022-06-12 07:55:57.230406
# Unit test for function join_each
def test_join_each():
    p = '/home/user'
    iterable = ['.', '..', 'foo', 'bar']
    actual = join_each(p, iterable)
    expected = ['/home/user/.', '/home/user/..', '/home/user/foo', '/home/user/bar']
    assert list(actual) == expected

# Generated at 2022-06-12 07:56:02.585322
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/', ['jonathan', 'sabrina',
                                     'willy', 'mike'])) == [
                                         '/home/jonathan',
                                         '/home/sabrina',
                                         '/home/willy',
                                         '/home/mike']

# Generated at 2022-06-12 07:56:13.405641
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/Users/', ['Documents', 'Downloads'])) == [
        '/Users/Documents',
        '/Users/Downloads',
    ]
    assert list(
        join_each('/Users/', [['Documents'], ['Downloads']])) == [
        '/Users/Documents',
        '/Users/Downloads',
    ]



# Generated at 2022-06-12 07:56:16.330173
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', ['README', 'foo.cxx'])) == ['/home/user/README', '/home/user/foo.cxx']



# Generated at 2022-06-12 07:56:19.389451
# Unit test for function join_each
def test_join_each():
    assert list(join_each('dir', ['file1', 'file2'])) == ['dir/file1',
                                                          'dir/file2']

# Generated at 2022-06-12 07:56:21.931088
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', ['hosts', 'hosts~'])) == [
        '/etc/hosts', '/etc/hosts~'
    ]



# Generated at 2022-06-12 07:56:24.805021
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/tmp', ('file1', 'file2'))) == ('/tmp/file1', '/tmp/file2')

# Requires Python 2.6 or greater

# Generated at 2022-06-12 07:56:27.349838
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/a/b/c', ['d', 'e', 'f']))
    assert result == ['/a/b/c/d', '/a/b/c/e', '/a/b/c/f']

# Generated at 2022-06-12 07:56:37.438849
# Unit test for function join_each
def test_join_each():
    def test_iterable_type(parent, iterable):
        assert list(join_each(parent, iterable)) == [os.path.join(parent, p) for p in iterable]

    non_iterable = "str"
    with pytest.raises(TypeError):
        test_iterable_type("parent", non_iterable)

    non_iterable = 1
    with pytest.raises(TypeError):
        test_iterable_type("parent", non_iterable)

    non_iterable = 1.0
    with pytest.raises(TypeError):
        test_iterable_type("parent", non_iterable)

    iterable = ()
    test_iterable_type("parent", iterable)

    iterable = []
    test_iterable_type("parent", iterable)



# Generated at 2022-06-12 07:56:39.212853
# Unit test for function join_each
def test_join_each():
    assert join_each('/a', ['b', 'c']) == ['/a/b', '/a/c']



# Generated at 2022-06-12 07:56:43.314442
# Unit test for function join_each
def test_join_each():
    expected = [
        '/a/b',
        '/a/c',
        '/a/d',
        '/a/e'
    ]
    assert list(join_each('/a', 'bcd')) == expected
    assert list(join_each('/a/b', ['c', 'd'])) == expected

# Generated at 2022-06-12 07:56:45.301656
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:57:01.128754
# Unit test for function join_each
def test_join_each():
    assert (['/home/acj/', '/home/acj/bar', '/home/acj/baz', '/home/foo']
            == list(join_each('/home/acj', ['', 'bar', 'baz', '/home/foo'])))



# Generated at 2022-06-12 07:57:05.918225
# Unit test for function join_each
def test_join_each():
    assert list(join_each(os.path.sep, ["a", "b"])) == [
        os.path.join(os.path.sep, "a"),
        os.path.join(os.path.sep, "b"),
    ]
    assert list(join_each("", ["a", "b"])) == ["a", "b"]



# Generated at 2022-06-12 07:57:08.034024
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ('a', 'b'))) == ['a', 'b']



# Generated at 2022-06-12 07:57:10.428140
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]



# Generated at 2022-06-12 07:57:12.984962
# Unit test for function join_each
def test_join_each():
    import os
    assert list(join_each('a', ['b', 'c'])) == [os.path.join('a', 'b'), os.path.join('a', 'c')]



# Generated at 2022-06-12 07:57:15.697637
# Unit test for function join_each
def test_join_each():
    assert list(join_each(
        "dir",
        ["file1", "file2"])) == [
        "dir/file1",
        "dir/file2"
        ]


# Returns an iterator for each path that exists

# Generated at 2022-06-12 07:57:18.103423
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/a/b', ['c', 'd'])) == ['/a/b/c', '/a/b/d']

# Generated at 2022-06-12 07:57:22.220584
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr", ['bin', 'lib'])) == ['/usr/bin', '/usr/lib']
    assert list(join_each(None, ['bin', 'lib'])) == ['bin', 'lib']




# Generated at 2022-06-12 07:57:25.450030
# Unit test for function join_each
def test_join_each():
    p = "."
    i = ['a', 'b']
    expected = [".", "./a", "./b"]
    actual = list(join_each(p, i))
    assert expected == actual



# Generated at 2022-06-12 07:57:29.714527
# Unit test for function join_each
def test_join_each():
    input = ['a', 'b']
    expected = [os.path.join('.', 'a'), os.path.join('.', 'b')]
    actual = join_each('.', input)
    assert all([a == e for a, e in zip(actual, expected)])



# Generated at 2022-06-12 07:57:44.736868
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/root', ['/aa', '/bb'])) == [
        '/root/aa', '/root/bb']



# Generated at 2022-06-12 07:57:47.933402
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ('local', 'bin'))) == ['/usr/local', '/usr/bin']
    assert list(join_each('/', ('var', 'tmp'))) == ['/var', '/tmp']



# Generated at 2022-06-12 07:57:49.790187
# Unit test for function join_each
def test_join_each():
    iterable = ['one', 'two']
    assert list(join_each('/', iterable)) == ['/one', '/two']

# Generated at 2022-06-12 07:57:51.664617
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["usr", "local"])) == [
        "/usr",
        "/local",
    ]

# Generated at 2022-06-12 07:57:56.193136
# Unit test for function join_each
def test_join_each():
    parent = '/home/user/a'
    iterable = ['b', 'c', 'd']
    result = list(join_each(parent, iterable))
    assert result == ['/home/user/a/b',
                      '/home/user/a/c',
                      '/home/user/a/d']



# Generated at 2022-06-12 07:57:58.203222
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:57:59.527533
# Unit test for function join_each
def test_join_each():
    values = ['bar', 'spam', 'egg']
    expected = ['foo/bar', 'foo/spam', 'foo/egg']
    actual = list(join_each('foo', values))
    assert(actual == expected)



# Generated at 2022-06-12 07:58:04.148089
# Unit test for function join_each
def test_join_each():
    assert join_each('/', '') == '/'
    assert join_each('/', '/') == '/'
    assert join_each('/', 'a') == '/a'
    assert join_each('a', 'b') == 'a/b'
    assert join_each('a', 'b/c') == 'a/b/c'
    assert join_each('a', '/b') == 'a/b'
    assert join_each('a', '/b/c') == 'a/b/c'
    assert join_each('/a', 'b') == '/a/b'
    assert join_eac

# Generated at 2022-06-12 07:58:07.980023
# Unit test for function join_each
def test_join_each():
    parent = '/etc'
    iterable = ['passwd', 'group', 'shadow']
    expected = ['/etc/passwd', '/etc/group', '/etc/shadow']
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-12 07:58:11.082365
# Unit test for function join_each
def test_join_each():

    assert(list(join_each('public', ['a', 'b', 'c'])) ==
           ['public/a', 'public/b', 'public/c'])



# Generated at 2022-06-12 07:58:38.293554
# Unit test for function join_each
def test_join_each():
    assert join_each("/user", ["test", "bin"]) == ["/user/test", "/user/bin"]



# Generated at 2022-06-12 07:58:40.466536
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == \
        ['/a', '/b', '/c']



# Generated at 2022-06-12 07:58:45.904810
# Unit test for function join_each
def test_join_each():
    parent = "/path/to/"
    iterable = ["a.txt", "b.txt", "c.txt"]
    expected = ["/path/to/a.txt", "/path/to/b.txt", "/path/to/c.txt"]
    new_iterable = join_each(parent, iterable)
    assert expected == list(new_iterable)



# Generated at 2022-06-12 07:58:50.036025
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('aa', ['bb', 'cc'])) ==
           ['aa' + os.path.sep + 'bb', 'aa' + os.path.sep + 'cc'])



# Generated at 2022-06-12 07:58:51.751069
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-12 07:58:53.003410
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) \
        == ['/a', '/b', '/c']



# Generated at 2022-06-12 07:58:59.014687
# Unit test for function join_each
def test_join_each():
    test_data = [('', ['a', 'b', 'c']),
                 ('/', ['a', 'b', 'c']),
                 ('/foo', ['a', 'b', 'c']),
                 ('/foo/bar', ['a', 'b', 'c']),
                 ('/foo/bar/baz', ['a', 'b', 'c']),
                 ]

    for parent, paths in test_data:
        expected = [os.path.join(parent, p) for p in paths]
        result = list(join_each(parent, paths))
        assert expected == result



# Generated at 2022-06-12 07:59:08.331424
# Unit test for function join_each
def test_join_each():
    # Valid input, expect a valid iterator
    assert list(join_each('/', ['a.txt', 'b.txt'])) == ['/a.txt', '/b.txt']

    # Valid input, expect a valid iterator
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']

    # Empty input, expect empty iterator
    assert list(join_each('/', [])) == []

    # Valid input, expect a valid iterator
    assert list(join_each('/', ['a.txt', 'b.txt', 'c.txt'])) == ['/a.txt', '/b.txt', '/c.txt']

    with pytest.raises(TypeError):
        join_each(1, [])



# Generated at 2022-06-12 07:59:15.653273
# Unit test for function join_each
def test_join_each():
    test_data = [
        ("ejemplos", ("3.7", "tutorial")),
        ("", ("uno", "dos")),
        ("..", ("uno", "dos")),
        ("/", ("uno", "dos")),
        ("$HOME", ("uno", "dos")),
        ("~", ("uno", "dos")),
        ("tmp", ("file.tar.gz", "subdir")),
    ]

    for parent, children in test_data:
        print(parent)
        for path in join_each(parent, children):
            print(path)
        print()


test_join_each()

# Generated at 2022-06-12 07:59:19.225207
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/opt", ["a", "b", "c"])) == ["/opt/a", "/opt/b", "/opt/c"]
    assert list(join_each(None, [])) == []



# Generated at 2022-06-12 08:00:14.197005
# Unit test for function join_each
def test_join_each():
    parent = "some/path"
    iterable = ["a", "b", "c"]
    expected = ["some/path/a", "some/path/b", "some/path/c"]
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-12 08:00:18.044125
# Unit test for function join_each
def test_join_each():
    print("Testing join_each")
    assert tuple(join_each('a', 'b')) == ("a/b",)
    assert tuple(join_each('a', ['b', 'c'])) == ("a/b", "a/c")



# Generated at 2022-06-12 08:00:19.917551
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/foo", ["bar", "baz"])) == [
        "/foo/bar",
        "/foo/baz",
    ]



# Generated at 2022-06-12 08:00:21.658788
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ("usr", "bin"))) == ["/home/usr", "/home/bin"]

# Generated at 2022-06-12 08:00:25.835175
# Unit test for function join_each
def test_join_each():
    assert list(join_each(None, [".py"])) == [".py"]
    assert list(join_each(None, [".py", ".java"])) \
        == [".py", ".java"]
    assert list(join_each(None, None)) == []
    assert list(join_each("", None)) == []



# Generated at 2022-06-12 08:00:27.507694
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]



# Generated at 2022-06-12 08:00:32.993440
# Unit test for function join_each
def test_join_each():
    # ---- Positive Tests ----
    # Test 1: Joining a single file
    assert list(join_each("/home", ["file"])) == ["/home/file"]

    # Test 2: Joining two files
    assert list(join_each("/home", ["file1", "file2"])) == [
        "/home/file1",
        "/home/file2",
    ]

    # Test 3: Joining two files, with first element empty
    assert list(join_each("/home", ["", "file2"])) == ["/home", "/home/file2"]

    # Test 4: Joining two files, with second element empty
    assert list(join_each("/home", ["file1", ""])) == ["/home/file1", "/home"]

    # Test 5: Joining two files, with both elements empty
   

# Generated at 2022-06-12 08:00:39.974595
# Unit test for function join_each
def test_join_each():
    # input = [(1, 2, 3), (4, 5, 6), (7, 8, 9)]
    input = [('1', '2', '3'), ('4', '5', '6'), ('7', '8', '9')]
    result = list(join_each(os.path.join('myfolder', 'myfile'), input))

    print(result)

    assert result == [
        os.path.join('myfolder', 'myfile', '1', '2', '3'),
        os.path.join('myfolder', 'myfile', '4', '5', '6'),
        os.path.join('myfolder', 'myfile', '7', '8', '9')
    ]



# Generated at 2022-06-12 08:00:45.338913
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('parent', ('a', 'b'))) == ('parent/a', 'parent/b')
    assert tuple(join_each('/parent', ('a', 'b'))) == ('/parent/a', '/parent/b')
    assert tuple(join_each('./parent', ('a', 'b'))) == ('./parent/a', './parent/b')



# Generated at 2022-06-12 08:00:48.422713
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ['file1', 'file2', 'file3']
    expected = ['parent/file1', 'parent/file2', 'parent/file3']
    res = list(join_each(parent, iterable))
    assert res == expected



# Generated at 2022-06-12 08:02:57.176214
# Unit test for function join_each
def test_join_each():
    p0 = '/a/b/c'
    iter0 = ['d', 'e', 'f']
    for p, q in zip(join_each(p0, iter0), ['/a/b/c/d', '/a/b/c/e', '/a/b/c/f']):
        assert p == q



# Generated at 2022-06-12 08:02:58.958526
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-12 08:03:01.963108
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == ['/tmp/a', '/tmp/b', '/tmp/c']
    assert list(join_each('/tmp', [])) == []



# Generated at 2022-06-12 08:03:04.044763
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ('user', 'bin', 'python'))) == ['/home/user', '/home/bin', '/home/python']

# Generated at 2022-06-12 08:03:11.260270
# Unit test for function join_each
def test_join_each():
    test_case1 = list(join_each("/home", ["user1", "user2", "user3"]))
    assert test_case1 == ["/home/user1", "/home/user2", "/home/user3"]

    test_case2 = list(join_each("/home", [["user1", "user2"], ["user3", "user4"]]))
    assert test_case2 == ["/home/user1/user2", "/home/user3/user4"]



# Generated at 2022-06-12 08:03:13.907108
# Unit test for function join_each
def test_join_each():
    assert list(join_each('', ['a', 'b'])) == ['a', 'b']
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-12 08:03:17.182316
# Unit test for function join_each
def test_join_each():
    import nose.tools
    import unittest

    class MyTest(unittest.TestCase):
        def test1(self):
            self.assertEqual(list(join_each("a", ["b", "c"])),
                             ["a/b", "a/c"])
    nose.runmodule()



# Generated at 2022-06-12 08:03:20.478289
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/share', ['examples', 'skel', 'skel.d'])) == [
        '/usr/share/examples',
        '/usr/share/skel',
        '/usr/share/skel.d'
    ]



# Generated at 2022-06-12 08:03:22.053560
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == [
            '/tmp/a', '/tmp/b', '/tmp/c'
        ]

# Generated at 2022-06-12 08:03:25.060869
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b', 'c'])) == ['parent/a', 'parent/b', 'parent/c']
    assert list(join_each('/usr/local', ["bin", "games"])) == ['/usr/local/bin', '/usr/local/games']

