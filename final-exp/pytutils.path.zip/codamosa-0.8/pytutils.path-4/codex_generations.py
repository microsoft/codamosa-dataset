

# Generated at 2022-06-12 07:54:29.698480
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['A', 'B', 'C'])) == ['parent/A', 'parent/B', 'parent/C']



# Generated at 2022-06-12 07:54:32.783235
# Unit test for function join_each
def test_join_each():
    assert ["./path/file.ext", "./path/other/file.ext"] == list(join_each("./path", ["file.ext", "other/file.ext"]))



# Generated at 2022-06-12 07:54:36.616646
# Unit test for function join_each
def test_join_each():
    assert list(join_each(".", ["python"])) == ["./python"]
    assert list(join_each(".", ["python", "foobar"])) == [
        "./python",
        "./foobar",
    ]



# Generated at 2022-06-12 07:54:42.757093
# Unit test for function join_each
def test_join_each():
    parent = '/usr/local'
    iterable = ['bin', 'share']
    joined = join_each(parent, iterable)
    assert '/usr/local/bin' == list(joined)[0]
    assert '/usr/local/share' == list(joined)[1]


# Assumes os.path.join (i.e. 'foo/bar' + 'baz') equals 'foo/bar/baz'
# and os.path.join (i.e. 'foo/bar' + '') equals 'foo/bar'
#
# Note: this is usually true but may not be true in all operating systems.

# Generated at 2022-06-12 07:54:46.331120
# Unit test for function join_each
def test_join_each():
    parent = '/'
    iterable = ('var', 'lib')
    answer = ('/var', '/lib')
    assert tuple(join_each(parent, iterable)) == answer

# Generated at 2022-06-12 07:54:49.352848
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['one', 'two', 'three'])) == [
        'parent\\one',
        'parent\\two',
        'parent\\three'
    ]



# Generated at 2022-06-12 07:54:54.802450
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', ['a', 'b/c'])) == ['/a', '/b/c']
    assert list(join_each('/', ['a', 'b/c', 'd/e'])) == ['/a', '/b/c', '/d/e']



# Generated at 2022-06-12 07:54:58.411866
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a', '')) == []

# Generated at 2022-06-12 07:55:01.904105
# Unit test for function join_each
def test_join_each():
    iter = join_each("/the/parent", ["child1", "child2"])
    assert iter.next() == "/the/parent/child1"
    assert iter.next() == "/the/parent/child2"



# Generated at 2022-06-12 07:55:04.517612
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp/test", ["hello", "world"])) == ["/tmp/test/hello", "/tmp/test/world"]

# Generated at 2022-06-12 07:55:11.597109
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('C:\\', ['a', 'b', 'c'])) == (
        'C:\\a', 'C:\\b', 'C:\\c')


# ----------------------------------------------------------------------

# Generated at 2022-06-12 07:55:15.120607
# Unit test for function join_each
def test_join_each():
    parent = '/home/user'
    iterable = ['a', 'b', 'c']
    expect = ['/home/user/a', '/home/user/b', '/home/user/c']
    assert list(join_each(parent, iterable)) == expect



# Generated at 2022-06-12 07:55:21.031015
# Unit test for function join_each
def test_join_each():
    # Case one: parent has slash at the end, iterable is a list
    parent = os.path.join(os.path.dirname(__file__), os.path.pardir)
    parent = os.path.join(parent, 'test_case')
    iterable = ["testA", "test_B", "testC"]
    joined_each = join_each(parent, iterable)
    answer = ["/home/zc/PycharmProjects/team_project/test_case/testA", "/home/zc/PycharmProjects/team_project/test_case/test_B", "/home/zc/PycharmProjects/team_project/test_case/testC"]
    for i, item in enumerate(joined_each):
        print(item)
        assert item == answer[i]

# Generated at 2022-06-12 07:55:24.076254
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b", "c"])) == [
        "/tmp/a",
        "/tmp/b",
        "/tmp/c",
    ]



# Generated at 2022-06-12 07:55:27.002067
# Unit test for function join_each
def test_join_each():
    assert list(join_each('woot', ["a", "b", "c"])) == \
           ['woot/a', 'woot/b', 'woot/c']



# Generated at 2022-06-12 07:55:30.507858
# Unit test for function join_each
def test_join_each():
    assert(list(join_each("/", ["a", "b", "c"])) == ["/a", "/b", "/c"])


# Return a list of all files in the current directory and its subdirectories
# that match the given pattern.

# Generated at 2022-06-12 07:55:33.198842
# Unit test for function join_each
def test_join_each():
    iterable = ["a", "b", "c"]
    parent = "/home/user"

    result = [os.path.join(parent, p) for p in iterable]
    assert list(join_each(parent, iterable)) == result



# Generated at 2022-06-12 07:55:37.215965
# Unit test for function join_each
def test_join_each():
    parent = 'foo'
    child = ['bar', 'baz']

    result = join_each(parent, child)

    expected_result = ['foo/bar', 'foo/baz']
    expected_result = iter(expected_result)

    for r, e in zip(result, expected_result):
        assert r == e



# Generated at 2022-06-12 07:55:41.053075
# Unit test for function join_each
def test_join_each():
    for p in join_each("", ["a", "b"]):
        print(p)

    for p in join_each("./", ["a", "b"]):
        print(p)


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-12 07:55:45.187156
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/foo/bar', 'ijk')) == ('/foo/bar/i', '/foo/bar/j', '/foo/bar/k')


# Convert an iterator of paths to an iterator of pairs (parent path, child path)
# where child paths are relative to parent paths

# Generated at 2022-06-12 07:55:53.805431
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    iterable = ['user', 'Documents', 'selfies']
    expected = ['/home/user', '/home/Documents', '/home/selfies']
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-12 07:55:55.624634
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', [1, 2, 3])) == ['a/1', 'a/2', 'a/3']



# Generated at 2022-06-12 07:56:01.906900
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['bar', 'baz'])) == ['/foo/bar', '/foo/baz']
    assert list(join_each('/foo/', ['bar', 'baz'])) == ['/foo/bar', '/foo/baz']
    assert list(join_each('/foo', [])) == []



# Generated at 2022-06-12 07:56:04.068891
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]
    assert list(join_each("a", [])) == []



# Generated at 2022-06-12 07:56:14.639205
# Unit test for function join_each

# Generated at 2022-06-12 07:56:18.677033
# Unit test for function join_each
def test_join_each():
    parent = "root"
    iterable = ["file1", "file2"]
    expected = ["root/file1", "root/file2"]
    actual = list(join_each(parent, iterable))
    assert actual == expected

# Generated at 2022-06-12 07:56:21.255363
# Unit test for function join_each
def test_join_each():
    assert list(join_each(os.getcwd(), ['.', '..'])) \
        == [os.getcwd(), os.path.dirname(os.getcwd())]

# Generated at 2022-06-12 07:56:23.532217
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-12 07:56:26.017504
# Unit test for function join_each
def test_join_each():
    """
    >>> list(join_each('/tmp', ['usr', 'var', 'lib']))
    ['/tmp/usr', '/tmp/var', '/tmp/lib']
    """



# Generated at 2022-06-12 07:56:31.906656
# Unit test for function join_each
def test_join_each():
    expected = [
        '/root/dir1/dir2/dir3/dir4',
        '/root/dir1/dir2/dir3/dir5',
        '/root/dir1/dir2/dir3/dir6',
        '/root/dir1/dir4/dir4',
        '/root/dir1/dir4/dir5',
        '/root/dir1/dir4/dir6',
        '/root/dir2/dir4/dir4',
        '/root/dir2/dir4/dir5',
        '/root/dir2/dir4/dir6',
    ]

# Generated at 2022-06-12 07:56:39.598481
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']



# Generated at 2022-06-12 07:56:42.276962
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b'])) == [
        'parent/a',
        'parent/b'
    ]



# Generated at 2022-06-12 07:56:44.430694
# Unit test for function join_each
def test_join_each():
    assert list(join_each("dir", ["a", "b"])) == ["dir/a", "dir/b"]



# Generated at 2022-06-12 07:56:48.480985
# Unit test for function join_each
def test_join_each():
    test_iterable = ['a', 'b', 'c']
    test_parent = 'foo'
    assert list(join_each(test_parent, test_iterable)) == ['foo/a', 'foo/b', 'foo/c']



# Generated at 2022-06-12 07:56:54.278940
# Unit test for function join_each
def test_join_each():

    # Root is empty string
    assert list(join_each("", ["1", "2"])) == ["1", "2"]

    # Root is '/'
    assert list(join_each("/", ["1", "2"])) == ["/1", "/2"]

    # Root is 'path'
    assert list(join_each("path", ["1", "2"])) == ["path/1", "path/2"]

# Generated at 2022-06-12 07:56:57.656353
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']


# Transpose a list of lists.

# Generated at 2022-06-12 07:57:00.991689
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['bin', 'sbin'])) == [
        '/usr/bin',
        '/usr/sbin'
    ]



# Generated at 2022-06-12 07:57:03.010260
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['usr', 'lib'])) == [
        '/usr',
        '/lib'
    ]

# Generated at 2022-06-12 07:57:07.922486
# Unit test for function join_each
def test_join_each():
    assert list(join_each('', [])) == []
    assert list(join_each('', ['', ''])) == ['', '']
    assert list(join_each('test', ['one', 'two', 'three'])) == [
        'test/one', 'test/two', 'test/three'
    ]



# Generated at 2022-06-12 07:57:11.088253
# Unit test for function join_each
def test_join_each():
    iterable = ["a", "b", "c"]
    expected = ["/", "/a", "/b", "/c"]
    result = join_each("/", iterable)
    assert result == expected

# Generated at 2022-06-12 07:57:24.805857
# Unit test for function join_each
def test_join_each():
    pass
    assert "".join(join_each("src", ["main.py", "test.py"])) == "src/main.py src/test.py"



# Generated at 2022-06-12 07:57:27.389842
# Unit test for function join_each
def test_join_each():
    assert set(join_each('/foo', ['bar', 'baz'])) == \
        set(['/foo/bar', '/foo/baz'])

# Generated at 2022-06-12 07:57:30.168207
# Unit test for function join_each
def test_join_each():
    seq = ['foo', 'bar']
    res = join_each("foo", seq)
    assert res is not None
    first, second = res
    assert first == 'foo/foo'
    assert second == 'foo/bar'

# Generated at 2022-06-12 07:57:32.791242
# Unit test for function join_each
def test_join_each():
    assert ['a/b', 'a/d'] == list(join_each('a', ['b', 'd']))



# Generated at 2022-06-12 07:57:37.744780
# Unit test for function join_each
def test_join_each():
    current = os.getcwd()
    some_path = ('.', '..', 'tmp', '..')
    expected = ('.', '..', os.path.join(current, 'tmp'), '..')
    actual = list(join_each(current, some_path))
    assert expected == actual



# Generated at 2022-06-12 07:57:44.329057
# Unit test for function join_each
def test_join_each():
    assert list(join_each("c://", ("a", "b", "c"))) == ["c://a", "c://b",
                                                         "c://c"]
    assert list(join_each("c://", ("a/b", "b/c", "c/d"))) == ["c://a/b",
                                                              "c://b/c",
                                                              "c://c/d"]
    assert list(join_each("c://", ("a/b/c", "b/c/d", "c/d/e"))) == ["c://a/b/c",
                                                                    "c://b/c/d",
                                                                    "c://c/d/e"]
# Solution to https://ingsw2.pythonanywhere.com/extract_from_text
# found in

# Generated at 2022-06-12 07:57:50.664460
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', [])) == []
    assert list(join_each('/', ['etc'])) == ['/etc']
    # assert list(join_each('/', ['etc', 'init.d'])) == ['/etc/init.d']
    assert list(join_each('/', ['etc/init.d'])) == ['/etc/init.d']
    # assert list(join_each('/', ['etc/init.d', 'sshd'])) == ['/etc/init.d/sshd']

# Generated at 2022-06-12 07:57:53.586085
# Unit test for function join_each
def test_join_each():
    iterable = ["foo", "bar", "baz"]
    expected = ["foo/foo", "foo/bar", "foo/baz"]
    actual = list(join_each("foo", iterable))
    assert actual == expected



# Generated at 2022-06-12 07:57:56.425937
# Unit test for function join_each
def test_join_each():
    t = ('home', 'cov', 'file.txt')
    assert list(join_each('/', t)) == ['/home', '/cov', '/file.txt']

# Generated at 2022-06-12 07:57:59.786675
# Unit test for function join_each
def test_join_each():
    parent = '/a/b/c'
    input = ['d', 'e', 'f']
    assert ['/a/b/c/d', '/a/b/c/e', '/a/b/c/f'] == list(join_each(parent, input))

# Generated at 2022-06-12 07:58:24.426196
# Unit test for function join_each
def test_join_each():
    assert join_each('a', ['b', 'c']) == ['ab', 'ac']
    assert join_each('', ['foo', 'bar']) == ['foo', 'bar']

# Generated at 2022-06-12 07:58:31.404936
# Unit test for function join_each
def test_join_each():
    cases = [
        ('/usr/bin', ('python', 'racket', 'racket')),
        ('../usr/bin', ('python', 'racket', 'racket')),
        ('/usr/bin', ('/python', 'racket', 'racket')),
        ('', ('python', 'racket', 'racket')),
        ('', ()),
    ]

    for parent, children in cases:
        assert list(join_each(parent, children)) == [
            os.path.join(parent, p) for p in children
        ]



# Generated at 2022-06-12 07:58:34.799008
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["foo", "bar", "baz"])) == [
        "/foo",
        "/bar",
        "/baz",
    ]



# Generated at 2022-06-12 07:58:37.160341
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ('b', 'c', 'd'))) == ['a/b', 'a/c', 'a/d']

# Generated at 2022-06-12 07:58:40.078271
# Unit test for function join_each
def test_join_each():
    p = join_each('/home/me', ['-', '.', '..'])
    assert p == ['/home/me/-', '/home/me/.', '/home/me/..']

# Generated at 2022-06-12 07:58:45.554830
# Unit test for function join_each
def test_join_each():
    expected = [
    '/tmp/foo/bar',
    '/tmp/bar/bar',
    '/tmp/baz/bar',
    '/tmp/qux/bar'
    ]

    assert list(join_each('/tmp', ['foo', 'bar', 'baz', 'qux'])) == expected



# Generated at 2022-06-12 07:58:48.671241
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo/bar', 'baz boom'.split())) == ['/foo/bar/baz', '/foo/bar/boom']



# Generated at 2022-06-12 07:58:53.907333
# Unit test for function join_each
def test_join_each():
    """
    Asserts that the function join_each is correct.
    """
    other_string_list = ['.', '..', 'name.data']

# Generated at 2022-06-12 07:58:55.724927
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]

# Generated at 2022-06-12 07:58:57.221513
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c'])

# Generated at 2022-06-12 07:59:51.615813
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["child1", "child2", "child3"]
    # a = [os.path.join(parent, p) for p in iterable]
    a = join_each(parent, iterable)
    print(list(a))



# Generated at 2022-06-12 07:59:55.656797
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']
    assert list(join_each('foo/', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:59:57.423300
# Unit test for function join_each
def test_join_each():
    print(list(join_each('/var/log', ['messages', 'bootstrap.log'])))



# Generated at 2022-06-12 08:00:00.499637
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == [
        '/tmp/a', '/tmp/b', '/tmp/c'
    ]



# Generated at 2022-06-12 08:00:01.884245
# Unit test for function join_each

# Generated at 2022-06-12 08:00:04.860769
# Unit test for function join_each
def test_join_each():
    assert list(join_each('base', ['a', 'b'])) == ['base\\a', 'base\\b']



# Generated at 2022-06-12 08:00:08.492531
# Unit test for function join_each
def test_join_each():
    parent = '/usr'
    iterable = ('local', 'bin', 'python')
    expected = ('/usr/local', '/usr/bin', '/usr/python')
    actual = join_each(parent, iterable)
    assert actual == expected

# Generated at 2022-06-12 08:00:14.849080
# Unit test for function join_each
def test_join_each():
    # init
    test_parent = "test_parent"
    test_iterable = ["test1", "test2", "test3"]
    ex_result = ["test_parent/test1", "test_parent/test2", "test_parent/test3"]
    # run function
    result = list(join_each(test_parent, test_iterable))
    # assert
    assert result == ex_result

# Generated at 2022-06-12 08:00:22.270528
# Unit test for function join_each
def test_join_each():
    parent = os.path.expanduser('~/work')
    iterable = ['foo', 'bar', 'baz']
    result = join_each(parent, iterable)
    expected = [os.path.join(parent, 'foo'),
                os.path.join(parent, 'bar'),
                os.path.join(parent, 'baz')]
    assert list(result) == expected, "join_each result = {}, expected = {}".format(result, expected)

# Generated at 2022-06-12 08:00:24.766318
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b', 'c'])) == ['parent/a', 'parent/b', 'parent/c']



# Generated at 2022-06-12 08:02:28.166120
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/path/to",
              ["file1", "file2", "file3"])) == \
        ['/path/to/file1', '/path/to/file2', '/path/to/file3']

    # empty list
    assert list(join_each("/path/to", [])) == []



# Generated at 2022-06-12 08:02:31.164429
# Unit test for function join_each
def test_join_each():
    p = '/test'
    d = [1, 2, 3]
    actual = list(join_each(p, d))
    expected = ['/test/1', '/test/2', '/test/3']
    assert actual == expected



# Generated at 2022-06-12 08:02:33.941173
# Unit test for function join_each
def test_join_each():
    input_pair = ('/home', ('vaclav', 'Documents', 'repos'))
    assert tuple(join_each(*input_pair)) \
        == ('/home/vaclav', '/home/Documents', '/home/repos')



# Generated at 2022-06-12 08:02:38.977050
# Unit test for function join_each
def test_join_each():
    for parent, iterable, result in [
        ("", ["a", "b", "c"], ["a", "b", "c"]),
        ("", "abcd", "abcd"),
    ]:
        assert list(join_each(parent, iterable)) == result



# Generated at 2022-06-12 08:02:42.569147
# Unit test for function join_each
def test_join_each():
    parent = "/home/mona"
    iterable = ["Documents", "Downloads"]
    assert list(join_each(parent, iterable)) == [
        "/home/mona/Documents",
        "/home/mona/Downloads",
    ]

# Generated at 2022-06-12 08:02:46.254746
# Unit test for function join_each
def test_join_each():
    parent = '/home/tom/Desktop'
    iterable = ['file1.txt', 'file2.txt']
    expected = [os.path.join(parent, 'file1.txt'),
                os.path.join(parent, 'file2.txt')]
    result = list(join_each(parent, iterable))
    assert expected == result



# Generated at 2022-06-12 08:02:48.075952
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('foo', ('bar', 'baz'))) == ['foo/bar', 'foo/baz'])

# Generated at 2022-06-12 08:02:50.579300
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b/c', ['x', 'y', 'z'])) == [
        '/a/b/c/x', '/a/b/c/y', '/a/b/c/z'
    ]



# Generated at 2022-06-12 08:02:54.900910
# Unit test for function join_each
def test_join_each():
    test_parent = 'parent_dir'
    test_files = ['1.txt', '2.txt', '3.txt']
    test_joined = [os.path.join(test_parent, f) for f in test_files]
    test_result = [b for b in join_each(test_parent, test_files)]
    assert test_joined == test_result

# Generated at 2022-06-12 08:02:57.218806
# Unit test for function join_each
def test_join_each():
    assert list(join_each('path', ['a', 'b', 'c'])) == ['path/a','path/b','path/c']
    assert list(join_each('path', [])) == []

