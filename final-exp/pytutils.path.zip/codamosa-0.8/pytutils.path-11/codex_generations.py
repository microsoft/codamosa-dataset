

# Generated at 2022-06-12 07:54:27.085593
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar'])) == ['/foo', '/bar']

# Generated at 2022-06-12 07:54:31.613120
# Unit test for function join_each
def test_join_each():
    parent = '/foo/bar'
    iterable = ['baz', 'biz']
    result = list(join_each(parent, iterable))
    assert result[0] == '/foo/bar/baz'
    assert result[1] == '/foo/bar/biz'

# Generated at 2022-06-12 07:54:35.343280
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('/root', ['a', 'b']))
           == ['/root/a', '/root/b'])
    assert(list(join_each('/root', [])) == [])



# Generated at 2022-06-12 07:54:43.384588
# Unit test for function join_each
def test_join_each():
    from itertools import count
    from random import choice, randint

    random_strings = [''.join(choice('abcde') for _ in range(randint(1, 10))) for _ in count()]
    random_paths = ['/'.join(map(str, (randint(1, 100), random_strings[i], random_strings[i + 1]))) for i in count()]
    sep = os.path.sep

    for i in range(100):
        parent = random_paths[randint(1, 100)]
        children = [random_strings[i] for i in range(1, len(random_strings), 2)]
        joined = list(map(lambda p: parent + sep + p, children))
        assert(list(join_each(parent, children)) == joined)

# Generated at 2022-06-12 07:54:45.181025
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar'])) == ['/foo', '/bar']

# Generated at 2022-06-12 07:54:48.124114
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz', 'quux'])) == [
        'foo/bar', 'foo/baz', 'foo/quux']



# Generated at 2022-06-12 07:54:52.911449
# Unit test for function join_each
def test_join_each():
    parent = '.'
    children = ['a', 'b', 'c']
    expected = ['.' + os.sep + 'a', '.' + os.sep + 'b', '.' + os.sep + 'c']
    result = list(join_each(parent, children))
    for e, r in zip(expected, result):
        assert e == r



# Generated at 2022-06-12 07:54:55.706849
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/path/to', ['a', 'b/c', 'd'])) == [
        '/path/to/a',
        '/path/to/b/c',
        '/path/to/d'
    ]

# Generated at 2022-06-12 07:54:58.990502
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['a', 'b'])) == [os.path.join('.', 'a'), os.path.join('.', 'b')]



# Generated at 2022-06-12 07:55:02.138163
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/koduki', [
        'bin',
        'lib',
    ])) == ['/home/koduki/bin', '/home/koduki/lib']

# Generated at 2022-06-12 07:55:07.314989
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c', 'd'])) == ['a/b', 'a/c', 'a/d']


# Given path to folder, return a list of all of the absolute subfolder paths

# Generated at 2022-06-12 07:55:12.522626
# Unit test for function join_each
def test_join_each():
    assert [
        *join_each('a', ['b', 'c', 'd'])
    ] == [os.path.join('a', 'b'), os.path.join('a', 'c'), os.path.join('a', 'd')]

# Generated at 2022-06-12 07:55:16.660684
# Unit test for function join_each
def test_join_each():
    parent = 'path/to'
    iterable = ['a', 'b', 'c']
    assert list(join_each(parent, iterable)) == [
        os.path.join(parent, 'a'),
        os.path.join(parent, 'b'),
        os.path.join(parent, 'c')
    ]

# Generated at 2022-06-12 07:55:20.405869
# Unit test for function join_each
def test_join_each():
    pass
    # assert list(join_each('a', ['x', 'y'])) == ['a/x', 'a/y']
    # assert list(join_each('a', [])) == []


# A function that takes a filename, reads it and returns a list of strings.
# Every line will be a string.

# Generated at 2022-06-12 07:55:23.039543
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['will', 'bob/bob'])) == ['/home/will', '/home/bob/bob']



# Generated at 2022-06-12 07:55:30.408387
# Unit test for function join_each
def test_join_each():
    for i in range(10):
        iterable = ['a', 'b', 'c', 'd']
        parent = 'p/' + str(i)
        expected = [
            'p/' + str(i) + '/a',
            'p/' + str(i) + '/b',
            'p/' + str(i) + '/c',
            'p/' + str(i) + '/d',
        ]
        actual = list(join_each(parent, iterable))
        assert expected == actual



# Generated at 2022-06-12 07:55:33.597329
# Unit test for function join_each
def test_join_each():
    expected = ['/home/ubuntu/a/b', '/home/ubuntu/a/c', '/home/ubuntu/a/d']
    parent = '/home/ubuntu/a'
    iterable = ['b', 'c', 'd']
    assert expected == list(join_each(parent, iterable))

# Generated at 2022-06-12 07:55:35.925555
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['/bin', '/sbin'])) == [
        '/usr/bin',
        '/usr/sbin',
    ]

# Generated at 2022-06-12 07:55:38.061634
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child1', 'child2'])) == ['parent/child1', 'parent/child2']

# Generated at 2022-06-12 07:55:40.651800
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/opt', ['a', 'b', 'c'])) == (
        '/opt/a', '/opt/b', '/opt/c')



# Generated at 2022-06-12 07:55:47.235760
# Unit test for function join_each
def test_join_each():
    parent = '/Users/a'
    iterable = ['b', 'c', 'd']
    expected = [
        '/Users/a/b',
        '/Users/a/c',
        '/Users/a/d'
    ]
    actual = list(join_each(parent, iterable))
    assert actual == expected



# Generated at 2022-06-12 07:55:56.577677
# Unit test for function join_each
def test_join_each():
    # Test with a simple iterable
    assert list(join_each('first', ('2', '3'))) == [
        os.path.join('first', '2'),
        os.path.join('first', '3')
    ]

    # Test with an iterable that is a generator
    # Note that we expect the iterable to be consumed
    assert list(join_each('one', (str(i) for i in range(2)))) == [
        os.path.join('one', '0'),
        os.path.join('one', '1')
    ]

    # Test with a changed separator
    assert list(join_each('first', ('2', '3'), sep='/')) == [
        'first/2',
        'first/3'
    ]

# Generated at 2022-06-12 07:55:59.336501
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ('a', 'b', 'c'))) == [
        '/a',
        '/b',
        '/c',
    ]



# Generated at 2022-06-12 07:56:02.892211
# Unit test for function join_each
def test_join_each():
    assert [p for p in join_each("/home", ["test", "a", "b"])] == ["/home/test", "/home/a", "/home/b"]



# Generated at 2022-06-12 07:56:05.359994
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/path', ['a', 'b'])) == ['/path/a', '/path/b']



# Generated at 2022-06-12 07:56:10.305054
# Unit test for function join_each
def test_join_each():
    from pathlib import Path
    x = Path('../')
    res = join_each(x, os.listdir(x))
    print(next(res))
    print(next(res))


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-12 07:56:13.194562
# Unit test for function join_each
def test_join_each():
    assert list(join_each('c:\\foo', ('bar', 'baz'))) == \
        ['c:\\foo\\bar', 'c:\\foo\\baz']



# Generated at 2022-06-12 07:56:13.763212
# Unit test for function join_each
def test_join_each():
    asser

# Generated at 2022-06-12 07:56:22.956693
# Unit test for function join_each
def test_join_each():
    import itertools
    import re
    patterns = [
        os.path.join('list_directory', '..', 'list_directory'),
        os.path.join('list_directory', '..', 'list_directory', '..', 'list_directory'),
        os.path.join('list_directory', '..', 'list_directory', '..', 'list_directory', '..', 'list_directory'),
    ]
    assert all(isinstance(p, str) and re.match('^list_directory$', p) for p in itertools.islice(join_each(
        'list_directory', itertools.repeat('..')), len(patterns)))



# Generated at 2022-06-12 07:56:25.828753
# Unit test for function join_each
def test_join_each():
    assert list(join_each('%s/level0' % os.getcwd(), ['level1', 'level1.1'])) == ['%s/level0' % os.getcwd(), '/level1', '/level1.1']



# Generated at 2022-06-12 07:56:36.162446
# Unit test for function join_each
def test_join_each():
    test_dir = "dir"
    test_dir2 = "dir2"
    test_file = "file"
    test_dict = join_each(test_dir, [f for f in [test_dir2, test_file]])
    for path in test_dict:
        assert os.path.join(test_dir, test_file) == path
        assert os.path.join(test_dir, test_dir2) == path



# Generated at 2022-06-12 07:56:41.760917
# Unit test for function join_each
def test_join_each():
    assert ['a', 'b', 'c'] == list(join_each('.', ['a', 'b', 'c']))
    assert ['.', 'a', 'b', 'c'] == list(join_each('.', ['.', 'a', 'b', 'c']))
    assert ['.\\a', '.\\b', '.\\c'] == list(join_each('.', ['\\a', '\\b', '\\c']))
    assert ['./a', './b', './c'] == list(join_each('.', ['/a', '/b', '/c']))

# Generated at 2022-06-12 07:56:43.598294
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['tmp', 'lock'])) == ['/tmp', '/lock']

# Generated at 2022-06-12 07:56:46.772969
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ['c', 'd', 'e'])) == [
        '/a/b/c', '/a/b/d', '/a/b/e']



# Generated at 2022-06-12 07:56:49.702099
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', [])) == []
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-12 07:56:54.519117
# Unit test for function join_each
def test_join_each():
    assert ['/foo/bar', '/foo/baz'] == list(join_each('/foo', ['bar', 'baz']))
    assert [] == list(join_each('/foo', []))
    assert ['/foo', '/foo/bar'] == list(join_each('/foo', [None, 'bar']))



# Generated at 2022-06-12 07:56:58.791111
# Unit test for function join_each
def test_join_each():
    assert list(join_each('src/lgd/', ['test', '__init__.py'])) == [
        'src/lgd/test',
        'src/lgd/__init__.py'
    ]

# Generated at 2022-06-12 07:57:05.512807
# Unit test for function join_each
def test_join_each():
    assert list(join_each(None, [])) == []
    assert list(join_each('', [])) == []
    assert list(join_each(None, ['a'])) == ['a']
    assert list(join_each('', ['a'])) == ['a']
    assert list(join_each('.', ['a'])) == ['a']
    assert list(join_each('/', ['a'])) == ['a']
    assert list(join_each('a', ['b'])) == ['a/b']

# Generated at 2022-06-12 07:57:11.303977
# Unit test for function join_each
def test_join_each():
    parent = "/home/svn"
    iterable = ["trunk", "branches", "tags"]
    expected = ["/home/svn/trunk", "/home/svn/branches", "/home/svn/tags"]
    actual = list(join_each(parent, iterable))
    assert actual == expected


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-12 07:57:18.426444
# Unit test for function join_each
def test_join_each():
    assert join_each("./", ["./"]) == "./"
    assert join_each("./", ["../"]) == "../"
    assert join_each("./", ["../", "one"]) == "../one"
    assert join_each("./", ["../", "one", "../"]) == "../one/../"
    assert join_each("./", ["../", "one", "../", "ob"]) == "../one/../ob"
    assert join_each("./", ["../", "one", "../", "ob", "./"]) == "../one/../ob/."
    assert join_each("./", ["./", ".."]) == "./.."

# Generated at 2022-06-12 07:57:30.360749
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ('a', 'b', 'c'))) == [
        'a', 'b', 'c'
    ]
    assert list(join_each('/', ('a', 'b', 'c'))) == [
        '/a', '/b', '/c'
    ]



# Generated at 2022-06-12 07:57:37.020337
# Unit test for function join_each
def test_join_each():
    parent = os.path.dirname(__file__)
    expect = [
        ('tests', '../tests'),
        ('conftest.py', '../conftest.py'),
        ('test_util.py', '../test_util.py')
    ]
    assert list(
        zip(expect, join_each(parent, map(lambda x: x[0], expect)))) == expect



# Generated at 2022-06-12 07:57:41.464440
# Unit test for function join_each
def test_join_each():
    assert list(join_each('abc', ['def', 'ghi'])) == ['abc/def', 'abc/ghi']
    assert list(join_each('/abc', ['def', 'ghi'])) == ['/abc/def', '/abc/ghi']
    assert list(join_each('abc/', ['def', 'ghi'])) == ['abc/def', 'abc/ghi']



# Generated at 2022-06-12 07:57:43.402626
# Unit test for function join_each
def test_join_each():
    assert ["/bin/usr", "/bin/local"] == list(join_each("/bin", ["usr", "local"]))

# Generated at 2022-06-12 07:57:46.646109
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['user', 'bin'])) == [
        '/home/user', '/home/bin']


# Return union of all paths in `parents`

# Generated at 2022-06-12 07:57:48.413854
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['bin', 'src'])) == ['/usr/bin', '/usr/src']



# Generated at 2022-06-12 07:57:50.704475
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr/doc", ["mohan", "jerry"])) == ["/usr/doc/mohan", "/usr/doc/jerry"]



# Generated at 2022-06-12 07:57:53.311142
# Unit test for function join_each
def test_join_each():
    assert list(join_each("abc", ["1", "2"])) == [
        os.path.join("abc", "1"), os.path.join("abc", "2")
    ]



# Generated at 2022-06-12 07:57:58.966959
# Unit test for function join_each
def test_join_each():
    assert list(join_each(
        os.path.dirname(__file__),
        ["t", "t2", "t3"]
    )) == [
        os.path.join(os.path.dirname(__file__), "t"),
        os.path.join(os.path.dirname(__file__), "t2"),
        os.path.join(os.path.dirname(__file__), "t3")
    ]

# Generated at 2022-06-12 07:58:03.308122
# Unit test for function join_each
def test_join_each():
    parent = "/home/kzk"
    names = ["aa", "bb", "cc"]
    expected = [
        "/home/kzk/aa",
        "/home/kzk/bb",
        "/home/kzk/cc"
    ]
    actual = list(join_each(parent, names))

    assert expected == actual


# Generated at 2022-06-12 07:58:23.820685
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/user", ["bin", "lib", "src"])) == [
        "/home/user/bin",
        "/home/user/lib",
        "/home/user/src",
    ]



# Generated at 2022-06-12 07:58:25.427946
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['data', 'tmp'])) == ['/data', '/tmp']



# Generated at 2022-06-12 07:58:28.583303
# Unit test for function join_each
def test_join_each():
    input_list = ['a', 'b', 'c']
    expected_list = ['dir/a', 'dir/b', 'dir/c']
    assert list(join_each('dir', input_list)) == expected_list



# Generated at 2022-06-12 07:58:31.172702
# Unit test for function join_each
def test_join_each():
    assert set(join_each('/usr/share', ['a', 'b'])) == {'/usr/share/a', '/usr/share/b'}



# Generated at 2022-06-12 07:58:36.723548
# Unit test for function join_each
def test_join_each():
    base = os.path.dirname(os.path.realpath(__file__))
    assert list(join_each(base, ["test_fileutils.py", "test_fileutils.pyc"])) == [os.path.realpath("test_fileutils.py"), os.path.realpath("test_fileutils.pyc")]



# Generated at 2022-06-12 07:58:41.470196
# Unit test for function join_each
def test_join_each():
    parent = 'a/'
    # iterable = ['b', 'c']
    # l = [os.path.join(parent, p) for p in iterable]
    l = [os.path.join(parent, p) for p in ['b', 'c']]
    print(l)
    assert l == ['a/b', 'a/c']



# Generated at 2022-06-12 07:58:43.353205
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["bin", "usr"])) == [
        "/bin",
        "/usr",
    ]



# Generated at 2022-06-12 07:58:46.932788
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c', 'd'])) == ['a/b', 'a/c', 'a/d']



# Generated at 2022-06-12 07:58:55.567038
# Unit test for function join_each
def test_join_each():
    assert list(join_each(os.path.expanduser('~'), 'abc')) == [
        os.path.join(os.path.expanduser('~'), 'a'),
        os.path.join(os.path.expanduser('~'), 'b'),
        os.path.join(os.path.expanduser('~'), 'c'),
    ]
    assert list(join_each('/', ['/a', 'b', '/c'])) == [
        '/a', '/b', '/c',
    ]
    assert list(join_each('/a', ['/b', 'c', '/d'])) == [
        '/b', '/a/c', '/d'
    ]



# Generated at 2022-06-12 07:58:58.179107
# Unit test for function join_each
def test_join_each():
    parent = '/'
    iterable = ('some', 'paths', 'to', 'join')
    expected = ('/some', '/paths', '/to', '/join')
    assert tuple(join_each(parent, iterable)) == expected



# Generated at 2022-06-12 07:59:41.218862
# Unit test for function join_each
def test_join_each():
    iterable = iter(['a', 'b', 'c'])
    res = [x for x in join_each('tmp', iterable)]
    assert len(res) == 3
    assert res == [os.path.join('tmp', 'a'), os.path.join('tmp', 'b'), os.path.join('tmp', 'c')]



# Generated at 2022-06-12 07:59:43.451435
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/local', ['bin', 'lib'])) == ['/usr/local/bin', '/usr/local/lib']



# Generated at 2022-06-12 07:59:46.550422
# Unit test for function join_each
def test_join_each():
    parent = "C:"
    iterable = ["a", "b", "c", "d", "e", "f"]
    for i, p in enumerate(join_each(parent, iterable)):
        assert p == os.path.join(parent, iterable[i])



# Generated at 2022-06-12 07:59:49.847124
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/bin', ['ls', 'cp', 'mv'])) == ['/usr/bin/ls', '/usr/bin/cp', '/usr/bin/mv']

# Generated at 2022-06-12 07:59:55.077639
# Unit test for function join_each
def test_join_each():
    xs = ['a', 'b', 'c']
    ys = join_each('d', xs)
    assert next(ys) == 'd/a'
    assert next(ys) == 'd/b'
    assert next(ys) == 'd/c'
    try:
        next(ys)
        assert False
    except StopIteration:
        pass


res = join_each('/', ['home', 'mike', 'src'])
print([x for x in res])
res = join_each('/', '123')
print([x for x in res])

test_join_each()

# Generated at 2022-06-12 07:59:58.381459
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['a', 'b', 'c']
    assert list(join_each(parent, iterable)) == [
        'parent/a',
        'parent/b',
        'parent/c',
    ]

# Generated at 2022-06-12 08:00:08.135814
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ('bin', 'etc'))) == ['/bin', '/etc']
    assert list(join_each(('/', 'tmp'), ('bin', 'etc'))) == ['', '/tmp']
    assert list(join_each(('/', '/tmp'), ('bin', 'etc'))) == ['/bin', '/etc', '/tmp/bin', '/tmp/etc']
    assert list(join_each('/usr/local', ('bin', 'share'))) == ['/usr/local/bin', '/usr/local/share']
    assert list(join_each('/usr/local', ())) == []



# Generated at 2022-06-12 08:00:10.392785
# Unit test for function join_each
def test_join_each():
    assert join_each('/', ['etc', 'usr']) == ['/etc', '/usr']



# Generated at 2022-06-12 08:00:14.246769
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/bin', ['python', 'sh', 'firefox'])) == [
        '/usr/bin/python', '/usr/bin/sh', '/usr/bin/firefox'
    ]



# Generated at 2022-06-12 08:00:19.885333
# Unit test for function join_each
def test_join_each():
    mylist = ["a.txt", "b.txt", "c.txt"]
    parent = "/home/me"
    expected = [os.path.join(parent, filename) for filename in mylist]
    assert list(join_each(parent, mylist)) == expected


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-12 08:01:56.025561
# Unit test for function join_each
def test_join_each():
    iterable = ['child1', 'child2', 'child3', 'child4']
    parent = 'parent'

    expected = ['parent/child1', 'parent/child2', 'parent/child3', 'parent/child4']
    actual = list(join_each(parent, iterable))

    assert actual == expected

# Generated at 2022-06-12 08:01:59.346499
# Unit test for function join_each
def test_join_each():
    p = '/tmp'
    it = ['foo', 'bar']
    assert list(join_each(p, it)) == [
        '/tmp/foo',
        '/tmp/bar',
    ]



# Generated at 2022-06-12 08:02:01.122022
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', 'abc')) == ['/a', '/b', '/c']



# Generated at 2022-06-12 08:02:07.088173
# Unit test for function join_each
def test_join_each():
    expect = ['/disc1/dir1/dir2/dir3',
              '/disc1/dir1/dir2/dir4',
              '/disc1/dir1/dir2/dir5',
              '/disc1/dir1/dir2/dir6']
    result = join_each('/disc1/dir1/dir2', ['dir3', 'dir4', 'dir5', 'dir6'])
    assert list(result) == expect



# Generated at 2022-06-12 08:02:09.217224
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["foo", "bar"])) == [
        "/tmp/foo",
        "/tmp/bar",
    ]



# Generated at 2022-06-12 08:02:12.832075
# Unit test for function join_each
def test_join_each():
    parent = "/"
    iterable = ["tmp", "home", "usr"]

    actual = list(join_each(parent, iterable))
    expected = ["/tmp", "/home", "/usr"]
    assert actual == expected, "Expected {}, got {}".format(expected, actual)
    # /tmp, /home, /usr

# Generated at 2022-06-12 08:02:16.601255
# Unit test for function join_each
def test_join_each():
    filepath_list = ['/a/b/c', '/a/b/d']
    file_list = ['1', '2']
    expected_result = ['/a/b/c/1', '/a/b/c/2', '/a/b/d/1', '/a/b/d/2']
    result = list(join_each(filepath_list, file_list))
    assert sorted(result) == sorted(expected_result)



# Generated at 2022-06-12 08:02:19.831000
# Unit test for function join_each
def test_join_each():
    parent = "foo"
    iterable = ["bar", "baz", "quux"]
    result = list(join_each(parent, iterable))
    assert result == ["foo/bar", "foo/baz", "foo/quux"]



# Generated at 2022-06-12 08:02:22.551219
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['share', 'files', 'photos'])) == \
        ['/home/share', '/home/files', '/home/photos']



# Generated at 2022-06-12 08:02:26.168227
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c', 'd'])) == ['a/b', 'a/c', 'a/d']


# Parse lines from a file for specific key and value