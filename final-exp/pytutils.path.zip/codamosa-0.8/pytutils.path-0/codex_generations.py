

# Generated at 2022-06-12 07:54:32.038180
# Unit test for function join_each
def test_join_each():
    assert list(join_each("parent_dir", ["foo", "bar"])) == \
        ['parent_dir/foo', 'parent_dir/bar']



# Generated at 2022-06-12 07:54:41.562470
# Unit test for function join_each
def test_join_each():
    base = "."
    paths = ["/usr/bin", "lib/", "lib64"]
    expected = ["/usr/bin", "lib/", "lib64"]
    result = join_each(base, paths)
    assert list(result) == expected


# File manager
folder = "."
files = os.listdir(folder)

# Ignore files in folder .git
files[:] = [f for f in files if not f.startswith(".git")]

# Ignore files in folder .idea
files[:] = [f for f in files if not f.startswith(".idea")]

# Ignore files in folder .data
files[:] = [f for f in files if not f.startswith(".data")]

# Ignore files in folder __pycache__

# Generated at 2022-06-12 07:54:46.665938
# Unit test for function join_each
def test_join_each():
    p = os.path.normpath('/a/b/c')
    i = ['x', 'y', 'z']
    expected = ['/a/b/c/x', '/a/b/c/y', '/a/b/c/z']
    assert list(join_each(p, i)) == expected

# Generated at 2022-06-12 07:54:49.307312
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home/me", ["a", "b"])) == [
        "/home/me/a",
        "/home/me/b"
    ]



# Generated at 2022-06-12 07:54:51.249153
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('/', ['a', 'b'])) == ['/a', '/b'])

# Generated at 2022-06-12 07:54:54.379787
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b"])) == ["/tmp/a", "/tmp/b"]
    assert list(join_each("/tmp", ["a"])) == ["/tmp/a"]



# Generated at 2022-06-12 07:54:59.035725
# Unit test for function join_each
def test_join_each():
    assert list(join_each(os.path.sep, ["a", "b", "c"])) == [os.path.join(
        os.path.sep, p) for p in ["a", "b", "c"]]



# Generated at 2022-06-12 07:55:06.037927
# Unit test for function join_each
def test_join_each():
    files_to_check = ['windows.h', 'setupapi.h', 'wincrypt.h', 'main.cpp']
    headers_path = join('..', '..', '..', '..', 'include', 'windows')
    assert list(join_each(headers_path, files_to_check)) == [
        join(headers_path, 'windows.h'),
        join(headers_path, 'setupapi.h'),
        join(headers_path, 'wincrypt.h'),
        join(headers_path, 'main.cpp'),
    ]

# Generated at 2022-06-12 07:55:07.879717
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child1', 'child2'])) == ['parent/child1', 'parent/child2']



# Generated at 2022-06-12 07:55:17.726882
# Unit test for function join_each
def test_join_each():
    a = 'a'
    b = 'b'
    c = 'c'
    d = 'd'
    e = 'e'
    f = 'f'
    g = 'g'
    h = 'h'
    i = 'i'
    j = 'j'
    k = 'k'
    l = 'l'

    args = [a, b, c, d, e, f, g, h, i, j, k, l]

    for idx, arg in enumerate(args):
        for path in join_each(arg, args[idx+1:]):
            assert os.path.isabs(path) is True, 'join_each failed to yield absolute paths'



# Generated at 2022-06-12 07:55:23.934740
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["a", "b", "c"]
    it = join_each(parent, iterable)
    assert np.all([os.path.join(parent, i) == next(it) for i in iterable])



# Generated at 2022-06-12 07:55:33.003220
# Unit test for function join_each
def test_join_each():
    original = [os.path.join('foo', 'bar'),
                os.path.join('foo', 'baz')]
    new_items = [os.path.join('foo', 'bar'),
                 os.path.join('foo', 'baz')]

    assert list(join_each('foo', ('bar', 'baz'))) == original
    assert list(join_each('foo', ['bar', 'baz'])) == original
    assert list(join_each('foo', new_items)) == original


# Dummy filesystem structure
tree = {'foo': {'bar': {'a.txt': 'a',
                         'b.txt': 'b'},
                'baz': {'c.txt': 'c'}}}



# Generated at 2022-06-12 07:55:35.926087
# Unit test for function join_each
def test_join_each():
    assert list(join_each('path', ('one', 'two', 'three'))) == \
           ['path/one', 'path/two', 'path/three']


# Generator that finds all files with a given extension below a given directory.

# Generated at 2022-06-12 07:55:40.007365
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('/user', ['vokal', 'co'])) == [
        '/user/vokal',
        '/user/co'
    ]



# Generated at 2022-06-12 07:55:42.232430
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-12 07:55:47.181166
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']
    assert list(join_each('a', [])) == []
    assert list(join_each('/a', [])) == []



# Generated at 2022-06-12 07:55:51.855413
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]
    assert list(join_each("foo", [""])) == ["foo"]
    assert list(join_each("", ["bar", "baz"])) == ["bar", "baz"]



# Generated at 2022-06-12 07:55:53.670353
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == list('/a', '/b')

# Generated at 2022-06-12 07:55:58.556989
# Unit test for function join_each
def test_join_each():
    assert [p for p in join_each("dir", ["file1", "file2", "file3"])
            ] == [os.path.join("dir", p) for p in ["file1", "file2", "file3"]
                   ]
    assert [p for p in join_each("dir", ["file1", "file2", "file3"], "file4"
                                 )] == [os.path.join("dir", p) for p in
                                        ["file1", "file2", "file3", "file4"]
                                        ]


# Helper function to recursively list files in a directory

# Generated at 2022-06-12 07:56:05.736022
# Unit test for function join_each
def test_join_each():
    parent = 'C:\\pythontest'
    paths = ['./dir1', 'dir2', 'dir3/dir4', 'dir5']
    joined = list(join_each(parent, paths))
    assert(joined[0] == 'C:\\pythontest\\dir1')
    assert(joined[1] == 'C:\\pythontest\\dir2')
    assert(joined[2] == 'C:\\pythontest\\dir3/dir4')
    assert(joined[3] == 'C:\\pythontest\\dir5')

# Generated at 2022-06-12 07:56:15.583636
# Unit test for function join_each
def test_join_each():
    """Unit test for function join_each."""
    assert list(join_each("base", [])) == []
    assert list(join_each("base", [("dir1", "dir2")])) == ['base/dir1', 'base/dir2']
    assert list(join_each("base", [("dir1", "dir2"), ("dir3", "dir4")])) == \
        ['base/dir1', 'base/dir2', 'base/dir3', 'base/dir4']

# Generated at 2022-06-12 07:56:22.873132
# Unit test for function join_each
def test_join_each():
    from pprint import pprint
    from nose.tools import assert_list_equal
    assert_list_equal(
        list(join_each('p', ['a', 'b', 'c'])),
        [os.path.join('p', 'a'),
         os.path.join('p', 'b'),
         os.path.join('p', 'c')],
    )
    # pprint(list(join_each('p', ['a', 'b', 'c'])))



# Generated at 2022-06-12 07:56:24.810020
# Unit test for function join_each
def test_join_each():
    assert list(join_each('test', ['a', 'b'])) == ['test/a', 'test/b']



# Generated at 2022-06-12 07:56:28.349487
# Unit test for function join_each
def test_join_each():
    input = ['a', 'b', 'c']
    expected_output = [
        os.path.join('parent', 'a'),
        os.path.join('parent', 'b'),
        os.path.join('parent', 'c'),
    ]
    assert list(join_each('parent', input)) == expected_output


# Unit tests for enumeration of file paths in a directory

# Generated at 2022-06-12 07:56:29.666294
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b'])) == ['parent/a', 'parent/b']



# Generated at 2022-06-12 07:56:38.350732
# Unit test for function join_each
def test_join_each():
    """ Unit test for function join_each.
    """
    assert list(join_each('/foo', ['bar', 'baz'])) == ['/foo/bar', '/foo/baz']
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']
    assert list(join_each('foo/', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']
    assert list(join_each('foo', [])) == []
    assert list(join_each('', ['bar', 'baz'])) == ['bar', 'baz']
    assert list(join_each('', [])) == []

# Generated at 2022-06-12 07:56:42.180228
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['/foo/bar', 'baz'])) == ['/foo/bar', '/baz']


# Builds a list of all the paths for files to be included in the
# corpus.  This list is expected to be the lines of a file-list file

# Generated at 2022-06-12 07:56:44.697987
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ('c', 'd'))) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-12 07:56:48.772770
# Unit test for function join_each
def test_join_each():
    parent = "/foo/bar"
    assert list(join_each(parent, ('a', 'b', 'c'))) == [
        '/foo/bar/a', '/foo/bar/b', '/foo/bar/c']



# Generated at 2022-06-12 07:56:53.835055
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', 'iterable')) == ['parent/iterable']
    assert list(join_each('parent', ['iterable'])) == ['parent/iterable']
    assert list(join_each('parent', ['iterable', 'some'])) == ['parent/iterable', 'parent/some']

# Generated at 2022-06-12 07:57:08.712296
# Unit test for function join_each
def test_join_each():
    parent = '/usr/foo'
    iterable = ('bin', 'local/bin')
    paths = join_each(parent, iterable)
    expected = ['/usr/foo/bin', '/usr/foo/local/bin']
    assert list(paths) == expected



# Generated at 2022-06-12 07:57:10.622764
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-12 07:57:13.853959
# Unit test for function join_each
def test_join_each():
    # Returned value is iterable
    assert isinstance(join_each('a', ['b', 'c']), types.GeneratorType)
    # Check that it joins properly
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-12 07:57:22.140739
# Unit test for function join_each
def test_join_each():
    assert os.path.join('ab', 'cd') == next(join_each('ab', ['cd']))
    assert os.path.join('ab', 'cd') == next(join_each('ab', ('cd',)))
    assert os.path.join('ab', 'cd') == next(join_each('ab', 'cd'))
    assert os.path.join('ab', 'cd') == next(join_each('ab', iter('cd')))
    assert os.path.join('ab', 'cd') == next(join_each('ab', map(str, ['cd'])))
    assert os.path.join('ab', 'cd') == next(join_each('ab', map(str, ('cd',))))

    iterator = join_each('ab', ['cd', 'e', 'f'])


# Generated at 2022-06-12 07:57:26.285934
# Unit test for function join_each
def test_join_each():
    parent = 'foo/bar'
    iterable = ['baz', 'blah']
    expected = ['foo/bar/baz', 'foo/bar/blah']
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-12 07:57:28.476630
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b'])) == ['parent/a', 'parent/b']



# Generated at 2022-06-12 07:57:32.243056
# Unit test for function join_each
def test_join_each():
    parent = "/home/atrask/devel/test"
    iterable = ["test", "foo", "bar"]
    expected = ["/home/atrask/devel/test/test", "/home/atrask/devel/test/foo",
                "/home/atrask/devel/test/bar"]
    for expected_prefix, prefix in zip(expected, join_each(parent, iterable)):
        assert expected_prefix == prefix

# Generated at 2022-06-12 07:57:35.693448
# Unit test for function join_each
def test_join_each():
    parent = '/tmp/parent'
    paths = ['file01', 'file02']
    expected = ['/tmp/parent/file01', '/tmp/parent/file02']
    assert list(join_each(parent, paths)) == expected



# Generated at 2022-06-12 07:57:38.815717
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ['b', 'c', 'd'])) == ['/a/b', '/a/c', '/a/d']



# Generated at 2022-06-12 07:57:44.608655
# Unit test for function join_each
def test_join_each():
    assert list(join_each("x", "ab")) == ["x/a", "x/b"]
    assert list(join_each("x", ["a", "b"])) == ["x/a", "x/b"]
    assert list(join_each("x", [])) == []
    assert list(join_each("x", "")) == []



# Generated at 2022-06-12 07:58:11.083047
# Unit test for function join_each
def test_join_each():
    assert ['a/b', 'a/c', 'a/d'] == list(join_each('a', ['b', 'c', 'd']))

# Generated at 2022-06-12 07:58:14.086797
# Unit test for function join_each
def test_join_each():
    p = '/tmp'
    i = ['a', 'b', 'c']

    print(list(join_each(p, i)))


# Unit test entry point
if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-12 07:58:19.333065
# Unit test for function join_each
def test_join_each():
    assert list(join_each(b"/path", [b"1", b"2", b"3"])) == [
        b"/path/1",
        b"/path/2",
        b"/path/3",
    ]
    assert list(join_each(b"/path", [])) == []
    assert list(join_each(b"/path", [b"1"])) == [b"/path/1"]



# Generated at 2022-06-12 07:58:23.027868
# Unit test for function join_each
def test_join_each():
    data = "12345"

    # Test that the generator was created
    gen = join_each(data, data)
    assert gen is not None

    # Test that it is an iterable
    assert isinstance(gen, Iterable)

    # Test that it returns what we expect
    assert "1/1" in gen



# Generated at 2022-06-12 07:58:24.825431
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/bin/', ['ls', 'ls.exe'])) == ['/bin/ls', '/bin/ls.exe']



# Generated at 2022-06-12 07:58:27.444368
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["1", "2"]
    expected = ["parent/1", "parent/2"]
    result = list(join_each(parent, iterable))
    assert expected == result

# Generated at 2022-06-12 07:58:30.364596
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["user", "root", "bin"])) == [
        "/home/user",
        "/home/root",
        "/home/bin",
    ]



# Generated at 2022-06-12 07:58:36.816627
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', [])) == []
    assert list(join_each('foo', ['bar'])) == ['foo/bar']
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']


# It's not clear what a good test for this is. Maybe use the
# reverse mapping of test_join_each.

# Generated at 2022-06-12 07:58:40.607821
# Unit test for function join_each
def test_join_each():
    actual_result = list(join_each('parent', ['a', 'b', 'c']))
    expected_result = ['parent/' + p for p in ['a', 'b', 'c']]
    assert (actual_result == expected_result)

# Generated at 2022-06-12 07:58:44.270814
# Unit test for function join_each
def test_join_each():
    parent_dir_name = 'parent'
    child_dir_name = 'child'
    assert os.path.join(parent_dir_name, child_dir_name) == next(join_each(parent_dir_name, [child_dir_name]))
    assert os.path.join('/a/b/c', 'd') == next(join_each('/a/b/c', ['d']))



# Generated at 2022-06-12 07:59:12.511097
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', 'b c d'.split())) == ['a/b', 'a/c', 'a/d']


# Generator for a series of subdirectories

# Generated at 2022-06-12 07:59:17.083393
# Unit test for function join_each
def test_join_each():
    parent = "/home/khill"
    kids = ["pics", "videos", "docs"]
    actual = list(join_each(parent, kids))
    expected = [
        os.path.join(parent, "pics"),
        os.path.join(parent, "videos"),
        os.path.join(parent, "docs"),
    ]
    assert actual == expected



# Generated at 2022-06-12 07:59:20.772893
# Unit test for function join_each
def test_join_each():
    assert list(join_each("C:", ["\\", "Temp"])) == ["C:\\", "C:\\Temp"]
    assert list(join_each("C:\\", ["Temp", "Temp2"])) == ["C:\\Temp", "C:\\Temp2"]



# Generated at 2022-06-12 07:59:21.622394
# Unit test for function join_each
def test_join_each():
    assert join_each("/path", ["dir1", "dir2"]) == \
           ["/path/dir1", "/path/dir2"]



# Generated at 2022-06-12 07:59:23.133375
# Unit test for function join_each
def test_join_each():
    assert "a" in join_each("/tmp", ["a", "b"])



# Generated at 2022-06-12 07:59:25.533070
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/Users/tom', ['foo.py', 'bar.py'])) == ['/Users/tom/foo.py', '/Users/tom/bar.py']



# Generated at 2022-06-12 07:59:27.477640
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/', ['a', 'b', 'c']))
    assert result == ['/a', '/b', '/c']

# Generated at 2022-06-12 07:59:29.539135
# Unit test for function join_each
def test_join_each():
    assert list(join_each("dir", ["subdir1", "subdir2"])) == ["dir/subdir1", "dir/subdir2"]



# Generated at 2022-06-12 07:59:33.866838
# Unit test for function join_each
def test_join_each():
    '''
    >>> list(join_each('/home/edwin/code', ['python',
    ...                                                 'cpp']))
    ['/home/edwin/code/python', '/home/edwin/code/cpp']
    '''
    pass



# Generated at 2022-06-12 07:59:37.545336
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', 'alice', 'bob')) == ['/home/alice', '/home/bob']
    assert list(join_each('home', ['alice', 'bob'])) == ['home/alice', 'home/bob']



# Generated at 2022-06-12 08:00:09.909705
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/etc", ["ssh", "passwd"])) == [
        "/etc/ssh",
        "/etc/passwd",
    ]
    assert list(join_each("/root", ["/bin"])) == ["/root/bin"]
    assert list(join_each("/root/", ["/bin"])) == ["/root/bin"]
    assert list(join_each("/root/", ["bin"])) == ["/root/bin"]

# Generated at 2022-06-12 08:00:13.711856
# Unit test for function join_each
def test_join_each():
    assert list(join_each("./staging", ["a", "b"])) == ["./staging/a", "./staging/b"]
    assert list(join_each("./staging", [])) == []



# Generated at 2022-06-12 08:00:16.407730
# Unit test for function join_each
def test_join_each():
    assert list(join_each("test", ["a", "b"])) == ["test\\a", "test\\b"]



# Generated at 2022-06-12 08:00:20.996008
# Unit test for function join_each
def test_join_each():
    root = os.path.dirname(__file__)
    assert list(join_each(root, ("foo", "bar"))) == [
        os.path.join(root, "foo"),
        os.path.join(root, "bar"),
    ]

# Generated at 2022-06-12 08:00:25.246851
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/Parent', [])) == []
    assert list(join_each('/Parent', ["One", "Two"])) == [
        "/Parent/One",
        "/Parent/Two",
    ]


# Function to recursively walk from a root directory and yield all files
# in the tree under that root that end in .py

# Generated at 2022-06-12 08:00:29.269862
# Unit test for function join_each
def test_join_each():
    from itertools import islice
    from aiofwa.utils import join_each
    parent = '/home/user/some/path'
    pathjoin = os.path.join
    paths = ['../test1', 'test2', 'test3']
    result = map(pathjoin, [parent] * 3, paths)
    assert list(result) == list(islice(join_each(parent, paths), 3))



# Generated at 2022-06-12 08:00:31.439417
# Unit test for function join_each
def test_join_each():
    assert list(join_each(iterable=['a', 'b', 'c'], parent='foo')) == \
        ['foo/a', 'foo/b', 'foo/c']



# Generated at 2022-06-12 08:00:35.637947
# Unit test for function join_each
def test_join_each():
    parent_path = os.path.join(os.getcwd(), "test")
    lst_paths = ["a", "b", "c"]
    result = list(join_each(parent_path, lst_paths))
    assert result[0] == os.path.join(parent_path, "a")



# Generated at 2022-06-12 08:00:38.085517
# Unit test for function join_each
def test_join_each():
    p = '/opt'
    children = ['bin', 'lib', 'sbin']
    assert tuple(join_each(p, children)) == (
        '/opt/bin', '/opt/lib', '/opt/sbin')



# Generated at 2022-06-12 08:00:39.624726
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 08:01:46.164177
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['bar', 'baz'])) == [
        '/foo/bar', '/foo/baz']

# Generated at 2022-06-12 08:01:51.878388
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]
    assert list(join_each("/foo", ["bar", "baz"])) == ["/foo/bar", "/foo/baz"]
    assert list(join_each("foo", ["/bar", "baz"])) == ["foo//bar", "foo/baz"]



# Generated at 2022-06-12 08:01:55.001257
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ('foo', 'bar'))) == [
        '/home/foo',
        '/home/bar'
    ]



# Generated at 2022-06-12 08:01:58.713215
# Unit test for function join_each
def test_join_each():
    parent = "./"
    iterable = ["posts", "assets"]
    assert list(join_each(parent, iterable)) == [
        "./posts",
        "./assets",
    ]



# Generated at 2022-06-12 08:02:03.490609
# Unit test for function join_each
def test_join_each():
    # Arrange
    parent = 'C:\\Users\\tester\\Downloads'
    # Act
    result = list(join_each(parent, ['foo.txt', 'bar.txt']))
    # Assert
    assert result == [
        'C:\\Users\\tester\\Downloads\\foo.txt',
        'C:\\Users\\tester\\Downloads\\bar.txt',
    ]



# Generated at 2022-06-12 08:02:05.143152
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-12 08:02:08.124718
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', ['filename', 'dirname'])) == ['/home/user/filename', '/home/user/dirname']



# Generated at 2022-06-12 08:02:12.388698
# Unit test for function join_each
def test_join_each():
    test_path = '/tmp'
    test_list = ['test_file_1', 'test_file_2', 'test_file_3']
    expected = ['/tmp/test_file_1',
                '/tmp/test_file_2',
                '/tmp/test_file_3']
    output = [p for p in join_each(test_path, test_list)]

    assert output == expected



# Generated at 2022-06-12 08:02:14.084054
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/', ['user', 'proj'])) == ['/home/user', '/home/proj']



# Generated at 2022-06-12 08:02:15.655691
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['usr', 'local', 'bin'])) == [
        '/usr', '/local', '/bin']

