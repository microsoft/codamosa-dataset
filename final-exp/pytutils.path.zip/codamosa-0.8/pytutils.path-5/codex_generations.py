

# Generated at 2022-06-12 07:54:35.970578
# Unit test for function join_each
def test_join_each():
    parent = '/home/matthias/dev'
    child = list(join_each(parent, ['projects']))
    assert child == ['/home/matthias/dev/projects']
    child = list(join_each(parent, ['projects', 'spring']))
    assert child == ['/home/matthias/dev/projects', '/home/matthias/dev/spring']

# Generated at 2022-06-12 07:54:39.429318
# Unit test for function join_each
def test_join_each():
    parent = 'parent/'
    iterable = ('child1', 'child2', 'child3')

    expected = ('parent/child1', 'parent/child2', 'parent/child3')

    assert expected == tuple(join_each(parent, iterable))



# Generated at 2022-06-12 07:54:44.413661
# Unit test for function join_each
def test_join_each():
    d = '/home/vlad'
    paths = ['etc', 'bin']
    expected_output = ['/home/vlad/etc', '/home/vlad/bin']
    assert list(join_each(d, paths)) == expected_output



# Generated at 2022-06-12 07:54:46.430875
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-12 07:54:48.777412
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b"])) == ["/tmp/a", "/tmp/b"]



# Generated at 2022-06-12 07:54:53.934082
# Unit test for function join_each
def test_join_each():
    projects = ["home", "work", "tmp"]
    expected = [
        os.path.join("/home", "user", "projects", p)
        for p in ["home", "work", "tmp"]
    ]
    parent = os.path.join("/home", "user", "projects")
    result = list(join_each(parent, projects))
    assert result == expected



# Generated at 2022-06-12 07:54:56.909293
# Unit test for function join_each
def test_join_each():
    iterable = ('a', 'b', 'c')
    parent = '/tmp'
    expected = ['/tmp/a', '/tmp/b', '/tmp/c']
    assert list(join_each(parent, iterable)) == expected


# Test if the function join_each can be a generator in a list comprehension

# Generated at 2022-06-12 07:55:00.978396
# Unit test for function join_each
def test_join_each():
    cwd = os.getcwd()
    expected = [os.path.join(cwd, "file1"), os.path.join(cwd, "file2")]
    assert expected == list(join_each(cwd, ["file1", "file2"]))

# Generated at 2022-06-12 07:55:05.907776
# Unit test for function join_each
def test_join_each():
    paths = [
        "a",
        "b",
        "c/d/e",
        "f/g/h",
    ]
    assert list(join_each("p", paths)) == [
        "p/a",
        "p/b",
        "p/c/d/e",
        "p/f/g/h",
    ]



# Generated at 2022-06-12 07:55:08.865923
# Unit test for function join_each
def test_join_each():
    parent = 'path_to'
    iterable = ['a', 'b', 'c']
    expected = ['path_to/a', 'path_to/b', 'path_to/c']
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-12 07:55:13.523186
# Unit test for function join_each
def test_join_each():
    parent = '/path/to/parent'
    children = ['child1', 'child2']
    children_path = ['/path/to/parent/child1', '/path/to/parent/child2']
    result = join_each(parent, children)
    assert list(result) == children_path


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-12 07:55:15.616906
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) \
           == ['a/b', 'a/c']

# Generated at 2022-06-12 07:55:17.915038
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/lib', ['python2.4', 'python2.6'])) == [
        '/usr/lib/python2.4', '/usr/lib/python2.6']



# Generated at 2022-06-12 07:55:21.619379
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/usr/bin', ('sbin', 'src'))) == (
        '/usr/bin/sbin',
        '/usr/bin/src',
    )


# Using the function join_each, implement a function that returns the
# paths to all Python files in a directory.

# Generated at 2022-06-12 07:55:26.171796
# Unit test for function join_each
def test_join_each():
    # Test empty list
    assert list(join_each('a', [])) == []

    # Test single element
    assert list(join_each('a', ['b'])) == ['a/b']

    # Test multiple elements
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-12 07:55:31.733751
# Unit test for function join_each
def test_join_each():
    p0 = 'C:\\'
    p1 = 'C:/'
    p2 = '/home'
    p3 = 'home'
    for p in (p0, p1, p2, p3):
        assert list(join_each(p, ('windows', 'system32'))) == [os.path.join(p, 'windows'),
                                                               os.path.join(p, 'system32')]

# Generated at 2022-06-12 07:55:34.946361
# Unit test for function join_each
def test_join_each():
    assert [
        p
        for p in join_each("~", ["somefile", "someotherfile"])
    ] == [
        os.path.expanduser("~/somefile"),
        os.path.expanduser("~/someotherfile"),
    ]

# Generated at 2022-06-12 07:55:37.213185
# Unit test for function join_each
def test_join_each():
    assert list(join_each('hello', ['a', 'b', 'c'])) == [
        'hello/a', 'hello/b', 'hello/c']



# Generated at 2022-06-12 07:55:41.830465
# Unit test for function join_each
def test_join_each():
    assert all(os.path.isabs(p) for p in join_each('/', ['/etc', '/usr/lib/libc.8.dylib']))
    assert all(os.path.isabs(p) for p in join_each('/tmp', ['/etc', '/usr/lib/libc.8.dylib']))



# Generated at 2022-06-12 07:55:44.851752
# Unit test for function join_each
def test_join_each():
    assert(list(join_each("/tmp", [".", "..", "./test.txt"]))
           == ["/tmp/./", "/tmp/../", "/tmp/./test.txt"])



# Generated at 2022-06-12 07:55:56.206618
# Unit test for function join_each
def test_join_each():
    # Test a non-nested collection
    assert tuple(join_each("root", ["a", "b", "c"])) == ("root/a", "root/b", "root/c")
    # Test a nested collection
    assert tuple(join_each("root", ["a", ["b", "c"], "d"])) == (
        "root/a",
        "root/b",
        "root/c",
        "root/d",
    )



# Generated at 2022-06-12 07:55:58.288240
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['usr', 'bin'])) == ['/usr', '/bin']



# Generated at 2022-06-12 07:56:05.854597
# Unit test for function join_each
def test_join_each():
    assert list(
        join_each('/home/user', [
            '.',
            '..',
            './file.txt',
            '/file.txt',
            './dir1/dir2/file.txt',
            '/dir1/dir2/file.txt',
        ])) == [
            '/home/user/./',
            '/home/user/../',
            '/home/user/./file.txt',
            '/file.txt',
            '/home/user/./dir1/dir2/file.txt',
            '/dir1/dir2/file.txt',
        ]



# Generated at 2022-06-12 07:56:08.926464
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/etc", ("passwd", "group", "shadow"))) == ["/etc/passwd", "/etc/group", "/etc/shadow"]



# Generated at 2022-06-12 07:56:13.296546
# Unit test for function join_each
def test_join_each():
    parent = '/foo'
    it = join_each(parent, ['bar', 'baz', 'zap'])
    assert isinstance(it, types.GeneratorType)
    assert list(it) == ['/foo/bar', '/foo/baz', '/foo/zap']

# Generated at 2022-06-12 07:56:17.142940
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b', 'c'])) == [
        os.path.join('parent', 'a'),
        os.path.join('parent', 'b'),
        os.path.join('parent', 'c'),
    ]



# Generated at 2022-06-12 07:56:21.255118
# Unit test for function join_each
def test_join_each():
    assert list(join_each(os.path.sep, ['etc', 'passwd'])) == [
        os.path.join(os.path.sep, 'etc'),
        os.path.join(os.path.sep, 'passwd')
    ]



# Generated at 2022-06-12 07:56:25.519398
# Unit test for function join_each
def test_join_each():
    parent = 'C:\\'
    iterable = ['Folder1', 'Folder2']
    it = join_each(parent, iterable)
    assert next(it) == os.path.join(parent, 'Folder1')
    assert next(it) == os.path.join(parent, 'Folder2')



# Generated at 2022-06-12 07:56:27.414706
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []



# Generated at 2022-06-12 07:56:30.074572
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/root", ["a", "b", "c"])) == [
        "/root/a", "/root/b", "/root/c"
    ]



# Generated at 2022-06-12 07:56:44.473269
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['bar', 'baz'])) == ['/foo/bar', '/foo/baz']



# Generated at 2022-06-12 07:56:51.499449
# Unit test for function join_each
def test_join_each():
    test_cases = [(('a', 'b', 'c'), ('d', 'e'), ('a/b/c', 'a/b/c/d', 'a/b/c/e')),
                  ('a', ('b', 'c'), ('a/b', 'a/c'))]
    for case in test_cases:
        assert list(join_each(*case[0])) == list(case[2])


package = 'pykitml'



# Generated at 2022-06-12 07:56:54.667428
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('foo', [])) == [])
    assert(list(join_each('foo', ['bar1', 'bar2'])) ==
           ['foo/bar1', 'foo/bar2'])

# Generated at 2022-06-12 07:56:57.791056
# Unit test for function join_each
def test_join_each():
    assert_equal(join_each('a', ['b', 'c']), ['a/b', 'a/c'])



# Generated at 2022-06-12 07:57:00.719284
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]



# Generated at 2022-06-12 07:57:06.553359
# Unit test for function join_each
def test_join_each():
    from nose import tools
    from pytest import raises

    a_list = [join_each('home', ['/bin', 'bin']), join_each('/bin', [])]
    tools.assert_equals(
        list(a_list),
        [[os.path.join('home', '/bin'), os.path.join('home', 'bin')], []]
    )

    with raises(TypeError):
        list(join_each([], []))



# Generated at 2022-06-12 07:57:10.949842
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    parent = os.getcwd()

    res = list(join_each(parent, iterable))
    exp = [os.path.join(parent, x) for x in iterable]

    assert exp == res

# Generated at 2022-06-12 07:57:13.142162
# Unit test for function join_each
def test_join_each():
    assert list(join_each('dir', ['a', 'b', 'c'])) == ['dir/a', 'dir/b', 'dir/c']



# Generated at 2022-06-12 07:57:17.128613
# Unit test for function join_each
def test_join_each():
    assert isinstance(join_each('', ''), types.GeneratorType)
    assert tuple(join_each('', '')) == ()
    assert tuple(join_each('', ['a'])) == ('a',)
    assert tuple(join_each('parent', [])) == ()
    assert tuple(join_each('parent', ['a', 'b'])) == ('parent/a', 'parent/b')



# Generated at 2022-06-12 07:57:26.380771
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', 'abc')) == ['foo/a', 'foo/b', 'foo/c']
    assert list(join_each('foo', ['a', 'b', 'c'])) == ['foo/a', 'foo/b', 'foo/c']
    assert list(join_each(u'foo/bar', [u'a/b', u'b/c'])) ==\
           [u'foo/bar/a/b', u'foo/bar/b/c']
    for t in join_each('foo', ['a', 'b', 'c']):
        assert t.startswith('foo')



# Generated at 2022-06-12 07:57:56.103349
# Unit test for function join_each
def test_join_each():
    parent = "/"
    iterable = ["tmp", "usr", "blah"]

    assert (
        list(join_each(parent, iterable)) == [
            os.path.join(parent, p) for p in iterable
        ]
    )


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-12 07:57:57.222056
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']


# Function to read a directory and return the files in it.

# Generated at 2022-06-12 07:58:00.818038
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ('b', 'c', 'd'))) == ['a/b', 'a/c', 'a/d']
    assert list(join_each('/', ('b', 'c', 'd'))) == ['/b', '/c', '/d']



# Generated at 2022-06-12 07:58:02.648177
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child1', 'child2'])) == [
        'parent/child1', 'parent/child2']



# Generated at 2022-06-12 07:58:05.745270
# Unit test for function join_each
def test_join_each():
    parent = 'p'
    iterable = [1, 2, 3]
    result = list(join_each(parent, iterable))
    assert result == ['p\\1', 'p\\2', 'p\\3']

# Generated at 2022-06-12 07:58:09.027319
# Unit test for function join_each
def test_join_each():
    assert [os.path.join(os.path.curdir, 'test') for _ in range(2)] == list(join_each(os.path.curdir, ['test'] * 2))



# Generated at 2022-06-12 07:58:11.753006
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['c', 'd'])) == ['parent/c', 'parent/d']



# Generated at 2022-06-12 07:58:15.888323
# Unit test for function join_each
def test_join_each():
    a = ['b.py', 'd.py', 'i/j.py']
    b = ['a/b.py', 'a/d.py', 'a/i/j.py']
    assert a == [x[2:] for x in join_each('a', a)]
    assert b == list(join_each('a', a))

# Generated at 2022-06-12 07:58:17.703900
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-12 07:58:21.062073
# Unit test for function join_each
def test_join_each():
    parent = '/home/foo'
    iterable = ('bar', 'bar2')

    expected_results = ('/home/foo/bar', '/home/foo/bar2')

    assert expected_results == tuple(join_each(parent, iterable))


# This generator yeilds it's self in a cyclic manner.

# Generated at 2022-06-12 07:59:15.772484
# Unit test for function join_each
def test_join_each():
    parent = "/tmp"
    iterable = ["a", "b", "c"]
    result = join_each(parent, iterable)
    assert list(result) == ["/tmp/a", "/tmp/b", "/tmp/c"]


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-12 07:59:20.078619
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/path/to', ['file1', 'file2', 'file3'])) == \
           ['/path/to/file1', '/path/to/file2', '/path/to/file3']


# Returns a list of all files in a subtree of the filesystem

# Generated at 2022-06-12 07:59:22.934056
# Unit test for function join_each
def test_join_each():
    iterable = join_each("/foo", ["bar", "fie", "baz"])
    arr = list(iterable)
    assert arr == ["/foo/bar", "/foo/fie", "/foo/baz"]



# Generated at 2022-06-12 07:59:26.258107
# Unit test for function join_each
def test_join_each():
    iterable = [
        '.', '..', 'usr', 'var', 'lib'
    ]
    assert list(join_each('/', iterable)) == [
        '/',
        '/',
        '/usr',
        '/var',
        '/lib'
    ]



# Generated at 2022-06-12 07:59:29.616707
# Unit test for function join_each
def test_join_each():
    arr = [1, 2, 3]
    assert list(join_each('.', arr)) == [
        os.path.join('.', 1),
        os.path.join('.', 2),
        os.path.join('.', 3)
    ]

# Generated at 2022-06-12 07:59:32.078925
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('dir', ['file1', 'file2'])) == ['dir/file1', 'dir/file2'])



# Generated at 2022-06-12 07:59:36.505169
# Unit test for function join_each
def test_join_each():
    parent = '/tmp'
    iterable = ['1', '2', '3']
    got = list(join_each(parent, iterable))
    assert 3 == len(got)
    # Check first item
    expected = os.path.join(parent, iterable[0])
    assert expected == got[0]



# Generated at 2022-06-12 07:59:38.247470
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['bin', 'usr'])) == ['/bin', '/usr']



# Generated at 2022-06-12 07:59:42.136485
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr", ["local", "lib"])) == ["/usr/local", "/usr/lib"]
    # assert list(join_each("/usr", ["local", "lib"])) == ["/usr/local", "/usr/lib"]



# Generated at 2022-06-12 07:59:44.014994
# Unit test for function join_each
def test_join_each():
    assert list(join_each('mid', ['right', 'left'])) == ['mid/right', 'mid/left']



# Generated at 2022-06-12 08:01:45.247241
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/y/', ['a', 'b'])) == ['/y/a', '/y/b']



# Generated at 2022-06-12 08:01:49.426159
# Unit test for function join_each
def test_join_each():
    parent = os.path.dirname(os.path.abspath(__file__))
    actual = list(join_each(parent, ['a', 'b', 'c']))
    expected = [os.path.join(parent, c) for c in ['a', 'b', 'c']]
    assert actual == expected



# Generated at 2022-06-12 08:01:55.074162
# Unit test for function join_each
def test_join_each():
    result  = list(join_each(".", ['subpackage/subsubpackage', 'subpackage']))
    expected = [os.path.join(".", 'subpackage/subsubpackage'), os.path.join(".", 'subpackage')]
    assert result == expected


if __name__ == "__main__":
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-12 08:01:57.601168
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('a', ('b', 'c'))) == ('a/b', 'a/c')



# Generated at 2022-06-12 08:02:07.787902
# Unit test for function join_each
def test_join_each():
    from itertools import chain
    assert list(join_each('/usr', iter(('local', 'share')))) == [
                                                            '/usr/local',
                                                            '/usr/share',
                                                            ]
    assert list(join_each('/', iter(()))) == []
    assert list(join_each('', iter(()))) == []
    assert list(join_each('', iter(('',)))) == ['']
    assert list(join_each(None, iter(('',)))) == [None]
    assert list(join_each('', iter(('/',)))) == ['/']
    assert list(join_each('//', iter(('/',)))) == ['///']
    assert list(join_each('/', iter(('/',)))) == ['/']

# Generated at 2022-06-12 08:02:12.062095
# Unit test for function join_each
def test_join_each():
    parent = '/usr/local/bin'
    iterable = ['python', 'python2', 'python3']

    joined = list(join_each(parent, iterable))
    expected = [
        '/usr/local/bin/python',
        '/usr/local/bin/python2',
        '/usr/local/bin/python3'
    ]
    assert joined == expected


# Custom implementation of filter

# Generated at 2022-06-12 08:02:13.794063
# Unit test for function join_each
def test_join_each():
    assert list(join_each("parent", ["one", "two"])) == ["parent/one", "parent/two"]



# Generated at 2022-06-12 08:02:19.465521
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['home', 'nebula'])) == [
        '/home', '/nebula']
    assert list(join_each('/home', ['nebula'])) == ['/home/nebula']
    assert list(join_each('/home', ['', 'nebula'])) == ['/home', '/home/nebula']
    assert list(join_each('/home', ['', 'nebula', ''])) == ['/home', '/home/nebula', '/home/']



# Generated at 2022-06-12 08:02:29.245881
# Unit test for function join_each
def test_join_each():
    parent = "a"
    inputs = ["b", "c", "d"]
    outputs = ["a/b", "a/c", "a/d"]
    assert list(join_each(parent, inputs)) == outputs

    # Unit test for function join_each
    # assuming list is used in function,
    # otherwise use assert list(join_each(parent, [])) == []
    assert list(join_each(parent, [])) == []

    # Unit test for function join_each
    # assuming list is used in function,
    # otherwise use assert list(join_each(parent, [1])) == [1]
    assert list(join_each(parent, [1])) == [1]



# Generated at 2022-06-12 08:02:32.896855
# Unit test for function join_each
def test_join_each():
    paths = list(join_each('one', ['two', 'three']))
    assert len(paths) == 2
    assert paths[0] == os.path.join('one', 'two')
    assert paths[1] == os.path.join('one', 'three')


# Exclude files, directories and/or regex patterns