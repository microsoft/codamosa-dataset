

# Generated at 2022-06-12 07:54:32.963689
# Unit test for function join_each
def test_join_each():
    actual = list(join_each('/home', ['foo', 'bar']))
    assert actual == [
        '/home/foo',
        '/home/bar',
    ]


# TODO: multiple lines of input
# TODO: handle user breaking out of file selection early
# TODO: test select_files
# TODO: test select_dirs


# Generated at 2022-06-12 07:54:36.660430
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', ['passwd', 'quota'])) == \
        [os.path.join('/etc', 'passwd'), os.path.join('/etc', 'quota')]



# Generated at 2022-06-12 07:54:39.356518
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo/bar', ['baz', 'quux'])) == [
        '/foo/bar/baz',
        '/foo/bar/quux',
    ]



# Generated at 2022-06-12 07:54:46.526950
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b', 'c'])) == ['parent/a', 'parent/b', 'parent/c']
    assert list(join_each('pare/nt', ['a', 'b', 'c'])) == ['pare/nt/a', 'pare/nt/b', 'pare/nt/c']


# Wrapper function to get the filenames of a particular format

# Generated at 2022-06-12 07:54:49.174494
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c', 'd'])) == ['a/b', 'a/c', 'a/d']



# Generated at 2022-06-12 07:54:51.415895
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ("bar", "baz"))) == ["foo/bar", "foo/baz"]



# Generated at 2022-06-12 07:54:53.808917
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['', 'etc', 'passwd'])) == [
        '/',
        '/etc',
        '/passwd']



# Generated at 2022-06-12 07:54:56.821239
# Unit test for function join_each
def test_join_each():
    parent = "foo/"
    iterable = ["bar", "baz", "qux"]
    assert list(join_each(parent, iterable)) == [os.path.join(parent, i) for i in iterable]


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-12 07:54:58.254004
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', ['a', 'b'])) == ['/home/user/a', '/home/user/b']



# Generated at 2022-06-12 07:55:04.887269
# Unit test for function join_each
def test_join_each():
    root = '/some/path'
    asserts = [
        ['/some/path/a/b', '/some/path/c/d'],
        ['/some/path/a/b', '/some/path/c/d'],
        ['/some/path/a/b', '/some/path/c/d'],
    ]
    for i, j in zip(asserts, join_each(root, [['a', 'b'], ['c', 'd']])):
        assert i == j

# Generated at 2022-06-12 07:55:14.711447
# Unit test for function join_each
def test_join_each():
    parent_path = '/var/log'

    result = join_each(parent_path, ['a.txt', 'b.txt'])
    assert isinstance(result, types.GeneratorType)

    result_list = list(result)
    assert result_list == [os.path.join(parent_path, 'a.txt'),
                           os.path.join(parent_path, 'b.txt')]



# Generated at 2022-06-12 07:55:17.754845
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    actual_results = sorted(join_each(parent, ('1', '2', '3')))
    expected_results = sorted(['parent/1', 'parent/2', 'parent/3'])
    assert actual_results == expected_results



# Generated at 2022-06-12 07:55:27.721573
# Unit test for function join_each
def test_join_each():
    tests = ((("a", ["1", "2"]), ["a/1", "a/2"]),
             (("a/b", ["c", "d"]), ["a/b/c", "a/b/d"]),
             (("", ["1", "2"]), ["1", "2"]),
             (([], ["1", "2"]), []),
             (("a", []), []),
             (("a", [""]), ["a/"]),
             (("a", ["", "/b", "", "c/", "d//"]), ["a/", "/b", "a/c/", "a/d//"]),
             ((["a", "b", ""], ["c", "d"]), ["a/c", "a/d", "b/c", "b/d", "/c", "/d"]))

# Generated at 2022-06-12 07:55:34.539113
# Unit test for function join_each
def test_join_each():
    assert isinstance(join_each('parent', ('foo', 'bar', 'baz')), types.GeneratorType)
    assert list(join_each('parent', ('foo', 'bar', 'baz'))) == [
        'parent/foo',
        'parent/bar',
        'parent/baz'
    ]
    assert list(join_each(None, ('foo', 'bar', 'baz'))) == [
        None + '/foo',
        None + '/bar',
        None + '/baz'
    ]
    assert list(join_each('parent', [])) == []
    assert list(join_each('parent', [])) == []




# Generated at 2022-06-12 07:55:36.224103
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['etc', 'bin'])) == ['/etc', '/bin']



# Generated at 2022-06-12 07:55:39.246601
# Unit test for function join_each
def test_join_each():
    parent = 'a'
    it = ['b', 'c']
    expected = ['a/b', 'a/c']
    assert expected == list(join_each(parent, it))



# Generated at 2022-06-12 07:55:43.014005
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["usr", "bin"])) == ["/usr", "/bin"]
    assert list(join_each("/home", ["user1", "user2"])) == ["/home/user1", "/home/user2"]



# Generated at 2022-06-12 07:55:45.136075
# Unit test for function join_each
def test_join_each():
    assert join_each("a", ["b", "c", "d"]) == join_each("a", ["b", "c", "d"])



# Generated at 2022-06-12 07:55:49.655613
# Unit test for function join_each
def test_join_each():
    assert(list(join_each("/", ["usr", "local"])) == ["/usr", "/local"])
    assert(list(join_each("/usr/local", ["a", "b"])) == ["/usr/local/a",
                                                         "/usr/local/b"])



# Generated at 2022-06-12 07:55:51.619341
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["a", "b"])) == ["/a", "/b"]



# Generated at 2022-06-12 07:55:58.775607
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:56:07.278924
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]
    assert list(join_each("foo", [])) == []
    assert list(join_each("foo", ["foo"])) == ["foo/foo"]
    assert list(join_each("foo", ["foo", "bar"])) == ["foo/foo", "foo/bar"]
    assert list(join_each("", ['foo', 'bar'])) == ["foo", "bar"]
    assert list(join_each("/", ["foo", "bar"])) == ["/foo", "/bar"]
    assert list(join_each("foo/", ["bar", "baz"])) == ["foo/bar", "foo/baz"]

# Generated at 2022-06-12 07:56:10.351515
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["foo", "bar"])) == [
        "/home/foo",
        "/home/bar",
    ]



# Generated at 2022-06-12 07:56:13.855349
# Unit test for function join_each
def test_join_each():
    """
    Test that join_each returns the expected result.
    """
    result = list(join_each("home", ["user", "lib", "site"]))
    expected = ["home/user", "home/lib", "home/site"]
    assert result == expected

# Generated at 2022-06-12 07:56:16.125040
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]



# Generated at 2022-06-12 07:56:18.822658
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]



# Generated at 2022-06-12 07:56:21.394067
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    iterable = ['foo', 'bar']
    assert list(join_each(parent, iterable)) == ['/home/foo', '/home/bar']

# Generated at 2022-06-12 07:56:24.010712
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a/b/c", ["d", "e"])) == ["/a/b/c/d", "/a/b/c/e"]



# Generated at 2022-06-12 07:56:27.464450
# Unit test for function join_each
def test_join_each():
    from contextlib import redirect_stdout
    from io import StringIO
    f = StringIO()
    with redirect_stdout(f):
        ls = list(join_each('.', ['.', '..']))
    assert len(ls) == 2
    assert ls[0] == '.'
    assert ls[1] == '..'



# Generated at 2022-06-12 07:56:30.847704
# Unit test for function join_each
def test_join_each():
    assert isinstance(join_each('a', ['b', 'c']), types.GeneratorType)
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']


# Custom function to walk through subdirs

# Generated at 2022-06-12 07:56:46.772443
# Unit test for function join_each
def test_join_each():
    parent = "/tmp"
    test_strings = ["a", "b", "c"]
    actual = list(join_each(parent, test_strings))
    expected = ["/tmp/a", "/tmp/b", "/tmp/c"]
    assert actual == expected

# Generated at 2022-06-12 07:56:48.819453
# Unit test for function join_each
def test_join_each():
    assert len(list(join_each('/path/to', ['parent', 'iterable']))) == 2

# Generated at 2022-06-12 07:56:51.545772
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr/local', ['bin', 'share'])) == [
        '/usr/local/bin', '/usr/local/share']



# Generated at 2022-06-12 07:56:55.246436
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/var/log', ['syslog', 'kern.log', 'lastlog'])) == [
        '/var/log/syslog',
        '/var/log/kern.log',
        '/var/log/lastlog',
    ]



# Generated at 2022-06-12 07:57:00.762839
# Unit test for function join_each
def test_join_each():
    each = join_each('/a/b/c', ['x', 'y', 'z'])
    assert next(each) == '/a/b/c/x'
    assert next(each) == '/a/b/c/y'
    assert next(each) == '/a/b/c/z'



# Generated at 2022-06-12 07:57:02.747133
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ('bar', 'baz'))) \
           == ['foo/bar', 'foo/baz']

# Generated at 2022-06-12 07:57:05.055007
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:57:09.587571
# Unit test for function join_each
def test_join_each():
    parent = '/tmp/dir'
    iterable = ['value1', 'value2', 'value3']
    expected = ['/tmp/dir/value1', '/tmp/dir/value2', '/tmp/dir/value3']
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-12 07:57:12.692910
# Unit test for function join_each
def test_join_each():
    iterable = ('a', 'b', 'c')
    assert len(list(join_each('root', iterable))) == len(iterable)
    assert all([p.startswith('root') for p in join_each('root', iterable)])

# Generated at 2022-06-12 07:57:15.444285
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/path/to/dir", ["file1.txt", "file2.txt"])) == [
        "/path/to/dir/file1.txt",
        "/path/to/dir/file2.txt",
    ]

# Generated at 2022-06-12 07:57:42.758965
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']
    assert list(join_each('foo', [])) == []



# Generated at 2022-06-12 07:57:47.354970
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', 'child')) == ['parent/child']
    assert list(join_each('parent', ['child1', 'child2'])) == ['parent/child1', 'parent/child2']


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-12 07:57:51.848417
# Unit test for function join_each
def test_join_each():
    parent = os.path.dirname(__file__)
    files = ["file1", "file2", "file3"]
    expected_paths = [os.path.join(parent, "file1"),
                      os.path.join(parent, "file2"),
                      os.path.join(parent, "file3")]
    assert list(join_each(parent, files)) == expected_paths



# Generated at 2022-06-12 07:57:56.059958
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/path/to', ['file1.txt', 'dir1'])) == [
        '/path/to/file1.txt',
        '/path/to/dir1'
    ]

    assert list(join_each('/path/to', [])) == []



# Generated at 2022-06-12 07:57:59.459615
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['a', 'b', 'c'])) == \
        [os.path.join('.', 'a'), os.path.join('.', 'b'),
         os.path.join('.', 'c')]



# Generated at 2022-06-12 07:58:01.002030
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-12 07:58:05.158052
# Unit test for function join_each
def test_join_each():
    pwd = os.path.abspath(os.curdir)
    parent = os.path.join(pwd, 'parent')
    iterable = ['child1', 'child2', 'child3']
    expected = [
        os.path.join(pwd, 'parent', 'child1'),
        os.path.join(pwd, 'parent', 'child2'),
        os.path.join(pwd, 'parent', 'child3')
    ]
    result = list(join_each(parent, iterable))
    assert result == expected



# Generated at 2022-06-12 07:58:15.684738
# Unit test for function join_each
def test_join_each():
    # Setup
    parent = tempfile.mkdtemp()
    os.mkdir(os.path.join(parent, 'a'))
    os.makedirs(os.path.join(parent, 'b', 'c'))
    os.makedirs(os.path.join(parent, 'b', 'd'))

    # Exercise
    it = join_each(parent, ['a', 'b/c', os.path.join('b', 'd')])
    actual = list(it)

    # Verify
    assert actual == [
        os.path.join(parent, 'a'),
        os.path.join(parent, 'b', 'c'),
        os.path.join(parent, 'b', 'd'),
    ]

    # Teardown

# Generated at 2022-06-12 07:58:19.104741
# Unit test for function join_each
def test_join_each():
    for parent in ("/", "/tmp", "/x/y/z"):
        assert list(join_each(parent, ("a", "b"))) == [os.path.join(parent, "a"), os.path.join(parent, "b")]



# Generated at 2022-06-12 07:58:20.481746
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-12 07:59:13.904315
# Unit test for function join_each
def test_join_each():
    # Test 1
    test_parent = "test_parent"
    for each in join_each(test_parent, ["test_child1", "test_child2"]):
        assert each == os.path.join(test_parent, each)

# Generated at 2022-06-12 07:59:16.768205
# Unit test for function join_each
def test_join_each():
    L = ['file1', 'file2', 'file3']
    Lp = list(join_each('home', L))
    assert Lp == ['home/file1', 'home/file2', 'home/file3']

# Generated at 2022-06-12 07:59:19.834216
# Unit test for function join_each
def test_join_each():
    assert set(join_each('a/b', ['c', 'd', 'e'])) == set(['a/b/c', 'a/b/d', 'a/b/e'])

# Generated at 2022-06-12 07:59:23.962431
# Unit test for function join_each
def test_join_each():
    childs = ['a.txt', 'b.txt', 'c.txt']
    assert list(join_each('/', childs)) == ['/a.txt', '/b.txt', '/c.txt']
    assert list(join_each('/home', childs)) == ['/home/a.txt', '/home/b.txt', '/home/c.txt']



# Generated at 2022-06-12 07:59:25.563201
# Unit test for function join_each
def test_join_each():
    parent = '/home/user'
    iterable = ['file1', 'file2', 'file3']

    assert [
        os.path.join(parent, path) for path in iterable
    ] == list(join_each(parent, iterable))

# Generated at 2022-06-12 07:59:30.040497
# Unit test for function join_each
def test_join_each():
    path = "/home/user/document"
    folder_name = "myfolder"
    file_name = "myfile"

    file_path = join_each(path, [folder_name, file_name])
    assert next(file_path) == os.path.join(path, folder_name)
    assert next(file_path) == os.path.join(path, folder_name, file_name)



# Generated at 2022-06-12 07:59:33.344031
# Unit test for function join_each
def test_join_each():
    parent = "/tmp"
    items = ["a", "b"]
    expected = ["/tmp/a", "/tmp/b"]
    assert list(join_each(parent, items)) == expected

# Generated at 2022-06-12 07:59:36.856296
# Unit test for function join_each
def test_join_each():
    assert list(itertools.islice(join_each('a', ['b', 'c', 'd']), 3)) == ['a/b', 'a/c', 'a/d']
    assert not hasattr(join_each('a', ['b', 'c', 'd']), '__dict__')



# Generated at 2022-06-12 07:59:39.149717
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/a', ('b', 'c'))) == ('/a/b', '/a/c')



# Generated at 2022-06-12 07:59:46.026416
# Unit test for function join_each
def test_join_each():
    iterable = ('a', 'b/c', '../d')
    expected = ('a', 'b/c', '../d')
    result = tuple(join_each('', iterable))
    assert result == expected

    iterable = ('a', 'b/c', '../d')
    expected = ('/tmp/a', '/tmp/b/c', '/tmp/../d')
    result = tuple(join_each('/tmp', iterable))
    assert result == expected

    iterable = ('a', 'b/c', '../d')
    expected = ('/tmp/a', '/tmp/b/c', '/tmp/../d')
    result = tuple(join_each('/tmp/', iterable))
    assert result == expected



# Generated at 2022-06-12 08:00:40.514886
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/tmp', ['a', 'b', 'c'])) == \
           tuple(map(lambda x: '/tmp/' + x, ['a', 'b', 'c']))



# Generated at 2022-06-12 08:00:44.678055
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['a', 'b', 'c'])) == ['/home/a', '/home/b', '/home/c']
    assert list(join_each('/home', 'abc')) == ['/home/a', '/home/b', '/home/c']

# Generated at 2022-06-12 08:00:48.675095
# Unit test for function join_each
def test_join_each():
    l = list(join_each('parent', ['child1', 'child2', 'child3']))
    assert l[0] == os.path.join('parent', 'child1')
    assert l[1] == os.path.join('parent', 'child2')
    assert l[2] == os.path.join('parent', 'child3')



# Generated at 2022-06-12 08:00:51.256361
# Unit test for function join_each
def test_join_each():
    actual = list(join_each("/", ["etc", "bin", "usr"]))
    expected = ["/etc", "/bin", "/usr"]
    assert actual == expected


# Generated at 2022-06-12 08:00:52.932868
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ('name', 'age'))) == ['/home/name', '/home/age']



# Generated at 2022-06-12 08:00:58.925865
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a/b", ["c", "d"])) == ['a/b/c', 'a/b/d']
    assert list(join_each("a/b", ["a", "b/c", "c/d", "../e/f/g"])) == ['a/b/a', 'a/b/b/c', 'a/b/c/d', 'a/b/../e/f/g']


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-12 08:01:00.653919
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr", ["bin", "local"])) == [
        "/usr/bin",
        "/usr/local",
    ]

# Generated at 2022-06-12 08:01:03.895245
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/path', ('a', 'b', 'c'))) == [
        '/path/a', '/path/b', '/path/c'
    ], "Join_each should prepend the give path to each item in the iterable."



# Generated at 2022-06-12 08:01:09.298126
# Unit test for function join_each
def test_join_each():
    parent = '/home/bojack'
    iterable = ('horseman', 'season4', 'eighteen', 'video')
    assert tuple(join_each(parent, iterable)) == (
        '/home/bojack/horseman',
        '/home/bojack/season4',
        '/home/bojack/eighteen',
        '/home/bojack/video'
    )


test_join_each()


# Non-functional version of join_each

# Generated at 2022-06-12 08:01:11.981629
# Unit test for function join_each
def test_join_each():
    assert list(join_each("parent", ['a', 'b', 'c'])) == ['parent/a', 'parent/b', 'parent/c']

# Generated at 2022-06-12 08:03:14.508510
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']



# Generated at 2022-06-12 08:03:17.734659
# Unit test for function join_each
def test_join_each():
    parent = "foo/bar"
    iterable = ["baz", "qux", "zzz"]
    expect = ["foo/bar/baz", "foo/bar/qux", "foo/bar/zzz"]
    actual = list(join_each(parent, iterable))
    assert actual == expect

# Generated at 2022-06-12 08:03:20.907433
# Unit test for function join_each
def test_join_each():
    parent = os.path.abspath(__file__)
    children = ['a', 'b', 'c']
    expected = [os.path.join(parent, child) for child in children]
    assert list(join_each(parent, children)) == expected



# Generated at 2022-06-12 08:03:23.236538
# Unit test for function join_each
def test_join_each():
    # same as map(os.path.join, ['home', 'a', 'b'], ['home', 'a', 'b'])
    assert list(join_each('home', ['a', 'b'])) == \
           [join('home', 'a'), join('home', 'b')]

# Generated at 2022-06-12 08:03:26.112717
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    iterable = ['jdoe', 'jsmith', 'jdoe']
    expected = ['/home/jdoe', '/home/jsmith', '/home/jdoe']
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-12 08:03:28.294746
# Unit test for function join_each
def test_join_each():
    parent = 'root'
    iterable = ['folder', 'subfolder']
    assert list(join_each(parent, iterable)) == ['root/folder', 'root/subfolder']

# Generated at 2022-06-12 08:03:31.787215
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ["usr", "local", "bin"])) == \
        ['/usr', '/local', '/bin']
    assert list(join_each('/home/mike', ["Documents", "Photos"])) == \
        ['/home/mike/Documents', '/home/mike/Photos']



# Generated at 2022-06-12 08:03:34.852852
# Unit test for function join_each
def test_join_each():
    joined = join_each("/", ["a", "b", "c"])
    assert list(joined) == ["/a", "/b", "/c"]


# Use function join_each in a Generator Expression

# Generated at 2022-06-12 08:03:38.633570
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    expected = [os.path.join('p', 'a'),
                os.path.join('p', 'b'),
                os.path.join('p', 'c')]
    actual = list(join_each('p', iterable))
    assert expected == actual

# Generated at 2022-06-12 08:03:40.545379
# Unit test for function join_each
def test_join_each():
    assert list(join_each("base", ["a", "b"])) == ["base/a", "base/b"]

