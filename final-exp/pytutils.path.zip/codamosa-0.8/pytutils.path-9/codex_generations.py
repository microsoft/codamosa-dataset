

# Generated at 2022-06-12 07:54:30.288792
# Unit test for function join_each
def test_join_each():
    assert list(join_each(None, ["test", "test2"])) == [
        "test",
        "test2"
    ]
    assert list(join_each("parent", ["test", "test2"])) == [
        "parent/test",
        "parent/test2"
    ]



# Generated at 2022-06-12 07:54:32.645973
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == \
        ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:54:35.252564
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['/', '//', '/etc/'])) == ['/', '/', '/etc/']



# Generated at 2022-06-12 07:54:41.661903
# Unit test for function join_each
def test_join_each():
    parent = os.path.abspath(os.path.dirname(__file__))
    sample_data = [
        'a/b/c',
        'd/e/f',
        'g/h/i',
    ]
    expected_data = [
        os.path.join(parent, 'a/b/c'),
        os.path.join(parent, 'd/e/f'),
        os.path.join(parent, 'g/h/i'),
    ]
    assert list(join_each(parent, sample_data)) == expected_data

# Generated at 2022-06-12 07:54:46.385971
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ('bar', 'baz'))) == ['/foo/bar', '/foo/baz']
    assert list(join_each('/foo/', ('bar', 'baz'))) == ['/foo/bar', '/foo/baz']



# Generated at 2022-06-12 07:54:50.125707
# Unit test for function join_each
def test_join_each():
    parent = '/home/kimse'
    iterable = ['one', 'two']
    result = join_each(parent, iterable)
    assert list(result) == ['/home/kimse/one', '/home/kimse/two']



# Generated at 2022-06-12 07:54:53.093134
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', 'resolv.conf fstab'.split())) == [
        '/etc/resolv.conf', '/etc/fstab'
    ]



# Generated at 2022-06-12 07:54:57.915605
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['a'])) == ['./a']
    assert list(join_each('.', ['a', 'b', 'c'])) == ['./a', './b', './c']
    assert list(join_each('.', ['./a', './b', './c'])) == ['./a', './b', './c']
    assert list(join_each('.', ['../a', '../b', '../c'])) == ['../a', '../b', '../c']

# Generated at 2022-06-12 07:55:01.441583
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/directory', ['file1', 'file2', 'file3'])) == [
        '/directory/file1',
        '/directory/file2',
        '/directory/file3',
    ]



# Generated at 2022-06-12 07:55:06.223884
# Unit test for function join_each
def test_join_each():
    parent = os.path.abspath(os.path.dirname(__file__))
    res = list(join_each(parent, ['a', 'b', 'c']))
    assert os.path.join(parent, 'a') in res
    assert os.path.join(parent, 'b') in res
    assert os.path.join(parent, 'c') in res

# Generated at 2022-06-12 07:55:15.256144
# Unit test for function join_each
def test_join_each():
    """
    Test for the function join_each
    """
    dirs = [str(i) for i in range(10)]
    dir_path = os.path.join(os.path.curdir, 'test')
    dir_paths = join_each(dir_path, dirs)
    for dlist, dpath in zip(dirs, dir_paths):
        assert dlist == os.path.relpath(dpath, dir_path)



# Generated at 2022-06-12 07:55:17.653054
# Unit test for function join_each
def test_join_each():
    test = ['/a/b/c', '/a/b/d', '/a/b/e']

    assert list(join_each('/a/b', ['c', 'd', 'e'])) == test

# Generated at 2022-06-12 07:55:22.992644
# Unit test for function join_each
def test_join_each():
    from itertools import izip
    from itertools import imap

    assert tuple(join_each("/", "ab".split(""))) == tuple(imap(os.path.join, "/", "ab".split("")))
    assert tuple(join_each("/tmp/", "ab".split(""))) == tuple(imap(os.path.join, "/tmp/", "ab".split("")))



# Generated at 2022-06-12 07:55:26.075816
# Unit test for function join_each
def test_join_each():
    ls = ['/tmp/', 'a', 'b']
    assert list(join_each(*ls)) == [
        '/tmp/a',
        '/tmp/b',
    ]



# Generated at 2022-06-12 07:55:29.698635
# Unit test for function join_each
def test_join_each():
    parent = '/'
    iterable = ('usr', 'local', 'bin')
    expected = ('/usr', '/local', '/bin')

    result = join_each(parent, iterable)

    assert tuple(result) == expected



# Generated at 2022-06-12 07:55:31.814114
# Unit test for function join_each
def test_join_each():
    assert list(join_each('root', ['a', 'b'])) == ['root/a', 'root/b']



# Generated at 2022-06-12 07:55:33.713221
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/etc', ['passwd', 'group'])) == ['/etc/passwd', '/etc/group']



# Generated at 2022-06-12 07:55:35.671827
# Unit test for function join_each
def test_join_each():
    assert list(join_each('root', ['a', 'b'])) == ['root/a', 'root/b']



# Generated at 2022-06-12 07:55:38.154252
# Unit test for function join_each
def test_join_each():
    input = ("a", ("b", "c"))
    expected = ("a/b", "a/c")
    assert tuple(join_each(*input)) == expected

# Generated at 2022-06-12 07:55:48.322517
# Unit test for function join_each
def test_join_each():
    f = join_each
    assert list(f('', [''])) == ['']
    assert list(f('.', [''])) == ['.']
    assert list(f('', ['', ''])) == ['', '']
    assert list(f('', ['.'])) == ['.']
    assert list(f('', ['..'])) == ['..']
    assert list(f('', ['./'])) == ['./']
    assert list(f('', ['./.'])) == ['./.']
    assert list(f('.', ['.'])) == ['.']
    assert list(f('.', ['..'])) == ['..']
    assert list(f('.', ['./'])) == ['./']

# Generated at 2022-06-12 07:55:56.630229
# Unit test for function join_each
def test_join_each():
    """
    Function join_each is a generator,
    so we can't use to make assertTrue.
    So we use next(join_each) instead of it.
    """

    iterable = [
        "a.txt",
        "b.txt",
        "c.txt",
    ]
    dir_name = "/tmp"
    str_next = next(join_each(dir_name, iterable))
    assert str_next == os.path.join(dir_name, iterable[0])

# Generated at 2022-06-12 07:55:59.379457
# Unit test for function join_each
def test_join_each():
    expected = ['test/test', 'test/test2']
    assert(list(join_each('test', ['test', 'test2'])) == expected)



# Generated at 2022-06-12 07:56:05.261566
# Unit test for function join_each
def test_join_each():
    root = os.path.abspath(os.getcwd())
    common_paths = ['my_dir_1/my_dir_2/my_dir_3', 'my_dir_4/my_dir_5']
    expected = list(map(lambda x: os.path.join(root, x), common_paths))
    result = list(join_each(root, common_paths))
    assert result == expected



# Generated at 2022-06-12 07:56:08.450317
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['usr', 'bin'])) == ['/usr', '/bin']
    assert list(join_each('/', [])) == []



# Generated at 2022-06-12 07:56:12.383002
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a/x", ["b", "c"])) == ["a/x/b", "a/x/c"]


# Function to change into the specified directory and run the command
# finally return to the original directory

# Generated at 2022-06-12 07:56:16.279832
# Unit test for function join_each
def test_join_each():
    parent = '/foo/bar'
    things = ['a', 'b', 'c']

    expected = [
        '/foo/bar/a',
        '/foo/bar/b',
        '/foo/bar/c',
    ]
    assert list(join_each(parent, things)) == expected



# Generated at 2022-06-12 07:56:19.340362
# Unit test for function join_each
def test_join_each():
    l = ['foo', 'bar']
    assert list(join_each('baz', l)) == ['baz/foo', 'baz/bar']



# Generated at 2022-06-12 07:56:23.969402
# Unit test for function join_each
def test_join_each():
    expected = ['/a/b/c', '/a/b/d', '/e/b/c', '/e/b/d']
    assert list(join_each('/a', ('b/c', 'b/d'))) == expected
    assert list(join_each('/e', ('/b/c', '/b/d'))) == expected



# Generated at 2022-06-12 07:56:26.913021
# Unit test for function join_each
def test_join_each():
    parent = "/tmp"
    iterable = ["a", "b"]

    result = [os.path.join("/tmp", "a"), os.path.join("/tmp", "b")]

    assert result == list(join_each(parent, iterable))

# Generated at 2022-06-12 07:56:30.660820
# Unit test for function join_each
def test_join_each():
    test_cases = [
        ('p', ['a', 'b'], ['p/a', 'p/b']),
        ('p', [], []),
    ]
    for parent, iterable, expected_result in test_cases:
        assert list(join_each(parent, iterable)) == expected_result



# Generated at 2022-06-12 07:56:38.468412
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['var', 'local'])) == [
        '/var', '/local']



# Generated at 2022-06-12 07:56:39.986852
# Unit test for function join_each
def test_join_each():
    parent = 'root'
    assert list(join_each(parent, ['a', 'b'])) == ['root/a', 'root/b']



# Generated at 2022-06-12 07:56:44.068073
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    files = ["file1", "file2", "file3"]
    expected = ["parent/file1", "parent/file2", "parent/file3"]
    actual = list(join_each(parent, files))
    assert expected == actual



# Generated at 2022-06-12 07:56:49.298444
# Unit test for function join_each
def test_join_each():
    parent = '/foo'
    iterable = (b'bar', b'baz', b'qux')
    target = ('/foo/bar', '/foo/baz', '/foo/qux')
    result = list(join_each(parent, iterable))
    assert result == target


# Use mock.patch to use a mock version of iterdir

# Generated at 2022-06-12 07:56:53.971797
# Unit test for function join_each
def test_join_each():
    parent_dir = '/tmp/'
    children = ['child1', 'child2', 'child3']
    expected_result = ['/tmp/child1', '/tmp/child2', '/tmp/child3']
    assert tuple(join_each(parent_dir, children)
                 ) == tuple(expected_result)

# Generated at 2022-06-12 07:56:56.427005
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['bin', 'opt'])) == ['/bin', '/opt']



# Generated at 2022-06-12 07:57:04.413535
# Unit test for function join_each
def test_join_each():
    inputs = ('spam/', 'ham', 'eggs')
    outputs = tuple(join_each('root', inputs))
    assert outputs == ('root/spam/', 'root/ham', 'root/eggs')


# Use tuple unpacking to put the outputs into three variables
inputs = ('spam/', 'ham', 'eggs')
outputs = tuple(join_each('root', inputs))
spam, ham, eggs = outputs
assert spam == 'root/spam/'
assert ham == 'root/ham'
assert eggs == 'root/eggs'

# Generated at 2022-06-12 07:57:06.185848
# Unit test for function join_each
def test_join_each():
    assert list(join_each("parent", ["child-a", "child-b"])) ==\
        ["parent/child-a", "parent/child-b"]


# Generator that returns all the files in a folder recursively

# Generated at 2022-06-12 07:57:08.819929
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('/foo', ('bar', 'baz'))) == ('/foo/bar', '/foo/baz')

# Generated at 2022-06-12 07:57:12.404979
# Unit test for function join_each
def test_join_each():
    parent = '/home/foo'
    iterable = ['bar', 'baz', 'qux']
    expected = ['/home/foo/bar', '/home/foo/baz', '/home/foo/qux']
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-12 07:57:28.272139
# Unit test for function join_each
def test_join_each():
    test_dir = "/test/directory"
    test_result = join_each(test_dir, ["one", "two", "three"])
    assert list(test_result) == [
        "/test/directory/one",
        "/test/directory/two",
        "/test/directory/three",
    ]

# Generated at 2022-06-12 07:57:30.201218
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a/b', ['/c/d', '/e/f'])) == ['/a/b/c/d', '/a/b/e/f']

# Generated at 2022-06-12 07:57:37.211974
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp/a', [])) == []
    assert list(join_each('/tmp/a', [''])) == ['/tmp/a']
    assert list(join_each('/tmp/a', ['a'])) == ['/tmp/a/a']
    assert list(join_each('/tmp/a', ['a', 'b'])) == ['/tmp/a/a', '/tmp/a/b']



# Generated at 2022-06-12 07:57:40.818888
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/etc', ('squid', 'cups')))
    assert isinstance(result, list)
    assert len(result) == 2
    assert result[0] == '/etc/squid'
    assert result[1] == '/etc/cups'



# Generated at 2022-06-12 07:57:49.490368
# Unit test for function join_each
def test_join_each():
    parent = "/usr/bin"
    iterable = ["python", "gcc"]
    expected = ["/usr/bin/python", "/usr/bin/gcc"]
    actual = list(join_each(parent, iterable))
    assert actual == expected


# Files and Folders to create
FILES = ["foo.txt", "bar.txt", "baz.txt"]
FOLDERS = ["alpha", "beta", "gamma"]


# This is the base path.
# We will create our files and folders here
BASE_PATH = os.path.join(os.path.expanduser("~"), "data", "demo")



# Generated at 2022-06-12 07:57:51.664504
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a', [])) == []



# Generated at 2022-06-12 07:57:54.648011
# Unit test for function join_each
def test_join_each():
    paths = ['/tmp', 'home', 'colin']
    result = list(join_each('/', paths))
    assert result == ['/tmp', '/home', '/colin']



# Generated at 2022-06-12 07:57:57.849072
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/user', os.listdir('/home/user'))) == ['/home/user/file1', '/home/user/file2']


# Implementation of one-line function called split_dirs

# Generated at 2022-06-12 07:58:07.357852
# Unit test for function join_each
def test_join_each():
    # Second argument is zipped, so it stops after the shorter one
    assert list(join_each('/', ['a', 'b', 'c'])) == \
        ['/a', '/b', '/c']
    assert list(join_each('/', ['/a', '/b', '/c'])) == \
        ['/a', '/b', '/c']
    assert list(join_each('/', ['a/', 'b/', 'c/'])) == \
        ['/a/', '/b/', '/c/']
    assert list(join_each('/', ['a', 'b/', 'c/'])) == \
        ['/a', '/b/', '/c/']

# Generated at 2022-06-12 07:58:12.807278
# Unit test for function join_each
def test_join_each():
    # Setup
    parent = 'parent'
    iterable = ['child1', 'child2', 'child3']

    # Exercise
    actual = join_each(parent, iterable)

    # Verify
    expected = ['parent/child1', 'parent/child2', 'parent/child3']
    assert all(x == y for x, y in zip(expected, actual))



# Generated at 2022-06-12 07:58:30.465612
# Unit test for function join_each
def test_join_each():
    a_file = 'a.txt'
    b_file = 'b.txt'
    dir_name = 'foo'
    parent = 'bar'

    expected = ['bar/a.txt', 'bar/b.txt', 'bar/foo/a.txt', 'bar/foo/b.txt']
    actual = join_each(parent, [a_file, b_file, join_each(dir_name, [a_file, b_file])])
    assert actual == expected

# Generated at 2022-06-12 07:58:35.480420
# Unit test for function join_each
def test_join_each():
    """
    Check join_each
    """
    expected = ['apple/banana', 'apple/cucumber', 'apple/durian']
    fruits = ['banana', 'cucumber', 'durian']

    got = list(join_each('apple', fruits))
    assert got == expected

# Generated at 2022-06-12 07:58:38.337373
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", [
        "bar",
        "baz",
    ])) == [
        "foo/bar",
        "foo/baz",
    ]

# Generated at 2022-06-12 07:58:41.463953
# Unit test for function join_each
def test_join_each():
    p = '/tmp/'
    files = ['a', 'b', 'c']
    expected = '/tmp/a /tmp/b /tmp/c'
    assert list_to_str(list(join_each(p, files))) == expected



# Generated at 2022-06-12 07:58:49.319537
# Unit test for function join_each
def test_join_each():
    # Initialize paths
    path = "/home/user"
    paths = [".cache/image1.png", ".cache/image2.png"]
    # Expected output
    expected = ["/home/user/.cache/image1.png", "/home/user/.cache/image2.png"]
    # Retrieve result
    result = list(join_each(path, paths))
    # Check
    assert all(e == r for e, r in zip(expected, result))


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-12 07:58:53.407909
# Unit test for function join_each
def test_join_each():
    # Given
    path = '/tmp'
    dirs = ['a', 'b', 'c']
    expected = ['/tmp/a', '/tmp/b', '/tmp/c']

    # When
    actual = [x for x in join_each(path, dirs)]

    # Then
    assert actual == expected

# Generated at 2022-06-12 07:58:55.696064
# Unit test for function join_each
def test_join_each():
    assert list(join_each('root', ['c', 'd', 'e'])) == \
        ['root/c', 'root/d', 'root/e']

# Generated at 2022-06-12 07:58:59.690523
# Unit test for function join_each
def test_join_each():
    parent = '/usr'
    iterable = ['local', 'bin']

    # Test if join_each behaves the same as itertools
    assert list(join_each(parent, iterable)) == \
        list(itertools.starmap(os.path.join,
                               itertools.repeat(parent),
                               iterable))


modules = ('testmod', 'testmod2')

# Function that loads the modules using importlib

# Generated at 2022-06-12 07:59:02.581283
# Unit test for function join_each
def test_join_each():
    p = os.path.join('c:', 'this', 'is', 'path')
    assert list(join_each(p, ['a', 'b'])) == ['c:\\this\\is\\path\\a', 'c:\\this\\is\\path\\b']

# Generated at 2022-06-12 07:59:06.539050
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b'])) == ['/tmp/a', '/tmp/b']
    assert list(join_each('/tmp', [])) == []



# Generated at 2022-06-12 07:59:36.329989
# Unit test for function join_each
def test_join_each():
    tests = [(["/home/", "user", "docs"], ["/home/user", "/home/docs"]),
             (["/home/", "user", "docs"], ["/home/user/docs"])]
    for test in tests:
        assert list(join_each(*test[0])) == test[1]



# Generated at 2022-06-12 07:59:40.339966
# Unit test for function join_each
def test_join_each():
    assert (next(join_each('a', ['b', 'c'])) == os.path.join('a', 'b'))
    assert (next(join_each('a', ['b', 'c'])) == os.path.join('a', 'c'))



# Generated at 2022-06-12 07:59:44.285379
# Unit test for function join_each
def test_join_each():
    assert list(join_each(os.sep, ['a', 'b', 'c'])) == [os.path.join(os.sep, 'a'),
                                                        os.path.join(os.sep, 'b'),
                                                        os.path.join(os.sep, 'c')]



# Generated at 2022-06-12 07:59:48.516990
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["a", "b", "c"]
    expected = ["parent/a", "parent/b", "parent/c"]
    actual = list(join_each(parent, iterable))
    assert actual == expected

# Generated at 2022-06-12 07:59:50.988014
# Unit test for function join_each
def test_join_each():
    assert list(join_each('c:\\', ['a.in', 'b.out'])) == ['c:\\a.in', 'c:\\b.out']



# Generated at 2022-06-12 07:59:53.302256
# Unit test for function join_each
def test_join_each():
    parent = '/home'
    children = ['foo', 'bar']

    assert list(join_each(parent, children)) == [
        '/home/foo',
        '/home/bar'
    ]

# Generated at 2022-06-12 07:59:55.453672
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']



# Generated at 2022-06-12 08:00:02.400181
# Unit test for function join_each
def test_join_each():
    # Setup
    actual = join_each('/foo/bar', ['baz', 'foobar'])
    expected = [
        '/foo/bar/baz',
        '/foo/bar/foobar'
    ]

    # Exercise
    actual_list = list(actual)

    # Verify
    assert expected == actual_list

    # Cleanup - none necessary


# Local Variables:
# compile-command: "python -m pytest -v test_join_each.py"
# End:

# Generated at 2022-06-12 08:00:09.104053
# Unit test for function join_each
def test_join_each():
    p = 'path'
    i = ['', '/', 'p', 'p/', '/p', '/p/', 'p/a', 'p/a/']
    expected = ['path', '/path', 'path/p', 'path/p/', '/path/p', '/path/p/', 'path/p/a', 'path/p/a/']
    actual = list(join_each(p, i))

    assert expected == actual



# Generated at 2022-06-12 08:00:15.417797
# Unit test for function join_each
def test_join_each():
    parent = '/some/path'
    expected = [
        '/some/path/some_path',
        '/some/path/another/path',
        '/some/path/yet/another/path',
    ]
    result = list(join_each(parent,
                            ['some_path', 'another/path', 'yet/another/path']))
    assert expected == result


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-12 08:01:22.979483
# Unit test for function join_each
def test_join_each():
    for a, b in [
        ('a', ['b', 'c']),
        ('a', ['b', 'c', 'd']),
    ]:
        assert list(join_each(a, b)) == [
            os.path.join(a, c)
            for c in b
        ]

    assert list(join_each(None, [1, 2, 3])) == [1, 2, 3]
    assert list(join_each(None, [])) == []



# Generated at 2022-06-12 08:01:25.846509
# Unit test for function join_each
def test_join_each():
    dir = "parent"
    children = ["child1", "child2"]
    assert list(join_each(dir, children)) == ["parent/child1", "parent/child2"]



# Generated at 2022-06-12 08:01:33.384496
# Unit test for function join_each
def test_join_each():
    # Function 'join_each' should join each item of the iterable withe parent
    # path to create a new path.
    path1 = os.path.join('good', 'path')
    path2 = os.path.join('bad', 'path')
    assert list(join_each('.', [path1, path2])) == ['.' +  path1, '.' + path2]
    assert list(join_each('./', [path1, path2])) == ['./' +  path1, './' + path2]
    assert list(join_each('../', [path1, path2])) == ['../' +  path1, '../' + path2]



# Generated at 2022-06-12 08:01:35.175120
# Unit test for function join_each
def test_join_each():
    assert list(join_each('root', ['foo', 'bar'])) == ['root/foo', 'root/bar']



# Generated at 2022-06-12 08:01:37.402335
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('~', ['a', 'b'])) == ('~/a', '~/b')



# Generated at 2022-06-12 08:01:45.248606
# Unit test for function join_each
def test_join_each():
    cases = [
        ['', []],
        ['', []],
        ['/', ['foo', 'bar']],
        ['/home', ['foo', 'bar']],
        ['/var/log', ['foo', 'bar']],
    ]
    expected = [
        [],
        [],
        ['/foo', '/bar'],
        ['/home/foo', '/home/bar'],
        ['/var/log/foo', '/var/log/bar'],
    ]
    for i, (parent, iterable) in enumerate(cases):
        result = list(join_each(parent, iterable))
        assert result == expected[i]

# Generated at 2022-06-12 08:01:47.784715
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == ['/tmp/a', '/tmp/b', '/tmp/c']



# Generated at 2022-06-12 08:01:50.589201
# Unit test for function join_each
def test_join_each():
    t = join_each('/', ['usr', 'lib'])
    assert next(t) == '/usr'
    assert next(t) == '/lib'



# Generated at 2022-06-12 08:01:54.382768
# Unit test for function join_each
def test_join_each():
    parent = os.getcwd()
    for child in join_each(parent, ["asdf", "qwer", "zxcv"]):
        assert os.path.normpath(os.path.join(parent, child)) != child



# Generated at 2022-06-12 08:02:00.725265
# Unit test for function join_each
def test_join_each():
    paths = ["/home", "/home", "/home/username", "/home/username/Downloads", "/home/username/Downloads/pytorch-crf"]
    expected = ["/home", "/home/private", "/home/username", "/home/username/Downloads", "/home/username/Downloads/pytorch-crf"]
    assert list(join_each("/home/private", paths)) == expected



# Generated at 2022-06-12 08:04:13.010533
# Unit test for function join_each
def test_join_each():
    # Change cwd
    cwd = os.getcwd()
    parent = os.path.dirname(cwd)

    # Run function and assert result
    assert [os.path.join(parent, 'a'), os.path.join(parent, 'b')] == list(join_each(parent, ['a', 'b']))

    # Restore cwd
    os.chdir(cwd)



# Generated at 2022-06-12 08:04:14.898092
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each("foo",
                           ("bar", "baz", "asd"))) == ("foo/bar", "foo/baz", "foo/asd")



# Generated at 2022-06-12 08:04:16.721539
# Unit test for function join_each
def test_join_each():
    result = list(join_each("aa", ["bb", "cc", "dd"]))
    expected = ["aa/bb", "aa/cc", "aa/dd"]
    assert result == expected



# Generated at 2022-06-12 08:04:20.220420
# Unit test for function join_each
def test_join_each():
    a = ['a', 'b', 'c']
    assert list(join_each('/path', a)) == [
        '/path/a', '/path/b', '/path/c']



# Generated at 2022-06-12 08:04:21.548576
# Unit test for function join_each
def test_join_each():
    assert join_each('a', ['b', 'c']) == ['a/b', 'a/c']

# Generated at 2022-06-12 08:04:22.795393
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-12 08:04:27.591413
# Unit test for function join_each
def test_join_each():
    t1 = [1, 2, 3]
    t2 = [4, 5]
    t3 = ['', '', '']

    assert list(join_each(t1, t2)) == [5, 6]
    assert list(join_each(t1, t3)) == t1
    assert list(join_each(t3, t1)) == t1