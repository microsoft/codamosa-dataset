

# Generated at 2022-06-12 07:54:29.152511
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-12 07:54:31.798576
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']


# End unit test



# Generated at 2022-06-12 07:54:34.304661
# Unit test for function join_each
def test_join_each():
    assert list(join_each("aaa", ["bbb", "ccc"])) == ["aaa/bbb", "aaa/ccc"]



# Generated at 2022-06-12 07:54:37.045304
# Unit test for function join_each
def test_join_each():
    assert list(join_each("path", ["a", "b"])) == ["path/a", "path/b"]
    assert list(join_each("path/a", ["b", "c"])) == ["path/a/b", "path/a/c"]
    assert list(join_each("", [])) == []



# Generated at 2022-06-12 07:54:39.090584
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ('b', 'c'))) == ['a/b', 'a/c']



# Generated at 2022-06-12 07:54:41.710599
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ["a", "b"])) == ["/tmp/a", "/tmp/b"]



# Generated at 2022-06-12 07:54:44.219279
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']

# Generated at 2022-06-12 07:54:49.084349
# Unit test for function join_each
def test_join_each():
    parent = '/usr/local'
    list_of_stuff = ['bin', 'share', 'lib']
    actual_list = list(join_each(parent, list_of_stuff))
    expected_list = [os.path.join(parent, s) for s in list_of_stuff]
    assert actual_list == expected_list



# Generated at 2022-06-12 07:54:54.204609
# Unit test for function join_each
def test_join_each():
    parent = '/home/'
    children = ['path', 'to', 'file', 'in', 'path']

    actual = join_each(parent, children)
    expected = [
        '/home/path',
        '/home/to',
        '/home/file',
        '/home/in',
        '/home/path',
    ]

    assert all(a == e for a, e in zip(actual, expected))

# Generated at 2022-06-12 07:54:57.342529
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar'])) == ['/foo', '/bar']



# Generated at 2022-06-12 07:55:02.693419
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["user", "test"])) == [
        "/home/user",
        "/home/test",
    ]
    assert list(join_each("/home", [])) == []

# Generated at 2022-06-12 07:55:07.356080
# Unit test for function join_each
def test_join_each():
    parent = os.path.dirname(__file__)
    children = ['foo', 'bar', 'baz']
    joined = join_each(parent, children)

    assert list(joined) == [os.path.join(parent, 'foo'),
                            os.path.join(parent, 'bar'),
                            os.path.join(parent, 'baz')]



# Generated at 2022-06-12 07:55:12.566404
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/var/log", ["apache", "mysql"])) == [
        "/var/log/apache",
        "/var/log/mysql",
    ]


from operator import add



# Generated at 2022-06-12 07:55:19.991494
# Unit test for function join_each
def test_join_each():
    xs = ['a', 'b', 'c']
    ys = ['a1', 'a2']
    zs = ['z1', 'z2', 'z3', 'z4']

# Generated at 2022-06-12 07:55:25.259299
# Unit test for function join_each
def test_join_each():
    assert len(list(join_each('/test', []))) == 0
    assert len(list(join_each('/test', ['']))) == 1
    assert list(join_each('/test', ['', ''])) == ['/test', '/test']
    assert list(join_each('/test', ['', 'a', 'b'])) == ['/test', '/test/a', '/test/b']



# Generated at 2022-06-12 07:55:28.269229
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/', [])) == []



# Generated at 2022-06-12 07:55:30.883785
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["A", "B", "C"])) == [
        "/A",
        "/B",
        "/C",
    ]



# Generated at 2022-06-12 07:55:34.482102
# Unit test for function join_each
def test_join_each():
    expected = [
        os.path.join('path', 'to', 'file'),
        os.path.join('path', 'to', 'file2'),
    ]
    assert list(join_each('path/to', ['file', 'file2'])) == expected



# Generated at 2022-06-12 07:55:36.097936
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['etc', 'bin'])) == ['/etc', '/bin']



# Generated at 2022-06-12 07:55:38.244128
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['opt/', 'usr/bin/'])) == ['/home/opt/', '/home/usr/bin/']

# Generated at 2022-06-12 07:55:45.508050
# Unit test for function join_each
def test_join_each():
    assert ['a/b', 'a/c'] == list(join_each('a', ['b', 'c']))



# Generated at 2022-06-12 07:55:49.277166
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['usr', 'bin'])) == ['/home/usr', '/home/bin']
    assert list(join_each('/home', [''])) == ['/home/']



# Generated at 2022-06-12 07:55:52.016737
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/usr', ['tmp', 'cnt']))\
        == ['/home/usr/tmp', '/home/usr/cnt']

# Generated at 2022-06-12 07:55:57.821594
# Unit test for function join_each
def test_join_each():
    assert list(join_each('', [''])) == ['']
    assert list(join_each('', ['b', 'c'])) == ['b', 'c']
    assert list(join_each('a', [])) == []
    assert list(join_each('a', ['b'])) == ['a/b']
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']
    assert list(join_each('a/b/c', ['d', 'e'])) == ['a/b/c/d', 'a/b/c/e']

# Generated at 2022-06-12 07:56:00.203453
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:56:05.883031
# Unit test for function join_each
def test_join_each():
    test_pairs = (
        (os.path.join('foo', 'bar', 'baz'), []),
        (os.path.join('foo', 'bar'), ['baz']),
        (os.path.join('foo', 'bar'), ['baz', 'bop']),
    )
    for parent, children in test_pairs:
        assert list(join_each(parent, children)) == list(map(partial(os.path.join, parent), children))



# Generated at 2022-06-12 07:56:08.967360
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ('bar', 'zoo'))) == [
        '/foo/bar',
        '/foo/zoo'
    ]

# Generated at 2022-06-12 07:56:13.598641
# Unit test for function join_each
def test_join_each():
    iterable = ['dir1', 'dir2']
    expected_iterable = ['dir1/dir1', 'dir1/dir2', 'dir2/dir1', 'dir2/dir2']

    assert(list(join_each('dir1', iterable)) == expected_iterable)



# Generated at 2022-06-12 07:56:20.149616
# Unit test for function join_each
def test_join_each():
    parent = '../data/coco/'
    child = ['annotations/instances_train2017.json',
             'annotations/instances_val2017.json']
    results = list(join_each(parent, child))
    assert results == [
        '../data/coco/annotations/instances_train2017.json',
        '../data/coco/annotations/instances_val2017.json']


# Helper function to replace file contents

# Generated at 2022-06-12 07:56:22.246353
# Unit test for function join_each
def test_join_each():
    """Simple test for join_each"""
    assert "".join(list(join_each("a", ["b", "c"]))) == "abc"



# Generated at 2022-06-12 07:56:36.577272
# Unit test for function join_each
def test_join_each():
    p = "/home"
    i = ["foo", "bar"]
    e = ["/home/foo", "/home/bar"]
    assert list(join_each(p, i)) == e



# Generated at 2022-06-12 07:56:41.788750
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['var', 'etc'])) == ['/var', '/etc']
    assert list(join_each('/var', ['log', 'log/apache2'])) == ['/var/log', '/var/log/apache2']
    assert list(join_each('/var', ['*', 'log/apache2'])) == ['/var/*', '/var/log/apache2']
    assert list(join_each('/var', ['*/*'])) == ['/var/*/*']



# Generated at 2022-06-12 07:56:48.058849
# Unit test for function join_each
def test_join_each():
    parent = "testdir"
    iterable = ["dir1", "dir2", "dir3"]
    res = join_each(parent, iterable)
    assert next(res) == os.path.join(parent, iterable[0])
    assert next(res) == os.path.join(parent, iterable[1])
    assert next(res) == os.path.join(parent, iterable[2])



# Generated at 2022-06-12 07:56:50.590631
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-12 07:56:54.812537
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['foo/bar', 'baz'])) == \
           ['foo/bar', 'baz']
    assert list(join_each('foo/bar', ['baz', '.'])) == \
           ['foo/bar/baz', 'foo/bar/.']

# Generated at 2022-06-12 07:56:58.790005
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each("a", "bc")) == ("a/b", "a/c")


# This function helps find a file in a directory tree

# Generated at 2022-06-12 07:57:04.788788
# Unit test for function join_each
def test_join_each():
    test_dir = "testdir"
    paths = ("dir1", "dir2", "dir3")

    res = list(join_each(test_dir, paths))
    assert res == [
        os.path.join(test_dir, path)
        for path in paths
    ]
    assert res == [
        "testdir/dir1",
        "testdir/dir2",
        "testdir/dir3",
    ]

# Generated at 2022-06-12 07:57:08.439170
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr", ["bin", "tmp", "local", "lib"])) == [
        "/usr/bin", "/usr/tmp", "/usr/local", "/usr/lib"
    ]


# End test



# Generated at 2022-06-12 07:57:11.465823
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['/bar', '/baz'])) == ['/foo/bar', '/foo/baz']


# TODO: Implement path_join_map

# Generated at 2022-06-12 07:57:16.163755
# Unit test for function join_each
def test_join_each():
    # Make a list of paths
    lst = ['foo', 'bar', 'baz']

    # Generate a globbed iterator of paths
    actual = join_each('/tmp', lst)

    # Make a globbed list of paths
    expected = ['/tmp/foo', '/tmp/bar', '/tmp/baz']

    # Check the actual and expected lists are the same
    assert list(actual) == expected


if __name__ == "__main__":

    this_directory = os.path.dirname(os.path.abspath(__file__))
    directory_list = os.listdir(this_directory)
    directory_join = list(join_each(this_directory, directory_list))
    print(directory_list)
    print(directory_join)

    # test_join_each()

# Generated at 2022-06-12 07:57:41.819241
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/foo', ['bar', 'baz']))
    assert result == ['/foo/bar', '/foo/baz']

# Generated at 2022-06-12 07:57:46.426234
# Unit test for function join_each
def test_join_each():
    correct = ['a/b', 'a/c', 'd/b', 'd/c']
    assert list(join_each('a', ['b', 'c'])) == correct
    assert list(join_each('d', ['b', 'c'])) == correct

# Generated at 2022-06-12 07:57:48.924610
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/home", ["anna", "bob", "charly"])) == [
        "/home/anna",
        "/home/bob",
        "/home/charly",
    ]

# Generated at 2022-06-12 07:57:53.469047
# Unit test for function join_each
def test_join_each():
    path = "data"
    assert list(join_each(path, [])) == []
    assert list(join_each(path, ["one"])) == [os.path.join(path, "one")]
    assert list(join_each(path, ["one", "two"])) == \
           [os.path.join(path, "one"), os.path.join(path, "two")]



# Generated at 2022-06-12 07:57:56.287329
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', 'abcd')) == ['parent/a', 'parent/b', 'parent/c', 'parent/d']



# Generated at 2022-06-12 07:57:57.832169
# Unit test for function join_each
def test_join_each():
    dir_path = "/home/alice"
    file_list = ["document.txt", "excel.xls"]
    expected = ["/home/alice/document.txt", "/home/alice/excel.xls"]

# Generated at 2022-06-12 07:57:59.745464
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:58:01.233001
# Unit test for function join_each
def test_join_each():
    assert list(join_each(".", ["foo", "bar"])) == ["./foo", "./bar"]



# Generated at 2022-06-12 07:58:02.824007
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["my", "dir"])) == ["/my", "/dir"]



# Generated at 2022-06-12 07:58:05.937493
# Unit test for function join_each
def test_join_each():
    test_input = ("/", "etc", "passwd")
    test_expected_output = "/etc/passwd"
    assert list(join_each(*test_input))[0] == test_expected_output

# Generated at 2022-06-12 07:58:56.814991
# Unit test for function join_each
def test_join_each():
    parent = '/'
    iterable = ('tmp', 'usr', 'local')
    joined = join_each(parent, iterable)
    results = tuple(joined)
    expected = tuple(os.path.join(parent, p) for p in iterable)
    assert results == expected



# Generated at 2022-06-12 07:58:59.736122
# Unit test for function join_each
def test_join_each():
    assert next(join_each('a', ['b', 'c'])) == 'a/b'
    assert next(join_each('a', ['b', 'c'])) == 'a/c'
    assert next(join_each('a', ['b', 'c'])) == 'a/d'



# Generated at 2022-06-12 07:59:02.945849
# Unit test for function join_each
def test_join_each():
    assert [os.path.join('.', 'path', 'one'),
            os.path.join('.', 'path', 'two'),
            os.path.join('.', 'path', 'three')] == list(join_each('.', ['path', 'one', 'two', 'three']))



# Generated at 2022-06-12 07:59:13.665196
# Unit test for function join_each
def test_join_each():
    parent = os.path.join('test_parent')
    children = ['a', 'b', 'c']
    assert list(join_each(parent, children)) == [
        os.path.join('test_parent', 'a'),
        os.path.join('test_parent', 'b'),
        os.path.join('test_parent', 'c')
    ]


file_extensions = {
    'audio': ['.mp3', '.m4a', '.flac', '.wav', '.wma'],
    'video': ['.mp4', '.wmv', '.flv'],
    'image': ['.png', '.jpg'],
    'text': ['.txt', '.doc', '.docx', '.rtf'],
    'ebook': ['.epub']
}



# Generated at 2022-06-12 07:59:16.473894
# Unit test for function join_each
def test_join_each():
    parent = "/home/user"
    names = [".", "..", "Downloads", "Examples"]

    paths = join_each(parent, names)

# Generated at 2022-06-12 07:59:19.874671
# Unit test for function join_each

# Generated at 2022-06-12 07:59:23.376863
# Unit test for function join_each
def test_join_each():
    assert list(join_each('base', ['a', 'b', 'c'])) == ['base/a', 'base/b', 'base/c']
    assert list(join_each('base', ('a', 'b', 'c'))) == ['base/a', 'base/b', 'base/c']



# Generated at 2022-06-12 07:59:29.004629
# Unit test for function join_each
def test_join_each():
    result = join_each('data/', ['file1.txt', 'file2.txt'])
    assert next(result) == 'data/file1.txt'
    assert next(result) == 'data/file2.txt'
    with pytest.raises(StopIteration):
        next(result)
    # The next line is only executed if the previous line did
    # not raise an exception
    print('No exception was raised.')


# In this case pytest.raises(StopIteration) is not required
# because if it can successfully iterate to the end of the generator
# then it will detect that it raised a StopIteration exception.

# Generated at 2022-06-12 07:59:33.246818
# Unit test for function join_each
def test_join_each():
    assert list(join_each('abc', ['de', 'fg'])) == ['abc/de', 'abc/fg']
    assert list(join_each('/usr', ['bin', 'lib', 'local'])) == ['/usr/bin', '/usr/lib', '/usr/local']

# Generated at 2022-06-12 07:59:38.217776
# Unit test for function join_each
def test_join_each():
    parent = 'parent'

    # Test when iterable is empty.
    assert list(join_each(parent, [])) == []

    # Test full iteration.
    children = ['child_1', 'child_2', 'child_3']
    expected = [
        os.path.join(parent, child)
        for child in children
    ]
    assert list(join_each(parent, children)) == expected

# Generated at 2022-06-12 08:01:36.581020
# Unit test for function join_each
def test_join_each():
    origin_iterable = ["a", "b", "c"]
    parent = "."
    actual = join_each(parent, origin_iterable)
    expected = ["./a", "./b", "./c"]
    for e_path, a_path in zip(expected, actual):
        assert e_path == a_path



# Generated at 2022-06-12 08:01:41.294334
# Unit test for function join_each
def test_join_each():
    from itertools import chain

    actual = list(join_each('a', ['b', 'c', 'd']))
    expected = list(map(lambda x: os.path.join('a', x), ['b', 'c', 'd']))
    assert actual == expected


# This code uses itertools.chain to implement the joining

# Generated at 2022-06-12 08:01:43.182897
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child1', 'child2'])) == [
        'parent/child1', 'parent/child2']

# Generated at 2022-06-12 08:01:48.699854
# Unit test for function join_each
def test_join_each():
    # Test for join 2 elements
    expected = ["src/main/python", "src/main/java"]
    items = join_each("src", ["main/python", "main/java"])
    for i in items:
        assert i in expected
    # Test for join 3 elements with parent will start with '/'
    expected = ["/home/python", "/home/java", "/home/node"]
    items = join_each("/home", ["python", "java", "node"])
    # It should pass, but python3 can't transfer the string to unicode
    # So I use workaround
    # assert list(items) == expected
    for i in items:
        assert i in expected

# Generated at 2022-06-12 08:01:56.906375
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/var/log", ["messages", "auth.log"])) == ["/var/log/messages", "/var/log/auth.log"]
    assert list(join_each("/var/log/", ["messages", "auth.log"])) == ["/var/log/messages", "/var/log/auth.log"]
    assert list(join_each("/var/log", [""])) == ["/var/log"]
    assert list(join_each("", ["/var/log", "/etc/passwd"])) == ["/var/log", "/etc/passwd"]
    assert list(join_each("", [""])) == [""]


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-12 08:02:01.238957
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar'])) == ['/foo', '/bar']
    assert list(join_each('/', ['', 'bar'])) == ['/bar']
    assert list(join_each('/', ['foo', ''])) == ['/foo', '/']



# Generated at 2022-06-12 08:02:03.378477
# Unit test for function join_each
def test_join_each():
    assert list(join_each("./", "abcd")) == ["./a", "./b", "./c", "./d"]


# Check whether directory is empty

# Generated at 2022-06-12 08:02:12.543312
# Unit test for function join_each
def test_join_each():
    # Test 1
    assert list(join_each('/home/user', ['1', '2', '3'])) == [
        '/home/user/1', '/home/user/2', '/home/user/3']

    # Test 2
    assert list(join_each('/home/user', (i for i in range(10)))) == [
        '/home/user/0', '/home/user/1', '/home/user/2', '/home/user/3',
        '/home/user/4', '/home/user/5', '/home/user/6', '/home/user/7',
        '/home/user/8', '/home/user/9']

    # Test 3
    assert list(join_each('/home/user', [])) == []


if __name__ == '__main__':
    test_join

# Generated at 2022-06-12 08:02:15.195452
# Unit test for function join_each
def test_join_each():
    assert list(join_each(1, [2])) == [os.path.join(1, 2)]
    assert list(join_each(1, [2, 3])) == [os.path.join(1, 2), os.path.join(1, 3)]



# Generated at 2022-06-12 08:02:22.315210
# Unit test for function join_each
def test_join_each():
    # Test1: iterable being empty
    assert list(join_each('.', [])) == []

    # Test2: iterable containing one element
    assert list(join_each('.', ['file1'])) == ['./file1']

    # Test3: iterable containing 2 elements
    assert list(join_each('.', ['file1', 'file2'])) == [
        './file1', './file2']

    # Test4: parent being empty
    assert list(join_each('', ['file1', 'file2'])) == [
        'file1', 'file2']

