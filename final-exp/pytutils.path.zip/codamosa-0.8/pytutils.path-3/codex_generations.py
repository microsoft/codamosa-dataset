

# Generated at 2022-06-12 07:54:34.029998
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['user', 'local'])) == ['/home/user', '/home/local']
    assert list(join_each('/home', ['', ''])) == ['/home//home/']

# Generated at 2022-06-12 07:54:40.851048
# Unit test for function join_each
def test_join_each():
    assert join_each('/parent', ['/dir1/dir2/dir3', '/dir4/dir5/dir6']) \
        == ['/parent/dir1/dir2/dir3', '/parent/dir4/dir5/dir6']
    assert join_each('', ['/dir1/dir2/dir3', '/dir4/dir5/dir6']) \
        == ['/dir1/dir2/dir3', '/dir4/dir5/dir6']
    assert join_each('/parent', []) == []


NO_NODES = ''



# Generated at 2022-06-12 07:54:43.014202
# Unit test for function join_each
def test_join_each():
    parent = os.path.abspath('.')
    files = 'file1, file2'
    for path in join_each(parent, files.split(', ')):
        assert os.path.exists(path)



# Generated at 2022-06-12 07:54:44.554100
# Unit test for function join_each
def test_join_each():
    print(list(join_each('/', ['foo', 'bar'])))



# Generated at 2022-06-12 07:54:46.938872
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-12 07:54:53.143427
# Unit test for function join_each
def test_join_each():
    test_folder = 'test_folder'
    test_files = ['file1', 'file2', 'file3']
    paths = list(join_each(test_folder, test_files))

    assert paths[0] == os.path.join(test_folder, 'file1')
    assert paths[1] == os.path.join(test_folder, 'file2')
    assert paths[2] == os.path.join(test_folder, 'file3')



# Generated at 2022-06-12 07:54:55.872853
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo/', ['bar'])) == ['foo/bar']
    assert list(join_each('foo', ['bar', 'buzz'])) == ['foo/bar', 'foo/buzz']



# Generated at 2022-06-12 07:54:59.493520
# Unit test for function join_each
def test_join_each():
    assert list(join_each('c:/example', ['a', 'b', 'c'])) == ['c:/example/a',
                                                              'c:/example/b',
                                                              'c:/example/c']

# Generated at 2022-06-12 07:55:08.525258
# Unit test for function join_each
def test_join_each():
    base = '/foo/bar'
    tests = (
        ('local', 'foo', 'bar'),
        ('local', ('foo', 'bar')),
        ('local', ('foo',)),
        ('local', tuple()),
    )

    results = ('/foo/bar/local/foo/bar',
               '/foo/bar/local/foo/bar',
               '/foo/bar/local/foo',
               '/foo/bar/local',
               )

    for i, test in enumerate(tests):
        assert list(join_each(base, test))[0] == results[i], test


if __name__ == '__main__':
    test_join_each()
    # print list(join_each('/foo/bar/', ('x', 'y')))

# Generated at 2022-06-12 07:55:13.410276
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    items = ["one", "two", "three"]
    result = list(join_each(parent, items))
    expected = [os.path.join(parent, i) for i in items]
    assert result == expected



# Generated at 2022-06-12 07:55:18.688327
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    iterable = ['foo', 'bar']
    result = list(join_each(parent, iterable))
    assert result == [os.path.join(parent, 'foo'), os.path.join(parent, 'bar')]


# Script execution
if __name__ == '__main__':
    # execute only if run as a script
    test_join_each()

# Generated at 2022-06-12 07:55:28.897036
# Unit test for function join_each
def test_join_each():
    # List of lists
    parent = '/opt'
    data = [['a', 'b', 'c'], ['d', 'e'], ['f', 'g', 'h']]
    result = ['/opt/a', '/opt/b', '/opt/c', '/opt/d', '/opt/e',
              '/opt/f', '/opt/g', '/opt/h']
    generated_result = list(join_each(parent, data))
    error_message = '{} != {}'.format(generated_result, result)
    assert generated_result == result, error_message
    # List of tuples
    data = [('a', 'b', 'c'), ('d', 'e'), ('f', 'g', 'h')]

# Generated at 2022-06-12 07:55:32.672694
# Unit test for function join_each
def test_join_each():
    parent = '/home/somebody'
    iterable = ['/var', '/etc', '/var/log']
    expect = ['/home/somebody/var', '/home/somebody/etc',
              '/home/somebody/var/log']
    assert list(join_each(parent, iterable)) == expect

# Generated at 2022-06-12 07:55:35.553377
# Unit test for function join_each
def test_join_each():
    result = list(join_each("/tmp", ["a", "b", "c"]))
    assert result == [
        "/tmp/a",
        "/tmp/b",
        "/tmp/c",
    ]



# Generated at 2022-06-12 07:55:39.246213
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp/xtandem', ['a.xml', 'b.xml', 'c.xml'])) == [
        '/tmp/xtandem/a.xml', '/tmp/xtandem/b.xml', '/tmp/xtandem/c.xml']



# Generated at 2022-06-12 07:55:42.132476
# Unit test for function join_each
def test_join_each():
    assert [p for p in join_each("/", ["home", "test", "1", "2/5"])] == [
        "/home", "/test", "/1", "/2/5"
    ]

# Generated at 2022-06-12 07:55:44.322999
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz"])) == ["foo/bar", "foo/baz"]



# Generated at 2022-06-12 07:55:46.490135
# Unit test for function join_each
def test_join_each():
    assert list(join_each('c:/', ['a', 'b'])) == ['c:/a', 'c:/b']



# Generated at 2022-06-12 07:55:55.870962
# Unit test for function join_each
def test_join_each():
    assert "." == os.path.normpath(os.path.join(".", "."))
    assert "./a" == os.path.normpath(os.path.join(".", "a"))
    assert "./a/b.txt" == os.path.normpath(os.path.join(".", "a",
                                                        "b.txt"))
    assert "." == os.path.normpath(os.path.join([".", "."]))
    assert "./a" == os.path.normpath(os.path.join([".", "a"]))
    assert "./a/b.txt" == os.path.normpath(os.path.join([".", "a",
                                                        "b.txt"]))


# Generated at 2022-06-12 07:55:58.235477
# Unit test for function join_each
def test_join_each():
    for value in join_each("a", ["b", "c"]):
        print(value)



# Generated at 2022-06-12 07:56:04.356831
# Unit test for function join_each
def test_join_each():
    print('Test Join Each')
    assert tuple(join_each('/etc', ('passwd', 'group', 'shadow'))) == ('/etc/passwd',
                                                                       '/etc/group',
                                                                       '/etc/shadow')



# Generated at 2022-06-12 07:56:09.090933
# Unit test for function join_each
def test_join_each():
    parent = r"C:\project\examples"
    iterable = ("a", "b")
    expected = [r"C:\project\examples\a", r"C:\project\examples\b"]
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-12 07:56:13.926336
# Unit test for function join_each
def test_join_each():
    expected = [
        '/home/brodie/a.py',
        '/home/brodie/b.py',
        '/home/brodie/c.py',
    ]
    actual = list(join_each('/home/brodie', ['a.py', 'b.py', 'c.py']))
    assert expected == actual



# Generated at 2022-06-12 07:56:17.142210
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/var/lib", "foo", "bar")) == [
        "/var/lib/foo", "/var/lib/bar"
    ]  # noqa



# Generated at 2022-06-12 07:56:19.262808
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ('src', 'test'))) == ['./src', './test']

# Generated at 2022-06-12 07:56:25.519660
# Unit test for function join_each
def test_join_each():
    # The function is not tested, as it contains no logic,
    # but if the function is ever changed, the test below
    # will fail
    assert list(join_each('/usr/local', ['bin', 'src'])) == \
           ['/usr/local/bin', '/usr/local/src']

    assert list(join_each('/usr/local', [''])) == \
           ['/usr/local']

    assert list(join_each('/usr/local', [])) == \
           []



# Generated at 2022-06-12 07:56:27.150342
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']



# Generated at 2022-06-12 07:56:35.789946
# Unit test for function join_each
def test_join_each():
    test_cases = [
        ('/home', ['user1', 'user2'],
         ['/home/user1', '/home/user2']),
        ('/home', ('user1', 'user2'),
         ['/home/user1', '/home/user2']),
        ('/home', {'user1', 'user2'},
         ['/home/user1', '/home/user2']),
        ('/home', {'user1': '123', 'user2': '456'},
         ['/home/user1', '/home/user2']),
    ]

    for parent, iterable, result in test_cases:
        assert list(join_each(parent, iterable)) == result



# Generated at 2022-06-12 07:56:42.909692
# Unit test for function join_each
def test_join_each():
    parent = '/home/pkage/data'
    children = ['a/b/c', 'd/e/f', 'g/h/i']
    
    result = join_each(parent, children)
    assert list(result) == ['/home/pkage/data/a/b/c', 
                            '/home/pkage/data/d/e/f',
                            '/home/pkage/data/g/h/i']


# 파일 정보를 담을 클래스
# 각각의 속성: 파일이름, 파일 크기, 파일 수

# Generated at 2022-06-12 07:56:46.165480
# Unit test for function join_each
def test_join_each():
    result = list(join_each("/a/b/c", ["d", "e", "f"]))
    assert result == ["/a/b/c/d", "/a/b/c/e", "/a/b/c/f"]



# Generated at 2022-06-12 07:56:53.606839
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["a", "b", "c"])) == ["/a", "/b", "/c"]

# Generated at 2022-06-12 07:56:54.921344
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['a', 'b'])) == ['./a', './b']



# Generated at 2022-06-12 07:56:58.789768
# Unit test for function join_each
def test_join_each():
    x = join_each('mydir', 'one two three'.split())
    assert list(x) == ['mydir/one', 'mydir/two', 'mydir/three']

# Generated at 2022-06-12 07:57:02.702414
# Unit test for function join_each
def test_join_each():
    y = ['test.txt', 'test.txt', 'test.txt', 'test.txt']
    x = join_each('./', ['test.txt', 'test.txt', 'test.txt', 'test.txt'])
    assert x == y



# Generated at 2022-06-12 07:57:06.095416
# Unit test for function join_each
def test_join_each():
    """Test function join_each."""
    path = join_each("foo", ["bar", "baz"])
    assert next(path) == "foo/bar"
    assert next(path) == "foo/baz"



# Generated at 2022-06-12 07:57:10.429751
# Unit test for function join_each
def test_join_each():
    assert(list(join_each(os.path.sep, ["home", "user"])) ==
           [os.path.join(os.path.sep, "home"), os.path.join(os.path.sep, "user")]
           )


# Main function

# Generated at 2022-06-12 07:57:13.301170
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", "bc")) == ["a/b", "a/c"]


# Helper function to compute a path relative to the directory containing
# the script.  This is only useful in scripts that are run directly.

# Generated at 2022-06-12 07:57:14.333252
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'bin'])) == ['/tmp/a', '/tmp/bin']



# Generated at 2022-06-12 07:57:17.271248
# Unit test for function join_each
def test_join_each():
    parent = './test'
    children = ['a', 'b', 'c']
    expected = ['./test/a', './test/b', './test/c']
    for a, b in zip(join_each(parent, children), expected):
        assert a == b



# Generated at 2022-06-12 07:57:19.898644
# Unit test for function join_each
def test_join_each():
    assert list(join_each("hello", [])) == []
    assert list(join_each("hello", ["world"])) == ["hello" + os.sep + "world"]



# Generated at 2022-06-12 07:57:28.311669
# Unit test for function join_each
def test_join_each():
    parent = '.'
    iterable = ['1', '2', '3']
    assert list(join_each(parent, iterable)) == ['1', '2', '3']



# Generated at 2022-06-12 07:57:30.926394
# Unit test for function join_each
def test_join_each():
    assert 'foo/bar' in join_each('foo', ['bar', 'baz'])
    assert all(os.path.join('foo', p) in join_each('foo', ['bar', 'baz'])
               for p in ['bar', 'baz'])



# Generated at 2022-06-12 07:57:33.179264
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ('bar', 'baz'))) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:57:41.043659
# Unit test for function join_each
def test_join_each():
    # Parent
    parent = 'C:\\Users\\admin\\Documents'
    # Children
    children = ['kite.txt', 'raptor.txt', 'owl.txt']

    # Joining children to parent
    check_list = [os.path.join(parent, child) for child in children]
    gen_list = [x for x in join_each(parent, children)]

    # Testing if lists are equal
    assert check_list == gen_list


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    test_join_each()

# Generated at 2022-06-12 07:57:43.479327
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:57:47.748472
# Unit test for function join_each
def test_join_each():
    join_paths = join_each('foo', ['bar.txt', 'baz.jpg'])
    assert next(join_paths) == 'foo/bar.txt'
    assert next(join_paths) == 'foo/baz.jpg'



# Generated at 2022-06-12 07:57:49.904905
# Unit test for function join_each
def test_join_each():
    assert list(join_each(
        "/tmp",
        ["foo", "bar"]
    )) == [
        "/tmp/foo",
        "/tmp/bar",
    ]

# Generated at 2022-06-12 07:57:59.336962
# Unit test for function join_each
def test_join_each():
    # Given
    path = r'/dir_a/dir_b'
    files = ['a.txt', 'b.txt', 'c.txt']

    # When
    joined_files = join_each(path, files)

    # Then
    assert list(joined_files) == [r'/dir_a/dir_b/a.txt',
                                  r'/dir_a/dir_b/b.txt',
                                  r'/dir_a/dir_b/c.txt']


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-12 07:58:01.748156
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ('a.txt', 'b.txt', 'c.txt'))) == \
           ['/home/a.txt', '/home/b.txt', '/home/c.txt']

# Generated at 2022-06-12 07:58:05.985416
# Unit test for function join_each
def test_join_each():
    parent = '/'
    iterable = ('etc', 'usr', 'tmp')

    result = join_each(parent, iterable)
    assert next(result) == '/etc'
    assert next(result) == '/usr'
    assert next(result) == '/tmp'
    assert list(result) == []

# Generated at 2022-06-12 07:58:20.031435
# Unit test for function join_each
def test_join_each():
    assert list(join_each('path/to/', ('file1', 'file2', 'file3'))) == ['path/to/file1', 'path/to/file2',
                                                                        'path/to/file3']



# Generated at 2022-06-12 07:58:23.857496
# Unit test for function join_each
def test_join_each():
    parent = 'foo'
    iterable = [
        'bar',
        'baz',
    ]
    actual = list(join_each(parent, iterable))
    expected = [
        os.path.join(parent, 'bar'),
        os.path.join(parent, 'baz'),
    ]
    assert actual == expected



# Generated at 2022-06-12 07:58:26.876702
# Unit test for function join_each
def test_join_each():
    actual_result = list(join_each('/home', ['user', 'dcjones']))
    expected_result = ['/home/user', '/home/dcjones']
    assert actual_result == expected_result



# Generated at 2022-06-12 07:58:28.993177
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('foo', ['bar', 'baz'])) == ('foo\\bar', 'foo\\baz')



# Generated at 2022-06-12 07:58:38.293576
# Unit test for function join_each
def test_join_each():
    test_data = {
        ('/home/', ['foo/', 'bar']): ['/home/foo/', '/home/bar'],
        ('/usr', []): [],
        ('.', ['main.py']): ['main.py'],
        ('.', ['a/main.py']): ['a/main.py'],
        ('/usr', ['lib', 'bin', 'share']):
        ['/usr/lib', '/usr/bin', '/usr/share']
    }
    for (parent, iterable), expected in test_data.items():
        actual = list(join_each(parent, iterable))
        assert actual == expected

# Generated at 2022-06-12 07:58:41.988441
# Unit test for function join_each
def test_join_each():
    # Test to see if the method returns a generator object
    # that returns all the joined pathnames
    parent = 'data'
    children = ['a', 'b', 'c']
    assert list(join_each(parent, children)) == ['data/a', 'data/b', 'data/c']

# Generated at 2022-06-12 07:58:50.799753
# Unit test for function join_each
def test_join_each():
    # setup
    expected = [
        '/a/b.c',
        '/a/d/e.f',
        '/a/d/g.h',
        '/a/i.j',
        '/a/k/l.m',
        '/a/k/n.o',
    ]
    # execute
    actual = list(join_each('/a', ('b.c', ('d/e.f', 'd/g.h'), ('i.j', ('k/l.m', 'k/n.o')))))
    # verify
    assert expected == actual



# Generated at 2022-06-12 07:58:52.702333
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['usr', 'lib'])) == ['/usr', '/lib']



# Generated at 2022-06-12 07:59:00.098001
# Unit test for function join_each
def test_join_each():
    from os.path import join
    from math import pi
    from nose.tools import assert_equal
    from .. import join_each

    # Test with an iterable.
    assert_equal(join_each('/home', ('jbarnoud', 'openalea')), [
        join('/home', 'jbarnoud'),
        join('/home', 'openalea'),
    ])

    # Test with a generator.
    assert_equal(join_each('/home', ('jbarnoud', 'openalea')), (
        join('/home', 'jbarnoud'), join('/home', 'openalea')
    ))

    # Test with a dict.

# Generated at 2022-06-12 07:59:09.827190
# Unit test for function join_each
def test_join_each():
    """
    Test function  join_each
    :return:
    """
    parent = "/home/user"
    iterable = ["test1", "test2"]
    # test = list(join_each(parent, iterable))
    # test = map(lambda item: os.path.join(parent, item), iterable)
    # test = map(lambda item: parent + os.sep + item, iterable)
    test = map(lambda item: os.path.join(parent, item), iterable)

    # Generator map ( no matter which form)
    # print test.next()
    # print test.next()
    # print test.next()

    # List
    # for i in test:
    #     print i



# Generated at 2022-06-12 07:59:37.767869
# Unit test for function join_each
def test_join_each():
    data = ('a.txt', 'b.txt')
    expected = ('root/a.txt', 'root/b.txt')
    actual = join_each('root', data)
    assert tuple(expected) == tuple(actual)

# Generated at 2022-06-12 07:59:46.640579
# Unit test for function join_each
def test_join_each():
    # Test 1:
    # Test if it will return the same as os.path.join
    p = r'valid\path'
    iterable = ('file1', 'file2', 'file3')
    test = join_each(p, iterable)
    assert next(test) == os.path.join(p, iterable[0])
    assert next(test) == os.path.join(p, iterable[1])
    assert next(test) == os.path.join(p, iterable[2])

    # Test 2:
    # Test if it will return the same as os.path.join if paths are full instead of relative
    iterable = (r'path\to\file1', r'path\to\file2', r'path\to\file3')
    test = join_each(p, iterable)

# Generated at 2022-06-12 07:59:50.501474
# Unit test for function join_each
def test_join_each():
    root = '/root/dir'
    paths = ['a', 'b', 'c']
    assert list(join_each(root, paths)) == [
        '/root/dir/a',
        '/root/dir/b',
        '/root/dir/c',
    ]

# Generated at 2022-06-12 07:59:54.181911
# Unit test for function join_each
def test_join_each():
    parent = '/home/user/'
    iterable = ['subfolder1', 'subfolder2', 'subfolder3']
    joined = list(join_each(parent, iterable))
    expected = ['/home/user/subfolder1', '/home/user/subfolder2',
                '/home/user/subfolder3']
    assert joined == expected



# Generated at 2022-06-12 07:59:56.442765
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each("/tmp", ("foo", "bar"))) == (
        "/tmp/foo",
        "/tmp/bar",
    )

# Generated at 2022-06-12 08:00:02.219720
# Unit test for function join_each
def test_join_each():
    parent = '/'
    iterable = ['etc', 'var', 'usr', 'bin']
    assert '/bin' in join_each(parent, iterable)
    assert '/etc' in join_each(parent, iterable)
    assert '/var' in join_each(parent, iterable)
    assert '/usr' in join_each(parent, iterable)


# Test for function join_each with a different path

# Generated at 2022-06-12 08:00:05.693851
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/tmp", ('file.txt', 'file2.txt'))) == ['/tmp/file.txt', '/tmp/file2.txt']

# Generated at 2022-06-12 08:00:10.263293
# Unit test for function join_each
def test_join_each():
    paths = ['/a/b/c', '/a/b/d']

    expected = (os.path.join('/', x) for x in paths)
    result = join_each('/', paths)
    assert len(list(result)) == len(list(expected)) is True

    for a, b in zip(result, expected):
        assert a == b



# Generated at 2022-06-12 08:00:13.708160
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == [
        '/tmp/a',
        '/tmp/b',
        '/tmp/c'
    ]



# Generated at 2022-06-12 08:00:15.578829
# Unit test for function join_each
def test_join_each():
    assert list(join_each("a", ["b", "c"])) == ["a/b", "a/c"]

# Generated at 2022-06-12 08:01:21.002778
# Unit test for function join_each
def test_join_each():
    parent = '/etc/'
    iterable = ['passwd', 'fstab', 'init.d']
    expected = ['/etc/passwd', '/etc/fstab', '/etc/init.d']
    assert list(join_each(parent, iterable)) == expected



# Generated at 2022-06-12 08:01:21.831108
# Unit test for function join_each
def test_join_each():
    pass



# Generated at 2022-06-12 08:01:23.784197
# Unit test for function join_each
def test_join_each():
    assert join_each("/", "123") == "/1/2/3"

# Generated at 2022-06-12 08:01:26.383097
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['a', 'b', 'c'])) == [
        'parent/a',
        'parent/b',
        'parent/c'
    ]



# Generated at 2022-06-12 08:01:30.994355
# Unit test for function join_each
def test_join_each():
    iterable = ['one', 'two', 'three']
    parent = '.'
    it = join_each(parent, iterable)
    assert it.next() == './one'
    assert it.next() == './two'
    assert it.next() == './three'
    assert it.next() == StopIteration



# Generated at 2022-06-12 08:01:32.604102
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['bar', 'baz'])) == ['/foo/bar', '/foo/baz']

# Generated at 2022-06-12 08:01:34.559067
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('.', ['..', 'bin', 'test'])) == ['../', 'bin/', 'test/'])

# Generated at 2022-06-12 08:01:38.944828
# Unit test for function join_each
def test_join_each():
    parent = "test_path"
    test_iterable = [
        "a",
        "b",
        "c",
    ]
    expected_results = [
        os.path.join(parent, i) for i in test_iterable
    ]
    assert list(join_each(parent, test_iterable)) == expected_results



# Generated at 2022-06-12 08:01:41.381793
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['foo', 'bar'])) == ['/tmp/foo', '/tmp/bar']



# Generated at 2022-06-12 08:01:43.555280
# Unit test for function join_each
def test_join_each():
    assert list(join_each("foo", ["bar", "baz", "quux"])) == ["foo/bar", "foo/baz", "foo/quux"]

# Generated at 2022-06-12 08:02:44.896071
# Unit test for function join_each
def test_join_each():
    parent = 'parent'
    children = ['child1', 'child2', 'child3']
    joined = join_each(parent, children)
    assert list(joined) == [os.path.join(parent, 'child1'), os.path.join(parent, 'child2'), os.path.join(parent, 'child3')]

    # If no children, then nothing is returned
    joined = join_each(parent, [])
    assert list(joined) == []

    # If a single child, then just the child is returned
    joined = join_each(parent, ['child'])
    assert list(joined) == [os.path.join(parent, 'child')]



# Generated at 2022-06-12 08:02:47.072955
# Unit test for function join_each

# Generated at 2022-06-12 08:02:48.820298
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 08:02:53.549844
# Unit test for function join_each
def test_join_each():
    input1 = ["./a.txt", "./b.txt", "./c.txt"]
    result = join_each(".", input1)
    expected = ["./a.txt", "./b.txt", "./c.txt"]
    for i, r in enumerate(result):
        assert (expected[i] == r)


# Main function for reading all files in a directory and
# writing the metadata to be used for the solr index

# Generated at 2022-06-12 08:02:57.761044
# Unit test for function join_each
def test_join_each():
    # Arrange
    parent = "/usr/local"
    paths = ["bin", "lib", "include", "share"]

    # Act
    result = list(join_each(parent, paths))

    # Assert
    assert ["/usr/local/bin", "/usr/local/lib", "/usr/local/include",
            "/usr/local/share"] == result


# Simple unit test using unittest

# Generated at 2022-06-12 08:03:00.522291
# Unit test for function join_each
def test_join_each():
    assert list(join_each(os.path.curdir, ['a', 'b', 'c'])) == [
        os.path.join(os.path.curdir, x) for x in ['a', 'b', 'c']]



# Generated at 2022-06-12 08:03:05.864308
# Unit test for function join_each
def test_join_each():
    """
    return an iterator of joined path
    :param parent: the parent directory
    :param iterable: iterable of child directory
    """
    paths1 = join_each("/Users/michael/Downloads/", ["a.txt", "b.txt"])
    paths2 = [os.path.join("/Users/michael/Downloads/", p) for p in ["a.txt", "b.txt"]]
    for path in paths1:
        assert path in paths2



# Generated at 2022-06-12 08:03:11.454065
# Unit test for function join_each
def test_join_each():
    """
    Test join_each function
    """
    parent = '/tmp'
    childs = ['a', 'b', 'c']
    result_list = ['/tmp/a', '/tmp/b', '/tmp/c']
    result_gen = join_each(parent, childs)
    assert result_gen
    assert list(result_gen) == result_list



# Generated at 2022-06-12 08:03:14.265794
# Unit test for function join_each
def test_join_each():
    p = '/'
    iterable = ['one', 'two', 'three']
    expected_result = ['/one', '/two', '/three']
    result = list(join_each(p, iterable))
    assert result == expected_result



# Generated at 2022-06-12 08:03:16.291952
# Unit test for function join_each
def test_join_each():
    arr = ['a', 'b']
    path = '/tmp'

    for i, j in zip(arr, join_each(path, arr)):
        assert j == os.path.join(path, i)