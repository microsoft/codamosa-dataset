

# Generated at 2022-06-12 07:54:31.051227
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/karel', ['a', 'b', 'c'])) == [
        '/home/karel/a',
        '/home/karel/b',
        '/home/karel/c',
    ]



# Generated at 2022-06-12 07:54:33.936072
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/a/b/c", ["h", "i"])) == ["/a/b/c/h", "/a/b/c/i"]



# Generated at 2022-06-12 07:54:37.657139
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['usr', 'local'])) == ['/usr', '/local']
    assert list(join_each('/home/liam', ['Desktop', 'Documents'])) == ['/home/liam/Desktop', '/home/liam/Documents']



# Generated at 2022-06-12 07:54:43.333552
# Unit test for function join_each
def test_join_each():
    path_inputs = [
        "foo",
        "bar",
        "baz",
    ]
    expected = [
        "xyz/foo",
        "xyz/bar",
        "xyz/baz",
    ]
    actual = list(join_each("xyz", path_inputs))
    assert actual == expected



# Generated at 2022-06-12 07:54:45.918408
# Unit test for function join_each
def test_join_each():
    assert list(join_each('.', ['abc', 'def', 'ghi'])) == ['abc', 'def', 'ghi']

# Generated at 2022-06-12 07:54:48.995371
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/tmp', ['a', 'b', 'c'])) == [
        '/tmp/a',
        '/tmp/b',
        '/tmp/c']



# Generated at 2022-06-12 07:54:52.729729
# Unit test for function join_each
def test_join_each():
    assert list(join_each('abc', [])) == []
    assert list(join_each('abc', ['/'])) == ['abc/']
    assert list(join_each('abc', ['de', '/'])) == ['abc/de', 'abc/']



# Generated at 2022-06-12 07:54:57.050150
# Unit test for function join_each
def test_join_each():
    result = join_each(os.path.abspath('.'), ['Ab', 'cd', 'e'])
    result = list(result)
    assert result == [
        '/home/osa/software/exercise/exercise-03/Ab',
        '/home/osa/software/exercise/exercise-03/cd',
        '/home/osa/software/exercise/exercise-03/e'
    ]



# Generated at 2022-06-12 07:55:00.575000
# Unit test for function join_each
def test_join_each():
    p = "/path"
    it = ["f1", "f2", "f3"]
    jt = [os.path.join(p, f) for f in it]
    assert list(join_each(p, it)) == jt



# Generated at 2022-06-12 07:55:04.011447
# Unit test for function join_each
def test_join_each():
    parent = "/home"
    iterable = ("foo", "bar")
    expected = ("/home/foo", "/home/bar")
    assert tuple(join_each(parent, iterable)) == expected


# Main function

# Generated at 2022-06-12 07:55:09.514379
# Unit test for function join_each
def test_join_each():
    from os import path
    assert list(join_each('.','foo bar'.split())) == list(map(path.join, ['.'] * 2, 'foo bar'.split()))
    assert list(join_each('p','f b'.split())) == list(map(path.join, ['p'] * 2, 'f b'.split()))



# Generated at 2022-06-12 07:55:15.388652
# Unit test for function join_each
def test_join_each():
    parent = os.path.dirname(__file__)
    paths = (os.path.basename(__file__), os.path.basename(__file__))
    out = join_each(parent, paths)
    assert out == (os.path.join(parent, os.path.basename(__file__)),
                   os.path.join(parent, os.path.basename(__file__)))



# Generated at 2022-06-12 07:55:17.979508
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["1", "2", "3"]
    items = join_each(parent, iterable)
    assert list(items) == [os.path.join(parent, item) for item in iterable]



# Generated at 2022-06-12 07:55:23.644734
# Unit test for function join_each
def test_join_each():
    # Empty list
    assert list(join_each('/', [])) == []
    # Only one item
    assert list(join_each('/', ['a'])) == ['/a']
    # Normal cases
    assert list(join_each('/', ['a', 'b', 'c'])) == ['/a', '/b', '/c']
    assert list(join_each('/', ['', 'b', 'c'])) == ['/', '/b', '/c']



# Generated at 2022-06-12 07:55:25.794544
# Unit test for function join_each
def test_join_each():
    assert list(join_each("root", ["c1", "c2"])) == ["root/c1", "root/c2"]



# Generated at 2022-06-12 07:55:28.704965
# Unit test for function join_each
def test_join_each():
    result = [i for i in join_each("/home", ["user", "dir"])]
    assert result == ["/home/user", "/home/dir"]


# Generated at 2022-06-12 07:55:31.931386
# Unit test for function join_each
def test_join_each():
    parent = '/home/joe'
    iterable = ["foo", "bar"]
    expected = ['/home/joe/foo', '/home/joe/bar']

    actual = list(join_each(parent, iterable))

    assert actual == expected

# Generated at 2022-06-12 07:55:33.790327
# Unit test for function join_each
def test_join_each():
    assert list(join_each('root', ('a', 'b'))) \
        == ['root/a', 'root/b']

# Generated at 2022-06-12 07:55:36.796452
# Unit test for function join_each
def test_join_each():
    parent = '../'
    iterable = ['a', 'b', 'c']
    expected = ('../a', '../b', '../c')
    assert tuple(join_each(parent, iterable)) == expected



# Generated at 2022-06-12 07:55:43.784086
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', [''])) == ['/']
    assert list(join_each('/', ['a'])) == ['/a']
    assert list(join_each('/a', ['b'])) == ['/a/b']
    assert list(join_each('/a', ['b', 'c'])) == ['/a/b', '/a/c']
    assert list(join_each('/a/', ['b', 'c'])) == ['/a/b', '/a/c']



# Generated at 2022-06-12 07:55:52.851479
# Unit test for function join_each
def test_join_each():
    parent = '/Users/Agnes/Desktop'
    iterable = ['uploads', 'result']

    for p in iterable:
        assert os.path.join(parent, p) == next(join_each(parent, iterable))


# Code


# Generated at 2022-06-12 07:55:55.002983
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ('1', '2'))) == ['/a/1', '/a/2']



# Generated at 2022-06-12 07:55:59.152889
# Unit test for function join_each
def test_join_each():
    assert [p for p in join_each('/', ['tmp', 'hello.txt'])] == [
        '/tmp',
        '/hello.txt',
    ]


# This function is used to convert a file path to a unique key.

# Generated at 2022-06-12 07:56:02.348478
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/usr", ["bin", "share"])) == ["/usr/bin", "/usr/share"]



# Generated at 2022-06-12 07:56:04.232599
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ('usr', 'bin'))) == ['/usr', '/bin']



# Generated at 2022-06-12 07:56:14.746460
# Unit test for function join_each
def test_join_each():
    test_iterable = ['hello', 'world']
    test_iterable2 = ['hello']
    expected_result = ['foo/hello', 'foo/world']
    expected_result2 = ['foo/hello']
    func_result = list(join_each('foo', test_iterable))
    func_result2 = list(join_each('foo', test_iterable2))
    try:
        assert expected_result == func_result
        assert expected_result2 == func_result2
        print('Test passed. Expected result: {0} - Function result: {1}'.format(expected_result, func_result))
    except AssertionError:
        print('Test failed. Expected result: {0} - Function result: {1}'.format(expected_result, func_result))


test_join_each()

# Generated at 2022-06-12 07:56:23.611175
# Unit test for function join_each
def test_join_each():
    assert list(join_each("data", ["a", "b", "c"])) == ["data/a", "data/b", "data/c"]
    assert list(join_each("data/", ["a", "b", "c"])) == ["data/a", "data/b", "data/c"]
    assert list(join_each("data", ["/a", "/b", "/c"])) == ["data//a", "data//b", "data//c"]
    assert list(join_each("data/", ["/a", "/b", "/c"])) == ["data///a", "data///b", "data///c"]

# Generated at 2022-06-12 07:56:26.669824
# Unit test for function join_each
def test_join_each():
    # Test 1
    parent = "Test1"
    iterable = ["A", "B", "C"]
    result = [os.path.join(parent, i) for i in iterable]
    assert list(join_each(parent, iterable)) == result



# Generated at 2022-06-12 07:56:28.922695
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['user', 'file'])) == ['/home/user', '/home/file']
    assert list(join_each('/home', [])) == []

# Generated at 2022-06-12 07:56:35.563208
# Unit test for function join_each
def test_join_each():
    test_iterable = ["sub1", "sub2", "sub3"]
    assert list(join_each("/home/user/", ["sub1", "sub2", "sub3"])) == list(join_each("/home/user/", test_iterable))
    assert list(join_each("/home/user", ["sub1", "sub2", "sub3"])) == \
           ["/home/user/sub1", "/home/user/sub2", "/home/user/sub3"]

# Generated at 2022-06-12 07:56:49.438073
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/", ["bin", "sbin"])) == ("/bin", "/sbin")



# Generated at 2022-06-12 07:56:51.794465
# Unit test for function join_each
def test_join_each():
    joined = list(join_each('test', ['a', 'b']))
    expected = ['test/a', 'test/b']
    assert joined == expected

# Generated at 2022-06-12 07:56:55.436327
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['a', 'b'])) == ['/a', '/b']
    assert list(join_each('/a/b', ['c', 'd'])) == ['/a/b/c', '/a/b/d']



# Generated at 2022-06-12 07:57:04.268778
# Unit test for function join_each
def test_join_each():
    parent = "/home/marcus/projects/bioinformatics"
    iterable = ["reading_notes", "sequencing_methods", "small_RNA"]
    actual = join_each(parent, iterable)
    expected = (
        "/home/marcus/projects/bioinformatics/reading_notes",
        "/home/marcus/projects/bioinformatics/sequencing_methods",
        "/home/marcus/projects/bioinformatics/small_RNA",
    )
    for a, e in zip(actual, expected):
        assert a == e



# Generated at 2022-06-12 07:57:07.123407
# Unit test for function join_each
def test_join_each():
    parent = ''
    iterable = ['x', 'y', 'z']
    result = list(join_each(parent, iterable))
    assert result == ['x', 'y', 'z']



# Generated at 2022-06-12 07:57:10.067346
# Unit test for function join_each
def test_join_each():
    print(list(join_each('p', ['a', 'b', 'c'])))


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-12 07:57:16.700888
# Unit test for function join_each
def test_join_each():
    # Pre-defined parent and iterable
    parent = "C:/Users/John"
    iterable = ['Desktop', 'Downloads', 'Favorites', 'Links']
    # Answer
    answer = ['C:/Users\\John/Desktop', 'C:/Users\\John/Downloads', 'C:/Users\\John/Favorites', 'C:/Users\\John/Links']
    # Get all files in the folder
    join = list(join_each(parent, iterable))
    # Check if the answer is the same as get from join_each
    for i in range(4):
        assert join[i] == answer[i]



# Generated at 2022-06-12 07:57:20.228202
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']


# Part 1:
# Write a function uniques that accepts a list of strings and returns the
# unique strings as a list, in the order that they first appear.

# Generated at 2022-06-12 07:57:24.806264
# Unit test for function join_each
def test_join_each():
    parent = '/first/second'
    iterable = ['/third', '/fourth']
    result = join_each(parent, iterable)
    assert next(result) == '/first/second/third'
    assert next(result) == '/first/second/fourth'



# Generated at 2022-06-12 07:57:27.023426
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/', ['foo', 'bar'])) == ['/foo', '/bar']



# Generated at 2022-06-12 07:57:56.196701
# Unit test for function join_each
def test_join_each():
    test = join_each('a', ['b', 'c', 'd'])
    assert list(test) == ['a/b', 'a/c', 'a/d']


# Return generator function to join each file in a directory to
# the directory path

# Generated at 2022-06-12 07:57:58.201363
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/a', ('b', 'c'))) == ['a/b', 'a/c']



# Generated at 2022-06-12 07:58:01.345543
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = ["dir", "dir2"]
    result = ["parent/dir", "parent/dir2"]

    for index, child in enumerate(join_each(parent, iterable)):
        assert child == result[index]



# Generated at 2022-06-12 07:58:03.785330
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/foo', ['bar', 'baz'])) == \
            ['/foo/bar', '/foo/baz']



# Generated at 2022-06-12 07:58:12.681478
# Unit test for function join_each
def test_join_each():
    parent = pathlib.Path('/home/guru/')
    iterable = [
        pathlib.PurePosixPath('some/dir'),
        pathlib.PurePosixPath('other/dir'),
        pathlib.PurePosixPath('some/other/dir')
    ]
    assert list(join_each(parent, iterable)) == [
        pathlib.PurePosixPath('/home/guru/some/dir'),
        pathlib.PurePosixPath('/home/guru/other/dir'),
        pathlib.PurePosixPath('/home/guru/some/other/dir')
    ]



# Generated at 2022-06-12 07:58:14.251743
# Unit test for function join_each
def test_join_each():
    assert list(join_each('..', ['test', 'text'])) == ['../test', '../text']



# Generated at 2022-06-12 07:58:15.926405
# Unit test for function join_each
def test_join_each():
    assert join_each('a', ['b', 'c']) == ['a/b', 'a/c']



# Generated at 2022-06-12 07:58:18.061160
# Unit test for function join_each
def test_join_each():
    assert join_each("dir", ["dir2", "dir3"]) == ["dir/dir2", "dir/dir3"]



# Generated at 2022-06-12 07:58:18.589585
# Unit test for function join_each
def test_join_each():
    pass



# Generated at 2022-06-12 07:58:20.270292
# Unit test for function join_each
def test_join_each():
    assert list(join_each('foo', ['bar', 'baz'])) == ['foo/bar', 'foo/baz']



# Generated at 2022-06-12 07:58:47.065426
# Unit test for function join_each
def test_join_each():
    assert list(join_each('parent', ['child', 'grandchild'])) == ['parent/child', 'parent/grandchild']

# Generated at 2022-06-12 07:58:51.713866
# Unit test for function join_each
def test_join_each():
    p = 'some/dir'
    iterable = ['a', 'b', 'c']
    joined = join_each(p, iterable)
    assert list(joined) == [
        os.path.join(p, 'a'),
        os.path.join(p, 'b'),
        os.path.join(p, 'c')
    ]

# Generated at 2022-06-12 07:58:53.777362
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home/username', ['subdir', 'subsubdir'])) == [
        os.path.join('/home/username', 'subdir'),
        os.path.join('/home/username', 'subsubdir')
    ]

# Generated at 2022-06-12 07:58:57.296372
# Unit test for function join_each
def test_join_each():
    assert list(join_each(".", ["a", "b", "c"])) == [
        "./a", "./b", "./c"
    ]
    assert list(join_each("", ["a", "b", "c"])) == [
        "a", "b", "c"
    ]

# Generated at 2022-06-12 07:58:58.552864
# Unit test for function join_each
def test_join_each():
    assert(list(join_each('/', ['foo', 'bar'])) == ['/foo', '/bar'])



# Generated at 2022-06-12 07:59:01.677261
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/opt/python", ["python3.6", "python2.7", "python3.7"])) == [
        "/opt/python/python3.6",
        "/opt/python/python2.7",
        "/opt/python/python3.7",
    ]



# Generated at 2022-06-12 07:59:05.998121
# Unit test for function join_each
def test_join_each():
    cases = [
        (('/var', ('log', 'lib')), ('/var/log', '/var/lib')),
    ]

    for (parent, iterable), expected in cases:
        actual = tuple(join_each(parent, iterable))
        assert actual == expected

# Generated at 2022-06-12 07:59:14.916718
# Unit test for function join_each
def test_join_each():
    tests = [
        {
            'parent': 'a',
            'iterable': ['a', 'b'],
            'expected': ['a/a', 'a/b']
            },
        {
            'parent': 'a/b',
            'iterable': ['a', 'b'],
            'expected': ['a/b/a', 'a/b/b']
            },
        {
            'parent': '',
            'iterable': [],
            'expected': []
            },
        ]
    for i, test in enumerate(tests):
        assert list(join_each(test['parent'], test['iterable'])) == test['expected']
        print('Done %d' % i)



# Generated at 2022-06-12 07:59:20.245575
# Unit test for function join_each
def test_join_each():
    p = '/path/to/parent/'
    path_gen = join_each(p, ['a', 'b', 'c'])

    assert next(path_gen) == '/path/to/parent/a'
    assert next(path_gen) == '/path/to/parent/b'
    assert next(path_gen) == '/path/to/parent/c'

# Generated at 2022-06-12 07:59:24.356663
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b']
    parent = 'test'
    new_iterable = join_each(parent, iterable)
    print(new_iterable)
    assert next(new_iterable) == os.path.join(parent, 'a')
    assert next(new_iterable) == os.path.join(parent, 'b')



# Generated at 2022-06-12 08:00:16.867305
# Unit test for function join_each
def test_join_each():
    # Arrange, Act, Assert
    assert list(join_each('/tmp', ['a', 'b'])) == ['/tmp/a', '/tmp/b']
    assert next(join_each('/tmp', [])) is None

# Generated at 2022-06-12 08:00:19.658197
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('a/b', ('c', 'd'))) == ('a/b/c', 'a/b/d')

# Generated at 2022-06-12 08:00:21.835540
# Unit test for function join_each
def test_join_each():
    assert ['foo/a', 'foo/b'] == list(join_each('foo', ['a', 'b']))


# Generated at 2022-06-12 08:00:28.675327
# Unit test for function join_each
def test_join_each():
    test_cases = [
        (['/', '/', '/'], ['/', 'a', 'b'], ['/', '/a', '/b']),
        (['/', '/', '/'], ['/a', 'b', '/c'], ['/a', '/a/b', '/c']),
        (['/a', '/a', '/a'], ['/b', 'c', '/d'], ['/a/b', '/a/c', '/a/d'])
    ]

    for (parent, iterable, expected) in test_cases:
        result = list(join_each(parent, iterable))
        assert result == expected


# Generated at 2022-06-12 08:00:30.290490
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each('foo', 'bar', 'baz')) == ('foo/bar', 'foo/baz')



# Generated at 2022-06-12 08:00:34.766371
# Unit test for function join_each
def test_join_each():
    parent = "root"
    list_of_children = ["a", "b", "c"]
    joined_list = list(join_each(parent, list_of_children))
    assert len(list_of_children) == len(joined_list)
    for child in list_of_children:
        assert os.path.join(parent, child) in joined_list



# Generated at 2022-06-12 08:00:37.604198
# Unit test for function join_each
def test_join_each():
    parent = "parent"
    iterable = "iterable"

    it = join_each(parent, iterable)
    assert iter(it) is it
    assert list(it) == [os.path.join(parent, p) for p in iterable]



# Generated at 2022-06-12 08:00:39.887190
# Unit test for function join_each
def test_join_each():
    assert tuple(join_each(u"/tmp", [u"a", u"b", u"c"])) == (
        u"/tmp/a", u"/tmp/b", u"/tmp/c")



# Generated at 2022-06-12 08:00:49.610917
# Unit test for function join_each
def test_join_each():
    iterable = ['a', 'b', 'c']
    parent = '~'
    joined = list(join_each(parent, iterable))
    expected = [os.path.join('~', 'a'),
                os.path.join('~', 'b'),
                os.path.join('~', 'c')]
    assert joined == expected

# test on folders and files
# list of folder and files with relative path
files = ['images/apple.jpg',
         'images/orange.jpg',
         'images/banana.jpg',
         'images/apple-banana.jpg',
         'images/apple-orange.jpg',
         'images/banana-orange.jpg',
         'images/apple-banana-orange.jpg']
old_path = os.getcwd()
new_path = os.path

# Generated at 2022-06-12 08:00:53.145635
# Unit test for function join_each
def test_join_each():
    result = list(join_each('/', ['usr', 'local']))
    assert result == ['/usr', '/local']
    result = list(join_each('/usr', []))
    assert result == []
    result = list(join_each('', ['usr', 'local']))
    assert result == ['usr', 'local']

# Generated at 2022-06-12 08:03:01.146618
# Unit test for function join_each

# Generated at 2022-06-12 08:03:07.984574
# Unit test for function join_each
def test_join_each():
    parent = 'foo'

    assert list(join_each(parent, [''])) == ['foo']
    assert list(join_each(parent, ['bar'])) == ['foo/bar']
    assert list(join_each(parent, ['bar', 'baz'])) == ['foo/bar', 'foo/baz']

    assert list(join_each('', [''])) == ['']
    assert list(join_each('', ['bar'])) == ['bar']
    assert list(join_each('', ['bar', 'baz'])) == ['bar', 'baz']

    assert list(join_each(parent, ['', 'bar', 'baz'])) == [
        'foo', 'foo/bar', 'foo/baz'
    ]


# Generated at 2022-06-12 08:03:10.484198
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/home', ['a', 'b'])) == ['/home/a', '/home/b']

# Generated at 2022-06-12 08:03:14.089441
# Unit test for function join_each
def test_join_each():
    assert list(join_each('/usr', ['bin', 'lib'])) == ['/usr/bin', '/usr/lib']
    assert list(join_each('/usr', [])) == []


# Function that returns the number of characters in a file.
# nb_chars : str -> int

# Generated at 2022-06-12 08:03:15.597860
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a' + os.sep + 'b', 'a' + os.sep + 'c']



# Generated at 2022-06-12 08:03:19.076693
# Unit test for function join_each
def test_join_each():
    parent = '/my/parent'
    iterable = ['one', 'two', 'three']
    expected = ['/my/parent/one', '/my/parent/two', '/my/parent/three']
    assert list(join_each(parent, iterable)) == expected

# Generated at 2022-06-12 08:03:24.770757
# Unit test for function join_each
def test_join_each():
    base = '/home/florent'
    expected = [
        '/home/florent/file1.txt',
        '/home/florent/file2.txt',
        '/home/florent/dir/file3.txt',
    ]

    expected = iter(expected)
    got = join_each(base, [
        'file1.txt',
        'file2.txt',
        os.path.join('dir', 'file3.txt'),
    ])

    for a, b in zip(expected, got):
        assert a == b


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-12 08:03:27.415889
# Unit test for function join_each
def test_join_each():
    parent = os.path.dirname(__file__)
    assert list(join_each(parent, ['a', 'b'])) == [os.path.join(parent, 'a'), os.path.join(parent, 'b')]

# Generated at 2022-06-12 08:03:29.490912
# Unit test for function join_each
def test_join_each():
    assert list(join_each("/etc", ["passwd", "group"])) == [
        '/etc/passwd',
        '/etc/group',
    ]



# Generated at 2022-06-12 08:03:30.928860
# Unit test for function join_each
def test_join_each():
    assert next(join_each("foo", ["bar", "baz"])) == "foo/bar"

