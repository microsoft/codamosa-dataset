

# Generated at 2022-06-26 02:38:57.377595
# Unit test for function join_each
def test_join_each():
    assert test_case_0() == '....'

# Generated at 2022-06-26 02:39:00.056872
# Unit test for function join_each
def test_join_each():
    str_0 = ".MI'"
    var_0 = join_each(str_0, str_0)
    assert var_0.__next__() == ".MI'.MI'"

# Generated at 2022-06-26 02:39:05.893966
# Unit test for function join_each
def test_join_each():
    try:
        print("Testing join_each...", end="")
        str_0 = ".MI'"
        var_0 = join_each(str_0, str_0)
        for p in var_0:
            print('"', p, '"', sep='')

        print("Passed.")
    except:
        print("Failed")



# Generated at 2022-06-26 02:39:08.893343
# Unit test for function join_each
def test_join_each():
    str_0 = "parent"
    list_0 = ["a", "b", "c", "d"]
    for i in range(1, 10):
        test_case_0()
# test_join_each()

# Generated at 2022-06-26 02:39:10.888350
# Unit test for function join_each
def test_join_each():
    test_case_0()


if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-26 02:39:13.281077
# Unit test for function join_each

# Generated at 2022-06-26 02:39:15.092086
# Unit test for function join_each
def test_join_each():
    assert all(join_each(".MI'", ".MI'") == (".MI'.MI'",))

test_join_each()

# Generated at 2022-06-26 02:39:26.680755
# Unit test for function join_each
def test_join_each():
    assert str(list(join_each("/tmp", ["file_1", "file_2"]))) == "['/tmp/file_1', '/tmp/file_2']"

    assert str(list(join_each("/tmp", ["file_1"]))) == "['/tmp/file_1']"

    assert str(list(join_each("/tmp", ["file_1", "file_2", "file_3"]))) == "['/tmp/file_1', '/tmp/file_2', '/tmp/file_3']"


# Generated at 2022-06-26 02:39:33.639346
# Unit test for function join_each
def test_join_each():
    str_0 = ".MI'"
    var_0 = join_each(str_0, str_0)
    """
    if not (var_0.__next__() == ".MMII'" and var_0.__next__() == ".MM'I'" and var_0.__next__() == ".MI''" and var_0.__next__() == ".MI'I'"):
        fail(var_0)"""
    assert var_0.__next__() == ".MMII'" and var_0.__next__() == ".MM'I'" and var_0.__next__() == ".MI''" and var_0.__next__() == ".MI'I'"

# Generated at 2022-06-26 02:39:35.668817
# Unit test for function join_each
def test_join_each():
    assert next(join_each("a", ["b", "c"])) == "a/b"
    assert next(join_each("a", ["b", "c"])) == "a/c"

