

# Generated at 2022-06-26 02:38:57.283553
# Unit test for function join_each
def test_join_each():
    print("Unit test for join_each")
    test_case_0()
    print("Successful pass")


# run test case
test_join_each()

# Generated at 2022-06-26 02:38:59.097761
# Unit test for function join_each
def test_join_each():
    assert isinstance(join_each(None, None, None), util.Iterator)




# Generated at 2022-06-26 02:39:06.541352
# Unit test for function join_each
def test_join_each():
    a = [5,5,5,5]
    b = ['yolo','yolo','yolo','yolo']
    c = ['lmao','lmao','lmao','lmao']
    d = [['yolo','lmao'],['yolo','lmao'],['yolo','lmao'],['yolo','lmao']]
    e = join_each(a,d)
    assert set(e) == set(d)


# Generated at 2022-06-26 02:39:08.731114
# Unit test for function join_each
def test_join_each():
    assert(os.path.join('.', 'spam.txt') == join_each('.', ['spam.txt']))

# Generated at 2022-06-26 02:39:10.139826
# Unit test for function join_each
def test_join_each():
    assert join_each('','abc') == 'abc'


# Generated at 2022-06-26 02:39:16.277179
# Unit test for function join_each
def test_join_each():
    print("Unit Tests for function join_each")

    # Arrange
    parent = "."
    iterable = ["a", "b", "c"]

    # Act
    actual = join_each(parent, iterable)

    # Assert
    expected = ["./a", "./b", "./c"]

    for e, a in zip(expected, actual):
        assert a == e

    # Arrange
    parent = "a"
    iterable = ["b/c", "b/d", "e/f", "e/g"]

    # Act
    actual = join_each(parent, iterable)

    # Assert
    expected = ["a/b/c", "a/b/d", "a/e/f", "a/e/g"]


# Generated at 2022-06-26 02:39:28.123014
# Unit test for function join_each
def test_join_each():
    assert join_each(None, None) == None
    assert join_each("/home", ["dir", "dir2"]) == ["/home/dir", "/home/dir2"]
    assert join_each("/home", [None, "dir2"]) == ["/home/None", "/home/dir2"]
    assert join_each("/home", ["dir", None]) == ["/home/dir", "/home/None"]
    assert join_each("/home", [None, None]) == ["/home/None", "/home/None"]
    assert join_each("/home", [3, None]) == ["/home/3", "/home/None"]
    assert join_each("/home", [None, 3]) == ["/home/None", "/home/3"]

# Generated at 2022-06-26 02:39:40.235574
# Unit test for function join_each

# Generated at 2022-06-26 02:39:43.865465
# Unit test for function join_each
def test_join_each():
    assert join_each is None


# Generated at 2022-06-26 02:39:52.167617
# Unit test for function join_each
def test_join_each():
    assert join_each(0, 0) == iter([])
    assert join_each(0, {0}) == iter([])
    assert join_each(0, [0]) == iter([])
    assert join_each(0, {0:0}) == iter([])
    assert join_each(0, (0, 0)) == iter([])
    assert join_each(0, xrange(0)) == iter([])
    assert join_each(0, (0 for x in xrange(0))) == iter([])
    assert join_each('', '') == iter([])
    assert join_each('', '0') == iter([])
    assert join_each('', '0') == iter([])
    assert join_each('', '0') == iter([])
    assert join_each('', '0') == iter([])
   

# Generated at 2022-06-26 02:40:02.534257
# Unit test for function join_each
def test_join_each():

    file_list = ['file_1', 'file_2', 'file_3', 'file_4']
    path1 = 'folder_1'
    path2 = 'folder_2'
    path3 = 'folder_3'

    new_file_list = ['folder_1/file_1', 'folder_1/file_2', 'folder_2/file_3',
                     'folder_3/file_4']

    new_file_list_from_join_each = list(join_each(path1, file_list))

    assert new_file_list == new_file_list_from_join_each

    for i, each in enumerate(new_file_list_from_join_each[2:]):
        assert each == file_list[i + 2]
        print(i)
        print(each)


# Generated at 2022-06-26 02:40:12.177484
# Unit test for function join_each
def test_join_each():

    with pytest.raises(Exception) as e:
        test_case_0()
    assert e.type == TypeError
    assert e.value.args[0] == "str expected"

# Generated at 2022-06-26 02:40:21.989571
# Unit test for function join_each
def test_join_each():
    list_0 = []
    list_0.append("../Output/Global/20171006/VIA/Doughnut/20171006_Doughnut_VIA_0.jpg")
    list_1 = []
    list_1.append("../Output/Global/20171006/VIA/Doughnut/20171006_Doughnut_VIA_0.jpg")
    assert join_each(list_0, list_1) == ['../Output/Global/20171006/VIA/Doughnut/20171006_Doughnut_VIA_0.jpg/../Output/Global/20171006/VIA/Doughnut/20171006_Doughnut_VIA_0.jpg']

# Generated at 2022-06-26 02:40:34.034301
# Unit test for function join_each
def test_join_each():
    assert func(join_each)




if __name__ == "__main__":
    import sys
    import os
    py_file_name = os.path.basename(__file__)
    if len(sys.argv) > 1 and sys.argv[1] in ['-v', '--verbose']:
        print('Test Cases for ', py_file_name)
        for fun in [x for x in list(globals().keys()) if x.startswith('test_')]:
            callable = globals()[fun]
            print('\nTesting {0} : {1}'.format(fun, callable))
            callable()
    elif len(sys.argv) > 1 and sys.argv[1] in ['--version', '-V']:
        print(__version__)

# Generated at 2022-06-26 02:40:36.893994
# Unit test for function join_each
def test_join_each():
    try:
        test_case_0()
    except:
        assert False



# Generated at 2022-06-26 02:40:40.842779
# Unit test for function join_each
def test_join_each():
    parent = os.getcwd()
    iterable = [parent]
    result = list(join_each(parent, iterable))
    assert result == [parent]

# Generated at 2022-06-26 02:40:52.936723
# Unit test for function join_each

# Generated at 2022-06-26 02:40:55.896920
# Unit test for function join_each
def test_join_each():
    test_case_0()

if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-26 02:40:57.248846
# Unit test for function join_each
def test_join_each():
    assert join_each(None, None) == ()

# Generated at 2022-06-26 02:40:59.311053
# Unit test for function join_each
def test_join_each():
    assert join_each == "success"