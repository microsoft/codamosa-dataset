

# Generated at 2022-06-26 02:38:59.157941
# Unit test for function join_each
def test_join_each():
    assert hasattr(join_each, "__call__")
    assert join_each(4, [2, 3]) == [4, 4]


# Generated at 2022-06-26 02:39:05.839347
# Unit test for function join_each
def test_join_each():
    str_0 = '^q2E*\x0c6c^BS\tp\x0bS_:'
    var_0 = join_each(str_0, str_0)
    assert str_0 == '^q2E*\x0c6c^BS\tp\x0bS_:'
    assert var_0 == 'S_:S_:S_:S_:'

# Test main branching

# Generated at 2022-06-26 02:39:08.840654
# Unit test for function join_each
def test_join_each():
    assert join_each("asdf", ["a","b"]) == join_each("asdf", ["a","b"])


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 02:39:11.962556
# Unit test for function join_each
def test_join_each():
    str_0 = 'hello world'

    result_0 = join_each(str_0, [''])
    expected_0 = 'hello world'

    assert result_0 == expected_0


# Generated at 2022-06-26 02:39:16.875883
# Unit test for function join_each
def test_join_each():
    assert str(test_case_0()) == '^q2E*\x0c6c^BS\tp\x0bS_:^q2E*\x0c6c^BS\tp\x0bS_:'



if __name__ == "__main__":
    test_case_0()

    print(str(test_case_0()))

# Generated at 2022-06-26 02:39:17.879484
# Unit test for function join_each
def test_join_each():
    test_case_0()




# Generated at 2022-06-26 02:39:18.870750
# Unit test for function join_each
def test_join_each():
    test_case_0()


# Generated at 2022-06-26 02:39:29.385200
# Unit test for function join_each
def test_join_each():
    str_0 = '^q2E*\x0c6c^BS\tp\x0bS_:'
    var_0 = join_each(str_0, str_0)
    assert var_0 == ['^q2E*\x0c6c^BS\tp\x0bS_:^q2E*\x0c6c^BS\tp\x0bS_:']
    str_0 = '9"\x01%c^j.<'
    var_0 = join_each(str_0, str_0)
    assert var_0 == ['9"\x01%c^j.<9"\x01%c^j.<']


# Generated at 2022-06-26 02:39:30.899250
# Unit test for function join_each
def test_join_each():
    print('Testing join_each')

    assert_equal(test_join_each(), None)

    print('Passed.')

# ------------
# Test Runner
# ------------

# Generated at 2022-06-26 02:39:40.178018
# Unit test for function join_each
def test_join_each():
    str_0 = '^q2E*\x0c6c^BS\tp\x0bS_:'
    var_0 = join_each(str_0, str_0)

    assert '^q2E*\x0c6c^BS\tp\x0bS_:^q2E*\x0c6c^BS\tp\x0bS_:' == ''.join(list(var_0))
    assert '^q2E*\x0c6c^BS\tp\x0bS_:^q2E*\x0c6c^BS\tp\x0bS_:' == ''.join(list(var_0))

