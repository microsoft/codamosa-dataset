

# Generated at 2022-06-26 02:38:55.303864
# Unit test for function join_each
def test_join_each():
    test_case_0()

# Generated at 2022-06-26 02:38:56.867880
# Unit test for function join_each
def test_join_each():
    test_case_0()


test_join_each()

# Generated at 2022-06-26 02:39:04.815325
# Unit test for function join_each
def test_join_each():
    # Test when argument is str
    assert join_each('/', ['test.py', 'test_case.py']) == \
    ['/test.py', '/test_case.py']
    # Test when argument is list
    assert join_each('/', ['test.py', 'test_case.py']) == \
    ['/test.py', '/test_case.py']
    # Test when argument is tuple
    assert join_each('/', ['test.py', 'test_case.py']) == \
    ['/test.py', '/test_case.py']

# Generated at 2022-06-26 02:39:09.788277
# Unit test for function join_each
def test_join_each():
    assert all([x == y for x, y in zip(join_each(True, "K5] itAr`='"), [True, 'K', True, '5', True, ']', True, ' ', True, 'i', True, 't', True, 'A', True, 'r', True, '`', True, '=', True, "'"])])

# Generated at 2022-06-26 02:39:12.066167
# Unit test for function join_each

# Generated at 2022-06-26 02:39:13.653533
# Unit test for function join_each
def test_join_each():
    assert join_each(False, []) == join_each(True, [])


# Generated at 2022-06-26 02:39:20.126062
# Unit test for function join_each
def test_join_each():

    bool_0 = True
    str_0 = "K5] itAr`='"
    var_0 = join_each(bool_0, str_0)
    print("var_0")
    print(var_0)
    print("type(var_0)")
    print(type(var_0))

    for s in var_0:
        print("s")
        print(s)

    assert(isinstance(var_0, type(str_0)))

if __name__ == "__main__":
    test_join_each()

# Generated at 2022-06-26 02:39:31.172050
# Unit test for function join_each
def test_join_each():
    assert join_each(False, False) == False
    assert join_each(False, True) == True
    assert join_each(False, "str") == "str" # <Type 'str'>
    assert join_each(False, 10) == 10 # <Type 'int'>
    assert join_each(False, 10.0) == 10.0 # <Type 'float'>
    assert join_each(False, [10]) == [10] # <Type 'list'>
    assert join_each(False, (10,)) == (10,) # <Type 'tuple'>
    assert join_each(False, [10]) == [10] # <Type 'list'>
    assert join_each(False, {10}) == {10} # <Type 'set'>
    assert join_each(False, {"key": 10}) == {"key": 10}

# Generated at 2022-06-26 02:39:38.390259
# Unit test for function join_each
def test_join_each():
    # Test 0
    bool_0 = True
    str_0 = "K5] itAr`='"
    var_0 = join_each(bool_0, str_0)
    assert_equals([True, 'K'], list(var_0))

    # Test 1
    bool_1 = False
    str_1 = "NQO<)d"
    var_1 = join_each(bool_1, str_1)
    assert_equals([False, 'N'], list(var_1))

    # Test 2
    bool_2 = False
    str_2 = "u4t"
    var_2 = join_each(bool_2, str_2)
    assert_equals([False, 'u'], list(var_2))

    # Test 3
    bool_3 = False


# Generated at 2022-06-26 02:39:39.647497
# Unit test for function join_each
def test_join_each():
    assert True == True
