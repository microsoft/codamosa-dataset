

# Generated at 2022-06-26 02:39:02.116257
# Unit test for function join_each
def test_join_each():
    str_arg_0 = 'd6\x0b\x0b8W'
    var_0 = join_each(str_arg_0, str_arg_0)
    assert var_0 == (
        'd6\x0b\x0b8Wd6\x0b\x0b8W',
        'd6\x0b\x0b8WcMc\r7v?',
        'd6\x0b\x0b8WL_41Z\ncMc\r7v?',
    )



# Generated at 2022-06-26 02:39:04.081117
# Unit test for function join_each
def test_join_each():
    try:
        test_case_0()
    except:
        assert False




# Generated at 2022-06-26 02:39:08.125668
# Unit test for function join_each
def test_join_each():
    str_0 = 'L_41Z\ncMc\r7v?'
    var_0 = join_each(str_0, str_0)
    assert id(var_0) == id(str_0)



# Generated at 2022-06-26 02:39:13.811173
# Unit test for function join_each
def test_join_each():
    str_0 = 'L_41Z\ncMc\r7v?'
    var_0 = ['L_41Z\ncMc\n7v?\\L_41Z', 'L_41Z\ncMc\n7v?\\cMc', 'L_41Z\ncMc\n7v?\\7v?']
    var_1 = join_each(str_0, str_0)
    assert var_1 == var_0

# Generated at 2022-06-26 02:39:16.450941
# Unit test for function join_each
def test_join_each():
    var_0 = join_each('parent', 'iterable')
    assert str(var_0) == "<generator object join_each at 0x7f3d9800abe0>"

# Function for testing join_each

# Generated at 2022-06-26 02:39:18.603016
# Unit test for function join_each
def test_join_each():
    assert join_each('bar', ['a', 'b', 'c']) == ['bar/a', 'bar/b', 'bar/c']



# Generated at 2022-06-26 02:39:23.127056
# Unit test for function join_each
def test_join_each():
    str_0 = 'Kj^\nY@C\r7$'
    var_0 = join_each(str_0, str_0)
    assert str_0 == str_0


# Generated at 2022-06-26 02:39:32.329422
# Unit test for function join_each
def test_join_each():
    str_0 = 'L_41Z\ncMc\r7v?'
    str_1 = 'L_41Z\ncMc\r7v?'
    var_0 = join_each(str_0, str_1)
    var_1 = join_each(str_0, str_1)
    assert id(var_0) != id(var_1)
    assert type(var_0) == type(var_1)
    assert id(list(var_0)) != id(list(var_1))
    assert type(list(var_0)) == type(list(var_1))
    assert len(list(var_0)) == len(list(var_1))
    assert len(list(var_0)) == 9
    assert list(var_0) == list(var_1)
    int_0

# Generated at 2022-06-26 02:39:36.316761
# Unit test for function join_each
def test_join_each():
    str_0 = 'L_41Z\ncMc\r7v?'
    var_0 = join_each(str_0, str_0)

    with open('tests/expected/join_each_0.txt') as f:
        expect = f.read().splitlines()

    assert len(var_0) == len(expect)
    assert all([a == b for a, b in zip(var_0, expect)])



# Generated at 2022-06-26 02:39:38.792277
# Unit test for function join_each
def test_join_each():
    assert 'L_41Z\ncMc\r7v?\\L_41Z\ncMc\r7v?' == test_case_0()