

# Generated at 2022-06-26 02:39:04.717042
# Unit test for function join_each
def test_join_each():
    # Initialize the test case data
    str_0 = ''
    int_0 = -3768
    # Perform the unit test
    for res in join_each(str_0, (int_0, )):
        assert res == ''
    int_1 = -5514
    for res in join_each((int_1, ), (str_0, )):
        assert res == int_1
    int_2 = -6843
    for res in join_each(str_0, (int_2, )):
        assert res == ''
    str_1 = 'ToCk'
    str_2 = 'V'
    for res in join_each(str_1, (str_2, )):
        assert res == 'ToCkV'
    int_3 = -9104
    int_4 = -8857

# Generated at 2022-06-26 02:39:10.138413
# Unit test for function join_each
def test_join_each():

    str_0 = '/usr/bin'
    iterable_0 = ('.', '.')
    with pytest.raises(TypeError):
      join_each(str_0, iterable_0)

    str_1 = 'z'
    iterable_1 = ()
    with pytest.raises(TypeError):
      join_each(str_1, iterable_1)

# Generated at 2022-06-26 02:39:12.674503
# Unit test for function join_each
def test_join_each():
    str_0 = ''
    int_0 = -3196
    var_0 = join_each(str_0, int_0)
    assert var_0 == None



# Generated at 2022-06-26 02:39:13.646015
# Unit test for function join_each
def test_join_each():
    test_case_0()

# Generated at 2022-06-26 02:39:24.955592
# Unit test for function join_each
def test_join_each():
    str_0 = ''
    int_0 = -3196
    var_1 = join_each(str_0, int_0)
    str_1 = 'a'
    str_2 = 'b'
    int_1 = -5
    var_2 = join_each(str_1, str_2)
    str_3 = 'rW'
    str_4 = 'Z'
    str_5 = 'Mz'
    str_6 = 'J'
    int_2 = 8
    var_3 = join_each(str_3, str_4)
    var_4 = join_each(str_5, str_6)
    var_5 = join_each(int_2, var_4)
    var_6 = join_each(var_3, var_5)
    int_3

# Generated at 2022-06-26 02:39:27.584707
# Unit test for function join_each
def test_join_each():
    str_0 = ''
    int_0 = -3196
    var_0 = join_each(str_0, int_0)
    

# Generated at 2022-06-26 02:39:30.661204
# Unit test for function join_each
def test_join_each():
    assert test_case_0() == None

# Generated at 2022-06-26 02:39:35.598541
# Unit test for function join_each
def test_join_each():
    assert type(join_each('', 3)) == types.GeneratorType
    assert next(join_each('A', [3,4,5])) == 'A3'
    assert next(join_each('B', ['a','b','c'])) == 'Ba'

# Generated at 2022-06-26 02:39:38.175683
# Unit test for function join_each
def test_join_each():
    # Test case with arguments (str, int)
    test_case_0()




# Generated at 2022-06-26 02:39:39.488428
# Unit test for function join_each
def test_join_each():
    assert join_each('', -3196) == None