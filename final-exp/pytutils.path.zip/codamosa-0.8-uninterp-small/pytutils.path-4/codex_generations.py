

# Generated at 2022-06-26 02:39:07.129238
# Unit test for function join_each
def test_join_each():

    # Setup
    str_0 = 'tY.\t;c%'
    str_1 = '[]RjK\x1a\x13#'
    str_2 = 'Et-c'
    str_3 = 'V\x1b]xE'
    str_4 = 'V\x14-H9'
    str_5 = 'K!p<'
    str_6 = '$+A6'
    str_7 = '\x18.3@'
    str_8 = 'J/\x7f'
    str_9 = 'M1:A'
    var_0 = join_each(str_0, str_0)
    var_1 = join_each(str_1, str_1)

# Generated at 2022-06-26 02:39:09.740833
# Unit test for function join_each
def test_join_each():
    assert join_each(['1'], ['2']) == ['12']
    # assert join_each(['1'], ['2']) == ['2']

test_case_0()

# Generated at 2022-06-26 02:39:18.122808
# Unit test for function join_each
def test_join_each():
    str_0 = '1_'
    var_0 = 'jO C]{%!\r1_\nz4'
    var_1 = [var_0]
    var_2 = list(join_each(var_0, var_1))
    assert var_2 == ['jO C]{%!\r1_\nz4jO C]{%!\r1_\nz4']
    str_0 = ''
    var_0 = 'g'
    var_1 = [var_0]
    var_2 = list(join_each(var_0, var_1))
    assert var_2 == ['gg']
    str_0 = 'f{}|\xe9'
    var_0 = '!m'
    var_1 = [var_0]
    var_2 = list

# Generated at 2022-06-26 02:39:24.425114
# Unit test for function join_each
def test_join_each():
    parent = 'ab'
    iterable = ['c', 'd']
    join_each(parent, iterable)
    assert join_each(parent, iterable) is not None

'''
if __name__ == '__main__':

    import pytest
    pytest.main(args=[__file__])
'''

# Generated at 2022-06-26 02:39:33.181004
# Unit test for function join_each
def test_join_each():
    str_0 = 'jO C]{%!\r1_\nz4'
    var_0 = join_each(str_0, str_0)
    assert_equal(var_0, [os.path.join(str_0, str_0) for str_0 in str_0])
    str_0 = '\\2Hr1J\r1I[\n`3'
    var_0 = join_each(str_0, str_0)
    assert_equal(var_0, [os.path.join(str_0, str_0) for str_0 in str_0])
    str_0 = 't8o*W\x0c\x08\x0f'
    var_0 = join_each(str_0, str_0)

# Generated at 2022-06-26 02:39:34.171036
# Unit test for function join_each
def test_join_each():
    assert(test_case_0())
    
    
    
    

# Generated at 2022-06-26 02:39:41.774963
# Unit test for function join_each
def test_join_each():
    try:
        test_case_0()
    except:
        import sys
        print("[FAIL]", sys.exc_info()[0])
        return
    print("[PASS] All test cases")


if __name__ == '__main__':
    test_join_each()

# Generated at 2022-06-26 02:39:54.399298
# Unit test for function join_each

# Generated at 2022-06-26 02:39:58.723504
# Unit test for function join_each
def test_join_each():
    str_0 = 'jO C]{%!\r1_\nz4'
    var_0 = join_each(str_0, str_0)
    assert iter(var_0) is not None

# Generated at 2022-06-26 02:40:03.282269
# Unit test for function join_each
def test_join_each():
    parent = "I am a parent"
    s = "I am a child"
    path = join_each(parent, s)

    assert(path) == "I am a child"


# Mutation test for function join_each