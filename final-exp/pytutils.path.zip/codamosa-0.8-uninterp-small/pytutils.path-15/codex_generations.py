

# Generated at 2022-06-26 02:38:57.219861
# Unit test for function join_each
def test_join_each():
    str_0 = 'a/b/c'
    tuple_1 = ('d','e','f')
    var_0 = join_each(str_0, tuple_1)
    for p in var_0:
        print(p)



# Generated at 2022-06-26 02:38:59.487005
# Unit test for function join_each
def test_join_each():
    # Test for str and tuple
    try:
        test_case_0()
    except StopIteration:
        pass



# Generated at 2022-06-26 02:39:05.725985
# Unit test for function join_each
def test_join_each():
    parent = "test"
    iterable = ['a', 'b', 'c']
    list_0 = []
    for p in iterable:
        list_0.append(os.path.join(parent, p))
    tuple_0 = ('test/a', 'test/b', 'test/c')
    assert tuple_0 == tuple(join_each(parent, iterable))

# Generated at 2022-06-26 02:39:12.014947
# Unit test for function join_each
def test_join_each():
    str_0 = "test string"
    tuple_0 = (1, 2, 3)
    for i, j in enumerate(join_each(str_0, tuple_0)):
        assert j == os.path.join(str_0, str(tuple_0[i]))

    str_1 = None
    tuple_1 = ("a", "b", "c")
    var_1 = join_each(str_1, tuple_1)
    assert var_1 == None

# Generated at 2022-06-26 02:39:19.233169
# Unit test for function join_each
def test_join_each():
    str_0 = "hello/world"
    tuple_0 = ("a", "b", "c")
    unit_test_assert_equals(join_each(str_0, tuple_0),
                            ("hello/world/a", "hello/world/b", "hello/world/c"))

    str_0 = None
    tuple_0 = ()
    unit_test_assert_equals(join_each(str_0, tuple_0), tuple())

    str_0 = ""
    tuple_0 = ("a", "b", "c")
    unit_test_assert_equals(join_each(str_0, tuple_0), ("a", "b", "c"))

    str_0 = ""
    tuple_0 = ()

# Generated at 2022-06-26 02:39:30.060605
# Unit test for function join_each
def test_join_each():
    print("Test 0")
    str_0 = None
    tuple_0 = ()
    var_0 = join_each(str_0, tuple_0)
    assert var_0 == ()
    print("Test 1")
    str_0 = "foo"
    tuple_0 = ("bar", "baz")
    var_0 = join_each(str_0, tuple_0)
    assert var_0 == ("foobar", "foobaz")
    print("Test 2")
    str_0 = "stuff"
    tuple_0 = ("orange", "green", "blue")
    var_0 = join_each(str_0, tuple_0)
    assert var_0 == ("stufforange", "stuffgreen", "stuffblue")


# Generated at 2022-06-26 02:39:30.530791
# Unit test for function join_each
def test_join_each():
    assert True

# Generated at 2022-06-26 02:39:32.936450
# Unit test for function join_each
def test_join_each():
    print(__name__)

    with pytest.raises(TypeError):
        test_case_0()

# Generated at 2022-06-26 02:39:38.101052
# Unit test for function join_each
def test_join_each():
    file = join_each("/a/b/c", ["d", "e", "f"])
    file.next()
    file.next()
    file.next()
    with raises(StopIteration):
        file.next()
    
    

# Generated at 2022-06-26 02:39:41.779173
# Unit test for function join_each
def test_join_each():
    path = 'C:\\Windows\\System32'
    files = ['smss.exe', 'ntdll.dll']
    expected = ['C:\\Windows\\System32\\smss.exe',
                'C:\\Windows\\System32\\ntdll.dll']
    assert list(join_each(path, files)) == expected

