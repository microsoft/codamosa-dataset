

# Generated at 2022-06-26 02:39:06.990525
# Unit test for function join_each
def test_join_each():
    assert join_each('a', 'b') == os.path.join('a', 'b') # test_case_0
    assert join_each('a', []) == [] # test_case_1
    assert join_each('a', ['b']) == ['ab'] # test_case_2
    assert join_each('a', ['b', 'c']) == ['ab', 'ac'] # test_case_3
    assert join_each('a', ['b', 'c']) == join_each('a', ('b', 'c')) # test_case_4
    assert join_each('a/b', ['c', 'd']) == ['a/bc', 'a/bd'] # test_case_5
    assert join_each(None, ['c', 'd']) == ['c', 'd'] # test_case_

# Generated at 2022-06-26 02:39:10.980318
# Unit test for function join_each
def test_join_each():
    assert join_each('foo', 'bar') == os.path.join('foo', 'bar')
    assert join_each('foo', ['bar', 'baz']) == list(map(os.path.join, ['foo']*2, ['bar', 'baz']))

# Generated at 2022-06-26 02:39:18.727075
# Unit test for function join_each

# Generated at 2022-06-26 02:39:30.247347
# Unit test for function join_each
def test_join_each():
    str_0 = 'W3k!nL\r%> F%\\V1\nlNl'

# Generated at 2022-06-26 02:39:33.937892
# Unit test for function join_each
def test_join_each():
    in_0 = os.sep + 'home'
    in_1 = ['.', 'var', 'public', 'index.html']
    out = ['/home/./var/public/index.html']
    result = join_each(in_0, in_1)
    assert isinstance(result, types.GeneratorType)
    assert list(result) == out

# Generated at 2022-06-26 02:39:38.853937
# Unit test for function join_each
def test_join_each():
    with open("tests/aoc_2016_6/input_6.txt", "r") as f:
        data = [line.rstrip('\n') for line in f]

    parent = data[0]
    iterable = data[1:]
    out = join_each(parent, iterable)

    assert out

# Generated at 2022-06-26 02:39:40.475459
# Unit test for function join_each
def test_join_each():
    test_case_0()

# Program entry point
if __name__ == "__main__":
    tes

# Generated at 2022-06-26 02:39:51.732035
# Unit test for function join_each
def test_join_each():
    str_0 = 'W3k!nL\r%> F%\\V1\nlNl'
    var_0 = join_each(str_0, str_0)
    result = True

# Generated at 2022-06-26 02:39:57.613610
# Unit test for function join_each
def test_join_each():
    str_0 = 'W3k!nL\r%> F%\\V1\nlNl'
    var_0 = join_each(str_0, str_0)
    var_0_iterator = iter(var_0)

# Generated at 2022-06-26 02:40:03.729058
# Unit test for function join_each
def test_join_each():
    assert test_case_0() == (
        'W3k!nL\r%> F%\\V1\nlNl/W3k!nL\r%> F%\\V1\nlNl',
        'W3k!nL\r%> F%\\V1\nlNl/W3k!nL\r%> F%\\V1\nlNl'
    )

# Generated at 2022-06-26 02:40:11.570016
# Unit test for function join_each
def test_join_each():
    str_0 = '0R%gp=1;Q@!\'"'
    str_1 = 'L'
    bool_0 = path_utils.is_absolute_path(str_0)
    bool_1 = path_utils.is_absolute_path(str_1)
    str_2 = str_0 + path_utils.get_sep_char() + str_1
    str_3 = path_utils.join_path(str_0, str_1)

    assert str_2 == str_3


# Generated at 2022-06-26 02:40:17.019709
# Unit test for function join_each
def test_join_each():

    assert list(join_each('.', ['file1', 'file2'])) == [
        './file1', './file2'
    ], 'Test case 0'




# Generated at 2022-06-26 02:40:22.262094
# Unit test for function join_each
def test_join_each():
    assert join_each('parent', ['child1', 'child2']) == ['parent/child1', 'parent/child2']
    assert join_each('/home/jack', ['example.py', 'example.conf']) == ['parent/example.py', 'parent/example.conf']

# Generated at 2022-06-26 02:40:29.685773
# Unit test for function join_each
def test_join_each():
    str_0 = 'W3k!nL\r%> F%\\V1\nlNl'
    str_ret_0 = join_each(str_0, str_0)
    assert str_ret_0 == 'W3k!nL\r%> F%\\V1\nlNl'


# Generated at 2022-06-26 02:40:34.875159
# Unit test for function join_each
def test_join_each():
    # Example 0
    assert list(join_each('parent', ['child1', 'child2'])) == ['parent\\child1', 'parent\\child2']
    # Example 1
    assert list(join_each('parent', ['child1.txt', 'child2.txt'])) == ['parent\\child1.txt', 'parent\\child2.txt']
    # Example 2
    assert list(join_each('parent', ['child1.txt', 'child2.txt', 'child3.py'])) == ['parent\\child1.txt', 'parent\\child2.txt', 'parent\\child3.py']

# Generated at 2022-06-26 02:40:42.168505
# Unit test for function join_each
def test_join_each():
    str_0 = 'W3k!nL\r%> F%\\V1\nlNl'
    parent = str_0[6:]
    iterable = str_0 * 0
    assert join_each(parent, iterable) is not None
    assert len(join_each(parent, iterable)) == 0



# Generated at 2022-06-26 02:40:44.242096
# Unit test for function join_each
def test_join_each():
    assert join_each('a', 'bc') == ['a/b', 'a/c']


# Generated at 2022-06-26 02:40:46.898933
# Unit test for function join_each
def test_join_each():
    assert list(join_each('a', ['b', 'c'])) == ['a/b', 'a/c']

# Generated at 2022-06-26 02:40:55.422864
# Unit test for function join_each
def test_join_each():
    arr_0 = [
        'f9poKrBVp!fR!W$V7o5P5];5w5*yiF6yzAi8UYz6UY0lRRnNx',
        'Ke;]Nk!gD^/Rf:=jKXC_\t,N/\\\x0c',
        '[c4-sfu\\pI\x0c',
        '\'iS\\^a>n[-}N#^Zw#N;B\nFJB*G=J'
    ]
    prop_0 = 'W3k!nL\r%> F%\\V1\nlNl'
    ret_0 = list(join_each(prop_0, arr_0))

# Generated at 2022-06-26 02:41:05.995893
# Unit test for function join_each
def test_join_each():
    str_0 = 'W3k!nL\r%> F%\\V1\nlNl'
    assert list(join_each('', str_0)) == ['W', '3', 'k', '!', 'n', 'L', '\r', '%', '>', ' ', 'F', '%', '\\', 'V', '1', '\n', 'l', 'N', 'l']
    str_1 = 'SbW#!8BwY_nCfr<4x '
    assert list(join_each('', str_1)) == ['S', 'b', 'W', '#', '!', '8', 'B', 'w', 'Y', '_', 'n', 'C', 'f', 'r', '<', '4', 'x', ' ']