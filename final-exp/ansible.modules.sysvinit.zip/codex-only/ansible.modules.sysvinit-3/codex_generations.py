

# Generated at 2022-06-23 04:29:42.718240
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
    )

    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:29:55.431388
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
        supports_check_mode=True
    )

# Generated at 2022-06-23 04:30:06.276895
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    result['status'].setdefault('enabled', {})

# Generated at 2022-06-23 04:30:16.354352
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled
    from ansible.module_utils._text import to_bytes
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str'),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ))
    # Check the basics of our main function
   

# Generated at 2022-06-23 04:30:19.596838
# Unit test for function main
def test_main():
    from ansible.modules.system.sysvinit import main
    res = main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:31.728299
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
           name=dict(required=True),
           state=dict(required=True),
           enabled=dict(required=True),
           sleep=dict(required=True),
           pattern=dict(required=True),
           arguments=dict(required=True),
           runlevels=dict(required=True),
           daemonize=dict(required=True),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.service import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:42.631207
# Unit test for function main
def test_main():
    test_module = AnsibleModule( argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:50.965056
# Unit test for function main
def test_main():
    out = {'changed': False, 'status': {'enabled': {'changed': False, 'rc': -1, 'stderr': None, 'stdout': None}, 'started': {'changed': False, 'rc': -1, 'stderr': None, 'stdout': None}}, 'name': u'apache2'}

# Generated at 2022-06-23 04:31:06.884132
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize

    # Mock module arguments
    name = "apache2"
    state = ""
    enabled = ""
    sleep = ""
    pattern = ""
    arguments = ""
    runlevels = ""
    daemonize = ""
    check_mode = ""
    diff_mode = ""
    platform = ""
    rc = 0
    out = ""
    err = ""

    class AnsibleModuleMock(AnsibleModule):
        def fail_json(self, *args, **kwargs):
            self.exit_json(failed=True, *args, **kwargs)


# Generated at 2022-06-23 04:31:18.726387
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-23 04:31:26.973039
# Unit test for function main
def test_main():
    '''
    This is a basic unit test for the sysvinit module.
    '''

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )



# Generated at 2022-06-23 04:31:40.457765
# Unit test for function main
def test_main():
    test_arguments = {
        "name":"test",
        "module_args":{
            "name":"test_module",
            "state":"started",
            "enabled":True,
            "runlevels":["1"],
            "pattern":"test_pattern"
        }
    }
    result = {
        "name": "test_module",
        "changed": True,
        "status": {
            "enabled": {
                "changed": True,
                "rc": None,
                "stdout": None,
                "stderr": None,
                "runlevels":["1"]
            },
            "started": {
                "changed": True,
                "rc": None,
                "stdout": None,
                "stderr": None
            }
        }
    }

# Generated at 2022-06-23 04:31:41.807194
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        load_fixture('main')
        main()


# Generated at 2022-06-23 04:31:51.263944
# Unit test for function main
def test_main():
    # Unit test for function 'main'
    args = dict(
      name = 'httpd',
      enabled = True,
      state = 'started',
      runlevels = [ '1', '2', '3' ],
      daemonize = True,
      pattern = 'httpd'
    )

    # Mock object for the module
    class MockModule:
        pass

    # Mock object for the module
    class MockModule:
        def __init__(self, name, enabled, state, runlevels, daemonize, pattern):
            self.params = dict(name=name, enabled=enabled, state=state, runlevels=runlevels, daemonize=daemonize, pattern=pattern)

        # Mock function for the run_command function.

# Generated at 2022-06-23 04:32:01.674990
# Unit test for function main
def test_main():
    # mock module
    module = AnsibleModule(
            argument_spec=dict(
                name=dict(required=True, type='str', aliases=['service']),
                state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
                sleep=dict(type='int', default=1),
                pattern=dict(type='str'),
                enabled=dict(type='bool'),
                arguments=dict(type='str', aliases=['args']),
                runlevels=dict(type='list', elements='str'),
                daemonize=dict(type='bool', default=False),
            ),
            supports_check_mode=True,
            required_one_of=[['state', 'enabled']],
        )
    # mock module
    #import ansible.utils
    #ansible.

# Generated at 2022-06-23 04:32:14.858937
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']
    enabled = module.params['enabled']
    runlevels

# Generated at 2022-06-23 04:32:26.589405
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    # dummy module args
    new_module_args = {
        'name':'test',
        'state':'started',
        'enabled':True,
        'sleep':1,
        'arguments':'',
        'runlevels':'',
    }
    # dummy module

# Generated at 2022-06-23 04:32:31.075471
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'name': 'crond',
        'enabled': True,
        'state': 'started',
        'sleep': 1,
    })
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:44.723284
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # create a temp directory
    import tempfile, shutil

    tmpdir = tempfile

# Generated at 2022-06-23 04:32:54.211692
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'name': {'required': True, 'type': 'str'}, 'state': {'choices': ['started', 'stopped', 'restarted', 'reloaded'], 'type': 'str'}, 'enabled': {'type': 'bool'}, 'sleep': {'type': 'int', 'default': 1}, 'pattern': {'type': 'str'}, 'arguments': {'type': 'str', 'aliases': ['args']}, 'runlevels': {'type': 'list', 'elements': 'str'}, 'daemonize': {'type': 'bool', 'default': False}})
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:02.778803
# Unit test for function main

# Generated at 2022-06-23 04:33:12.840653
# Unit test for function main

# Generated at 2022-06-23 04:33:14.532494
# Unit test for function main
def test_main():
    # Test for abstract
    assert main == ansible_module_sysvinit.main


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:27.518958
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:33:37.461580
# Unit test for function main

# Generated at 2022-06-23 04:33:49.940489
# Unit test for function main
def test_main():
    # set up some vars
    cliargs = {'state': 'started', 'enabled': False, 'arguments': None, 'name': 'apache2', 'runlevels': None}
    # set up some vars

# Generated at 2022-06-23 04:33:55.250532
# Unit test for function main
def test_main():

    module = AnsibleModule({
        'name': "ansible-test-service",
        'state': "started",
        'enabled': False
    })

    main()
    import pytest
    pytest.raises(SystemExit, main)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:08.416875
# Unit test for function main
def test_main():
    args = {}
    args['name'] = 'apache'
    args['state'] = 'started'
    args['enabled'] = True
    args['sleep'] = 1
    args['pattern'] = ''
    args['arguments'] = ''
    args['runlevels'] = '3'
    args['daemonize'] = False

# Generated at 2022-06-23 04:34:12.160401
# Unit test for function main
def test_main():
    rc, out, err = None, None, None
    result = {
        'name': name,
        'changed': False,
        'status': {}
    }
    assert result

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:26.142828
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:38.681876
# Unit test for function main

# Generated at 2022-06-23 04:34:52.815033
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:35:05.161865
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule, get_distribution
    from ansible.module_utils.actions import AnsibleModuleTestCase

    def fake_run_command(self, cmd):
        "Mock run_command"
        class MockReturns(object):
            "Mock of return values"
            def __init__(self, rets):
                self.items = list()
                for item in rets:
                    self.items.append(item)
            def __next__(self):
                if len(self.items):
                    return self.items.pop(0)
                raise StopIteration
            def next(self):
                return self.__next__()

# Generated at 2022-06-23 04:35:18.661685
# Unit test for function main
def test_main():
    test_params = {
        'name': 'httpd',
        'enabled': True,
        'state': 'started',
        'runlevels': [ 2, 3, 4, 5 ],
    }
    test_result = {
        'attempts': 1,
        'changed': True,
        'name': 'httpd',
        'status': {
            'enabled': {
                'changed': True,
                'rc': 0,
                'stderr': '',
                'stdout': ''
            },
            'started': {
                'changed': True,
                'rc': 0,
                'stderr': '',
                'stdout': ''
            }
        }
    }


# Generated at 2022-06-23 04:35:31.121924
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'run_command') as mock_run_command:
        with patch.object(AnsibleModule, 'exit_json') as mock_exit_json:
            mock_run_command.return_value = (0, '', '')
            __builtins__.__dict__['fail_if_missing'] = 'Mock_fail_if_missing'
            __builtins__.__dict__['sysv_exists'] = 'Mock_sysv_exists'
            __builtins__.__dict__['get_sysv_script'] = 'Mock_get_sysv_script'
            __builtins__.__dict__['sysv_is_enabled'] = 'Mock_sysv_is_enabled'

# Generated at 2022-06-23 04:35:42.642789
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.params['state'] = 'started'
    module.params['enabled'] = True

    main()

# Generated at 2022-06-23 04:35:56.548910
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    import sys
    sys.path.append('/home/sjones/temp/ansible/test/units/')
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import service

# Generated at 2022-06-23 04:35:58.227759
# Unit test for function main
def test_main():
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:11.738832
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:21.607226
# Unit test for function main

# Generated at 2022-06-23 04:36:32.871595
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:36:45.527785
# Unit test for function main
def test_main():
    def mock_module(**kwargs):
        return MagicMock(**kwargs)

    def mock_run_command(res=None, rc=0, out='', err=''):
        if res is None:
            res = (rc, out, err)
        if rc != 0:
            mock_run_command.fail = True
        return res

    # Mock all module functions
    mock_module.run_command = mock_run_command
    mock_module.check_mode = False
    mock_module.get_bin_path = lambda x,y: x
    mock_module.jsonify = lambda y: y

    mock_module.params = {
            "name": "test",
            "enabled": False,
            "runlevels": ["3", "5"],
            "state": None
    }

    # Mock functions

# Generated at 2022-06-23 04:36:58.842777
# Unit test for function main
def test_main():

    # FIXME: move tests to test directory

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=0),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action

# Generated at 2022-06-23 04:37:03.529575
# Unit test for function main
def test_main():
    assert abs(main(9, 2) == 7)
    assert abs(main(5, 8) == 3)
    assert abs(main(6, 2) == 4)
    assert abs(main(1, 4) == 3)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:37:15.907753
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:37:26.624902
# Unit test for function main
def test_main():
    success_return = {
            "attempts": 1,
            "changed": True,
            "name": "apache2",
            "status": {
                "enabled": {
                    "changed": True,
                    "rc": 0,
                    "stderr": "",
                    "stdout": ""
                },
                "stopped": {
                    "changed": True,
                    "rc": 0,
                    "stderr": "",
                    "stdout": "Stopping web server: apache2.\n"
                }
            }
        }

# Generated at 2022-06-23 04:37:39.417757
# Unit test for function main
def test_main():
    """
        Allows for testing the main function from outside of the module
    """
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()


# Generated at 2022-06-23 04:37:47.919994
# Unit test for function main
def test_main():
    # This is the basic test case
    run_setup = [
        'ansible-playbook sysvinit.yml -vv',
        'ansible-playbook sysvinit_enabled.yml -vv',
        'ansible-playbook sysvinit_enabled_runlevels.yml -vv',
        'ansible-playbook sysvinit_restart.yml -vv',
    ]
    module = AnsibleModule([{ 'name' : 'apache2', 'state' : 'started', 'enabled' : 'yes' }], check_mode=True)
    if not module.run_command(run_setup[0]):
        print("Setup was successful")
    if not module.run_command(run_setup[1]):
        print("Setup was successful")

# Generated at 2022-06-23 04:37:51.784919
# Unit test for function main
def test_main():
    args = dict(
        name="httpd",
        enabled=True,
        runlevels=[1,2,3,4,5],
    )
    module = AnsibleModule(argument_spec=args)
    print(str(main()))


# Generated at 2022-06-23 04:38:04.764570
# Unit test for function main
def test_main():
    from ansible.module_utils.ansible_release import __version__ as ansible_version


# Generated at 2022-06-23 04:38:15.635624
# Unit test for function main
def test_main():
    assert main() is None

# units tests
if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import common as ansiblecommon
    from ansible.module_utils.six.moves import builtins
    import sys

    if len(sys.argv) > 1:
        del sys.argv[1:]

    sys.modules['ansible'] = AnsibleModule
    sys.modules['ansible.module_utils'] = AnsibleModule
    sys.modules['ansible.module_utils.basic'] = AnsibleModule
    sys.modules['ansible.module_utils.common'] = ansiblecommon
    sys.modules['builtins'] = builtins

    test_main()

# Generated at 2022-06-23 04:38:27.992690
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(name=dict(required=True, type='str'),
                                              state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
                                              enabled=dict(type='bool'),
                                              sleep=dict(type='int', default=1),
                                              pattern=dict(type='str'),
                                              arguments=dict(type='str', aliases=['args']),
                                              runlevels=dict(type='list', elements='str'),
                                              daemonize=dict(type='bool', default=False)),
                           supports_check_mode=True,
                           required_one_of=[['state', 'enabled']])

    main(module)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:38:29.917353
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()
# end unit test for function main


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:38:41.543383
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main(module)

import json
if __name__ == '__main__':
    main

# Generated at 2022-06-23 04:38:46.234318
# Unit test for function main
def test_main():
    m = AnsibleModule('sysvinit', name='httpd', state='started', daemonize=True)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:38:58.426216
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:39:03.617249
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:07.548563
# Unit test for function main
def test_main():
    #module = import_module('sysvinit')
    module = AnsibleModule('sysvinit')

    module.params['state'] = 'stopped'

    # test non-existent service
    module.params['name'] = 'nosuchservice'

    main()


# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:16.908970
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    module.params = dict(
        name='service',
        state='started',
        enabled=True,
        runlevels=['3','5']
    )

    main()


# Generated at 2022-06-23 04:39:23.051662
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:39:30.254516
# Unit test for function main
def test_main():
    import json
    import sys
    import subprocess
    sys.path.append('lib')
    import ansible.module_utils.service as service
    # create test environment
    # ansible/test/units/module_utils/service/tests/service_test_env.py
    test_env = {
        'PATH':'/bin:/usr/bin',
        'ANSIBLE_MODULE_ARGS':json.dumps({'name':'apache2', 'daemonize':False, 'enabled':False, 'arguments':None})
    }
    # ansible/test/units/module_utils/service/tests/test_sysv_init.py

# Generated at 2022-06-23 04:39:37.946816
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
        "name": {"required": True},
        "sleep": {"type": "int"},
        "state": {"choices": ["started", "stopped", "restarted", "reloaded"]},
        "runlevels": {"type": "list", "elements": "str"},
        "enabled": {"type": "bool"},
        "pattern": {"type": "str"},
        "arguments": {"type": "str"},
        "daemonize": {"type": "bool", "default": False}
    })
    module.run_command = Mock(return_value=(0, "", ""))
    module.exit_json = Mock(return_value=None)
    module.warn = Mock(return_value=None)
    module.fail_json = Mock(return_value=None)
   