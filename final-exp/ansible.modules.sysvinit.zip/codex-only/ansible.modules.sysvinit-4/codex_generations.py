

# Generated at 2022-06-23 04:29:42.256564
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    # Mock module input
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']]
    )
    module

# Generated at 2022-06-23 04:29:46.313143
# Unit test for function main
def test_main():
    module = AnsibleModule({'name': 'time', 'state': 'stopped'}, supports_check_mode=True)
    result = main()
    assert result['changed'] is True
    assert result['status']['stopped']['changed'] is True


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:00.021595
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:30:09.844873
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:30:11.162342
# Unit test for function main
def test_main():
  main()

if __name__ == '__main__':
  main()

# Generated at 2022-06-23 04:30:16.795790
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
    ))
    module.main()

# Generated at 2022-06-23 04:30:30.692527
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson

    # Mock sysvinit.get_sysv_script()
    from ansible.module_utils.service import get_sysv_script
    old_get_sysv_script = get_sysv_script
    def mock_get_sysv_script(name):
        return '/etc/rc.d/init.d/' + name
    get_sysv_script = mock_get_sysv_script

    # Mock sysvinit.sysv_exists()
    from ansible.module_utils.service import sysv_exists
    old_sysv_exists = sysv_exists

# Generated at 2022-06-23 04:30:41.141944
# Unit test for function main
def test_main():
    script = 'ansible-test-service_script'
    file_name = '/etc/init.d/' + script
    args = dict(
        name=script,
        state='stopped',
        enabled=True
    )
    module = AnsibleModule(argument_spec=args)

    f = open(file_name, 'w')
    f.write('#!/usr/bin/env python3\nprint("I was called")')
    f.close()

    module.run_command = lambda args, check_rc=True, close_fds=True: (0, 'I was called', '')
    main()
    module.run_command = lambda args, check_rc=True, close_fds=True: (1, 'I was called', '')
    # This should error out

# Generated at 2022-06-23 04:30:49.739899
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    assert main() is None

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:51.249031
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:01.298118
# Unit test for function main
def test_main():
    print("Test 1, name: apache2, state: started, enabled: yes")
    main()
    print("Test 2, name: apache2, state: started, enabled: yes")
    main()
    print("Test 3, name: apache2, state: started, enabled: yes")
    main()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-23 04:31:14.115213
# Unit test for function main
def test_main():
    from ansible.module_utils.service import sysv_exists, sysv_is_enabled

# Generated at 2022-06-23 04:31:23.867396
# Unit test for function main
def test_main():
    try:
        import json
    except ImportError:
        import simplejson as json
    m = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True, type='str'),
            state = dict(required=False, type='str'),
            enabled = dict(required=False, type='bool'),
            sleep = dict(required=False, type='int', default=1),
            pattern = dict(required=False, type='str'),
            arguments = dict(required=False, type='str', aliases=['args']),
            runlevels = dict(required=False, type='list', elements='str'),
            daemonize = dict(required=False, type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    # TODO: implement actual unit testing
    main()


# Generated at 2022-06-23 04:31:29.895738
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
        ),
        required_one_of=[['state', 'enabled']],
    )
    class Mock(object):
        def __init__(self):
            self.stdout = None
            self.stderr = None
            self.rc = 0

# Generated at 2022-06-23 04:31:41.603624
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:31:47.740725
# Unit test for function main
def test_main():
    args = dict(
        name=name,
        state=state,
        enabled=enabled,
        sleep=sleep,
        pattern=pattern,
        arguments=arguments,
        runlevels=runlevels,
        daemonize=daemonize,
    )
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec=args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:49.955681
# Unit test for function main

# Generated at 2022-06-23 04:32:00.213852
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
    )

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:13.939964
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import service
    #from ansible.module_utils import sysvinit
    import sys
    import os

    print("*********************************************************")


# Generated at 2022-06-23 04:32:14.680601
# Unit test for function main
def test_main():
    assert main() is True

# Generated at 2022-06-23 04:32:16.711835
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    x = main()
    return x

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:26.176259
# Unit test for function main
def test_main():
    """
    This function tests the main() module
    """
    test_module = AnsibleModule(argument_spec={
        "name": {"required": True, "type": "str"},
        "state": {"choices": ["started", "stopped", "restarted", "reloaded"], "type": "str"},
        "enabled": {"type": "bool"},
        "pattern": {"type": "str"},
        "sleep": {"type": "int"},
        "arguments": {"type": "str"},
        "runlevels": {"type": "list", "elements": "str"},
        "daemonize": {"type": "bool"},
    })
    main()

# continue to run main()
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:40.373889
# Unit test for function main
def test_main():
    test_runlevel_status = {
            "enabled": False,
            "3": {"enabled": False},
            "5": {"enabled": False}
        }

# Generated at 2022-06-23 04:32:49.777797
# Unit test for function main
def test_main():
    import json
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        ''' for testing purposes '''
        def __init__(self):
            self.params = {}

# Generated at 2022-06-23 04:33:00.451835
# Unit test for function main
def test_main():
    from ansible.module_utils import module_invoke_hacks
    from ansible.module_utils import sysvinit_module_common
    from ansible.module_utils import basic
    from ansible.module_utils import service
    from ansible.module_utils import daemon

    def fake_ansible_module(argument_spec, **kwargs):
        class FakeAnsibleModule(object):
            def __init__(self, argument_spec, **kwargs):
                self._argument_spec = argument_spec
                self.params = {}
                try:
                    self.check_mode = kwargs.pop('check_mode')
                except KeyError:
                    self.check_mode = False
                try:
                    self.diff_mode = kwargs.pop('diff_mode')
                except KeyError:
                    self.diff

# Generated at 2022-06-23 04:33:10.955960
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    
    
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:22.404682
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:33:23.372117
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:33.293783
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    #try:
    name = module.params['name']

# Generated at 2022-06-23 04:33:47.709997
# Unit test for function main
def test_main():

    # Mock module input parameters.
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    from sysvinit_test_fixtures import MockModuleFixture

# Generated at 2022-06-23 04:34:00.733710
# Unit test for function main
def test_main():
    module_name = 'sysvinit'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    if not module._socket_path:
        module

# Generated at 2022-06-23 04:34:12.728403
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys
    import json
    import tempfile
    import subprocess

    # Copy argument spec, drop 'state' which is not required for this function
    argument_spec = json.loads(main.__doc__)['argument_spec']
    del argument_spec['state']
    del argument_spec['enabled']
    del argument_spec['runlevels']
    del argument_spec['daemonize']

    # Generate a temporary file to 'run'
    fd, tmp_file = tempfile.mkstemp()
    os.close(fd)
    with open(tmp_file, 'wb') as f:
        f.write("#!/bin/bash\nexit 0\n")

# Generated at 2022-06-23 04:34:26.600723
# Unit test for function main
def test_main():

    if __name__ == '__main__':

        module = AnsibleModule(
            argument_spec=dict(
                name=dict(required=True, type='str', aliases=['service']),
                state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
                enabled=dict(type='bool'),
                sleep=dict(type='int', default=1),
                pattern=dict(type='str'),
                arguments=dict(type='str', aliases=['args']),
                runlevels=dict(type='list', elements='str'),
                daemonize=dict(type='bool', default=False),
            ),
            supports_check_mode=True,
            required_one_of=[['state', 'enabled']],
        )

        main()


# Generated at 2022-06-23 04:34:39.030227
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    assert main() == 'ansible.module_utils.basic.AnsibleModule'

# Generated at 2022-06-23 04:34:52.878306
# Unit test for function main
def test_main():
    import os
    import shutil
    import sys

    def test_module(module_name):
        return f"""
        import os
        import sys

        sys.path.append(os.path.join(os.getcwd(), "%s"))
        import %s
        %s.main()
        """ % (module_name, module_name, module_name)

    assert os.getcwd().endswith("ansible_collections/ansible/builtin/plugins/modules")
    if os.path.isdir("tests/unit/modules/system"):
        shutil.rmtree("tests/unit/modules/system")
    os.makedirs("tests/unit/modules/system")
    shutil.copy("service_mock.py", "tests/unit/modules/system/sysvinit.py")



# Generated at 2022-06-23 04:34:57.146300
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    # Fail if any python exception occurs
    # FIXME: This should be better
    try:
        main()
    except Exception:
        raise AssertionError('Exception thrown')


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:03.580457
# Unit test for function main
def test_main():
    
    # setup testing
    import sys
    import inspect

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize

# Generated at 2022-06-23 04:35:07.104733
# Unit test for function main
def test_main():
    main()

# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:20.386728
# Unit test for function main
def test_main():
    import os
    import sys
    import mock
    import json

    # Mock out the AnsibleModule
    mock_module = mock.MagicMock()
    mock_module.params = {}
    mock_module.params['name'] = 'mock_name'
    mock_module.params['state'] = 'stopped'
    mock_module.check_mode = True
    mock_module.exit_json = exit_json
    mock_module.fail_json = fail_json
    mock_module.run_command = run_command

    # Mock out the functions used by the module
    mock_sysv_exists = mock.MagicMock()
    mock_sysv_exists.return_value = True
    mock_module.get_bin_path = get_bin_path
    mock_module.daemonize = daemonize


# Generated at 2022-06-23 04:35:22.754722
# Unit test for function main
def test_main():
    """ Unit test for function main """
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:33.325444
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize


# Generated at 2022-06-23 04:35:38.525153
# Unit test for function main
def test_main():
    # import library
    from ansible.module_utils.service import sysv_is_enabled

    # Nothing to be done
    this = {
        "state": "stopped",
        "enabled": False
    }
    that= {
        "state": "stopped",
        "enabled": False
    }
    assert(this == that)

    # Enable service
    this = {
        "state": "stopped",
        "enabled": True
    }
    that= {
        "state": "stopped",
        "enabled": True
    }
    assert(this == that)

    # Disable service
    this = {
        "state": "started",
        "enabled": False
    }
    that= {
        "state": "started",
        "enabled": False
    }
    assert(this == that)

# Generated at 2022-06-23 04:35:44.836920
# Unit test for function main
def test_main():
    d = dict(
        name='service_name',
        state='state_decision',
        enabled=False,
        sleep=1,
        pattern='pattern_for_testing',
        arguments='arguments_for_testing',
        runlevels=['runlevel_one', 'runlevel_two'],
        daemonize=True
    )
    module = AnsibleModule(**d)

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:58.615210
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:36:11.272092
# Unit test for function main
def test_main():
    class test_module(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.check_mode = False
            self.run_command = None
            self.fail_json = None
            self.run_command = None
            self.get_bin_path = None
        def exit_json(self, **kwargs):
            return kwargs
    module = test_module(
        name = "atd",
        state = "stopped"
        )
    main()

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.service import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:21.488282
# Unit test for function main
def test_main():
    # Setup
    module_mock = MagicMock()
    module_mock.params = {
        'name': 'apache2',
        'state': None,
        'enabled': True,
        'sleep': 1,
        'pattern': '',
        'arguments': '',
        'runlevels': [],
        'daemonize': False
    }
    sysvinit_mock = MagicMock()
    sysvinit_mock.syv_exists.return_value = True
    sysvinit_mock.syv_is_enabled.return_value = False
    sysvinit_mock.get_sysv_script.return_value = "/etc/init.d/apache2"
    sysvinit_mock.get_ps.return_value = True
    module_mock.check_

# Generated at 2022-06-23 04:36:32.797863
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes


    ###########################################################################
    # BEGIN: Helpers
    def runme_daemonize(module, cmd):
        import subprocess
        import os
        import signal

        # we put a wrapper with a timeout around the module command to prevent
        # deadlocks when the module hangs.  We specifically do not
        # use Python's signal.alarm() because this causes any system calls to
        # return EINTR.  This is not what we want.  We want the program to
        # effectively die when we kill the process.

# Generated at 2022-06-23 04:36:45.427330
# Unit test for function main
def test_main():
    action_stub = [0, "", ""]
    run_command_stub = [0, "", ""]
    daemonize_stub = [0, "", ""]
    get_bin_path = [0, "", ""]
    from ansible.module_utils.service import sysv_exists
    from ansible.module_utils.service import sysv_is_enabled
    from ansible.module_utils.service import get_sysv_script
    from ansible.module_utils.service import fail_if_missing
    from ansible.module_utils.six.moves import mock
    import imp
    import sys
    # Mock module
    class ModuleStub(object):
        ansible_module_args = {}
        def run_command(self,command):
            return run_command_stub
       

# Generated at 2022-06-23 04:36:47.085233
# Unit test for function main
def test_main():
    result = main()
    assert result is None

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:48.652199
# Unit test for function main
def test_main():
    print("Hello, World!")

if __name__ == '__main__':
    main()


# Generated at 2022-06-23 04:37:01.148600
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ),
    required_one_of=[['state', 'enabled']],
    supports_check_mode=True,
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:37:02.468074
# Unit test for function main
def test_main():
    assert True == True

# Generated at 2022-06-23 04:37:04.100834
# Unit test for function main
def test_main():
    args = "\
        --check \
        --state=stopped \
        --name ssh\
    "
    from ansible.modules.system import sysvinit
    sysvinit.main(base.Base().parse(args.split()))


# Generated at 2022-06-23 04:37:05.655516
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:37:18.676375
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import action_common_attributes

# Generated at 2022-06-23 04:37:27.845250
# Unit test for function main
def test_main():
    import mock
    import os
    import tempfile
    import shutil
    try:
        from ansible.module_utils.basic import AnsibleModule
    except:
        pass
    # noinspection PyPep8Naming
    import ansible.module_utils.service as service

    # noinspection PyPep8Naming
    def sysv_exists(name):
        return True

    # noinspection PyPep8Naming
    def get_sysv_script(name):
        return "/tmp/doesnotexist"

    # noinspection PyPep8Naming
    def get_ps(module, service_name):
        return False

    # noinspection PyPep8Naming
    def sysv_is_enabled(name, runlevel=None):
        return False

    # noinspection PyP

# Generated at 2022-06-23 04:37:40.254267
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 04:37:48.544386
# Unit test for function main
def test_main():
    test_input = {
        'name' : 'apache',
        'state' : 'started',
        'enabled' : 'yes'
    }

    test_model = {
        'results' : {
            'attempts' : 1,
            'changed' : True,
            'name' : 'apache',
            'status' : {
                'enabled' : {
                    'changed' : True,
                    'rc' : 0,
                    'stderr' : '',
                    'stdout' : ''
                },
                'stopped' : {
                    'changed' : True,
                    'rc' : 0,
                    'stderr' : 'Stopping web server: apache2.\n',
                    'stdout' : ''
                }
            }
        }
    }


# Generated at 2022-06-23 04:38:02.186238
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:38:13.898393
# Unit test for function main
def test_main():
  from ansible.module_utils.basic import AnsibleModule
  arguments = dict(
      name=dict(required=True, type='str', aliases=['service']),
      state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
      enabled=dict(type='bool'),
      sleep=dict(type='int', default=1),
      pattern=dict(type='str'),
      arguments=dict(type='str', aliases=['args']),
      runlevels=dict(type='list', elements='str'),
      daemonize=dict(type='bool', default=False),
  )
  module = AnsibleModule(
      argument_spec=arguments,
      supports_check_mode=True,
      required_one_of=[['state', 'enabled']],
  )
 

# Generated at 2022-06-23 04:38:22.385619
# Unit test for function main
def test_main():
    import sys
    import os
    import doctest
    module_dir = os.path.dirname(os.path.abspath(__file__))
    module_file = os.path.join(module_dir, 'sysvinit.py')
    examples_dir = os.path.join(module_dir, '..', '..', '..', 'doc', 'sysvinit')
    tests = doctest.DocFileSuite(module_file, module_relative=False, optionflags=doctest.ELLIPSIS)
    tests.module.sysvinit = sys.modules[__name__]
    tests.globs['examples_dir'] = examples_dir
    result = unittest.TextTestRunner(verbosity=2).run(tests)
    sys.exit(not result.wasSuccessful())


# Generated at 2022-06-23 04:38:35.880211
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    
    test_module.main()


# Generated at 2022-06-23 04:38:51.846914
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    results = main()

# Generated at 2022-06-23 04:39:06.336721
# Unit test for function main
def test_main():
    import inspect
    import os
    import sys
    import re
    #import mock
    #mock.patch('ansible.module_utils.basic.sysv_is_enabled')
    from ansible.module_utils.basic import *
    #from ansible.module_utils.basic import AnsibleModule

    sys.modules['ansible.module_utils.service'] = mock.Mock()
    import ansible.module_utils.service
    #sys.modules['ansible.module_utils.service'] = mock.Mock()
    #from ansible.module_utils.service import *
    #import ansible.module_utils.service as service


# Generated at 2022-06-23 04:39:12.952561
# Unit test for function main
def test_main():
    result = {"name": "foo", "changed": False, "status": {"enabled": {"changed": False, "rc": None}}}
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json = lambda **kwargs: result.update(kwargs) or kwargs
    main()
    assert result == {"name": "foo", "changed": False, "status": {"enabled": {"changed": False, "rc": None}}}

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:15.766481
# Unit test for function main
def test_main():
    Test = AnsibleModule({'name': "httpd", 'enabled': True}, check_invalid_arguments=False)
    Test.exit_json(**main())

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:23.621582
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:39:30.646263
# Unit test for function main
def test_main():
    [module, result] = main(module={}, state='started', name='apache2')

    # check type of returned data
    assert isinstance(result, dict), "Returned result is not of type dict."

    # Check for state related parameters
    assert 'changed' in result, "Returned result does not have the required key 'changed'."
    assert 'status' in result, "Returned result does not have the required key 'status'."
    assert result['status'] is not None, "Returned status object is not of type dict."

    # Check for enable/disable related parameters
    assert 'enabled' in result['status'], "Returned status object does not have the required key 'enabled'."
    assert result['status']['enabled'] is not None, "Returned enable object is not of type dict."

    # Check for state related parameters
    assert 'changed'

# Generated at 2022-06-23 04:39:35.897435
# Unit test for function main
def test_main():
    def run_exit(module, state):
        module.exit_json(**state)
    def run_fail(module, msg):
        module.fail_json(msg=msg)
    # For test_main, we are going to set the module methods to Mock objects that do a very basic
    # truth test on the function parameters