

# Generated at 2022-06-23 04:29:42.021363
# Unit test for function main
def test_main():
    import ansible.module_utils.service

    # set up mock stuff
    class AnsibleModuleMock(object):
        params = {
            'arguments': '',
            'daemonize': False,
            'enabled': None,
            'name': 'foo',
            'pattern': None,
            'runlevels': [],
            'sleep': 1,
            'state': 'started'
        }
        def get_bin_path(self, *args, **kwargs):
            return "/sbin/service"

        def fail_json(self, *args, **kwargs):
            raise Exception("fail_json")

        def run_command(self, *args, **kwargs):
            return 1, "foo", ""

        def warn(self, *args, **kwargs):
            raise Exception("warn")

    #

# Generated at 2022-06-23 04:29:43.003826
# Unit test for function main
def test_main():
    r=main()

# Generated at 2022-06-23 04:29:55.959125
# Unit test for function main
def test_main():
    import tempfile
    import sys
    import os
    with tempfile.NamedTemporaryFile() as tmpfile:
        ansible_module_args = {
            'name': 'foo',
            'state': 'started',
            'pattern': 'foo',
            'daemonize': True,
        }

# Generated at 2022-06-23 04:30:05.156808
# Unit test for function main
def test_main():
    args = dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    )
    assert main(args) == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:10.576604
# Unit test for function main
def test_main():
    module = AnsibleModule({
        "name": "abc",
        "enabled": True
    })
    result = main()
    assert result == {
        'name': 'abc',
        'changed': False,
        'status': {}
    }


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:17.579995
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # Execute main function
    main()



# Generated at 2022-06-23 04:30:31.041290
# Unit test for function main
def test_main():
    testmodule = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-23 04:30:39.227382
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils._text import to_bytes

    sys.stdin = open(to_bytes(__file__.replace('.pyc', '.yml')), 'rb')
    sys.argv.append(to_bytes(__file__.replace('.pyc', '.yml')))
    sys.argv.append(to_bytes('-vvvvv'))
    import unittest
    unittest.main()
    sys.stdout = sys.__stdout__


if __name__ == "__main__":
    main()

# Generated at 2022-06-23 04:30:49.420858
# Unit test for function main
def test_main():
    import os
    import platform
    import random
    import string
    import sys
    import subprocess
    import tempfile
    import time

    try:
        import sysvinit
    except ImportError:
        try:
            subprocess.check_call(['yum', 'install', 'python-daemon'])
        except:
            raise ImportError("Could not import sysvinit or python-daemon dependency")

    from ansible.module_utils.basic import AnsibleModule

    def random_string(length):
        return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(length))

    def gen_script(service_name, cmd, svc_status):
        # in memory script, throw away when done
        fd, filename = tempfile.mkstemp()
       

# Generated at 2022-06-23 04:31:05.544092
# Unit test for function main
def test_main():
    ###########################################################################
    # begin unit test
    import json

    arguments = [
        'name=test_service',
        'state=stopped',
        'enabled=false',
        'daemonize=true',
    ]


# Generated at 2022-06-23 04:31:17.425369
# Unit test for function main
def test_main():

    # BINARY_LOCATION is used as a mock object
    class BinaryLocation:
        def __init__(self, binary_name, binary_location):
            self.binary_name = binary_name
            self.binary_location = binary_location

        def get_bin_path(self, binary_name, opt_dirs=None):
            return self.binary_location

    # MOCK_MODULE is used as a mock object
    class MockModule:
        def __init__(self, module_name):
            self.module_name = module_name
            self.fail_json = Mock(return_value=None)
            self.run_command = Mock(return_value=None)
            self.get_bin_path = Mock(return_value=None)

        def check_mode(self):
            return None


# Generated at 2022-06-23 04:31:29.539279
# Unit test for function main
def test_main():
    argv = ['name', 'state', 'enabled', 'sleep', 'pattern', 'arguments', 'runlevels', 'daemonize']
    args = dict(
        name='foo',
        state='started',
        enabled=True,
        sleep=1,
        pattern='^service$',
        arguments='',
        runlevels='2 3 4 5',
        daemonize=True
    )

# Generated at 2022-06-23 04:31:41.433698
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec = dict(
            name = dict(required = True, type = 'str', aliases = ['service']),
            state = dict(choices = ['started', 'stopped', 'restarted', 'reloaded'], type = 'str'),
            enabled = dict(type = 'bool'),
            sleep = dict(type = 'int', default = 1),
            pattern = dict(type = 'str'),
            arguments = dict(type = 'str', aliases = ['args']),
            runlevels = dict(type = 'list', elements = 'str'),
            daemonize = dict(type = 'bool', default = False),
        ),
        supports_check_mode = True,
        required_one_of = [['state', 'enabled'],]
    )

# Generated at 2022-06-23 04:31:51.046994
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    import sysvinit
    main

# Generated at 2022-06-23 04:32:01.547866
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:32:11.306942
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted'], type='str'),
            enabled=dict(type='bool'),
            runlevels=dict(type='list', elements='str'),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:12.925724
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:24.144005
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # Create test cases
    # Mock data

# Generated at 2022-06-23 04:32:26.864648
# Unit test for function main
def test_main():
    unittest.TestCase('__init__')

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:32.192222
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'name': {'type': 'str', 'required': True}, })
    return main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:39.833672
# Unit test for function main
def test_main():
    module=AnsibleModule({
        "name": "unittest",
    })
    exit_return_value=main()
    module.exit_json(changed=True, meta=exit_return_value)

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.service import *
from ansible.module_utils.pycompat24 import get_exception
main()

# Generated at 2022-06-23 04:32:49.537940
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile
    service_file = 'i-do-not-exist'
    tmpdir = tempfile.mkdtemp()
    shutil.copy("/etc/init.d/vsftpd", tmpdir)
    shutil.copy("/usr/lib/systemd/system/vsftpd.service", tmpdir)
    service_link = os.path.join(tmpdir, "vsftpd")
    os.symlink(service_file, service_link)
    os.symlink("/etc/init.d/vsftpd", os.path.join(tmpdir, "vsftpd.service"))
    os.environ['PATH'] = tmpdir + ":" + os.environ['PATH']
    os.environ['HOME'] = tmpdir
    m = Ansible

# Generated at 2022-06-23 04:32:52.743843
# Unit test for function main
def test_main():
    import sys
    if '-v' in sys.argv:
        print(sys.path)
    main()


# Generated at 2022-06-23 04:33:01.090183
# Unit test for function main
def test_main():
    import sys
    import ansible.module_utils.service.sysv_service
    from ansible.module_utils.basic import AnsibleModule
    sysv_service = ansible.module_utils.service.sysv_service

    # Load module
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda *args, **kwargs: 0

    # Unit test sysvinit
    with open("tests/unit/modules/ansible/modules/system/service/test_sysvinit.py", 'r') as f:
        code = compile(f.read(), "test_sysvinit.py", 'exec')
        exec(code, locals(), globals())


# Generated at 2022-06-23 04:33:11.478356
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_exists, sysv_is_enabled, get_sysv_script
    import xml.etree.ElementTree as ET


# Generated at 2022-06-23 04:33:22.531990
# Unit test for function main
def test_main():
    import sys
    import subprocess

    # my_args = sys.stdin.read()
    # print(my_args)
    # sys.exit(0)
    # module_args = {}


# Generated at 2022-06-23 04:33:33.868672
# Unit test for function main
def test_main():
    MOCK_PARAMS = {
        'name': 'foo',
        'state': None,
        'enabled': True,
        'sleep': 1,
        'pattern': None,
        'arguments': None,
        'runlevels': [
            '5',
            '3'
        ],
        'daemonize': False
    }
    MOCK_MODULE = type('MockModule', (), MOCK_PARAMS)

    MOCK_RUN_COMMAND_RESULT = (0, 'foo', 'bar')
    MOCK_SYSTEMCTL_RESULT = (0, '', '')

    import sys
    sys.path.append("/path/to/nowhere")
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is

# Generated at 2022-06-23 04:33:48.373784
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.actions import AnsibleModuleHelper
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize
    
    

# Generated at 2022-06-23 04:33:55.081006
# Unit test for function main
def test_main():
    import sys, os
    libdir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    sys.path.insert(0, libdir)
    from test_sysvinit import mock_module, mock_run_command
    from sysvinit import main

    module = mock_module(
            params={
                'name': 'apache2',
                'state': 'started',
                'enabled': True,
                'sleep': 1,
                'pattern': False,
                'arguments': '',
                'runlevels': ['3', '5'],
                'daemonize': False
            }
        )
    setattr(module, "run_command", mock_run_command)
    main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 04:34:01.898124
# Unit test for function main
def test_main():
    class module():
        def __init__(self,params):
            self.params = params

    params = {"name":"httpd","enabled":True,"daemonize":True,"runlevels":None,"arguments":None,"state":"started","sleep":1,"pattern":None}
    module = module(params)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:11.087524
# Unit test for function main
def test_main():
    args = dict(
        name='yum-updatesd',
        state='stopped',
        pattern='yum-updatesd',
    )
    result = {'changed': True, 'status': {'stopped': {'changed': True}}, 'name': 'yum-updatesd'}
    with patch.object(AnsibleModule, 'run_command') as run_command:
        run_command.return_value = (0, 'yum-updatesd', '')
        assert sysvinit.main(AnsibleModule(**args)) == result


# Generated at 2022-06-23 04:34:15.815853
# Unit test for function main
def test_main():
    args = dict(
        daemonize=False,
        name="test_service",
        state="started",
        enabled=False,
        sleep=1
    )
    main(args)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:29.378688
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.exit_json(**main())


# Generated at 2022-06-23 04:34:40.789284
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    res = main()
    assert res[0]['changed'] == True

# Generated at 2022-06-23 04:34:46.360800
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        # arguments are ignored
        main(module)
    assert pytest_wrapped_e.type == SystemExit

# ====================================================

if __name__ == '__main__':

    main()

# Generated at 2022-06-23 04:34:48.171552
# Unit test for function main
def test_main():

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:49.828216
# Unit test for function main
def test_main():
    assert not main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:02.275316
# Unit test for function main

# Generated at 2022-06-23 04:35:11.687875
# Unit test for function main
def test_main():
    result = {
        'name': 'apache2',
        'changed': False,
        'status': {
            'started': {
                'changed': False,
                'rc': None,
                'stdout': None,
                'stderr': None
            },
            'enabled': {
                'changed': False,
                'rc': None,
                'stdout': None,
                'stderr': None
            }
        }
    }
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:13.763566
# Unit test for function main
def test_main():
    assert main() is None

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:19.373707
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    path_backup = module.get_bin_path


# Generated at 2022-06-23 04:35:31.487316
# Unit test for function main
def test_main():
    module = AnsibleModule(dict(
        name=dict(required=True),
        state=dict(default=None, required=False),
        enabled=dict(default=None, required=False),
        sleep=dict(default=None, required=False),
        pattern=dict(default=None, required=False),
        arguments=dict(default=None, required=False),
        runlevels=dict(default=None, required=False),
        daemonize=dict(default=False, required=False),
    ))

    module.run_command = lambda x: (0, '', '')
    module.get_bin_path = lambda x: '/sbin'
    module.get_ps_command = lambda: 'ps'
    module.warn = lambda x: None
    module.exit_json = lambda **kwargs: None
    module

# Generated at 2022-06-23 04:35:44.300427
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:58.216804
# Unit test for function main

# Generated at 2022-06-23 04:36:05.492367
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# import module snippets
from ansible.module_utils.basic import *

main()

# Generated at 2022-06-23 04:36:17.840688
# Unit test for function main
def test_main():
    modargs = dict(
            name="httpd",
            enabled=True,
            runlevels=[1,2,3,4,5]
        )
    mod = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ))
    result = main()
    assert result['changed'] == True


# Generated at 2022-06-23 04:36:29.953225
# Unit test for function main
def test_main():
    import json
    mod = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
    )
    def run_command(cmd):
        return (2, '', '')

    def exit_json(result):
        print(result)
        mod.exit_

# Generated at 2022-06-23 04:36:37.391782
# Unit test for function main
def test_main():
    # MagicMock object created
    module = MagicMock(name='module')
    # 'get_bin_path' method is a MagicMock object and is created as
    # an attribute to 'module' object
    module.get_bin_path = MagicMock(name='get_bin_path')
    # Returns all the attributes of 'module'
    print(dir(module))
    # Returns all the attributes of 'get_bin_path'
    print(dir(module.get_bin_path))
    # When 'main' is called with params, the 'module' is passed
    # inside the function
    main(module)


# Generated at 2022-06-23 04:36:48.767668
# Unit test for function main
def test_main():
    """Unit tests for function main"""
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()


# Generated at 2022-06-23 04:37:01.173704
# Unit test for function main
def test_main():
    module=AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    #name = module.params['name']
    #action = module.params['state']


# Generated at 2022-06-23 04:37:02.833731
# Unit test for function main
def test_main():

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:37:07.564515
# Unit test for function main
def test_main():
    for param in ["name", "state", "enabled", "runlevels", "pattern", "sleep", "arguments"]:
        if not module.params.get(param):
            module.params[param] = None

    argv = sys.argv[1:]
    argv.append("service=foo")
    sys.argv = argv
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:37:20.179724
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    mktemp = tempfile.mktemp
    PY3 = sys.version_info[0] == 3

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Create a temporary module object
    module = type("AnsibleModule", (object,), dict(
        argument_spec = dict(),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']]
    ))

    # this is for unit testing with the test playbook
    sys.modules['ansible.module_utils.basic'] = type("AnsibleModuleUtilsBasic", (object,), dict(
        AnsibleModule = module
    ))

    # check that the module works
    filename_ = mktemp()

# Generated at 2022-06-23 04:37:28.578056
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:37:41.157462
# Unit test for function main

# Generated at 2022-06-23 04:37:49.300554
# Unit test for function main
def test_main():

    answer = dict(
        changed=False,
        status=dict(
            enabled=dict(
                runlevels=["3", "5"],
                changed=False,
                rc=None,
                stdout=None,
                stderr=None
            )
        ),
        name="httpd"
    )

    has_update_rcd = False
    has_chkconfig = False
    for path in ("/sbin/update-rc.d", "/usr/sbin/update-rc.d"):
        if os.path.exists(path):
            has_update_rcd = True
            break

    for path in ("/sbin/chkconfig", "/usr/sbin/chkconfig"):
        if os.path.exists(path):
            has_chkconfig = True
            break



# Generated at 2022-06-23 04:37:58.970585
# Unit test for function main
def test_main():
    payload = {
        'daemonize': True,
        'enabled': True,
        'name': 'name',
        'runlevels': [
            'runlevel'
        ],
        'state': 'state'
    }

    module = AnsibleModule(argument_spec={})
    module.params.update(**payload)

    action_map = {}

    # run module
    sysvinit = main()

    # check attributes set
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:38:07.702806
# Unit test for function main
def test_main():
    ansible_mock = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    import os
    import sys
    import unittest


# Generated at 2022-06-23 04:38:18.674854
# Unit test for function main
def test_main():

    args = dict(
        name='httpd',
        state='started',
        enabled=True,
        sleep=1,
        pattern=None,
        arguments=None,
        runlevels=['1', '2', '3', '4', '5'],
        daemonize=False,
    )

    module = AnsibleModule(**args)

    # Loading the actual module
    from ansible.modules.system.sysvinit import main as sysvinit

    # calling the function main
    sysvinit(module)


if __name__ == '__main__':
    import sys
    import doctest
    from ansible.module_utils.basic import AnsibleModule
    # when called via ansible
    module = AnsibleModule(argument_spec=dict(foo=dict(default='bar', type='str')))
    main

# Generated at 2022-06-23 04:38:33.036784
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    

# Generated at 2022-06-23 04:38:48.824526
# Unit test for function main
def test_main():
    # test main function with mocked get_bin_path
    module = AnsibleModule(argument_spec=dict(name=dict(required=True, type='str')))
    def mock_get_bin_path(arg, opt_dirs=None):
        if arg == 'chkconfig':
            return '/opt/bin/chkconfig'
        return None
    module.get_bin_path = mock_get_bin_path

    #test main function with mocked run_command
    def mock_run_command(arg):
        if arg == 'chkconfig --list some_service':
            return (0, 'some_service 0:off 1:off 2:off', '')
        if arg == 'chkconfig some_service on':
            return (0, '', '')

# Generated at 2022-06-23 04:39:03.380131
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:39:05.365920
# Unit test for function main
def test_main():
    args = dict(
        name='sysvinit-test',
        state='started',
        arguments='my args'
    )
    module = AnsibleModule(**args)
    sysvinit_main(module)
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:15.101597
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
   

# Generated at 2022-06-23 04:39:23.141781
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    ###########################################################################
    # BEGIN: sysvinit_unit_test_main
   

# Generated at 2022-06-23 04:39:30.346079
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = u'apachetest'
    action = u'started'

# Generated at 2022-06-23 04:39:37.973068
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']