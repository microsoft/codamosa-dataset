

# Generated at 2022-06-23 04:29:46.138050
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-23 04:29:59.888436
# Unit test for function main
def test_main():
    args = {
        "name": "test",
        "state": "started",
        "enabled": True,
        "sleep": 1,
        "pattern": None,
        "arguments": "",
        "runlevels": [
            "3",
            "5"
        ],
        "daemonize": False,
        "check_mode": True,
        "diff_mode": False,
        "platform": "posix"
    }


# Generated at 2022-06-23 04:30:09.727611
# Unit test for function main
def test_main():
    """
    This is the unit test for ansible module.

    """
    ###########################################################################
    # BEGIN: Optional code for unit test
    import sys, os
    from io import StringIO

    class AnsibleModuleFake(object):
        """
        This is the class for fake ansible module
        """
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            """ fail_json funtion """
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

        def exit_json(self, *args, **kwargs):
            """ exit_json funtion """
            self.exit_args = args
            self.exit_kwargs = kw

# Generated at 2022-06-23 04:30:19.785909
# Unit test for function main
def test_main():
    test_name = 'test'
    test_args = {
            'name': test_name,
            'state': 'stopped',
            'enabled': 'yes',
            'runlevels': ['1'],
            'check_mode': True,
            'daemonize': True,
            'pattern': test_name,
            'sleep': True,
            'arguments': 'test'
        }
    import os
    from ansible.module_utils import basic
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize
    from ansible.module_utils.action_common_attributes import get_bin_path


# Generated at 2022-06-23 04:30:21.609747
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    sys.argv = [sys.argv[0]]
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:28.339139
# Unit test for function main
def test_main():
    test_module = AnsibleModule({
        "name": "top", 
        "state": "started", 
        "pattern": "top", 
        "sleep": 1, 
        "enabled": false
    })
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:40.300663
# Unit test for function main
def test_main():

    module_arg_spec = dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    )

    # simulate module
    module = AnsibleModule(argument_spec=module_arg_spec)

    mod = Sysvinit(module)

    module.exit_json(**{
        "results": mod.results
    })


# Generated at 2022-06-23 04:30:49.772883
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec={
            'name': {'required': True, 'aliases': ['service'], 'type': 'str'},
            'state': {'default': None, 'type': 'str', 'choices': ['started', 'stopped', 'restarted', 'reloaded']},
            'enabled': {'type': 'bool'},
            'sleep': {'type': 'int', 'default': 1},
            'pattern': {'type': 'str'},
            'runlevels': {'type': 'list', 'elements': 'str'},
            'arguments': {'type': 'str', 'aliases': ['args']},
        },
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()


# Generated at 2022-06-23 04:31:05.920002
# Unit test for function main
def test_main():
    test_main.__self__.maxDiff = None  # pylint: disable=no-member
    test_module = AnsibleModule({
        'name': 'test',
        'state': 'stopped',
        'enabled': True,
        'sleep': 5,
        'runlevels': [ '3', '5' ],
        'arguments': 'foo bar',
        'daemonize': True
    })

    # Check parameters
    assert isinstance(test_module, AnsibleModule)
    assert test_module.params['name'] == 'test'
    assert test_module.params['state'] == 'stopped'
    assert test_module.params['enabled'] is True
    assert test_module.params['sleep'] == 5
    assert test_module.params['runlevels'] == [ '3', '5' ]
   

# Generated at 2022-06-23 04:31:11.632154
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass

# import module snippets
if __name__ == "__main__":
    # Unit test or run?
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        test_main()
    else:
        main()

# Generated at 2022-06-23 04:31:14.057538
# Unit test for function main
def test_main():
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:23.827761
# Unit test for function main
def test_main():
    import sys
    import json
    import os
    import subprocess
    import tempfile
    import shutil

    class MockModule(object):
        """
        The mock module class.  You can specify a dictionary of return values
        with keys matching the names of the functions you wish to mock.

        You can also set the side_effect attribute to an exception class or
        instance to raise an exception when a function is called.

        """
        def __init__(self, results=None, side_effect=None):
            if results is None:
                results = {}
            self.results = results
            self.side_effect = side_effect

            for key, value in results.items():
                setattr(self, key, value)

        def __getattr__(self, item):
            if self.results is None:
                return None


# Generated at 2022-06-23 04:31:25.020882
# Unit test for function main
def test_main():
    print(__name__)
    print(main())


# Generated at 2022-06-23 04:31:32.450076
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:47.783284
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-23 04:31:59.692328
# Unit test for function main
def test_main():
    name = 'httpd'
    state = 'stopped'
    enabled = None
    runlevels = None
    pattern = None
    sleep_for = 1
    rc = 0
    out = err = ''
    result = {
        'name': name,
        'changed': False,
        'status': {}
    }

    # ensure service exists, get script name
    fail_if_missing(None, sysv_exists(name), name)
    script = get_sysv_script(name)

    # locate binaries for service management
    paths = ['/sbin', '/usr/sbin', '/bin', '/usr/bin']
    binaries = ['chkconfig', 'update-rc.d', 'insserv', 'service']

    # Keeps track of the service status for various runlevels because we can
    # operate on multiple

# Generated at 2022-06-23 04:32:01.880533
# Unit test for function main
def test_main():
    main()
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-23 04:32:12.363580
# Unit test for function main
def test_main():
    t_mock = mock.Mock()
    t_mock.params = {
        'name': 'apache2',
        'state': 'started',
        'enabled': True,
        'runlevels': None,
        'pattern': None,
        'sleep': 1,
        'daemonize': False,
        '_ansible_check_mode': False
    }
    t_mock.run_command = mock.Mock(return_value=(0, '', '', ''))
    t_mock.get_bin_path = mock.Mock(return_value='/sbin/service')
    main()

# Generated at 2022-06-23 04:32:23.873022
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']
    enabled = module.params['enabled']
    runlevels

# Generated at 2022-06-23 04:32:38.191048
# Unit test for function main
def test_main():
    def mock_run_command(self, cmd):
        if cmd == '/usr/sbin/update-rc.d apache2 defaults':
            return 0, "", ""
        elif cmd == '/usr/sbin/update-rc.d apache2 disable':
            return 0, "", ""
        elif cmd == '/etc/rc.d/init.d/apache2 status':
            return 0, "apache2 (pid 2482) is running...", ""
        elif cmd == '/etc/rc.d/init.d/apache2 stop':
            return 0, "Stopping apache2: [  OK  ]\n", ""
        elif cmd == '/etc/rc.d/init.d/apache2 start':
            return 0, "Starting apache2: [  OK  ]\n", ""

# Generated at 2022-06-23 04:32:48.927814
# Unit test for function main
def test_main():
    # Run the main function
    test_object = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1, required=True),
            pattern=dict(type='str', required=True),
            arguments=dict(type='str', aliases=['args'], required=True),
            runlevels=dict(type='list', elements='str', required=True),
            daemonize=dict(type='bool', default=False, required=True),
        ),
        required_one_of=[['state', 'enabled']],
    )
    test_att

# Generated at 2022-06-23 04:32:59.731577
# Unit test for function main
def test_main():
    expected = {
        "name": "apache",
        "changed": False,
        "status": {
            "started": {
                "changed": False,
                "rc": None,
                "stdout": None,
                "stderr": None
            },
            "enabled": {
                "changed": False,
                "rc": None,
                "stdout": None,
                "stderr": None
            }
        }
    }


# Generated at 2022-06-23 04:33:06.125871
# Unit test for function main
def test_main():
    import sys
    import ansible.module_utils.basic as basic
    import ansible.module_utils.service as service
    import ansible.module_utils.actions as actions
    from mock import patch, MagicMock

    sys.modules['ansible.module_utils.actions'] = actions
    sys.modules['ansible.module_utils.basic'] = basic
    sys.modules['ansible.module_utils.service'] = service

    module_args = {
        'name': 'my_service',
        'state': 'started',
        'sleep': 1,
        'pattern': 'my_pattern',
        'arguments': 'my_arguments',
        'runlevels': ['3', '5'],
        'daemonize': False,
    }
    # in case the module fails to exit_json
    real_exit

# Generated at 2022-06-23 04:33:07.425440
# Unit test for function main
def test_main():
  print(main())


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:16.346709
# Unit test for function main
def test_main():
    name = "test"
    state = "running"
    enabled = True
    sleep_for = 1
    pattern = None
    arguments = None
    runlevels = None
    rc = 0
    out = err = None
    # 
    fqn = __name__.split(".")[-1]
    fqn = "sysvinit." + fqn

# Generated at 2022-06-23 04:33:29.213058
# Unit test for function main

# Generated at 2022-06-23 04:33:38.345043
# Unit test for function main
def test_main():
    action_dict = {
    u'action': None,
    u'action_default': None,
    u'action_initialized': False,
    u'action_required': False,
    u'action_type': u'list',
    u'action_warnings': [],
    u'action_choices': [u'started', u'stopped', u'restarted', u'reloaded'],
    u'action_valid': True,
    u'action_value_set': False,
    u'action_value': None
    }


# Generated at 2022-06-23 04:33:39.196370
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:33:51.793132
# Unit test for function main
def test_main():
    arg_spec = dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    )
    module = AnsibleModule(argument_spec=arg_spec, supports_check_mode=True)
    name, state, enabled, sleep_for, pattern, daemonize = 'name', 'state', True, 1, 'pattern', True
    rc, out

# Generated at 2022-06-23 04:33:53.515903
# Unit test for function main
def test_main():
    if True:
        main()
# Loads python unit tests

# Generated at 2022-06-23 04:34:06.961132
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import service

    ansible = dict(
        # defaults
        ANSIBLE_MODULE_ARGS = dict(
            name='foobar',
            state='started',
            enabled=True,
            daemonize=False,
        ),
        # provided by the controller
        MODULE_ARGS = dict(),
        # (optional) provided by the controller
        MODULE_COMPLEX_ARGS = dict(),
        # embedded ansible facts, see setup.py
        ANSIBLE_FACTS=dict(module_setup=True),
    )

    # set up the module object
    basic._ANSIBLE_ARGS = dict()

# Generated at 2022-06-23 04:34:19.301421
# Unit test for function main
def test_main():
    import shutil
    from tempfile import mkdtemp
    from ansible.module_utils import modules
    from ansible.module_utils.basic import AnsibleModule

    # Create and generate test directories
    test_dir = mkdtemp()
    test_service_dir = mkdtemp(dir=test_dir)

    # Create and generate test files
    test_bin = open(os.path.join(test_dir, "test_bin"), "w")
    test_bin.write("#!/bin/bash\nexit 0")
    test_bin.close()
    os.chmod(os.path.join(test_dir, "test_bin"), 0o755)

    test_init = open(os.path.join(test_service_dir, "test_init"), "w")

# Generated at 2022-06-23 04:34:33.866939
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:34:42.569051
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_ps
    from ansible.module_utils.sysvinit_common import get_sysv_script, sysv_exists, fail_if_missing

    # Unit test for function get_sysv_script
    def test_get_sysv_script():
        assert get_sysv_script('foo') == '/etc/init.d/foo'
    # Unit test for function sysv_exists
    def test_sysv_exists():
        assert sysv_exists('foo') == True
    # Unit test for function fail_if_missing
    def test_fail_if_missing():
        assert fail_if_missing(None, True, 'foo') == True
        assert fail_

# Generated at 2022-06-23 04:34:55.790743
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:09.053686
# Unit test for function main
def test_main():
    match = None

    class test:
        class run_command:
            class sub_command:
                def __init__(self, rc, out, err):
                    assert rc is not None
                    assert out is not None
                    assert err is not None

                def __enter__(self):
                    assert self

                def __exit__(self, exc_type, exc_value, traceback):
                    assert self
            def __init__(self, command):
                assert command is not None

            def __call__(self, command):
                assert command is not None
                return test.run_command.sub_command(1, '', '')
        class exit_json:
            def __init__(self, **kwargs):
                global match
                match = kwargs

# Generated at 2022-06-23 04:35:22.476063
# Unit test for function main

# Generated at 2022-06-23 04:35:32.433065
# Unit test for function main

# Generated at 2022-06-23 04:35:44.545997
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize


# Generated at 2022-06-23 04:35:58.519967
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec={
            "name": {"required": True, "type": "str", "aliases": ["service"]},
            "state": {"choices": ["started", "stopped", "restarted", "reloaded"], "type": "str"},
            "enabled": {"type": "bool"},
            "sleep": {"type": "int", "default": 1},
            "pattern": {"type": "str"},
            "arguments": {"type": "str", "aliases": ["args"]},
            "runlevels": {"type": "list", "elements": "str"},
            "daemonize": {"type": "bool", "default": False},
        },
        required_one_of=[["state", "enabled"]],
    )

    name = module.params['name']

# Generated at 2022-06-23 04:36:12.231105
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # import module snippets
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 04:36:18.309889
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            state=dict(required=False),
            enabled=dict(required=False),
            sleep=dict(default=1, type='int'),
            pattern=dict(required=False),
            arguments=dict(aliases=['args'], required=False),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = "ansible-working"
    action = "started"
    enabled = True
    rc = 0
    out = err = ""
    result = {}
    result["name"] = name

# Generated at 2022-06-23 04:36:30.247301
# Unit test for function main
def test_main():
    result=dict(
        attempts=1,
        changed=True,
        name="service",
        status=dict(
            enabled=dict(
                changed=True,
                rc=0,
                stderr="",
                stdout="",
                runlevels=["1"]
            ),
            started=dict(
                changed=True,
                rc=0,
                stderr="",
                stdout="Stopping web server: apache2.\n"
            )
        )
    )

    def run_command_mock(module, cmd):
        return 0, "Stopping web server: apache2.\n", ""

    def get_bin_path_mock(module, name, opt_dirs=[]):
        if name == 'service':
            return "/usr/sbin/service"
       

# Generated at 2022-06-23 04:36:38.697012
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:42.541364
# Unit test for function main
def test_main():
    module_args = dict(service='httpd', state='stopped')
    r = AnsibleModule(module_args).run()
    assert r['changed'] is False

# Test module

# Generated at 2022-06-23 04:36:51.485834
# Unit test for function main
def test_main():
    # test module execution
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-23 04:37:03.338034
# Unit test for function main
def test_main():
    # Test case where name is specified
    args = dict(
        name = "apache2",
        state = "started"
    )
    res = main(args)
    assert res["status"]["started"]["changed"] == False
    assert res["status"]["started"]["rc"] == None

    args = dict(
        name = "apache2",
        state = "stopped"
    )
    res = main(args)
    assert res["status"]["stopped"]["changed"] == False
    assert res["status"]["stopped"]["rc"] == None

    args = dict(
        name = "apache2",
        state = "restarted"
    )
    res = main(args)
    assert res["status"]["restarted"]["changed"] == True

# Generated at 2022-06-23 04:37:04.664115
# Unit test for function main
def test_main():
    print(main())
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 04:37:17.209948
# Unit test for function main
def test_main():

    # Set up a test object
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # Set up the test function name
    name = module.params

# Generated at 2022-06-23 04:37:19.167538
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:37:30.043998
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize, sysv_get_runlevels
    from ansible.module_utils import action_common_attributes
    from ansible.module_utils import common_koji
    from ansible.module_utils.distribution import Distribution
    from ansible.module_utils.network import LinuxDistribution
    from ansible.module_utils.six.moves import builtins


# Generated at 2022-06-23 04:37:42.385913
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'name': {'type': 'str', 'required': True},
                                          'enable': {'type': 'bool'},
                                          'state': {'choices': ['started', 'stopped', 'restarted', 'reloaded'], 'type': 'str'},
                                          'runlevels': {'type': 'list', 'elements': 'str'},
                                          'daemonize': {'type': 'bool', 'default': False}},
                           supports_check_mode=True, required_one_of=[['state', 'enable']])

    class MockResult:
        def __init__(self, code, msg, cmd=''):
            self.rc = code
            self.stdout = self.stderr = msg
            self.cmd = cmd

   

# Generated at 2022-06-23 04:37:43.725365
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:37:51.029801
# Unit test for function main
def test_main():
    def testrun(**kwargs):
        return {'msg': 'success', 'rc': 0, 'out': 'test', 'stderr': 'test', 'changed': True, 'name': 'test' }
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str'),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
        arguments=dict(type='str', aliases=['args']),
        pattern=dict(type='str'),
        sleep=dict(type='int', default=1)
    )
    )
    module.run_

# Generated at 2022-06-23 04:38:03.519276
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:38:15.379072
# Unit test for function main
def test_main():

    # Stub sub functions
    def sysv_is_enabled(name, *args, **kwargs):
        return True
    def get_sysv_script(name):
        return '/etc/init.d/ansible'
    def sysv_exists(name):
        return True
    def fail_if_missing(module, value, msg):
        return None
    def get_ps(module, pattern):
        return True
    def daemonize(module, cmd):
        return (0, 'dummy output', 'dummy err')

    # Set up module and stub functions

# Generated at 2022-06-23 04:38:23.224189
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import service
    from ansible.module_utils.service import sysv_is_enabled, fail_if_missing, sysv_exists
    from io import StringIO
    import sys
    import pytest
    from tempfile import TemporaryDirectory
    from ansible.module_utils import basic
    import os

    def dummy_module_mock(**kwargs):
        dummy_module_mock.dummy_module_mock_results = kwargs
        return kwargs

    dummy_module_mock.dummy_module_mock_results = None

    class TemporaryDirectoryMock():
        def __enter__(self):
            return '/tmp'

        def __exit__(self, type, value, traceback):
            return '/tmp'

   

# Generated at 2022-06-23 04:38:27.329920
# Unit test for function main
def test_main():
    test_args = [ 'service', 'httpd', 'state', 'started', 'enabled', True ]

# Generated at 2022-06-23 04:38:37.987139
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']]
    )
    (rc, out, err) = main()
    module.fail_json(rc=rc, out=out, err=err)


# Generated at 2022-06-23 04:38:56.264178
# Unit test for function main
def test_main():
    name = 'foo'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-23 04:38:56.886222
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-23 04:39:02.605610
# Unit test for function main
def test_main():

    test_args = ['-m', '-a' , 'name=foo', 'state=restared', 'enabled=True']
    with pytest.raises(SystemExit):
        main()

    with patch.object(AnsibleModule, 'run_command') as mock_run_command, \
        patch.object(AnsibleModule, 'get_bin_path') as mock_get_bin_path:
        instance = mock_run_command.return_value
        instance.return_code = 0
        instance.stdout = 'stdout'

        instance = mock_get_bin_path.return_value
        instance.return_code = 0
        instance.stdout = '/opt/bin/chkconfig'


# Generated at 2022-06-23 04:39:10.591456
# Unit test for function main
def test_main():
    test_input = {
      "action": "restart",
      "check_mode": False,
      "daemonize": False,
      "enabled": None,
      "name": "pgsql-8.3",
      "pattern": None,
      "runlevels": None,
      "sleep": 1,
      "state": "restarted"
    }

# Generated at 2022-06-23 04:39:18.807519
# Unit test for function main
def test_main():
    # function main - AnsibleModule object
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    # call the function
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:31.248061
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:43.839970
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.run_command = Mock(return_value=(0, '', ''))