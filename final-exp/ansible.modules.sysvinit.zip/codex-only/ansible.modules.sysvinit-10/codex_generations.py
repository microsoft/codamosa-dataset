

# Generated at 2022-06-23 04:29:34.818273
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:29:46.093169
# Unit test for function main

# Generated at 2022-06-23 04:29:50.828945
# Unit test for function main
def test_main():

    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.common.parameters import json_dict_unicode_to_bytes
    import json


# Generated at 2022-06-23 04:30:03.560408
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import unittest

    def create_test_script(path):
        with open(path, 'w') as f_script:
            f_script.write(TEST_SYSTEMD_SERVICE)

    TEST_SYSTEMD_SERVICE = """[Unit]
Description=Example Service
After=network.target

[Service]
Type=oneshot
ExecStart=/usr/bin/python -c "print 'hello world'"
ExecStop=/usr/bin/python -c "print 'goodbye'"
RemainAfterExit=yes

[Install]
WantedBy=default.target
"""

    class TestSysVInit(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

# Generated at 2022-06-23 04:30:12.671410
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    if not basic.HAS_SUBPROCESS:
        raise SkipTest("Subprocess is not available")
    from ansible.module_utils import service
    from ansible.module_utils import sysv_is_enabled
    from ansible.module_utils import sysv_exists
    from ansible.module_utils import get_sysv_script
    from tempfile import TemporaryFile
    import os
    import sys
    import re

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            self.exit_called = True


# Generated at 2022-06-23 04:30:17.241941
# Unit test for function main
def test_main():

    # Action test for service starts and stops
    class Args(object):
        daemonize = False
        enabled = None
        arguments = None
        state = 'started'
        sleep = 1
        pattern = None
        runlevels = None

    class Module(object):
        def __init__(self, daemonize, enabled, arguments, state, sleep, pattern, runlevels):
            self.params = Args()
            self.params.daemonize = daemonize
            self.params.enabled = enabled
            self.params.arguments = arguments
            self.params.state = state
            self.params.sleep = sleep
            self.params.pattern = pattern
            self.params.runlevels = runlevels
        
        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/' + name

       

# Generated at 2022-06-23 04:30:30.991614
# Unit test for function main
def test_main():
    argument_spec = dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        sleep=dict(type='int', default=1)
    )


# Generated at 2022-06-23 04:30:41.272133
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import get_sysv_script
    test_module = AnsibleModule(argument_spec={
        'name': { 'required': True },
        'state': { 'required': False, 'type': 'str', 'choices': ['started', 'stopped', 'restarted', 'reloaded'] },
        'enabled': { 'required': False, 'type': 'bool' },
        'runlevels': { 'required': False, 'type': 'list', 'elements': 'str' },
        'arguments': { 'required': False, 'type': 'str' },
        'daemonize': { 'required': False, 'type': 'bool', 'default': False },
    })
    # test_module.params = { 'name': 'service

# Generated at 2022-06-23 04:30:42.260982
# Unit test for function main
def test_main():
    """ Unit test for function main"""


# Generated at 2022-06-23 04:30:50.761601
# Unit test for function main
def test_main():

    # Name
    module_args = {'name': 'iptables'}

    # State
    module_args['state'] = 'started'
    result = main(module_args)
    assert result['changed']

    module_args['state'] = 'reloaded'
    result = main(module_args)
    assert result['changed']

    # Enabled
    module_args['enabled'] = True
    result = main(module_args)
    assert result['changed']

    module_args['enabled'] = False
    result = main(module_args)
    assert result['changed']

    # Runlevels
    module_args['runlevels'] = ['3', '5']
    module_args['enabled'] = True
    result = main(module_args)
    assert result['changed']


# Generated at 2022-06-23 04:30:57.740152
# Unit test for function main
def test_main():
    # TODO: Implement a unit test for the action module: sysvinit
    # Test function main, module sysvinit, result sysvinit
    assert True


# Generated at 2022-06-23 04:31:06.221157
# Unit test for function main
def test_main():
    # Bypassing the argument spec, we can run this unit test without having
    # to fake a service.
    module = AnsibleModule(argument_spec={})
    module.check_mode = True

    # Insert artifical functions

    # Do the test
    main()

    # Dispose artifical functions
    del sysv_is_enabled
    del get_sysv_script
    del sysv_exists
    del fail_if_missing
    del get_ps
    del daemonize

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:18.083392
# Unit test for function main

# Generated at 2022-06-23 04:31:26.538218
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.run_command = lambda *args, **kwargs: ("", "", "")
   

# Generated at 2022-06-23 04:31:40.416091
# Unit test for function main
def test_main():

    # See unit test docs for more on this setup
    mock_check_mode = True
    mock_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )



# Generated at 2022-06-23 04:31:52.003302
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()


#############################
# Unit Tests                #
#############################


# Generated at 2022-06-23 04:31:53.103856
# Unit test for function main
def test_main():
    print(main())

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 04:32:02.634642
# Unit test for function main
def test_main():
    result = {
        'changed': False,
        'results': {
            'enabled': {
                'changed': False
            },
            'running': {
                'changed': False
            }
        }
    }


# Generated at 2022-06-23 04:32:15.222201
# Unit test for function main
def test_main():

    # Test case#1
    class ModuleStub(object):
        """Stub class for testing"""

        def __init__(self):
            self.params = {}
            self.args = {
                'actions': [
                    {
                        'name': 'testactions',
                        'required_one_of': [
                            {
                                'state': 'COlOred',
                                'enabled': 'COlOred'
                            }
                        ]
                    }
                ]
            }

        def fail_json(self, **kwargs):
            """Stubbing fail_json method"""

            self.args.update(kwargs)
            return 0

        def get_bin_path(self, binname, opt_dirs=None):
            """Stubbing get_bin_path method"""


# Generated at 2022-06-23 04:32:26.446566
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

# import module snippets
from ansible.module_utils.basic import *

# Generated at 2022-06-23 04:32:40.679790
# Unit test for function main
def test_main():
    # Get the short name of the module
    module_name = __name__.rsplit('.')[-1]
    # Import the module source
    module = __import__(module_name)
    # Get the source code from the module
    f2 = open(module.__file__.rsplit('.')[0]+'.py', 'r')
    f1 = open('/tmp/test_'+module_name+'.py', 'w')
    f1.write('#!/usr/bin/env python\n')
    f1.write('\n')
    f1.write('"""\n')
    for i in f2.readlines():
        if i[:5] == 'class':
            break
        f1.write(i)
    f1.write('"""\n')
    f1.write

# Generated at 2022-06-23 04:32:42.495720
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:44.068807
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:47.463409
# Unit test for function main
def test_main():

    print(main.__doc__)

    sysvinit = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sysvinit.exit_json(changed=False, results="foo")


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:49.514600
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()
# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 04:33:00.217067
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    # set up a fake module

# Generated at 2022-06-23 04:33:01.892985
# Unit test for function main
def test_main():
    print("Unit test for function main")
    pass

if __name__ == '__main__':
    main()
    #test_main()

# Generated at 2022-06-23 04:33:07.523231
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int'),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False)
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    if __name__ == '__main__':
        main()


# Generated at 2022-06-23 04:33:17.922587
# Unit test for function main
def test_main():
    #pylint: disable=ungrouped-imports
    import sys
    import ansible.module_utils.basic
    import ansible.module_utils.service
    #pylint: enable=ungrouped-imports
    class Argv(object):
        def __getitem__(self, index):
            return "/usr/bin/ansible-local"
    old_argv = sys.argv
    sys.argv = Argv()
    result = main()
    sys.argv = old_argv

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 04:33:30.441121
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = test_module.params['name']

# Generated at 2022-06-23 04:33:38.588741
# Unit test for function main
def test_main():
    import tempfile
    import ansible.module_utils.basic
    import ansible.module_utils.service
    import ansible.module_utils.actions
    import ansible.module_utils.facts.system.distribution

    my_sysv_exists = ansible.module_utils.service.sysv_exists
    my_get_sysv_script = ansible.module_utils.service.get_sysv_script
    my_sysv_is_enabled = ansible.module_utils.service.sysv_is_enabled
    my_fail_if_missing = ansible.module_utils.service.fail_if_missing
    my_get_bin_path = ansible.module_utils.basic.AnsibleModule.get_bin_path

# Generated at 2022-06-23 04:33:51.044065
# Unit test for function main
def test_main():
    # Mock module
    parent_dirs = []
    for parent_dir in __file__.split("/")[0:-1]:
        parent_dirs.append(parent_dir)
    file_path = "/".join(parent_dirs) + "/ansible_module_sysvinit.py"

    # Mock module
    sys.modules["ansible.module_utils.basic"] = MagicMock()
    m = MagicMock()
    m.get_bin_path.return_value = "/bin/service"
    m.get_bin_path.side_effect = lambda x: "/bin/service"
    m.run_command.return_value = (0, "", "")
    m.run_command.side_effect = lambda x: (0, "", "")
    m.fail_json.side_effect

# Generated at 2022-06-23 04:34:04.553639
# Unit test for function main
def test_main():
    import tempfile
    temp = tempfile.NamedTemporaryFile()

    # Test case 1
    # unit test function
    # want to intercept exit_json so we don't actually exit
    def exit_json(*args, **kwargs):
        if 'changed' in kwargs:
            return kwargs['changed']
        return False

    # need to create a stub for the function get_bin_path
    def get_bin_path_fake(binary, opt_dirs=[]):
        return binary


# Generated at 2022-06-23 04:34:16.673995
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils import basic
    # test setup

# Generated at 2022-06-23 04:34:30.379101
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()


if __name__ == '__main__':
    main()
# Unit test

# Generated at 2022-06-23 04:34:41.379987
# Unit test for function main
def test_main():
    import sys
    import os
    # Set the module_utils path, so that Ansible can find the modules.
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../'))
    # Fail fast if there is any argument parsing error.

# Generated at 2022-06-23 04:34:54.785283
# Unit test for function main
def test_main():
    # Module mock
    class AnsibleModuleMock(object):
        def __init__(self, argument_spec=None, supports_check_mode=True, required_one_of=None):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.required_one_of = required_one_of
            self.exit_json = sys.exit
            self.fail_json = sys.exit
            self.warn = print

        def get_bin_path(self, binary, opt_dirs=None):
            return "/usr/bin/some_bin"

        def run_command(self, cmd):
            return (0, "check_mode ran", "")

    main(AnsibleModuleMock)


# Generated at 2022-06-23 04:35:07.719269
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # run your code
    main()

# import module snippets

# Generated at 2022-06-23 04:35:20.915576
# Unit test for function main
def test_main():
    test1_in = {
        'name': 'apache2',
        'state': 'started',
        'enabled': True,
        'sleep': 1,
        'pattern': None,
        'arguments': None,
        'runlevels': None,
        'daemonize': False
    }
    test1_out = {
        'results': {
            'name': 'apache2',
            'changed': True,
            'status': {
                'enabled': {
                    'changed': True,
                    'rc': 0,
                    'stdout': None,
                    'stderr': None
                },
                'started': {
                    'changed': True,
                    'rc': 0,
                    'stdout': None,
                    'stderr': None
                }
            }
        }
    }
    test1

# Generated at 2022-06-23 04:35:32.463738
# Unit test for function main
def test_main():
    # import module snippets
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize
    
    # import mock snippets
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 04:35:44.546481
# Unit test for function main
def test_main():
    testmodule = AnsibleModule(
  name=os.path.basename(__file__),
  argument_spec=dict(
    name=dict(required=True, type='str'),
    state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
    enabled=dict(type='bool'),
    sleep=dict(type='int', default=1),
    pattern=dict(type='str'),
    arguments=dict(type='str', aliases=['args']),
    runlevels=dict(type='list', elements='str'),
    daemonize=dict(type='bool', default=False),
  ),
  supports_check_mode=True,
  required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-23 04:35:58.519994
# Unit test for function main
def test_main():
    from ansible.module_utils.common.shell import ShellError
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import (get_bin_path, get_ps)
    from ansible.module_utils.common import (get_platform, get_distribution)
    from mock import patch
    from time import sleep

    def mock_run_command(cmd, *args, **kwargs):
        if 'systemctl' in cmd:
            return -1, '', ''
        elif 'service' in cmd:
            return -1, '', ''
        elif 'chkconfig' in cmd:
            return 0, kwargs['check_rc'](kwargs['rc'])
        elif 'update-rc.d' in cmd:
            return 0, kwargs

# Generated at 2022-06-23 04:36:12.230317
# Unit test for function main

# Generated at 2022-06-23 04:36:21.780456
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:33.022465
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:36:45.692491
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    try:
        main()
    except SystemExit as excep:
        print(repr(excep))

# Generated at 2022-06-23 04:36:59.021665
# Unit test for function main
def test_main():
    package = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    #print 'package: ', package
    #print '

# Generated at 2022-06-23 04:37:10.986960
# Unit test for function main
def test_main():
    moh = MockAnsibleModule(dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ))
    moh.set_command_arguments(dict(
        arguments='',
        daemonize='False',
        enabled='True',
        name='apache2',
        sleep=1,
        state='started',
    ))


# Generated at 2022-06-23 04:37:23.314553
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    assert True == main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:37:25.286322
# Unit test for function main
def test_main():
    # TODO: Add unit tests
    return 1

# BOILERPLATE CODE BELOW
#


# Generated at 2022-06-23 04:37:38.800808
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.run_command = lambda x: ('FAILED', '', 'ERROR: foo')


# Generated at 2022-06-23 04:37:48.590011
# Unit test for function main
def test_main():
    test1 = dict(
        name='test1',
        state='stopped',
    )
    test2 = dict(
        name='test2',
        enabled=False,
    )
    test3 = dict(
        name='test3',
        state='started',
        sleep=0,
    )
    test4 = dict(
        name='test4',
        state='started',
        sleep=0,
        daemonize=True,
    )
    test5 = dict(
        name='test5',
        state='started',
        sleep=5,
        daemonize=True,
    )
    test6 = dict(
        name='test6',
        state='started',
        sleep=0,
        daemonize=False,
    )

# Generated at 2022-06-23 04:38:02.251268
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize

# Generated at 2022-06-23 04:38:10.111049
# Unit test for function main
def test_main():
    import sys
    import StringIO
    import __builtin__

    fd = StringIO.StringIO()
    sys.stdout = fd


# Generated at 2022-06-23 04:38:14.857630
# Unit test for function main
def test_main():
    import sys
    import os
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']]
    )



# Generated at 2022-06-23 04:38:22.870988
# Unit test for function main
def test_main():

    test_argv = []
    test_output = '{"failed": true, "msg": "Missing required arguments: action"}'
    test_main_result = main(test_argv)
    assert test_main_result['msg'] == "Missing required arguments: action"
    assert test_main_result['failed']

    test_argv = ['name=svc']
    test_output = '{"failed": true, "msg": "No action detected in task or implicit. The old \"service\" module no longer supports implicit run."}'
    test_main_result = main(test_argv)
    assert test_main_result['msg'] == "No action detected in task or implicit. The old \"service\" module no longer supports implicit run."
    assert test_main_result['failed']


# Generated at 2022-06-23 04:38:36.094269
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # get sysvinit service script path
    res = get_sysv_script("apache2")

# Generated at 2022-06-23 04:38:54.865169
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    test_module.exit_json = mock_exit_json
    test_module.run

# Generated at 2022-06-23 04:38:59.304144
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:08.912668
# Unit test for function main
def test_main():
    import tempfile
    from ansible.modules.system.sysvinit import main
    from ansible.module_utils.six import StringIO

    # Mock the module input parameters

# Generated at 2022-06-23 04:39:12.062690
# Unit test for function main
def test_main():
    # Load test scenario/fixtures
    sys.path.append('tests/python')
    from unit_tests import test_main
    test_main(sys.argv[1:])


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:17.460996
# Unit test for function main
def test_main():
    name = 'apache2'
    state = 'started'
    enabled = True
    runlevels = [3, 5]
    sleep_for = 1
    pattern = None
    command = 'service apache2 status'



# Generated at 2022-06-23 04:39:22.263357
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_exists
    from ansible.module_utils.service import sysv_is_enabled
    import time
    import subprocess

    # check service should be enabled
    def check_service_should_be_enabled(name, runlevel=None):
        module = AnsibleModule(argument_spec={'name': {'required': True}, 'enabled': {'default': True}})
        result_enabled = sysv_is_enabled(name, runlevel)
        assert result_enabled == True

    # check service should be disabled

# Generated at 2022-06-23 04:39:33.184218
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
            state = dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled = dict(type='bool'),
            pattern = dict(type='str'),
            arguments = dict(type='str', aliases=['args']),
            runlevels = dict(type='list', elements='str'),
            daemonize = dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
        supports_check_mode=True,
    )

    from sysvinit import main
    from ansible.module_utils.basic import AnsibleModule

    main(module)
        #assert False
