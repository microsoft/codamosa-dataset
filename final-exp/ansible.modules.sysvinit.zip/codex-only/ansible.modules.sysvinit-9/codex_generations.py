

# Generated at 2022-06-23 04:29:40.237706
# Unit test for function main
def test_main():
    # get return value and check module args
    res_args, res_rc = run_test()
    assert res_rc['failed'] == False
    assert res_rc['changed'] == False



# Generated at 2022-06-23 04:29:51.291594
# Unit test for function main
def test_main():
    test_args = {
        'name': 'sshd',
        'state': 'restarted',
        'enabled': True,
        'sleep': 10,
        'pattern': 'sshd',
        'arguments': '',
        'runlevels': ['3', '5'],
        'daemonize': False,
    }
    test_result = dict(
        name='sshd',
        changed=True,
        status={'enabled': {'changed': True, 'rc': 0, 'stderr': '', 'stdout': ''}, 'restarted': {'changed': True, 'rc': 0, 'stderr': '', 'stdout': ''}}
    )


# Generated at 2022-06-23 04:30:03.989693
# Unit test for function main
def test_main():

    class Args(object):
        '''Fake class to change the module.params'''
        def __init__(self):
            self.state = None


# Generated at 2022-06-23 04:30:15.096861
# Unit test for function main
def test_main():
    class Args:
        name='common-auth'
        state=None
        enabled=True
        sleep=1
        pattern=None
        arguments=None
        runlevels=None
        daemonize=False

        def __init__(self, **kwargs):
            for key, value in kwargs.iteritems():
              setattr(self, key, value)

    class FailJson:
        def __init__(self, **kwargs):
            self.msg=""
            self.result=""
            self.rc=""
            self.stderr=""
            self.stdout=""
            self.status=""
            self.checked=""
            self.disabled=""
            self.enabled=""
            self.changed=""
            self.runlevels=""
            self.check_mode=True

# Generated at 2022-06-23 04:30:28.904629
# Unit test for function main
def test_main():
    test1 = {
        "name": "apache",
        "state": "stopped",
        "enabled": True,
        "runlevels": [
            "3",
            "5"
        ],
        "sleep": 1,
        "pattern": "",
        "arguments": "",
        "daemonize": False
    }
    test_ans = {
        "results": {
            "attempts": 1,
            "changed": True,
            "name": "apache",
            "status": {
                "enabled": {
                    "changed": True,
                    "runlevels": [
                        "3",
                        "5"
                    ],
                    "rc": 0,
                    "stderr": "",
                    "stdout": ""
                }
            }
        }
    }

# Generated at 2022-06-23 04:30:30.368552
# Unit test for function main
def test_main():
    # test_module = AnsibleModule(argument_spec=dict(), 
    #                             supports_check_mode=True)
    # test_main()
    # main(test_module.params)
    pass


# Generated at 2022-06-23 04:30:34.109364
# Unit test for function main
def test_main():
    from ansible.modules.system.sysvinit import main

# Boilerplate code to execute module as a script
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:43.168703
# Unit test for function main
def test_main():
    """ Unit test for ansible.module_utils.service.sysvinit """


# Generated at 2022-06-23 04:30:48.778908
# Unit test for function main
def test_main():
    def stub_module_run_command(module, command):
        if command.startswith('/sbin/update-rc.d apache2 enable'):
            return (0, '', '')
        elif command.startswith('/sbin/update-rc.d apache2 disable'):
            return (0, '', '')
        elif command.startswith('/sbin/chkconfig --level 2345 apache2 on'):
            return (0, '', '')
        elif command.startswith('/sbin/chkconfig --level 2345 apache2 off'):
            return (0, '', '')
        elif command.startswith('/sbin/chkconfig apache2 on'):
            return (0, '', '')

# Generated at 2022-06-23 04:31:05.032286
# Unit test for function main
def test_main():
  test_module = AnsibleModule(argument_spec={'name': {'required': True, 'type': 'str', 'aliases': ['service']},
                                             'state': {'choices': ['started', 'stopped', 'restarted', 'reloaded'], 'type': 'str'},
                                             'enabled': {'type': 'bool'},
                                             'sleep': {'type': 'int', 'default': 1},
                                             'pattern': {'type': 'str'},
                                             'arguments': {'type': 'str', 'aliases': ['args']},
                                             'runlevels': {'type': 'list', 'elements': 'str'},
                                             'daemonize': {'type': 'bool', 'default': False}})
  # Check basic requirements

# Generated at 2022-06-23 04:31:11.320327
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:23.757077
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    print("Running test")
    assert(main()) is True


# Generated at 2022-06-23 04:31:32.509462
# Unit test for function main
def test_main():
    print("ExecuteTest")
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    name = module.params['name']

# Generated at 2022-06-23 04:31:47.783940
# Unit test for function main
def test_main():
    # CHECK_MODE
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str', default=''),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # Mock
    # Mocks must be defined before

# Generated at 2022-06-23 04:31:50.012668
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:00.914149
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:09.942469
# Unit test for function main
def test_main():

    # Pull in our common testing code
    import tests.utils as utils

    module = utils.AnsibleExitJson()
    module.params = {
        'name': 'nginx',
        'state': 'started',
        'sleep': None,
        'pattern': None,
        'runlevels': None,
        'enabled': None,
        'arguments': None,
        'daemonize': False
    }

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:21.040727
# Unit test for function main
def test_main():
    import sys
    import argparse
    import os
    import unittest

    #replace this line with the code you are testing:
    class TestMain(unittest.TestCase):
        @classmethod
        def setup_class(self):
            self.action = 'start'
            self.enabled = True
            self.runlevels = [2, 3]
            self.sleep = 1
            self.pattern = None
            self.arguments = None
            self.daemonize = False

# Generated at 2022-06-23 04:32:26.272300
# Unit test for function main
def test_main():
    module_params = {
        'name': 'foo',
        'action': 'started',
        'enabled': False,
        'sleep': 1,
        'pattern': 'bar',
        'arguments': '',
        'runlevels': '',
        'daemonize': False,
    }
    module_obj = AnsibleModule(argument_spec=module_params, supports_check_mode=True)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:40.505389
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec={
            'name' : {'type': 'str', 'required': True, 'aliases': ['service']},
            'state': {'choices': ['started', 'stopped', 'restarted', 'reloaded'], 'type': 'str'},
            'enabled': {'type':'bool'},
            'sleep': {'type':'int', 'required': True},
            'pattern': {'type':'str'},
            'arguments': {'type': 'str', 'required': False, 'aliases': ['args']},
            'runlevels': {'type':'list', 'elements': 'str'},
            'daemonize': {'type': 'bool', 'required': True}
        }
    )
    import sys


# Generated at 2022-06-23 04:32:42.353824
# Unit test for function main
def test_main():
    res = main()
    assert False
if __name__ == "__main__":
    main()

# Generated at 2022-06-23 04:32:43.914222
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:51.636945
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:01.231904
# Unit test for function main
def test_main():
    os = Mock()
    os.environ = dict()
    os.path.basename.return_value = "test"
    os.path.exists.return_value = True
    os.path.isfile.return_value = True
    os.path.join.return_value = "test"
    os.makedirs = Mock()
    os.stat = Mock()
    os.stat.st_uid = 1
    os.stat.st_gid = 1
    os.stat.st_mode = 0o755
    os.remove = Mock()
    os.remove.side_effect = None
    os.unlink = Mock()
    os.unlink.side_effect = None
    os.chmod = Mock()
    os.chmod.side_effect = None
    os.chown = Mock()
   

# Generated at 2022-06-23 04:33:11.596846
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import service
    from ansible.module_utils import action_common_attributes
    from ansible.module_utils import module_common_argspec
    from ansible.module_utils.six.moves import builtins

# Generated at 2022-06-23 04:33:22.944543
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # Mock values
    name = 'apache2'
    action = 'started'

# Generated at 2022-06-23 04:33:33.054384
# Unit test for function main
def test_main():
    g_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:47.425181
# Unit test for function main
def test_main():

    import tempfile
    import shutil
    import time

    runlevel_dir = "/etc/rc3.d/"
    if not os.path.isdir(runlevel_dir):
        os.makedirs(runlevel_dir)

    tempdir = tempfile.mkdtemp()
    test_script = os.path.join(tempdir, 'test.py')

    fh = open(test_script, 'w')
    fh.write("""#!/usr/bin/python
import sys
print sys.argv[1]
""")
    fh.close()

# Generated at 2022-06-23 04:34:00.425942
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:34:12.440399
# Unit test for function main
def test_main():
  argv = ["sysvinit", "-m", "/usr/share/ansible/plugins/modules/system/sysvinit.py", "-a", "name=nginx", "-a", "state=reloaded", "-a", "enabled=yes", "-a", "runlevels=3,5", "-e", "@/etc/ansible/hosts", "-vvvv", "--extra-vars", "{}"]
  from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 04:34:26.434071
# Unit test for function main
def test_main():
   
    m = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service'], choices=['cron']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    test_main_class = main(m)

# Generated at 2022-06-23 04:34:28.130144
# Unit test for function main
def test_main():
    rc, out, err = main()
    assert rc == 0

# Generated at 2022-06-23 04:34:40.104201
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-23 04:34:51.710304
# Unit test for function main
def test_main():
  argv = [
    "/usr/bin/ansible-playbook",
    "--ssh-common-args=-o IdentitiesOnly=yes -o PubkeyAuthentication=no -o StrictHostKeyChecking=no -o User=root -o ConnectTimeout=10 -o ControlMaster=auto -o ControlPersist=60s",
    "--private-key=/tmp/vagrant_private_key",
    "--user=root",
    "--extra-vars",
    "ansible_python_interpreter=/usr/bin/python3",
    "/tmp/test.yml"
  ]
  rc = main()
  assert rc == 0


# Generated at 2022-06-23 04:34:54.412578
# Unit test for function main
def test_main():
    main()

# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:07.274069
# Unit test for function main
def test_main():
    testobj = AnsibleModule( argument_spec = dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ))
    def get_bin_path(self, executable, opt_dirs=[]):
        return executable
    testobj.get_bin_path = lambda executable, opt_dirs: executable

# Generated at 2022-06-23 04:35:20.551740
# Unit test for function main
def test_main():
    import pytest
    test_module = pytest.importorskip("ansible.plugins.action")

    kwargs = {
        "name": "apache2",
        "state": "started",
        "enabled": True,
        "sleep": 1,
        "pattern": None,
        "arguments": 1,
        "runlevels": None,
        "daemonize": False
    }
    obj = test_module.ActionModule(
        argument_spec={
            "enabled": True,
            "sleep": 1,
            "pattern": True,
            "arguments": 1,
            "runlevels": True,
            "daemonize": False,
            "name": True,
            "state": True
        }
    )
    obj.params = kwargs

# Generated at 2022-06-23 04:35:32.217551
# Unit test for function main
def test_main():
    out_fail_json = dict(msg='Failed to restart service: name')
    out_exit_json = dict(changed=False, status=dict())


# Generated at 2022-06-23 04:35:37.127861
# Unit test for function main
def test_main():
    result = main()


if __name__ == '__main__':
   main()

# import module snippets
from ansible.module_utils.basic import *

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 04:35:46.706509
# Unit test for function main
def test_main():
    sys.modules['ansible'] = Mock()
    sys.modules['ansible.module_utils.basic'] = Mock()
    sys.modules['ansible.module_utils.service'] = Mock()
    sys.modules['ansible.module_utils.service'].sysv_is_enabled = lambda x, y: True
    sys.modules['ansible.module_utils.service'].get_sysv_script = lambda x, y: True
    sys.modules['ansible.module_utils.service'].sysv_exists = lambda x, y: True
    sys.modules['ansible.module_utils.service'].fail_if_missing = lambda x, y, z: True
    sys.modules['ansible.module_utils.service'].get_ps = lambda x, y: True
    import sysvinit as mym


# Generated at 2022-06-23 04:35:59.410747
# Unit test for function main
def test_main():

    import sys
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO


# Generated at 2022-06-23 04:36:12.561263
# Unit test for function main
def test_main():
    from ansible.module_utils.ansible_release import __version__ as ANSIBLE_VERSION
    from ansible.module_utils.six import PY3

    if not PY3:
        # Ansible 2.4 drops py2 support in tests
        raise SkipTest()


# Generated at 2022-06-23 04:36:18.336019
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'name': {'type': 'str'}, 'state': {'type': 'str'}, 'enabled': {'type': 'bool'}, 'sleep': {'type': 'int'}, 'pattern': {'type': 'str'}, 'arguments': {'type': 'str', 'aliases': ['args']}, 'runlevels': {'type': 'list', 'elements': 'str'}, 'daemonize': {'type': 'bool', 'default': False}}, supports_check_mode=True)
    module.exit_json(changed=True, original_message="foo", message="hi")
# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:30.247319
# Unit test for function main
def test_main():
    os.system("touch /etc/init.d/unit-test")
    os.system("chmod +x /etc/init.d/unit-test")
    os.system("update-rc.d unit-test defaults")
    os.system("update-rc.d unit-test enable")
    os.system("touch /etc/rc3.d/K01unit-test")
    os.system("touch /etc/rc4.d/K01unit-test")
    os.system("touch /etc/rc5.d/S01unit-test")
    os.system("touch /etc/rc5.d/S03unit-test")
    os.system("touch /etc/rc.d/init.d/unit-test")

# Generated at 2022-06-23 04:36:38.697305
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            pattern=dict(type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-23 04:36:40.366145
# Unit test for function main
def test_main():
    assert(1 == 1)
# import module snippets
from ansible.module_utils.basic import *


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:50.010877
# Unit test for function main
def test_main():
    args = dict(
        name='test',
        state='test',
        enabled=False,
        sleep=1,
        pattern='test',
        arguments='test',
        runlevels=['test'],
        daemonize=False,
        show_diff=False
    )

# Generated at 2022-06-23 04:37:01.548785
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # main(test)

    # TODO: implement this
    # test.fail_json(

# Generated at 2022-06-23 04:37:08.016009
# Unit test for function main
def test_main():
    result = dict(
        name="test",
        changed=False,
         status={}
    )
    result['status'].setdefault('enabled', {})
    result['status']['enabled']['changed'] = False
    result['status']['enabled']['rc'] = None
    result['status']['enabled']['stdout'] = None
    result['status']['enabled']['stderr'] = None
    assert result == main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:37:14.431400
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # Instantiate the test class
    test_class = ServiceTestClass(test_module)

# Generated at 2022-06-23 04:37:17.315981
# Unit test for function main
def test_main():

    # No unit tests for this module written
    assert False

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:37:23.954608
# Unit test for function main
def test_main():
    import sys
    import inspect
    import tempfile
    import subprocess
    import os
    import json

    globals_dict = globals()
    c = list(globals_dict.keys())
    # print c
    # ['socket', 'os', 'basestring', '__name__', 'get_ps', 'inspect', 'sys', 'daemonize', 'json', 're', 'main', 'subprocess', 'fail_if_missing', 'get_sysv_script', 'sysv_exists', 'sysv_is_enabled', 'test_main']

    # https://stackoverflow.com/questions/419163/what-does-if-name-main-do
    # if __name__ == '__main__':
    #     pass

# Generated at 2022-06-23 04:37:37.330705
# Unit test for function main
def test_main():
    args = dict(
        name='sshd', state='started', enabled='yes'
    )
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-23 04:37:47.684997
# Unit test for function main
def test_main():
    """ Unit test for function main
    """
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()


# Generated at 2022-06-23 04:37:50.209681
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as exec_info:
        assert main()
        exit_args = exec_info.value.args[0]
        assert exit_args['changed']

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:38:03.511178
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:38:15.378502
# Unit test for function main
def test_main():
    # Mock module
    sys.modules["ansible.module_utils.basic"] = Mock(AnsibleModule=Mock())
    sys.modules["ansible.module_utils.service"] = Mock(sysv_is_enabled=Mock(return_value=True),
                                                       get_sysv_script=Mock(return_value=""),
                                                       sysv_exists=Mock(return_value=True))
    sys.modules["ansible.module_utils.action"] = Mock(AnsibleModule=Mock())
    sys.modules["action_common_attributes"] = Mock()
    sys.modules["ansible.module_utils.basic"].AnsibleModule.exit_json = Mock()

    result = main()
    assert_equal(result, None)


# Generated at 2022-06-23 04:38:20.595113
# Unit test for function main
def test_main():
    data = {
        'name': 'sudo',
        'state': 'started',
        'enabled': 'yes',
        'runlevels': [],
        'pattern': '',
        'sleep': 1,
        'arguments': '',
        'daemonize': False,
    }
    main()

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:38:34.607618
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    global script
    script = 'script'
    global location

# Generated at 2022-06-23 04:38:50.870794
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
        'name': dict(required=True, type='str', aliases=['service']),
        'state': dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        'enabled': dict(type='bool'),
        'sleep': dict(type='int', default=1),
        'pattern': dict(type='str'),
        'arguments': dict(type='str', aliases=['args']),
        'runlevels': dict(type='list', elements='str'),
        'daemonize': dict(type='bool', default=False),
    }, supports_check_mode=True, required_one_of=[['state', 'enabled']])
    ###########################################################################
    # BEGIN: Enable/Disable
    module.params['state']

# Generated at 2022-06-23 04:39:05.279368
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.run_command = mock_run_command
    module.get_bin_path = mock

# Generated at 2022-06-23 04:39:14.973338
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    _main(module)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:23.049240
# Unit test for function main
def test_main():
    import os
    import ansible.module_utils.basic
    import ansible.module_utils.sysv
    import ansible.module_utils.service
    import ansible.module_utils.service.sysv
    # set up test fixtures
    ansible.module_utils.basic._ANSIBLE_ARGS = ['test_main']
    ansible.module_utils.basic.HAS_PYTHON_OS = True
    ansible.module_utils.basic.HAS_PYTHON_SUBPROCESS = True
    ansible.module_utils.sysv.HAS_INITCTL = True
    ansible.module_utils.sysv.HAS_CHKCONFIG = True
    ansible.module_utils.sysv.HAS_UPDATE_RCD = True
    ansible.module_utils

# Generated at 2022-06-23 04:39:24.476555
# Unit test for function main
def test_main():
    # Skip the test
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:31.336102
# Unit test for function main
def test_main():
    # initialize the basic AnsibleModule object
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-23 04:39:43.880882
# Unit test for function main
def test_main():
    result = {}
    argument_spec = {}
    name = 'httpd'
    action = 'started'
    enabled = True
    runlevels = [ '3', '5' ]
    pattern = 'httpd'
    sleep_for = 1
    rc = 0
    out = err = ''
