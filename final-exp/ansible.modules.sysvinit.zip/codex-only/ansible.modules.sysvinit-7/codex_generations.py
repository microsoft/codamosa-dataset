

# Generated at 2022-06-23 04:29:46.049657
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.dict_transformations import camel_dict_to_snake_dict
    from ansible.module_utils.six import PY3
    from io import StringIO


# Generated at 2022-06-23 04:29:59.820605
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-23 04:30:09.688456
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:19.741292
# Unit test for function main
def test_main():
    import json
    import ansible.module_utils.service as module_utils_service
    import ansible.module_utils.action as action_utils
    import ansible.module_utils.basic as module_utils_basic
    import ansible.module_utils.sysvinit as module_utils_sysvinit
    import ansible.module_utils.pycompat24 as module_utils_pycompat24

    # create a mock module object
    module_name = 'sysvinit'

# Generated at 2022-06-23 04:30:24.014715
# Unit test for function main

# Generated at 2022-06-23 04:30:33.515953
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
    name=dict(required=True,type='str'),
    state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
    enabled=dict(type='bool'),
    sleep=dict(type='int', default=1),
    pattern=dict(type='str'),
    arguments=dict(type='str', aliases=['args']),
    runlevels=dict(type='list', elements='str'),
    daemonize=dict(type='bool', default=False),
))
    main()

# Generated at 2022-06-23 04:30:34.161736
# Unit test for function main
def test_main():
    assert True == True

# Generated at 2022-06-23 04:30:38.719754
# Unit test for function main
def test_main():
    print("Running Unit Tests")
    import doctest
    doctest.testmod(verbose=True)

if __name__ == '__main__':
    # Run unit tests if called from command line
    if len(sys.argv) > 1 and sys.argv[1] == 'test':
        test_main()
    else:
        main()

# Generated at 2022-06-23 04:30:45.184910
# Unit test for function main
def test_main():
    import ansible.module_utils.basic as basic
    sysvinit_path = "./ansible/module_utils/service/sysvinit"
    sysvinit_module = "sysvinit"
    module_args = {
        'name': 'apache2',
        'state': 'started',
        'enabled': True
    }
    run_module = basic.AnsibleModule(sysvinit_path, sysvinit_module, module_args)
    args = module_args
    run_module.params = args
    runme = main(run_module)
    assert(runme['changed'] == True)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:50.202147
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:31:06.311354
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # Setup mocks

# Generated at 2022-06-23 04:31:07.382798
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:14.680075
# Unit test for function main
def test_main():
    # Module args defaults
    args = dict(
        name='apcupsd',
        state=None,
        enabled=None,
        sleep=1,
        pattern='apcupsd',
        arguments=None,
        runlevels=None,
        daemonize=False,
    )
    # State specified
    module = AnsibleModule(argument_spec=dict(name=dict(required=True),
                                              state=dict(default=None),
                                              enabled=dict(default=None),
                                              sleep=dict(default=1),
                                              pattern=dict(default=''),
                                              arguments=dict(default=None),
                                              runlevels=dict(default=None),
                                              daemonize=dict(default=False)
                                              ))

# Generated at 2022-06-23 04:31:27.220575
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import json

    file, path = tempfile.mkstemp(suffix='.py')
    os.close(file)


# Generated at 2022-06-23 04:31:40.539412
# Unit test for function main
def test_main():
    # Mock out argument specification
    args = dict(
        name="foo",
        state="bar",
        enabled="baz",
        sleep=3,
        pattern="pattern",
        arguments="args",
        runlevels=["one", "two"],
        daemonize="yes"
    )

    res = dict(
        changed=False,
        results=None
    )

    # Mock out basic module funtions
    m = MagicMock(**{"run_command.return_value":(0, True, False)})
    m.params = args
    m.check_mode = False
    # Mock out AnsibleModule
    m.AnsibleModule = MagicMock()


# Generated at 2022-06-23 04:31:52.314546
# Unit test for function main
def test_main():

    names = ["apache2"]
    states = ["started", "stopped", "restarted", "reloaded"]
    runlevels = ["3", "5"]
    patterns = ["apache"]
    sleep_for = ["1"]
    daemonizes = [True, False]

    # NOTE: Not exhaustive, but should be sufficient

# Generated at 2022-06-23 04:32:01.338534
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:14.670596
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    global rc, out, err
    rc = 0
    out = err = ""

# Generated at 2022-06-23 04:32:26.080878
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    import sys
    import os

# Generated at 2022-06-23 04:32:40.243221
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:32:47.746424
# Unit test for function main
def test_main():
    # mock for module
    module = AnsibleModule()

    # mock for module.run_command
    def run_command(command):
        return "", "", ""

    # mock for module.exit_json
    def exit_json(**kargs):
        pass

    # mock for module.fail_json
    def fail_json(**kargs):
        pass

    module.run_command = run_command
    module.exit_json = exit_json
    module.fail_json = fail_json

    # call function main
    main()
    # assert something

# Generated at 2022-06-23 04:32:58.522451
# Unit test for function main
def test_main():
    import sys
    import imp
    import yaml
    module = imp.new_module('ansible_module_sysvinit')
    module.run_command = lambda x: (0, x, '')
    module.get_bin_path = lambda x, y=None: 'fake-%s' % x
    sys.modules["ansible.module_utils.basic"] = module
    module.sysv_is_enabled = lambda x, r=None: ('start' in x) if r else ('start' in x)
    module.sysv_exists = lambda x: True
    module.get_sysv_script = lambda x: 'service-%s' % x
    module.warn = lambda x: sys.stderr.write(x)
    module.get_ps = lambda y, z: 'start' in y
   

# Generated at 2022-06-23 04:33:09.897392
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
            'name': dict(required=True, type='str'),
            'state': dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            'enabled': dict(type='bool'),
            'sleep': dict(type='int', default=1),
            'pattern': dict(type='str'),
            'arguments': dict(type='str', aliases=['args']),
            'runlevels': dict(type='list', elements='str'),
            'daemonize': dict(type='bool', default=False),
        },
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    import tempfile

    tmpdir = tempfile.TemporaryDirectory()

# Generated at 2022-06-23 04:33:21.597222
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False)),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']])
    main()

# import module snippets
from ansible.module_utils.basic import *

# Generated at 2022-06-23 04:33:32.372594
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # Skip test if no action to test (no state, enabled attribute is required)

# Generated at 2022-06-23 04:33:33.257907
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:33:47.655853
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os

    if not os.path.isfile('/bin/systemctl'):
        sys.exit(0)


# Generated at 2022-06-23 04:34:00.673613
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:06.177867
# Unit test for function main
def test_main():
    args = dict(
        name="mytestservice",
        state=None,
        enabled=None,
        sleep=1,
        pattern=None,
        arguments=None,
        runlevels=None,
    )
    main(args)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:13.711199
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import service
    import unittest

    import sys
    sys.path.append(".")
    from test.unit.module_utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase

    class TestSysvinit(ModuleTestCase):

        FAKE_RC_OK = 0
        FAKE_RC_FAIL = 1
        FAKE_RC_NONZERO = -1

        def setUp(self):
            super(TestSysvinit, self).setUp()

            # original module
            self.org_module = sys.modules['ansible.modules.system.sysvinit']
            sys.modules['ansible.modules.system.sysvinit'] = service

            # original module_utils

# Generated at 2022-06-23 04:34:26.910666
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True, type='str', aliases=['service']),
            state = dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled = dict(type='bool'),
            sleep = dict(type='int', default=1),
            pattern = dict(type='str'),
            arguments = dict(type='str', aliases=['args']),
            runlevels = dict(type='list', elements='str'),
            daemonize = dict(type='bool', default=False),
            ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
        )
    try:
        main()
    except Exception as e:
        print(e)
        test

# Generated at 2022-06-23 04:34:39.248968
# Unit test for function main
def test_main():

    # Start a simple check_mode test
    class TestModule(object):
        def __init__(self):
            self.params = dict()
            self.check_mode = True
            self.fail_json = lambda **kwargs: sys.exit(1)

    sys.modules['ansible.module_utils.basic'] = TestModule()

    main()

    # Now do a main test

    class TestModule(object):
        def __init__(self):
            self.params = {
              "name": "apache2",
              "state": "started"
            }
            self.check_mode = True

        def fail_json(self, **kwargs):
            print("Failed")
            sys.exit(1)

        def exit_json(self, **kwargs):
            print("Success")

# Generated at 2022-06-23 04:34:44.997612
# Unit test for function main
def test_main():
    # Case 1
    module_name = 'sysvinit'
    module_class = 'main'
    data = {
        'state': None,
        'enabled': None,
        'name': u'httpd',
}
    expected_results = {
        'changed': False,
        'name': u'httpd',
        'status': {
            'enabled': {
                'changed': False,
                'rc': None,
                'stderr': None,
                'stdout': None,
            },
            'restarted': {
                'changed': False,
                'rc': None,
                'stderr': None,
                'stdout': None,
            }
        }
    }
    return_value = main()
    # Actual result from the function

# Generated at 2022-06-23 04:34:46.945764
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:59.247117
# Unit test for function main
def test_main():
    args = dict(
        name="foo",
        state="stopped"
    )
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
   

# Generated at 2022-06-23 04:35:03.420111
# Unit test for function main
def test_main():
    arguments = dict(
        name = "foo",
        state = "stopped",
    )
    module = AnsibleModule(argument_spec=arguments)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:16.844923
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.params['name'] = 'httpd'

# Generated at 2022-06-23 04:35:30.179976
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    test_name = "ethtool"
    test_action = "started"
    test_enabled = "yes"
    test_sleep = 1

# Generated at 2022-06-23 04:35:43.533173
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # module.run_command = fake_run_command  # noqa
    # test name


# Generated at 2022-06-23 04:35:45.671278
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:58.890587
# Unit test for function main
def test_main():
    # Create a fake module object
    class FakeModule(object):
        def __init__(self, name=None, state=None, enabled=None, runlevels=None, pattern=None):
            self.params = dict()
            self.params['name'] = name
            self.params['state'] = state
            self.params['enabled'] = enabled
            self.params['runlevels'] = runlevels
            self.params['pattern'] = pattern
            self.exit_json = lambda x: print("exit_json: %s" % str(x))

# Generated at 2022-06-23 04:36:09.014990
# Unit test for function main
def test_main():
    args = dict(
        name="test_name",
        state=None,
        enabled=None,
        sleep=1,
        pattern=None,
        runlevels=None,
        daemonize=False,
    )

    rc, out, err = main(args)
    assert rc == 0, "Unexpected error code: %d, output: %s, error: %s" % (rc, out, err)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:20.303083
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:31.942439
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
            'name': dict(required=True, type='str', aliases=['service']),
            'state': dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            'enabled': dict(type='bool'),
            'sleep': dict(type='int', default=1),
            'pattern': dict(type='str'),
            'arguments': dict(type='str', aliases=['args']),
            'runlevels': dict(type='list', elements='str'),
            'daemonize': dict(type='bool', default=False),
        },
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    assert not main()


# Generated at 2022-06-23 04:36:44.454723
# Unit test for function main
def test_main():
    # Fail load module.
    class AnsibleFailJson(object):
        def __init__(self, kwargs):
            self.kwargs = kwargs

        def fail_json(self, **kwargs):
            raise Exception(kwargs)

    # Fail run_command.
    class AnsibleRunCommand(object):
        def __init__(self, kwargs):
            self.kwargs = kwargs

        def fail_json(self, **kwargs):
            raise Exception(kwargs)

        def run_command(self, **kwargs):
            return 0

    # Pass load module.
    class AnsibleLoadModule(object):
        def __init__(self, kwargs):
            self.kwargs = kwargs

        def exit_json(self, **kwargs):
            pass

    module

# Generated at 2022-06-23 04:36:57.493882
# Unit test for function main
def test_main():
    content = "[test]\nname=test\nstart=start\nstop=stop"
    m = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ))
    m.run_command = MagicMock(return_value=(0, "", ""))
    m.get_bin_path

# Generated at 2022-06-23 04:37:07.970729
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
    )
    main()

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:37:09.521832
# Unit test for function main
def test_main():
    """
    Unit test for function main
    print(main())
    """

# Generated at 2022-06-23 04:37:22.058010
# Unit test for function main
def test_main():
    out = dict(
        changed=False,
        attempts=1,
        status=dict(
            enabled=dict(
                changed=True,
                rc=0,
                stderr="",
                stdout=""
            ),
            stopped=dict(
                changed=True,
                rc=0,
                stderr="Stopping web server: apache2.\n",
                stdout=""
            )
        ),
        name="apache2"
    )
    print("\nGet expected output:\n", out)
    # Instantiate a class

# Generated at 2022-06-23 04:37:35.252093
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    setattr(module, 'run_command', mocked_run_command)

# Generated at 2022-06-23 04:37:46.363836
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    print("Running unit test for function main")
    main()

# Import Ansible utilities

# Generated at 2022-06-23 04:37:52.396904
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    test_main={'name': 'apache2'}
    main()


# Generated at 2022-06-23 04:38:04.503035
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec = dict(
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
        name=dict(required=True, type='str', aliases=['service']),
    ))
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:38:16.133699
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    if __name__ == '__main__':
        main()


# Generated at 2022-06-23 04:38:28.960539
# Unit test for function main
def test_main():
    # Create the module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    return module

# unit test for function

# Generated at 2022-06-23 04:38:38.713394
# Unit test for function main
def test_main():
    """Test module main"""
    m = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
    )
    m.params.update(dict(
        name='foo',
        state='started',
    ))
    m.exit_json = lambda **kwargs: kwargs
    assert main()['changed']

# Generated at 2022-06-23 04:38:44.793573
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:38:57.927176
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_exists
    from ansible.module_utils.service import get_sysv_script

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    module.params['name'] = 'nginx'
    module.params['state'] = 'started'
    module.params['enabled'] = True
    module.params['sleep'] = 1
    module.params['pattern'] = 'nginx'
    module.params['arguments'] = 'nginx'
    module.params['runlevels'] = ['3', '5']
    module.params['daemonize'] = False

# Successful execution
    module.exit_json = mock_exit_json

# Generated at 2022-06-23 04:39:03.273639
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.run_command = MagicMock()

# Generated at 2022-06-23 04:39:11.412138
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    FAKE_CUR_RUNLVL = 3
    FAKE_RUNLVL_

# Generated at 2022-06-23 04:39:16.203451
# Unit test for function main
def test_main():
    # mock things
    module = AnsibleModule({'arguments': 'server'}, check_mode=True)
    module.exit_json = mock.MagicMock()

    # run the code to test
    main()

    # assert that module.exit_json has been called
    module.exit_json.assert_called_with(
        changed = False,
        results = module.params
    )

# Generated at 2022-06-23 04:39:22.918870
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule, load_fixture
    module = AnsibleModule(argument_spec=dict(foo=dict(type='str', default=None)))
    fixture = load_fixture('test_main.json')
    expected = load_fixture('test_main_expected.json')

    module.exit_json.__globals__['ansible_module_instance'].params = fixture
    main()

    assert module.exit_json.call_count == 1
    result = module.exit_json.call_args[0][0]
    assert result == expected


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:30.093951
# Unit test for function main
def test_main():
    import mock
    import sys
    import os
    import argparse

    mock_scripts = {
            'apache2': '/etc/init.d/apache2',
            'rsyslog': '/etc/init.d/rsyslog',
            'systemd-tmpfiles': '/bin/systemd-tmpfiles',
            'systemd-udevd': '/bin/systemd-udevd',
            'acpid': '/usr/sbin/acpid',
            'iptables': '/etc/init.d/iptables',
            'nfslock': '/etc/init.d/nfslock',
            'sysstat': '/etc/init.d/sysstat'
        }


# Generated at 2022-06-23 04:39:37.834564
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    pass

if __name__ == '__main__':
    main()