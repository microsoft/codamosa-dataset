

# Generated at 2022-06-23 04:29:38.928883
# Unit test for function main
def test_main():
    args = dict(
        name='test',
        state='restarted',
        enabled=True,
        runlevels=['3', '5'],
        daemonize=True,
    )
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(**args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:29:50.047987
# Unit test for function main
def test_main():
    # Set up mock data for the unit test
    action_mock = 'start'
    enabled_mock = False
    runlevels_mock = [3]
    pattern_mock = None
    sleep_for_mock = None

    # Create the mock module

# Generated at 2022-06-23 04:29:57.046904
# Unit test for function main
def test_main():
    # code to be executed for unit test
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:01.046972
# Unit test for function main
def test_main():
    with open('data/sysvinit/expected.json') as expected:
        with open('data/sysvinit/output.json') as output:
            assert json.loads(output.read()) == json.loads(expected.read())

# }}}
main()

# Generated at 2022-06-23 04:30:10.902889
# Unit test for function main
def test_main():
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    script = 'service'
    fail_if_missing(module, True, None)
    get_sysv_script(None)
    sysv_is_enabled(None, runlevel=None)
    get_ps(module, None)
    daemonize(module, None)
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:13.968110
# Unit test for function main
def test_main():
    # id = sysvinit.main(['fake_name','arg1','arg2'])
    # print id
    assert True

# id = main()
# print id

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:26.200615
# Unit test for function main
def test_main():
    # Test with default parameters
    m=dict(name="myService", state="started",enabled=True)
    r = AnsibleModule(m).execute()
    assert r['results'] == {
        'results': {
            'status': {
                'started': {
                    'changed': False,
                    'rc': None,
                    'stdout': None,
                    'stderr': None
                },
                'enabled': {
                    'changed': False,
                    'rc': None,
                    'stdout': None,
                    'stderr': None
                }
            },
            'name': 'myService',
            'changed': False
        }
    }

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:36.658498
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
   

# Generated at 2022-06-23 04:30:44.205943
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            pattern=dict(type='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.exit_json(changed=False, rc=None, stdout=None, stderr=None)

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 04:30:49.316653
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-23 04:31:05.497962
# Unit test for function main
def test_main():
    # Set the following values as per your need
    name = 'my_service'
    action = "started"
    enabled = True
    runlevels = [ '3' , '5' ]
    pattern = ""
    sleep_for = "1"
    rc = 0
    out = err = ""
    result = {
        'name': name,
        'changed': False,
        'status': {}
    }

# Generated at 2022-06-23 04:31:17.380765
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    module_args = dict(
        name='apache2',
        sleep=1,
        state='restarted',
        enabled=None,
        pattern=None,
        arguments=None,
        runlevels=None,
        daemonize=None,
    )

    # FIXME - If a unit test is failing on you, take a look here first!
    # Check to see if we are running in the ansible-test repository checkout.
    # We do this to avoid error messages from module_utils/urls.py when we are
    # using a network connection. We also generate the ANSIBLE_TEST_DATA_ROOT
    # environment variable.
    test_data_path = None

# Generated at 2022-06-23 04:31:26.083425
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    class ExeModule(object):

        def __init__(self):
            self.exit_

# Generated at 2022-06-23 04:31:27.534540
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:40.684420
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
    )
    if __name__ == '__main__':
        main()

# import module snippets
from ansible.module_utils.basic import *

# Generated at 2022-06-23 04:31:52.608094
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize


# Generated at 2022-06-23 04:32:01.579230
# Unit test for function main
def test_main():
  module = AnsibleModule(dict(
    name=dict(required=True, type='str', aliases=['service']),
    state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
    enabled=dict(type='bool'),
    sleep=dict(type='int', default=1),
    pattern=dict(type='str'),
    arguments=dict(type='str', aliases=['args']),
    runlevels=dict(type='list', elements='str'),
    daemonize=dict(type='bool', default=False),
  ), supports_check_mode=True)

  main()



if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:14.770991
# Unit test for function main
def test_main():
    import inspect
    args = [
        "name=sshd",
        "state=started",
        "enabled=yes",
    ]

# Generated at 2022-06-23 04:32:26.144535
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:32:40.310301
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:49.508349
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.main()

# Generated at 2022-06-23 04:33:00.216174
# Unit test for function main
def test_main():
    # mock values for function main
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ),
    supports_check_mode=True,
    required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-23 04:33:10.724562
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

# import module snippets
from ansible.module_utils.basic import *

# Generated at 2022-06-23 04:33:22.283266
# Unit test for function main
def test_main():
    args = dict(
        name='foo',
        state='started'
    )

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-23 04:33:32.861714
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    def run_command(*args, **kwargs):
        out = ''
        err = ''


# Generated at 2022-06-23 04:33:35.019745
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:49.121249
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'name': 'test',
        'state': 'started',
        'enabled': True,
        'sleep': 1,
        'pattern': None,
        'arguments': None,
        'runlevels': None,
        'daemonize': False,
    })
    module.check_mode = True
    rc = None
    out = err = ''
    runlevel_status = {}
    location = {}
    name = module.params['name']
    action = module.params['state']
    enabled = module.params['enabled']
    runlevels = module.params['runlevels']
    pattern = module.params['pattern']
    sleep_for = module.params['sleep']
    result = {
        'name': name,
        'changed': False,
        'status': {}
    }


# Generated at 2022-06-23 04:34:02.062521
# Unit test for function main
def test_main():
    print("test")
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    test_module.params = {'name': "tst"}

# Generated at 2022-06-23 04:34:14.828070
# Unit test for function main
def test_main():
    with open('sysvinit-out.txt') as content_file:
        out = content_file.read()
    with open('sysvinit-err.txt') as content_file:
        err = content_file.read()
    with open('sysvinit-res.txt') as content_file:
        res = content_file.read()

# Generated at 2022-06-23 04:34:27.590888
# Unit test for function main
def test_main():
    """Test main unit test"""
    module = AnsibleModule(argument_spec={'name': dict(required=True, type='str', aliases=['service']),
                                          'state': dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
                                          'enabled': dict(type='bool'),
                                          'sleep': dict(type='int', default=1),
                                          'pattern': dict(type='str'),
                                          'arguments': dict(type='str', aliases=['args']),
                                          'runlevels': dict(type='list', elements='str'),
                                          'daemonize': dict(type='bool', default=False)})
    main()

if __name__ == 'main':
    main()

# Generated at 2022-06-23 04:34:40.020628
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:53.597273
# Unit test for function main
def test_main():
    import sys
    import os
    import platform
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.service.sysv_attributes as sattrs
    from ansible.module_utils.sysv_attributes import SysvAttributes

    import sysvinit

    is_freebsd = False
    if re.match('freebsd', platform.system(), re.I):
        is_freebsd = True

    # Use the actual script and find it using PATH
    sysvinit_path = os.path.realpath(sysvinit.__file__)
    sysvinit_path = re.sub(r'(.*)lib/ansible/module_utils/service(.*)', r'\1bin/ansible\2', sysvinit_path)
    sysvinit_

# Generated at 2022-06-23 04:35:06.043935
# Unit test for function main
def test_main():
    """Mock `main` function for testing module using pytest."""

# Generated at 2022-06-23 04:35:19.714698
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.exit_json(**main())



# Generated at 2022-06-23 04:35:31.716252
# Unit test for function main
def test_main():
    testArgs={'name': 'test', 'state': 0,
              'enabled': 2, 'runlevels': None,
              'pattern': 'pattern', 'arguments': None,
              'sleep': 1, 'daemonize': False}
    templist = sys.argv
    sys.argv = []
    sys.argv.append(__file__)
    sys.argv.append('-m')
    sys.argv.append('-a')
    sys.argv.append('name=test')
    sys.argv.append('state=0')
    sys.argv.append('enabled=2')
    sys.argv.append('runlevels=None')
    sys.argv.append('pattern=pattern')
    sys.argv.append('arguments=None')
    sys.argv.append

# Generated at 2022-06-23 04:35:44.424628
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ), supports_check_mode=True, required_one_of=[['state', 'enabled'],])

    # Load return values specified in the arguments
    result = dict()
    results= {}

# Generated at 2022-06-23 04:35:58.370801
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-23 04:36:12.025819
# Unit test for function main
def test_main():

    # import unittest and mock as needed
    import unittest
    import mock
    import sys
    import os

    # Mock's don't work with magic
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))

    # import module we are testing
    from ansible.modules.packaging.os.sysvinit import main as sysvinit

    ###########################################################################
    # sysvinit.py
    ###########################################################################

    class TestSysvinit(unittest.TestCase):
        '''
        Test cases for sysvinit.py
        '''

        #######################################################################
        # Mock Functions
        #######################################################################

# Generated at 2022-06-23 04:36:16.994634
# Unit test for function main
def test_main():
    # Start sysvinit unit tests
    module = AnsibleModule({'name': 'iptables', 'enabled': True, 'runlevels': ['3', '5'], 'daemonize': True})
    try:
        main()
    except SystemExit:
        pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:19.028905
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:22.400575
# Unit test for function main
def test_main():
    assert main() == 0

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.action_common import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:33.911413
# Unit test for function main
def test_main():
    outcome = {}
    def _fake_module(**kwargs):
        outcome['foo'] = kwargs
        return True
    _fake_module.fail_json = lambda *args, **kwargs: setattr(outcome, "exception", kwargs)
    _fake_module.exit_json = lambda *args, **kwargs: setattr(outcome, "exit_json", kwargs)
    _fake_module.running_in_container = False
    _fake_module.check_mode = False
    _fake_module.params = {}


# Generated at 2022-06-23 04:36:37.512821
# Unit test for function main
def test_main():
    sample_ansible_args = dict(check_mode=True)
    result = main(sample_ansible_args)
    assert result['changed'] == False


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:48.800457
# Unit test for function main
def test_main():
    # mock module
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # Test Passed
    def test_passed():
        return main

# Generated at 2022-06-23 04:37:01.174472
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    runlevels = module.params['runlevels']
    enabled = module.params['enabled']
   

# Generated at 2022-06-23 04:37:14.150376
# Unit test for function main

# Generated at 2022-06-23 04:37:25.445753
# Unit test for function main
def test_main():
    '''Unit test for function main'''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

# Generated at 2022-06-23 04:37:29.941672
# Unit test for function main
def test_main():
    'test_main'


# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:37:42.296695
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = test_module.params['name']

# Generated at 2022-06-23 04:37:50.241547
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.modules.system.sysvinit as sysvinit
    sysvinit.main = main

    # Instantiate Ansible module

# Generated at 2022-06-23 04:38:03.554864
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-23 04:38:10.430084
# Unit test for function main
def test_main():
    module_args={
        'arguments': None,
        'enabled': True,
        'name': 'apache2',
        'pattern': None,
        'runlevels': None,
        'sleep': 1,
        'state': 'started',
        'daemonize': False,
    }
    res = main(**module_args)
    assert res['name'] == 'apache2'

if __name__ == '__main__':
    main()