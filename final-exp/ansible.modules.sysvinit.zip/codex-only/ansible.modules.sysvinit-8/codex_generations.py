

# Generated at 2022-06-23 04:29:46.263432
# Unit test for function main
def test_main():

    ###########################################################################
    # BEGIN: TESTING
    ###########################################################################

    # FIXME: Test module, this is fugly
    # Taken from https://github.com/cmullaut/ansible-modules/blob/master/sysvinit/sysvinit.py
    from ansible.module_utils.service import sysv_is_enabled
    import sys

    import ansible.utils.template as template
    import ansible.utils as utils
    import ansible.errors as errors
    import ansible.module_utils.basic as basic

    # This will be used later on by the module, but you
    # can use it to test module functionality.

# Generated at 2022-06-23 04:29:59.966110
# Unit test for function main
def test_main():
    from ansible.module_utils.service import sysv_is_enabled
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded']),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    service = module

# Generated at 2022-06-23 04:30:04.670164
# Unit test for function main

# Generated at 2022-06-23 04:30:07.361754
# Unit test for function main
def test_main():
    rc, out, err = main(argv=[])

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:17.887050
# Unit test for function main
def test_main():
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.six import PY2
    import tempfile, os, re

    test_dir = tempfile.mkdtemp()
    test_file_path = tempfile.mkstemp(dir=test_dir)
    os.close(test_file_path[0])

    test_file = os.path.basename(test_file_path[1])
    module_path = os.path.join(test_dir, test_file)

    if PY2:
        write_string = "import os,sys,json\n"
        write_string += "def main():\n"

# Generated at 2022-06-23 04:30:31.317656
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    # FIXME - currently no way to test daemonize
    #module = basic.AnsibleModule(argument_spec=dict(
    #    name = dict(required=True, type='str', aliases=['service']),
    #    action = dict(choices=['start', 'stop', 'restart', 'reload'], type='str'),
    #    enabled = dict(type='bool'),
    #    sleep = dict(type='int', default=1),
    #    pattern = dict(type='str'),
    #    runlevels = dict(type='list', elements='str'),
    #    daemonize = dict(type='bool', default=False),
    #), supports_check_mode=True)

    #name = module.params['name']
    #action = module.params['

# Generated at 2022-06-23 04:30:34.025161
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:43.103854
# Unit test for function main
def test_main():
    name = 'httpd'
    state = 'started'
    enabled = True
    sleep_for = 1
    pattern = r'httpd'
    rc = 0
    out = err = ''
    result = {
        'name': name,
        'changed': False,
        'status': {}
    }
    result['status'].setdefault('enabled', {})
    result['status']['enabled']['changed'] = False
    result['status']['enabled']['rc'] = None
    result['status']['enabled']['stdout'] = None
    result['status']['enabled']['stderr'] = None
    
    result['status'].setdefault(state, {})
    result['status'][state]['changed'] = False

# Generated at 2022-06-23 04:30:48.731332
# Unit test for function main
def test_main():
    try:
        # import python libs
        import os
        import sys
        import tempfile
        import shutil
        import subprocess
    except Exception as e:
        sys.exit(1)

    # Set up environment
    tempdir = tempfile.mkdtemp()
    os.environ['ANSIBLE_CONFIG'] = os.path.join(tempdir, 'ansible.cfg')
    fd, temppath = tempfile.mkstemp()
    with open(temppath, 'wt') as f:
        f.write('[defaults]\nroles_path = %s\n' % os.path.join(tempdir, 'test-roles'))
    os.close(fd)
    os.chmod(temppath, 0o600)

    # Make test directories

# Generated at 2022-06-23 04:31:05.032105
# Unit test for function main
def test_main():
    #
    #
    #
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module

# Generated at 2022-06-23 04:31:17.112648
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True, type='str'),
            state = dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled = dict(type='bool'),
            sleep = dict(type='int', default=1),
            pattern = dict(type='str'),
            arguments = dict(type='str', aliases=['args']),
            runlevels = dict(type='list', elements='str'),
            daemonize = dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = 'apache2'
    action = 'started'
    enabled = True

# Generated at 2022-06-23 04:31:29.288482
# Unit test for function main
def test_main():
    import sys
    sys.modules['ansible'] = MagicMock()
    f = MagicMock(name="f")
    f.run = MagicMock()
    f.run.return_value = (0, "", "")

    module = MagicMock(name="module")
    module.params = {'service': 'test', 'state': 'started', 'enabled': False}
    module.check_mode = False
    module.exit_json = MagicMock()
    module.exit_json.return_value = None
    module.exit_json.return_value = None
    module.run_command.return_value = (0, "","")
    module.run_command.return_value = (0, "","")
    module.run_command.return_value = (0, "","")
    module.run_

# Generated at 2022-06-23 04:31:41.283787
# Unit test for function main
def test_main():
    mod = AnsibleModule(
    argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
        )
    main()

# import module snippets
from ansible.module_utils.basic import *

# Generated at 2022-06-23 04:31:50.982830
# Unit test for function main
def test_main():
    # User chosen variables
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']

# Generated at 2022-06-23 04:32:01.513851
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-23 04:32:07.265697
# Unit test for function main
def test_main():
  m = AnsibleModule(
    argument_spec = dict(
      name=dict(required=True, type='str'),
      state=dict(choices=['running', 'restarted'], type='str'),
      pattern=dict(type='str')
    )
  )

main()

# Generated at 2022-06-23 04:32:13.200464
# Unit test for function main

# Generated at 2022-06-23 04:32:24.187312
# Unit test for function main
def test_main():

    # import pdb; pdb.set_trace()
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()


# Generated at 2022-06-23 04:32:38.415087
# Unit test for function main
def test_main():
    import sys
    import tempfile

    def test_module(**kwargs):
        sysargv = sys.argv

        sys.argv = list(sysargv)
        sys.argv.append('--')
        for k, v in kwargs.items():
            sys.argv.append("{}={}".format(k, v))

        module = None
        try:
            module = main()
        finally:
            del sys.argv[1:]
            sys.argv = sysargv

        return module

    def output_kwargs(module, **kwargs):
        out = ''
        err = ''
        rc = 1

        if module.params['state'] == 'started':
            rc = 0


# Generated at 2022-06-23 04:32:49.062069
# Unit test for function main
def test_main():

    # Monkey patch the action plugin to get the basic functionality
    class FakeModule(object):
        def exit_json(self, **kwargs):
            pass
        def run_command(self, *args, **kwargs):
            for i in range(0, len(args)):
                if re.search(r'^\s+$', args[i]):
                    args[i] = ''
            return (0, ' '.join(args), None)
        def get_bin_path(self, binary, opt_dirs=[]):
            if binary == 'insserv':
                return '/sbin/insserv'
            elif binary == 'service':
                return '/usr/sbin/service'
            elif binary == 'update-rc.d':
                return '/usr/sbin/update-rc.d'
           

# Generated at 2022-06-23 04:32:59.816366
# Unit test for function main
def test_main():
  data = dict(
    name='apache2',
    state='stopped'
  )
  result = dict(
    attempts=1,
    changed=True,
    name='apache2',
    status=dict(
      stopped=dict(
        changed=True,
        rc=0,
        stderr='',
        stdout='Stopping web server: apache2.\n'
      )
    )
  )

# Generated at 2022-06-23 04:33:02.221102
# Unit test for function main

# Generated at 2022-06-23 04:33:12.429908
# Unit test for function main
def test_main():
    context = {}
    context['check_mode'] = False
    context['diff_mode'] = False
    context['playbook_dir'] = "ansible-playbook"
    context['play_context'] = {}
    context['play_context']['check_mode'] = False
    context['play_context']['diff_mode'] = False
    context['play_context']['playbook_dir'] = "ansible-playbook"
    context['play_context']['remote_addr'] = "127.0.0.1"
    context['play_context']['remote_user'] = "root"
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 04:33:15.345616
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:24.169707
# Unit test for function main

# Generated at 2022-06-23 04:33:33.692787
# Unit test for function main
def test_main():
    import os

    def file_exists(filename):
        try:
            os.path.isfile(filename)
            return True
        except os.error:
            return False

    def create_dummy_service(name):
        f = open("/etc/init.d/" + name, 'w')
        f.write("#!/bin/sh\n# \n# " + name + "\n# \n")
        f.write("# This service is designed to be a dummy init.d script.  It has no\n")
        f.write("# real service behind it and can be used for testing purposes.\n")
        f.write("#\n")
        f.write("# chkconfig:   35 99 01\n")
        f.write("# description: Dummy Service\n")

# Generated at 2022-06-23 04:33:48.146584
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

# import module snippets
from ansible.module_utils.basic import *



# Generated at 2022-06-23 04:34:01.200540
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:34:13.986008
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:27.197956
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required = True, type = 'str', aliases = ['service']),
            state = dict(choices = ['started', 'stopped', 'restarted', 'reloaded'], type = 'str'),
            enabled = dict(type = 'bool'),
            sleep = dict(type = 'int', default = 1),
            pattern = dict(type = 'str'),
            arguments = dict(type = 'str', aliases = ['args']),
            runlevels = dict(type = 'list', elements = 'str'),
            daemonize = dict(type = 'bool', default = False),
        ),
        supports_check_mode = True,
        required_one_of = [['state', 'enabled']],
    )


# Generated at 2022-06-23 04:34:39.462582
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:34:53.158915
# Unit test for function main
def test_main():
    # Stub command line arguments
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params

# Generated at 2022-06-23 04:34:57.934357
# Unit test for function main
def test_main():
# AnsibleModule function is called in ansible module
#    module = AnsibleModule(
#        argument_spec=dict(
#            name=dict(required=True, type='str', aliases=['service']),
#            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
#            enabled=dict(type='bool'),
#            sleep=dict(type='int', default=1),
#            pattern=dict(type='str'),
#            arguments=dict(type='str', aliases=['args']),
#            runlevels=dict(type='list', elements='str'),
#        ),
#        supports_check_mode=True,
#        required_one_of=[['state', 'enabled']],
#    )
    module = {}
    param = {}

# Generated at 2022-06-23 04:35:11.746272
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
    )
    module.run_command = lambda x: (0, '', '')

# Generated at 2022-06-23 04:35:13.820270
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:19.407897
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize


# Generated at 2022-06-23 04:35:31.533136
# Unit test for function main
def test_main():
    test_cmd = ['ansible-playbook', '-i', 'localhost,', '-c',
                'local', 'buncha.yml', '-t', 'sysinit', '-e',
                'name=apache2', '-e', 'enabled=true', '-e',
                'state=started', '-e', 'pattern=httpd', '--syntax-check',
                '--extra-vars=\'{ "ansible_module": "action_plugin" }\'']
    test_args = [subprocess.PIPE, subprocess.PIPE, subprocess.PIPE]
    test_p = subprocess.Popen(test_cmd, *test_args, shell=False)
    test_p.wait()
    test_output = test_p.communicate()
    test_return

# Generated at 2022-06-23 04:35:44.299883
# Unit test for function main
def test_main():
    import json
    # called as a module, not like a script.
    # this allows us to use the module in unittests
    # without any extra boilerplate.

# Generated at 2022-06-23 04:35:58.218606
# Unit test for function main
def test_main():
    from ansible.module_utils.service import sysv_is_enabled, \
        get_sysv_script, sysv_exists
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import get_ps, daemonize

# Generated at 2022-06-23 04:36:11.739110
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec = dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.params['state'] = 'started'

# Generated at 2022-06-23 04:36:20.932722
# Unit test for function main
def test_main():
    import sys
    if sys.version_info >= (3, 0):
        import unittest.mock as mock
    else:
        import mock
    module = mock.Mock()
    module.run_command = mock.Mock(return_value=(0, '', ''))
    module.check_mode = False
    module.fail_json = mock.Mock()
    module.exit_json = mock.Mock()
    module.get_bin_path = mock.Mock()
    module.warn = mock.Mock()
    module.params = {
        'name': '',
        'sleep': '',
        'state': '',
        'enabled': '',
        'daemonize': '',
    }
    main()

# Generated at 2022-06-23 04:36:32.327470
# Unit test for function main
def test_main():
    # Replace sys with builtin mock to mock out the dependencies.
    import __builtin__ as builtins
    builtins.__dict__['sys'] = mock.Mock()

    # Replace module_utils with builtin mock to mock out the dependencies.
    mod_utils = module_utils
    module_utils = mock.Mock()

    # Replace module with builtin mock to mock out the dependencies.
    mod_module = module
    module = mock.Mock()

    # Replace time with builtin mock to mock out the dependencies.
    mod_time = time
    time = mock.Mock()

    try:
        main()
    except SystemExit as e:
        # Always exit with code 0
        # Coverage doesn't currently support this module due to the
        # way it handles exceptions.
        if mock.call().code == 0:
            pass

# Generated at 2022-06-23 04:36:44.805719
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:36:51.959564
# Unit test for function main
def test_main():
    failed, tested = 0, 0
    for (name, opts) in EXAMPLES:
        failed += 1
        try:
            main(**opts)
        except:
            pass
        else:
            failed -= 1
        tested += 1
    print("** %d of %d tests failed" % (failed, tested))

if __name__ == "__main__":
    main()