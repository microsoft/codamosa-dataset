

# Generated at 2022-06-23 04:29:42.048724
# Unit test for function main
def test_main():
    import sys
    import os
    import json

    testmod_dir = os.path.dirname(sys.modules[__name__].__file__)

    f = open(os.path.join(testmod_dir, 'testdata.json'), 'r')
    data = json.load(f)

    # need to set module_utils

# Generated at 2022-06-23 04:29:47.422835
# Unit test for function main
def test_main():
    # test function main
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True, type='str', aliases=['service']),
            state = dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled = dict(type='bool'),
            sleep = dict(type='int', default=1),
            pattern = dict(type='str'),
            arguments = dict(type='str', aliases=['args']),
            runlevels = dict(type='list', elements='str'),
            daemonize = dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.main()

# Generated at 2022-06-23 04:30:02.260933
# Unit test for function main
def test_main(): 
 
  module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-23 04:30:14.183973
# Unit test for function main
def test_main():
    test_dict = dict(
        daemonize=True,
        name='apache2',
        pattern=None,
        sleep=1,
        state='started',
        enabled=True,
        runlevels=['3', '5'],
        arguments=None
    )

# Generated at 2022-06-23 04:30:27.652402
# Unit test for function main
def test_main():
    # Test no change
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-23 04:30:37.585789
# Unit test for function main
def test_main():

    # Test module arguments
    module_args = dict(
        name='iptables',
        state=None,
        enabled=True,
        sleep=1,
        pattern='pattern',
        arguments='arguments',
        runlevels=['2', '3'],
        daemonize=True,
        )

    # AnsibleModule
    module = AnsibleModule(
            argument_spec=module_args,
            supports_check_mode=True
            )

    # Check action state
    assert module.params['state'] == None

    # Check enabled state
    assert module.params['enabled'] == True

    # Check sleep time
    assert module.params['sleep'] == 1

    # Check pattern
    assert module.params['pattern'] == 'pattern'

    # Check arguments
    assert module.params['arguments'] == 'arguments'



# Generated at 2022-06-23 04:30:45.101821
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ),
    supports_check_mode=True,
    required_one_of=[['state', 'enabled']])

    global module
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:50.195966
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:31:06.311119
# Unit test for function main
def test_main():
    name = 'apache2'
    state = 'started'
    enabled = True
    runlevels = [3, 5]
    pattern = ''
    sleep_for = 1
    rc = 0
    out = err = ''
    result = {
        'name': name,
        'changed': False,
        'status': {}
    }

    # ensure service exists, get script name
    #fail_if_missing(module, sysv_exists(name), name)
    script = '/etc/init.d/apache2'

    # locate binaries for service management
    paths = ['/sbin', '/usr/sbin', '/bin', '/usr/bin']
    binaries = ['chkconfig', 'update-rc.d', 'insserv', 'service']

    # Keeps track of the service status for various runlevels because we can


# Generated at 2022-06-23 04:31:18.168942
# Unit test for function main
def test_main():
  args = {
    "name": "apache2",
    "state": "started",
    "enabled": False,
    "sleep": 1,
    "pattern": None,
    "arguments": None,
    "runlevels": None,
    "daemonize": False
  }
  result = main(args)
  assert result['changed'] == True

# Generated at 2022-06-23 04:31:26.602917
# Unit test for function main

# Generated at 2022-06-23 04:31:40.416154
# Unit test for function main

# Generated at 2022-06-23 04:31:51.943408
# Unit test for function main
def test_main():
    """ Unit test for main """
    result = {}
    result['changed'] = False
    result['status'] = {}
    result['status']['enabled'] = {'stdout': None, 'stderr': None, 'rc': None, 'changed': False}
    result['status']['started'] = {'stdout': None, 'stderr': None, 'rc': None, 'changed': False}
    # Create a dummy class object with a dummy method for calling main
    dummyclass = type('DummyClass', (object,), dict(exit_json=lambda self, **kwargs: result.update(**kwargs)))

    # get main method
    main_method = main

    # Create an instance of the dummy class, and create a dummy module object
    dummyinst = dummyclass()

# Generated at 2022-06-23 04:32:01.949208
# Unit test for function main
def test_main():
    if not HAS_YAML:
        raise Exception('PyYAML is required for this module.')

    # Load module source files and add items to globals and locals for the executed example code.
    source_file = '../../../plugins/modules/sysvinit.py'
    p1 = os.path.abspath(os.path.dirname(source_file))
    p2 = os.path.abspath(p1 + "/../../action_plugins")
    p3 = os.path.abspath(p1 + "/../../library")
    p4 = os.path.abspath(p1 + "/../../module_utils")
    p5 = os.path.abspath(p1 + "/../../utils")

# Generated at 2022-06-23 04:32:08.095738
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            state=dict(),
            enabled=dict(),
            sleep=dict(),
            pattern=dict(),
            arguments=dict(),
            runlevels=dict(),
            daemonize=dict(),
        ),
        supports_check_mode=True,
    )

    result = dict(
        changed=False,
        name="apache2",
        status={}
    )

    def runme(doit):
        return (0, '', '')

    test_module.params['name'] = 'apache2'
    test_module.params['enabled'] = True
    test_module.params['runlevels'] = [3, 5]
    test_module.params['daemonize'] = True

# Generated at 2022-06-23 04:32:18.604621
# Unit test for function main
def test_main():
    test_args = {
        'state': 'started',
        'enabled': True,
        'runlevels': ['3', '4', '5'],
        'pattern': '',
        'arguments': '',
        # the following are used by the module internally
        'name': 'foo',
        'sleep': 1,
        'check_mode': True,
    }

    # init AnsibleModule, exit_json and fail_json are overriden.
    AnsibleModule().exit_json = lambda x: None
    AnsibleModule().fail_json = lambda x: None

    module = AnsibleModule(argument_spec=test_args)

    module.run_command = lambda x: (0, 'hello', 'world')
    module.get_bin_path = lambda x, y: x
    x = main()

#

# Generated at 2022-06-23 04:32:31.299038
# Unit test for function main
def test_main():
    import json
    import os
    import pytest
    import subprocess
    import ansible.module_utils.basic
    import ansible.module_utils.action_plugins.systemd
    import ansible.module_utils.service
    #import ansible.module_utils.service_management
    import ansible.module_utils.sysv_functions
    from ansible.module_utils.sysv_functions import get_service
    from ansible.module_utils.service import sysv_exists, sysv_is_enabled, get_sysv_script, fail_if_missing, get_ps, daemonize
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 04:32:44.905804
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:32:52.617142
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=False,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:01.826499
# Unit test for function main
def test_main():
    module_argv = [
        'name=/etc/passwd',
        'state=started',
        'enabled=yes',
        'sleep=1',
        'pattern=root',
        'arguments='
    ]
    module_calls = [
        'name=/etc/passwd',
        'state=started',
        'enabled=yes',
        'sleep=1',
        'pattern=root',
        'arguments='
    ]
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_exists, sysv_is_enabled, get_sysv_script
    import re
    import sys
    import inspect
    import os
    import signal
    import subprocess
    import tempfile

    # For testing purposes, load the sysvinit module without

# Generated at 2022-06-23 04:33:12.088128
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # Reload variables
    module.params = {}

# Generated at 2022-06-23 04:33:22.651435
# Unit test for function main
def test_main():

    import os
    import tempfile
    from ansible.module_utils._text import to_bytes

    # test case 1
    test_state = 'started'
    test_action = 'start'
    test_name = 'test'
    test_enabled = True
    test_runlevels = False
    test_daemonize = False

    test_args = "param=val"
    test_sleep_for = 1


# Generated at 2022-06-23 04:33:34.039514
# Unit test for function main
def test_main():
    from ansible.modules.system.sysvinit import main
    import sys
    import os
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )



# Generated at 2022-06-23 04:33:48.554735
# Unit test for function main
def test_main():
    args = dict(
        name = 'apache2',
        state = 'stopped',
        enabled = 'yes',
        arguments = '/usr/sbin/apache2ctl -D FOREGROUND',
        runlevels = ['3', '4', '5']
    )

# Generated at 2022-06-23 04:33:55.241965
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()


if __name__ == '__main__':
    main

# Generated at 2022-06-23 04:34:08.416506
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    name = 'test-sysvinit'
    service_file = os.path.join(tempfile.gettempdir(), name)
    service_data = '#!/bin/bash\necho "service: $0"\n'

# Generated at 2022-06-23 04:34:11.001086
# Unit test for function main
def test_main():
    # No function to test
    return

# Make the module executable
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:21.588935
# Unit test for function main
def test_main():
    args = dict(name="httpd", state=None, enabled=None, sleep=1, pattern=None, arguments=None, runlevels=None, daemonize=False)
    r = {"status": {"enabled": {"stderr": None, "stdout": None, "rc": None, "runlevels": None, "changed": False}, "started": {"stderr": None, "stdout": None, "rc": None, "changed": False}}, "name": "httpd", "changed": False}
    m = AnsibleModule(argument_spec=args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:29.231688
# Unit test for function main
def test_main():
    argv = [
        '-s', 'not really',
        '-b', 'not.really.exists',
        '-e', '{"name": "test", "enabled": true, "runlevels": ["1", "2"]}'
    ]
    with pytest.raises(SystemExit):
        main()
        sys.argv = argv
        main()

# Generated at 2022-06-23 04:34:40.716021
# Unit test for function main
def test_main():
    # Dummy variables
    varA = {'_ansible_check_mode': True, '_ansible_diff': False, '_ansible_verbosity': 0, '_ansible_version': {'full': '2.5.0', 'major': 2, 'minor': 5, 'revision': 0, 'string': '2.5.0'}, 'ansible_loop_var': 'item', 'changed': False, 'failed': False}
    varB = {'action': 'restarted', 'arguments': None, 'daemonize': False, 'enabled': None, 'name': 'abc', 'pattern': None, 'runlevels': [], 'sleep': 1, 'state': 'restarted'}

    # Assign the arguments to the module

# Generated at 2022-06-23 04:34:42.537548
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:54.575915
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import set_module_args
    test_args = {
        "enabled": False,
        "name": "telnet",
        "state": "started",
    }
    basic._ANSIBLE_ARGS = MagicMock(args=['ansible_module_telnet', 'arg1', 'arg2'])
    set_module_args(test_args)
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-23 04:35:07.443729
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:14.369633
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:35:27.980911
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(required=True, type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # In Ansible 2.8, Ansible changed import paths.

# Generated at 2022-06-23 04:35:35.120764
# Unit test for function main
def test_main():

    # replace with your own test cases
    test_cases = [
        {
            "name": "Unit test for function main",
            "module_args": {
                "name": "apache2",
                "state": "started",
                "enabled": True,
                "sleep": 1,
                "pattern": "",
                "arguments": "",
                "runlevels": [
                    "3",
                    "5"
                ],
                "daemonize": False
            },
            "rc": 0,
            "out": "",
            "err": ""
        }
    ]

    for test_case in test_cases:

        module = AnsibleModule(**test_case['module_args'])

        # This module's function is mainly for unit testing. I'm not sure how
        # to test that the daemonization code is

# Generated at 2022-06-23 04:35:45.819523
# Unit test for function main
def test_main():

    # ansible inputs
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
    )

    # empty result
    result = {
        'name': module.params['name'],
        'changed': False,
        'status': {}
    }

    # empty returning

# Generated at 2022-06-23 04:35:59.020421
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:12.530187
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    # Test case for parameter check.
    argument_spec = dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    )

# Generated at 2022-06-23 04:36:18.508689
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # Mock parameters
    name = module.params['name']

# Generated at 2022-06-23 04:36:27.912624
# Unit test for function main
def test_main():
    from ansible.module_utils.service import sysv_is_enabled, sysv_exists
    name = 'apache'
    state = 'stopped'
    sleep = 1
    enabled = True
    #
    args = 'arguments'
    runlevels = 3
    pattern = 'pattern'
    daemonize = False
    #
    #
    assert sysv_exists(name) == True
    assert sysv_is_enabled(name) == True
    assert sysv_is_enabled(name) == True


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:38.208588
# Unit test for function main
def test_main():
    global module, params, result
    # FIXME: add unit tests
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-23 04:36:41.781537
# Unit test for function main
def test_main():
    runMain = False
    if runMain:
        main()
# Some unit tests below this line
import sys
import unittest

# Helper functions that are not part of the class

# Generated at 2022-06-23 04:36:51.099151
# Unit test for function main
def test_main():
    fake_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    fake_module.automodule = True  # Make it fake real module.
   

# Generated at 2022-06-23 04:37:02.346586
# Unit test for function main
def test_main():

    # Mock ansible module args
    module_args = {
        "arguments": "",
        "pattern": None,
        "name": "nfs-client",
        "enabled": None,
        "sleep": 1,
        "runlevels": None,
        "state": None,
        "daemonize": False,
    }

    # Mock ansible module results
    results = {
        'changed': False,
    }

    # Mock pyrun module instantiation
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # Mock module exit_json
    def exit_json(**kwargs):
        assert kwargs == results
        module.exit_json(**kwargs)

# Generated at 2022-06-23 04:37:11.241013
# Unit test for function main
def test_main():
    if not pytest.config.getoption("--os"):
        pytest.skip("This test only runs on linux")

# Generated at 2022-06-23 04:37:16.306406
# Unit test for function main

# Generated at 2022-06-23 04:37:26.585003
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ), supports_check_mode=True, required_one_of=[['state', 'enabled']])

    main()



if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 04:37:39.364870
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:37:48.874858
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:38:02.656369
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    test_name = test_module.params['name']
    test_action = test_

# Generated at 2022-06-23 04:38:08.396630
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.exit_json(changed=True)



# Generated at 2022-06-23 04:38:16.547793
# Unit test for function main
def test_main():
    import argparse

    argv = [
        '--name=gpg-agent',
        '--state=started'
    ]

    args = argparse.Namespace()
    args.name = 'gpg-agent'
    args.state = 'started'
    args.sleep = 1
    args.pattern = 'gpg-agent'
    args.arguments = False
    args.runlevels = ['3']
    args.enabled = True
    args.daemonize = False

    main(args)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:38:23.165638
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool'),
        ),
        required_one_of=[['state', 'enabled']],
    )
    assert main()

# Generated at 2022-06-23 04:38:24.493261
# Unit test for function main
def test_main():
    # test_main_args

    # test_main_run
    assert True  # Haha, the day someone tests this module is the day I buy a lottery ticket

# Generated at 2022-06-23 04:38:26.487168
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:38:37.498676
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    location = {}
    for binary in ['chkconfig', 'update-rc.d', 'insserv', 'service']:
        location[binary] = module

# Generated at 2022-06-23 04:38:56.021001
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-23 04:39:06.806140
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    process = [ 'bash', '-c', 'echo hello' ]
    rc, out, err = daemonize(AnsibleModule({}), process)
    assert rc == 0, "Failure running daemonize function with valid arguments"

    process = [ 'bash', '-c', 'echo hello' ]
    rc, out, err = daemonize(AnsibleModule({}), process, daemonize=False)
    assert rc == 0, "Failure running daemonize function with valid arguments"

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:11.481201
# Unit test for function main
def test_main():
    import sys, os
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    from action_plugins.sysvinit import main
    try:
        sys.argv.pop(1)
    except:
        pass
    assert main() == None
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 04:39:20.230695
# Unit test for function main
def test_main():
    # Assigned to module so we can call directly with args if needed
    module = AnsibleModule(argument_spec={'name': {'required': True, 'type': 'str', 'aliases': ['service']}, 'state': {'choices': ['started', 'stopped', 'restarted', 'reloaded'], 'type': 'str'}, 'enabled': {'type': 'bool'}, 'sleep': {'type': 'int', 'default': 1}, 'pattern': {'type': 'str'}, 'arguments': {'type': 'str', 'aliases': ['args']}, 'runlevels': {'type': 'list', 'elements': 'str'}, 'daemonize': {'type': 'bool', 'default': False}})
    # Assigned to function so we can call it directly with args if needed

# Generated at 2022-06-23 04:39:32.125496
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    # Make sure old path is not used
    os.unsetenv('PATH')
    # Make sure python path is not used instead of ansible path
    os.unsetenv('PYTHONPATH')

    # Mock subprocess
    class MockPopen(object):
        code = 0
        def __init__(self, *args, **kwargs):
            pass

        def communicate(self):
            return (b'fake_out', b'fake_err')

    class MockModule(object):
        exit_json = sys.exit
        fail_json = sys.exit
        params = {"name": "apache2", "state": "started"}
        get_bin_path = lambda *a, **kw: 'fake_path'

        def __init__(self):
            self.check

# Generated at 2022-06-23 04:39:44.615396
# Unit test for function main
def test_main():
    from ansible.module_utils.common.process import NoSuchProcess
    from ansible.module_utils.service import sysv_is_enabled
    from ansible.module_utils.service import sysv_exists
    from ansible.module_utils.service import get_sysv_script
    from ansible.module_utils.service import fail_if_missing
    from ansible.module_utils.service import get_ps
    global module