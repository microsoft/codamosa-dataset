

# Generated at 2022-06-23 04:29:46.375838
# Unit test for function main
def test_main():
    ansible_args = dict(
        # Uncomment the next line and set to valid values
        #name=dict(required=True, type='str', aliases=['service']),
        #state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        #enabled=dict(type='bool'),
        #sleep=dict(type='int', default=1),
        #pattern=dict(type='str'),
        #arguments=dict(type='str', aliases=['args']),
        #runlevels=dict(type='list', elements='str'),
        #daemonize=dict(type='bool', default=False),
    )
    module = AnsibleModule(ansible_args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:00.058989
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:09.887367
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists

    myModule = sysvinit.main()
    myModule.params = {}
    myModule.params['name'] = 'sendmail'
    myModule.params['state'] = 'started'
    myModule.params['enabled'] = True
    myModule.params['runlevels'] = [3, 5]
    myModule.check_mode = False
    myModule.location = {}
    myModule.location['chkconfig'] = '/sbin/chkconfig'
    myModule.location['insserv'] = '/sbin/insserv'
    myModule.location['service'] = '/sbin/service'

# Generated at 2022-06-23 04:30:16.498700
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    assert main() == None


# Generated at 2022-06-23 04:30:20.284690
# Unit test for function main
def test_main():
    content = read_file('./test_main_module.py')
    print(content)
    sys.exit(1)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:33.603186
# Unit test for function main
def test_main():

    def get_bin_path(name, opt_dirs=[]):
        return "/usr/sbin/service"

    module_args = dict(
        name="httpd",
        enabled=True,
        state="started",
        daemonize=False,
        arguments="",
        sleep=1,
        pattern="",
    )

# Generated at 2022-06-23 04:30:36.066988
# Unit test for function main
def test_main():
    # FIXME: make into a unit test
    pass
# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:44.524741
# Unit test for function main
def test_main():

    import os

    test_args = {
        'state': 'started',
        'enabled': True,
        'daemonize': False,
        'pattern': None,
        'runlevels': ['3', '5'],
        'sleep': 1,
        'arguments': None,
        'name': 'apache2',
        'state_started': True,
        'service': 'apache2',
        '_ansible_check_mode': False
    }
    test_bin = os.getenv('PYTHON_BINARY', sys.executable)

    if '__file__' in test_args.keys():
        test_args.pop('__file__')

    from ansible.module_utils.six import PY3
    if PY3:
        from io import StringIO

# Generated at 2022-06-23 04:30:49.645069
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # unit tests should ensure module doesn't exit
    main()

# Generated at 2022-06-23 04:31:05.771382
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:31:08.618549
# Unit test for function main
def test_main():

    val = main()
    assert val is not None
    print("test_main: val = %s" % (val))

# Generated at 2022-06-23 04:31:19.966866
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.service import has_sysv_exits, sysv_exists, get_sysv_script, sysv_is_enabled
    from ansible.module_utils.common.collections import ImmutableDict

    test_object = basic.AnsibleModule(
        argument_spec = dict(
            name=dict(required=True, type='str'),
            enabled=dict(type='bool'),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # example data
    test_object.params = ImmutableDict(dict(name='apache2', enabled=None))
    test_object.run_command = lambda x: (-1, '', '') # just to pass the tests

# Generated at 2022-06-23 04:31:21.248237
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:31.495356
# Unit test for function main
def test_main():
  import tempfile
  
  fd, path = tempfile.mkstemp()
  print("Path: " + path)
  
  fd, path2 = tempfile.mkstemp()
  print("Path2: " + path2)
  
  fh = open(path, 'w')

# Generated at 2022-06-23 04:31:42.026869
# Unit test for function main
def test_main():
    action = {
        'name': 'httpd',
        'state': 'started',
        'enabled': 'yes',
        'runlevels': ['3','5'],
        'arguments': 'start',
        'daemonize': 'False'
    }
    module = AnsibleModule(argument_spec=action)
    result = main()

# Generated at 2022-06-23 04:31:48.434174
# Unit test for function main
def test_main():
    from ansible.module_utils.power_supply_info import PowerSupplyInfo
    p = PowerSupplyInfo()
    setattr(p, 'sysfs_path', '/sys')
    p.get_info()
    assert p.info == {}

# Use the below if you want to run the module in standalone mode for debugging
#if __name__ == '__main__':
#    main()

##########################################################################################
# BEGIN: Ansible module required functions
##########################################################################################


# Generated at 2022-06-23 04:32:00.213502
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool', default=None),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-23 04:32:13.947031
# Unit test for function main
def test_main():
    question="""
        - name: Make sure apache2 is started
          sysvinit:
              name: apache2
              state: started
              enabled: yes
      
        - name: Make sure apache2 is started on runlevels 3 and 5
          sysvinit:
              name: apache2
              state: started
              enabled: yes
              runlevels:
                - 3
                - 5
    """
    try:
        # Parse example content to get all argument and value
        argument_to_value_dict=json.loads(question)['argument_spec']
        test_function_of_module(__name__, argument_to_value_dict)
    except Exception as e:
        print('test_main',str(e))
        sys.exit(1)


# Generated at 2022-06-23 04:32:25.649673
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True, type='str', aliases=['service']),
            state = dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled = dict(type='bool'),
            sleep = dict(type='int', default=1),
            pattern = dict(type='str'),
            arguments = dict(type='str', aliases=['args']),
            runlevels = dict(type='list', elements='str'),
            daemonize = dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-23 04:32:30.287093
# Unit test for function main
def test_main():
    """ Unit tests for the main() function. """

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-23 04:32:31.752123
# Unit test for function main
def test_main():
    print("hello")
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:33.827171
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:46.381258
# Unit test for function main
def test_main():
    """ Unit tests for function main """
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    args = {
        'name': 'test',
        'state': 'test',
        'enabled': False,
        'runlevels': ['3'],
        'arguments': 'test',
        'daemonize': True
    }
    if not os.path.exists('./test/__init__.py'):
        os.mkdir('./test')
        with open('./test/__init__.py', 'w') as f:
            f.write('')

# Generated at 2022-06-23 04:32:57.013541
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:00.276568
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:10.809504
# Unit test for function main
def test_main():
    import json
    import StringIO
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.run_command=run_command

# Generated at 2022-06-23 04:33:22.312649
# Unit test for function main
def test_main():
    """ sysv: Test for main module """
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=False, type='str'),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False)
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']]
    )
    main()

if __name__ == '__main__':
    main

# Generated at 2022-06-23 04:33:32.895460
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:34.078672
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:33:48.554668
# Unit test for function main
def test_main():

    # Ensure ansible 2.5 used in unit test
    ansible_version = pkg_resources.get_distribution('ansible').version
    assert LooseVersion(ansible_version) >= LooseVersion("2.5"), "Unit test requires ansible version 2.5 or greater, current version is: %s" % ansible_version

    # Module specific imports
    import sys
    import os
    import tempfile
    import shutil
    import errno
    import traceback
    import time
    import ansible.module_utils.basic

    # Prep output dir
    dir_name = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(dir_name)
    output_dir = os.path.join(dir_name, '../output/unit')

# Generated at 2022-06-23 04:33:55.243733
# Unit test for function main
def test_main():
    import inspect
    import unittest
    import os
    import shutil
    import tempfile
    import module_utils.service

    def fake_get_bin_path(arg, opt_dirs=[]):
        return '/bin/true'

    module_utils.service.get_bin_path = fake_get_bin_path


    class AnsibleModule(object):
        def __init__(self, argument_spec):
            self.params = dict(argument_spec)
            for k, v in argument_spec.items():
                if 'default' in v:
                    self.params[k] = v['default']
        def fail_json(self, msg):
            assert False, msg
        def exit_json(self, **kwargs):
            self.result = kwargs

# Generated at 2022-06-23 04:34:07.578049
# Unit test for function main
def test_main():
    import sys
    import json

    # Save the original arguments so we can restore them in cleanup
    ORIG_ARGS = sys.argv

    # Make a deep copy of the arguments without the module filename
    argv = ORIG_ARGS[1:]
    argv = json.loads(json.dumps(argv))

    # Parse the configuration and return an ansible params object
    module = get_module(argv)
    module.params['runlevels'] = ['3', '5']
    module.params['sleep'] = 0
    module.params['arguments'] = ''
    module.params['daemonize'] = False

    main()

    # Restore the original arguments before exiting
    sys.argv = ORIG_ARGS


# Generated at 2022-06-23 04:34:14.410972
# Unit test for function main
def test_main():
    # This is the method that will be used in the mock to replace module.run_command()
    def run_command_mock(self, params):
        (rc, out, err) = (0, "", "")
        return (rc, out, err)
    # Import mocks
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.action_plugins.systemd.service as service
    import types
    # Import sysvinit
    import sysvinit
    # Override the run_command method in AnsibleModule class
    sysvinit.AnsibleModule.run_command = run_command_mock
    global module
    # Load arguments
    name = 'test_name'
    state = 'test_state'


# Generated at 2022-06-23 04:34:21.404542
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json = mock.MagicMock()
    main()
    err = module.exit_json.call_args[0][1]['status']['enabled']['stderr']
    assert err == 'ERROR: No such runlevel'
    pass

# if __name__ == '__main__':
#     main()

# Generated at 2022-06-23 04:34:35.720687
# Unit test for function main

# Generated at 2022-06-23 04:34:40.461208
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:53.979690
# Unit test for function main
def test_main():

    import sys
    import os
    import shutil
    import tempfile
    sys.path.append('../')
    from ansible.module_utils import ansible_module
    module = ansible_module.build_module('sysvinit')
    os_path = os.path.dirname(os.path.realpath(__file__))
    sys_path = os.path.dirname(os_path)
    tmp = tempfile.mkdtemp()
    tmp_path = os.path.join(tmp, 'ansible_module_sysvinit')
    shutil.copytree(os_path, tmp_path)
    sys.path.append(tmp_path)

    # Get the sys v script for dhcp
    script = get_sysv_script('dhcp')

    # Create a fake dhcp script
    fake

# Generated at 2022-06-23 04:35:06.441600
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_

# Generated at 2022-06-23 04:35:19.942881
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.exit_json(**main())

# import module snippets

# Generated at 2022-06-23 04:35:31.858513
# Unit test for function main
def test_main():
    from ansible.modules.system.sysvinit import main
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()


# Generated at 2022-06-23 04:35:39.948592
# Unit test for function main
def test_main():
    """Performs basic tests on the main function"""
    module = AnsibleModule({
        'name': 'sysvinit',
        'state': 'started',
        'enabled': True,
        'sleep': 1,
        'pattern': 'service <pattern>',
        'arguments': '',
        'runlevels': [1],
        'daemonize': False,
    }, no_log=True)
    assert main() is None

# Generated at 2022-06-23 04:35:41.190042
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-23 04:35:48.602895
# Unit test for function main
def test_main():
  # Test without fail_json
  module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
  module.exit_json = MagicMock()
  main()

# Generated at 2022-06-23 04:36:01.591135
# Unit test for function main
def test_main():
    # Test case which calls the function without any argument.
    args = {
        'name': '',
        'state': '',
        'enabled': '',
        'sleep': '',
        'pattern': '',
        'arguments': '',
        'runlevels': [],
        'daemonize': '',
    }

# Generated at 2022-06-23 04:36:12.062078
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

# import module snippets
from ansible.module_utils.basic import *

# Generated at 2022-06-23 04:36:12.969051
# Unit test for function main
def test_main():
    assert True



# Generated at 2022-06-23 04:36:22.145503
# Unit test for function main
def test_main():
    from ansible.module_utils import sysvinit

    test_module = sysvinit

    # Create test object

# Generated at 2022-06-23 04:36:33.318489
# Unit test for function main
def test_main():
    import sys
    from io import StringIO
    module_args = dict(
        name="foo",
        state="reloaded",
        enabled=False,
        runlevels=["3","5"],
        pattern="foo",
    )
    def exit_json(*args, **kwargs):
        pass
    def fail_json(*args, **kwargs):
        sys.exit(1)
    class AnsibleModule(object):
        def __init__(self, *args, **kwargs):
            self.params = args[0]
        def fail_json(self, *args, **kwargs):
            fail_json(*args, **kwargs)
        def exit_json(self, *args, **kwargs):
            exit_json(*args, **kwargs)

# Generated at 2022-06-23 04:36:37.550610
# Unit test for function main
def test_main():
    test_target = SysVModule()
    try:
        test_target.main()
    except SystemExit as e:
        if e.code == 0:
            pass
        else:
            raise
# Unit test to validate results

# Generated at 2022-06-23 04:36:43.370201
# Unit test for function main
def test_main():
    import os
    import sys
    from tempfile import mkstemp
    from shutil import copy
    from contextlib import contextmanager

    @contextmanager
    def open_mock(filename, mode="w"):
        yield tempfile.open(filename, mode)
    import tempfile
    tempfile.open = open_mock
    tempdir = os.path.dirname(tempfile.mkstemp()[1])
    shutil.copytree = lambda br, bw: None
    test_data_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), "../unit/test_data_for_modules/action_plugins/")
    sys.path.insert(0, test_data_dir)

# Generated at 2022-06-23 04:36:51.889055
# Unit test for function main
def test_main():
    """sysvinit (AB-common) unit tests"""
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.six import PY3
    import platform

    # This function is imported at the top of this file and then mocked in the
    # unit tests below.
    def get_bin_path(binary, opt_dirs=None):
        if not isinstance(opt_dirs, list):
            opt_dirs = []

        return binary

    # Mock Python 3's builtin check_output function
    if PY3:
        import sys
        import io
        import subprocess

        def subprocess_check_output(*popenargs, **kwargs):
            """Mock version of subprocess.check_output for Python 3."""

# Generated at 2022-06-23 04:37:01.750058
# Unit test for function main
def test_main():
    this = os.path.splitext(os.path.basename(__file__))[0]
    runlevels = []

    # Set up mock module
    mock_module = MagicMock()
    mock_module.params = {}
    mock_module.params['state'] = 'started'
    mock_module.params['name'] = 'apache2'
    mock_module.params['enabled'] = 'yes'
    mock_module.params['daemonize'] = 'no'
    mock_module.params['sleep'] = '1'
    mock_module.params['pattern'] = ''
    mock_module.params['arguments'] = ''

    rv = sysvinit.main(mock_module)

main()

# Generated at 2022-06-23 04:37:10.824441
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name = dict(required=True, type='str', aliases=['service']),
            state = dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled = dict(type='bool'),
            sleep = dict(type='int', default=1),
            pattern = dict(type='str'),
            arguments = dict(type='str', aliases=['args']),
            runlevels = dict(type='list', elements='str'),
            daemonize = dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    ###########################################################################
    # BEGIN: Test cases
    ###########################################################################

   

# Generated at 2022-06-23 04:37:23.165801
# Unit test for function main
def test_main():
    # Test 1
    module_args = {}
    res = AnsibleModule(argument_spec=module_args).execute_module()
    assert 'service' in res['msg']

    # Test 2
    module_args = {"name": "foo", "state": "started"}
    res = AnsibleModule(argument_spec=module_args).execute_module()
    assert 'script' in res['msg']

    # Test 3
    module_args = {"name": "foo", "state": "started", "pattern": "foo"}
    res = AnsibleModule(argument_spec=module_args).execute_module()
    assert 'script' in res['msg']

    # Test 4
    module_args = {"name": "foo", "state": "started", "pattern": "foo", "daemonize": True}
    res = AnsibleModule

# Generated at 2022-06-23 04:37:29.114387
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name = dict(required = True, type = 'str', aliases=['service']),
        state = dict(type = 'str', choices = ['started', 'stopped', 'restarted', 'reloaded']),
        enabled = dict(type = 'bool'),
        sleep = dict(type = 'int', default = 1),
        pattern = dict(type = 'str'),
        arguments = dict(type = 'str', aliases=['args']),
        runlevels = dict(type = 'list', elements='str'),
        daemonize = dict(type = 'bool', default = False),
    ))
    main()

# Generated at 2022-06-23 04:37:41.599023
# Unit test for function main
def test_main():
    test_args = {
        'name': 'test',
        'state': 'test',
        'enabled': False,
        'sleep': 1,
        'pattern': 'test',
        'arguments': 'test',
        'runlevels': [ 'test' ],
        'daemonize': False,
    }

    if False:
        # Alter parameters
        test_args['name'] = 'foo'
        test_args['state'] = 'foo'
        test_args['enabled'] = True
        test_args['sleep'] = 2
        test_args['pattern'] = 'foo'
        test_args['arguments'] = 'foo'
        test_args['runlevels'] = [ 'foo' ]
        test_args['daemonize'] = True

# Generated at 2022-06-23 04:37:49.670124
# Unit test for function main
def test_main():
    if name == '__main__':
        sys.path.append('..')
        # only import when running stand alone

        class Module(object):
            def __init__(self, **kwargs):
                self.params = kwargs
                self.check_mode = False
                self.module_args = kwargs
            def fail_json(self, **kwargs):
                pass

        class RunCmd(object):
            def __init__(self, cmd, **kwargs):
                self.state = 'noop'
                self.rc = 0
                self.stdout = ''
                self.stderr = ''
                self.__cmd = cmd
                self.__kwargs = kwargs
            def get_output(self):
                return (self.rc, self.stdout, self.stderr)
           

# Generated at 2022-06-23 04:38:03.057717
# Unit test for function main
def test_main():
    # ansible func module import
    from ansible.module_utils.basic import AnsibleModule
    # test case init

# Generated at 2022-06-23 04:38:08.718197
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import get_sysv_script
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-23 04:38:19.297472
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    script = get_sysv_script(module.params['name'])
    assert script is not False


# Generated at 2022-06-23 04:38:33.717600
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    import sys
    print(sys.path)
    print(basic.__file__)

    class Args(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class Module(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

        def get_bin_path(self, value, opt_dirs=None):
            return value

        def run_command(self, value):
            return (1, '', '')

        def exit_json(self, **entries):
            print(entries)

        def fail_json(self, **entries):
            print(entries)

# Generated at 2022-06-23 04:38:49.735055
# Unit test for function main
def test_main():
    mod = AnsibleModule(
        argument_spec={
            'name': { 'type': 'str', 'required': True, 'aliases': ['service'] },
            'state': { 'type': 'str', 'choices': ['started', 'stopped', 'restarted', 'reloaded'] },
            'enabled': { 'type': 'bool' },
            'sleep': { 'type': 'int', 'default': 1 },
            'pattern': { 'type': 'str' },
            'runlevels': { 'type': 'list', 'elements': 'str' },
            'daemonize': { 'type': 'bool', 'default': False },
        },
        required_one_of=[['state', 'enabled']],
    )

    mock_run_command = MagicMock(return_value=(0, None, None))
    mock

# Generated at 2022-06-23 04:38:55.963259
# Unit test for function main
def test_main():
    args = dict(
        name="filesystem",
        state=None,
        enabled=None,
        sleep=1,
        pattern=None,
        arguments=None,
        runlevels=None,
    )
    result = AnsibleModule(argument_spec={}).execute_module(**args)
    assert result['name'] == 'filesystem'


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:08.506765
# Unit test for function main
def test_main():
    args = dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    )
    module = AnsibleModule(argument_spec=args,
                           supports_check_mode=True,
                           required_one_of=[['state', 'enabled']])

    rc = 0
    out = err = ''

# Generated at 2022-06-23 04:39:17.597562
# Unit test for function main

# Generated at 2022-06-23 04:39:30.051946
# Unit test for function main
def test_main():

    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils import service
    from ansible.module_utils.six.moves import builtins

    ###########################################################################
    # BEGIN: Generate an instance of ArgumentSpec()
    argument_spec = basic.AnsibleModule(argument_spec={})

# Generated at 2022-06-23 04:39:32.629810
# Unit test for function main
def test_main():
    assertion = 'test'
    assert assertion == 'test'
    
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:45.080126
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = test.params['name']
    action = test.params['state']