

# Generated at 2022-06-11 08:08:46.421086
# Unit test for function main
def test_main():
    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), '../molecule/common'))
    from test_ansible.results import TestCreateResult

    TCR = TestCreateResult()


# Generated at 2022-06-11 08:08:59.257122
# Unit test for function main
def test_main():
    import sys
    import os
    import json

    class mock_module(object):
        def fail_json(*args, **kwargs):
            self.fail_args = args[1]
            self.fail_kwargs = kwargs
            self.exit_args = {'failed': True}
        def exit_json(*args, **kwargs):
            self.exit_args = args[1]

    class mock_runner(object):
        def run_command(*args, **kwargs):
            return args[1], '', ''

    def get_bin_path(bin, opt_dirs=[]):
        if bin == 'update-rc.d' or bin == 'chkconfig':
            return '%s/test-bin' % bin
        return None

    def sysv_exists():
        return True


# Generated at 2022-06-11 08:09:10.187898
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.run_command = mock.Mock(return_value=(0, '', ''))


# Generated at 2022-06-11 08:09:11.550394
# Unit test for function main
def test_main():
    print(main)


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:09:23.025291
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:09:33.299692
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main(module)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:09:44.524658
# Unit test for function main
def test_main():

    action = r'started'
    enabled = False
    is_started = False
    out = err = ''
    cmd = script = location = name = pattern = sleep_for = result = rc = runlevels = ''

    def runme(doit):

        args = ''
        cmd = "%s %s %s" % (script, doit, "" if args is None else args)

        rc = 0
        out = err = ''

        return (rc, out, err)

    if action:
        action = re.sub(r'p?ed$', '', action.lower())

        if action == 'restart':
            result['changed'] = True

            if sleep_for:
                print('sleep')

        elif is_started != (action == 'start'):
            result['changed'] = True


# Generated at 2022-06-11 08:09:55.481783
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec= dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
        )

# Generated at 2022-06-11 08:10:01.559096
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:10:03.979487
# Unit test for function main
def test_main():
    # Tests for function main
    assert main.__name__ == "main"


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:10:55.675551
# Unit test for function main
def test_main():
    out1 = main()
    out2 = main()
    if out1 != out2:
        raise AssertionError("Unit test for function main failed")


# Generated at 2022-06-11 08:11:06.353619
# Unit test for function main
def test_main():
    # Test case data
    data = dict(
        name='service_name',
        pattern='service_name',
        state='restarted',
        enabled=True,
        sleep=1,
        runlevels=['3', '5'],
        daemonize=False,
    )
    # Module creation
    my_module = AnsibleModule(argument_spec=data)
    # Test failure if service command fails
    # Unit test
    my_module.params["name"] = ""
    main()
    # Test failure if enable command fails
    main()
    # Test failure if disable command fails
    main()
    # Test failure if enable command fails
    main()
    # Test failure if disable command fails
    main()
    # Test failure if start command fails
    main()
    # Test failure if restart command fails
    main()
   

# Generated at 2022-06-11 08:11:17.506764
# Unit test for function main
def test_main():
    import sys
    import tempfile

    sys.path.append('./lib/')
    test_service_name = 'not_a_real_service'

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    def test_fail_if_missing():
        if sysv_exists(test_service_name):
            module.fail_json(msg="Testing of sysv_exists failed!  The service exists!  DANGER DANGER DANGER")

    def test_get_sysv_script():
        script = get_sysv_script(test_service_name)

# Generated at 2022-06-11 08:11:22.685698
# Unit test for function main
def test_main():
    some_dict = {
        "state": "restarted",
        "name": "httpd"
    }
    assert main({
        "params": some_dict
    }) == {
        "params": some_dict,
        "check_mode": False
    }

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:33.392128
# Unit test for function main
def test_main():
    # Test to see if AnsibleModule is working
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    assert 'state' in module.params
   

# Generated at 2022-06-11 08:11:45.583011
# Unit test for function main
def test_main():
    # First we create a module, and set the input and return values of the function.
    # We have to create the module in a specific way, because we need to set a few
    # command line arguments, which would not be required in the normal Ansible
    # execution flow. The name of the module is stored in the module_name var, we
    # currently don't use it, but it might be useful later.
    module_name = 'sysvinit'
    set_module_args(dict(
        name="apache2",
        state="started",
        enabled=True
    ))

# Generated at 2022-06-11 08:11:56.690309
# Unit test for function main
def test_main():
    # NOTE: format of test_cases is [ <main_args>, <expected_return_val> ]
    test_cases = [
        # FIXME: implement
        # [ {"state": "started", "enabled": "yes"},
        #   { "changed": True, "status": { "enabled": { "changed": True, "rc": 0, "stdout": "", "stderr": "" }, "started": { "changed": True, "rc": 0, "stdout": "", "stderr": "" } } } ],
        # [ {"state": "started", "enabled": "no"},
        #   { "changed": True, "status": { "enabled": { "changed": True, "rc": 0, "stdout": "", "stderr": "" } } } ],
    ]

# Generated at 2022-06-11 08:12:08.204162
# Unit test for function main
def test_main():

    # To avoid a pytest error module 'ansible_collections.ansible.community.plugins.modules.service.sysvinit'
    # has no attribute 'main'
    import ansible_collections.ansible.community.plugins.modules.service.sysvinit

    # To avoid a pytest error module 'ansible_collections.ansible.community.plugins.modules.service'
    # has no attribute 'main'
    import ansible_collections.ansible.community.plugins.modules.service

    # To avoid a pytest error module 'ansible_collections.ansible.community.plugins.modules.service.sysvinit'
    # has no attribute 'module'
    import ansible_collections.ansible.community.plugins.modules.service.sysvinit

    # To avoid a pytest error module 'ansible.module_

# Generated at 2022-06-11 08:12:09.803005
# Unit test for function main
def test_main():

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:18.431451
# Unit test for function main
def test_main():
    mod = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # Create the test case
    class Args:
        name= 'test'

# Generated at 2022-06-11 08:14:00.897383
# Unit test for function main
def test_main():
    """
    Unit test for function main
    :return:
    """
    print("test_main")
    main()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-11 08:14:11.049669
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:14:21.388107
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True, type='str'),
            state = dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled = dict(type='bool'),
            sleep = dict(type='int', default=1),
            pattern = dict(type='str'),
            arguments = dict(type='str', aliases=['args']),
            daemonize = dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']
    enabled = module.params['enabled']
    sleep_for = module.params['sleep']
    pattern

# Generated at 2022-06-11 08:14:22.207158
# Unit test for function main

# Generated at 2022-06-11 08:14:23.271555
# Unit test for function main
def test_main():
    assert 1


# Generated at 2022-06-11 08:14:32.108791
# Unit test for function main
def test_main():
    expected = {'changed': True,
                'status': {
                'enabled': {
                    'changed': True,
                    'rc': 0,
                    'stdout': None,
                    'stderr': None
                },
                'stopped': {
                    'changed': True,
                    'rc': 0,
                    'stdout': None,
                    'stderr': None
                }
            }
        }
    mock_module = AnsibleModule({"state": "stopped",
                                 "enabled": False})
    mock_module.exit_json = lambda x=None: expected
    sysvinit.main()


# Generated at 2022-06-11 08:14:43.207599
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'name': {'required': True, 'type': 'str'}, 'sleep': {'default': 1, 'type': 'int'}, 'enabled': {'type': 'bool'}, 'state': {'choices': ['started', 'stopped', 'restarted', 'reloaded'], 'type': 'str'}, 'runlevels': {'type': 'list', 'elements': 'str'}, 'arguments': {'type': 'str', 'aliases': ['args']}, 'daemonize': {'type': 'bool', 'default': False}}, supports_check_mode=True, required_one_of=[['state', 'enabled']])
    module.exit_json = lambda x: x
    result = main()
    assert isinstance(result, dict)


# Generated at 2022-06-11 08:14:53.920833
# Unit test for function main
def test_main():
    state = 'started'
    enabled = True
    runlevels = ['3', '5']
    pattern = 'apache2'
    sleep_for = 1
    rc = 0
    out = err = ''
    result = {
        'name': name,
        'changed': False,
        'status': {}
    }

    # ensure service exists, get script name
    fail_if_missing(module, sysv_exists(name), name)
    script = get_sysv_script(name)

    # locate binaries for service management
    paths = ['/sbin', '/usr/sbin', '/bin', '/usr/bin']
    binaries = ['chkconfig', 'update-rc.d', 'insserv', 'service']

    # Keeps track of the service status for various runlevels because we can
    # operate on multiple run

# Generated at 2022-06-11 08:15:04.574158
# Unit test for function main
def test_main():
    '''
    Validate module's method main
    '''
    # Read in the module arguments
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-11 08:15:17.064633
# Unit test for function main
def test_main():
    # Mock return values of AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']