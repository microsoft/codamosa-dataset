

# Generated at 2022-06-11 08:08:42.410266
# Unit test for function main
def test_main():
    import sys
    import tempfile
    import platform
    module = AnsibleModule(argument_spec={
        'name': dict(required=True, type='str', aliases=['service']),
        'state': dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        'enabled': dict(type='bool'),
        'sleep': dict(type='int', default=1),
        'pattern': dict(type='str'),
        'arguments': dict(type='str', aliases=['args']),
        'runlevels': dict(type='list', elements='str'),
        'daemonize': dict(type='bool', default=False),
    }, supports_check_mode=True)
    name = module.params['name']
    action = module.params['state']
    enabled = module

# Generated at 2022-06-11 08:08:50.085033
# Unit test for function main
def test_main():
    args = dict(
        name="sshd",
        daemonize=True,
        sleep=2
    )
    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str', required=True, aliases=['service']),
        daemonize=dict(type='bool', default=False),
        sleep=dict(type='int', default=1)
    ))

    rc = main()
    print(rc)


# Generated at 2022-06-11 08:09:01.849825
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:09:12.041381
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    try:
        from ansible.modules.system.service import ActionModule as sysvinit
    except ImportError:
        sysvinit = None

    if sysvinit is None:
        raise ImportError("sysvinit could not be imported")
    else:
        sysvinit = sysvinit()
    sysvinit.params = {
        "name": "service_name",
        "state": "state",
        "enabled": "enabled"
    }
    sysvinit.fail_json = lambda x: basic._ANSIBLE_ARGS

    try:
        sysvinit.main()
    except TypeError as e:
        if 'unexpected keyword argument' in to_bytes(e):
            return
    raise Assert

# Generated at 2022-06-11 08:09:23.405535
# Unit test for function main
def test_main():
    args = dict(
        name='ping',
        state="started",
        sleep=1,
        pattern=None,
        arguments=None,
        runlevels=None,
        daemonize=False,
    )

    module = AnsibleModule(argument_spec={})
    module.exit_json = Mock(return_value=dict(
        name='ping',
        state='started',
        sleep=1,
        pattern=None,
        arguments=None,
        runlevels=None,
        daemonize=False
    ))

    sysvinit = Sysvinit()

# Generated at 2022-06-11 08:09:34.033023
# Unit test for function main
def test_main():
    """Test function main"""

    ansible_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()



# Generated at 2022-06-11 08:09:45.368077
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:09:46.590159
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 08:09:56.783359
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    test.exit_json(**main())


# Generated at 2022-06-11 08:10:06.946116
# Unit test for function main
def test_main():
    # TODO: Provide this as a resource or generate this
    # as a utility script
    class MockModule():
        """
    Mock ansible.module_utils.basic.AnsibleModule object
        """

        class MockCommand():
            """
            Mock class to allow side effects
            """
            def __init__(self, module):
                self.module = module
                self.commands = {}

            def run_command(self, cmd):
                """
                Side effect method to emulate module.run_command
                """
                if type(cmd) not in self.commands.keys():
                    raise KeyError("Command '%s' not found in mock commands" % cmd)

                return self.commands[type(cmd)]

        def __init__(self, **kwargs):
            self.params = kwargs
            self.check

# Generated at 2022-06-11 08:11:06.797942
# Unit test for function main
def test_main():
    import sysvinit
    from ansible.module_utils import basic
    from ansible.module_utils import service
    from ansible.module_utils.service import sysv_is_enabled, sysv_exists
    import json

    ###########################################################################
    #
    # Example of functionality without multiple return values:
    #
    # (rc, out, err) = module.run_command('ls /')
    #
    # returns:
    #
    # rc = 0
    # out = "file1 file2 file3 .... "
    # err = ""
    #
    ###########################################################################

    ###########################################################################
    #
    # Example of functionality with multiple return values:
    #
    # def runme(doit):
    #     cmd = "%s %s %s" % (script, doit

# Generated at 2022-06-11 08:11:13.718416
# Unit test for function main
def test_main():
    input = {'name':'test_service_name','state':'test_state','enabled':True,'sleep':1,'pattern':'test_pattern','arguments':'test_args','runlevels':['test_rl1', 'test_rl2']}
    module = AnsibleModule(argument_spec=input)
    test_main_value = main()
    assert test_main_value == module.exit_json()



if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:25.366278
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    # create mock module
    m = basic.AnsibleModule(
        argument_spec = dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # create

# Generated at 2022-06-11 08:11:35.327703
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:11:47.095144
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:11:53.192466
# Unit test for function main
def test_main():
    module = AnsibleModule()
    args = dict(
        name='apache2',
        state='started',
        enabled=True,
        sleep=1,
        pattern='',
        arguments='',
        runlevels=['3', '5'],
        daemonize=True,
    )
    module.params = args
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:00.260383
# Unit test for function main
def test_main():
    #import sys
    #sys.argv.append('--debug')
    #test_ansible_module(MODULE_PATH, 'main', FUNCTION_NAME, *test_arguments, **test_kwargs)
    #test_ansible_module(MODULE_PATH, 'main', FUNCTION_NAME, *test_arguments, **test_kwargs)
    test_ansible_module(MODULE_PATH, 'main', FUNCTION_NAME)


# Generated at 2022-06-11 08:12:02.331075
# Unit test for function main
def test_main():
    """Function for unit-testing"""
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:13.689532
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.exit_json(**main())

if __name__ == '__main__':
    main

# Generated at 2022-06-11 08:12:24.549299
# Unit test for function main
def test_main():
    # Use the AnsibleModuleTest harness to test the function
    module = AnsibleModuleTestHarness(main)
    # provide the module parameters and expected results
    module.params = dict(
        # Test all return values
        name='httpd',
        state='started',
        enabled=True,
        sleep=0,
        pattern='/usr/sbin/httpd',
        arguments='',
        runlevels='3',
        daemonize=False
    )

# Generated at 2022-06-11 08:14:13.293205
# Unit test for function main
def test_main():
    from ansible.module_utils.ansible_sax.sysvinit import main as target
    import ansible.module_utils.ansible_sax.module_utils.basic as mbasic
    import ansible.module_utils.ansible_sax.module_utils.service as mservice

    target.sysv_is_enabled = lambda x: True
    target.sysv_exists = lambda x: True
    target.get_sysv_script = lambda x: 'testscript'
    target.get_ps = lambda x, y: True
    target.AnsibleModule = mbasic.AnsibleModule
    target.daemonize = lambda x, y: (0, '', '')
    class mmodule(answer=None):
        def __init__(self, answer):
            self.answers = answer
       

# Generated at 2022-06-11 08:14:22.952372
# Unit test for function main
def test_main():
    import sys
    import json
    munch = AnsibleModule(argument_spec={
        'name': dict(required=True),
        'arguments': dict(),
        'pattern': dict(),
        'runlevels': dict()
    })

    sys.modules['ansible.module_utils.basic'] = sys.modules['ansible.module_utils.basic']
    sys.modules['ansible.module_utils.service'] = sys.modules['ansible.module_utils.service']

    mock_run_command = lambda x: (0, '', '')
    munch.run_command = mock_run_command
    mock_get_bin_path = lambda x: '/bin/chkconfig'
    munch.get_bin_path = mock_get_bin_path

# Generated at 2022-06-11 08:14:33.254892
# Unit test for function main

# Generated at 2022-06-11 08:14:44.498696
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
    )

    # Make sure service doesn't exist
    module.run_command("service testservice stop")

# Generated at 2022-06-11 08:14:54.857519
# Unit test for function main
def test_main():
    #import pdb; pdb.set_trace()
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-11 08:15:05.811782
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
    )

    result = {}
    result['name'] = 'httpd'
    result

# Generated at 2022-06-11 08:15:17.947552
# Unit test for function main
def test_main():
    """ Create the class to be instantiated for testing """
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    """ Instantiate the class we're testing """

# Generated at 2022-06-11 08:15:28.374221
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # locate binaries for service management

# Generated at 2022-06-11 08:15:39.018602
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # Mock return values of AnsibleModule.exit_json
    m_exit_json = mocker

# Generated at 2022-06-11 08:15:46.308237
# Unit test for function main
def test_main():
    # Mock the module class
    module = Mock()
    module.check_mode = False
    module.get_bin_path = Mock(return_value='/bin/')

    def run_command(*args, **kwargs):
        return 0, '', ''

    module.run_command = Mock(side_effect=run_command)

    # The args/params we pass to the module
    module.params = {
        'name': 'apache2',
        'state': 'started',
        'enabled': True,
        'sleep': 1,
        'pattern': '',
        'arguments': '',
        'runlevels': '',
        'daemonize': False,
    }

    # The functions we mock so that module.exit_json() and fail_json() get called