

# Generated at 2022-06-11 08:08:37.901936
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 08:08:50.085950
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # Mock run_command
    import __builtin__
    old_run_command = __built

# Generated at 2022-06-11 08:09:01.849380
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:09:06.937156
# Unit test for function main
def test_main():
    module = AnsibleModule(
    name = "tst_sysvinit",
    argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ),
    supports_check_mode=True,
    required_one_of=[['state', 'enabled']],
    )
    main()

# Generated at 2022-06-11 08:09:14.713287
# Unit test for function main
def test_main():
    import sys
    import os
    import time
    import json

    env_vars = {}


# Generated at 2022-06-11 08:09:25.386239
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'name': {'required': True, 'type': 'str'}, 'state': {'required': False, 'choices': ['started', 'stopped', 'restarted', 'reloaded'], 'type': 'str'}, 'enabled': {'required': False, 'type': 'bool'}, 'sleep': {'required': False, 'type': 'int', 'default': 1}, 'pattern': {'required': False, 'type': 'str'}, 'arguments': {'required': False, 'type': 'str', 'aliases': ['args']}, 'runlevels': {'required': False, 'type': 'list', 'elements': 'str'}, 'daemonize': {'required': False, 'type': 'bool', 'default': False}})

# Generated at 2022-06-11 08:09:36.438923
# Unit test for function main
def test_main():
    import os
    import platform
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled
    module = AnsibleModule(argument_spec={
        'name': {'required': True, 'type': 'str'},
        'enabled': {'required': True, 'type': 'bool'},
        'runlevels': {'required': True, 'type': 'list', 'elements': 'str'},
    })

    # This is messy, the module assumes you have a valid sysv script
    # and that the script properly implements status
    if platform.system() != 'Linux':
        module.warn("Trying to execute sysvinit unit test on a non-linux host, skipping")
        return False


# Generated at 2022-06-11 08:09:41.317171
# Unit test for function main
def test_main():
    # Check for required parameters
    module = AnsibleModule({
        'name': 'apache2',
        'enabled': None,
        'runlevels': None,
        'state': None,
        'pattern': None,
        'sleep': 1,
    })
    result = main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:09:53.238038
# Unit test for function main
def test_main():
    from ansible.module_utils.service import sysv_exists
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-11 08:10:03.752325
# Unit test for function main
def test_main():
  with patch('ansible.module_utils.common.sysvinit.get_sysv_script', return_value = 'None'):
    with patch('ansible.module_utils.common.sysvinit.sysv_exists', return_value = 'None'):
      with patch('ansible.module_utils.basic.AnsibleModule.run_command', return_value = ('0', 'stdout', 'stderr')):
        sysvinit = sys.modules['ansible.module_utils.common.sysvinit']
        sysvinit.main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:05.276992
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-11 08:11:07.306967
# Unit test for function main
def test_main():
  raise Exception("Unit test not implemented")


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:18.582352
# Unit test for function main
def test_main():
    argv = []
    argv.append('')

    class Args(object):
        def __init__(self):
            self.daemonize = True

# Generated at 2022-06-11 08:11:29.950099
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:11:39.112567
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:11:47.671791
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:59.512356
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:12:11.014659
# Unit test for function main
def test_main():
    '''
    sysvinit.py Unit test
    '''
    # Save the current values so that we can restore them after
    # we are done with our testing


# Generated at 2022-06-11 08:12:19.045192
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-11 08:12:23.001422
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda data : None
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:13:13.951070
# Unit test for function main

# Generated at 2022-06-11 08:13:15.882207
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:13:24.326138
# Unit test for function main
def test_main():
    """
    Test for function main
    """
    import platform

    class TestAnsibleModule(object):

        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

        def get_bin_path(self, *args, **kwargs):
            # FIXME
            return '/usr/bin/'+args[0]

        def run_command(self, *args, **kwargs):
            # FIXME
            return (0, '', '')



# Generated at 2022-06-11 08:13:25.656605
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:13:28.655391
# Unit test for function main
def test_main():
    inp = { "name" : "good", "state" : "running" }
    rc = runme(inp, True)
    assert rc['rc'] == 0
    #assert rc['stdout'] == '{"changed": true, "msg": "OK"}'


# Generated at 2022-06-11 08:13:37.871090
# Unit test for function main
def test_main():
    load_fixture(dict(
        name='test_name',
        state='test_state',
        enabled=True,
        sleep=1,
        pattern=None,
        arguments='test_arguments',
        runlevels=['test_runlevels'],
        daemonize=False,
    ))

# Generated at 2022-06-11 08:13:47.287217
# Unit test for function main
def test_main():
    name = 'apache2'
    action = 'started'
    enabled = True
    runlevels = ['3', '5']
    pattern = 'apache'
    sleep_for = 1
    checkmode = False

# Generated at 2022-06-11 08:13:58.687874
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    def get_bin_path(bin_name, opt_dirs=None):
        return '/bin/' + bin_name


# Generated at 2022-06-11 08:14:08.602411
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    assert main() == 'foo'

if __name__ == '__main__':
    main

# Generated at 2022-06-11 08:14:10.469627
# Unit test for function main
def test_main():
    module.exit_json(msg="Hello world")


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:15:06.985722
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule'):
        with patch('ansible.module_utils.service.sysv_is_enabled') as sysv_is_enabledMock:
            with patch('ansible.module_utils.service.get_sysv_script') as get_sysv_scriptMock:
                with patch('ansible.module_utils.service.sysv_exists') as sysv_existsMock:
                    with patch('ansible.module_utils.service.fail_if_missing') as fail_if_missingMock:
                        with patch('ansible.module_utils.service.get_ps') as get_psMock:
                            with patch('ansible.module_utils.service.daemonize') as daemonizeMock:
                                main()

# Generated at 2022-06-11 08:15:08.512580
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:15:19.421325
# Unit test for function main
def test_main():
    # Load module as a pseudo action plugin
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ), supports_check_mode=True, required_one_of=[['state', 'enabled']])

    module.exit_json = exit_json
    module.fail_json = fail_json

# Generated at 2022-06-11 08:15:30.373490
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule, get_exception
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    #################################

# Generated at 2022-06-11 08:15:34.548691
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:15:42.912492
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    class ModuleFailException(Exception):
        pass
    import sys
    import subprocess
    #

# Generated at 2022-06-11 08:15:51.488594
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common import json

    modargs = json.dumps({'name':'apache2', 'state':'started', 'enabled':True, 'sleep':1, 'pattern':'', 'arguments':'', 'runlevels':'3,5', 'daemonize':False})
    modargs = modargs.encode("utf-8")
    results = basic.run_command(to_bytes("/usr/local/bin/ansible-test units --python %s" % __file__), stdin_data=modargs)
    assert results['rc'] == 0
    assert results['stderr'] == b''
   

# Generated at 2022-06-11 08:15:54.160870
# Unit test for function main
def test_main():
    module = AnsibleModule(dict(name='ansible-sysvinit', state='started'))
    try:
        main()
    except Exception as e:
        raise
# Test code
#main()
test_main()

# Generated at 2022-06-11 08:16:01.246543
# Unit test for function main
def test_main():
    module_args = dict( name="apache2", state="started", enabled=True)
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value='/bin')
    sysvinit = Sysvinit( module, module_args )
    sysvinit.main()
    module.exit_json.assert_called_with(changed=True, name="apache2", results="success" )


# Generated at 2022-06-11 08:16:10.480685
# Unit test for function main
def test_main():
    args_for_result = {
        "state": "started", 
        "enabled": True, 
        "runlevels": ["1"],
        "daemonize": True,
        "sleep": 1,
        "pattern": "sshd",
        "name": "my_service"
    }
    res_args = {
        "name": "my_service",
        "changed": True,
        "status": {
            "started": {"changed": True, "rc": 0, "stderr": "", "stdout": ""},
            "enabled": {
                "changed": True,
                "runlevels": ["1"],
                "rc": 0,
                "stdout": "",
                "stderr": ""
            }
        }
    }
    main()
    # TODO: Check result with Ansible