

# Generated at 2022-06-11 08:08:47.717625
# Unit test for function main
def test_main():

    # Unit test for function main
    def test_main():
        module = AnsibleModule(
            argument_spec=dict(
                name=dict(required=True, type='str', aliases=['service']),
                state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
                enabled=dict(type='bool'),
                sleep=dict(type='int', default=1),
                pattern=dict(type='str'),
                arguments=dict(type='str', aliases=['args']),
                runlevels=dict(type='list', elements='str'),
                daemonize=dict(type='bool', default=False),
            ),
            supports_check_mode=True,
            required_one_of=[['state', 'enabled']],
        )

    main()



# Generated at 2022-06-11 08:09:00.230070
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule, env_fallback
    from ansible.module_utils.six.moves import StringIO


# Generated at 2022-06-11 08:09:05.056632
# Unit test for function main
def test_main():

    class FakeModule(object):
        '''Fake module for unit tests'''

        FAKE_RESULTS = dict(
            params=dict(daemonize=False),
            check_mode=True,
        )

        def __init__(self):
            self.params = dict()
            self.exit_json = self.fake_exit_json

        def fake_exit_json(self, *args, **kwargs):
            '''Fake exit_json'''
            self.FAKE_RESULTS['changed'] = True
            self.FAKE_RESULTS['results'] = kwargs

        def get_bin_path(self, binary, opt_dirs=[]):
            '''Fake get_bin_path'''
            return binary

    my_module = FakeModule()

# Generated at 2022-06-11 08:09:13.880590
# Unit test for function main
def test_main():
    args = dict(
        name='test_serv',
        state='started',
        enabled=True,
        pattern=r'pattern',
        sleep=2,
        runlevels=['3', '5'],
        arguments='arguments',
        daemonize=True
    )

# Generated at 2022-06-11 08:09:24.737264
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    test_module.exit_json = exit_json
    test_module.fail_json

# Generated at 2022-06-11 08:09:35.644408
# Unit test for function main

# Generated at 2022-06-11 08:09:47.352751
# Unit test for function main
def test_main():
    # New module object
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # Include unit test as module argument

# Generated at 2022-06-11 08:09:57.164525
# Unit test for function main
def test_main():
    result = {
        'name': 'apache2',
        'changed': False,
        'status': {
            'enabled': {
                'runlevels': ['3', '5'],
                'changed': True,
                'rc': None,
                'stdout': None,
                'stderr': None
            },
            'stopped': {
                'changed': False,
                'rc': None,
                'stdout': None,
                'stderr': None
            }
        }
    }


# Generated at 2022-06-11 08:10:07.222093
# Unit test for function main
def test_main():
    # Mock parameters
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

# import module snippets

# Generated at 2022-06-11 08:10:17.736997
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleFailJson):
        result = dict(
            changed=False,
            name='apache2',
            status=dict(
                enabled=dict(
                    changed=True,
                    rc=None,
                    stderr=None,
                    stdout=None,
                ),
                stopped=dict(
                    changed=True,
                    rc=0,
                    stderr="",
                    stdout="Stopping web server: apache2.\n"
                )
            )
        )

# Generated at 2022-06-11 08:11:17.988500
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import shutil
    import tempfile
    import platform
    import ansible.module_utils.service as service_utils
    import ansible.module_utils.basic

    def get_current_state(name, path):
        is_started = False
        is_enabled = True
        if name == "insserv":
            is_enabled = service_utils.sysv_is_enabled(name, runlevel=None)
        else:
            is_enabled = service_utils.sysv_is_enabled(name, runlevel=[2])
        is_started = service_utils.sysv_is_running(name, path)
        return is_started, is_enabled

    # Test file
    script_name = "test_script"

# Generated at 2022-06-11 08:11:29.433560
# Unit test for function main
def test_main():
    import os
    try:
        os.remove(RUNNING_TEST_FILE)
    except:
        pass

# Generated at 2022-06-11 08:11:38.685474
# Unit test for function main
def test_main():

    # Test inner function runme
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import get_sysv_script
    from ansible.module_utils.service import sysv_exists
    module = AnsibleModule(argument_spec={})
    name = 'iptables'
    script = get_sysv_script(name)
    fail_if_missing(module, sysv_exists(name), name)
    action = 'start'
    opts = None
    cmd = "%s %s %s" % (script, action, "" if opts is None else opts)

    # Test inner function runme
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import get_sysv_script

# Generated at 2022-06-11 08:11:48.195507
# Unit test for function main
def test_main():
    """
    Check if the ansible module sysvinit is called correctly
    """
    from ansible.modules.system.sysvinit import main

    runlevel_status = {}
    location = {}
    location['update-rc.d'] = True
    location['chkconfig'] = True

    data = dict(
        name='apache2',
        state= 'started',
        enabled=True,
        runlevels=['1','2','3','4','5'],
        sleep= 1,
        pattern= None,
        arguments= True,
        daemonize= False,
    )

    assert(main(data, is_started=True, runlevel_status=runlevel_status, location=location))
    assert(main(data, is_started=False, runlevel_status=runlevel_status, location=location))


# Generated at 2022-06-11 08:11:53.418012
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.run_command = Mock(return_value=(-1, '', ''))
    module

# Generated at 2022-06-11 08:12:04.600731
# Unit test for function main
def test_main():
    module = AnsibleModule(
            argument_spec=dict(
                name=dict(required=True, type='str', aliases=['service']),
                state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
                enabled=dict(type='bool'),
                sleep=dict(type='int', default=1),
                pattern=dict(type='str'),
                arguments=dict(type='str', aliases=['args']),
                runlevels=dict(type='list', elements='str'),
                daemonize=dict(type='bool', default=False),
            ),
            supports_check_mode=True,
            required_one_of=[['state', 'enabled']],
        )

    assert True

# Generated at 2022-06-11 08:12:15.361121
# Unit test for function main
def test_main():
    args = {
            "name": "sshd",
            "state": None,
            "enabled": True,
            "sleep": 1,
            "pattern": None,
            "arguments": None,
            "runlevels": None,
            "daemonize": False,
    }
    args_good = args.copy()

    args_bad = args.copy()
    args_bad["name"] = "foobar"
    def test_args(args):
        script = get_sysv_script(args['name'])
        old_rc = args['rc']
        if script:
            args['rc'] = 0
            old_stdout = args['stdout']
            args['stdout'] = ""
            old_stderr = args['stderr']
            args['stderr'] = ""
            main()

# Generated at 2022-06-11 08:12:26.543382
# Unit test for function main
def test_main():
    test_args = { 'name': 'test1',
                  'state': 'started',
                  'enabled': True,
                  'sleep': 1,
                  'pattern': '',
                  'arguments': '',
                  'runlevels': [],
                  'daemonize': False,
                }
    test_ansible_module = AnsibleModule(test_args, supports_check_mode=True)
    test_bin_paths = ['/sbin', '/usr/sbin', '/bin', '/usr/bin']
    test_binaries = ['chkconfig', 'update-rc.d', 'insserv', 'service']
    test_location = {}

# Generated at 2022-06-11 08:12:34.989815
# Unit test for function main
def test_main():
    # Assumed to be called from within test/ directory, see AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={
        'foo': {'type': 'str', 'default': 'bar'},
        'bar': {'type': 'int'},
        'baz': {'type': 'bool'},
        'car': {'type': 'list'},
        'cdr': {'type': 'dict'},
    })
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:42.138463
# Unit test for function main
def test_main():
    import inspect
    import sys
    import time
    import socket
    import threading
    import os
    import psutil
    import tempfile
    import subprocess
    #if os.path.exists('/etc/init.d/atd'):
    #    import unittest
    #    from ansible.module_utils.basic import AnsibleModule
    #    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize
    #
    #    class TestDaemonize(unittest.TestCase):
    #        def setUp(self):
    #            self.hostname = socket.gethostname()
    #            self.sysvinit_file = get_sysv_script('atd')

# Generated at 2022-06-11 08:14:27.769304
# Unit test for function main
def test_main():
    args = {
        'name': 'apache2',
        'enabled': False,
        'runlevels': '3',
    }


# Generated at 2022-06-11 08:14:31.719581
# Unit test for function main
def test_main():
    module = ansible_module_create()
    module.params = {'name': 'ntpd', 'state': 'started', 'enabled': True}
    main()
    module.exit_json(changed=True, results="foo")
# Make it happen!
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:42.680513
# Unit test for function main
def test_main():
    import os
    from tests.unit.compat import unittest
    import ansible.module_utils.basic as basic
    from ansible.module_utils.service import sysv_exists, get_sysv_script, sysv_is_enabled, fail_if_missing

    class UnitMain(unittest.TestCase):
        def setUp(self):
            global main
            self.tempdir = "/var/tmp/%s" % __file__
            if os.path.exists(self.tempdir):
                import shutil
                shutil.rmtree(self.tempdir)
            os.makedirs(self.tempdir)
            self.fh, self.fn = basic.mkstemp_safe(dir=self.tempdir)
            self.fhi, self.fni = basic.mkstem

# Generated at 2022-06-11 08:14:53.469394
# Unit test for function main
def test_main():
    # import module snippets
    from ansible.module_utils.basic import get_exception

    # made up results for testing
    results = {
        "attempts": 1,
        "changed": True,
        "name": "apache2",
        "status": {
            "enabled": {
                "changed": True,
                "rc": 0,
                "stderr": "",
                "stdout": ""
            },
            "stopped": {
                "changed": True,
                "rc": 0,
                "stderr": "",
                "stdout": "Stopping web server: apache2.\n"
            }
        }
    }

    # place for mocks to go

# Generated at 2022-06-11 08:15:00.389187
# Unit test for function main
def test_main():
    module = AnsibleModule(
            argument_spec=dict(
                name=dict(required=True, type='str'),
                enabled=dict(type='bool'),
                runlevels=dict(type='list', elements='str'),
                daemonize=dict(type='bool', default=False),
            ),
            required_one_of=[['state', 'enabled']],
        )
    main()

# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:15:13.454494
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.exit_json = lambda **kwargs: kwargs

# Generated at 2022-06-11 08:15:15.003225
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:15:18.084722
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        main()

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.service import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:15:28.555301
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import os
    import math

    tmpdir = tempfile.mkdtemp()
    tmpdir2 = tempfile.mkdtemp()
    tmpdir3 = tempfile.mkdtemp()
    tmpdir4 = tempfile.mkdtemp()
    tmpdir5 = tempfile.mkdtemp()
    tmpdir6 = tempfile.mkdtemp()
    tmpdir7 = tempfile.mkdtemp()

    tmpfile1 = tempfile.NamedTemporaryFile(dir=tmpdir)
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir)
    tmpfile3 = tempfile.NamedTemporaryFile(dir=tmpdir)
    tmpfile4 = tempfile.NamedTemporaryFile(dir=tmpdir2)
    tmpfile5 = tempfile.Named

# Generated at 2022-06-11 08:15:39.104370
# Unit test for function main