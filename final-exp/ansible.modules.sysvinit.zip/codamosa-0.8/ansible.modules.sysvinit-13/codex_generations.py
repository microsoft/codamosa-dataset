

# Generated at 2022-06-11 08:08:40.974732
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    ###########################################################################
    # BEGIN: Enable/Disable

# Generated at 2022-06-11 08:08:53.516246
# Unit test for function main
def test_main():
  module = AnsibleModule(
      argument_spec=dict(
          name=dict(required=True, type='str', aliases=['service']),
          state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
          enabled=dict(type='bool'),
          sleep=dict(type='int', default=1),
          pattern=dict(type='str'),
          arguments=dict(type='str', aliases=['args']),
          runlevels=dict(type='list', elements='str'),
          daemonize=dict(type='bool', default=False),
      ),
      required_one_of=[['state', 'enabled']],
  )
  setattr(module, 'run_command', lambda *args, **kwargs: (0, '', ''))

# Generated at 2022-06-11 08:09:05.307986
# Unit test for function main
def test_main():
    this_module = get_module_path()
    _loaded_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    _loaded_module.autom

# Generated at 2022-06-11 08:09:09.672324
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            test_var=dict(required=True, type='int'),
        ),
        supports_check_mode=True,
    )
    assert module.params['test_var'] == 3

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:09:21.290801
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes

    # AnsibleModule

# Generated at 2022-06-11 08:09:29.276814
# Unit test for function main
def test_main():

    import subprocess
    import sys
    import traceback
    import __builtin__

    def fake_open_module(self):
        return """
#!/usr/bin/python

from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

"""
    def fake_fail_json(self, **kwargs):
        self.result = kwargs
        self.sys.exit(1)
    def fake_run_command(self, cmd):
        return (0,'','Test.stdout')
    def fake_get_ps(module,pattern):
        return True
    def fake_is_systemd(self):
        return False
    def fake_get_bin_path(self, program, *args, **kwargs):
        return None

# Generated at 2022-06-11 08:09:40.492229
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:09:52.608739
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile

    # Create dummy service file
    service_path = tempfile.mkdtemp()
    service_file = os.path.join(service_path, "test_service")
    with open(service_file,"wb") as f:
        f.write(b"#!/bin/sh\necho Starting test service")

    # Create dummy module and set module args

# Generated at 2022-06-11 08:10:04.899964
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.get_bin_path = lambda x, y: '/usr/bin/fake' 


# Generated at 2022-06-11 08:10:15.442247
# Unit test for function main
def test_main():

    # Set up parameters
    params = {}
    params['name'] = 'httpd'
    params['state'] = 'started'
    params['enabled'] = True
    params['sleep'] = 1
    params['pattern'] = None
    params['arguments'] = None
    params['runlevels'] = ['3', '5']
    params['daemonize'] = False

    # Set up mocks for AnsibleModule
    module = MagicMock()
    module.params = params
    module.check_mode.return_value = True
    module.get_bin_path.return_value = '/usr/bin/chkconfig'
    module.run_command.return_value = (1, "stdout", "stderr")
    sysvinit, termination

    # Run function
    main()

    # Verify results

# Generated at 2022-06-11 08:11:14.085795
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    import ansible.utils.template as template
    # This sets the module args from the arguments spec.

# Generated at 2022-06-11 08:11:25.764044
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-11 08:11:35.623615
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-11 08:11:47.339242
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(name=dict(required=True, type='str'),
                                              state=dict(choices=['started', 'stopped', 'restarted', 'reloaded', None], default=None),
                                              enabled=dict(type='bool', default=None),
                                              sleep=dict(type='int', default=1),
                                              pattern=dict(type='str', default=None),
                                              arguments=dict(type='str', aliases=['args'], default=None),
                                              runlevels=dict(type='list', elements='str', default=None),
                                              daemonize=dict(type='bool', default=False)),
                             supports_check_mode=True,
                             required_one_of=[['state', 'enabled']])

# Generated at 2022-06-11 08:11:59.027914
# Unit test for function main
def test_main():
    test = '''
- name: Make sure apache2 is started
  sysvinit:
      name: apache2
      state: started
      enabled: yes

- name: Make sure apache2 is started on runlevels 3 and 5
  sysvinit:
      name: apache2
      state: started
      enabled: yes
      runlevels:
        - 3
        - 5
'''
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils._text import to_bytes

# Generated at 2022-06-11 08:12:10.577865
# Unit test for function main
def test_main():
    args = dict(
        name="bogus",
        enabled=False,
        daemonize=False,
    )


# Generated at 2022-06-11 08:12:18.828515
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:12:30.194196
# Unit test for function main
def test_main():
    import json
    json_arg = dict(
        name = "httpd",
        state = "restarted",
        enabled = True,
        sleep = 5,
        pattern = "(?i)httpd",
        arguments = "",
        runlevels = None,
        daemonize = False,
    )
    json_arg = json.dumps(json_arg)
    class AnsibleModuleMock(object):
        def __init__(self, *args, **kwargs):
            self.params = json.loads(json_arg)
        def run_command(self, cmd):
            rc = 0
            out = "httpd dead but subsytem is locked"
            err = None
            return rc, out, err
        def warn(self, *args, **kwargs):
            pass

# Generated at 2022-06-11 08:12:40.026483
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:12:51.115972
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:14:35.412586
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-11 08:14:46.932054
# Unit test for function main
def test_main():
    name = 'foobar'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-11 08:14:50.071104
# Unit test for function main
def test_main():
    result = {}
    with patch.object(ansible_module, 'run_command') as r_cmd1:
        result = main()
    assert result['name'] == 'httpd'


# Generated at 2022-06-11 08:14:51.032631
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:58.529682
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.run_command = MagicMock(return_value=(0,'',''))
    module

# Generated at 2022-06-11 08:15:11.124384
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # mock the module with the mocks

# Generated at 2022-06-11 08:15:13.279660
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:15:20.666221
# Unit test for function main
def test_main():
    # make sure we run a test on a version of Ansible without this module
    if not os.path.exists("/etc/rc.d/snmpd"):
        module.exit_json(skipped=True)

    module = AnsibleModule({
        'name': 'snmpd',
        'state': 'started',
        'enabled': True,
        'runlevels': [2, 3, 5],
        'pattern': '',
        'sleep': 1,
    })

    result = main()

    # make sure our test actually ran
    if 'attempts' in result:
        assert result['attempts'] == 1

    if 'changed' in result:
        assert result['changed'] == True

    if 'status' in result:
        assert result['status']['started']['changed'] == True
       

# Generated at 2022-06-11 08:15:31.898283
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec={
            'name': dict(required=True, type='str'),
            'state': dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            'enabled': dict(type='bool'),
            'sleep': dict(type='int', default=1),
            'pattern': dict(type='str'),
            'arguments': dict(type='str', aliases=['args']),
            'runlevels': dict(type='list', elements='str'),
            'daemonize': dict(type='bool', default=False),
        },
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:15:41.208836
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # Mock getbinpath