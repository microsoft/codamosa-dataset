

# Generated at 2022-06-11 08:08:40.858292
# Unit test for function main
def test_main():
    import sys
    import tempfile
    import shutil
    import os
    import subprocess
    my_env = os.environ.copy()
    my_env["LC_ALL"] = "C"
    from ansible.module_utils.basic import AnsibleModule


    sys.path.append('/usr/local/lib/python3.4/dist-packages/ansible/module_utils')

    name='test_service'
    state='started'
    enabled=True
    result = {
        'changed': False,
        'status': {}
    }

    # Stub make files
    init_dir_path=tempfile.mkdtemp()
    init_dir_abs=os.path.join(os.getcwd(), init_dir_path)

# Generated at 2022-06-11 08:08:53.341965
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()
    module.exit_json(**result)


# Generated at 2022-06-11 08:09:05.143093
# Unit test for function main
def test_main():
    recout = [
        r"^(?!(Ansiball)).*",
        r"^msg:.*",
        r"^stdout:.*",
        r"^stderr:.*",
        r"^rc:.*",
        r"^changed:.*"
    ]

# Generated at 2022-06-11 08:09:13.937579
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True, type='str', aliases=['service']),
            state = dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled = dict(type='bool'),
            sleep = dict(type='int', default=1),
            pattern = dict(type='str'),
            arguments = dict(type='str', aliases=['args']),
            runlevels = dict(type='list', elements='str'),
            daemonize = dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    results = main()
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:09:18.500481
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    if not basic.HAS_ANSIBLE_TESTLIB:
        raise SkipTest("ansible-testlib package is required")
    # TODO
    # fails becuase of imports
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:09:27.838152
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:09:39.080128
# Unit test for function main
def test_main():
    # Test 1
    sysvinit_instance = sysvinit_init(
        module_params={"name": "foo",
                       "state": "started",
                       "enabled": True,
                       "sleep": 1,
                       "pattern": "",
                       "arguments": "",
                       "runlevels": [],
                       "daemonize": False})
    # Test 2
    sysvinit_instance = sysvinit_init(
        module_params={"name": "foo",
                       "state": "stopped",
                       "enabled": True,
                       "sleep": 1,
                       "pattern": "",
                       "arguments": "",
                       "runlevels": [],
                       "daemonize": False})
    # Test 3

# Generated at 2022-06-11 08:09:51.339876
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    print(main())


################################################################

# Generated at 2022-06-11 08:10:03.617255
# Unit test for function main
def test_main():
    # Import dependencies
    import json

    # Unit test spec

# Generated at 2022-06-11 08:10:10.360690
# Unit test for function main
def test_main():
    mod = sys.modules['__main__']
    module = AnsibleModule(argument_spec=dict(name=dict(required=True, type='str', aliases=['service']), state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'), enabled=dict(type='bool'), sleep=dict(type='int', default=1), pattern=dict(type='str'), arguments=dict(type='str', aliases=['args']), runlevels=dict(type='list', elements='str'), daemonize=dict(type='bool', default=False),), supports_check_mode=True, required_one_of=[['state', 'enabled']])

# Generated at 2022-06-11 08:11:07.568313
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:18.862427
# Unit test for function main
def test_main():
    # noinspection PyUnresolvedReferences
    import pytest
    # import module snippets
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_exists, sysv_is_enabled, get_sysv_script
    from ansible.module_utils.service import fail_if_missing, get_ps, daemonize
    from sysvinit_service import main

    # AnsibleModule args and kwargs

# Generated at 2022-06-11 08:11:30.174383
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']

    # ensure service exists, get script name
    fail_

# Generated at 2022-06-11 08:11:39.274330
# Unit test for function main
def test_main():
    from ansible.module_utils.common._json_compat import json
    from ansible.module_utils.common.collections import ImmutableDict
    import ansible.module_utils.common.ansible_module_common as amc


# Generated at 2022-06-11 08:11:48.568149
# Unit test for function main
def test_main():
    import sys
    import io
    import os
    import tempfile
    tmpdir = tempfile.gettempdir()
    # Build up a text file that the rc file will read.
    file1 = os.path.join(tmpdir, 'file1.txt')
    file2 = os.path.join(tmpdir, 'file2.txt')

# Generated at 2022-06-11 08:12:00.055176
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.params = {'name': 'foobar', 'state': None, 'enabled': True, 'runlevels': ['3', '5']}
    main()


# Generated at 2022-06-11 08:12:11.714662
# Unit test for function main
def test_main():

    class Module(object):

        run_command_calls = 0

        def __init__(self, params):
            self.params = params

        def fail_json(self, **kwargs):
            raise AssertionError('AnsibleModule.fail_json() should not have been called')

        def run_command(self, cmd):
            self.run_command_calls += 1
            sys.stdout.write('%s\n' % cmd)

            if self.params['name'] == 'apache2':
                if cmd.startswith('/etc/init.d/apache2 status'):
                    return (0, "apache2 is running", "")
                if cmd.startswith('/etc/init.d/apache2 stop'):
                    return (0, "Stopping web server: apache2.", "")


# Generated at 2022-06-11 08:12:19.310957
# Unit test for function main
def test_main():
    # Mock class for AnsibleModule
    class AnsibleModuleMock(object):

        def __init__(self, params):
            self.params = params

        def run_command(self, cmd):
            return (0, 'stdout', 'stderr')

        def get_bin_path(self, cmd, opt_dirs=None):
            return '/bin/' + cmd

        def fail_json(self, **kwargs):
            raise AssertionError(kwargs)

        def exit_json(self, **kwargs):
            raise AssertionError(kwargs)

    # Mock class for AnsibleModule
    class AnsibleModuleMock2(object):

        def __init__(self, params):
            self.params = params


# Generated at 2022-06-11 08:12:24.064631
# Unit test for function main
def test_main():
    # create the module instance
    module = sys.modules['__main__']
    module.params = {'name': 'httpd'}
    main()
    # assert that the expected results were obtained
    assert module.exit_json.__class__.__name__ == 'function'

# Generated at 2022-06-11 08:12:35.446039
# Unit test for function main
def test_main():

    # Case 1 - Simple enabled check
    from ansible.modules.system.service import ActionModule
    from ansible.module_utils.basic import AnsibleModule
    import subprocess
    import sys
    import ansible.module_utils

# Generated at 2022-06-11 08:14:22.170427
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:31.500331
# Unit test for function main
def test_main():
    """If running unit tests, perform a basic test."""
    global module
    module = type('module', (object,), {'exit_json':print, 'fail_json':exit}) # simple mockup
    module.params = {'name': 'example', 'enabled': None, 'state': None, 'pattern': 'example', 'sleep': None, 'arguments': None, 'daemonize': None, 'runlevels': None}
    module.get_bin_path = lambda name, default: default
    module.run_command = lambda command: (0, '', '')
    main()

# Execute if not a test
if __name__ != '__main__':
    main()

# Generated at 2022-06-11 08:14:32.779043
# Unit test for function main
def test_main():
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:43.960218
# Unit test for function main
def test_main():
    import sys
    import __builtin__


    # Enable debugging
    debug = False

    # Mock module
    class AnsibleModule(object):
        def __init__(self, *args, **kwargs):
            sys.exit(1)
        def fail_json(self, *args, **kwargs):
            sys.exit(1)
        def exit_json(self, *args, **kwargs):
            sys.exit(0)
        def get_bin_path(bin, *args, **kwargs):
            return '/bin/' + bin


# Generated at 2022-06-11 08:14:54.487540
# Unit test for function main
def test_main():
    #
    # expected results
    results = dict(
        changed=True,
        result='foo bar',
    )

    #
    # the test function
    def test_function(module):
        module.exit_json(**results)

    #
    # the tests
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Override methods in the specific type of manager
    mock_module = type('module', (object,), dict(
        params=dict(),
        check_mode=False,
        exit_json=test_function,
        fail_json=test_function,
        run_command=test_function
    ))

    # Override methods in the specific type of return value
    mock_module.run_command = test_function

    # Run it

# Generated at 2022-06-11 08:15:05.328611
# Unit test for function main
def test_main():
    name = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    )).params['name']


# Generated at 2022-06-11 08:15:11.735226
# Unit test for function main
def test_main():
    test_module_args = dict(state='', name='', enabled='', runlevels='', sleep='', pattern='', arguments='', daemonize='')
    test_module = AnsibleModule(argument_spec=test_module_args, supports_check_mode=True)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:15:20.211608
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name = dict(type='str'),
            state = dict(type='str'),
            enabled = dict(type='bool'),
            sleep = dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments = dict(type='str', aliases = ['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False)
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']]
    )
    # mock the module calls

# Generated at 2022-06-11 08:15:31.397673
# Unit test for function main
def test_main():
    in_args = dict(
        state='started',
        daemonize=True
        )
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str'),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ),
    supports_check_mode=True,
    required_one_of=[['state', 'enabled']])
    module.params = in_args
   

# Generated at 2022-06-11 08:15:40.855554
# Unit test for function main
def test_main():
    # mock basic os module for testing
    import __builtin__
    class mock_os_module():
        class path(object):
            @staticmethod
            def realpath(path):
                return '/usr/bin/service'
    class mock_module_object():
        class basic(object):
            AnsibleModule = mock_AnsibleModule
        class service(object):
            sysv_is_enabled = mock_sysv_is_enabled
            get_sysv_script = mock_get_sysv_script
            sysv_exists = mock_sysv_exists
        class action_common_attributes(object):
            # empty class
            pass

    mod = mock_module_object
    mod.basic.AnsibleModule = mock_AnsibleModule
    mod.service.sysv_exists = mock_sys