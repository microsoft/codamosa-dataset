

# Generated at 2022-06-11 08:08:42.631033
# Unit test for function main
def test_main():

    import sys

    # The mock module provides a core Mock class removing the need to create a host of stubs
    # throughout our test suite.
    # Mocking out modules or classes that we will be using through our test suite is fairly
    # straightforward.
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.six import b
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.sysvinit import sysv_is_enabled
    from ansible.module_utils.sysvinit import sysv_exists
    from ansible.module_utils.sysvinit import get_sysv_script


# Generated at 2022-06-11 08:08:46.089204
# Unit test for function main

# Generated at 2022-06-11 08:08:58.868455
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    # the function we are testing
    from ansible.modules.extras.system.sysvinit import main


# Generated at 2022-06-11 08:09:09.891564
# Unit test for function main
def test_main():
    import os
    import json
    import sys

    test_out = os.path.join(os.path.dirname(__file__), 'unit')
    sys.path.append(test_out)

    m_path = os.path.join(test_out, 'ansible_sysvinit_module_mock.py')

    from ansible_sysvinit_module_mock import AnsibleModule
    from ansible_sysvinit_module_mock import ModuleTestFunction

    test_dir = os.path.dirname(__file__)

    with open(os.path.join(test_dir, 'unit/ansible_sysvinit_module_mock.json'), 'r') as data_file:
        test_data = json.load(data_file)


# Generated at 2022-06-11 08:09:21.291487
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # Create a dummy module class

# Generated at 2022-06-11 08:09:29.276645
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO

    # restore stdout/stderr for later interactive debugging
    saved_stdout = sys.stdout
    saved_stderr = sys.stderr

    # capture the stdout/stderr on an in-memory buffer
    sys.stdout = StringIO()
    sys.stderr = StringIO()

    # create a fake ansible module that invokes the service module

# Generated at 2022-06-11 08:09:40.491158
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:09:52.607893
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps
    import pytest
    import os
    import re
    import ansible.module_utils.basic

    #print(dir(ansible.module_utils.basic))
    name = "apache2"
    action = "stopped"
    enabled = False
    runlevels = ["3", "5"]
    pattern = ""
    sleep_for = 1
    rc = 0
    out = err = ""
    result = {
        'name': name,
        'changed': False,
        'status': {}
    }

    # ensure service exists, get script name
    #fail_if_missing(module

# Generated at 2022-06-11 08:10:04.900947
# Unit test for function main
def test_main():

    #Creating mock object for module.run_command

    mock_run_command = mock.Mock(return_value=dict(rc=0, stdout='', stderr=''))
    sysvinit.module.run_command = mock_run_command
    #Creating mock object for module.fail_json
    mock_fail_json = mock.Mock(return_value=dict(rc=0, msg='mock fail_json'))
    sysvinit.module.fail_json = mock_fail_json
    #Creating mock object for module.exit_json
    mock_exit_json = mock.Mock(return_value=dict(rc=0, msg='mock exit_json'))
    sysvinit.module.exit_json = mock_exit_json
    #Creating mock object for module.get_bin_path
   

# Generated at 2022-06-11 08:10:15.491474
# Unit test for function main
def test_main():
    from sys import version_info
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.plugins.modules.system import sysvinit

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        raise AnsibleFailJson(kwargs)

    if version_info[:2] not in ((2, 7), (3, 5)):
        sysvinit.AnsibleExitJson = AnsibleExitJson


# Generated at 2022-06-11 08:11:06.111961
# Unit test for function main
def test_main():
    main()

# import module snippets
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:17.191693
# Unit test for function main
def test_main():
    '''Unit test for function main'''
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()


# Generated at 2022-06-11 08:11:28.856223
# Unit test for function main
def test_main():
    # this is called by unit tests
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-11 08:11:31.376683
# Unit test for function main
def test_main():
    ret = main()
    assert ret
    assert 'running' in ret['status']['started']['stdout']

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:40.065203
# Unit test for function main
def test_main():
    sysvinit_data = '''
    "attempts": 1,
    "changed": true,
    "name": "apache2",
    "status": {
        "enabled": {
            "changed": true,
            "rc": 0,
            "stderr": "",
            "stdout": ""
        },
        "stopped": {
            "changed": true,
            "rc": 0,
            "stderr": "",
            "stdout": "Stopping web server: apache2.\n"
        }
    }
    '''
    print("Testing main()")
    print("-", sysvinit_data)
    p = re.compile(r'^\s+')
    # print("-", p.sub("", sysvinit_data))

# Generated at 2022-06-11 08:11:48.878481
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.service import sysv_is_enabled
    from ansible.module_utils import action_common_attributes
    setattr(action_common_attributes, 'SYSTEM_BIN_PATH', '/usr/bin')
    setattr(basic.AnsibleModule, 'run_command', lambda self, x: (0, "", ""))
    setattr(sysv_is_enabled, 'get_sysv_script', lambda x: None)
    setattr(sysv_is_enabled, 'sysv_exists', lambda x: True)
    setattr(get_ps, 'find_bin', lambda x, paths: None)
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:00.368630
# Unit test for function main
def test_main():
    from sys import version_info
    if version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    module = AnsibleModule(argument_spec={})
    modargs = dict(name="test", daemonize=False)

    def run_command(args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        return_value = (0, "", "")
        if type(args) is not list:
            args = shlex.split(args)
        command = args[0]
        args = args[1:]
        # capture output
        stdout = StringIO()
        stderr = StringIO()
        sys.stdout = stdout
        sys.stderr = stderr

        #

# Generated at 2022-06-11 08:12:12.036173
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'name': 'apach2',
        'state': 'stopped',
        'enabled': 'yes',
        'sleep': 1,
        'pattern': 'apache2',
        'arguments': '',
        'runlevels': '3,5',
        'daemonize': False,
    })

# Generated at 2022-06-11 08:12:19.431431
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.six import PY2
    from sys import version_info

    if version_info[0] < 3:
        assert False, "pytest is not supported on python 2"

    with pytest.raises(SystemExit):
        main()

    ###########################################################################

    def mock_exists(name):
        return True

    def mock_is_enabled(name):
        return True

    def mock_get_script(name):
        return "/mock/script"

    def mock_run_command(name):
        return 0, '', ''

    def mock_get_bin_path(name, opt_dirs=[]):
        return '/mock/bin/%s' % name

    def mock_fail_if_missing(module, status, name):
        pass

# Generated at 2022-06-11 08:12:23.791681
# Unit test for function main
def test_main():
    # get command line arguments
    # import sys
    # sys.argv = [ 'ansible-sysvinit.py' ]
    main()

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:23.418695
# Unit test for function main
def test_main():
    """ validate module argument parsing """
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:33.533121
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
    )
    class mock: # pylint: disable=too-few-public-methods
        """ Mock class """

# Generated at 2022-06-11 08:14:36.644053
# Unit test for function main
def test_main():
    # TODO: write tests
    pass

# Import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:39.211171
# Unit test for function main
def test_main():
    pass


# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:50.307414
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:58.003169
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:15:10.499682
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    location = {
        'service': '/usr/sbin/service'
    }

# Generated at 2022-06-11 08:15:19.839599
# Unit test for function main
def test_main():

    test = []
    test.append(({ 'name': 'sshd', 'state': 'started', 'enabled': 'yes' }, { 'changed': True }))
    test.append(({ 'name': 'sshd', 'state': 'stopped', 'enabled': 'no' }, { 'changed': True }))
    test.append(({ 'name': 'sshd', 'state': 'started', 'enabled': 'yes' }, { 'changed': True }))
    test.append(({ 'name': 'sshd', 'state': 'stopped', 'enabled': 'no' }, { 'changed': False }))
    test.append(({ 'name': 'sshd', 'state': 'stopped', 'enabled': 'no' }, { 'changed': True }))

# Generated at 2022-06-11 08:15:22.937479
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    result = main()
    module.exit_json(**result)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:15:27.915480
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    # pass in an empty module and check for changed/failures
    module = AnsibleModule(argument_spec={})
    changed, results = main(module)
    assert(changed)
    assert(results['failed'])

if __name__ == '__main__':
    main()