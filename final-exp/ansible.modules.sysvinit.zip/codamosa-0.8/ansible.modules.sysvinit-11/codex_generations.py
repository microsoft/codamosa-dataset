

# Generated at 2022-06-11 08:08:46.750793
# Unit test for function main
def test_main():
    # Unit tests  are required because the general case is non-deterministic
    # due to the use of ps -ef to determine service status.
    os = __import__('os')

# Generated at 2022-06-11 08:08:59.583544
# Unit test for function main
def test_main():
    test_args = dict(
        name='test_service',
        state='started',
        enabled=True,
        runlevels=[3, 5],
        daemonize=False,
        sleep=1
    )

# Generated at 2022-06-11 08:09:10.441292
# Unit test for function main
def test_main():
    import os
    os.environ["PATH"] = "/bin:/sbin:/usr/sbin:/usr/bin:/usr/local/bin:/usr/local/sbin"
    # These tests only work on linux, so skip them on other platforms
    import platform
    if platform.system() != 'Linux':
        print("Unable to test Linux only module")
        return
    # For testing purposes, we set the environment variable INIT_SYSVINIT_PATH
    # to the path of the init scripts to test.
    if "INIT_SYSVINIT_PATH" not in os.environ:
        print("Cannot test without init scripts initialized in environment variable INIT_SYSVINIT_PATH")
        return
    # Create a simple init script in a temp directory
    from tempfile import mkdtemp

# Generated at 2022-06-11 08:09:11.733168
# Unit test for function main
def test_main():
    return

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:09:23.218558
# Unit test for function main
def test_main():
    # basic import of module, no params
    m = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    # verify imports
    assert(m.run_command is not None)

    with pytest.raises(SystemExit):
        m.fail_json(msg='foo')

    # very basic sample returns
    m.exit_json(foo='foo', changed=True)
    m.exit_json(foo='foo', changed=False)
    m.exit_json(foo='foo', ansible_facts={})
    m.exit_json(foo='foo', changed=True, ansible_facts={})
    m.exit_json(foo='foo', changed=False, ansible_facts={})
    m.fail_json(msg='foo')

    # quick check of get_bin_path


# Generated at 2022-06-11 08:09:33.580773
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, get_ps
    import tempfile
    import shutil
    import os
    import sys

    script = "/tmp/test/test-service"
    lsb = "/tmp/test/test.lsb"
    initdir = "/tmp/test/initdir"
    updir = "/tmp/test/updir"
    downpath = "%s/K-01test-service" % updir
    uppath = "%s/S-01test-service" % updir
    is_started = False
    args = 'arg1 arg2'


# Generated at 2022-06-11 08:09:44.813095
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    basic._ANSIBLE_ARGS = to_bytes(u'{"ANSIBLE_HOST_KEY_CHECKING": "False", "action": "sysvinit", "ANSIBLE_LIBRARY": "/usr/share/ansible", "ANSIBLE_MODULE_ARGS": {"state": "started", "name": "httpd"}, "ANSIBLE_REMOTE_USER": "root", "ansible_verbose_always": true, "ANSIBLE_DEBUG": true, "ANSIBLE_SSH_ARGS": "", "env": {}, "ANSIBLE_HOST_KEY_CHECKING": "False", "become": true, "ANSIBLE_ROLES_PATH": null}')
    basic._ANSIBLE_CONNECTION = True
   

# Generated at 2022-06-11 08:09:55.636034
# Unit test for function main
def test_main():
  test_argv = ['ansible-test', '--diff', '--check', '-v', '-vv', '-vvv', '-vvvv', '-vvvvv', '-vvvvvv', '-m', 'sysvinit', '--syslog', '--timeout=2', '-a', '{"name": "ansible", "version": 20200504, "platform": "posix"}', '--tags', '--skip-tags', '--force-handlers', '--start-at-task', '--step', '--start-at-task']
  with testtools.capture_stdout_stderr(stdout=True, stderr=True) as out:
    main()
  test_stdout, test_stderr = out

# Generated at 2022-06-11 08:10:01.271588
# Unit test for function main
def test_main():
  module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str',default='started'),
            enabled=dict(type='bool',default=True),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        )
  )
  main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:10:09.298053
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True, type='str', aliases=['service']),
            state = dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled = dict(type='bool'),
            sleep = dict(type='int', default=1),
            pattern = dict(type='str'),
            arguments = dict(type='str', aliases=['args']),
            runlevels = dict(type='list', elements='str'),
            daemonize = dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
    )

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:07.787884
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.modules.system.sysvinit import main

    # prepar input data
    sys.argv[1:] = ["name=cron","state=started","enabled=yes","runlevels=3","daemonize=False"]
    # prepar module obj

# Generated at 2022-06-11 08:11:19.087266
# Unit test for function main
def test_main():
    import ansible
    import json
    import os
    import pytest
    import subprocess
    import sys
    import stat
    import shutil
    import platform
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    if PY3:
        from ansible.module_utils.six.moves import StringIO
    else:
        from StringIO import StringIO

    # This creates a fake file in memory
    # with the contents that would be
    # in a normal file.
    class FakeModule:
        def __init__(self, name):
            self.name = name

        def exit_json(self, **kwargs):
            self.result = kwargs

        def fail_json(self, **kwargs):
            self.result = kw

# Generated at 2022-06-11 08:11:23.625006
# Unit test for function main
def test_main():
    # input parameters
    module_args = dict(
  name='apache2',
  state='started',
  enabled=True
    )

    # expected result
    results = dict(
        changed=False,
        msg=''
    )

import pprint
import collections


# Generated at 2022-06-11 08:11:34.071012
# Unit test for function main
def test_main():
    # Create an instance of the AnsibleModule class
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']])
    #What happens when the user calls this module locally and passes in a

# Generated at 2022-06-11 08:11:45.668903
# Unit test for function main
def test_main():
    mock_module = type('', (), dict(run_command=magic))
    mock_module.fail_json = magic
    mock_module.warn = magic
    mock_module.debug = magic
    mock_module.exit_json = magic
    mock_module.get_bin_path = lambda x: '/bin'
    mock_module.params = {
        "name": "httpd",
        "state": "started",
        "daemonize": False,
        "enabled": True,
        "runlevels": [
            2,
            3
        ],
        "sleep": 1,
        "pattern": "",
        "arguments": "",
    }
    mock_run_command = MagicMock(return_value=(0, "", ""))
    mock_module.run_command = mock_run_command

    main

# Generated at 2022-06-11 08:11:56.795678
# Unit test for function main
def test_main():
    test_name = 'foo'
    test_full_path = '/etc/init.d/foo'
    test_rc = 0
    test_stdout = 'foo'
    test_stderr = 'bar'

# Generated at 2022-06-11 08:11:58.377244
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:00.911015
# Unit test for function main
def test_main():
    res = main()
    print(res)
    assert 'name' in res

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 08:12:12.490481
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    if __name__ == '__main__':
        main()


# Generated at 2022-06-11 08:12:23.001673
# Unit test for function main

# Generated at 2022-06-11 08:14:09.333408
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:19.914415
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_exists, sysv_is_enabled

    # test_args is a "fake" module argument list which we use to generate a
    # module object that Ansible can play with.
    test_args = [
        'name',
        'state',
        'enabled'
    ]

    test_params = {
        'name': 'apache2',
        'state': 'started',
        'enabled': True
    }


# Generated at 2022-06-11 08:14:30.314585
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-11 08:14:33.773351
# Unit test for function main
def test_main():
# Call function main with test_args and test_kwargs.
    test_args = ("test","test","test")
    test_kwargs = {"test":"test"}
    test_result = main(*test_args, **test_kwargs)
    assert test_result == None