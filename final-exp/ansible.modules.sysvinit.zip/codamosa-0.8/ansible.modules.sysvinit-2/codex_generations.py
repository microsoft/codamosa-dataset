

# Generated at 2022-06-11 08:08:42.177531
# Unit test for function main

# Generated at 2022-06-11 08:08:43.842995
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:08:56.580276
# Unit test for function main
def test_main():
    name = "test"
    state = "test"
    enabled = True
    sleep = 1
    pattern = "test"
    arguments = "test"
    runlevels = ["test"]
    daemonize = False
    out = "test"
    err = "test"
    rc = 0
    action = "test"
    is_started = False
    worked = False
    paths = ["/sbin", "/usr/sbin", "/bin", "/usr/bin"]
    binaries = ["chkconfig", "update-rc.d", "insserv", "service"]
    runlevel_status = {}
    location = {}
    for binary in binaries:
        location[binary] = "test"
    result = {
        "name": name,
        "changed": False,
        "status": {}
    }

# Generated at 2022-06-11 08:09:08.139484
# Unit test for function main
def test_main():
    from ansible.modules.system.sysvinit import main as sysvinit_main
    from ansible.module_utils.basic import AnsibleModule as ansible_module
    from ansible.module_utils.service import sysv_exists as sysv_exists_func
    from ansible.module_utils.service import get_sysv_script as get_sysv_script_func
    from ansible.module_utils.basic import EnvironmentError as EnvironmentError
    import sys

    # Save the original function reference so we can reset it later
    sysv_exists_original = sysv_exists_func
    get_sysv_script_original = get_sysv_script_func

    # Unit test function wrapper

    def sysv_exists_wrap(name):
        if name == 'test service one':
            return True
       

# Generated at 2022-06-11 08:09:20.636980
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:09:28.939960
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
        'name': { 'required': True, 'type': 'str', 'aliases': ['service'] },
        'state': { 'choices': ['started', 'stopped', 'restarted', 'reloaded'], 'type': 'str' },
        'enabled': { 'type': 'bool' },
        'sleep': { 'type': 'int', 'default': 1 },
        'pattern': { 'type': 'str' },
        'arguments': { 'type': 'str', 'aliases': ['args'] },
        'runlevels': { 'type': 'list', 'elements': 'str' },
        'daemonize': { 'type': 'bool', 'default': False },
    })
    if 'test' in dir(module):
        module.test()

# Generated at 2022-06-11 08:09:40.078309
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # module._debug_messages()

# Generated at 2022-06-11 08:09:52.248603
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils.service import sysv_is_enabled, fail_if_missing, sysv_exists
    # Load the sysvinit module up
    sys.modules["sysvinit"] = basic
    # Set module args
    module_args = dict(
        name="httpd",
        state="running",
        enabled=False,
        sleep=1,
        pattern=None,
        arguments="",
        runlevels=[],
        daemonize=False,
    )
    module = AnsibleModule(argument_spec=module_args)
    module.fail_json = lambda **kwargs: sys.exit(3)
    module.exit_json = lambda **kwargs: sys.exit(0)

# Generated at 2022-06-11 08:09:53.086808
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 08:10:05.499279
# Unit test for function main
def test_main():
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    import ansible.module_utils.service
    ansible.module_utils.service.sysv_is_enabled = lambda x: True
    import sys
    import json
    import mock


# Generated at 2022-06-11 08:11:03.280380
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os

    def get_bin_path(self, arg, opt_dirs=[]):
        return '/usr/bin/' + arg

    def run_command(self, cmd, check_rc=True, close_fds=False, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
        return 0, '', ''

    def fail_json(self, msg):
        raise OSError(msg)

    def debug(self, msg):
        print(msg)

    def warn(self, msg):
        print(msg)

    def exit_json(self, **kwargs):
        print(kwargs)

   

# Generated at 2022-06-11 08:11:14.967041
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils.common.dict_transformations import dict_merge, dict_copy
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils._text import to_bytes

    module_args = dict(
        name="nope",
        state="started",
        enabled="yes",
        sleep=1,
        pattern="dead",
        arguments="",
        runlevels="",
        daemonize="no"
    )

    show_custom_fields = True

    if basic._ANSIBLE_ARGS is None:
        context = {'ANSIBLE_MODULE_ARGS': module_args}

# Generated at 2022-06-11 08:11:18.312499
# Unit test for function main
def test_main():
    import requests

    url = "http://localhost:5000/server/rest/api/v2/projects"
    response = requests.request("GET", url)
    print(response.text)


# Generated at 2022-06-11 08:11:29.786390
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True, type='str', aliases=['service']),
            state = dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled = dict(type='bool'),
            sleep = dict(type='int', default=1),
            pattern = dict(type='str'),
            arguments = dict(type='str', aliases=['args']),
            runlevels = dict(type='list', elements='str'),
            daemonize = dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-11 08:11:38.972826
# Unit test for function main

# Generated at 2022-06-11 08:11:48.381098
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:11:59.862731
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

if __name__ == '__main__':
    main()
# Unit test

# Generated at 2022-06-11 08:12:10.958959
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
            name=dict(required=True, type='str'),
            state=dict(choices=['started', 'stopped', 'restarted'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.exit_json(**main())


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:12.586464
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:23.161815
# Unit test for function main
def test_main():
    test_params = {
        'name': 'httpd',
        'state': 'started',
        'sleep': 1,
        'pattern': '',
        'arguments': '',
        'runlevels': False,
        'daemonize': False,
        'enabled': True,
        'check_mode': False,
    }

    test_result = {
        'name': 'httpd',
        'status': {
            'enabled': {
                'changed': True,
                'stderr': None,
                'stdout': None,
                'rc': None,
            },
            'started': {
                'changed': True,
                'stderr': None,
                'stdout': None,
                'rc': None,
            },
        },
        'changed': True,
    }

    module

# Generated at 2022-06-11 08:14:15.280558
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    print(main())

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:23.960092
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    runlevel_status = {}

    name = module.params['name']

# Generated at 2022-06-11 08:14:25.871403
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:30.268083
# Unit test for function main
def test_main():
    test_module = AnsibleModule({
        "name": "httpd",
        "state": "started",
        "enabled": True
    }, check_invalid_arguments=False)
    try:
        main()
    except SystemExit:
        pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:32.181151
# Unit test for function main
def test_main():
    return_value = main()
    assert return_value is None

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:43.259054
# Unit test for function main
def test_main():

    name = apache2
    state = started
    enabled = yes

# Generated at 2022-06-11 08:14:53.962624
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = 'apache2'
    action = 'started'
    enabled = True
    runlevels

# Generated at 2022-06-11 08:15:04.624145
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:15:17.107233
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=False, type='str'),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    #if module.params['state'] == 'started':

# Generated at 2022-06-11 08:15:27.545891
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.service.sysv import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize
    import sys
    import os
    import re
    import pytest
    #from io import StringIO
    #from io import BytesIO
    #from contextlib import redirect_stdout
    #from contextlib import redirect_stderr

    # Set up some mock text for tests.
    fake_service_name_text = 'Service name foo\n'
    fake_is_started_text = 'Service foo is running \n'
    fake_is_stopped_text = 'Service foo is stopped \n'
   