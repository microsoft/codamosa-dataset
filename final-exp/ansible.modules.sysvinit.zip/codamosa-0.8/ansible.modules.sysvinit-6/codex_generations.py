

# Generated at 2022-06-11 08:08:47.667084
# Unit test for function main
def test_main():
    # FIXME: AnsibleModule.set_module_args is annoying
    module = AnsibleModule(argument_spec = dict(
        name = dict(required=True, type='str'),
        action = dict(default=None, choices=['start', 'stop', 'restart', 'reload']),
        enabled = dict(default=None, type='bool'),
        sleep = dict(default=1, type='int'),
        pattern = dict(default=None, type='str'),
        arguments = dict(default=None, type='str'),
        runlevels = dict(default=None, type='list'),
        daemonize = dict(default=False, type='bool')
    ))

    try:
        main()
    except Exception as ex:
        print(ex)

main()

# Generated at 2022-06-11 08:08:55.969215
# Unit test for function main
def test_main():
    sysvinit = AnsibleModule({
        'enabled': True,
        'name': "apache2",
        'state': 'started',
        'runlevels': [3,5],
        'changed': False,
        'status': {
            'enabled': False,
            'stopped': False,
            'stdout': 'Stopping web server: apache2.\n'
        }
    })
    test_main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:09:07.525344
# Unit test for function main
def test_main():
    import sys

    import ansible.module_utils.basic
    import ansible.module_utils.service
    import ansible.module_utils.sysvinit_attribs

    if sys.version_info[0] > 2:
        import importlib

        importlib.reload(ansible.module_utils.basic)
        importlib.reload(ansible.module_utils.service)
        importlib.reload(ansible.module_utils.sysvinit_attribs)
    else:
        reload(ansible.module_utils.basic)
        reload(ansible.module_utils.service)
        reload(ansible.module_utils.sysvinit_attribs)

    # Assign function to class module
    module = type(sysvinit)('tests.unit.module_utils.sysvinit')

# Generated at 2022-06-11 08:09:09.006484
# Unit test for function main
def test_main():
  main()

if __name__ == '__main__':
  main()

# Generated at 2022-06-11 08:09:21.014297
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:09:29.139896
# Unit test for function main
def test_main():
    mymodule = AnsibleModule({'name': 'foo'}, check_mode=False)
    mymodule.params['state'] = 'started'
    mymodule.params['enabled'] = True
    mymodule.params['runlevels'] = []
    mymodule.params['pattern'] = 'icmp'
    mymodule.params['sleep'] = 1
    mymodule.get_bin_path = Mock(return_value='/bin/chkconfig')
    module_exit_json = Mock()
    setattr(mymodule, 'exit_json', module_exit_json)
    get_sysv_script = Mock(return_value='/bin/testscript')
    setattr(mymodule, 'get_sysv_script', get_sysv_script)
    sysv_is_enabled = Mock(return_value=True)
    set

# Generated at 2022-06-11 08:09:40.341154
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-11 08:09:47.641832
# Unit test for function main
def test_main():
    testobj = {
            "name": "apache2",
            "state": "started",
            "enabled": "yes",
            "sleep": 1,
            "pattern": "",
            "arguments": "",
            "runlevels": [
                "3",
                "5"
                ],
            "daemonize": False
        }
    sysvinit(testobj)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:09:57.324207
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # TODO add unit tests

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:10:07.327549
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import service
    from ansible.module_utils import action
    from ansible.module_utils import daemonize
    module = AnsibleModule(argument_spec=dict(name=dict(required=True), state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str')))

    module.params = {}
    module.params['name'] = 'apache2'
    module.params['state'] = 'started'

    module.run_command = lambda cmd: (0, cmd, "")
    module.get_bin_path = lambda binary_name, opt_dirs=[] : '/bin/' + binary_name
    service.sysv_exists = lambda name: '/etc/init.d/' + name
   

# Generated at 2022-06-11 08:11:06.206145
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils.basic import AnsibleModule
    sys.argv = ['ansible-sysvinit','/root/ansible/sysvinit.py','--name','test','--state','started','--enabled','yes','--runlevels','3','5','--pattern','test','--arguments','test','--daemonize','yes']
    sys.modules['ansible.module_utils.basic'] = AnsibleModule
    global module

# Generated at 2022-06-11 08:11:17.312208
# Unit test for function main
def test_main():
    from ansible.module_utils.actions.service import main
    from ansible.module_utils.action_common import AnsibleAction
    AnsibleAction.main = main
    action = AnsibleAction(
        dict(
            action=dict(required=False, choices=['start', 'stop', 'restart', 'reload']),
            name=dict(required=False),
            pattern=dict(required=False),
            enabled=dict(required=False, choices=BOOLEANS),
            runlevels=dict(required=False, type='list', elements='str'),
            sleep=dict(required=False, type='int'),
            daemonize=dict(required=False, type='bool', default=False),
            arguments=dict(required=False, type='str', aliases=['args'])
        )
    )
    action.execute

# Generated at 2022-06-11 08:11:28.856021
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-11 08:11:34.481459
# Unit test for function main
def test_main():
    class args:
        module = AnsibleModule()
        name = "sysvinit"
        state = "started"
        enabled = None
        sleep = 1
        pattern = None
        arguments = None
        runlevels = None
        daemonize = False

    a = args()
    main()

# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:46.093570
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:11:57.268400
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:12:08.806076
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

# Generated at 2022-06-11 08:12:17.894662
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.dict_transformations import deep_diff

    if basic._ANSIBLE_ARGS is None:
        args = sys.argv[:]
        basic._ANSIBLE_ARGS = basic.AnsibleOptions(args)
    args = basic._ANSIBLE_ARGS
    sys.argv[1:] = ['-vvvv']
    sys.argv[0] = to_bytes(sys.argv[0])

    # Mock the options
    args.connection = 'local'
    args.module_path = '.'
    args.forks = 1
    args.private_key_file = ''
    args.diff = True
    args.check = False

    # Mock the uninitialized

# Generated at 2022-06-11 08:12:29.193584
# Unit test for function main
def test_main():

    # test required args
    args = dict(
        name="apache2",
        state="started",
        enabled=True,
        sleep=1,
        pattern="pattern",
        arguments="args",
        runlevels=["1", "2", "3", "4"],
        daemonize=True,
    )

    # test missing required args
    with pytest.raises(TypeError, message="missing a required argument: 'name'"):
        main()

    # test required args with no value
    args = dict(
        name="",
        state="started",
        enabled=True,
        sleep=1,
        pattern="pattern",
        arguments="args",
        runlevels=["1", "2", "3", "4"],
        daemonize=True,
    )


# Generated at 2022-06-11 08:12:39.570955
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule, get_exception
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists
    import sys

    PARSER = argparse.ArgumentParser(add_help=False)
    PARSER.add_argument('--version', action='version', version=version.__version__)
    PARSER.add_argument('-v', '--verbose', action='count', help="Enable verbose mode")
    PARSER.add_argument('--verbosity', type=int, default=None, help="Verbosity level")
    PARSER.add_argument('--force-color', action='store_true', help="Force colored output")

# Generated at 2022-06-11 08:13:53.455251
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:01.827255
# Unit test for function main
def test_main():
  from ansible.module_utils.facts import Facts
  from ansible.module_utils.sysv_attributes import SysvinitAttributes


# Generated at 2022-06-11 08:14:07.433801
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    ###########################################################################
    # BEGIN: main
    ###########################################################################
    # FIXME: Add unit tests for function main
    ###########################################################################
    # END: main
    ###########################################################################


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:17.757946
# Unit test for function main
def test_main():
    "Mock sysvinit module's main()"

    import sys
    import os

    mock_action = None
    # Mocked module arguments
    m_args = {
        'check_mode': True,
        'diff_mode': False,
        'platform': 'posix',
        'state': 'started',
        'enabled': True
    }
    module = AnsibleModule(**m_args)

    # Mocked module return value

# Generated at 2022-06-11 08:14:23.575778
# Unit test for function main
def test_main():
    fake = FakeAnsibleModule(dict(
            name = 'apache2',
            state = 'started',
            enabled = 'yes',
            sleep = 1,
            pattern = '',
            arguments = '',
            runlevels ='',
            daemonize = False,
            ),
        supports_check_mode = True,
        required_one_of = [['state', 'enabled'],])
    fake.run_command()
    module.exit_json(**result)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:33.623122
# Unit test for function main
def test_main():

    class ModuleStub(object):
        def __init__(stub, **kwargs):
            stub.params = kwargs

            def get_bin_path(stub, binary, opt_dirs=[]):
                return "/bin/" + binary

            def fail_json(stub, **kwargs):
                raise AnsibleError(kwargs['msg'])

            def warn(stub, msg):
                None

            def run_command(stub, cmd):
                return (0, '', '')

            module.get_bin_path = get_bin_path
            module.fail_json = fail_json
            module.warn = warn
            module.run_command = run_command

            class AnsibleError(Exception):
                pass


# Generated at 2022-06-11 08:14:44.936782
# Unit test for function main

# Generated at 2022-06-11 08:14:55.097788
# Unit test for function main
def test_main():
    import sys
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.ansible_release import __version__ as ansible_release


# Generated at 2022-06-11 08:15:06.025988
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    print("Running Unit Test for function main")


# Generated at 2022-06-11 08:15:18.051201
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

# import module snippets
if __name__ == '__main__':
    main

# Generated at 2022-06-11 08:17:24.032349
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    class FakeModule:
        def __init__(self, **kwargs):
            self.__