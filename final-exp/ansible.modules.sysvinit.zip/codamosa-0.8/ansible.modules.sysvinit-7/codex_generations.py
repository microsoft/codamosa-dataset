

# Generated at 2022-06-11 08:08:36.324226
# Unit test for function main
def test_main():
    import __main__ as main
    sysvinit = reload(main)
    assert sysvinit.main() is None

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:08:47.717928
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, get_ps, daemonize

    # shared objects
    class MockModule(object):
        def __init__(self):
            self.run_command_result = None

        def run_command(self, command):
            return self.run_command_result

    m_module = MockModule()

    # test functions
    def test_check_mode(self):
        m_module.run_command_result = (None, None, None)

        class MockModuleArgs(object):
            def __init__(self):
                self.name = 'ansible'
                self.state = 'started'
                self.enabled = None
                self.sleep

# Generated at 2022-06-11 08:09:00.229706
# Unit test for function main
def test_main():
    import copy
    import json
    from ansible.module_utils.basic import AnsibleModule
    from sysvinit import main


# Generated at 2022-06-11 08:09:10.896164
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

# Import module snippets.

# Generated at 2022-06-11 08:09:22.261605
# Unit test for function main
def test_main():
    # set up standard test interface
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # set test input

# Generated at 2022-06-11 08:09:29.699667
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
        ),
        required_one_of=[['state', 'enabled']],
    )
    # module_instance.params = {"name": "apache2", "enabled":  True, "runlevels": ["2", "3", "4", "5"]}
    # module_instance.params = {"

# Generated at 2022-06-11 08:09:40.848852
# Unit test for function main
def test_main():
    result = dict()
    result['name'] = 'apache2'
    result['changed'] = False
    result['status'] = dict()
    result['status']['enabled'] = dict()
    result['status']['enabled']['changed'] = False
    result['status']['enabled']['rc'] = None
    result['status']['enabled']['stdout'] = None
    result['status']['enabled']['stderr'] = None
    result['status']['started'] = dict()
    result['status']['started']['changed'] = False
    result['status']['started']['rc'] = None
    result['status']['started']['stdout'] = None
    result['status']['started']['stderr'] = None

# Generated at 2022-06-11 08:09:52.876625
# Unit test for function main
def test_main():
    # setup mock args and module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # Mock values extracted from actual bash script
    module.get_

# Generated at 2022-06-11 08:10:05.244848
# Unit test for function main
def test_main():
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch

    mock_module = unittest.mock.MagicMock()
    mock_module.params = {'name': 'apache', 'runlevels': None, 'sleep': 2, 'state': 'started', 'enabled': True}
    mock_module.run_command.return_value = (0, '', '')
    mock_module.get_bin_path.return_value = '/bin/service'

    mock_module.service.sysv_is_enabled.return_value = True
    mock_module.service.sysv_exists.return_value = True
    mock_module.service.get_sysv_script

# Generated at 2022-06-11 08:10:15.851550
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    name = 'httpd'
    state = 'started'
    enabled = True
    sleep = 1
    pattern = ''
    arguments = ''
    runlevels = ''
    daemonize = False
    

# Generated at 2022-06-11 08:11:18.424902
# Unit test for function main
def test_main():
    print("Testing main()")
    test_params = {}
    test_params['name'] = 'apache2'
    test_params['state'] = 'started'
    test_params['enabled'] = True
    test_params['runlevels'] = [3, 5]
    test_params['pattern'] = None
    test_params['arguments'] = None
    test_params['daemonize'] = False

# Generated at 2022-06-11 08:11:29.040602
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.actions import AnsibleAction

    # Mock out AnsibleModule and AnsibleAction
    sys.modules['ansible.module_utils.basic.AnsibleModule'] = AnsibleModule
    sys.modules['ansible.module_utils.basic.AnsibleAction'] = AnsibleAction

    # Use pre-loaded function call data
    data = {
      "arguments": None,
      "daemonize": False,
      "enabled": False,
      "name": "apache2",
      "state": "stopped"
    }

    # Execute main()
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:38.386875
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    setattr(module, 'exit_json', exit_json)

# Generated at 2022-06-11 08:11:45.881086
# Unit test for function main
def test_main():
    import sys
    import os
    testfile = open('/tmp/ansible_module_sysvinit.data', 'w')
    testfile.write('{\"module_args\": {\"name\": \"sysvinit\", \"state\": \"start\"}}')
    testfile.close()

    os.chdir('/usr/local/lib/python2.7/dist-packages/ansible/modules/')
    sys.argv = ['ansible-module-sysvinit']
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:57.064669
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:08.586466
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    with open('../test_data/test_result.json', 'r') as f:
        data = f.read()
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False)
    ))
    main()

# Generated at 2022-06-11 08:12:17.778542
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps
    from ansible.module_utils.common.process import get_bin_path
    def run_command(self):
        if self.module.params['arguments'] is None:
            return self.fail_json(msg="Failed to {0} service: {1}".format(action, name))
        elif self.module.params['arguments'] == 'args':
            return (0, "", "")

    AnsibleModule.run_command = run_command
    AnsibleModule.get_bin_path = get_bin_path
    AnsibleModule.get_sysv_exists = sy

# Generated at 2022-06-11 08:12:29.107335
# Unit test for function main
def test_main():
    # Unit test for function main
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']

# Generated at 2022-06-11 08:12:38.966032
# Unit test for function main
def test_main():
    args = [
        'name: test_service',
    ]

    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ))
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:50.434848
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
        'name': dict(required=True, type='str', aliases=['service']),
        'state': dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        'enabled': dict(type='bool'),
        'sleep': dict(type='int', default=1),
        'pattern': dict(type='str'),
        'arguments': dict(type='str', aliases=['args']),
        'runlevels': dict(type='list', elements='str'),
        'daemonize': dict(type='bool', default=False),
    },
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']])
    main(module)


# Generated at 2022-06-11 08:14:43.582356
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 08:14:54.224273
# Unit test for function main
def test_main():
    test_name = 'test'
    test_state = 'started'
    test_enabled = False
    test_runlevels = []
    test_pattern = None
    test_sleep = 1
    test_rc = 0


# Generated at 2022-06-11 08:14:58.575058
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    if __name__ == '__main__':
        basic._ANSIBLE_ARGS = ['--module-path', '', '--name', name, '--state', state, '--enabled', enabled, '--runlevels', runlevels, '--arguments', arguments]
        main()

main()

# Generated at 2022-06-11 08:15:01.602040
# Unit test for function main
def test_main():
    my_loop = asyncio.get_event_loop()
    my_loop.run_until_complete(test_main_coro())
    print("TEST COMPLETE")

# Generated at 2022-06-11 08:15:14.659763
# Unit test for function main
def test_main():
    # Have to init our AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            state=dict(required=False, type='str'),
            enabled=dict(required=True, type='bool'),
            sleep=dict(required=False, type='int', default=1),
            pattern=dict(required=False, type='str'),
            arguments=dict(required=False, type='str', aliases=['args']),
            runlevels=dict(required=False, type='list', elements='str'),
            daemonize=dict(required=False, type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
    )

    sysvinit = Sysvinit(module)

# Generated at 2022-06-11 08:15:15.827045
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:15:26.119226
# Unit test for function main
def test_main():
    import mock
    import sys
    from ansible.module_utils.basic import AnsibleModule

    if sys.version_info[:2] != (2, 7):
        sys.exit("This unit test is for Python 2.7 only")

    m = mock.MagicMock()
    m.run_command.return_value = ('','','','','','','','','')
    m.params = {'state': 'started', 'action': 'start', 'name': 'syslog',  'daemonize': True}
    m.get_bin_path = lambda x, opt_dirs=None: '/bin/' + x
    m.run_command = lambda x: (100, '', '', '')
    m.exit_json = lambda x: None


# Generated at 2022-06-11 08:15:36.854138
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-11 08:15:44.309022
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import os
    import re

    # Create a temporary directory to store the scripts and any other content
    # needed for testing.
    tmpdir = tempfile.mkdtemp(prefix='ansible_test_sysv_module')
    cwd = os.getcwd()
    os.chdir(tmpdir)

    # Create a fake init script to test

# Generated at 2022-06-11 08:15:45.563716
# Unit test for function main
def test_main():
    ret = main()
# Unit testing
# test_main()