

# Generated at 2022-06-25 03:28:22.990538
# Unit test for function main
def test_main():
    assert main()[0] == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:28:34.829533
# Unit test for function main
def test_main():
    # Service exists and is in runlevel 123
    assert main().__dict__ == {
        'status': {
            'started': {'changed': True},
            'enabled': {'changed': True}},
        'changed': True,
        'name': "service_name"
    }
    # Service doesn't exists and should be added to runlevel 123
    assert main().__dict__ == {
        'status': {
            'started': {'changed': False},
            'enabled': {'changed': True}},
        'changed': True,
        'name': "service_name"
    }
    # Service exists and is in runlevel 123 and should be removed

# Generated at 2022-06-25 03:28:38.105000
# Unit test for function main
def test_main():
    result = main()
    assert result == None, "Function main returning unexpected result"

if __name__ == "__main__":
    test_case_0()

main()

# Generated at 2022-06-25 03:28:39.769497
# Unit test for function main
def test_main():
    var_0 = main()
    assert(var_0 != None)


# Generated at 2022-06-25 03:28:48.747541
# Unit test for function main
def test_main():
    from ansible_collections.misc.not_a_real_collection.plugins.modules.system.sysvinit import main
    import os # python standard library
    import tempfile # built-in

    # Make a temp directory to work in
    tmpdir = tempfile.mkdtemp()
    # Make sure the directory is cleaned up
    # noinspection PyBroadException

# Generated at 2022-06-25 03:28:50.004660
# Unit test for function main
def test_main():
    var = main()
    print(var)

# Generated at 2022-06-25 03:28:52.916144
# Unit test for function main
def test_main():
    test_case_0()

# Command to execute unit tests
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:28:54.568984
# Unit test for function main
def test_main():
    var_0 = main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 03:29:04.131786
# Unit test for function main
def test_main():
    var_0 = AnsibleModule()
    var_1 = var_0.params
    var_2 = "name"
    var_1.__setitem__(var_2,"test_value")

    var_2 = "state"
    var_1.__setitem__(var_2,"test_value")

    var_2 = "enabled"
    var_1.__setitem__(var_2,"test_value")

    var_2 = "sleep"
    var_1.__setitem__(var_2,1)

    var_2 = "pattern"
    var_3 = var_1.get(var_2)

# Generated at 2022-06-25 03:29:05.050293
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 03:30:45.608798
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print('Test Case  0 Fail')

test_main()

# Generated at 2022-06-25 03:30:47.787220
# Unit test for function main
def test_main():
    var_0 = main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:30:48.971488
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 03:30:50.737301
# Unit test for function main
def test_main():
    # Run Unit tests for function main
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:30:57.753326
# Unit test for function main
def test_main():

    param0 = None
    tests_ok = 0
    tests_fail = 0

    if(test_case_0()[1]):
        tests_ok += 1
    else:
        tests_fail += 1

    if(tests_fail):
        print("TESTS FAIL")
    else:
        print("TESTS OK")

# Main function
if __name__ == '__main__':

    print("Test suite: %s" % __file__)
    test_main()

# Generated at 2022-06-25 03:31:01.644024
# Unit test for function main
def test_main():
    test_case_main = [
    {
        "name": "apache2",
        "state": "started",
        "enabled": true,
        "runlevels": ["3", "5"],
        "pattern": "pattern",
        "arguments": "arguments",
        "daemonize": true
    }]

    return test_case_main

if __name__ == '__main__':
    main()


# Generated at 2022-06-25 03:31:03.316468
# Unit test for function main
def test_main():
    assert main()



# Generated at 2022-06-25 03:31:08.124329
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] is True:
            return 0
        return 1
    except Exception as e:
        print('Exception: %s' % e)
        return 1

if __name__ == '__main__':
    print('Value returned = %s' % (test_main()))

# Generated at 2022-06-25 03:31:09.817619
# Unit test for function main
def test_main():
    assert True == True

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:31:13.167390
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as e:
        print('Caught exception: ' + repr(e))

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:33:06.682806
# Unit test for function main
def test_main():
    arguments = {
        "service": "sysvinit_service_name"
    }
    res = {}
    var_0 = main(arguments=arguments, res=res)
    assert var_0 == res

################################################################################
# OUTPUT:
#
# {'results': {
#     'changed': True,
#     'status': {
#     'enabled': {
#              'changed': True,
#              'runlevels': ['3', '5'],
#              'rc': 0,
#              'stderr': '',
#              'stdout': ''
#     },
#     'reloaded': {
#              'changed': True,
#              'rc': 0,
#              'stderr': '',
#              'stdout': 'Reloading web server config: apache2 ... waiting

# Generated at 2022-06-25 03:33:07.406924
# Unit test for function main
def test_main():
    var_0 = main()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 03:33:13.842999
# Unit test for function main
def test_main():
    # try:
    #     test_case_0()
    # except Exception as error:
    #     print(error)
    #     assert(1==0)

    assert(main() == "Service restarts")

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:33:19.329269
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 is not None, "Cannot find main"




if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:33:20.677235
# Unit test for function main
def test_main():
    var_0 = main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:33:21.704114
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:33:22.699450
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:33:25.051560
# Unit test for function main
def test_main():
    var_0 = main()
    assert True == True


# Generated at 2022-06-25 03:33:26.414101
# Unit test for function main
def test_main():
    print("Testing function main")
    assert test_case_0() == None

test_main()

# Generated at 2022-06-25 03:33:30.912933
# Unit test for function main
def test_main():
    print('Hooray! Test passed')

test_main()