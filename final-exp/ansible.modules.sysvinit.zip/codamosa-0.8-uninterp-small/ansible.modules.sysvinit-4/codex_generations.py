

# Generated at 2022-06-25 03:28:32.557880
# Unit test for function main
def test_main():
    # Initialize the module with the required arguments.
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # Initialize a mock stdin and a mock

# Generated at 2022-06-25 03:28:36.732452
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        # If we don't catch, ansible will print the exception and use a error
        # style task result.
        raise



# Generated at 2022-06-25 03:28:38.464745
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        assert(False)


test_main()

# Generated at 2022-06-25 03:28:40.182091
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 03:28:42.752573
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print('exception raised')

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:28:50.620726
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    #from ansible.module_utils.actions import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize


# Generated at 2022-06-25 03:28:52.052381
# Unit test for function main
def test_main():
    try:
        var_0 = main()
    except Exception as e:
        raise AssertionError(e)

# Unit test main function

# Generated at 2022-06-25 03:28:54.569369
# Unit test for function main
def test_main():
    var_0 = main()
    if var_0 != 1:
        print ("test_main: Failed")
        raise AssertionError('test_main')


# Generated at 2022-06-25 03:28:55.869036
# Unit test for function main
def test_main():
    # Test for function main
    var_d = main()
    assert var_d == 1

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 03:29:03.534431
# Unit test for function main
def test_main():
    var_0 = {'status': {'enabled': {'stdout': None, 'stderr': None, 'rc': None, 'runlevels': ['3', '5'], 'changed': False}}, 'changed': True, 'name': 'apache2'}
    assert var_0 == {'status': {'enabled': {'stdout': None, 'stderr': None, 'rc': None, 'runlevels': ['3', '5'], 'changed': False}}, 'changed': True, 'name': 'apache2'}

test_main()

# Generated at 2022-06-25 03:29:53.825975
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:29:56.815074
# Unit test for function main
def test_main():
    test_case_0()
    
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 03:29:59.846706
# Unit test for function main
def test_main():
    assert True == True

if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-25 03:30:01.236201
# Unit test for function main
def test_main():
    print("Start function main")
    main()
    print("End function main")

# Run unit test
test_main()

# Generated at 2022-06-25 03:30:03.807300
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None, "main returns an error"


TEST_CASES = [
    test_case_0
]

if __name__ == '__main__':
    for testcase in TEST_CASES:
        print("Running testcase " + testcase.__name__)
        testcase()

# Generated at 2022-06-25 03:30:06.601634
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit as exception:
        pass



# Generated at 2022-06-25 03:30:15.036010
# Unit test for function main
def test_main():
    arg0 = {}
    arg0['name'] = 'foo.service'
    arg0['state'] = 'started'
    arg0['enabled'] = True
    arg0['sleep'] = 1
    arg0['pattern'] = 'pattern-1'
    arg0['arguments'] = 'args-1'
    arg0['runlevels'] = ['runlevels-1', 'runlevels-2']
    arg0['daemonize'] = False
    test_case_0(arg0)
    return 'unit test'

if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-25 03:30:16.682581
# Unit test for function main
def test_main():
    pass

# Call main()
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:30:19.259721
# Unit test for function main
def test_main():
    var_2 = main()

if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-25 03:30:20.699400
# Unit test for function main
def test_main():
    assert main() == None

if __name__=='__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-25 03:31:59.998855
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 03:32:06.531134
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        import sys
        if sys.argv[0] == '':
            # Unit tests on console
            test_case_0()
        else:
            # Unit tests from file
            #test_case_1()
            #test_case_2()
            pass


# Generated at 2022-06-25 03:32:08.042738
# Unit test for function main
def test_main():
    assert main()


if __name__ == "__main__":
    main()
    test_main()

# Generated at 2022-06-25 03:32:09.925524
# Unit test for function main
def test_main():
    assert var_0 == None, 'AssertionError: "var_0" does not match expected value'

test_case_0()
test_main()

# Generated at 2022-06-25 03:32:10.827370
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 03:32:16.442189
# Unit test for function main
def test_main():
    mock_0 = {'type': 'bool', 'aliases': ['service']}
    mock_1 = {'type': 'list', 'choices': ['stopped', 'started', 'reloaded', 'restarted'], 'aliases': ['args']}
    mock_2 = {'type': 'bool'}
    mock_3 = {'type': 'dict'}
    mock_4 = {'type': 'dict'}
    mock_5 = {'type': 'dict'}
    mock_6 = {'type': 'list', 'elements': 'str'}
    mock_7 = {'type': 'str'}
    mock_8 = {'type': 'int', 'default': 1}
    mock_9 = {'type': 'bool', 'default': False}

# Generated at 2022-06-25 03:32:20.143708
# Unit test for function main
def test_main():
    name = "foo"
    state = "started"
    enabled = True
    sleep = 1
    pattern = None
    arguments = None
    runlevels = None
    daemonize = False

    # mock setup
    service = Sysvinit(name, action, enabled, sleep, pattern, arguments, runlevels, daemonize)
    service.run()

    # mock check
    assert service.result['command'] == command

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:32:21.725630
# Unit test for function main
def test_main():
    assert main() is None

# Test case for function main

# Generated at 2022-06-25 03:32:25.559601
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 03:32:35.578404
# Unit test for function main
def test_main():
    mock_module = MagicMock()
    mock_module.params = {
    }

    with patch("ansible_collections.ansible.community.plugins.module_utils.basic.AnsibleModule") as mock_AnsibleModule:
        mock_AnsibleModule.return_value = mock_module
        with patch("ansible_collections.ansible.community.plugins.service.sysv.sysv_is_enabled") as mock_sysv_is_enabled:
            mock_sysv_is_enabled.return_value = False
            with patch("ansible_collections.ansible.community.plugins.service.sysv.get_sysv_script") as mock_get_sysv_script:
                mock_get_sysv_script.return_value = "/etc/init.d/var_0"

# Generated at 2022-06-25 03:36:30.207683
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 03:36:31.164716
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:36:32.050451
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 03:36:36.525924
# Unit test for function main
def test_main():
    assert True == True


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:36:45.374486
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(argument_spec={'enabled': 'bool', 'state': 'str', 'daemonize': 'bool', 'sleep': 'int', 'name': 'str', 'runlevels': 'list', 'arguments': 'str'})
    var_0.run_command = lambda x: (1346657734, '', '')
    var_0.get_bin_path = lambda x, y: 'foo'
    var_0.check_mode = False
    var_0.params['name'] = 'foo'
    var_0.params['enabled'] = True
    main()
    var_0.warn = lambda x: None
    main()
    main()
    main()
    main()
    main()
    main()
    main()
    main()
    main()
    main()
    main

# Generated at 2022-06-25 03:36:46.648893
# Unit test for function main
def test_main():
    assert main()


# Generated at 2022-06-25 03:36:50.278233
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None, "main returns unexpected result"

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 03:36:55.830634
# Unit test for function main
def test_main():
    with patch(u'module_utils.action_plugins.service.sysv_is_enabled', return_value=None) as mock_sysv_is_enabled:
        var_1 = main()
        call_0 = call('name', None)
        call_1 = call('name')
        mock_sysv_is_enabled.assert_has_calls([call_0, call_1])


# Generated at 2022-06-25 03:36:56.736912
# Unit test for function main
def test_main():
    test_case_0()
    

# Generated at 2022-06-25 03:36:58.144783
# Unit test for function main
def test_main():
    var_0 = main()
    pass

if __name__ == '__main__':
    main()