

# Generated at 2022-06-25 03:28:22.286573
# Unit test for function main
def test_main():
    os.system('touch ansible-test-file.txt')
    out = os.system('timeit -n 1 -r 2 python ansible_test.py 2>&1 >/dev/null')
    if out == 0:
        os.system('rm -f ansible-test-file.txt')
        return True
    else:
        os.system('rm -f ansible-test-file.txt')
        return False

test_main()


# Generated at 2022-06-25 03:28:24.951222
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == None, 'main returns None.'

if __name__ == '__main__':
    test_main()
    print('main done.')

# Generated at 2022-06-25 03:28:37.787362
# Unit test for function main
def test_main():
    if not os.path.exists('/tmp/ansible_sysv_unit_tests'):
        os.mkdir('/tmp/ansible_sysv_unit_tests')
    f = open('/tmp/ansible_sysv_unit_tests/test_main','w')
    f.write('''

''')
    f.close()

    sysv_exists_calls = []
    sysv_is_enabled_calls = []
    get_sysv_script_calls = []
    get_ps_calls = []
    daemonize_calls = []
    run_command_calls = []

    class sysv_exists_mock(object):
        def __init__(self, name):
            sysv_exists_calls.append(name)
            return True



# Generated at 2022-06-25 03:28:38.674042
# Unit test for function main
def test_main():
    assert main("")


# Generated at 2022-06-25 03:28:40.993511
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 in (True, False)


# Generated at 2022-06-25 03:28:44.711464
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:28:46.940303
# Unit test for function main
def test_main():
    # 1. This should run successfully
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:28:50.519351
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit:
        pass



# Generated at 2022-06-25 03:28:53.784071
# Unit test for function main
def test_main():
    print('in test_main')
    try:
        main()
    except:
        print('EXCEPTION THROWN IN main')
        pass


# Generated at 2022-06-25 03:29:01.740980
# Unit test for function main
def test_main():
    # Initializing the module object
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # Getting the arguments
    name = module.params['name']

# Generated at 2022-06-25 03:30:38.494651
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 03:30:40.182700
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:30:43.096488
# Unit test for function main
def test_main():
    assert isinstance(main(), dict)

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:30:44.761877
# Unit test for function main
def test_main():
    # Check if main function is called
    assert main == sys.modules[__name__].__dict__['main']

# Run test for function main

# Generated at 2022-06-25 03:30:46.703979
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Error while executing test_case_0")


test_main()

# Generated at 2022-06-25 03:30:50.567162
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] == 0:
            pass
        else:
            raise

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 03:30:56.573983
# Unit test for function main
def test_main():
    test_case_0()

################################################################################

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:31:01.594091
# Unit test for function main
def test_main():
    var_1 = "value"
    assert main(var_1) == "value"

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:31:04.774651
# Unit test for function main
def test_main():
    try:
        #sysvinit.main()
        var_0 = main()
    except SystemExit as exception:
        return 
    assert False


# Generated at 2022-06-25 03:31:06.259617
# Unit test for function main
def test_main():

    test_0 = main()
    assert test_0 == 0



# Generated at 2022-06-25 03:32:41.468615
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:32:47.603138
# Unit test for function main
def test_main():
    args = {"enabled": None, "runlevels": None, "name": "", "daemonize": False, "arguments": None, "sleep": None, "pattern": None, "state": ""}
    if __name__ == '__main__':
        main()
        #test_case_0()
        #main()
        #test_main()
        #print(main())
        #main()
        #print(main(args))
        #main(args)
        print(test_case_0())
        test_case_0()
        print(test_main())
        test_main()

# Generated at 2022-06-25 03:32:51.917583
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as ex:
        if ex.code != 0:
            print('FAILED')
        else:
            print('PASSED')
    except:
        print('FAILED')

# Collect all test cases in this file

# Generated at 2022-06-25 03:32:55.106778
# Unit test for function main
def test_main():
    assert test_case_0() is None, "init failed."

# Local variables:
# mode: python
# coding: utf-8
# tab-width: 4
# py-indent-offset: 4
# indent-tabs-mode: nil
# End:

# Generated at 2022-06-25 03:32:55.703080
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 03:33:02.245497
# Unit test for function main
def test_main():
    mock_0 = ({"metavar": "COMMAND", "required": False, "default": None, "help": "Control the state of the service", "choices": ["started", "stopped", "restarted", "reloaded"], "type": "str"})
    mock_1 = ({"metavar": "bool", "required": False, "default": False, "help": "Whether or not to enable the service", "type": "bool"})
    mock_2 = ({"metavar": "integer", "required": False, "default": 1, "help": "Whether or not to sleep between actions", "type": "int"})

# Generated at 2022-06-25 03:33:04.014435
# Unit test for function main
def test_main():

    # Test case 0
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:33:05.015953
# Unit test for function main
def test_main():
    case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:33:06.261066
# Unit test for function main
def test_main():
    var_0 = main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 03:33:13.015059
# Unit test for function main
def test_main():
    var_0 = main()
    print(var_0)


if __name__ == "__main__":
    try:
        test_main()
    except:
        pass

# Generated at 2022-06-25 03:36:55.647808
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 03:37:03.484568
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == r'{"status": {"enabled": {}, "reloaded": {"rc": null, "stderr": null, "stdout": null, "changed": false}, "restarted": {"rc": null, "stderr": null, "stdout": null, "changed": false}, "started": {"rc": null, "stderr": null, "stdout": null, "changed": false}, "stopped": {"rc": null, "stderr": null, "stdout": null, "changed": false}}, "changed": false, "name": "apache2"}'


# Generated at 2022-06-25 03:37:08.492871
# Unit test for function main
def test_main():
    module = {"params": {"runlevels": [], "pattern": "", "enabled": True, "state": "started", "daemonize": False, "arguments": "", "sleep": 1, "name": "apache2"},
    "run_command": test_case_0,
    "fail_json": test_case_0,
    "get_bin_path": test_case_0,
    "exit_json": test_case_0,
    "check_mode": None
    }
    main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:37:14.314654
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    try:
        main()
    except Exception as e:
        print(e)
