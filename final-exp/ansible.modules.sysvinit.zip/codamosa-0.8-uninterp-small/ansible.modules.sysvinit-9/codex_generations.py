

# Generated at 2022-06-25 03:28:25.202334
# Unit test for function main

# Generated at 2022-06-25 03:28:26.114892
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 03:28:32.866018
# Unit test for function main
def test_main():
    import sys
    import StringIO
    import os

    capturedOutput = StringIO.StringIO()
    sys.stdout = capturedOutput

    test_case_0()

    sys.stdout = sys.__stdout__

# Generated at 2022-06-25 03:28:33.831749
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 03:28:37.250615
# Unit test for function main
def test_main():
    var_0 = main()

# Main program for unit test
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 03:28:38.341210
# Unit test for function main
def test_main():
    assert(main())


# Generated at 2022-06-25 03:28:47.999845
# Unit test for function main
def test_main():
    var_1 = "/sbin"
    var_2 = "/sbin/apache2"
    var_3 = ""
    var_4 = "apache2"
    var_5 = "/usr/sbin"
    var_6 = "/bin"
    var_7 = "/usr/bin"
    var_8 = "/usr/sbin"
    var_9 = "apache2"
    var_10 = "/bin"
    var_11 = "/usr/bin"
    var_12 = "/usr/bin/chkconfig"
    var_13 = "/usr/sbin/update-rc.d"
    var_14 = "/sbin/insserv"
    var_15 = "/usr/sbin/service"
    var_16 = "started"
    var_17 = "enabled"

# Generated at 2022-06-25 03:28:48.959427
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:28:51.396184
# Unit test for function main
def test_main():
    var_1 = main()
    print(var_1)


# Generated at 2022-06-25 03:28:52.730720
# Unit test for function main
def test_main():
    test_case_0()

# This is the standard boilerplate that calls the main() function.
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:29:41.875604
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 03:29:44.496595
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    # test_main()
    main()

# Generated at 2022-06-25 03:29:53.147898
# Unit test for function main
def test_main():
    arguments = {
        "name": "",
        "pattern": "",
        "args": "",
        "sleep": 1,
        "state": "started",
        "enabled": None,
        "runlevels": [],
        "daemonize": False,
    }
    retval = main(**arguments)
    # Our tests return this value at the end
    return retval
