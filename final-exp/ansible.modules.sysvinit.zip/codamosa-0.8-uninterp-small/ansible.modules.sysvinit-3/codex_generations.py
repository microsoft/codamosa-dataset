

# Generated at 2022-06-25 03:28:18.097908
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        assert False


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:28:22.374146
# Unit test for function main
def test_main():
    var_0 = ""

# Generated at 2022-06-25 03:28:24.384670
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        assert False


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:28:25.327113
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 03:28:27.631561
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None

if __name__=="__main__":
    test_main()

# Generated at 2022-06-25 03:28:40.345019
# Unit test for function main
def test_main():
    var_0 = main()
    assert type(var_0) == dict
    assert 'results' in var_0
    dict_0 = var_0['results']
    assert type(dict_0) == dict
    assert u'attempts' in dict_0
    int_0 = dict_0['attempts']
    assert type(int_0) == int
    assert int_0 == 1
    assert u'changed' in dict_0
    bool_0 = dict_0['changed']
    assert type(bool_0) == bool
    assert bool_0 == True
    assert u'name' in dict_0
    str_0 = dict_0['name']
    assert type(str_0) == str
    assert str_0 == 'apache2'
    assert u'status' in dict_0
    dict

# Generated at 2022-06-25 03:28:43.872959
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:28:48.629231
# Unit test for function main
def test_main():
    var_0 = main()
    sys.stdout.flush()
    capturedOutput = sys.stdout.getvalue().strip()
    assert capturedOutput == '{}'


# Generated at 2022-06-25 03:28:51.832732
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None, "main() returned %s. Expected %s" % (var_0, None)

# Generated at 2022-06-25 03:28:54.217123
# Unit test for function main
def test_main():

    test_case_0()

if __name__ == '__main__':
    #test_main()
    main()

# Generated at 2022-06-25 03:29:49.906207
# Unit test for function main
def test_main():
    import sys
    import io
    import sys
    import os
    import sys
    import sys
    import sys

    class AnsibleArgs(object):
        def __init__(self):
            self.name = __name__
            self.module_name = None
            self.module_args = None
            self.verbosity = None
            self.version = None

    test_case_ansible_args = AnsibleArgs()
    test_case_ansible_args.name = __file__
    test_case_ansible_args.module_name = "sysvinit"

# Generated at 2022-06-25 03:29:58.486759
# Unit test for function main
def test_main():
    # mock ignore path
    global mock_ignore_path
    mock_ignore_path = ['mock_ansible_module',
    'mock_ansible_module.params',
    'mock_ansible_module.params.get',
    'mock_ansible_module.params.get.return_value',
    'mock_ansible_module.run_command',
    'mock_ansible_module.run_command.return_value',]
    # mock state
    global mock_state

# Generated at 2022-06-25 03:30:04.462699
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    print("Test of function main")
    test_main()
    print("End of Function Test")

# Generated at 2022-06-25 03:30:09.797703
# Unit test for function main
def test_main():
    var_0 = None
    try:
        var_0 = main()
        assert var_0 == None
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 03:30:20.015760
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(name = "AnsibleModule", argument_spec = {}, supports_check_mode = False, required_one_of = [["state", "enabled"]], )
    var_1 = {'name': 'service', 'state': 'restart', 'enabled': None, 'sleep': 1, 'pattern': None, 'arguments': None, 'runlevels': None, 'daemonize': False}
    var_2 = 'service'
    var_3 = None
    var_4 = True
    var_5 = [1]
    var_6 = 'service'
    var_7 = [1]
    var_8 = 'service'
    var_9 = []
    var_10 = 'service'
    var_11 = {'stopped', 'started', 'restarted', 'reloaded'}


# Generated at 2022-06-25 03:30:21.985727
# Unit test for function main

# Generated at 2022-06-25 03:30:24.726107
# Unit test for function main
def test_main():
    name = "test_main"
    description = "Unit test of main"
    data = "main()"
    module = None
    out = get_template_output(description, data, name)
    return_code = main()
    check_return_code(return_code, out)


# Generated at 2022-06-25 03:30:25.656274
# Unit test for function main
def test_main():
    print(test_case_0())

test_main()

# Generated at 2022-06-25 03:30:26.551342
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 is None


# Generated at 2022-06-25 03:30:27.423093
# Unit test for function main
def test_main():
    # generate tests for each argument type
    pass


# Generated at 2022-06-25 03:31:20.074196
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        assert False

# Import testcases.py
import testcases

# Collect all test cases in this file
module_test_cases = filter(lambda x: x.__name__.startswith("test_"), globals().values())

if __name__ == '__main__':

    # Run unit tests
    for testCase in module_test_cases:
        testCase()

# Generated at 2022-06-25 03:31:23.660292
# Unit test for function main
def test_main():
    print("test_main")
    var_0 = main()
    print("test_main")
    print(var_0)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:31:26.060031
# Unit test for function main
def test_main():
    print('main')


# Generated at 2022-06-25 03:31:33.240170
# Unit test for function main
def test_main():
    """
    :return:
    """
    # Testing when sysvinit package is absent
    import os
    import sys
    import tempfile
    import contextlib

    # We do not need to make any changes to the environment here.
    orig_environ = os.environ.copy()

    @contextlib.contextmanager
    def make_temp_dir():
        tempdir = tempfile.mkdtemp()
        orig_dir = os.getcwd()
        try:
            os.chdir(tempdir)
            yield tempdir
        finally:
            os.chdir(orig_dir)
            for filename in os.listdir(tempdir):
                os.remove(os.path.join(tempdir, filename))
            os.rmdir(tempdir)

    # We need to create a temporary directory

# Generated at 2022-06-25 03:31:35.127424
# Unit test for function main
def test_main():
    test_case_0()

# Unit test execution
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:31:35.925247
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 03:31:38.875251
# Unit test for function main
def test_main():
    # Arrange
    module_exists_mock = Mock()
    module_exists_mock.return_value = 0

    var_0 = module_exists_mock

    # Act
    main()

    # Assert

test_main()

# Generated at 2022-06-25 03:31:45.434692
# Unit test for function main
def test_main():
    mock_args = argparse.Namespace()
    mock_args.name = "apache2"
    mock_args.state = "started"
    mock_args.enabled = "yes"
    mock_args.runlevels = "3"
    mock_args.arguments = ""
    mock_args.daemonize = "no"
    test_case_0()


# Generated at 2022-06-25 03:31:51.376722
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] is True:
            return 0
    return 1

ANSIBLE_METADATA = {'status': ['preview'],
                    'supported_by': 'core',
                    'version': '1.0'}

#if __name__ == '__main__':
#    if test_main() == 0:
#        print("Test Success")
#    else:
#        print("Test Failure")
#    sys.exit(0)

# Generated at 2022-06-25 03:31:54.056552
# Unit test for function main
def test_main():
    var_0 = main()

test_main()

# Generated at 2022-06-25 03:33:30.432341
# Unit test for function main
def test_main():
    pass



# Generated at 2022-06-25 03:33:37.096858
# Unit test for function main
def test_main():
    file_path = os.path.dirname(os.path.realpath(__file__))
    file_path += '/test_cases/'
    json_file = file_path + 'sysvinit_tc.json'
    module = AnsibleModule(argument_spec = json.load(open(json_file)))

    try:
        main()
    except SystemExit:
        pass


# Generated at 2022-06-25 03:33:38.701800
# Unit test for function main
def test_main():
    assert 0 == main()

# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 03:33:42.412493
# Unit test for function main
def test_main():
    print("\tRunning test_main...")
    if __name__ == "__main__":
        test_case_0()

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 03:33:49.806949
# Unit test for function main
def test_main():
    with mock.patch.object(AnsibleModule, 'get_bin_path') as mock_get_bin_path:
        var_0 = mock_get_bin_path.return_value = '/bin/bash'
        with mock.patch.object(AnsibleModule, 'run_command') as mock_run_command:
            var_1 = mock_run_command.return_value = (0, 'stdout', 'stderr')
            var_2 = main()
            assert var_2 == {'changed': True, 'name': 'apache2', 'status': {'started': {'stdout': 'stdout', 'rc': 0, 'stderr': 'stderr', 'changed': True}}}
            assert mock_run_command.call_count == 1

# Generated at 2022-06-25 03:33:54.280334
# Unit test for function main
def test_main():

    # Setup
    var_0 = AnsibleModule

    # Tested code
    var_1 = main()

    # Return results
    assert var_1 == None
    assert var_0 == 'ansible.module_utils.basic.AnsibleModule'


# Generated at 2022-06-25 03:33:55.090788
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 03:33:56.031895
# Unit test for function main
def test_main():
    mock_module = AnsibleModule
    assert True == True

# Generated at 2022-06-25 03:33:58.335355
# Unit test for function main
def test_main():
    var_0 = main()
    assert(var_0 == 'main')


# Generated at 2022-06-25 03:34:04.898758
# Unit test for function main
def test_main():
    var_check_mode = False
    var_pattern = None
    var_sleep = 1
    var_daemonize = False
    var_runlevels = None
    var_enabled = None
    var_state = None
    var_name = None
    var_arguments = None
    name = 'docker'
    state = 'started'
    enabled = True
    service = {
      'name': name,
      'state': state,
      'enabled': enabled
    }
    type_map = {
      'name': str,
      'state': str,
      'enabled': bool
    }
    try:
        var_check_mode = None
    except ModuleFailException as e:
        e.args[0]
    except Exception:
        pass