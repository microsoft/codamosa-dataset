

# Generated at 2022-06-25 03:28:18.448442
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-25 03:28:22.152553
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] is True:
            raise Exception("Test of function main failed because unexpected exception was raised")

# Collect all test cases in this file

# Generated at 2022-06-25 03:28:24.824141
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == main() or (var_0 != main() and var_0 == main())

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:28:31.979348
# Unit test for function main
def test_main():
    # Input params for function
    arguments = {}

    # Output returned from function
    output = main(**arguments)

    # Execute the function
    var_0 = test_case_0()

    # Check if the outputs are equal
    assert var_0 == output
    print("")
    print("Test Case Passed")

if __name__ == '__main__':
    test_main()