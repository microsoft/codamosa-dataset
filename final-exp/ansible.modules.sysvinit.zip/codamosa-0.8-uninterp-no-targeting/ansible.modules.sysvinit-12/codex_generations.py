

# Generated at 2022-06-20 22:46:53.320438
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize
    from ansible.module_utils.pycompat24 import get_exception
    # Setup

# Generated at 2022-06-20 22:47:04.909472
# Unit test for function main

# Generated at 2022-06-20 22:47:14.319058
# Unit test for function main
def test_main():
    ''' Unit test for function main '''
    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str'),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        runlevels=dict(type='list', elements='str'),
    ), required_one_of=[['state', 'enabled']],)
    module.exit_json = lambda: None
    main()

# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:24.533928
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:47:35.799615
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    import json
    import os
    import tempfile
    import sys

# Generated at 2022-06-20 22:47:45.655297
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:49.234159
# Unit test for function main
def test_main():
    try:
        main()
    except:
        #print("Error in main")
        assert False

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-20 22:48:00.884958
# Unit test for function main
def test_main():
    # Mock module input and exit
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
    )

    # Mock the results of module.get_bin_path()
    # This is needed because several methods are required

# Generated at 2022-06-20 22:48:09.966063
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-20 22:48:20.648774
# Unit test for function main
def test_main():
    filename = os.path.basename(__file__)
    print("Running unit tests for %s" % filename)
    print("===================================")

    # Define module parameters

# Generated at 2022-06-20 22:49:26.247044
# Unit test for function main

# Generated at 2022-06-20 22:49:38.208426
# Unit test for function main

# Generated at 2022-06-20 22:49:39.497440
# Unit test for function main
def test_main():
    pass



# Generated at 2022-06-20 22:49:41.850991
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:49.657357
# Unit test for function main
def test_main():
    ''' Test module main '''

    # We need to mock several items. Let us begin with AnsibleModule
    #import ansible.module_utils.basic
    #ansible.module_utils.basic.AnsibleModule = Mock()
    #ansible.module_utils.basic.AnsibleModule.return_value = Mock()
    #ansible.module_utils.basic.AnsibleModule.return_value.params = {'name': 'foo'}

    #import sysvinit
    #sysvinit.main()


# Generated at 2022-06-20 22:50:00.463562
# Unit test for function main
def test_main():

    from ansible.module_utils import basic
    from ansible.module_utils import service
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils import six

    if not six.PY3:
        import sys
        reload(sys)
        sys.setdefaultencoding('utf8')

    # Load arguments and results
    if ansible_version < '2.4':
        module_args = {
            "name": "apache2",
            "enabled": "true",
            }
        if module_result.get('failed'):
            test_result = False
        elif module_result.get('changed'):
            test_result = None
        else:
            test_result = True

# Generated at 2022-06-20 22:50:11.991590
# Unit test for function main
def test_main():
    # Test a good call with a basic service on an Ubuntu box
    # Return the actual parameters used by AnsibleModule
    def create_argument_spec():
        return dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
            supports_check_mode=True,
            required_one_of=[['state', 'enabled']],
        )
   

# Generated at 2022-06-20 22:50:21.142234
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.run_command = get_command_exit_values
    module.get_bin_path

# Generated at 2022-06-20 22:50:29.417880
# Unit test for function main

# Generated at 2022-06-20 22:50:37.887378
# Unit test for function main
def test_main():

    if sys.version_info[:2] < (2, 7):
        module = ansible_module_pre21()
    else:
        module = ansible_module_post21()

    # Replacing the standard exit_json and fail_json with something that records the calls
    module.exit_json = exit_json = lambda **kwargs: setattr(_test_main, 'exit_json', kwargs)
    module.fail_json = fail_json = lambda **kwargs: setattr(_test_main, 'fail_json', kwargs)

    # Make a reset function that resets all the recorded attributes on _test_main
    def reset():
        for key in ['exit_json', 'fail_json']:
            try:
                delattr(_test_main, key)
            except AttributeError:
                pass

    #

# Generated at 2022-06-20 22:52:44.580991
# Unit test for function main
def test_main():
    filename = 'my_file'
    with open(filename, 'w') as my_file:
        print("test file")
    def mock_run_command(cmd):
        if "update-rc.d" in cmd:
            return 0, cmd, ""
        elif "chkconfig" in cmd:
            return 0, cmd, ""
        elif "service" in cmd:
            return 0, cmd, ""
        elif "status" in cmd:
            return 0, cmd, ""
        else:
            return 0, cmd, ""

    mock_module = Mock()
    mock_module.run_command = mock_run_command
    mock_module.exit_json = Mock()
    mock_module.fail_json = Mock()
    main()

# Generated at 2022-06-20 22:52:45.705393
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        result = main()
        assert result == 0


# Generated at 2022-06-20 22:52:57.342632
# Unit test for function main
def test_main():
    """ main unit test"""
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda self, **kwargs: True
    module.run_command = lambda self, **kwargs: (0, b"", b"")
    module.daemonize = lambda self, **kwargs: (0, b"", b"")
    module.sysexit = lambda self, **kwargs: True
    module.fail_json = lambda self, **kwargs: True
    module.get_bin_path = lambda self, **kwargs: "/bin"

# Generated at 2022-06-20 22:53:09.410101
# Unit test for function main
def test_main():
    m = AnsibleModule(
        dict(
            name='foo',
            state='started',
            enabled=False,
            sleep=1,
            pattern='',
            arguments='',
            runlevels=[],
            daemonize=True,
        ),
        check_mode=False,
        required_one_of=[['state', 'enabled']],
    )
    # unit, not integration
    m.get_bin_path = lambda x, opt_dirs=None: True
    m.run_command = lambda x: (0, '', '')
    m.fail_json = lambda **kwargs: True

    main()
# END Unit test for function main


# BEGIN Unit test for function main
if __name__ == '__main__':
    import doctest
    from ansible.module_utils.basic import Ansible

# Generated at 2022-06-20 22:53:21.678634
# Unit test for function main
def test_main():
    from ansible.module_utils.service import sysv_exists
    from ansible.module_utils.basic import AnsibleModule
    from mock import patch

    service_name = "dummy-service"
    service_state = "started"

    def side_effect(*args):
        return service_name

    def side_effect_exists(*args):
        return True

    with patch('ansible.module_utils.service.sysv_exists', side_effect_exists):
        with patch('ansible.module_utils.service.get_sysv_script', side_effect):
            args = dict(
                name=service_name,
                state=service_state,
            )
            module = AnsibleModule(argument_spec={})
            module.params = args

# Generated at 2022-06-20 22:53:31.950053
# Unit test for function main
def test_main():
    print("Test for main function")
    module_args = dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']]
    )
    main()


# Generated at 2022-06-20 22:53:43.445620
# Unit test for function main
def test_main():
    test_args = dict(
        name='httpd',
        pattern='apache2',
    )
    argv = ['main', '-m', '/usr/local/lib/python2.7/dist-packages/ansible', '-v']
    argv.extend(['-a', json.dumps(test_args)])


# Generated at 2022-06-20 22:53:45.040152
# Unit test for function main
def test_main():
    # FIXME
    pass

# Import module snippets
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:54.333229
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

# Generated at 2022-06-20 22:53:59.783097
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    class MyTestClass(object):
        def __init__(self):
            self.paths