

# Generated at 2022-06-20 22:46:38.226154
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:46:45.687173
# Unit test for function main
def test_main():
    '''
    Unit test for function main
    '''
    # check if required options are present
    obj = AnsibleModule({}, {})
    assert obj.params['state'] == None

    # check if required options are present
    obj = AnsibleModule({}, {'enabled': True})
    assert obj.params['state'] == None

    # check if required options are present
    obj = AnsibleModule({}, {'state' : 'started'})
    assert obj.params['state'] != None


# Generated at 2022-06-20 22:46:49.822667
# Unit test for function main
def test_main():
  try:
    main()
  except SystemExit as inst:
    if inst.args[0] == 0:
      pass
    else:
      raise


if __name__ == '__main__':
  from ansible.module_utils.basic import *
  main()

# Generated at 2022-06-20 22:47:01.550313
# Unit test for function main
def test_main():
    from ansible.module_utils.common.text_compare import tc
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.service import sysv_is_enabled

    module_args = {
        'name': 'iptables',
        'enabled': True,
    }


# Generated at 2022-06-20 22:47:09.910296
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import random
    import shutil
    import copy
    from ddt import ddt, data
#
# unique module name
#
    os.environ["ANSIBLE_MODULE_NAME"] = "test_module_%d" % random.randint(0, 99999999999)
#
#  create temporary module dir to use with ANSIBLE_LIBRARY
#
    module_dir = tempfile.mkdtemp()
    ansible_library_dir = os.path.join(module_dir, 'ansible_module')
    os.makedirs(ansible_library_dir)
    ansible_library_dir_file = os.path.join(ansible_library_dir, '__init__.py')

# Generated at 2022-06-20 22:47:20.052295
# Unit test for function main
def test_main():
    import os
    import platform
    import subprocess
    import mock
    import shutil

    if 'VIRTUAL_ENV' in os.environ:
        test_dir = '/tmp/test_sysvinit_%s' % str(os.getpid())
        os.environ['PATH'] = '/usr/bin:/bin/usr/bin'

        shutil.copytree(
            os.environ['VIRTUAL_ENV'] + '/lib/python2.7/site-packages/ansible/modules/system',
            test_dir
        )

        old_cwd = os.getcwd()
        os.chdir(test_dir)

    m_module = mock.MagicMock()
    m_module.check_mode = False
    m_module.debug = False
    m_module.run_

# Generated at 2022-06-20 22:47:28.399154
# Unit test for function main
def test_main():
    if os.path.exists('/etc/init.d/exim'):
        module = AnsibleModule(
            argument_spec=dict(
                name=dict(required=True, type='str', aliases=['service']),
                state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
                enabled=dict(type='bool'),
                sleep=dict(type='int', default=1),
                pattern=dict(type='str'),
                arguments=dict(type='str', aliases=['args']),
                runlevels=dict(type='list', elements='str'),
                daemonize=dict(type='bool', default=False),
            ),
            supports_check_mode=True,
            required_one_of=[['state', 'enabled']],
        )
        module

# Generated at 2022-06-20 22:47:32.999230
# Unit test for function main
def test_main():
    argv = ['--name', 'apache2', '--state', 'started']
    argv += ['--enabled', 'yes']
    argv += ['--runlevels', '3', '5']
    argv += ['--sleep', '1']
    argv += ['--pattern', 'httpd']
    argv += ['--arguments', '']
    argv += ['--daemonize', 'False']
    (rc, out, err) = main(argv)
    assert rc == 0
    assert out != ""
    assert err == ""

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:43.919933
# Unit test for function main
def test_main():
    module = AnsibleModule(
            argument_spec=dict(
                name=dict(required=False, type='str', aliases=['service']),
                state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
                enabled=dict(type='bool'),
                sleep=dict(type='int', default=1),
                pattern=dict(type='str'),
                arguments=dict(type='str', aliases=['args']),
                runlevels=dict(type='list', elements='str'),
                daemonize=dict(type='bool', default=False),
            ),
            supports_check_mode=True,
            required_one_of=[['state', 'enabled']],
        )
    rc, out, err = main()

# Generated at 2022-06-20 22:47:50.902179
# Unit test for function main
def test_main():

    # Mock AnsibleModule's run_command
    #m = MagicMock()
    #m.run_command.return_value = ('returncode', 'stdout', 'stderr')
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Mock AnsibleModule's get_bin_path()
    def get_bin_path(bin, opt_dirs=None):
        return "/usr/bin/" + bin
    setattr(module, 'get_bin_path', get_bin_path)

    # Mock AnsibleModule's run_command()

    class RunCommand(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err


# Generated at 2022-06-20 22:49:40.705793
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:47.771581
# Unit test for function main
def test_main():
    """
    function: test_main

    Purpose:
        Test the sysvinit module.

    Return:
        None
    """
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled
    from ansible.module_utils.service import get_sysv_script
    from ansible.module_utils.service import sysv_exists
    from ansible.module_utils.service import fail_if_missing
    from ansible.module_utils.service import get_ps
    from ansible.module_utils.service import daemonize


# Generated at 2022-06-20 22:49:56.596011
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.exit_json(main(module))


# Generated at 2022-06-20 22:50:08.688729
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # str(dict)

# Generated at 2022-06-20 22:50:17.667073
# Unit test for function main
def test_main():
    import os
    import sys
    import pytest
    import types
    import shutil
    import tempfile
    import subprocess
    import filecmp
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize
    from ansible.module_utils.common.collections import ImmutableDict

    (fd, path) = tempfile.mkstemp()


# Generated at 2022-06-20 22:50:18.302759
# Unit test for function main
def test_main():
    ...

# Generated at 2022-06-20 22:50:27.435964
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    # Dummy values for module args
    module_args = {
        'name': 'dummy',
        'state': 'started',
        'enabled': True,
        'sleep': 1,
        'pattern': None,
        'arguments': None,
        'runlevels': [
            '3',
            '5'
        ],
        'daemonize': False
    }
    # Create a fake module to use as a mock
    module = AnsibleModule(argument_spec=module_args)
    # Mock function call
    def get_sysv_script(name):
        return '/etc/init.d/%s' %name

    def sysv_exists(name):
        return '/etc/init.d/%s' %name


# Generated at 2022-06-20 22:50:36.653301
# Unit test for function main
def test_main():
    print("Started unit test for function main")
    testArgs = dict({
        "name": "apache2",
        "state": "started",
        "enabled": True,
        "sleep": 1,
        "pattern": None,
        "arguments": None,
        "runlevels": None,
        "daemonize": False,
        "_ansible_check_mode": True,
        "_ansible_diff": False,
        "_ansible_verbosity": 0,
        "changed": True,
        "active": True
    })
    # print(sysvinit.main(None, testArgs))

# Generated at 2022-06-20 22:50:45.736014
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:50:56.494681
# Unit test for function main
def test_main():
    # module = AnsibleModule( argument_spec = dict (
    #     name=dict(required=True, type='str', aliases=['service']),
    #     state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
    #     enabled=dict(type='bool'),
    #     sleep=dict(type='int', default=1),
    #     pattern=dict(type='str'),
    #     arguments=dict(type='str', aliases=['args']),
    #     runlevels=dict(type='list', elements='str'),
    # ), supports_check_mode=True, required_one_of=[['state', 'enabled']])
    # main()
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:02.404218
# Unit test for function main
def test_main():

    test_dir = os.path.dirname(os.path.abspath(__file__))
    module = AnsibleModule(argument_spec={
        'name': {'required': True, 'type': 'str'},
        'state': {'required': True, 'type': 'str'},
        'enabled': {'required': True, 'type': 'bool'},
    })

    def run_command_result(return_code, stdout_content=None, stderr_content=None):
        module.run_command_result = {
            'rc': return_code,
            'stdout_lines': stdout_content,
            'stderr_lines': stderr_content
        }

    def run_command_check_result(mock_module_class, cmd, **kwargs):
        run_

# Generated at 2022-06-20 22:53:13.940711
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    ###########################################################################
    # BEGIN: Enable/Disable

# Generated at 2022-06-20 22:53:26.123474
# Unit test for function main
def test_main():
    # mock module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-20 22:53:34.691945
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    test_module.run_command = mock_run_command
    test_module.get

# Generated at 2022-06-20 22:53:41.180535
# Unit test for function main
def test_main():
    from ansible.modules.system.sysvinit import main as sysvinit_main
    from ansible.module_utils.basic import AnsibleModule

    with open('./test/unit/modules/system/test_sysvinit.py') as data_file:
        data = json.load(data_file)

    module = AnsibleModule(argument_spec=data['arguments'])
    sysvinit_main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:49.800561
# Unit test for function main
def test_main():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps


# Generated at 2022-06-20 22:53:57.103003
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-20 22:54:05.207354
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        )
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:54:13.297435
# Unit test for function main
def test_main():
    # Mock the module.
    class ModuleMock(object):
        def __init__(self):
            pass
        def get_bin_path(*args):
            return "mock"
        def fail_json(*args):
            raise Exception("module.fail_json was called")
        def warn(*args):
            raise Exception("module.warn was called")
        def run_command(*args):
            return (0, '', '')
    module = ModuleMock()
    # Mock the action.
    def runme(*args):
        return (0, '', '')
    # Mock the enable/disable action.
    def enableme(*args):
        return True
    def disableme(*args):
        return False
    # Mock the service management tool
    def sysv_exists(*args):
        return True

# Generated at 2022-06-20 22:54:19.579428
# Unit test for function main
def test_main():
    # Read in unit test data
    with open('/home/leo/ansible_modules/system/init/tests/unit/system/init/data/main.json') as unit_test_data:
        unit_test_orig_data = json.loads(unit_test_data.read())
        orig_update_rc_d = unit_test_orig_data['update_rc_d']

        # Mock update_rc_d command
        class Mock(object):
            """docstring for Mock"""
            def __init__(self, inp):
                super(Mock, self).__init__()
                self.inp = inp
