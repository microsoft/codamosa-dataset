

# Generated at 2022-06-20 22:46:38.509735
# Unit test for function main
def test_main():
    result = {}
    params = create_params()
    result = main(params)
    params = check_result(result, params)


# Generated at 2022-06-20 22:46:48.278228
# Unit test for function main
def test_main():

    results = {
        'changed': True,
        'status': {
            'enabled': {
                'changed': True,
                'rc': 0,
                'stdout': None,
                'stderr': None,
            },
            'stopped': {
                'changed': True,
                'rc': 0,
                'stdout': 'stdout data',
                'stderr': '',
            },
        }
    }

    mock_run_command = MagicMock(return_value=(3, results['status']['stopped']['stdout'], results['status']['stopped']['stderr']))


# Generated at 2022-06-20 22:46:59.041971
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={})
    serviceList = [
        {
            'name': 'sshd',
            'action': 'started',
            'enabled': True
        },
        {
            'name': 'sshd',
            'action': 'started',
            'enabled': False
        },
        {
            'name': 'sshd',
            'action': 'stopped',
            'enabled': True
        },
        {
            'name': 'sshd',
            'action': 'stopped',
            'enabled': False
        },
    ]
    # Use the module to calculate main result.
    main()
    # Test the main function
    main()



# Generated at 2022-06-20 22:47:07.815129
# Unit test for function main
def test_main():
    arg_spec = dict(name=dict(required=True, type='str', aliases=['service']),
                    state =dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
                    enabled=dict(type='bool'),
                    sleep=dict(type='int', default=1),
                    pattern=dict(type='str'),
                    arguments=dict(type='str', aliases=['args']),
                    runlevels=dict(type='list', elements='str'),
                    daemonize=dict(type='bool', default=False),
                    )
    module = AnsibleModule(argument_spec=arg_spec, supports_check_mode=True,
                           required_one_of=[['state', 'enabled']])
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:18.406927
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    print("***Calling main***")
    return main(module)


# Generated at 2022-06-20 22:47:27.094688
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:37.878438
# Unit test for function main
def test_main():

    # Import the module infra
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
        ),
        supports_check_mode=True,
    )

    # Define mock arguments
    name = 'ansible'
    action = 'stopped'
    enabled = False

# Generated at 2022-06-20 22:47:47.721726
# Unit test for function main
def test_main():
    # mock
    import ansible.module_utils.basic
    import os.path
    import tempfile
    import shutil

    class MockModule(object):
        def __init__(self):
            self.params = {
                        "arguments": None,
                        "daemonize": False,
                        "enabled": None,
                        "name": "service_name",
                        "pattern": None,
                        "runlevels": [],
                        "sleep": 1,
                        "state": None,
                        "_ansible_check_mode": False,
                        "_ansible_diff": False,
                        "_ansible_module_name": "service",
                        "_ansible_version": "2.9.2"
                    }
            self.check_mode = False

# Generated at 2022-06-20 22:47:59.576277
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.params['name'] = 'jenkins'

# Generated at 2022-06-20 22:48:09.657159
# Unit test for function main
def test_main():
    module = AnsibleModule({'name': 'test_service','state': 'reloaded','enabled': True,'sleep': 2,'pattern': '','runlevels': [],'daemonize': False}, check_mode=True)
    module.run_command = mock.Mock(return_value=(0, '', ''))
    module.get_bin_path = mock.Mock(return_value='/bin/service')
    module.warn = mock.Mock()
    module.fail_json = mock.Mock()
    module.exit_json = mock.Mock()
    main()
    module.run_command.assert_any_call('/bin/service test_service reload')
    module.warn.assert_called_once_with("Unable to determine service status")
    module.fail_json.assert_not_called()
    module

# Generated at 2022-06-20 22:49:09.304346
# Unit test for function main
def test_main():

    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    import sys
    import os

    # -*- -*- -*- End included

# Generated at 2022-06-20 22:49:17.096386
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
if __name__ == '__main__':
    test_main()
# main()

# Generated at 2022-06-20 22:49:20.945512
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json(changed=True, original_message='foo', message='bar')

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:26.850348
# Unit test for function main
def test_main():
    # See if failure/success cases are covered
    pass
# END unit test for function main


# begin execution
if __name__ == '__main__':
    # run unit tests if in debug run mode
    if __debug__:
        try:
            test_main()
        except:  # pylint: disable=bare-except
            import traceback
            traceback.print_exc()
            raise
    # get args, call main
    main()

# Generated at 2022-06-20 22:49:38.716337
# Unit test for function main
def test_main():

    # Setup the AnsibleModule stub.
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ))
    # Construct the params
    params = dict()
    params['name'] = 'redis'
    params['state'] = 'started'
    params['enabled'] = True
    params

# Generated at 2022-06-20 22:49:50.999772
# Unit test for function main
def test_main():
    from sys import argv
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize
    from ansible.module_utils.service import complex_args, safe_eval
    from ansible.module_utils.six import PY2
    import imp
    import os
    import sys

    if PY2:
        open_func = '__builtin__.open'
    else:
        open_func = 'builtins.open'

    if not os.path.isfile(argv[0]):
        print("FATAL: no such file: %s" % argv[0])
       

# Generated at 2022-06-20 22:50:01.278419
# Unit test for function main
def test_main():
    name = "tomcat"
    action = "started"
    enable= False
    runlevels = []
    pattern = ""
    sleep_for = "1"
    daemonize=False
    rc = 0
    out = err = ""
    result = {
        'name': name,
        'changed': False,
        'status': {}
    }
    # ensure service exists, get script name
    fail_if_missing(module, sysv_exists(name), name)
    script = get_sysv_script(name)

    # locate binaries for service management
    paths = ['/sbin', '/usr/sbin', '/bin', '/usr/bin']
    binaries = ['chkconfig', 'update-rc.d', 'insserv', 'service']
    runlevel_status = {}
    location = {}

# Generated at 2022-06-20 22:50:12.624753
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # Set up parameters
    name = module.params['name']

# Generated at 2022-06-20 22:50:22.295248
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.exit_json(**main())


# Generated at 2022-06-20 22:50:32.234546
# Unit test for function main
def test_main():
  module = AnsibleModule({'name': 'test', 'state': 'started', 'enabled': False, 'sleep': 1, 'runlevels': ['3', '4'], 'arguments': 'test', 'pattern': 'test', 'daemonize': False}, check_mode=False)
  assert main() == module.exit_json(attempts=1, changed=False, name='test', status={'enabled': {'changed': True, 'rc': None, 'stderr': None, 'stdout': None, 'runlevels': ['3', '4']}, 'started': {'changed': False, 'rc': None, 'stderr': None, 'stdout': None}})

# Generated at 2022-06-20 22:52:36.131033
# Unit test for function main
def test_main():
    import sys, imp
    path = imp.find_module("sysvinit", sys.path)
    test_sysvinit = imp.load_module("test_sysvinit", *path)
    # Try an example command
    test_sysvinit.main(args=[]);


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:52:48.656616
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
        ),
        required_one_of=[['state', 'enabled']],
    )
    module.exit_json(**main())

# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:52:50.204937
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:52:55.167576
# Unit test for function main
def test_main():

    import os
    class AnsibleModuleFake(object):

        def __init__(self):
            self.result = dict(
                changed=False,
                status=dict()
            )
            self.params = dict(
                name='sysvinit_test',
                state='started',
                sleep=0,
                daemonize=False
            )

        def exit_json(self, **kwargs):
            self.result = kwargs

        def run_command(self, cmd):
            return 0, '', ''

        def get_bin_path(self, cmd, opt_dirs=None):
            if cmd == 'service':
                return os.path.join(os.path.dirname(os.path.realpath(__file__)), 'unit_tests', 'fake_service.sh')
            return True


# Generated at 2022-06-20 22:53:07.134486
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']
    enabled = module.params['enabled']
    runlevels = module

# Generated at 2022-06-20 22:53:18.377185
# Unit test for function main
def test_main():
    name = "test"
    action = "restarted"
    enabled = "yes"
    runlevels = ["3", "5"]

# Generated at 2022-06-20 22:53:23.677861
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ))
    module.main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:33.319945
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    #sys.

# Generated at 2022-06-20 22:53:37.373124
# Unit test for function main
def test_main():
    ''' placeholder for tests '''
    iolog = StringIO()
    with redirect_stdout(iolog):
        main()
    iolog.getvalue()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:46.812261
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.run_command = lambda *args, **kwargs: (0, "", "")
