

# Generated at 2022-06-20 22:46:41.768158
# Unit test for function main
def test_main():
    # assume --no-check-mode
    # init_paths()
    # ForkingTestClient()
    main()



if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:46:53.589130
# Unit test for function main
def test_main():
    # Copy of source to test
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    import platform

# Generated at 2022-06-20 22:47:05.145258
# Unit test for function main
def test_main():

    args = dict(
        name='apache2',
        state='started',
        enabled='yes',
        sleep='1',
        pattern='apache2',
        arguments='apache2',
        runlevels=['3','5'],
        daemonize='True'
    )


# Generated at 2022-06-20 22:47:14.589748
# Unit test for function main
def test_main():
    module = AnsibleModule({
        "name": "apache2",
        "state": "started",
        "enabled": True,
        "sleep": 1,
        "pattern": None,
        "arguments": None,
        "runlevels": None,
        "daemonize": False,
    })

    main()

    module.exit_json(changed=True, status={"enabled":{"changed":True, "rc":0, "stdout": "", "stderr": ""}, "started":{"changed":True, "rc":0, "stdout": "", "stderr": ""}})

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:23.498866
# Unit test for function main
def test_main():
    # The following command line arguments are in the format of a list containing
    # the arguments as simple strings.

    argv = [
        """
        ---
        name: apache2
        state: started
        enabled: yes
        runlevels:
            - 3
            - 5
        """,
    ]

    results = []

# Generated at 2022-06-20 22:47:28.190444
# Unit test for function main
def test_main():
    print("Running main function")

    module.params['state'] = 'started'
    module.params['enabled'] = True

    # run the module
    main()


# import module snippets
from ansible.module_utils.basic import *

if __name__ == "__main__":
    main()

# Generated at 2022-06-20 22:47:31.574959
# Unit test for function main
def test_main():
    test_args = {
        'state': 'started',
        'enabled': True,
        'sleep': 1,
        'pattern': '',
        'arguments': '',
        'runlevels': '',
        'daemonize': False,
    }
    test_args.update({"name": "apache2"})
    a = main(test_args)
    assert a


# Generated at 2022-06-20 22:47:42.341810
# Unit test for function main
def test_main():
    testmodule = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    testmodule.run_command = run_command

# Generated at 2022-06-20 22:47:43.871769
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:44.853370
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-20 22:49:28.910549
# Unit test for function main
def test_main():
    argv = [
        '',
        '-s',
        '-v',
        '-C',
        '-W',
        '-m',
        'setup',
        '-a',
        '"filter=ansible_distribution*"',
        '-a',
        '"gather_subset=!all,!any"'
    ]
    from sys import argv
    from os import chdir
    chdir('..')
    main()

# Generated at 2022-06-20 22:49:30.516377
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:39.227571
# Unit test for function main
def test_main():
    # Test module with arguments
    arguments = dict(
        name='apache2',
        state='started',
        enabled=True,
    )
    # The AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode
    module = AnsibleModule(argument_spec=arguments)

    # when the module is called we will instantly create a new AnsibleModule
    # object
    after_main()
    module.exit_json(changed=False, original_message='', message='')


# Generated at 2022-06-20 22:49:41.791936
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()


# Generated at 2022-06-20 22:49:52.495009
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-20 22:50:01.404835
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False)
    )
    )
    sysvinit = main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:50:12.767470
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
        'name': dict(required=True, type='str', aliases=['service']),
        'state': dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        'enabled': dict(type='bool'),
        'sleep': dict(type='int', default=1),
        'pattern': dict(type='str'),
        'arguments': dict(type='str', aliases=['args']),
        'runlevels': dict(type='list', elements='str'),
        'daemonize': dict(type='bool', default=False),
    },
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.params['name'] = 'apache2'
    module.params

# Generated at 2022-06-20 22:50:21.666476
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:50:32.915012
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # the following is to get around the request for import, likely a bug
    module.run_

# Generated at 2022-06-20 22:50:33.912543
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:54:26.531481
# Unit test for function main
def test_main():
    test_sysv_is_enabled = {
        'got_enabled': True,
        'return_code': 0,
        'stderr': '',
        'stdout': '2:on\n3:on\n4:on\n5:on\n'
    }
    test_sysv_exists = {
        'got_script': True,
        'return_code': 0,
        'stderr': '',
        'stdout': '/etc/init.d/iptables\n'
    }
    test_get_ps = {
        'process_count': 1,
        'return_code': 0,
        'stderr': '',
        'stdout': '32709 ?        00:00:08 iptables-restore\n'
    }
    test_daemonize

# Generated at 2022-06-20 22:54:33.970840
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._json_compat import json
    from ansible.module_utils.common.removed import removed_module
    import sys

    def test_function_import(module):
        return True


# Generated at 2022-06-20 22:54:39.747579
# Unit test for function main
def test_main():
    try:
        from unittest.mock import patch
        from unittest.mock import MagicMock
        from unittest.mock import Mock
    except ImportError:
        from mock import patch
        from mock import MagicMock
        from mock import Mock
    import imp

    class TestException(Exception):
        pass

    # this is the magic
    main_path = imp.load_source('', 'module')
    main_obj = main_path.main()

    # unit tests begin
    # test functions in src/main.py
    mock_module = patch.multiple(main_path, module=MagicMock(), exit_json=MagicMock(), fail_json=MagicMock())

    # create mock objects
    mock_module.start()

    # start to test main() function
    # case 1: when required_

# Generated at 2022-06-20 22:54:48.063433
# Unit test for function main
def test_main():
    # Unit test for function main
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
            state = dict(choices=['started', 'stopped', 'restarted', 'reloaded']),
            enabled = dict(),
            sleep = dict(type='int'),
            pattern = dict(),
            arguments = dict(),
            runlevels = dict(type='list', elements='str'),
            daemonize = dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
    )

    # Unit test for function main
    module.params['name'] = 'service'
    module.params['state'] = 'started'
    module.params['enabled'] = True
    module.params['sleep'] = 0
    module.params['pattern'] = ''

# Generated at 2022-06-20 22:54:56.455673
# Unit test for function main
def test_main():

    class Args(dict):
        def __init__(self, *args, **kwargs):
            super(Args, self).__init__(*args, **kwargs)
            self.__dict__ = self


# Generated at 2022-06-20 22:55:07.504875
# Unit test for function main
def test_main():

  module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )



# Generated at 2022-06-20 22:55:15.706602
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:55:16.688104
# Unit test for function main
def test_main():

    with pytest.raises(SystemExit):
        main()



# Generated at 2022-06-20 22:55:18.336888
# Unit test for function main
def test_main():
    with pytest.raises(Exception):
        main()

# Generated at 2022-06-20 22:55:21.793721
# Unit test for function main
def test_main():
    import sys
    main()
    sys.stdout.close()
    sys.exit(0)

if __name__ == '__main__':
    main()