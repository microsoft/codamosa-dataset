

# Generated at 2022-06-20 22:46:48.350748
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'name': {'required': True, 'type': 'str'}, 'state': {'choices': ['started', 'stopped', 'restarted', 'reloaded'], 'type': 'str'}, 'enabled': {'type': 'bool'}, 'sleep': {'type': 'int', 'default': 1}, 'pattern': {'type': 'str'}, 'arguments': {'type': 'str', 'aliases': ['args']}, 'runlevels': {'type': 'list', 'elements': 'str'}, 'daemonize': {'type': 'bool', 'default': False}})

# Generated at 2022-06-20 22:47:01.128621
# Unit test for function main
def test_main():
    modules = get_examples_from_docs(examples)
    result = {}
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main

# Generated at 2022-06-20 22:47:09.723740
# Unit test for function main
def test_main():
    # Mock module args and params
    args = dict(
        name="name",
        state=None,
        enabled=None,
        sleep=1,
        pattern='pattern',
        arguments='arguments',
        runlevels=['runlevels'],
        daemonize=False
    )


# Generated at 2022-06-20 22:47:19.933480
# Unit test for function main
def test_main():
    # The following are some of the things that the function wraps
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize
    import ansible
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 22:47:28.307524
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:47:34.147141
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.exit_json(**main())


# Generated at 2022-06-20 22:47:45.085516
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.process import get_bin_path

    # Prepare arguments for module.run_command
    def get_bin_path_side_effect(binary, opt_dirs=[]):
        if binary == 'service':
            return binary
        elif binary == 'chkconfig':
            return binary

    def run_command_side_effect(args, **kwargs):
        if args == 'service apache2 status':
            return 0, '', ''
        elif args == 'apache2 status':
            return 0, '', ''
        elif args == 'apache2 start':
            return 0, '', ''
        elif args == 'apache2 stop':
            return 0, '', ''

# Generated at 2022-06-20 22:47:57.372235
# Unit test for function main
def test_main():
    from ansible.modules.system.service import main

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

# Generated at 2022-06-20 22:48:01.744936
# Unit test for function main
def test_main():
    options = dict(
        name=['acpid'],
        state=['restarted'],
        enabled=['yes'],
        sleep=['1'],
        pattern=['ifconfig'],
        arguments=['arg1'],
        runlevels=[''],
        daemonize=['no'],
    )
    assert main(options)

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:48:05.021719
# Unit test for function main
def test_main():
    import sys
    sys.path.append('/home/dongl/src/devops/mysite')
    import ansible_test
    ansible_test.execute_ansible_module(sys.modules[__name__])



# Generated at 2022-06-20 22:49:06.997327
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()


# import module snippets
from ansible.module_utils.basic import *

# Generated at 2022-06-20 22:49:13.651889
# Unit test for function main
def test_main():
    test_mod = AnsibleModule({
        "name": "ansible_test",
        "state": "stopped",
        "enabled": True,
        "sleep": 1,
        "pattern": "",
        "arguments": "",
        "runlevels": [],
        "daemonize": False,
        "DEBUG": True
    })

    test_mod.sysv_exists = (lambda x: True)
    test_mod.sysv_is_enabled = (lambda x: True)
    test_mod.get_bin_path = (lambda x: '/bin/service')
    test_mod.get_ps = (lambda x: False)
    test_mod.run_command = (lambda x: (0, '', ''))

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:25.295008
# Unit test for function main
def test_main():
    from ansible.modules.system.sysvinit import main
    module_args = dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    )
    out = dict(
        name=name,
        changed=False,
        status={}
    )

# Generated at 2022-06-20 22:49:26.502515
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:38.504462
# Unit test for function main
def test_main():
    # Service already started
    module = AnsibleModule(
                argument_spec=dict(
                    name=dict(required=True, type='str', aliases=['service']),
                    state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
                    enabled=dict(type='bool'),
                    sleep=dict(type='int', default=1),
                    pattern=dict(type='str'),
                    arguments=dict(type='str', aliases=['args']),
                    runlevels=dict(type='list', elements='str'),
                    daemonize=dict(type='bool', default=False),
                ),
                supports_check_mode=True,
                required_one_of=[['state', 'enabled']],
            )

    name = "sshd"
    module.params['name'] = name

# Generated at 2022-06-20 22:49:50.810323
# Unit test for function main
def test_main():
    test_name = "test_main"

    # create a mock module with all args set to none
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-20 22:49:51.507854
# Unit test for function main
def test_main():

    return

# Generated at 2022-06-20 22:50:01.088303
# Unit test for function main
def test_main():
  module_args = {
    "name": "",
    "state": "",
    "enabled": "",
    "sleep": "",
    "pattern": "",
    "arguments": "",
    "runlevels": "",
    "daemonize": ""
  }
  def mock_run_command(self, cmd, tmp_path, delete_remote_tmp=False):
    return 123, "stdout", "stderr"
  module = Mock()
  module.params = module_args
  module.get_bin_path = Mock()
  module.run_command = Mock(side_effect=mock_run_command)
  module.warn = Mock()
  module.fail_json = Mock()
  main()


# Generated at 2022-06-20 22:50:12.487694
# Unit test for function main
def test_main():
    print("===== test_main =====")
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    name = 'ssl-client'
    action = 'reloaded'
   

# Generated at 2022-06-20 22:50:23.391639
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = 'sysvinit'
   

# Generated at 2022-06-20 22:52:35.257461
# Unit test for function main
def test_main():
    # Just create a temporary module to use, then destroy it after the test
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # Create some test value

# Generated at 2022-06-20 22:52:42.812397
# Unit test for function main
def test_main():
    from ansible.modules.system.sysvinit import main
    import os

    # load in test vars (inventory)
    script_dir = os.path.dirname(os.path.realpath(__file__))
    test_vars = {"inventory_hostname": "localhost"}
    test_vars_path = os.path.join(script_dir, 'test_vars.json')
    if os.path.isfile(test_vars_path):
        with open(test_vars_path) as f:
            test_vars = json.load(f)

    # test results
    results = main(dict(
        name='sshd',
        state='started',
        enabled=True,
        runlevels=None,
    ), test_vars)

    # expect service state to be started (false

# Generated at 2022-06-20 22:52:55.501209
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:53:08.133686
# Unit test for function main
def test_main():
    func_args = dict(
        name='apache2',
        state='stopped',
        enabled=False,
        sleep=1,
        pattern='',
        arguments='',
        runlevels=['3', '5'],
        daemonize=False,
    )
    [rc, result] = main(func_args, True)
    assert rc == 'changed'
    assert result['results']['changed'] == True
    assert result['results']['status'] == {'enabled': {'rc': 0, 'stdout': None, 'stderr': None, 'changed': False}, 'stopped': {'rc': 0, 'stdout': None, 'stderr': None, 'changed': False}}
    assert result['results']['name'] == 'apache2'



# Generated at 2022-06-20 22:53:20.015615
# Unit test for function main
def test_main():
    test_action_common_attributes = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-20 22:53:30.851768
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.exit_json = lambda **kwargs: kwargs

# Generated at 2022-06-20 22:53:31.773747
# Unit test for function main

# Generated at 2022-06-20 22:53:35.327851
# Unit test for function main
def test_main():
    # (data, expected_output[, msg])
    # TODO: Write unit tests for this module
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:45.385013
# Unit test for function main
def test_main():

    #import ansible.modules.system.service.py

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# import module snippets

# Generated at 2022-06-20 22:53:54.887685
# Unit test for function main
def test_main():
    import sys
    import os
    import random
    import string
    import shutil

    # generate a temporary file
    # this file is written in the system temp directory and removed at exit
    tmp_file = os.path.join(os.environ.get('TMPDIR', '/tmp'), ''.join(random.choice(string.ascii_uppercase) for x in range(10)))

    # write a temp file to the system temp directory
    # this file is removed at exit
    with open(tmp_file, "w") as f:
        f.write('')


    module = AnsibleModule({})
    module.sysvinit()

    # test if the temorary file exists
    assert os.path.exists(tmp_file)

    # remove the temporary file
    os.remove(tmp_file)
