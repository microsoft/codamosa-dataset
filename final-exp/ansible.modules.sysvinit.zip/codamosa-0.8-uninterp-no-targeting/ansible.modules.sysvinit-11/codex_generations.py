

# Generated at 2022-06-20 22:46:51.660365
# Unit test for function main
def test_main():

    from ansible.module_utils.basic import AnsibleModule, load_platform_subclass
    import ansible.module_utils.service

    module = AnsibleModule(argument_spec={'state': dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'), 'enabled': dict(type='bool'), 'sleep': dict(type='int', default=1), 'pattern': dict(type='str'), 'arguments': dict(type='str', aliases=['args']), 'runlevels': dict(type='list', elements='str'), 'daemonize': dict(type='bool', default=False), 'name': dict(required=True, type='str', aliases=['service'])}, supports_check_mode=True, required_one_of=[['state', 'enabled']])


# Generated at 2022-06-20 22:47:03.366901
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:15.316678
# Unit test for function main
def test_main():
    # The following arguments are not used by the module
    module_args = dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
        check_mode=dict(type='bool', default=False),
        diff_mode=dict(type='bool', default=False),
        platform=dict(type='str', default='posix'),
    )


# Generated at 2022-06-20 22:47:18.542540
# Unit test for function main
def test_main():
  mock_module = Mock(return_value = None)
  mock_module.params = {'state':'started'}
  main()
  assert mock_module.exit_json.called

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:27.204179
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'name': {'required': True, 'type': 'str'}, 'state': {'choices': ['started', 'stopped', 'restarted', 'reloaded'], 'type': 'str'}, 'enabled': {'type': 'bool'}, 'sleep': {'type': 'int', 'default': 1}, 'pattern': {'type': 'str'}, 'arguments': {'type': 'str', 'aliases': ['args']}, 'runlevels': {'type': 'list', 'elements': 'str'}, 'daemonize': {'type': 'bool', 'default': False}}, supports_check_mode=True)
    try:
        main()
    except:
        print('main exception')

# import module snippets
from ansible.module_utils.basic import *


# Generated at 2022-06-20 22:47:37.957400
# Unit test for function main
def test_main():
    import sys
    import json

    # prep result

# Generated at 2022-06-20 22:47:47.756912
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec = dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    test_service = test_module.params['name']


# Generated at 2022-06-20 22:47:59.146620
# Unit test for function main
def test_main():
    module = AnsibleModule( argument_spec = dict(
            name = dict(required = True, type = 'str'),
            state = dict(choices = ['started', 'stopped', 'restarted', 'reloaded'], type = 'str'),
            enabled = dict(),
            sleep = dict(type = 'int', default = 1),
            pattern = dict(type = 'str'),
            arguments = dict(type = 'str', aliases = ['args']),
            runlevels = dict(type = 'list', elements = 'str'),
            daemonize = dict(type = 'bool', default = False),
        ),
        required_one_of = [['state', 'enabled']],
    )
    main(module)
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:48:08.623252
# Unit test for function main
def test_main():
  module = AnsibleModule(
    argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ),
    supports_check_mode=True,
    required_one_of=[['state', 'enabled']],
  )


# Generated at 2022-06-20 22:48:19.073205
# Unit test for function main
def test_main():
    # Input parameters
    test_module_args={"name": "apache2", "state": "started", "enabled": True}
    # Output parameters
    test_results = {"changed": True, "name": "apache2", "status": {"enabled": {"changed": True}}}
    def test_run_command(args, check_rc=True):
        """Simulate `run_command`"""
        return (0, "", "")
    setattr(AnsibleModule, 'run_command', test_run_command)
    setattr(AnsibleModule, 'fail_json', lambda self, *args, **kwargs: self.exit_json(**kwargs))
    # Test execution
    module = AnsibleModule(test_module_args)
    main()
    # Test results
    assert test_results == module.exit_json_

# Generated at 2022-06-20 22:49:24.058830
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:49:35.724838
# Unit test for function main
def test_main():
    from ansible.module_utils.service_common import ServiceFailure
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.sysvinit import main as original_main
    import sys

    class FakeModule(object):
        def __init__(self):
            self.params = {}
        def fail_json(self, **kwargs):
            raise ServiceFailure(kwargs)
        def get_bin_path(self, *args, **kwargs):
            return ""
        def run_command(self, *args, **kwargs):
            return 0, "", "ERROR"
        def warn(self, *args, **kwargs):
            pass

# Generated at 2022-06-20 22:49:42.360520
# Unit test for function main
def test_main():
    global location, action, is_started, runlevel_status

    location = {}
    action = 'started'
    is_started = False
    runlevel_status = {}
    runlevel_status["enabled"] = False
    class Args:
        def __init__(self):
            self.name = 'test_service'
            self.state = 'started'
            self.enabled = False
            self.runlevels = [ '3', '5' ]
            self.sleep = 1
            self.pattern = False
            self.arguments = None
    main(Args())

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:48.881292
# Unit test for function main
def test_main():
    # Load the input parameters into this module
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # Set runlevels to test

# Generated at 2022-06-20 22:49:58.038217
# Unit test for function main
def test_main():
    mod = AnsibleModule({
        'name': 'mytest',
        'state': 'started',
        'enabled': True,
        'runlevels': ['3', '5'],
        'daemonize': False,
    })
    #create a mock state object
    class mockclass(object):
        pass
    sysvinit=mockclass()
    sysvinit.enabled=False
    sysvinit.is_started=True
    # inject the mock into the test scope
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:50:01.631999
# Unit test for function main
def test_main():
    """Main entry Point for unit testing"""
    import argparse

    argparse.ArgumentParser(argument_default=argparse.SUPPRESS)



# Generated at 2022-06-20 22:50:12.942317
# Unit test for function main
def test_main():
    in_args = {}
    in_args['name'] = "testname"
    in_args['state'] = "teststate"
    in_args['enabled'] = True
    in_args['runlevels'] = [ 1,2,3 ]
    in_args['pattern'] = ''
    in_args['sleep'] = 1
    in_args['daemonize'] = True

    _m = AnsibleModule(argument_spec={})
    _m.params = in_args
    _m.check_mode = False

    # Insert the patched module functions directly into the module object
    _m.get_bin_path = lambda name, opt_dirs=None: \
        "/tmp/" + name


# Generated at 2022-06-20 22:50:22.644088
# Unit test for function main

# Generated at 2022-06-20 22:50:33.860829
# Unit test for function main
def test_main():
    """ Unit test for function main
    """
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action

# Generated at 2022-06-20 22:50:35.542147
# Unit test for function main
def test_main():
    assert False, "No test for function main"

# Generated at 2022-06-20 22:52:42.429339
# Unit test for function main
def test_main():
    from mock import Mock, patch
    from ansible.module_utils.sysv_service import AnsibleModule
    from ansible.module_utils.service import sysv_exists, sysv_is_enabled, get_sysv_script, get_ps

    def mock_get_bin_path(name, path):
        return '/usr/bin/'+name

    def mock_sysv_exists():
        return (True, None)

    def mock_sysv_is_enabled():
        return True

    def mock_get_sysv_script():
        return '/etc/init.d/foo'

    def mock_get_ps():
        return True


# Generated at 2022-06-20 22:52:44.397228
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:52:46.961910
# Unit test for function main
def test_main():
    test_name = 'apache2'
    result_test_main = main()
    assert result_test_main == test_name


# Generated at 2022-06-20 22:52:58.826808
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    assert main() is None



# Generated at 2022-06-20 22:53:03.933863
# Unit test for function main
def test_main():
    # Set up arguments and return values
    results = {
        'name': 'apache2',
        'changed': True,
        'status': {
            'started': {
                'changed': True,
                'rc': 0,
                'stdout': '',
                'stderr': ''
            },
            'enabled': {
                'changed': True,
                'rc': 0,
                'stdout': None,
                'stderr': ''
            }
        }
    }

# Generated at 2022-06-20 22:53:15.281354
# Unit test for function main
def test_main():
    import os
    from ansible.module_utils.basic import AnsibleModule, load_platform_subclass, assert_fail_json
    try:
        from ansible.module_utils.common.process import get_bin_path
    except ImportError:
        pass
    import tempfile
    import sys


# Generated at 2022-06-20 22:53:17.758451
# Unit test for function main
def test_main():
    print("Test: main")
    print("This test won't work")


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:29.558505
# Unit test for function main
def test_main():
    import os
    import sys

    testdir = os.path.dirname(__file__)
    testdir = os.path.normpath(os.path.join(testdir, '..', 'common'))
    sys.path.insert(0, testdir)

    import test_utils as utils
    import sysvinit

    module = utils.AnsibleModuleStub(
        name=None,
        state=None,
        enabled=None,
        sleep=1,
        pattern=None,
        arguments=None,
        runlevels=None,
        daemonize=False,

        # Overwrite
        TESTING=True,
    )

    module.return_values['fail_if_missing'] = lambda x,y: None

# Generated at 2022-06-20 22:53:31.525391
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={})
    main(module)
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:40.717941
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'name': {'type': 'str'}, 'action': {'type': 'str'}, 'enabled': {'type': 'bool'}, 'sleep': {'type': 'int', 'default': 1}, 'pattern': {'type': 'str'}, 'arguments': {'type': 'str', 'aliases': ['args']}, 'runlevels': {'type': 'list', 'elements': 'str'}, 'daemonize': {'type': 'bool', 'default': False}})
    main()

# import module snippets
if __name__ == '__main__':
    main()