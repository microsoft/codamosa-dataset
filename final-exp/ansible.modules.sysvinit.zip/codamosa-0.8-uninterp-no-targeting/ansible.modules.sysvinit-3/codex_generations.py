

# Generated at 2022-06-20 22:46:52.581193
# Unit test for function main

# Generated at 2022-06-20 22:47:04.224619
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    res = {}
    res['enabled'] = {}
    res['started'] = {}

    def fake_exists(name):
        return '/etc/init.d/%s' % name


# Generated at 2022-06-20 22:47:15.597501
# Unit test for function main
def test_main():
    module = AnsibleModule(
    argument_spec = dict(
        name = dict(required=True, type='str', aliases=['service']),
        state = dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled = dict(type='bool'),
        sleep = dict(type='int', default=1),
        pattern = dict(type='str'),
        arguments = dict(type='str', aliases=['args']),
        runlevels = dict(type='list', elements='str'),
        daemonize = dict(type='bool', default=False),
    ),
    supports_check_mode=True,
    required_one_of=[['state', 'enabled']],
    )
    output=main()

# Generated at 2022-06-20 22:47:18.016746
# Unit test for function main
def test_main():
    # TODO: Implement test_main
    assert False

# Standard boilerplate to call the main() function.
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:26.736897
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-20 22:47:37.515776
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:47:43.370442
# Unit test for function main
def test_main():
    for arg in ['name', 'state']:
        try:
            del sys.argv[1]
        except IndexError:
            pass
        if arg == 'name':
            sys.argv.append('name=apache2')
        elif arg == 'state':
            sys.argv.append('state=started')
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:50.644775
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:48:02.054860
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:48:09.159060
# Unit test for function main
def test_main():
    from ansible.modules.system.sysvinit import main

    module_args = dict(
        name='ip6tables',
        state='started',
        enabled=True,
        pattern='',
        arguments='',
        sleep='1',
        daemonize=False
    )

    module = AnsibleModule(argument_spec=module_args)
    results = main()

    assert 'results' in results
    assert 'attempts' in results['results']
    assert 'changed' in results['results']
    assert 'name' in results['results']
    assert 'status' in results['results']


# Generated at 2022-06-20 22:49:10.298282
# Unit test for function main
def test_main():
    import sys

    sys.modules['ansible'] = __import__('mock_ansible')
    sys.modules['ansible.module_utils'] = __import__('mock_module_utils')
    sys.modules['ansible.module_utils.basic'] = __import__('mock_module_utils.basic')
    sys.modules['ansible.module_utils.basic'].AnsibleModule = __import__('mock_ansible.module').AnsibleModule
    sys.modules['ansible.module_utils.service'] = __import__('mock_module_utils.service')
    sys.modules['ansible.module_utils.service'].sysv_is_enabled = __import__('mock_module_utils.service').sysv_is_enabled

# Generated at 2022-06-20 22:49:17.817889
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    import tempfile
    from ansible.module_utils.service import sysv_exists, get

# Generated at 2022-06-20 22:49:29.042891
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mock
    from ansible.module_utils.service import sysv_exists


# Generated at 2022-06-20 22:49:39.713640
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

# import module snippets
from ansible.module_utils.basic import *

# Generated at 2022-06-20 22:49:44.155569
# Unit test for function main
def test_main():
    args = {
        "name": "emby-server",
        "state": "",
        "enabled": None,
        "sleep": 1,
        "pattern": "",
        "arguments": "",
        "runlevels": None,
        "daemonize": False,
    }
    result = main(args)
    assert (result == None)

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:49.919266
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    ###########################################################################
    # BEGIN: Main function
    ###########################################################################
   

# Generated at 2022-06-20 22:50:00.651881
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import get_sysv_script, sysv_is_enabled, sysv_exists
    from ansible.module_utils._text import to_native
    basic._ANSIBLE_ARGS = to_native(None)

    m_args = dict(
      name="apache2",
      state=None,
      enabled=None,
    )
    m_ansible  = AnsibleModule( argument_spec=dict(m_args, supports_check_mode=True))
    #default args set above
    #m_ansible.params = m_args
    m_ansible.params['pattern'] = None

    # Note: sysv_exists will always return True because of default args


# Generated at 2022-06-20 22:50:12.171923
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest


# Generated at 2022-06-20 22:50:21.271435
# Unit test for function main
def test_main():
    sysvinit = replace_module(
        'sysvinit',
        {
            'ANSIBLE_MODULE_ARGS': {
                'name': 'test',
                'daemonize': True,
                'pattern': '',
                'state': 'started',
                'enabled': False,
                'runlevels': [],
                'arguments': ''
            }
        }
    )
    sysvinit.run_command = MagicMock(return_value=(0, '', ''))
    sysvinit.symlink = MagicMock()
    sysvinit.get_bin_path = MagicMock(return_value='/bin/test')
    sysvinit.sysv_exists = MagicMock(return_value=True)

# Generated at 2022-06-20 22:50:29.497592
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:52:35.301256
# Unit test for function main
def test_main():
    rh = SysvinitModule()
    # rh.main()
    rh.main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:52:42.838566
# Unit test for function main
def test_main():
    # Set up argument spec for program
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # Set up variables needed by program

# Generated at 2022-06-20 22:52:55.549684
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:53:07.510064
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.exit_json(
        changed=False,
        msg='Test OK'
    )

# Generated at 2022-06-20 22:53:19.440739
# Unit test for function main
def test_main():
    import ansible.module_utils.ansible_release
    ansible_release = ansible.module_utils.ansible_release

# Generated at 2022-06-20 22:53:20.614525
# Unit test for function main
def test_main():
    main()
# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:31.409639
# Unit test for function main
def test_main():
    import json
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-20 22:53:37.194112
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:42.262873
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'name': 'runit',
        'state': 'stopped',
        'sleep': 5,
        'daemonize': False
    }, supports_check_mode=True)
    assert main() == 0

# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:50.339694
# Unit test for function main
def test_main():
    # get all return values
    # Get all return values from module
    # AnsibleModule will be Mocked and object is returned
    # that can be used to get the 'result' return value.
    import sys
    import os
    #sys.argv=['main.py','service=openstack-nova-api','state=stopped','enabled=no','sleep=1','pattern=/usr/bin/python /usr/bin/nova-api']
    sys.argv=['main.py','service=httpd','state=started','enabled=no','sleep=1','pattern=/usr/bin/python /usr/bin/nova-api']
    #sys.argv=['main.py','service=httpd','state=started','enabled=no','sleep=1','pattern=/usr/bin/python /usr/bin/nova-api']
    #build