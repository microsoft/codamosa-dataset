

# Generated at 2022-06-20 22:46:48.634453
# Unit test for function main
def test_main():
  module = AnsibleModule(
      argument_spec=dict(
          name=dict(required=True, type='str', aliases=['service']),
          state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
          enabled=dict(type='bool'),
          sleep=dict(type='int', default=1),
          pattern=dict(type='str'),
          arguments=dict(type='str', aliases=['args']),
          runlevels=dict(type='list', elements='str'),
          daemonize=dict(type='bool', default=False),
      ),
      supports_check_mode=True,
      required_one_of=[['state', 'enabled']],
  )
  main()

# import module snippets
from ansible.module_utils.basic import *



# Generated at 2022-06-20 22:47:00.459554
# Unit test for function main
def test_main():
    """
    This functions provides the tests for all the functionality of the module.
    """
    ###########################################################################
    # BEGIN: sysvinit module tests

# Generated at 2022-06-20 22:47:09.329787
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:19.595724
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import sys
    import json


# Generated at 2022-06-20 22:47:22.440330
# Unit test for function main
def test_main():
    print("You can test this module by running: python -m ansible.modules.system.sysvinit name=foobar enabled=true")

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:28.491181
# Unit test for function main
def test_main():
    TEST_SAMPLE_INPUT1 = None
    TEST_SAMPLE_INPUT2 = '{"name": "sshd", "state": "started", "enabled": true, "sleep": 1, "pattern": null, "arguments": "", "runlevels": ["2", "3", "4", "5"], "daemonize": false, "check_mode": false}'
    TEST_SAMPLE_INPUT3 = '{"name": "", "state": "", "enabled": false, "sleep": 1, "pattern": "", "arguments": "", "runlevels": [], "daemonize": false, "check_mode": false}'


# Generated at 2022-06-20 22:47:34.281699
# Unit test for function main
def test_main():
    from tempfile import TemporaryDirectory
    from shutil import which
    from ansible.module_utils.basic import AnsibleModule
    import pytest
    import os
    import json

    tmpdir = TemporaryDirectory()

    # Create fake ansible module
    module = AnsibleModule({}, {}, tmpdir.name)

    # Create fake modules
    test_service = False
    if which('service'):
        test_service = True
        os.system("printf '#!/bin/bash\nexit 0' > %s/service" % tmpdir.name)
        os.system("chmod +x %s/service" % tmpdir.name)

    # Run tests
    assert main() == 'No tests ran.'


# Generated at 2022-06-20 22:47:45.084425
# Unit test for function main
def test_main():
    import inspect
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from io import StringIO

    # create a dummy module args
    args = dict(
                 name=dict(required=True, type='str', aliases=['service']),
                 state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
                 enabled=dict(type='bool'),
                 sleep=dict(type='int', default=1),
                 pattern=dict(type='str'),
                 arguments=dict(type='str', aliases=['args']),
                 runlevels=dict(type='list', elements='str'),
                 daemonize=dict(type='bool', default=False),
               )


# Generated at 2022-06-20 22:47:57.372500
# Unit test for function main
def test_main():
    try:
        # this is the global context
        # where the function is isolated
        import __builtin__
        builtin_open = __builtin__.open

        def fake_open(name, mode="r", buffering=-1):
            # i don't know how to test this one
            # that's why i need your help, please
            # contact me if you can figure something out
            return

        # patch builtins
        __builtin__.open = fake_open

        # execute function
        main()

        # unpatch builtins
        __builtin__.open = builtin_open

    except SystemExit as e:
        print(e.code)
        # get the substr of the last test
        return e.code


if __name__ == '__main__':
    result = test_main()

# Generated at 2022-06-20 22:48:07.115810
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # test with empty args
    module = AnsibleModule({})
    module.exit_json = lambda **kwargs: kwargs
    exit_args = module.exit_json(**{'changed': False, 'results': [{'action': 'start', 'command': 'service abc start', 'rc': 1, 'stdout': 'abc is dead.', 'stderr': ''}, {'action': 'stop', 'command': 'service abc stop', 'rc': 1, 'stdout': 'abc is dead.', 'stderr': ''}]})
    assert exit_args['changed'] == False
    assert exit_args['results'][0]['action'] == 'start'

# Generated at 2022-06-20 22:48:58.606253
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:48:59.898811
# Unit test for function main
def test_main():
    main()
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:09.888943
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False)
    ))
    isinstance(main(), AnsibleModule)

# import module snippets
from ansible.module_utils.basic import AnsibleModule

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:22.466687
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:32.382546
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # set up the test data

# Generated at 2022-06-20 22:49:41.910281
# Unit test for function main
def test_main():
    import mock
    from ansible.module_utils.basic import AnsibleModule

    fake_module = mock.Mock()
    fake_module.params = {
        'arguments': '',
        'daemonize': False,
        'enabled': None,
        'name': 'foo',
        'runlevels': '',
        'sleep': 1,
        'state': None,
        'pattern': '',
    }

    fake_module.get_bin_path.return_value = '/bin/true'
    fake_module.run_command.return_value = (0, '', '')


# Generated at 2022-06-20 22:49:52.572064
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.exit_json(**main())


# Generated at 2022-06-20 22:50:01.976265
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:50:13.219554
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        test_module = AnsibleModule(
            argument_spec=dict(
                name=dict(required=True, type='str', aliases=['service']),
                state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
                enabled=dict(type='bool'),
                sleep=dict(type='int', default=1),
                pattern=dict(type='str'),
                arguments=dict(type='str', aliases=['args']),
                runlevels=dict(type='list', elements='str'),
                daemonize=dict(type='bool', default=False),
            ),
            supports_check_mode=True,
            required_one_of=[['state', 'enabled']],
        )

# Generated at 2022-06-20 22:50:21.928795
# Unit test for function main
def test_main():
    mod = AnsibleModule(argument_spec={
        'name': dict(type='str', required=True),
        'state': dict(type='str', choices=['started', 'stopped', 'restarted', 'reloaded']),
        'enabled': dict(type='bool'),
        'pattern': dict(type='str'),
        'arguments': dict(type='str', aliases=['args']),
        'sleep': dict(type='int', default=1),
        'runlevels': dict(type='list', elements='str'),
        'daemonize': dict(type='bool', default=False),
    },
    supports_check_mode=True,
    required_one_of=[['state', 'enabled']])


# Generated at 2022-06-20 22:52:32.720286
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json(**main())

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:52:38.017440
# Unit test for function main
def test_main():

    import pytest
    mock_module = pytest.mock.Mock()
    loads = {'check_mode': True, 'state': None, 'enabled': None}
    mock_module.params = loads
    mock_module.run_command.return_value = (0, '', '')
    mock_module.get_bin_path.return_value = None
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-20 22:52:44.455944
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
    ))
    module.run_command = mock_run_command
    module.get_bin_path = mock_get_bin_

# Generated at 2022-06-20 22:52:49.218311
# Unit test for function main
def test_main():
    import mock
    import json

    ###########################################################################
    # BEGIN: mock to create and change states of services
    class MockModule(object):
        def __init__(self):
            self.params = {
                'name': 'nginx',
                'state': 'started',
                'enabled': True,
                'sleep': 1,
                'pattern': None,
                'arguments': None,
                'runlevels': None,
                'daemonize': False
            }

            self.fail_json = mock.MagicMock()
            self.warn = mock.MagicMock()


# Generated at 2022-06-20 22:53:02.015088
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:53:13.382104
# Unit test for function main
def test_main():

    import os
    import tempfile
    import shutil
    import sys
    import json

    sys.path.append(os.path.dirname(os.path.dirname(__file__)))

    from test.test_module_utils.test_import_module import temp_module_name

    params = dict(
        name = "test_service",
        state = "started",
        enabled = True,
        sleep = None,
        pattern = None,
        arguments = None,
        runlevels = None,
        daemonize = False,
    )

    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-20 22:53:25.675914
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
    argument_spec=dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']]
    )

    # test with name=apache2 state=started enabled=yes runlevels=3,5


# Generated at 2022-06-20 22:53:34.419865
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:53:44.773300
# Unit test for function main
def test_main():
    module = AnsibleModule(
        required_one_of=[['state', 'enabled']],
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    module.main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:54.852957
# Unit test for function main
def test_main():
    NAME = "sysvinit.py"
    ARG_SPEC = dict(
        name=dict(required=True, type='str', aliases=['service']),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    result = AnsibleModule(name=NAME, argument_spec=ARG_SPEC).main()