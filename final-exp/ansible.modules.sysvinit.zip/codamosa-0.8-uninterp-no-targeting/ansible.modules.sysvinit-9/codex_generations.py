

# Generated at 2022-06-20 22:46:37.647250
# Unit test for function main

# Generated at 2022-06-20 22:46:48.167875
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize
    import random
    import tempfile

    service = 'testservice-' + str(random.random())
    command = 'touch /tmp/' + service

    # Create a script that runs our command
    script_dir = tempfile.mkdtemp()
    script_path = script_dir + '/' + service

# Generated at 2022-06-20 22:47:00.121651
# Unit test for function main
def test_main():
    import tempfile, os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary environment variable
    tmpdirenv = os.path.join(tmpdir, 'tempdir')
    os.environ[tmpdirenv] = tmpdir

    # Create a test module
    module = AnsibleModule({
      "name": tmpdir,
      "state": "started",
    }, check_invalid_arguments=False)

    # Set up arguments for module.run_command in daemonize.
    cmd = ['echo', 'Hello World']
    shell = False
    executable = None
    in_data = None
    binary_data = False
    path_prefix = None
    cwd = None

    # Execute the module code with given arguments
    (rc, out, err) = daemonize

# Generated at 2022-06-20 22:47:09.116574
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    main_obj = main()

    ## Example string data
    module = 'sysvinit'
    name = 'apache2'
    state = 'started'
    enabled = 'yes'
    runlevels = ['3', '5']
    arguments = ''
    daemonize = 'no'

    ## Source example data
    basic._ANSIBLE_ARGS = to_bytes("""
    """)

# Generated at 2022-06-20 22:47:19.465451
# Unit test for function main
def test_main():
    argv = ['name', 'state', 'enabled', 'sleep', 'pattern', 'arguments', 'runlevels', 'daemonize']

# Generated at 2022-06-20 22:47:24.057250
# Unit test for function main
def test_main():
    test_function = AnsibleModule({
        "name": "test_main",
        "state": "test_main",
        "arguments": "test_main",
        "runlevels": ["test_main"],
        "check_mode": True,
        "enabled": True
    })
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:26.210705
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:27.342329
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:38.072583
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:47:47.862079
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule, load_platform_subclass
    from ansible.module_utils.six import ensure_str
    from ansible.module_utils.six.moves import StringIO
    import os
    import re
    import json
    import yaml
    import sys

    sys.path.append(os.path.join(os.environ['ANSIBLEDIR'], 'lib'))

    test_class = load_platform_subclass(AnsibleModule)
    module = test_class('sysvinit.py')
    module._load_params()


# Generated at 2022-06-20 22:48:45.758937
# Unit test for function main
def test_main():
    import doctest
    import ansible.modules.system.sysvinit
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.processor import collect_subset_facts
    from ansible.module_utils.facts.system import distribution_facts
    
    # Run doctests
    doctest.testmod(ansible.modules.system.sysvinit)

    # Get and collect facts
    fact_subset = [
        'distribution',
        'distribution_release',
        'distribution_version',
        'os_family'
    ]
    facts = collect_subset_facts(fact_subset)
    facts = distribution_facts(facts)
    fc = FactCollector(facts=facts, write_to_cache=True)
    fc.collect()
   

# Generated at 2022-06-20 22:48:47.370852
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:48:56.887472
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:07.726480
# Unit test for function main
def test_main():
    test_module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
        enabled=dict(type='bool'),
        sleep=dict(type='int', default=1),
        pattern=dict(type='str'),
        arguments=dict(type='str', aliases=['args']),
        runlevels=dict(type='list', elements='str'),
        daemonize=dict(type='bool', default=False),
    ),
        supports_check_mode=True,
        required_one_of=['state', 'enabled']
    )

    setattr(test_module, 'get_bin_path', lambda x: x)

# Generated at 2022-06-20 22:49:15.857537
# Unit test for function main
def test_main():
    import sys, os
    import configparser
    target = os.path.normpath(os.path.dirname(os.path.abspath(__file__)) + "/../../lib")
    sys.path.append(target)

    # Set up paths
    test_path = os.path.normpath(os.path.dirname(os.path.abspath(__file__)))
    test_config_file = test_path+"/test.cfg"
    config = configparser.ConfigParser()
    config.read(test_config_file)
    test_service = config['test_service']['test_service']
    test_service_state = config['test_service']['test_service_state']
    test_service_enabled = config['test_service']['test_service_enabled']
    test

# Generated at 2022-06-20 22:49:18.278119
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleFailJson):
        main()


# Generated at 2022-06-20 22:49:25.722907
# Unit test for function main
def test_main():
    # mock out some test data / objects
    class module:
        def __init__(self):
            self.params = {
                'name': 'apache2',
                'state': 'started',
                'enabled': None,
                'runlevels': None,
                'pattern': '',
                'sleep': 1,
                'daemonize': 'True',
                'check_mode': 'False',
                'arguments': ''
            }
            self.fail_json = None
            self.exit_json = None
            self.get_bin_path = None
            self.run_command = None

        def debug(self, msg):
            print(msg)


# Generated at 2022-06-20 22:49:37.593903
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:49:49.914651
# Unit test for function main
def test_main():
    """
     Unit test for main
    """
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.main()


# Generated at 2022-06-20 22:50:00.652316
# Unit test for function main
def test_main():
    
    test_i = 1
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-20 22:51:51.482492
# Unit test for function main
def test_main():
    test_name = os.path.basename(sys.argv[0])
    if test_name == 'test_sysvinit.py':
        print("Unit test execution")
        main()
        exit()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:52:02.327215
# Unit test for function main
def test_main():
    # Assign mock defaults
    import sys
    import io

    sys.argv[1:] = ['-s', 'started', '-e', 'yes', '-n', 'httpd', '-a', '-v']
    # sys.argv[1:] = ['-s', 'stopped', '-e', 'yes', '-n', 'httpd', '-a', '-v']
    # sys.argv[1:] = ['-s', 'reloaded', '-e', 'yes', '-n', 'httpd', '-a', '-v']
    # sys.argv[1:] = ['-s', 'restarted', '-e', 'yes', '-n', 'httpd', '-a', '-v']
    # sys.argv[1:] = ['-s', 'started', '

# Generated at 2022-06-20 22:52:08.393215
# Unit test for function main
def test_main():
    # Mock module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # Setup args

# Generated at 2022-06-20 22:52:10.654446
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:52:21.260325
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    rc = 0
    out = err = ''

# Generated at 2022-06-20 22:52:33.302878
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-20 22:52:43.535077
# Unit test for function main
def test_main():
    args = dict(
        name='apache2',
        state='started',
        enabled=True,
        sleep=1,
        pattern=None,
        arguments=None,
        runlevels=None,
        daemonize=False,
        changed=True,
        status={
            'enabled':{
                'changed':True,
                'rc':None,
                'stdout':None,
                'stderr':None
            },
            'started':{
                'changed':True,
                'rc':None,
                'stdout':None,
                'stderr':None
            }
        }
    )
    assert main(args) == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:52:56.223102
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:52:57.625027
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:09.654819
# Unit test for function main
def test_main():
    import os

    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_data_dir = os.path.join(test_dir, 'testdata')

    # example init.d file
    apache_initd = '/etc/init.d/apache2'
    if os.path.isfile(apache_initd):
        apache_file = apache_initd
        apache_name = 'apache2'
    else:
        apache_file = os.path.join(test_data_dir, 'sysv_test_data')
        apache_name = 'test'

    # example arguments
    apache_args = '-f /tmp/foo'

    # params for state