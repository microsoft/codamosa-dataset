

# Generated at 2022-06-20 22:46:39.992514
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:46:49.116995
# Unit test for function main

# Generated at 2022-06-20 22:47:00.985761
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-20 22:47:09.646084
# Unit test for function main
def test_main():
    # import at top level so no dependencies
    import platform

    # just in case, this should be impossible to hit if distribute is installed
    try:
        # import only required to test, not required by module
        import distribute
    except ImportError:
        pass
    else:
        del distribute

    # patch shell, os and platform modules to mock out the calls
    # patching the actual path would be more appropriate but this will suffice and is simpler

    class MockOsModule(object):

        def __init__(self):
            self.environ = {}

    class MockShellModule(object):

        def __init__(self):
            pass


# Generated at 2022-06-20 22:47:19.853643
# Unit test for function main
def test_main():
    import sys
    import __builtin__

    # Hack to simulate built-in __salt__
    # TODO: Refactor
    __salt__ = {}

    def mock_fail_json(*args, **kwargs):
        raise Exception('fail_json')

    def mock_exit_json(*args, **kwargs):
        return True

    def mock_salt_call(*args, **kwargs):
        return True

    def mock_run_command(*args, **kwargs):
        return True

    def mock_get_bin_path(*args, **kwargs):
        return True

    # Mock built-ins
    __builtin__.__salt__ = __salt__
    __builtin__.fail_json = mock_fail_json
    __builtin__.exit_json = mock_exit_json

   

# Generated at 2022-06-20 22:47:28.244632
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule, env_fallback
    test_main_args = {}


# Generated at 2022-06-20 22:47:38.681014
# Unit test for function main
def test_main():
    docstr = '''
- name: Make sure apache2 is started
  sysvinit:
      name: apache2
      state: started
      enabled: yes
      daemonize: yes
'''

# Generated at 2022-06-20 22:47:40.207140
# Unit test for function main
def test_main():
    pass

# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:48.455590
# Unit test for function main
def test_main():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.service import sysv_exists, sysv_is_enabled, get_sysv_script
    from ansible.module_utils.service import check_service_status_via_lsb
    import platform
    from sys import platform as _platform
    module, module_args, func, call_args, sysv, result = None, None, None, None, None, None

    # Make module usage easier by creating an alias to the function being called
    func = get_ps

    call_args = dict(
        pattern='',
    )
    module = AnsibleModule(argument_spec=dict())
    # For testing any action that is not None, set the module argument to a valid value
    module.params = dict(action='started')
    # Create a Facts

# Generated at 2022-06-20 22:47:50.586258
# Unit test for function main
def test_main():

    # Exit code
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:48:40.603992
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:48:50.877063
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import json

    # write test case
    with open('sysvinit.json', 'w') as outfile:
        json.dump(
            dict(
                failed=False,
                check_mode=False,
                name='httpd',
                state='started',
                enabled=True,
            ),
            outfile
        )

    # load module

# Generated at 2022-06-20 22:48:58.559976
# Unit test for function main
def test_main():
    from ansible.module_utils.pycompat24 import get_exception
    import sys
    import ansible.module_service
    from units.compat import unittest
    from units.compat.mock import MagicMock, patch

    class TestServiceModule(unittest.TestCase):
        def setUp(self):
            self.mock_module = MagicMock(name='ansible.module_service.AnsibleModule')
            self.mock_module.check_mode = False
            self.mock_module.params = dict(
                name='httpd',
                state='started',
                enabled=True,
                sleep=1,
                pattern=None,
                arguments=None,
                runlevels=None,
                daemonize=False,
            )


# Generated at 2022-06-20 22:49:08.733580
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    assert module

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:16.627329
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:49:27.284234
# Unit test for function main
def test_main():
    mod = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-20 22:49:39.677623
# Unit test for function main
def test_main():
    pattern = r'provided = {.*\n.*run_command.*\n.*chdir.*'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-20 22:49:51.300692
# Unit test for function main
def test_main():
    from sys import version_info
    from pickle import dumps, loads
    if version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize

    # read module arguments from a pickle file
    with open('./tests/unit/module_args/sysvinit.pkl', 'rb') as f:
        module_args = loads(f.read())

    # create an empty module for testing
    basic._ANSIBLE_ARGS = to_bytes('')

# Generated at 2022-06-20 22:50:01.404966
# Unit test for function main
def test_main():
    """Exercise the module and return exit_json."""

# Generated at 2022-06-20 22:50:08.050888
# Unit test for function main

# Generated at 2022-06-20 22:52:18.139936
# Unit test for function main
def test_main():
    # Check if the module is in fact loadable. This should be done first to
    # allow early bailing out.
    try:
        got = AnsibleModule(
            argument_spec={},
        )
        fail = False
    except:
        fail = True
    assert not fail, 'Module is not loadable'



# Generated at 2022-06-20 22:52:29.790019
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:52:36.807466
# Unit test for function main
def test_main():
    import sys
    import json
    import copy

    sys.argv = ["sysvinit", "--name", "apache2", "--state", "started", "--enabled", "yes"]
    #print json.dumps(main())

    sys.argv = ["sysvinit", "--name", "apache2", "--state", "started", "--enabled", "yes"]

# Generated at 2022-06-20 22:52:48.794753
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    assert main() == 'WORKS'

# Generated at 2022-06-20 22:52:54.000248
# Unit test for function main
def test_main():
    # import module snippets
    from ansible.modules.system.service import main as sysvinit
    # Inject required args into module

# Generated at 2022-06-20 22:52:59.176979
# Unit test for function main
def test_main():
    name = "ansible"
    action = "start"
    enabled = "True"
    runlevels = ""
    sleep_for = "1"
    
    from ansible.module_utils.basic import AnsibleModule, AnsibleModuleExit
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize

    def module_exit_json(**kwargs):
        return kwargs
    def module_fail_json(**kwargs):
        pass
    
    class testModule(AnsibleModule):
        
        def __init__(self, *args, **kwargs):
            super(testModule, self).__init__(*args, **kwargs)
            self.exit_json = module_exit_

# Generated at 2022-06-20 22:53:10.649776
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    module.run_command = MagicMock(return_value=(0, '', ''))
    module.exit_json = MagicMock()
    main()
    module.exit

# Generated at 2022-06-20 22:53:12.109680
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:25.526932
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:28.677891
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert "FAILED" not in main(module)

if __name__ == '__main__':
    main()