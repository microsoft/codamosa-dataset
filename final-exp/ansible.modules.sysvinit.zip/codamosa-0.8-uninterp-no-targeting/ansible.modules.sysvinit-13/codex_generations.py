

# Generated at 2022-06-20 22:46:51.239294
# Unit test for function main
def test_main():
    name = 'apache2'
    runlevels = [3, 5]
    daemonize = False
    location = {}
    location['chkconfig'] = '/sbin/chkconfig'
    location['update-rc.d'] = '/usr/sbin/update-rc.d'
    location['service'] = '/sbin/service'
    location['insserv'] = '/sbin/insserv'
    location['chkconfig'] = '/sbin/chkconfig'


# Generated at 2022-06-20 22:47:01.790448
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        required_one_of=[['state', 'enabled']],
    )
    main(module)

# Generated at 2022-06-20 22:47:12.211512
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main(module)

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:13.883392
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:22.998641
# Unit test for function main
def test_main():
    module_args = dict(
        name='iptables',
        pattern='',
        daemonize=False,
        runlevels='',
        state='',
        enabled=''
    )
    result = dict(
        results=dict(
            ansible_facts=dict(
                name='iptables'
            ),
            changed=True,
            status=dict(
                enabled=dict(
                    stdout='',
                    stderr='',
                    changed=True,
                    rc=0
                ),
                started=dict(
                    stdout='',
                    stderr='',
                    changed=True,
                    rc=0
                ),
                stopped=dict(
                    stdout='',
                    stderr='',
                    changed=True,
                    rc=0
                ),
            )
        )
    )
    module

# Generated at 2022-06-20 22:47:35.050789
# Unit test for function main
def test_main():
    # We need to specify a name so we can
    # determine the output from running the
    # script as a unit test.
    name = "test_script"

    # The script_args variable is a list of
    # the arguments to pass to AnsibleModule.
    script_args = []

    # Create an AnsibleModule object with
    # the correct arguments and the test_alias
    # name (must match the import in the unit
    # test script).

# Generated at 2022-06-20 22:47:45.307171
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import os
    import ansible.utils.template as template
    from ansible.utils.vars import merge_hash

    ##################################################
    # FIXTURE

    # Make a stub for any command that could be run
    def stub_command(self, command, args, check_rc=True, executable=None, run_as_root=False, use_unsafe_shell=False):
        ''' return our fake responses '''
        if command == "cat /etc/init.d/fooservice":
            # make sure the file exists
            open(self.tmpdir+'/fooservice', 'a').close()
            return (0, self.tmpdir+'/fooservice', '')

# Generated at 2022-06-20 22:47:47.084099
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:56.213313
# Unit test for function main
def test_main():
    from ansible.modules.system.service import main
    import json
    import os
    os.environ['ANSIBLE_MODULE_NO_JSON'] = '1'
    s = json.dumps({
        'state': 'started',
        'enabled': False,
        'runlevels': ['3', '5'],
        'name': 'apache2'
    })
    m = AnsibleModule(argument_spec=dict())
    m.params = json.loads(s)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:48:02.144175
# Unit test for function main
def test_main():
    args = {
        "name": "foo",
        "state": "started",
        "enabled": True,
        "sleep": 1,
        "pattern": "bar",
        "arguments": "baz",
        "runlevels": [ "qux" ],
        "daemonize": False,
    }

    module = AnsibleModule(argument_spec = args)

    print(module.params)
    main()

# Generated at 2022-06-20 22:49:01.166394
# Unit test for function main
def test_main():
    ''' Test for function main '''
    args = {
        'name': 'apache2',
        'state': 'started',
        'enabled': True,
    }

    main(args)

# Generated at 2022-06-20 22:49:10.588623
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    ###########################################################################
    # BEGIN: mock code

# Generated at 2022-06-20 22:49:23.501735
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.exit_json(changed=True, rc=0, out='', err='')


# Generated at 2022-06-20 22:49:35.388478
# Unit test for function main

# Generated at 2022-06-20 22:49:43.426085
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
main()

# Generated at 2022-06-20 22:49:55.060692
# Unit test for function main
def test_main():

    import os
    import sys
    import tempfile
    import textwrap

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']
    enabled = module

# Generated at 2022-06-20 22:49:59.773857
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    import json

    # load test data

# Generated at 2022-06-20 22:50:03.258421
# Unit test for function main
def test_main():
    pass
if __name__ == '__main__':
    # Unit test
    test_main()
# vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4 :

# Generated at 2022-06-20 22:50:14.229524
# Unit test for function main
def test_main():
    # Mock ansible module
    import ansible.module_utils.basic

# Generated at 2022-06-20 22:50:22.472342
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.exit_json(**main())


# Generated at 2022-06-20 22:52:33.257692
# Unit test for function main
def test_main():
    a = '''
    - name: Make sure apache2 is started
      sysvinit:
          name: apache2
          state: started
          enabled: yes

    - name: Make sure apache2 is started on runlevels 3 and 5
      sysvinit:
          name: apache2
          state: started
          enabled: yes
          runlevels:
            - 3
            - 5
    '''

# Generated at 2022-06-20 22:52:38.165745
# Unit test for function main
def test_main():
    test_args = {
        'name': 'httpd',
        'enabled': 'yes',
        'state': 'started',
        'daemonize': 'yes',
        'arguments': '',
        'sleep': '1',
        'runlevels': ''
    }
    module = AnsibleModule(**test_args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:52:39.022051
# Unit test for function main
def test_main():
	pass

# Collecting tests for this module

# Generated at 2022-06-20 22:52:51.632018
# Unit test for function main

# Generated at 2022-06-20 22:53:04.614032
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    test_module.params['name'] = 'apache2'
    test_module.params

# Generated at 2022-06-20 22:53:15.930449
# Unit test for function main
def test_main():
    from ansible.module_utils import AnsibleModule

# Generated at 2022-06-20 22:53:25.904937
# Unit test for function main
def test_main():
    class MockArgs:
        def __init__(self, *args, **kwargs):
            pass

    args = MockArgs(name="hello", state=None)
    with patch('ansible.module_utils.basic.AnsibleModule') as mock_AnsibleModule:
        mock_AnsibleModule.return_value = MockArgs()
        main()
        mock_AnsibleModule.assert_called_once()
        mock_AnsibleModule().get_bin_path.assert_called_once()
        mock_AnsibleModule().run_command.assert_called_once()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:27.538682
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-20 22:53:35.304933
# Unit test for function main
def test_main():
    the_module = open("/tmp/test_module", "w")

# Generated at 2022-06-20 22:53:37.059499
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()