

# Generated at 2022-06-20 22:46:49.056551
# Unit test for function main

# Generated at 2022-06-20 22:47:00.894733
# Unit test for function main
def test_main():
    test_dict = {'daemonize': False,
                 'arguments': '',
                 'runlevels': None,
                 'sleep': 1,
                 'name': 'null',
                 'pattern': '',
                 'enabled': None,
                 'state': 'started'}

# Generated at 2022-06-20 22:47:09.685281
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.action import ActionBase
    from ansible.playbook.play_context import PlayContext
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    action_base = ActionBase(play_context=PlayContext(check_mode=True, connection_user='remote_user', become_method='sudo'),
                             task_vars={'python': sys.executable},
                             task=dict(action=dict(name='sysvinit', version='2.8.0')))
    action_base._execute_module(module, tmp=None, task_vars=None, wrap_async=None)
    sys.modules.pop('sysvinit')



# Generated at 2022-06-20 22:47:14.323575
# Unit test for function main
def test_main():
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.action import AnsibleAction
    from ansible.module_utils.service import get_ps, fail_if_missing, sysv_exists

# Generated at 2022-06-20 22:47:15.777952
# Unit test for function main
def test_main():
    assert 1 == 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:24.236112
# Unit test for function main

# Generated at 2022-06-20 22:47:25.985771
# Unit test for function main
def test_main():
    dbg_main()


# Generated at 2022-06-20 22:47:32.395160
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:47:43.469869
# Unit test for function main
def test_main():
    import ml
    import json


# Generated at 2022-06-20 22:47:55.073091
# Unit test for function main
def test_main():
    attr_test = {
            "arguments": "arguments test",
            "daemonize": "daemonize test",
            "enabled": "enabled test",
            "name": "name test",
            "pattern": "pattern test",
            "sleep": "sleep test",
            "state": "state test"
    }

    def test_sysv_is_enabled(name, runlevel=None):
        """Function for test_sysv_is_enabled(name, runlevel=None)
        """
        return "sysv_is_enabled test"

    def test_get_sysv_script(name):
        """Function for test_get_sysv_script(name)
        """
        return "get_sysv_script test"


# Generated at 2022-06-20 22:48:48.633558
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:48:58.766864
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required = True, type = 'str'),
            state = dict(choices = ['started', 'stopped', 'restarted', 'reloaded'], type = 'str'),
            enabled = dict(type = 'bool')
        ),
        required_one_of=[['state', 'enabled']],
        supports_check_mode=True
    )

    # Mock out get_ps() to answer true
    def get_ps(module, pattern):
        return True

    # Mock out sysv_is_enabled() to answer false
    def sysv_is_enabled(name, runlevel=None):
        return False

    # Mock out sysv_exists() to answer true
    def sysv_exists(name):
        return True

    # Mock out get

# Generated at 2022-06-20 22:49:07.864770
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script, sysv_exists, fail_if_missing, get_ps, daemonize
    import os

    # Unit test script that runs a local function and emulates what
    # would be done by AnsibleModule()

    # Define the class it would be invoked with

# Generated at 2022-06-20 22:49:15.932754
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:26.805171
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    name = module.params['name']
    action = module.params['state']

# Generated at 2022-06-20 22:49:38.718316
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    rc = 0
    out = err = ''

# Generated at 2022-06-20 22:49:50.999006
# Unit test for function main
def test_main():
    # FIXME:  How to pass in check_mode ?
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']]
    )


# Generated at 2022-06-20 22:49:55.932149
# Unit test for function main
def test_main():
    try:
        from ansible.modules.system.sysvinit import main
    except Exception:
        assert False, "Cannot import ansible.modules.system.sysvinit"


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:50:07.709156
# Unit test for function main
def test_main():
    import os
    import sys
    import json
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_is_enabled, get_sysv_script

    # Setup mock directory structure

    # Assume that module is run from a subdirectory of ansible/lib/ansible/modules
    # we find the root ansible directory and then sub in the module path
    # This is required to support the unit test environment
    # We need the executable to find the service file
    root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Generated at 2022-06-20 22:50:17.221538
# Unit test for function main
def test_main():
    spec = {
        "name": {"required": True, "type": "str"},
        "state": {"choices": ["started", "stopped", "restarted", "reloaded"], "type": "str"},
        "enabled": {"type": "bool"},
        "sleep": {"type": "int", "default": 1},
        "pattern": {"type": "str"},
        "arguments": {"type": "str", "aliases": ["args"]},
        "runlevels": {"type": "list", "elements": "str"},
        "daemonize": {"type": "bool", "default": False},
    }
    module = AnsibleModule(argument_spec=spec, supports_check_mode=True, required_one_of=[["state", "enabled"]])

# Generated at 2022-06-20 22:52:30.811125
# Unit test for function main
def test_main():
    args = dict(
        {
            'state': 'started',
            'enabled': True,
            'name': 'apache2'
        }
    )
    with pytest.raises(SystemExit) as excinfo:
        main()
    assert excinfo.value.code == 0


# Generated at 2022-06-20 22:52:39.852984
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:52:53.351722
# Unit test for function main
def test_main():
    import json
    from ansible.module_utils import basic

    test_result = dict(
        # The daemonize option avoids returning the session id in stdout
        results = dict(
            name = "mydaemon",
            changed= False,
            status= dict(
                enabled= dict(
                    changed=False,
                    rc=None,
                    stderr=None,
                    stdout=None),
                stopped= dict(
                    changed=False,
                    rc=None,
                    stderr=None,
                    stdout="Stopping web server: apache2.\n")
            ),
            rc = 0,
            stdout = "",
            stderr = ""
        )
    )


# Generated at 2022-06-20 22:52:57.014446
# Unit test for function main
def test_main():
    """Unit test for ansible.module_utils.basic.sysv_is_enabled"""
    assert 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:08.287867
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str'),
            state=dict(type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:20.161731
# Unit test for function main

# Generated at 2022-06-20 22:53:31.044991
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )


# Generated at 2022-06-20 22:53:42.362394
# Unit test for function main
def test_main():

    # module setup
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # set dependencies for test case

# Generated at 2022-06-20 22:53:50.392359
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:57.434557
# Unit test for function main
def test_main():
    module.exit_json = lambda x: x
    for action in ['started', 'stopped', 'restarted', 'reloaded']:
        for enabled in [True, False]:
            name = 'foo'
            script = '/etc/init.d/foo'
            rc = 0
            out = err = ''
            result = {
                'name': name,
                'changed': False,
                'status': {}
            }

            # ensure service exists, get script name
            fail_if_missing(module, sysv_exists(name), name)
            script = get_sysv_script(name)

            # locate binaries for service management
            paths = ['/sbin', '/usr/sbin', '/bin', '/usr/bin']