

# Generated at 2022-06-20 22:46:47.135049
# Unit test for function main
def test_main():
    # AnsibleModule is INCOMPATIBLE with pytest
    #m = AnsibleModule(argument_spec={'text': {'type': 'str'}, '_ansible_check_mode': {'type': 'bool'}, '_ansible_debug': {'type': 'bool'}, '_ansible_diff': {'type': 'bool'}, 'msg': {'type': 'str'}})
    #m._ansible_debug = False
    #m._ansible_check_mode = True
    #m._ansible_diff = False
    #arg = {'text': 'foo', '_ansible_check_mode': True, '_ansible_debug': False, '_ansible_diff': False}

    #(changed, result) = main(m, arg)
    #return changed
    return True



# Generated at 2022-06-20 22:46:49.928847
# Unit test for function main
def test_main():
    args = dict(
        name='apache2',
        enabled=True
    )
    module = AnsibleModule(argument_spec=args)
    main()

# Generated at 2022-06-20 22:47:01.709700
# Unit test for function main
def test_main():
    # Unit test setup
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    # Unit test code
    return module

# Unit test execution

# Generated at 2022-06-20 22:47:02.525356
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:10.431849
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    test_module.exit_json = exit_json
    test_module.fail_json

# Generated at 2022-06-20 22:47:20.445758
# Unit test for function main
def test_main():
    name = 'apache2'
    action = 'started'
    enabled = True
    runlevels = None
    pattern = None
    sleep_for = 1
    rc = 0
    out = err = ''
    result = {
        'name': name,
        'changed': False,
        'status': {}
    }

    # ensure service exists, get script name
    fail_if_missing(module, sysv_exists(name), name)
    script = get_sysv_script(name)

    # locate binaries for service management
    paths = ['/sbin', '/usr/sbin', '/bin', '/usr/bin']
    binaries = ['chkconfig', 'update-rc.d', 'insserv', 'service']

    # Keeps track of the service status for various runlevels because we can
    # operate on multiple run

# Generated at 2022-06-20 22:47:28.578283
# Unit test for function main
def test_main():
    test_data = """{
        "state": "started",
        "check_mode": false,
        "diff_mode": false
    }"""


# Generated at 2022-06-20 22:47:38.106445
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os
    # Check for service
    is_service = True
    if os.path.exists("/usr/bin/ansible") and os.access("/usr/bin/ansible", os.X_OK):
        is_service = False

    # Replace with unit test framework
    sys.argv = ["main.py", "--daemonize", "--name", "httpd", "--enabled", True]
    if is_service:
        sys.argv.append("--state")
        sys.argv.append("stopped")

    print(sys.argv)
    main()

if __name__ == '__main__':
    #test_main()
    main()

# Generated at 2022-06-20 22:47:44.854059
# Unit test for function main
def test_main():
    # Test module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    module.main()


# Generated at 2022-06-20 22:47:56.938449
# Unit test for function main

# Generated at 2022-06-20 22:48:49.154428
# Unit test for function main
def test_main():
    # FIXME: Write more meaningful test
    # Assumes: runs as part of test playbook, so not going to be run as root which
    # will cause the module to fail, so just test the module code that can be run
    # by a non-root user.
    print("FIXME: No unittest for sysvinit module")
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:48:57.424265
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )
    # ensure service exists, get script name

# Generated at 2022-06-20 22:49:02.796839
# Unit test for function main
def test_main():

    # Variable to hold results
    results = []

    # Test for failure on missing script
    module = AnsibleModule({"name": "test", "state": "test", "arguments": ""}, check_invalid_arguments=False)
    result = {}
    result["name"] = "test"
    result["changed"] = False
    result["status"] = {
        "enabled": {
            "changed": False,
            "rc": None,
            "stdout": None,
            "stderr": None,
            "runlevels": [
                "3",
                "5"
            ]
        }
    }
    results.append((module, result))

    # Test for failure on missing script

# Generated at 2022-06-20 22:49:11.567103
# Unit test for function main
def test_main():
    import tempfile
    import os
    import shutil
    from ansible.module_utils.common.removed import removed_module
    from ansible.module_utils.six.moves import StringIO
    try:
        from unittest.mock import patch, Mock, MagicMock
    except ImportError:
        from mock import patch, Mock, MagicMock
    # Create empty mock
    mock_empty = Mock()
    # Create mock module
    mock_module = MagicMock()
    mock_module.params = {
        'arguments': '',
        'daemonize': False,
        'enabled': '',
        'name': '',
        'pattern': '',
        'runlevels': [],
        'sleep': 1,
        'state': ''
    }
    mock_module.run_command = Mock

# Generated at 2022-06-20 22:49:24.270486
# Unit test for function main
def test_main():

    def test_module_parameters(module):

        module.params = {
            'name': 'apache2',
            'state': 'started',
            'enabled': True,
            'sleep': 1,
            'runlevels': ['1', '2'],
            'arguments': '',
            'daemonize': False
        }


# Generated at 2022-06-20 22:49:35.975142
# Unit test for function main
def test_main():
    # Unit test to demonstrate the functionality of code
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

# Generated at 2022-06-20 22:49:44.125340
# Unit test for function main
def test_main():
    my_module = AnsibleModule({
        'service': 'ntpd',
        'state': 'stopped'
    })
    my_module.start = magic_mock()
    my_module.exit_json = magic_mock()
    my_module.run_command = magic_mock()
    my_module.get_bin_path = magic_mock(return_value="/usr/bin/update-rc.d")

    # test start
    my_module.params['state'] = 'started'
    my_module.params['enabled'] = True
    main()
    my_module.run_command.assert_called_with("/usr/bin/update-rc.d ntpd defaults")
    assert my_module.exit_json.called

    # test stop

# Generated at 2022-06-20 22:49:45.905027
# Unit test for function main
def test_main():
    import ansible.module_utils.sysvinit as sysvinit
    module, action, action_changed, rc, out, err = sysvinit.main()

# Generated at 2022-06-20 22:49:58.409745
# Unit test for function main
def test_main():
    from ansible.utils.color import ANSIBLE_COLOR
    import sys

    ANSIBLE_COLOR['good'] = '\x1b[32m'
    ANSIBLE_COLOR['warn'] = '\x1b[33m'
    ANSIBLE_COLOR['failed'] = '\x1b[31m'
    ANSIBLE_COLOR['stdout'] = '\x1b[0m'
    ANSIBLE_COLOR['stderr'] = '\x1b[31m'
    ANSIBLE_COLOR['reset'] = '\x1b[0m'


# Generated at 2022-06-20 22:50:10.989261
# Unit test for function main
def test_main():

    # Import modules needed for testing
    import sys
    import os
    import subprocess

    # Set ansible mode to run actions
    os.environ['ANSIBLE_MODULE_MODE'] = "ACTION"

    # Create AnsibleModule mock
    class AnsiModule(object):
        def __init__(self, arg_spec, arg_type):
            self.params = {}
            self.params['name'] = 'ansible-test'
            self.params['state'] = 'stopped'
            self.params['enabled'] = False
            self.params['sleep'] = 0
            self.params['pattern'] = None
            self.params['arguments'] = None
            self.params['runlevels'] = None
            self.params['daemonize'] = False


# Generated at 2022-06-20 22:52:19.832994
# Unit test for function main
def test_main():
    # Mock up arguments.
    state = 'started'
    action = 'start'
    enabled = False
    runlevels = ['3', '5']
    pattern = 'apache2'
    sleep_for = 1
    rc = 0
    out = err = ''
    result = {
        'name': 'apache2',
        'changed': False,
        'status': {}
    }
    module = Mock()
    module.params['name'] = 'apache2'
    module.params['state'] = 'started'
    module.params['enabled'] = enable

# Generated at 2022-06-20 22:52:31.675593
# Unit test for function main
def test_main():

    # Mock function to init the module class
    def ansible_module_init(self, argument_spec, bypass_checks=False, no_log=True, check_invalid_arguments=True, mutually_exclusive=None, required_together=None, required_one_of=None,
            add_file_common_args=False, supports_check_mode=False, required_if=None):
        pass

    # Mock function to init the module arguments

# Generated at 2022-06-20 22:52:40.419096
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import atexit
    sys.path.append(os.path.join(sys.path[0],'..'))
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.actions import AnsibleModuleError
    from ansible.module_utils._text import to_bytes, to_native

    TEST_PLAYBOOK_FILE = tempfile.mkstemp(prefix="test", suffix="test_service")[1]
    def cleanup():
        os.unlink(TEST_PLAYBOOK_FILE)
    atexit.register(cleanup)

    # create a dummy playbook file
    pb = open(TEST_PLAYBOOK_FILE, "w")

# Generated at 2022-06-20 22:52:52.278776
# Unit test for function main
def test_main():
    monkeypatch = MonkeyPatch()
    def mock_module_get_bin_path(module, module_arg, opt_dirs=None, required=False):
        if module_arg == 'service':
            return '/bin/service'
        elif module_arg == 'chkconfig':
            return '/bin/chkconfig'
        elif module_arg == 'update-rc.d':
            return '/bin/update-rc.d'
    monkeypatch.setattr(SysvinitModule, "get_bin_path", mock_module_get_bin_path)

    def mock_run_command(module, cmd):
        if "status" in cmd:
            return (0, "Active: active (running)", "")
        else:
            return (0, "", "")

# Generated at 2022-06-20 22:53:05.397436
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.service import sysv_exists, sysv_is_enabled

    # Setup AnsibleModule

# Generated at 2022-06-20 22:53:16.711102
# Unit test for function main

# Generated at 2022-06-20 22:53:28.679576
# Unit test for function main
def test_main():
    def do_test(mock_module):
        state = mock_module.params['state']
        enabled = mock_module.params['enabled']
        runlevels = mock_module.params['runlevels']
        if runlevels:
            for level in runlevels:
                if enabled:
                    mock_module.run_command.assert_any_call("update-rc.d foo enable %s" % level)
                else:
                    mock_module.run_command.assert_any_call("update-rc.d foo disable %s" % level)
        else:
            if enabled:
                mock_module.run_command.assert_called_with("update-rc.d foo defaults")
            else:
                mock_module.run_command.assert_called_with("update-rc.d foo disable")

        if state:
            expected

# Generated at 2022-06-20 22:53:29.991087
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:41.018559
# Unit test for function main
def test_main():
    os = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', aliases=['service']),
            state=dict(choices=['started', 'stopped', 'restarted', 'reloaded'], type='str'),
            enabled=dict(type='bool'),
            sleep=dict(type='int', default=1),
            pattern=dict(type='str'),
            arguments=dict(type='str', aliases=['args']),
            runlevels=dict(type='list', elements='str'),
            daemonize=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled']],
    )

    main()
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:44.811980
# Unit test for function main
def test_main():

    from ansible.module_utils.action_plugins import action
    import sys
    import pytest

    sys.modules['ansible.module_utils.service'] = action

    pytest.main([__file__])

if __name__ == "__main__":
    main()