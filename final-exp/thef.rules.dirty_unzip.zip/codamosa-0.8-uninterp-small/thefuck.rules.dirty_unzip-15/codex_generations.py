

# Generated at 2022-06-26 05:46:19.329730
# Unit test for function match
def test_match():
    arg0 = 125
    res0 = match(arg0)
    assert res0 == False


# Generated at 2022-06-26 05:46:26.174738
# Unit test for function side_effect
def test_side_effect():
    a = b = c = d = e = f = g = h = i = j = k = l = m = n = o = p = q = r = s = t = u = v = w = x = y = z = 0
    side_effect(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z)

# Generated at 2022-06-26 05:46:30.274924
# Unit test for function side_effect
def test_side_effect():
    var_0 = side_effect()

# Generated at 2022-06-26 05:46:32.173349
# Unit test for function side_effect
def test_side_effect():
    var_0 = side_effect(None, None)


# Generated at 2022-06-26 05:46:34.881701
# Unit test for function match
def test_match():
    var = u'unzip zipfile a'
    actual = match(var)
    # assert actual == expect


# Generated at 2022-06-26 05:46:40.575885
# Unit test for function match
def test_match():
    int_0 = 125
    var_0 = match(int_0)


# Generated at 2022-06-26 05:46:41.886996
# Unit test for function match
def test_match():
    assert match(u'unzip tests/crashdump.zip')



# Generated at 2022-06-26 05:46:44.712347
# Unit test for function side_effect
def test_side_effect():
    int_0 = 125
    int_1 = 125
    var_0 = side_effect(int_0, int_1)


# Generated at 2022-06-26 05:46:47.562043
# Unit test for function side_effect
def test_side_effect():
    assert True
    # Make sure that the function side_effect exists
    print('\nUnit test for function side_effect')
    assert callable(side_effect)
    # Make sure that the function returns nothing
    assert side_effect('', '') == None
    print('Assertions passed')

# Generated at 2022-06-26 05:46:53.820575
# Unit test for function side_effect
def test_side_effect():
    from thefuck.rules.unzip_to_current_dir import side_effect
    side_effect(None, None)
    pass


# Generated at 2022-06-26 05:47:05.420651
# Unit test for function side_effect
def test_side_effect():
    old_cmd = ['-d', 'C:\\Users\\Dell\\Desktop', '-l', 'C:\\Users\\Dell\\Desktop\\backup_Folder']
    command = 'unzip -d C:\\Users\\Dell\\Desktop\\backup_Folder C:\\Users\\Dell\\Desktop\\backup_Folder.zip'
    side_effect(old_cmd, command)


# Generated at 2022-06-26 05:47:06.942761
# Unit test for function match
def test_match():
    # ZIP_FILE returns True if the zip file is Bad
    out, err = capsys.readouterr()
    assert _is_bad_zip(out) == True


# Generated at 2022-06-26 05:47:16.093083
# Unit test for function side_effect
def test_side_effect():
    archive = zipfile.ZipFile(_zip_file(old_cmd), 'r')
    for file in archive.namelist():
        if not os.path.abspath(file).startswith(os.getcwd()):
            # it's unsafe to overwrite files outside of the current directory
            continue

        try:
            os.remove(file)
        except OSError:
            # does not try to remove directories as we cannot know if they
            # already existed before
            pass

    # Cleanup.
    archive.close()


# Mocking
# 1. Mock two functions
shell.quote = mock.Mock(side_effect=lambda x: '"{}"'.format(x))
os.path.abspath = mock.Mock(return_value='abc')

# 2. Mock a class

# Generated at 2022-06-26 05:47:18.522179
# Unit test for function match
def test_match():
    cmd = types.SimpleNamespace(script_parts=[u'unzip', u'test.zip'])
    assert match(cmd)


# Generated at 2022-06-26 05:47:19.469137
# Unit test for function side_effect
def test_side_effect():
    var_1 = side_effect()


# Generated at 2022-06-26 05:47:27.889462
# Unit test for function side_effect
def test_side_effect():
    # Setup
    try:
        from thefuck.utils import for_app
    except ImportError:
        pytest.skip('No "for_app" function')
    try:
        from thefuck.rules.unzip_in_current_dir import side_effect
    except ImportError:
        pytest.skip('No "side_effect" function')
    try:
        from thefuck.rules.unzip_in_current_dir import get_new_command
    except ImportError:
        pytest.skip('No "get_new_command" function')
    try:
        from thefuck.rules.unzip_in_current_dir import match
    except ImportError:
        pytest.skip('No "match" function')

    # Exercise
    side_effect()

    # Verify
    assert True


# Generated at 2022-06-26 05:47:28.962624
# Unit test for function side_effect
def test_side_effect():
    assert side_effect is not None


# Generated at 2022-06-26 05:47:32.113070
# Unit test for function match
def test_match():
    assert match('unzip -d') == False
    test_zip = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            'data/test_unzip.zip')
    assert match('unzip ' + test_zip) == True

# Generated at 2022-06-26 05:47:37.066363
# Unit test for function match
def test_match():
    command = "unzip file"
    output = match(command)
    assert(output == False)
    command = "unzip file.zip"
    output = match(command)
    assert(output == False)


# Generated at 2022-06-26 05:47:39.363785
# Unit test for function side_effect
def test_side_effect():
    old_cmd = u'unzip thefuck-master.zip'
    command = u'unzip thefuck-master.zip -d thefuck-master'

    side_effect(old_cmd, command)



# Generated at 2022-06-26 05:47:46.624096
# Unit test for function match
def test_match():
    assert match('') == False


# Generated at 2022-06-26 05:47:48.210833
# Unit test for function side_effect
def test_side_effect():
    var_1 = set_ut()
    side_effect(var_1)


# Generated at 2022-06-26 05:47:50.671569
# Unit test for function match
def test_match():
    var_0 = 'unzip'
    var_0 = _zip_file(var_0)
    var_0 = _is_bad_zip(var_0)


# Generated at 2022-06-26 05:47:52.870076
# Unit test for function match
def test_match():
    assert not _is_bad_zip('unzip_test.py')
    assert _is_bad_zip('unzip_test_bad.zip')



# Generated at 2022-06-26 05:47:54.630267
# Unit test for function side_effect
def test_side_effect():
    # Should not alter the directory structure
    assert True


# Generated at 2022-06-26 05:47:59.635850
# Unit test for function match
def test_match():
    float_0 = -669.0
    var_0 = _zip_file(float_0)
    assert _zip_file(float_0) == '-669.zip', 'Incorrect output'
    assert _is_bad_zip(var_0) == True, 'Incorrect output'
    assert match(float_0) == True, 'Incorrect output'


# Generated at 2022-06-26 05:48:05.298467
# Unit test for function side_effect
def test_side_effect():
    var_0 = "top -bn1"
    var_1 = "unzip /tmp/a"
    var_2 = ""
    # Test code
    # Test 0
    side_effect(var_1, var_2)
    # Test 1
    side_effect('top -bn1', '')
    # Test 2
    side_effect('top -bn1', '')

# Generated at 2022-06-26 05:48:13.452501
# Unit test for function match
def test_match():
    print("test_match")
    assert _match(shell.and_('unzip', 'a.zip', 'b.zip'))
    assert _match(shell.and_('unzip', '-x', 'a.zip'))
    assert not _match(shell.and_('unzip', '-d', 'a.zip'))
    assert not _match(shell.and_('unzip', 'a.rar'))
    assert not _match(shell.and_('unrar', 'a.rar'))
    print("test_match, Success")


# Generated at 2022-06-26 05:48:17.624566
# Unit test for function side_effect
def test_side_effect():
    float_0 = -669.0
    command = u''.join([u'unzip', u' ', u'-d', u' ', u'.'])
    side_effect(float_0, command)

# Generated at 2022-06-26 05:48:29.010910
# Unit test for function match
def test_match():
    assert _is_bad_zip("take2.zip")
    assert _zip_file("unzip take2.zip") == "take2.zip"
    float_0 = -669.0
    float_1 = -587.0
    float_2 = -486.0
    float_3 = -1.0
    float_4 = -33.0
    float_5 = 0.0
    float_6 = 4.0
    float_7 = 36.0
    float_8 = 48.0
    float_9 = 59.0
    float_10 = 90.0
    float_11 = 99.0
    
    
    
    
    
    
    
    
    
    
    
    float_12 = 1000.0
    float_13 = 5555.0
    float_14 = 100000.

# Generated at 2022-06-26 05:48:47.446330
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '')) is True
    assert match(Command('unzip one.zip two.tar.gz file.zip', '')) is True
    assert match(Command('unzip file', '')) is True
    assert match(Command('unzip file', '')) is True
    assert match(Command('unzip file.tar', '')) is False
    assert match(Command('unzip file.tar', '')) is False
    assert match(Command('unzip -d dir file.zip', '')) is False
    assert match(Command('unzip -d dir file.zip', '')) is False
    assert match(Command('unzip -d dir one.zip two.tar.gz file.zip', '')) is False
    assert match(Command('unzip -d dir one.zip two.tar.gz file.zip', ''))

# Generated at 2022-06-26 05:48:48.684493
# Unit test for function match
def test_match():
    assert match('Some_string') == False


# Generated at 2022-06-26 05:48:51.318383
# Unit test for function side_effect
def test_side_effect():
    float_0 = -669.0
    float_1 = -669.0
    assert side_effect(float_0, float_1) == None


# Generated at 2022-06-26 05:48:54.223323
# Unit test for function side_effect
def test_side_effect():
    int_0 = 0
    str_0 = 'for'
    # redundancy for side_effect
    assert(side_effect(int_0, str_0)==None)


# Generated at 2022-06-26 05:49:06.528518
# Unit test for function side_effect
def test_side_effect():
    float_0 = -75.2

# Generated at 2022-06-26 05:49:08.448816
# Unit test for function match
def test_match():
    test_case = -669.0
    assert match(test_case) == False


# Generated at 2022-06-26 05:49:18.648777
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', '')) is True
    assert match(Command('unzip file.zip', '', '')) is False
    assert match(Command('unzip -d file.zip', '', '')) is False
    assert match(Command('unzip -d file.zip', '', '')) is False
    assert match(Command('unzip -d file.zip', '', '')) is False
    assert match(Command('unzip -d file.zip', '', '')) is False
    assert match(Command('unzip -d file.zip', '', '')) is False
    assert match(Command('unzip -d file.zip', '', '')) is False
    assert match(Command('unzip -d file.zip', '', '')) is False



# Generated at 2022-06-26 05:49:26.867541
# Unit test for function side_effect
def test_side_effect():
    from thefuck.main import Command
    from thefuck.types import CorrectedCommand
    from thefuck.rules.unzip_single_file import side_effect
    from thefuck.rules.unzip_single_file import _zip_file

    zip_file = _zip_file(Command('unzip file.zip'))
    old_cmd = Command('unzip file.zip', 'unzip:  must specify one of -t, -x, -d, or -l\n')
    side_effect(old_cmd, CorrectedCommand('unzip file.zip -d {}'.format(zip_file[:-4]), ''))
    # Test that side_effect function is working as expected
    assert True

# Generated at 2022-06-26 05:49:28.729495
# Unit test for function side_effect
def test_side_effect():
    assert_equal(side_effect, None)
    assert_raises(TypeError, side_effect, None, '')
    assert_raises(TypeError, side_effect, '', None)


# Generated at 2022-06-26 05:49:30.181181
# Unit test for function side_effect
def test_side_effect():
    assert True


# Generated at 2022-06-26 05:49:57.916160
# Unit test for function match
def test_match():
    if match(123):
        assert True
    else:
        assert False

# Generated at 2022-06-26 05:50:05.724546
# Unit test for function match
def test_match():
    command = 'unzip .'
    assert match(command) == False
    command = 'unzip /tmp/not_exist'
    assert match(command) == False
    command = 'unzip /tmp/exist.zip'
    assert match(command) == False
    command = 'unzip -l /tmp/exist.zip'
    assert match(command) == False
    command = 'unzip -l /tmp/not_exist'
    assert match(command) == False
    command = 'unzip -d /tmp /tmp/exist.zip'
    assert match(command) == False
    command = 'unzip -d /tmp /tmp/not_exist'
    assert match(command) == False
    command = 'unzip -l /tmp/bad.zip'
    assert match(command) == True

# Generated at 2022-06-26 05:50:13.409486
# Unit test for function match
def test_match():
    # checking if the correct output is generated
    import re
    import thefuck as tf

    shell = tf.shell.from_clerk(
        os.getenv('SHELL', 'bash'), alias=tf.shell.alias.from_clerk())
    new_command = get_new_command(
        tf.Command('', '', '', stderr=('unzip:  cannot find or open '
                                      '.zip, .ZIP or ZIP.\r\n')))

    assert (re.match(r'unzip \-d \S+', new_command, re.U | re.I) != None) == True



# Generated at 2022-06-26 05:50:16.993677
# Unit test for function match
def test_match():
    float_1 = -593.0
    assert match(float_1)


# Generated at 2022-06-26 05:50:20.071480
# Unit test for function match
def test_match():
    var_0 = _zip_file(var_0)
    var_1 = os.path.join()


# Generated at 2022-06-26 05:50:23.931289
# Unit test for function match
def test_match():
    assert match('')         # == False
    assert match('-d')       # == False
    assert match('-x')       # == False
    assert match('unzip')    # == False


# Generated at 2022-06-26 05:50:27.044545
# Unit test for function match
def test_match():
    assert not is_bad_zip("unzip_test.py")
    assert not match("unzip unzip_test.py")
    assert match("unzip unzip_test.py")


# Generated at 2022-06-26 05:50:35.734559
# Unit test for function match
def test_match():
    float_0 = 669.0
    float_0 = 'test_value'
    assert _zip_file(float_0) == 'test_value.zip'
    assert match(float_0) == True if _is_bad_zip(
        'test_value.zip') else False
    float_0 = -669.0
    float_0 = '-d'
    assert match(float_0) == False


# Generated at 2022-06-26 05:50:39.168614
# Unit test for function side_effect
def test_side_effect():
    assert side_effect(float_0, float_0) == None

if __name__ == '__main__':
    test_case_0()
    test_side_effect()

# Generated at 2022-06-26 05:50:43.167060
# Unit test for function match
def test_match():
    var_1 = unittest.TestCase()
    var_1.assertTrue(match(var_1))


# Generated at 2022-06-26 05:51:36.037281
# Unit test for function side_effect
def test_side_effect():
    float_0 = -669.0
    assert side_effect(float_0, '') == ""


# Generated at 2022-06-26 05:51:39.305248
# Unit test for function side_effect
def test_side_effect():
    float_0 = -669.0
    var_0 = get_new_command(float_0)
    side_effect(float_0, var_0)


# Generated at 2022-06-26 05:51:44.394649
# Unit test for function side_effect
def test_side_effect():
    float_0 = -669.0
    var_0 = get_new_command(float_0)
    side_effect(float_0, var_0)


if (__name__ == '__main__'):
    test_case_0()
    test_side_effect()

# Generated at 2022-06-26 05:51:47.689476
# Unit test for function match
def test_match():
    float_0 = -669.0
    var_0 = _is_bad_zip(float_0)
    var_1 = match(float_0)
    assert(var_0 == var_1)


# Generated at 2022-06-26 05:51:49.517424
# Unit test for function side_effect
def test_side_effect():
    assert side_effect(1, 2) == 2

# Generated at 2022-06-26 05:51:50.261357
# Unit test for function match
def test_match():
    pass


# Generated at 2022-06-26 05:51:50.740087
# Unit test for function side_effect
def test_side_effect():
    pass

# Generated at 2022-06-26 05:51:54.857077
# Unit test for function match
def test_match():
    var_0 = 'unzip package.zip'
    var_1 = _is_bad_zip('package.zip')
    assert match(var_0) == var_1
    var_0 = 'unzip package.zip'
    var_1 = _is_bad_zip('package.zip')
    assert match(var_0) == var_1
    var_0 = 'unzip package.zip'
    var_1 = _is_bad_zip('package.zip')
    assert match(var_0) == var_1
    var_0 = 'unzip package.zip'
    var_1 = _is_bad_zip('package.zip')
    assert match(var_0) == var_1


# Generated at 2022-06-26 05:51:57.963029
# Unit test for function match
def test_match():
    if __name__ == '__main__':
        var_0 = match(float_0)
        if var_0:
            print(var_0)
        else:
            print(var_0)


# Generated at 2022-06-26 05:52:05.932655
# Unit test for function match
def test_match():
    var_0 = 'unzip IO.zip'
    var_0 = match(var_0)
    var_1 = os.path.join(os.getcwd(), 'IO.zip')
    var_1 = _is_bad_zip(var_1)
    var_2 = var_0
    var_0 = type(var_0)
    var_2 = type(var_2)
    assert var_0 is bool
    assert var_2 is bool
    assert var_0 == var_1


# Generated at 2022-06-26 05:54:03.554167
# Unit test for function match
def test_match():
    var_0 = match("unzip -u '/home/rs/projeto/app/.gitignore'", "")
    assert var_0
    var_1 = match("unzip -u '/home/rs/projeto/app/.gitignore'", "")
    assert not var_1



# Generated at 2022-06-26 05:54:05.979357
# Unit test for function match
def test_match():
    var_1 = 'unzip -d foo.zip'
    var_2 = match(var_1)
    assert var_2 == false



# Generated at 2022-06-26 05:54:07.985377
# Unit test for function side_effect
def test_side_effect():
    try:
        # setup
        side_effect(old_cmd, command)
    except Exception as e:
        # verify
        raise AssertionError(str(e))
    finally:
        # cleanup
        pass

# Generated at 2022-06-26 05:54:08.472719
# Unit test for function side_effect
def test_side_effect():
    assert True


# Generated at 2022-06-26 05:54:09.885332
# Unit test for function side_effect
def test_side_effect():
    pass


# Generated at 2022-06-26 05:54:11.950281
# Unit test for function match
def test_match():
    assert _is_bad_zip('badzip.zip') == True, 'Is not Bad Zip'


# Generated at 2022-06-26 05:54:12.751937
# Unit test for function match
def test_match():
    assert match([]) == False


# Generated at 2022-06-26 05:54:13.815937
# Unit test for function side_effect
def test_side_effect():
    var_0 = side_effect(test_case_0())



# Generated at 2022-06-26 05:54:18.673569
# Unit test for function side_effect
def test_side_effect():
    # A possible side effect of this test is that
    # "W: Possible missing firmware /lib/firmware/i915/kbl_dmc_ver1_01.bin for module i915"
    # is logged. This is not what we test here, it's a side effect.
    int_0 = 2147483647
    var_0 = side_effect(int_0, 32767)


# Generated at 2022-06-26 05:54:25.301693
# Unit test for function match
def test_match():
    assert match(Command('unzip', 'unzip *.zip'))
    assert match(Command('unzip', 'unzip -l *.zip'))
    assert not match(Command('unzip', 'unzip -d *.zip'))
    assert not match(Command('unzip', 'unzip a/b/c/*.zip'))
    assert match(Command('unzip', 'unzip -l a/b/c/*.zip'))