

# Generated at 2022-06-26 05:46:25.890666
# Unit test for function side_effect
def test_side_effect():
    assert isinstance(side_effect(), object) or isinstance(side_effect(), type)

import unittest


# Generated at 2022-06-26 05:46:30.275357
# Unit test for function match
def test_match():
	assert match('') == False



# Generated at 2022-06-26 05:46:31.444188
# Unit test for function side_effect
def test_side_effect():
    assert side_effect is not None
# vim: noai:ts=4:sw=4

# Generated at 2022-06-26 05:46:42.633292
# Unit test for function match
def test_match():
    cases = dict()
    cases['1'] = dict()
    cases['1']['given'] = 'unzip file.zip'
    cases['1']['want'] = False
    cases['2'] = dict()
    cases['2']['given'] = 'unzip file.zip -d dest_dir'
    cases['2']['want'] = False
    cases['3'] = dict()
    cases['3']['given'] = 'unzip file.zip -d dest_dir'
    cases['3']['want'] = False

    for case in cases:
        cases[case]['got'] = match(cases[case]['given'])

# Generated at 2022-06-26 05:46:44.107421
# Unit test for function match
def test_match():
    assert match() == "unzip -d"

# Generated at 2022-06-26 05:46:47.232346
# Unit test for function match
def test_match():
    cmd_0 = """unzip /tmp/zip_file_name.zip"""
    fnmatch_0 = match(cmd_0)
    if fnmatch_0 is None:
        print ("Test case 0: filter unzip: Failed, no match")
        return
    test_case_0()
    return

# Generated at 2022-06-26 05:46:58.251712
# Unit test for function match
def test_match():
    assert zipfile.ZipFile('/home/mm/njtech/thefuck/thefuck/rules/unzip_extract_to.py__.zip', 'r')
    assert os.path.abspath(file).startswith(os.getcwd())
    assert shell.quote(_zip_file(list_0)[:-4])
    assert test_case_0()
    assert test_match()

# Generated at 2022-06-26 05:46:59.501108
# Unit test for function side_effect
def test_side_effect():
    assert side_effect() == 'None'


# Generated at 2022-06-26 05:47:00.653139
# Unit test for function side_effect
def test_side_effect():
    for_app('unzip').side_effect(list_0, '')

# Generated at 2022-06-26 05:47:02.590361
# Unit test for function match
def test_match():
    list_0 = []
    var_1 = match(list_0)
    assert var_1 == False

# Generated at 2022-06-26 05:47:14.277446
# Unit test for function match
def test_match():
    assert True == match(['unzip', 'foo.zip'])
    assert True == match(['unzip', 'foo'])
    assert False == match(['unzip', '-d', 'bar', 'foo.zip'])
    assert False == match(['unzip', '-d', 'bar', 'foo'])
    assert False == match(['unzip', '-d', 'bar', 'foo', 'bar'])


# Generated at 2022-06-26 05:47:16.830381
# Unit test for function side_effect
def test_side_effect():
    list_0 = []
    side_effect(list_0, str)


# Generated at 2022-06-26 05:47:18.053470
# Unit test for function side_effect
def test_side_effect():
    assert side_effect


# Generated at 2022-06-26 05:47:19.389341
# Unit test for function side_effect
def test_side_effect():
    assert side_effect(list_0) == result_0


# Generated at 2022-06-26 05:47:22.685320
# Unit test for function side_effect
def test_side_effect():
    import unittest
    assert unittest.Callable(side_effect)
    
    list_0 = []
    var_0 = side_effect(list_0)


# Generated at 2022-06-26 05:47:26.003958
# Unit test for function side_effect
def test_side_effect():
    assert True


# Generated at 2022-06-26 05:47:28.299796
# Unit test for function match
def test_match():
    assert match(list_0) == False


# Generated at 2022-06-26 05:47:30.255976
# Unit test for function side_effect
def test_side_effect():
    def fn():
        return ['a']

    side_effect(fn, 'b')
    side_effect(fn, 'b')

# Generated at 2022-06-26 05:47:31.098184
# Unit test for function match
def test_match():
    assert match([]) == False


# Generated at 2022-06-26 05:47:33.304357
# Unit test for function side_effect
def test_side_effect():
    assert os.path.exists(str(var_0))

# Generated at 2022-06-26 05:47:44.933333
# Unit test for function match
def test_match():
    # Verify that globals are set as expected
    assert len(list(_is_bad_zip(list(zipfile)))) == len(list(set(list(zipfile))))


# Generated at 2022-06-26 05:47:47.242997
# Unit test for function match
def test_match():
    list_0 = ['unzip', '-d', '/tmp/extract_here', 'pic.zip']
    var_0 = _is_bad_zip(list_0)
    assert var_0 == False


# Generated at 2022-06-26 05:47:50.001547
# Unit test for function side_effect
def test_side_effect():
    old_cmd = ["unzip", "-d", "~/Pictures"]
    command = get_new_command(old_cmd)

    side_effect(old_cmd, command)

# Generated at 2022-06-26 05:47:52.590120
# Unit test for function match
def test_match():
    assert match(u'unzip abc.zip')
    assert not match(u'unzip -d /tmp/out abc.zip')
    assert not match(list(None))


# Generated at 2022-06-26 05:47:56.675000
# Unit test for function side_effect
def test_side_effect():
    file_path = os.path.abspath(__file__)
    script_dir = os.path.dirname(file_path)
    cur_dir = os.getcwd()
    os.chdir(script_dir)

    new_file = os.path.join(script_dir, 'test.zip')
    try:
        with zipfile.ZipFile(new_file, 'w'):
            pass
        side_effect(list_0, var_0)
        assert not os.path.exists(new_file)
    finally:
        os.chdir(cur_dir)

# Generated at 2022-06-26 05:47:58.304150
# Unit test for function match
def test_match():
    assert match == False

if __name__ == '__main__':
    test_match()

# Generated at 2022-06-26 05:47:58.995146
# Unit test for function side_effect
def test_side_effect():
    pass

# Generated at 2022-06-26 05:48:00.093009
# Unit test for function match
def test_match():
    list_0 = []
    match(list_0)


# Generated at 2022-06-26 05:48:08.315057
# Unit test for function match
def test_match():
    assert True == match('unzip file.zip -d /')
    assert True == match('unzip file.zip')
    assert False == match('unzip -h')
    assert False == match('unzip -d')
    assert False == match('unzip -d dir file.zip')
    assert False == match('unzip -d dir')
    assert False == match('unzip')
    assert False == match('unzip -')
    assert False == match('unzip -d dir - foo.zip')
    assert False != match('unzip -d dir -d')


# Generated at 2022-06-26 05:48:10.925577
# Unit test for function side_effect
def test_side_effect():
    list_0 = []
    side_effect(list_0, list_0)


# Generated at 2022-06-26 05:48:31.805527
# Unit test for function side_effect
def test_side_effect():
    assert side_effect(list_0, var_0)
# unit test for function match

# Generated at 2022-06-26 05:48:35.703056
# Unit test for function match
def test_match():
    list_0 = []
    var_0 = _zip_file(list_0)
    var_1 = _is_bad_zip(list_0)
    var_2 = match(list_0)

# Generated at 2022-06-26 05:48:45.716382
# Unit test for function match
def test_match():
    var_1 = os.path.abspath('/usr')
    var_2 = os.path.abspath('/Users/joshgavin')
    var_3 = os.path.abspath('/bin')
    list_0 = ['/usr', '/bin', '/etc']
    var_4 = u'unzip -d /etc'
    list_1 = ['/usr', '/bin', '/etc']
    var_5 = u'unzip -d /usr'
    list_2 = ['/usr', '/bin', '/etc']
    var_6 = u'unzip -d /bin'
    list_3 = ['/usr', '/bin', '/etc']
    var_7 = u'unzip -d /etc'
    list_4 = ['/usr', '/bin', '/etc']
    var_

# Generated at 2022-06-26 05:48:47.282489
# Unit test for function match
def test_match():
    assert match(list_0) == False


# Generated at 2022-06-26 05:48:48.245470
# Unit test for function match
def test_match():
    assert match == True


# Generated at 2022-06-26 05:48:50.232035
# Unit test for function match
def test_match():
    list_0 = []
    var_0 = match(list_0)


# Generated at 2022-06-26 05:48:50.757809
# Unit test for function match
def test_match():
    assert False

# Generated at 2022-06-26 05:48:55.583715
# Unit test for function side_effect
def test_side_effect():
    list_0 = []
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Generated at 2022-06-26 05:49:06.640249
# Unit test for function match
def test_match():
    list_0 = ['unzip', '-r', '-Z', '-T', '-J', '-U', 'zip_file_0']
    var_0 = _zip_file(list_0)
    var_1 = _is_bad_zip(var_0)
    var_2 = match(list_0)
    assert(var_2 == False)
    list_1 = ['unzip', '-r', '-Z', '-T', '-J', '-U', 'zip_file_0.zip']
    var_3 = _zip_file(list_1)
    var_4 = _is_bad_zip(var_3)
    var_5 = match(list_1)
    assert(var_5 == False)

# Generated at 2022-06-26 05:49:07.629027
# Unit test for function match
def test_match():
    assert match(var_0)

# Generated at 2022-06-26 05:49:49.371618
# Unit test for function side_effect
def test_side_effect():
    list_0 = []
    command_0 = get_new_command(list_0)
    side_effect(list_0, command_0)


# Generated at 2022-06-26 05:49:58.198578
# Unit test for function match
def test_match():
    try:
        # test with assert
        var_0 = _zip_file(list_0)
        assert var_0 == '.zip'
        assert var_0 == 'file(s)'
        var_1 = _is_bad_zip(var_0)
        assert var_1
        var_0 = get_new_command(list_0)
        assert var_0 == '.zip'
        assert var_0 == 'file(s)'
        assert var_0 == '-x'
        var_1 = match(list_0)
        assert var_1
    except AssertionError:
        pass


# Generated at 2022-06-26 05:50:03.629598
# Unit test for function side_effect
def test_side_effect():
    var_1 = ["unzip", "some_folder.zip"]
    side_effect(var_1)
    var_2 = ["unzip", "some_folder", "some_file"]
    side_effect(var_2)

if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-26 05:50:05.641330
# Unit test for function side_effect
def test_side_effect():
    assert side_effect(['unzip', 'file_name'], ['unzip', '-d', 'file_name']) == None


# Generated at 2022-06-26 05:50:07.098359
# Unit test for function side_effect
def test_side_effect():
    list_0 = []
    side_effect(list_0, list_0)


# Generated at 2022-06-26 05:50:09.670096
# Unit test for function side_effect
def test_side_effect():
    if besar.side_effect(list_0,list_0) == var_0:
        return True
    else:
        return False

# Generated at 2022-06-26 05:50:11.397860
# Unit test for function side_effect
def test_side_effect():
    command_0 = "" 
    int_0 = side_effect(command_0, command_0)


# Generated at 2022-06-26 05:50:14.879270
# Unit test for function match
def test_match():
    assert match(list_0)


# Generated at 2022-06-26 05:50:18.200609
# Unit test for function match
def test_match():
    _is_bad_zip(var_0)
    assert dict(_is_bad_zip) == dict(_is_bad_zip)

# Generated at 2022-06-26 05:50:24.222499
# Unit test for function match
def test_match():
    #1
    command = "unzip -qqo /home/subhojit777/git/TheFuck/tests/source.zip"
    assert not match(command)
    #2
    command = "unzip -qqo /home/subhojit777/git/TheFuck/tests/invalid.zip"
    assert match(command)


# Generated at 2022-06-26 05:51:42.722942
# Unit test for function side_effect
def test_side_effect():
    list_0 = []
    var_0 = side_effect(list_0, list_0)


# Generated at 2022-06-26 05:51:43.650709
# Unit test for function side_effect
def test_side_effect():
    test_case_0()



# Generated at 2022-06-26 05:51:46.761012
# Unit test for function side_effect
def test_side_effect():
    try:
        globals().__setitem__("os_remove", os.remove)
    except KeyError:
        pass
    side_effect(globals().__getitem__("var_0"), globals().__getitem__("var_1"))


# Generated at 2022-06-26 05:51:55.386470
# Unit test for function side_effect
def test_side_effect():
    thefuck.shells.get_closest.return_value = shell.Script(['unzip', '-d'])
    with patch.object(os, 'remove') as mock_remove:
        # TODO: mockos.path.abspath(), os.getcwd()

        # 1) .zip contains file that is not under the cwd,
        # nothing should be removed
        side_effect(list_0,list_0)
        assert not mock_remove.called

        # 2) .zip contains file that is in the cwd, should be removed
        # (even if the file is a directory, which is unexpected by the
        # user)
        side_effect(list_0,list_0)
        mock_remove.assert_called_once_with('file')

        # 3) .zip contains file that is in the

# Generated at 2022-06-26 05:51:56.150792
# Unit test for function side_effect
def test_side_effect():
    assert callable(side_effect)



# Generated at 2022-06-26 05:51:57.853180
# Unit test for function side_effect
def test_side_effect():
    assert side_effect(list_0, var_0) == None

# Generated at 2022-06-26 05:52:05.391091
# Unit test for function side_effect
def test_side_effect():
    with zipfile.ZipFile(_zip_file(old_cmd), 'r') as archive:
        for file in archive.namelist():
            if not os.path.abspath(file).startswith(os.getcwd()):
                # it's unsafe to overwrite files outside of the current directory
                continue

            try:
                os.remove(file)
            except OSError:
                # does not try to remove directories as we cannot know if they
                # already existed before
                pass

# Generated at 2022-06-26 05:52:15.979020
# Unit test for function match
def test_match():
    list_0 = []
    list_0 = [list_0, u"unzip", u"~/mdr.zip"]
    var_0 = _is_bad_zip(list_0)
    var_1 = match(list_0)
    var_2 = get_new_command(list_0)
    var_3 = side_effect(list_0, list_0)
    list_0 = [list_1, u"unzip", u"~/mdr/mdr/mdr.zip"]
    list_1 = []
    var_4 = _is_bad_zip(list_0)
    var_5 = match(list_1)
    var_6 = get_new_command(list_1)
    var_7 = side_effect(list_1, list_1)
    var_

# Generated at 2022-06-26 05:52:17.682574
# Unit test for function match
def test_match():
    assert match(list_0) > match(list_1)


# Generated at 2022-06-26 05:52:19.971267
# Unit test for function match
def test_match():
    new_list = list()
    var0 = _is_bad_zip(new_list)


# Generated at 2022-06-26 05:55:30.300485
# Unit test for function match
def test_match():
    output = match(command)
    assert output == None

# Generated at 2022-06-26 05:55:30.896415
# Unit test for function match
def test_match():
  test_case_0()


# Generated at 2022-06-26 05:55:32.655908
# Unit test for function side_effect
def test_side_effect():
    file_0 = 'test'
    cmd_0 = [u'unzip', u'test.zip']
    side_effect(cmd_0, file_0)

# Generated at 2022-06-26 05:55:33.309532
# Unit test for function side_effect
def test_side_effect():
    assert True == False


# Generated at 2022-06-26 05:55:37.949513
# Unit test for function match
def test_match():
    assert(match(list_0) == False)
    assert(match(list_0) == False)
    assert(match(list_0) == False)
    assert(match(list_0) == False)
    assert(match(list_0) == False)
    assert(match(list_0) == False)


# Generated at 2022-06-26 05:55:45.003725
# Unit test for function match
def test_match():
    for d in os.listdir("../"):
        if str(d).startswith("Test"):
            if str(d) == "Test0":
                list_0 = []
                var_0 = match(list_0)
                assert var_0 == False
            if str(d) == "Test1":
                list_1 = []
                var_1 = match(list_1)
                assert var_1 == False
            if str(d) == "Test2":
                list_2 = []
                var_2 = match(list_2)
                assert var_2 == False
            if str(d) == "Test3":
                list_3 = []
                var_3 = match(list_3)
                assert var_3 == False
            if str(d) == "Test4":
                list_4

# Generated at 2022-06-26 05:55:45.974143
# Unit test for function match
def test_match():
    assert match(list_0) == bool(0)


# Generated at 2022-06-26 05:55:54.677815
# Unit test for function match
def test_match():
    assert not match(list('unzip'))
    assert not match(list('unzip -l'))
    assert not match(list('unzip -d mydir archive.zip'))
    assert not match(list('unzip -d mydir archive.zip file1'))
    assert not match(list("unzip -d mydir 'archive.zip'"))
    assert not match(list("unzip -d mydir 'archive.zip' file1"))
    assert not match(list("unzip -d 'mydir' archive.zip file1"))
    assert match(list('unzip archive.zip'))
    assert not match(list('unzip archive.zip file1'))
    assert not match(list("unzip 'archive.zip'"))
    assert not match(list("unzip 'archive.zip' file1"))

# Generated at 2022-06-26 05:56:03.941962
# Unit test for function match
def test_match():
    assert _is_bad_zip('.')
    assert _is_bad_zip('./')
    assert _is_bad_zip('../')
    assert _is_bad_zip('./foo')
    assert _is_bad_zip('./foo.zip')
    assert _is_bad_zip('../foo')
    assert _is_bad_zip('../foo.zip')
    assert _is_bad_zip('/')
    assert _is_bad_zip('/home')
    assert _is_bad_zip('/home/')
    assert _is_bad_zip('/home/foo')
    assert _is_bad_zip('/home/foo.zip')
    assert _is_bad_zip('/home/../foo')
    assert _is_bad_zip('/home/../foo.zip')


# Generated at 2022-06-26 05:56:07.037287
# Unit test for function match
def test_match():
    assert (match("unzip a.zip")) == False
    assert (match("unzip -d a.zip")) == False
    assert (match("unzip a.zip b.zip")) == True
    assert (match("unzip a.zip b.zip -x c.zip")) == True
