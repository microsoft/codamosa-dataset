

# Generated at 2022-06-26 05:46:28.744111
# Unit test for function match
def test_match():
    assert match("unzip file.zip") == False
    assert match("unzip -d dir file.zip") == False
    assert match("unzip file.zip") == False
    assert match("unzip -d dir file.zip") == False
    assert match("unzip -d dir file.zip") == False
    assert match("unzip file.zip") == False
    assert match("unzip -d dir file.zip") == False
    assert match("unzip file.zip") == False
    assert match("unzip -d dir file.zip") == False
    assert match("unzip -d dir file.zip") == False
    assert match("unzip -d dir file.zip") == False
    assert match("unzip file.zip") == False
    assert match("unzip -d dir file.zip") == False

# Generated at 2022-06-26 05:46:40.547852
# Unit test for function side_effect
def test_side_effect():
    # Construction of a mock object.
    zip_file = mock.Mock()

    # Accessing the mock object as a context manager.
    with mock.patch.object(zipfile, 'ZipFile', return_value=zip_file) as mock_zipfile_zipfile:
        # Calling the function under test.
        side_effect(mock.Mock(), mock.Mock())

        # Verifying that the mock has been called.
        mock_zipfile_zipfile.assert_called_once_with(zip_file, 'r')

        # Accessing the mock object attributes.
        mock_zipfile_zipfile.return_value.namelist.assert_called_once_with()

# Generated at 2022-06-26 05:46:48.985144
# Unit test for function match
def test_match():
    var_0 = match('>')
    assert var_0 == False
    var_1 = match('grep HI -i')
    assert var_1 == False
    var_2 = match('grep HI -i | grep HI -i')
    assert var_2 == True
    var_3 = match('grep HI -i | grep HI -i | grep HI -i')
    assert var_3 == True
    var_4 = match('grep HI -i | grep HI -i | grep HI -i | grep HI -i')
    assert var_4 == True
    var_5 = match('grep HI -i | grep HI -i | grep HI -i | grep HI -i | grep HI -i')
    assert var_5 == True

# Generated at 2022-06-26 05:46:49.999097
# Unit test for function side_effect
def test_side_effect():
    assert side_effect(str_0, str_0) == None


# Generated at 2022-06-26 05:46:51.606743
# Unit test for function match
def test_match():
    str_0 = '>'

    try:
        var_0 = match(str_0)
    except Exception as e:
        assert False



# Generated at 2022-06-26 05:47:02.436930
# Unit test for function side_effect
def test_side_effect():
    with patch('thefuck.rules.unzip.zipfile.ZipFile') as mock_zipfile:
        with patch('thefuck.rules.unzip.shell.quote') as mock_shell:
            with patch('thefuck.rules.unzip.os.remove') as mock_remove:
                with patch('thefuck.rules.unzip.os.getcwd') as mock_getcwd:
                    mock_remove.side_effect = [OSError, None]
                    mock_getcwd.return_value = '\\tmp'
                    side_effect(mock_zipfile.return_value, mock_shell.return_value)
                    mock_remove.assert_called_once_with('\\tmp\\unzip')
# Test case for function match

# Generated at 2022-06-26 05:47:08.413121
# Unit test for function side_effect
def test_side_effect():
    str_0 = '>'
    var_0 = match(str_0)
    str_1 = '>'
    var_1 = get_new_command(str_1)
    side_effect(str_1, var_1)

# Generated at 2022-06-26 05:47:14.746170
# Unit test for function match
def test_match():
    assert match('') == False
    assert match('\n') == False
    assert match('unzip test') == False
    assert match('unzip test -d test') == False
    assert match('unzip test -d') == False
    assert match('unzip test/test.zip') == False
    assert match('unzip test/test') == False

if __name__ == "__main__":
    test_case_0()
    test_match()

# Generated at 2022-06-26 05:47:18.079539
# Unit test for function match
def test_match():
    command = 'unzip'
    assert_equals(False, match(command))
    zip_file = 'archive.zip'
    command = 'unzip'


# Generated at 2022-06-26 05:47:20.525630
# Unit test for function side_effect
def test_side_effect():
    str_0 = '>'
    str_1 = '>'
    var_0 = side_effect(str_0, str_1)


# Generated at 2022-06-26 05:47:28.667983
# Unit test for function match
def test_match():
    output_0 = _is_bad_zip(str_0)
    assert output_0 == False


# Generated at 2022-06-26 05:47:29.903495
# Unit test for function match
def test_match():
    assert True == match(str_0)


# Generated at 2022-06-26 05:47:36.465841
# Unit test for function match
def test_match():
    input_0 = 'unzip 1.zip'
    input_1 = 'unzip 1.zip 2'
    input_2 = 'unzip 1.zip 2.zip'
    input_3 = 'unzip -d 1 2.zip'
    input_4 = 'unzip 1.zip 2.zip'
    input_5 = 'unzip 1.zip 2'
    output_2 = False
    output_4 = False
    output_0 = output_2
    output_1 = output_2
    output_3 = output_4

    pass_bool_0 = match(input_0)
    pass_bool_1 = match(input_1)
    pass_bool_2 = match(input_2)
    pass_bool_3 = match(input_3)
    pass_bool_4 = match(input_4)

# Generated at 2022-06-26 05:47:43.204365
# Unit test for function side_effect
def test_side_effect():
    class Arch:
        def namelist(self):
            return ['file1']
    before = ['unzip', 'file1.zip']
    after = ['unzip', '-d', 'file1', 'file1.zip']
    assert match(Command(' '.join(before)))
    assert get_new_command(Command(' '.join(before))) == ' '.join(after)
    side_effect(Command(' '.join(before)), None)

if __name__ == '__main__':
    for i in range(7):
        test_case_0()
    test_side_effect()

# Generated at 2022-06-26 05:47:50.288893
# Unit test for function side_effect
def test_side_effect():
    str_0 = '/bin/unzip'
    str_1 = '-d'
    str_2 = 'Sites.zip'
    str_3 = 'Sites.zip Sites.zip'
    str_4 = 'command: /bin/unzip -d Sites.zip Sites.zip'
    str_5 = 'type: program'
    str_6 = '---'
    str_7 = '/bin/unzip -d "Sites"'
    str_8 = 'Sites.zip'
    str_9 = 'r'
    tuple_5 = (str_1, str_2, str_3)
    tuple_6 = (str_4, str_5, str_6)
    tuple_7 = (str_7, str_8, str_9)

# Generated at 2022-06-26 05:47:54.440521
# Unit test for function match
def test_match():
    # TODO: Test raises unzip:  cannot find or open XXXX.zip, XXXX.zip.zip or XXXX.zip.ZIP
    command = Command(script='unzip {}')
    assert not match(command)
    command = Command(script='unzip {} -d {}')
    assert not match(command)
    command = Command(script='unzip {}')
    assert match(command)


# Generated at 2022-06-26 05:47:57.408208
# Unit test for function match
def test_match():
    assert (match(Command('unzip file.zip')) == False)
    assert (match(Command('unzip file.zip file file -x file')) == False)


# Generated at 2022-06-26 05:48:07.743030
# Unit test for function match
def test_match():
    str_0 = 'e7z'
    str_1 = 'unzip -l e7z.zip'
    str_2 = 'unzip e7z.zip'
    str_3 = 'e7z.zip'
    str_4 = 'unzip -d e7z'
    command = type('Command', (object,), {'script': str_3})
    bool_0 = False
    assert match(command) == bool_0
    command = type('Command', (object,), {'script': str_4})
    assert match(command) == bool_0
    command = type('Command', (object,), {'script': str_0})
    bool_1 = True
    assert match(command) == bool_1

# Generated at 2022-06-26 05:48:18.229051
# Unit test for function match
def test_match():
    str_0 = 'u'
    answer_0 = match(str_0)
    str_1 = 'unzip -d'
    answer_1 = match(str_1)
    str_2 = 'unzip foo.zip'
    answer_2 = match(str_2)
    str_3 = 'unzip foo.zip bar.zip'
    answer_3 = match(str_3)
    str_4 = 'unzip -d foo.zip.zip'
    answer_4 = match(str_4)
    str_5 = 'unzip -d foo.zip.zip bar'
    answer_5 = match(str_5)
    str_6 = 'unzip foo.zip.zip'
    answer_6 = match(str_6)
    str_7 = 'unzip foo.zip bar'
   

# Generated at 2022-06-26 05:48:24.041378
# Unit test for function match
def test_match():
    str_0 = 'unzip'
    str_1 = 'unzip'
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = '-d'
    str_6 = ''
    str_7 = ''
    str_8 = ''
    str_9 = 'unzip -d'
    str_10 = 'unzip -c'
    str_11 = ''
    str_12 = 'unzip -c'
    str_13 = 'unzip -d'
    str_14 = ''
    str_15 = 'unzip'
    str_16 = 'unzip'
    str_17 = ''
    str_18 = ''
    str_19 = ''
    str_20 = '-d'
    str_21 = ''
    str_22 = ''


# Generated at 2022-06-26 05:48:42.535272
# Unit test for function side_effect
def test_side_effect():
    # In case of zip files, unzip extracts a number of files in the current directory.
    # This can be a problem when you don't know what is inside the archive and
    # you don't want to overwrite existing files.
    # Try to unzip a file in a new directory.
    old_cmd = 'unzip foo.zip'
    command = 'unzip foo.zip -d foo'
    side_effect(command)


# Generated at 2022-06-26 05:48:48.655983
# Unit test for function side_effect
def test_side_effect():
    # Get line number of this method, then we could ignore it in traceback.
    line = sys._getframe().f_lineno + 1
    # Call function of this package, then raise exception
    str_0 = 's'
    try:
        assert False
    except AssertionError:
        # Get traceback
        _, _, tb = sys.exc_info()
        # Get traceback list
        tblist = traceback.extract_tb(tb)
        # Get index of this function in traceback list
        stack_index = next((i for i, v in enumerate(tblist)
                                if v[2] == 'test_side_effect'), None)

# Generated at 2022-06-26 05:48:59.144264
# Unit test for function match
def test_match():
    command = shell.and_('fzf', '-q', 'v', '-x')
    assert match(command) == False
    command = shell.and_('2', '-b', '^', '-p', '4')
    assert match(command) == False
    command = shell.and_('X', '-z', '10', '-t')
    assert match(command) == False
    command = shell.and_('^', '-5', '-b', '-t')
    assert match(command) == False
    command = shell.and_('0', '-0', '-v')
    assert match(command) == False
    command = shell.and_('-r', 'z', '-g')
    assert match(command) == False

# Generated at 2022-06-26 05:49:07.996530
# Unit test for function side_effect
def test_side_effect():
    str_0 = 'r'
    str_1 = 'r'
    str_2 = 'r'
    str_3 = 'r'
    str_4 = 'r'
    str_5 = 'r'

    # call function
    side_effect(str_0, str_1)

    # call function
    side_effect(str_2, str_3)

    # call function
    side_effect(str_4, str_5)

    # call function
    side_effect(str_0, str_5)

    # call function
    side_effect(str_2, str_5)

    # call function
    side_effect(str_4, str_1)

    # call function
    side_effect(str_4, str_3)

    # call function

# Generated at 2022-06-26 05:49:11.188855
# Unit test for function side_effect
def test_side_effect():
    # TODO: Figure out how to 'old_cmd' in mock
    # str_0 = 'r'
    # assert test_case_0() == side_effect(old_cmd, command)
    return None


# Generated at 2022-06-26 05:49:16.757330
# Unit test for function match
def test_match():
    func = match
    # 0
    str_0 = 'unzip test.zip'
    ret = func(str_0)
    assert ret == True
    # 1
    str_0 = 'unzip -d somedir/ test.zip'
    ret = func(str_0)
    assert ret == False


# Generated at 2022-06-26 05:49:26.498341
# Unit test for function match
def test_match():
    str_0 = 'unzip foo.zip'
    str_1 = 'unzip bar.zip'
    str_2 = 'unzip file.zip -d foo'
    str_3 = 'unzip foo.zip -d bar'
    str_4 = 'unzip foo.zip -d bar/'
    str_5 = 'unzip foo.zip foo/bar.txt'
    str_6 = 'unzip foo.zip'
    str_7 = 'unzip foo.zip'
    str_8 = 'unzip foo.zip'
    str_9 = 'unzip foo.zip'
    str_10 = 'unzip foo.zip'
    str_11 = 'unzip foo.zip'
    str_12 = 'unzip foo.zip'
    str_13 = 'unzip foo.zip'
    str

# Generated at 2022-06-26 05:49:32.445809
# Unit test for function match
def test_match():
    assert _is_bad_zip('tests/unzip_test.zip')
    assert not _is_bad_zip('tests/unzip_test_single.zip')

    assert not match(Command('unzip', 'unzip -d test_folder arch.zip'))
    assert match(Command('unzip', 'unzip arch.zip'))
    assert match(Command('unzip', 'unzip -o arch.zip'))


# Generated at 2022-06-26 05:49:35.968569
# Unit test for function match
def test_match():
    class Command_0:
        def __init__(self):
            self.script = str_0
    class Command_1:
        def __init__(self):
            self.script = str_0
    assert match(Command_0()) == False
    assert match(Command_1()) != False
    pass


# Generated at 2022-06-26 05:49:37.484365
# Unit test for function match
def test_match():
    assert(_zip_file(test_case_0) == _zip_file(test_case_0))


# Generated at 2022-06-26 05:49:54.758898
# Unit test for function side_effect
def test_side_effect():
    zip_file = str_0
    with zipfile.ZipFile(zip_file, 'r') as archive:
        for file in archive.namelist():
            if (not os.path.abspath(file).startswith(os.getcwd())):
                pass
            try:
                shell_0 = shell
                shell_0.set_environment(file, 'r', 'r')
                os.remove((file + str(2)))
            except OSError:
                pass
    # Return type annotation
    return None


# Generated at 2022-06-26 05:49:57.673916
# Unit test for function match
def test_match():
    # AssertionError: False is not True : Failed match test!
    assert match(str_0)


# Generated at 2022-06-26 05:49:59.990570
# Unit test for function match
def test_match():
    str_0 = 'r'

#Unit test for function get_new_command

# Generated at 2022-06-26 05:50:04.741882
# Unit test for function side_effect
def test_side_effect():
    with zipfile.ZipFile('./thefuck/rules/unzip.py', 'r') as archive:
        for file in archive.namelist():
            if not os.path.abspath(file).startswith(os.getcwd()):
                # it's unsafe to overwrite files outside of the current directory
                continue

            try:
                os.remove(file)
            except OSError:
                # does not try to remove directories as we cannot know if they
                # already existed before
                pass

# Generated at 2022-06-26 05:50:06.989805
# Unit test for function side_effect
def test_side_effect():
    mock_old_cmd = str_0
    mock_command = str_0

    # Pass: test_case_0
    side_effect(mock_old_cmd, mock_command)

# Generated at 2022-06-26 05:50:12.546244
# Unit test for function side_effect
def test_side_effect():
    zip_file_0 = 'foo_bar'
    shell_quote_0 = shell.quote('foo_bar')
    return_value_0 = os.path.dirname('foo_bar')
    test_function_0 = shell.quote
    return_value_1 = test_function_0('foo_bar')
    assert return_value_1 == shell_quote_0


# Generated at 2022-06-26 05:50:24.128870
# Unit test for function side_effect
def test_side_effect():
    str_0 = 'unzip \'*.{}.zip\''.format(str_0)
    str_1 = str_0[5:]
    str_2 = 'unzip \'-d\' \'*.{}.zip\''.format(str_0)
    str_3 = str_2[5:]
    str_4 = str_1.find(' ')
    str_5 = str_3[str_4 : str_4 + 2]
    str_6 = str_3[str_4 + 2 :]
    if not str_5 == str_3:
        str_3 = str_1.replace(str_5, str_5 + '$')
    else:
        str_3 = str_1 + '$'
    str_7 = str_3 + ' ' + str_6

# Generated at 2022-06-26 05:50:30.555316
# Unit test for function side_effect
def test_side_effect():
	str_0 = 'r'
	str_1 = 'unzip -l {}'
	str_2 = 'unzip -d {}'
	str_3 = 'unzip {}'
	try:
		os.remove('test.zip')
	except OSError:
		pass
	with zipfile.ZipFile('test.zip', 'w') as archive:
		archive.writestr('r', str_0)
	with open('r', 'r') as f:
		assert f.read() != str_0
	with zipfile.ZipFile('test.zip', 'r') as archive:
		assert archive.namelist() == ['r']
	timing_print('test output for unzipping without -d')
	with open('r', 'w') as f:
		f.write

# Generated at 2022-06-26 05:50:39.566772
# Unit test for function side_effect
def test_side_effect():
    str_0 = 'x'
    str_1 = 'sY^M[2@V'
    str_2 = 't~WhT#JF'
    str_3 = 'sY^M[2@Q'
    str_4 = 't~WhT#TK'

    # Setup mock object
    class mock_class_0:
        __init__ = test_case_0

    # Mock function to test side_effect
    class mock_class_1:
        argv = [str_0, str_1, str_2, str_3, str_4]
        script_parts = [str_0, str_1, str_2, str_3, str_4]
        def get_command(self):
            return str_0


# Generated at 2022-06-26 05:50:48.361881
# Unit test for function side_effect
def test_side_effect():
    str_0 = 'r'
    str_1 = 'r'
    str_2 = 'r'
    str_3 = 'r'
    str_4 = 'r'
    str_5 = 'r'
    str_6 = 'r'

    os.remove(str_0)
    os.remove(str_1)
    os.remove(str_2)
    str_3 = zipfile.ZipFile(str_0, 'r')
    str_4 = str_3.namelist()
    str_5 = os.path.abspath(str_1)
    str_6 = os.getcwd()

    if str_5.startswith(str_6) and not len(str_4) > 1:
        return 'r'


# Generated at 2022-06-26 05:51:20.166036
# Unit test for function match
def test_match():
    command_0 = 'unzip -l r.zip'
    str_0 = zipfile.ZipFile
    str_1 = 'r'
    str_2 = 'r.zip'
    assert _is_bad_zip(str_2) == True
    str_3 = 'unzip -l r.zip'
    str_4 = 'r.zip'
    str_5 = 'unzip -l r.zip'
    str_6 = 'r.zip'
    str_7 = 'unzip -l r.zip'
    str_8 = 'r.zip'
    str_9 = 'unzip -l r.zip'
    str_10 = 'r.zip'
    str_11 = 'unzip -l r.zip'
    str_12 = 'r.zip'

# Generated at 2022-06-26 05:51:23.656879
# Unit test for function side_effect
def test_side_effect():
    args_0 = {'script': str_0}
    old_cmd = namedtuple('old_cmd', 'script')(**args_0)
    zip_file = str_0
    command = str_0
    return side_effect(old_cmd, command)


# Generated at 2022-06-26 05:51:26.150476
# Unit test for function match
def test_match():
    str_0 = 'z'
    assrt_eq(match(str_0), "z")



# Generated at 2022-06-26 05:51:32.867439
# Unit test for function side_effect
def test_side_effect():
    str_0 = 'r'
    str_1 = 'r'
    file_0 = zipfile.ZipFile(str_0, 'r')
    list_0 = file_0.namelist()
    for str_2 in list_0:
        os.remove(str_2)
    str_3 = 'r'
    str_4 = 'r'
    str_5 = 'r'
    str_6 = 'r'
    str_7 = 'r'
    str_8 = 'r'
    file_1 = zipfile.ZipFile(str_7, 'r')
    list_1 = file_1.namelist()
    for str_9 in list_1:
        try:
            os.remove(str_9)
        except:
            pass
    str_10 = 'r'
   

# Generated at 2022-06-26 05:51:33.710694
# Unit test for function side_effect
def test_side_effect():
    assert side_effect is not None


# Generated at 2022-06-26 05:51:36.535675
# Unit test for function match
def test_match():
    str_0 = 'r'
    assert match(str_0) == False


# Generated at 2022-06-26 05:51:41.726755
# Unit test for function match
def test_match():
    assert match(Command('unzip foo.zip', '', stderr=''))
    assert not match(Command('unzip -d foo foo.zip'))
    assert not match(Command('unzip foo', '', stderr=''))
    assert not match(Command('', '', stderr=''))
    assert not match(Command('', '', ''))


# Generated at 2022-06-26 05:51:42.772571
# Unit test for function match
def test_match():
    assert match(str_0)


# Generated at 2022-06-26 05:51:44.570361
# Unit test for function match
def test_match():
    command = Command(script='unzip test.zip', output=None, stderr=None)
    assert match(command)


# Generated at 2022-06-26 05:51:46.830109
# Unit test for function side_effect
def test_side_effect():
    # Return type
    assert isinstance(side_effect(test_case_0(), test_case_0()), None)


# Generated at 2022-06-26 05:52:12.110460
# Unit test for function side_effect
def test_side_effect():
    old_cmd = object()
    command = object()
    side_effect(old_cmd, command)


# Generated at 2022-06-26 05:52:18.369343
# Unit test for function side_effect
def test_side_effect():
    var_18 = get_new_command("fool")
    var_19 = "echo fool"
    tree = ast.parse(var_19)
    var_20 = ast.fix_missing_locations(tree)
    var_21 = get_new_command("fool")

    assert side_effect("fool", "fool") == None

# Generated at 2022-06-26 05:52:29.455809
# Unit test for function match
def test_match():
    str_0 = 'unzip -u /home/user/.fuck/1590339742/zip/project-1.zip'
    str_1 = 'unzip project-1.zip'
    str_2 = 'unzip project-1.zip'
    str_3 = 'unzip /home/user/.fuck/1590339742/zip/project-1.zip'
    str_4 = 'unzip -j -r /home/user/.fuck/1590339742/zip/project-1.zip'
    str_5 = 'unzip project.zip'
    var_0 = _is_bad_zip(str_5)
    var_1 = _zip_file(str_1)
    var_2 = _zip_file(str_4)

# Generated at 2022-06-26 05:52:30.667356
# Unit test for function side_effect
def test_side_effect():
    assert True # TODO: implement test



# Generated at 2022-06-26 05:52:41.110861
# Unit test for function match
def test_match():
    var_1 = '-l'
    var_0 = u'unzip ' + var_1
    var_0 = Command(var_0, '', var_1)
    var_3 = u"-d 'file.zip'"
    var_2 = Command(var_3, '', var_3)
    var_5 = u'-d file.zip'
    var_4 = Command(var_5, '', var_5)
    var_7 = u'unzip -d file.zip'
    var_6 = Command(var_7, '', var_7)
    var_8 = _zip_file(var_0)
    var_9 = _zip_file(var_2)
    var_10 = _zip_file(var_4)
    var_11 = _zip_file(var_6)

# Generated at 2022-06-26 05:52:44.762978
# Unit test for function side_effect
def test_side_effect():
    file_ = "zipfile.py"
    cmd = {'script_parts': [file_, file_]}
    output = side_effect(cmd)


# Generated at 2022-06-26 05:52:55.644297
# Unit test for function match
def test_match():
    # These "asserts" using only for self-checking and not necessary for auto-testing
    assert match(Command(script='unzip file.zip'))
    assert match(Command(script='unzip file.zip name_of_file'))
    assert match(Command(script="unzip file_with_unsupported_format.zip"))
    assert not match(Command(script='unzip -d dir file.zip'))
    assert not match(Command(script='unzip file.tar'))

    assert _is_bad_zip('file.zip')
    assert not _is_bad_zip('file.py')



# Generated at 2022-06-26 05:53:02.496829
# Unit test for function side_effect
def test_side_effect():
    var_1 = os.path.abspath.return_value = '/usr/bin'
    var_2 = OSError()
    var_2.errno = 13
    os.remove.side_effect = var_2
    float_1 = 0.6
    with pytest.raises(OSError):
        side_effect(float_1, float_1)
    assert var_1 == os.path.abspath.return_value


# Generated at 2022-06-26 05:53:11.078740
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    zip_file = tempfile.NamedTemporaryFile(suffix='.zip', delete=False)
    with zipfile.ZipFile(zip_file.name, 'w') as archive:
        archive.writestr('file1.txt', 'test')
    zip_file.close()
    dir_name = zip_file.name[:-4]
    os.mkdir(dir_name)
    with open(os.path.join(dir_name, 'file2.txt'), 'w') as f:
        f.write('test')
    command = 'unzip ' + zip_file.name
    side_effect(command, command)
    assert os.path.isfile(os.path.join(dir_name, 'file1.txt'))

# Generated at 2022-06-26 05:53:16.947384
# Unit test for function side_effect
def test_side_effect():
    zip_file_0 = '/home/tony/.thefuck/repos/tony/fuck/fucks/zip.py'
    assert side_effect(zip_file_0, None) == None


if __name__ == '__main__':
    test_case_0()
    test_side_effect()

# Generated at 2022-06-26 05:54:17.250616
# Unit test for function side_effect
def test_side_effect():
    try:
        var_0 = side_effect(float_0, var_0)
        var_1 = side_effect(var_0, var_1)
    except Exception as var_2:
        print(var_2)


# Generated at 2022-06-26 05:54:24.235433
# Unit test for function match
def test_match():
    assert _is_bad_zip('/path/to/file1.zip') is False
    assert _is_bad_zip('/path/to/file2.zip') is True
    assert match('unzip file1 file2.zip') is False
    assert match('unzip file1.zip -x file2.zip') is False
    assert match('unzip -d directory file1.zip file2.zip') is False
    assert match('unzip file1.zip') is True
    assert match('unzip directory.zip') is False

# Generated at 2022-06-26 05:54:28.481139
# Unit test for function match
def test_match():
    # zip_file = _zip_file(command)
    # if zip_file:
    #     return _is_bad_zip(zip_file)
    # else:
    #     return False
    file_path = 'file/file.zip'
    assert _zip_file(file_path) == 'file.zip'
    assert _zip_file('-6') == '6.zip'

# Generated at 2022-06-26 05:54:30.309679
# Unit test for function match
def test_match():
    script = ['./test_unzip.py', 'bixx.zip']
    command = 0
    var_0 = match(command)
    assert var_0


# Generated at 2022-06-26 05:54:34.737329
# Unit test for function side_effect
def test_side_effect():
    assert get_new_command(match('unzip abc.zip')) == 'unzip -d "abc"'
    assert get_new_command(match('unzip abc')) == 'unzip -d "abc"'
    assert match('unzip -d abc.zip') is False
    assert match('unzip -d abc') is False

# Generated at 2022-06-26 05:54:42.084058
# Unit test for function match
def test_match():
    assert True == match(float_0)
    assert True == match(float_1)
    assert True == match(float_2)
    assert True == match(float_3)
    assert True == match(float_4)
    assert True == match(float_5)
    assert True == match(float_6)
    assert True == match(float_7)
    assert False == match(float_8)
    assert True == match(float_9)
    assert True == match(float_10)


# Generated at 2022-06-26 05:54:43.904310
# Unit test for function match
def test_match():
    float_0 = 0.6
    assert match(float_0) == False


# Generated at 2022-06-26 05:54:49.346326
# Unit test for function side_effect
def test_side_effect():
    zip_file = os.path.dirname(__file__) + '/test_data.zip'
    os.chdir(os.path.dirname(__file__))
    path = 'some_file'
    with open(path, 'w') as f:
        f.write('')
    old_cmd = Command('unzip {}'.format(zip_file))
    assert os.path.isfile(path)
    assert os.path.isfile(path + '.txt')
    side_effect(old_cmd, None)
    assert not os.path.isfile(path)
    assert os.path.isfile(path + '.txt')

# Generated at 2022-06-26 05:54:55.914485
# Unit test for function match
def test_match():
    assert _is_bad_zip(u'afile.zip')
    assert not _is_bad_zip(u'bfile.zip')
    assert not _is_bad_zip(u'cfile.zip')
    assert not _is_bad_zip(u'archive.zip')
    assert not _is_bad_zip(u'dfile.zip')
    assert not _is_bad_zip(u'efile.zip')
    assert not _is_bad_zip(u'ffile.zip')
    assert not _is_bad_zip(u'gfile.zip')
    assert not _is_bad_zip(u'hfile.zip')
    assert not _is_bad_zip(u'ifile.zip')
    assert not _is_bad_zip(u'jfile.zip')
    assert not _

# Generated at 2022-06-26 05:54:58.911431
# Unit test for function side_effect
def test_side_effect():
    float_0 = 0.1
    old_cmd = float_0
    float_0 = 0.2
    command = float_0
    side_effect(old_cmd, command)
