

# Generated at 2022-06-26 05:46:25.727187
# Unit test for function side_effect
def test_side_effect():
    # Arguments
    old_cmd = bool_0
    command = var_0

    # Call function
    side_effect(old_cmd, command)


# Generated at 2022-06-26 05:46:30.963333
# Unit test for function side_effect
def test_side_effect():
    bool_0 = False
    assert side_effect(bool_0, bool_0) == None


# Generated at 2022-06-26 05:46:34.294434
# Unit test for function match
def test_match():
    # Uncomment the line(s) below to test match
    assert match(True)
    # test_func(var_0)


# Generated at 2022-06-26 05:46:35.831150
# Unit test for function side_effect
def test_side_effect():
    f = side_effect(1, 4)


# Generated at 2022-06-26 05:46:45.571863
# Unit test for function side_effect
def test_side_effect():
    var_1 = None
    var_1 = _zip_file(var_1)
    with zipfile.ZipFile(var_1, 'r') as var_3:
        for var_4 in var_3.namelist() :
            if (not os.path.abspath(var_4).startswith(os.getcwd())) :
                continue

            try:
                os.remove(var_4)

            except OSError:
                pass


# Generated at 2022-06-26 05:46:52.725712
# Unit test for function match
def test_match():
    class TestArgs(object):
        def __init__(self, script, script_parts):
            self.script = script
            self.script_parts = script_parts

    file_in = 'test.zip'
    file_out = 'test'
    file_bad = 'test_bad.zip'
    # Bad zip
    with zipfile.ZipFile(file_bad, 'w') as archive:
        archive.writestr('test1', 'test')
        archive.writestr('test2', 'test')

    # Valid zip
    with zipfile.ZipFile(file_in, 'w') as archive:
        archive.writestr('test', 'test')

    assert match(TestArgs(script='unzip test.zip', script_parts=['unzip', 'test.zip'])) == False

# Generated at 2022-06-26 05:47:02.083583
# Unit test for function side_effect
def test_side_effect():
    var_0 = False
    with TemporaryDirectory() as var_8:
        try:
            with open(var_8 + "/test", "w") as var_4:
                var_4.write("Test")
            assert side_effect(var_0, var_8) == None
            with open(var_8 + "/test", "r") as var_3:
                var_2 = var_3.read()
            assert var_2 == "Test"
        finally:
            var_3.close()
        var_4.close()
    var_3.close()
    var_4.close()


# Generated at 2022-06-26 05:47:03.464622
# Unit test for function match
def test_match():
    if not test_case_0():
        print("Failed")
    else:
        print("Succeeded")

# Generated at 2022-06-26 05:47:14.182175
# Unit test for function match
def test_match():
    assert match('unzip -l BERLIN.zip') == False
    assert match('unzip BERLIN.zip') == True
    assert match('unzip -qq BERLIN.zip') == True
    assert match('unzip -d foo BERLIN.zip') == False
    assert match('unzip BERLIN.zip -x foo') == False
    assert match('unzip -d foo BERLIN.zip -x foo') == False
    assert match('unzip -d foo BERLIN.zip -x BERLIN.zip') == False
    assert match('unzip BERLIN.zip -x BERLIN.zip') == False



# Generated at 2022-06-26 05:47:21.028316
# Unit test for function match
def test_match():
    var_0 = False
    var_1 = _zip_file(var_0)
    var_2 = _is_bad_zip(var_1)
    var_3 = match(var_2)
    assert var_3 == True

    var_1 = _zip_file(var_0)
    var_2 = _is_bad_zip(var_1)
    var_3 = match(var_2)
    assert var_3 == False

# Generated at 2022-06-26 05:47:38.101796
# Unit test for function match
def test_match():
    bool_0 = match(command=None)
    bool_1 = match(command=None)
    bool_2 = match(command=None)
    bool_3 = match(command=None)
    bool_4 = match(command=None)
    bool_5 = match(command=None)
    bool_6 = match(command=None)
    bool_7 = match(command=None)
    bool_8 = match(command=None)
    bool_9 = match(command=None)


# Generated at 2022-06-26 05:47:42.580259
# Unit test for function match
def test_match():
    assert match(
        {'script': 'unzip -p a b c', 'script_parts': ['unzip', '-p', 'a', 'b', 'c']})
    assert not match(
        {'script': 'unzip -p a b c', 'script_parts': ['unzip', '-p', 'a', 'b', 'c']})


# Generated at 2022-06-26 05:47:52.428562
# Unit test for function side_effect
def test_side_effect():
    func_return_value_0 = get_new_command(Mock(**{'script': 'unzip', 'script_parts': ['/usr/bin/unzip', '-d', '/home/sebastian/Downloads', 'hello.zip']}))
    func_return_value_0 = Mock(**{'stdout': '', 'stderr': '', 'script': '/home/sebastian/Downloads/hello.zip', 'script_parts': ['/home/sebastian/Downloads/hello.zip']})
    # mock test
    # make an assertion
    # assert


# Generated at 2022-06-26 05:47:56.231144
# Unit test for function match
def test_match():
    command = Command('unzip foo.zip')
    shell.to_shell = Mock(return_value='/path/to/unzip')
    _is_bad_zip = Mock(return_value=bool_0)
    is_app = Mock(return_value=True)
    assert match(command) == bool_0


# Generated at 2022-06-26 05:48:07.036603
# Unit test for function side_effect
def test_side_effect():
    assert side_effect(test_case_0, test_case_0)
    assert side_effect(test_case_0, test_case_0)
    assert side_effect(test_case_0, test_case_0)
    assert side_effect(test_case_0, test_case_0)
    assert side_effect(test_case_0, test_case_0)
    assert side_effect(test_case_0, test_case_0)
    assert side_effect(test_case_0, test_case_0)
    assert side_effect(test_case_0, test_case_0)
    assert side_effect(test_case_0, test_case_0)
    assert side_effect(test_case_0, test_case_0)


# Generated at 2022-06-26 05:48:17.543854
# Unit test for function match
def test_match():
    # File from current directory
    bool_0 = False
    mock_script = Mock(return_value=bool_0)
    mock_script_parts = Mock(return_value=['script.parts'])
    mock_script_parts = Mock(return_value=['script.parts'])
    command = Mock(script=mock_script, script_parts=mock_script_parts)
    assert match(command) == bool_0
    # File from parent directory
    bool_0 = False
    mock_script = Mock(return_value=bool_0)
    mock_script_parts = Mock(return_value=['script.parts'])
    mock_script_parts = Mock(return_value=['script.parts'])
    command = Mock(script=mock_script, script_parts=mock_script_parts)


# Generated at 2022-06-26 05:48:19.376786
# Unit test for function match
def test_match():
    cmd = 'unzip -d tests/corrections tests/data/test.zip'
    assert match(cmd) is False


# Generated at 2022-06-26 05:48:28.114071
# Unit test for function match
def test_match():
    tmp = os.path.join(os.getcwd(), 'test_match.tmp')
    f = open(tmp, 'w')
    f.write('nonsense')
    f.close()
    zip_file = u'{}.zip'.format(tmp)
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.write(tmp)

    test_cmd = Command('unzip test_match.tmp', '', '')
    assert bool_0 == match(test_cmd)
    os.remove(tmp)
    os.remove(zip_file)



# Generated at 2022-06-26 05:48:31.766704
# Unit test for function match
def test_match():
    assert not match(test_case_0()) == '__main__.py'

# Generated at 2022-06-26 05:48:39.866249
# Unit test for function side_effect
def test_side_effect():
    # AssertionError: One or more unzip commands with bad destination
    # e.g. `unzip archive.zip`
    with zipfile.ZipFile('archive.zip', 'w') as archive:
        archive.writestr('file1', 'content')
        archive.writestr('file2', 'content')
    file1_path = os.path.join(os.getcwd(), 'file1') 
    file2_path = os.path.join(os.getcwd(), 'file2') 
    with open('file1', 'w') as f:
        f.write('1')
    with open('file2', 'w') as f:
        f.write('2')
    old_cmd = u'unzip archive.zip'

# Generated at 2022-06-26 05:48:50.348937
# Unit test for function match
def test_match():
    # Basic test 1
    command = 'unzip file.zip'
    result = match(shell.from_shell(command))
    assert not result
    # Basic test 2
    command = 'unzip file.zip'
    result = match(shell.from_shell(command))
    assert not result



# Generated at 2022-06-26 05:49:00.330216
# Unit test for function match
def test_match():
    fuck_0 = Command('unzip a.zip', 'asd')
    fuck_1 = Command('unzip a.zip', 'asd')
    fuck_2 = Command('unzip a.zip', 'asd')
    fuck_3 = Command('unzip a.zip', 'asd')
    fuck_4 = Command('unzip a.zip', 'asd')
    fuck_5 = Command('unzip a.zip', 'asd')
    fuck_6 = Command('unzip a.zip', 'asd')
    fuck_7 = Command('unzip a.zip', 'asd')
    fuck_8 = Command('unzip a.zip', 'asd')
    fuck_9 = Command('unzip a.zip', 'asd')
    fuck_10 = Command('unzip a.zip', 'asd')
   

# Generated at 2022-06-26 05:49:08.336999
# Unit test for function match
def test_match():
    with open('test/unzip_data.txt', 'r') as f:
        lines = map(lambda x: x.strip(), f.readlines())

    for line in lines:
        command = mock.MagicMock()
        command.script = line
        command.script_parts = line.split(' ')
        if line.startswith('./unzip') or line.startswith('unzip'):
            if command.script_parts[-1] == 'test.zip':
                bool_0 = match(command)
                assert bool_0 == True
            else:
                if command.script_parts[-1] == 'test.in' or command.script_parts[-1] == 'test.zipin':
                    bool_0 = match(command)
                    assert bool_0 == False

# Generated at 2022-06-26 05:49:19.053711
# Unit test for function side_effect
def test_side_effect():
    import subprocess
    
    # Initialize the directory "dir_0"
    os.system("mkdir -p dir_0")
    
    # Populate the directory with files
    os.system("echo 'This is a test of the emergency broadcast system' >> dir_0/file_0")
    os.system("echo 'This is a test of the emergency broadcast system' >> dir_0/file_1")
    
    # Zip the directory
    subprocess.run("zip -q -r dir_0.zip dir_0", shell=True)
    
    # Remove the directory
    os.system("rm -r dir_0")
    
    # Run the unzip command
    cmd = "unzip dir_0.zip -d dir_0"

# Generated at 2022-06-26 05:49:23.562101
# Unit test for function side_effect
def test_side_effect():
    input_0 = None
    input_1 = None

    try:
        assert side_effect(input_0, input_1) == None
    # AssertionError: None != None
    except AssertionError as exception:
        print(exception)


# Generated at 2022-06-26 05:49:30.022539
# Unit test for function match
def test_match():
    bool_0 = False
    command_0 = input('Enter command: ')
    bool_0 = match(command_0)
    if bool_0:
        print('Success')
    else:
        print('Failure')


# Generated at 2022-06-26 05:49:32.530247
# Unit test for function match
def test_match():
    command = Command(script = "unzip somefile.zip", stdout = "")

    # Call
    result = match(command)

    # Assert
    assert result == False

#######


# Generated at 2022-06-26 05:49:35.815462
# Unit test for function side_effect
def test_side_effect():
    # can't test side_effect on test cases, because it writes to the file system
    # instead, I'm testing that the side_effect function is implemented in the if clause in match()
    assert match(magic_mock.Mock(script='unzip test_case_0.zip')) == bool_0

# Generated at 2022-06-26 05:49:48.622730
# Unit test for function match
def test_match():
    # Match should not run if -d is in command.script
    bool_0 = False

    # Match should not run if -d is in command.script
    bool_1 = False

    # Match should not run if -d is in command.script
    bool_2 = False

    # Test for the scenario where the file exists and has more than one file
    bool_3 = match(Command('unzip foo.zip', '', ''))

    # Test for the scenario where the file exists and has more than one file
    bool_4 = match(Command('unzip foo.zip bar.zip', '', ''))

    # Test for the scenario where the file exists and has more than one file
    bool_5 = match(Command('unzip foo.zip bar.zip', '', ''))

    # Test for the scenario where the file exists and has more than one file

# Generated at 2022-06-26 05:49:59.263813
# Unit test for function side_effect
def test_side_effect():
    print("Unit test for function side_effect")
    file_0 = "file_0"
    command_0 = Command(script="unzip file_0", stdout="test_stdout", stderr="test_stderr")
    command_1 = Command(script="unzip file_1", stdout="test_stdout", stderr="test_stderr")
    int_0 = len(command_1.script_parts)
    if(int_0 == 1):
        side_effect(command_0, command_1)

# Generated at 2022-06-26 05:50:06.442934
# Unit test for function side_effect
def test_side_effect():
    assert _zip_file.__name__ == '_zip_file'


# Generated at 2022-06-26 05:50:10.945131
# Unit test for function side_effect
def test_side_effect():
    unittest.TestCase().assertEquals(
        side_effect(
            # command
            'unzip /foo/bar/baz.zip',
            # new_cmd
            'unzip -d /foo/bar/baz /foo/bar/baz.zip'
        ),
        None
    )


# Generated at 2022-06-26 05:50:14.425680
# Unit test for function match
def test_match():
    assert not _is_bad_zip('test_file.zip')
    assert _is_bad_zip('test_file_bad_zip.zip')
    old_cmd_0 = shell.ShellCommand("unzip foo")
    test_case_0()
    assert match(old_cmd_0) == bool_0


# Generated at 2022-06-26 05:50:18.609418
# Unit test for function match
def test_match():
    assert not match('')
    assert match('unzip')
    assert not match('unzip -j')
    assert not match('unzip -d')


# Generated at 2022-06-26 05:50:28.580686
# Unit test for function match
def test_match():
    cmd = shell.and_('unzip /tmp/test.zip', 'exit 1')
    assert match(cmd) == False

    cmd = shell.and_('unzip /tmp/test.zip -d test/', 'exit 1')
    assert match(cmd) == False

    cmd = shell.and_('unzip /tmp/test.zip -d test/', 'exit 0')
    assert match(cmd) == False

    cmd = shell.and_('unzip /tmp/test.zip -d test/', 'exit 0')
    with patch('thefuck.rules.unzip.zipfile.ZipFile') as mock:
        mock().namelist.return_value = ['/tmp/test.txt', '/tmp/test.txt']
        assert match(cmd) == True


# Generated at 2022-06-26 05:50:32.658844
# Unit test for function side_effect
def test_side_effect():
    # Input arguments
    old_cmd = 'unzip some_file.zip'
    command = 'unzip some_file.zip'

    side_effect(old_cmd, command)

# Generated at 2022-06-26 05:50:35.165235
# Unit test for function side_effect
def test_side_effect():
    # no output
    # test cases here
    assert test_case_0()



# Generated at 2022-06-26 05:50:38.021586
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command(script=u'unzip file.zip', side_effect=None)
    command = Command(script=u'unzip -d file.zip', side_effect=None)
    assert side_effect(old_cmd, command) is None


# Generated at 2022-06-26 05:50:41.375872
# Unit test for function match
def test_match():
    assert bool_0 == bool(match(''))


# Generated at 2022-06-26 05:50:44.289240
# Unit test for function side_effect
def test_side_effect():
    try:
        test_case_0()
        assert (True == False)
    except:
        assert (False == False)



# Generated at 2022-06-26 05:50:54.583097
# Unit test for function side_effect
def test_side_effect():
    var_0 = 'γ'
    var_1 = "unzip '{}'".format('Φ')
    var_2 = side_effect(var_1, var_0)


# Generated at 2022-06-26 05:50:59.107157
# Unit test for function match
def test_match():
    arg_1 = 'unzip strange-filename.zip'
    result_1 = match(arg_1)
    assert result_1 == False


# Generated at 2022-06-26 05:51:08.494342
# Unit test for function match
def test_match():
    file_path = os.path.realpath(__file__)
    test_files_dir = os.path.join(os.path.dirname(file_path), 'test_files')
    zip_file = os.path.join(test_files_dir, 'example.zip')

    assert _is_bad_zip(zip_file)

    command = 'unzip {}'.format(zip_file)
    assert match(command)

    command = 'unzip {} '.format(zip_file)
    assert match(command)

    command = 'unzip {}\n'.format(zip_file)
    assert match(command)

    command = 'unzip {} -d'.format(zip_file)
    assert match(command) is False

    command = 'unzip {} -d '.format(zip_file)

# Generated at 2022-06-26 05:51:12.169493
# Unit test for function match
def test_match():
    print(match(str_0))
    print(match(str_0))
    print(match(str_0))


# Generated at 2022-06-26 05:51:15.102052
# Unit test for function side_effect
def test_side_effect():
    # Test case 0
    str_0 = 'Ζ'
    var_1 = side_effect(str_0, 'Ζ')


# Generated at 2022-06-26 05:51:17.587786
# Unit test for function side_effect
def test_side_effect():
    var_0 = _zip_file()
    var_1 = side_effect(var_0)
    assert var_1 is None


# Generated at 2022-06-26 05:51:18.101864
# Unit test for function side_effect
def test_side_effect():
    pass

# Generated at 2022-06-26 05:51:28.159436
# Unit test for function match
def test_match():
    assert match('unzip a.zip')
    assert match('unzip a.zip hi.txt')
    assert match('unzip a.zip hi.txt -j')
    assert not match('unzip a.zip -d hi.txt')
    assert not match('unzip a.zip -d hi.txt')
    assert not match('unzip -d a.zip hi.txt')
    assert not match('unzip -d a.zip hi.txt')
    assert not match('unzip -d a.zip -o hi.txt')
    assert not match('unzip -d a.zip -o hi.txt')
    assert not match('unzip -dlo a.zip hi.txt')
    assert not match('unzip -dlo a.zip hi.txt')

# Generated at 2022-06-26 05:51:34.176392
# Unit test for function match
def test_match():
    var_0 = 'Ξ'
    var_1 = _zip_file(var_0)
    var_2 = 'unzip -d έ'
    var_3 = match(var_2)
    assert var_3 == False

    var_4 = 'unzip ΣΖΞέέΔΣΤΣΥΦΩΨΦΥΣΧΥ.zip'
    var_5 = match(var_4)
    assert var_5 == False

    var_6 = 'unzip ΖέΔΠΣΤΣΥΦΩΨΦΥΣΧΥ'

# Generated at 2022-06-26 05:51:36.570999
# Unit test for function side_effect
def test_side_effect():
    str_0 = 'Ζ'
    side_effect(str_0, str_0)


# Generated at 2022-06-26 05:51:52.326248
# Unit test for function match
def test_match():
    cmd = u'unzip archive.zip'
    assert match(cmd)
    cmd = u'unzip archive'
    assert match(cmd)
    cmd = u'unzip -l archive.zip'
    assert not match(cmd)
    cmd = u'unzip -d dest archive.zip'
    assert not match(cmd)

# Generated at 2022-06-26 05:51:58.926465
# Unit test for function match
def test_match():
    var_0 = '$(zip -r \x00)'
    var_1 = match(var_0)
    assert var_1 == True

    var_0 = '$(zip -r)'
    var_1 = match(var_0)
    assert var_1 == False

    var_0 = '$(zip -r /)'
    var_1 = match(var_0)
    assert var_1 == False

    var_0 = '$(zip -r /tmp/he)'
    var_1 = match(var_0)
    assert var_1 == False

    var_0 = '$(zip -r ~/dotfiles.zip ~/dotfiles/)'
    var_1 = match(var_0)
    assert var_1 == False


# Generated at 2022-06-26 05:52:03.829429
# Unit test for function side_effect
def test_side_effect():
    old_cmd = 'unzip -d /home/santeri/src/thefuck/tests/fixtures/unzip/unzip a.zip'
    command = 'unzip -d a'
    side_effect(old_cmd, command)


# Generated at 2022-06-26 05:52:06.832188
# Unit test for function match
def test_match():
    assert match('unzip file.zip')
    assert match('unzip file2.zip')
    assert not match('unzip -d file.zip')
    assert not match('')
    assert not match('unzip file.tar')
    assert not match('my_cmd file.zip')



# Generated at 2022-06-26 05:52:09.294117
# Unit test for function match
def test_match():
    assert isinstance(match(None), bool)


# Generated at 2022-06-26 05:52:14.165432
# Unit test for function match
def test_match():
    pass



# Generated at 2022-06-26 05:52:14.912822
# Unit test for function side_effect
def test_side_effect():
    assert False

# Generated at 2022-06-26 05:52:16.019779
# Unit test for function match
def test_match():
    assert match(u'str_0'), 'not match'

# Generated at 2022-06-26 05:52:19.363942
# Unit test for function match
def test_match():
    str_0 = 'Ζ'
    var_0 = _is_bad_zip(str_0)
    assert(var_0 == False)

# Generated at 2022-06-26 05:52:20.273494
# Unit test for function match
def test_match():
    assert match('') == False


# Generated at 2022-06-26 05:52:47.961925
# Unit test for function side_effect
def test_side_effect():
    assert side_effect is not None


# Generated at 2022-06-26 05:52:57.502195
# Unit test for function match
def test_match():
    assert match('This is a sample') == False
    assert match('unzip abc.zip') == False
    assert match('unzip -l abc.zip') == False
    assert match('This is a sample') == False
    assert match('This is a sample') == False
    assert match('This is a sample') == False
    assert match('This is a sample') == False
    assert match('unzip abc.zip') == False
    assert match('unzip -d abc.zip') == False
    assert match('unzip abc.zip def.txt') == False
    assert match('unzip abc.zip') == False
    assert match('This is a sample') == False
    assert match('This is a sample') == False
    assert match('unzip abc.zip') == False

# Generated at 2022-06-26 05:53:01.425853
# Unit test for function side_effect

# Generated at 2022-06-26 05:53:04.984094
# Unit test for function side_effect
def test_side_effect():
    zip_file = _zip_file()
    if zip_file:
        return _is_bad_zip(zip_file)
    else:
        return False

    # Test function
    side_effect(zip_file)

    # Test output



# Generated at 2022-06-26 05:53:08.748498
# Unit test for function match
def test_match():
    var_0 = shell.and_('a', shell.bg_not_('b'), 'c')
    var_1 = '-d'
    assert (match(var_0) == False)
    assert (match(var_1) == False)


# Generated at 2022-06-26 05:53:19.578689
# Unit test for function match
def test_match():
    assert _is_bad_zip('test_cases/unzip/with_spaces_and_nonascii.zip')
    assert not _is_bad_zip('test_cases/unzip/single_file.zip')
    assert not _is_bad_zip('test_cases/unzip/does_not_exist.zip')

    assert match(Command('unzip single_file.zip', '', '', '',
                         'test_cases/unzip'))
    assert match(Command('unzip single_file.zip foo', '', '', '',
                         'test_cases/unzip'))
    assert match(Command('unzip -t single_file.zip', '', '', '',
                         'test_cases/unzip'))

# Generated at 2022-06-26 05:53:21.981235
# Unit test for function side_effect
def test_side_effect():
    assert True == True

test_case_0()
test_side_effect()

# Generated at 2022-06-26 05:53:27.382205
# Unit test for function match
def test_match():
    file_0 = open('./data/fuckers/bad_zip.txt', 'r')
    file_1 = open('./data/fuckers/unzip.txt', 'r')
    str_0 = file_0.read()
    str_1 = file_1.read()
    str_2 = 'zip'
    var_0 = match(str_1)
    var_1 = match(str_0)
    var_2 = match(str_2)
    assert var_0 == False
    assert var_1 == True
    assert var_2 == False


# Generated at 2022-06-26 05:53:32.777735
# Unit test for function match
def test_match():
    assert match('unzip bad_zip_file__.zip')
    assert match('unzip bad_zip_file__.zip foo.zip')
    assert not match('unzip bad_zip_file__.zip -d foo')
    assert not match('unzip bad_zip_file__.zip foo.zip -d foo')
    assert not match('unzip bad_zip_file__.zip -x foo.zip')
    assert not match('unzip bad_zip_file__.zip foo.zip -x foo.zip')


# Generated at 2022-06-26 05:53:33.765187
# Unit test for function side_effect
def test_side_effect():
    var_0 = ' '
    var_1 = ' '
    assert side_effect(var_0, var_1) == None


# Generated at 2022-06-26 05:54:41.285092
# Unit test for function side_effect
def test_side_effect():

    str_0 = 'unzip -d /tmp/test/test.zip'
    side_effect(str_0)


# Generated at 2022-06-26 05:54:41.996610
# Unit test for function match
def test_match():
    assert match('Ζ') == False


# Generated at 2022-06-26 05:54:42.916996
# Unit test for function side_effect
def test_side_effect():
    pass

# Generated at 2022-06-26 05:54:44.379586
# Unit test for function side_effect
def test_side_effect():
    str_0 = 'Ζ'
    var_0 = side_effect(str_0)


# Generated at 2022-06-26 05:54:46.326058
# Unit test for function side_effect
def test_side_effect():
    '''
    Auto-generated by Spyder:
    unzip     Test case 0:
    unzip     Test case 0:
    '''
    assert False


# Generated at 2022-06-26 05:54:51.754555
# Unit test for function match
def test_match():
    try:
        from unittest import mock
    except ImportError:
        import mock

    var_0 = 'dummy'
    expected_0 = False
    actual_0 = match(var_0)
    assert expected_0 == actual_0
    var_1 = mock.MagicMock()
    attrs = {'script_parts': ['unzip', 'file'], 'script': 'unzip file'}
    var_1.configure_mock(**attrs)
    with mock.patch('zipfile.ZipFile', return_value=mock.MagicMock(__len__=lambda x: x)):
        with mock.patch('os.path.exists', return_value=True):
            expected_1 = True
            actual_1 = match(var_1)
            assert expected_1 == actual_1

# Generated at 2022-06-26 05:54:56.444828
# Unit test for function side_effect
def test_side_effect():
    file_0 = 'Ζ'
    var_0 = os.getcwd()
    var_1 = side_effect(file_0, var_0)


# Generated at 2022-06-26 05:55:00.835387
# Unit test for function match
def test_match():
    assert match(u'unzip useless')
    assert match(u'unzip useless.zip')
    assert match(u'unzip useless.zip asd')
    assert not match(u'unzip -d useless')
    assert not match(u'unzip -d useless.zip')
    assert not match(u'unzip -d useless.zip asd')



# Generated at 2022-06-26 05:55:02.056950
# Unit test for function side_effect
def test_side_effect():
    str_0 = 'Ζ'
    var_0 = side_effect(str_0)

# Generated at 2022-06-26 05:55:08.396242
# Unit test for function match
def test_match():
    assert match(str_0) == True
    assert _is_bad_zip('/Users/moselle/Desktop/fuck_mistakes/zip.zip') == True
    assert _zip_file(str_0) == 'Ζ.zip'
    assert _zip_file('Ζ') == 'Ζ.zip'
    assert match('Ζ') == True
    assert match('unzip Ζ') == True
    assert _is_bad_zip('/Users/moselle/Desktop/fuck_mistakes/zip.zip') == True

