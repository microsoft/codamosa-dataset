

# Generated at 2022-06-26 05:46:29.108410
# Unit test for function match
def test_match():
    script_parts = []
    script_parts.append('test.zip')
    script = 'unzip zip_file'
    cwd = ''
    args = []
    env = {}
    command = Command(script, 'unzip', script_parts, command='unzip', env=env, args=args, cd=cwd)
    assert match(command) == False

# Generated at 2022-06-26 05:46:36.962738
# Unit test for function match
def test_match():
    assert match(b'unzip file.zip')
    assert not match(b'unzip -d dir file.zip')
    assert not match(b'unzip -l file.zip')
    assert not match(b'unzip')
    assert not match(b'unzip -a -b -c')


# Generated at 2022-06-26 05:46:48.162533
# Unit test for function match
def test_match():
    assert match("unzip test1.zip") == False, 'Wrong Testcase'
    assert match("unzip test.zip -d test_dir") == False, 'Wrong Testcase'
    assert match("unzip test.zip test/index.html") == False, 'Wrong Testcase'
    assert match("unzip test2.zip") == True, 'Wrong Testcase'
    assert match("unzip test3.zip -d test_dir") == True, 'Wrong Testcase'
    assert match("unzip test4.zip test/index.html") == True, 'Wrong Testcase'
    assert match("unzip -t test1.zip") == False, 'Wrong Testcase'
    assert match("unzip -t test2.zip") == True, 'Wrong Testcase'

# Generated at 2022-06-26 05:46:49.465754
# Unit test for function match
def test_match():
    bytes_0 = b'unzip -d'
    var_0 = match(bytes_0)


# Generated at 2022-06-26 05:46:53.937031
# Unit test for function side_effect
def test_side_effect():
    var_0 = side_effect(b'unzip "file.zip"', b'unzip "file.zip"')


# Generated at 2022-06-26 05:47:00.006091
# Unit test for function match
def test_match():
    with open('unzip-bad.zip', 'w') as zip_file:
        with zipfile.ZipFile(zip_file, 'w') as archive:
            archive.writestr('test.file', 'test content')
            archive.writestr('another.file', 'another test content')
    assert match(b'unzip unzip-bad.zip')


# Generated at 2022-06-26 05:47:05.014595
# Unit test for function side_effect
def test_side_effect():
    with patch('os.remove') as remove, patch('zipfile.ZipFile') as ZipFile:
        directory = Mock()
        directory.namelist.return_value = ['file.txt', 'file_folder/']
        ZipFile.return_value.__enter__.return_value = directory
        side_effect('unzip file.zip', 'unzip file.zip')
        remove.assert_called_once_with('file.txt')



# Generated at 2022-06-26 05:47:15.456769
# Unit test for function side_effect
def test_side_effect():
    zip_file_0 = u'ztest.zip'
    os.mkdir(u'ztest')
    with open(u'ztest/test.txt', u'w') as var_0:
        var_0.write(u'hello')
    with zipfile.ZipFile(zip_file_0, u'w', zipfile.ZIP_DEFLATED) as var_1:
        var_1.write(u'ztest/test.txt', u'test.txt')
    var_2 = shell.from_string(u'unzip {}'.format(shell.quote(zip_file_0)))
    var_3 = get_new_command(var_2)
    side_effect(var_2, var_3)


# Generated at 2022-06-26 05:47:18.330532
# Unit test for function match
def test_match():
    # this is a test
    bytes_a = b''
    var_0 = match(bytes_a)
    assert var_0 == False

# Generated at 2022-06-26 05:47:22.407230
# Unit test for function side_effect
def test_side_effect():
    file_0 = 'file'
    filename_0 = 'filename'
    cmd_0 = Command(script=file_0)
    archive_0 = zipfile.ZipFile(filename_0, 'r')
    assert side_effect(cmd_0) == None


# Generated at 2022-06-26 05:47:32.216658
# Unit test for function match
def test_match():
    assert match('unzip test.zip') == False
    assert match('unzip -d test test.zip') == False
    assert match('unzip test.zip test2') == True
    assert match('unzip test.zip test2 test3.rar') == True


# Generated at 2022-06-26 05:47:43.019589
# Unit test for function match
def test_match():
    assert match(
        u"unzip extract.zip"
    ) is False

    assert match(
        u"unzip -d extract.zip"
    ) is False

    assert match(
        u"unzip extract.zip file.txt"
    ) is False

    assert match(
        u"unzip -d extract.zip file.txt"
    ) is False

    assert match(
        u"unzip extract.zip file.txt file2.txt"
    ) is False

    assert match(
        u"unzip -d extract.zip file.txt file2.txt"
    ) is False

    assert match(
        u"unzip extract.zip file.txt -x file2.txt"
    ) is False


# Generated at 2022-06-26 05:47:47.501677
# Unit test for function side_effect
def test_side_effect():
    bytes_0 = b'myfile.zip'
    bytes_1 = b'myfile'
    var_0 = side_effect(bytes_0, bytes_1)


# Generated at 2022-06-26 05:47:49.909563
# Unit test for function side_effect
def test_side_effect():
    # call function with the following parameters
    # command, old_cmd
    side_effect("ls", "rm *")


# Generated at 2022-06-26 05:47:57.281504
# Unit test for function side_effect
def test_side_effect():
    old_cmd = match(b'unzip file.zip')
    command = get_new_command(old_cmd)
    with zipfile.ZipFile(_zip_file(old_cmd), 'r') as archive:
        archive.extractall()
        assert side_effect(old_cmd, command) == None

# Generated at 2022-06-26 05:47:59.555272
# Unit test for function match
def test_match():
    assert not match(Command(script='unzip archive.zip -d', stderr=''))
    assert not match(Command(script='unzip archive.zip', stderr=''))

# Generated at 2022-06-26 05:48:06.031626
# Unit test for function match
def test_match():
    assert(match.match(bytes('unzip -d directory file.zip', 'utf8')) == False)
    assert(match.match(bytes('unzip file.zip', 'utf8')) == False)
    assert(match.match(bytes('unzip -d directory file.zip', 'utf8')) == False)
    assert(match.match(bytes('unzip -d directory file.zip', 'utf8')) == False)


# Generated at 2022-06-26 05:48:08.639544
# Unit test for function match
def test_match():
    command = mock.Mock(script_parts=[u'unzip', u'-qq', u'-o', u'file.zip'])
    assert match(command) is True


# Generated at 2022-06-26 05:48:11.446323
# Unit test for function side_effect
def test_side_effect():
    bytes_0 = b''
    var_0 = side_effect(bytes_0, '-d')


# Generated at 2022-06-26 05:48:20.207211
# Unit test for function match
def test_match():
    bytes_0 = b'unzip:  cannot find or open fixme.zip, fixme.ZIP or fixme.z01.\n'
    var_0 = False
    assert match(bytes_0) == var_0
    bytes_0 = b'Archive:  fixme.zip\n   creating: _tmp/\n  inflating: _tmp/file\n   creating: file.txt/\n  inflating: file.txt/file2\n'
    var_0 = True
    assert match(bytes_0) == var_0
    bytes_0 = b'unzip fixme.zip\nArchive:  fixme.zip\n   creating: _tmp/\n  inflating: _tmp/file\n   creating: file.txt/\n  inflating: file.txt/file2\n'
    var_0

# Generated at 2022-06-26 05:48:40.048431
# Unit test for function side_effect
def test_side_effect():
    bytes_0 = b''
    var_0 = side_effect(bytes_0, bytes_0)
    assert var_0 == None


# Generated at 2022-06-26 05:48:47.088758
# Unit test for function side_effect
def test_side_effect():
    os.makedirs("/home/maksim/Desktop/test/fake_dir")
    os.makedirs("/home/maksim/Desktop/test/fake_dir/another_dir")
    with open("/home/maksim/Desktop/test/file1.txt", "w"):
        pass

    with open("/home/maksim/Desktop/test/file2.txt", "w"):
        pass

    with open("/home/maksim/Desktop/test/fake_dir/file3.txt", "w"):
        pass

    with open("/home/maksim/Desktop/test/fake_dir/another_dir/file4.txt", "w"):
        pass


# Generated at 2022-06-26 05:48:48.405487
# Unit test for function match
def test_match():
    assert _is_bad_zip(BadZipFile) == False



# Generated at 2022-06-26 05:48:52.488109
# Unit test for function match
def test_match():

    # Variable
    var_0 = None
    var_1 = None
    var_2 = None

    # Test 1
    var_0 = 'test_unzip.zip'
    var_1 = _is_bad_zip(var_0)
    var_2 = var_1
    assert var_2 is True

# Generated at 2022-06-26 05:48:53.149146
# Unit test for function side_effect
def test_side_effect():
    pass

# Generated at 2022-06-26 05:48:55.423267
# Unit test for function side_effect
def test_side_effect():
    bytes_0 = b'unzip file.zip'
    function_side_effect = side_effect(bytes_0, bytes_0)


# Generated at 2022-06-26 05:49:06.851026
# Unit test for function match
def test_match():
    bytes_0 = b'unzip /home/an/Documents/dist.zip'
    var_0 = match(bytes_0)
    assert(not var_0)
    bytes_1 = b'unzip -d /home/an/Documents -j /home/an/Documents/dist.zip'
    var_1 = match(bytes_1)
    assert(not var_1)
    bytes_2 = b'unzip -d /home/an/Documents /home/an/Documents/dist.zip'
    var_2 = match(bytes_2)
    assert(var_2)

# Generated at 2022-06-26 05:49:09.595269
# Unit test for function side_effect
def test_side_effect():
    old_cmd = 'unzip -d'
    command = 'unzip -d'
    return side_effect(old_cmd, command)


# Generated at 2022-06-26 05:49:20.470445
# Unit test for function match
def test_match():
    file_0 = 'foo.txt'
    file_1 = 'bar'
    file_2 = 'baz.zip'
    file_3 = 'foo.txt.zip'
    bytes_0 = b'unzip foo.txt'
    bytes_1 = b'unzip bar'
    bytes_2 = b'unzip bar.zip'
    bytes_3 = b'unzip foo.txt.zip'
    bytes_4 = b'unzip -d foo.txt.zip'
    bytes_5 = b'unzip -d bar'
    bytes_6 = b'unzip -d bar.zip'
    bytes_7 = b'unzip -d foo.txt'
    var_1 = match(bytes_0)
    var_2 = match(bytes_1)

# Generated at 2022-06-26 05:49:27.200410
# Unit test for function side_effect
def test_side_effect():
    with open("test_zip_file.zip", "w") as test_zip_file:
        test_zip_file.write("test zip file")
    old_cmd = b'unzip test_zip_file.zip'
    command = b'unzip -d test_zip_file test_zip_file.zip'
    side_effect(old_cmd, command)
    assert os.path.exists(b'test_zip_file') is True
    os.remove("test_zip_file.zip")
    os.removedirs("test_zip_file")


# Generated at 2022-06-26 05:49:51.187144
# Unit test for function side_effect
def test_side_effect():
    # "file.zip" archive contains a single file "test", which must be
    # extracted in the current directory
    # Try to set up test environment
    with open("file.zip", 'w') as archive:
        with zipfile.ZipFile(archive, 'w') as zip_archive:
            zip_archive.writestr("test", "")

    # Call function under test
    test_side_effect()

    # Verify that test was successful
    assert _is_bad_zip("file.zip")
    assert os.path.isfile("test")
    assert not os.path.isfile("file")


# Generated at 2022-06-26 05:49:53.287438
# Unit test for function match
def test_match():
	bytes_0 = b'unzip file.zip'
	assert match(bytes_0)



# Generated at 2022-06-26 05:50:04.725188
# Unit test for function side_effect
def test_side_effect():
    import pytest
    with pytest.raises(Exception) as e_1:
        side_effect(b'unzip "file.zip"', b'unzip "file.zip"')
    with pytest.raises(Exception) as e_2:
        side_effect(b'unzip -d "directory" "file.zip"', b'unzip "file.zip"')
    with pytest.raises(Exception) as e_3:
        side_effect(b'unzip -d "directory" "file.zip"', b'unzip -d "directory" "file.zip"')
    with pytest.raises(Exception) as e_4:
        side_effect(b'unzip "file.zip" "file.zip"', b'unzip "file.zip"')

# Generated at 2022-06-26 05:50:07.202563
# Unit test for function side_effect
def test_side_effect():
    var_1 = b'unzip "file.zip"'

    var_2 = side_effect(var_1, var_1)
    pass

# Test for function get_new_command

# Generated at 2022-06-26 05:50:11.704377
# Unit test for function match
def test_match():
    bytes_0 = b'unzip "file.zip"'
    var_0 = match(bytes_0)
    assert var_0 == True
    bytes_1 = b'unzip "file.zip" -n'
    var_1 = match(bytes_1)
    assert var_1 == False


# Generated at 2022-06-26 05:50:16.268874
# Unit test for function match
def test_match():
    with zipfile.ZipFile('test.zip', mode='w') as test_zip:
        test_zip.writestr('test.txt', b'test')
        test_zip.writestr('test2.txt', b'foo')
    command = 'unzip test.zip'
    old_cmd = command
    var_0 = get_new_command(command)

# Generated at 2022-06-26 05:50:19.553284
# Unit test for function match
def test_match():
    bytes_0 = b'unzip "file.zip"'
    var_0 = match(bytes_0)


# Generated at 2022-06-26 05:50:26.706389
# Unit test for function side_effect
def test_side_effect():
    import os
    import zipfile
    from thefuck.utils import for_app
    from thefuck.shells import shell


    def is_bad_zip():
        pass


    def zip_file():
        pass


    def unit_test():
        # Define test data
        bytes_0 = b'unzip "file.zip"'
        var_0 = side_effect(bytes_0, bytes_0)
    unit_test()

# Generated at 2022-06-26 05:50:27.983465
# Unit test for function side_effect
def test_side_effect():
    assert True == True

# Generated at 2022-06-26 05:50:29.574284
# Unit test for function match
def test_match():
    assert not match(bytes_0)


# Generated at 2022-06-26 05:51:06.884050
# Unit test for function match
def test_match():
    bytes_0 = b'unzip "file.zip"'
    bytes_1 = b'unzip -d "dir" "file.zip"'
    var_0 = _is_bad_zip(bytes_0)
    var_1 = match(bytes_0)
    var_2 = match(bytes_1)
    assert var_0
    assert var_1
    assert not var_2


# Generated at 2022-06-26 05:51:18.502324
# Unit test for function match
def test_match():
    bytes_0 = b'unzip "file.zip"'
    var_0 = _is_bad_zip(bytes_0)
    expected_var_0 = False
    assert var_0 == expected_var_0
    bytes_1 = b'unzip "file.zip"'
    var_1 = _zip_file(bytes_1)
    expected_var_1 = b'file.zip'
    assert var_1 == expected_var_1
    bytes_2 = b'unzip file.zip'
    var_2 = _zip_file(bytes_2)
    expected_var_2 = b'file.zip'
    assert var_2 == expected_var_2

# Generated at 2022-06-26 05:51:20.500335
# Unit test for function match
def test_match():
    command = "unzip 'file.zip'"
    var_1 = match(command)


# Generated at 2022-06-26 05:51:29.665987
# Unit test for function side_effect
def test_side_effect():
    arg0 = u"unzip 'file.zip'"
    arg1 = u'unzip -d file file.zip'
    with patch('thefuck.rules.unzip.os') as mock_os:
        mock_os.getcwd.return_value = '/'
        mock_os.path.abspath.return_value = '/file2'
        mock_os.remove = Mock()
        side_effect(arg0, arg1)
        mock_os.remove.assert_not_called()
    with patch('thefuck.rules.unzip.os') as mock_os:
        mock_os.getcwd.return_value = '/'
        mock_os.path.abspath.return_value = '/file2'
        mock_os.remove = Mock()
        os.remove.side_effect = OSE

# Generated at 2022-06-26 05:51:31.989080
# Unit test for function match
def test_match():
    var_1 = _zip_file(b'unzip file')
    test_case_0()
    assert var_1 == u'file.zip'


# Generated at 2022-06-26 05:51:35.638713
# Unit test for function match
def test_match():
    bytes_0 = b'unzip "file.zip"'
    var_0 = match(bytes_0)
    assert(var_0 == b'file.zip')


# Generated at 2022-06-26 05:51:37.910958
# Unit test for function match
def test_match():
    bytes_0 = b'unzip "file.zip"'
    var_0 = match(bytes_0)


# Generated at 2022-06-26 05:51:43.960532
# Unit test for function match
def test_match():
    assert (match(b'unzip') is False)
    assert (match(b'unzip file.txt') is False)
    assert (match(b'unzip *.zip') is False)
    assert (match(b'unzip file.zip') is True)
    assert (match(b'unzip file.zip -d path') is False)
    assert (match(b'unzip -l file.zip') is False)
    assert (match(b"unzip 'file.zip'") is True)
    assert (match(b"unzip \"file.zip\"") is True)


# Generated at 2022-06-26 05:51:53.419618
# Unit test for function side_effect
def test_side_effect():
    from os import path
    from os.path import isfile, join
    from subprocess import check_output
    from thefuck.types import Command
    from thefuck.rules import side_effect, match
    from thefuck.rules.zip_all import get_new_command, match
    from thefuck.rules.zip_all import requires_output
    from thefuck.shells import shell
    from thefuck.main import Rules
    from zipfile import ZipFile
    from contextlib import contextmanager
    from shutil import rmtree
    from tempfile import mkdtemp
    import os
    import sys
    # Test cases
    def test_case_0():
        bytes_0 = b'unzip "file.zip"'
        var_0 = side_effect(bytes_0, bytes_0)
    # Unit test for function side_effect

# Generated at 2022-06-26 05:51:55.156753
# Unit test for function match
def test_match():
    bytes_0 = b'unzip "file.zip"'
    var_0 = match(bytes_0)


# Generated at 2022-06-26 05:53:01.135675
# Unit test for function side_effect
def test_side_effect():
    test_case_0()

# Generated at 2022-06-26 05:53:09.184678
# Unit test for function match
def test_match():
    assert match(
        Command('unzip file.zip', '', '')) is True, 'unzip file.zip succeeds'
    assert match(
        Command('unzip -d dir file.zip', '', '')) is False, 'unzip -d dir file.zip fails'
    assert match(
        Command('unzip file', '', '')) is False, 'unzip file fails'
    assert match(
        Command('unzip --help', '', '')) is False, 'unzip --help fails'
    assert match(
        Command('unzip file.zip file.txt', '', '')) is False, 'unzip file.zip file.txt fails'


# Generated at 2022-06-26 05:53:12.225935
# Unit test for function side_effect
def test_side_effect():
    dummy_file = 'unzip "file.zip"'
    dummy_file_1 = 'unzip "file.zip"'
    assert side_effect(dummy_file, dummy_file_1) is not None

test_case_0()

# Generated at 2022-06-26 05:53:16.621619
# Unit test for function side_effect
def test_side_effect():
    bytes_0 = b'unzip "file.zip"'
    var_0 = side_effect(bytes_0, bytes_0)



# Generated at 2022-06-26 05:53:17.989303
# Unit test for function side_effect
def test_side_effect():
    assert side_effect("unzip 'file.zip'", "unzip 'file.zip'") == None

# Generated at 2022-06-26 05:53:18.910564
# Unit test for function side_effect
def test_side_effect():
    assert True == False
    pass



# Generated at 2022-06-26 05:53:25.514573
# Unit test for function side_effect
def test_side_effect():
    var_1 = os.getcwd()
    var_2 = os.path.join(var_1, 'thefuck', 'etc', 'test')
    var_3 = os.chdir(var_2)
    var_4 = os.path.join(var_2, 'zip_file.tar.gz')
    var_5 = os.path.join(var_2, 'zipfile.py')
    var_6 = ['unzip', var_4]
    var_6_1 = ' '.join(var_6)



# Generated at 2022-06-26 05:53:27.331213
# Unit test for function side_effect
def test_side_effect():
    # Assume
    file = r'unzip "file.zip"'
    # Action
    var_0 = side_effect(file, file)
    # Assert
    assert var_0 == None


# Generated at 2022-06-26 05:53:31.128496
# Unit test for function match
def test_match():
    bytes_0 = b'unzip file.zip'
    var_0 = _zip_file(bytes_0)
    assert var_0 == u'file.zip'

    bytes_1 = b'unzip file.zip'
    var_1 = match(bytes_1)
    assert var_1 == True


# Generated at 2022-06-26 05:53:31.577579
# Unit test for function side_effect
def test_side_effect():
    assert test_case_0() == None