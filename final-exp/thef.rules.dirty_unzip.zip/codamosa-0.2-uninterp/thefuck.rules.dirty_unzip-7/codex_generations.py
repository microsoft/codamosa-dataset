

# Generated at 2022-06-18 07:40:06.758644
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a zip file
    zip_file = os.path.join(tmpdir, "test.zip")
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.write(tmpfile.name, "test.txt")
    # Create a directory
    os.mkdir(os.path.join(tmpdir, "test"))
    # Create a file in the directory
    tmpfile2 = tempfile.NamedTemporaryFile(dir=os.path.join(tmpdir, "test"))

    #

# Generated at 2022-06-18 07:40:15.410751
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))

# Generated at 2022-06-18 07:40:26.649283
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip -l file.zip', '', ''))
    assert match(Command('unzip -l file.zip file1 file2', '', ''))
    assert match(Command('unzip -d dir file.zip', '', ''))
    assert match(Command('unzip -d dir file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d dir file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d dir file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d dir file.zip file1 file2', '', ''))


# Generated at 2022-06-18 07:40:36.203981
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir -x file3.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir file2.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir file2.zip -x file3.zip', '', ''))

# Generated at 2022-06-18 07:40:46.559483
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import get_shell
    from thefuck.types import Command
    from thefuck.rules.unzip_single_file import side_effect
    from thefuck.rules.unzip_single_file import _zip_file
    from thefuck.rules.unzip_single_file import get_new_command
    from thefuck.rules.unzip_single_file import match
    from thefuck.rules.unzip_single_file import _is_bad_zip
    from thefuck.rules.unzip_single_file import requires_output
    import os
    import zipfile
    import shutil
    import tempfile


# Generated at 2022-06-18 07:40:57.361629
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    from thefuck.types import Command

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:41:08.172673
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', '', ''))
    assert not match(Command('unzip -d test.zip', '', ''))
    assert not match(Command('unzip -d test', '', ''))
    assert not match(Command('unzip -d test.zip test', '', ''))
    assert not match(Command('unzip -d test.zip test.zip', '', ''))
    assert not match(Command('unzip -d test.zip test.zip test', '', ''))
    assert not match(Command('unzip -d test.zip test.zip test.zip', '', ''))
    assert not match(Command('unzip -d test.zip test.zip test.zip test', '', ''))

# Generated at 2022-06-18 07:41:17.804926
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell
    from thefuck.types import Command

    test_dir = tempfile.mkdtemp()
    os.chdir(test_dir)
    test_file = 'test.txt'
    test_file_content = 'test'
    test_zip = 'test.zip'
    test_zip_content = 'test.txt'
    test_zip_content_content = 'test'
    test_zip_content_content_new = 'test_new'
    test_zip_content_new = 'test_new.txt'
    test_zip_content_new_content = 'test_new'
    test_dir_new = 'test_new'

# Generated at 2022-06-18 07:41:27.582922
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import subprocess

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:41:37.571873
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip file.zip -x file2.zip', '', ''))
    assert not match(Command('unzip file.zip -x file2.zip file3.zip', '', ''))

# Generated at 2022-06-18 07:41:51.288086
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
        archive.writestr('test2.txt', 'test2')

    # Create a file to be removed
    file_to_remove = os.path.join(tmpdir, 'test.txt')
    with open(file_to_remove, 'w') as f:
        f.write('test')

    # Create a file to be removed

# Generated at 2022-06-18 07:42:02.136586
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    archive = zipfile.ZipFile(os.path.join(tmpdir, 'test.zip'), 'w')
    archive.writestr('test.txt', 'test')
    archive.close()

    # Create a file
    open(os.path.join(tmpdir, 'test.txt'), 'w').close()

    # Create a directory
    os.mkdir(os.path.join(tmpdir, 'test'))

    # Create a file in the directory
    open(os.path.join(tmpdir, 'test', 'test.txt'), 'w').close()

    # Create a file outside the temporary directory

# Generated at 2022-06-18 07:42:11.220430
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert not match(Command('unzip file.zip -d file', '', ''))
    assert not match(Command('unzip file.zip file -d', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d file3 file4', '', ''))

# Generated at 2022-06-18 07:42:20.403562
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file file2', '', ''))
    assert not match(Command('unzip file file2', '', ''))
    assert not match(Command('unzip file.zip file2', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip file3.zip', '', ''))

# Generated at 2022-06-18 07:42:29.608170
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))

# Generated at 2022-06-18 07:42:38.833497
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir/', '', ''))
    assert not match(Command('unzip file.zip -d dir/subdir', '', ''))
    assert not match(Command('unzip file.zip -d dir/subdir/', '', ''))
    assert not match(Command('unzip file.zip -d dir/subdir/subsubdir', '', ''))

# Generated at 2022-06-18 07:42:42.671788
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))


# Generated at 2022-06-18 07:42:54.303343
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file', '', ''))
    assert match(Command('unzip file.zip file -x file2', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file.zip file -x file2', '', ''))
    assert not match(Command('unzip file.zip file2', '', ''))
    assert not match(Command('unzip file.zip file2 -x file3', '', ''))
    assert not match(Command('unzip -d file.zip file2', '', ''))

# Generated at 2022-06-18 07:43:04.534703
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.specific.unzip as unzip

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:43:12.022002
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.shells import get_closest

    # Create a zip file
    zip_file = 'test.zip'
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a directory
    dir_name = 'test_dir'
    os.mkdir(dir_name)

    # Create a file
    file_name = 'test.txt'
    with open(file_name, 'w') as f:
        f.write('test')

    # Create a command
    command = Command('unzip test.zip', '', '')

    # Test side_effect
    side_effect(command, command)

    # Test if the file and the directory were removed

# Generated at 2022-06-18 07:43:32.507870
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file.txt', '', ''))
    assert match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert match(Command('unzip file.zip -x file.txt', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file.txt', '', ''))
    assert not match(Command('unzip -d file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip -d file.zip -x file.txt', '', ''))
    assert not match(Command('unzip file.txt', '', ''))
   

# Generated at 2022-06-18 07:43:41.014672
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d dir file.zip', '', ''))
    assert not match(Command('unzip file.zip file', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3 file4', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3 file4 file5', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3 file4 file5 file6', '', ''))
    assert not match

# Generated at 2022-06-18 07:43:50.977705
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file1 file2', '', ''))
    assert not match(Command('unzip -d file file1 file2 file3', '', ''))

# Generated at 2022-06-18 07:44:01.623069
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))


# Generated at 2022-06-18 07:44:11.796929
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    archive = zipfile.ZipFile(os.path.join(tmpdir, 'test.zip'), 'w')
    archive.writestr('test.txt', 'test')
    archive.close()

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()
    os.chdir(tmpdir2)

    # Create a file
    open('test.txt', 'a').close()

    # Execute side_effect
    side_effect(None, None)

    # Check if the file has been removed
    assert not os.path.exists('test.txt')

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-18 07:44:19.159250
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))

# Generated at 2022-06-18 07:44:30.618500
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip -d dir file.zip', '', ''))
    assert not match(Command('unzip -d dir file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d dir file.zip file2.zip file3.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip file3.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip file3.zip file4.zip', '', ''))

# Generated at 2022-06-18 07:44:39.281993
# Unit test for function side_effect
def test_side_effect():
    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir)
    # Create a zip file
    zip_file = tempfile.NamedTemporaryFile(dir=tmp_dir)
    with zipfile.ZipFile(zip_file.name, 'w') as archive:
        archive.write(tmp_file.name)
    # Test side_effect function
    side_effect(zip_file.name, tmp_file.name)
    # Remove temporary directory
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:44:48.017466
# Unit test for function side_effect
def test_side_effect():
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a zip file
    zip_file = tempfile.NamedTemporaryFile(dir=tmpdir)
    with zipfile.ZipFile(zip_file.name, 'w') as archive:
        archive.write(tmpfile.name)
    # Create a command
    command = Command('unzip {}'.format(zip_file.name), '', '')
    # Call side_effect
    side_effect(command, command)
    # Check that the file has been removed
    assert not os.path.exists(tmpfile.name)

# Generated at 2022-06-18 07:44:57.528737
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file file2.zip', '', ''))
    assert not match(Command('unzip -d file file2', '', ''))
    assert not match(Command('unzip -d file.zip file2', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))

# Generated at 2022-06-18 07:45:27.284617
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file1 file2', '', ''))
    assert not match(Command('unzip -d file file1 file2 file3', '', ''))
    assert not match(Command('unzip -d file file1 file2 file3 file4', '', ''))

# Generated at 2022-06-18 07:45:37.568645
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file', '', ''))
    assert not match(Command('unzip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))

# Generated at 2022-06-18 07:45:45.157619
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip -x file.txt', '', ''))
    assert not match(Command('unzip file.zip -x file.txt file.txt', '', ''))
    assert not match(Command('unzip file.zip -x file.txt file.txt file.txt', '', ''))
    assert not match(Command('unzip file.zip -x file.txt file.txt file.txt file.txt', '', ''))

# Generated at 2022-06-18 07:45:55.537528
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test', '', ''))
    assert not match(Command('unzip -d test', '', ''))
    assert not match(Command('unzip -d', '', ''))
    assert not match(Command('unzip', '', ''))
    assert not match(Command('unzip -d test test.zip test2.zip', '', ''))
    assert not match(Command('unzip -d test test.zip test2', '', ''))
    assert not match(Command('unzip -d test test.zip test2.zip test3', '', ''))

# Generated at 2022-06-18 07:46:03.287200
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile.close()

    # Create a zip file
    with zipfile.ZipFile(os.path.join(tmpdir, 'test.zip'), 'w') as archive:
        archive.write(tmpfile.name, 'test.txt')

    # Test side_effect
    side_effect(shell.and_('unzip test.zip', 'unzip test.zip'),
                shell.and_('unzip test.zip', 'unzip test.zip'))

    # Check that the file has been removed

# Generated at 2022-06-18 07:46:11.112902
# Unit test for function side_effect
def test_side_effect():
    # Create a zip file with a file in it
    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file with the same name as the one in the zip file
    with open('test.txt', 'w') as f:
        f.write('test')

    # Run side_effect
    side_effect(Command('unzip test.zip', 'unzip test.zip'), Command('unzip test.zip -d test', 'unzip test.zip -d test'))

    # Check that the file has been removed
    assert not os.path.isfile('test.txt')

    # Cleanup
    os.remove('test.zip')

# Generated at 2022-06-18 07:46:21.427014
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert match(Command('unzip file.zip file2.zip', ''))
    assert match(Command('unzip file.zip file2.zip -x file3.zip', ''))
    assert not match(Command('unzip file.zip -d /tmp', ''))
    assert not match(Command('unzip file.zip -d /tmp file2.zip', ''))
    assert not match(Command('unzip file.zip -d /tmp file2.zip -x file3.zip', ''))
    assert not match(Command('unzip file.zip -d /tmp file2.zip -x file3.zip', ''))
    assert not match(Command('unzip file.zip -d /tmp file2.zip -x file3.zip', ''))

# Generated at 2022-06-18 07:46:32.954391
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Create a file in the directory

# Generated at 2022-06-18 07:46:40.530493
# Unit test for function side_effect
def test_side_effect():
    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    os.chdir(tmp_dir)

    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.close()

    # Create a zip file
    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.write(tmp_file.name)

    # Test side_effect
    side_effect(None, None)

    # Check that the file has been removed
    assert not os.path.isfile(tmp_file.name)

    # Remove the temporary directory
    os.remove('test.zip')
    os.rmdir(tmp_dir)

# Generated at 2022-06-18 07:46:50.370149
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip -a file.zip', '', ''))
    assert match(Command('unzip -a file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2', '', ''))

# Generated at 2022-06-18 07:47:36.833061
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert not match(Command('unzip -d file.zip -d', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -d', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip -d', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))

# Generated at 2022-06-18 07:47:44.047827
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert not match(Command('unzip -d file.zip -d', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -d', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip -d', '', ''))

# Generated at 2022-06-18 07:47:48.831137
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', '', ''))
    assert not match(Command('unzip -d test.zip', '', ''))
    assert not match(Command('unzip test.zip', '', ''))
    assert not match(Command('unzip -d test.zip', '', ''))


# Generated at 2022-06-18 07:47:58.551844
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()
    os.chdir(tmpdir2)

    # Create a file
    file = os.path.join(tmpdir2, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Test side_effect

# Generated at 2022-06-18 07:48:06.842503
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip file.zip file1 file2 -x file3', '', ''))
    assert not match(Command('unzip -d dir file.zip', '', ''))
    assert not match(Command('unzip -d dir file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d dir file.zip file1 file2 -x file3', '', ''))
    assert not match(Command('unzip file', '', ''))
    assert not match(Command('unzip file1 file2', '', ''))
    assert not match(Command('unzip file1 file2 -x file3', '', ''))

# Unit

# Generated at 2022-06-18 07:48:15.722461
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip file3.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip file3.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip file3.zip', '', ''))

# Generated at 2022-06-18 07:48:27.134000
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip file.zip file', '', ''))
    assert not match(Command('unzip file file', '', ''))
    assert not match(Command('unzip', '', ''))
    assert not match(Command('unzip -d', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))

# Generated at 2022-06-18 07:48:37.330650
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.types import Command

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:48:44.657041
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file file2', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file file2', '', ''))
    assert not match(Command('unzip file.zip file2.zip -d file3.zip', '', ''))

# Generated at 2022-06-18 07:48:54.788442
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells.bash as bash

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary zip file
    tmpzip = tempfile.NamedTemporaryFile(dir=tmpdir, suffix='.zip', delete=False)
    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)
    # Create a temporary file
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir2, delete=False)

    # Create a zip file with the temporary file and directory