

# Generated at 2022-06-18 07:40:04.986601
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command

    old_cmd = Command('unzip test.zip', '', '')
    command = Command('unzip -d test test.zip', '', '')

    side_effect(old_cmd, command)

    assert not os.path.exists('test.zip')
    assert os.path.exists('test')
    assert os.path.exists('test/test.txt')
    assert os.path.exists('test/test2.txt')

    os.remove('test/test.txt')
    os.remove('test/test2.txt')
    os.rmdir('test')

# Generated at 2022-06-18 07:40:12.607715
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip -x file3.zip', '', ''))


# Generated at 2022-06-18 07:40:24.573806
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))

# Generated at 2022-06-18 07:40:34.442411
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    from thefuck.types import Command

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:40:44.107053
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip file.zip -x file1 file2', '', ''))
    assert match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))

# Generated at 2022-06-18 07:40:51.442608
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip file.zip file2', '', ''))
    assert not match(Command('unzip file file2', '', ''))
    assert not match(Command('unzip -d file.zip file2', '', ''))
    assert not match(Command('unzip -d file file2', '', ''))
    assert not match(Command('unzip file.zip file2 file3', '', ''))
    assert not match(Command('unzip file file2 file3', '', ''))

# Generated at 2022-06-18 07:41:00.835699
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file with a file and a directory
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('file', 'content')
        archive.writestr('dir/file', 'content')

    # Create a file and a directory in the temporary directory
    file_path = os.path.join(tmpdir, 'file')
    dir_path = os.path.join(tmpdir, 'dir')
    with open(file_path, 'w') as f:
        f.write('content')
   

# Generated at 2022-06-18 07:41:11.042392
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Create a file in the directory
    file_in_dir = os.path.join(dir, 'test.txt')

# Generated at 2022-06-18 07:41:21.884753
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:41:30.891007
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert match(Command('unzip -l file.zip', '', ''))
    assert not match(Command('unzip -d dir file.zip', '', ''))
    assert not match(Command('unzip -d dir file', '', ''))
    assert not match(Command('unzip -d dir -l file.zip', '', ''))
    assert not match(Command('unzip -d dir -l file', '', ''))
    assert not match(Command('unzip -d dir file1.zip file2.zip', '', ''))
    assert not match(Command('unzip -d dir file1 file2', '', ''))

# Generated at 2022-06-18 07:41:53.542175
# Unit test for function side_effect
def test_side_effect():
    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Change the current directory to the temporary directory
    os.chdir(tmp_dir)
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    # Create a zip archive containing the temporary file
    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.write(tmp_file.name, 'test')
    # Call side_effect
    side_effect(None, None)
    # Check that the temporary file has been removed
    assert not os.path.isfile(tmp_file.name)
    # Remove the temporary directory
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:42:03.667252
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells.generic

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Create a command
    command = thefuck.shells

# Generated at 2022-06-18 07:42:12.674479
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary zipfile
    tmpzip = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpzip.close()
    # Add the temporary file to the zipfile
    with zipfile.ZipFile(tmpzip.name, 'w') as archive:
        archive.write(tmpfile.name, os.path.basename(tmpfile.name))
    # Create a command
    cmd = shell.and_('unzip', tmpzip.name)
    # Call side_effect

# Generated at 2022-06-18 07:42:22.613922
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip file.zip -x file1 file2', '', ''))
    assert not match(Command('unzip -d dir file.zip', '', ''))
    assert not match(Command('unzip -d dir file.zip file', '', ''))
    assert not match(Command('unzip -d dir file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d dir file.zip -x file1 file2', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2', '', ''))
   

# Generated at 2022-06-18 07:42:31.230038
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))

# Generated at 2022-06-18 07:42:40.935954
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Create a subdirectory
    subdir = os.path.join

# Generated at 2022-06-18 07:42:52.269476
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert match(Command('unzip file', ''))
    assert not match(Command('unzip -d file.zip', ''))
    assert not match(Command('unzip -d file', ''))
    assert not match(Command('unzip file.zip file2.zip', ''))
    assert not match(Command('unzip file file2', ''))
    assert not match(Command('unzip -d file.zip file2.zip', ''))
    assert not match(Command('unzip -d file file2', ''))
    assert not match(Command('unzip file.zip file2.zip file3.zip', ''))
    assert not match(Command('unzip file file2 file3', ''))

# Generated at 2022-06-18 07:42:56.952293
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import get_shell
    from thefuck.types import Command

    old_cmd = Command('unzip file.zip', '', get_shell())
    command = Command('unzip -d file file.zip', '', get_shell())
    side_effect(old_cmd, command)
    assert not os.path.exists('file')

# Generated at 2022-06-18 07:43:06.781262
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)
    # Create a temporary file
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir2)

    # Create a zip archive
    archive = zipfile.ZipFile(tmpfile.name + '.zip', 'w')
    archive.write(tmpfile.name)
    archive.write(tmpfile2.name)
    archive.close()

    # Create a command

# Generated at 2022-06-18 07:43:14.733004
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    archive = zipfile.ZipFile(os.path.join(tmpdir, 'archive.zip'), 'w')
    archive.writestr('file1', 'content1')
    archive.writestr('file2', 'content2')
    archive.close()

    # Create a file in the temporary directory
    file1 = os.path.join(tmpdir, 'file1')
    with open(file1, 'w') as f:
        f.write('content1')

    # Create a directory in the temporary directory
    dir1 = os.path.join(tmpdir, 'dir1')
    os.mkdir(dir1)

    #

# Generated at 2022-06-18 07:43:38.628713
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d dir file.zip', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3', '', ''))

# Generated at 2022-06-18 07:43:44.601287
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip file3.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip file3.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip file3.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip file3.zip', '', ''))

# Generated at 2022-06-18 07:43:55.311475
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert not match(Command('unzip file.zip -d file', '', ''))
    assert not match(Command('unzip file.zip file', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d', '', ''))
    assert not match(Command('unzip file.zip -d file1 file2', '', ''))
    assert not match(Command('unzip file.zip -d file1 file2 -d', '', ''))

# Generated at 2022-06-18 07:44:05.056499
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip file.zip -x file2.zip', '', ''))
    assert not match(Command('unzip file.zip -x file2.zip file3.zip', '', ''))

# Generated at 2022-06-18 07:44:14.882809
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir file.txt', '', ''))
    assert not match(Command('unzip file.zip -d dir file.txt -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir file.txt -d dir -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir file.txt -d dir -d dir -d dir', '', ''))

# Generated at 2022-06-18 07:44:22.542197
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert not match(Command('unzip -d file.zip -d', '', ''))
    assert not match(Command('unzip file.zip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d file.zip -d', '', ''))
    assert not match(Command('unzip -d file.zip -d file.zip -d', '', ''))

# Generated at 2022-06-18 07:44:34.197542
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1.txt', '', ''))
    assert match(Command('unzip file.zip file1.txt file2.txt', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file1.txt', '', ''))
    assert not match(Command('unzip -d file.zip file1.txt file2.txt', '', ''))
    assert not match(Command('unzip file1.txt file2.txt', '', ''))
    assert not match(Command('unzip file1.txt', '', ''))
    assert not match(Command('unzip', '', ''))

# Generated at 2022-06-18 07:44:45.239207
# Unit test for function match
def test_match():
    # Test if the function match works correctly
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file.zip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file.zip file.zip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file.zip file.zip file.zip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file.zip file.zip file.zip file.zip file.zip', '', ''))

# Generated at 2022-06-18 07:44:54.299489
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    archive = zipfile.ZipFile(os.path.join(tmpdir, 'test.zip'), 'w')
    archive.writestr('test.txt', 'test')
    archive.close()

    # Create a file to be removed
    open(os.path.join(tmpdir, 'test.txt'), 'a').close()

    # Create a directory to be removed
    os.mkdir(os.path.join(tmpdir, 'test'))

    # Create a file in the directory to be removed

# Generated at 2022-06-18 07:45:05.066992
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file.txt', '', ''))
    assert match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert match(Command('unzip file.zip -x file.txt', '', ''))
    assert match(Command('unzip file.zip -x file.txt file.txt', '', ''))
    assert match(Command('unzip file.zip -x file.txt file.txt file.txt', '', ''))
    assert match(Command('unzip file.zip -x file.txt file.txt file.txt file.txt', '', ''))

# Generated at 2022-06-18 07:45:43.292054
# Unit test for function side_effect
def test_side_effect():
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a temporary zip file
    tmpzip = tempfile.NamedTemporaryFile(suffix='.zip', dir=tmpdir)
    # Create a temporary zip file
    tmpzip2 = tempfile.NamedTemporaryFile(suffix='.zip', dir=tmpdir)
    # Create a temporary zip file
    tmpzip3 = tempfile.NamedTemporaryFile(suffix='.zip', dir=tmpdir)

    with zipfile.ZipFile(tmpzip.name, 'w') as archive:
        archive.write(tmpfile.name)


# Generated at 2022-06-18 07:45:52.595539
# Unit test for function side_effect
def test_side_effect():
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a zip file
    zip_file = tempfile.NamedTemporaryFile(dir=tmpdir, suffix='.zip')
    with zipfile.ZipFile(zip_file.name, 'w') as archive:
        archive.write(tmpfile.name, os.path.basename(tmpfile.name))
    # Create a directory
    dir = os.path.join(tmpdir, 'dir')
    os.mkdir(dir)
    # Create a file in the directory
    file = os.path.join(dir, 'file')
    with open(file, 'w') as f:
        f.write('content')
    #

# Generated at 2022-06-18 07:46:01.858705
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))

# Generated at 2022-06-18 07:46:10.133475
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells.bash as bash
    import thefuck.shells.zsh as zsh
    import thefuck.shells.fish as fish
    import thefuck.shells.shell as shell
    import thefuck.shells.cmd as cmd
    import thefuck.shells.powershell as powershell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a temporary zip file
    tmpzip = tempfile.NamedTemporaryFile(dir=tmpdir, suffix='.zip')
    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)
    #

# Generated at 2022-06-18 07:46:20.375772
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test_file')
    temp_zip = os.path.join(temp_dir, 'test.zip')

    with open(temp_file, 'w') as f:
        f.write('test')

    with zipfile.ZipFile(temp_zip, 'w') as z:
        z.write(temp_file)

    old_cmd = shell.and_('unzip', temp_zip)
    command = shell.and_('unzip', temp_zip, '-d', temp_dir)

    side_effect(old_cmd, command)

    assert not os.path.exists

# Generated at 2022-06-18 07:46:31.896754
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()
    os.chdir(tmpdir2)

    # Create a file
    file = os.path.join(tmpdir2, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Test side_effect

# Generated at 2022-06-18 07:46:40.343720
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    from thefuck.shells import shell

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:46:50.209775
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create the zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create the test file
    test_file = os.path.join(tmpdir, 'test.txt')
    with open(test_file, 'w') as f:
        f.write('test')

    # Create the test directory
    test_dir = os.path.join(tmpdir, 'test')
    os.mkdir(test_dir)

    # Create the

# Generated at 2022-06-18 07:47:01.011758
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    archive = zipfile.ZipFile(os.path.join(tmpdir, 'test.zip'), 'w')
    archive.writestr('test.txt', 'test')
    archive.close()

    # Create a file
    open(os.path.join(tmpdir, 'test.txt'), 'w').close()

    # Create a directory
    os.mkdir(os.path.join(tmpdir, 'test'))

    # Create a file in the directory
    open(os.path.join(tmpdir, 'test', 'test.txt'), 'w').close()

    # Create a command
    command = 'unzip test.zip'

# Generated at 2022-06-18 07:47:08.218510
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', '', ''))
    assert not match(Command('unzip -d test.zip', '', ''))
    assert not match(Command('unzip -d test', '', ''))
    assert not match(Command('unzip -d test', '', ''))
    assert not match(Command('unzip -d test', '', ''))
    assert not match(Command('unzip -d test', '', ''))
    assert not match(Command('unzip -d test', '', ''))
    assert not match(Command('unzip -d test', '', ''))
    assert not match(Command('unzip -d test', '', ''))
    assert not match(Command('unzip -d test', '', ''))
    assert not match(Command('unzip -d test', '', ''))


# Generated at 2022-06-18 07:47:49.212093
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2', '', ''))

# Generated at 2022-06-18 07:47:58.953186
# Unit test for function side_effect
def test_side_effect():
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
    # Create a file in the temporary directory
    file_path = os.path.join(tmpdir, 'test.txt')
    with open(file_path, 'w') as file:
        file.write('test')
    # Create a command
    command = Command('unzip test.zip', '', tmpdir)
    # Call side_effect
    side_effect(command, command)
    # Check that the file has been removed
    assert not os.path.exists(file_path)

# Generated at 2022-06-18 07:48:07.218308
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))

# Generated at 2022-06-18 07:48:16.205646
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells as shells

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    archive = zipfile.ZipFile(os.path.join(tmpdir, 'archive.zip'), 'w')
    archive.writestr('file1.txt', 'file1')
    archive.writestr('file2.txt', 'file2')
    archive.close()

    # Create some files in the temporary directory
    open(os.path.join(tmpdir, 'file1.txt'), 'w').close()
    open(os.path.join(tmpdir, 'file2.txt'), 'w').close()

# Generated at 2022-06-18 07:48:27.643546
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    archive = zipfile.ZipFile(os.path.join(tmpdir, 'test.zip'), 'w')
    archive.writestr('test.txt', 'test')
    archive.close()

    # Create a file
    open(os.path.join(tmpdir, 'test.txt'), 'w').close()

    # Create a directory
    os.mkdir(os.path.join(tmpdir, 'test'))

    # Create a file in the directory
    open(os.path.join(tmpdir, 'test', 'test.txt'), 'w').close()

    # Create a command

# Generated at 2022-06-18 07:48:37.755174
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file1 file2', '', ''))
    assert not match(Command('unzip -d file file1 file2 file3', '', ''))
    assert not match(Command('unzip -d file file1 file2 file3 file4', '', ''))

# Generated at 2022-06-18 07:48:44.883106
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert match(Command('unzip file.zip file1 file2', ''))
    assert match(Command('unzip file.zip file1 file2 -x file3', ''))
    assert match(Command('unzip file.zip file1 file2 -x file3 -d dir', ''))
    assert not match(Command('unzip -d dir file.zip', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir file1 file2', ''))
    assert not match(Command('unzip file.zip -d dir file1 file2 -x file3', ''))

# Generated at 2022-06-18 07:48:55.033926
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file.zip file2', '', ''))
    assert not match(Command('unzip -d file file file2.zip', '', ''))
    assert not match(Command('unzip -d file file file2', '', ''))
   

# Generated at 2022-06-18 07:49:04.476600
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip file.zip -x file1 file2', '', ''))
    assert match(Command('unzip file.zip -x file1 file2 file3', '', ''))
    assert match(Command('unzip file.zip -x file1 file2 file3 file4', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir file', '', ''))
    assert not match(Command('unzip file.zip -d dir file1 file2', '', ''))


# Generated at 2022-06-18 07:49:12.329142
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file.txt', '', ''))
    assert match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file.txt', '', ''))
    assert not match(Command('unzip -d file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip -x file.txt', '', ''))
    assert not match(Command('unzip file.zip -x file.txt -d file.txt', '', ''))