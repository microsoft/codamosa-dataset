

# Generated at 2022-06-18 07:40:06.854363
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir -x file', '', ''))
    assert not match(Command('unzip file -d dir -x file', '', ''))
    assert not match(Command('unzip file.zip -d dir -x file.zip', '', ''))
    assert not match(Command('unzip file -d dir -x file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir -x file.zip -x file2', '', ''))
   

# Generated at 2022-06-18 07:40:15.439557
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))


# Generated at 2022-06-18 07:40:26.649089
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))

# Generated at 2022-06-18 07:40:36.204985
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip file1 -x file2', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3 file4', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3 file4 file5', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3 file4 file5 file6', '', ''))


# Generated at 2022-06-18 07:40:46.519372
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file file2', '', ''))
    assert not match(Command('unzip -d file.zip file2', '', ''))
    assert not match(Command('unzip -d file file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))

# Generated at 2022-06-18 07:40:57.361946
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file file.zip', '', ''))
    assert not match(Command('unzip -d file file file', '', ''))
    assert not match(Command('unzip -d file file.zip file', '', ''))
    assert not match(Command('unzip -d file file file.zip file', '', ''))

# Generated at 2022-06-18 07:41:05.108338
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    try:
        os.chdir(temp_dir)
        with open('test.txt', 'w') as f:
            f.write('test')
        with zipfile.ZipFile('test.zip', 'w') as f:
            f.write('test.txt')
        side_effect(None, None)
        assert not os.path.exists('test.txt')
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:41:13.077133
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:41:23.983226
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a temporary file
    tmpfile = os.path.join(tmpdir, 'test.txt')
    with open(tmpfile, 'w') as f:
        f.write('test')

    # Create a temporary directory
    tmpdir2 = os.path.join(tmpdir, 'test')
    os.mkdir(tmpdir2)

    # Create a temporary file
    tmpfile2

# Generated at 2022-06-18 07:41:33.234844
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))

# Generated at 2022-06-18 07:41:56.816487
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))

# Generated at 2022-06-18 07:42:06.933922
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert not match(Command('unzip -d file.zip', ''))
    assert not match(Command('unzip file.zip -d', ''))
    assert not match(Command('unzip -d file.zip -d', ''))
    assert not match(Command('unzip file.zip -d file.zip', ''))
    assert not match(Command('unzip -d file.zip file.zip', ''))
    assert not match(Command('unzip -d file.zip file.zip -d', ''))
    assert not match(Command('unzip -d file.zip -d file.zip', ''))
    assert not match(Command('unzip -d file.zip -d file.zip -d', ''))

# Generated at 2022-06-18 07:42:14.842654
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.shells import get_shell
    from thefuck.main import create_alias
    from thefuck.rules.unzip_single_file import side_effect
    import os
    import zipfile

    alias = create_alias()
    shell = get_shell()
    zip_file = 'test.zip'
    file_to_unzip = 'test.txt'
    file_to_unzip_content = 'test'
    file_to_unzip_path = os.path.join(os.getcwd(), file_to_unzip)
    zip_file_path = os.path.join(os.getcwd(), zip_file)


# Generated at 2022-06-18 07:42:25.521173
# Unit test for function side_effect
def test_side_effect():
    import os
    import tempfile
    import zipfile

    with tempfile.TemporaryDirectory() as tmpdir:
        with zipfile.ZipFile(os.path.join(tmpdir, 'test.zip'), 'w') as archive:
            archive.writestr('test.txt', 'test')
            archive.writestr('test2.txt', 'test2')

        with open(os.path.join(tmpdir, 'test.txt'), 'w') as f:
            f.write('test')

        with open(os.path.join(tmpdir, 'test2.txt'), 'w') as f:
            f.write('test2')

        with open(os.path.join(tmpdir, 'test3.txt'), 'w') as f:
            f.write('test3')


# Generated at 2022-06-18 07:42:33.262012
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    archive = zipfile.ZipFile(os.path.join(tmpdir, 'test.zip'), 'w')
    archive.writestr('test.txt', 'test')
    archive.close()

    # Create a file
    open(os.path.join(tmpdir, 'test.txt'), 'w').close()

    # Create a directory
    os.mkdir(os.path.join(tmpdir, 'test'))

    # Create a file in the directory
    open(os.path.join(tmpdir, 'test', 'test.txt'), 'w').close()

    # Create a command

# Generated at 2022-06-18 07:42:42.929228
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test_file')
    tmp_zip = os.path.join(tmp_dir, 'test_file.zip')

    with open(tmp_file, 'w') as f:
        f.write('test')

    with zipfile.ZipFile(tmp_zip, 'w') as z:
        z.write(tmp_file)

    old_cmd = 'unzip {}'.format(tmp_zip)
    command = 'unzip -d {} {}'.format(tmp_dir, tmp_zip)

    side_effect(old_cmd, command)

    assert os.path.exists(tmp_file)


# Generated at 2022-06-18 07:42:54.621006
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))

# Generated at 2022-06-18 07:43:04.824280
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import subprocess

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:43:12.173849
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
        archive.writestr('test2.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')

# Generated at 2022-06-18 07:43:22.072621
# Unit test for function side_effect
def test_side_effect():
    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir)
    # Create a zip file
    with zipfile.ZipFile(tmp_file.name, 'w') as archive:
        archive.write(tmp_file.name)
    # Create a command
    command = Command('unzip {}'.format(tmp_file.name), '', '')
    # Call side_effect
    side_effect(command, command)
    # Check that the file has been removed
    assert not os.path.exists(tmp_file.name)
    # Remove the temporary directory
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:43:43.367051
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')
    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)
    # Create a file in the directory
    file_in_dir = os.path.join(dir, 'test.txt')

# Generated at 2022-06-18 07:43:53.826931
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip'))
    assert match(Command('unzip file.zip file2.zip'))
    assert match(Command('unzip -a file.zip'))
    assert match(Command('unzip -a file.zip file2.zip'))
    assert not match(Command('unzip -d file.zip'))
    assert not match(Command('unzip -d file.zip file2.zip'))
    assert not match(Command('unzip -d file.zip file2.zip file3.zip'))
    assert not match(Command('unzip -d file.zip file2.zip file3.zip file4.zip'))
    assert not match(Command('unzip -d file.zip file2.zip file3.zip file4.zip file5.zip'))

# Generated at 2022-06-18 07:44:03.705601
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells
    import thefuck.types

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Create a command

# Generated at 2022-06-18 07:44:13.808672
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3', '', ''))
    assert match(Command('unzip file.zip file1 file2 -x file3 file4', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3 file4 file5', '', ''))
    assert match(Command('unzip file.zip file1 file2 -x file3 file4 file5 file6', '', ''))

# Generated at 2022-06-18 07:44:20.069186
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Test side_effect
    old_cmd = type('', (), {'script': 'unzip test.zip', 'script_parts': ['unzip', 'test.zip']})

# Generated at 2022-06-18 07:44:31.548245
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file1 file2', '', ''))
    assert not match(Command('unzip -d file file1 file2 file3', '', ''))
    assert not match(Command('unzip -d file file1 file2 file3 file4', '', ''))

# Generated at 2022-06-18 07:44:43.379242
# Unit test for function match
def test_match():
    assert match(Command('unzip', 'unzip file.zip'))
    assert not match(Command('unzip', 'unzip -d file.zip'))
    assert not match(Command('unzip', 'unzip -d file'))
    assert not match(Command('unzip', 'unzip -d file.zip file'))
    assert not match(Command('unzip', 'unzip -d file.zip file.zip'))
    assert not match(Command('unzip', 'unzip -d file.zip file.zip file'))
    assert not match(Command('unzip', 'unzip -d file.zip file.zip file.zip'))
    assert not match(Command('unzip', 'unzip -d file.zip file.zip file.zip file'))

# Generated at 2022-06-18 07:44:50.679002
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create the zip file
    test_zip = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(test_zip, 'w') as archive:
        archive.writestr('test.txt', 'test')
        archive.writestr('test2.txt', 'test')

    # Create the command
    command = shell.and_('unzip', test_zip)

    # Create the test file
    test_file = os.path.join(tmpdir, 'test.txt')
    with open(test_file, 'w') as f:
        f.write('test')

    #

# Generated at 2022-06-18 07:45:00.539965
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip file.zip -x file1 file2', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d file.zip -x file1 file2', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d file3', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d file3', '', ''))

# Generated at 2022-06-18 07:45:11.211122
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a temporary zip file
    tmpzip = tempfile.NamedTemporaryFile(dir=tmpdir, suffix='.zip')
    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)
    # Create a temporary file
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir2)

    # Create a zip file
    with zipfile.ZipFile(tmpzip.name, 'w') as archive:
        archive.write(tmpfile.name, os.path.basename(tmpfile.name))

# Generated at 2022-06-18 07:45:37.312841
# Unit test for function side_effect
def test_side_effect():
    from thefuck.rules.unzip_single_file import side_effect
    from thefuck.shells import shell
    from thefuck.types import Command
    import os
    import zipfile
    import tempfile
    import shutil
    import subprocess

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary zip file
    tmpzip = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpzip.close()
    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir2, delete=False)

# Generated at 2022-06-18 07:45:44.738160
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')
    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)
    # Create a file in the directory
    file_in_dir = os.path.join(dir, 'test.txt')

# Generated at 2022-06-18 07:45:54.657966
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip', '', ''))
    assert not match(Command('unzip -d dir', '', ''))
    assert not match(Command('unzip -d dir file.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir file2.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir file2.zip -d dir2', '', ''))

# Generated at 2022-06-18 07:46:02.919026
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    with tempfile.TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        with open('file1.txt', 'w') as f:
            f.write('test')
        with open('file2.txt', 'w') as f:
            f.write('test')
        with open('file3.txt', 'w') as f:
            f.write('test')
        with open('file4.txt', 'w') as f:
            f.write('test')
        os.mkdir('dir1')
        os.mkdir('dir2')
        with open('dir1/file5.txt', 'w') as f:
            f.write('test')

# Generated at 2022-06-18 07:46:11.358212
# Unit test for function match
def test_match():
    assert match(Command('unzip', 'unzip file.zip'))
    assert match(Command('unzip', 'unzip file'))
    assert match(Command('unzip', 'unzip file.zip file2.zip'))
    assert match(Command('unzip', 'unzip file.zip file2'))
    assert match(Command('unzip', 'unzip file.zip file2 -x file3'))
    assert not match(Command('unzip', 'unzip -d dir file.zip'))
    assert not match(Command('unzip', 'unzip -d dir file'))
    assert not match(Command('unzip', 'unzip -d dir file.zip file2.zip'))
    assert not match(Command('unzip', 'unzip -d dir file.zip file2'))

# Generated at 2022-06-18 07:46:21.683221
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d directory', '', ''))
    assert not match(Command('unzip -l file.zip', '', ''))
    assert not match(Command('unzip -l file.zip', '', ''))
    assert not match(Command('unzip -l file.zip', '', ''))
    assert not match(Command('unzip -l file.zip', '', ''))
    assert not match(Command('unzip -l file.zip', '', ''))
    assert not match(Command('unzip -l file.zip', '', ''))
    assert not match(Command('unzip -l file.zip', '', ''))
    assert not match(Command('unzip -l file.zip', '', ''))
   

# Generated at 2022-06-18 07:46:33.233281
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))

# Generated at 2022-06-18 07:46:41.178693
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file.zip file2', '', ''))
    assert not match(Command('unzip -d file file file2.zip', '', ''))
    assert not match(Command('unzip -d file file file2', '', ''))
   

# Generated at 2022-06-18 07:46:51.351982
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)
    os.mkdir('test_dir')
    with open('test_file', 'w') as f:
        f.write('test')

    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.write('test_file')
        archive.write('test_dir')

    old_cmd = shell.and_('unzip test.zip', 'echo "test"')
    side_effect(old_cmd, shell.and_('unzip test.zip', 'echo "test"'))

    assert not os.path.exists('test_file')
    assert os.path.exists

# Generated at 2022-06-18 07:47:01.790646
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')
    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)
    # Create a file in the directory
    file_in_dir = os.path.join(dir, 'test.txt')

# Generated at 2022-06-18 07:47:28.284819
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file file.zip', '', ''))
    assert not match(Command('unzip -d file file file', '', ''))
    assert not match(Command('unzip -d file file.zip file', '', ''))
    assert not match

# Generated at 2022-06-18 07:47:34.685856
# Unit test for function side_effect
def test_side_effect():
    os.mkdir('test')
    with open('test/test.txt', 'w') as f:
        f.write('test')
    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.write('test/test.txt')
    os.remove('test/test.txt')
    os.rmdir('test')
    side_effect(None, None)
    assert os.path.exists('test.txt')
    os.remove('test.txt')
    os.remove('test.zip')

# Generated at 2022-06-18 07:47:41.325480
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file.zip file2', '', ''))
    assert not match(Command('unzip -d file file file2.zip', '', ''))
    assert not match(Command('unzip -d file file file2', '', ''))
   

# Generated at 2022-06-18 07:47:48.403313
# Unit test for function side_effect
def test_side_effect():
    # create a zip file
    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.writestr('test.txt', 'test')
    # create a file with the same name as the one in the zip file
    with open('test.txt', 'w') as f:
        f.write('test')
    # run the side effect
    side_effect(None, None)
    # check that the file has been removed
    assert not os.path.isfile('test.txt')
    # remove the zip file
    os.remove('test.zip')

# Generated at 2022-06-18 07:47:58.035463
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells
    from thefuck.types import Command

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Test side_effect


# Generated at 2022-06-18 07:48:06.355201
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file.zip file2', '', ''))
    assert not match(Command('unzip -d file file file2.zip', '', ''))
    assert not match(Command('unzip -d file file file2', '', ''))
   

# Generated at 2022-06-18 07:48:15.057112
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))

# Generated at 2022-06-18 07:48:26.356303
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:48:36.606904
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.shells import get_shell
    from thefuck.main import create_alias
    from thefuck.rules.unzip_single_file import side_effect
    from thefuck.rules.unzip_single_file import get_new_command
    from thefuck.rules.unzip_single_file import match

    shell = get_shell()
    alias = create_alias()
    old_cmd = Command('unzip file.zip', '', alias)
    command = get_new_command(old_cmd)
    side_effect(old_cmd, command)
    assert match(Command('unzip file.zip', '', alias))
    assert not match(Command('unzip file.zip -d file', '', alias))

# Generated at 2022-06-18 07:48:44.227107
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file file2', '', ''))
    assert not match(Command('unzip -d file file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))

# Generated at 2022-06-18 07:49:22.047121
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
        archive.writestr('test2.txt', 'test')

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()
    os.chdir(tmpdir2)

    # Create a file
    file = os.path.join(tmpdir2, 'test.txt')

# Generated at 2022-06-18 07:49:32.794500
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir file1 file2', '', ''))
    assert not match(Command('unzip file.zip -d dir -x file1 file2', '', ''))

# Generated at 2022-06-18 07:49:42.155939
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()
    os.chdir(tmpdir2)

    # Create a file
    open('test.txt', 'a').close()

    # Test side_effect
    old_cmd = type('', (), {'script': 'unzip {}'.format(zip_file)})()

# Generated at 2022-06-18 07:49:48.989891
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert not match(Command('unzip -d file.zip -d', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -d', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip -d', '', ''))

# Generated at 2022-06-18 07:49:56.649197
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells
    import thefuck.specific.unzip

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a directory
    dir_name = os.path.join(tmpdir, 'test')
    os.mkdir(dir_name)

    # Create a file
    file_name = os.path.join(dir_name, 'test.txt')