

# Generated at 2022-06-18 07:40:04.935061
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import shell
    from thefuck.types import Command
    from thefuck.rules.unzip_single_file import side_effect
    import os
    import zipfile

    # Create a temporary directory
    import tempfile
    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)

    # Create a zip file
    with open('file1', 'w') as f:
        f.write('file1')
    with open('file2', 'w') as f:
        f.write('file2')
    with open('file3', 'w') as f:
        f.write('file3')
    with zipfile.ZipFile('test.zip', 'w') as z:
        z.write('file1')
        z.write('file2')

# Generated at 2022-06-18 07:40:14.402701
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as temp_dir:
        os.chdir(temp_dir)
        os.mkdir('test_dir')
        with open('test_file', 'w') as f:
            f.write('test')

        with zipfile.ZipFile('test.zip', 'w') as archive:
            archive.write('test_file')
            archive.write('test_dir')

        side_effect(None, None)

        assert os.path.exists('test_file')
        assert os.path.exists('test_dir')
        assert os.path.isdir('test_dir')
        assert os.path.isfile('test_file')

        shutil.rmtree('test_dir')
        os.remove('test_file')

# Generated at 2022-06-18 07:40:25.540034
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1.txt', '', ''))
    assert match(Command('unzip file.zip file1.txt file2.txt', '', ''))
    assert not match(Command('unzip file.zip -d dest', '', ''))
    assert not match(Command('unzip file.zip -d dest file1.txt', '', ''))
    assert not match(Command('unzip file.zip -d dest file1.txt file2.txt', '', ''))
    assert not match(Command('unzip file.zip file1.txt -d dest', '', ''))
    assert not match(Command('unzip file.zip file1.txt file2.txt -d dest', '', ''))

# Generated at 2022-06-18 07:40:35.195711
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1', '', ''))
    assert not match(Command('unzip file.zip -x file1 -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))

# Generated at 2022-06-18 07:40:45.260350
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test_file')
    tmp_file2 = os.path.join(tmp_dir, 'test_file2')
    tmp_file3 = os.path.join(tmp_dir, 'test_file3')
    tmp_file4 = os.path.join(tmp_dir, 'test_file4')
    tmp_file5 = os.path.join(tmp_dir, 'test_file5')
    tmp_file6 = os.path.join(tmp_dir, 'test_file6')

# Generated at 2022-06-18 07:40:51.983491
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')
    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Test side_effect

# Generated at 2022-06-18 07:41:00.994864
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file file file2', '', ''))
    assert not match(Command('unzip -d file file.zip file2', '', ''))

# Generated at 2022-06-18 07:41:11.177284
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip file.zip -x file1 file2', '', ''))
    assert match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))

# Generated at 2022-06-18 07:41:21.871942
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    file_path = os.path.join(tmpdir, 'file')
    with open(file_path, 'w') as f:
        f.write('test')

    # Create a zip file in the temporary directory
    zip_path = os.path.join(tmpdir, 'file.zip')
    with zipfile.ZipFile(zip_path, 'w') as zip_file:
        zip_file.write(file_path)

    # Create a command
    command = 'unzip {}'.format(zip_path)
    # Create a command object
    command_object = shell.and_('', command)

    # Call side

# Generated at 2022-06-18 07:41:30.892644
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file', '', ''))
    assert match(Command('unzip -a file.zip', '', ''))
    assert match(Command('unzip -a file.zip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2 file3', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2 file3 file4', '', ''))

# Generated at 2022-06-18 07:41:46.269656
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2', '', ''))
    assert match(Command('unzip file file2.zip', '', ''))
    assert match(Command('unzip file file2', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2', '', ''))

# Generated at 2022-06-18 07:41:57.076685
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))

# Generated at 2022-06-18 07:42:07.178129
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
    # Create a temporary file
    tmp_file = os.path.join(tmpdir, 'test.txt')
    with open(tmp_file, 'w') as f:
        f.write('test')
    # Create a temporary directory
    tmp_dir = os.path.join(tmpdir, 'test')
    os.mkdir(tmp_dir)
    # Create a temporary file in the temporary directory
    tmp_file_in_dir

# Generated at 2022-06-18 07:42:15.032338
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')
    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)
    # Create a file in the directory
    file_in_dir = os.path.join(dir, 'test.txt')

# Generated at 2022-06-18 07:42:25.720530
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:42:34.117101
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
        archive.writestr('test2.txt', 'test2')

    # Create a file
    test_file = os.path.join(tmpdir, 'test.txt')
    with open(test_file, 'w') as f:
        f.write('test')

    # Create a directory
    test_dir = os.path.join(tmpdir, 'test')
    os.mkdir(test_dir)

    # Create a

# Generated at 2022-06-18 07:42:43.754964
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells.shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create the zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create the command
    old_cmd = thefuck.shells.shell.And('unzip', zip_file)

    # Create the file to be removed
    file_to_remove = os.path.join(tmpdir, 'test.txt')
    with open(file_to_remove, 'w') as f:
        f.write('test')

    # Test the side

# Generated at 2022-06-18 07:42:55.153347
# Unit test for function side_effect
def test_side_effect():
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a zip file
    with zipfile.ZipFile(tmpdir + '/test.zip', 'w') as archive:
        archive.write(tmpfile.name)
    # Create a command
    command = Command('unzip test.zip', '', tmpdir)
    # Create a old_cmd
    old_cmd = Command('unzip test.zip', '', tmpdir)
    # Call side_effect
    side_effect(old_cmd, command)
    # Check if the file has been removed
    assert not os.path.exists(tmpfile.name)
    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-18 07:43:03.525372
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file file2', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file file2', '', ''))


# Generated at 2022-06-18 07:43:11.398401
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:43:35.854108
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create the zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file to remove
    test_file = os.path.join(tmpdir, 'test.txt')
    with open(test_file, 'w') as f:
        f.write('test')

    # Create a directory to remove
    test_dir = os.path.join(tmpdir, 'test')
    os.mkdir(test_dir)

    # Create a

# Generated at 2022-06-18 07:43:41.426697
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file', '', ''))
    assert match(Command('unzip file.zip file -x file2', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir file', '', ''))
    assert not match(Command('unzip file.zip -d dir file -x file2', '', ''))


# Generated at 2022-06-18 07:43:51.017060
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip -x file.txt', '', ''))
    assert not match(Command('unzip file.zip -x file.txt', '', ''))
    assert not match(Command('unzip file.zip -x file.txt file.txt', '', ''))
    assert not match(Command('unzip file.zip -x file.txt file.txt file.txt', '', ''))

# Generated at 2022-06-18 07:44:01.665693
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip file', '', ''))
    assert not match(Command('unzip file.zip file -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip file1 file2 file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 file3 -d dir', '', ''))

# Generated at 2022-06-18 07:44:11.842614
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))

# Generated at 2022-06-18 07:44:19.181686
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells.shell
    import thefuck.specific.unzip

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile.close()
    # Create a temporary zip file
    tmpzip = tempfile.NamedTemporaryFile(dir=tmpdir, suffix='.zip', delete=False)
    tmpzip.close()
    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)
    # Create a temporary file
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir2, delete=False)
    tmpfile2

# Generated at 2022-06-18 07:44:30.666364
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))

# Generated at 2022-06-18 07:44:42.292362
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Test side_effect
    old_cmd = type('', (), {'script': 'unzip test.zip', 'script_parts': ['unzip', 'test.zip']})

# Generated at 2022-06-18 07:44:50.122821
# Unit test for function match
def test_match():
    assert match(Command('unzip', 'unzip file.zip'))
    assert match(Command('unzip', 'unzip file'))
    assert not match(Command('unzip', 'unzip -d file.zip'))
    assert not match(Command('unzip', 'unzip -d file'))
    assert not match(Command('unzip', 'unzip -d file.zip file'))
    assert not match(Command('unzip', 'unzip -d file file.zip'))
    assert not match(Command('unzip', 'unzip -d file file'))
    assert not match(Command('unzip', 'unzip -d file file.zip file2'))
    assert not match(Command('unzip', 'unzip -d file file2 file.zip'))

# Generated at 2022-06-18 07:45:00.477474
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.shells import get_shell
    from thefuck.main import create_alias
    from thefuck.rules.unzip_single_file import side_effect
    from thefuck.rules.unzip_single_file import get_new_command
    from thefuck.rules.unzip_single_file import _zip_file
    from thefuck.rules.unzip_single_file import _is_bad_zip
    from thefuck.rules.unzip_single_file import match
    from thefuck.rules.unzip_single_file import requires_output

    # Create a temporary directory
    import tempfile
    import shutil
    import os
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    # Create a file
    f = open

# Generated at 2022-06-18 07:45:25.715452
# Unit test for function side_effect
def test_side_effect():
    # Create a zip archive with a file
    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file with the same name as the file in the archive
    with open('test.txt', 'w') as f:
        f.write('test')

    # Create a directory with the same name as the file in the archive
    os.mkdir('test.txt')

    # Run the side_effect function
    side_effect(None, None)

    # Check that the file is gone
    assert not os.path.isfile('test.txt')

    # Check that the directory is still there
    assert os.path.isdir('test.txt')

    # Clean up
    os.remove('test.zip')

# Generated at 2022-06-18 07:45:36.126081
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file file.zip', '', ''))
    assert not match(Command('unzip -d file file file', '', ''))
    assert not match(Command('unzip -d file file file file.zip', '', ''))

# Generated at 2022-06-18 07:45:42.158914
# Unit test for function side_effect
def test_side_effect():
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Change to that directory
    os.chdir(tmpdir)
    # Create a zip file
    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.writestr('test.txt', 'test')
    # Create a file
    with open('test.txt', 'w') as f:
        f.write('test')
    # Run the side_effect function
    side_effect(None, None)
    # Check that the file has been removed
    assert not os.path.isfile('test.txt')
    # Remove the temporary directory
    os.rmdir(tmpdir)

# Generated at 2022-06-18 07:45:51.386348
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3 file4', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3 file4 file5', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3 file4 file5 file6', '', ''))

# Generated at 2022-06-18 07:46:00.828190
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells.shell

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:46:06.392186
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip -d dir file.zip', '', ''))
    assert not match(Command('unzip -d dir file', '', ''))
    assert not match(Command('unzip -d dir file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d dir file.zip file2', '', ''))
    assert not match(Command('unzip -d dir file.zip file2.zip file3', '', ''))
    assert not match(Command('unzip -d dir file.zip file2.zip file3.zip', '', ''))

# Generated at 2022-06-18 07:46:11.196851
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.shells import get_shell
    from thefuck.main import get_closest

    shell = get_shell()
    old_cmd = Command('unzip', 'unzip file.zip')
    command = get_closest(old_cmd)
    side_effect(old_cmd, command)
    assert shell.run(command).stdout == ''

# Generated at 2022-06-18 07:46:21.566702
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))

# Generated at 2022-06-18 07:46:33.099151
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.shells import get_shell
    from thefuck.main import get_closest

    shell_obj = get_shell()
    shell_obj.system.side_effect = lambda x: 0
    shell_obj.system.return_value = 0
    shell_obj.system.stdout.return_value = 'unzip:  cannot find or open file.zip, file.zip.zip or file.zip.ZIP.'
    shell_obj.system.stderr.return_value = ''
    shell_obj.system.stdin.return_value = ''
    shell_obj.system.files = {'file.zip': '', 'file.txt': ''}
    shell_obj.system.dirs = {'dir': ''}
    shell_obj.system.getcwd

# Generated at 2022-06-18 07:46:41.103057
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip -d file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -d file3.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -d file3.zip file4.zip', '', ''))

# Generated at 2022-06-18 07:47:05.487755
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    archive = zipfile.ZipFile(os.path.join(tmpdir, 'test.zip'), 'w')
    archive.writestr('test.txt', 'test')
    archive.close()

    # Create a file in the temporary directory
    open(os.path.join(tmpdir, 'test.txt'), 'w').close()

    # Create a command
    command = type('Command', (object,), {
        'script': 'unzip -d ' + tmpdir + ' ' + os.path.join(tmpdir, 'test.zip')
    })

    # Run side_effect
    side_effect(command, command)

    #

# Generated at 2022-06-18 07:47:14.358109
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)

    # Create a zip file with a file and a directory
    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.writestr('file', '')
        archive.writestr('dir/file', '')

    # Create a file and a directory
    os.mkdir('dir')
    with open('file', 'w') as f:
        f.write('')

    # Test side_effect
    side_effect(None, None)

    # Check that the file and the directory have been removed
    assert not os.path.exists('file')
    assert not os.path.exists('dir')

    # Clean

# Generated at 2022-06-18 07:47:24.130617
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))

# Generated at 2022-06-18 07:47:34.163844
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:47:40.609687
# Unit test for function side_effect
def test_side_effect():
    # Create a zip file
    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.writestr('test.txt', 'test')
        archive.writestr('test2.txt', 'test2')

    # Create a file to be overwritten
    with open('test.txt', 'w') as f:
        f.write('test')

    # Create a file to be overwritten
    with open('test2.txt', 'w') as f:
        f.write('test2')

    # Create a file to be overwritten
    with open('test3.txt', 'w') as f:
        f.write('test3')

    # Create a directory to be overwritten
    os.mkdir('test')

    # Create a directory to be overwritten
    os.mkdir('test2')

# Generated at 2022-06-18 07:47:50.164487
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip file.zip -x file2.zip', '', ''))
    assert not match(Command('unzip file.zip -x file2.zip file3.zip', '', ''))

# Generated at 2022-06-18 07:47:59.613062
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.shells import get_shell
    from thefuck.main import create_alias
    from thefuck.rules.unzip import side_effect
    from thefuck.rules.unzip import get_new_command
    from thefuck.rules.unzip import match
    import os
    import zipfile
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    archive = zipfile.ZipFile(os.path.join(tmpdir, 'test.zip'), 'w')
    archive.writestr('test.txt', 'test')
    archive.close()

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()

    # Create a file
    f

# Generated at 2022-06-18 07:48:07.841029
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Create a file in the directory
    file_in_dir = os.path.join(dir, 'test.txt')

# Generated at 2022-06-18 07:48:16.967169
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells
    import thefuck.rules.unzip_single_file

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a directory
    dir_name = os.path.join(tmpdir, 'test')
    os.mkdir(dir_name)

    # Create a file
    file_name = os.path.join(tmpdir, 'test.txt')
    with open(file_name, 'w') as f:
        f

# Generated at 2022-06-18 07:48:28.556199
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip file.zip file1 file2 -x file3', '', ''))
    assert match(Command('unzip file.zip -x file3', '', ''))
    assert match(Command('unzip file.zip -x file3 -x file4', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir -x file3', '', ''))
    assert not match(Command('unzip file.zip -d dir file1 file2', '', ''))

# Generated at 2022-06-18 07:49:05.329245
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.shells import get_shell
    from thefuck.main import create_alias
    from thefuck.rules.unzip_single_file import side_effect

    shell = get_shell()
    alias = create_alias()
    old_cmd = Command('unzip file.zip', '', alias)
    command = Command('unzip -d file file.zip', '', alias)

    side_effect(old_cmd, command)

    assert shell.and_(
        shell.rm('file'),
        shell.rm('file.zip')
    ) in shell.history

# Generated at 2022-06-18 07:49:11.392481
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d', '', ''))
    assert not match(Command('unzip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file file2', '', ''))


# Generated at 2022-06-18 07:49:17.770661
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.specific.unzip as unzip

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # create a file in the directory
    file

# Generated at 2022-06-18 07:49:26.894778
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert not match(Command('unzip -d file.zip -d', '', ''))
    assert not match(Command('unzip -d file.zip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file.zip -d', '', ''))
    assert not match(Command('unzip -d file.zip file.zip -d file.zip', '', ''))

# Generated at 2022-06-18 07:49:36.330951
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # create a file in the directory

# Generated at 2022-06-18 07:49:45.559318
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Create a file in the directory
    file_in_dir = os.path.join(dir, 'test.txt')

# Generated at 2022-06-18 07:49:53.704657
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')
    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)
    # Create a file in the directory
    file_in_