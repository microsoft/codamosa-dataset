

# Generated at 2022-06-18 07:40:07.368936
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert match(Command('unzip file.zip -x file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip -d file.zip -x file2.zip', '', ''))

# Generated at 2022-06-18 07:40:15.722847
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a temporary file
    tmpfile = os.path.join(tmpdir, 'test.txt')
    with open(tmpfile, 'w') as f:
        f.write('test')

    # Create a temporary directory
    tmpdir2 = os.path.join(tmpdir, 'test')
    os.mkdir(tmpdir2)

    # Create a temporary file in the temporary directory
    tmpfile2 = os.path.join

# Generated at 2022-06-18 07:40:26.926777
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:40:36.405059
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
    # Create a directory
    dir_path = os.path.join(tmpdir, 'test')
    os.mkdir(dir_path)
    # Create a file in the directory
    file_path = os.path.join(dir_path, 'test.txt')
    with open(file_path, 'w') as f:
        f.write('test')
    #

# Generated at 2022-06-18 07:40:46.710587
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    tmpfile.write(b'foo')
    tmpfile.flush()

    # Create temporary zip file
    tmpzip = tempfile.NamedTemporaryFile(dir=tmpdir, suffix='.zip')
    with zipfile.ZipFile(tmpzip.name, 'w') as archive:
        archive.write(tmpfile.name, os.path.basename(tmpfile.name))

    # Create temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)

    # Create temporary file in temporary directory
    tmp

# Generated at 2022-06-18 07:40:57.371864
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip -a file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip file3.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip file3.zip file4.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip file3.zip file4.zip file5.zip', '', ''))

# Generated at 2022-06-18 07:41:08.172474
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells
    import thefuck.types
    import thefuck.main

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:41:14.459072
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d file3', '', ''))

# Generated at 2022-06-18 07:41:25.183828
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip file3.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip file3.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert not match(Command('unzip file.zip file2.zip -d', '', ''))

# Generated at 2022-06-18 07:41:29.394922
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.shells import get_shell
    from thefuck.main import create_alias
    from thefuck.rules.unzip_single_file import side_effect
    from thefuck.rules.unzip_single_file import _zip_file
    import os
    import tempfile
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)

    # Create a zip file
    archive = zipfile.ZipFile('test.zip', 'w')
    archive.writestr('test.txt', 'test')
    archive.close()

    # Create a file
    open('test.txt', 'w').close()

    # Create a command
    command = Command('unzip test.zip', '', get_shell())

# Generated at 2022-06-18 07:41:43.916812
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2 -x file3', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2 -x file3 file4', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2 -x file3 file4 file5', '', ''))

# Generated at 2022-06-18 07:41:53.985308
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))


# Generated at 2022-06-18 07:42:04.150402
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert match(Command('unzip file.zip file1.txt', ''))
    assert match(Command('unzip file.zip file1.txt file2.txt', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir file1.txt', ''))
    assert not match(Command('unzip file.zip -d dir file1.txt file2.txt', ''))
    assert not match(Command('unzip file.zip -d dir file1.txt file2.txt', ''))
    assert not match(Command('unzip file.zip -d dir file1.txt file2.txt', ''))

# Generated at 2022-06-18 07:42:13.043133
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))

# Generated at 2022-06-18 07:42:23.586339
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))

# Generated at 2022-06-18 07:42:31.528889
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells
    import thefuck.specific.unzip

    temp_dir = tempfile.mkdtemp()
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir)
    temp_file.write(b'foo')
    temp_file.flush()
    temp_file_name = temp_file.name
    temp_file.close()

    with zipfile.ZipFile(os.path.join(temp_dir, 'test.zip'), 'w') as archive:
        archive.write(temp_file_name)

    thefuck.shells.shell = thefuck.shells.Bash()
    thefuck.specific.unzip.side_effect(None, 'unzip test.zip')


# Generated at 2022-06-18 07:42:41.263910
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells.shell

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:42:52.790321
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file.txt', '', ''))
    assert not match(Command('unzip -d file.zip file.txt file2.txt', '', ''))
    assert not match(Command('unzip -d file.zip file.txt file2.txt file3.txt', '', ''))
    assert not match(Command('unzip -d file.zip file.txt file2.txt file3.txt file4.txt', '', ''))
    assert not match(Command('unzip -d file.zip file.txt file2.txt file3.txt file4.txt file5.txt', '', ''))

# Generated at 2022-06-18 07:43:03.102186
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()

    # Create a file in the temporary directory
    file = os.path.join(tmpdir2, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a command
    command = 'unzip -d {} {}'.format(tmpdir2, zip_file)

    # Test the side effect


# Generated at 2022-06-18 07:43:11.113709
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2', '', ''))
    assert match(Command('unzip file file2.zip', '', ''))
    assert match(Command('unzip file file2', '', ''))
    assert match(Command('unzip -a file.zip', '', ''))
    assert match(Command('unzip -a file', '', ''))
    assert match(Command('unzip -a file.zip file2.zip', '', ''))
    assert match(Command('unzip -a file.zip file2', '', ''))

# Generated at 2022-06-18 07:43:36.105602
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # create a file in the temporary directory
    test_file = os.path.join(tmpdir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')
    # create a zip file with the test file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.write(test_file, 'test_file')

    # create a command object
    class Command(object):
        def __init__(self, script):
            self.script = script
            self.script_parts = script.split()

    # test that

# Generated at 2022-06-18 07:43:43.540487
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -x file3.zip file4.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -x file3.zip file4.zip -x file5.zip', '', ''))

# Generated at 2022-06-18 07:43:51.996463
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file file2', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file file2', '', ''))


# Generated at 2022-06-18 07:44:02.002677
# Unit test for function side_effect
def test_side_effect():
    import os
    import tempfile
    import zipfile
    from thefuck.shells import shell

    with tempfile.TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        with open('file1', 'w') as f:
            f.write('test')
        with open('file2', 'w') as f:
            f.write('test')
        with open('file3', 'w') as f:
            f.write('test')
        os.mkdir('dir1')
        with open('dir1/file4', 'w') as f:
            f.write('test')
        with open('dir1/file5', 'w') as f:
            f.write('test')
        os.mkdir('dir2')

# Generated at 2022-06-18 07:44:12.184310
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip file3.zip', '', ''))
    assert match(Command('unzip file.zip -d dir', '', ''))
    assert match(Command('unzip file.zip -d dir file2.zip', '', ''))
    assert match(Command('unzip file.zip -d dir file2.zip file3.zip', '', ''))
    assert not match(Command('unzip -d dir file.zip', '', ''))
    assert not match(Command('unzip -d dir file.zip file2.zip', '', ''))

# Generated at 2022-06-18 07:44:19.337276
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))

# Generated at 2022-06-18 07:44:30.836399
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Create a command

# Generated at 2022-06-18 07:44:42.519165
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file file2', '', ''))
    assert not match(Command('unzip -d file file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))

# Generated at 2022-06-18 07:44:48.197056
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    try:
        os.chdir(tmpdir)
        with open('test.txt', 'w') as f:
            f.write('test')
        with zipfile.ZipFile('test.zip', 'w') as z:
            z.write('test.txt')
        side_effect(None, None)
        assert not os.path.isfile('test.txt')
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 07:44:57.753023
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    def _create_zip(zip_file, files):
        with zipfile.ZipFile(zip_file, 'w') as archive:
            for file in files:
                archive.write(file)

    def _create_file(file):
        with open(file, 'w') as f:
            f.write('test')

    def _test_side_effect(files, expected_files):
        with tempfile.TemporaryDirectory() as tmp_dir:
            zip_file = os.path.join(tmp_dir, 'test.zip')
            _create_zip(zip_file, files)
            old_cmd = Command('unzip {}'.format(zip_file), '', '')
            side_effect(old_cmd, Command('', '', ''))

# Generated at 2022-06-18 07:45:23.263815
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary zip file
    tmpzip = tempfile.NamedTemporaryFile(suffix='.zip', delete=False)
    tmpzip.close()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile.close()
    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)
    # Create a temporary file in the temporary directory
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir2, delete=False)
    tmpfile2.close()
    # Create a temporary file

# Generated at 2022-06-18 07:45:33.105717
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert not match(Command('unzip -d file.zip', ''))
    assert not match(Command('unzip -d file.zip', ''))
    assert not match(Command('unzip -d file.zip', ''))
    assert not match(Command('unzip -d file.zip', ''))
    assert not match(Command('unzip -d file.zip', ''))
    assert not match(Command('unzip -d file.zip', ''))
    assert not match(Command('unzip -d file.zip', ''))
    assert not match(Command('unzip -d file.zip', ''))
    assert not match(Command('unzip -d file.zip', ''))
    assert not match(Command('unzip -d file.zip', ''))
    assert not match

# Generated at 2022-06-18 07:45:42.509578
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file1 file2', '', ''))
    assert not match(Command('unzip -d file file1 file2 file.zip', '', ''))
    assert not match(Command('unzip -d file file1 file2 file', '', ''))

# Generated at 2022-06-18 07:45:51.701528
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test_file', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test_file')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test_dir')
    os.mkdir(dir)

    # Create a file in the directory

# Generated at 2022-06-18 07:45:56.390959
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))


# Generated at 2022-06-18 07:46:03.787894
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert not match(Command('unzip file.zip -d file', '', ''))
    assert not match(Command('unzip file.zip file', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d file', '', ''))
    assert not match(Command('unzip file.zip -d file1 file2', '', ''))
    assert not match(Command('unzip file.zip -d file1 file2 -d file', '', ''))
    assert not match

# Generated at 2022-06-18 07:46:12.340267
# Unit test for function side_effect
def test_side_effect():
    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir)
    # Create a temporary zip file
    tmp_zip = tempfile.NamedTemporaryFile(suffix='.zip', dir=tmp_dir)
    # Add the temporary file to the zip file
    with zipfile.ZipFile(tmp_zip.name, 'w') as archive:
        archive.write(tmp_file.name, os.path.basename(tmp_file.name))
    # Change the current directory to the temporary directory
    old_cwd = os.getcwd()
    os.chdir(tmp_dir)
    # Create the command

# Generated at 2022-06-18 07:46:22.575346
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.shells import get_shell
    from thefuck.main import create_alias
    from thefuck.rules.unzip_single_file import side_effect
    import os
    import zipfile
    import shutil
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)
    # Create a temporary file
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir2, delete=False)
    # Create a temporary zip file

# Generated at 2022-06-18 07:46:34.251595
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip file3.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip file3.zip file4.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip file3.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip file3.zip file4.zip', '', ''))

# Generated at 2022-06-18 07:46:43.146414
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file1 file2', '', ''))
    assert not match(Command('unzip -d file file1 file2 file3', '', ''))

# Generated at 2022-06-18 07:47:23.946792
# Unit test for function match
def test_match():
    assert not match(Command('unzip', 'unzip -d test.zip'))
    assert match(Command('unzip', 'unzip test.zip'))
    assert match(Command('unzip', 'unzip test'))
    assert not match(Command('unzip', 'unzip test.zip test2.zip'))
    assert not match(Command('unzip', 'unzip test.zip test2'))
    assert not match(Command('unzip', 'unzip test test2'))
    assert not match(Command('unzip', 'unzip test.zip test2.zip test3'))
    assert not match(Command('unzip', 'unzip test.zip test2.zip test3.zip'))
    assert not match(Command('unzip', 'unzip test.zip test2.zip test3.zip test4'))


# Generated at 2022-06-18 07:47:33.973629
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert match(Command('unzip file.zip file', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip file.zip -x file1 file2', '', ''))
    assert match(Command('unzip file.zip -x file1 file2 file3', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 file3 -d', '', ''))

# Generated at 2022-06-18 07:47:38.819826
# Unit test for function side_effect
def test_side_effect():
    # create a zip file with a file inside
    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.writestr('test.txt', 'test')

    # create a file with the same name as the one inside the zip file
    with open('test.txt', 'w') as f:
        f.write('test')

    # run the side effect
    side_effect(None, None)

    # check that the file has been removed
    assert not os.path.isfile('test.txt')

    # remove the zip file
    os.remove('test.zip')

# Generated at 2022-06-18 07:47:47.777680
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', '')) == False
    assert match(Command('unzip -d file.zip', '', '')) == False
    assert match(Command('unzip file.zip file', '', '')) == False
    assert match(Command('unzip file.zip file1 file2', '', '')) == False
    assert match(Command('unzip file.zip file1 file2 -x file3', '', '')) == False
    assert match(Command('unzip file.zip file1 file2 -x file3 file4', '', '')) == False
    assert match(Command('unzip file.zip file1 file2 -x file3 file4 file5', '', '')) == False

# Generated at 2022-06-18 07:47:57.322682
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile.close()
    # Create a temporary zip file
    tmpzip = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpzip.close()
    with zipfile.ZipFile(tmpzip.name, 'w') as archive:
        archive.write(tmpfile.name, os.path.basename(tmpfile.name))

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()
    # Create a temporary file

# Generated at 2022-06-18 07:48:05.742119
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import subprocess
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Create a subprocess

# Generated at 2022-06-18 07:48:12.069185
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file1 file2', '', ''))
    assert not match(Command('unzip -d file file1 file2 file3', '', ''))

# Generated at 2022-06-18 07:48:22.549930
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells
    from thefuck.types import Command

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    archive = zipfile.ZipFile(os.path.join(tmpdir, 'test.zip'), 'w')
    archive.writestr('test.txt', 'test')
    archive.close()

    # Create a file
    open(os.path.join(tmpdir, 'test.txt'), 'w').close()

    # Create a directory
    os.mkdir(os.path.join(tmpdir, 'test'))

    # Create a command
    command = Command('unzip test.zip', '', tmpdir)

    # Test side_effect
    side_effect

# Generated at 2022-06-18 07:48:33.696400
# Unit test for function side_effect
def test_side_effect():
    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temporary zip file
    tmp_zip = tempfile.NamedTemporaryFile(suffix='.zip', delete=False)
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)

    # Create a zip archive containing the temporary file
    with zipfile.ZipFile(tmp_zip.name, 'w') as archive:
        archive.write(tmp_file.name, os.path.basename(tmp_file.name))

    # Test side_effect
    side_effect(Command('unzip {}'.format(tmp_zip.name), '', ''),
                Command('unzip {}'.format(tmp_zip.name), '', ''))

    # Check that the temporary

# Generated at 2022-06-18 07:48:42.267916
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip file.zip -x file1 file2', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir file1 file2', '', ''))
    assert not match(Command('unzip file.zip -d dir -x file1 file2', '', ''))
    assert not match(Command('unzip file.zip -d dir -x file1 file2', '', ''))
    assert not match(Command('unzip file.zip -d dir -x file1 file2', '', ''))

# Generated at 2022-06-18 07:49:52.325461
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    from thefuck.shells import shell
    from thefuck.types import Command

    temp_dir = tempfile.mkdtemp()