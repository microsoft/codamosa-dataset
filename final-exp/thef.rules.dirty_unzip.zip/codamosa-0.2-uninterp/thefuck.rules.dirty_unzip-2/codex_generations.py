

# Generated at 2022-06-18 07:40:05.653461
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))

# Generated at 2022-06-18 07:40:14.762012
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import subprocess

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # create a temporary zip file
    tmpzip = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpzip.close()
    # create a temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)

    # create a zip file with a file and a directory
    with zipfile.ZipFile(tmpzip.name, 'w') as archive:
        archive.write(tmpfile.name, os.path.basename(tmpfile.name))

# Generated at 2022-06-18 07:40:25.120745
# Unit test for function side_effect
def test_side_effect():
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a zip file
    with zipfile.ZipFile(tmpfile.name, 'w') as archive:
        archive.write(tmpfile.name)
    # Change the current directory
    os.chdir(tmpdir)
    # Run the side effect
    side_effect(Command('unzip ' + tmpfile.name, '', ''),
                Command('unzip ' + tmpfile.name + ' -d ' + tmpdir, '', ''))
    # Check that the file has been removed
    assert not os.path.isfile(tmpfile.name)

# Generated at 2022-06-18 07:40:34.923104
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert match(Command('unzip file', '', ''))
    assert match(Command('unzip file.zip file', '', ''))
    assert match(Command('unzip file.zip file -x file', '', ''))
    assert not match(Command('unzip file.zip file -d file', '', ''))
    assert not match(Command('unzip file.zip file -d', '', ''))
    assert not match(Command('unzip file.zip file -d file -x file', '', ''))

# Generated at 2022-06-18 07:40:44.827051
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip file3.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip file3.zip file4.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip file3.zip file4.zip file5.zip', '', ''))

# Generated at 2022-06-18 07:40:51.806470
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip -a file.zip', '', ''))
    assert match(Command('unzip -a file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d dir file.zip', '', ''))
    assert not match(Command('unzip -d dir file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d dir -a file.zip', '', ''))
    assert not match(Command('unzip -d dir -a file.zip file1 file2', '', ''))

# Generated at 2022-06-18 07:41:00.995606
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert match(Command('unzip file.zip file', '', ''))
    assert match(Command('unzip file file.zip', '', ''))
    assert match(Command('unzip -a file.zip', '', ''))
    assert match(Command('unzip -a file', '', ''))
    assert match(Command('unzip -a file.zip file', '', ''))
    assert match(Command('unzip -a file file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))

# Generated at 2022-06-18 07:41:11.177401
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells.shell

    tmp_dir = tempfile.mkdtemp()
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)
    tmp_file.close()
    tmp_file_name = tmp_file.name
    tmp_file_name_2 = tmp_file_name + '_2'
    tmp_file_name_3 = tmp_file_name + '_3'
    tmp_file_name_4 = tmp_file_name + '_4'
    tmp_file_name_5 = tmp_file_name + '_5'
    tmp_file_name_6 = tmp_file_name + '_6'
    tmp_file_name_7 = tmp_

# Generated at 2022-06-18 07:41:21.873018
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.shells import get_shell
    from thefuck.main import create_alias
    from thefuck.rules.unzip_single_file import side_effect
    from thefuck.rules.unzip_single_file import get_new_command
    from thefuck.rules.unzip_single_file import match
    from thefuck.rules.unzip_single_file import _zip_file
    from thefuck.rules.unzip_single_file import _is_bad_zip
    from thefuck.rules.unzip_single_file import requires_output

    # Create a temporary directory
    import tempfile
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    # Create a zip file
    import zipfile

# Generated at 2022-06-18 07:41:30.891228
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip file.txt -x file.txt', '', ''))

# Generated at 2022-06-18 07:41:43.653896
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file.txt', '', ''))
    assert match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip -d file.txt', '', ''))
    assert not match(Command('unzip file.zip -d file.txt', '', ''))
    assert not match(Command('unzip file.zip -d file.txt', '', ''))
    assert not match(Command('unzip file.zip -d file.txt', '', ''))
    assert not match(Command('unzip file.zip -d file.txt', '', ''))
    assert not match(Command('unzip file.zip -d file.txt', '', ''))

# Generated at 2022-06-18 07:41:53.846306
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file_to_remove = os.path.join(tmpdir, 'test.txt')
    with open(file_to_remove, 'w') as f:
        f.write('test')

    # Test side_effect
    old_cmd = shell.and_('unzip', zip_file)

# Generated at 2022-06-18 07:42:03.941054
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))

# Generated at 2022-06-18 07:42:12.860950
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip file.zip -x file1 file2', '', ''))
    assert match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))

# Generated at 2022-06-18 07:42:23.229990
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip file.zip file1 file2 -x file3', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir file1 file2', '', ''))
    assert not match(Command('unzip file.zip -d dir file1 file2 -x file3', '', ''))
    assert not match(Command('unzip file.zip -d dir file1 file2 -x file3', '', ''))
    assert not match(Command('unzip file.zip -d dir file1 file2 -x file3', '', ''))

# Generated at 2022-06-18 07:42:28.477159
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.shells import get_shell

    old_cmd = Command('unzip file.zip', '', '')
    command = Command('unzip -d file file.zip', '', '')
    side_effect(old_cmd, command)
    shell = get_shell()
    assert shell.run(shell.and_('rm file.zip', 'ls file')).stdout == ''

# Generated at 2022-06-18 07:42:38.347069
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip file', '', ''))
    assert not match(Command('unzip file.zip file -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2 file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 file3 -d dir', '', ''))

# Generated at 2022-06-18 07:42:48.923338
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Create a file in the directory

# Generated at 2022-06-18 07:42:59.802825
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip file', '', ''))
    assert not match(Command('unzip file.zip file -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip file1 file2 file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 file3 -d dir', '', ''))

# Generated at 2022-06-18 07:43:09.001275
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:43:29.374929
# Unit test for function side_effect
def test_side_effect():
    # create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir)
    # create a zip file
    zip_file = tempfile.NamedTemporaryFile(dir=tmp_dir, suffix='.zip')
    with zipfile.ZipFile(zip_file.name, 'w') as archive:
        archive.write(tmp_file.name, os.path.basename(tmp_file.name))
    # create a command
    command = Command(script='unzip {}'.format(zip_file.name),
                      stdout='', stderr='')
    # run the side effect
    side_effect(command, command)
    # check that the file has been removed

# Generated at 2022-06-18 07:43:34.306623
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command('unzip test.zip', '', '')
    command = Command('unzip -d test test.zip', '', '')
    side_effect(old_cmd, command)
    assert os.path.isfile('test/test.txt')
    os.remove('test/test.txt')
    os.rmdir('test')

# Generated at 2022-06-18 07:43:39.643015
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file file2', '', ''))
    assert not match(Command('unzip -d file file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))


# Generated at 2022-06-18 07:43:49.181283
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    try:
        os.chdir(temp_dir)
        with open('test.txt', 'w') as f:
            f.write('test')
        with open('test2.txt', 'w') as f:
            f.write('test')
        with zipfile.ZipFile('test.zip', 'w') as z:
            z.write('test.txt')
        side_effect(None, None)
        assert os.path.isfile('test.txt') == False
        assert os.path.isfile('test2.txt') == True
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:43:59.758649
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
        archive.writestr('test2.txt', 'test')

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()

    # Create a file in the temporary directory
    file = os.path.join(tmpdir2, 'test.txt')
    open(file, 'a').close()

    # Create a command

# Generated at 2022-06-18 07:44:09.959504
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))

# Generated at 2022-06-18 07:44:18.066716
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary zipfile
    tmpzip = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpzip.close()
    with zipfile.ZipFile(tmpzip.name, 'w') as archive:
        archive.write(tmpfile.name)

    # Test side_effect
    side_effect(None, None)
    assert os.path.exists(tmpfile.name)
    side_effect(None, None)
    assert os.path.exists(tmpfile.name)

    # Clean up


# Generated at 2022-06-18 07:44:29.269492
# Unit test for function side_effect
def test_side_effect():
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a zip file
    with zipfile.ZipFile(tmpfile.name, 'w') as archive:
        archive.writestr('test', 'test')
    # Create a directory
    os.mkdir(os.path.join(tmpdir, 'test'))
    # Create a file in the directory
    open(os.path.join(tmpdir, 'test', 'test'), 'w').close()
    # Create a file in the parent directory
    open(os.path.join(tmpdir, 'test2'), 'w').close()
    # Run the side effect

# Generated at 2022-06-18 07:44:40.064800
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells.bash as bash

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Create a command
    old_cmd = bash

# Generated at 2022-06-18 07:44:48.041667
# Unit test for function match
def test_match():
    assert match(Command('unzip foo.zip', '', ''))
    assert match(Command('unzip foo.zip bar', '', ''))
    assert match(Command('unzip foo', '', ''))
    assert not match(Command('unzip -d foo foo.zip', '', ''))
    assert not match(Command('unzip -d foo foo', '', ''))
    assert not match(Command('unzip -d foo', '', ''))
    assert not match(Command('unzip -d', '', ''))
    assert not match(Command('unzip', '', ''))
    assert not match(Command('unzip -d foo bar', '', ''))
    assert not match(Command('unzip -d foo bar.zip', '', ''))

# Generated at 2022-06-18 07:45:15.100153
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import random
    import string

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Create a temporary directory
    temp_dir2 = tempfile.mkdtemp(dir=temp_dir)

    # Create a temporary file
    temp_file2 = tempfile.NamedTemporaryFile(dir=temp_dir2, delete=False)
    temp_file2.close()

    # Create a temporary file
    temp_file3 = tempfile.NamedTemporaryFile(dir=temp_dir2, delete=False)
    temp_file3.close()

# Generated at 2022-06-18 07:45:25.265311
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'file')
    tmp_zip = os.path.join(tmp_dir, 'file.zip')
    with open(tmp_file, 'w') as f:
        f.write('test')
    with zipfile.ZipFile(tmp_zip, 'w') as archive:
        archive.write(tmp_file)

    old_cmd = shell.and_('unzip', tmp_zip)
    command = shell.and_('unzip', tmp_zip, '-d', tmp_dir)
    side_effect(old_cmd, command)

# Generated at 2022-06-18 07:45:35.749120
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    archive = zipfile.ZipFile(os.path.join(tmpdir, 'archive.zip'), 'w')
    archive.writestr('file1.txt', 'file1')
    archive.writestr('file2.txt', 'file2')
    archive.close()

    # Create a file
    open(os.path.join(tmpdir, 'file1.txt'), 'w').write('file1')

    # Create a directory
    os.mkdir(os.path.join(tmpdir, 'dir1'))

    # Create a file in the directory

# Generated at 2022-06-18 07:45:43.968793
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2', '', ''))
    assert not match(Command('unzip file', '', ''))
    assert not match(Command('unzip file1 file2', '', ''))
    assert not match(Command('unzip file1 file2 file3', '', ''))

# Generated at 2022-06-18 07:45:53.429726
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))

# Generated at 2022-06-18 07:46:02.433837
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))

# Generated at 2022-06-18 07:46:10.870643
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2', '', ''))
    assert match(Command('unzip file file2.zip', '', ''))
    assert match(Command('unzip file file2', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2', '', ''))

# Generated at 2022-06-18 07:46:21.166186
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip file.zip file.zip', '', ''))
    assert not match(Command('unzip file file', '', ''))
    assert not match(Command('unzip -d file.zip file.zip file.zip', '', ''))
    assert not match(Command('unzip -d file file file', '', ''))

# Generated at 2022-06-18 07:46:32.664398
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    from thefuck.shells import shell
    from thefuck.types import Command

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Create a command
    command = Command

# Generated at 2022-06-18 07:46:40.825948
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)
    # Create a temporary file
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir2)
    # Create a temporary file
    tmpfile3 = tempfile.NamedTemporaryFile(dir=tmpdir2)
    # Create a temporary file
    tmpfile4 = tempfile.NamedTemporaryFile(dir=tmpdir2)
    # Create a temporary file
    tmpfile5 = tempfile.NamedTemporaryFile(dir=tmpdir2)
    # Create

# Generated at 2022-06-18 07:47:28.482932
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip file3.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip file3.zip file4.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip file3.zip file4.zip file5.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip file3.zip file4.zip file5.zip file6.zip', '', ''))

# Generated at 2022-06-18 07:47:37.090426
# Unit test for function side_effect
def test_side_effect():
    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temporary zip file
    tmp_zip = tempfile.NamedTemporaryFile(suffix='.zip')
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir)
    # Create a temporary directory
    tmp_dir2 = tempfile.mkdtemp(dir=tmp_dir)
    # Create a temporary file in the temporary directory
    tmp_file2 = tempfile.NamedTemporaryFile(dir=tmp_dir2)
    # Create a temporary file in the temporary directory
    tmp_file3 = tempfile.NamedTemporaryFile(dir=tmp_dir2)
    # Create a temporary file in the temporary directory

# Generated at 2022-06-18 07:47:44.593836
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a temporary zip file
    tmpzip = tempfile.NamedTemporaryFile(dir=tmpdir)
    with zipfile.ZipFile(tmpzip.name, 'w') as archive:
        archive.write(tmpfile.name)

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir2)

    # Create a temporary zip file
    tmpzip2 = tempfile.NamedTemporaryFile(dir=tmpdir2)

# Generated at 2022-06-18 07:47:54.981369
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a temporary file
    tmpfile = os.path.join(tmpdir, 'test.txt')
    with open(tmpfile, 'w') as f:
        f.write('test')

    # Test side_effect
    old_cmd = type('', (), {'script': 'unzip {}'.format(zip_file),
                            'script_parts': ['unzip', zip_file]})

# Generated at 2022-06-18 07:48:01.812407
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert not match(Command('unzip file.zip -d file', '', ''))
    assert not match(Command('unzip file.zip file -d', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d file3 file4', '', ''))

# Generated at 2022-06-18 07:48:09.780778
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    with tempfile.TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        with open('test.txt', 'w') as f:
            f.write('test')
        with open('test2.txt', 'w') as f:
            f.write('test')
        with open('test3.txt', 'w') as f:
            f.write('test')
        with open('test4.txt', 'w') as f:
            f.write('test')
        with open('test5.txt', 'w') as f:
            f.write('test')
        os.mkdir('test_dir')

# Generated at 2022-06-18 07:48:19.208454
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile.close()
    # Create a temporary zip file
    tmpzip = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpzip.close()
    with zipfile.ZipFile(tmpzip.name, 'w') as archive:
        archive.write(tmpfile.name)
    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)
    # Create a temporary file in the temporary directory
    tmpfile2 = tempfile.N

# Generated at 2022-06-18 07:48:30.414291
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.types import Command

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    test_zip = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(test_zip, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    test_file = os.path.join(tmpdir, 'test.txt')
    with open(test_file, 'w') as f:
        f.write('test')

    # Create a directory
    test_dir = os.path.join(tmpdir, 'test')
    os.mkdir(test_dir)

    # Test side_effect


# Generated at 2022-06-18 07:48:40.199771
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import subprocess
    import sys
    import thefuck.shells
    import thefuck.shells.bash
    import thefuck.shells.zsh
    import thefuck.shells.fish
    import thefuck.shells.tcsh
    import thefuck.shells.xonsh
    import thefuck.shells.powershell
    import thefuck.shells.cmd
    import thefuck.shells.common
    import thefuck.shells.shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')

# Generated at 2022-06-18 07:48:51.539114
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells as shells
    import thefuck.specific.unzip as unzip

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')
    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)
   

# Generated at 2022-06-18 07:49:42.077495
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip file', '', ''))
    assert not match(Command('unzip file.zip file -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d dir -x file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d dir -x file3 file4', '', ''))

# Generated at 2022-06-18 07:49:48.936672
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file with a file and a directory
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
        archive.writestr('test/test.txt', 'test')

    # Create a temporary directory to unzip the file
    tmpdir2 = tempfile.mkdtemp()

    # Change the current directory to the temporary directory
    os.chdir(tmpdir2)

    # Create a file and a directory
    open('test.txt', 'w').close()
    os.mkdir('test')

    # Call the