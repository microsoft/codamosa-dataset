

# Generated at 2022-06-18 07:39:42.732011
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert match(Command('unzip file.zip file2.zip', ''))
    assert match(Command('unzip file.zip file2.zip -x file3.zip', ''))
    assert match(Command('unzip file.zip file2.zip -x file3.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip file2.zip -d dir', ''))
    assert not match(Command('unzip file.zip file2.zip -x file3.zip -d dir', ''))
    assert not match(Command('unzip file.zip file2.zip -x file3.zip -d dir -x file4.zip', ''))

# Generated at 2022-06-18 07:39:50.609608
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert match(Command('unzip file.zip file1', ''))
    assert match(Command('unzip file.zip file1 file2', ''))
    assert match(Command('unzip file.zip file1 file2 -x file3', ''))
    assert match(Command('unzip file.zip -x file1 file2', ''))
    assert match(Command('unzip file.zip -x file1', ''))
    assert match(Command('unzip file.zip -x', ''))
    assert match(Command('unzip file.zip -x file1 file2 -x file3', ''))
    assert match(Command('unzip file.zip -x file1 -x file2', ''))

# Generated at 2022-06-18 07:39:58.121302
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip -x file3.zip', '', ''))


# Generated at 2022-06-18 07:40:09.578983
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert match(Command('unzip file', ''))
    assert not match(Command('unzip -d file.zip', ''))
    assert not match(Command('unzip -d file', ''))
    assert not match(Command('unzip -d file file.zip', ''))
    assert not match(Command('unzip -d file file', ''))
    assert not match(Command('unzip -d file file1 file2', ''))
    assert not match(Command('unzip -d file file1 file2 file.zip', ''))
    assert not match(Command('unzip -d file file1 file2 file', ''))
    assert not match(Command('unzip -d file file1 file2 file.zip file', ''))

# Generated at 2022-06-18 07:40:13.198824
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command('unzip test.zip')
    command = Command('unzip -d test test.zip')
    side_effect(old_cmd, command)
    assert os.path.isfile('test/test.txt')
    os.remove('test/test.txt')
    os.rmdir('test')

# Generated at 2022-06-18 07:40:24.674563
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert match(Command('unzip -a file', '', ''))
    assert match(Command('unzip -a file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))

# Generated at 2022-06-18 07:40:34.562287
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file in the temporary directory
    file_to_remove = os.path.join(tmpdir, 'test.txt')
    with open(file_to_remove, 'w') as f:
        f.write('test')

    # Create a directory in the temporary directory
    dir_to_remove = os.path.join(tmpdir, 'test')
    os.mkdir(dir_to_remove)

    # Create a file

# Generated at 2022-06-18 07:40:40.724188
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.types import Command

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    archive = zipfile.ZipFile(os.path.join(tmpdir, 'archive.zip'), 'w')
    archive.writestr('file1.txt', 'content')
    archive.writestr('file2.txt', 'content')
    archive.close()

    # Create a file
    with open(os.path.join(tmpdir, 'file1.txt'), 'w') as f:
        f.write('content')

    # Create a directory
    os.mkdir(os.path.join(tmpdir, 'dir'))

    # Create a file in the directory

# Generated at 2022-06-18 07:40:49.947096
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file.txt', '', ''))
    assert match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir file.txt', '', ''))
    assert not match(Command('unzip file.zip -d dir file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip -d dir file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip -d dir file.txt -x file.txt', '', ''))

# Generated at 2022-06-18 07:40:59.501791
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))
    assert not match(Command('unzip file.zip -d dir', ''))

# Generated at 2022-06-18 07:41:14.439480
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert not match(Command('unzip file.zip -d folder', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d folder', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d folder', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d folder', '', ''))


# Generated at 2022-06-18 07:41:25.199578
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.rules.unzip_single_file import side_effect
    import tempfile
    import zipfile
    import os

    with tempfile.TemporaryDirectory() as tempdir:
        # Create a zip file with a single file
        zip_file = os.path.join(tempdir, 'test.zip')
        with zipfile.ZipFile(zip_file, 'w') as archive:
            archive.writestr('test.txt', 'test')

        # Create a file in the temporary directory
        file_path = os.path.join(tempdir, 'test.txt')
        with open(file_path, 'w') as f:
            f.write('test')

        # Run the side effect

# Generated at 2022-06-18 07:41:29.424478
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert not match(Command('unzip file.zip -d file', '', ''))
    assert not match(Command('unzip file.zip file', '', ''))
    assert not match(Command('unzip file.zip file -d', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip file1 file2 file3 -d', '', ''))

# Generated at 2022-06-18 07:41:39.203103
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert match(Command('unzip file', ''))
    assert not match(Command('unzip -d file.zip', ''))
    assert not match(Command('unzip -d file', ''))
    assert not match(Command('unzip -d file', ''))
    assert not match(Command('unzip -d file', ''))
    assert not match(Command('unzip -d file', ''))
    assert not match(Command('unzip -d file', ''))
    assert not match(Command('unzip -d file', ''))
    assert not match(Command('unzip -d file', ''))
    assert not match(Command('unzip -d file', ''))
    assert not match(Command('unzip -d file', ''))

# Generated at 2022-06-18 07:41:46.038941
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file in the temporary directory
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test1.txt', 'test1')
        archive.writestr('test2.txt', 'test2')

    # Create a file in the temporary directory
    file = os.path.join(tmpdir, 'test1.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory in the temporary directory
    dir = os.path.join(tmpdir, 'test_dir')

# Generated at 2022-06-18 07:41:56.862908
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file file.zip', '', ''))
    assert not match(Command('unzip -d file file file', '', ''))
    assert not match(Command('unzip -d file file file file.zip', '', ''))

# Generated at 2022-06-18 07:42:06.980086
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3 file4', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3 file4 file5', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3 file4 file5 file6', '', ''))

# Generated at 2022-06-18 07:42:14.875630
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match

# Generated at 2022-06-18 07:42:25.560623
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells as shells

    def _create_zip_file(zip_file_name, file_names):
        with zipfile.ZipFile(zip_file_name, 'w') as archive:
            for file_name in file_names:
                archive.write(file_name)

    def _create_file(file_name):
        with open(file_name, 'w') as f:
            f.write('test')

    def _create_dir(dir_name):
        os.mkdir(dir_name)

    def _create_files_and_dirs(file_names, dir_names):
        for file_name in file_names:
            _create_file(file_name)

# Generated at 2022-06-18 07:42:33.857512
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip file.zip file1 file2 -x file3', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip file -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3 -d dir', '', ''))

# Generated at 2022-06-18 07:42:57.035942
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    from thefuck.types import Command

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:43:06.863948
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary zip file
    tmpzip = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpzip.close()
    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)
    # Create a temporary file
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir2, delete=False)
    tmpfile2.close()

    # Create a zip file

# Generated at 2022-06-18 07:43:14.802682
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip file.zip -x file1 file2', '', ''))
    assert match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir file1 file2', '', ''))
    assert not match(Command('unzip file.zip -d dir -x file1 file2', '', ''))
    assert not match(Command('unzip file.zip -d dir -x file1 file2 -d dir2', '', ''))

# Generated at 2022-06-18 07:43:26.193807
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file.zip file2', '', ''))
    assert not match(Command('unzip -d file file file2.zip', '', ''))
    assert not match(Command('unzip -d file file file2', '', ''))
   

# Generated at 2022-06-18 07:43:36.401141
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells
    import thefuck.specific.unzip

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip archive
    archive = zipfile.ZipFile(os.path.join(tmpdir, 'test.zip'), 'w')
    archive.writestr('test1.txt', 'test1')
    archive.writestr('test2.txt', 'test2')
    archive.close()

    # Create a file
    open(os.path.join(tmpdir, 'test1.txt'), 'w').close()

    # Create a directory
    os.mkdir(os.path.join(tmpdir, 'test2.txt'))

    # Create a command
    command = the

# Generated at 2022-06-18 07:43:43.720573
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells.shell
    from thefuck.shells.shell import And, Or

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
        archive.writestr('test2.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory

# Generated at 2022-06-18 07:43:54.181907
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file with a file in it
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()

    # Create a file in the temporary directory
    file = os.path.join(tmpdir2, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a command
    command = 'unzip {}'.format(zip_file)

    # Call side_effect
    side

# Generated at 2022-06-18 07:43:58.519367
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))


# Generated at 2022-06-18 07:44:08.828928
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file file2', '', ''))
    assert not match(Command('unzip -d file file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2', '', ''))
    assert not match(Command('unzip -d file file2 file3.zip', '', ''))

# Generated at 2022-06-18 07:44:17.251614
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d folder', '', ''))
    assert not match(Command('unzip file.zip -d folder', '', ''))
    assert not match(Command('unzip file.zip -d folder', '', ''))
    assert not match(Command('unzip file.zip -d folder', '', ''))
    assert not match(Command('unzip file.zip -d folder', '', ''))
    assert not match(Command('unzip file.zip -d folder', '', ''))
    assert not match(Command('unzip file.zip -d folder', '', ''))
    assert not match(Command('unzip file.zip -d folder', '', ''))

# Generated at 2022-06-18 07:44:49.144627
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:44:58.863668
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.shells import get_shell
    from thefuck.shells.bash import Bash
    from thefuck.shells.zsh import Zsh
    from thefuck.shells.fish import Fish
    from thefuck.shells.cmd import Cmd
    from thefuck.shells.powershell import Powershell
    from thefuck.shells.xonsh import Xonsh

    # Test for bash
    shell = get_shell(Bash)
    old_cmd = Command('unzip test.zip', '', '', '', '', '')
    command = get_new_command(old_cmd)
    side_effect(old_cmd, command)
    assert shell.and_('test.zip', command) == 'unzip test.zip && {}'.format(command)

    #

# Generated at 2022-06-18 07:45:09.755418
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))

# Generated at 2022-06-18 07:45:17.720367
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import sys
    import thefuck.shells

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
        archive.writestr('test2.txt', 'test')

    # Create a file in the temporary directory
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory in the temporary directory

# Generated at 2022-06-18 07:45:24.400986
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command

    old_cmd = Command('unzip test.zip', 'test.zip:  bad zipfile offset (local header sig):  0')
    command = Command('unzip -d test test.zip', 'test.zip:  bad zipfile offset (local header sig):  0')
    side_effect(old_cmd, command)
    assert os.path.exists('test')

# Generated at 2022-06-18 07:45:34.024545
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file file.zip', '', ''))
    assert not match(Command('unzip -d file file file', '', ''))
    assert not match(Command('unzip -d file file file file.zip', '', ''))

# Generated at 2022-06-18 07:45:43.257336
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
        archive.writestr('test2.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Create a file in the directory
    file_in

# Generated at 2022-06-18 07:45:52.553175
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:46:01.822926
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.specific.unzip as unzip

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Create a file in the directory
    file

# Generated at 2022-06-18 07:46:09.896307
# Unit test for function side_effect
def test_side_effect():
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary zip file
    tmpzip = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpzip.close()
    with zipfile.ZipFile(tmpzip.name, 'w') as archive:
        archive.write(tmpfile.name, os.path.basename(tmpfile.name))
    # Run side_effect
    side_effect(Command('unzip ' + tmpzip.name, ''), Command('unzip ' + tmpzip.name, ''))
    # Check if the file has been removed
    assert not os.path.isfile(tmpfile.name)
    # Remove temporary

# Generated at 2022-06-18 07:47:04.938547
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import shell
    from thefuck.types import Command
    from thefuck.rules.unzip_single_file import side_effect
    from thefuck.rules.unzip_single_file import _zip_file
    import os
    import zipfile
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        with open('test.txt', 'w') as f:
            f.write('test')
        with open('test2.txt', 'w') as f:
            f.write('test')
        with zipfile.ZipFile('test.zip', 'w') as z:
            z.write('test.txt')
        command = Command('unzip test.zip', '', '')
        side_effect(command, command)

# Generated at 2022-06-18 07:47:13.510400
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a directory
    dir_path = os.path.join(tmpdir, 'test')
    os.mkdir(dir_path)

    # Create a file
    file_path = os.path.join(dir_path, 'test.txt')
    with open(file_path, 'w') as f:
        f.write('test')

    # Test side_effect

# Generated at 2022-06-18 07:47:23.244493
# Unit test for function side_effect
def test_side_effect():
    """
    Test side_effect function
    """
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)
    # Create a temporary file
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir2)
    # Create a temporary file
    tmpfile3 = tempfile.NamedTemporaryFile(dir=tmpdir2)

    # Create a zip file
    zip_file = tempfile.NamedTemporaryFile(dir=tmpdir, suffix='.zip')

# Generated at 2022-06-18 07:47:33.357145
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 file3', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 file3 -d dir', '', ''))
    assert not match(Command('unzip file.zip -x file1 file2 file3 file4', '', ''))

# Generated at 2022-06-18 07:47:39.687032
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()

    # Create a file in the temporary directory
    file_path = os.path.join(tmpdir2, 'test.txt')
    with open(file_path, 'w') as f:
        f.write('test')

    # Create a command
    command = 'unzip {}'.format(zip_file)

    # Call side_

# Generated at 2022-06-18 07:47:48.830603
# Unit test for function match
def test_match():
    assert match(Command('unzip foo.zip'))
    assert match(Command('unzip foo.zip bar.zip'))
    assert match(Command('unzip foo.zip bar.zip -x baz.zip'))
    assert not match(Command('unzip -d foo foo.zip'))
    assert not match(Command('unzip -d foo foo.zip bar.zip'))
    assert not match(Command('unzip -d foo foo.zip bar.zip -x baz.zip'))
    assert not match(Command('unzip -d foo foo.zip bar.zip -x baz.zip'))
    assert not match(Command('unzip -d foo foo.zip bar.zip -x baz.zip'))

# Generated at 2022-06-18 07:47:58.551490
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d file file1 file2', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d file file1 file2', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2', '', ''))

# Generated at 2022-06-18 07:48:06.843852
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file', '', ''))

# Generated at 2022-06-18 07:48:15.759690
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file1 file2', '', ''))
    assert not match(Command('unzip -d file file1 file2 file3', '', ''))
    assert not match(Command('unzip -d file file1 file2 file3 file4', '', ''))

# Generated at 2022-06-18 07:48:19.259606
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command

    old_cmd = Command('unzip file.zip', '', '')
    command = Command('unzip -d file file.zip', '', '')
    side_effect(old_cmd, command)