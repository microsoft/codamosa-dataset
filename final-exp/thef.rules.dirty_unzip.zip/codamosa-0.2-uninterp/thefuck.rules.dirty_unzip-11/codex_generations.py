

# Generated at 2022-06-18 07:40:08.189141
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    testzip = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(testzip, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()
    os.chdir(tmpdir2)

    # Create a file in the temporary directory
    testfile = os.path.join(tmpdir2, 'test.txt')
    with open(testfile, 'w') as f:
        f.write('test')

    # Create a command

# Generated at 2022-06-18 07:40:12.573946
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:40:24.573572
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    archive = zipfile.ZipFile(os.path.join(tmpdir, 'test.zip'), 'w')
    archive.writestr('test.txt', 'test')
    archive.close()

    # Create a file
    with open(os.path.join(tmpdir, 'test.txt'), 'w') as f:
        f.write('test')

    # Create a directory
    os.mkdir(os.path.join(tmpdir, 'test'))

    # Create a file in the directory
    with open(os.path.join(tmpdir, 'test', 'test.txt'), 'w') as f:
        f.write

# Generated at 2022-06-18 07:40:34.441220
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Test side_effect
    old_cmd = type('', (), {'script': 'unzip test.zip', 'script_parts': ['unzip', 'test.zip']})

# Generated at 2022-06-18 07:40:40.673162
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:40:49.888801
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip file.zip -d file', '', ''))
    assert not match(Command('unzip file -d file', '', ''))
    assert not match(Command('unzip file.zip file -d file', '', ''))
    assert not match(Command('unzip file file -d file', '', ''))

# Generated at 2022-06-18 07:40:59.466601
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file.zip file2', '', ''))
    assert not match(Command('unzip -d file file file2.zip', '', ''))
    assert not match(Command('unzip -d file file file2', '', ''))
   

# Generated at 2022-06-18 07:41:10.013265
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file.txt', '', ''))
    assert match(Command('unzip file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file.txt', '', ''))
    assert not match(Command('unzip -d file.zip file.txt -x file.txt', '', ''))
    assert not match(Command('unzip file.zip -x file.txt', '', ''))
    assert not match(Command('unzip file.zip -x file.txt -d file.txt', '', ''))

# Generated at 2022-06-18 07:41:20.473270
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)

    # Create a file in the directory
    file_in_

# Generated at 2022-06-18 07:41:29.816673
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip file.zip -x file2.zip', '', ''))
    assert not match(Command('unzip file.zip -x file2.zip -x file3.zip', '', ''))

# Generated at 2022-06-18 07:41:53.340141
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')

    # Test side_effect
    old_cmd = type('Command', (object,), {'script': 'unzip {}'.format(zip_file)})

# Generated at 2022-06-18 07:42:03.467001
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))

# Generated at 2022-06-18 07:42:12.486870
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    import thefuck.shells.shell

    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)
    os.mkdir('test_dir')
    with open('test_file', 'w') as f:
        f.write('test')

    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.write('test_file')
        archive.write('test_dir')

    side_effect(thefuck.shells.shell.And('unzip test.zip', 'unzip test.zip'),
                thefuck.shells.shell.And('unzip test.zip -d test', 'unzip test.zip -d test'))


# Generated at 2022-06-18 07:42:22.373550
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert not match(Command('unzip file.zip -d file', '', ''))
    assert not match(Command('unzip file.zip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d file.zip file', '', ''))
    assert not match(Command('unzip file.zip -d file.zip file.zip', '', ''))
    assert not match(Command('unzip file.zip -d file.zip file.zip file', '', ''))

# Generated at 2022-06-18 07:42:31.056519
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file1 file2', '', ''))
    assert not match(Command('unzip -d file file1 file2 file3', '', ''))

# Generated at 2022-06-18 07:42:40.760093
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip file3.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip -d', '', ''))
    assert not match(Command('unzip file.zip -d file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -d', '', ''))
    assert not match(Command('unzip file.zip file2.zip -d file3.zip', '', ''))

# Generated at 2022-06-18 07:42:48.592964
# Unit test for function side_effect
def test_side_effect():
    import os
    import tempfile
    import zipfile
    from thefuck.types import Command

    with tempfile.TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        with open('file', 'w') as f:
            f.write('content')

        with zipfile.ZipFile('file.zip', 'w') as z:
            z.write('file')

        side_effect(Command('unzip file.zip', '', ''), Command('unzip file.zip', '', ''))
        assert not os.path.exists('file')

# Generated at 2022-06-18 07:42:59.502105
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a zipfile
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')
    # Create a file
    file = os.path.join(tmpdir, 'test.txt')
    with open(file, 'w') as f:
        f.write('test')
    # Create a directory
    dir = os.path.join(tmpdir, 'test')
    os.mkdir(dir)
    # Create a file in the directory
    file_in_

# Generated at 2022-06-18 07:43:08.754639
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells import shell

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:43:18.024892
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    import zipfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    archive = zipfile.ZipFile(os.path.join(tmpdir, 'test.zip'), 'w')
    archive.writestr('test.txt', 'test')
    archive.close()

    # Create a file
    open(os.path.join(tmpdir, 'test.txt'), 'w').close()

    # Create a directory
    os.mkdir(os.path.join(tmpdir, 'test'))

    # Create a file in the directory
    open(os.path.join(tmpdir, 'test', 'test.txt'), 'w').close()

    # Create a subdirectory

# Generated at 2022-06-18 07:43:55.625291
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip file.zip file', '', ''))
    assert not match(Command('unzip file file', '', ''))
    assert not match(Command('unzip file.zip file -x file', '', ''))
    assert not match(Command('unzip file file -x file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file', '', ''))

# Generated at 2022-06-18 07:44:05.373381
# Unit test for function match
def test_match():
    # unzip -d
    assert not match(Command('unzip -d', ''))
    # unzip -d file.zip
    assert not match(Command('unzip -d file.zip', ''))
    # unzip file.zip
    assert match(Command('unzip file.zip', ''))
    # unzip file.zip file2.zip
    assert match(Command('unzip file.zip file2.zip', ''))
    # unzip file.zip file2.zip -x file3.zip
    assert match(Command('unzip file.zip file2.zip -x file3.zip', ''))
    # unzip file.zip -x file3.zip
    assert match(Command('unzip file.zip -x file3.zip', ''))
    # unzip -x file3.zip file.zip
    assert match

# Generated at 2022-06-18 07:44:09.688743
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command('unzip test.zip', '', '')
    command = Command('unzip -d test test.zip', '', '')
    side_effect(old_cmd, command)
    assert os.path.isfile('test/test.txt')

# Generated at 2022-06-18 07:44:17.874884
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert not match(Command('unzip -d file.zip', ''))
    assert not match(Command('unzip file.zip -d', ''))
    assert not match(Command('unzip -d file.zip -d', ''))
    assert not match(Command('unzip file.zip -d file.zip', ''))
    assert not match(Command('unzip -d file.zip -d file.zip', ''))
    assert not match(Command('unzip file.zip -d file.zip -d', ''))
    assert not match(Command('unzip -d file.zip -d file.zip -d', ''))
    assert not match(Command('unzip file.zip -d file.zip -d file.zip', ''))

# Generated at 2022-06-18 07:44:29.020234
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip -a file.zip', '', ''))
    assert match(Command('unzip -a file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2', '', ''))
    assert not match(Command('unzip -d file.zip file1 file2', '', ''))

# Generated at 2022-06-18 07:44:39.498593
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import get_shell
    from thefuck.types import Command
    from thefuck.rules.unzip_single_file import side_effect
    import os
    import zipfile

    # Create a zip file with a single file
    zip_file = 'test.zip'
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a file with the same name as the file in the zip file
    file = 'test.txt'
    with open(file, 'w') as f:
        f.write('test')

    # Create a directory with the same name as the file in the zip file
    dir = 'test.txt'
    os.mkdir(dir)

    # Create a file with the same name as the directory in

# Generated at 2022-06-18 07:44:49.007123
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))


# Generated at 2022-06-18 07:44:58.710058
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip file.zip file1 file2 -x file3', '', ''))
    assert match(Command('unzip file.zip -x file3', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir file1 file2', '', ''))
    assert not match(Command('unzip file.zip -d dir file1 file2 -x file3', '', ''))
    assert not match(Command('unzip file.zip -d dir -x file3', '', ''))
    assert not match(Command('unzip', '', ''))


# Generated at 2022-06-18 07:45:09.680485
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file file2', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file file2', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file file2', '', ''))
   

# Generated at 2022-06-18 07:45:17.614247
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    test_zip = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(test_zip, 'w') as archive:
        archive.writestr('test.txt', 'test')
        archive.writestr('test2.txt', 'test2')

    # Create a file in the temporary directory
    test_file = os.path.join(tmpdir, 'test.txt')
    with open(test_file, 'w') as f:
        f.write('test')

    # Create a directory in the temporary directory
    test_dir = os.path.join(tmpdir, 'test_dir')
    os.mkdir

# Generated at 2022-06-18 07:46:20.700027
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip -x file3.zip', '', ''))
    assert not match(Command('unzip file.zip -x file2.zip', '', ''))
    assert not match(Command('unzip file.zip -x file2.zip file3.zip', '', ''))
    assert not match(Command('unzip file.zip -x file2.zip file3.zip file4.zip', '', ''))

# Generated at 2022-06-18 07:46:32.195878
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a zip file
    zip_file = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a script
    script = 'unzip {}'.format(zip_file)

    # Create a command
    command = type('', (), {'script': script})

    # Call side_effect
    side_effect(command, command)

    # Check that the file has been removed
    assert not os.path.exists(os.path.join(tmpdir, 'test.txt'))

    # Remove the temporary directory

# Generated at 2022-06-18 07:46:40.562771
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import zipfile
    import os
    import shutil
    from thefuck.types import Command

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a test zip file
    test_zip = os.path.join(tmpdir, 'test.zip')
    with zipfile.ZipFile(test_zip, 'w') as archive:
        archive.writestr('test.txt', 'test')

    # Create a test file
    test_file = os.path.join(tmpdir, 'test.txt')
    with open(test_file, 'w') as f:
        f.write('test')

    # Create a test directory
    test_dir = os.path.join(tmpdir, 'test_dir')
    os.mkdir(test_dir)

    #

# Generated at 2022-06-18 07:46:50.778996
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file file2', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file file2', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip file3.zip', '', ''))

# Generated at 2022-06-18 07:47:01.261623
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', '', ''))
    assert not match(Command('unzip -d test.zip', '', ''))
    assert not match(Command('unzip test.zip -d test', '', ''))
    assert not match(Command('unzip test.zip test', '', ''))
    assert not match(Command('unzip test.zip test1 test2', '', ''))
    assert not match(Command('unzip -d test.zip test1 test2', '', ''))
    assert not match(Command('unzip -d test.zip test1 test2', '', ''))
    assert not match(Command('unzip test.zip test1 test2 -d test', '', ''))
    assert not match(Command('unzip test.zip test1 test2 -d test', '', ''))

# Generated at 2022-06-18 07:47:08.390520
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', '', ''))
    assert match(Command('unzip test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))

# Generated at 2022-06-18 07:47:14.144949
# Unit test for function side_effect
def test_side_effect():
    # Create a test zip file
    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.writestr('test', 'test')
    # Create a test file
    with open('test', 'w') as f:
        f.write('test')
    # Run side_effect
    side_effect(None, None)
    # Check that the test file has been removed
    assert not os.path.isfile('test')
    # Cleanup
    os.remove('test.zip')

# Generated at 2022-06-18 07:47:23.902304
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip -d file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2', '', ''))
    assert not match(Command('unzip -d file.zip file2', '', ''))
    assert not match(Command('unzip file.zip file2.zip file3', '', ''))

# Generated at 2022-06-18 07:47:33.933631
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', '', ''))
    assert not match(Command('unzip -d test.zip', '', ''))
    assert not match(Command('unzip -d test', '', ''))
    assert not match(Command('unzip -d test.zip test.zip', '', ''))
    assert not match(Command('unzip -d test.zip test', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test', '', ''))
    assert not match(Command('unzip -d test test.zip test', '', ''))
    assert not match(Command('unzip -d test test test.zip', '', ''))

# Generated at 2022-06-18 07:47:40.371320
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file1 file2', '', ''))
    assert match(Command('unzip file.zip file1 file2 -x file3', '', ''))
    assert match(Command('unzip file.zip file1 file2 -x file3 -d dir', '', ''))
    assert not match(Command('unzip file.zip -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3 -d dir', '', ''))
    assert not match(Command('unzip file.zip file1 file2 -x file3 -d dir -x file4', '', ''))


# Generated at 2022-06-18 07:49:36.583758
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip'))
    assert match(Command('unzip file.zip file'))
    assert match(Command('unzip file.zip file -x file'))
    assert match(Command('unzip file.zip -x file'))
    assert match(Command('unzip file -x file'))
    assert not match(Command('unzip -d dir file.zip'))
    assert not match(Command('unzip -d dir file'))
    assert not match(Command('unzip -d dir file -x file'))
    assert not match(Command('unzip -d dir file.zip -x file'))
    assert not match(Command('unzip -d dir -x file'))
    assert not match(Command('unzip -d dir -x file file.zip'))

# Generated at 2022-06-18 07:49:45.780996
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d file.zip file', '', ''))
    assert not match(Command('unzip -d file file.zip', '', ''))
    assert not match(Command('unzip -d file file', '', ''))
    assert not match(Command('unzip -d file file.zip file2', '', ''))
    assert not match(Command('unzip -d file file file2.zip', '', ''))
    assert not match(Command('unzip -d file file file2', '', ''))
   

# Generated at 2022-06-18 07:49:51.892797
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    try:
        os.chdir(temp_dir)
        os.mkdir('test')
        with open('test/test.txt', 'w') as f:
            f.write('test')
        with zipfile.ZipFile('test.zip', 'w') as archive:
            archive.write('test/test.txt')
        side_effect(None, None)
        assert not os.path.exists('test/test.txt')
    finally:
        shutil.rmtree(temp_dir)