

# Generated at 2022-06-24 06:14:25.858649
# Unit test for function get_new_command
def test_get_new_command():
    script = 'unzip my_zipfile.zip'
    command = Command(script)
    assert get_new_command(command) == 'unzip -d my_zipfile my_zipfile.zip'



# Generated at 2022-06-24 06:14:36.760796
# Unit test for function side_effect
def test_side_effect():
    os.mkdir('test')
    with open('test/foo', 'w') as f:
        f.write('foo')
    with open('test/bar', 'w') as f:
        f.write('bar')
    with open('test/baz', 'w') as f:
        f.write('baz')
    with zipfile.ZipFile('test.zip', 'w') as f:
        f.write('test/foo')
        f.write('test/bar')
        f.write('test/baz')
    side_effect(None, None)
    assert not os.path.isfile('test/foo')
    assert not os.path.isfile('test/bar')
    assert not os.path.isfile('test/baz')
    assert os.path.isdir('test')

# Generated at 2022-06-24 06:14:43.272994
# Unit test for function match
def test_match():
    from thefuck.specific.unzip import match
    old_cwd = os.getcwd()
    try:
        os.chdir('tests/test-data/dir2')
        command = 'unzip -j a.zip'
        assert not match(command)
        command = 'unzip -j a.zip -d dir1'
        assert not match(command)
        command = 'unzip a.zip'
        assert match(command)
    finally:
        os.chdir(old_cwd)


# Generated at 2022-06-24 06:14:49.670226
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', '', ''))
    assert match(Command('unzip test.zip file.txt', '', ''))
    assert not match(Command('unzip -d test.zip', '', ''))
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file.zip file.txt', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))


# Generated at 2022-06-24 06:14:54.326852
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(shell.and_('unzip file.zip', 'tree')) == 'unzip file.zip tree -d file'
    assert get_new_command(shell.and_('unzip file.zip a', 'tree')) == 'unzip file.zip a tree -d file'

# Generated at 2022-06-24 06:15:03.891452
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import shell
    script = 'unzip root.zip'
    old_command = shell.and_('ls', script)
    with zipfile.ZipFile('root.zip', 'w') as archive:
        archive.writestr('root', '')
        archive.writestr('root/a', '')
        archive.writestr('root/a/b', '')
    side_effect(old_command, command)
    assert os.path.exists('root')
    assert os.path.exists('root/a')
    assert os.path.exists('root/a/b')

    shutil.rmtree('root')
    with zipfile.ZipFile('root.zip', 'w') as archive:
        archive.writestr('root', '')
        archive.writestr

# Generated at 2022-06-24 06:15:07.565549
# Unit test for function get_new_command
def test_get_new_command():
    """Tests the function get_new_command for correct output."""
    the_command = Command(script='unzip myfile', stdout=None, stderr=None)
    the_result = get_new_command(the_command)
    assert the_result == 'unzip -d ~'

# Generated at 2022-06-24 06:15:15.083803
# Unit test for function match
def test_match():
    assert _is_bad_zip('tests/resources/zip_files/nested.zip')
    assert _is_bad_zip('tests/resources/zip_files/test.zip')
    assert not _is_bad_zip('tests/resources/zip_files/test')

    assert match(Command('unzip tests/resources/zip_files/test.zip', ''))
    assert match(Command('unzip tests/resources/zip_files/nested.zip', ''))
    assert not match(Command('unzip tests/resources/zip_files/nested.zip -d folder/',''))



# Generated at 2022-06-24 06:15:19.435155
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command(u'unzip file.zip', None)) == \
        u'unzip file.zip -d file'

    assert get_new_command(Command(u'unzip file.zip -a -b', None)) == \
        u'unzip file.zip -a -b -d file'

# Generated at 2022-06-24 06:15:29.029204
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command.Command('unzip test.zip', '', '', 0)).script == 'unzip -d test test.zip'

    # Test for function zip_file with valid parameters
    assert _zip_file(command.Command('unzip test', '', '', 0)) == 'test.zip'
    assert _zip_file(command.Command('unzip -a test', '', '', 0)) == 'test.zip'
    assert _zip_file(command.Command('unzip test.zip', '', '', 0)) == 'test.zip'
    assert _zip_file(command.Command('unzip -a test.zip', '', '', 0)) == 'test.zip'

    # Test for function zip_file with invalid parameters

# Generated at 2022-06-24 06:15:36.461505
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from tempfile import mkdtemp
    from os import chdir
    from os.path import basename
    from shutil import rmtree

    # the side effect is supposed to remove any file that is in the zip file
    # but only those files in the current directory
    dir_name = mkdtemp()
    chdir(dir_name)
    command = 'unzip {}'.format(basename(__file__))
    old_cmd = Command(command, '', '')
    side_effect(old_cmd, command)

    # check that the test file has been removed
    assert not os.path.exists(basename(__file__))

    # check that the directory has not been touched
    assert os.path.exists(dir_name)

    # cleanup

# Generated at 2022-06-24 06:15:39.147501
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('unzip /tmp/test.zip', None)) == 'unzip -d /tmp/test /tmp/test.zip'

# Generated at 2022-06-24 06:15:45.866401
# Unit test for function side_effect
def test_side_effect():
    out = "Archive:  test.zip\n" + \
        " extracting: test.txt" + os.linesep
    shell.from_string('unzip test.zip').set_stdout(out)
    with open('test.txt', 'w') as f:
        f.write('test')
    side_effect('unzip test.zip', 'unzip -d test test.zip')
    assert not path.isfile('test.txt')

# Generated at 2022-06-24 06:15:56.071766
# Unit test for function match
def test_match():
    # Test when script is no 'unzip'
    command_no_unzip = Command("tar", '')
    assert not match(command_no_unzip)

    # Test when script is 'unzip' but not with a bad zip
    command_good_zip = Command("unzip test.zip", '')
    assert not match(command_good_zip)

    # Test when script is unzip and a bad zip
    command_bad_zip = Command("unzip test.zip", '')
    with mock.patch('thefuck.rules.unzip._zip_file', return_value='test.zip'):
        with mock.patch('thefuck.rules.unzip._is_bad_zip', return_value=True):
            assert match(command_bad_zip)



# Generated at 2022-06-24 06:15:59.358380
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip file.zip', '', '')) == 'unzip -d file file.zip'
    assert get_new_command(Command('unzip file', '', '')) == 'unzip -d file file.zip'

# Generated at 2022-06-24 06:16:04.007940
# Unit test for function match
def test_match():
    assert not match(Command('unzip', ''))
    assert not match(Command('unzip', '-d a'))
    assert not match(Command('unzip', 'a'))
    assert match(Command('unzip', 'b.zip'))
    assert not match(Command('unzip', '-d b.zip'))

    script = 'unzip -p -a -d a b.zip'
    assert not match(Command(script, ''))
    assert match(Command(script, 'b.zip'))

    script = 'unzip a b.zip'
    assert not match(Command(script, ''))
    assert match(Command(script, 'b.zip'))



# Generated at 2022-06-24 06:16:12.474278
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert 'unzip -d a.zip a.zip' == get_new_command(Command(
        u'unzip a.zip', u'  inflating: a.zip              \n', ''))
    assert 'unzip -d a.zip a.zip' == get_new_command(Command(
        u'unzip a.zip', '  inflating: a.zip              \n', ''))
    assert 'unzip -d a.zip a.zip' == get_new_command(Command(
        u'unzip a.zip -x file.txt', '  inflating: a.zip              \n', ''))

# Generated at 2022-06-24 06:16:22.057749
# Unit test for function match
def test_match():
    # unzip <file.zip>
    assert match(Command("unzip file.zip"))
    assert match(Command("unzip file1.zip file2.zip"))
    assert match(Command("unzip file.zip -foo bar"))
    assert not match(Command("unzip file.zip -d output_dir"))
    assert not match(Command("unzip -d output_dir file.zip"))
    assert not match(Command("unzip -d output_dir file.zip -foo bar"))
    assert not match(Command("unzip file.zip -d output_dir -foo bar"))
    assert not match(Command("unzip -d output_dir file.zip -foo bar"))
    # zip <file.zip>
    assert match(Command("zip file.zip"))
    assert match(Command("zip file1.zip file2.zip"))


# Generated at 2022-06-24 06:16:29.018070
# Unit test for function match
def test_match():
    output = 'Archive:  test.zip\n' \
             '   creating: test/\n' \
             '  inflating: test/file.txt          \n' \
             '  inflating: test/sub/subfile.txt   \n'
    assert match(Command('unzip test.zip file.txt', output))
    assert not match(Command('unzip -d test test.zip', output))
    assert not match(Command('unzip test1.zip', output))
    assert not match(Command('unzip test.zip', 'some output'))


# Generated at 2022-06-24 06:16:30.502653
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('unzip lol.zip', '') == "unzip -d 'lol'"

# Generated at 2022-06-24 06:16:37.421834
# Unit test for function match
def test_match():
    import unittest

    class MatchTest(unittest.TestCase):

        def test_match_with_zip_file_without_path(self):
            command = type('obj', (object,), {'script': u'unzip bad.zip',
                                              'script_parts': [u'unzip',
                                                               'bad.zip']})
            self.assertTrue(match(command))

        def test_match_with_zip_file_with_path(self):
            command = type('obj', (object,), {'script': u'unzip docs/bad.zip',
                                              'script_parts': [u'unzip',
                                                               'docs/bad.zip']})
            self.assertTrue(match(command))


# Generated at 2022-06-24 06:16:42.732808
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('unzip new_dir file.zip dir/file', '', '')) == \
           'unzip -d new_dir file.zip dir/file'
    assert get_new_command(Command('unzip file.zip file', '', '')) == \
           'unzip -d file file.zip'

# Generated at 2022-06-24 06:16:48.634166
# Unit test for function match
def test_match():
    zip_file = "test_match.zip"
    with zipfile.ZipFile(zip_file, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("test_file0.txt", "just a file")
        archive.writestr("test_file1.txt", "just a file")

    command = "unzip {}".format(zip_file)
    assert (match(shell.and_("", command)) is True)



# Generated at 2022-06-24 06:16:53.061980
# Unit test for function match
def test_match():
    # Test for a file whose full name is .zip
    command_with_zip = 'unzip .zip'
    assert match(command_with_zip)
    # Test for a .zip file with 2 elements
    command_with_2_elements = 'unzip 2_elements.zip'
    assert match(command_with_2_elements)



# Generated at 2022-06-24 06:16:55.904509
# Unit test for function get_new_command
def test_get_new_command():
    assert "unzip archive.zip -d archive" == get_new_command("unzip archive.zip".split())


# Generated at 2022-06-24 06:17:02.304259
# Unit test for function side_effect
def test_side_effect():
    shell = Mock()
    shell.quote = str

    script_parts = mock.Mock()
    script_parts.script = u'unzip {0}'.format(mock.Mock())
    old_cmd = mock.Mock()
    old_cmd.script_parts = script_parts
    old_cmd.script = script_parts.script

    command = mock.Mock()
    command.script = mock.Mock()
    side_effect(old_cmd, command)

# Generated at 2022-06-24 06:17:07.166869
# Unit test for function match
def test_match():
    assert (match(Command(script='unzip FileDir'))
            == '/home/User/FileDir.zip')
    assert (match(Command(script='unzip FileDir.ZIP'))
            == '/home/User/FileDir.ZIP')
    assert (match(Command(script='unzip File1 File2 File3'))
            == '/home/User/File3.zip')



# Generated at 2022-06-24 06:17:11.848542
# Unit test for function match
def test_match():
    assert match(Command(script='unzip -d'))
    assert match(Command(script='unzip file.zip'))
    assert match(Command(script='unzip file.zip -d'))
    assert not match(Command(script='unzip -d file.zip'))
    assert not match(Command(script='unzip file1.zip file1.zip'))



# Generated at 2022-06-24 06:17:22.587504
# Unit test for function match
def test_match():
    assert match(Command('/usr/bin/unzip /home/user/archive.zip',
                         os.path.abspath('/usr/bin/unzip')))
    assert match(Command('unzip /home/user/archive.zip',
                         os.path.abspath('/usr/bin/unzip')))

    assert not match(Command('/usr/bin/unzip -d /home/user/archive.zip',
                             os.path.abspath('/usr/bin/unzip')))
    assert not match(Command('unzip -d /home/user/archive.zip',
                             os.path.abspath('/usr/bin/unzip')))

# Generated at 2022-06-24 06:17:25.899488
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('unzip toto.zip', '', '', '', '')
    new_command = get_new_command(command)
    assert new_command == 'unzip -d toto toto.zip'

# Generated at 2022-06-24 06:17:34.742410
# Unit test for function side_effect
def test_side_effect():
    from unittest.mock import patch, mock_open
    result = mock_open()
    result.read_data = '\n'.join([
        'Archive:  test.zip',
        ' extracting: dir/',
        ' extracting: dir/file1',
        ' extracting: dir/file2',
        ' extracting: test'])
    with patch('subprocess.check_output', return_value=result.read_data), \
            patch('builtins.open', new=result):
        cmd = shell.and_('unzip test.zip', 'unzip test.zip')
        side_effect(cmd, cmd)

# Generated at 2022-06-24 06:17:44.977855
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.rules.zip_unzip import get_new_command, side_effect

    old_cmd = Command('unzip test.zip', 'unzip:  cannot find or open test.zip, test.zip.zip or test.zip.ZIP.')
    command = get_new_command(old_cmd)
    side_effect(old_cmd, command)

    file = open('test.zip', 'w')
    file.close()
    file = open('test.zip/file.abc', 'w')
    file.close()
    old_cmd = Command('unzip test.zip', 'unzip:  cannot find or open test.zip, test.zip.zip or test.zip.ZIP.')
    command = get_new_command(old_cmd)
    side_effect

# Generated at 2022-06-24 06:17:56.476907
# Unit test for function side_effect
def test_side_effect():
    # Install an archive with  a file aa.txt
    zipFile = 'test.zip'
    zip = zipfile.ZipFile(zipFile, 'w')
    zip.writestr('aa.txt', 'Hello World')
    zip.close()
    # Remove file aa.txt if it exists and run side_effect()
    if os.path.isfile('aa.txt'):
        os.remove('aa.txt')
    command = type('', (), {})()
    command.script = 'unzip -d . test.zip'
    side_effect(command, '')
    # Assert that the file aa.txt does not exist
    assert not os.path.isfile('aa.txt')
    # Remove the archive
    os.remove('test.zip')

# Generated at 2022-06-24 06:18:06.494619
# Unit test for function side_effect
def test_side_effect():
    """
    Test side effect function of unzip rule
    """
    old_cmd = Command('unzip test.zip', '', None)  # noqa
    command = Command('unzip -d test test.zip', '', None)  # noqa
    test_cwd = '/home/user/'
    test_zip = 'test.zip'
    test_file = 'unittest.txt'

    # Simulate that we're in a directory where it's not safe to overwrite files
    os.chdir('/tmp/')
    side_effect(old_cmd, command)  # should not throw an error

    # Go to the directory the unit test can operate safely
    os.chdir(test_cwd)
    with zipfile.ZipFile(test_zip, 'w') as test_zip_file:
        test_zip

# Generated at 2022-06-24 06:18:10.370802
# Unit test for function get_new_command
def test_get_new_command():
    old_cmd = FakeCommand(script = 'unzip foo.zip')
    assert get_new_command(old_cmd) == 'unzip -d foo foo.zip'
    old_cmd = FakeCommand(script = 'unzip foo.zip -x bar.zip')
    assert get_new_command(old_cmd) == 'unzip -d foo.zip -x bar.zip'

# Generated at 2022-06-24 06:18:14.955406
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip file', None)) == 'unzip -d file file'
    assert get_new_command(Command('unzip file.zip', None)) == 'unzip -d file file.zip'
    assert get_new_command(Command('unzip -l file', None)) == 'unzip -l -d file file'
    assert get_new_command(Command('unzip -l file.zip', None)) == (
        'unzip -l -d file file.zip')


# Generated at 2022-06-24 06:18:22.151399
# Unit test for function get_new_command
def test_get_new_command():
    script = "unzip file"
    bad_command = "unzip file.zip"
    correct_command = "unzip -d file file.zip"
    extracted_dir = os.path.join(os.getcwd(), "file")
    command = type("Command", (object,), {"script": script, "script_parts":
                                          bad_command.split(), "stderr": "", "stdout": "", "stdin": ""})
    assert get_new_command(command) == correct_command



# Generated at 2022-06-24 06:18:26.343096
# Unit test for function get_new_command
def test_get_new_command():
    """Function should return correct command"""
    from thefuck.specific.unzip import get_new_command
    assert get_new_command(type('Command', (object,), {
        'script': 'unzip test.zip',
        'script_parts': ['unzip', 'test.zip']})) == 'unzip -d test test.zip'

# Generated at 2022-06-24 06:18:37.329344
# Unit test for function match
def test_match():
    assert match(Command('unzip example.zip', ''))
    assert match(Command('unzip -d example.zip', ''))
    assert match(Command('unzip -l example.zip', ''))
    assert not match(Command('unzip -d example example.zip', ''))
    assert not match(Command('unzip unzip.zip', ''))
    assert not match(Command('unzip -d unzip.zip', ''))
    assert not match(Command('unzip -l unzip.zip', ''))
    assert not match(Command('unzip example.zip -d foo', ''))
    assert not match(Command('unzip example.zip foo', ''))
    assert not match(Command('unzip', ''))



# Generated at 2022-06-24 06:18:40.295249
# Unit test for function get_new_command
def test_get_new_command():
    script = 'unzip file.zip /tmp'
    output = 'error:  must specify an existing directory'
    get_new_command(shell.And('', script, output))

# Generated at 2022-06-24 06:18:49.624315
# Unit test for function side_effect
def test_side_effect():
    """
    To test the side_effect function, the unittest module is used. The
    side_effect function is called with an invalid archive
    """
    import tempfile

    test_file = tempfile.mktemp()
    f = open(test_file, 'w')
    f.write('TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST\n')
    f.close()

    test_zip = tempfile.mktemp()
    with zipfile.ZipFile(test_zip, 'w') as f:
        f.write(test_file)

    class Command():
        script = u'unzip -d {0} {1}'.format(test_file[:-4], test_zip)

# Generated at 2022-06-24 06:18:57.440576
# Unit test for function side_effect
def test_side_effect():
    # Create test dir
    test_dir_path = os.path.expanduser(u'~/thefuck-test')
    os.mkdir(test_dir_path)
    os.chdir(test_dir_path)

    # Create test zip file
    test_file_name = 'test.zip'
    test_file_path = os.path.join(test_dir_path, test_file_name)
    with open(test_file_path, 'wb') as test_file:
        test_file.write(b'''\
UEsFBgAAAAABAAEAOAAAAGRhdGEv
    ''')

    # Create test file
    test_text_file_name = 'test.txt'

# Generated at 2022-06-24 06:19:00.474332
# Unit test for function match
def test_match():

    assert(match(Command(script='unzip test.zip',
                         stderr='test.zip:  zip file is empty')) == True)



# Generated at 2022-06-24 06:19:09.703310
# Unit test for function match
def test_match():
    script = "unzip ~/Desktop/test.zip"
    script_parts = script.split()
    command = type('Command', (object,),
                   {'script': script, 'script_parts': script_parts})

    assert match(command) is True

    script = "unzip ~/Desktop/test.zip -d ~/Desktop/test/"
    script_parts = script.split()
    command = type('Command', (object,),
                   {'script': script, 'script_parts': script_parts})
    assert match(command) is False

    script = "unzip ~/Desktop/test.zip test"
    script_parts = script.split()
    command = type('Command', (object,),
                   {'script': script, 'script_parts': script_parts})
    assert match(command) is True


# Generated at 2022-06-24 06:19:14.732473
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("unzip file.zip", "ls")) == "unzip -d 'file' file.zip"
    assert get_new_command(Command("unzip -j file.zip", "ls")) == "unzip -j -d 'file' file.zip"

# Generated at 2022-06-24 06:19:23.744659
# Unit test for function match
def test_match():
    with shell.TempDirectory() as directory:
        os.chdir(directory.name)
        with zipfile.ZipFile(directory.name + '/test.zip', 'a') as archive:
            archive.write(directory.name + '/test1.txt')
            archive.write(directory.name + '/test2.txt')
            archive.write(directory.name + '/test3.txt')

        assert match(Command('unzip test.zip -d test_dir', '', directory.name))

        with zipfile.ZipFile(directory.name + '/test.zip', 'a') as archive:
            archive.write(directory.name + '/test.txt')

        assert not match(Command('unzip test.zip -d test_dir', '', directory.name))



# Generated at 2022-06-24 06:19:33.022218
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip file', '', '')) == 'unzip -d file'
    assert get_new_command(Command('unzip file.zip', '', '')) == 'unzip -d file'
    assert get_new_command(Command('unzip file.zip file1.txt', '', '')) == 'unzip -d file file1.txt'
    assert get_new_command(Command('unzip -u file.zip', '', '')) == 'unzip -u -d file file.zip'
    assert get_new_command(Command('unzip -u file1.zip file1.txt', '', '')) == 'unzip -u -d file1 file1.zip file1.txt'


# Generated at 2022-06-24 06:19:40.737479
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('unzip my_file.zip some_file.txt')
    assert not match(command)
    command = Command('unzip my_file.zip some_file.txt -d')
    assert not match(command)
    command = Command('unzip my_file.zip -d')
    assert not match(command)
    command = Command('unzip my_file.zip')
    assert match(command)
    command = Command('unzip /tmp/my_file.zip')
    assert match(command)
    command = Command('unzip /tmp/my_file.zip -d')
    assert match(command)
    assert get_new_command(command) == 'unzip /tmp/my_file.zip -d /tmp/my_file'

# Generated at 2022-06-24 06:19:43.624045
# Unit test for function match
def test_match():
    from tests.utils import Command

    assert _zip_file(Command('unzip file.zip')) == 'file.zip'

# Generated at 2022-06-24 06:19:48.468977
# Unit test for function match
def test_match():
    command = Command('unzip file.zip')
    assert match(command) == False

    command = Command('unzip -d dest file.zip')
    assert match(command) == False

    command = Command('unzip a.zip b.zip all.zip')
    assert match(command) == False

    command = Command('unzip file.zip')
    assert match(command) == False

    command = Command('unzip dest/file.zip')
    assert match(command) == False

    command = Command('unzip -d dest/ dir/file.zip')
    assert match(command) == False

    command = Command('unzip dir/file.zip')
    assert match(command) == False

    command = Command('unzip dir/file.zip')
    assert match(command) == False

# Generated at 2022-06-24 06:19:50.709543
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', None))
    assert not match(Command('unzip test.zip -d test', None))


# Generated at 2022-06-24 06:19:53.432164
# Unit test for function match
def test_match():
    assert _is_bad_zip("test_file.zip") == False
    assert _is_bad_zip("test_file2.zip") == False
    assert _is_bad_zip("test_file3.zip") == True

# Generated at 2022-06-24 06:19:59.417538
# Unit test for function match
def test_match():
    # Test zip file that shouldn't be in the current directory
    f = 'test/test_match.zip'
    open(f, 'a').close()
    assert not match(Command('unzip ' + f, None, None))
    os.remove(f)

    # Test zip file that shouldn't have more than one file in it
    f = 'test/test_match.zip'
    with zipfile.ZipFile(f, 'w') as archive:
        archive.writestr('test', '')
    assert not match(Command('unzip ' + f, None, None))
    os.remove(f)

    # Test zip file that should be in the current directory
    f = 'test/test_match.zip'

# Generated at 2022-06-24 06:20:01.794146
# Unit test for function match
def test_match():
    r = match(Command('ls', 'ls'))
    assert not r

# Generated at 2022-06-24 06:20:03.810782
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip file.zip', '')) == 'unzip -d file file.zip'

# Generated at 2022-06-24 06:20:11.466391
# Unit test for function match
def test_match():
    # No file to unzip, nothing to test
    assert not match(Command('unzip archive.zip', '', ''))

    # With a file that does not zipfile
    assert not match(Command('unzip archive.zip myfile.txt', '', ''))

    # With file to unzip that does not exist
    assert not match(Command('unzip archive.zip myfile.zip', '', ''))

    # With a file to unzip that exists
    # With a zipfile that has more than one file
    assert match(Command('unzip archive.zip myfile.zip', '', ''))

    # With a zipfile that has only one file
    assert not match(Command('unzip archive.zip myfile.zip', '', ''))

# Generated at 2022-06-24 06:20:17.875974
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import functools

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-24 06:20:27.232060
# Unit test for function match
def test_match():
    files = ["file1.zip", "file2.zip"]
    for f in files:
        with open(f, 'w') as fp:
            fp.write("Hello, World!\n")

    assert match(Command("unzip", "")) == False
    assert match(Command("unzip", "file1.zip")) == True
    assert match(Command("unzip", "file1.zip", "file2.zip")) == False
    assert match(Command("unzip", "-d", "file1.zip")) == False
    assert match(Command("unzip", "-d", "file1.zip", "file2.zip")) == False

    for f in files:
        os.remove(f)

# Generated at 2022-06-24 06:20:37.876394
# Unit test for function match
def test_match():
    match("") == False
    match("unzip") == False
    match("unzip file.zip") == False
    match("unzip -d folder file.zip") == False
    match("unzip -d folder file.zip archive.zip") == True
    match("unzip file.zip archive") == False
    match("unzip file.zip archive.zip") == True
    match("unzip file") == False
    match("unzip file archive") == False
    match("unzip file archive.zip") == True
    match("unzip file file.zip") == True
    match("unzip file.zip file") == True
    match("unzip file.zip file file.zip") == True


# Generated at 2022-06-24 06:20:39.461539
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('unzip foo.zip') == 'unzip foo.zip -d foo'



# Generated at 2022-06-24 06:20:42.891819
# Unit test for function side_effect
def test_side_effect():
    script = u'unzip -d test /tmp/test.zip'
    old_cmd = Command(script, '')
    command = u'unzip -d test /tmp/test.zip'
    side_effect(old_cmd, command)
    assert Command(command, '').script == 'unzip -d test /tmp/test.zip'

# Generated at 2022-06-24 06:20:53.913597
# Unit test for function side_effect
def test_side_effect():
    import shutil
    import tempfile
    import zipfile
    from thefuck.shells import shell

    tmpdir = tempfile.mkdtemp()
    test_file = os.path.join(tmpdir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('Content')

    with zipfile.ZipFile(os.path.join(tmpdir, 'test_file.zip'), 'w') as zf:
        zf.write(test_file)

    command = shell.and_('cd {}'.format(shell.quote(tmpdir)), 'unzip test_file.zip')

    assert os.path.exists(test_file)
    side_effect(get_new_command(command), command)
    assert not os.path.exists(test_file)

   

# Generated at 2022-06-24 06:20:57.158463
# Unit test for function match
def test_match():
    assert not match(Command('unzip -d /tmp/b.zip'))
    assert match(Command('unzip /tmp/a.zip'))
    assert match(Command('unzip foo.zip'))


# Generated at 2022-06-24 06:21:03.972826
# Unit test for function get_new_command
def test_get_new_command():
    command = u'unzip test.zip'
    assert get_new_command(shell.and_('/usr/local/bin/unzip ' + command)) == u'/usr/local/bin/unzip ' + command + ' -d test'
    command = u'unzip test'
    assert get_new_command(shell.and_('/usr/local/bin/unzip ' + command)) == u'/usr/local/bin/unzip ' + command + ' -d test'


# Generated at 2022-06-24 06:21:08.839527
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'unzip foo.zip') == \
        u'unzip -d foo foo.zip'
    assert get_new_command(u'unzip bar') == \
        u'unzip -d bar bar.zip'
    assert get_new_command(u'unzip foo.zip bar') == \
        u'unzip -d foo foo.zip bar'

# Generated at 2022-06-24 06:21:09.368512
# Unit test for function side_effect
def test_side_effect():
    pass

# Generated at 2022-06-24 06:21:13.845689
# Unit test for function match
def test_match():
    assert match(Command('unzip foo.zip'))
    assert match(Command('unzip foo.zip bar.zip'))
    assert not match(Command('unzip foo.zip -d bar'))
    assert not match(Command('ls'))
    assert not match(Command('unzip foo.zp'))



# Generated at 2022-06-24 06:21:22.297511
# Unit test for function match
def test_match():
    # function _is_bad_zip
    assert _is_bad_zip('fixtures/malicious.zip')
    assert not _is_bad_zip('fixtures/not_malicious.zip')

    # function _zip_file
    assert _zip_file(Command('', 'unzip malicious.zip -d /')) == 'malicious.zip'
    assert (_zip_file(Command('', 'unzip not_malicious.zip -d /'))
            == 'not_malicious.zip')

    # function match
    assert match(Command('', 'unzip fixtures/malicious.zip /etc'))
    assert not match(Command('', 'unzip fixtures/not_malicious.zip /etc'))
    assert not match(Command('', 'zip -r malicious.zip fixtures/malicious.zip'))


# Unit

# Generated at 2022-06-24 06:21:31.737700
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    # simple unzip
    assert get_new_command(Command('unzip file.zip')) \
        == u'unzip -d file file.zip'

    # unzip with relative path
    assert get_new_command(Command('unzip ../file.zip')) \
        == u'unzip -d ../file ../file.zip'

    # unzip with relative path (without -d)
    assert get_new_command(Command('unzip ../file.zip ./')) \
        == u'unzip -d ../file ../file.zip ./'

    # unzip to subdirectory
    assert get_new_command(Command('unzip file.zip subdir')) \
        == u'unzip -d subdir file.zip subdir'

    # unzip

# Generated at 2022-06-24 06:21:42.481954
# Unit test for function side_effect
def test_side_effect():
    subprocess.check_call(['touch', 'file1'])
    subprocess.check_call(['mkdir', 'folder1'])
    subprocess.check_call(['mkdir', 'folder2'])
    subprocess.check_call(['touch', 'folder2/file2'])
    subprocess.check_call(['touch', 'folder3/file3'])
    subprocess.check_call(['touch', 'file4'])
    subprocess.check_call(['touch', '../file5'])
    subprocess.check_call(['touch', '/file6'])

    side_effect(Command('unzip file1.zip file1 file4 ../file5 /file6 folder2/file2 folder3/file3', None), None)

    assert os.path.isfile('file1') is False

# Generated at 2022-06-24 06:21:46.287981
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (), {
        'script': 'foo bar baz.zip',
        'script_parts': ['foo', 'bar', 'baz.zip']
    })

    assert get_new_command(command) == 'foo -d baz'

# Generated at 2022-06-24 06:21:56.485960
# Unit test for function side_effect
def test_side_effect():
    # Set command to unzip the zipfile
    old_cmd = shell.and_('unzip', 'mytest.zip')

    # Create the zipfile
    with zipfile.ZipFile('mytest.zip', 'w') as archive:
        archive.writestr('archive.txt', 'test string')

    # Assert that the zipfile exists
    assert zipfile.is_zipfile('mytest.zip')

    # Unzip the file
    side_effect(old_cmd, None)

    # Assert that the zipfile is not there any more
    assert not zipfile.is_zipfile('mytest.zip')
    # Assert that the file exists
    assert os.path.isfile('archive.txt')

    # Cleanup
    os.remove('archive.txt')

# Generated at 2022-06-24 06:22:04.991627
# Unit test for function match
def test_match():
    assert not match(Command('unzip foo.zip bar', '', ''))
    assert not match(Command('unzip foo.zip bar -d foo', '', ''))
    assert not match(Command('unzip foo.zip', '', ''))
    assert not match(Command('unzip foo.zip foo', '', ''))
    assert match(Command('unzip foo.zip bar baz', '', ''))
    assert match(Command('unzip foo.zip -d foo', '', ''))
    assert match(Command('unzip foo.zip foo bar', '', ''))
    assert match(Command('unzip foo.zip -d foo bar baz', '', ''))

# Generated at 2022-06-24 06:22:14.589919
# Unit test for function match
def test_match():
    file_name = "test_file.zip"
    file_name_not_zip = "test_file"

    # Test for unzip
    with open(file_name, 'w') as f: 
        f.write("test")

    assert _zip_file(Command('', 'unzip ' + file_name)) == file_name

    # Test for unzip with flags
    assert _zip_file(Command('', 'unzip -d ' + file_name)) == None

    # Test for unzip with multiple files
    assert _zip_file(Command('', 'unzip ' + file_name + " " + file_name_not_zip)) == file_name

    # Test for unzip without zip file
    assert _zip_file(Command('', 'unzip ')) == None

    # Test for unzip without file
   

# Generated at 2022-06-24 06:22:24.395275
# Unit test for function get_new_command
def test_get_new_command():
    assert u'unzip -d foo-master foo-master.zip' == get_new_command(
        Command(u'unzip foo-master.zip', u'', u''))

    assert u'unzip -d foo-master foo-master.zip bar.zip' == get_new_command(
        Command(u'unzip foo-master.zip bar.zip', u'', u''))

    assert u'unzip -d foo -d foo-master foo-master.zip bar.zip' == get_new_command(
        Command(u'unzip -d foo-master foo-master.zip bar.zip', u'', u''))

# Generated at 2022-06-24 06:22:34.730218
# Unit test for function match
def test_match():
    assert not match(Command('zip file.zip file'))
    assert not match(Command('zip -d file.zip file'))
    assert match(Command('unzip file'))
    assert match(Command('unzip file.zip'))
    assert not match(Command('unzip -d file.zip'))
    assert match(Command('unzip file.zip file1 file2'))
    assert match(Command('unzip file.zip file1 file2 file3'))
    assert match(Command('unzip file.zip -x file1 file2'))
    assert match(Command('unzip file.zip -x file1 file2 file3'))
    assert match(Command('unzip file.zip -x file1 file2 -d dir'))

# Generated at 2022-06-24 06:22:42.858697
# Unit test for function match
def test_match():
    from thefuck.types import Command

    output = u'Archive: /home/paulojjr/test.zip\n  End-of-central-directory signature not found.  Either this file is not\n  a zipfile, or it constitutes one disk of a multi-part archive.  In the\n  latter case the central directory and zipfile comment will be found on\n  the last disk(s) of this archive.\nunzip:  cannot find zipfile directory in one of /home/paulojjr/test.zip or\n        /home/paulojjr/test.zip.zip, and cannot find /home/paulojjr/test.zip.ZIP, period.'

    assert match(Command('unzip /home/paulojjr/test.zip', output))

# Generated at 2022-06-24 06:22:50.075899
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip one.zip', '')) == 'unzip one.zip -d one'
    assert get_new_command(Command('unzip -a one.zip', '')) == 'unzip -a one.zip -d one'
    assert get_new_command(Command('unzip -a one', '')) == 'unzip -a one.zip -d one'
    assert get_new_command(Command('unzip -a "one"', '')) == 'unzip -a "one" -d one'

# Generated at 2022-06-24 06:22:56.257668
# Unit test for function side_effect
def test_side_effect():
    # Create test directory
    os.mkdir('test')
    # Create test file
    with open('test/test_file', 'w') as f:
        f.write('test')
    # Create test zip file
    with zipfile.ZipFile('test.zip', 'w') as f:
        f.write('test/test_file')
    # Test
    side_effect(None, None)
    # Cleanup
    os.remove('test/test_file')
    os.rmdir('test')
    os.remove('test.zip')
    os.remove('test_file')

# Generated at 2022-06-24 06:23:05.447667
# Unit test for function side_effect
def test_side_effect():
    tmp_dir = mkdtemp()
    tmp_archive = os.path.join(tmp_dir, 'archive.zip')
    tmp_file = os.path.join(tmp_dir, 'file')

    archive = zipfile.ZipFile(tmp_archive, 'w')
    archive.writestr('file', 'content')
    archive.close()

    open(tmp_file, 'w').write('content')

    os.chdir(tmp_dir)

    try:
        side_effect(Command('unzip archive.zip', ''), Command('unzip archive.zip -d'))

        assert not os.path.exists(tmp_file)
    finally:
        rmtree(tmp_dir)

# Generated at 2022-06-24 06:23:11.318757
# Unit test for function match
def test_match():
    # Test for zip file
    shell.from_string('unzip test.zip').and_return((0, '', ''))
    _is_bad_zip('test.zip').should.be.false
    match(shell.from_string('unzip test.zip')).should.be.false
    _is_bad_zip('test.zip').should.be.false
    # Test for multiple files in the archive
    _is_bad_zip('test.zip').should.be.true
    match(shell.from_string('unzip test.zip')).should.be.true


# Generated at 2022-06-24 06:23:16.126927
# Unit test for function match
def test_match():
    assert match(Command('unzip', 'something'))
    assert match(Command('unzip', '-d', 'somewhere', 'something'))
    assert not match(Command('unzip', '-d', 'somewhere', '-q', 'something'))



# Generated at 2022-06-24 06:23:20.760537
# Unit test for function match
def test_match():
    assert match(Command(script='unzip foo.zip'))
    assert match(Command(script='unzip foo'))
    assert not match(Command(script='unzip -d foo'))
    assert not match(Command(script='unzip -d foo.zip'))
    assert not match(Command(script='unzipa foo'))



# Generated at 2022-06-24 06:23:24.097522
# Unit test for function match
def test_match():
    assert match(Command('unzip ZipFile.zip', '', '/bin/unzip'))
    assert not match(Command('unzip -d unzipped ZipFile.zip', '', '/bin/unzip'))



# Generated at 2022-06-24 06:23:30.287735
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash
    shell = Bash()
    assert get_new_command(
        type('Command', (object,),
             {'script': 'unzip file.zip somedir newfile.txt',
              'script_parts': ['unzip', 'file.zip', 'somedir', 'newfile.txt']}
            )
        ) == u'unzip -d {} {}'.format(shell.quote('file'),
                                      shell.quote('somedir'),
                                      shell.quote('newfile.txt'))

# Generated at 2022-06-24 06:23:42.373590
# Unit test for function side_effect
def test_side_effect():
    from thefuck.runner import Runner

    # Create an archive
    _zip_file = 'test.zip'
    old_cmd_script = "unzip {}".format(_zip_file)
    _zip_dir = 'testdir'
    with zipfile.ZipFile(_zip_file, 'w') as archive:
        archive.writestr(_zip_dir+"/contents.txt", "Contents of dir.\n")
        archive.writestr("root.txt", "Contents of root.\n")
    # Run side_effect
    old_cmd = Runner(old_cmd_script)
    side_effect(old_cmd, None)
    # Check that the archive is unzipped.
    assert os.path.exists(_zip_dir)

# Generated at 2022-06-24 06:23:52.309216
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip test.zip', None, '/tmp')) == 'unzip -d test test.zip'
    assert get_new_command(Command('unzip -v test.zip', None, '/tmp')) == 'unzip -v -d test test.zip'
    assert get_new_command(Command('unzip -v -a test.zip', None, '/tmp')) == 'unzip -v -a -d test test.zip'
    assert get_new_command(Command('unzip test.zip test2.zip', None, '/tmp')) == 'unzip -d test test.zip'
    assert get_new_command(Command('unzip test.zip test2', None, '/tmp')) == 'unzip -d test2 test.zip'

# Generated at 2022-06-24 06:23:58.713235
# Unit test for function side_effect
def test_side_effect():
    """
    Check side_effect function
    """
    # prepare
    filename = "file.zip"
    with zipfile.ZipFile(filename, mode='w') as z:
        z.writestr('file.txt', "This is test text")
    # test
    side_effect("unzip file.zip", "unzip file.zip -d file")
    # results
    assert not os.path.isfile("file/file.txt")

# Generated at 2022-06-24 06:24:06.951933
# Unit test for function match
def test_match():
    assert match(Command('unzip'))
    assert match(Command('unzip -o'))
    assert not match(Command('unzip -d foo'))
    assert not match(Command('unzip -o -d foo'))
    assert not match(Command('unzip -l'))
    assert match(Command('unzip foo.zip'))
    assert match(Command('unzip foo.zip bar'))
    assert match(Command('unzip foo.zip bar.zip'))
    assert match(Command('unzip foo.zip bar.zip baz.zip'))



# Generated at 2022-06-24 06:24:15.069787
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(shell.and_('unzip abcd.zip', ';', 'cd'),
                                  'unzip abcd.zip')
    assert new_command == 'unzip -d abcd'

    new_command = get_new_command(shell.and_('unzip abcd.zip', '&&', 'cd'),
                                  'unzip abcd.zip')
    assert new_command == 'unzip -d abcd'

    new_command = get_new_command(shell.and_('unzip abcd', '&&', 'cd'),
                                  'unzip abcd')
    assert new_command == 'unzip -d abcd'


# Generated at 2022-06-24 06:24:24.355943
# Unit test for function side_effect
def test_side_effect():
    import os
    import tempfile
    import zipfile

    dirpath = tempfile.mkdtemp()
    try:
        zippath = os.path.join(dirpath, 'foo.zip')
        with zipfile.ZipFile(zippath, 'w') as z:
            z.writestr('foo', 'bar')

        os.chdir(dirpath)
        open('foo', 'w').close()

        side_effect(type('', (), {'script': 'unzip {}'.format(zippath)}),
                    type('', (), {'script': 'unzip {} -d .'.format(zippath)}))

        assert not os.path.isfile('foo')

    finally:
        shutil.rmtree(dirpath)