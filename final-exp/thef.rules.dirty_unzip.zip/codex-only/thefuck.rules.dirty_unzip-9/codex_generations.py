

# Generated at 2022-06-24 06:14:33.623916
# Unit test for function side_effect
def test_side_effect():
    f = open('test.txt', 'w')
    f.write('TEST STRING')
    f.close()

    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.write('test.txt')

    assert os.path.isfile('test.txt')

    side_effect('command', 'new_command')

    assert not os.path.isfile('test.txt')

    os.remove('test.zip')

# Generated at 2022-06-24 06:14:39.228529
# Unit test for function get_new_command
def test_get_new_command():
    command = 'unzip file.zip'
    assert get_new_command(command) == u'unzip file.zip -d file'

    command = 'unzip file'
    assert get_new_command(command) == u'unzip file -d file'

    command = 'unzip -l file.zip'
    assert get_new_command(command) == u'unzip -l file.zip -d file'

# Generated at 2022-06-24 06:14:41.636758
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip foo.zip')) == 'unzip -d foo foo.zip'
    assert get_new_command(Command('unzip -o foo.zip')) == 'unzip -d foo -o foo.zip'

# Generated at 2022-06-24 06:14:45.858646
# Unit test for function match

# Generated at 2022-06-24 06:14:48.467076
# Unit test for function get_new_command
def test_get_new_command():
    test_command = Command("unzip test.zip", '', '')
    assert get_new_command(test_command) == 'unzip -d test test.zip'

# Generated at 2022-06-24 06:14:58.375078
# Unit test for function match
def test_match():
    # Test if match returns True if failed with
    # Command line interface error message
    command = 'unzip -d'
    assert match(command) is True

    # Test if match returns False if failed with
    # Error message saying 'Cannot find zip file'
    command = 'unzip -d abc'
    assert match(command) is False

    # Test if match returns True if failed with
    # Error message saying 'At least one file must be specified'
    command = 'unzip'
    assert match(command) is True

    # Test if match returns False if failed with
    # Warning message saying 'End-of-central-directory signature not found'
    command = 'unzip abc.zip'
    assert match(command) is False

    # Test if match returns True if failed with
    # Warning message saying 'Empty zip file'
   

# Generated at 2022-06-24 06:15:07.720858
# Unit test for function side_effect
def test_side_effect():
    test_directory = '/tmp/some_directory/some_sub_directory'
    test_file = '/tmp/some_directory/some_sub_directory/test.txt'
    test_file_content = 'This is a test'
    test_file2 = '/tmp/test2.txt'

    os.makedirs(test_directory)
    with open(test_file, 'w') as f:
        f.write(test_file_content)
    with open(test_file2, 'w') as f:
        f.write(test_file_content)
    with open('/tmp/test.zip', 'w') as f:
        with zipfile.ZipFile(f, 'w') as archive:
            archive.write(test_file)
            archive.write(test_file2)


# Generated at 2022-06-24 06:15:14.163595
# Unit test for function match
def test_match():
    assert not match(Command('unzip', 'unzip -d test'))
    assert match(Command('unzip', 'unzip test.zip'))
    assert match(Command('unzip', 'unzip test'))
    assert match(Command('unzip', 'unzip test.zip test2.zip'))
    assert not match(Command('unzip', 'unzip -d test.zip'))
    assert not match(Command('unzip', 'unzip -d test'))
    assert match(Command('unzip', 'unzip test.zip'))
    assert match(Command('unzip', 'unzip test'))
    assert match(Command('unzip', 'unzip test.zip test2.zip'))
    assert not match(Command('unzip', 'unzip -d test.zip'))

# Generated at 2022-06-24 06:15:16.594883
# Unit test for function match
def test_match():
    assert match(Command('unzip test1.zip', ''))
    assert not match(Command('unzip -d test1 test1.zip', ''))


# Generated at 2022-06-24 06:15:22.883247
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip foo.zip', '', '')) == u'unzip -d foo foo.zip'
    assert get_new_command(Command('unzip -x foo.zip', '', '')) == u'unzip -x -d foo foo.zip'
    assert get_new_command(Command('unzip -x ./foo.zip', '', '')) == u'unzip -x -d foo ./foo.zip'
    assert get_new_command(Command('unzip -x /path/to/foo.zip', '', '')) == u'unzip -x -d foo /path/to/foo.zip'

# Generated at 2022-06-24 06:15:25.584870
# Unit test for function match
def test_match():
    assert match(Command('zip file.zip file.txt', ''))
    assert not match(Command('unzip file.zip -d ./file', ''))


# Generated at 2022-06-24 06:15:29.757258
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command(script='unzip bad.zip', script_parts=['unzip', 'bad.zip'])
    command = Command(script='unzip -d bad bad.zip', script_parts=['unzip', '-d', 'bad', 'bad.zip'])
    side_effect(old_cmd, command)

# Generated at 2022-06-24 06:15:32.293477
# Unit test for function get_new_command
def test_get_new_command():
	old_cmd ='unzip file.zip'
	command = 'unzip file.zip'
	assert get_new_command(command) == 'unzip -d file file.zip'



# Generated at 2022-06-24 06:15:37.480345
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip -d in.zip')) == u'unzip -d in in.zip'
    assert get_new_command(Command('unzip in.zip')) == u'unzip -d in in.zip'
    assert get_new_command(Command(
        'unzip in.zip word.txt')) == u'unzip -d in in.zip word.txt'
    assert get_new_command(Command('unzip -j in.zip')) == u'unzip -j -d in in.zip'

# Generated at 2022-06-24 06:15:46.691904
# Unit test for function side_effect
def test_side_effect():
    # Tests if it does not fail
    cmd = 'unzip -o test.zip'
    old_cmd = 'unzip -o test.zip'
    side_effect(old_cmd,cmd)
    os.remove('file.txt')
    os.remove('another_file.txt')
    os.rmdir('inside_a_folder')
    os.remove('inside_a_folder/file.txt')
    os.rmdir('other_folder')
    os.remove('other_folder/another_file.txt')
    os.rmdir('other_folder/inside_a_folder')
    os.remove('other_folder/inside_a_folder/file.txt')

# Generated at 2022-06-24 06:15:50.847163
# Unit test for function get_new_command
def test_get_new_command():
    old_cmd_1 = 'unzip file.zip'
    new_cmd_1 = get_new_command(old_cmd_1)
    assert(new_cmd_1 == 'unzip -d file file.zip')

    old_cmd_2 = 'unzip file'
    new_cmd_2 = get_new_command(old_cmd_2)
    assert(new_cmd_2 == 'unzip -d file file.zip')

# Generated at 2022-06-24 06:15:59.177223
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command('cd a ; unzip file.zip')
    assert old_cmd.script_parts == ['cd', 'a', ';', 'unzip', 'file.zip']
    command = 'unzip -d file file.zip'
    assert get_new_command(old_cmd) == command
    assert _zip_file(old_cmd) == 'file.zip'
    assert not _is_bad_zip('file.zip')
    assert match(old_cmd)
    with zipfile.ZipFile('file.zip', 'w') as archive:
        archive.writestr('a.txt', 'a')



# Generated at 2022-06-24 06:16:04.008291
# Unit test for function match
def test_match():
    with open('file.zip', 'wb') as zip:
        zip.write(b'PK\x05\x06\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
                  b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
                  b'\x00')
    assert not match(Command('unzip file.zip test_nested.txt -d test',
                             '', ''))
    assert match(Command('unzip file.zip test.txt -d test', '', ''))
    os.remove('file.zip')



# Generated at 2022-06-24 06:16:07.191853
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip -l bad-zip.zip', '')) == u'unzip -l bad-zip.zip -d bad-zip'

# Generated at 2022-06-24 06:16:12.301072
# Unit test for function match
def test_match():
    ret = match(Command("unzip -d test.zip ", "unzip:  cannot find or open test.zip, test.zip.zip or test.zip.ZIP."))
    assert not ret
    ret = match(Command("unzip test.zip ", "unzip:  cannot find or open test.zip, test.zip.zip or test.zip.ZIP."))
    assert ret


# Generated at 2022-06-24 06:16:14.219523
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("unzip file.zip") == "unzip -d file file.zip"



# Generated at 2022-06-24 06:16:19.788387
# Unit test for function side_effect
def test_side_effect():
    class Object: pass
    class Command(Object): 
        def __init__(self):
            self.script = '/usr/bin/unzip -t archive.zip'
            class script_parts(object):
                def __getitem__(self, index):
                    if index == 0:
                        return '/usr/bin/unzip'
                    elif index == 1:
                        return '-t'
                    elif index == 2:
                        return 'archive.zip'
                    else:
                        return None
            self.script_parts = script_parts()

    class Archive(zipfile.ZipFile):
        def __init__(self, file):
            self.file = file

        def namelist(self):
            return ['file', 'file2']


# Generated at 2022-06-24 06:16:28.905738
# Unit test for function match

# Generated at 2022-06-24 06:16:31.005041
# Unit test for function get_new_command
def test_get_new_command():
    command = 'unzip test.zip'
    foo = get_new_command(command)
    assert foo == 'unzip test.zip -d test'



# Generated at 2022-06-24 06:16:33.077793
# Unit test for function match
def test_match():
    command = "unzip bad.zip"
    assert match(command) == True
    command = "unzip -d bad.zip"
    assert match(command) == False


# Generated at 2022-06-24 06:16:38.243401
# Unit test for function side_effect
def test_side_effect():
    def rm_file(file):
        open(file, 'a').close()

    zip_file = '/tmp/test_side_effect.zip'
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('test_side_effect/file1', '')
        archive.writestr('test_side_effect/file2', '')

    rm_file('test_side_effect/file1')
    rm_file('test_side_effect/file2')
    side_effect(old_cmd=zip_file, command='test_side_effect')

    assert os.path.exists('test_side_effect/file1')
    assert os.path.exists('test_side_effect/file2')

    os.remove(zip_file)

# Generated at 2022-06-24 06:16:46.880876
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip'))
    assert match(Command('unzip file.zip file2.zip'))
    assert match(Command('unzip file.zip file2.zip file3.zip'))
    assert not match(Command('unzip -d dir file.zip'))
    assert not match(Command('unzip -d dir file.zip file2.zip'))
    assert not match(Command('unzip -d dir file.zip file2.zip file3.zip'))
    assert not match(Command('unzip file.zip file2.zip file3.zip -x file4.zip'))


# Generated at 2022-06-24 06:16:49.561415
# Unit test for function match
def test_match():
    assert match(Command('unzip -d test.zip'))
    assert match(Command('unzip test.zip'))
    assert match(Command('unzip test'))
    assert not match(Command('unzip -d test'))



# Generated at 2022-06-24 06:16:57.816979
# Unit test for function match
def test_match():
    assert match(Command("unzip file_name.zip"))
    assert not match(Command("unzip file_name.zip file2.zip"))
    assert not match(Command("unzip file_name.zip -d /tmp"))
    assert not match(Command("unzip -l file_name.zip"))
    assert not match(Command("unzip -h"))
    assert not match(Command("unzip"))
    assert not match(Command("unzip file_name.gz"))
    assert not match(Command("zip -l file_name.zip"))
    assert not match(Command("zip"))


# Generated at 2022-06-24 06:16:59.770872
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('unzip foo.zip') == 'unzip -d foo foo.zip'

# Generated at 2022-06-24 06:17:03.369736
# Unit test for function match
def test_match():
    command = 'unzip archive.zip'
    assert match(command)

    command = 'unzip archive.zip archive2.zip'
    assert not match(command)

    command = 'unzip -d dir archive.zip'
    assert not match(command)



# Generated at 2022-06-24 06:17:07.620912
# Unit test for function match
def test_match():
    command = Command('unzip fuck.zip', '')
    assert not match(command)

    command = Command('unzip -d fuck.zip', '')
    assert not match(command)

    command = Command('unzip test.zip', '')
    assert match(command)

    command = Command('unzip test', '')
    assert match(command)

# Generated at 2022-06-24 06:17:13.631726
# Unit test for function get_new_command
def test_get_new_command():
    zip_file = 'test/test.zip'
    script = 'unzip {}'.format(os.path.abspath(zip_file))
    command = Command(script=script, stdout='', stderr='')
    assert get_new_command(command) == 'unzip -d {} {}'.format(
        shell.quote(zip_file[:-4]),
        shell.quote(os.path.abspath(zip_file)))

# Generated at 2022-06-24 06:17:15.720158
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('unzip filename.zip', '', '')) == u'unzip -d filename filename.zip'

# Generated at 2022-06-24 06:17:20.349861
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip file1 file2'))
    assert match(Command('unzip file.zip file1 file2.zip'))
    assert not match(Command('unzip -d file.zip file1 file2'))
    assert match(Command('unzip file1 file2 file3 file4 file5.zip'))



# Generated at 2022-06-24 06:17:26.517604
# Unit test for function side_effect
def test_side_effect():
    from thefuck.main import get_closest

    with zipfile.ZipFile('test_side_effect.zip', 'w') as archive:
        archive.writestr('test_side_effect', '')

    get_closest('test_side_effect.zip')
    with open('test_side_effect', 'w') as f:
        f.write('foo')
    side_effect(None, None)

    closest = get_closest('test_side_effect')
    assert next(closest) == 'test_side_effect'

# Generated at 2022-06-24 06:17:29.623416
# Unit test for function get_new_command
def test_get_new_command():
    script = u"unzip file.zip"
    _get_new_command = get_new_command(shell.And('unzip', script))
    assert _get_new_command == "unzip -d file file.zip"

# Generated at 2022-06-24 06:17:31.943002
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip foo.zip', '', '/home/user/')) == \
           'unzip -d foo foo.zip'

# Generated at 2022-06-24 06:17:39.554237
# Unit test for function side_effect
def test_side_effect():
    with TemporaryDirectory() as tmpdir:
        zip_path = tmpdir + '/test.zip'

        with zipfile.ZipFile(zip_path, 'w') as archive:
            archive.writestr('first-file', 'contents')
            archive.writestr('second-file', 'contents')

        with TemporaryDirectory() as tmpdir:
            old_cmd = Command(
                script='unzip {}'.format(shell.quote(zip_path)),
                stdout='unzip:  cannot find or open {}'.format(zip_path)
            )

            before_files = os.listdir(tmpdir)
            assert before_files == []

            side_effect(old_cmd, Command(None))

            after_files = os.listdir(tmpdir)

# Generated at 2022-06-24 06:17:46.111102
# Unit test for function match
def test_match():
    from thefuck.rules.unzip_dot_dot import match
    from tests.utils import Command
    assert match(Command("unzip ../test.zip"))
    assert not match(Command("unzip -d ../test.zip"))
    assert not match(Command("unzip -d test.zip"))
    assert not match(Command("unzip /tmp/test.zip"))
    assert not match(Command("unzip test.zip"))
    assert not match(Command("zip -d test.zip"))
    assert match(Command("unzip test"))


# Generated at 2022-06-24 06:17:50.881851
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command('unzip file.zip') == 'unzip -d file file.zip'
	assert get_new_command('unzip file.tar') == 'unzip -d file file.tar'

# Generated at 2022-06-24 06:17:59.926956
# Unit test for function get_new_command
def test_get_new_command():
    # unzip a-file.zip
    command = 'unzip a-file.zip'
    assert get_new_command(Command(command, None)) == 'unzip -d a-file a-file.zip'

    # unzip a-file
    command = 'unzip a-file'
    assert get_new_command(Command(command, None)) == 'unzip -d a-file a-file.zip'

    # unzip -o a-file.zip
    command = 'unzip -o a-file.zip'
    assert get_new_command(Command(command, None)) == 'unzip -o -d a-file a-file.zip'

    # unzip -o a-file
    command = 'unzip -o a-file'

# Generated at 2022-06-24 06:18:06.157592
# Unit test for function side_effect
def test_side_effect():
    # Create file and directory to test 'side_effect' function
    file = open('test_file', 'w+')
    file.close()
    os.mkdir('test_directory')
    old_cmd = "unzip file.zip"
    command = "unzip -d file file.zip"
    side_effect(old_cmd, command)
    # Checking that 'test_file' and 'test_directory' have been removed
    assert not os.path.isfile('test_file')
    assert not os.path.isdir('test_directory')

# Generated at 2022-06-24 06:18:13.206313
# Unit test for function side_effect
def test_side_effect():
    os.mkdir('/tmp/test_zip')
    with open('/tmp/test_zip/test.txt', 'w') as tmp_file:
        tmp_file.write('test_text')

    with zipfile.ZipFile('/tmp/test_zip.zip', 'w') as archive:
        archive.write('/tmp/test_zip/test.txt')

    old_cmd = type('cmd', (), {
        'script': u'unzip /tmp/test_zip.zip',
        'script_parts': ['unzip', '/tmp/test_zip.zip', '-d', '/tmp/test_zip.zip']
    })

    side_effect(old_cmd, 'unzip /tmp/test_zip.zip -d /tmp/test_zip.zip')

# Generated at 2022-06-24 06:18:14.966266
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip test.zip', '$')) == 'unzip -d test test.zip'

# Generated at 2022-06-24 06:18:25.179080
# Unit test for function match
def test_match():
    assert _is_bad_zip(
        os.path.join(os.path.dirname(__file__), u'fixtures', 'bad.zip'))
    assert not _is_bad_zip(
        os.path.join(os.path.dirname(__file__),
                     u'fixtures', 'good.zip'))

    assert match(Command('unzip bad.zip', '', ''))
    assert not match(Command('unzip -d good.zip', '', ''))
    assert not match(Command('unzap evil.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d folder/file.zip', '', ''))
    assert not match(Command('unzip file.zip', '', ''))


# Generated at 2022-06-24 06:18:36.804242
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.extract_archive import get_new_command
    assert get_new_command('') == ' unzip -d  '
    assert get_new_command('error:  command failed') == ' unzip -d  '
    assert get_new_command('unzip charlie.zip') == 'unzip -d charlie'
    assert get_new_command('unzip -a alpha.zip') == 'unzip -a -d alpha'
    assert get_new_command('unzip alpha.zip beta.zip') == 'unzip -d alpha'
    assert get_new_command('unzip -a alpha.zip beta.zip') == 'unzip -a -d alpha'
    assert get_new_command('unzip alpha.zip -d beta') == 'unzip -d alpha'
    assert get_new

# Generated at 2022-06-24 06:18:38.577978
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('unzip file.zip', 
            ['unzip:  cannot find or open file.zip, file.zip.zip or file.zip.ZIP.'])) == u'unzip file.zip -d file'



# Generated at 2022-06-24 06:18:47.428302
# Unit test for function match
def test_match():
    from thefuck.rules.unzip_to_current_directory import match
    from thefuck.types import Command
    assert match(Command('unzip fck.zip', ''))
    assert match(Command('unzip *.zip', ''))
    assert not match(Command('unzip -d fck.zip', ''))
    assert not match(Command('unzip -lol fck.zip', ''))
    assert not match(Command('unzip -d fck', ''))
    assert not match(Command('unzip -d fck', ''))
    assert not match(Command('unzip -d fck.rar', ''))
    assert not match(Command('unzip -d fck.rar', ''))


# Generated at 2022-06-24 06:18:50.820602
# Unit test for function get_new_command
def test_get_new_command():
    script = u'unzip dir/file.zip'
    command = u'unzip -d dir/file file.zip'
    assert get_new_command(shell.and_(script, '', command)) == command

# Generated at 2022-06-24 06:18:58.244038
# Unit test for function match
def test_match():
    assert _zip_file('unzip file1.zip') == 'file1.zip'
    assert _zip_file('unzip file.zip file2.zip') == 'file.zip'
    assert _zip_file('unzip file') == 'file.zip'
    assert _zip_file('unzip -l file.zip') == 'file.zip'
    assert _zip_file('unzip -t file.zip') == 'file.zip'
    assert _zip_file('unzip -caqdf2 file.zip') == 'file.zip'
    assert _zip_file('unzip -caqdf2 file') == 'file.zip'
    assert not match('unzip -t file.zip')
    assert not match('unzip -d dir file.zip')

# Generated at 2022-06-24 06:19:04.691172
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create temporary files
    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    tmpfile.close()
    tmpdirlink = os.path.join(tmpdir, 'dirlink')
    os.makedirs(tmpdirlink)
    tmpfilelink = os.path.join(tmpdirlink, 'filelink')
    os.symlink(tmpfile.name, tmpfilelink)

    command = Command(script=u'unzip {} {}'.format(tmpfile.name, tmpfilelink),
                      stdout=u'',
                      stderr=u'')
    side_effect(command, get_new_command(command))

    # Check if directory and link is gone

# Generated at 2022-06-24 06:19:12.002255
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('unzip test.zip') == 'unzip test.zip -d test'
    assert get_new_command('unzip test.zip test') == 'unzip test.zip -d test'
    assert get_new_command('unzip test.zip test.txt') == 'unzip test.zip -d test'
    assert get_new_command('unzip test.zip test/') == 'unzip test.zip -d test'
    assert get_new_command('unzip test.zip test/file') == 'unzip test.zip test/file -d test'
    assert get_new_command('unzip test.zip test/file a') == 'unzip test.zip -d test'

# Generated at 2022-06-24 06:19:20.517275
# Unit test for function match
def test_match():
    script = "unzip test.zip"
    command = type('obj', (object,), {'script': script})
    assert match(command) == False

    script = "unzip -d test.zip"
    command = type('obj', (object,), {'script': script})
    assert match(command) == False

    script = "unzip test.zip file1 file2"
    command = type('obj', (object,), {'script': script})
    assert match(command) == False

    script = "unzip test.zip file1 file2"
    command = type('obj', (object,), {'script': script})
    assert match(command) == False

    script = "unzip -d test.zip"
    command = type('obj', (object,), {'script': script})
    assert match(command)

# Generated at 2022-06-24 06:19:24.671093
# Unit test for function match
def test_match():
    from thefuck.types import Command

    assert not match(Command('unzip -d a.zip b.zip', ''))
    assert match(Command('unzip a.zip b.zip', ''))
    assert match(Command('$ unzip a.zip b.zip', ''))


# Generated at 2022-06-24 06:19:33.669225
# Unit test for function side_effect
def test_side_effect():
    # Directory should not be removed after testing
    test_dir_name = 'test_dir'
    os.mkdir(test_dir_name)
    # File should be removed after testing
    test_file_name = 'test_file'
    with open(test_file_name, 'w+') as test_file:
        test_file.write('test')
    zip_test_file_name = 'test.zip'
    zip = zipfile.ZipFile(zip_test_file_name, 'w+')
    zip.write(test_file_name)
    zip.close()
    os.chdir('..')

# Generated at 2022-06-24 06:19:39.021628
# Unit test for function match
def test_match():
    assert match(Command('unzip file.ZIP', None, None))
    assert match(Command('unzip file.zip', None, None))
    assert match(Command('unzip -d dir file.zip', None, None))
    assert match(Command('unzip -d dir file.zip file2.zip file3.zip', None, None))
    assert not match(Command('unzip file.rar', None, None))
    assert not match(Command('unzip -d dir file.zip file2.zip file3.zip', None, None))

# Generated at 2022-06-24 06:19:44.716133
# Unit test for function match
def test_match():
    # this is a bad zip file
    assert match(Command('unzip a.zip'))
    # this is a bad zip file
    assert match(Command('unzip b.zip'))
    # this is a bad zip file
    assert match(Command('unzip c.zip'))
    # this is a bad zip file
    assert match(Command('unzip a'))
    # this is a bad zip file
    assert match(Command('unzip b'))
    # this is a bad zip file
    assert match(Command('unzip c'))
    # this is a bad zip file
    assert match(Command('unzip a.zip firstsecond.py'))
    # this is a bad zip file
    assert match(Command('unzip b.zip first.py second.py'))
    # this is a bad zip file

# Generated at 2022-06-24 06:19:49.571500
# Unit test for function match
def test_match():
    assert match(Command('unzip lol.zip', '', stderr='',
                        stdout='error:  invalid command arguments'))

    assert not match(Command('unzip -d lol.zip', '', stderr='',
                             stdout='error:  invalid command arguments'))

    assert not match(Command('unzip -d lol.zip', '', stderr='',
                         stdout=''))


# Generated at 2022-06-24 06:19:56.325092
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command('unzip test.zip')
    assert get_new_command(cmd) == 'unzip -d test test.zip'
    cmd = Command('unzip test_no_dot_zip')
    assert get_new_command(cmd) == 'unzip -d test_no_dot_zip test_no_dot_zip.zip'
    cmd = Command('unzip test.zip test1.zip')
    assert get_new_command(cmd) == 'unzip -d test test.zip'
    cmd = Command('unzip test.zip test1.zip test2.zip')
    assert get_new_command(cmd) == 'unzip -d test test.zip'
    cmd = Command('unzip test')
    assert get_new_command(cmd) == 'unzip -d test test.zip'

# Generated at 2022-06-24 06:20:07.275109
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

    files = list()
    cwd = os.getcwd()
    tmp_dir = tempfile.mkdtemp()
    tmp_file_1 = os.path.join(tmp_dir, 'foo1')
    tmp_file_2 = os.path.join(tmp_dir, 'foo2')
    tmp_file_3 = os.path.join(tmp_dir, 'foo3')

    files.append(tmp_file_1)
    files.append(tmp_file_2)
    files.append(tmp_file_3)

    with open(tmp_file_1, 'w') as f:
        f.write('foo1')
    with open(tmp_file_2, 'w') as f:
        f.write('foo2')
   

# Generated at 2022-06-24 06:20:15.417527
# Unit test for function side_effect
def test_side_effect():
    zip = zipfile.ZipFile('zip.zip', 'w')
    zip.writestr('file.txt', 'text')
    zip.close()

    with open('file.txt', 'w') as f:
        f.write('text')

    os.mkdir('dir')
    os.mkdir('dir/subdir')
    os.mkdir('dir/subdir/subsubdir')
    with open('dir/subdir/subsubdir/file2.txt', 'w') as f:
        f.write('text')

    side_effect(1, 1)

    assert not os.path.exists('file.txt')
    assert not os.path.exists('dir')
    assert os.path.exists('file.txt.zip')

    os.remove('file.txt.zip')

# Generated at 2022-06-24 06:20:19.904903
# Unit test for function side_effect
def test_side_effect():
    from tests.utils import Command

    with zipfile.ZipFile('files/bad_zip.zip', 'w') as zip_file:
        zip_file.write('files/bad_zip')

    with open('files/bad_zip', 'w+') as _file:
        print >> _file, 'test'

    old_cmd = Command('unzip files/bad_zip.zip')
    side_effect(old_cmd, old_cmd)
    with open('files/bad_zip') as _file:
        assert _file.readline() == 'test'


# Generated at 2022-06-24 06:20:27.355690
# Unit test for function match
def test_match():
    assert match(Command(script='unzip file.zip')) == False
    assert match(Command(script='unzip -d file.zip')) == False
    assert match(Command(script='unzip file.zip file.zip')) == False
    assert match(Command(script='unzip file.zip file')) == False
    assert match(Command(script='unzip file -d file.zip')) == False
    assert match(Command(script='unzip file.zip -d file.zip')) == False


# Unit tests for function get_new_command

# Generated at 2022-06-24 06:20:34.979050
# Unit test for function side_effect
def test_side_effect():
    side_effect(TestCommand(script='unzip /tmp/file.zip',
                           script_parts=['unzip', '/tmp/file.zip'],
                           command='unzip /tmp/file.zip'),
                TestCommand(script='unzip -d /tmp/file /tmp/file.zip',
                            script_parts=['unzip', '-d', '/tmp/file', '/tmp/file.zip']))



# Generated at 2022-06-24 06:20:39.837860
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {'script_parts': ['unzip', 'file.zip']})
    assert get_new_command(command) == u'unzip -d file'

    command = type('Command', (object,), {'script_parts': ['unzip', '-l', 'file.zip']})
    assert get_new_command(command) == u'unzip -l -d file'

# Generated at 2022-06-24 06:20:44.607181
# Unit test for function side_effect
def test_side_effect():
    files = ['file1', 'file2']
    test_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test')
    with zipfile.ZipFile(test_dir + '/test.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for file in files:
            archive.write(test_dir + '/' + file, arcname=file)
    with zipfile.ZipFile(test_dir + '/test.zip', 'r') as archive:
        archive.extractall(test_dir)
    assert 8 == len(os.listdir(test_dir))
    side_effect(None, None)
    assert 4 == len(os.listdir(test_dir))
    os.remove(test_dir + '/test.zip')

# Generated at 2022-06-24 06:20:49.811098
# Unit test for function get_new_command
def test_get_new_command():
    """
    Generate new command from the old one
    """
    from thefuck.rules.unzip_the_wrong_file import get_new_command

    assert u'unzip -d foo bar.zip' == get_new_command(
        shell.and_('unzip bar.zip', 'unzip -d foo bar.zip'))

# Generated at 2022-06-24 06:20:51.901331
# Unit test for function get_new_command
def test_get_new_command():
    # Test if the function returns the command with the -d flag
    command = 'unzip -q foo.zip'
    output = u'unzip -q -d {} foo.zip'.format(shell.quote('foo'))

    assert get_new_command(shell.and_(command)) == output

# Generated at 2022-06-24 06:20:55.402709
# Unit test for function side_effect
def test_side_effect():
    """
    Funcion side_effect creates a file and a directory and then
    test the removal of all of them
    """
    file = open('dummy_file', 'w')
    file.write('dummy_content')
    file.close()
    os.mkdir('dummy_directory')
    command = type('', (), dict(script='unzip dummy_file.zip', script_parts=['unzip', 'dummy_file.zip']))()
    side_effect(command, command)
    assert os.path.exists('dummy_file') == False
    assert os.path.exists('dummy_directory') == True
    os.remove('dummy_directory')

# Generated at 2022-06-24 06:21:01.539890
# Unit test for function side_effect
def test_side_effect():
    command = Command('unzip test_file.zip test.py')
    archive = zipfile.ZipFile('test_file.zip', 'w')
    archive.writestr('test.py', 'test')
    archive.close()
    side_effect(command, command)
    assert os.path.exists('test.py')
    os.remove('test_file.zip')
    os.remove('test.py')

# Generated at 2022-06-24 06:21:10.962400
# Unit test for function side_effect
def test_side_effect():
    old_cmd = 'unzip foo.zip'
    command = 'unzip -d foo foo.zip'
    cwd = os.getcwd()

# Generated at 2022-06-24 06:21:15.709013
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('''unzip file.zip''') == '''unzip -d file file.zip'''
    assert get_new_command('''unzip -o -P 123 file.zip''') == '''unzip -o -P 123 -d file file.zip'''
    assert get_new_command('''unzip -l -q test.zip''') == '''unzip -l -q -d test test.zip'''

# Generated at 2022-06-24 06:21:18.639624
# Unit test for function match
def test_match():
    script = 'unzip file1 file2'
    command = '{}'.format(script)
    output = 'file1  file1.zip'
    side_effect = 'file1'
    assert match(command, output, side_effect)

# Generated at 2022-06-24 06:21:25.171750
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -j file.zip', '', ''))
    assert not match(Command('unzip file.tar.gz', '', ''))
    assert match(Command('unzip file.zip file2.zip', '', ''))
    assert not match(Command('unzip file.zip file2.zip file3.zip', '', ''))
    assert not match(Command('unzip -fo file.zip', '', ''))
    assert match(Command('unzip file.zip file2.zip -fo', '', ''))



# Generated at 2022-06-24 06:21:27.209446
# Unit test for function side_effect
def test_side_effect():
    assert side_effect(
        'unzip archive.zip',
        'unzip archive.zip -d folder') is None


# Generated at 2022-06-24 06:21:38.015201
# Unit test for function match
def test_match():
    assert match(Command("unzip 1.zip", "", "")) == False
    assert match(Command("unzip *.zip", "", "")) == False
    assert match(Command("unzip a.zip b.zip c.zip", "", "")) == False
    assert match(Command("unzip a.zip -d foo", "", "")) == False
    assert match(Command("unzip -l a.zip", "", "")) == False
    assert match(Command("unzip -l *.zip", "", "")) == False
    assert match(Command("unzip -l a.zip b.zip c.zip", "", "")) == False
    assert match(Command("unzip -l a.zip -d foo", "", "")) == False
    assert match(Command("unzip -v a.zip -d foo", "", "")) == False

# Generated at 2022-06-24 06:21:46.082965
# Unit test for function side_effect
def test_side_effect():
    import os
    import tempfile
    import shutil
    from zipfile import ZipFile
    from zipfile import ZIP_DEFLATED
    tempdir = tempfile.gettempdir()
    dirname = os.path.join(tempdir, "test_unzip")
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    archive_name = os.path.join(tempdir, "test.zip")
    file_name = os.path.join(dirname, "test.txt")
    with open(file_name, "w") as f:
        f.write("test")
    with ZipFile(archive_name, "w", ZIP_DEFLATED) as archive:
        archive.write(file_name, "test.txt")
    os.chdir(dirname)

# Generated at 2022-06-24 06:21:49.438649
# Unit test for function get_new_command
def test_get_new_command():
    command = shell.And('script', '-e', 'file.zip')
    assert get_new_command(command) == 'script -e file.zip -d file'

# Generated at 2022-06-24 06:21:59.965043
# Unit test for function side_effect
def test_side_effect():
    path = os.path.abspath("test_side_effect")

# Generated at 2022-06-24 06:22:04.129319
# Unit test for function side_effect
def test_side_effect():
    fake_old_cmd = type('fake', (object,),
                        {'script': 'unzip -l Archive.zip'})
    fake_cmd = type('fake', (object,),
                     {'script': 'unzip -l Archive.zip'})
    side_effect(fake_old_cmd, fake_cmd)


priority = 2000

# Generated at 2022-06-24 06:22:08.162539
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command("unzip -aaf", '')) == "unzip -aaf -d unzip"



# Generated at 2022-06-24 06:22:11.993092
# Unit test for function match
def test_match():
    assert match(Command('unzip filename.zip'))
    assert match(Command('unzip filename.zip -c'))
    assert match(Command('unzip -c filename.zip'))
    assert not match(Command('unzip filename.zip -d'))
    assert not match(Command('unzip filename.zip -d folder'))
    assert not match(Command('zip filename.zip -d folder'))


# Generated at 2022-06-24 06:22:20.036212
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('unzip badzip.zip') == 'unzip -d badzip badzip.zip'
    assert get_new_command('unzip badzip.zip -o') == 'unzip -d badzip badzip.zip -o'
    assert get_new_command('unzip badzip.zip file') == 'unzip -d badzip badzip.zip file'
    assert get_new_command('unzip badzip') == 'unzip -d badzip badzip.zip'
    assert get_new_command('unzip -o badzip.zip -d ~/path') == 'unzip -o -d badzip ~/path badzip.zip'

# Generated at 2022-06-24 06:22:22.857177
# Unit test for function match
def test_match():
    command = 'unzip test.zip'
    assert not match(command)
    with open('test.zip', 'w') as f:
        f.write('test')
    assert match(command)



# Generated at 2022-06-24 06:22:32.631213
# Unit test for function match
def test_match():
    assert match(Command('unzip not_existing.zip', '', '/usr/bin/unzip'))
    assert not match(Command(
        'unzip not_existing.zip', '', '/usr/bin/unzip',
        stderr='unzip:  cannot find or open not_existing.zip, not_existing.zip.zip or'
               ' not_existing.zip.ZIP.'))
    assert match(Command(
        'unzip existing.zip', '', '/usr/bin/unzip',
        stderr='unzip:  cannot find or open existing.zip, existing.zip.zip or'
               ' existing.zip.ZIP.'))
    assert match(Command('unzip -d dir_to_unpack not_existing.zip', '',
                         '/usr/bin/unzip'))
    assert not match

# Generated at 2022-06-24 06:22:35.370023
# Unit test for function get_new_command
def test_get_new_command():
    old_cmd = 'unzip file1.zip file2.zip'
    command = get_new_command(old_cmd)
    assert command == 'unzip -d file1 file1.zip file2.zip'

# Generated at 2022-06-24 06:22:43.244817
# Unit test for function side_effect
def test_side_effect():
    from tempfile import mkdtemp
    from shutil import rmtree

    old_cwd = os.getcwd()
    try:
        test_dir = mkdtemp(prefix='thefuck-test-unzip-')
        os.chdir(test_dir)

        open('test.zip', 'w+').close()
        open('test.txt', 'w+').close()

        from thefuck.rules.unzip import side_effect
        side_effect(None, None)

        assert not os.path.exists('test.zip')
        assert not os.path.exists('test.txt')
    except OSError as e:
        raise OSError('Unable to delete folder {}: {}'.format(test_dir, e.strerror))

# Generated at 2022-06-24 06:22:49.366052
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.bad_zipfile import get_new_command
    old_cmd = 'unzip test1.zip'
    command = get_new_command(old_cmd)
    assert command == 'unzip -d test1 test1.zip'

    old_cmd = 'unzip test2.zip'
    command = get_new_command(old_cmd)
    assert command == 'unzip -d test2 test2.zip'

# Generated at 2022-06-24 06:22:53.990967
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.unzip_to_current_dir import get_new_command
    actual = get_new_command(Command(
        script='unzip my_archive.zip',
        stderr='error',
        stdout=''))
    expected = 'unzip -d my_archive my_archive.zip'
    assert actual == expected



# Generated at 2022-06-24 06:23:04.704596
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip -j -d test/ dir/file.zip', '', '')) == 'unzip -j -d test/ dir/file.zip'
    assert get_new_command(Command('unzip -j -d test/ -d dir/file.zip', '', '')) == 'unzip -j -d test/ -d dir/file.zip'
    assert get_new_command(Command('unzip -j -d test/ file.zip', '', '')) == 'unzip -j -d test/ file.zip'
    assert get_new_command(Command('unzip -j -d test/ file', '', '')) == 'unzip -j -d test/ file'

# Generated at 2022-06-24 06:23:12.121925
# Unit test for function side_effect
def test_side_effect():
    os.mkdir('test_side_effect_folder')
    os.mkdir('another_folder')
    with open('test_side_effect_folder/test_side_effect_file', 'w') as f:
        f.write('Test file')

    with zipfile.ZipFile('test.zip', 'w') as z:
        z.write('test_side_effect_folder/test_side_effect_file')

    zip_command = Command(script='unzip test.zip',
                          stdout='Archive:  test.zip\n   creating: test_side_effect_folder/\n  inflating: test_side_effect_folder/test_side_effect_file\n',
                          stderr='')

    side_effect(zip_command, 'unzip -d folder test.zip')

   

# Generated at 2022-06-24 06:23:15.451343
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(_make_mock_command('unzip script.zip')) ==\
        'unzip -d script script.zip'



# Generated at 2022-06-24 06:23:19.920115
# Unit test for function match
def test_match():
    command = type('cmd', (object,), {'script': 'unzip x.zip'})()
    assert not match(command)
    command = type('cmd', (object,), {'script': 'unzip x.zip -d y'})()
    assert not match(command)


# Generated at 2022-06-24 06:23:29.448141
# Unit test for function side_effect
def test_side_effect():
    # create test file and directory
    os.makedirs('test')
    test_file = open('test.txt', 'w')
    test_file.write('test')
    test_file.close()

    # create zip archive containing test file and directory
    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.write('test.txt')
        archive.write('test')

    # run unzip without the -d flag
    old_command = u'unzip test.zip'
    run(old_command.split())

    # side effect deletes test file and directory because they are located
    # inside the current directory
    side_effect(old_command, u'unzip -d test test.zip'.split())
    assert(not os.path.exists('test.txt'))

# Generated at 2022-06-24 06:23:32.393823
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip'))
    assert match(Command('unzip test'))
    assert match(Command('unzip -o test.zip'))
    assert not match(Command('unzip -d test.zip'))
    assert not match(Command('unzip -t test.zip'))


# Generated at 2022-06-24 06:23:37.338408
# Unit test for function match
def test_match():
    assert match(Command('unzip filename.zip', '', ''))
    assert not match(Command('unzip filename', '', ''))
    assert not match(Command('unzip -d filename filename', '', ''))
    assert match(Command('unzip -l filename', '', ''))
    assert match(Command('unzip -z filename', '', ''))

# Generated at 2022-06-24 06:23:40.113576
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('unzip zipfile.zip', ''))
    assert not match(Command('unzip -d zipfile.zip', ''))



# Generated at 2022-06-24 06:23:44.221237
# Unit test for function get_new_command
def test_get_new_command():
    command = MagicMock()
    command.script = 'unzip -d /my/path/to/directory -j myarchive.zip'
    command.script_parts = command.script.split()

    assert get_new_command(command) == u'unzip -d myarchive -j myarchive.zip'



# Generated at 2022-06-24 06:23:49.731678
# Unit test for function match
def test_match():
    assert match('unzip file.zip') != None
    assert match('unzip file.zip foo') != None
    assert match('unzip file.zip foo.csv bar.txt') != None
    assert match('unzip file foo') == None
    assert match('unzip file') == None
    assert match('unzip file.zip -d foo') == None



# Generated at 2022-06-24 06:24:01.128438
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.rules.unzip import side_effect
    import os
    import zipfile

    zip_file = os.path.join(os.getcwd(), 'test.zip')
    file_to_extract = os.path.join(os.getcwd(), 'file_to_extract')
    file_to_extract_2 = os.path.join(os.getcwd(), 'file_to_extract_2')
    with open(file_to_extract, "w") as f:
        f.write("1")
    with open(file_to_extract_2, "w") as f:
        f.write("2")

# Generated at 2022-06-24 06:24:05.600223
# Unit test for function get_new_command
def test_get_new_command():
    assert 'unzip -d file zipfile.zip' == get_new_command('unzip zipfile.zip')

# Generated at 2022-06-24 06:24:14.455554
# Unit test for function side_effect
def test_side_effect():
    # generate a test zip file
    import shutil
    import tempfile
    import os
    import zipfile

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-24 06:24:16.572634
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('unzip file.zip', '')) == u'unzip -d file'

# Generated at 2022-06-24 06:24:27.268809
# Unit test for function side_effect
def test_side_effect():
    from shutil import rmtree
    from tempfile import mkdtemp
    from os import chdir
    from os.path import isdir, isfile
    import glob

    tmpdir = mkdtemp()
    chdir(tmpdir)
    open('test_side_effect', 'w').close()
    open('afile', 'w').close()
    os.mkdir('adir')
    os.mkdir('bar')
    open('bar/baz', 'w').close()

    files = ['test_side_effect', 'bar']
    command = u'unzip {} -d {}'.format(shell.and_(' '.join(files)),
                                       'foobar')
    old_cmd = u'unzip {}'.format(shell.and_(' '.join(files)))

# Generated at 2022-06-24 06:24:33.258201
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', '')) == False
    assert match(Command('unzip -d file.zip', '', '')) == False
    assert match(Command('unzip -d file.zip', '', '')) == False
    assert match(Command('unzip file.zip', '', '')) == False
    assert match(Command('unzip file', '', '')) == False
    assert match(Command('unzip file.zip', '', '')) == False
    assert match(Command('unzip file.zip', '', '')) == False
