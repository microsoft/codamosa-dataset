

# Generated at 2022-06-22 01:23:17.060949
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import os.path

    test_file = os.path.join(tempfile.gettempdir(), "test")
    zip_file = os.path.join(tempfile.gettempdir(), "test.zip")

    test_content = "this is a test"
    compressed_file = zipfile.ZipFile(zip_file, 'w')
    compressed_file.writestr('file.txt', test_content)
    compressed_file.close()

    # First try without side_effect
    with open(test_file, 'w') as f:
        f.write(test_content)

    old_cmd = "unzip {}".format(zip_file)
    new_cmd = get_new_command(old_cmd)

    with open(test_file, 'r') as f:
        assert f

# Generated at 2022-06-22 01:23:22.050660
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip file.zip', '')) \
        == "unzip file.zip -d 'file'"
    assert get_new_command(Command('unzip file.zip file2.zip', '')) \
        == "unzip file.zip file2.zip -d 'file'"
    assert get_new_command(Command('unzip file.zip -x file.txt', '')) \
        == "unzip file.zip -x file.txt -d 'file'"

# Generated at 2022-06-22 01:23:30.502761
# Unit test for function side_effect
def test_side_effect():
    import os
    import tempfile
    # create a directory
    tempdir = tempfile.mkdtemp()
    os.chdir(tempdir)
    fulldir = os.path.abspath(os.path.join(tempdir, 'dir'))
    os.mkdir(fulldir)
    # create a file and write some data to it
    fullfile = os.path.abspath(os.path.join(tempdir, 'file'))
    with open(fullfile, 'w') as f:
        f.write('File to be unzipped')
    # create a zip file and write the file and direcotry to it
    dirinzip = os.path.join('dir', 'dir')
    fileinzip = os.path.join('dir', 'file')

# Generated at 2022-06-22 01:23:38.450284
# Unit test for function side_effect
def test_side_effect():
    shell = Mock()
    shell.quote = lambda s: s
    old_cmd = Mock(script_parts=['unzip', 'test.zip', '-x', 'exclude.txt'])
    cmd = get_new_command(old_cmd)
    side_effect(old_cmd, cmd)
    expected_calls = [call(['unzip', '-d', 'test', '-x', 'exclude.txt'])]
    assert shell.execute.call_args_list == expected_calls

# Generated at 2022-06-22 01:23:46.247830
# Unit test for function match
def test_match():
    # Case when the zip file contains only one file
    assert match(Command('unzip test.zip', '')) is False

    # Case when the zip file contains more than one file
    with tempfile.NamedTemporaryFile('w') as archive, \
            tempfile.NamedTemporaryFile('w') as file_in_archive, \
            tempfile.NamedTemporaryFile('w') as file_in_archive2:
        archive.write(file_in_archive.read())
        archive.write(file_in_archive2.read())
        archive.flush()
        assert match(Command('unzip {}'.format(archive.name), '')) is True



# Generated at 2022-06-22 01:23:58.439135
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('unzip test.zip',
                             'Archive:  test.zip\n'
                             '  End-of-central-directory signature not found.  Either this file is not\n'
                             '  a zipfile, or it constitutes one disk of a multi-part archive.  In the\n'
                             '  latter case the central directory and zipfile comment will be found on\n'
                             '  the last disk(s) of this archive.\n',
                             '', 1)) \
                        == 'unzip -d test test.zip'

# Generated at 2022-06-22 01:24:10.912089
# Unit test for function match
def test_match():
    # Normal case
    script = 'unzip test_thefuck.zip'
    command = Command(script, '', '')
    assert match(command) is False

    # Case where -d flag is present in command
    script = 'unzip -d test_thefuck.zip'
    command = Command(script, '', '')
    assert match(command) is False

    # Case where unzip command is not used
    script = 'tar -xzf xzfile.tar.gz'
    command = Command(script, '', '')
    assert match(command) is False

    # Case where empty command is passed
    script = ''
    command = Command(script, '', '')
    assert match(command) is False

    # Case where unzip file does not exist

# Generated at 2022-06-22 01:24:13.891430
# Unit test for function get_new_command
def test_get_new_command():
    old_cmd = u'unzip test.zip'
    command = u'unzip test.zip'
    assert get_new_command(old_cmd) == u'unzip -d test test.zip'

# Generated at 2022-06-22 01:24:18.044659
# Unit test for function match
def test_match():
    assert match(Command('unzip hello_world.zip', ''))
    assert match(Command('unzip -a hello_world', ''))
    assert not match(Command('unzip hello_world.zip -d hello_world', ''))
    assert not match(Command('unzip -a hello_world -d hello_world', ''))



# Generated at 2022-06-22 01:24:30.660221
# Unit test for function side_effect
def test_side_effect():

    import tempfile

    curr_dir = os.getcwd()
    tmp_dir = tempfile.TemporaryDirectory()

    # change working directory
    os.chdir(tmp_dir.name)

    # create tmp file
    open("tmp_file", "a").close()

    # assert tmp file is present
    assert os.path.exists("tmp_file")

    # assert tmp file is not present in the current directory
    assert not os.path.exists(curr_dir + "/tmp_file")

    # create zip file with a directory containing the tmp file
    with zipfile.ZipFile("tmp_archive.zip", "w") as zip:
        zip.write("tmp_file", arcname="tmp_dir/tmp_file")

    # assert tmp archive exists

# Generated at 2022-06-22 01:24:49.265720
# Unit test for function side_effect
def test_side_effect():
    os.system('mkdir temp && cd temp && mkdir testdir && touch testdir/file1 && touch testdir/file2 && touch file3 && touch file4 && touch file5')
    os.system('echo "Hello, World!" | gzip -c > testdir/file1.gz')
    os.system('echo "Hello, World!" | gzip -c > file4.gz')
    os.system('echo "Hello, World!" | gzip -c > file5.gz')
    os.system('zip -r test.zip testdir')
    os.system('zip test.zip file3')
    old_cmd = 'unzip test.zip'
    side_effect(old_cmd, 'unzip -d test.zip')
    assert os.path.isdir('temp/testdir/testdir')
    assert os.path

# Generated at 2022-06-22 01:24:50.485137
# Unit test for function side_effect
def test_side_effect():
    pass

# Generated at 2022-06-22 01:24:56.397998
# Unit test for function match
def test_match():
    assert match(Command('unzip f.zip a b', 5000)) == True
    assert match(Command('unzip f.zip -d x', 5000)) == False
    assert match(Command('unzip f', 5000)) == True
    assert match(Command('unzip xxx', 5000)) == False
    assert match(Command('unzip f.zip', 5000)) == True


# Generated at 2022-06-22 01:25:00.906041
# Unit test for function match
def test_match():
    assert match(Command('unzip /path/to/archive.zip', ''))
    assert match(Command('unzip /path/to/archive.zip foo.txt', ''))
    assert not match(Command('unzip -d /path/to/archive.zip', ''))
    assert not match(Command('unzip', ''))



# Generated at 2022-06-22 01:25:03.795791
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip test.zip', '')) == 'unzip -d test test.zip'


# Generated at 2022-06-22 01:25:13.380208
# Unit test for function side_effect
def test_side_effect():
    file1 = 'test.txt'
    file2 = 'test2.txt'
    with open(file1, 'w') as f:
        f.write('toto')
    with open(file2, 'w') as f:
        f.write('toto')
    cmd = shell.And('unzip test.zip', 'unzip test.zip -d test')

    assert os.path.isfile(file1)
    assert os.path.isfile(file2)
    side_effect(cmd, None)
    assert not os.path.isfile(file1)
    assert os.path.isfile(file2)
    os.remove(file2)

# Generated at 2022-06-22 01:25:15.202213
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip test.zip')) == 'unzip -d test test.zip'

# Generated at 2022-06-22 01:25:27.249619
# Unit test for function match
def test_match():
    # is_bad_zip()
    assert _is_bad_zip('test_utils.py') == False
    assert _is_bad_zip('thefuck/utils.py') == False
    # zip_file()
    assert _zip_file('unzip test.zip test.zip') == 'test.zip'
    assert _zip_file('unzip test.txt test.txt') == 'test.txt.zip'
    assert _zip_file('unzip test.txt') == None
    # match()
    assert match(command='unzip test.zip') == True
    assert match(command='unzip test.zip -d test') == False
    assert match(command='unzip test.txt') == False
    assert match(command='unzip test.txt -d test') == False

# Generated at 2022-06-22 01:25:36.150802
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip'))
    assert match(Command('unzip /a/b/test.zip'))
    assert match(Command('unzip -x /a/b/test.zip'))
    assert not match(Command('unzip -d /a/b/test.zip'))
    assert not match(Command('unzip -d /a/b/test.zip'))
    assert not match(Command('unzip -x /a/b/test.zip a.txt'))
    assert not match(Command('unzip -x /a/b/test.zip a.txt test2.zip'))
    assert not match(Command('unzip -x /a/b/test.zip test2.zip a.txt'))

# Generated at 2022-06-22 01:25:45.880028
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip file.zip', 'unzip:  cannot find or open file.zip, file.zip.zip or file.zip.ZIP.')) == 'unzip -d file file.zip'
    assert get_new_command(Command('unzip file', 'unzip:  cannot find or open file, file.zip or file.ZIP.')) == 'unzip -d file file'
    assert get_new_command(Command('unzip file.ZIP', 'unzip:  cannot find or open file.ZIP, file.ZIP.zip or file.ZIP.ZIP.')) == 'unzip -d file file.ZIP'


# Generated at 2022-06-22 01:26:01.921473
# Unit test for function match
def test_match():
    file = '/tmp/m1.zip'
    with open(file, 'w') as f:
        f.write('tmp')
    assert _is_bad_zip(file)

# Generated at 2022-06-22 01:26:09.960364
# Unit test for function match
def test_match():
    assert match(Command(script='unzip this.zip',
                         stderr='error:  cannot find zipfile directory in one of this.zip or'
                                '\n                this.zip.zip, and cannot find this.zip.ZIP, period.'))
    assert match(Command(script='unzip this.zip',
                         stderr='error:  cannot find zipfile directory in one of this.zip or'
                                '\n                this.zip.zip, and cannot find this.zip.ZIP, period.'))
    assert match(Command(script='unzip this.zip',
                         stderr='error:  cannot find zipfile directory in one of this.zip or'
                                '\n                this.zip.zip, and cannot find this.zip.ZIP, period.'))

# Generated at 2022-06-22 01:26:13.577798
# Unit test for function get_new_command
def test_get_new_command():
    test_command = "unzip myzip.zip"
    assert get_new_command(test_command) == 'unzip -d myzip'


# Generated at 2022-06-22 01:26:20.644001
# Unit test for function get_new_command
def test_get_new_command():
    oldcmd = "unzip test.zip"
    newcmd = get_new_command(shell.and_('unzip', 'test.zip'))
    assert newcmd == 'unzip -d test test.zip'

    oldcmd = "unzip -n test.zip"
    newcmd = get_new_command(shell.and_('unzip', '-n', 'test.zip'))
    assert newcmd == 'unzip -d test -n test.zip'

# Generated at 2022-06-22 01:26:32.086895
# Unit test for function get_new_command
def test_get_new_command():
    # Case 1: no flags provided
    old_cmd = "unzip file.zip"
    assert get_new_command(old_cmd) == 'unzip -d file file.zip'

    # Case 2: single flag provided
    old_cmd = "unzip file.zip -l"
    assert get_new_command(old_cmd) == 'unzip -d file file.zip -l'

    # Case 3: multiple flags provided
    old_cmd = "unzip file.zip -l -o"
    assert get_new_command(old_cmd) == 'unzip -d file file.zip -l -o'

    # Case 4: flags provided before and after file.zip
    old_cmd = "unzip -l file.zip -o"

# Generated at 2022-06-22 01:26:44.045586
# Unit test for function side_effect
def test_side_effect():
    file_in_current_directory = os.path.join(os.getcwd(), "foo")
    file_outside_current_directory_1 = "/foo"
    file_outside_current_directory_2 = "../foo"
    file_outside_current_directory_3 = "foo/../../../foo"
    goods = [file_in_current_directory, file_outside_current_directory_1,
             file_outside_current_directory_2, file_outside_current_directory_3]
    fs = {file_in_current_directory: "",
          file_outside_current_directory_1: "",
          file_outside_current_directory_2: "",
          file_outside_current_directory_3: ""}
    test_zip = zipfile.ZipFile("test_zip.zip", "w")


# Generated at 2022-06-22 01:26:53.215072
# Unit test for function side_effect
def test_side_effect():
    """
    Test function side_effect()
    """
    import tempfile
    dirpath = tempfile.mkdtemp()
    test_command = "unzip -l {}/test.zip".format(dirpath)
    test_old_cmd = Command(test_command, "", "", 0, None)
    side_effect(test_old_cmd, test_command)
    assert not os.path.exists("{}/test".format(dirpath))
    assert not os.path.exists("{}/test.zip".format(dirpath))
    os.removedirs(dirpath)

# Generated at 2022-06-22 01:27:01.361481
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip foo', '', '', None, 1)) == "unzip -d 'foo'"
    assert get_new_command(Command('unzip foo', '', '', None, 1)) != "unzip foo"
    assert get_new_command(Command('unzip foo.zip', '', '', None, 1)) == "unzip -d 'foo'"
    assert get_new_command(Command('unzip foo.zip', '', '', None, 1)) != "unzip foo.zip"

# Generated at 2022-06-22 01:27:12.553311
# Unit test for function side_effect
def test_side_effect():
    import zipfile
    import tempfile
    import os.path

    dirpath = tempfile.mkdtemp()
    filepath = os.path.join(dirpath, "test.zip")

    # Create the zip file
    with zipfile.ZipFile(filepath, 'w') as zip_file:
        zip_file.writestr('test.txt', 'test')
        zip_file.writestr('subdir/sub.txt', 'subtest')
        zip_file.writestr('subdir/subsubdir/subsub.txt', 'subsubtest')
        zip_file.writestr('subdir/subsubdir/subsubsubdir/subsubsubtest.txt', 'subsubsubtest')

# Generated at 2022-06-22 01:27:21.385981
# Unit test for function match
def test_match():
    from tests.utils import Command

    assert match(Command('unzip', '--help'))
    assert not match(Command('unzip', '-d', 'foo'))
    assert match(Command('unzip', 'foo'))
    assert match(Command('unzip', 'foo.zip'))
    assert not match(Command('unzip', '-d', 'foo', 'foo.zip'))
    assert match(Command('unzip', '-d', 'foo', 'bar'))
    assert not match(Command('unzip', '-d', 'foo', 'bar', 'foo.zip'))



# Generated at 2022-06-22 01:27:58.375048
# Unit test for function get_new_command
def test_get_new_command():
    script = "unzip image.zip"
    new_script = get_new_command(script)
    assert new_script == "unzip -d " + shell.quote('image') + " image.zip"
    script = "unzip image.zip file2.png"
    new_script = get_new_command(script)
    assert new_script == "unzip -d " + shell.quote('image') + " image.zip file2.png"
    script = "unzip -q image.zip file2.png"
    new_script = get_new_command(script)
    assert new_script == "unzip -q -d " + shell.quote('image') + " image.zip file2.png"

# Generated at 2022-06-22 01:28:04.586852
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.unzip_current_dir_rule import get_new_command

    assert get_new_command(u'unzip file.zip') == u'unzip -d file file.zip'
    assert get_new_command(u'unzip file') == u'unzip -d file file.zip'
    assert get_new_command(u'unzip file -x file2.txt') == u'unzip -d file file.zip'

# Generated at 2022-06-22 01:28:09.797760
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import subprocess

    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a zip file
        subprocess.check_call(['zip', '-1', 'test.zip', 'a'])
        # Move it to the temporary directory
        shutil.move('test.zip', tmpdir)

        # Create a file to unzip from the zip file
        with open(os.path.join(tmpdir, 'a'), 'w') as f:
            f.write('a')

        # Make sure to rewrite a
        assert subprocess.check_call(['unzip', 'test.zip'], cwd=tmpdir) == 0
        with open(os.path.join(tmpdir, 'a'), 'r') as f:
            assert f.read() == 'a'

# Generated at 2022-06-22 01:28:18.650155
# Unit test for function get_new_command
def test_get_new_command():
	assert('unzip -d zipped-file zipped-file.zip' == get_new_command(OldCmd('unzip zipped-file.zip', 'test/testfile.txt')))
	assert('unzip -d zipped-file zipped-file.zip.zip' == get_new_command(OldCmd('unzip zipped-file.zip.zip', 'test/testfile.txt')))
	assert('unzip -d /etc/hosts /etc/hosts.zip' == get_new_command(OldCmd('unzip /etc/hosts.zip', 'test/testfile.txt')))
	


# Generated at 2022-06-22 01:28:27.486562
# Unit test for function match
def test_match():
    assert(match(Command(script='unzip -p')) == False)
    assert(match(Command(script='unzip -d')) == False)
    assert(match(Command(script='unzip -d -k')) == False)
    assert(match(Command(script='unzip -d -k test')) == False)
    assert(match(Command(script='unzip -d -k test.zip')) == False)
    assert(match(Command(script='unzip -d -k test.zip file')) == False)
    assert(match(Command(script='unzip -d -k test.zip 1 file2')) == False)
    assert(match(Command(script='unzip -d -k test.zip 1 file2 -x')) == False)

# Generated at 2022-06-22 01:28:38.217900
# Unit test for function side_effect
def test_side_effect():
    files = ['test_file', 'test/test_file_2', '/etc/test']
    files_to_keep = ['/etc/test', 'fake_file']
    files += files_to_keep
    with zipfile.ZipFile('test_file.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for file in files:
            archive.write(file)

    set_up = False
    if not os.path.exists('test'):
        os.mkdir('test')
        set_up = True
    for file in files:
        if os.path.exists(file):
            os.remove(file)
        if os.path.exists(file):
            raise Exception('Unable to remove file {}'.format(file))
        open(file, 'a').close()

# Generated at 2022-06-22 01:28:42.127446
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='unzip file.zip',
                                   stderr=u'unzip:  cannot find or open file.zip, file.zip.zip or file.zip.ZIP.')) == u"unzip -d 'file'"

# Generated at 2022-06-22 01:28:53.756230
# Unit test for function side_effect
def test_side_effect():
    # use a temporary directory
    cwd = os.getcwd()
    tempdir = tempfile.mkdtemp()
    os.chdir(tempdir)
    
    # Create a zip file
    with open(os.path.join(tempdir, 'f1'), 'w') as f1:
        f1.write('content1')
    zf = os.path.join(tempdir, 'myfile.zip')
    pk = zipfile.ZipFile(zf, mode='w')
    pk.write(os.path.join(tempdir, 'f1'))
    pk.close()
    
    # A 'unzip myfile.zip' command
    class UnzipCommand(object):
        def __init__(self):
            self.script = 'unzip myfile.zip'
            self

# Generated at 2022-06-22 01:29:05.548797
# Unit test for function side_effect
def test_side_effect():
    import mock
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        file1_path = os.path.join(temp_dir, 'file1')
        file2_path = os.path.join(temp_dir, 'file2')
        file3_path = os.path.join(temp_dir, 'file3')
        file4_path = os.path.join(temp_dir, 'file3/file4')
        dir1_path = os.path.join(temp_dir, 'dir1')
        os.mkdir(dir1_path)

        with mock.patch.object(shell, 'and_', lambda *args: ' && '.join(args)):
            command = 'unzip {}'.format(file1_path)

# Generated at 2022-06-22 01:29:12.809467
# Unit test for function side_effect
def test_side_effect():
    os.chdir("..")
    test_cmd = Command("unzip test.zip", "")
    assert check_output('ls -l test_zip/myfile.txt',
                        shell=True).decode('utf-8') != ""
    side_effect(test_cmd, test_cmd)
    assert check_output('ls -l test_zip/myfile.txt',
                        shell=True).decode('utf-8') == ""

# Generated at 2022-06-22 01:30:16.232498
# Unit test for function side_effect
def test_side_effect():
    if os.path.isfile('foo'):
        os.remove('foo')
    with open('foo', 'w') as f:
        f.write('foo')

    old_cmd = Command('unzip', 'unzip foo.zip')
    new_cmd = Command('unzip', 'unzip -d foo foo.zip')
    file1 = os.path.join(os.getcwd(), 'foo')
    file2 = os.path.join(os.getcwd(), 'foo/foo')
    with open(file1, 'w') as f:
        f.write('foo')
    with open(file2, 'w') as f:
        f.write('foo2')
    side_effect(old_cmd, new_cmd)
    assert not os.path.isfile(file1)
    assert os

# Generated at 2022-06-22 01:30:28.107131
# Unit test for function match
def test_match():
    assert match(Command('unzip a.zip', '', ''))
    assert match(Command('unzip a b.zip', '', ''))
    assert match(Command('unzip a.zip b.zip', '', ''))
    assert match(Command('unzip a.zip -d c', '', ''))
    assert match(Command('unzip a b.zip -d c', '', ''))
    assert match(Command('unzip a.zip b.zip -d c', '', ''))

    assert not match(Command('unzip -d a.zip', '', ''))
    assert not match(Command('unzip -d b.zip', '', ''))
    assert not match(Command('unzip -d a b.zip', '', ''))

# Generated at 2022-06-22 01:30:39.782975
# Unit test for function side_effect
def test_side_effect():
    os.makedirs('dir')
    with open('dir/file1.txt', 'w+') as f:
        f.write('file1')

    with zipfile.ZipFile('test_zip.zip', 'w') as myzip:
        myzip.write('dir/file1.txt')

    # unzip dir/file1.txt file1.txt
    side_effect(namedtuple('Command', 'script_parts')('unzip dir/file1.txt file1.txt'.split())
                , namedtuple('Command', 'script_parts')('unzip dir/file1.txt file1.txt'.split()))

    assert not os.path.isfile('dir/file1.txt')
    assert os.path.isfile('file1.txt')
    os.remove('file1.txt')

# Generated at 2022-06-22 01:30:49.602622
# Unit test for function match
def test_match():
    assert match(Command(script='unzip foo.zip', stderr=""))
    assert match(Command(script='unzip foo', stderr=""))
    assert match(Command(script='unzip -q foo.zip', stderr=""))
    assert not match(Command(script='unzip foo -d bar', stderr=""))
    assert not match(Command(script='cd /etc && unzip foo', stderr=""))
    assert not match(Command(script='cd /etc && unzip bar/foo.zip', stderr=""))
    assert not match(Command(script='unzip foo.zip', stderr="error"))

# Generated at 2022-06-22 01:30:58.346058
# Unit test for function side_effect
def test_side_effect():
    old_cmd = type('old_cmd', (object,), {
        'script': 'unzip /C/File.zip',
        'script_parts': ['unzip', '/C/File.zip']})()
    command = type('command', (object,), {
        'script': 'unzip /C/File.zip -d D:/NewDir'})()
    side_effect(old_cmd, command)
    assert os.path.exists('/C/File.zip')
    assert not os.path.exists('/C/File')
    assert os.path.exists('D:/NewDir/File')

# Generated at 2022-06-22 01:31:00.096073
# Unit test for function get_new_command
def test_get_new_command():
    assert 'unzip -d test.zip' == get_new_command(
        'unzip test.zip')
    assert 'unzip -d test test.zip' == get_new_command(
        'unzip test test.zip')

# Generated at 2022-06-22 01:31:01.662971
# Unit test for function match
def test_match():
    # Test if the condition is True
    command = "unzip <filename>.zip"
    assert match(command) == False
    assert match(command) == None



# Generated at 2022-06-22 01:31:12.145376
# Unit test for function match
def test_match():
    from tests.utils import Command
    assert match(Command('unzip ~/Documents/Archive.zip'))
    assert match(Command('unzip ~/Documents/Archive'))
    assert match(Command('unzip -i ~/Documents/Archive'))
    assert match(Command('unzip -i ~/Documents/Archive foo'))
    assert match(Command('unzip -i ~/Documents/Archive foo bar'))
    assert not match(Command('unzip ~Documents/Archive'))
    assert not match(Command('unzip ~/Documents/Archive -d ~/Documents'))
    # Archive.zip contains multiple files
    assert match(Command(''))
    assert match(Command(''))
    assert match(Command(''))


# Generated at 2022-06-22 01:31:16.402083
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command.Command('unzip unzip.zip', '', '')) == 'unzip -d unzip unzip.zip'
    assert get_new_command(command.Command('unzip unzip', '', '')) == 'unzip -d unzip unzip'

# Generated at 2022-06-22 01:31:19.574145
# Unit test for function match
def test_match():
    assert match(Command('unzip dest.zip', '', None))
    assert not match(Command('unzip dest.zip -d dest', '', None))
