

# Generated at 2022-06-22 01:23:12.953089
# Unit test for function match
def test_match():
    if os.system('unzip -h > /dev/null 2>&1') != 0:
        return False
    command = Command('unzip file.zip', '', '')
    assert match(command) == False
    command = Command('unzip -d dir file.zip', '', '')
    assert match(command) == False
    command = Command('unzip file', '', '')
    assert match(command) == False



# Generated at 2022-06-22 01:23:21.502905
# Unit test for function match
def test_match():
    good_command = Command()
    good_command.script = 'unzip hack.zip'

    bad_command = Command()
    bad_command.script = 'unzip -d /tmp/hack hack.zip'

    no_command = Command()
    no_command.script = 'unzip -f hack.zip'

    assert not match(good_command)
    assert not match(bad_command)
    assert not match(no_command)

    with open('hack.zip', 'wb') as f:
        f.write(zipfile.ZipFile('tests/hack.zip', 'r').read('hack.zip'))

    assert not match(good_command)
    assert match(bad_command)
    assert not match(no_command)

    os.remove('hack.zip')



# Generated at 2022-06-22 01:23:30.822573
# Unit test for function side_effect
def test_side_effect():
    # test removing one file
    with tempfile.NamedTemporaryFile() as tmpfile:
        tmpfile.write(b'abcdefg')
        tmpfile.flush()
        zip_path = u'{}.zip'.format(tmpfile.name)
        with zipfile.ZipFile(zip_path, 'w') as archive:
            archive.write(tmpfile.name, 'my_file')
        os.remove(tmpfile.name)
        old_cmd = MagicMock(script=u'unzip {}'.format(zip_path))

        side_effect(old_cmd, None)
        assert not os.path.exists(tmpfile.name)

        # test removing several files

# Generated at 2022-06-22 01:23:40.114741
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Cmd', (object,), {
        'script': 'unzip myfile.zip',
        'script_parts': ['unzip', 'myfile.zip']})
    assert get_new_command(command) == 'unzip -d myfile myfile.zip'

    command = type('Cmd', (object,), {
        'script': 'unzip -d myfile myfile.zip',
        'script_parts': ['unzip', '-d', 'myfile', 'myfile.zip']})
    assert get_new_command(command) == 'unzip -d myfile myfile.zip'

# Generated at 2022-06-22 01:23:50.722069
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    # The directory created with the new command is the same as the zipfile
    # without the .zip extension.
    assert get_new_command(Command('unzip some_zipfile.zip', '')) == \
        'unzip some_zipfile.zip -d some_zipfile'

    # If a subdirectory was selected while creating the zipfile, the new
    # directory should not have that subfolder
    assert get_new_command(Command('unzip some_zipfile.zip', '')) == \
        'unzip some_zipfile.zip -d some_zipfile'

    # If the zipfile path is too long or contains spaces, the new command is
    # not created

# Generated at 2022-06-22 01:23:56.257986
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip file.zip', '', '')) == (
        u'unzip -d file file.zip')
    assert get_new_command(Command('unzip -l file.zip', '', '')) == (
        u'unzip -d file -l file.zip')

# Generated at 2022-06-22 01:24:03.442420
# Unit test for function side_effect
def test_side_effect():
    from os import getcwd
    from thefuck.types import Command

    old_cmd = Command("unzip foobar.zip", "")
    command = Command("unzip -d foobar foobar.zip", "")

    def _zip_file(old_cmd):
        return old_cmd.script.split()[-1]

    def shell_quote(cmd):
        return cmd
    command.shell.quote = shell_quote

    # Testing if the side effect works as intended.
    # Side effect should remove any existing directory or files before
    # unzipping.
    # In this case the side effect will try to remove the file example.txt
    # in case it already exists
    side_effect(old_cmd, command)
    # Create a test file and make sure that the side effect removed it

# Generated at 2022-06-22 01:24:15.400798
# Unit test for function side_effect
def test_side_effect():
    # Create the temporary directory
    cwd = tempfile.mkdtemp()
    with zipfile.ZipFile(os.path.join(cwd, 'test.zip'), 'w') as archive:
        archive.writestr('abc', '')
        archive.writestr('def/bar', '')
    # Test directory structure
    assert os.path.isdir('{}/def'.format(cwd))
    assert os.path.isfile('{}/test.zip'.format(cwd))
    assert os.path.isfile('{}/abc'.format(cwd))
    # Execute the side_effect function

# Generated at 2022-06-22 01:24:28.205111
# Unit test for function side_effect
def test_side_effect():
    from tests.types import Command, Settings, Path
    import os
    from six import u

    # Create temporary paths
    old_cmd = Command(u("unzip test.zip"), None)
    old_cmd.script_parts = old_cmd.script.split()

    temp_zip = Path("test.zip")
    temp_zip.touch()
    zip_file = zipfile.ZipFile(temp_zip.path, 'w')
    zip_file.writestr("test.txt", "test")
    zip_file.close()

    temp_txt = Path("test.txt")
    if temp_txt.exists():
        temp_txt.remove()
    temp_txt.touch()

    test = side_effect(old_cmd, None)
    assert temp_txt.exists()

    temp_zip.remove()

# Generated at 2022-06-22 01:24:36.240621
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip test.zip',
                                   'unzip:  cannot find or open test.zip, test.zip.zip or test.zip.ZIP.')) == 'unzip -d test.zip test.zip'
    assert get_new_command(Command('unzip -d test1 test.zip',
                                   'unzip:  cannot find or open test.zip, test.zip.zip or test.zip.ZIP.')) == 'unzip -d test1 test.zip'

# Generated at 2022-06-22 01:24:51.512839
# Unit test for function side_effect
def test_side_effect():
    import unittest
    import mock
    import tempfile

    class TestSideEffect(unittest.TestCase):
        def setUp(self):
            self.dirpath = tempfile.mkdtemp()
            self.old_cmd = mock.Mock(script=None, script_parts=None)
            self.old_cmd.script_parts = ['unzip', self.dirpath+'/test.zip']
            self.old_cmd.script = ' '.join(self.old_cmd.script_parts)

            self.cmd = mock.Mock()
            self.cmd.script = 'unzip test.zip'
            self.cmd.script_parts = self.cmd.script.split()

            with zipfile.ZipFile(self.old_cmd.script_parts[1], 'w') as archive:
                archive.writ

# Generated at 2022-06-22 01:24:59.772168
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command('unzip file.zip', '', None)
    fake_zip_file = 'file.zip'
    archive = zipfile.ZipFile(fake_zip_file, 'w')
    files = ['file1.txt', 'file2.txt', 'file3.txt']
    for file in files:
        archive.writestr(file, 'test')
    archive.close()
    side_effect(old_cmd, 'unzip file.zip')
    for file in files:
        os.remove(file)
    os.remove('file.zip')

# Generated at 2022-06-22 01:25:11.774518
# Unit test for function match
def test_match():
    # test that unzip is matched
    command = Command('unzip archive.zip')
    assert match(command)
    assert not match(command)

    # test that unzip with existing archive returns true
    command = Command('unzip archive.zip')
    zip_file = _zip_file(command)
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.write('file1.txt')
    assert match(command)
    os.remove(zip_file)

    # test that unzip with existing archive and -d flag returns false
    command = Command('unzip archive.zip -d dest')
    zip_file = _zip_file(command)
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.write('file1.txt')

# Generated at 2022-06-22 01:25:19.780993
# Unit test for function match
def test_match():
    """
    Tests for the match function
    """
    from thefuck.rules.unzip_single_file import match
    import zipfile
    import tempfile

    tmp_dir = tempfile.mkdtemp()
    tmp_zip = os.path.join(tmp_dir, 'test.zip')

    # Test 1: With a zip file with 1 file in it
    with zipfile.ZipFile(tmp_zip, 'w') as archive:
        archive.writestr('file.txt', 'test')

    result = match(Command('unzip ' + tmp_zip + ' file.txt',
                           '', '', None))
    assert result is False

    # Test 2: With a zip file with 5 files in it

# Generated at 2022-06-22 01:25:30.983778
# Unit test for function match
def test_match():
    assert _is_bad_zip('/home/foo/.vim/bundle/YouCompleteMe/third_party/ycmd/tests/testdata/compile_commands.zip')
    assert not _is_bad_zip('/home/foo/.vim/bundle/YouCompleteMe/third_party/ycmd/tests/testdata/compile_commands.zip')

    # Test that match with the incorrect zip file
    assert match(Command("unzip /home/foo/.vim/bundle/YouCompleteMe/third_party/ycmd/tests/testdata/compile_commands.zip", "cd /home/foo/dev/rep/vimtest"))

# Generated at 2022-06-22 01:25:43.751434
# Unit test for function match
def test_match():
    zip_file = '/tmp/zip_file.zip'
    with open(zip_file, 'w') as archive:
        archive.write('test\n')

    # unzip a single file
    assert match(shell.and_('unzip {}'.format(zip_file), '')) is False

    # unzip a directory
    assert match(shell.and_('unzip -d directory {}'.format(zip_file), '')) is False

    # one file in the archive
    assert match(shell.and_('unzip {}'.format(zip_file), '')) is False

    with zipfile.ZipFile(zip_file, 'a') as archive:
        archive.writestr('test2.txt', 'test\n')

    # two files in the archive

# Generated at 2022-06-22 01:25:53.597033
# Unit test for function match
def test_match():
    # Unzipping one file in the same directory as the archive
    assert match(Command('unzip file')) == False
    # Unzipping many files in the same directory as the archive
    assert match(Command('unzip file1 file2')) == True
    # Unzipping files to a directory that already exists
    assert match(Command('unzip file1 file2 -d directory')) == False
    # Unzipping files to a directory that doesn't exist
    assert match(Command('unzip file1 file2 -d missing_directory')) == True
    # Unzipping with zip extension specified
    assert match(Command('unzip file.zip')) == False
    # Unzipping without zip extension specified
    assert match(Command('unzip file')) == True
    # Unzipping without zip extension specified and dereferencing the file
    #

# Generated at 2022-06-22 01:26:02.841752
# Unit test for function match
def test_match():
    command = Mock(script_parts=[])
    assert not match(command)

    command = Mock(script_parts=['unzip', 'archive.zip'])
    assert match(command)

    command = Mock(script_parts=['unzip', 'archive.zip', 'file.zip'])
    assert not match(command)

    command = Mock(script_parts=['unzip', '-d', 'archive.zip'])
    assert not match(command)

    command = Mock(script_parts=['unzip', '-d', 'archive.zip', 'file.zip'])
    assert not match(command)


# Generated at 2022-06-22 01:26:08.901148
# Unit test for function match
def test_match():
    assert not match(Command('zip test.zip file1 file2', '', ''))
    assert match(Command('unzip test.zip', '', ''))
    assert match(Command('unzip test', '', ''))
    assert match(Command('unzip test.zip -d target', '', ''))
    assert match(Command('unzip test -d target', '', ''))
    assert not match(Command('unzip test.zip -d target file', '', ''))
    assert not match(Command('unzip test', '', ''))



# Generated at 2022-06-22 01:26:17.304182
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.unzip_single_file_no_directory import get_new_command
    assert get_new_command(u'unzip test.zip') == u'unzip -d test test.zip'
    assert get_new_command(u'unzip -l test.zip') == u'unzip -l -d test test.zip'
    assert get_new_command(u'unzip -d test_folder test.zip') == u'unzip -d test_folder test.zip'

# Generated at 2022-06-22 01:26:32.409563
# Unit test for function match
def test_match():
    assert match(Command('', '')) is False
    assert match(Command('unzip archive.zip', '')) is True
    assert match(Command('unzip -d archive.zip', '')) is False
    assert match(Command('unzip archive.zip file1', '')) is True
    assert match(Command('unzip archive.zip file1 file2', '')) is False
    assert match(Command('unzip archive.zip -x file1', '')) is True
    assert match(Command('unzip archive.zip -x file1 file2', '')) is False


# Generated at 2022-06-22 01:26:33.017766
# Unit test for function side_effect
def test_side_effect():
    assert side_effect

# Generated at 2022-06-22 01:26:39.151983
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command('unzip file.zip', 'file.zip')
    zip_file = _zip_file(old_cmd)
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.write('test.txt')
    side_effect(old_cmd, Command('', ''))
    assert not os.path.exists('test.txt')

# Generated at 2022-06-22 01:26:45.111812
# Unit test for function get_new_command
def test_get_new_command():
    commands = [[u'/usr/bin/unzip', u'x', u'x.zip']]
    for command in commands:
        cmd = Command(command, None)
        if match(cmd):
            assert(get_new_command(cmd) == u'/usr/bin/unzip -d {} {}'.format(shell.quote(u'x'), shell.quote(u'x.zip')))

# Generated at 2022-06-22 01:26:49.358470
# Unit test for function side_effect
def test_side_effect():
    zip_file = 'test.zip'
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('file', 'text')
    os.remove('file')
    side_effect(zip_file, zip_file)
    assert os.path.isfile('file')
    os.remove(zip_file)

# Generated at 2022-06-22 01:27:01.259957
# Unit test for function match
def test_match():
    # test for simple cases
    assert match(Command('unzip foobar.zip', '')) == True
    assert match(Command('unzip foobar', '')) == True
    assert match(Command('unzip foobar.zip foobar.py', '')) == True
    assert match(Command('unzip -d foobar foobar.zip', '')) == False

    # test for flag case
    assert match(Command('unzip -t', '')) == False
    assert match(Command('unzip -t foobar.zip', '')) == False

    # test to ensure we can handle dashes in file names
    assert match(Command('unzip -t foobar-2.zip', '')) == True
    assert match(Command('unzip -t foobar-2', '')) == True


# Generated at 2022-06-22 01:27:02.726242
# Unit test for function match
def test_match():
    assert match(Command('unzip abc.zip', None))


# Generated at 2022-06-22 01:27:10.074233
# Unit test for function match
def test_match():
    script = 'unzip test.zip'
    command = Command(script, '', '')
    with open(u'{}.zip'.format(command.script_parts[-1]), 'w') as archive:
        with zipfile.ZipFile(archive, 'w') as zip_archive:
            zip_archive.writestr(u"test.txt", "test")
            zip_archive.writestr(u"test.html", "test")
    assert match(command)



# Generated at 2022-06-22 01:27:12.856610
# Unit test for function side_effect
def test_side_effect():
    old_cmd = "unzip test.zip"
    command = "unzip test.zip"
    side_effect(old_cmd, command)
    assert True

# Generated at 2022-06-22 01:27:19.394202
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='unzip myarchive.zip',
                                   stdout='', stderr='')).script == u'unzip -d myarchive myarchive.zip'
    assert get_new_command(Command(script='unzip myarchive mydirectory',
                                   stdout='', stderr='')).script == u'unzip -d myarchive myarchive'


# Generated at 2022-06-22 01:27:44.177053
# Unit test for function match
def test_match():
    # check for regular unzip
    assert match(unzip('unzip test.zip')) is False
    assert match(unzip('unzip test.zip file')) is False
    assert match(unzip('unzip test.zip file1 file2')) is False
    assert match(unzip('unzip test.zip -d dir file1 file2')) is False
    assert match(unzip('unzip test.zip file -d dir')) is False
    assert match(unzip('unzip test.zip -d dir file')) is False

    # check for bad unzip
    assert match(unzip('unzip test.zip file1 file2')) is False
    assert match(unzip('unzip test.zip')) is True

    # check if it works with -d flag

# Generated at 2022-06-22 01:27:47.236985
# Unit test for function get_new_command
def test_get_new_command():
    c = Command('unzip /tmp/test.zip', '', '')
    assert get_new_command(c) == 'unzip -d /tmp/test /tmp/test.zip'

# Generated at 2022-06-22 01:27:52.208684
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'unzip archive.zip') == u'unzip archive.zip -d archive'
    assert get_new_command(u'unzip archive.zip archive') == u'unzip archive.zip archive -d archive'


# Generated at 2022-06-22 01:28:03.237361
# Unit test for function side_effect
def test_side_effect():
    import os
    import tempfile
    import zipfile

    with tempfile.TemporaryDirectory() as tmp_dir:
        zip_file = '{}/test.zip'.format(tmp_dir)
        with zipfile.ZipFile(zip_file, 'w') as archive:
            archive.writestr('test1', '')
            archive.writestr('test2', '')
            archive.writestr('test3', '')

        old_cmd = Command(u'unzip {}'.format(zip_file), u'unzip {}')
        command = Command(u'unzip -d {} {}'.format(tmp_dir, zip_file), u'unzip -d {} {}')
        side_effect(old_cmd, command)


# Generated at 2022-06-22 01:28:03.841996
# Unit test for function side_effect
def test_side_effect():
    pass

# Generated at 2022-06-22 01:28:16.179902
# Unit test for function side_effect
def test_side_effect():
    fake_old_cmd = type('FakeCommand', (object, ),
                        {'script': u'unzip test.zip',
                        'script_parts': [u'unzip', u'test.zip']})
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, u'test.txt')
    script_file = os.path.join(tmp_dir, u'test.zip')
    with open(tmp_file, 'w') as f:
        f.write(u'pippo')
    with zipfile.ZipFile(script_file, 'w') as archive:
        archive.write(tmp_file)
    side_effect(fake_old_cmd, None)
    assert os.path.isfile(tmp_file)
    os

# Generated at 2022-06-22 01:28:18.910257
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('unzip test.zip', '', '')
    assert get_new_command(command) == 'unzip -d test test.zip'


# Generated at 2022-06-22 01:28:27.674710
# Unit test for function side_effect
def test_side_effect():
    from tempfile import mkdtemp
    import zipfile
    from shutil import rmtree
    from os.path import join

    test_dir = mkdtemp()
    os.chdir(test_dir)
    test_zip = 'test.zip'

    with open(join(test_dir, 'file_to_delete'), 'w') as f:
        f.write('file_to_delete')

    with zipfile.ZipFile(test_zip, 'w') as archive:
        archive.writestr('file_to_delete', 'file_to_delete')

    old_cmd = FakeCommand(script='unzip ' + test_zip,
                          script_parts=['unzip', test_zip])

# Generated at 2022-06-22 01:28:36.005991
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("unzip filename.zip") == "unzip -d filename filename.zip", "unzip without -d"
    assert get_new_command("unzip -q filename.zip") == "unzip -q -d filename filename.zip", "unzip with -q"
    assert get_new_command("unzip -l filename.zip") == "unzip -l -d filename filename.zip", "unzip with -l"
    assert get_new_command("unzip -l -q filename.zip") == "unzip -l -q -d filename filename.zip", "unzip with -q and -l"

# Generated at 2022-06-22 01:28:47.282782
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip test.zip', '', None)) == u'unzip -d test test.zip'
    assert get_new_command(Command('unzip test.zip file.txt', '', None)) == u'unzip -d test test.zip file.txt'
    assert get_new_command(Command('unzip test.zip file1.txt file2.txt', '', None)) == u'unzip -d test test.zip file1.txt file2.txt'
    assert get_new_command(Command('unzip -Z test.zip', '', None)) == u'unzip -Z -d test test.zip'

# Generated at 2022-06-22 01:29:18.894258
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    output = get_new_command(Command('unzip foo', 'foo.zip:  bad zipfile offset (local header sig):  0\n'
                                                 'unzip:  cannot find or open foo.zip, foo.zip.zip or foo.zip.ZIP.'))
    assert output == 'unzip -d foo'

# Generated at 2022-06-22 01:29:30.594387
# Unit test for function side_effect
def test_side_effect():
    """ Unit tests for side_effect

    Test that:
    1. The side effect properly determines the file to unzip,
    2. The side effect is not able to remove files outside of the
       current working directory
    3. The side effect is able to remove files outside of the
       current working directory.
    """
    import thefuck.rules.unzip_single_file as unzip
    import tempfile
    import os
    import shutil
    import zipfile

    # Prepare th temp dir
    tempdir = tempfile.mkdtemp()
    testdir = os.path.join(tempdir, 'testdir')
    os.mkdir(testdir)
    os.mkdir(os.path.join(testdir, 'anotherdir'))

    # Prepare the test zip

# Generated at 2022-06-22 01:29:34.713173
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('unzip', 'unzip file.zip'))
    assert not match(Command('unzip', 'unzip file.zip -d path'))
    assert not match(Command('unzip', 'unzip file.zip path'))
    assert not match(Command('unzip', 'unzip file.zip path -d path2'))


# Generated at 2022-06-22 01:29:39.227155
# Unit test for function side_effect
def test_side_effect():
    assert side_effect(['unzip', 'text1'], ['unzip', '-d', 'text1']) is None
    assert side_effect(['unzip', 'images.zip'], ['unzip', '-d', 'images']) is None

# Generated at 2022-06-22 01:29:44.117059
# Unit test for function get_new_command
def test_get_new_command():
    from . import assert_equals
    from thefuck.types import Command
    with open(__file__, 'rb') as script:
        assert_equals(get_new_command(Command(script.read(), '')),
                      u'unzip -d thefuck unzip.py')


# Generated at 2022-06-22 01:29:50.475841
# Unit test for function side_effect
def test_side_effect():
    os.mkdir('test_dir')
    os.chdir('test_dir')
    os.mkdir('test_dir2')
    file = open('test_file', 'w')
    file.write('test')
    file.close()
    file = open('test_dir2/test_file2', 'w')
    file.write('test')
    file.close()
    # zip the test_dir
    zipf = zipfile.ZipFile('test.zip', 'w', zipfile.ZIP_DEFLATED)
    zipf.write('test_file')
    zipf.write('test_dir2/test_file2')
    zipf.close()
    # change working directory to ..
    os.chdir('..')
    # call side_effect

# Generated at 2022-06-22 01:30:02.581872
# Unit test for function match
def test_match():
    match_fun = match
    assert not match_fun(Command('unzip backup.zip', '', None))
    assert not match_fun(Command('unzip backup.zip', '', None))
    assert not match_fun(Command("unzip backup.zip -d 'dir with space'", '', None))
    assert not match_fun(Command("unzip backup.zip -d'dir with no space'", '', None))
    assert match_fun(Command("unzip backup.zip '*.txt'", '', None))
    assert match_fun(Command("unzip backup.zip a.txt b.txt", '', None))
    assert match_fun(Command("unzip backup.zip '\"quoted spaces\"'", '', None))

# Generated at 2022-06-22 01:30:08.782147
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command('echo 0', 'echo 0')
    command = Command('unzip -d test', 'unzip -d test')
    side_effect(old_cmd, command)
    assert os.path.exists('test') is True
    os.removedirs('test')
    assert os.path.exists('test') is False

# Generated at 2022-06-22 01:30:20.206850
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command(script='unzip some_file.zip')
    assert get_new_command(cmd) == "unzip -d some_file some_file.zip"
    cmd = Command(script='unzip some_file')
    assert get_new_command(cmd) == "unzip -d some_file some_file.zip"
    cmd = Command(script='unzip -d test some_file')
    assert get_new_command(cmd) == "unzip -d test some_file.zip"
    cmd = Command(script='unzip -d test -n some_file')
    assert get_new_command(cmd) == "unzip -d test -n some_file.zip"
    cmd = Command(script='unzip -d test some_file.zip')

# Generated at 2022-06-22 01:30:26.445418
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip file.zip', 'unzip:  cannot find or open file.zip, file.zip.zip or file.zip.ZIP')) == 'unzip -d file file.zip'
    assert get_new_command(Command('unzip file', 'unzip:  cannot find or open file, file.zip or file.ZIP')) == 'unzip -d file file'


# Generated at 2022-06-22 01:31:28.437964
# Unit test for function match
def test_match():
    assert not match(Command('command', 'echo'))
    assert not match(Command('unzip', 'unzip -d'))
    assert not match(Command('unzip', 'unzip test.zip'))
    assert not match(Command('unzip', 'unzip test.zip test'))

    assert match(Command('echo', 'unzip test.zip file.txt'))
    assert match(Command('echo', 'unzip test file.txt'))

# Generated at 2022-06-22 01:31:37.039549
# Unit test for function side_effect
def test_side_effect():
    from tempfile import mkdtemp
    from shutil import rmtree

    tmp_dir = mkdtemp()
    test_zip = os.path.join(tmp_dir, 'test.zip')

    try:
        with zipfile.ZipFile(test_zip, 'w') as archive:
            archive.writestr('test.txt', 'foobar')
            archive.writestr('test2.txt', 'foobaz')

        command = Command('/usr/bin/unzip -l {}'.format(test_zip),
                          'fake output')

        side_effect(command, None)

        assert os.path.isfile('test.txt')
        assert os.path.isfile('test2.txt')
    finally:
        rmtree(tmp_dir)

# Generated at 2022-06-22 01:31:49.042615
# Unit test for function match
def test_match():
    def test(command, output, result):
        assert match(command) == result
        assert get_new_command(command) == output

    test(Command('unzip source.zip', '', '', None, 1),
         "unzip -d 'source' source.zip",
         True)
    test(Command('unzip source.zip -d dest', '', '', None, 1),
         "unzip -d 'dest' source.zip",
         True)
    test(Command('unzip source.zip dest', '', '', None, 1),
         "unzip -d 'dest' source.zip",
         True)
    test(Command('unzip source.zip dest/', '', '', None, 1),
         "unzip -d 'dest/' source.zip",
         True)

# Generated at 2022-06-22 01:31:53.919516
# Unit test for function match
def test_match():
    assert _is_bad_zip("XXX") == False  # File doesn't exist
    assert _is_bad_zip("README.md") == False  # File doesn't exist
    assert _is_bad_zip("examples/!") == True
    assert _is_bad_zip("examples/~") == True


# Generated at 2022-06-22 01:31:57.535266
# Unit test for function match
def test_match():
    output = "Archive:  foo.zip\n  inflating: bar.txt              \n  inflating: baz.txt              "
    command = 'unzip foo.zip'
    assert match(command)

# Generated at 2022-06-22 01:32:01.544536
# Unit test for function match
def test_match():
    assert match(Command('unzip 1.zip', '', ''))
    assert not match(Command('unzip -d 1.zip', '', ''))
    assert match(Command('unzip 1', '', ''))
    assert not match(Command('unzip -d 1', '', ''))

# Generated at 2022-06-22 01:32:09.069749
# Unit test for function match
def test_match():
    assert not match(Command('apt-get install unzip', ''))
    assert not match(Command('unzip -d /media/gfdfg/fdgdfg/ archive.zip', ''))
    assert not match(Command('unzip -d ~ archive.zip', ''))
    assert match(Command('unzip -d ~ archive.zip file1 file2', ''))
    assert match(Command('unzip -d ~ file', ''))
    assert match(Command('unzip file', ''))


# Generated at 2022-06-22 01:32:21.017616
# Unit test for function side_effect
def test_side_effect():
    import os
    import tempfile
    from thefuck.types import Command
    import zipfile


# Generated at 2022-06-22 01:32:29.371837
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip file2.zip', '', '')) == u'unzip -d file2 file2.zip'
    assert get_new_command(Command('unzip file2.zip file1.txt', '', '')) == u'unzip -d file2 file2.zip file1.txt'
    assert get_new_command(Command('unzip file2 file1.txt', '', '')) == u'unzip -d file2 file2 file1.txt'

# Generated at 2022-06-22 01:32:40.141024
# Unit test for function side_effect
def test_side_effect():
    old_cmd = type('', (), {
        'script': 'unzip /tmp/test_unzip.zip',
        'script_parts': ['unzip', '/tmp/test_unzip.zip']})
    command = type('', (), {'script': 'unzip -d /tmp/test_unzip'})