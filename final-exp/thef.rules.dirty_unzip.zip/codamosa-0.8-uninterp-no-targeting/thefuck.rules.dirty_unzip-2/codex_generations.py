

# Generated at 2022-06-22 01:23:11.576899
# Unit test for function match
def test_match():
    assert match(Command('unzip bar'))
    assert match(Command('unzip bar.zip'))
    assert not match(Command('unzip -d bar.zip'))
    assert not match(Command('unzip -d bar'))


# Generated at 2022-06-22 01:23:20.443386
# Unit test for function side_effect
def test_side_effect():
    """
    Side effect will not remove directories
    """
    import os
    import shutil
    import tempfile
    import zipfile

    tmp_dir = tempfile.mkdtemp()
    zip_file = os.path.join(tmp_dir, 'test.zip')
    not_removable_dir = os.path.join(tmp_dir, 'removable_dir')
    test_file = os.path.join(tmp_dir, 'test')

    with open(zip_file, 'w') as tmp_file:
        tmp_file.write('')

    with open(test_file, 'w') as tmp_file:
        tmp_file.write('')

    os.mkdir(not_removable_dir)


# Generated at 2022-06-22 01:23:29.560665
# Unit test for function match
def test_match():
    from thefuck.rules.unzip_to_current_folder import match
    match_1 = match(Command('unzip existing-file-x.zip', '', ''))
    assert match_1 == True
    match_2 = match(Command('unzip existing-file-x.zip', '', ''))
    assert match_2 == True
    match_3 = match(Command('unzip existing-file-x.zip', '', ''))
    assert match_3 == True
    match_4 = match(Command('unzip existing-file-x.zip', '', ''))
    assert match_4 == True
    match_5 = match(Command('unzip existing-file-x.zip', '', ''))
    assert match_5 == True


# Generated at 2022-06-22 01:23:41.659410
# Unit test for function match
def test_match():
    assert match(Command('unzip -a bad.zip'))
    assert not match(Command('unzip -a bad.zip *'))
    assert not match(Command('unzip -a bad.zip * -d none'))
    assert not match(Command('unzip -a bad.zip * -d none',
                             'something'))
    assert not match(Command('unzip -a bad.zip * -d none',
                             'something',
                             'something'))
    assert match(Command('unzip -a bad.zip * -d none',
                        'Archive:  bad.zip',
                        '  inflating: file1'))

# Generated at 2022-06-22 01:23:48.054800
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import get_shell
    import tempfile
    import os

    with tempfile.TemporaryDirectory() as temp_dir:
        shell = get_shell()
        command = 'unzip -d {}'.format(temp_dir)
        old_cmd = shell.from_shell(
            '{} {}'.format(command, os.path.join(temp_dir, 'test1.zip')))
        side_effect(old_cmd, shell.from_shell(command))

# Generated at 2022-06-22 01:23:58.976384
# Unit test for function side_effect
def test_side_effect():
    # creates zip file
    with zipfile.ZipFile("test.zip", "w") as archive:
        archive.writestr("test", "")
    # creates directory
    os.mkdir("test_dir")

    class OldCommand(object):
        script = "unzip test.zip"

    class Command(object):
        script = "unzip test.zip -d test_dir"

    side_effect(OldCommand, Command)
    # tests if file was extracted
    assert os.path.isfile("test")
    # tests if directory was not deleted
    assert os.path.isdir("test_dir")
    # removes created files and directories
    os.remove("test")
    os.rmdir("test_dir")

# Generated at 2022-06-22 01:24:11.425035
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('unzip random.zip', '', '')) ==
            u"unzip -d 'random' random.zip")
    assert (get_new_command(Command('unzip random.zip dir', '', '')) ==
            u"unzip -d 'random' random.zip")
    assert (get_new_command(Command('unzip random.app.zip dir', '', '')) ==
            u"unzip -d 'random.app' random.app.zip")
    assert (get_new_command(Command('unzip -d dir random.zip', '', '')) ==
            u"unzip -d 'random' random.zip")

# Generated at 2022-06-22 01:24:16.099696
# Unit test for function get_new_command
def test_get_new_command():
    assert u'unzip test.zip -d test' == get_new_command(shell.And('unzip test.zip', 'ls -la'))
    assert u'unzip test.zip -d test' == get_new_command(shell.And('unzip test.zip othefile.zip', 'ls -la'))

# Generated at 2022-06-22 01:24:20.969155
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert not match(Command('unzip -d other.zip', ''))
    assert not match(Command('unzip file.epub', ''))


# Unit tests for function get_new_command

# Generated at 2022-06-22 01:24:30.716562
# Unit test for function get_new_command
def test_get_new_command():
    old_cmd = 'unzip file.zip'
    command = 'unzip file.zip'
    assert get_new_command(old_cmd, command) == 'unzip -d file file.zip'
    old_cmd = 'unzip file.zip'
    command = 'unzip -d file file.zip'
    assert get_new_command(old_cmd, command) == 'unzip -d file file.zip'
    old_cmd = 'unzip file.zip'
    command = 'unzip -d file file.tar'
    assert get_new_command(old_cmd, command) == 'unzip -d file file.zip'

# Generated at 2022-06-22 01:24:42.338909
# Unit test for function side_effect
def test_side_effect():
    assert side_effect('unzip hello.zip', None)
    assert os.path.exists('./hello')
    assert not os.path.exists('./hello/hello.txt')
    assert not os.path.exists('./hello.txt')
    shutil.rmtree('./hello')

# Generated at 2022-06-22 01:24:47.659465
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip file.zip', "", "", 0, None)) == 'unzip -d file file.zip'
    assert get_new_command(Command('unzip -x file file.zip', "", "", 0, None)) == 'unzip -d file file.zip'

# Generated at 2022-06-22 01:25:00.463638
# Unit test for function get_new_command
def test_get_new_command():
    # test_unzip_with_one_file.zip contains one file "test.txt"
    assert get_new_command('unzip test_unzip_with_one_file.zip') == 'unzip -d test_unzip_with_one_file test_unzip_with_one_file.zip'
    # test_unzip_with_two_files.zip contains two files "test.txt" and "test2.txt"
    assert get_new_command('unzip test_unzip_with_two_files.zip') == 'unzip -d test_unzip_with_two_files test_unzip_with_two_files.zip'
    # test_unzip_with_one_dir.zip contains one directory "test" which contains a file "test.txt"

# Generated at 2022-06-22 01:25:11.208722
# Unit test for function match
def test_match():
    assert match(Command('unzip test1.zip', 'unzip test1.zip')) == False
    assert match(Command('unzip -d test1.zip', 'unzip test1.zip')) == False
    assert match(Command('unzip', 'unzip test1.zip')) == False

    assert match(Command('unzip test2.zip', 'unzip test2.zip')) == True

    assert match(Command('unzip test3.zip', 'unzip test3.zip')) == False
    assert match(Command('unzip -d test3.zip', 'unzip test3.zip')) == False
    assert match(Command('unzip', 'unzip test3.zip')) == False


# Generated at 2022-06-22 01:25:19.490886
# Unit test for function side_effect
def test_side_effect():
    old_cmd = type('Command', (object,), {
        'script': 'unzip archive.zip file1.txt',
        'script_parts': ['unzip', 'archive.zip', 'file1.txt'],
    })()
    command = type('Command', (object,), {
        'script': 'unzip -d archive archive.zip file1.txt file2.txt',
        'script_parts': ['unzip', '-d', 'archive', 'archive.zip', 'file1.txt', 'file2.txt'],
    })()
    cwd = os.getcwd()
    os.chdir(os.path.join(os.path.dirname(__file__), 'unzip', 'archive'))
    with zipfile.ZipFile('../archive.zip', 'r') as archive:
        archive

# Generated at 2022-06-22 01:25:24.200292
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("unzip new.zip")
    assert get_new_command(command) == "unzip -d new new.zip"
    command = Command("unzip -x new.zip")
    assert get_new_command(command) == "unzip -x -d new new.zip"

# Generated at 2022-06-22 01:25:26.575463
# Unit test for function match
def test_match():
    """
    Call match with unzip command that should work
    """
    assert match(u'unzip file.zip')



# Generated at 2022-06-22 01:25:27.201273
# Unit test for function side_effect
def test_side_effect():
    pass

# Generated at 2022-06-22 01:25:29.804219
# Unit test for function match
def test_match():
    import os
    zip_file = os.path.abspath(__file__)
    result = match(zip_file)
    assert result is True

# Generated at 2022-06-22 01:25:42.427032
# Unit test for function match
def test_match():
    assert match(Command(script='unzip file.zip', stderr='error'))
    assert match(Command(script='unzip file.zip file2.zip', stderr='error'))
    assert match(Command(script='unzip -d file.zip', stderr='error')) is False
    assert match(Command(script='unzip -d file.zip', stderr='error')) is False
    assert match(Command(script='unzip -d f1.zip f2.zip', stderr='error')) is False
    assert match(Command(script='unzip', stderr='error')) is False
    assert match(Command(script='unzip f.zip', stderr='error'))
    assert match(Command(script='unzip f.zip', stderr='error')) is False

# Generated at 2022-06-22 01:25:55.794202
# Unit test for function side_effect
def test_side_effect():
    script = 'unzip file.zip'
    command = Command(script, '')
    old_cmd = Command(script, '')
    with zipfile.ZipFile('file.zip', 'w') as archive:
        archive.writestr('file1.txt', 'Hello world 1')
        archive.writestr('file2.txt', 'Hello world 2')
    side_effect(old_cmd, command)
    assert os.path.isfile(os.path.abspath('file1.txt')) == True
    assert os.path.isfile(os.path.abspath('file2.txt')) == True
    with open(os.path.abspath('file1.txt')) as f:
        assert f.readline() == 'Hello world 1'

# Generated at 2022-06-22 01:25:57.768144
# Unit test for function get_new_command
def test_get_new_command():
    test_command = "unzip /home/user/test_file.zip"
    from thefuck.types import Command
    assert get_new_command(Command(test_command, None)) == "unzip -d /home/user/test_file test_file.zip"

# Generated at 2022-06-22 01:26:08.139165
# Unit test for function side_effect
def test_side_effect():
    zip_file = "test_unzip.zip"
    out_dir = "test_unzip"
    file_in_zip = 'test_unzip/test'
    cwd = os.getcwd()

    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr(file_in_zip, '')

    os.mkdir(out_dir)
    script = "unzip {} -d {}".format(zip_file, shell.and_("%s", out_dir, command=True))
    old_cmd = type('struct', (object,), {"script": script, "script_parts": script.split()})
    command = type('struct', (object,), {"script": script})

    side_effect(old_cmd, command)

    assert not os.path.isf

# Generated at 2022-06-22 01:26:10.053217
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('unzip example.zip') == 'unzip example.zip -d example'



# Generated at 2022-06-22 01:26:22.033161
# Unit test for function side_effect
def test_side_effect():
    import shutil
    from thefuck.types import Command
    import tempfile
    import sys

    if sys.version_info[0] < 3:
        from contextlib2 import nested
        from thefuck.utils import NamedTemporaryFile
    else:
        from contextlib import nested
        from tempfile import NamedTemporaryFile

    with nested(
        NamedTemporaryFile(delete=False),
        NamedTemporaryFile(delete=False),
        NamedTemporaryFile(delete=False),
        NamedTemporaryFile(delete=False)
    ) as (dir0, dir1, f0, f1):
        dir0.close()
        dir1.close()
        f0.close()
        f1.close()

        os.mkdir(dir0.name)
        os.mkdir(dir1.name)


# Generated at 2022-06-22 01:26:28.098371
# Unit test for function get_new_command
def test_get_new_command():
    class Command():
        def __init__(self):
            self.script = 'fooo'
            self.script_parts = [
                    'a','b','c','d','e','f','g','h','i','j','k','l'
                    ]

    assert get_new_command(Command()) == u"a b c d e f g h i j k -d l"

# Generated at 2022-06-22 01:26:33.480705
# Unit test for function match
def test_match():
    assert(match(Command('unzip file.zip')) is True)
    assert(match(Command('unzip file.zip file2.zip')) is True)
    assert(match(Command('unzip file.zip file2.zip -d folder')) is False)
    assert(match(Command('unzip file.zip file2.zip -d folder/')) is False)


# Generated at 2022-06-22 01:26:45.342716
# Unit test for function side_effect
def test_side_effect():
    # smoke test for side_effect for command failing to unzip
    # because unzip creates directories for zip files
    with zipfile.ZipFile('thefuck-test.zip', 'w') as archive:
        archive.write('thefuck/rules/unzip.py')
        archive.write('thefuck/rules/ls.py')

    script = u'unzip thefuck-test.zip'
    old_cmd = Command(script, '', '')

    side_effect(old_cmd, None)

    # tests as long as unzip-test.zip is not empty
    assert not os.path.exists('unzip.py')
    assert not os.path.exists('ls.py')
    assert not os.path.exists('thefuck-test.zip')
    assert not os.path.exists('thefuck')

# Generated at 2022-06-22 01:26:48.845583
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip bad_zip.zip', '')) == 'unzip -d bad_zip bad_zip.zip'
    assert get_new_command(Command('unzip bad_zip', '')) == 'unzip -d bad_zip bad_zip'

# Generated at 2022-06-22 01:26:52.750746
# Unit test for function get_new_command
def test_get_new_command():
    script = 'unzip -l test/test.zip'
    command = Command(script, '', script.split())
    assert get_new_command(command) == 'unzip -d test/test test/test.zip'

# Generated at 2022-06-22 01:27:18.182699
# Unit test for function match
def test_match():
    import os
    import tempfile
    from thefuck.rules.unzip_file import match
    from thefuck.types import Command

    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a new empty file in the temporary directory
        tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
        tmpfile.close()

        # use zipfile to zip the empty file in a zip archive
        os.chdir(tmpdir)
        z = zipfile.ZipFile('test.zip', 'w')
        z.write(tmpfile.name)
        z.close()

        # Test the function match
        assert match(Command('unzip {}'.format(os.path.join(tmpdir, 'test.zip')),
                             os.getcwd())) == True

# Generated at 2022-06-22 01:27:29.194577
# Unit test for function side_effect
def test_side_effect():
    file1 = './file'
    file2 = './folder/file'

    with open(file1, 'w'):
        pass

    os.makedirs(os.path.dirname(file2))

    with open(file2, 'w'):
        pass

    class OldCommand(object):
        def __init__(self):
            self.script = 'unzip -d folder file'
            self.script_parts = self.script.split(' ')


    side_effect(OldCommand(), 'unzip -d folder file.zip')

    assert os.path.isfile(file1)
    assert os.path.isfile(file2)

    os.remove(file1)
    os.remove(file2)
    os.rmdir(os.path.dirname(file2))

# Generated at 2022-06-22 01:27:40.996585
# Unit test for function side_effect
def test_side_effect():
    import os
    import shutil
    import tempfile

    temp = tempfile.mkdtemp()
    home = os.path.expanduser('~')
    os.chdir(temp)
    os.mkdir('foo')
    with open('foo/file.txt', 'w') as file:
        file.write('TEST')

    with zipfile.ZipFile('foo.zip', 'w') as zip:
        zip.write('foo')

    side_effect(command.Command('unzip foo.zip'), command.Command('unzip -d foo foo.zip'))
    assert 'file.txt' not in os.listdir(temp)
    assert 'file.txt' in os.listdir(os.path.join(os.getcwd(), 'foo'))


# Generated at 2022-06-22 01:27:46.869328
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('unzip archive.zip')) == "unzip -d archive archive.zip"
    assert get_new_command(Command('unzip archive.zip file')) == "unzip -d archive file.zip"
    assert get_new_command(Command('unzip -o archive.zip')) == "unzip -o -d archive archive.zip"

# Generated at 2022-06-22 01:27:58.950066
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='unzip test.zip', stdout=None, stderr=None)
    assert get_new_command(command) == u'unzip -d test test.zip'
    command = Command(script='unzip -o test.zip', stdout=None, stderr=None)
    assert get_new_command(command) == u'unzip -o -d test test.zip'
    command = Command(script='unzip -o -j test.zip', stdout=None, stderr=None)
    assert get_new_command(command) == u'unzip -o -j -d test test.zip'
    command = Command(script='unzip -o -j test', stdout=None, stderr=None)

# Generated at 2022-06-22 01:28:00.007264
# Unit test for function side_effect
def test_side_effect():
    assert side_effect(None, None) is None

# Generated at 2022-06-22 01:28:12.093643
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import mock
    from thefuck.types import Command

    old_cmd = Command('unzip example.zip', '', '')

    with tempfile.NamedTemporaryFile() as archive:
        with zipfile.ZipFile(archive, 'w') as archive:
            archive.writestr('example', 'content')

        archive.seek(0)

        with tempfile.NamedTemporaryFile() as existing_file:
            existing_file.write(b'content')
            existing_file.seek(0)

            with tempfile.TemporaryDirectory() as existing_dir:
                with tempfile.NamedTemporaryFile(dir=existing_dir) as existing_file_in_dir:
                    existing_file_in_dir.write(b'content')
                    existing_file_in_dir.seek(0)

# Generated at 2022-06-22 01:28:22.766284
# Unit test for function match
def test_match():
    script = "unzip foobar.zip"
    shell = _is_bad_zip
    res = match(shell_command(script, output='no foobar.zip'))
    assert(res == False)
    res = match(shell_command(script, output='foobar.zip'))
    assert(res == True)
    # This test is a bit weird, because we are assuming the inner function
    # returns an appropriate value for the mock
    with patch('thefuck.rules.unzip.zipfile.ZipFile') as zfile:
        zfile.return_value.namelist.return_value = [1]
        res = match(shell_command(script, output='foobar.zip'))
        assert(res == True)
        zfile.return_value.namelist.return_value = []

# Generated at 2022-06-22 01:28:34.145259
# Unit test for function get_new_command
def test_get_new_command():
    # test standard input
    command = type('Command', (object,), {
        'script': 'unzip test_zip.zip -o'
    })
    assert get_new_command(command) == 'unzip test_zip.zip -o -d test_zip'

    # test with flag input
    command = type('Command', (object,), {
        'script': 'unzip -o test_zip.zip'
    })
    assert get_new_command(command) == 'unzip -o test_zip.zip -d test_zip'

    # test no zip file
    command = type('Command', (object,), {
        'script': 'unzip'
    })
    assert get_new_command(command) == 'unzip -d'

    # test multiple zip file

# Generated at 2022-06-22 01:28:42.571795
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="unzip file.zip",
                                  stdout="",
                                  stderr="")) == "unzip -d file file.zip"
    assert get_new_command(Command(script="unzip -o file.zip",
                                  stdout="",
                                  stderr="")) == "unzip -o -d file file.zip"
    assert get_new_command(Command(script="unzip file",
                                  stdout="",
                                  stderr="")) == "unzip -d file file.zip"



# Generated at 2022-06-22 01:29:15.922970
# Unit test for function match
def test_match():
    assert match(Command('unzip -d otherdir dir', '')) is False
    assert match(Command('unzip dir.zip', '')) is False
    assert match(Command('unzip dir', '')) is False
    assert match(Command('unzip dir.zip', '')) is False

    assert match(Command('unzip otherdir', '')) is True


# Generated at 2022-06-22 01:29:28.492992
# Unit test for function match
def test_match():
    # get_new_command works by removing the last component of the zip file
    # path, so we need to check that too.
    unzip_path = '/usr/bin/unzip'
    # unzip /foo.zip
    assert match(Command(unzip_path, '', ''))
    assert match(Command(unzip_path, ' ', ''))
    assert match(Command(unzip_path, ' /foo/bar', ''))
    assert match(Command(unzip_path, '', '/foo/bar.zip'))
    assert match(Command(unzip_path, ' ', '/foo/bar.zip'))
    assert match(Command(unzip_path, ' /foo/bar', '/foo/bar.zip'))
    assert not match(Command(unzip_path, '', '/foo/bar'))
   

# Generated at 2022-06-22 01:29:38.069236
# Unit test for function get_new_command
def test_get_new_command():
    assert 'unzip -d .vim .' == get_new_command('unzip .vim.zip')
    assert 'unzip -d .vim .' == get_new_command('unzip .vim.zip ')
    assert 'unzip -d .vim .' == get_new_command('unzip .vim.zip *')

    assert 'unzip -d .vim .' == get_new_command('unzip .vim.zip')
    assert 'unzip -d .vim .' == get_new_command('unzip .vim.zip ')
    assert 'unzip -d .vim .' == get_new_command('unzip .vim.zip *')

# Generated at 2022-06-22 01:29:43.476514
# Unit test for function match
def test_match():
    assert match(Command('unzip x', None))
    assert match(Command('unzip x.zip', None))
    assert not match(Command('unzip x.zip -d foo', None))
    assert not match(Command('unzip', None))
    assert not match(Command('unzip -d foo', None))



# Generated at 2022-06-22 01:29:44.893585
# Unit test for function side_effect
def test_side_effect():
    assert side_effect is None

enabled_by_default = True

# Generated at 2022-06-22 01:29:56.009424
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import GnuShell

    wrong_cmd = 'unzip test.zip'
    new_cmd = get_new_command(wrong_cmd)

    with GnuShell() as shell:
        os.mkdir('test')
        with open('test/file.txt', 'w') as f:
            f.write("")

        with zipfile.ZipFile('test.zip', 'w') as myzip:
            myzip.write('test/file.txt')

        side_effect(wrong_cmd, new_cmd)

        assert not os.path.exists('test/file.txt')
        assert os.path.exists('test.zip')

        os.remove('test.zip')
        os.rmdir('test')

# Generated at 2022-06-22 01:30:00.011010
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    old_cmd = 'unzip test.zip -j'
    command = get_new_command(Command(old_cmd, ''))
    side_effect(Command(old_cmd, ''), command)

# Generated at 2022-06-22 01:30:08.062613
# Unit test for function get_new_command
def test_get_new_command():
    with patch('os.path.abspath') as path_abspath:
        path_abspath.return_value = '/full/path/to/file.zip'
        with patch('thefuck.specific.unzip._zip_file',
                   return_value='file.zip') as zip_file:
            assert get_new_command(
                Command('unzip -o file.zip', None)) == u'unzip -o file.zip -d /full/path/to/file'
            assert get_new_command(
                Command('unzip -o file', None)) == u'unzip -o file -d /full/path/to/file'

# Generated at 2022-06-22 01:30:14.779976
# Unit test for function side_effect
def test_side_effect():
    archive = u'archive.zip'
    with zipfile.ZipFile(archive, 'a') as arc:
        arc.writestr('file', 'content')

    old_cmd = MagicMock(script=u'unzip {}'.format(archive),
                        script_parts=[u'unzip'] + shlex.split(archive))

    side_effect(old_cmd, None)
    assert not os.path.isfile('file')
    os.remove(archive)

# Generated at 2022-06-22 01:30:16.575131
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("unzip a.zip") == "unzip -d a a.zip"

# Generated at 2022-06-22 01:31:20.892920
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from tests.utils import CommandResult
    from thefuck.rules.unzip_single_file import side_effect

    zip_file='some/zip/file.zip'
    old_cmd = Command('some command', 'some')
    command = Command('some command', 'some')
    archive = zipfile.ZipFile(zip_file, 'r')
    archive.extractall()
    archive.close()

    assert os.path.isfile(zip_file[:-4])
    assert os.path.getsize(zip_file[:-4]) > 0

    side_effect(old_cmd, command)

    assert not os.path.isfile(zip_file[:-4])

# Generated at 2022-06-22 01:31:33.382018
# Unit test for function side_effect
def test_side_effect():
    import datetime
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        with open('file', 'w') as f:
            f.write('')

        zfile = os.path.join(tmpdir, 'file.zip')
        with zipfile.ZipFile(zfile, 'w') as archive:
            archive.write('file')
            archive.write('dir')
            end_of_central_dir = archive.fp.tell()
            archive.fp.seek(0 - end_of_central_dir, os.SEEK_END)
            archive_data = archive.fp.read()
            crc = zipfile.crc32(archive_data)

# Generated at 2022-06-22 01:31:38.390246
# Unit test for function get_new_command
def test_get_new_command():
    test_command = 'unzip foo.zip -x bar'
    expected_output = 'unzip foo.zip -x bar -d foo'
    output = get_new_command(shell.and_('unzip foo.zip -x bar'))
    assert expected_output == output

# Generated at 2022-06-22 01:31:50.654046
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import zipfile
    import shutil
    import os
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

# Generated at 2022-06-22 01:32:00.376764
# Unit test for function match
def test_match():
    # Test for "unzip file.zip" command
    unzip_file = 'unzip file.zip'
    assert match(Command(unzip_file))
    # Test for "unzip file" command
    unzip_file = 'unzip file'
    assert match(Command(unzip_file))
    # Test for "unzip -l file.zip" command
    unzip_file = 'unzip -l file.zip'
    assert not match(Command(unzip_file))
    # Test for "unzip file.zip -d dest" command
    unzip_file = 'unzip file.zip -d dest'
    assert not match(Command(unzip_file))


# Generated at 2022-06-22 01:32:01.133413
# Unit test for function get_new_command

# Generated at 2022-06-22 01:32:12.423042
# Unit test for function match
def test_match():
    from thefuck.shells import Bash, Zsh
    from tests.utils import Command

    zipfile.ZipFile(u'test.zip', mode='w')
    os.chdir(os.getcwd())
    command = Command(script=u'unzip test.zip', stdout=u'foo', stderr=u'bar')

    assert match(command)

    command = Command(script=u'unzip -d test test.zip', stdout=u'foo', stderr=u'bar')
    shell = Zsh()
    assert not match(command)

    command = Command(script=u'unzip -d test test.zip', stdout=u'foo', stderr=u'bar')
    shell = Bash()
    assert not match(command)


# Generated at 2022-06-22 01:32:23.151384
# Unit test for function get_new_command
def test_get_new_command():
    # command: unzip file.zip
    command = Command(script='unzip file.zip',
                      stdout='test.txt',
                      stderr='test.txt')
    assert get_new_command(command) == 'unzip -d file file.zip'

    # command: unzip file.zip -a
    command = Command(script='unzip file.zip -a',
                      stdout='test.txt',
                      stderr='test.txt')
    assert get_new_command(command) == 'unzip -a -d file file.zip'

    # command: unzip -a file.zip
    command = Command(script='unzip -a file.zip',
                      stdout='test.txt',
                      stderr='test.txt')

# Generated at 2022-06-22 01:32:27.386386
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("unzip foo") == u'unzip -d foo foo'
    assert get_new_command("unzip foo.zip") == u'unzip -d foo foo'

# Generated at 2022-06-22 01:32:30.662853
# Unit test for function get_new_command
def test_get_new_command():
    command = "unzip /home/group/archive.zip"
    assert get_new_command(command) == 'unzip -d /home/group/archive'

