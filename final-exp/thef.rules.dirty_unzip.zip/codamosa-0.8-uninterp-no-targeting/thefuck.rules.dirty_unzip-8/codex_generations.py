

# Generated at 2022-06-22 01:23:06.943160
# Unit test for function get_new_command
def test_get_new_command():
    import tempfile
    with tempfile.NamedTemporaryFile() as archive:
        command = type(
            'Command', (object,),
            {'script': 'unzip {}'.format(archive.name),
             'script_parts': ['unzip', archive.name,
                              "script", "parts", "flags"]})
        assert get_new_command(
            command) == u'unzip {} -d {}'.format(archive.name,
                                                 shell.quote(archive.name[:-4]))

# Generated at 2022-06-22 01:23:12.695707
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        shell.And('unzip', 'unzip', 'test.zip')) == u'unzip -d test test.zip'
    assert get_new_command(
        shell.And('unzip', 'unzip', 'test', '.zip')) == u'unzip -d test test.zip'



# Generated at 2022-06-22 01:23:20.062267
# Unit test for function get_new_command
def test_get_new_command():
    old_command = type('Command', (object,), {
        'script': 'unzip hack.zip',
        'script_parts': ['unzip', 'hack.zip']
    })

    assert get_new_command(old_command) == 'unzip hack.zip -d hack'

    old_command = type('Command', (object,), {
        'script': 'unzip -t hack.zip',
        'script_parts': ['unzip', '-t', 'hack.zip']
    })

    assert get_new_command(old_command) == 'unzip -t hack.zip -d hack'



# Generated at 2022-06-22 01:23:25.530625
# Unit test for function get_new_command
def test_get_new_command():
    # pylint: disable=protected-access
    assert get_new_command(shell._parse_command('unzip file1.zip')) == u'unzip file1.zip -d file1'
    assert get_new_command(shell._parse_command('unzip file2')) == u'unzip file2 -d file2'

# Generated at 2022-06-22 01:23:37.793971
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import os
    import shutil
    import zipfile

    # create a temporary directory
    temp_dir = tempfile.mkdtemp()
    print (temp_dir)
    os.chdir(temp_dir)

    # create a text file
    f = open('test.txt','w')
    f.write('Hello The Fuck\nWorld')
    f.close()

    #create a zip file
    zf = zipfile.ZipFile('test.zip','w')
    zf.write('test.txt')
    zf.close()

    # run the side_effect function
    side_effect('unzip', 'unzip test.zip')

    # check if the side_effect function worked
    if os.path.isfile('test.txt'):
        assert True

# Generated at 2022-06-22 01:23:46.749145
# Unit test for function side_effect
def test_side_effect():
    import sys
    import tempfile
    import zipfile
    from thefuck.types import Command

    with tempfile.TemporaryDirectory() as tmpdir:
        with tempfile.NamedTemporaryFile(dir=tmpdir, delete=False) as f:
            f.write(b'foobar')

        old_cmd = Command('unzip ' + sys.executable, '', None)
        with tempfile.NamedTemporaryFile(prefix='unzip') as zip_file:
            zip_file.write(b'foobar')
            with zipfile.ZipFile(zip_file, 'a') as myzip:
                myzip.write(f.name)

            os.remove(zip_file.name)


# Generated at 2022-06-22 01:23:49.432787
# Unit test for function get_new_command
def test_get_new_command():
    command = 'unzip archive.zip'
    assert get_new_command(command) == 'unzip -d archive archive.zip'


# Generated at 2022-06-22 01:24:00.205294
# Unit test for function side_effect
def test_side_effect():
    import thefuck.types as types
    from thefuck.shells import shell
    from thefuck.shells import get_closest
    from thefuck.debug import get_log, set_log
    from thefuck.dependencies import which

    # Mock all
    (set_log, get_log, which, get_closest, shell) = [lambda x: None] * 5

    # Mock types.Command
    class Command(types.Command):
        def __init__(self, script):
            script = script.split(' ')
            self.script = script[0]
            self.script_parts = script[1:]

    # Mock zipfile.ZipFile
    class ZipFile(object):
        def __init__(self, path, mode):
            self.path = path
            self.mode = mode

# Generated at 2022-06-22 01:24:02.073783
# Unit test for function side_effect
def test_side_effect():
    # the function which can test side_effect does not exist yet
    pass

# Generated at 2022-06-22 01:24:13.702699
# Unit test for function side_effect
def test_side_effect():
    os.chdir('test_directory')

    # change side_effect function to not delete files outside of the current
    # directory
    global requires_output
    requires_output = True

    side_effect('unzip {fuck} -d {fuck}',
                'unzip test_file.zip -d test')

    # We do not assert on this because it changes with the timing of the test
    # try:
    #  with open('test_file.txt') as fd:
    #    assert fd.read() == 'test'
    # except IOError:
    #  assert False

    try:
        with open('test/test_file.txt') as fd:
            assert fd.read() == 'test'
    except IOError:
        assert False


# Generated at 2022-06-22 01:24:27.441919
# Unit test for function match
def test_match():
    # should match the command line
    assert match(Command('unzip abc.zip'))
    assert match(Command('unzip abc'))
    assert not match(Command('unzip -l abc.zip'))
    assert not match(Command('unzip -d abc abc.zip'))
    assert not match(Command('unzip -d abc abc'))


# Generated at 2022-06-22 01:24:35.298333
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('', '')) == u''
    assert get_new_command(Command('unzip', '')) == u'unzip -d '
    assert get_new_command(
        Command('unzip -d', '')) == u'unzip -d -d '
    assert get_new_command(
        Command('unzip -d .', '')) == u'unzip -d . -d .'
    assert get_new_command(
        Command('unzip -d . file.zip', '')) == u'unzip -d . file.zip -d ./file'


# Generated at 2022-06-22 01:24:37.869923
# Unit test for function match
def test_match():
    assert match(Command('unzip new.zip', '', '')) == True
    assert match(Command('unzip old.zip', '', '')) == False


# Generated at 2022-06-22 01:24:45.132289
# Unit test for function match
def test_match():
    from thefuck.rules.unzip_single_file import match
    command = '''unzip bad.zip'''
    assert match(command)

    command = '''unzip -a bad.zip'''
    assert match(command)

    command = '''unzip -d bad.zip'''
    assert not match(command)

    command = '''unzip -d blah bad.zip'''
    assert not match(command)

    command = '''haha -a bad.zip'''
    assert not match(command)



# Generated at 2022-06-22 01:24:51.086430
# Unit test for function side_effect
def test_side_effect():
    import thefuck.types
    from tests.utils import Command, is_not_empty

    file = 'thefuck/shells/__init__.py'
    Command('unzip -j -d {} {}'.format(file, file),
            'Archive:  {}\n[{}] {}/__init__.py  already exists;\
            do you wish to overwrite [y]es, [n]o, [A]ll, \
            [N]one, [r]ename:'.format(file, file, file)).assert_output(
            is_not_empty,
            side_effect,
            thefuck.types.Rule(True, None))

# Generated at 2022-06-22 01:24:56.506211
# Unit test for function match
def test_match():
    assert match(Command('unzip archive.zip'))
    assert match(Command('unzip -qq archive.zip'))
    assert match(Command('unzip archive.tar.zip'))
    assert not match(Command('unzip archive.zip -d target'))
    assert not match(Command('unzip archive.zip file.txt'))



# Generated at 2022-06-22 01:25:06.103579
# Unit test for function side_effect
def test_side_effect():
    from thefuck.conf import settings
    from thefuck.types import Command

    _zip_file = 'file.zip'
    old_cmd = Command('unzip file.zip', '')

    zip_file = zipfile.ZipFile(_zip_file, 'w')
    zip_file.writestr('file', 'contents')
    zip_file.writestr('dir/file', 'contents')
    zip_file.close()

    side_effect(old_cmd, None)
    with open('file', 'r') as f:
        assert f.read() == 'contents'
    if settings.require_confirmation:
        assert os.path.exists('dir')
        assert os.path.exists('dir/file')
    else:
        assert not os.path.exists('dir')

# Generated at 2022-06-22 01:25:12.973425
# Unit test for function side_effect
def test_side_effect():
    from thefuck import shell
    import tempfile, os

    temp_files = [tempfile.NamedTemporaryFile(delete=False) for _ in range(2)]
    temp_zip = tempfile.NamedTemporaryFile(delete=False)
    temp_zip.close()

    shell.to_sep(';').join([temp_file.name for temp_file in temp_files])

    side_effect(None, 'unzip -d ' + shell.quote(temp_zip.name))

    # TODO: non-existing files


# Generated at 2022-06-22 01:25:23.073194
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command

    old_cmd = Command('unzip test.zip', 'unzip:  cannot find or open test.zip, test.zip.zip or test.zip.ZIP.')
    with zipfile.ZipFile(_zip_file(old_cmd), 'w') as archive:
        archive.writestr('test.py', b'import sys\nprint("hi")')

    side_effect(old_cmd, Command('unzip test.zip -d test/'))
    assert os.path.exists('test.py')
    os.remove('test.py')
    os.remove('test.zip')

# Generated at 2022-06-22 01:25:30.741834
# Unit test for function side_effect
def test_side_effect():
    # Create a fake file
    old_cmd = Command('unzip -j file.zip -d /test/testfile')
    file_path = os.path.join('/test/testfile', 'test')
    with open(file_path, 'w+') as f:
        f.write('test')
    # Test if side_effect() works properly
    side_effect(old_cmd, None)
    assert not os.path.exists(file_path)
    # Cleanup
    os.remove(file_path)

# Generated at 2022-06-22 01:25:53.248673
# Unit test for function side_effect
def test_side_effect():
    # Simulate output of unzip -l command
    output = "\n".join([
        "Archive:  tmp.zip",
        "  Length      Date    Time    Name",
        "---------  ---------- -----   ----",
        "        0  2016-01-28 14:05   file",
        "---------                     -------",
        "        0                     1 file"])
    # old_cmd is the command run by the user
    old_cmd = type("Cmd", (), {
        "script": "unzip -j tmp.zip",
        "script_parts": ["unzip", "-j", "tmp.zip"]})
    command = type("Cmd", (), {
        "script": "unzip -d tmp tmp.zip",
        "script_parts": ["unzip", "-d", "tmp", "tmp.zip"]})
    side_

# Generated at 2022-06-22 01:26:04.747013
# Unit test for function match
def test_match():
    command = Command('unzip not_a_zip.zip')
    assert match(command) is False
    command = Command('unzip -NOT_A_FLAG not_a_zip.zip')
    assert match(command) is False
    command = Command('unzip -d not_a_zip.zip')
    assert match(command) is False

    command = Command('unzip a_zip_file.zip')
    assert match(command) is False
    command = Command('unzip a_zip_file')
    assert match(command) is False
    command = Command('unzip a_zip_file.zip a_file.txt')
    assert match(command) is False

    command = Command('unzip a_zip_directory.zip')
    assert match(command) is True
    command = Command('unzip a_zip_directory')

# Generated at 2022-06-22 01:26:10.955402
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.zip_unzip_undo import get_new_command
    shell.FromHistory().get_aliases = lambda: {}
    shell.FromHistory().get_history = lambda: [u'unzip archive.zip file']
    assert get_new_command(u'unzip archive.zip file') == u'unzip archive.zip file -d archive'
    assert get_new_command(u'unzip archive.zip') == u'unzip archive.zip -d archive'
    assert get_new_command(u'unzip -a archive.zip file') == u'unzip -a archive.zip file -d archive'
    assert get_new_command(u'unzip -l archive.zip file') == u'unzip -l archive.zip file -d archive'

# Generated at 2022-06-22 01:26:22.550073
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    tmp_dir = tempfile.mkdtemp()

    # Create ZIP archive
    with zipfile.ZipFile(os.path.join(tmp_dir, 'test.zip'), 'w') as zip_:
        zip_.write(__file__, 'test_side_effect.py')
        zip_.write(__file__, 'test_side_effect.pyc')

    # Create directories
    shutil.copytree(os.path.dirname(__file__),
                    os.path.join(tmp_dir, 'matching_dir'))
    os.mkdir(os.path.join(tmp_dir, 'nonmatching_dir'))

    # Create files
    shutil.copy2(__file__, tmp_dir)

    current_dir = os.getcwd()

# Generated at 2022-06-22 01:26:33.642697
# Unit test for function get_new_command
def test_get_new_command():

    # Test 1: file names ending in zip
    test_cmd_1 = 'unzip realmusic.zip'
    test_cmd_1_output = get_new_command(test_cmd_1)
    assert test_cmd_1_output == 'unzip -d realmusic realmusic.zip'

    # Test 2: file names not ending in zip
    test_cmd_2 = 'unzip realmusic'
    test_cmd_2_output = get_new_command(test_cmd_2)
    assert test_cmd_2_output == 'unzip -d realmusic realmusic.zip'

    # Test 3: file with spaces in name
    test_cmd_3 = 'unzip realmusic.zip'
    test_cmd_3_output = get_new_command(test_cmd_3)
    assert test_cmd_3

# Generated at 2022-06-22 01:26:36.962227
# Unit test for function side_effect
def test_side_effect():
    old_cmd = "unzip wrong.zip"
    command = get_new_command(old_cmd)
    assert side_effect(old_cmd, command) is None

# Generated at 2022-06-22 01:26:47.811745
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.shells.bash import Bash
    from thefuck.rules.unzip import side_effect
    import tempfile
    import os
    import zipfile
    import sys

    class C(Command):

        def script(self):
            return u'unzip'

    def execute(script):
        return script

    def get_all_logs(cls):
        return ''

    source_dir = os.path.abspath(os.path.dirname(__file__))


# Generated at 2022-06-22 01:26:59.074230
# Unit test for function match
def test_match():
    assert match(Command(script='unzip -l foo.zip', stdout='foo'))
    assert not match(Command(script='unzip -l foo.zip', stdout='bar'))
    assert not match(Command(script='unzip -d foo.zip', stdout='foo'))
    assert not match(Command(script='unzip foo.zip', stdout='foo'))
    assert match(Command(script='unzip foo.zip'))
    assert match(Command(script='unzip foo'))
    assert match(Command(script='unzip foo', stdout='bar'))
    assert not match(Command(script='unzip foo', stderr='bar'))
    assert not match(Command(script='unzip -l -d foo.zip'))

# Generated at 2022-06-22 01:27:10.433470
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    test_file = 'tests/resources/file1.txt'
    test_file2 = 'tests/resources/file2.txt'
    old_cmd = Command('unzip tests/resources/file1.zip', '', '')
    command = Command('unzip -d {} tests/resources/file1.zip'.format(
        shell.quote('tests/resources')), '', '')

    # Side effect must delete the file1.txt, and not touch file2.txt
    with open(test_file, 'w+') as file1:
        file1.write('Test')
    with open(test_file2, 'w+') as file2:
        file2.write('Test')

    side_effect(old_cmd, command)

# Generated at 2022-06-22 01:27:14.826082
# Unit test for function get_new_command
def test_get_new_command():
    script = "unzip d 'a.zip'"
    old_cmd = Command(script, '')
    command = get_new_command(old_cmd)
    assert command == u'unzip -d d a'


# Generated at 2022-06-22 01:27:53.912357
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    temp = tempfile.mkdtemp()
    import os
    # Create a dir inside the temp directory
    os.makedirs(temp+"/test")
    # Create a file inside the temp directory
    with open(temp+"/test1.txt", "w") as file:
        file.write("test")
    old_cmd = OldCommand(cmd="unzip test.zip", script="unzip test.zip")
    command = Command(script="unzip test.zip", cmd="unzip test.zip", stdout="unzip test.zip")
    old_wd = os.getcwd()
    # Change the current working directory to temp to test side_effect
    os.chdir(temp)
    side_effect(old_cmd, command)
    # Reset the current working directory
    os.chdir

# Generated at 2022-06-22 01:27:59.222597
# Unit test for function match
def test_match():
    assert match(Command('unzip -d test')) is False
    # test short form
    assert match(Command('unzip test.zip')) is False
    # test long form
    assert match(Command('unzip --test.zip')) is False
    # test non existent file
    assert match(Command('unzip test.zip')) is False



# Generated at 2022-06-22 01:28:01.504496
# Unit test for function match
def test_match():
    result = _is_bad_zip('/any/path/critical_files.zip')
    assert result == True


# Generated at 2022-06-22 01:28:13.748307
# Unit test for function match
def test_match():
    assert _is_bad_zip('test/resources/test_zip.zip')
    assert not _is_bad_zip('test/resources/test_zip.zip')  # File doesn't exist
    assert not _is_bad_zip('test/resources/test_zip')  # File isn't zip archive
    assert not _is_bad_zip('test/resources/test_bad_zip')  # Zip is corrupted
    assert not match(Command('', '', ''))
    assert not match(Command('unzip', 'unzip -d test_zip.zip', ''))
    assert match(Command('unzip', 'unzip test_zip.zip', ''))
    assert match(Command('unzip', 'unzip test_zip', ''))
    assert match(Command('unzip', 'unzip -l test_zip.zip', ''))


# Generated at 2022-06-22 01:28:23.856781
# Unit test for function match
def test_match():
    command = Command('unzip test.zip', '', '', '', '')
    assert match(command) is False

    command = Command('unzip test.zip', '', '', '', '')
    assert match(command) is False

    command = Command('unzip test.zip test.txt', '', '', '', '')
    assert match(command) is False

    command = Command('unzip -d test test.zip test.txt', '', '', '', '')
    assert match(command) is False

    command = Command('unzip', '', '', '', '')
    assert match(command) is False

    command = Command('unzip test.zip', os.linesep.join(['Archive:  test.zip',
                                                         '  inflating: test.txt']), '', '', '')


# Generated at 2022-06-22 01:28:34.684269
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', ''))
    assert match(Command('unzip test', ''))

    assert not match(Command('unzip test.zip -d test', ''))
    assert not match(Command('unzip test -d test', ''))

    assert match(Command('unzip -l test.zip', ''))
    assert match(Command('unzip -l test', ''))

    assert not match(Command('unzip -l test.zip -d test', ''))
    assert not match(Command('unzip -l test -d test', ''))

    assert match(Command('unzip -l test.zip test2.zip', ''))
    assert match(Command('unzip -l test test2', ''))

    assert not match(Command('unzip -l test.zip test2.zip -d test', ''))


# Generated at 2022-06-22 01:28:37.017635
# Unit test for function get_new_command
def test_get_new_command():
    command = u'unzip zip_file unzip_file'
    new_command = get_new_command(command)
    assert u'unzip -d zip_file' == new_command


# Generated at 2022-06-22 01:28:43.805608
# Unit test for function get_new_command
def test_get_new_command():
    # Test for command: unzip folder.zip
    old_cmd = "unzip folder.zip"
    script = Command(script=old_cmd)
    assert get_new_command(script) == "unzip -d folder folder.zip"

    # Test for command: unzip -u filename.zip
    old_cmd = "unzip -u filename.zip"
    script = Command(script=old_cmd)
    assert get_new_command(script) == "unzip -u -d filename filename.zip"

# Generated at 2022-06-22 01:28:48.791096
# Unit test for function match
def test_match():
    assert(not match(Command('zip -d directory zipfile.zip', '', '', 1, False)))
    assert(not match(Command('unzip zipfile.zip', '', '', 1, False)))
    assert(match(Command('unzip zipfile.zip', '', '', 1, False)))

# Generated at 2022-06-22 01:29:00.055005
# Unit test for function match
def test_match():
    # case 1: file is not a zip file
    result = match(Command('unzip', 'unzip test.txt'))
    assert result == False

    # case 2: the zip file does not contain multiple files
    test_path = os.path.dirname(__file__) + '/test.zip'
    result = match(Command('unzip', 'unzip {}/test.zip'.format(test_path)))
    assert result == False

    # case 3: the zip file contains multiple files
    test_path = os.path.dirname(__file__) + '/test2.zip'
    result = match(Command('unzip', 'unzip {}/test2.zip'.format(test_path)))
    assert result == True


# Generated at 2022-06-22 01:30:04.326007
# Unit test for function match
def test_match():
    # unzip
    command = 'unzip file.zip'
    assert match(command) is False

    # unzip with flags : -d flag
    command = 'unzip -d file.zip'
    assert match(command) is False

    # unzip with flags : -d flag not zip file
    command = 'unzip -d file file.zip'
    assert match(command) is False

    # unzip file.zip directory
    command = 'unzip file.zip directory/'
    assert match(command) is False

    # unzip file.zip file
    command = 'unzip file.zip file'
    assert match(command) is False

    # unzip file.zip directory file
    command = 'unzip file.zip directory/ file'
    assert match(command) is False

    # unzip file.zip file directory/

# Generated at 2022-06-22 01:30:10.148522
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.unzip_to_current_directory import get_new_command
    from thefuck.rules.unzip_to_current_directory import Command

    script = "unzip archive.zip"
    new_script = get_new_command(Command(script, ''))
    assert new_script == "unzip archive.zip -d archive"

# Generated at 2022-06-22 01:30:14.818338
# Unit test for function match
def test_match():
    from thefuck.types import Command

    assert match(Command('unzip file.zip', '', '')) is False
    assert match(Command('unzip file.zip', '', ''), _is_bad_zip=lambda x: False) is False
    assert match(Command('unzip file.zip', '', ''), _is_bad_zip=lambda x: True) is True
    assert match(Command('unzip -flag', '', ''), _is_bad_zip=lambda x: True) is False
    assert match(Command('unzip file', '', ''), _is_bad_zip=lambda x: True) is True



# Generated at 2022-06-22 01:30:26.199147
# Unit test for function side_effect
def test_side_effect():
    from tempfile import mkdtemp
    from shutil import rmtree
    from thefuck.types import Command
    from thefuck.rules.unzip import side_effect
    import os

    def touch(path):
        with open(path, 'a'):
            os.utime(path, None)

    dir_name = mkdtemp()
    path1 = os.path.join(dir_name, "foo.txt")
    path2 = os.path.join(dir_name, "bar.txt")
    path3 = os.path.join(dir_name, "baz.txt")

    touch(path1)
    touch(path2)
    touch(path3)


# Generated at 2022-06-22 01:30:38.064791
# Unit test for function side_effect
def test_side_effect():
    """
    Test that the side effect function is able to delete files and leaves the directories intact.
    """
    import thefuck.shells

    # Test that a single file and a directory in it is properly deleted.
    output = thefuck.shells.and_(
        thefuck.shells.echo(u'a'),
        thefuck.shells.echo(u'b')
    )
    with open('a', 'w') as f:
        f.write('a')
    os.mkdir('b')
    # Test that the function is able to delete a file.
    side_effect(output, command)
    assert not os.path.isfile('a')
    # Test that the function is able to skip a directory.
    assert os.path.isdir('b')
    # Test that it is able to delete two files, in

# Generated at 2022-06-22 01:30:45.784852
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('zip -r foo foo', '')) == 'zip -r foo foo -d foo'
    assert get_new_command(
        Command('unzip -d bar foo.zip', '')) == 'unzip -d bar foo.zip -d foo'
    assert get_new_command(
        Command('unzip -d bar foo.zip; unzip foo.zip', '')) == 'unzip -d bar foo.zip; unzip foo.zip -d foo'

# Generated at 2022-06-22 01:30:56.249257
# Unit test for function side_effect
def test_side_effect():
    from thefuck.tests.utils import Command
    from thefuck.rules.unzip_without_directory import side_effect

    try:
        os.makedirs('/tmp/thefuck-tmp/unzip')
    except OSError:
        pass

    with open('/tmp/thefuck-tmp/unzip/z', 'w') as f:
        f.write('z')

    side_effect(Command('unzip a.zip'), Command('unzip a.zip'))

    assert not os.path.exists('/tmp/thefuck-tmp/unzip/z')
    assert os.path.exists('/tmp/thefuck-tmp/unzip/a')



# Generated at 2022-06-22 01:30:58.193920
# Unit test for function match
def test_match():
    command = 'unzip \'file.zip\''
    assert match(command) == True


# Generated at 2022-06-22 01:31:06.826937
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    script_parts = ['unzip', 'test.zip']
    assert get_new_command(Command(' '.join(script_parts), '', '')) == 'unzip -d "test" test.zip'

    script_parts = ['unzip', 'test.zip', 'file1.txt']
    assert get_new_command(Command(' '.join(script_parts), '', '')) == 'unzip -d "test" test.zip file1.txt'

    script_parts = ['unzip', 'test.zip', 'file1.txt', '-j']
    assert get_new_command(Command(' '.join(script_parts), '', '')) == 'unzip -d "test" test.zip file1.txt -j'



# Generated at 2022-06-22 01:31:17.503698
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.unzip import get_new_command
    assert get_new_command('unzip "file.zip"', 'unzip "file.zip"') == 'unzip -d file file.zip'
    assert get_new_command('unzip "file.zip" foo bar', 'unzip "file.zip" foo bar') == 'unzip -d file file.zip foo bar'
    assert get_new_command('unzip file.zip', 'unzip file.zip') == 'unzip -d file file.zip'
    assert get_new_command('unzip file.zip foo bar', 'unzip file.zip foo bar') == 'unzip -d file file.zip foo bar'