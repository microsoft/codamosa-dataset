

# Generated at 2022-06-22 01:23:16.316481
# Unit test for function side_effect
def test_side_effect():
    with zipfile.ZipFile('./tests/fixtures/unzip_a.zip', 'w') as archive:
        archive.writestr('uni.txt', 'A test string')

    for_app('unzip')(
        Command('unzip unzip_a.zip', None, '', '', 0)).side_effect(
        Command('unzip unzip_a.zip', None, '', '', 0),
        Command('unzip -d unzip_a unzip_a.zip', None, '', '', 0))

    with open('uni.txt', 'r') as f:
        assert f.read() == 'A test string'

    os.remove('uni.txt')
    os.remove('unzip_a.zip')

# Generated at 2022-06-22 01:23:23.384831
# Unit test for function match
def test_match():
    script = "unzip myfile.zip"

    os.makedirs('temp/')
    with zipfile.ZipFile('temp/myfile.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('myfile.zip', 'content')

    command = Command(script, '', None)
    assert not match(command)

    os.makedirs('temp/')
    with zipfile.ZipFile('temp/myfile.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('content.txt', 'content')

    command = Command(script, '', None)
    assert match(command)

    shutil.rmtree('temp/')



# Generated at 2022-06-22 01:23:25.978149
# Unit test for function get_new_command
def test_get_new_command():
    expected = u'unzip -d /home/meeting-room file.zip'
    result = get_new_command(Command('unzip file.zip', '', '', 0, '', None))
    assert result == expected

# Generated at 2022-06-22 01:23:31.025404
# Unit test for function get_new_command
def test_get_new_command():
    cmd = shell.and_('unzip zipfile -d zipp')
    assert get_new_command(cmd) == 'unzip zipfile.zip -d zipp'

    cmd = shell.and_('unzip zip')
    assert get_new_command(cmd) == 'unzip zip.zip -d zip'

# Generated at 2022-06-22 01:23:43.198177
# Unit test for function side_effect
def test_side_effect():  # nocoverage
    import mock
    import tempfile
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_file_name = os.path.join(tmp_dir.name, 'test_side_effect.txt')
    with open(tmp_file_name, 'w') as file:
        file.write('Hello World!')
    old_cmd = mock.Mock(script='unzip test.zip')
    old_cmd.script_parts = old_cmd.script.split(' ')
    os.chdir(tmp_dir.name)
    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.write(tmp_file_name)
    side_effect(old_cmd, 'unzip test.zip -d test')
    os.chdir('..')
    tmp_dir

# Generated at 2022-06-22 01:23:55.108353
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip file.zip', '', '', 0)) == u'unzip -d file file.zip'
    assert get_new_command(Command('unzip file', '', '', 0)) == u'unzip -d file file.zip'
    assert get_new_command(Command('unzip file.zip -d direc', '', '', 0)) == u'unzip -d file file.zip'
    assert get_new_command(Command('unzip file.zip -b otherfile.zip', '', '', 0)) == u'unzip -d file file.zip'
    assert get_new_command(Command('unzip file.zip -d otherfile.zip', '', '', 0)) == u'unzip -d file file.zip'

# Generated at 2022-06-22 01:24:06.816568
# Unit test for function match
def test_match():
    script1 = "unzip /path/to/a-file.zip"
    script2 = "unzip /path/to/a-file.zip new_file.txt"
    script3 = "unzip /path/to/a-file.zip -d /path/to/destination"
    script4 = "unzip /path/to/a-file.zip new_file.txt -d /path/to/destination"
    script5 = "unzip /path/to/a-file.zip -x new_file.txt -d /path/to/destination"
    script6 = "unzip /path/to/a-file.zip -x new_file.txt"
    script7 = "tar xf /path/to/a-tar-file.tar"

    assert match(Command(script1))

# Generated at 2022-06-22 01:24:08.400147
# Unit test for function match
def test_match():
    assert match(Command(script='unzip -o /home/hernan/test.zip',
                         stdout=''))

# Generated at 2022-06-22 01:24:12.888357
# Unit test for function match
def test_match():
    assert not match(Command('echo lol', '', None))
    assert not match(Command('unzip -d folder file.zip', '', None))
    assert match(Command('unzip file', '', None))
    assert match(Command('unzip file.zip', '', None))



# Generated at 2022-06-22 01:24:20.927970
# Unit test for function match
def test_match():
    command1 = Command("unzip something.zip", "")
    command2 = Command("unzip something.zip -d blah blah blah", "")
    command3 = Command("unzip something.zip", "Archive:  something.zip")
    command4 = Command("unzip -d download something.zip", "")
    command5 = Command("unzip something.zip", "")
    

# Generated at 2022-06-22 01:24:38.800334
# Unit test for function match
def test_match():
    from thefuck.types import Command

    # test when unzip succeeds
    assert not match(Command('unzip success.zip', '', None))

    # test when unzip fails with bad zip
    assert match(Command('unzip bad.zip', '', None))

    # test when unzip fails with multiple files
    assert match(Command('unzip multi.zip', '', None))

    # test when unzip fails with bad zip and flags
    assert match(Command('unzip -t bad.zip', '', None))

    # test when unzip fails with bad zip and flags and path
    assert match(Command('unzip -t ~/bad.zip', '', None))

    # test when unzip fails with multiple files with flags
    assert match(Command('unzip -t multi.zip', '', None))

    # test when unzip fails with multiple

# Generated at 2022-06-22 01:24:47.395903
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    temp_dir = tempfile.TemporaryDirectory()
    sample_zip = "sample.zip"
    old_wd = os.getcwd()
    os.chdir(temp_dir.name)
    test_file = "test"
    utils.create_file(test_file, "Test content")
    os.chdir(old_wd)
    test_zip = temp_dir.name + "/" + sample_zip
    with zipfile.ZipFile(test_zip, 'w') as temp_zip:
        temp_zip.write(temp_dir.name + "/" + test_file, test_file)
    temp_dir.cleanup()

    result_command = Command(script=u"unzip {}".format(test_zip),
                             side_effect=side_effect)

    result

# Generated at 2022-06-22 01:25:00.259973
# Unit test for function side_effect
def test_side_effect():
    # Create a test ZIP file
    with zipfile.ZipFile(u'test.zip', 'w') as archive:
        archive.writestr(u'existing_file', u'')
        archive.writestr(u'folder/existing_file_in_folder', u'')
        archive.writestr(u'none_existing_file', u'')

    # Replace the old working directory
    old_path = os.getcwd()
    os.chdir(old_path)

    # Make sure the file we want to remove exists
    open(u'existing_file', 'w').close()
    os.mkdir(u'folder')
    open(u'folder/existing_file_in_folder', 'w').close()

    # Create a test Command object

# Generated at 2022-06-22 01:25:11.976672
# Unit test for function side_effect
def test_side_effect():
    import mock
    mock_archive = mock.Mock()
    mock_archive.namelist.return_value = ['f', 'foo/bar.txt', '../baz.txt']
    with mock.patch('thefuck.rules.unzip_all.zipfile.ZipFile'):
        zipfile.ZipFile.return_value.__enter__.return_value = mock_archive
        with mock.patch('thefuck.rules.unzip_all.os.remove'):
            side_effect('unzip lol', 'unzip -d out/ lol')
            assert os.remove.call_count == 1
            mock.patch('thefuck.rules.unzip_all._zip_file').return_value = 'lol.zip'

# Generated at 2022-06-22 01:25:19.857380
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(command=u'unzip zipfile.zip') ==
           u'unzip zipfile.zip -d zipfile')
    assert(get_new_command(command=u'unzip -v zipfile.zip') ==
           u'unzip -v zipfile.zip -d zipfile')
    assert(get_new_command(command=u'unzip -v zipfile.zip file1') ==
           u'unzip -v zipfile.zip file1 -d zipfile')
    assert(get_new_command(command=u'unzip -v file1 -d dir') ==
           u'unzip -v file1 -d dir')

# Generated at 2022-06-22 01:25:27.507420
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.rules.sudo_extract_files import side_effect

    script = 'unzip -d file.zip'
    c = Command(script, '', None)
    side_effect(c, c)
    assert _is_bad_zip('file.zip') is True

    script = 'sudo unzip -d file.zip'
    c = Command(script, '', None)
    side_effect(c, c)
    assert _is_bad_zip('file.zip') is False

# Generated at 2022-06-22 01:25:35.024404
# Unit test for function side_effect
def test_side_effect():
    # create test.zip which has test.txt in it
    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.writestr('test.txt', 'hello world')
    # write test.txt on disk
    with open('test.txt', 'w') as f:
        f.write('hello world')
    # run function side_effect
    side_effect(create_command(script='unzip test.zip'), create_command(script='unzip -d test.zip'))
    # check that test.txt was overwritten on disk
    assert open('test.txt', 'r').read() == 'hello world'

# Generated at 2022-06-22 01:25:36.971535
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip spam.zip', '')) == 'unzip -d spam spam.zip'

# Generated at 2022-06-22 01:25:48.391376
# Unit test for function side_effect
def test_side_effect():
    # initialize a file
    with open('test.txt', 'w') as f:
        f.write('hello\n')
    # initialize a directory
    os.makedirs('testdir')

    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.write('test.txt')
        archive.write('testdir')

    side_effect(['unzip', 'test.zip'], ['unzip', 'test.zip'])
    assert os.path.isfile('test.txt')
    assert os.path.isdir('testdir')

    side_effect(['unzip', 'test.zip', 'test.txt'],
                ['unzip', 'test.zip', 'test.txt'])
    assert os.path.isfile('test.txt')
    assert os.path.isdir

# Generated at 2022-06-22 01:25:52.429333
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.unzip import get_new_command
    assert get_new_command('unzip something.zip') == 'unzip -d something something.zip'
    assert get_new_command('unzip something-else.zip') == 'unzip -d something-else something-else.zip'
    assert get_new_command('unzip -h') == 'unzip -h'

# Generated at 2022-06-22 01:26:09.211355
# Unit test for function side_effect
def test_side_effect():
    from .utils import TemporaryDirectory
    from .types import Command

    # create a zip file
    with TemporaryDirectory() as tmpdir:
        data = 'test data'

        # create nested directories for the test
        for dirname in ['foo', 'bar']:
            os.mkdir(os.path.join(tmpdir, dirname))
            with open(os.path.join(tmpdir, dirname, 'test'), 'wb') as file:
                file.write(data)

        # zip the directory
        zip_name = os.path.join(tmpdir, 'test.zip')

# Generated at 2022-06-22 01:26:11.425564
# Unit test for function match
def test_match():
    assert _is_bad_zip('test.zip')
    assert not _is_bad_zip('test.txt')

# Generated at 2022-06-22 01:26:22.821233
# Unit test for function side_effect
def test_side_effect():
    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'foo.txt')
    with open(test_file, 'w') as f:
        f.write('')
    os.chdir(test_dir)
    old_cmd = type('Command', (object, ), {})()
    old_cmd.script = 'unzip foo.txt'
    zip_file = zipfile.ZipFile('f.zip', 'w')
    zip_file.write(test_file)
    zip_file.close()
    os.remove(test_file)
    command = type('Command', (object, ), {})()
    command.script = 'unzip f.zip'
    side_effect(old_cmd, command)

# Generated at 2022-06-22 01:26:33.522071
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("unzip foobar.zip") == u"unzip -d foobar foobar.zip"
    assert get_new_command("unzip -D foobar.zip") == u"unzip -D -d foobar foobar.zip"
    assert get_new_command("unzip -D foobar.zip -x *.jar") == u"unzip -D -d foobar foobar.zip -x *.jar"
    assert get_new_command("unzip -D -o foobar.zip") == u"unzip -D -o -d foobar foobar.zip"
    assert get_new_command("unzip -D -o foobar.zip -x *.jar") == u"unzip -D -o -d foobar foobar.zip -x *.jar"

# Generated at 2022-06-22 01:26:43.776065
# Unit test for function side_effect
def test_side_effect():
    from thefuck import main
    from thefuck.shells import get_shell
    from thefuck.rules.unzip_all_files import side_effect

    shell_ = get_shell()
    command = shell_.from_raw_script('unzip rckt-cli-v0.0.8-darwin-x64.zip')
    old_cmd = shell_.from_raw_script('unzip rckt-cli-v0.0.8-darwin-x64.zip')
    side_effect(old_cmd, command)
    assert main.get_closest('rckt-cli-v0.0.8-darwin-x64')

# Generated at 2022-06-22 01:26:55.256953
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command(script='unzip file',
                                   stderr='caution: filename not matched')) == \
           'unzip -d file file'
    assert get_new_command(Command(script='unzip file.zip',
                                   stderr='caution: filename not matched')) == \
           'unzip -d file file.zip'
    assert get_new_command(Command(script='unzip -l -d file',
                                   stderr='caution: filename not matched')) == \
           'unzip -l -d file file'

# Generated at 2022-06-22 01:26:58.019442
# Unit test for function side_effect
def test_side_effect():
    import os
    from tests.utils import Command
    
    command = Command('unzip file.zip', '')
    side_effect(command, '')

# Generated at 2022-06-22 01:27:07.019007
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert 'unzip archive.zip -d /tmp' == get_new_command(
            Command('unzip archive.zip', None))
    assert 'unzip -l archive.zip -d /tmp' == get_new_command(
            Command('unzip -l archive.zip', None))
    assert 'unzip -l archive.zip -d /tmp' == get_new_command(
            Command('unzip -l archive.zip', None))
    assert 'unzip -l -d /tmp archive.zip' == get_new_command(
            Command('unzip -l -d /tmp archive.zip', None))

# Generated at 2022-06-22 01:27:19.107551
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command = Command('unzip exampleArchive.zip')
    assert get_new_command(command) == u'unzip -d exampleArchive exampleArchive.zip'
    command = Command('unzip exampleArchive')
    assert get_new_command(command) == u'unzip -d exampleArchive exampleArchive.zip'
    command = Command('unzip -pe exampleArchive.zip')
    assert get_new_command(command) == u'unzip -pe -d exampleArchive exampleArchive.zip'
    command = Command('unzip -pe exampleArchive')
    assert get_new_command(command) == u'unzip -pe -d exampleArchive exampleArchive.zip'
    command = Command('unzip -Pe exampleArchive.zip')
    assert get_new_

# Generated at 2022-06-22 01:27:27.263829
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('unzip file.zip', '', '')) == u'unzip -d file file.zip'
    assert get_new_command(
        Command('unzip -o file.zip', '', '')) == u'unzip -d file -o file.zip'
    assert get_new_command(
        Command('unzip -o file_with_extensions_in_name.zip', '', '')) == u'unzip -d file_with_extensions_in_name -o file_with_extensions_in_name.zip'

# Generated at 2022-06-22 01:27:43.562708
# Unit test for function get_new_command
def test_get_new_command():
    script = '/usr/bin/unzip -o foo.zip'
    command = Command(script, 'unzip:  cannot find or open foo.zip, foo.zip.zip or foo.zip.ZIP')
    assert get_new_command(command) == '/usr/bin/unzip -o -d foo foo.zip'

    script = '/usr/bin/unzip -o foo.bar'
    command = Command(script, 'unzip:  cannot find or open foo.bar, foo.bar.zip or foo.bar.ZIP')
    assert get_new_command(command) == '/usr/bin/unzip -o -d foo foo.bar'

    script = '/usr/bin/unzip -o -d target foo.bar'

# Generated at 2022-06-22 01:27:55.820275
# Unit test for function side_effect
def test_side_effect():
    filename = 'test_side_effect.zip'
    with zipfile.ZipFile(filename, 'w') as archive:
        archive.writestr('test_side_effect.txt', 'content')

    # opens a file in write and close it, otherwise rmtree cannot delete the
    # directory
    with open('test_side_effect', 'w'):
        pass

    try:
        side_effect(create_mock_cmd('unzip {}'.format(filename)), None)
        assert os.path.exists(os.path.join(os.getcwd(), 'test_side_effect'))
        assert not os.path.exists(os.path.join(os.getcwd(),
                                               'test_side_effect.txt'))
    finally:
        os.remove(filename)

# Generated at 2022-06-22 01:27:59.003334
# Unit test for function match
def test_match():
    assert match(Command('unzip', 'unzip.zip'))
    assert match(Command('unzip', 'unzip'))
    assert not match(Command('unzip', '-d unzip.zip'))

# Generated at 2022-06-22 01:28:11.107027
# Unit test for function match
def test_match():
    # files
    assert match(Command('unzip file.zip', '', None))
    assert match(Command('unzip another_file.zip', '', None))
    assert match(Command('unzip file', '', None))
    assert match(Command('unzip file.zip file2.zip', '', None))
    assert match(Command('unzip file -x', '', None))
    assert match(Command('unzip -t', '', None))
    assert match(Command('unzip file.zip file2.zip -x file.pyc', '', None))
    assert match(Command('unzip "file.zip"', '', None))
    assert match(Command('unzip "file.zip" file2.zip', '', None))
    assert not match(Command('unzip -d file.zip', '', None))
   

# Generated at 2022-06-22 01:28:14.819948
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("unzip x.zip") == "unzip -d 'x' x.zip"
    assert get_new_command("unzip x") == "unzip -d 'x' x"



# Generated at 2022-06-22 01:28:24.637619
# Unit test for function get_new_command
def test_get_new_command():
    command1 = type(u'command', (object,), {u'script_parts': u'unzip afile.zip'.split(), u'script': u'unzip afile.zip'})
    assert get_new_command(command1) == u'unzip -d afile'

    command2 = type(u'command', (object,), {u'script_parts': u'unzip afile.zip -d'.split(), u'script': u'unzip afile.zip -d'})
    assert get_new_command(command2) == u'unzip -d afile'

    command3 = type(u'command', (object,), {u'script_parts': u'unzip -d afile.zip'.split(), u'script': u'unzip -d afile.zip'})
    assert get_new_

# Generated at 2022-06-22 01:28:35.181808
# Unit test for function side_effect
def test_side_effect():
    import shutil
    root = '/tmp/unzip'
    zip_path = '/tmp/unzip/archive.zip'
    file_path = '/tmp/unzip/root/file1.txt'
    dir_path = '/tmp/unzip/root/dir1'
    file_path2 = '/tmp/unzip/file2.txt'
    os.makedirs(root)
    with zipfile.ZipFile(zip_path, 'w') as zf:
        zf.writestr('root/file1.txt', 'its text file')
        zf.writestr('root/dir1/file2.txt', 'its text file inside directory')
    side_effect(None, None)
    assert open(file_path).read().strip() == 'its text file'

# Generated at 2022-06-22 01:28:42.932617
# Unit test for function match
def test_match():
    # Should be matched
    assert match(Command(script='unzip 1.zip', stderr='error',
                         stdout=''))
    assert match(Command(script='unzip 1.zip', stderr='file exists',
                         stdout=''))
    # Should be not matched
    assert not match(Command(script='unzip 1.zip -d 2', stderr='error',
                             stdout=''))
    assert not match(Command(script='unzip 1.zip', stderr='error',
                             stdout='text'))



# Generated at 2022-06-22 01:28:48.308656
# Unit test for function match
def test_match():
    from thefuck.rules.unzip_flag_d import match
    from tests.utils import Command

    assert match(Command('unzip archive.zip'))
    assert not match(Command('unzip -d archive.zip'))
    assert not match(Command('unzip archive_foo.zip'))
    assert not match(Command('unzip archive.tar'))

# Generated at 2022-06-22 01:28:48.937024
# Unit test for function side_effect
def test_side_effect():
    pass

# Generated at 2022-06-22 01:29:07.452794
# Unit test for function get_new_command
def test_get_new_command():
    example = Command('unzip archive.zip')
    assert get_new_command(example) == 'unzip -d archive archive.zip'

    example = Command('unzip archive')
    assert get_new_command(example) == 'unzip -d archive archive.zip'

    example = Command('unzip -flags archive.zip')
    assert get_new_command(example) == 'unzip -d archive -flags archive.zip'

    example = Command('unzip -flags archive')
    assert get_new_command(example) == 'unzip -d archive -flags archive.zip'

    example = Command('unzip -flags archive1 archive2')
    assert get_new_command(example) == 'unzip -d archive1 -flags archive1 archive2'

    example = Command('unzip -flags archive1.zip archive2')
   

# Generated at 2022-06-22 01:29:10.129229
# Unit test for function get_new_command
def test_get_new_command():
    command = 'unzip test.zip'
    assert get_new_command(Command(command, '')) == 'unzip -d test test.zip'



# Generated at 2022-06-22 01:29:18.615470
# Unit test for function side_effect
def test_side_effect():
    command = u'unzip test.zip if.csv'
    old_cmd = u'unzip test.zip if.csv'
    try:
        os.mkdir('test')
        side_effect(old_cmd, command)
        assert not os.path.exists('test.zip')
        assert os.path.exists('if.csv')
        assert os.path.exists('test')
    finally:
        print('Remove file if.csv')
        os.remove('if.csv')
        print('Remove folder test')
        os.removedirs('test')

# Generated at 2022-06-22 01:29:30.396907
# Unit test for function side_effect
def test_side_effect():
    import os
    import shutil
    import stat
    import tempfile
    import zipfile
    from thefuck.types import Command

    with tempfile.TemporaryDirectory() as tmpdir:
        zip_path = os.path.join(tmpdir, 'test.zip')
        with zipfile.ZipFile(zip_path, 'w') as zip_file:
            zip_file.writestr('test_file', 'content')
            zip_file.writestr('test_dir/test_file', 'content')

        old_cmd = Command('unzip test', '')
        old_cmd.script_parts = ['unzip', 'test.zip']
        new_cmd = Command('unzip test', '')
        new_cmd.script_parts = ['unzip', '-d', 'test', 'test.zip']

       

# Generated at 2022-06-22 01:29:39.646719
# Unit test for function match
def test_match():
    assert match(Command('unzip jasdkl.zip', '')) is False
    assert match(Command('unzip -d jasdkl.zip', '')) is False
    assert match(Command('unzip jasdkl.zip file.txt', '')) is True
    assert match(Command('unzip jasdkl.zip -X file.txt', '')) is False
    assert match(Command('unzip file.txt', '')) is True
    assert match(Command('unzip file', '')) is True
    assert match(Command('unzip file.txt', '')) is True
    assert match(Command('unzip file', '')) is True


# Generated at 2022-06-22 01:29:42.933283
# Unit test for function match
def test_match():
    assert _is_bad_zip('/some/path/somefile.zip') is True
    assert _is_bad_zip('/some/path/somefile.ext') is False

# Generated at 2022-06-22 01:29:50.057954
# Unit test for function match

# Generated at 2022-06-22 01:30:02.254369
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil

    def create_file(path, content):
        with open(path, 'w') as file:
            file.write(content)

    with tempfile.TemporaryDirectory() as tmp:
        create_file(os.path.join(tmp, '1'), '1')
        create_file(os.path.join(tmp, '2'), '2')

        with zipfile.ZipFile(os.path.join(tmp, 'archive.zip'), 'w') as archive:
            archive.write(os.path.join(tmp, '1'), '1.txt')
            archive.write(os.path.join(tmp, '2'), '2.txt')

        create_file(os.path.join(tmp, '1.txt'), '1.txt')
        folder = os.path.join

# Generated at 2022-06-22 01:30:14.633192
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('unzip test.zip', './'))
    assert match(Command('unzip -t test.zip', './'))
    assert match(Command('unzip test.zip test2.zip', './'))
    assert match(Command('unzip test.zip test2.zip file1 file2', './'))
    assert not match(Command('unzip -d test.zip', './'))
    assert not match(Command('unzip test.zip', './', stderr='test.zip'))
    assert not match(Command('unzip test.zip test2.zip', './', stderr='test.zip'))
    assert not match(Command('unzip test.zip file1 file2', './', stderr='test.zip'))

# Generated at 2022-06-22 01:30:20.378405
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip archive.zip foo/bar.txt')) == 'unzip archive.zip foo/bar.txt -d archive'
    assert get_new_command(Command('unzip archive.zip foo/bar.txt -x foo/baz.txt')) == 'unzip archive.zip foo/bar.txt -x foo/baz.txt -d archive'

# Generated at 2022-06-22 01:30:41.622035
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("unzip ~/Documents/competitions/sentiment-analysis-on-movie-reviews/test.tsv.zip") == "unzip ~/Documents/competitions/sentiment-analysis-on-movie-reviews/test.tsv.zip -d test.tsv"


# Generated at 2022-06-22 01:30:44.911327
# Unit test for function get_new_command
def test_get_new_command():
    script = 'unzip test.zip'
    command = Command(script, '')
    assert get_new_command(command) == 'unzip -d test test.zip'

# Generated at 2022-06-22 01:30:47.512784
# Unit test for function match
def test_match():
    from thefuck.rules.zip_file import match
    script = "unzip file.zip"
    assert(match(script))

# Generated at 2022-06-22 01:30:51.965614
# Unit test for function match
def test_match():
    assert match(Command('unzip archive.zip'))
    assert not match(Command('unzip archive.zip -d subdirectory'))
    assert not match(Command('unzip -l archive.zip'))
    assert not match(Command('ls'))



# Generated at 2022-06-22 01:31:03.242417
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('unzip archive.zip one.txt', '''caution:   one.txt appears to 
    include path information; this does not 
    work in all cases.
    file #1:  bad zipfile offset (local header 
    sig):  2
     (attempting to re-compensate)
    file #1:  bad zipfile offset (local header 
    sig):  2
    warning [archive.zip]:  2 extra bytes at 
    beginning or within zipfile
    (attempting to process anyway)
    error [archive.zip]:  reported length of 
    central directory is -1 bytes too long (At 
    least one entry
    ''', '', 0, 'unzip archive.zip one.txt')) == True

# Generated at 2022-06-22 01:31:14.962027
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip helloWorld.zip', '')) ==  'unzip helloWorld.zip -d helloWorld'
    assert get_new_command(Command('unzip -h', '')) == 'unzip -h'
    assert get_new_command(Command('unzip -p', '')) == 'unzip -p'
    assert get_new_command(Command('unzip -l', '')) == 'unzip -l'
    assert get_new_command(Command('unzip -t', '')) == 'unzip -t'
    assert get_new_command(Command('unzip -v', '')) == 'unzip -v'
    assert get_new_command(Command('unzip -L', '')) == 'unzip -L'


# Generated at 2022-06-22 01:31:23.931533
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip -x filefoo.zip filebar', ''))
    assert get_new_command(Command('unzip filefoo.zip filebar', ''))
    assert get_new_command(Command('unzip filefoo.zip.zip filebar', ''))
    assert get_new_command(Command('unzip filefoo.zip foo/filebar', ''))
    assert get_new_command(Command('unzip filefoo.zip foo/filebar foo/another/file', ''))
    assert get_new_command(Command('unzip filefoo.zip filebar -x wow', ''))
    assert get_new_command(Command('unzip filefoo.zip filebar -x "wow something"', ''))

# Generated at 2022-06-22 01:31:34.729658
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import Bash
    test_shell = Bash()
    
    # Setup a file for removal
    import tempfile
    temp_file_path = tempfile.mkstemp()[1]
    
    # First try to remove a non-existing file
    test_shell.system(u'rm ' + temp_file_path + u'_not_exists', None)
    
    # Remove the file
    test_shell.system(u'rm ' + temp_file_path, None)
    assert not os.path.isfile(temp_file_path)
    
    # Try to remove the file again
    test_shell.system(u'rm ' + temp_file_path, None)

# Generated at 2022-06-22 01:31:35.372132
# Unit test for function side_effect
def test_side_effect():
    pass

# Generated at 2022-06-22 01:31:43.021700
# Unit test for function side_effect
def test_side_effect():
    old_cmd = type('FakeCommand', (object,), {'script_parts': ['/bin/unzip', 'pkg.zip']})
    command = type('FakeCommand', (object,), {'script_parts': ['/bin/unzip', 'pkg.zip', '-d', 'pkg']})
    side_effect(old_cmd, command)
    assert not os.path.exists('pkg.zip')
    assert not os.path.exists('file')
    assert not os.path.exists('pkg')

# Generated at 2022-06-22 01:32:22.171709
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command(script='unzip test.zip', stderr='')) == \
        'unzip -d test test.zip'
    assert get_new_command(Command(script='unzip test1.zip test2.zip',
                                   stderr='')) == \
        'unzip -d test1 test1.zip test2.zip'
    assert get_new_command(Command(script='unzip -v test1.zip test2.zip',
                                   stderr='')) == \
        'unzip -d test1 -v test1.zip test2.zip'

# Generated at 2022-06-22 01:32:31.068129
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'unzip file.zip') == u'unzip -d file file.zip'
    assert get_new_command(u'unzip -q file.zip') == u'unzip -q -d file file.zip'
    assert get_new_command(u'unzip -qo file.zip') == u'unzip -qo -d file file.zip'
    assert get_new_command(u'unzip -qqox file.zip') == u'unzip -qqox -d file file.zip'

# Generated at 2022-06-22 01:32:41.324766
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os
    temp_dir = tempfile.mkdtemp()
    file = os.path.join(temp_dir, 'file.txt')
    dir = os.path.join(temp_dir, 'dir')
    os.makedirs(dir)
    fh = open(file, "w")
    fh.write("data")
    fh.close()
    old_cmd = 'unzip {}/archive.zip'.format(temp_dir)
    command = get_new_command(old_cmd)
    side_effect(old_cmd, command)
    assert open(file).read() == 'data'
    assert os.path.isdir(dir)
    shutil.rmtree(temp_dir)

# Generated at 2022-06-22 01:32:52.746573
# Unit test for function match
def test_match():
    assert match(Command('unzip selenium-server-standalone-2.53.1.jar'))
    assert not match(Command('unzip selenium-server-standalone-2.53.1.jar -d /usr/local/bin/'))
    assert match(Command('unzip /path/to/selenium-server-standalone-2.53.1.jar'))
    assert match(Command('zip -r foo.zip bar'))
    assert not match(Command('zip -r foo.zip bar -d /path/to/bar'))
    assert match(Command('unzip -qq selenium-server-standalone-2.53.1.jar'))
    assert match(Command('unzip -qq /path/to/selenium-server-standalone-2.53.1.jar'))
   

# Generated at 2022-06-22 01:32:58.467145
# Unit test for function match
def test_match():
    # test when zipfile contains multiple files
    assert match(Command('unzip test.zip'))
    assert match(Command('unzip test.zip file1 file2'))
    assert not match(Command('unzip -d test test.zip'))
    assert not match(Command('unzip file1 file2'))


# Generated at 2022-06-22 01:33:03.274988
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', stderr='error'))
    assert not match(Command('unzip -d file file.zip', '', stderr='error'))
    assert not match(Command('unzip file.zip', '', stderr=''))

