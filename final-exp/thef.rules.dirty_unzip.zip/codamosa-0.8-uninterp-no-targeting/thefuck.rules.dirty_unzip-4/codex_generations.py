

# Generated at 2022-06-22 01:23:16.316649
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.chdir(tmpdirname)
        # Create a text file to be zipped
        text_file = open("test.txt", "w")
        text_file.write("This is a simple test")
        text_file.close()
        # Create a zip file
        open("test.zip", "w").close()
        zipf = zipfile.ZipFile("test.zip", "a")
        zipf.write("test.txt", "test.txt", zipfile.ZIP_DEFLATED)
        zipf.close()
        # Imitate command
        old_cmd = shell.And('', 'unzip test.zip', 'unzip test.zip')
        # Run side_effect
        side_effect(old_cmd, '')

# Generated at 2022-06-22 01:23:17.283010
# Unit test for function side_effect
def test_side_effect():
    assert side_effect(None, None) is None

# Generated at 2022-06-22 01:23:27.437954
# Unit test for function match
def test_match():
    match_results = [
        ('unzip foo.zip', False),
        ('unzip -d foo.zip', False),
        ('unzip foo', False),
        ('unzip foo.zip bar.zip', False),
        ('unzip foo.zip -x bar.zip', False),
        ('unzip foo.zip bar', False),
        ('unzip foo.zip bar.zip qux.zip', False),
        ('unzip bar.zip', True),
        ('unzip bar', True),
        ('unzip foo bar', True),
        ('unzip foo.zip bar.zip quux.zip', True)]

    for test in match_results:
        assert match(Command(test[0], '')) == test[1]


## Test for function get_new_command

# Generated at 2022-06-22 01:23:39.247725
# Unit test for function side_effect
def test_side_effect():
    old_cmd = type('', (object,), {'script': 'unzip file.zip',
                                   'script_parts': ['unzip', 'file.zip']})
    command = type('', (object,), {'script': 'unzip -d file file.zip'})
    file_to_unzip = 'file.zip'
    file_to_remove = 'file'

# Generated at 2022-06-22 01:23:43.871696
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip'))
    assert match(Command('unzip test.zip file1'))
    assert match(Command('unzip test.zip file1 file2 -d test'))
    assert not match(Command('unzip test.zip -d test'))



# Generated at 2022-06-22 01:23:53.116180
# Unit test for function side_effect
def test_side_effect():
    class FakeCommand:
        def __init__(self, script):
            self.script = script

    # test script
    script = "unzip game.zip -d game"

    # create the test zip file
    zf = zipfile.ZipFile("game.zip", "w")
    zf.write("game.py")
    zf.write("game.txt")
    zf.write("folder")
    zf.close()

    # call the function side_effect
    side_effect(FakeCommand(script), script)

    # assert file is removed
    assert not os.path.isfile("game.py")

# Generated at 2022-06-22 01:23:59.737231
# Unit test for function match
def test_match():
    assert match(Command('unzip a.zip'))
    assert match(Command('unzip a.zip b.zip'))
    assert match(Command('unzip a.zip -x b.txt'))
    assert not match(Command('unzip'))
    assert not match(Command('unzip -d test a.zip'))
    assert not match(Command('unzip a.zip -d test'))
    assert not match(Command('unzip -d test a.zip -x b.txt'))

# Generated at 2022-06-22 01:24:11.820833
# Unit test for function side_effect
def test_side_effect():
    old_cmd = 'unzip test.zip'
    command = 'unzip -d test_dir test.zip'
    test_dir = 'test_dir'
    test_file_in_dir = 'file_in_dir'
    test_file = 'test_file'
    if not os.path.exists(test_dir):
        os.makedirs(test_dir)
    with open(os.path.join(test_dir, test_file_in_dir), 'w') as tfid:
        tfid.write('test file in dir')
    with open(test_file, 'w') as tf:
        tf.write('test file')
    with zipfile.ZipFile('test.zip', 'w') as zip_test:
        zip_test.write(test_file_in_dir)
       

# Generated at 2022-06-22 01:24:18.922992
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('unzip abc.zip') == 'unzip -d abc abc.zip'
    assert get_new_command('unzip abc.zip a.txt b.txt') == 'unzip -d abc abc.zip a.txt b.txt'
    assert get_new_command('unzip -a abc.zip') == 'unzip -a -d abc abc.zip'
    assert get_new_command('unzip -a -e abc.zip') == 'unzip -a -e -d abc abc.zip'



# Generated at 2022-06-22 01:24:26.392294
# Unit test for function side_effect
def test_side_effect():
    zip = zipfile.ZipFile('.test_zip.zip', 'w')
    with zip:
        zip.writestr('file1.txt', 'content')
        zip.writestr('subdir/file2.txt', 'content')

    side_effect(None, None)
    assert not os.path.isfile('file1.txt')
    assert not os.path.isfile('subdir/file2.txt')

# Generated at 2022-06-22 01:24:42.028135
# Unit test for function side_effect
def test_side_effect():
    zip_file = ZipFile('test_zip.zip', 'w')
    zip_file.writestr('test.txt', 'test')
    zip_file.close()
    assert open('test.txt') == 'test'
    assert os.path.isfile('test_zip.zip')
    side_effect('unzip test_zip.zip', 'unzip test_zip.zip -d test_zip')
    assert os.path.isfile('test_zip/test.txt')
    assert not os.path.isfile('test_zip.zip')
    assert not os.path.isfile('test.txt')

# Generated at 2022-06-22 01:24:47.902491
# Unit test for function match
def test_match():
    assert match(Command('unzip foo.zip'))
    assert not match(Command('unzip foo.zip', 'unzip: foo.zip: Not a valid zip file'))
    assert not match(Command('unzip foo.zip -d dest/'))
    assert not match(Command('unzip -t foo.zip'))


# Generated at 2022-06-22 01:25:00.504098
# Unit test for function side_effect
def test_side_effect():
    archive_name = "./test.zip"
    with zipfile.ZipFile(archive_name, 'w') as archive:
        # add existing file
        archive.write('./test.py')
        # add a new file
        archive.writestr('new_file.txt', "new file")
        # add a subdir
        archive.writestr('subdir/subdir.txt', "subdir")
    # test
    mock_command = type('MockCommand', (object,), {
        'script': 'unzip ./test.zip',
        'script_parts': ['unzip', './test.zip']
    })
    side_effect(mock_command, mock_command)
    assert os.path.isfile('./test.py')

# Generated at 2022-06-22 01:25:12.269462
# Unit test for function side_effect
def test_side_effect():
    # First create a temp directory
    test_dir = tempfile.mkdtemp()
    os.chdir(test_dir)

    # Create a file in it
    filename = 'test.txt'
    json.dump(dict(foo='bar'), open(filename, 'w'))

    # Compress it into a zip file
    zip_file = 'test.zip'
    with zipfile.ZipFile(zip_file, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.write(filename)

    # Call side_effect with a command object containing the file
    command = shell.And('', '', '', '', ['unzip', zip_file])
    side_effect(command, command)

    # Check if the file has been removed
    assert(not os.path.isfile(filename))

# Generated at 2022-06-22 01:25:15.429582
# Unit test for function match
def test_match():
    old_cmd = Command("unzip stuff.zip -d output")
    test_cmd = Command("unzip stuff.zip -d output")
    assert match(old_cmd) == False


# Generated at 2022-06-22 01:25:19.570238
# Unit test for function get_new_command
def test_get_new_command():
    command = 'unzip a/b/c.zip'
    assert get_new_command(command) == 'unzip -d a/b/c a/b/c.zip'

# Generated at 2022-06-22 01:25:30.823167
# Unit test for function side_effect
def test_side_effect():
  # create a temporary directory
  temp_dir_path = tempfile.mkdtemp()
  # change working directory to a new temporary directory
  os.chdir(temp_dir_path)
  # create a subdirectory
  sub_dir_path = temp_dir_path + "/test_side_effect_sub"
  os.mkdir(sub_dir_path)
  # create a file
  temp_file_path = temp_dir_path + "/test_side_effect_tmp.txt"
  test_file = open(temp_file_path,"w")
  test_file.write("test")
  test_file.close()

  # change working directory to a subdirectory
  os.chdir(sub_dir_path)
  # create a zip file

# Generated at 2022-06-22 01:25:35.993413
# Unit test for function match
def test_match():
    command = type('obj', (object,), {'script': 'unzip foo.zip'})
    assert match(command)
    command = type('obj', (object,), {'script': 'unzip -d foo.zip'})
    assert not match(command)



# Generated at 2022-06-22 01:25:44.202072
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.unzip_without_directory import get_new_command
    assert get_new_command('unzip file.zip') == 'unzip -d file file.zip'
    assert get_new_command('unzip -L file.zip') == 'unzip -L -d file file.zip'
    assert get_new_command('unzip -o file.zip') == 'unzip -o -d file file.zip'
    assert get_new_command('unzip file') == 'unzip -d file file.zip'

# Generated at 2022-06-22 01:25:53.713366
# Unit test for function side_effect
def test_side_effect():
    # Generate a zip file containing a text file called 'test1.txt'
    with zipfile.ZipFile('test.zip', 'w') as zip_file:
        zip_file.writestr('test1.txt', "1111")
    # Create a text file called 'test1.txt' in current directory
    with open('test1.txt', 'w') as file:
        file.write('A test file')
    # Test unzip
    old_cmd = u'unzip test.zip'
    command = u'unzip -d {} test.zip'.format(shell.quote('test.zip'))
    side_effect(old_cmd, command)
    with open('test1.txt', 'r') as file:
        assert file.read() == "1111"

# Generated at 2022-06-22 01:26:07.921923
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', ''))
    assert match(Command('unzip file', '', ''))
    assert not match(Command('unzip -d file.zip', '', ''))
    assert not match(Command('unzip -d file', '', ''))
    assert not match(Command('unzip -d', '', ''))
    assert not match(Command('unzip -d', '', ''))
    assert not match(Command('unzip', '', ''))
    assert not match(Command('unzip -', '', ''))



# Generated at 2022-06-22 01:26:15.091298
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert not match(Command('unzip test.zip', ''))
    assert match(Command('unzip test.zip make.sh', ''))
    assert match(Command('unzip make.sh', ''))
    assert not match(Command('unzip -d make make.sh', ''))
    assert not match(Command('unzip --help', ''))
    assert match(Command('unzip make.zip make.sh', ''))

# Generated at 2022-06-22 01:26:24.555911
# Unit test for function match
def test_match():
    assert match(Command('unzip -d output.zip', '')) is False
    assert match(Command('unzip output.zip', '')) is False
    assert match(Command('unzip output', '')) is False
    assert match(Command('unzip output.zip file.txt', '')) is False
    assert match(Command('unzip output.zip file.txt -d output/', '')) is False
    assert match(Command('unzip output.zip file.txt -d output/', '')) is False
    assert match(Command('unzip output.zip file.txt -d output/', '')) is False
    assert match(Command('unzip output.zip file.txt -d output/', '')) is False
    assert match(Command('unzip output.zip file.txt -d output/', '')) is False

# Generated at 2022-06-22 01:26:31.597355
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command('unzip test.zip test1.txt test2.txt test3.txt')
    command = Command('unzip test.zip -d test')
    side_effect(old_cmd, command)
    assert not os.path.exists('test1.txt')
    assert not os.path.exists('test2.txt')
    assert not os.path.exists('test3.txt')
    assert not os.path.exists('test')

# Generated at 2022-06-22 01:26:43.290435
# Unit test for function side_effect
def test_side_effect():
    dir_name = "unzip_test"
    os.mkdir(dir_name)
    os.mkdir(os.path.join(dir_name, "test_dir"))
    file = open(os.path.join(dir_name, "file.txt"), "w")
    file.close()
    file = open(os.path.join(dir_name, "test_dir", "other_file.txt"), "w")
    file.close()
    zip_file = zipfile.ZipFile("unzip_test.zip", "w")
    zip_file.write(os.path.join(dir_name, "file.txt"))
    zip_file.write(os.path.join(dir_name, "test_dir", "other_file.txt"))
    zip_file.close()

    os.ch

# Generated at 2022-06-22 01:26:53.981895
# Unit test for function side_effect
def test_side_effect():
    """
    Test that side_effect works properly
    """
    import tempfile
    import os.path

    # create temporary directory and save it's path in a variable
    with tempfile.TemporaryDirectory() as tempdir:
        # create temporary file in temporary directory
        temp_file = tempfile.NamedTemporaryFile(dir=tempdir)
        # close the file so it can be used in zipfile later
        temp_file.close()

        # create a zip file
        archive = zipfile.ZipFile(os.path.join(tempdir, 'file.zip'), 'w')
        # archive the temporary file
        archive.write(temp_file.name, arcname='file')
        # close the zip file
        archive.close()

        # run side_effect and pass temp_file.name in order to delete it
        side_

# Generated at 2022-06-22 01:27:05.553181
# Unit test for function get_new_command
def test_get_new_command():
    # test for command that has zip file name and directory name separate
    assert get_new_command(Command('unzip file.zip', '~')) == 'unzip -d file file.zip'
    # test for command with zip file name and directory name together
    assert get_new_command(Command('unzip file', '~')) == 'unzip -d file file'
    # test for command with zip file name and directory name together with path
    assert get_new_command(Command('unzip b/file', '~')) == 'unzip -d b/file b/file'
    # test for command with zip file name and directory name together with path and zip file extension
    assert get_new_command(Command('unzip b/test.zip', '~')) == 'unzip -d b/test.zip b/test.zip'


# Generated at 2022-06-22 01:27:17.743509
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Mock(
        script=u'unzip foo.zip',
        script_parts=[u'unzip', u'foo.zip']
    )

    # This will be temp file
    tmp_file = os.path.join(os.getcwd(), 'tmp/foo.txt')
    os.makedirs('tmp')
    open(tmp_file, 'a').close()

    try:
        # Assert that file exists
        assert os.path.isfile(tmp_file) is True

        side_effect(old_cmd, u"no command")
        # Assert that file does not exists after side effect
        assert os.path.isfile(tmp_file) is False
    finally:
        # Clean up
        os.remove(tmp_file)
        os.removedirs('tmp')

# Generated at 2022-06-22 01:27:19.956037
# Unit test for function match
def test_match():
    assert match(Command('unzip machine_learning.zip',
          'machine_learning.zip:  cannot find or open'))



# Generated at 2022-06-22 01:27:25.058241
# Unit test for function match
def test_match():
    # Test case one: run unzip with one parameter (folder not end with .zip)
    # should return True.
    folder = 'folder'
    assert match(
        Command('unzip {}'.format(folder), '')
    )

    # Test case two: run unzip with multiple parameters (folder with .zip)
    # should return True.
    folder_with_zip = '{}.zip'.format(folder)
    assert match(
        Command('unzip {}'.format(folder_with_zip), '')
    )

    # Test case three: run unzip -d folder
    # should return False.
    assert not match(
        Command('unzip -d {}'.format(folder), '')
    )

    # Test case four: run unzip -d folder.zip
    # should return False.

# Generated at 2022-06-22 01:27:44.978509
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip'))
    assert match(Command('unzip -a test.zip'))
    assert not match(Command('unzip -d test.zip'))
    assert not match(Command('unzip -j test.zip'))
    assert not match(Command('unzip -x file test.zip'))
    assert not match(Command('unzip -d not_existing_archive.zip'))



# Generated at 2022-06-22 01:27:57.229584
# Unit test for function side_effect
def test_side_effect():
    tmp_path = '/tmp/thefuck/unit-test'
    os.mkdir(tmp_path)
    os.mkdir(os.path.join(tmp_path, 'test'))
    cwd = os.getcwd()
    os.chdir(tmp_path)
    archive_path = os.path.join(tmp_path, 'test.zip')
    archive = zipfile.ZipFile(archive_path, 'w')
    archive.write('test/test2', arcname='test2')
    archive.close()
    old_cmd = 'unzip test.zip'
    command = 'unzip test.zip'
    side_effect(old_cmd, command)
    assert not os.path.isfile('test2')
    assert not os.path.isfile('test/test2')
    os

# Generated at 2022-06-22 01:28:08.024136
# Unit test for function match
def test_match():
    # Negative test
    assert not match(Command('unzip -d test.zip', '', '', 0, None))
    # Positive test
    with open('unzip.zip', 'w') as unzip_zip:
        with zipfile.ZipFile(unzip_zip, 'w') as archive:
            archive.writestr('unzip.zip', 'contents')
    with open('unzip.zip', 'r') as unzip_zip:
        with open('unzip', 'w') as unzip:
            unzip.write('unzip')
    assert match(Command('unzip unzip.zip', '', '', 0, None))
    os.remove('unzip.zip')
    os.remove('unzip')


# Generated at 2022-06-22 01:28:19.464877
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("unzip foo.zip", "unzip:  cannot find or open foo.zip, foo.zip.zip or foo.zip.ZIP.")
    assert get_new_command(command) == "unzip -d " + shell.quote("foo")

    command = Command("unzip foo", "unzip:  cannot find or open foo, foo.zip or foo.ZIP.")
    assert get_new_command(command) == "unzip -d " + shell.quote("foo")

    command = Command("unzip foo.zip bar.zip", "unzip:  cannot find or open bar.zip, bar.zip.zip or bar.zip.ZIP.")
    assert get_new_command(command) == "unzip -d " + shell.quote("bar")


# Generated at 2022-06-22 01:28:31.978253
# Unit test for function get_new_command
def test_get_new_command():
    zip_file = '/home/user/test.zip'
    with open(zip_file, 'w'):
        # create empty zip file
        pass

    command = type('Command', (object,), {
        'script': u'unzip {} -d'.format(shell.quote(zip_file)),
        'script_parts': [u'unzip', zip_file, u'-d']})
    assert get_new_command(command) == u'unzip {} -d {}'.format(
        shell.quote(zip_file),
        shell.quote(zip_file[:-4]))


# Generated at 2022-06-22 01:28:40.187007
# Unit test for function side_effect
def test_side_effect():
    current_dir = os.path.abspath(".")
    test_dir = os.path.join(".", ".test_dir")
    os.makedirs(test_dir)
    test_file = os.path.join(".", ".test_zip")
    zip_file = zipfile.ZipFile(test_file, "w")
    zip_file.write(test_file)
    zip_file.write(test_dir)
    zip_file.close()

    old_cmd = 'unzip -d {} {}'.format(test_dir, test_file)
    command = 'unzip -d {} {}'.format(test_dir, test_file)
    side_effect(old_cmd, command)

    assert not os.path.exists(test_file)

# Generated at 2022-06-22 01:28:46.047231
# Unit test for function match
def test_match():
    from thefuck.types import Command

    assert match(Command('unzip archive.zip', 'unzip:  cannot find or open archive.zip',
            '', '', '', '', ''))
    assert not match(Command('unzip archive.zip', '', '', '', '', '', ''))
    assert not match(Command('unzip archive.zip -d extracted', '', '', '', '',
            '', ''))
    assert not match(Command('unzip', 'unzip:  cannot find or open archive.zip',
            '', '', '', '', ''))

# Generated at 2022-06-22 01:28:57.855372
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    from thefuck.shells import get_shell
    path = tempfile.mkdtemp()
    shell = get_shell()

    assert not os.path.exists(path + '/file')
    side_effect(fake_command('unzip file', path + '/file.zip'),
                fake_command('unzip -d file', path + '/file.zip'))
    assert not os.path.exists(path + '/file')
    open(path + '/file', 'a').close()
    side_effect(fake_command('unzip file', path + '/file.zip'),
                fake_command('unzip -d file', path + '/file.zip'))
    assert not os.path.exists(path + '/file')

    new_path = path + '/test'
    assert not os.path.ex

# Generated at 2022-06-22 01:29:01.805481
# Unit test for function match
def test_match():
    assert match(Command('unzip foo.zip'))
    assert not match(Command('unzip -d foo.zip'))
    assert not match(Command('unzip -d foo'))
    assert not match(Command('unzip'))


# Generated at 2022-06-22 01:29:07.172381
# Unit test for function match
def test_match():
    # Simple test
    zip_file = "./test.zip"
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.write("test/test.txt", "test/")

    assert _is_bad_zip(zip_file) == True

    # Test with bad zip file
    zip_file = "./test.txt"

    assert _is_bad_zip(zip_file) == False

# Generated at 2022-06-22 01:29:46.156033
# Unit test for function side_effect
def test_side_effect():
    test_dir = tempfile.mkdtemp()
    try:
        f = open(os.path.join(test_dir, 'file'), 'w')
        f.close()

        zip_file = os.path.join(os.path.join(os.path.join(test_dir, 'zip_file'), 'file'))
        os.makedirs(os.path.dirname(zip_file))

        with zipfile.ZipFile(zip_file, 'w') as archive:
            archive.write('file')

        side_effect(Command('unzip', 'unzip {}'.format(zip_file)), Command('unzip', 'unzip {}'.format(zip_file)))
        assert os.path.isfile('file')
    finally:
        os.remove('file')

# Generated at 2022-06-22 01:29:50.912795
# Unit test for function match
def test_match():
    from tests.util import Command

    unzip_command = 'unzip arch.zip'
    unzip_bad_zip_command = 'unzip -q arch.zip'

    assert match(Command(unzip_command, None, None)) is False
    assert match(Command(unzip_bad_zip_command, None, None)) is True

# Generated at 2022-06-22 01:30:02.895444
# Unit test for function match
def test_match():
    from thefuck.rules.unzip_single_file import _zip_file
    # Test for zip with one file
    with open('test.zip', "wb") as f:
        f.write('PK\x03\x04\x14\x00\x00\x00\x08\x00\x8d\xb4\x5f\xed\x4d'
                '\xfa\xfbjP\x00\x00\x00\x02\x00\x00\x00\t\x00\x00\x00test')

    command = type('Command', (object, ), {
        'script': u'unzip test.zip',
        'script_parts': ['unzip', 'test.zip']
    })
    assert match(command) is True

# Generated at 2022-06-22 01:30:15.075521
# Unit test for function get_new_command
def test_get_new_command():
    os.chdir(os.path.dirname(__file__))

    assert _is_bad_zip('file_1.zip')
    assert _is_bad_zip('file_2.zip')
    assert _is_bad_zip('file_3.zip')
    assert _is_bad_zip('file_4.zip')
    assert _is_bad_zip('file_5.zip')
    assert _is_bad_zip('file_6.zip')
    assert _is_bad_zip('file_7.zip')
    assert not _is_bad_zip('file_8.zip')

    assert get_new_command(shell.and_('unzip file_1.zip', 'file_1.zip')) == 'unzip -d file_1 file_1.zip'
    assert get_new_command

# Generated at 2022-06-22 01:30:19.233119
# Unit test for function match
def test_match():
    assert match(u'unzip test.zip')
    assert match(u'unzip test')
    assert not match(u'unzip -d test')
    assert not match(u'unzip -d test.zip')
    assert not match(u'unzip test.zip -d')

# Generated at 2022-06-22 01:30:26.246715
# Unit test for function side_effect
def test_side_effect():
    current_dir = os.getcwd()
    os.chdir('tests/fixtures')
    assert os.listdir() == ['a.zip']
    assert side_effect(FakeCommand('unzip a.zip'), None) is None
    assert os.listdir() == ['a.zip', 'dir']
    assert os.listdir('dir') == ['test.txt']
    assert os.path.exists('test.txt') is False
    os.chdir(current_dir)

# Generated at 2022-06-22 01:30:38.074954
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    new_cmd = get_new_command(Command('unzip myzip.zip', '', ''))
    assert new_cmd == 'unzip -d myzip'

    new_cmd = get_new_command(Command('unzip "/my path/myzip.zip"', '', ''))
    assert new_cmd == 'unzip -d "/my path/myzip"'

    new_cmd = get_new_command(Command('unzip myzip.zip -x myzip/file', '', ''))
    assert new_cmd == 'unzip -d myzip'

    new_cmd = get_new_command(Command('unzip myzip.zip -x myzip/file myzip/myfile', '', ''))
    assert new_cmd == 'unzip -d myzip'

# Generated at 2022-06-22 01:30:50.177648
# Unit test for function side_effect
def test_side_effect():
    directory = os.path.join(os.environ['HOME'], 'test_folder')
    os.mkdir(directory)
    file = open(os.path.join(directory, 'test_file.txt'), 'w')
    file.write('test')
    file.close()
    file = open(os.path.join(directory, 'test_file_2.txt'), 'w')
    file.write('test')
    file.close()
    with zipfile.ZipFile(os.path.join(os.environ['HOME'], 'test_zip.zip'), 'w') as myzip:
        myzip.write(os.path.join(directory, 'test_file.txt'))
    os.chdir(directory)

# Generated at 2022-06-22 01:31:01.540088
# Unit test for function match
def test_match():
    assert _is_bad_zip('tests/fixtures/bad_zip')
    assert not _is_bad_zip('tests/fixtures/not_bad_zip')
    assert not _is_bad_zip('tests/fixtures/bad_zip.zip')
    assert not _is_bad_zip('tests/fixtures/not_bad_zip.zip')

    assert match(Command('unzip tests/fixtures/bad_zip', ''))
    assert not match(Command('unzip tests/fixtures/not_bad_zip', ''))
    assert match(Command('unzip tests/fixtures/bad_zip.zip', ''))
    assert not match(Command('unzip tests/fixtures/not_bad_zip.zip', ''))
    assert match(Command('unzip -l tests/fixtures/bad_zip', ''))


# Generated at 2022-06-22 01:31:11.934971
# Unit test for function match
def test_match():
    """
    For function match
    """
    assert (match(Command(script='unzip test.zip',
                         stdout='''Archive:  test.zip
  inflating: test1
  inflating: test2''')))

    assert not match(Command(script='unzip test.zip',
                             stdout='',
                             stderr='''Archive:  test.zip'''))

    assert not match(Command(script='unzip -d test test.zip',
                             stdout='''Archive:  test.zip
  inflating: test/test1
  inflating: test/test2'''))

    assert not match(Command(script='unzip test.zip',
                             stdout='''test'''))

# Generated at 2022-06-22 01:32:12.737519
# Unit test for function match
def test_match():
    os.environ['HOME'] = '/home/mrx'
    assert match(Command('unzip /tmp/file.zip', '')) == False
    assert match(Command('unzip /tmp/file.zip -d /tmp/random', '')) == False
    assert match(Command('unzip /tmp/random/file.zip', '')) == False
    assert match(Command('unzip file.zip', '')) == True
    assert match(Command('unzip file', '')) == True

# Generated at 2022-06-22 01:32:23.095053
# Unit test for function match
def test_match():
    from tests.utils import Command

    # test if unzip command will match with bad zip
    assert match(Command(script='unzip badzip.zip'))
    assert match(Command(script='unzip badzip'))

    assert match(Command(script='unzip -d dir badzip.zip'))
    assert match(Command(script='unzip -d dir badzip'))

    assert not match(Command(script='unzip goodzip.zip'))
    assert not match(Command(script='unzip goodzip'))

    # test if unzip command won't match with bad zip
    assert not match(Command(script='zip goodzip.zip'))
    assert not match(Command(script='gzip'))
    assert not match(Command(script='love'))


# Generated at 2022-06-22 01:32:27.753731
# Unit test for function side_effect
def test_side_effect():
    old_cmd = type('', (), {'script': 'unzip testfile.zip'})
    command = type('', (), {'script': 'unzip -d testfile.zip'})
    side_effect(old_cmd, command)

# Generated at 2022-06-22 01:32:37.906557
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    tmpdir = tempfile.mkdtemp()
    old_cmd = Command(u'unzip /tmp/archive.zip', '', tmpdir)

    open(os.path.join(tmpdir, u'my_file'), 'w').close()
    with zipfile.ZipFile(os.path.join(tmpdir, 'archive.zip'), 'w') as archive:
        archive.writestr('my_file', '')

    command = Command(u'unzip -d /tmp/archive /tmp/archive.zip', '', tmpdir)

    side_effect(old_cmd, command)

    assert u'my_file' in os.listdir(tmpdir)

# Generated at 2022-06-22 01:32:49.401313
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import shell
    from os.path import exists
    from os import getcwd
    import zipfile

    file_to_remove = 'remove_me'
    file_to_keep = 'keep_me'

    file_path_to_remove = os.path.join(getcwd(), file_to_remove)
    file_path_to_remove = os.path.join(getcwd(), file_to_keep)

    with open(file_path_to_remove, 'w') as f:
        f.write('Fake file')

    with open(file_path_to_keep, 'w') as f:
        f.write('Fake file')

    tmp = os.path.join(getcwd(), 'test.zip')
    archive = zipfile.ZipFile(tmp, 'w')


# Generated at 2022-06-22 01:32:54.137611
# Unit test for function get_new_command
def test_get_new_command():
    script = 'unzip test_directory/test_python_linux.zip -p'
    command = Command(script)
    get_new_cmd = get_new_command(command)
    assert get_new_cmd == 'unzip test_directory/test_python_linux.zip -d test_directory/test_python_linux'

# Generated at 2022-06-22 01:33:06.027683
# Unit test for function get_new_command
def test_get_new_command():
    command_str = "unzip -l foo.zip"
    command = create_command(command_str, '/tmp/test_match/')
    old_cmd = "unzip foo.zip"
    assert get_new_command(command) == \
        old_cmd + ' -d ' + shell.quote('/tmp/test_match/foo')

    # Should work even if the file is not in the current directory
    command_str = "unzip -l a/b/c/foo.zip"
    command = create_command(command_str, '/tmp/test_match/')
    old_cmd = "unzip a/b/c/foo.zip"