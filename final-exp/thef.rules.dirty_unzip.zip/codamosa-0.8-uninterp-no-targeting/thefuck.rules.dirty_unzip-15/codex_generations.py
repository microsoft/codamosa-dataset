

# Generated at 2022-06-22 01:23:06.031346
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip -l file.zip', None, None, None, None)) == u'unzip -l file.zip -d file'
    assert get_new_command(Command('unzip -l file1.zip file2.zip', None, None, None, None)) == u'unzip -l file1.zip file2.zip -d file2'

# Generated at 2022-06-22 01:23:14.235607
# Unit test for function match
def test_match():
    assert match(Command('unzip root.zip', '', '', 0, ''))
    assert not match(Command('unzip root.zip', '', 'unzip:  cannot find or open root.zip', 0, ''))
    assert not match(Command('unzip root.zip', '', 'caution:  filename not matched:  root', 0, ''))
    assert not match(Command('unzip --help', '', '', 0, ''))
    assert not match(Command('unzip -d tmp root.zip', '', '', 0, ''))

# Generated at 2022-06-22 01:23:17.997591
# Unit test for function get_new_command
def test_get_new_command():
    old_cmd = Command('unzip -qq test.zip', '', '')
    new_cmd = get_new_command(old_cmd)
    assert new_cmd == 'unzip -qq -d test test.zip', new_cmd


# Generated at 2022-06-22 01:23:21.189501
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip'))
    assert not match(Command('unzip -d file.zip'))
    assert not match(Command('unzip -j file.zip'))
    assert match(Command('unzip file'))
    assert not match(Command('zip file'))

# Generated at 2022-06-22 01:23:27.349252
# Unit test for function match
def test_match():
    c = Command('unzip test.zip')
    assert match(c)

    c = Command('unzip -d test test.zip')
    assert not match(c)

    c = Command('unzip -d test other.zip')
    assert not match(c)

    c = Command('unzip .zip')
    assert match(c)

    c = Command('unzip -d .zip')
    assert not match(c)



# Generated at 2022-06-22 01:23:39.150645
# Unit test for function match
def test_match():
    assert not match(Command(script='unzip -d abc.zip',
                             stderr='unzip:  cannot find or open abc.zip',
                             stdout=''))

    #if zipfile is empty
    assert not match(Command(script='unzip abc.zip',
                             stderr='' ,
                             stdout=''))

    #if zipfile is not empty

# Generated at 2022-06-22 01:23:47.304677
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('''unzip foo.zip''') == '''unzip -d foo foo.zip'''
    assert get_new_command('''unzip -d foo foo.zip''') == '''unzip -d foo foo.zip'''
    assert get_new_command('''unzip -d foo.bar foo.zip''') == '''unzip -d "foo.bar" foo.zip'''
    assert get_new_command('''unzip -d foo. bar foo.zip''') == '''unzip -d "foo. bar" foo.zip'''
    assert get_new_command('''unzip -d foo.\ bar foo.zip''') == '''unzip -d "foo. bar" foo.zip'''

# Generated at 2022-06-22 01:23:59.083288
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import os

# Generated at 2022-06-22 01:24:03.164566
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command(
        Command('unzip file.zip', '', ''))
    print(result)
    assert result == 'unzip -d file file.zip'



# Generated at 2022-06-22 01:24:15.161539
# Unit test for function side_effect
def test_side_effect():
    # case: zip contains only one file
    stub_old_cmd = type('stub_old_cmd', (object,),
                        {'script': 'unzip -d test_side_effect.zip'})
    stub_command = type('stub_command', (object,),
                        {'script': 'unzip -d test_side_effect.zip'})
    stub_zip = 'test_side_effect.zip'
    stub_zip_path = os.path.join(os.getcwd(), stub_zip)
    stub_file_name = 'a'
    stub_file_path = os.path.join(os.getcwd(), stub_file_name)
    open(stub_file_path, 'w').close()

# Generated at 2022-06-22 01:24:27.852489
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(shell.and_('unzip file.zip', 'unzip file')) == 'unzip -d file file.zip'
    assert get_new_command(shell.and_('unzip file.zip foo bar', 'unzip file')) == 'unzip -d file file.zip foo bar'
    assert get_new_command(shell.and_('unzip file', 'unzip file')) == 'unzip -d file file.zip'

# Generated at 2022-06-22 01:24:37.951915
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as tmpdir:
        os.mkdir(os.path.join(tmpdir, '1'))
        os.mkdir(os.path.join(tmpdir, '1', '2'))
        os.mkdir(os.path.join(tmpdir, '1', '2', '3'))
        os.mkdir(os.path.join(tmpdir, '1', '2', '3', 'unsafe'))
        open(os.path.join(tmpdir, '1', '2', 'file1'), 'a').close()
        open(os.path.join(tmpdir, '1', '2', 'file2'), 'a').close()

# Generated at 2022-06-22 01:24:44.581066
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command('unzip file.zip', None)
    assert get_new_command(cmd) == u'unzip -d file file.zip'

    cmd = Command('unzip -a file', None)
    assert get_new_command(cmd) == u'unzip -a -d file file'

    cmd = Command('unzip -a -b file', None)
    assert get_new_command(cmd) == u'unzip -a -b -d file file'

# Generated at 2022-06-22 01:24:49.070305
# Unit test for function side_effect
def test_side_effect():
    old_cmd = "unzip test01.zip"
    old_cmd_script_parts = ["unzip", "test01.zip"]
    command = "unzip -d test01 test01.zip"
    command_script_parts = ["unzip", "-d", "test01", "test01.zip"]
    assert side_effect(old_cmd, command) == None
    assert command == "unzip -d test01 test01.zip"
    assert command_script_parts == ["unzip", "-d", "test01", "test01.zip"]
    assert old_cmd == "unzip test01.zip"
    assert old_cmd_script_parts == ["unzip", "test01.zip"]

# Generated at 2022-06-22 01:24:57.836366
# Unit test for function match
def test_match():
    # Test true case
    example_bad_zip = shell.from_string('/usr/bin/unzip Testing.zip')
    example_good_zip = shell.from_string('/usr/bin/unzip test-output.zip')
    example_unzip = shell.from_string('/usr/bin/unzip test-output.zip test-output/')
    assert match(example_bad_zip)
    # Test false case
    assert not match(example_good_zip)
    assert not match(example_unzip)



# Generated at 2022-06-22 01:25:03.029276
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip file.txt', ''))
    assert match(Command('unzip test.zip test',''))
    assert not match(Command('unzip test.zip -d test_dir',''))
    assert not match(Command('unzip test.zip -d test_dir file.txt', ''))
    assert not match(Command('unzip', ''))
    assert not match(Command('unzip -d test', ''))



# Generated at 2022-06-22 01:25:10.538772
# Unit test for function match
def test_match():
    script = u'unzip foobar.zip'
    app = shell.and_('unzip', 'unzip')

    # this is the case when unzip is run without `-d`
    command = Command(script, '', app=app)
    assert match(command)

    # this is the case when unzip is run with `-d`
    script_dir = u'unzip -d foobar/ foobar.zip'
    command_dir = Command(script_dir, '', app=app)
    assert not match(command_dir)


# Generated at 2022-06-22 01:25:19.251434
# Unit test for function side_effect
def test_side_effect():
    # create test_dir
    os.mkdir('test_dir')
    # create test_dir/test_file
    open('test_dir/test_file.txt', 'w').close()
    # create test_dir/test_dir1
    os.mkdir('test_dir/test_dir1')
    open('test_dir/test_dir1/test_file2.txt', 'w').close()
    # create test_dir/test_dir2
    os.mkdir('test_dir/test_dir2')
    open('test_dir/test_dir2/test_file2.txt', 'w').close()
    # create test_zip.zip
    zf = zipfile.ZipFile('test_zip.zip', mode='w')
    zf.write('test_dir')

    # create the

# Generated at 2022-06-22 01:25:26.120556
# Unit test for function match
def test_match():
    # file doesn't exist
    assert not match(Command('unzip nonexistant.zip', '', None))
    # file doesn't end in '.zip'
    assert not match(Command('unzip file', '', None))
    # file is empty
    assert not match(Command('unzip empty.zip', '', None))
    # file is not a zip file
    assert not match(Command('unzip notazip.zip', '', None))
    # file is a single-file zip file
    assert not match(Command('unzip single.zip', '', None))
    # file is a multi-file zip file
    assert match(Command('unzip multi.zip', '', None))

# Generated at 2022-06-22 01:25:35.475330
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('unzip test.zip', 'unzip:  cannot find or open test.zip,  test.zip.zip or test.zip.ZIP.')).script == 'unzip test.zip -d test'
    assert get_new_command(
        Command('unzip test', 'unzip:  cannot find or open test,  test.zip or test.ZIP.')).script == 'unzip test -d test'
    assert get_new_command(
        Command('unzip test.zip test2.zip', 'unzip:  cannot find or open test.zip,  test.zip.zip or test.zip.ZIP.')).script == 'unzip test.zip test2.zip -d test'

# Generated at 2022-06-22 01:25:53.493662
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command

    old_cmd = Command('unzip file.zip', '')
    assert _zip_file(old_cmd) == 'file.zip'

    command = Command(
        'unzip file.zip',
        'file.zip:  bad zipfile offset (local header sig):  '
        '0       file.zip:  not a zip file')
    side_effect(old_cmd, command)
    assert test_os.path.exists('file.zip')
    test_os.remove('file.zip')

    with open('./file.txt', 'a'):
        pass

    command = Command(
        'unzip file.zip',
        'file.zip:  bad zipfile offset (local header sig):  '
        '0       file.zip:  not a zip file')


# Generated at 2022-06-22 01:25:56.912837
# Unit test for function get_new_command
def test_get_new_command():
    script = 'unzip file.zip'
    command = Command(script, '')
    assert get_new_command(command) == 'unzip -d file file.zip'


# Generated at 2022-06-22 01:26:03.434757
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import shell
    assert get_new_command(shell.and_('unzip file', '', '')) \
           == 'unzip -d {} file'.format(shell.quote('file'[:-4]))
    assert get_new_command(shell.and_('unzip -j file', '', '')) \
           == 'unzip -d {} -j file'.format(shell.quote('file'[:-4]))

# Generated at 2022-06-22 01:26:12.060300
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.unzip_one_file import get_new_command
    assert get_new_command(
        'unzip -d /tmp/test test.zip') == 'unzip -d /tmp/test test.zip'
    assert get_new_command(
        'unzip test.zip') == 'unzip -d test test.zip'
    assert get_new_command(
        'unzip -d /tmp/test /tmp/file.zip') == 'unzip -d /tmp/test /tmp/file.zip'
    assert get_new_command(
        'unzip /tmp/file.zip') == 'unzip -d /tmp/file /tmp/file.zip'

# Generated at 2022-06-22 01:26:23.225403
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command(script='unzip -a Test.zip',
                                    stdout='', stderr='', exit_code=2))
            == u'unzip -a Test.zip -d Test')
    assert (get_new_command(Command(script='unzip Test',
                                    stdout='', stderr='', exit_code=2))
            == u'unzip Test -d Test')
    assert (get_new_command(Command(script='unzip -- Test',
                                    stdout='', stderr='', exit_code=2))
            == u'unzip -- Test -d Test')

# Generated at 2022-06-22 01:26:34.131161
# Unit test for function side_effect
def test_side_effect():
    import os.path
    from thefuck.types import Command

    # create 'test.zip' and 'test/test.txt'
    bad_zip = os.path.abspath("./test.zip")
    with zipfile.ZipFile(bad_zip, 'w') as zip:
        zip.writestr('test/test.txt', 'test')

    # create an old_cmd object
    old_cmd = Command('unzip test.zip',
                      'ZIP file was not extracted in current directory, but in \'test\'. Unzip file again',
                      '',
                      '')

    # Test if the side effect reset the directory to it's original state
    side_effect(old_cmd, "")
    assert not os.path.exists('test')
    assert not os.path.exists('test.zip')



# Generated at 2022-06-22 01:26:39.745199
# Unit test for function get_new_command
def test_get_new_command():
    # Test that new command is formed correctly
    from thefuck.types import Command
    old_cmd = Command('unzip some_file.zip', 'some_file.zip not found or empty')
    new_cmd = get_new_command(old_cmd)
    assert u'unzip -d some_file some_file.zip' == new_cmd

# Generated at 2022-06-22 01:26:48.478160
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('unzip archive')) == u'unzip -d archive archive'
    assert get_new_command(Command('unzip archive.zip')) == u'unzip -d archive archive.zip'
    assert get_new_command(Command('unzip -x archive')) == u'unzip -x -d archive archive'
    assert get_new_command(Command('unzip -x archive.zip')) == u'unzip -x -d archive archive.zip'
    assert get_new_command(Command('unzip -x test archive.zip')) == u'unzip -x test -d archive archive.zip'

# Generated at 2022-06-22 01:26:55.154533
# Unit test for function side_effect
def test_side_effect():
    assert len(os.listdir(os.getcwd())) == 0
    zipfile.ZipFile('__test.zip', 'w').close()
    test_cmd = type('cmd', (object,), {'script': 'unzip __test.zip'})

    side_effect(test_cmd, None)
    assert len(os.listdir(os.getcwd())) == 1

    os.remove('__test.zip')

# Generated at 2022-06-22 01:27:03.782413
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    from thefuck.shells import Bash
    here = os.path.dirname(os.path.abspath(__file__))
    dir  = tempfile.mkdtemp()
    with open(dir + '/sample.tmp', 'w') as f:
        f.write('')

    side_effect(Command('unzip tmp.zip',
                  Bash(), here + '/tmp.zip'),
                  Command('unzip tmp.zip',
                  Bash(), here + '/tmp.zip'))
    assert(not os.path.exists(dir + '/sample.tmp'))

# Generated at 2022-06-22 01:27:26.021704
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    #get_new_command(command)
    assert get_new_command(Command('unzip filename.zip', '')) =='unzip -d filename filename.zip'

# Generated at 2022-06-22 01:27:37.962111
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import shell
    from thefuck.rules.unzip_folder import side_effect

    # Creating temporary files
    from tempfile import NamedTemporaryFile
    temp_files = [NamedTemporaryFile(delete=False) for _ in range(4)]
    for i, file in enumerate(temp_files):
        file.write('this is a testing file {}\n'.format(i))
        file.close()

    # Creating a zip of the files in order to do the test
    import zipfile
    with zipfile.ZipFile('test_fix_unzip_folder.zip', 'w') as zip_file:
        for file in temp_files:
            zip_file.write(file.name, os.path.basename(file.name))
        zip_file.close()

    old_cmd = shell

# Generated at 2022-06-22 01:27:40.218555
# Unit test for function side_effect
def test_side_effect():
    shell.from_string("unzip test.zip")
    side_effect("unzip test.zip", "unzip test.zip -d test")

# Generated at 2022-06-22 01:27:47.901858
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as dir:
        zip_file = os.path.join(dir, 'test')
        with zipfile.ZipFile(zip_file, 'w') as archive:
            archive.writestr('a', 'fake')
            archive.writestr('b/c', 'fake')
            archive.writestr('b/d', 'fake')

        shell.create_file('a', '1')
        shell.create_file('b/c', '2')
        shell.create_file('e/f', 'fake')

        os.mkdir(os.path.join(dir, 'b'))  # b is a directory
        os.mkdir(os.path.join(dir, 'f'))  # should be untouched


# Generated at 2022-06-22 01:27:59.850811
# Unit test for function match
def test_match():
    assert match(Command('unzip', 'unzip file1.zip')) == True
    assert match(Command('unzip', 'unzip -l file1.zip')) == False
    assert match(Command('unzip', 'unzip -d file1.zip')) == False
    assert match(Command('unzip', 'unzip file1.zip file2.zip')) == False
    assert match(Command('unzip', 'unzip -d file1.zip file2.zip')) == False
    assert match(Command('unzip', 'unzip file1 file2')) == False
    assert match(Command('unzip', 'unzip -d file1 file2')) == False
    assert match(Command('unzip', 'unzip file1 file2.zip')) == False

# Generated at 2022-06-22 01:28:11.938988
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', output='unzip:  cannot find or open file.zip, file.zip.zip or file.zip.ZIP'))
    assert not match(Command('unzip file.zip', output='unzip:  cannot find or open file.zip, file.zip.zip or file.zip.ZIP', stderr='unzip:  cannot find or open file.zip, file.zip.zip or file.zip.ZIP'))
    assert match(Command('unzip file.zip', output=''))
    assert match(Command('unzip file.zip -d folder', output=''))
    assert match(Command('unzip file.zip', output='unzip:  cannot find or open file.zip, file.zip.zip or file.zip.ZIP'))

# Generated at 2022-06-22 01:28:22.263373
# Unit test for function match
def test_match():
    from thefuck.tests.utils import Command

    assert match(Command('', ''))

    # We don't do anything for -d commands
    assert not match(Command('unzip -d foo bar.zip', ''))

    # We can't do anything with a bad file extension either.
    assert not match(Command('unzip foo.bar', ''))

    # Check that we can cope with multiple files
    assert match(Command('unzip foo.zip bar.zip baz.zip', ''))

    # Make sure we can deal with absolute and relative paths
    assert match(Command('unzip foo.zip /tmp/bar.zip', ''))

    # Make sure we don't choke on a bad zip file
    assert match(Command('unzip foo.zip', ''))


# Generated at 2022-06-22 01:28:26.673087
# Unit test for function match
def test_match():
    assert match(Command('unzip -d . .', '', ''))
    assert not match(Command('unzip .', '', ''))
    assert match(Command('unzip . .', '', ''))


# Generated at 2022-06-22 01:28:36.206668
# Unit test for function side_effect
def test_side_effect():
    import shutil
    import unittest
    import tempfile

    class SideEffectTest(unittest.TestCase):
        def setUp(self):
            self.base_dir = tempfile.mkdtemp(prefix='thefuck')
            self.work_dir = tempfile.mkdtemp(dir=self.base_dir)
            self.archive_path = '{}/archive.zip'.format(self.base_dir)
            shutil.copyfile('tests/fixtures/zip/archive.zip', self.archive_path)
            os.chdir(self.work_dir)
            self.file_path = '{}/file.txt'.format(self.base_dir)
            self.file_content = 'Content of the file'

# Generated at 2022-06-22 01:28:40.010428
# Unit test for function match
def test_match():
    code = u"unzip /path/to/file.zip"
    res = match(command=code)
    assert res is False
    res = match(command=code)
    assert res is False
    res = match(command=code)
    assert res is False


# Generated at 2022-06-22 01:29:29.028239
# Unit test for function match
def test_match():
    unzip_command = ['unzip', '-d', 'foo']
    assert not match(Command(unzip_command, '', ''))

    # unzipping existing zip file
    zip_file = 'test_unzip_existing.zip'
    unzip_command = [
        'unzip', '-d', 'test_unzip_existing', 'test_unzip_existing.zip']
    assert not match(Command(unzip_command, '', ''))

    # unzipping non-existing zip file
    zip_file = 'test_unzip_non_existing.zip'
    unzip_command = [
        'unzip', '-d', 'test_unzip_non_existing', 'test_unzip_non_existing.zip']
    assert not match(Command(unzip_command, '', ''))



# Generated at 2022-06-22 01:29:31.665005
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("unzip -q ../lol/file.zip file.txt") == "unzip -q ../lol/file.zip file.txt -d file"

# Generated at 2022-06-22 01:29:35.458729
# Unit test for function match
def test_match():
    assert match(Command(script='unzip test.zip', stderr=''))
    assert not match(Command(script='zip test.zip test', stderr=''))
    assert not match(Command(script='unzip -d test.zip test', stderr=''))



# Generated at 2022-06-22 01:29:40.929901
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', ''))
    assert not match(Command('unzip test.zip', '', stderr='error'))
    assert not match(Command('unzip test.zip -d test', ''))
    assert match(Command('unzip -l test.zip', ''))

# Generated at 2022-06-22 01:29:45.543701
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='unzip wrong_command.zip',
                                   stderr='unzip:  cannot find or open wrong_command.zip, wrong_command.zip.zip or wrong_command.zip.ZIP.')) == u'unzip -d wrong_command wrong_command.zip'

# Generated at 2022-06-22 01:29:48.744731
# Unit test for function get_new_command
def test_get_new_command():
    command = "unzip test.zip"
    new_command = "unzip -d test test.zip"
    assert (get_new_command(command) == new_command)

# Generated at 2022-06-22 01:29:58.444163
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='unzip file')) == 'unzip -d file'
    assert get_new_command(Command(script='unzip file.zip')) == 'unzip -d file'
    assert get_new_command(Command(script='unzip -h file.zip')) == 'unzip -h -d file'
    assert get_new_command(Command(script='unzip -h file')) == 'unzip -h -d file'
    assert get_new_command(Command(script='unzip -h file1 file2')) == 'unzip -h -d file1 file2'


# Generated at 2022-06-22 01:30:06.118266
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("unzip somedir.zip") == "unzip -d 'somedir' somedir.zip"
    assert get_new_command("unzip somedir.zip file1 file2") == "unzip -d 'somedir' somedir.zip file1 file2"
    assert get_new_command("unzip somedir file1 file2") == "unzip -d 'somedir' somedir.zip file1 file2"
    assert get_new_command("unzip -v somedir file1 file2") == "unzip -v -d 'somedir' somedir.zip file1 file2"


# Generated at 2022-06-22 01:30:11.688210
# Unit test for function match
def test_match():
    assert match(Command('unzip myfile.zip'))
    assert match(Command('unzip myfile'))
    assert not match(Command('unzip -d out myfile.zip'))
    assert not match(Command('unzip myfile.zip -d out'))
    assert not match(Command('unzip -d out myfile.zip file2 file3'))



# Generated at 2022-06-22 01:30:15.024199
# Unit test for function get_new_command
def test_get_new_command():
    with open(os.devnull, 'w') as devnull:
        old_cmd = Command('unzip test.zip', devnull)
        command = get_new_command(old_cmd)
        assert command == 'unzip -d test test.zip'

# Generated at 2022-06-22 01:31:31.700725
# Unit test for function match
def test_match():
	assert_true(match(Script('unzip 1.zip')))


# Generated at 2022-06-22 01:31:37.831302
# Unit test for function match

# Generated at 2022-06-22 01:31:46.623037
# Unit test for function get_new_command
def test_get_new_command():
    old = Command('unzip source.zip', '', '')
    new = get_new_command(old)
    assert new == 'unzip source.zip -d source'

    old = Command('unzip source1.zip source2.zip', '', '')
    new = get_new_command(old)
    assert new == 'unzip source1.zip source2.zip -d source1'

    old = Command('unzip -n -x badfile.zip', '', '')
    new = get_new_command(old)
    assert new == 'unzip -n -x badfile.zip -d badfile'

# Generated at 2022-06-22 01:31:58.593456
# Unit test for function side_effect
def test_side_effect():
    # create temporary zip file
    import tempfile
    temporary_zip_file = tempfile.NamedTemporaryFile(delete=False, suffix='.zip')
    temporary_zip_file.close()

    temporary_directory = tempfile.mkdtemp()
    zip_file_content = os.path.join(temporary_directory, os.path.basename(temporary_zip_file.name))

    with zipfile.ZipFile(zip_file_content, 'w') as archive:
        archive.writestr('file', 'test')

    # copy temporary zip to test side effects
    shutil.copy(zip_file_content, temporary_zip_file.name)

    # create a file before test
    temporary_file = tempfile.mkstemp()
    os.close(temporary_file[0])

    # test side

# Generated at 2022-06-22 01:32:05.277953
# Unit test for function side_effect
def test_side_effect():
    import os
    import tempfile
    with zipfile.ZipFile(tempfile.gettempdir()+'/file.zip', 'w') as zipfile_test:
        zipfile_test.write(tempfile.gettempdir()+'/file.txt')
    # Execute side effect
    side_effect(None, None)
    # Check side effect
    os.path.exists(tempfile.gettempdir()+'/file.txt')

# Generated at 2022-06-22 01:32:06.308161
# Unit test for function side_effect
def test_side_effect():
    assert not side_effect(None, None)

# Generated at 2022-06-22 01:32:17.522768
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('unzip file.zip', '', '')) == 'unzip -d file file.zip'
    assert get_new_command(Command('unzip -j file.zip', '', '')) == 'unzip -d file -j file.zip'
    assert get_new_command(Command('unzip -q file.zip', '', '')) == 'unzip -d file -q file.zip'
    assert get_new_command(Command('unzip file.zip test', '', '')) == 'unzip -d file file.zip test'
    assert get_new_command(Command('unzip file', '', '')) == 'unzip -d file file.zip'

# Generated at 2022-06-22 01:32:22.520481
# Unit test for function get_new_command
def test_get_new_command():
    command = 'unzip test.zip'
    assert get_new_command(shell.and_('unzip', command)) == command

    command = 'unzip test'
    assert u'{} -d {}'.format(command, shell.quote('test')) ==\
        get_new_command(shell.and_('unzip', command))

# Generated at 2022-06-22 01:32:28.750024
# Unit test for function get_new_command
def test_get_new_command():
    # This is the command to be tested
    command = type('cmd', (object,), {'script': 'unzip -x -d /home/test'})

    new_cmd = get_new_command(command)
    # Checking the output
    assert new_cmd == 'unzip -x -d /home/test -d '

# Generated at 2022-06-22 01:32:39.572803
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import get_shell
    new_command = 'unzip -d test_zip test_zip.zip'
    with open('test_zip.zip', 'w') as f:
        with zipfile.ZipFile(f, 'w') as z:
            z.writestr('test_file.py', 'print("hello")')
    old_cmd = get_shell().and_(new_command)
    command = get_shell().and_(new_command)
    side_effect(old_cmd, command)
    # test directory and file exist
    assert os.path.isdir('test_zip')
    assert os.path.isfile('test_zip/test_file.py')
    # test file content
    assert open('test_zip/test_file.py').read() == 'print("hello")'