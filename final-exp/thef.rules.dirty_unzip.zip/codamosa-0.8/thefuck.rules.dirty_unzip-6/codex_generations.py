

# Generated at 2022-06-12 11:08:22.289412
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import get_shell
    from thefuck.utils import get_closest

    test_script_parts = ['unzip', 'test.zip']
    test_os_path_sep = '/'

    test_file = 'test_file'
    test_file_exists = False
    test_file_is_dir = False
    test_file_content = 'test_content'

    def test_os_path_basename(path):
        return os.path.basename(path)

    def test_os_path_isfile(path):
        if test_os_path_basename(path) == test_file:
            return not test_file_exists
        else:
            return not test_file_is_dir


# Generated at 2022-06-12 11:08:32.475209
# Unit test for function match
def test_match():
    assert match(Command('unzip foo.zip', "unzip:  cannot find or open foo.zip, foo.zip.zip or foo.zip.ZIP", ""))
    assert not match(Command('unzip foo.zip', "unzip:  cannot find or open bar.zip, bar.zip.zip or bar.zip.ZIP", ""))
    assert match(Command('unzip foo.zip', "unzip:  cannot find or open foo.zip, foo.zip.zip or foo.zip.ZIP", "", stderr=True))
    assert not match(Command('unzip foo.zip', "unzip:  cannot find or open bar.zip, bar.zip.zip or bar.zip.ZIP", "", stderr=True))

# Generated at 2022-06-12 11:08:41.233670
# Unit test for function side_effect
def test_side_effect():
    assert not side_effect(None, None)
    assert not side_effect(None, 'error')
    assert not side_effect('unzip error.zip', 'unzip error.zip')
    assert not side_effect('unzip error.zip', 'unzip -d')
    assert not side_effect('unzip error.zip', 'unzip -e')
    assert side_effect('unzip error.zip', 'unzip -d error/')
    assert side_effect('unzip error.zip', 'unzip -d "error/"')
    assert side_effect('unzip error.zip', 'unzip -d "error/foo"')

# Generated at 2022-06-12 11:08:43.568872
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command(script = u'unzip test.zip file1.txt', stdout = u'')
    command = u'unzip ' + old_cmd.script + u' -d ' + old_cmd.script[6:-4]
    side_effect(old_cmd, command)
    assert not os.path.exists('file1.txt')

# Generated at 2022-06-12 11:08:46.781141
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert match(Command('unzip file.zip -d some_directory', ''))
    assert not match(Command('unzip -d some_directory file.zip', ''))


# Generated at 2022-06-12 11:08:57.890244
# Unit test for function match
def test_match():
    from thefuck.rules.unzip import match

    # Bad zip

    # Nested zip
    command = 'unzip b.zip'
    assert match(command)
    command = 'unzip a.zip'
    assert match(command)

    # Regular zip
    command = 'unzip c.zip'
    assert match(command)

    # No zip extension
    command = 'unzip d'
    assert not match(command)

    # Empty zip
    command = 'unzip e.zip'
    assert not match(command)

    # Good zip

    command = 'unzip -d c f.zip'
    assert not match(command)

    # Unzip to directory
    command = 'unzip -d d e.zip'
    assert not match(command)



# Generated at 2022-06-12 11:09:03.518764
# Unit test for function side_effect
def test_side_effect():
    file_name = 'file.txt'
    with open(file_name, 'w') as f:
        f.write('old content')
    old_cmd = Command('', 'unzip')
    cmd = Command(u'unzip -d test/sample.zip', 'unzip')
    side_effect(old_cmd, cmd)
    assert os.path.getsize(file_name) == 0

# Generated at 2022-06-12 11:09:08.724187
# Unit test for function side_effect
def test_side_effect():
    assert os.path.exists('test') == False
    with open('test/test.txt', 'w') as f:
        f.write('test')

    assert os.path.exists('test/test.txt') == True
    side_effect(None, None)
    assert os.path.exists('test/test.txt') == True

    os.remove('test/test.txt')
    os.rmdir('test')

# Generated at 2022-06-12 11:09:15.144288
# Unit test for function match
def test_match():
    assert not match(Command('zip -r a.zip a_folder', ''))
    assert not match(Command('zip a.zip a', ''))
    assert match(Command('unzip a.zip', ''))
    assert match(Command('unzip a.zip c', ''))
    assert match(Command('unzip a.zip c d', ''))
    assert match(Command('unzip a.zip a', ''))

# Generated at 2022-06-12 11:09:23.282300
# Unit test for function match
def test_match():
    from tests.utils import Command

    assert match(Command('unzip', 'unzip archive.zip'))
    assert not match(Command('unzip', 'unzip archive.zip -d foo'))
    assert match(Command('unzip', 'unzip archive.zip\nsome thing'))
    assert match(Command('unzip', 'unzip -x archive.zip'))
    assert match(Command('unzip', 'unzip -d directory archive.zip'))
    assert match(Command('unzip', 'unzip archive.zip\nunzip foo'))
    assert match(Command('unzip', 'unzip -x archive.zip\nsome thing'))

    assert not match(Command('unzip', 'unzip'))
    assert not match(Command('unzip', 'unzip\nunzip'))

# Generated at 2022-06-12 11:09:45.837847
# Unit test for function match
def test_match():
    cmd = 'unzip README.txt.zip'
    assert not match(cmd)

    cmd = 'unzip -d example.zip'
    assert not match(cmd)

    cmd = 'unzip README.txt.zip README.txt'
    assert not match(cmd)

    cmd = 'unzip README.txt.zip README.txt -x something.txt'
    assert not match(cmd)

    cmd = 'unzip README.zip'
    assert match(cmd)

    cmd = 'unzip README.zip README.txt'
    assert match(cmd)

    cmd = 'unzip README.zip README.txt -x something.txt'
    assert match(cmd)



# Generated at 2022-06-12 11:09:49.829169
# Unit test for function match
def test_match():
    from thefuck.types import Command

    assert match(
        Command('unzip file.zip', 'bad.zip:  bad zipfile offset (local header sig):  failed to find end of central directory', '', '', ''))
    assert not match(Command('unzip file.zip -d dest', '', '', '', ''))



# Generated at 2022-06-12 11:09:53.827836
# Unit test for function side_effect
def test_side_effect():
    """Test the side effect function"""
    old_cmd = 'unzip test.zip'
    cmd = 'unzip -d test/ test.zip'
    os.mkdir('test')
    with open('test/text', 'w') as f:
        f.write('text_in_file')

    side_effect(old_cmd, cmd)

    assert not os.path.exists('test/text')

# Generated at 2022-06-12 11:10:01.754524
# Unit test for function side_effect
def test_side_effect():
    tmp_dir = tempfile.mkdtemp()
    os.chdir(tmp_dir)
    file_name = os.path.join(tmp_dir, "test_file")
    script = 'unzip ' + file_name
    fake_command = type('FakeCommand', (object,), dict(script=script, script_parts=script.split()))

    open(file_name, 'w').close()
    open(file_name + '.zip', 'w').close()

    side_effect(fake_command, None)

    assert os.path.exists(file_name + '.zip')
    assert not os.path.exists(file_name)

# Generated at 2022-06-12 11:10:12.562000
# Unit test for function side_effect
def test_side_effect():
    import zipfile
    import os
    test_zip = "stuff.zip"
    file1 = "potato"
    file2 = "/tmp/potato"
    file3 = "kittens/potato"

    with zipfile.ZipFile(test_zip, 'w') as z:
        z.writestr(file1, "potato1")
        z.writestr(file2, "potato2")
        z.writestr(file3, "potato3")
    assert os.path.isfile(file1)
    assert os.path.isfile(file2)
    assert not os.path.isfile(file3)


# Generated at 2022-06-12 11:10:21.409022
# Unit test for function side_effect
def test_side_effect():
    with open('test_file.txt', 'w') as fp:
        fp.write('test_file\n')
    with open('test_file2.txt', 'w') as fp:
        fp.write('test_file2\n')
    zipf = zipfile.ZipFile('test_archive.zip', 'w')
    zipf.write('test_file.txt')
    zipf.close()
    script_parts = ['unzip', 'test_archive.zip']
    command = Mock(script_parts=script_parts)
    side_effect(command, command)
    with open('test_file.txt') as fp:
        assert not 'test_file\n' in fp.readline()

# Generated at 2022-06-12 11:10:32.456257
# Unit test for function match
def test_match():
    assert match(Command('unzip my_archive.zip', '')) == False  # archive does not exist (False)
    assert match(Command('unzip -d my_archive.zip', '')) == False  # don't want to unzip into a directory (False)
    assert match(Command('unzip -d my_archive.zip', '')) == False  # don't want to unzip into a directory (False)
    assert match(Command('unzip this_archive.zip', '')) == False  # archive does not exist (False)
    assert match(Command('unzip my_archive.zip foo bar', '')) == False  # archive exists but no files inside (False)
    assert match(Command('unzip my_archive.zip foo bar', '')) == False  # archive exists but no files inside (False)

# Generated at 2022-06-12 11:10:40.695036
# Unit test for function match
def test_match():
    assert match(Command('unzip', 'unzip /tmp/test.zip'))
    assert match(Command('unzip', 'unzip /tmp/test.zip -x /tmp/test2.zip'))
    assert not match(Command('unzip', 'unzip /tmp/test.zip -d /tmp/test'))
    assert not match(
        Command('unzip', 'unzip /tmp/test.zip -d /tmp/test file'))
    assert not match(
        Command('unzip', 'unzip /tmp/test.zip -d /tmp/test file.txt'))
    assert not match(
        Command('unzip', 'unzip /tmp/test.zip -d /tmp/test /tmp/file.txt'))

# Generated at 2022-06-12 11:10:50.689072
# Unit test for function side_effect
def test_side_effect():
    dir = '.'
    archive = zipfile.ZipFile('archive.zip', 'w')
    archive.write('{}/file1.txt'.format(dir))
    archive.write('{}/file2.txt'.format(dir))
    dir2 = './dir2'
    archive.write('{}/file3.txt'.format(dir2))
    archive.close()

    file1_path = '{}/file1.txt'.format(dir)
    file2_path = '{}/file2.txt'.format(dir)
    file3_path = '{}/file3.txt'.format(dir2)
    file4_path = 'file4.txt'
    file5_path = 'file5.txt'
    with open(file1_path, 'w') as f:
        pass

# Generated at 2022-06-12 11:10:57.362359
# Unit test for function side_effect
def test_side_effect():
    from tempfile import mkdtemp
    import shutil

    path = mkdtemp()

# Generated at 2022-06-12 11:11:26.993272
# Unit test for function match
def test_match():
    assert match(Command('unzip x.zip', '', None))
    assert match(Command('unzip x', '', None))
    assert not match(Command('unzip x.zip -d x', '', None))
    assert not match(Command('cat x.zip', '', None))


# Generated at 2022-06-12 11:11:32.958686
# Unit test for function side_effect
def test_side_effect():
    cmd = 'unzip file.zip'
    with zipfile.ZipFile('file.zip', 'w') as archive:
        archive.writestr('file1.txt', b'This is a test')
    old_cmd = u'{} -d {}'.format(cmd, shell.quote(_zip_file(cmd)[:-4]))
    side_effect(old_cmd, '')
    assert os.path.isfile('file1.txt')

# Generated at 2022-06-12 11:11:37.148508
# Unit test for function match
def test_match():
	assert not match(Command("unzip file.zip"))
	assert not match(Command("unzip -d file.zip"))
	assert match(Command("unzip file.zip"))
	assert match(Command("unzip file1.zip file2.zip file3.zip"))


# Generated at 2022-06-12 11:11:46.552840
# Unit test for function side_effect
def test_side_effect():
    # Test that files are not deleted if they are in a subdirectory of the current
    # directory.
    import mock
    import shutil
    from thefuck.rules.unzip_single_file import side_effect

    old_cmd = mock.Mock(script='unzip some_archive.zip')
    old_cmd.script_parts = ['unzip', 'some_archive.zip']
    old_cmd.command = 'unzip some_archive.zip'

    shutil.rmtree('some_archive', ignore_errors=True)
    os.mkdir('some_archive')
    open('some_archive/some_file', 'w').close()

    side_effect(old_cmd, 'unzip some_archive.zip -d some_archive')

    # If the file has been removed, an OSError will be raised when

# Generated at 2022-06-12 11:11:54.941070
# Unit test for function match
def test_match():
    # Test with a zip archive containing only one file
    with patch('os.path.isfile', return_value=True):
        with patch('thefuck.rules.zip.zipfile.ZipFile', autospec=True) as mock_zipfile:
            mock_zipfile.return_value.namelist.return_value = ['file1.txt']
            assert match(Command('unzip file1.zip', '/bin/unzip'))
    assert not match(Command('unzip file1.zip file1.txt', '/bin/unzip'))

    # Test with a zip archive containing multiple files
    with patch('os.path.isfile', return_value=True):
        with patch('thefuck.rules.zip.zipfile.ZipFile', autospec=True) as mock_zipfile:
            mock_zipfile.return_value.nam

# Generated at 2022-06-12 11:12:05.680284
# Unit test for function side_effect
def test_side_effect():
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-12 11:12:14.988438
# Unit test for function side_effect
def test_side_effect():
    class C:
        def __init__(self, script):
            self.script = script

        def __call__(self, cmd):
            return get_new_command(self)

    # creation of a temporary directory
    temp_dir = tempfile.mkdtemp()
    # creation of a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()
    # creation of a temporary zip file
    temp_zip = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_zip.close()
    with zipfile.ZipFile(temp_zip.name, 'w') as archive:
        archive.write(temp_file.name, arcname=os.path.basename(temp_file.name))
   

# Generated at 2022-06-12 11:12:16.530698
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command

# Generated at 2022-06-12 11:12:25.759126
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command

    os.system('mkdir test_folder')
    os.chdir('test_folder')
    os.system('touch file')
    os.system('touch file1')

    with open('file', 'w') as f:
        f.write(u'test')
    with open('file1', 'w') as f1:
        f1.write(u'test1')


# Generated at 2022-06-12 11:12:28.887751
# Unit test for function match
def test_match():
    assert match(Command('unzip archive.zip', 'archive.zip'))
    assert not match(Command('unzip archive.zip -d directory', 'archive.zip'))



# Generated at 2022-06-12 11:12:56.611778
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import Bash
    cmd = Bash('unzip sample.zip')
    assert side_effect(cmd, None)

# Generated at 2022-06-12 11:12:59.137923
# Unit test for function match
def test_match():
    result = match(u'unzip test.zip')
    assert result == True
    result = match(u'unzip test.zip -d test')
    assert result == False

# Generated at 2022-06-12 11:13:04.488294
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', ''))
    assert match(Command('unzip test.zip file1 file2', ''))
    assert not match(Command('unzip test.zip -d test', ''))
    assert not match(Command('unzip test.zip file1 file2 -d test', ''))
    assert not match(Command('unzip -q test.zip', ''))


# Generated at 2022-06-12 11:13:08.424788
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', ''))
    assert match(Command('unzip test.zip a b -c', ''))
    assert not match(Command('unzip -d test.zip', ''))
    assert not match(Command('unzip -d test.zip', ''))

# Generated at 2022-06-12 11:13:19.361869
# Unit test for function side_effect
def test_side_effect():
    output = 'Archive:  test-bad.zip\n'\
             '   creating: test/\n'\
             '  inflating: test/test.txt      \n'\
             '   creating: test/test2/\n'\
             '  inflating: test/test2/dir.txt  \n'\
             '  inflating: test2.txt           \n'\
             '  inflating: test3.txt           \n'\
             '  inflating: test4.txt           \n'
    # First, create files and directories
    with open('test.txt', 'w') as test:
        test.write('test')
    with open('test2.txt', 'w') as test:
        test.write('test')

# Generated at 2022-06-12 11:13:25.425157
# Unit test for function match
def test_match():
    # False tests
    c1 = Command('unzip -d folder file.zip',
                 '  extracting: file.zip                                                      ')
    assert not match(c1)

    c2 = Command('unzip -d folder file.zip',
                 '  inflating: file.zip                                                      ')
    assert not match(c2)

    c3 = Command('unzip file.zip',
                 'error:  file.zip:  not a valid zip file')
    assert not match(c3)

    # True tests
    c4 = Command('unzip file.zip',
                 'caution: filename not matched: file.zip')
    assert match(c4)

    c5 = Command('unzip file.zip',
                 '  inflating: file.zip                                                      ')
    assert match(c5)


# Generated at 2022-06-12 11:13:32.721334
# Unit test for function side_effect
def test_side_effect():
    """ Create a fake zip file with another directory inside and make sure it
    doesn't get created to avoid overwritting outside the current directory """

    """ Create a fake zip file with two files inside and make sure they get
    deleted """

    import tempfile
    import zipfile

    # Create a temp directory to work inside
    work_directory = tempfile.mkdtemp()

# Generated at 2022-06-12 11:13:38.158743
# Unit test for function match
def test_match():
    assert match(Command('unzip', '', '')
                 ) == False

    assert match(Command('unzip', 'hello.zip', '')
                 ) == True

    assert match(Command('unzip', 'hello.zip -d', '')
                 ) == False

    assert match(Command('unzip', 'hello.zip -d tmp', '')
                 ) == False

# Generated at 2022-06-12 11:13:46.387596
# Unit test for function side_effect
def test_side_effect():
    bad_zip = 'foo/bar/test.zip'
    command = 'unzip ' + bad_zip
    old_cmd = Command(command)
    os.makedirs(os.path.dirname(bad_zip))
    write_file(bad_zip, 'test content')

# Generated at 2022-06-12 11:13:49.022404
# Unit test for function match
def test_match():
    assert _is_bad_zip('test_match_zipfile.zip')
    assert not _is_bad_zip('test_match_zipfile2.zip')


# Generated at 2022-06-12 11:14:44.571423
# Unit test for function match
def test_match():
    f = _is_bad_zip(u'a_file.zip')
    assert f is True
    f = _is_bad_zip(u'/home/dimas/a_file.zip')
    assert f is True


# Generated at 2022-06-12 11:14:51.823914
# Unit test for function match
def test_match():
    (test_script, test_file, test_dir) = ('test_script.zip', 'test_file', 'test_dir')
    with open(test_script, 'w') as f:
        pass
    with open(test_dir, 'w') as f:
        pass
    import thefuck.shells
    thefuck.shells.shell.known_executables.update({'unzip': 'unzip'})

    os.system((u'unzip -o {} {} {} {}'.format(test_script, test_file, test_dir, ' >/dev/null 2>&1')))

    archive = zipfile.ZipFile(test_script, 'r')
    assert archive.namelist() == [test_file, test_dir]

    from thefuck.rules.unzip_single_file import match
   

# Generated at 2022-06-12 11:15:02.138274
# Unit test for function side_effect
def test_side_effect():
    # Create temporary directory for testing
    tmpd = tempfile.mkdtemp()

    # Create test files
    safe_file = os.path.join(tmpd, 'safe.txt')
    with open(safe_file, 'w'):
        pass
    unsafe_file = os.path.join(tmpd, 'unsafe.txt')
    with open(unsafe_file, 'w'):
        pass
    test_directory = os.path.join(tmpd, 'test_dir')
    os.mkdir(test_directory)
    safe_dir = os.path.join(tmpd, 'safe_dir')
    os.mkdir(safe_dir)

    # Create zip file
    archive = zipfile.ZipFile(os.path.join(tmpd, 'test.zip'), 'w')
    archive.write

# Generated at 2022-06-12 11:15:10.958250
# Unit test for function side_effect
def test_side_effect():
    test_dir = os.path.join(os.getcwd(), 'test_dir_unzip_test')
    os.mkdir(test_dir)
    os.chdir(test_dir)

# Generated at 2022-06-12 11:15:21.652723
# Unit test for function match
def test_match():
    # Test for a zip file with multiple files
    assert match(Command('unzip test.zip', '', '')) is True
    # Test for a zip file with multiple files and flag -d
    assert match(Command('unzip -d test.zip', '', '')) is False
    # Test for a zip file with multiple files with other flags
    assert match(Command('unzip -o test.zip', '', '')) is True
    # Test for a zip file with one file
    assert match(Command('unzip test2.zip', '', '')) is False
    # Test for a zip file with one file with other flags
    assert match(Command('unzip -o test2.zip', '', '')) is False
    # Test for no zipfile and other flags
    assert match(Command('unzip -o', '', '')) is False
    #

# Generated at 2022-06-12 11:15:26.988346
# Unit test for function match
def test_match():
    # unzip has only one argument
    assert match(Command(script='unzip archive.zip')) == False

    # unzip has more than one argument
    assert match(Command(script='unzip archive.zip file1')) == False

    # unzip is extracting to a specified directory
    assert match(Command(script='unzip -d a.zip')) == False

    # unzip is extracting to the current directory
    # and the zip file contains more than two files
    assert match(Command(script='unzip archive.zip')) == True



# Generated at 2022-06-12 11:15:29.407570
# Unit test for function match
def test_match():
    from thefuck.rules.no_zip_files import match
    assert match(u'unzip test.zip')
    assert not match(u'unzip test.zip')


# Generated at 2022-06-12 11:15:38.523584
# Unit test for function match
def test_match():
    command = """
foo.zip
"""
    command = ShellCommand(command,[],'')
    assert(match(command) == False)
    command = """
foo.zip -d
"""
    command = ShellCommand(command,[],'')
    assert(match(command) == False)
    command = """
foo -d
"""
    command = ShellCommand(command,[],'')
    assert(match(command) == False)
    command = """
apt-get install foo -d
"""
    command = ShellCommand(command,[],'')
    assert(match(command) == False)
    command = """
apt-get install foo
"""
    command = ShellCommand(command,[],'')
    assert(match(command) == False)
    command = """
unzip foo.dff
"""

# Generated at 2022-06-12 11:15:41.269487
# Unit test for function side_effect
def test_side_effect():
    old_cmd = type('', (), {'script': 'unzip test -d test_dir', 'script_parts': ['unzip', 'test', '-d', 'test_dir']})
    command = type('', (), {'script': '', 'script_parts': []})
    side_effect(old_cmd, command)
    assert os.listdir(os.getcwd()) == []

# Generated at 2022-06-12 11:15:42.526584
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', '', ''))


# Generated at 2022-06-12 11:17:37.428172
# Unit test for function side_effect
def test_side_effect():
    import os
    file_name = "test.zip"
    directory_name = "test_directory"
    cmd = "unzip " + file_name
    if os.path.exists(file_name):
        os.remove(file_name)
    if os.path.exists(directory_name):
        os.rmdir(directory_name)
    with zipfile.ZipFile(file_name, 'w') as new_zip:
        new_zip.write("test_file.txt")
    side_effect(cmd, cmd)
    assert not os.path.exists("test_file.txt")
    assert os.path.exists(directory_name)

# Generated at 2022-06-12 11:17:46.464341
# Unit test for function side_effect
def test_side_effect():
    with tempfile.TemporaryDirectory() as temp_dir:
        script = "unzip file.zip"
        cmd = shell.and_('cd {}'.format(temp_dir), script)
        old_cmd = Command(script, cmd.script, cmd.stdout)

        with zipfile.ZipFile('file.zip', 'w') as zf:
            zf.writestr('exists', '')
            zf.writestr('existing_file', '')
            zf.writestr('existing_dir/file', '')
            os.mkdir('existing_dir')
            with open('existing_file', 'w'):
                pass

        side_effect(old_cmd, '')
        assert not os.path.exists('file.zip')
        assert os.path.exists('exists')
       

# Generated at 2022-06-12 11:17:50.031815
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import Bash

    old_cmd = Bash(u'unzip file_v1.zip')
    command = Bash(u'unzip -d file_v1 file_v1.zip')
    side_effect(old_cmd, command)

# Generated at 2022-06-12 11:17:51.457487
# Unit test for function side_effect
def test_side_effect():
    assert side_effect('unzip file.zip', 'unzip -d file.zip') == None

# Generated at 2022-06-12 11:17:53.933007
# Unit test for function match
def test_match():
    assert not match(Command('unzip -d dl/ test.zip', None))
    assert not match(Command('unzip -l test.zip', None))
    assert match(Command('unzip test.zip', None))
    assert match(Command('unzip test', None))
    assert match(Command('unzip test test2', None))


# Generated at 2022-06-12 11:18:02.391351
# Unit test for function side_effect
def test_side_effect():
    output = '''
        Archive:  test.zip
         creating: a/
        inflating: a/a
         creating: b/
        inflating: b/b
    '''

    old_cmd = Command('unzip test.zip', output)
    side_effect(old_cmd, 'unzip test.zip')

    assert os.path.isfile('a/a')
    assert os.path.isfile('b/b')

    # Remove files created by unit test
    os.remove('a/a')
    os.remove('b/b')
    os.rmdir('a')
    os.rmdir('b')

# Generated at 2022-06-12 11:18:08.232297
# Unit test for function match
def test_match():
    assert match(Command('unzip foo.zip', ''))
    assert match(Command('unzip foo.zip bar.txt', ''))
    assert match(Command('unzip foo.zip -d', ''))
    assert not match(Command('unzip foo.zip bar.txt -d', ''))
    assert not match(Command('unzip -d foo.zip bar.txt', ''))
    assert match(Command('unzip bar -d', ''))
    assert not match(Command('unzip bar.txt -d', ''))
    assert not match(Command('unzip -d bar.txt', ''))

