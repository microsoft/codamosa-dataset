

# Generated at 2022-06-12 11:08:22.057912
# Unit test for function side_effect
def test_side_effect():
    with zipfile.ZipFile('/tmp/test.zip', 'w') as archive:
        archive.writestr('/tmp/test1.txt', 'test')
    try:
        shell.set_append_history(False)
        shell.set_variable('LANG', 'C')  # disable translations
        side_effect(Mock(script=u'unzip /tmp/test.zip'), None)
        assert not os.path.exists('test1.txt')
    finally:
        shell.set_append_history(True)
        os.remove('/tmp/test.zip')

# Generated at 2022-06-12 11:08:32.260375
# Unit test for function side_effect
def test_side_effect():
    """Test the side_effect function of the unzip rule
    """
    import tempfile
    import shutil
    import zipfile
    import os

    dirpath = tempfile.mkdtemp()

    # Create a zipfile with 4 subdirectories
    path = os.path.join(dirpath, "newfile.zip")
    zip = zipfile.ZipFile(path, 'w')
    zip.writestr('file1.txt', 'Content of file1.txt')
    zip.writestr('dir/file2.txt', 'Content of dir/file2.txt')
    zip.writestr('dir/subdir/file3.txt', 'Content of dir/subdir/file3.txt')
    zip.writestr('test/file4.txt', 'Content of test/file4.txt')

# Generated at 2022-06-12 11:08:43.047326
# Unit test for function side_effect
def test_side_effect():
    filename = 'big.zip'
    test_dir = '/tmp/test_side_effect'
    with zipfile.ZipFile(filename, 'w') as archive:
        archive.writestr('hello', 'world')
        archive.writestr('how/are/you', 'world')
        archive.writestr('you/how/are', 'world')
        archive.writestr(test_dir + '/hello', 'world')
        archive.write('setup.py', 'setup.py')

    old_cmd = Command(filename, 'unzip', None)
    new_cmd = Command(filename, 'unzip', test_dir)

    if os.path.exists(new_cmd.script_parts[-1]):
        shutil.rmtree(new_cmd.script_parts[-1])

    side

# Generated at 2022-06-12 11:08:53.782119
# Unit test for function side_effect
def test_side_effect():
    safe = lambda: os.path.join(os.getcwd(), 'file' + str(i))
    for i in range(3):
        file = safe()
        assert not os.path.exists(file)
        with open(file, 'w') as f:
            f.write('Dummy file')
    with open('/tmp/file', 'w') as f:
        f.write('Dummy file')
    for i in range(3):
        assert os.path.exists(safe())

    side_effect(Command('unzip /tmp/archive.zip'), Command(''))

    assert os.path.exists('/tmp/file')
    for i in range(3):
        assert not os.path.exists(safe())
    for i in range(3):
        assert os.path.exists

# Generated at 2022-06-12 11:08:59.165636
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip'))
    assert match(Command('unzip test'))
    assert not match(Command('unzip -d test.zip'))
    assert not match(Command('unzip'))
    assert not match(Command('unzip -l test.zip'))
    assert match(Command('unzip -r test.zip'))


# Generated at 2022-06-12 11:09:07.576627
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import shell
    import tempfile
    import zipfile

    with tempfile.TemporaryDirectory() as temp_dir:
        with tempfile.NamedTemporaryFile(dir=temp_dir, delete=False) as temp_file:
            temp_file.write(b'zipfile.test.test_zipfile.test.test_zipfile\n')
            temp_file.flush()
            temp_file.close()

            with zipfile.ZipFile(temp_file.name, 'w') as archive:
                archive.write(temp_file.name)

            old_cmd = shell.And('echo', 'unzip', temp_file.name)
            side_effect(old_cmd, old_cmd)

        assert not os.path.exists(temp_file.name)

# Generated at 2022-06-12 11:09:18.294417
# Unit test for function side_effect
def test_side_effect():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import path, mkdir, chdir
    from unittest import TestCase

    tmp = mkdtemp()

# Generated at 2022-06-12 11:09:24.908128
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', 'cd folder', u'unzip:  cannot find or open file.zip, file.zip.zip or file.zip.ZIP.'))
    assert not match(Command('unzip file.zip -d folder', 'cd folder', u'unzip:  cannot find or open file.zip, file.zip.zip or file.zip.ZIP.'))
    assert match(Command('unzip file.zip -d folder', 'cd folder', u'unzip:  cannot find or open folder.zip, folder.zip.zip or folder.zip.ZIP.'))
    assert not match(Command('unzip file.zip', 'cd folder', u'unzip:  cannot find or open folder.zip, folder.zip.zip or folder.zip.ZIP.'))


# Generated at 2022-06-12 11:09:29.772917
# Unit test for function side_effect
def test_side_effect():
    import os
    import tempfile

    tempdir = tempfile.mkdtemp()
    os.chdir(tempdir)
    zip_file = os.path.join(tempdir, 'file.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('file', "Some content")
    side_effect('unzip file', 'unzip -d file')
    assert not os.path.exists('file')
    assert os.path.exists(os.path.join('file', 'file'))

# Generated at 2022-06-12 11:09:39.395177
# Unit test for function side_effect
def test_side_effect():
    import shutil, tempfile
    from thefuck.types import Command
    from thefuck.shells import shell
    from thefuck.rules.unzip import get_new_command, side_effect

    dirpath = tempfile.mkdtemp()

    with zipfile.ZipFile(os.path.join(os.path.dirname(__file__), 'fixtures/unzip.zip'), 'r') as archive:
        archive.extractall(dirpath)

    old_cmd = Command('unzip unzip.zip', 'file already exists', '/path/to')
    new_cmd = get_new_command(old_cmd)
    side_effect(old_cmd, Command(new_cmd, '', '/path/to'))

# Generated at 2022-06-12 11:09:54.096165
# Unit test for function side_effect
def test_side_effect():
    old_cmd = 'unzip file.zip'
    command = 'unzip -d file'
    side_effect(old_cmd, command)

# Generated at 2022-06-12 11:09:59.456967
# Unit test for function match
def test_match():
    from tests.utils import Command

    # If the file exists, match should return TRUE
    assert match(Command('unzip blah.zip')) == True
    assert match(Command('unzip blah')) == True

    # If the file doesnt exist, match should return FALSE
    assert match(Command('unzip blah.zip', '/does/not/exist')) == False
    assert match(Command('unzip blah', '/does/not/exist')) == False

# Generated at 2022-06-12 11:10:04.502498
# Unit test for function match

# Generated at 2022-06-12 11:10:14.653878
# Unit test for function match
def test_match():
    import pytest
    from thefuck.rules.zip_to_unzip import match
    command = type('obj', (object,), {'script': 'zip a.zip a', 'script_parts': ['zip', 'a.zip', 'a' ]})
    command1 = type('obj', (object,), {'script': 'zip a.zip a -d', 'script_parts': ['zip', 'a.zip', 'a' ]})
    command2 = type('obj', (object,), {'script': 'zip file1.zip file2.zip', 'script_parts': ['zip', 'file1.zip', 'file2.zip' ]})

# Generated at 2022-06-12 11:10:17.355508
# Unit test for function match
def test_match():
    """
    Match no parameters
    """
    command = Command(script=['unzip'], stdout='')
    assert not match(command)



# Generated at 2022-06-12 11:10:28.085033
# Unit test for function side_effect
def test_side_effect():
    # remove file if exists
    side_effect_file = os.getcwd()+'/side_effect'
    if os.path.exists(side_effect_file):
        os.remove(side_effect_file)
    open(side_effect_file, 'a').close()
    # zip the file
    test_zip_file = os.getcwd()+'/test.zip'
    with zipfile.ZipFile(test_zip_file, 'w') as test_archive:
        test_archive.write(side_effect_file)
    # remove file again
    os.remove(side_effect_file)
    # unzip the file
    side_effect(Command('unzip test.zip', ''), Command('unzip -d . test.zip', ''))
    # check if file was created

# Generated at 2022-06-12 11:10:34.195256
# Unit test for function match
def test_match():
    command = type('Command', (object,), {'script': 'unzip file1.zip'})
    assert match(command)
    command = type('Command', (object,), {'script': 'unzip -d file1.zip'})
    assert not match(command)
    command = type('Command', (object,), {'script': 'unzip file2.zip'})
    assert not match(command)

# Generated at 2022-06-12 11:10:41.406552
# Unit test for function side_effect
def test_side_effect():
    # Create a test zip file
    z = zipfile.ZipFile('test.zip', mode='w')
    try:
        z.writestr('test.txt', 'The unzip command will extract the "test.txt" file.\n')
    finally:
        z.close()

    # Check to see if the file was created in the current directory
    assert os.path.isfile('./test.zip') is True

    # Simulate the user running the "unzip test.zip" command
    side_effect(
        command=u'unzip test.zip',
        old_cmd=u'unzip test.zip')

    # Check to see if the file was extracted from the .zip archive
    assert os.path.isfile('./test.txt') is True

    # Cleanup old files

# Generated at 2022-06-12 11:10:46.411335
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', '', ''))
    assert match(Command('unzip file', '', '', ''))
    assert not match(Command('unzip -d dir file.zip', '', '', ''))
    assert not match(Command('unzip -d dir file', '', '', ''))


# Generated at 2022-06-12 11:10:54.794651
# Unit test for function side_effect
def test_side_effect():
    """
    Check whether the directory and its content is deleted
    """
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as tempdir:
        subdir = os.path.join(tempdir, "subdir")
        os.makedirs(subdir)
        open(os.path.join(subdir, "file.txt"), "w+").close()
        shutil.make_archive(os.path.join(tempdir, "test-archive"), "zip", root_dir=subdir)
        class FakeCommand:
            def __init__(self):
                self.script = "unzip {} -d {}".format(os.path.join(tempdir, "test-archive"), subdir)
                self.script_parts = self.script.split()


# Generated at 2022-06-12 11:11:26.589897
# Unit test for function match
def test_match():
    _c1 = Command('unzip file.zip', None)
    _c2 = Command('unzip file', None)
    _c3 = Command('unzip -d dir file.zip', None)
    _c4 = Command('unzip -t file.zip', None)
    assert match(_c1)
    assert match(_c2)
    assert not match(_c3)
    assert not match(_c4)



# Generated at 2022-06-12 11:11:37.227228
# Unit test for function side_effect
def test_side_effect():
    os.mkdir("/home/samir/t")
    os.mkdir("/home/samir/t/pp")
    os.mkdir("/home/samir/t/pp/f")
    os.mkdir("/home/samir/t/pp/f/kk")
    os.mkdir("/home/samir/t/pp/f/kk/l")
    os.mkdir("/home/samir/t/pp/f/kk/l/o")
    os.mkdir("/home/samir/t/pp/f/kk/l/o/o")
    os.mkdir("/home/samir/t/pp/f/kk/l/o/o/t")

# Generated at 2022-06-12 11:11:46.621319
# Unit test for function match
def test_match():
    # empty command
    assert not match(Command(script=''))

    # command with not supported flags
    assert not match(Command(script='unzip -n file.zip'))
    assert not match(Command(script='unzip -x file.zip'))
    assert not match(Command(script='unzip -d file.zip'))
    assert not match(Command(script='unzip -f file.zip'))
    assert not match(Command(script='unzip -a file.zip'))

    # command with not supported file extension
    assert not match(Command(script='unzip file'))
    assert not match(Command(script='unzip file.tar'))

    # command with not supported file
    assert not match(Command(script='unzip file.zip'))

    # single file in the archive
    # NOTE: the

# Generated at 2022-06-12 11:11:54.964992
# Unit test for function match
def test_match():
    # Unit test for function match: unzip without -d
    bad_script = 'unzip {}'
    zip_file = 'file.zip'

    assert _zip_file(Command(bad_script.format(zip_file), '')) == zip_file

    assert match(Command('unzip {}'.format(zip_file), ''))
    assert not match(Command('unzip -d {}'.format(zip_file), ''))
    assert not match(Command('unzip -d {} 1'.format(zip_file), ''))

    # Unit test for function match: unzip with -d
    assert _zip_file(Command(bad_script.format(zip_file), '')) == zip_file

    assert match(Command('unzip {}'.format(zip_file), ''))

# Generated at 2022-06-12 11:11:57.269316
# Unit test for function match
def test_match():
    command = 'unzip foo.zip'
    assert match(command)
    command = 'unzip foo.zip -d bar'
    assert not match(command)

# Generated at 2022-06-12 11:12:08.693607
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    cur_dir = os.path.join(test_dir, 'current')
    os.mkdir(cur_dir)
    os.mkdir(os.path.join(test_dir, 'tobeignored'))

    _create_dirs_and_files(cur_dir)

    with tempfile.TemporaryFile() as temp_file:
        with zipfile.ZipFile(temp_file, 'w') as temp_archive:
            temp_archive.write(os.path.join(test_dir, 'current', 'foo'), 'foo')
            temp_archive.write(os.path.join(test_dir, 'current', 'test', 'foo'), 'test/foo')

# Generated at 2022-06-12 11:12:16.045608
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    test_cmd = Command('unzip test.zip')
    with zipfile.ZipFile('test.zip', 'w') as archive:
                archive.writestr('filefoo', 'foo')
                archive.writestr('filebar', 'bar')
    try:
        side_effect(test_cmd, None)
        with open('filefoo', 'r') as f:
            assert f.read() == 'foo'
        with open('filebar', 'r') as f:
            assert f.read() == 'bar'
    finally:
        os.remove('filefoo')
        os.remove('filebar')
        os.remove('test.zip')

# Generated at 2022-06-12 11:12:25.651765
# Unit test for function side_effect
def test_side_effect():
    import tempfile

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a zip file with a directory and a file
    tmp_zip = os.path.join(tmp_dir, 'tmp.zip')
    with zipfile.ZipFile(tmp_zip, 'w') as archive:
        archive.writestr('file1', '')
        archive.writestr('dir/file2', '')

    # Create side effects
    assert(os.path.exists(tmp_zip))
    side_effect(Command(tmp_zip, '', ''), Command(tmp_zip, '', ''))
    assert(not os.path.exists(tmp_zip))
    assert(not os.path.exists(os.path.join(tmp_dir, 'dir')))

# Generated at 2022-06-12 11:12:34.313922
# Unit test for function side_effect
def test_side_effect():
    import os
    import zipfile
    from thefuck.rules.unzip import side_effect

    test_zip_file = 'tests/unit/rules/unzip_test.zip'


# Generated at 2022-06-12 11:12:44.772389
# Unit test for function match
def test_match():
    assert not match('')
    assert not match('unzip foo.txt bar.txt')
    assert not match('unzip foo.txt bar.txt -d baz')

    # Non existing zip file
    assert not match('unzip doesntExist')
    assert not match('unzip doesntExist.zip')

    # Empty file
    f = open('empty.zip', 'w')
    f.close()
    assert not match('unzip empty')
    assert not match('unzip empty.zip')
    os.remove('empty.zip')

    # A single file in the archive
    f = open('single.txt', 'w')
    f.close()
    with zipfile.ZipFile('single.zip', 'w') as myzip:
        myzip.write('single.txt')
    assert not match('unzip single')

# Generated at 2022-06-12 11:13:15.563597
# Unit test for function match
def test_match():
    script = 'unzip test.zip'
    assert match(Command(script, '')) is False
    assert match(Command(script, '')) is False
    assert match(Command(script, '')) is False
    assert match(Command(script, '')) is False



# Generated at 2022-06-12 11:13:24.096114
# Unit test for function match
def test_match():
    from thefuck.rules.unzip_bad import _zip_file
    assert _zip_file(Command(script='unzip archive.zip',
                             script_parts=['unzip', 'archive.zip'])) == u'archive.zip'
    assert _zip_file(Command(script='unzip archive.zip file.txt',
                             script_parts=['unzip', 'archive.zip', 'file.txt'])) == u'archive.zip'
    assert _zip_file(Command(script='unzip -l archive.zip',
                             script_parts=['unzip', '-l', 'archive.zip'])) == u'archive.zip'

# Generated at 2022-06-12 11:13:32.528982
# Unit test for function side_effect
def test_side_effect():
    from thefuck.rules.unzip_single_file import side_effect
    import tempfile
    import shutil
    import os
    import zipfile
    from thefuck.shells.shell import quote
    from thefuck.shells.bash import Bash

    with tempfile.TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        os.mkdir('dir1')
        os.mkdir('dir2')
        with open('file1', 'w') as f:
            f.write('foo')
        with open('file2', 'w') as f:
            f.write('bar')
        with open('file3', 'w') as f:
            f.write('baz')
        with open('file4', 'w') as f:
            f.write('foobar')


# Generated at 2022-06-12 11:13:43.138848
# Unit test for function side_effect
def test_side_effect():
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        archive = zipfile.ZipFile(os.path.join(tmpdir, 'archive.zip'), 'w')

        # create 2 files to be unzipped
        with open(os.path.join(tmpdir, 'test.txt'), 'w') as file:
            file.write('test')
        with open(os.path.join(tmpdir, 'test2.txt'), 'w') as file:
            file.write('test')

        archive.write(os.path.join(tmpdir, 'test.txt'))
        archive.write(os.path.join(tmpdir, 'test2.txt'))
        archive.close()

        class Command(object):
            script = u'unzip /tmp/archive.zip'
            script_parts

# Generated at 2022-06-12 11:13:47.044990
# Unit test for function side_effect
def test_side_effect():
    # if the file is in the current directory, it will be overwritten
    assert side_effect('unzip file', 'unzip -d folder file') == None
    # if the file is outside the current directory, it will not be overwritten
    assert side_effect('unzip /file', 'unzip -d folder /file') == None

# Generated at 2022-06-12 11:13:55.088344
# Unit test for function side_effect
def test_side_effect():
    with tempfile.TemporaryDirectory() as path:
        file1 = os.path.join(path, 'file1')
        file2 = os.path.join(path, 'file2')
        file1_test = os.path.join(path, 'file1_test')
        file2_test = os.path.join(path, 'file2_test')
        file3_test = os.path.join(path, 'fil3_test')
        file3 = os.path.join(path, 'fil3')
        file4_test = os.path.join(path, 'fil4_test')
        file4 = os.path.join(path, 'fil4')
        # Precondition
        with open(file1, 'w') as f:
            f.write('toto')

# Generated at 2022-06-12 11:14:04.488466
# Unit test for function match
def test_match():
    assert match(Command('unzip not_a_file.zip')) == False
    assert match(Command('unzip -l not_a_file.zip')) == False
    assert match(Command('unzip -d not_a_file.zip')) == False
    assert match(Command('unzip -l a_file.zip')) == True
    assert match(Command('unzip -l a_file.zip')) == True
    assert match(Command('unzip -l a_file.zip abc.txt')) == True
    assert match(Command('unzip a_file.zip abc.txt')) == True
    assert match(Command('unzip a_file')) == True
    assert True == match(Command('unzip bad.zip'))
    assert False == match(Command('unzip good.zip'))

# Generated at 2022-06-12 11:14:10.659881
# Unit test for function match
def test_match():
    assert match(Command('unzip', 'unzip A.zip'))
    assert match(Command('unzip', 'unzip A.zip A2.zip'))
    assert not match(Command('unzip', 'unzip -d A.zip A2.zip'))
    assert not match(Command('unzip', 'unzip A.zop'))
    assert not match(Command('unzip', 'unzip'))
    assert not match(Command('unzip', 'unzip A.zip -d'))



# Generated at 2022-06-12 11:14:19.677214
# Unit test for function side_effect
def test_side_effect():
    import subprocess
    import tempfile
    import shutil
    test_folder = tempfile.mkdtemp()
    with open(os.path.join(test_folder, 'testfile'), 'w') as test_file:
        test_file.write('test')

    with open(os.path.join(test_folder, 'testfile2'), 'w') as test_file:
        test_file.write('test2')

    command_script = "echo " + os.path.join(test_folder, 'testfile')
    old_cmd = subprocess.Popen(command_script, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    old_cmd = old_cmd.stdout.read().decode('utf-8').strip()

# Generated at 2022-06-12 11:14:28.212259
# Unit test for function side_effect

# Generated at 2022-06-12 11:15:27.371688
# Unit test for function match
def test_match():
    from thefuck.types import Command

    assert not match(Command('unzip -d test.zip'))
    assert match(Command('unzip test.zip'))
    assert not match(Command('unzip test.zip -d tmp'))
    assert match(Command('unzip test.zip tmp'))



# Generated at 2022-06-12 11:15:32.838157
# Unit test for function match
def test_match():
    from thefuck.types import Command
    # It's true if:
    #     - there is no '-d' arg
    #     - there is '.zip' file
    #     - it has more than one file
    assert match(Command('unzip test.zip',
                         'test.zip:  not a valid zip file'))
    # It's false if there is '-d' arg
    assert not match(Command('unzip test.zip -d project',
                             'test.zip:  not a valid zip file'))
    # It's false if there is no '.zip' file
    assert not match(Command('unzip test',
                             'test.zip:  not a valid zip file'))
    # It's false if there isn't more than one file

# Generated at 2022-06-12 11:15:41.140449
# Unit test for function match
def test_match():
    resolved = True
    assert match(Command('unzip example.zip', '')) == resolved
    assert match(Command('unzip example.zip -d example', '')) == (not resolved)
    assert match(Command('unzip bad_example.zip', '')) == resolved
    assert match(Command('unzip bad_example.zip -d example', '')) == (not resolved)
    assert match(Command('unzip good_example.zip', '')) == (not resolved)
    assert match(Command('unzip good_example.zip -d example', '')) == (not resolved)
    assert match(Command('unzip hello.zip', '')) == (not resolved)
    assert match(Command('unzip hello.zip -d example', '')) == (not resolved)
    assert match(Command('unzip hello.ZIP', '')) == (not resolved)

# Generated at 2022-06-12 11:15:50.634360
# Unit test for function match
def test_match():
    assert _is_bad_zip('tests/test_zip')
    assert not _is_bad_zip('tests/test_zip_ok')
    assert match(Command(script='unzip tests/test_zip.zip',
                         stderr='unzip:  cannot find or open tests/test_zip.zip, tests/test_zip.zip.zip or tests/test_zip.zip.ZIP.'))
    assert match(Command(script='unzip -L tests/test_zip.zip',
                         stderr='unzip:  cannot find or open tests/test_zip.zip, tests/test_zip.zip.zip or tests/test_zip.zip.ZIP.'))

# Generated at 2022-06-12 11:15:54.608322
# Unit test for function side_effect
def test_side_effect():
    old_cmd = [['fuck'], ['-d', '/home/user/test'], ['-l']]
    command = [['fuck'], ['-d'], ['/home/user/test']]
    side_effect(old_cmd, command)
    assert os.access('/home/user/test', os.R_OK)

# Generated at 2022-06-12 11:15:59.577021
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command('unzip ./test.zip')
    command = Command(get_new_command(old_cmd))
    side_effect(old_cmd, command)
    assert not os.path.exists('./folder/test.txt')
    assert os.path.exists('./folder/empty')
    os.rmdir('./folder/empty')
    os.rmdir('./folder')

# Generated at 2022-06-12 11:16:06.214657
# Unit test for function side_effect
def test_side_effect():
    old_cmd = mock.MagicMock(script='unzip 1.zip')
    mock_zipfile = mock.MagicMock(namelist=['1.zip'])
    with mock.patch(
        'zipfile.ZipFile', return_value=mock_zipfile
    ), mock.patch('os.remove'):
        side_effect(old_cmd, 'unzip -d 1 1.zip')
        mock_zipfile.extractall.assert_called_once_with('1')

# Generated at 2022-06-12 11:16:10.509301
# Unit test for function match
def test_match():
    assert match(Command("unzip test.zip", "", "")) is False
    assert match(Command("unzip -d test test.zip", "", "")) is False
    assert match(Command("unzip -d test.zip", "", "")) is False
    assert match(Command("unzip test.zip test1 test2", "", "")) is True
    assert match(Command("unzip -d test1 test2 test.zip", "", "")) is True



# Generated at 2022-06-12 11:16:18.135927
# Unit test for function side_effect
def test_side_effect():
    if not os.path.exists('/tmp/thefuck-test'):
        os.mkdir('/tmp/thefuck-test')
    os.chdir('/tmp/thefuck-test')

    open('file1.txt', 'w').close()
    open('file2.txt', 'w').close()

    with zipfile.ZipFile('test.zip','w') as archive:
        archive.write('file1.txt')
        archive.write('file2.txt')

    side_effect(0, 0)

    assert os.path.exists('file1.txt')
    assert os.path.exists('file2.txt')

# Generated at 2022-06-12 11:16:22.914332
# Unit test for function side_effect
def test_side_effect():
    # 1st case: it's safe to unzip files
    assert not side_effect(None, None)

    # 2nd case: we need to remove files before unzipping
    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.writestr('unwanted', u'')

    assert side_effect(
        type('', (object,), {'script_parts': ['unzip', 'test.zip']})(),
        type('', (object,), {'script': 'unzip test.zip'})())