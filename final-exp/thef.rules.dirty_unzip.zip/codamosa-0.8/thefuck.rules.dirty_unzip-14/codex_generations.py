

# Generated at 2022-06-12 11:08:17.777761
# Unit test for function side_effect
def test_side_effect():
    os.makedirs('foo')
    open('foo/bar.txt', 'w').close()

    with zipfile.ZipFile('foo.zip', 'w') as archive:
        archive.write('foo/bar.txt')

    with open('foo/bar.txt', 'r') as f:
        assert f.read() == ''

    old_cmd = Command('unzip -f foo.zip', 'asd', False)
    command = Command('unzip -d foo foo.zip', 'asd', False)
    side_effect(old_cmd, command)

    with open('foo/bar.txt', 'r') as f:
        assert f.read() == ''

    shutil.rmtree('foo')
    os.remove('foo.zip')

# Generated at 2022-06-12 11:08:20.952448
# Unit test for function side_effect
def test_side_effect():
    from unittest import TestCase
    from tempfile import mkdtemp
    import shutil

    from .utils import wrap_in_subprocess

    class Test(TestCase):
        def test(self):
            temp_dir = mkdtemp()

# Generated at 2022-06-12 11:08:25.625499
# Unit test for function match
def test_match():
    assert not match(Command('unzip test zip', '', ''))
    assert match(Command('unzip test.zip', '', ''))
    assert not match(Command('unzip test.zip -d test', '', ''))
    assert not match(Command('unzip test.zip -d test/', '', ''))


# Generated at 2022-06-12 11:08:34.481944
# Unit test for function match
def test_match():

    # Arrange
    import tempfile
    import shutil
    import subprocess

    current_dir = os.getcwd()
    tmp_dir = tempfile.mkdtemp()
    zip_file = os.path.join(tmp_dir, 'test.zip')
    in_dir = os.path.join(tmp_dir, 'in')
    out_dir = os.path.join(tmp_dir, 'out')
    archive_file1 = os.path.join(in_dir, 'file1.txt')
    archive_file2 = os.path.join(in_dir, 'file2.txt')
    unarchive_file1 = os.path.join(out_dir, 'file1.txt')
    unarchive_file2 = os.path.join(out_dir, 'file2.txt')

   

# Generated at 2022-06-12 11:08:44.719070
# Unit test for function side_effect
def test_side_effect():
    # Create a test directory
    import tempfile
    import shutil
    
    # Create and use a temp directory to avoid messing around with your files
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)
    # Create a file to unzip
    test_file_path = 'test.txt'
    test_file = open(test_file_path, 'a')
    test_file.write('test\n')
    test_file.close()
    # Zip the file
    test_zip = tempfile.mkstemp(suffix = '.zip')[1]
    zip_file = zipfile.ZipFile(test_zip, 'w')
    zip_file.write(test_file_path)
    zip_file.close()
    # Unzip the file
    os.chdir

# Generated at 2022-06-12 11:08:55.096951
# Unit test for function side_effect
def test_side_effect():
    zipfile_path = os.path.join(os.path.dirname(__file__), 'test.zip')
    file_path = os.path.join(os.path.dirname(__file__), 'test.py')
    with zipfile.ZipFile(zipfile_path, 'r') as archive:
        archive.extractall(os.path.dirname(__file__))
    try:
        assert os.path.isfile(file_path)
        side_effect('unzip test.zip', 'unzip test.zip')
        assert not os.path.isfile(file_path)
    finally:
        os.remove(zipfile_path)
        if os.path.isfile(file_path):
            os.remove(file_path)

# Generated at 2022-06-12 11:08:59.026078
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import shell
    from thefuck.rules.unzip_d import side_effect
    assert side_effect(shell.Script('unzip foo.zip'), shell.Script('unzip foo.zip -d foo')) is None

# Generated at 2022-06-12 11:09:07.505520
# Unit test for function side_effect
def test_side_effect():
    # Create a ZipFile
    with zipfile.ZipFile('foo.zip', 'w') as temp_zip:
        temp_zip.writestr('foo.txt', '')

    # Sanity check that extracting foo.zip will overwrite foo.txt
    assert shell.and_('unzip foo.zip', 'echo $?; test -f foo.txt') == '0\n0\n'

    # Call side_effect on foo.zip
    side_effect(Command('unzip foo.zip', '', ''), Command('unzip -d foo foo.zip', ''))

    # Sanity check that unzip foo.zip will fail after side_effect
    assert shell.and_('unzip foo.zip', 'echo $?; test -f foo.txt') == '1\n1\n'

    # Cleanup foo.zip
   

# Generated at 2022-06-12 11:09:17.008792
# Unit test for function match
def test_match():
  assert match(Command("unzip 'test.zip'", "", "", "", ""), None) == False
  assert match(Command("unzip test.zip", "", "", "", ""), None) == True
  assert match(Command("unzip -d '/home/user' test.zip", "", "", "", ""), None) == False
  assert match(Command("unzip -d '/home/user' '/home/user/test.zip'", "", "", "", ""), None) == True
  assert match(Command("unzip -d '/home/user' '/home/user/test'", "", "", "", ""), None) == True


# Generated at 2022-06-12 11:09:23.561249
# Unit test for function side_effect
def test_side_effect():
    from unittest.mock import call, patch

    with patch('os.path.abspath') as abspath, \
         patch('os.getcwd'), \
         patch('os.remove') as remove, \
         patch('zipfile.ZipFile.namelist', return_value=['file1', 'file2']), \
         patch('zipfile.ZipFile.__init__'):
        abspath.return_value = False

        side_effect(None, '')
        remove.assert_has_calls([call('file1'), call('file2')])

# Generated at 2022-06-12 11:09:30.177677
# Unit test for function match
def test_match():
    assert match(Command('gzip -d arch.zip'))
    assert match(Command('unzip arch.zip'))
    assert not match(Command('unzip -d dir arch.zip'))



# Generated at 2022-06-12 11:09:36.198593
# Unit test for function match
def test_match():
    assert match(Command('unzip material-design-icons-3.0.1.zip'))
    assert match(Command(
        'unzip material-design-icons-3.0.1.zip -d icons')) is False
    assert match(Command('unzip material-design-icons-3.0.1.zip -d /tmp')) is False
    assert match(Command('unzip material-design-icons-3.0.1.zip -d icons icons')) is False



# Generated at 2022-06-12 11:09:46.932527
# Unit test for function match
def test_match():
    assert match(Command('unzip -d foo.zip')) is False
    assert match(Command('unzip foo.zip')) is False
    assert match(Command('unzip bad.zip')) is False

    assert match(Command('unzip foo.zip bar.zip')) is False
    assert match(Command('unzip foo.zip bar.zip baz.zip')) is False
    assert match(Command('unzip foo.zip baz.zip foo.zip')) is False

    assert match(Command('unzip foo.zip foo.txt'))

    assert match(Command('unzip foo.zip foo.txt bar.zip')) is False
    assert match(Command('unzip foo.zip foo.txt bar.zip bar.txt bar.zip')) is False

# Generated at 2022-06-12 11:09:55.681250
# Unit test for function side_effect

# Generated at 2022-06-12 11:10:03.519091
# Unit test for function match
def test_match():
    assert match(Command('unzip', 'unzip *.zip'))
    assert match(Command('unzip', 'unzip -t *.zip'))
    assert match(Command('unzip', 'unzip -l *.zip'))
    assert match(Command('unzip', 'unzip -a test.zip'))
    assert not match(Command('unzip', 'unzip -d test.zip'))
    assert not match(Command('unzip', 'unzip -z'))
    assert not match(Command('unzip', 'zip -unzip'))
    assert not match(Command('unzip', 'foo unzip'))
    assert not match(Command('unzip', 'unzip'))
    assert not match(Command('unzip', 'unzip --help'))

# Generated at 2022-06-12 11:10:13.886514
# Unit test for function match
def test_match():
    assert not match(Command(script='unzip files.zip', stderr='foo'))

    # no file specified
    assert not match(Command(script='unzip', stderr='foo'))

    # file does not exist
    assert not match(Command(script='unzip does_not_exist.zip', stderr='foo'))

    # file does not end with .zip
    assert not match(Command(script='unzip files', stderr='foo'))

    # no second file specified
    assert not match(Command(script='unzip files.zip', stderr='foo'))

    # first file is a directory
    assert not match(Command(script='unzip files.zip directory2', stderr='foo'))

    # second file is a directory

# Generated at 2022-06-12 11:10:18.262937
# Unit test for function side_effect
def test_side_effect():
    # no error if file does not exist
    side_effect(command, command)
    # removes a file
    with open('side_effect_test_file', 'w') as f:
        f.write('file content')
    side_effect(command, command)
    assert not os.path.isfile('side_effect_test_file')

# Generated at 2022-06-12 11:10:29.019416
# Unit test for function match
def test_match():
    with open('unziptest.zip', 'w') as f:
        zipfile.ZipFile(f, 'w').extractall(os.getcwd())
    assert match(Command('unzip unziptest.zip', ''))
    os.remove('unziptest.zip')
    with open('unziptest.zip', 'w') as f:
        zipfile.ZipFile(f, 'w').extractall(os.getcwd())
    assert not match(Command('unzip unziptest.zip -d unziptest', ''))
    os.remove('unziptest.zip')

# Generated at 2022-06-12 11:10:36.266505
# Unit test for function match
def test_match():
    # Tests unzip command
    assert match(Command('unzip some.zip', None)) is False
    assert match(Command('unzip some.zip', None)) is False
    assert match(Command('unzip some.zip -d some', None)) is False
    assert match(Command('unzip some.zip -d some_directory', None)) is False

    # Tests bad zip file
    assert match(Command('unzip some.zip', None)) is True



# Generated at 2022-06-12 11:10:46.841548
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    from thefuck.types import Command

    with tempfile.TemporaryDirectory() as tmp_dir:
        with zipfile.ZipFile(os.path.join(tmp_dir, 'unzip-test.zip'), 'w') as archive:
            archive.writestr('test.txt', 'test')
            archive.writestr('/test.txt', 'test')

        side_effect(Command('unzip unzip-test.zip', ''), '')

        assert os.path.isfile(os.path.join(tmp_dir, 'unzip-test', 'test.txt'))
        assert not os.path.isfile(os.path.join(tmp_dir, 'test.txt'))

        zip_file = os.path.join(tmp_dir, 'zip-test.zip')

# Generated at 2022-06-12 11:10:58.625684
# Unit test for function match
def test_match():
    assert match(Command('unzip helloworld'))
    assert not match(Command('unzip -d helloworld'))
    assert match(Command('unzip helloworld.zip'))
    assert not match(Command('unzip -d helloworld.zip'))

# Generated at 2022-06-12 11:11:08.307467
# Unit test for function match
def test_match():
    assert _is_bad_zip('test-data/unzip-1.zip')
    assert not _is_bad_zip('test-data/unzip-2.zip')
    assert not _is_bad_zip('test-data/unzip-3.zip')
    assert match(Command('unzip test-data/unzip-1.zip', '', no_colors=True))
    assert not match(Command('unzip test-data/unzip-2.zip', '', no_colors=True))
    assert not match(Command('unzip test-data/unzip-3.zip', '', no_colors=True))
    assert not match(Command('unzip -d test-data/ unzip-1.zip', '', no_colors=True))



# Generated at 2022-06-12 11:11:17.453069
# Unit test for function side_effect
def test_side_effect():
    from tempfile import mkdtemp
    from shutil import rmtree
    from thefuck.shells import get_all_executables

    for shell in get_all_executables():
        with shell:
            tmpdir = mkdtemp()
            open(tmpdir + "/text", "w").close()
            script = u'unzip {}/text.zip'.format(tmpdir)
            old_cmd = type('cmd', (object,), {'script': script})
            command = type('cmd', (object,), {'script': script})
            side_effect(old_cmd, command)

# Generated at 2022-06-12 11:11:21.368993
# Unit test for function side_effect
def test_side_effect():
    file = '__test_side_effect.zip'
    with zipfile.ZipFile(file, 'w') as archive:
        archive.writestr('foo.txt', 'bar')
    assert side_effect(None, 'unzip -q {}'.format(file))
    assert not os.path.exists('foo.txt')

# Generated at 2022-06-12 11:11:29.704550
# Unit test for function match
def test_match():
    # unzip bad zip
    assert match(Command('unzip test.zip',
                         stderr='caution: not extracting:  bad file name:  foo'))
    assert match(Command('unzip test.zip',
                         stderr='caution:  foo:  bad file name:'))

    # unzip a file to a dir
    assert not match(Command('unzip test.zip -d out',
                             stderr='caution: not extracting:  bad file name:  foo'))
    assert not match(Command('unzip -d test.out test.zip',
                             stderr='caution: not extracting:  bad file name:  foo'))
    assert not match(Command('unzip test.zip -d out',
                             stderr='error:  foo:  directory not empty:'))

    #

# Generated at 2022-06-12 11:11:39.104044
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 11:11:45.314228
# Unit test for function side_effect
def test_side_effect():
    class OldCommand(object):
        def __init__(self, script):
            self.script = script

    script = u'unzip test_dir.zip'
    old_cmd = OldCommand(script)
    os.makedirs('test_dir')
    file = open('test_dir/content', 'w')
    file.write('delete me please')
    file.close()
    side_effect(old_cmd, 'fucking useless command')
    assert not os.path.exists('test_dir/content')

# Generated at 2022-06-12 11:11:51.109927
# Unit test for function match
def test_match():
    assert match(Command('unzip -j Archive.zip foo.txt')) is False
    assert match(Command('unzip Archive.zip')) is False
    assert match(Command('unzip an_archive_with_two_files.zip')) is True
    assert match(Command('unzip Archive.zip foo/bar.txt')) is False
    assert match(Command('unzip Archive.zip foo/bar.txt -d foobar')) is False



# Generated at 2022-06-12 11:11:57.471493
# Unit test for function match
def test_match():
    # Stage 1
    original_script = 'unzip file.zip'
    script = original_script
    command = Command(script, script)
    zip_file = 'file.zip'
    expected_zip_file = zip_file
    assert _is_bad_zip('file.zip') == False
    assert _zip_file(command) == expected_zip_file

    # Stage 2
    original_script = 'unzip file.zip'
    script = original_script
    command = Command(script, script)
    zip_file = 'file.zip'
    expected_zip_file = zip_file
    assert _is_bad_zip(zip_file) == True
    assert _zip_file(command) == expected_zip_file

# Generated at 2022-06-12 11:12:06.538767
# Unit test for function side_effect
def test_side_effect():
    archive_zip = zipfile.ZipFile('archive.zip', 'w')
    archive_zip.writestr('test.txt', 'hello')
    archive_zip.writestr('dir/file.txt', 'world')
    archive_zip.close()

    os.makedirs('dir')
    open('dir/file.txt', 'w').close()

    side_effect(Command('unzip archive.zip', ''), Command('unzip archive.zip -d archive', ''))
    assert shell.and_('rm archive.zip', 'rm -rf dir') == shell.to_script(Command('unzip', ''))

# Generated at 2022-06-12 11:12:31.598117
# Unit test for function match
def test_match():
    assert match(Command('unzip b.zip', '', '')) == False
    assert match(Command('unzip b.zip', '', '')) == False
    assert match(Command('unzip b', '', '')) == False
    assert match(Command('unzip', '', '')) == False
    assert match(Command('unzip', '', '')) == False
    assert match(Command('unzip', '', '')) == False
    assert match(Command('unzip', '', '')) == False
    assert match(Command('unzip', '', '')) == False
    assert match(Command('unzip', '', '')) == False

# Generated at 2022-06-12 11:12:38.671238
# Unit test for function side_effect
def test_side_effect():
    old_cmd = type('', (object,), {'script': 'unzip -d test.zip'})
    command = u'unzip -d test.zip'
    if not os.path.exists('test.zip'):
        with open('test.zip', 'wb') as f:
            with zipfile.ZipFile(f, 'w') as archive:
                archive.write('test', 'test.txt')
                archive.write('test', 'test.py')
    projects_dir = os.path.dirname(os.path.dirname(__file__))
    test_dir = os.path.join(projects_dir, 'test.txt')
    test_py = os.path.join(projects_dir, 'test.py')
    side_effect(old_cmd, command)
    assert not os.path

# Generated at 2022-06-12 11:12:43.986708
# Unit test for function match
def test_match():
    # unzip foo.zip
    assert match(Command('unzip foo.zip')) is True
    # unzip foo.zip bar.zip other_foo.zip
    assert match(Command('unzip foo.zip bar.zip other_foo.zip')) is True
    # unzip foo.zip -d extract_here
    assert match(Command('unzip foo.zip -d extract_here')) is False



# Generated at 2022-06-12 11:12:52.168693
# Unit test for function match
def test_match():
    p1 = 'unzip c:\\Desktop\\test.zip'
    p2 = 'unzip c:\\Desktop\\test1.zip -d c:\\Desktop\\test2.zip'
    p3 = 'unzip c:\\Desktop\\test1.zip -d c:\\Desktop\\test2.zip -d c:\\Desktop\\test3.zip'
    p4 = 'unzip c:\\Desktop\\test.zip -d c:\\Desktop\\test'
    assert match(shell(p1)) == False
    assert match(shell(p2)) == True
    assert match(shell(p3)) == False
    assert match(shell(p4)) == False


# Generated at 2022-06-12 11:12:55.785355
# Unit test for function match
def test_match():
    assert match(Command('unzip', '', ''))
    assert match(Command('unzip', '', '', '-d', ''))
    assert not match(Command('unarchive', '', ''))
    assert not match(Command('unzip', '', '', '-d', 'dir'))


# Generated at 2022-06-12 11:13:02.726713
# Unit test for function match
def test_match():
    # _is_bad_zip returns false if the zipfile contains more than one element
    # Error message when the zipfile contains more than one element

    # returns true only if the zipfile contains more than one element
    assert match(Command("unzip file.zip")) == False
    # returns false when the zipfile contains only one element
    assert match(Command("unzip -1 file.zip")) == False
    # returns false if its not the unzip command
    command = Command("zip file.zip test.txt")
    assert match(command) == False



# Generated at 2022-06-12 11:13:06.631875
# Unit test for function side_effect
def test_side_effect():
    os.environ['HOME'] = '/home/noone'
    path = os.path.join(os.environ['HOME'], 'file')
    file = open(path, 'w')
    file.close()
    os.makedirs('/home/noone/test')
    os.makedirs(os.path.join(os.environ['HOME'], 'test2'))

# Generated at 2022-06-12 11:13:17.716491
# Unit test for function match
def test_match():
    command = type('cmd', (object,), {'script_parts': ['unzip', 'file.zip'], 'script': 'unzip file.zip'})
    assert not match(command)

    command = type('cmd', (object,), {'script_parts': ['unzip', '-d', 'path', 'file.zip'], 'script': 'unzip -d path file.zip'})
    assert not match(command)

    command = type('cmd', (object,), {'script_parts': ['unzip', 'file.zip', '../path'], 'script': 'unzip file.zip ../path'})
    assert not match(command)


# Generated at 2022-06-12 11:13:21.405946
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Mock(script='unzip file_name.zip', script_parts=['unzip', 'file_name'])
    command = Mock(script='unzip file_name.zip -d dir_name')
    side_effect(old_cmd, command)

# Generated at 2022-06-12 11:13:30.786541
# Unit test for function side_effect
def test_side_effect():
    import os
    import shutil
    import tempfile

    try:
        old_path = os.path.abspath(os.curdir)
        dir = tempfile.mkdtemp()
        os.chdir(dir)

        archive = zipfile.ZipFile(os.path.join(dir, "archive.zip"), 'w')
        archive.writestr('file', 'content')
        archive.close()

        assert os.path.abspath(os.curdir) == dir
        side_effect(zip_file, 'unzip archive.zip')

        # if side_effect worked, file file was removed from dir
        assert not os.path.exists(os.path.join(dir, "file"))
    finally:
        shutil.rmtree(dir)

# Generated at 2022-06-12 11:14:09.308511
# Unit test for function match
def test_match():
    assert match(Command('unzip 1.zip', '', ''))
    assert not match(Command('unzip 1.zip -x', '', ''))
    assert match(Command('unzip -qq 1.zip', '', ''))

# Generated at 2022-06-12 11:14:18.647567
# Unit test for function match
def test_match():
    # checking that unzip without -d is not matched
    assert not match(Command('unzip francesco-mangiacrapa.zip', ''))

    # checking that unzip with -d is not matched
    assert not match(Command('unzip -d francesco-mangiacrapa.zip', ''))

    # checking that with a good zip archive is not matched
    command = Command('unzip francesco-mangiacrapa.zip', '')
    with zipfile.ZipFile(u'{}'.format(_zip_file(command)), 'w') as archive:
        archive.write('test')
    assert not match(command)

    # checking that with a bad zip archive the function will match
    command = Command('unzip francesco-mangiacrapa.zip', '')

# Generated at 2022-06-12 11:14:23.525732
# Unit test for function match
def test_match():
    os.system("touch a.zip")
    os.system("mkdir test")
    os.system("echo '123' > test/a.txt")
    os.system("zip a.zip test/a.txt")

    assert match(Command("unzip a.zip", None))
    assert not match(Command("unzip a.zip -x a.zip", None))
    assert not match(Command("unzip -d test a.zip", None))



# Generated at 2022-06-12 11:14:29.679923
# Unit test for function match
def test_match():
    assert match(Command(script='unzip foo.zip',))
    assert match(Command(script='unzip foo',))
    assert match(Command(script='unzip -q foo',))
    assert match(Command(script='unzip -d foo',))
    assert not match(Command(script='unzip -d bar foo',))
    assert not match(Command(script='unzip -d bar',))
    assert not match(Command(script='unzip -d bar',))
    assert match(Command(script='unzip -P pass -d bar',))



# Generated at 2022-06-12 11:14:36.992184
# Unit test for function match
def test_match():
    assert not match(Command('unzip file.zip'))
    assert not match(Command('unzip file.zip -d . '))
    assert not match(Command('unzip -d . file.zip '))

    archive = '/tmp/pycharm.zip'
    with zipfile.ZipFile(archive, 'w') as zip:
        zip.writestr('foo.txt', 'bar')

    assert not match(Command('unzip {}'.format(archive)))
    assert match(Command('unzip {}'.format(archive)))
    os.remove(archive)



# Generated at 2022-06-12 11:14:46.461741
# Unit test for function side_effect
def test_side_effect():
    os.makedirs('test', 0o755)

    with open('test/file1', 'w') as f:
        f.write('test')

    with open('test/file2', 'w') as f:
        f.write('test')

    with zipfile.ZipFile('test.zip', 'w') as zipfile:
        zipfile.write('test/file1')
        zipfile.write('test/file2')

    c = Command('unzip test.zip test/file1', '', '')
    side_effect(c, 'unzip -d test/ test.zip')

    assert not os.path.isfile('test/file1')
    assert os.path.isfile('test/file2')

    shutil.rmtree('test', ignore_errors=True)

# Generated at 2022-06-12 11:14:54.834105
# Unit test for function side_effect
def test_side_effect():
    from thefuck.main import Rule
    from thefuck.types import Command

    # Create directory tree
    test_dir = 'test_dir'
    sub_dir = os.path.join(test_dir, 'sub_dir')
    os.mkdir(test_dir)
    os.mkdir(sub_dir)
    test_text = 'test'
    text_file = 'file.txt'
    text_file2 = os.path.join(test_dir, 'file.txt')
    text_file3 = os.path.join(sub_dir, 'file.txt')
    with open(text_file, 'w+') as f:
        f.write(test_text)
    with open(text_file2, 'w+') as f:
        f.write(test_text)

# Generated at 2022-06-12 11:14:59.754566
# Unit test for function match
def test_match():
    assert not match(Command('unzip file.zip otherfile.zip aaa.zip bbb.zip', ''))
    assert match(Command('unzip file.zip', ''))
    assert not match(Command('unzip -d aaa file.zip', ''))
    assert match(Command('unzip file', ''))
    assert match(Command('unzip -l file', ''))


# Generated at 2022-06-12 11:15:09.534960
# Unit test for function match
def test_match():
    assert match(Command('unzip -p archive.zip', '')) == False
    assert match(Command('unzip archive.zip', '')) == False
    assert match(Command('unzip -d archive.zip', '')) == False

    with open('archive.zip', 'w') as f:
        with zipfile.ZipFile(f, 'w') as archive:
            archive.write('file1.txt', 'file1.txt')
            archive.write('file2.txt', 'file2.txt')

    assert match(Command('unzip archive.zip', '')) == True
    assert match(Command('unzip file1.txt.zip', '')) == True

    os.remove('archive.zip')



# Generated at 2022-06-12 11:15:20.047134
# Unit test for function side_effect
def test_side_effect():
    tmpdir = os.path.dirname(os.path.realpath(__file__)) + '/test'
    if(os.path.exists(tmpdir)):
        return
    os.mkdir(tmpdir)
    os.mkdir(tmpdir + '/bad_zip')
    with open(tmpdir + '/bad_zip/file_1' , 'w+') as f:
        f.write('demo')
    with open(tmpdir + '/bad_zip/file_2' , 'w+') as f:
        f.write('demo')
    os.mkdir(tmpdir + '/good_zip')
    with open(tmpdir + '/good_zip/file_1' , 'w+') as f:
        f.write('demo')

# Generated at 2022-06-12 11:16:36.982338
# Unit test for function match
def test_match():
    """
    >> match(Command('unzip linux-3.14.zip'))
    True
    >> match(Command('unzip -d linux-3.14 linux-3.14.zip'))
    False
    >> match(Command('unzip --version'))
    False
    >> match(Command('unzip linux-3.14'))
    True
    >> match(Command('unzip -l'))
    False
    >> match(Command('unzip linux-3.14/arch/arm/Kconfig'))
    False
    """


# Generated at 2022-06-12 11:16:45.662505
# Unit test for function match
def test_match():
    assert match(Command(script='unzip fileA.zip file1 file2 file3',
                         stderr='unzip:  cannot find or open fileA.zip, fileA.zip.zip or fileA.zip.ZIP.'))
    assert match(Command(script='unzip fileA.zip.zip file1 file2 file3',
                         stderr='unzip:  cannot find or open fileA.zip.zip, fileA.zip.zip.zip or fileA.zip.zip.ZIP.'))
    assert match(Command(script='unzip fileA.zip.ZIP file1 file2 file3',
                         stderr='unzip:  cannot find or open fileA.zip.ZIP, fileA.zip.ZIP.zip or fileA.zip.ZIP.ZIP.'))

# Generated at 2022-06-12 11:16:53.016983
# Unit test for function match
def test_match():
    assert match(Command('unzip', 'unzip file.zip'))
    assert match(Command('unzip', 'unzip file'))
    assert match(Command('unzip', 'unzip -o file.zip'))
    assert not match(Command('unzip', 'unzip -d folder file.zip'))
    assert not match(Command('unzip', 'unzip -d folder file'))
    assert not match(Command('unzip', 'unzip -d folder -o file.zip'))
    assert not match(Command('unzip', 'unzip -d folder -o file'))


# Generated at 2022-06-12 11:17:02.072520
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command(script='unzip archive',
                      stderr=u'unzip:  cannot find or open main.exe, main.exe.zip or main.exe.ZIP',
                      stdout=u'',
                      script_parts=['unzip', 'archive'])

    new_cmd = Command(script='unzip archive -d mainexe',
                      stderr=u'',
                      stdout=u'',
                      script_parts=['unzip', 'archive', '-d', 'mainexe'])
    side_effect(old_cmd, new_cmd)
    assert not os.path.isfile('main.exe')
    assert os.path.isdir('mainexe')


# Generated at 2022-06-12 11:17:10.546046
# Unit test for function match
def test_match():
    file_name = 'file.zip'
    test_command = unittest.mock.Mock(script='ls -l {}'.format(file_name), stdout='')

    # Assume file is good
    with unittest.mock.patch('zipfile.ZipFile.namelist', return_value=['file.txt']):
        assert not match(test_command)

    # Assume file is bad
    with unittest.mock.patch('zipfile.ZipFile.namelist', return_value=['file.txt', 'file2.txt']):
        assert match(test_command)

    # Assume file is broken
    with unittest.mock.patch('zipfile.ZipFile.namelist', side_effect=RuntimeError):
        assert not match(test_command)

    # Assume the

# Generated at 2022-06-12 11:17:20.570554
# Unit test for function match
def test_match():
    assert not match(Command('unzip file.zip', '', '/usr/bin/unzip'))
    assert not match(Command('unzip -x file.zip', '', '/usr/bin/unzip'))
    assert not match(Command('unzip -x file.zip file.tar test.zip',
                             '', '/usr/bin/unzip'))
    assert match(Command('unzip test.zip', '', '/usr/bin/unzip'))
    assert match(Command('unzip -x test.zip', '', '/usr/bin/unzip'))
    assert match(Command('unzip -x file.tar test.zip', '', '/usr/bin/unzip'))


# Generated at 2022-06-12 11:17:27.935947
# Unit test for function match
def test_match():
    # Test that function match is working
    # with the right command & output
    # and not for wrong command
    assert match(Command('unzip myth.zip',
                         'unzip:  cannot find or open myth.zip, myth.zip.zip or myth.zip.ZIP.'))
    assert match(Command('unzip myth',
                         'unzip:  cannot find or open myth, myth.zip or myth.ZIP.'))
    assert not match(Command('unzip myth.zip -d myth',
                             'Archive:  myth.zip'))
    assert not match(Command('unzip myth -d myth',
                             'Archive:  myth.zip'))



# Generated at 2022-06-12 11:17:38.133022
# Unit test for function side_effect
def test_side_effect():
    os.chdir(os.path.dirname(__file__))
    # Init dir
    os.mkdir('new_dir')
    os.mkdir('dir')
    with open('dir/file.txt', 'w'): pass

    # unzip is not working in test
    command = 'unzip {0}'.format(os.path.abspath('zip_file.zip'))
    with open('zip_file.zip', 'w') as zipf:
        zipf.write('foo')
    side_effect(command, command)

    assert os.path.isfile('zip_file.txt')
    assert os.path.isfile('file.txt')
    assert os.path.isdir('new_dir')

    # Cleaning
    os.remove('file.txt')

# Generated at 2022-06-12 11:17:47.202952
# Unit test for function match
def test_match():
    assert _is_bad_zip('tests/fixtures/bad_zip.zip')
    assert not _is_bad_zip('tests/fixtures/not_a_zip.zip')

    assert match(Command('unzip bad_zip.zip _4.py', ''))
    assert not match(Command('unzip not_a_zip.zip _4.py', ''))

    assert match(Command('unzip -x bad_zip.zip _4.py', ''))
    assert not match(Command('unzip -x not_a_zip.zip _4.py', ''))

    assert not match(Command('unzip -x bad_zip.zip', ''))
    assert not match(Command('unzip -d unzipped.zip', ''))



# Generated at 2022-06-12 11:17:54.348777
# Unit test for function match
def test_match():
    assert match(Command('unzip -l file.zip', '')) == False
    assert match(Command('unzip -l file', '')) == False
    assert match(Command('unzip -d ./ file.zip', '')) == False
    assert match(Command('unzip file2.zip', '')) == False
    assert match(Command('unzip file.zip', ''))
    assert match(Command('unzip file.zip file.txt', ''))
    assert match(Command('unzip file.zip -x file.txt', ''))
    assert match(Command('unzip -l file.zip file.txt', ''))

