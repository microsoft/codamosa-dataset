

# Generated at 2022-06-12 11:08:22.353260
# Unit test for function match
def test_match():
    output=u'Archive:  /home/user/test.zip\r\n  inflating: test.pdf            \r\n  inflating: test.odt           \r\n'
    command = Command('unzip /home/user/test')
    command.script_parts = [u'unzip', u'/home/user/test']
    command.stdout = output
    assert not match(command)

    output=u'Archive:  /home/user/test.zip\r\n  inflating: test.pdf            \r\n  inflating: test.odt           \r\n  inflating: test1.odt          \r\n'
    command = Command('unzip /home/user/test')
    command.script_parts = [u'unzip', u'/home/user/test']

# Generated at 2022-06-12 11:08:32.509065
# Unit test for function side_effect
def test_side_effect():
    from collections import namedtuple

    curdir = os.getcwd()
    dirpath = curdir + '/test_side_effect'

    if not os.path.exists(dirpath):
        os.makedirs(dirpath)

    paths = [dirpath + '/file1', dirpath + '/file2']
    for path in paths:
        open(path, 'a').close()
        assert os.path.exists(path)

    # example command line
    command = namedtuple('Command', ['script', 'script_parts'])
    command.script = 'unzip test_side_effect/zip_file.zip'
    command.script_parts = command.script.split(' ')

    side_effect(command, command)

    for path in paths:
        assert not os.path.exists(path)

# Generated at 2022-06-12 11:08:42.792076
# Unit test for function match
def test_match():
    not_match_bad_zip_with_extract_directory = \
        Command('unzip test.zip -d test_files', '', '')
    not_match_bad_zip_without_extract_directory = \
        Command('unzip test.zip', '', '')
    match_bad_zip = Command('unzip test.zip', '', '')
    not_match_good_zip = Command('unzip test_good.zip', '', '')

    assert not match(not_match_bad_zip_with_extract_directory)
    assert not match(not_match_bad_zip_without_extract_directory)
    assert match_bad_zip(match_bad_zip)
    assert not match(not_match_good_zip)



# Generated at 2022-06-12 11:08:51.105992
# Unit test for function match
def test_match():
    command = "unzip"
    # no param
    assert not match(command)

    # -d param
    command = "unzip -d a.zip"
    assert not match(command)

    # Unzip file doesn't exist
    command = "unzip file_not_exist"
    assert not match(command)
    
    # Unzip file exist
    command = "unzip a.zip"
    # but zip file is good
    assert not match(command)

    # Unzip file exist
    command = "unzip d.zip"
    # but zip file is bad
    assert match(command)

# Generated at 2022-06-12 11:09:02.117102
# Unit test for function side_effect
def test_side_effect():
    import os
    import shutil
    from contextlib import contextmanager
    from tempfile import mkdtemp

    @contextmanager
    def create_file(filename):
        open(filename, 'a').close()
        try:
            yield
        finally:
            os.remove(filename)

    @contextmanager
    def create_directory(name):
        try:
            os.mkdir(name)
        except OSError:
            pass
        try:
            yield
        finally:
            shutil.rmtree(name)

    class Command(object):

        def __init__(self, script):
            self.script = script
            self.script_parts = script.split()

    def create_command(path):
        return Command('unzip -u {}'.format(path))


# Generated at 2022-06-12 11:09:08.627258
# Unit test for function match
def test_match():
    assert match(Command('unzip whatever.zip', '')) is True
    assert match(Command('unzip whatever.zip file', '')) is False
    assert match(Command('unzip file whatever.zip', '')) is False
    assert match(Command('unzip what.zip', '')) is False
    assert match(Command('zip whatever', '')) is False
    assert match(Command('unzip whatever', '')) is False
    assert match(Command('unzip whatever.rar', '')) is False
    assert match(Command('unzip -d . whatever.zip', '')) is False

    assert match(Command('unzip whatever.zip', '')) is True
    assert match(Command('unzip -l whatever.zip', '')) is False
    assert match(Command('unzip whatever.zip ./file.txt', '')) is False

# Generated at 2022-06-12 11:09:19.733587
# Unit test for function side_effect
def test_side_effect():
    mock_os = Mock()
    mock_os.path.abspath.side_effect = lambda x: x
    mock_os.getcwd.return_value = '/test/path'
    mock_os_remove = Mock()
    mock_os.remove = mock_os_remove
    mock_zipfile = Mock()
    mock_zipfile.ZipFile().namelist.return_value = ['file1', 'file2']
    with patch.multiple('thefuck.rules.unzip_to_current_folder',
                        os=mock_os, zipfile=mock_zipfile):
        side_effect(':wq!', ':wq!')
        mock_os_remove.assert_has_calls(
            [call('file1'), call('file2')], any_order=True)

# Generated at 2022-06-12 11:09:27.016974
# Unit test for function side_effect
def test_side_effect():
    _dir = 'dir'
    _subdir = os.path.join(_dir, 'subdir')
    _file = os.path.join(_subdir, 'file')

    try:
        os.mkdir(_dir)
        os.mkdir(_subdir)
        with open(_file, 'w'):
            pass
        exit_code = 0
    except OSError:
        exit_code = -1

    assert exit_code == 0
    side_effect(None, None)
    assert not os.path.isdir(_dir)
    assert not os.path.isdir(_subdir)
    assert not os.path.isfile(_file)

# Generated at 2022-06-12 11:09:30.458284
# Unit test for function match
def test_match():
    assert not match(Command(script='unzip file.zip *'))
    assert not match(Command(script='unzip file.zip file2.zip'))
    assert match(Command(script='unzip -d file.zip *')) #fails at the moment
    assert match(Command(script='unzip -d file.zip file2.zip'))
    assert match(Command(script='unzip file file2.zip'))


# Generated at 2022-06-12 11:09:40.254552
# Unit test for function side_effect
def test_side_effect():
    assert os.path.isdir('test_directory') == False
    os.makedirs('test_directory/test_directory2')
    assert os.path.isdir('test_directory/test_directory2') == True
    open('test_directory/test_directory2/test_file.txt', 'w')
    assert os.path.isfile('test_directory/test_directory2/test_file.txt') == True
    side_effect(None, None)
    assert os.path.isdir('test_directory') == False
    assert os.path.isfile('test_directory/test_directory2/test_file.txt') == False
    os.rmdir('test_directory/test_directory2')
    assert os.path.isdir('test_directory/test_directory2') == False
    os.rmd

# Generated at 2022-06-12 11:09:51.170536
# Unit test for function match
def test_match():
    assert match(Command('unzip a.zip', ''))
    assert not match(Command('unzip -d a.zip', ''))
    assert not match(Command('unzip -d a.zip', ''))
    assert not match(Command('unzip -d a.zip', ''))
    assert not match(Command('unzip -d b.zip', ''))
    assert match(Command('unzip ab.zip', ''))
    assert match(Command('unzip a/b.zip', ''))
    assert match(Command('unzip a\\b.zip', ''))



# Generated at 2022-06-12 11:09:59.855881
# Unit test for function match
def test_match():
    assert match(Command(script='unzip file.zip', stdout='', stderr=''))
    assert match(Command(script='unzip file', stdout='', stderr=''))
    assert not match(Command(script='unzip -d file.zip', stdout='', stderr=''))
    assert not match(Command(script='unzip file.zip dir', stdout='', stderr=''))
    assert not match(Command(script='unzip file.zip -x file', stdout='', stderr=''))
    assert not match(Command(script='unzip', stdout='', stderr=''))
    assert not match(Command(script='unzip -d', stdout='', stderr=''))

# Generated at 2022-06-12 11:10:01.049846
# Unit test for function match
def test_match():
    assert not match(Command('unzip -d test.zip', ''))
    assert match(Command('unzip not_test.zip', ''))


# Generated at 2022-06-12 11:10:08.432417
# Unit test for function side_effect
def test_side_effect():
    with zipfile.ZipFile('test.zip', 'w') as myzip:
        myzip.writestr('test1', 'test1')
        myzip.writestr('test2', 'test2')
        myzip.writestr('test3', 'test3')

    side_effect('unzip test.zip', 'unzip test.zip')

    assert os.path.exists('test1')
    assert os.path.exists('test2')
    assert os.path.exists('test3')

    os.remove('test1')
    os.remove('test2')
    os.remove('test3')

# Generated at 2022-06-12 11:10:16.863831
# Unit test for function side_effect
def test_side_effect():
    """
    Test whether the side effect works correctly
    """
    import tempfile
    import shutil
    from thefuck.shells import shell

    def script_parts(cmd):
        """
        Return list of script parts (simulated version of command.script_parts)
        """
        return cmd.split(' ')

    test_dir = tempfile.mkdtemp()


# Generated at 2022-06-12 11:10:27.590002
# Unit test for function side_effect
def test_side_effect():
    dir_name = mkdtemp()

# Generated at 2022-06-12 11:10:38.096802
# Unit test for function match
def test_match():

    # The command output is:
    # unzip:  cannot find or open badzip.zip, badzip.zip.zip or badzip.zip.ZIP.
    # 1 error
    command = Command('unzip badzip.zip', '', '', 1, None, None)
    assert match(command)

    # The command output is:
    # unzip:  cannot find or open goodzip.zip, goodzip.zip.zip or goodzip.zip.ZIP.
    # 1 error
    command = Command('unzip goodzip.zip', '', '', 1, None, None)
    assert match(command) is False

    # The command output is:
    # unzip:  cannot find or open nozip.zip, nozip.zip.zip or nozip.zip.ZIP.
    # 1 error

# Generated at 2022-06-12 11:10:40.942407
# Unit test for function side_effect
def test_side_effect():
    with tempfile.NamedTemporaryFile() as tmp:
        with zipfile.ZipFile(tmp.name, 'w') as myzip:
            myzip.write('foo.txt')

# Generated at 2022-06-12 11:10:50.931350
# Unit test for function match
def test_match():
    assert match(Command('unzip foo.zip', ''))
    assert not match(Command('unzip foo.zip', '',
                        stderr='unzip:  cannot find or open foo.zip'))
    assert match(Command('unzip foo', ''))
    assert match(Command('unzip -l foo.zip', ''))
    assert not match(Command('unzip -d foo.zip', ''))
    assert match(Command('unzip -d foo', ''))
    assert match(Command('unzip -d foo', '',
                        stderr='unzip:  -d: No such file or directory'))
    assert not match(Command('unzip -x foo', ''))
    assert not match(Command('unzip -d -x foo', ''))

# Generated at 2022-06-12 11:10:57.482695
# Unit test for function match
def test_match():
    assert(match(Command('/usr/bin/unzip /home/user/a.zip',
                         '/home/user/a.zip')) == True)

    assert(match(Command('/usr/bin/unzip /home/user/d.zip',
                         '/home/user/d.zip')) == False)

    assert(match(Command('unzip a.zip', 'a.zip')) == True)
    assert(match(Command('unzip a.zip', 'a.zip')) == True)
    assert(match(Command('unzip b.zip', 'b.zip')) == False)
    assert(match(Command('unzip c.zip', 'c.zip')) == True)

    assert(match(Command('unzip a.zip a', 'a.zip')) == False)

# Generated at 2022-06-12 11:11:16.473014
# Unit test for function match
def test_match():
    # Should return true if unzip fails
    command = Command('unzip file.zip', '', '', 123, '', '')
    assert match(command)

    # Should return false if unzip succeeds
    command = Command('unzip file.zip', '', '', 0, '', '')
    assert not match(command)

    # Should return false if unzip is not the command
    command = Command('foo file.zip', '', '', 123, '', '')
    assert not match(command)

    # Should return false if unzip from bad zip file succeeds with -d flag
    with zipfile.ZipFile('file.zip', 'w') as archive:
        archive.write('file.txt')


# Generated at 2022-06-12 11:11:25.439259
# Unit test for function match
def test_match():
    import pytest

    assert not match(Command('unzip archive.zip', '', '', '', None, None))
    assert match(Command('unzip archive.zip file', '', '', '', None, None))
    assert match(Command('unzip archive.zip file1 file2', '', '', '', None,
        None))
    assert not match(Command('unzip archive.zip file1 file2 -d dir', '', '',
        '', None, None))
    assert not match(Command('unzip archive.zip file1 file2 -t dir', '', '',
        '', None, None))
    assert not match(Command('unzip archive.zip file1 -tld dir', '', '', '',
        None, None))

# Generated at 2022-06-12 11:11:27.008940
# Unit test for function side_effect
def test_side_effect():
    assert side_effect(u'unzip hello.zip', u'unzip hello.zip -d hello')

# Generated at 2022-06-12 11:11:28.615743
# Unit test for function side_effect
def test_side_effect():
    assert not side_effect(zip_file, command)

# Generated at 2022-06-12 11:11:32.455963
# Unit test for function match
def test_match():
    # unzip test.zip -d test/
    assert not match(Command('unzip test.zip -d test/', ''))
    # unzip test.zip
    assert match(Command('unzip test.zip', ''))
    # unzip test
    assert match(Command('unzip test', ''))


# Generated at 2022-06-12 11:11:37.654236
# Unit test for function match
def test_match():
    from tests.utils import Command

    assert match(Command('unzip file.zip', stderr=''))
    assert not match(Command('unzip file.zip -d directory', stderr=''))
    assert not match(Command('unzip file2.zip', stderr=''))
    assert not match(Command('unzip', stderr=''))


# Generated at 2022-06-12 11:11:43.144274
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert match(Command('unzip file.zip one.txt two.txt', ''))
    assert match(Command('unzip file.zip one.txt two.txt', ''))
    assert not match(Command('unzip file.zip one.txt two.txt -d dest', ''))
    assert not match(Command('unzip -d dest file.zip one.txt two.txt', ''))



# Generated at 2022-06-12 11:11:47.106824
# Unit test for function match
def test_match():
    assert match(Command(script="unzip zip_file.zip",
                         stdout="Archive:  zip_file.zip\n  inflating: foo.txt                \n  inflating: bar.txt                \n",
                         stderr=""))


# Generated at 2022-06-12 11:11:55.292788
# Unit test for function match
def test_match():
    assert not match(Command('dupa.zip', 'unzip'))
    assert not match(Command('dupa.zip', 'unzip -d'))
    assert not match(Command('unzip', 'unzip'))
    assert match(Command('dupa', 'unzip'))
    assert match(Command('dupa.zip', 'unzip dupa.zip'))
    assert match(Command('unzip dupa', 'unzip dupa'))
    assert match(Command('unzip dupa.zip', 'unzip dupa.zip'))
    assert match(Command('unzip dupa.zip dupa dupa2', 'unzip dupa.zip dupa dupa2'))
    assert match(Command('unzip -l dupa.zip', 'unzip -l dupa.zip'))

# Generated at 2022-06-12 11:12:04.913783
# Unit test for function side_effect
def test_side_effect():
    fname = '/tmp/hello/testing.zip'
    with zipfile.ZipFile(fname, 'w') as archive:
        archive.writestr('hello.txt', 'hello')
        archive.writestr('testing.txt', 'testing')
    c = Command('unzip testing.zip hello.txt testing.txt', '', '')
    side_effect(c, c)

    assert os.listdir('/tmp/hello') == ['hello.txt', 'testing.txt']
    os.remove('/tmp/hello/hello.txt')
    os.remove('/tmp/hello/testing.txt')
    os.removedirs('/tmp/hello')
    os.remove(fname)

# Generated at 2022-06-12 11:12:33.922338
# Unit test for function side_effect
def test_side_effect():
    files = ['a.txt', 'b.txt', 'c/d.txt', 'e.txt']
    tmp_dir = tempfile.gettempdir()
    # create 3 files and one directory (not empty)
    for name in files:
        if not os.path.exists(name):
            if not os.path.isdir(os.path.dirname(name)):
                os.makedirs(os.path.dirname(name))
            open(name, 'w').close()
    # create zip archive (make sure it will be removed even if side effect failed)

# Generated at 2022-06-12 11:12:35.648702
# Unit test for function match
def test_match():
    assert match(Command('unzip', 'unzip file.zip'))



# Generated at 2022-06-12 11:12:38.789283
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip'))
    assert match(Command('unzip test'))
    assert not match(Command('unzip -d test test.zip'))



# Generated at 2022-06-12 11:12:45.900848
# Unit test for function match
def test_match():
    # An unzip command with a path to a file where the unzip command will
    # extract the content of the file into the current directory
    assert(match(Command('unzip filename.zip', '')))
    # An unzip command with a path to a file where the unzip command will
    # extract the content of the file into a specific directory
    assert(not match(Command('unzip filename.zip -d folder1', '')))
    # An unzip command that does not have a path to a file
    assert(not match(Command('unzip -l', '')))

# Generated at 2022-06-12 11:12:55.063153
# Unit test for function match
def test_match():
    assert match(Command(script='unzip zip_with_multiple_files.zip file1',
                         stderr="unzip:  cannot find or open file1, file1.zip or file1.ZIP."))
    assert not match(Command(script='unzip zip_with_multiple_files.zip file1',
                         stderr="unzip:  cannot find or open file1, file1.zip or file1.ZIP.",
                         stdout="Archive:  zip_with_multiple_files.zip\n  inflating: file1"))
    assert not match(Command(script='unzip zip_with_multiple_files.zip -d /tmp',
                         stderr="unzip:  cannot find or open file1, file1.zip or file1.ZIP."))

# Generated at 2022-06-12 11:13:04.839610
# Unit test for function side_effect
def test_side_effect():
    
    #Setup fake zip file and folder
    old_cmd = 'unzip wibble.zip'
    tmpdir = '/tmp/test_side_effect'
    if os.path.isdir(tmpdir):
        os.system('rm -rf %s' % tmpdir)
    os.makedirs(tmpdir)
    os.chdir(tmpdir)
    os.system('mkdir wibble')
    os.system('touch wibble/wib1')
    os.system('touch wibble/wib2')
    os.system('touch wibble/wib3')
    os.system('touch not_in_zip')
    os.system('cd %s; zip -r wibble.zip wibble' % tmpdir)
    
    #Set up command and run side_effect

# Generated at 2022-06-12 11:13:10.095494
# Unit test for function match
def test_match():
    script = Command('unzip file.zip', '', stderr='')
    assert match(script) is False

    script = Command('unzip file.zip', '', stderr='error')
    assert match(script) is True

    script = Command('unzip -d dir file.zip', '', stderr='error')
    assert match(script) is False



# Generated at 2022-06-12 11:13:20.068246
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import get_shell

    mock_shell = get_shell('bash')
    side_effect(
        mock_shell.and_write_output(
            'unzip source.zip\n'),
        mock_shell.and_write_output(
            'unzip source.zip -d source\n'))
    assert mock_shell.output == 'unzip source.zip -d source\n'
    assert mock_shell.script == ['unzip source.zip -d source']
    assert os.path.isfile('hello')
    assert os.path.isdir('source')
    assert not os.path.isfile('source/hello')
    os.remove('hello')
    os.rmdir('source')

# Generated at 2022-06-12 11:13:24.840883
# Unit test for function match
def test_match():
    # match if single file extracted
    assert match(Command('unzip file.zip', '', ''))
    # match if multiple files extracted
    assert match(Command('unzip file.zip file2.zip', '', ''))
    # match if `-d` argument given
    assert match(Command('unzip -d file.zip', '', ''))
    # don't match if multiple files extracted, but none with a zip extension
    assert not match(Command('unzip file file2', '', ''))
    # don't match if unzip not called
    assert not match(Command('gzip file.zip', '', ''))

# Generated at 2022-06-12 11:13:31.137182
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '', '')) == False
    assert match(Command('unzip file.zip -d destination', '', '')) == False
    assert match(Command('unzip file.zip file1 file2', '', '')) == False
    assert match(Command('unzip file.zip file1 file2 file3', '', '')) == True
    assert match(Command('unzip file1 file2 file3', '', '')) == True
    assert match(Command('unzip file1', '', '')) == False


# Generated at 2022-06-12 11:14:10.967608
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command('unzip -u file.zip')
    command = Command('unzip file.zip')
    side_effect(old_cmd, command)
    
    assert os.path.exists('file')
    
    # Cleanup
    os.remove('file')

# Generated at 2022-06-12 11:14:19.900715
# Unit test for function side_effect
def test_side_effect():
    from tempfile import mkdtemp, mkstemp
    from thefuck.types import Command

    with mkdtemp() as tmpdir:
        # make a zip file
        tmp_zip = os.path.join(tmpdir, 'temp.zip')
        with zipfile.ZipFile(tmp_zip, 'w') as archive:
            # add file and directory
            _, tmp_file = mkstemp(dir=tmpdir)
            os.mkdir(os.path.join(tmpdir, 'temp_dir'))
            archive.write(tmp_file)
            archive.write(os.path.join(tmpdir, 'temp_dir'))

        # make sure the side effect works

# Generated at 2022-06-12 11:14:27.491280
# Unit test for function side_effect
def test_side_effect():
    import os
    import zipfile

    # Create test archive
    zip_file = "test.zip"
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.write("test_folder/test_file")

    # Create test files
    os.makedirs("test_folder")
    test_file = open("test_file", "w+")
    test_file.close()

    command = Command("unzip test.zip")
    side_effect(command, command)

    # Test files were removed
    assert not os.path.isfile("test_file")
    assert not os.path.isdir("test_folder")

    # Clean up
    os.remove(zip_file)

# Generated at 2022-06-12 11:14:37.078336
# Unit test for function side_effect
def test_side_effect():
    my_zip_file = 'test_zip_file.zip'
    with zipfile.ZipFile(my_zip_file, 'w') as archive:
        archive.write(_zip_file.__code__.co_filename)
    os.mkdir('test_directory')
    os.mkdir('test_zip_file')

# Generated at 2022-06-12 11:14:45.904233
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    cwd = tempfile.mkdtemp()
    zip_file = tempfile.NamedTemporaryFile(dir=cwd, suffix='.zip')
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.writestr('file.txt', 'file')
    side_effect(
        type('Command', (object,), {'script_parts': ['/bin/unzip', zip_file.name]})(),
        type('Command', (object,), {'script': '/bin/unzip'}))
    assert not os.path.isfile(os.path.join(cwd, 'file.txt'))
    shutil.rmtree(cwd)

# Generated at 2022-06-12 11:14:52.622976
# Unit test for function match
def test_match():
    # unzip argument
    bad_zip = _zip_file('unzip badzip.zip')
    assert bad_zip == 'badzip.zip'

    # unzip '-' argument
    bad_zip = _zip_file("unzip '-'")
    assert bad_zip is None

    # unzip '.' argument
    bad_zip = _zip_file("unzip '.'")
    assert bad_zip is None

    # unzip 'file'
    bad_zip = _zip_file("unzip 'file'")
    assert bad_zip == 'file.zip'

    # unzip '-h'
    bad_zip = _zip_file("unzip '-h'")
    assert bad_zip is None

    # unzip '-h' file

# Generated at 2022-06-12 11:15:03.657727
# Unit test for function match
def test_match():
    # testing with a bad zip file
    assert match(Command('unzip some_file.zip', '', ''))
    assert match(Command('unzip some_file.zip', '', ''))
    assert match(Command('unzip some_file', '', ''))
    # testing with a good zip file
    test_file = tempfile.NamedTemporaryFile()
    with zipfile.ZipFile(test_file.name, 'w') as zip_file:
        zip_file.writestr('file.txt', '')
    assert not match(Command('unzip {}'.format(test_file.name), '', ''))
    test_file.close()
    # test with a zip file that doesn't exist
    assert not match(Command('unzip doesnt_exist.zip', '', ''))



# Generated at 2022-06-12 11:15:10.655313
# Unit test for function match
def test_match():
    """Test a correct command"""
    assert match(Command('unzip a.zip'))

    """Test a correct command with a flag"""
    assert match(Command('unzip -l a.zip'))

    """Test a correct command with no .zip extension"""
    assert match(Command('unzip a'))

    """Test an incorrect command"""
    assert not match(Command('unzip a.zip -d foo'))

    """Test an incorrect command with a flag"""
    assert not match(Command('unzip -l a.zip -d foo'))

    """Test an incorrect command with no .zip extension"""
    assert not match(Command('unzip a -d foo'))



# Generated at 2022-06-12 11:15:21.382179
# Unit test for function match
def test_match():
    zip_file = "test.zip"
    command = "unzip " + zip_file
    assert match(shell.and_(command, shell.has_file(zip_file)))
    assert match(shell.and_(command, shell.file_is_bad_zip(zip_file)))
    assert not match(shell.and_(command, shell.file_is_bad_zip(zip_file), shell.with_argument('-d')))
    assert not match(shell.and_(command, shell.file_is_bad_zip(zip_file), shell.with_argument('-o')))
    assert not match(shell.and_(command, shell.file_is_bad_zip(zip_file), shell.with_argument('-u')))

# Generated at 2022-06-12 11:15:27.568791
# Unit test for function side_effect
def test_side_effect():
    # zipped file contain a file and a directory
    with zipfile.ZipFile("test.zip", "w") as zip_file:
        zip_file.writestr("delete.txt", "delete")
        zip_file.writestr("delete/", "delete")

    for_app("unzip")[0].side_effect("unzip test.zip", "unzip -d test test.zip")

    assert os.path.isfile("delete.txt")
    assert os.path.isdir("delete")
    assert os.listdir("delete") == []

    os.remove("delete.txt")
    os.rmdir("delete")

# Generated at 2022-06-12 11:16:50.612629
# Unit test for function side_effect
def test_side_effect():
    import os
    import os.path
    import tempfile
    import zipfile
    test_dir = tempfile.mkdtemp()
    assert os.path.exists(test_dir)
    os.chdir(test_dir)

    test_file = os.path.join(test_dir, "test_file.txt")
    open(test_file, 'a').close()
    assert os.path.exists(test_file)

    zip = zipfile.ZipFile("test_dir.zip", 'w')
    zip.write("test_file.txt")
    zip.close()

    class old_cmd:
        def __init__(self):
            self.script = "unzip -d . test_dir.zip"
            self.script_parts = self.script.split(' ')
    old_cmd

# Generated at 2022-06-12 11:16:59.805976
# Unit test for function match
def test_match():
    from thefuck.rules.unzip import match

    command = 'unzip /no/such/file.zip'
    assert match(command)

    command = 'unzip /no/such/file.txt'
    assert match(command)

    command = 'unzip /no/such/file'
    assert match(command)

    command = 'unzip /no/such/file.zip -d ./'
    assert not match(command)

    command = 'unzip /no/such/file error'
    assert not match(command)

    command = 'unzip /no/such/file.txt error'
    assert not match(command)

    command = 'unzip /no/such/file error'
    assert not match(command)



# Generated at 2022-06-12 11:17:07.406663
# Unit test for function side_effect
def test_side_effect():
    with zipfile.ZipFile('/tmp/test.zip', 'w') as archive:
        archive.write(__file__)

    test_command = Command('unzip -l /tmp/test.zip', '/tmp')
    os.chdir('/tmp')

    if not os.path.exists('unzip.py'):
        open('unzip.py', 'a').close()

    side_effect(test_command, Command('unzip /tmp/test.zip', '/tmp'))

    assert os.path.exists('unzip.py')

    os.remove('unzip.py')

# Generated at 2022-06-12 11:17:17.837231
# Unit test for function side_effect
def test_side_effect():
    """
    Given a command,
    and a directory with files in it,
    and a .zip file in the directory,
    and a file in the .zip file
    When side_effect is run,
    Then the file in the .zip file is removed from the directory
    """
    from thefuck import main

    import os
    import shutil
    import sys
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        zipfile_path = os.path.join(tmpdir, 'path/to/zipfile.zip')
        os.makedirs(os.path.join(tmpdir, 'path', 'to'))
        zipfile_file = os.path.join(zipfile_path, 'file.txt')
        open(zipfile_file, 'a').close()

# Generated at 2022-06-12 11:17:26.595220
# Unit test for function side_effect
def test_side_effect():
    test_zip_path = os.path.join(os.path.dirname(__file__),
                                 'test_data', 'test.zip')
    test_path = os.path.join(os.path.dirname(__file__),
                             'test_data')
    test_command = "unzip {}".format(test_zip_path)
    test_zip = _zip_file(Command(script=test_command))
    side_effect(Command(script=test_command),
                Command(script=test_command))
    assert not os.path.isfile(os.path.join(test_path, 'test1.txt'))
    assert not os.path.isfile(os.path.join(test_path, 'test2.txt'))

# Generated at 2022-06-12 11:17:29.441077
# Unit test for function match
def test_match():
    test_script1 = "unzip test.zip"
    test_script2 = "unzip test1.zip"
    assert not match(Command(script=test_script1))
    assert match(Command(script=test_script2))


# Generated at 2022-06-12 11:17:36.251432
# Unit test for function match
def test_match():
    assert match(Command('unzip a.zip', ''))
    assert match(Command('unzip a.zip b.zip', ''))
    assert match(Command('unzip a.tar.gz', ''))
    assert not match(Command('unzip -d a.zip', ''))
    assert not match(Command('unzip -j a.zip', ''))
    assert not match(Command('tar xzf a.tar.gz', ''))
    assert not match(Command('tar xzf', ''))


# Generated at 2022-06-12 11:17:37.817459
# Unit test for function match
def test_match():
    command = "unzip /home/roger/test/test.zip"
    assert match(command) is True


# Generated at 2022-06-12 11:17:40.159711
# Unit test for function side_effect
def test_side_effect():
    old_cmd = 'unzip test.zip'
    command = 'unzip test.zip -d test'
    side_effect(old_cmd, command)
    assert os.path.exists('test/test')

# Generated at 2022-06-12 11:17:42.752825
# Unit test for function side_effect
def test_side_effect():
    from thefuck.tests.utils import Command

    cmd = Command(script=u'unzip test.zip', stdout='', stderr='')
    side_effect(cmd, cmd)