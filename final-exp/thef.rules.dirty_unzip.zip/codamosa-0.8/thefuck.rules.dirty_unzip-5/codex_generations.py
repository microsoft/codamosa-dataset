

# Generated at 2022-06-12 11:08:22.914984
# Unit test for function side_effect
def test_side_effect():
    # test if side_effect removes a file
    filename = 'test.py'
    open(filename, 'w').close()
    cmd = Command('unzip -t test.zip', '', '')
    side_effect(cmd, cmd)
    assert not os.path.exists(filename)

    # test if side_effect does not remove a directory
    os.makedirs('test')
    cmd = Command('unzip -t test.zip', '', '')
    side_effect(cmd, cmd)
    assert os.path.exists('test')

    # test if side_effect does not remove a file outside of the current directory
    os.chdir('/')
    filename = os.path.join(os.getcwd(), 'test.py')
    open(filename, 'w').close()

# Generated at 2022-06-12 11:08:25.269839
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', ''))
    assert not match(Command('unzip test.zip -d test', ''))



# Generated at 2022-06-12 11:08:34.280232
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    from thefuck.rules.unzip import side_effect

# Generated at 2022-06-12 11:08:44.483673
# Unit test for function side_effect
def test_side_effect():
    from thefuck.conf import settings
    from thefuck.types import Command

    script=Command(script='unzip test.zip',
                   stderr=('unzip:  cannot find or open test.zip, '
                           'test.zip.zip or test.zip.ZIP.'))
    settings.no_colours = True

    side_effect(script,
                Command(script='unzip -d test test.zip'))

    with open('test', 'r') as myfile:
        contents = myfile.read()

    assert contents == 'test.zip contents'

    script = Command(script='unzip -n file.zip',
                     stderr=('unzip:  cannot find or open file.zip, '
                             'file.zip.zip or file.zip.ZIP.'))

# Generated at 2022-06-12 11:08:50.499029
# Unit test for function match
def test_match():
    assert not match(Command(script='unzip file.zip -d Dest_dir',
                             stderr='command not found: unzip'))
    assert match(Command(script='unzip file.zip',
                         stderr='error:  expected a single file name'))
    assert not match(Command(script='unzip file.zip -d Dest_dir',
                             stderr=''))



# Generated at 2022-06-12 11:09:01.068787
# Unit test for function side_effect
def test_side_effect():
    import os
    import shutil
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        t = os.path.join(tmpdir, 'test')
        os.mkdir(t)
        s = os.path.join(tmpdir, 'sub')
        os.mkdir(s)
        test_file = os.path.join(t, 'f')
        with open(test_file, 'w') as f:
            f.write('Hello\n')
        sub_file = os.path.join(s, 'g')
        with open(sub_file, 'w') as f:
            f.write('Hello\n')
        shutil.make_archive(os.path.join(tmpdir, 'test'), 'zip', tmpdir)

# Generated at 2022-06-12 11:09:05.559812
# Unit test for function match
def test_match():
    zip_file = "file.zip"
    out = open(zip_file, 'w')
    out.close()

    command = MagicMock()
    command.script_parts = ["unzip", zip_file]
    command.script = "unzip {}".format(zip_file)
    assert (match(command))

    os.remove(zip_file)

# Generated at 2022-06-12 11:09:08.683192
# Unit test for function match
def test_match():
	assert not match(Command('unzip -d folder.zip', '', None))
	assert match(Command('unzip folder.zip', '', None))
	assert not match(Command('unzip folder.zip', 'Error:  not a valid zip file', None))


# Generated at 2022-06-12 11:09:18.781141
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip')) == True
    assert match(Command('unzip file.zip file2.zip')) == True
    assert match(Command('unzip -d unzipped_file.zip')) == False
    assert match(Command('unzip -d unzipped_file file.zip')) == False
    assert match(Command('unzip file')) == True
    assert match(Command('unzip -d unzipped_file file')) == False
    assert match(Command('unzip file_without_extension.zip')) == True
    assert match(Command('unzip -d unzipped_file file_without_extension')) == False
    assert match(Command('')) == False


# Generated at 2022-06-12 11:09:23.361366
# Unit test for function match
def test_match():
    command = Command('unzip not_a.zip')
    assert not match(command)

    command = Command('unzip a.zip')
    assert match(command)

    command = Command('unzip -l a.zip')
    assert not match(command)

    command = Command('unzip -d foo a.zip')
    assert not match(command)

    command = Command('unzip a.zip b.txt c.txt')
    assert match(command)



# Generated at 2022-06-12 11:09:37.543719
# Unit test for function side_effect
def test_side_effect():
    os.mkdir('test_side_effect')
    test_zipfile = open('test_side_effect.zip', 'w')
    zip_archive = zipfile.ZipFile(test_zipfile, 'w')
    zip_archive.write('thefuck/test_data/test_file1.txt', 'test_file1.txt')
    zip_archive.write('thefuck/test_data/test_file2.txt', 'test_file2.txt')
    zip_archive.close()
    test_zipfile.close()
    side_effect('unzip test_side_effect.zip', 'unzip test_side_effect.zip')
    for _file in os.listdir(os.getcwd()):
        assert _file == 'test_side_effect.zip'

# Generated at 2022-06-12 11:09:44.785560
# Unit test for function side_effect
def test_side_effect():
    import mock
    from os import path
    from thefuck import shells
    from thefuck.types import Command

    script = Command("unzip test.zip")
    old_cmd = Command("unzip test.zip")

    side_effect(old_cmd, script)

    assert mock.call(path.abspath("test")) in mock.call.remove.call_args_list
    assert mock.call(shells.and_("rm", "-rf", path.abspath("test"))) not in mock.call.remove.call_args_list

# Generated at 2022-06-12 11:09:51.630656
# Unit test for function match
def test_match():
    assert not match(Command('ls', 'unzip -d'))
    assert match(Command('unzip', 'unzip'))
    assert match(Command('unzip', 'unzip my.zip'))
    assert match(Command('unzip', 'unzip my'))
    assert match(Command('unzip', 'unzip my.zip foo'))
    assert not match(Command('unzip', 'unzip -x my.zip'))
    assert not match(Command('unzip', 'unzip -x my'))
    assert not match(Command('unzip', 'unzip -x my.zip foo'))


# Generated at 2022-06-12 11:09:56.184344
# Unit test for function match
def test_match():
    assert not match(Command('unzip file.zip', ''))
    assert match(Command('unzip file.zip dir/', ''))
    assert match(Command('unzip -u file.zip', ''))
    assert match(Command('unzip -l file.zip', ''))
    assert match(Command('unzip -v file.zip', ''))
    assert match(Command('unzip -Z file.zip', ''))
    assert match(Command('unzip -t file.zip', ''))
    assert match(Command('unzip -L file.zip', ''))
    assert match(Command('unzip -d file.zip', ''))

# Generated at 2022-06-12 11:10:03.909659
# Unit test for function side_effect
def test_side_effect():
    with tempfile.TemporaryDirectory() as folder:
        zip_file = os.path.join(folder, "subfolder.zip")
        subfolder = os.path.join(folder, "subfolder")
        os.mkdir(subfolder)
        file_subfolder = os.path.join(subfolder, "subfile")

        archive = zipfile.ZipFile(zip_file, mode="w")
        archive.write(file_subfolder)
        archive.close()

        old_cmd = Command(script='unzip {}'.format(zip_file))
        command = get_new_command(old_cmd)
        side_effect(old_cmd, command)

        assert [f for f in os.listdir(subfolder)] == []

# Generated at 2022-06-12 11:10:09.300788
# Unit test for function side_effect
def test_side_effect():
    old_cmd = FakeCommand(script='unzip jquery-3.1.1.zip')
    command = FakeCommand(script=get_new_command(old_cmd))

    side_effect(old_cmd, command)

    assert os.path.exists('jquery-3.1.1')

    # Clean
    os.remove('jquery-3.1.1')



# Generated at 2022-06-12 11:10:17.329313
# Unit test for function side_effect
def test_side_effect():
    import mock
    import io
    from tempfile import TemporaryDirectory

    def mock_zipfile(archive):
        archived_file = io.BytesIO(b'file content')
        archived_file.name = 'archived file'

        def isdir(path):
            return path == 'dir'

        m = mock.MagicMock()
        m.namelist.return_value = ['dir', 'file']
        m.open.side_effect = [io.BytesIO(), archived_file]
        m.testzip.return_value = None
        m.isdir.side_effect = isdir

        return m

    with TemporaryDirectory() as d:
        os.mkdir(os.path.join(d, 'dir'))
        open(os.path.join(d, 'file'), 'w').close()


# Generated at 2022-06-12 11:10:28.039861
# Unit test for function side_effect
def test_side_effect():
    from tests.utils import Command
    from shutil import rmtree
    from tempfile import mkstemp
    from os import remove, close, mkdir

    # create a temporary directory
    tmpfile = mkstemp()[1]
    mkdir(tmpfile)

    # create a temporary file into the directory
    tmpfile = tmpfile + '/tmpfile'
    test_file = open(tmpfile, 'w+')
    test_file.close()

    # create a zip archive containing the file
    test_zip = zipfile.ZipFile('test.zip', 'w')
    test_zip.write(tmpfile)
    test_zip.close()


# Generated at 2022-06-12 11:10:38.436633
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    from thefuck.shells import Bash
    shell.set_shell(Bash())
    t = tempfile.NamedTemporaryFile()
    f = open('test_file', 'w')
    f.write('temp')
    f.close()
    f = open('test_file2', 'w')
    f.write('temp')
    f.close()
    os.makedirs('test_dir')
    os.makedirs(os.path.join('test_dir', 'sub_dir'))
    f = open(os.path.join('test_dir', 'sub_dir', 'test_file'), 'w')
    f.write('temp')
    f.close()

# Generated at 2022-06-12 11:10:48.690025
# Unit test for function side_effect
def test_side_effect():
    tmp = tempfile.mkdtemp()
    try:
        with open(os.path.join(tmp, 'file'), 'w') as tmp_file:
            tmp_file.write('file')

        zip_file = zipfile.ZipFile(os.path.join(tmp, 'test.zip'), 'w')
        zip_file.write(os.path.join(tmp, 'file'))
        zip_file.close()

        old_cmd = Command('unzip test.zip', '', tmp)
        command = Command('unzip test.zip', '', tmp)

        side_effect(old_cmd, command)

        # If we reach this point, it means that no error was raised, which
        # means that there was not a problem with the side effect
    finally:
        shutil.rmtree(tmp)

# Generated at 2022-06-12 11:11:08.425668
# Unit test for function side_effect
def test_side_effect():
    input_file = "afile.txt"
    output_file = "afile.zip"
    dummy_file = "dummy_file"

    with open(input_file, "w") as f:
        f.write('dummy')

    command = "unzip {}".format(output_file)
    script = command.split()
    old_cmd = type('Command', (), {
        'script': command,
        'script_parts': script,
        '_binary_suffix': 'unzip'
    })

    with zipfile.ZipFile(output_file, 'w') as zip_file:
        zip_file.write(input_file)

    with open(dummy_file, 'w') as f:
        pass

    side_effect(old_cmd, command)

    assert os.path.exists

# Generated at 2022-06-12 11:11:11.178425
# Unit test for function side_effect
def test_side_effect():
    old_cmd = _Command('unzip report.zip')
    command = get_new_command(old_cmd)
    side_effect(old_cmd, command)

# Generated at 2022-06-12 11:11:19.442905
# Unit test for function side_effect
def test_side_effect():
    # prepare test files
    tmp_dir = tempfile.mkdtemp(prefix='thefuck-test', dir='/tmp')
    firstfile = os.path.join(tmp_dir, 'firstfile')
    open(firstfile, 'w').close()
    secondfile = os.path.join(tmp_dir, 'secondfile')
    open(secondfile, 'w').close()
    os.mkdir(os.path.join(tmp_dir, 'dir'))

    # test function
    side_effect(
        cmd(u'unzip {} {}'.format(firstfile, secondfile)),
        cmd(u'unzip -d {} {} {}'.format(tmp_dir, firstfile, secondfile)))

    # assert that files have been removed
    assert not os.path.exists(firstfile)
    assert not os.path

# Generated at 2022-06-12 11:11:28.777808
# Unit test for function match
def test_match():
    assert not match(Command('', ''))
    assert not match(Command(u'unzip *', ''))
    assert not match(Command(u'unzip *', ''))
    assert match(Command(u'unzip file.zip', ''))
    assert match(Command(u'unzip file', ''))
    assert match(Command(u'unzip file -x', ''))
    assert not match(Command(u'unzip -d file', ''))
    assert not match(Command(u'unzip -d dir file', ''))
    assert not match(Command(u'unzip -d dir file.zip', ''))
    assert not match(Command(u'unzip -d dir', ''))
    assert not match(Command(u'unzip file', ''))
    assert not match(Command(u'unzip file', ''))

# Generated at 2022-06-12 11:11:31.656362
# Unit test for function match
def test_match():
    assert match(Command('unzip a.zip', ''))
    assert not match(Command('unzip -d a.zip', ''))
    assert not match(Command('unzip', ''))


# Generated at 2022-06-12 11:11:40.195461
# Unit test for function side_effect
def test_side_effect():
    from tempfile import mktemp
    from shutil import rmtree
    class command_old():
        def __init__(self, script):
            self.script = script
    code_ = 'unzip test_unit.zip'
    old_cmd = command_old(code_)
    side_effect(old_cmd, code_)
    assert os.path.isfile('test_unit_file')
    os.remove('test_unit_file')
    # Temporary directory
    new_directory = mktemp()
    os.makedirs(new_directory)
    os.chdir(new_directory)
    code_ = 'unzip test_unit.zip'
    old_cmd = command_old(code_)
    side_effect(old_cmd, code_)
    os.chdir('..')
    rmt

# Generated at 2022-06-12 11:11:49.846556
# Unit test for function match
def test_match():
    assert match(Command('unzip ./myfile.zip',
                         'unzip:  cannot find or open ./myfile.zip, ./myfile.zip.zip or ./myfile.zip.ZIP.'))
    assert match(Command('unzip myfile',
                         'unzip:  cannot find or open myfile, myfile.zip or myfile.ZIP.'))
    assert match(Command('unzip myfile.zip',
                         'Archive:  myfile.zip\n'
                         'replace myfile.xml? [y]es, [n]o, [A]ll, [N]one, [r]ename: '))
    assert match(Command('unzip myfile.zip',
                         'unzip:  cannot find or open myfile.zip, myfile.zip.zip or myfile.zip.ZIP.'))

   

# Generated at 2022-06-12 11:11:57.164416
# Unit test for function match
def test_match():
    assert not match(Command('unzip -d /some/file.zip'))
    assert match(Command('unzip /some/file.zip'))
    assert match(Command('unzip file.zip'))
    assert not match(Command('unzip'))
    # test with a bad zip

# Generated at 2022-06-12 11:12:08.572905
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil

    try:
        tmpdir = tempfile.mkdtemp()
        archive = tmpdir + '/archive.zip'
        target = tmpdir + '/target'

        # Create a file
        with open(target, mode='w') as f:
            f.write('Hello world\n')

        # Create the archive
        with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as f:
            f.write(target)

        # Simulate a command
        old_cmd = CmdMock(script=u'unzip ' + archive)

        side_effect(old_cmd, None)

        # Check that the file has been deleted
        assert not os.path.exists(target)
    finally:
        shutil.rmtree(tmpdir)



# Generated at 2022-06-12 11:12:14.264335
# Unit test for function match
def test_match():
    assert not match(Command('zip -d some.zip', '', ''))
    assert not match(Command('unzip -d some.zip', '', ''))
    assert match(Command('unzip some.zip', '', ''))
    assert not match(Command('unzip some.zip some.txt', '', ''))
    assert match(Command('unzip some.txt', '', ''))
    assert not match(Command('unzip some.txt some.zip', '', ''))



# Generated at 2022-06-12 11:12:44.166615
# Unit test for function match
def test_match():
    # Check True for the following scripts
    assert match(Command('unzip example.zip'))
    assert match(Command('unzip example.zip test.txt'))
    assert match(Command('unzip example.zip test.txt -x test.txt'))
    assert match(Command('unzip example.zip -x test.txt'))
    assert match(Command('unzip example.ZIP'))
    assert match(Command('unzip example.ZIP test.txt'))
    assert match(Command('unzip example.ZIP test.txt -x test.txt'))
    assert match(Command('unzip example.ZIP -x test.txt'))

    # Check False for the following scripts
    assert not match(Command('unzip -d example example.zip'))

# Generated at 2022-06-12 11:12:46.535220
# Unit test for function match
def test_match():
    command = 'unzip file.zip -x'
    assert match(command)



# Generated at 2022-06-12 11:12:51.395458
# Unit test for function match
def test_match():
    """Unit test for function match"""
    assert match({
        'script_parts': [u'unzip', '/tmp/archive.zip']
    })
    assert not match({
        'script_parts': [u'unzip', '-d', '/tmp/archive.zip']
    })
    assert not match({
        'script_parts': [u'unzip', '-l', '/tmp/archive.zip']
    })


# Generated at 2022-06-12 11:12:54.279798
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command('unzip docker-compose.zip', '')
    command = Command('unzip -d docker-compose docker-compose.zip', '')
    side_effect(old_cmd, command)

# Generated at 2022-06-12 11:13:03.905005
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', '')) is False
    assert match(Command('unzip -d foo file.zip', '')) is False
    assert match(Command('unzip -d file.zip', '')) is False
    assert match(Command('unzip file.zip bar', '')) is False
    assert match(Command('unzip file.zip -d', '')) is False
    assert match(Command('unzip file', '')) is True
    assert match(Command('unzip -j file', '')) is True
    assert match(Command('unzip -j file.zip', '')) is True
    # Unit test for function get_new_command
    print(get_new_command(Command('unzip file', '')))
    print(get_new_command(Command('unzip -j file', '')))

# Generated at 2022-06-12 11:13:14.090400
# Unit test for function match
def test_match():
    f = _zip_file
    assert f(Command('', 'unzip this.zip')) == 'this.zip'
    assert f(Command('', 'unzip -aC this.zip')) == 'this.zip'
    assert f(Command('', 'unzip -AC this.zip')) == 'this.zip'
    assert f(Command('', 'unzip -AC this.zip other.zip')) == 'this.zip'
    assert f(Command('', 'unzip -AC -x this.zip other.zip')) == 'other.zip'
    assert f(Command('', 'unzip -AC -x this.zip other.zip -d folder')) == 'other.zip'
    assert f(Command('', 'unzip this.zip -d folder')) == 'this.zip'

# Generated at 2022-06-12 11:13:23.317695
# Unit test for function side_effect
def test_side_effect():
    """user wants to unzip a file but unzip is not pointed to the
    file, but directly to a directory, in this case side_effect
    removes the files from the directory so that the new zip files
    are extracted
    """
    import tempfile
    tmpdir = tempfile.mkdtemp()
    file1 = os.path.join(tmpdir, 'abc.txt')
    file2 = os.path.join(tmpdir, 'def.txt')
    open(file1, 'w').close()
    open(file2, 'w').close()
    side_effect('unzip -d {}'.format(tmpdir), '')
    assert not os.path.exists(file1)
    assert not os.path.exists(file2)
    os.rmdir(tmpdir)

# Generated at 2022-06-12 11:13:31.607041
# Unit test for function match
def test_match():
    # Test case for when the given file ends with .zip
    result = match(Command('unzip foo.zip', '', ''))
    assert result

    # Test case for when the given file does not end with .zip
    result = match(Command('unzip foo', '', ''))
    assert result

    # Test case for skipping directories
    result = match(Command('unzip foo.zip -d foo', '', ''))
    assert result is False

    # Test case for error in the file
    result = match(Command('unzip foo.txt', '', ''))
    assert result is False

    # Test case for empty command
    result = match(Command('unzip', '', ''))
    assert result is False



# Generated at 2022-06-12 11:13:42.727244
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    from thefuck.types import Command
    # Test if files are removed:
    file_paths = [tempfile.mkstemp()[1] for _ in range(2)] # create 2 files
    assert len([f for f in os.listdir(tempfile.gettempdir()) if f.startswith(file_paths[0])]) == 2
    side_effect(Command('unzip {}.zip'.format(file_paths[0])), Command('unzip {}.zip -d {}'.format(file_paths[0], file_paths[0][:-4])))
    assert not os.path.isfile(file_paths[0])
    assert not os.path.isfile(file_paths[1])
    # Test if no exception when file does not exist:

# Generated at 2022-06-12 11:13:52.320454
# Unit test for function side_effect
def test_side_effect():
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        with zipfile.ZipFile('zip_test.zip', 'w') as zf:
            zf.write(tmp + '/file1')
            zf.write(tmp + '/file2')
        os.mkdir(tmp + '/file1')
        os.mkdir(tmp + '/file3')
        os.chdir(tmp)
        # unzip zip_test.zip will fail without the side_effect function
        match(_unzip('unzip zip_test.zip'))
        get_new_command(_unzip('unzip zip_test.zip'))
        side_effect(_unzip('unzip zip_test.zip'), _unzip('unzip zip_test.zip'))
        assert not len(os.listdir(tmp))

# Generated at 2022-06-12 11:14:39.998106
# Unit test for function match
def test_match():
    assert match(
        Command('unzip test_zip.zip', 'test_zip'))
    assert match(
        Command('unzip test_zip.zip', ''))
    assert match(
        Command('unzip test_zip.zip -d test_unzip', ''))
    assert not match(
        Command('unzip test_zip.zip -d test_unzip', 'test_zip'))
    assert not match(
        Command('unzip test_zip.zip -d test_unzip', 'test_unzip'))
    assert not match(Command('vim test_zip.zip', 'test_zip'))
    assert not match(Command('ls test_zip.zip', 'test_zip'))
    assert not match(Command('pwd', ''))


# Generated at 2022-06-12 11:14:45.621583
# Unit test for function match
def test_match():
    assert _is_bad_zip('zip.zip')
    assert not _is_bad_zip('unzip.py')
    assert not _is_bad_zip('__init__.py')

    assert not match(Command('unzip test.zip xxx.txt -d test', '', ''))
    assert match(Command('unzip test.zip', '', ''))
    assert match(Command('unzip test', '', ''))



# Generated at 2022-06-12 11:14:52.461886
# Unit test for function side_effect
def test_side_effect():
    if os.path.exists('a'):
        os.remove('a')
    if os.path.exists('dir'):
        os.rmdir('dir')
    if os.path.exists('dir/b'):
        os.remove('dir/b')
    with zipfile.ZipFile('test.zip','w') as test_zip:
        test_zip.write('a')
        test_zip.write('dir/b')

    side_effect('mock_script', 'mock_script')
    assert os.path.exists('a')
    assert os.path.exists('dir')
    assert os.path.exists('dir/b')
    os.remove('a')
    os.remove('dir/b')
    os.rmdir('dir')

# Generated at 2022-06-12 11:15:03.461437
# Unit test for function side_effect
def test_side_effect():
    import zipfile
    from thefuck.types import Command


# Generated at 2022-06-12 11:15:11.393030
# Unit test for function match
def test_match():
    match_dict = {
            # Good inputs
            'unzip test.zip': False,
            'unzip test.zip ': False,
            'unzip test.zip test.txt': False,
            'unzip test.zip other.txt': _is_bad_zip('test.zip'),
            'unzip test.zip -d test': _is_bad_zip('test.zip'),
            'unzip -h': False,

            # Bad inputs
            '': False,
            'unzip': False,
            'unzip -d': False,
            'unzip -d test': False,
            'unzip -d test test.zip': _is_bad_zip('test.zip'),
    }

    for key in match_dict.keys():
        command = shell.and_('unzip', '', key)
       

# Generated at 2022-06-12 11:15:19.993653
# Unit test for function match
def test_match():
    # Test for correct zip file
    script = 'unzip thefuck.zip'
    command = shell.and_('', script)
    result = match(command)
    assert result==True

    # Test for incorrect zip file
    script = 'unzip thefuck.ziz'
    command = shell.and_('', script)
    result = match(command)
    assert result==False

    # Test for multiple files
    script = 'unzip thefuck.zip thefuck.txt'
    command = shell.and_('', script)
    result = match(command)
    assert result==False


# Generated at 2022-06-12 11:15:27.818286
# Unit test for function side_effect
def test_side_effect():
    import os
    import tempfile
    import zipfile
    filename = tempfile.mktemp()
    base = 'test123'
    filename = os.path.join(base, 'test1.txt')
    with open(filename, 'w') as f:
        f.write('test')
    filename = os.path.join(base, 'test2.txt')
    with open(filename, 'w') as f:
        f.write('test')
    filename = os.path.join(base, 'test3.txt')
    with open(filename, 'w') as f:
        f.write('test')
    with zipfile.ZipFile(base + '.zip', 'w') as z:
        z.write(os.path.join(base, 'test1.txt'))

# Generated at 2022-06-12 11:15:31.586493
# Unit test for function side_effect
def test_side_effect():
    script = 'unzip -d test test.zip'
    command = shell.from_shell(script)
    test_files = ['test/file']
    side_effect(command, command)
    assert any([os.path.isfile(file) for file in test_files]) == False

# Generated at 2022-06-12 11:15:38.815313
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    old_command = Command('unzip file.zip', 'unzip: cannot find or open file.zip, file.zip.zip or file.zip.ZIP.')
    with zipfile.ZipFile('file.zip', 'w') as archive:
        archive.writestr('"file.zip"', 'file content')

    side_effect(old_command, Command('unzip -d file file.zip', ''))

    assert os.path.isfile('file')
    with open('file', 'r') as f:
        assert f.read() == 'file content'
    os.remove('file')
    os.remove('file.zip')

# Generated at 2022-06-12 11:15:43.721651
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command('unzip archive.zip')
    command = Command(get_new_command(old_cmd))
    with zipfile.ZipFile(_zip_file(old_cmd), 'r') as archive:
        for file in archive.namelist():
            if not os.path.abspath(file).startswith(os.getcwd()):
                # it's unsafe to overwrite files outside of the current directory
                continue

            open(file, 'a').close()
            assert os.path.isfile(file)
    side_effect(old_cmd, command)

# Generated at 2022-06-12 11:17:10.688788
# Unit test for function match
def test_match():
    command = Command('unzip commands.zip', '')
    assert not match(command)
    command = Command('unzip -d commands.zip', '')
    assert not match(command)
    command = Command('unzip -d commands.zip /home/user/file', '')
    assert not match(command)
    command = Command('unzip commands.zip /home/user/file', '')
    assert not match(command)
    command = Command('unzip commands.zip /home/user/file file2 file3', '')
    assert not match(command)
    command = Command('unzip commands.zip file', '')
    assert not match(command)
    command = Command('unzip commands.zip file file2 file3', '')
    assert not match(command)


# Generated at 2022-06-12 11:17:21.953571
# Unit test for function side_effect
def test_side_effect():
    os.mkdir('testdir')
    with open('file.zip', 'w') as f:
        f.write('empty')
    with open('testdir/file.zip', 'w') as f:
        f.write('empty')
    shell.and_('unzip file.zip', 'rm file.zip')
    os.mkdir('testdir2')
    shell.and_('unzip testdir/file.zip', 'rm testdir/file.zip')
    zip_file = _zip_file(shell.get_command())
    assert not os.path.exists(zip_file)
    side_effect(shell.get_command(), shell.get_command())
    assert not os.path.exists(zip_file[:-4])
    assert zip_file.endswith('testdir/file.zip')

# Generated at 2022-06-12 11:17:30.253190
# Unit test for function match
def test_match():
    # current version of unzip writes usage info to stderr
    # if file is not zip
    arch = 'arch1.zip'
    with open(arch, 'w') as _:
        pass

    with open('arch2.zip', 'w') as _:
        pass

    with open('arch3.zip', 'w') as _:
        pass

    # zip with one file
    with zipfile.ZipFile(arch, 'w') as archive:
        archive.writestr('data.txt', 'data')

    assert not match(Command(u'unzip arch1.zip', stderr=u''))
    assert not match(Command(u'unzip arch2.zip', stderr=u''))

# Generated at 2022-06-12 11:17:38.010600
# Unit test for function match
def test_match():
    assert not match(Command('unzip a.zip',
                             'unzip:  cannot find or open a.zip, a.zip.zip or a.zip.ZIP.'))

    assert not match(Command('unzip a.zip file.zip',
                             'unzip:  cannot find or open file.zip, file.zip.zip or file.zip.ZIP.'))

    assert match(Command('unzip a.zip',
                         'error:  zip file is empty'))

    assert match(Command('unzip a.zip',
                         'unzip:  cannot find or open a.zip, a.zip.zip or a.zip.ZIP.'))


# Generated at 2022-06-12 11:17:47.416937
# Unit test for function side_effect
def test_side_effect():
    filename = "test.zip"
    # Create the test.zip file
    archive = zipfile.ZipFile(filename, 'w')
    archive.writestr('file_to_extract', '')
    archive.writestr('another_file_to_extract', '')
    archive.close()
    # Test the side effect
    with open(filename, 'rb') as file:
        md5sum_before = md5(file.read()).hexdigest()
    command = get_new_command(shell.And('unzip', filename))
    old_cmd = Mock(spec=Command, script='unzip {}'.format(filename))
    side_effect(old_cmd, command)
    with open(filename, 'rb') as file:
        md5sum_after = md5(file.read()).hexdigest

# Generated at 2022-06-12 11:17:56.849568
# Unit test for function match
def test_match():
    # Test positive: command is unzip, _zip_file() return a potential bad zip
    # file and _is_bad_zip() return True
    #
    # unzip -l test/test.zip
    #  return a list of files present in archive
    #
    # _zip_file(command)
    #  return the zip file (test/test.zip)
    #
    # _is_bad_zip(zip_file)
    #  return True as the zip file contains multiple files
    command = type(
        'Command',
        (object,),
        {
            'script': u'unzip -l test/test.zip',
            'script_parts': [u'unzip', u'-l', u'test/test.zip']
        })
    assert match(command)

    # Test positive: command is

# Generated at 2022-06-12 11:18:00.415704
# Unit test for function match
def test_match():
    assert match(Command('unzip Test.zip File.txt', '')) is True
    assert match(Command('unzip Test.zip File.txt', '', '', False)) is False
    assert match(Command('unzip Test.zip -d Test\'folder', '')) is False



# Generated at 2022-06-12 11:18:08.580151
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil
    import zipfile

    path = tempfile.mkdtemp()
    zip_file = '{}.zip'.format(path)
    inside_file = '{}/inside'.format(path)
    outside_file = '{}/../outside'.format(path)

    with open(inside_file, 'w') as f:
        f.write('inside')

    with open(outside_file, 'w') as f:
        f.write('outside')

    with zipfile.ZipFile(zip_file, 'w') as f:
        f.write(inside_file)
        f.write(outside_file)

    class FakeCommand:
        def __init__(self, filename):
            self.script = filename
            self.script_parts = [filename]


# Generated at 2022-06-12 11:18:15.677809
# Unit test for function match
def test_match():
    assert match(Command('', '')) is False
    assert match(Command('', 'unzip foo.zip'))
    assert match(Command('', 'unzip foo.zip bar.zip'))
    assert not match(Command('', 'unzip -d foo.zip bar.zip'))
    assert match(Command('', 'unzip -h foo.zip bar.zip'))
    assert match(Command('', 'unzip -t foo.zip bar.zip'))
    assert match(Command('', 'unzip foo.zip -t'))
    assert match(Command('', 'unzip -t bar.zip'))
