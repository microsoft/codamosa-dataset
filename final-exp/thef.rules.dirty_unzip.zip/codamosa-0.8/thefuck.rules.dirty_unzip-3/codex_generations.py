

# Generated at 2022-06-12 11:08:22.860147
# Unit test for function side_effect
def test_side_effect():
    dir_name = 'test_side_effect'
    if os.path.exists(dir_name):
        import shutil
        shutil.rmtree(dir_name)
    os.mkdir(dir_name)
    with open(os.path.join(dir_name, 'test_side_effect'), 'w') as f:
        f.write("test")

    with zipfile.ZipFile('test_side_effect.zip', 'w', zipfile.ZIP_DEFLATED) as myzip:
        myzip.write('test_side_effect/test_side_effect')

    side_effect(None, None)
    import shutil
    shutil.rmtree(dir_name)
    os.remove('test_side_effect.zip')

# Generated at 2022-06-12 11:08:31.893771
# Unit test for function side_effect
def test_side_effect():
    assert not os.path.exists('/tmp/test/test2')

    mock = Mock(side_effect=side_effect)

    # Change path to create a new directory
    try:
        os.mkdir('/tmp/test/')

        # Create a file to delete it
        with open('/tmp/test/test2', 'w'):
            pass

        mock.side_effect(Mock(script='unzip a.zip'), Mock(script='unzip test2'))
        assert not os.path.exists('/tmp/test/test2')
    finally:
        # Remove directory created
        os.rmdir('/tmp/test/')

# Generated at 2022-06-12 11:08:42.609650
# Unit test for function side_effect
def test_side_effect():
    """
    Create a temp file within a temp dir
    zip it in a temp zip file
    test if the file within the temp dir has been deleted
    """
    import shutil
    import tempfile
    temp_dir = tempfile.mkdtemp()
    temp_file = tempfile.mkstemp(dir=temp_dir)[1]
    zip_file_path = tempfile.mkstemp(prefix='unzip_test_', suffix='.zip')[1]
    z = zipfile.ZipFile(zip_file_path, 'w')
    z.write(temp_file, os.path.basename(temp_file))
    z.close()
    side_effect('unzip ' + zip_file_path, 'unzip ' + zip_file_path + ' -d ' + temp_dir)
    assert not os

# Generated at 2022-06-12 11:08:44.310994
# Unit test for function side_effect
def test_side_effect():
    side_effect(old_cmd = 'unzip file.zip', command='unzip file.zip')

# Generated at 2022-06-12 11:08:55.051853
# Unit test for function side_effect
def test_side_effect():
    from mock import patch
    from thefuck.rules.unzip_single_file import side_effect

    import os
    import tempfile

    temp_dir = tempfile.mkdtemp()

    # Create file a file called test.txt
    with open(os.path.join(temp_dir, "test.txt"), 'w') as f:
        f.write("test")

    with patch("os.getcwd", return_value= temp_dir):
        # Create mock object for side_effect
        mock_command = type('', (object,), {'script': 'unzip test.txt',
                                           'script_parts': 'unzip test.txt'})

        side_effect(mock_command, mock_command)

        # Check if the file no longer exists

# Generated at 2022-06-12 11:09:00.170116
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip', '', ''))
    assert not match(Command('unzip -d test.zip', '', ''))
    assert not match(Command('unzip -d test test.zip', '', ''))
    assert not match(Command('unzip -d test test', '', ''))



# Generated at 2022-06-12 11:09:07.098704
# Unit test for function side_effect
def test_side_effect():
    os.mkdir('./test')
    os.chdir('./test')
    file = open('testfile', 'w+')
    file.close()
    with zipfile.ZipFile('./test.zip', 'w') as zipped:
        zipped.write('testfile')
    side_effect(shell.And('unzip test.zip', 'unzip test.zip'), None)
    assert os.path.isfile('testfile')

    os.chdir('..')
    test = os.path.isdir('./test')
    shutil.rmtree('./test')
    assert test

# Generated at 2022-06-12 11:09:17.847624
# Unit test for function side_effect
def test_side_effect():
    # Create temporary directory and change current directory to it
    tmp_dir = tempfile.TemporaryDirectory(prefix="tf_test_side_effect")
    old_cwd = os.getcwd()
    os.chdir(tmp_dir.name)

    # Create zip file with one file
    test_zip_file_name = os.path.join(tmp_dir.name, "test.zip")
    with zipfile.ZipFile(test_zip_file_name, 'w') as zip_file:
        zip_file.write("test.txt", "test.txt")

    # Test side_effect()
    file_path = os.path.join(tmp_dir.name, "test.txt")
    cmd = Command("unzip test.zip", "echo unzip -d test.zip", "echo")
    side_effect

# Generated at 2022-06-12 11:09:25.095381
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip somefile.txt', '', '')) == False
    assert match(Command('unzip -d test.zip', '', '')) == False
    assert match(Command('unzip -d test.zip somefile.txt', '', '')) == False
    assert match(Command('unzip -d test test.zip', '', '')) == False
    assert match(Command('unzip -d test.zip somefile.txt', '', '')) == False
    assert match(Command('unzip test.zip', '', '')) == True
    assert match(Command('unzip test', '', '')) == True


# Generated at 2022-06-12 11:09:27.879506
# Unit test for function match
def test_match():
    cmd = Command(script='unzip file.zip', stdout='')
    assert not match(cmd)

    cmd = Command(script='unzip -d file.zip', stdout=_is_bad_zip('file.zip'))
    assert match(cmd)

# Generated at 2022-06-12 11:09:45.016344
# Unit test for function match
def test_match():
    import re

    assert match(Command('unzip zipfile.zip')) == False
    assert match(Command('unzip -qq zipfile.zip')) == False
    assert match(Command('unzip -d unzipped zipfile.zip')) == False
    assert match(Command('unzip -wq zipfile.zip')) == False
    assert match(Command('unzip -j zipfile.zip')) == False
    assert match(Command('unzip -j -d unzipped zipfile.zip')) == False
    assert match(Command('unzip -l zipfile.zip')) == False
    assert match(Command('unzip -L zipfile.zip')) == False
    assert match(Command('unzip a.zip')) == False
    assert match(Command('unzip b.zip')) == False


# Unit test

# Generated at 2022-06-12 11:09:53.109049
# Unit test for function side_effect
def test_side_effect():
    import zipfile

    try:
        os.remove('test_side_effect')
    except OSError:
        pass

    try:
        os.remove('test_side_effect.zip')
    except OSError:
        pass

    f = open('test_side_effect', 'w')
    f.write('test')
    f.close()

    zipfile.ZipFile('test_side_effect.zip', 'w').write('test_side_effect')

    assert os.path.isfile('test_side_effect')
    assert os.path.isfile('test_side_effect.zip')

    side_effect(Command('unzip test_side_effect.zip', '', ''), Command('', '', ''))

    assert os.path.isfile('test_side_effect')

# Generated at 2022-06-12 11:10:02.783862
# Unit test for function match
def test_match():

    command_unzip_bad = Command('unzip tests/plain.zip', '', '')
    assert not match(command_unzip_bad)

    command_unzip_good = Command('unzip tests/plain-dir.zip', '', '')
    assert match(command_unzip_good)

    command_unzip_good_two = Command('unzip tests/plain-dir.zip', '', '')
    assert match(command_unzip_good_two)

    command_unzip_good_three = Command('unzip tests/plain-dir.zip tests/plain.zip', '', '')
    assert match(command_unzip_good_three)

    command_unzip_bad_two = Command('unzip tests/plain.zip tests/plain-dir.zip', '', '')

# Generated at 2022-06-12 11:10:08.992976
# Unit test for function match
def test_match():
    assert match(Command('unzip archive.zip'))
    assert match(Command('unzip archive.zip file1.txt'))
    assert match(Command('unzip archive.zip file1.txt file2.txt'))
    assert not match(Command('unzip -d destination archive.zip'))
    assert not match(Command('unzip -d destination archive.zip file1.txt'))
    assert not match(Command('unzip -d destination archive.zip file1.txt file2.txt'))


# Generated at 2022-06-12 11:10:17.163159
# Unit test for function match
def test_match():
    assert match(Command('unzip -l file.zip', '', None))
    assert match(Command('unzip -t file.zip', '', None))
    assert match(Command('unzip file.zip', '', None))
    assert match(Command('unzip file', '', None))
    assert match(Command('unzip -l file.zip test.txt', '', None))
    assert match(Command('unzip -t file.zip test.txt', '', None))
    assert not match(Command('unzip file.zip test.txt', '', None))
    assert not match(Command('unzip file test.txt', '', None))
    assert not match(Command('unzip -l file.zip test.txt -d dir', '', None))

# Generated at 2022-06-12 11:10:18.809100
# Unit test for function match
def test_match():
    assert match(Command("unzip foo.zip"))
    assert not match(Command("unzip -d foo foo.zip"))

# Generated at 2022-06-12 11:10:29.864437
# Unit test for function match
def test_match():
    # Test for non-matching script
    assert not match(Command('ls'))
    assert not match(Command('unzip -d dir1 file.zip'))
    # Test for matching script
    assert match(Command('unzip file.zip'))
    assert match(Command('unzip file1 file2.zip'))
    assert match(Command('unzip file1 file2 file3 file4.zip'))
    assert match(Command('unzip -a file1 file2 file3 file4.zip'))
    assert match(Command('unzip -ao file1 file2 file3 file4.zip'))
    assert match(Command('unzip -p file1 file2 file3 file4.zip'))
    assert match(Command('unzip -pa file1 file2 file3 file4.zip'))

# Generated at 2022-06-12 11:10:33.312276
# Unit test for function match
def test_match():
    assert match(Command('unzip -l file.zip', '')) is False
    assert match(Command('unzip file.zip', '')) is True
    assert match(Command('unzip file.zip something.zip', '')) is True



# Generated at 2022-06-12 11:10:43.395347
# Unit test for function side_effect
def test_side_effect():
    folder_name = 'test'
    file1_name = 'test/test.txt'
    file2_name = 'test/test2.txt'
    test_file1 = open(file1_name, 'w')
    test_file2 = open(file2_name, 'w')
    test_file1.close()
    test_file2.close()
    with zipfile.ZipFile('test.zip', 'w') as archive:
        archive.write(file1_name)
        archive.write(file2_name)
    os.remove(file1_name)
    os.remove(file2_name)
    assert not os.path.exists(file1_name)
    assert not os.path.exists(file2_name)
    assert os.path.exists(folder_name)


# Generated at 2022-06-12 11:10:52.821174
# Unit test for function side_effect
def test_side_effect():
    old_cmd = "unzip foo.zip"
    command = "unzip -d foo foo.zip"

    import os
    import zipfile
    from contextlib import nested
    from mock import patch
    from tempfile import NamedTemporaryFile
    from thefuck.types import Setting
    from thefuck.shells import shell

    with nested(
            patch('os.getcwd', return_value='/path/to'),
            patch('os.path.abspath', return_value='/path/to/foo.txt')) as (
            mock_getcwd, mock_abspath):

        with NamedTemporaryFile('w', delete=False, dir='/path/to') as f:
            f.write('')
        f.close()


# Generated at 2022-06-12 11:11:10.659332
# Unit test for function match
def test_match():
    file = 'file.zip'
    with open(file, 'w') as f:
        f.write('test')
    assert not _is_bad_zip(file)
    assert match(Command('unzip {}'.format(file), '')) == False
    os.remove(file)

    file = 'file.zip'
    with open(file, 'w') as f:
        with zipfile.ZipFile(file, 'w') as fzip:
            fzip.writestr('file', 'test')
    assert _is_bad_zip(file)
    assert match(Command('unzip {}'.format(file), '')) == True
    os.remove(file)

    file = 'file.zip'

# Generated at 2022-06-12 11:11:13.266562
# Unit test for function match
def test_match():
	assert not match(Command('git branch', ''))
	assert match(Command('unzip *.zip', ''))
	assert match(Command('unzip *.zip blabla', ''))


# Generated at 2022-06-12 11:11:19.208046
# Unit test for function side_effect
def test_side_effect():
    directory = '/tmp/thefucklstest'
    file = directory + '/toto.txt'
    zip_file = directory + '/test.zip'
    ensure_directory_exists(directory)
    ensure_file_exists(file)
    ensure_file_exists(zip_file)
    side_effect(Command('unzip -o test.zip', '', '/tmp/thefucklstest'),
                Command('unzip -o test.zip', '', '/tmp/thefucklstest/'))
    assert not os.path.exists(file)

# Generated at 2022-06-12 11:11:22.786383
# Unit test for function side_effect
def test_side_effect():
    from thefuck import shells

    old_cmd = shells.and_('unzip ZipFile', 'echo "ZipFile" | unzip')
    command = 'unzip -d ZipDir ZipFile'
    side_effect(old_cmd, command)

# Generated at 2022-06-12 11:11:28.970148
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command('unzip test.zip', '', None, None)
    command_new = Command('unzip test.zip -d test', '', None, None)
    file1 = 'test/file1.txt'
    file2 = 'test/file2.txt'
    with open(file1, 'w') as f:
        f.write('file1')
    with open(file2, 'w') as f:
        f.write('file2')
    side_effect(old_cmd, command_new)
    assert not os.path.exists(file2)

# Generated at 2022-06-12 11:11:38.594760
# Unit test for function side_effect
def test_side_effect():
    from .utils import get_closest

    path = get_closest('file1', 'file2', 'file3')
    tmp_path = path + '/.tmp/'
    os.makedirs(tmp_path)

# Generated at 2022-06-12 11:11:46.890049
# Unit test for function side_effect
def test_side_effect():
    from thefuck import shells
    from thefuck.types import Command

    with shells.PopenMock(
            'unzip example.zip',
            """Archive:  example.zip
   creating: a/
  inflating: a/a.txt
  inflating: a/a.zip"""):
        side_effect(Command(script='unzip example.zip',
                            stderr=''),
                    Command(script='unzip example.zip -d test',
                            output='', stderr=''))

    assert os.path.exists('a.zip')
    assert os.path.exists('a.txt')
    os.remove('a.txt')

# Generated at 2022-06-12 11:11:55.162268
# Unit test for function side_effect
def test_side_effect():
    from thefuck.rules.fix_unzip import side_effect
    import os
    import zipfile
    import tempfile

    with tempfile.NamedTemporaryFile(suffix=".zip") as temp:
        with zipfile.ZipFile(temp, 'w') as archive:
            archive.writestr('test.txt', 'test')
            archive.writestr('test2.txt', 'test')
        with tempfile.NamedTemporaryFile() as temp3:
            with open(os.path.join(os.getcwd(), "test.txt"), "w") as temp2:
                side_effect(
                    shell.And('unzip test.zip', 'exit 0'),
                    shell.And('unzip test.zip', 'exit 0'))
                assert os.path.isfile('test.txt')
                os

# Generated at 2022-06-12 11:12:00.458771
# Unit test for function match
def test_match():
    command = 'unzip watchmen.zip'
    assert match(command) == True
    command = 'unzip /home/username/Desktop/watchmen/watchmen.zip'
    assert match(command) == True
    command = 'unzip watchmen.zip -d /usr/local/bin'
    assert match(command) == False


# Generated at 2022-06-12 11:12:10.619363
# Unit test for function side_effect
def test_side_effect():
    """Test to ensure the side_effect function works correctly.
       The unit test creates a small zip file, with a root and subdirectory.
       It then ensures that the side effect function deletes the old files
       correctly, without exceptions"""
    script = '/usr/bin/unzip'
    files = ['test_side_effect.zip', 'test_side_effect/subdir/test.txt']

    # Create the zip file
    zf = zipfile.ZipFile('test_side_effect.zip', 'w')
    zf.writestr(files[1], 'Test file')
    zf.close()

    # Create the command object
    cmd = Command(script, 'unzip ' + files[0])

    # Run the side_effect function
    side_effect('', cmd)

    # Ensure the file has been removed

# Generated at 2022-06-12 11:12:27.966573
# Unit test for function match
def test_match():
    from thefuck.rules.zip_unzip import match
    command = 'unzip file.zip'
    zip_file = 'file.zip'
    assert match(command) == _is_bad_zip(zip_file)

# Generated at 2022-06-12 11:12:36.277546
# Unit test for function match
def test_match():
    assert match(Command('unzip 1.zip', '', ''))
    assert match(Command('unzip 1.zip A.txt', '', ''))
    assert match(Command('unzip 1', '', ''))
    assert not match(Command('unzip 1', '', ''))
    assert not match(Command('unzip 1.tar', '', ''))
    assert not match(Command('unzip 1.rar', '', ''))
    assert not match(Command('unzip 1.zip -d out', '', ''))
    assert not match(Command('unzip -t 1.zip', '', ''))
    assert not match(Command('unzip -t 1.rar', '', ''))

# Generated at 2022-06-12 11:12:46.972098
# Unit test for function side_effect
def test_side_effect():
    # pylint: disable=no-member
    # mock does not work well with pylint for some reason
    from unittest.mock import patch, mock_open
    from thefuck.types import Command
    from zipfile import ZipInfo

    test_zip = mock_open(read_data=b'Zipfilecontent')
    test_zip.name = 'test.zip'
    test_zip.info.return_value = ZipInfo('test')
    test_zip.namelist.return_value = ['test']
    with patch('zipfile.ZipFile', return_value=test_zip):
        old_cmd = Command('unzip test.zip', 'unzip:  cannot find or open test.zip, test.zip.zip or test.zip.ZIP.')

# Generated at 2022-06-12 11:12:52.568296
# Unit test for function match
def test_match():
    assert not match(Command('unzip test.zip -d test', 'unzip:  cannot find or open test.zip, test.zip.zip or test.zip.ZIP.'))
    assert not match(Command('unzip -l test.zip', "Archive:  test.zip\n  Length      Date    Time    Name\n---------  ---------- -----   ----\ntest1\ntest2"))
    assert not match(Command('unzip -d test test.zip', 'unzip:  cannot find or open test.zip, test.zip.zip or test.zip.ZIP.'))
    assert match(Command("unzip test.zip", "Archive:  test.zip\n  Length      Date    Time    Name\n---------  ---------- -----   ----\ntest1/\ntest2/"))


# Generated at 2022-06-12 11:12:54.525268
# Unit test for function match
def test_match():
    match_test = _is_bad_zip('/home/user/.fzf/test.zip')
    assert match_test == True


# Generated at 2022-06-12 11:12:59.784520
# Unit test for function match
def test_match():
    for str_cmd in ["unzip test.zip", "unzip test", "unzip -i test.zip",
                    "unzip -t test.zip", "unzip -o test.zip"]:
        assert match(shell.and_(str_cmd, "unzip.zip"))
    for str_cmd in ["unzip -d test.zip"]:
        assert not match(shell.and_(str_cmd, "unzip.zip"))

# Generated at 2022-06-12 11:13:05.008822
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert match(Command('unzip file', ''))
    assert not match(Command('unzip -d file.zip', ''))
    assert match(Command('unzip -d file', ''))
    assert not match(Command('unzip -d file file.zip', ''))
    assert match(Command('unzip -d file -x file', ''))

# Generated at 2022-06-12 11:13:08.055524
# Unit test for function match
def test_match():
    assert match(Command('unzip foo.zip', '', stderr=''))
    assert not match(Command('unzip -d foo foo.zip', '', stderr=''))


# Generated at 2022-06-12 11:13:13.006721
# Unit test for function match
def test_match():
    assert match(Command('ls', ''))
    assert match(Command('unzip 1.c', ''))
    assert match(Command('unzip 1.zip', ''))
    assert not match(Command('unzip -t 1.zip', ''))
    assert not match(Command('unzip -d 1.zip', ''))



# Generated at 2022-06-12 11:13:16.299196
# Unit test for function match
def test_match():
    assert match(Command('unzip zipfile.zip')) is True
    assert match(Command('unzip zipfile.zip -d target')) is False
    assert match(Command('unzip zipfile -d target')) is False


# Generated at 2022-06-12 11:13:40.568223
# Unit test for function match
def test_match():
    os.system('rm -rf test')
    os.system('mkdir test')
    os.chdir('test')
    os.system('touch file.zip')
    os.system('mkdir dir')
    os.system('touch dir/file')
    os.system('touch dir/file2')
    os.system('zip archive dir/file dir/file2')
    script = 'unzip archive'
    command = Command(script, '', '')
    assert match(command) is True
    os.chdir('..')
    os.system('rm -rf test')


# Generated at 2022-06-12 11:13:47.613730
# Unit test for function side_effect
def test_side_effect():
    old_cmd = 'unzip file.zip'
    command = 'unzip -d file file.zip'

    try:
        # Create an example archive file.zip containing foo.txt and bar.txt
        archive = zipfile.ZipFile("file.zip", "w")
        archive.write("test/unzip/foo.txt")
        archive.write("test/unzip/bar.txt")
        archive.close()

        # Test side_effect function
        side_effect(old_cmd, command)
        assert os.path.exists("test/unzip/foo.txt")
        assert os.path.exists("test/unzip/bar.txt")
    finally:
        if os.path.exists("file.zip"):
            os.remove("file.zip")

# Generated at 2022-06-12 11:13:55.412637
# Unit test for function match
def test_match():
    # Test script with different flags
    assert not match(Command(script='unzip -l some-file.zip',
                             stdout='', stderr=''))
    assert not match(Command(script='unzip -fo some-file.zip',
                             stdout='', stderr=''))
    assert not match(Command(script='unzip -f some-file.zip',
                             stdout='', stderr=''))
    assert not match(Command(script='unzip -qq some-file.zip',
                             stdout='', stderr=''))

    # Test script with different filenames
    assert match(Command(script='unzip some-file.zip',
                        stdout='', stderr=''))

# Generated at 2022-06-12 11:14:04.776033
# Unit test for function match
def test_match():
    assert match(Command(
        script="unzip somefile.zip",
        stdout="",
        stderr=""))
    assert match(Command(
        script="unzip somefile.zip",
        stdout="Archive:  somefile.zip\n  inflating: file1\n",
        stderr=""))
    assert match(Command(
        script="unzip somefile.zip file1",
        stdout="Archive:  somefile.zip\n  inflating: file1\n",
        stderr=""))
    assert not match(Command(
        script="unzip -d target somefile.zip",
        stdout="Archive:  somefile.zip\n  inflating: file1\n",
        stderr=""))

# Generated at 2022-06-12 11:14:15.190473
# Unit test for function side_effect
def test_side_effect():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmp:
        os.chdir(tmp)
        # Create target directory and file to be "overwritten"
        os.mkdir('subdir')
        with open('subdir/file.txt', 'w') as f:
            f.write('Target file')

        # Test against an actual directory
        old_cmd = _Command('unzip -d subdir test.zip')
        with zipfile.ZipFile('test.zip', 'w') as zip_out:
            zip_out.write('subdir/file.txt')

        side_effect(old_cmd, None)

        with open('subdir/file.txt', 'r') as f:
            assert f.read() == 'Target file'

        # Test against a symlink

# Generated at 2022-06-12 11:14:16.378819
# Unit test for function side_effect
def test_side_effect():
    test_command = Command('unzip oneFile.zip')
    side_effect(test_command, test_command)

# Generated at 2022-06-12 11:14:24.853177
# Unit test for function side_effect
def test_side_effect():
    script = mock.MagicMock()
    script.script_parts.__getitem__.return_value = 'file_test.zip'

    command = mock.MagicMock()
    command.script = 'unzip -d'
    command.script_parts = ['unzip', '-d', 'file_test.zip']

    with zipfile.ZipFile('tests/test_data/file_test.zip', 'r') as archive:
        archive.extractall('tests/test_data/unzip_side_effect')
        for file in archive.namelist():
            if not os.path.abspath(file).startswith(os.getcwd()):
                # it's unsafe to overwrite files outside of the current directory
                continue

# Generated at 2022-06-12 11:14:34.357643
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    import shutil

    test_archive = tempfile.NamedTemporaryFile(suffix='.zip')

    #Create a test zip file with a directory, a file and a symlink to a file
    testdir = tempfile.mkdtemp()
    testdirfile = tempfile.NamedTemporaryFile(dir=testdir, suffix='.tmp', delete=True)
    with zipfile.ZipFile(test_archive.name, 'w') as archive:
        archive.write(testdirfile.name)
        archive.write(testdirfile.name+".lnk", arcname=testdirfile.name+".lnk")
        archive.write(testdir)

    #Invoke side_effect

# Generated at 2022-06-12 11:14:42.494251
# Unit test for function match
def test_match():
    assert match(Command('unzip foo.zip', '', ''))
    assert not match(Command('unzip -d foo', '', ''))
    assert not match(Command('unzip', '', ''))
    assert not match(Command('unzip', '', ''))
    assert not match(Command('unzip -foo', '', ''))
    assert match(Command('unzip foo', '', ''))
    assert match(Command('unzip foo.zip bar', '', ''))
    assert match(Command('unzip -foo bar', '', ''))
    assert match(Command('unzip -foo bar -bar foo.zip', '', ''))
    assert match(Command('unzip -d foo -bar foo.zip', '', ''))

# Generated at 2022-06-12 11:14:51.000979
# Unit test for function side_effect
def test_side_effect():
    import shutil
    import tempfile
    import zipfile
    from thefuck.shells import get_closest

    dir_with_files = tempfile.mkdtemp()
    test_file1 = os.path.join(dir_with_files, "test_file1")
    test_file2 = os.path.join(dir_with_files, "test_file2")
    shutil.copy2("tests/res/random_file", test_file1)
    shutil.copy2("tests/res/random_file", test_file2)
    zip_file_path = tempfile.mktemp()
    with zipfile.ZipFile(zip_file_path, 'w') as zip_file:
        zip_file.write(test_file1)
        zip_file.write(test_file2)



# Generated at 2022-06-12 11:15:09.371043
# Unit test for function side_effect
def test_side_effect():
    old_cmd = Command('unzip /tmp/bad_zip.zip', '')
    cmd = Command('unzip /tmp/bad_zip.zip -d /tmp/bad_zip', '')

    side_effect(old_cmd, cmd)

    assert os.path.isfile('/tmp/bad_zip')

# Generated at 2022-06-12 11:15:19.758753
# Unit test for function side_effect
def test_side_effect():
    from thefuck.tests.utils import Command
    from cStringIO import StringIO
    testfile = 'testfile'
    testdir = 'testdir'
    testfile_inside = os.path.join(testdir, 'testfile')
    open(testfile, 'a').close()
    os.mkdir(testdir)
    open(testfile_inside, 'a').close()
    zip_file = zipfile.ZipFile(StringIO(), 'w')
    zip_file.write(testfile)
    zip_file.write(testfile_inside)
    zip_file.close()
    # If testfile or testfile_inside exist, side_effect removes them

# Generated at 2022-06-12 11:15:27.668357
# Unit test for function match
def test_match():
    from tests.utils import Command
    command = Command('unzip file.zip')
    assert not match(command)
    command = Command('unzip file.zip')
    assert not match(command)
    command = Command('unzip file.zip other.zip')
    assert not match(command)
    command = Command('unzip file.zip other.zip')
    assert not match(command)
    command = Command('unzip file.zip other.zip -d dir')
    assert not match(command)
    command = Command('unzip file.zip')
    _zip_file = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), 'file.zip')
    assert match(command)
    command = Command('unzip file')

# Generated at 2022-06-12 11:15:32.400593
# Unit test for function match
def test_match():
    assert match(Command(script='unzip -l test_zip.zip', stderr='test_zip.zip')) == True
    assert match(Command(script='unzip test_zip.zip', stderr='test_zip.zip')) == True
    assert match(Command(script='unzip test_zip', stderr='test_zip')) == True
    assert match(Command(script='unzip -t test_zip', stderr='test_zip')) == False
    assert match(Command(script='unzip test_zip.zip test_zip2.zip', stderr='test_zip.zip test_zip2.zip')) == True


# Generated at 2022-06-12 11:15:40.497500
# Unit test for function match
def test_match():
    res = match(Command('unzip /home/user/b.zip', '', ''))
    assert res is False
    res = match(Command('unzip /home/user/b.zip -d /home/user/c', '', ''))
    assert res is False
    res = match(Command('unzip /home/user/b.zip a', '', ''))
    assert res is True
    res = match(Command('unzip /home/user/b.zip a', '', ''))
    assert res is True
    res = match(Command('unzip /home/user/b.zip a', '', ''))
    assert res is True
    res = match(Command('unzip /home/user/b.zip a', '', ''))
    assert res is True


# Generated at 2022-06-12 11:15:43.806825
# Unit test for function match
def test_match():
    assert match(Command('unzip test.zip'))
    assert match(Command('unzip test.zip -o'))
    assert not match(Command('unzip test.zip -d dir'))
    assert not match(Command('unzip test.zip directory'))



# Generated at 2022-06-12 11:15:53.333566
# Unit test for function side_effect
def test_side_effect():
    from thefuck.types import Command
    from thefuck.conf import settings

    # no directories
    side_effect(Command('', 'unzip   file.zip'),
                Command('', 'unzip   file.zip -d .'))

    # with a directory already
    os.mkdir('foo')
    side_effect(Command('', 'unzip   file.zip'),
                Command('', 'unzip   file.zip -d foo'))

    # with a directory already and the setting checked
    settings.warn_on_directory_change = True
    side_effect(Command('', 'unzip   file.zip'),
                Command('', 'unzip   file.zip -d foo'))

    # with a directory already and the setting checked, but we're force

# Generated at 2022-06-12 11:16:02.153762
# Unit test for function side_effect
def test_side_effect():
    import tempfile
    directory = tempfile.mkdtemp()
    print(directory)
    with open(directory + '/foo.txt', 'w') as fp:
        fp.write('foo')
    with zipfile.ZipFile(directory + '/foo.zip', 'w') as fp:
        fp.write('foo')
    os.chdir(directory)
    old_cmd = type('old_cmd', (), {"script": "unzip foo.zip", "script_parts": ["unzip","foo.zip"]})
    command = type('command', (), {"script": "unzip -d foo foo.zip", "script_parts": ["unzip","-d","foo","foo.zip"]})
    side_effect(old_cmd, command)
    assert os.path.exists(directory + '/foo')

# Generated at 2022-06-12 11:16:10.624232
# Unit test for function match
def test_match():
    assert match(
        Command('unzip linux-4.2.3.zip', '', 'linux-4.2.3'))
    assert match(
        Command('unzip linux-4.2.3.zip', '', 'linux-4.2.3/'))
    assert match(
        Command('unzip linux-4.2.3.zip', '', 'linux-4.2.3/Makefile'))
    assert match(
        Command('unzip linux-4.2.3.zip', '', 'linux-4.2.3/scripts'))
    assert match(
        Command('unzip linux-4.2.3.zip', '', 'linux-4.2.3/scripts/mod'))

# Generated at 2022-06-12 11:16:15.808657
# Unit test for function match
def test_match():
    assert match(Command('unzip file.zip', ''))
    assert match(Command('unzip file.zip archive.zip', ''))
    assert not match(Command('unzip file.zip -d dest', ''))
    assert not match(Command('unzip file.zip archive.zip -d dest', ''))
    assert not match(Command('unzip', ''))
    assert not match(Command('unzip file.zip missing.zip', ''))



# Generated at 2022-06-12 11:16:49.553490
# Unit test for function match
def test_match():
    assert match(Command('unzip script.zip'))
    assert not match(Command('unzip script.zip -d script'))
    assert match(Command('unzip script'))
    assert not match(Command('unzip -d script script.zip'))
    assert not match(Command('unzip script.zipped'))
    assert match(Command('unzip script.zip file.file'))

# Generated at 2022-06-12 11:16:59.413609
# Unit test for function match
def test_match():
    from thefuck.shells import bash
    from thefuck.types import Command, CorrectedCommand
    from tests.utils import Rule, Mock

    assert match(Command('unzip dir/filename.zip'))
    assert not match(Command('rm dir/filename.zip'))
    assert not match(Command('unzip filename.zip'))
    assert not match(Command('unzip -d dir/filename.zip'))

    with Mock(bash, '_is_bad_zip', return_value=True):
        assert match(Command('unzip filename.zip'))

    assert match(Command('unzip filename.zip'))
    with Mock(bash, '_is_bad_zip', return_value=False):
        assert not match(Command('unzip filename.zip'))


# Generated at 2022-06-12 11:17:04.022049
# Unit test for function side_effect
def test_side_effect():
    with patch('os.remove') as remove:
        with patch('os.path.abspath') as abspath:
            abspath.return_value = False
            side_effect(None, None)
            remove.assert_not_called()

            abspath.return_value = True
            side_effect(None, None)
            remove.assert_called_once_with('file')

# Generated at 2022-06-12 11:17:11.723145
# Unit test for function side_effect
def test_side_effect():
    from thefuck.rules.unzip_to_current_dir import side_effect
    import tempfile
    import zipfile
    tdir = tempfile.mkdtemp()
    tempfile.mkdtemp(dir=tdir)
    cdir = os.getcwd()
    os.chdir(tdir)

# Generated at 2022-06-12 11:17:22.232467
# Unit test for function side_effect
def test_side_effect():
    # Unit test for function side_effect
    import os

    test_dir = 'test_dir'
    if not os.path.exists(test_dir):
        os.mkdir(test_dir)
    f = open(test_dir + '/test.txt', 'w+')
    f.close()
    zip_file = test_dir + '.zip'
    with zipfile.ZipFile(zip_file, 'w') as archive:
        archive.write(test_dir + '/test.txt')
    side_effect(zip_file, 'unzip -d ' + test_dir)
    os.remove(zip_file)
    assert os.path.exists(test_dir + '/test.txt')
    os.remove(test_dir + '/test.txt')
    os.rmdir(test_dir)

# Generated at 2022-06-12 11:17:26.403216
# Unit test for function match
def test_match():
    assert not match(Command('unzip -d foo.zip', '', ''))
    assert not match(Command('unzip foo', '', ''))
    assert match(Command('unzip foo.zip', '', ''))
    assert match(Command('unzip foo', '', ''))
    assert not match(Command('unzip foo.zipx', '', ''))



# Generated at 2022-06-12 11:17:33.167755
# Unit test for function side_effect
def test_side_effect():
    from thefuck.shells import shell
    from subprocess import PIPE, Popen, CalledProcessError

    # Command and working directory
    cwd = "/home/remy/thefuck/thefuck/"
    cmd_echo = "cd "+ cwd +"; echo 'foo'"
    cmd_unzip = "cd "+ cwd +"; unzip -o -qq thefuck.zip"

    # Create zip file and remove it afterwards
    p = Popen(cmd_echo, shell=True, stdout=PIPE)
    output = p.communicate()[0]
    p = Popen("zip thefuck.zip " + output, shell=True, stdout=PIPE)
    output = p.communicate()[0]

    # Unzip into ZipFile object

# Generated at 2022-06-12 11:17:39.949235
# Unit test for function side_effect

# Generated at 2022-06-12 11:17:49.703586
# Unit test for function side_effect
def test_side_effect():
    test_dir = os.path.dirname(os.path.realpath(__file__)) + "/testdir"
    if not os.path.exists(test_dir):
        os.makedirs(test_dir)

    dir_name = os.path.basename(os.path.normpath(test_dir)) + "/"
    file_one = dir_name + "file_one.txt"
    file_two = dir_name + "file_two.txt"
    file_three = dir_name + "file_three.txt"
    file_four = dir_name + "file_four.txt"

    test_zip = test_dir + "/" + "test.zip"
    archive = zipfile.ZipFile(test_zip, 'w')
    archive.write(file_one)

# Generated at 2022-06-12 11:17:51.371464
# Unit test for function side_effect
def test_side_effect():
    output = side_effect(shell, shell.and_('cd ~', 'unzip -d'), 'ls -F /')
    assert output == None