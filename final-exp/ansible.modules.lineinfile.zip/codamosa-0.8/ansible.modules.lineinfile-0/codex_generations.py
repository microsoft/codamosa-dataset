

# Generated at 2022-06-11 07:21:36.332855
# Unit test for function main

# Generated at 2022-06-11 07:21:37.211717
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-11 07:21:44.778259
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    dest = '/tmp/testfile.txt'
    b_lines = [b'abc\n', b'123\n', b'xyz\n']
    write_changes(module, b_lines, dest)

    assert(os.path.exists(dest))
    with open(dest) as f:
        content = f.read();

    assert(content == 'abc\n123\nxyz\n')
    os.unlink(dest)

# from ansible.module_utils.parsing.convert_bool import boolean
# These are Ansible native Python 3 class objects.  This helps avoid Python 2 and Python 3 issues.
import numbers

# The following is required for Ansible 2.9 and later
# from ansible.module_utils.six import string_types
# And is

# Generated at 2022-06-11 07:21:50.609807
# Unit test for function main

# Generated at 2022-06-11 07:21:55.782104
# Unit test for function main
def test_main():
    assert main()


# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.six import iteritems
from ansible.module_utils._text import to_bytes, to_native
from ansible.module_utils.parsing.convert_bool import boolean
from ansible.module_utils.pycompat24 import get_exception
from ansible.module_utils.six.moves import StringIO
from ansible.module_utils.six import string_types
from ansible.module_utils.six.moves import shlex_quote, zip
from ansible.module_utils.unicode import unicode_wrap
from ansible.module_utils.selection_list import list_choice_filter
from ansible.module_utils.urls import url_argument_spec, open_url

# Generated at 2022-06-11 07:22:02.210544
# Unit test for function check_file_attrs
def test_check_file_attrs():
    content = """#!/usr/bin/python
    # This is not a real python file.
    class LineinfileModule:
        """
    module = AnsibleModule(argument_spec=dict())

    setattr(module, 'params', {
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'selinux_user': 'system_u',
        'selinux_role': 'object_r',
        'selinux_type': 'etc_t'
    })

    m_tmpdir = tempfile.mkdtemp()

    setattr(module, 'tmpdir', m_tmpdir)
    m_tmpfd, m_tmpfile = tempfile.mkstemp(dir=module.tmpdir)

# Generated at 2022-06-11 07:22:12.329992
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({},
                               check_invalid_arguments=False,
                               no_log=True)
    b_lines = [to_bytes(u'127.0.0.1 foo\n', errors='surrogate_or_strict'),
               to_bytes(u'127.0.0.2 bar\n', errors='surrogate_or_strict'),
               to_bytes(u'127.0.0.3 baz\n', errors='surrogate_or_strict')]
    write_changes(module, b_lines, '/tmp/testfile')
    with open('/tmp/testfile', 'rb') as f:
        b_out = f.readlines()

    assert(b_lines == b_out)



# Generated at 2022-06-11 07:22:12.870391
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:22:15.676474
# Unit test for function present
def test_present():
    assert present(module, dest, regexp, search_string, line, insertafter, insertbefore, create, backup, backrefs, firstmatch) == 'true'
test_present()



# Generated at 2022-06-11 07:22:26.353666
# Unit test for function main
def test_main():
  params = dict(
    create=False,
    backup=False,
    backrefs=False,
    path='/home/vagrant/ansible/ansible-workspace/exercise/solution/playbooks/roles/system_config/templates/sshd_config',
    firstmatch=False,
    regexp="^PermitRootLogin\\s+yes",
    search_string="",
    line="PermitRootLogin no",
  )

# Generated at 2022-06-11 07:22:53.654518
# Unit test for function absent
def test_absent():
    testdest = tempfile.mktemp()
    with open(testdest, 'w') as f:
        f.write("""line 1
line 2
line 3
line 4
line 5
line 6
line 7
line 8
line 9
line 10""")

    testline = 'line 2'

    module = AnsibleModule(
        argument_spec = dict(
            state         = dict(default='present', choices=['absent']),
            dest          = dict(type='path'),
            regexp        = dict(),
            search_string = dict(),
            line          = dict(),
            backup        = dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    module.params['dest'] = testdest
    module.params['line'] = testline

# Generated at 2022-06-11 07:22:59.076872
# Unit test for function write_changes
def test_write_changes():
    unit_test_config_file_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'units'))
    importlib.import_module('ansible.modules.files.lineinfile.test_lineinfile', unit_test_config_file_path)



# Generated at 2022-06-11 07:23:02.597051
# Unit test for function absent
def test_absent():
    assert absent('/etc/passwd', regexp=None, search_string=None, line='foo', backup=None) == False
    assert absent('/etc/passwd', regexp=None, search_string=None, line='root', backup=None) == True


# Generated at 2022-06-11 07:23:13.987038
# Unit test for function main

# Generated at 2022-06-11 07:23:25.377966
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 07:23:31.814038
# Unit test for function write_changes
def test_write_changes():
    # Unit test for function write_changes
    module = AnsibleModule(
        argument_spec=dict(
            backup=dict(type='bool', default=False),
            content=dict(type='str', aliases=['value']),
            dest=dict(type='path', required=True),
            force=dict(type='bool', default=False, aliases=['thirsty']),
            others=dict(type='str'),
            validate=dict(type='str'),
        )
    )
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: True
    write_changes(module, to_bytes('#!/bin/sh\n', errors='surrogate_or_strict'), '/dest/file')

# Generated at 2022-06-11 07:23:38.609274
# Unit test for function write_changes
def test_write_changes():
    # Create a custom module with correct parameters
    module_args = dict(dest='/tmp/test', line='test line')

    module = AnsibleModule(argument_spec=module_args, check_invalid_arguments=False)

    b_lines = [b'test line1\n']
    dest = '/tmp/test'

    write_changes(module, b_lines, dest)

    with open('/tmp/test', 'rb') as f:
        lines = f.readlines()
        assert lines == b_lines



# Generated at 2022-06-11 07:23:50.955270
# Unit test for function present
def test_present():
    # Need to mock module for args.
    module = AnsibleModule({'dest': 'dest.txt', 'regexp': '^(a=).*', 'line': 'test', 'create': True})
    # Unit test for case where the file does not exist, and the line is added.
    if not os.path.exists('dest.txt'):
        with open('dest.txt', 'w') as f:
            f.write('')
        present(module)
        with open('dest.txt', 'r') as f:
            assert f.readlines() == ['test\n']
        os.remove('dest.txt')
    # Unit test for case where the file exists and the line is added at the end.

# Generated at 2022-06-11 07:23:59.301650
# Unit test for function check_file_attrs
def test_check_file_attrs():
    result = dict(
        changed=True,
        mode='0644',
        owner='foo',
        group='bar',
        seuser='baz',
        serole='qux',
        selevel='quux',
        setype='quuz'
    )
    module = AnsibleModule(argument_spec={})
    message = ''
    changed = False
    diff = {}
    result = check_file_attrs(module, changed, message, diff)
    assert(result[0] == '')
    assert(result[1] == False)



# Generated at 2022-06-11 07:24:00.782660
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:24:41.452410
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import json
    import copy
    import os

    module_name = 'lineinfile'
    if os.path.exists('.unit-tests'):
        fixture_path = os.path.join('.unit-tests', 'fixtures',
                                    'ansible_module_%s.json' % module_name)
    else:
        fixture_path = os.path.join('test', 'units', 'module_utils',
                                    'fixtures',
                                    'ansible_module_%s.json' % module_name)
    with open(fixture_path) as f:
        unit_test_fixtures = json.load(f)

    module = AnsibleModule({})
    module.params = dict()

# Generated at 2022-06-11 07:24:49.188564
# Unit test for function main
def test_main():
    args = {
        'state': 'present',
        'path': 'file.txt',
        'regexp': 'regex',
    }

    def test_present():
        with pytest.raises(AnsibleFailJson):
            present(None, **args)

    test_present()

    args[u'backrefs'] = True
    args[u'line'] = 'line'
    test_present()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:25:00.065699
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Testing with different parameters
    module = AnsibleModule(argument_spec={'src': dict(type='path'), 'dest': dict(type='path'), 'unsafe_writes': dict(type='bool', default=False), 'owner': dict(), 'group': dict(), 'mode': dict(), 'selevel': dict(), 'serole': dict(), 'setype': dict(), 'seuser': dict(), 'backup': dict(type='bool', default=False)})
    # Testing with changed=True, diff=None
    assert check_file_attrs(module, True, "test_message", None) == ("test_message and ownership, perms or SE linux context changed", True)
    # Testing with changed=False, diff=None

# Generated at 2022-06-11 07:25:10.897450
# Unit test for function main

# Generated at 2022-06-11 07:25:22.817190
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # check_file_attrs should return (message, changed)
    # check_file_attrs(module, changed, message, diff)
    # TODO: mock module
    module = AnsibleModule(argument_spec=dict())
    message = "test"
    changed = True
    diff = False
    assert check_file_attrs(module, changed, message, diff) == (message, changed)
    changed = False
    diff = True
    assert check_file_attrs(module, changed, message, diff) == (message, changed)
    changed = True
    diff = True
    assert check_file_attrs(module, changed, message, diff) == (message, True)
    changed = False
    diff = False
    assert check_file_attrs(module, changed, message, diff) == (message, False)



# Generated at 2022-06-11 07:25:23.970849
# Unit test for function present
def test_present():
    assert callable(present)


# Generated at 2022-06-11 07:25:34.648078
# Unit test for function main

# Generated at 2022-06-11 07:25:43.601607
# Unit test for function main
def test_main():
    module = MagicMock()
    #Input Params
    params = {
        'state': 'present',
        'path': 'path',
        'backrefs': False,
        'create': False,
        'backup': False,
        'firstmatch': False,
        'validate': None,
        'regexp': None,
        'search_string': None,
        'line': None,
        'insertafter': None,
        'insertbefore': None
    }
    module.params = params
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:25:52.058873
# Unit test for function write_changes

# Generated at 2022-06-11 07:25:59.987516
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'unsafe_writes': {'type': 'bool', 'default': False},
    })
    b_lines = [b'test1\n', b'test2\n']
    dest = '/tmp/fake'
    write_changes(module, b_lines, dest)
# end of unit test for function write_changes


# Generated at 2022-06-11 07:26:49.421510
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec=dict(
        src=dict(type='path'),
        dest=dict(type='path'),
        validate=dict(type='str'),
        unsafe_writes=dict(type='bool', default=False),
        backup=dict(type='bool', default=False),
    ))

    ret = dict(changed=False, msg="")
    dest = '/tmp/test_file'
    src = '/tmp/test_src_file'
    lines = ['foo\n', 'bar\n', 'baz\n']

    # Create source file
    with open(src, 'wb') as f:
        f.writelines(lines)

    # Copy source to destination
    module.copy(src, dest)
    validate = 'grep foo %s'
    valid = not validate

# Generated at 2022-06-11 07:27:00.283716
# Unit test for function present
def test_present():
    file = open("/tmp/ansible_lineinfile_test", "w")
    file.write("\n")
    file.close()

# Generated at 2022-06-11 07:27:02.324384
# Unit test for function check_file_attrs
def test_check_file_attrs():
    """Check behaviour of check_file_attrs()"""
    check_file_attrs(module, changed, message, diff)



# Generated at 2022-06-11 07:27:03.451540
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(None, False, 'msg', {}) == ('msg', False)



# Generated at 2022-06-11 07:27:04.959531
# Unit test for function absent
def test_absent():
    assert absent(module, dest, regexp, search_string, line, backup) == False


# Generated at 2022-06-11 07:27:10.225705
# Unit test for function absent
def test_absent():
    dest = 'test_absent'
    with open(dest, 'w') as fd:
        fd.write('test1\ntest2\ntest1\ntest3\n')
    module = FakeModule(dest=dest, regexp='test1')
    absent(module, dest, regexp='test1', search_string=None, line=None, backup=False)
    with open(dest, 'r') as fd:
        lines = fd.readlines()
    assert lines == ['test2\n', 'test3\n']
    # cleanup
    os.remove(dest)



# Generated at 2022-06-11 07:27:20.469148
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest = dict(type='str', required=True),
            regexp = dict(type='str'),
            search_string = dict(type='str'),
            line = dict(type='str'),
            backup = dict(type='bool', default=False),
            state = dict(type='str', default='present', choices=['present', 'absent'])
        ),
        supports_check_mode = True
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    m_absent(module, dest, regexp, search_string, line, backup)



# Generated at 2022-06-11 07:27:30.132544
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
            search_string=dict(type='str')
        ),
        supports_check_mode=True
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    line = module.params['line']
    backup = module.params['backup']
    search_string = module.params['search_string']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-11 07:27:34.151361
# Unit test for function absent
def test_absent():
    # Test with the requested line absent from the file.
    assert absent(module, dest, regexp=None,
                  search_string=None, line='# foo', backup=False) == (False, 0, 'file not present')

# Generated at 2022-06-11 07:27:43.898476
# Unit test for function absent
def test_absent():
    assert(absent(['a','b','c','d'], 'a') == ['b','c','d'])
    assert(absent(['a','b','c','d'], 'a',regexp=True) == ['b','c','d'])
    assert(absent(['a','b','c','d'], 'a',regexp=False) == ['b','c','d'])
    assert(absent(['a','b','c','d'], 'd') == ['a','b','c'])
    assert(absent(['a','b','c','d'], 'b') == ['a','c','d'])
    assert(absent(['a','b','c','d'], 'b',regexp=True) == ['a','c','d'])

# Generated at 2022-06-11 07:30:05.514813
# Unit test for function check_file_attrs
def test_check_file_attrs():
    ####################
    # Replacing with untested stub code:
    # Stub for function check_file_attrs(), which returns a tuple of (__result, __result, __result, __result)
    # __result = (None, True, u'message, ownership, perms or SE linux context changed', None)
    __result = (None, True, u'message, ownership, perms or SE linux context changed', None)
    # End stub code
    ####################
    return __result

# Generated at 2022-06-11 07:30:14.800292
# Unit test for function present

# Generated at 2022-06-11 07:30:23.711185
# Unit test for function write_changes
def test_write_changes():
    """
    write_changes
    """
    data = '''
    line1
    line2
    line3
    line4
    '''
    lines = ['line1\n', 'line2\n', 'line3\n', 'line4\n']
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='path'),
            regexp=dict(required=True),
            line=dict(required=True),
            validate=dict(required=False),
            dest=dict(type='path', aliases=['path', 'destfile', 'name'])
        ),
    )
    write_changes(module, lines, 'path')



# Generated at 2022-06-11 07:30:25.960314
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(['owner', 'group', 'mode', 'seuser', 'serole', 'setype', 'selevel']) == True


# Generated at 2022-06-11 07:30:31.991535
# Unit test for function main

# Generated at 2022-06-11 07:30:41.087860
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            path                     = dict(required=True, type='str'),
        ),
        supports_check_mode=True
    )
    file_args = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644', 'attributes': []}
    changed, message, diff = False, '', ''
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == ''
    assert changed == False
    changed, message, diff = True, 'ownership, perms or SE linux context changed', ''
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == ''
    assert changed == True


# Generated at 2022-06-11 07:30:46.779148
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            dest=dict(type='path', required=True),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            setype=dict(type='str'),
            seexec=dict(type='str'),
            owner=dict(type='str'),
            group=dict(type='str'),
            mode=dict(type='str'),
            unsafe_writes=dict(type='bool', default=True),
        )
    )
    # test_module.set_fs_attributes_if_different = MagicMock(return_value=True)
    test_module.set_fs_attributes_if_different = lambda *args: True

# Generated at 2022-06-11 07:30:51.974260
# Unit test for function write_changes