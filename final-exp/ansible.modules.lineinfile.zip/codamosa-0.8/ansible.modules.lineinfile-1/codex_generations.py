

# Generated at 2022-06-11 07:21:49.338437
# Unit test for function present
def test_present():
    module_present = AnsibleModule({
                                "line": "unit test line",
                                "path": "unit test path",
                                "create": False,
                                "state": "present"
                            })

    assert present(module_present, dest, regexp, search_string, line, insertafter, insertbefore, create,
                   backup, backrefs, firstmatch) == ({
                                "changed": False,
                                "msg": "line added",
                                "backup": "",
                                "diff": {
                                    "before": "",
                                    "after": "",
                                    "before_header": "dest (content)",
                                    "after_header": "dest (content)"
                                }
                            })



# Generated at 2022-06-11 07:21:59.668771
# Unit test for function write_changes
def test_write_changes():
    """
    Uses the mocked module to write tempfile lines to a specified
    temporary file and then validates the file has been written as
    expected.
    """
    module = AnsibleModule(argument_spec={'path': dict(type='str')})
    b_lines = [b'one\n', b'two\n', b'three\n']
    write_changes(module, b_lines, module.params['path'])
    with open(module.params['path'], 'rb') as f_obj:
        contents = f_obj.readlines()
        assert contents == b_lines
    os.remove(module.params['path'])



# Generated at 2022-06-11 07:22:10.676279
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 07:22:19.153036
# Unit test for function main
def test_main():
    import imp
    import os
    import sys
    
    imp.reload(sys)
    try:
        sys.setdefaultencoding('UTF8')
    except (AttributeError, UnicodeDecodeError):
        pass
    
    # Save the original modules so they can be restored if the test fails
    original_modules = list(sys.modules.keys())
    
    # Test parameters
    args = {}
    args['path'] = '/tmp/ansible-test.txt'
    args['state'] = 'present'
    args['regexp'] = None
    args['search_string'] = None
    args['line'] = ' value: abcd\n'
    args['insertafter'] = None
    args['insertbefore'] = None
    args['backrefs'] = False
    args['create'] = False

# Generated at 2022-06-11 07:22:21.150856
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(0,0,0,0) == (0,0)


# Generated at 2022-06-11 07:22:32.503677
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import shutil
    path = './unit-test-check_file_attrs-tmp'
    shutil.copy('../lib/ansible/module_utils/basic.py', path)
    module = AnsibleModule(argument_spec = dict())
    message = ''
    changed = False
    diff = '''diff --git a/a b/b
new file mode 100644
index 0000000..e69de29
'''
    module.params = {'path': path}
    try:
        message, changed = check_file_attrs(module, changed, message, diff)
        assert  message == 'ownership, perms or SE linux context changed'
        assert  changed == True
        os.remove(path)
    except AssertionError as e:
        print(e)

# Generated at 2022-06-11 07:22:34.359663
# Unit test for function main
def test_main():
    assert callable(main)


# Generated at 2022-06-11 07:22:44.920708
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # TODO - use a better mock module
    module = AnsibleModule()

    file_args = dict(
        path=os.path.abspath(os.path.join(os.path.dirname(__file__), '../../lib/ansible/modules/files/')),
        owner="root",
        group="root",
        mode=0o600,
        diff=True
    )

    module.set_fs_attributes_if_different = lambda x, y, diff=True: True

    module.params = file_args.copy()

    # These aren't used but are needed as params by check_file_attrs
    module.params['path'] = "/dev/null"
    module.params['unsafe_writes'] = False

    changed, message, diff = False, "", ""
    message, changed

# Generated at 2022-06-11 07:22:45.494995
# Unit test for function check_file_attrs
def test_check_file_attrs():

    assert True



# Generated at 2022-06-11 07:22:58.233628
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'path': '/tmp/testfile',
        'state': 'present',
        '_ansible_module_name': 'test_module',
        '_ansible_module_mock_test': True
    })
    if not os.path.exists(module.params['path']):
        open(module.params['path'], 'a').close()

    with open(module.params['path'], 'rb') as f:
        lines = f.readlines()
    lines = list(map(lambda x: x.decode('utf-8'), lines))
    lines.sort()

    assert not present(module, '/tmp/testfile', r'^# test line', None, '# test line', None, None, False, False, False, False)

# Generated at 2022-06-11 07:23:46.735770
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils._text import to_bytes
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'owner': {'type': 'str'},
        'group': {'type': 'str'},
        'mode': {'type': 'str', 'aliases': ['permissions']},
        'seuser': {'type': 'str'},
        'serole': {'type': 'str'},
        'setype': {'type': 'str'},
        'selevel': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': True},
    })

    (changed, message) = check_file_attrs(module, False, "", None)

# Generated at 2022-06-11 07:23:48.628988
# Unit test for function present
def test_present():
  b = os.path.getsize("/tmp/test")
  assert b > 0

# Generated at 2022-06-11 07:23:57.108248
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            unsafe_writes=dict(default=False, type='bool')
        )
    )
    module.params['path'] = 'somefile.txt'
    module.params['owner'] = 'someowner'
    file_args = module.load_file_common_arguments(module.params)
    file_args['path'] = "somefile.txt"
    assert check_file_attrs(module, False, "", None) == ("ownership, perms or SE linux context changed", True)



# Generated at 2022-06-11 07:24:04.269633
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = FakeAnsibleModule(name='test_check_file_attrs', params={'path':'path', 'owner':'owner', 'group':'group', 'mode':'mode', 'seuser':'seuser', 'serole':'serole', 'setype':'setype', 'selevel':'selevel'})
    module._diff = True
    assert check_file_attrs(module, False, 'message', module._diff) == ('message and ownership, perms or SE linux context changed', True)



# Generated at 2022-06-11 07:24:14.798794
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    file_args = {'path': '/tmp/testfile.txt', 'owner': 'root', 'group': 'root', 'mode': '0644',
                 'seuser': 'user_u', 'serole': 'user_r', 'setype': 'user_t', 'selevel': 's0',
                 'attributes': [ 'owner', 'group', 'mode', 'seuser', 'serole', 'setype', 'selevel'],
                 'unsafe_writes': True}
    test_module.set_fs_attributes_if_different(file_args, False, diff=None)
    assert test_module.params == file_args
    assert test_module.automagic == False
    assert test_module.skip

# Generated at 2022-06-11 07:24:25.290299
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            b_lines=dict(type='raw', required=True),
            validate=dict(type='str', default=None),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=False,
        add_file_common_args=True
    )
    dest = '/tmp/lineinfile_test_file'
    b_lines = [b'XDW2.0']
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        lines = f.readlines()
        assert lines == b_lines


# Generated at 2022-06-11 07:24:37.108272
# Unit test for function write_changes
def test_write_changes():
    # Removing a file before the test so we have a clear test environment
    os.remove('/tmp/config')

    # Test writing a single line to the file
    lines = ['host=127.0.0.1\n']
    write_changes('', lines, '/tmp/config')

    # Test writing a single line to the file with a backslash and quotes
    lines = ['host="10.1.1.1:443"\n']
    write_changes('', lines, '/tmp/config')

    # Test writing multiple lines to the file
    lines = ['host=127.0.0.1\n', 'port=80\n']
    write_changes('', lines, '/tmp/config')

    # Test writing multiple lines to the file with a backslash and quotes

# Generated at 2022-06-11 07:24:46.911671
# Unit test for function main
def test_main():
    import StringIO
    import sys

    class AnsibleModuleMock(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            sys.exit(1)

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            sys.exit(0)

    stdout = sys.stdout
    sys.stdout = StringIO.StringIO()
    atexit.register(lambda: setattr(sys, 'stdout', stdout))

# Generated at 2022-06-11 07:24:58.549778
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            regexp=dict(default=None),
            search_string=dict(default=None),
            line=dict(required=True, aliases=['value']),
            insertafter=dict(default=None),
            insertbefore=dict(default=None),
            create=dict(required=False, type='bool', default=False),
            backup=dict(default=True, type='bool'),
            backrefs=dict(default=False, type='bool'),
            firstmatch=dict(default=True, type='bool'),
            validate=dict(default=None)
        )
    )

    # Create test file
    dest = module.params['path']

# Generated at 2022-06-11 07:25:07.938391
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
            argument_spec=dict(
                dest=dict(required=True),
                regexp=dict(required=False),
                search_string=dict(required=False),
                line=dict(required=False),
                backup=dict(required=False, default=False)
            ),
            supports_check_mode=True
    )
    # test line
    module.absent(dest="test", line="test content")
    module.absent(dest="test", regexp="test content")
    module.absent(dest="test", search_string="test content")
    module.absent(dest="test", line="test content", backup=True)
    # test empty file


# Generated at 2022-06-11 07:25:52.918199
# Unit test for function absent
def test_absent():
    assert 1 == 2



# Generated at 2022-06-11 07:26:01.310687
# Unit test for function absent
def test_absent():

    test_lines = ['line 1\n', 'line 2\n','line 3\n']
    assert absent(test_lines, 'line 3\n') == ['line 1\n', 'line 2\n']
    assert absent(test_lines, 'line 1\n') == ['line 2\n','line 3\n']
    assert absent(test_lines, 'line 2\n') == ['line 1\n', 'line 3\n']

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:26:03.484325
# Unit test for function write_changes
def test_write_changes():
    result = write_changes(module, b_lines, dest)
    assert result == 'Error'


# Generated at 2022-06-11 07:26:15.506252
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    test_module.params['path'] = '/foo/bar/baz.txt'
    test_module.params['owner'] = 'root'
    test_module.params['group'] = 'root'
    test_module.params['mode'] = '0777'
    test_module.params['seuser'] = 'root'
    test_module.params['serole'] = 'root'
    test_module.params['setype'] = 'root'
    test_module.params['selabel'] = 'system_u:object_r:admin_home_t:s0'
    test_module.set_fs_attributes_if_different = lambda file_args, changed, diff: True
    (message, changed) = check_file

# Generated at 2022-06-11 07:26:16.453204
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-11 07:26:17.064480
# Unit test for function write_changes
def test_write_changes():
  assert True



# Generated at 2022-06-11 07:26:19.550629
# Unit test for function main
def test_main():
    """ Unit test for function main """
    try:
        assert(True)
    except AssertionError:
        print('Unit test for function main failed')

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:26:25.015408
# Unit test for function main

# Generated at 2022-06-11 07:26:34.232096
# Unit test for function write_changes
def test_write_changes():
    # mock module for this function
    module = AnsibleModule(argument_spec={})
    # create a temp file
    (handle, tmpfile) = tempfile.mkstemp(dir=tempfile.gettempdir())
    os.close(handle)
    # write lines to the file
    lines = b"one\ntwo\nthree\n"
    with open(tmpfile, 'wb') as f:
        f.write(lines)
    # change two lines in the file
    new_lines = b"one\nTWO\nthree\n"
    # run function under test
    write_changes(module, new_lines, tmpfile)
    # verify result
    with open(tmpfile, 'rb') as f:
        updated_lines = f.readlines()
    assert new_lines == updated_lines
    #

# Generated at 2022-06-11 07:26:35.922955
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(None, False, 'foo', None) == ('foo', False)



# Generated at 2022-06-11 07:28:09.591443
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', choices=BOOLEANS, default=False),
        ),
        supports_check_mode=True
    )
    dest = os.path.dirname(os.path.dirname(__file__))+'/line_inject_tests/test_absent_file.txt'
    regexp = None
    search_string = None
    line = 'abc'
    backup = False

    absent(module, dest, regexp, search_string, line, backup)



# Generated at 2022-06-11 07:28:19.312812
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Test with module_params contains 'owner', 'group' and 'mode'
    module_params = {'owner': 'root', 'group': 'root', 'mode': '0644'}
    module = MockFileCommon(module_params=module_params)
    changed = True
    message = "ownership, perms or SE linux context changed"
    diff = {'attributes': {}, 'before_header': '', 'diff': [], 'before': ''}
    result = check_file_attrs(module, changed, message, diff)
    assert result == ('ownership, perms or SE linux context changed', True)
# end of unit test check_file_attrs


# Generated at 2022-06-11 07:28:28.884440
# Unit test for function main

# Generated at 2022-06-11 07:28:32.994202
# Unit test for function write_changes
def test_write_changes():
    import locale
    import ansible.module_utils.basic
    setattr(locale, 'LC_ALL', 'en_US.UTF-8')
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={'backup': {'type': 'bool'}, 'content': {'type': 'str'}, 'create': {'default': False, 'type': 'bool'}, 'dest': {'required': True, 'type': 'path'}, 'group': {'default': None, 'type': 'str'}, 'mode': {'default': None, 'type': 'str'}, 'owner': {'default': None, 'type': 'str'}, 'unsafe_writes': {'default': False, 'type': 'bool'}, 'validate': {'default': None, 'type': 'str'}})

# Generated at 2022-06-11 07:28:39.354006
# Unit test for function present
def test_present():

    import os
    import tempfile

# Generated at 2022-06-11 07:28:43.203128
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({
        "validate": None,
        "unsafe_writes": True
    })
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    with os.fdopen(tmpfd, 'wb') as f:
        f.writelines('test\n'.encode())
    dest = tmpfile+'.test'
    write_changes(module, 'test\n'.encode(), dest)
    assert os.path.exists(to_bytes(dest, errors='surrogate_or_strict')) == True



# Generated at 2022-06-11 07:28:52.619033
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='str'),
            regexp = dict(type='str'),
            line = dict(type='str'),
        )
    )

    path = "unit_test_file"
    regexp = r"^#\s*\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\s+test"
    line = "test"

    with open(path, "w") as f:
        f.write("# 10.63.31.178 test\n")
        f.write("test\n")
        f.write("test\n")
        f.write("test\n")
        f.write("test\n")
        f.write("test\n")



# Generated at 2022-06-11 07:29:00.964677
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True, aliases=['name']),
            regexp=dict(required=False),
            search_string=dict(required=False),
            line=dict(required=False, type='raw'),
            backup=dict(required=False, default=False, type='bool'),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-11 07:29:02.682964
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
        )
    )
    write_changes(module, b'{}', 'dest')



# Generated at 2022-06-11 07:29:07.153900
# Unit test for function present
def test_present():
    from ansible.modules.files import lineinfile 
    module = lineinfile.__new__(lineinfile.AnsibleModule)