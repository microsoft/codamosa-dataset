

# Generated at 2022-06-11 07:21:54.193049
# Unit test for function present
def test_present():
  module = AnsibleModule(argument_spec={'dest': {"required": True},'regexp': {'required': False},'search_string': {'required': False},'line': {'required': True},'insertbefore': {'required': False},
  'insertafter': {'required': False},'create': {'required': False},'backup': {'required': False},'backrefs': {'required': False},'firstmatch': {'required': False},'validate': {'required': False}})
  res = present(module, dest = 'testfile', regexp=None, search_string=None, line='testline', insertafter=None, insertbefore=None, create=None, backup=None, backrefs=None, firstmatch=None)
  assert res['changed'] is True

# Generated at 2022-06-11 07:21:56.690487
# Unit test for function absent
def test_absent():
    assert absent(sys.modules[__name__], "module", regexp=None, search_string=None, line="module", backup=False) == None

# Generated at 2022-06-11 07:22:08.363393
# Unit test for function main
def test_main():
  path = 'path'
  params = {
    'backrefs': False,
    'backup': False,
    'create': False,
    'dest': 'dest',
    'destfile': 'destfile',
    'firstmatch': False,
    'insertafter': 'insertafter',
    'insertbefore': 'insertbefore',
    'line': 'line',
    'name': 'name',
    'regex': 'regex',
    'regexp': 'regexp',
    'search_string': 'search_string',
    'state': 'present',
    'validate': 'validate',
  }
  main(path, params)


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:22:18.657948
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})

    module.params['path'] = '/tmp/testfile'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '644'

    changed = False
    message = ''
    # empty file
    with open(module.params['path'], 'w') as f:
        f.write('')
    message, changed = check_file_attrs(module, changed, message, [])
    assert message == 'ownership, perms or SE linux context changed'
    assert changed

    changed = False
    message = ''
    # file with content
    with open(module.params['path'], 'w') as f:
        f.write('#/bin/bash')
    message, changed = check

# Generated at 2022-06-11 07:22:30.124048
# Unit test for function main

# Generated at 2022-06-11 07:22:42.519349
# Unit test for function absent
def test_absent():
    """
    Ansible file module unit tests for absent function
    """

    class ReturnInfo:
        """
        Class to set information for test only
        """
        changed = 0
        found = 0
        msg = ''
        backup = ''
        diff = []

    module = AnsibleModule({'backup': False},
                           check_invalid_arguments=False)
    module.params = {
        'dest': 'test.txt',
        'line': 'test',
        'backup': False,
        'regexp': None,
        'search_string': None
    }

    module.backup_local = lambda arg1: 'test.txt.%s' % datetime.datetime.now().isoformat()
    module.exit_json = lambda arg1: None
    module.warn = lambda msg: None


# Generated at 2022-06-11 07:22:53.534875
# Unit test for function present
def test_present():
    assert present(module, None, None, None, None, None, None, None, None, None, None) is None
    assert present(module, 'hello', 'world', None, None, None, None, None, None, None, None) is None
    assert present(module, 'hello', 'world', 'test', None, None, None, None, None, None, None) is None
    assert present(module, 'hello', 'world', 'test', 'test', None, None, None, None, None, None) is None
    assert present(module, 'hello', 'world', 'test', 'test', 'test', None, None, None, None, None) is None
    assert present(module, 'hello', 'world', 'test', 'test', 'test', 'test', None, None, None, None) is None

# Generated at 2022-06-11 07:23:03.664593
# Unit test for function present
def test_present():
    import sys
    import os
    import re
    import subprocess
    import tempfile
    module = 'lineinfile'
    current_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(current_dir + '/unit_tests/')
    from unit_test_utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase

    test_file_name = 'present_test_file'
    test_file_path = os.path.join(current_dir, test_file_name)
    test_file_content = '''line1
line2
line3
line4
'''

    test_file_content_replace = '''line1
line2
line3
line4
'''

    def setUp(self):
        import shutil


# Generated at 2022-06-11 07:23:12.494436
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'dest': '/tmp/foo',
        'backup': False,
        'state': 'present',
        'line': '#test',
        'create': True,
        'regexp': None,
        'search_string': None,
        'insertafter': None,
        'insertbefore': None,
    })

    present(module=module, dest='/tmp/foo', regexp=None, search_string=None, line='#test', insertafter=None,
            insertbefore=None, create=True, backup=False, backrefs=False, firstmatch=False)


# Generated at 2022-06-11 07:23:22.471732
# Unit test for function absent
def test_absent():
    module = FakeANSIModule()
    assert absent(module, '/test.conf', None, 'hello', 'hello', True) == {'changed': True, 'found': 1, 'msg': '1 line(s) removed', 'backup': ''}
    assert absent(module, '/test.conf', 'hello', None, 'hello', True) == {'changed': True, 'found': 1, 'msg': '1 line(s) removed', 'backup': ''}
    assert absent(module, '/test.conf', None, None, 'hello', True) == {'changed': True, 'found': 1, 'msg': '1 line(s) removed', 'backup': ''}


# Generated at 2022-06-11 07:23:52.463162
# Unit test for function write_changes
def test_write_changes():

    module = AnsibleModule(argument_spec={
        'arg1': {'type': 'str'},
        'arg2': {'type': 'str'},
        'arg3': {'type': 'bool', 'default': False},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False, 'required': False}
    })

    data_string = "data_string"
    dest = "/tmp/test_file.txt"
    write_changes(module, data_string, dest)



# Generated at 2022-06-11 07:24:03.870275
# Unit test for function present
def test_present():
    dest = to_bytes(os.path.join(tempfile.gettempdir(), 'testfile'))
    regexp = to_bytes('^(.*)Xms(\d+)m(.*)$')
    line = to_bytes('\1Xms' + str(xms) + 'm\3')
    insertafter = to_bytes('^# JAVA_OPTS')
    insertbefore = to_bytes(None)
    create = False
    backup = False
    backrefs = False
    firstmatch = False
    destpath = os.path.dirname(dest)
    if not os.path.exists(dest):
        if not create:
            module.fail_json(rc=257, msg='Destination %s does not exist !' % dest)

# Generated at 2022-06-11 07:24:14.552648
# Unit test for function check_file_attrs
def test_check_file_attrs():
    """
    Unit test to check the file attributes
    """

    # Sample data
    message = "My message"
    changed = True
    diff = {"after":"test"}

    # Create a instance of ansible module

# Generated at 2022-06-11 07:24:22.151367
# Unit test for function main
def test_main():

    path = "accounts.txt"
    state = "present"
    regexp = "^\\s*#"
    search_string = "username"
    line = "username"
    ins_bef = "^alias"
    ins_aft = "^alias"
    create = True
    backup = True
    backrefs = True
    firstmatch = True

    main(path, state, regexp, search_string, line, ins_bef, ins_aft, create, backup, backrefs, firstmatch)


# Generated at 2022-06-11 07:24:26.590203
# Unit test for function present
def test_present():
    return None

# import module snippets
from ansible.module_utils.basic import AnsibleModule

# import module snippets
from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils._text import to_bytes, to_native, to_text



# Generated at 2022-06-11 07:24:38.106447
# Unit test for function present

# Generated at 2022-06-11 07:24:45.115214
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str', required=True),
            search_string=dict(type='str', required=True),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False)
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-11 07:24:56.264880
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            lines=dict(type='list', required=True),
        ),
    )
    dest = 'test_write_changes'
    lines = module.params['lines']
    rc, out, err = module.run_command('touch %s' % dest)
    if rc != 0:
        module.fail_json(msg="failed to touch test_write_changes: %s" % out)
    write_changes(module, [to_bytes(x) for x in lines], dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == [to_bytes(x) for x in lines]



# Generated at 2022-06-11 07:25:03.215542
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class _module(object):
        def __init__(self):
            self.params = dict(path='/test/foo')
        def fail_json(self, *args, **kwargs):
            raise Exception(args, kwargs)
        def set_fs_attributes_if_different(self, a, *args, **kwargs):
            self.set_fs_attrs = a
            return True
        def load_file_common_arguments(self, params):
            self.common_args = params
            return params
    m = _module()
    changed, message, diff = False, "", ""
    assert check_file_attrs(m, changed, message, diff) == ("ownership, perms or SE linux context changed", True)
    assert m.common_args == m.params
    assert m.set

# Generated at 2022-06-11 07:25:08.842451
# Unit test for function present
def test_present():
    with pytest.raises(SystemExit):
        present(module, 'foo', None, None,
                'line', 'after', 'before', 'create',
                'backup', 'backrefs', 'firstmatch')
    module.exit_json.assert_called_with(changed='changed', msg='msg', backup='backupdest', diff='diff')



# Generated at 2022-06-11 07:25:49.676003
# Unit test for function present
def test_present():
    dest = "/tmp/dest"
    regexp = None
    search_string = None
    line = "line"
    insertafter = None
    insertbefore = None
    create = None
    backup = None
    backrefs = None
    firstmatch = None

    def mocked_module(**kwargs):
        module = MagicMock()
        module.params = kwargs
        module.check_mode = False
        module._diff = True
        module._socket_path = '/opt/ansible/module.sock'
        module.atomic_move = MagicMock()
        module.run_command = MagicMock()
        module.backup_local = MagicMock()
        module.set_fs_attributes_if_different = MagicMock()
        module.fail_json = MagicMock()
        module.exit

# Generated at 2022-06-11 07:26:01.885752
# Unit test for function present

# Generated at 2022-06-11 07:26:10.288216
# Unit test for function write_changes
def test_write_changes():
    '''
    Generate files and test write_changes function
    '''
    module = AnsibleModule(
        argument_spec=dict(
            content=dict(type='str', required=True),
            dest=dict(type='path', required=True),
        ),
    )
    content = module.params.get('content')
    dest = module.params.get('dest')
    b_lines = to_bytes(content)
    write_changes(module, b_lines, dest)


# Generated at 2022-06-11 07:26:11.357528
# Unit test for function write_changes
def test_write_changes():  
    write_changes(dest)


# Generated at 2022-06-11 07:26:20.576734
# Unit test for function main
def test_main():
    for param in ('regexp', 'search_string'):
        yield (run_ansible, dict(
            arguments = dict(
                path='/tmp/test.txt',
                state='present',
                line='hi',
                **{param: ''}
            ),
            output = dict(
                warn = 'The %s is an empty string' % param
            ),
            rc = 0
        ))
        yield (run_ansible, dict(
            arguments = dict(
                path='/tmp/test.txt',
                state='present',
                line='hi',
                backrefs=True,
                **{param: ''}
            ),
            output = dict(
                fail_json_msg = 'regexp is required with backrefs=true'
            ),
            rc = 256
        ))

# Generated at 2022-06-11 07:26:22.747569
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleFailJson) as exc:
        main()
    print('Error message: {0}'.format(exc.value.args[0]['msg']))

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:26:28.128634
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path'),
            owner=dict(),
            group=dict(),
            mode=dict(),
            seuser=dict(),
            serole=dict(),
            selevel=dict(),
            setype=dict(),
        ),
    )
    module.params['path'] = 'test'
    changed = False
    message = ""
    diff = {}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == ""
    assert changed == False



# Generated at 2022-06-11 07:26:37.924743
# Unit test for function main

# Generated at 2022-06-11 07:26:40.605531
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs('module', 'changed', 'message', 'diff') == ('message and ownership, perms or SE linux context changed', True)



# Generated at 2022-06-11 07:26:51.503006
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = get_module('ansible.builtin.lineinfile')
    file_args = module.load_file_common_arguments({'owner': 'root', 'group': 'root', 'mode': '0644', 'seuser': 'unconfined_u', 'serole': 'object_r', 'setype': 'httpd_sys_content_t', 'selevel': 's0', 'unsafe_writes': False})
    message = "ownership, perms or SE linux context changed"
    assert check_file_attrs(module, True, message, True) == ("ownership, perms or SE linux context changed and ownership, perms or SE linux context changed", True)


# Generated at 2022-06-11 07:27:19.622385
# Unit test for function present
def test_present():
    # Setup environment vars
    path = 'test.txt'
    line = 'testline'
    module = AnsibleModule(argument_spec={'path': {'type': 'path', 'required': True},
                                          'line': {'type': 'str', 'required': True},
                                          'create': {'type': 'bool', 'default': False}
                                         }
                          )
    assert present(module, path, None, None, line, None, None, True, False, False, False) == 1



# Generated at 2022-06-11 07:27:29.996112
# Unit test for function check_file_attrs

# Generated at 2022-06-11 07:27:35.240181
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({'path': 'path', 'backrefs': 'no'})
    changed, message, diff = False, '', ''
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == ''
    assert changed == False



# Generated at 2022-06-11 07:27:40.710581
# Unit test for function absent
def test_absent():
    module = AnsibleModule({'dest':'/tmp/file'})

    open('/tmp/file', 'w').close()
    b_dest = to_bytes('/tmp/file', errors='surrogate_or_strict')
    regexp = None
    search_string = None
    line = "Test Line"
    backup = False

    absent(module, b_dest, regexp, search_string, line, backup)


# Generated at 2022-06-11 07:27:47.638849
# Unit test for function present

# Generated at 2022-06-11 07:27:56.930911
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=False),
            search_string=dict(type='str', required=False),
            backrefs=dict(type='bool', default=False),
            line=dict(type='str', required=False),
            insertbefore=dict(type='str', required=False),
            insertafter=dict(type='str', required=False),
            create=dict(type='bool', required=False, default=False),
            backup=dict(type='bool', required=False, default=False),
            firstmatch=dict(type='bool', required=False, default=True),
        )
    )

    # mock the file attributes

# Generated at 2022-06-11 07:28:08.099786
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_dict = {}
    test_dict['insertbefore'] = None
    test_dict['insertafter'] = None
    test_dict['unsafe_writes'] = True
    test_dict['regexp'] = None
    test_dict['backrefs'] = False
    test_dict['path'] = u'/etc/sysctl.d/99-kubernetes-cri.conf'
    test_dict['insertbefore'] = u'EOF'
    test_dict['firstmatch'] = False
    test_dict['create'] = False
    test_dict['search_string'] = u'net.bridge.bridge-nf-call-iptables'
    test_dict['backup'] = False
    test_dict['state'] = u'present'

# Generated at 2022-06-11 07:28:08.775483
# Unit test for function write_changes
def test_write_changes():
    return None


# Generated at 2022-06-11 07:28:11.187550
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, '_diff') as _diff:
        assert main() == _diff.return_value

# Generated at 2022-06-11 07:28:22.259969
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            regexp=dict(required=False),
            search_string=dict(required=False),
            line=dict(required=True),
            insertafter=dict(required=False),
            insertbefore=dict(required=False),
            create=dict(required=False, type='bool', default=False),
            backup=dict(required=False, type='bool', default=False),
            backrefs=dict(required=False, type='bool', default=False),
            firstmatch=dict(required=False, type='bool', default=False),
        )
    )
    command_path = '/tmp/test_input_file'

# Generated at 2022-06-11 07:29:14.565100
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
            diff=dict(type='str', default=None, required=False),
        ),
    )

    (changed, message) = check_file_attrs(module, True, 'test msg', None)
    assert changed == True
    assert 'test msg' in message



# Generated at 2022-06-11 07:29:23.745814
# Unit test for function main

# Generated at 2022-06-11 07:29:29.571918
# Unit test for function main
def test_main():
    test_argv = ['lineinfile', 'foo/bar', 'line=baz']
    with patch.object(sys, 'argv', test_argv):
        with patch('ansible.module_utils.basic.AnsibleModule') as mock_basic:
            mock_basic.return_value.params = {'state': 'present'}
            main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:29:39.026023
# Unit test for function present
def test_present():
    module = AnsibleModule({'regexp' : '^test_line', 'line' : 'test_line'})
    set_module_args(module, 'foo.txt', '^test_line', None, 'test_line', None, None, False, False, False, False)
    dest = "/opt/ansible_test/foo.txt"
    regexp = "^test_line"
    search_string = None
    line = "test_line"
    insertafter = None
    insertbefore = None
    create = False
    backup = False
    backrefs = False
    firstmatch = True
    os.path.exists('/opt/ansible_test/') or os.makedirs('/opt/ansible_test/')

# Generated at 2022-06-11 07:29:48.269935
# Unit test for function present
def test_present():
    """
    Unit test for lineinfile.present
    """
    _lineinfile_present_mock = MagicMock(spec_set=AnsibleModule)
    _lineinfile_present_instance = lineinfile.present(_lineinfile_present_mock)

    dest = 'test.txt'
    regexp = None
    search_string = "string"
    line = "string"
    insertafter = None
    insertbefore = None
    create = True
    backup = True
    backrefs = False
    firstmatch = False

    b_dest = to_bytes(dest, errors='surrogate_or_strict')

    match_found = False

    b_lines = []

    msg = ''
    changed = False

# Generated at 2022-06-11 07:29:57.222430
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            path=dict(type='path'),
            regexp=dict(required=False),
            line=dict(required=False),
            backup=dict(default=False, type='bool')
        )
    )
    empty_file = tempfile.mkstemp()[1]
    # line is in the file
    result = absent(module, empty_file, None, None, 'test', False)
    assert result['changed'] == False
    # regexp is in the file
    regexp = 'test'
    result = absent(module, empty_file, regexp, None, None, False)
    assert result['changed'] == False
    # search_string is in the file
    search_string = 'test'

# Generated at 2022-06-11 07:30:05.963534
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'path', 'required': True},
        'owner': {'type': 'str'},
        'group': {'type': 'str'},
        'mode': {'type': 'str'},
        'seuser': {'type': 'str'},
        'serole': {'type': 'str'},
        'setype': {'type': 'str'},
        'selevel': {'type': 'str'},
    })
    module.atomic_move=object
    changed=False; message=''
    module.set_fs_attributes_if_different=lambda x,y,z: True
    diff='diff'
    check_file_attrs(module, changed, message, diff)



# Generated at 2022-06-11 07:30:15.430779
# Unit test for function present
def test_present():
    # mock_module = _get_mock_module()
    dest = 'path/file'
    firstmatch = False
    insertafter = 'EOF'
    insertbefore = None
    regexp = '^.*$'
    search_string = None
    line = ''
    backrefs = False
    # patch_stat = patch('ansible.module_utils.basic._get_file_stat', spec_set=True)(mock_module.stat)
    # patch_stat.side_effect = [Mock(st_mode=S_IFREG), Mock(st_mode=S_IFREG)]

# Generated at 2022-06-11 07:30:22.829571
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'dest': 'test/file',
        'regexp': 'hostname',
        'line': 'hostname = myhostname'
    })
    with open('test/file', 'w') as f:
        f.write("myhostname")
    result = present(module, 'test/file', 'hostname', None, 'hostname = myhostname', None, None, True,
            True, False, False)
    assert result.get('changed') == False
    assert result.get('msg') == "line replaced"
    os.remove('test/file')


# Generated at 2022-06-11 07:30:24.588929
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()