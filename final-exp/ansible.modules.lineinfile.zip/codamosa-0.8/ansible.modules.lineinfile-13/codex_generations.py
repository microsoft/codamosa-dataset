

# Generated at 2022-06-11 07:21:54.973160
# Unit test for function absent
def test_absent():
    import json

    # success
    test_lines = ['abc\n', 'def\n']
    test_lines_result = ['abc\n']
    test_argspec = {'dest': '/path/to/file', 'search_string': 'def', 'backup': ''}
    test_absent_result = {'changed': True, 'found': 1, 'msg': '1 line(s) removed', 'backup': ''}
    test_lines_diff = json.dumps({'before': 'abc\ndef\n', 'after': 'abc\n'})

# Generated at 2022-06-11 07:22:02.937842
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(default='present', choices=['absent', 'present']),
            path=dict(type='path'),
            regexp=dict(),
            search_string=dict(),
            line=dict(default=None),
            insertafter=dict(),
            insertbefore=dict(),
            create=dict(default=False, type='bool'),
            backup=dict(default=False, type='bool'),
            backrefs=dict(default=False, type='bool'),
            firstmatch=dict(default=False, type='bool'),
            validate=dict(),
            unsafe_writes=dict(default=False, type='bool', aliases=['unsafe-writes'])
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-11 07:22:04.943894
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(
        module, changed, message, diff) == "ownership, perms or SE linux context changed"



# Generated at 2022-06-11 07:22:08.699621
# Unit test for function write_changes
def test_write_changes():
    write_changes(module, b_lines=b'abcde', dest='/tmp/somename')
    module.fail_json(msg='failed to validate: '
                     'rc:%s error:%s' % (rc, err))


# Generated at 2022-06-11 07:22:17.054169
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import ansible

# Generated at 2022-06-11 07:22:28.055941
# Unit test for function check_file_attrs
def test_check_file_attrs():
    before_file_args=dict(
        path='/etc/selinux/config',
        owner='root',
        group=None,
        mode='0400',
        seuser='root',
        serole=None,
        setype='root',
        selevel='system_r',
        attributes=None,
        unsafe_writes=None,
    )

    after_file_args=dict(
        path='/etc/selinux/config',
        owner='root',
        group=None,
        mode='0400',
        seuser='root',
        serole=None,
        setype='root',
        selevel='system_r',
        attributes=None,
        unsafe_writes=None,
    )


# Generated at 2022-06-11 07:22:36.962574
# Unit test for function write_changes
def test_write_changes():
  test_module = AnsibleModule(
    argument_spec=dict(
      path=dict(type='str'),
      state=dict(default='present', choices=['present', 'absent']),
      regexp=dict(type='str'),
      line=dict(type='str'),
      validate=dict(type='str'),
      insertafter=dict(type='str'),
      insertbefore=dict(type='str'),
      create=dict(default=False, type='bool'),
      backup=dict(default=False, type='bool'),
      backup_file=dict(default='backup_file', type='str')
    )
  )
  b_lines = "test-line\n"
  dest = "/tmp/test_file"

# Generated at 2022-06-11 07:22:45.349283
# Unit test for function write_changes
def test_write_changes():
    lines = b"hello\nthere\n"
    temp_file = tempfile.mkstemp()
    try:
        write_changes(temp_file, lines)
        with open(temp_file) as f:
            lines_read = f.read()
        assert lines_read == lines

        lines = b"hello\nthere\nfoo\n"
        write_changes(temp_file, lines, validate="grep -q foo %s")
        with open(temp_file) as f:
            lines_read = f.read()
        assert lines_read == lines
    finally:
        os.remove(temp_file)



# Generated at 2022-06-11 07:22:58.092556
# Unit test for function write_changes
def test_write_changes():
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils import basic
    import os
    import re
    import tempfile

    # Create a module and use it as a factory to create AnsibleModule instances
    my_module = basic._AnsibleModule(
        argument_spec=dict()
    )

    def set_module_args(args):
        args = json.dumps({'ANSIBLE_MODULE_ARGS': args})
        basic._ANSIBLE_ARGS = to_bytes(args)

    args = dict(
        dest = "/tmp/test.txt",
        line = "test line",
        create = True
    )

    set_module_args(args)

# Generated at 2022-06-11 07:23:08.333480
# Unit test for function main

# Generated at 2022-06-11 07:23:47.275993
# Unit test for function absent
def test_absent():
    import tempfile
    from ansible.module_utils._text import to_bytes, to_text

    fd, dest = tempfile.mkstemp()
    os.close(fd)
    fd, dest2 = tempfile.mkstemp()
    os.close(fd)

    # No regexp and line is empty
    with open(dest, 'wb') as f:
        f.write(b"line1\nline2\nline3\n")
    assert absent(None, dest, None, None, b"", False)[1] == False

    # No regexp, search_string and line is empty
    with open(dest, 'wb') as f:
        f.write(b"line1\nline2\nline3\n")

# Generated at 2022-06-11 07:23:58.709857
# Unit test for function present
def test_present():
    module = AnsibleModule(argument_spec=dict(
        path=dict(type='path'),
        state=dict(type='str', default='present'),
        regexp=dict(type='str'),
        line=dict(type='str'),
        insertafter=dict(type='str'),
        insertbefore=dict(type='str'),
        create=dict(type='bool', default=False),
        backup=dict(type='bool', default=False),
        backrefs=dict(type='bool', default=False),
        validate=dict(type='str'),
        unsafe_writes=dict(type='bool', default=False),
    ))

    with tempfile.TemporaryDirectory() as tmpdirname:
        module.tmpdir = tmpdirname
        dest = '%s/test_file.txt' % module.tmpdir



# Generated at 2022-06-11 07:23:59.360153
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:23:59.974787
# Unit test for function check_file_attrs
def test_check_file_attrs():
    pass


# Generated at 2022-06-11 07:24:11.451374
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            regexp=dict(),
            search_string=dict(),
            line=dict(),
            insertafter=dict(),
            insertbefore=dict(),
            create=dict(default=False, type='bool'),
            backup=dict(default=False, type='bool'),
            backrefs=dict(default=False, type='bool'),
            firstmatch=dict(default=False, type='bool'),
            validate=dict(),
            unsafe_writes=dict(default=False, type='bool', aliases=['unsafe-writes']),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-11 07:24:21.153311
# Unit test for function absent
def test_absent():
    module = AnsibleModule(argument_spec = dict(
        state = dict(default='present', choices=['absent', 'present']),
        path = dict(required=True, type='path'),
        regexp = dict(required=False),
        search_string = dict(required=False),
        line = dict(required=True)
    )
)

    # Function call
    absent(module, '/etc/motd', None, 'bob', 'bob', None)

    # Check function output
    assert module.exit_json.called
    assert module.exit_json.call_count == 1
    assert module.exit_json.call_args[0][0]['changed'] == True
    assert module.exit_json.call_args[0][0]['msg'] == '2 line(s) removed'

    # Reset

# Generated at 2022-06-11 07:24:32.923124
# Unit test for function present

# Generated at 2022-06-11 07:24:42.557558
# Unit test for function check_file_attrs

# Generated at 2022-06-11 07:24:54.932797
# Unit test for function present

# Generated at 2022-06-11 07:24:56.878652
# Unit test for function main
def test_main():
    errno = AnsibleExitJson(msg='test')
    raise SystemExit(errno.msg)


# Generated at 2022-06-11 07:26:02.519071
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', aliases=['dest', 'destfile']),
            regexp=dict(),
            search_string=dict(),
            line=dict(),
            create=dict(type='bool'),
            insertbefore=dict(),
            insertafter=dict(),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict()
        ),
        supports_check_mode=True
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.set_fs_attributes_if_different = MagicMock()
    module.tmpdir = tempfile.gettemp

# Generated at 2022-06-11 07:26:07.392222
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({})
    module.set_module_args({'path': 'test', 'group': 'test', 'owner': 'test'})
    assert module.fs_attributes_changed == {'group': 'test', 'owner': 'test'}



# Generated at 2022-06-11 07:26:11.408526
# Unit test for function write_changes
def test_write_changes():
    """Unit test for function write_changes"""
    module = AnsibleModule({})
    write_changes(module, 'foo'.encode('utf-8'), '/tmp/foo')
    assert read_file('/tmp/foo') == 'foo'



# Generated at 2022-06-11 07:26:20.607964
# Unit test for function present
def test_present():
    # Given
    module = AnsibleModule({
        'dest': 'testfile',
        'regexp': '^#(.*)$',
        'search_string': '^#(.*)$',
        'line': '#testline',
        'insertafter': '^#(.*)$',
        'insertbefore': '^#(.*)$',
        'create': True,
        'backup': False,
        'backrefs': False
    })

    import sys
    if (sys.version_info[0] < 3):
        file = '__builtin__.file'
    else:
        file = 'builtins.open'


# Generated at 2022-06-11 07:26:24.050376
# Unit test for function write_changes
def test_write_changes():
    class fake_module(object):
        def __init__(self):
            self.params = dict(unsafe_writes=True)
            self.tmpdir = "/tmp"
            self.fail_json = print
            self.run_command = print

    b_lines = list()
    dest = '/tmp/t'
    module = fake_module()
    write_changes(module, b_lines, dest)


# Generated at 2022-06-11 07:26:32.559214
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'path'},
        'owner': {'type': 'str', 'default': None},
        'group': {'type': 'str', 'default': None},
        'mode': {'type': 'str', 'default': None},
        'selevel': {'type': 'str', 'default': None},
        'serole': {'type': 'str', 'default': None},
        'setype': {'type': 'str', 'default': None},
        'seuser': {'type': 'str', 'default': None},
    })

    changed = False
    message = ""
    diff = ""
    message, changed = check_file_attrs(module, changed, message, diff)
    assert not changed
    assert message == ""



# Generated at 2022-06-11 07:26:43.042120
# Unit test for function main
def test_main():
    """
    Unit test for function main.
    """
    os.environ['ANSIBLE_MODULE_FORCE_COLOR'] = 'false'

# Generated at 2022-06-11 07:26:48.940652
# Unit test for function main

# Generated at 2022-06-11 07:26:59.930923
# Unit test for function present

# Generated at 2022-06-11 07:27:08.141623
# Unit test for function write_changes
def test_write_changes():
    import imp
    import os
    import tempfile
    import shutil
    import pytest

    imp.load_source('ansible.module_utils.basic', 'lib/ansible/module_utils/basic.py')
    imp.load_source('ansible.module_utils._text', 'lib/ansible/module_utils/_text.py')
 
    class FakeModule(object):
        def __init__(self):
            self.tmpdir = tempfile.mkdtemp()
            self.t_tmpdir = to_text(self.tmpdir)
            self.tmpfile = os.path.join(self.tmpdir, 'tmpfile')
            self.t_tmpfile = os.path.join(self.tmpdir, 'tmpfile')
            self.t_dest = '/tmp/the_file'
            self

# Generated at 2022-06-11 07:30:30.263024
# Unit test for function absent
def test_absent():
    test_file = '/tmp/ansible_test_file_lineinfile'
    test_text = 'this is the first line\nthis is line, the second line\nthis is last line\n'
    with open(test_file, 'w+') as test_fd:
        test_fd.write(test_text)
    test = {
        'dest': test_file,
        'regexp': None,
        'search_string': None,
        'line': 'this is line, the second line',
        'backup': False,
    }

# Generated at 2022-06-11 07:30:33.241141
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(module, False, "message", None)



# Generated at 2022-06-11 07:30:36.091164
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = AnsibleModule({
        "path": "/tmp/foo",
        'unsafe_writes': True,
        "backup": False
    })

    message = "Changed"
    diff = None
    changed = True

    (message, changed) = check_file_attrs(module, changed, message, diff)

    assert message == "Changed and ownership, perms or SE linux context changed"
    assert changed is True


# Generated at 2022-06-11 07:30:39.831102
# Unit test for function present
def test_present():
    module = AnsibleModule(argument_spec={'dest':dict(type='str'),'regexp':dict(type='str'),'search_string':dict(type='str'),'line':dict(type='str'),'insertafter':dict(type='str'),'insertbefore':dict(type='str'),'create':dict(type='bool'),'backup':dict(type='str'),'backrefs':dict(type='bool'),'firstmatch':dict(type='bool')})
    present(module, "/tmp/foo", "test", None, "testtest", "testtest", "testtest", False, None, False, False)

# Generated at 2022-06-11 07:30:44.202432
# Unit test for function absent
def test_absent():
    dest = '/tmp/automation_test/test_path'
    line = "This is a test string\n"
    regexp = None
    search_string = None
    backup = False
    module = AnsibleModuleMock()
    module.check_mode = False
    module._diff = True
    module.exit_json = exit_json
    if os.path.exists(dest):
        os.remove(dest)
    with open(dest, 'w') as f:
        f.write(line)
    print("answer:"+str(absent(module, dest, regexp, search_string, line, backup)))

# Generated at 2022-06-11 07:30:46.507107
# Unit test for function absent
def test_absent():
    dest = 'test_absent.txt'
    regexp = 2
    search_string = 3
    line = 4
    backup = 5

    module = AnsibleModule({})
    module.exit_json({'changed': False, 'found': False})


# Generated at 2022-06-11 07:30:51.730774
# Unit test for function absent
def test_absent():
    lines = [b'a line\n', b'the next line\n', b'another line\n']
    b_line = b'the next line\n'
    regexp = 'the next line'
    search_string = None
    line = 'the next line'

    # Test if existing line is removed in dry-run mode
    b_lines = list(lines)
    changed, found, msg, b_lines = absent(b_lines, regexp, search_string, line, False)
    assert changed
    assert found == 1
    assert msg == "1 line(s) removed"
    assert b_lines == [b'a line\n', b'another line\n']

    # Test if existing line is removed in real mode
    b_lines = list(lines)
    changed, found, msg, b_lines = absent

# Generated at 2022-06-11 07:30:56.650299
# Unit test for function main
def test_main():
    import ansible.modules.files.lineinfile as li