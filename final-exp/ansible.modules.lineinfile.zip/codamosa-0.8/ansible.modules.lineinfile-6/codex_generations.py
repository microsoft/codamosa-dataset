

# Generated at 2022-06-11 07:21:42.314076
# Unit test for function check_file_attrs
def test_check_file_attrs():

    from ansible.modules.files.lineinfile import check_file_attrs

    module = AnsibleModule(
        argument_spec={
            'path': {'type': 'path', 'required': True},
            'owner': {'type': 'str'},
            'group': {'type': 'str'},
            'mode': {'type': 'str'},
            'seuser': {'type': 'str'},
            'serole': {'type': 'str'},
            'setype': {'type': 'str'},
            'selevel': {'type': 'str'},
            'unsafe_writes': {'type': 'bool', 'default': True, 'aliases': ['unsafe-writes']},
        },
        supports_check_mode=True
    )


# Generated at 2022-06-11 07:21:44.880199
# Unit test for function absent
def test_absent():
    assert absent(dest, regexp, search_string, line, backup) is None



# Generated at 2022-06-11 07:21:54.780910
# Unit test for function absent
def test_absent():
    module = AnsibleModule({'dest': 'dest_file', 'state': 'absent', 'regexp': None, 'line': 'newline'})
    dest_file_name = 'dest_file'
    dest_file = open(dest_file_name, 'w')
    dest_file.write('oldline')
    dest_file.close()

    absent(module, dest_file_name, None, None, 'newline', False)
    dest_file = open(dest_file_name, 'r')
    try:
        assert dest_file.read() == 'oldline'
    except AssertionError:
        raise AssertionError('Test failed - line not removed')
    dest_file.close()
    os.remove(dest_file_name)


# Generated at 2022-06-11 07:22:05.634713
# Unit test for function main
def test_main():
    import platform
    import sys
    # Patch sys.modules so that AnsibleModule is imported
    # from the right place
    sys.modules['ansible.module_utils.basic'] = 'fake'
    sys.modules['ansible.module_utils.basic.AnsibleModule'] = 'fake'
    sys.modules['ansible.module_utils.six'] = 'fake'
    sys.modules['ansible.module_utils.six.moves'] = 'fake'
    # Create a fake AnsibleModule object
    class AnsibleModule(object):
        def __init__(self, argument_spec, mutually_exclusive=None,
                 supports_check_mode=False, add_file_common_args=True):
            self.argument_spec = argument_spec

# Generated at 2022-06-11 07:22:17.393533
# Unit test for function present
def test_present():
    dest = '/tmp/test_lineinfile'
    if os.path.exists(dest):
        os.remove(dest)

    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(default=False, type='bool'),
            backup=dict(default=False, type='bool'),
            backrefs=dict(default=False, type='bool'),
            firstmatch=dict(default=False, type='bool'),
        ),
        supports_check_mode=True,
    )

    regex

# Generated at 2022-06-11 07:22:28.686731
# Unit test for function absent

# Generated at 2022-06-11 07:22:35.388347
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'line': 'The next line is the last line',
        'path': '/tmp/testfile',
        'create': False,
        'insertafter': 'EOF',
    })
    try:
        present(module, dest='/tmp/testfile', regexp=None, search_string=None,
                line='The next line is the last line', insertafter='EOF',
                insertbefore=None, create=False, backup=False, backrefs=False,
                 firstmatch=False)
    except SystemExit:
        pass

# Generated at 2022-06-11 07:22:37.601515
# Unit test for function main
def test_main():
    pass


# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:22:47.519201
# Unit test for function present
def test_present():
    dest = "~/test_present.txt"
    f = open(dest, 'wb')
    f.write(b"hello world!\n")
    f.close()


# Generated at 2022-06-11 07:23:00.412181
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    import tempfile
    import json

    # Make a temp directory
    tmpdir = tempfile.mkdtemp()
    print()
    print('Creating temp directory %s' % tmpdir)
    # Make a temp file
    tmpfd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    print()
    print('Creating temp file %s' % tmpfile)


# Generated at 2022-06-11 07:23:32.800358
# Unit test for function main

# Generated at 2022-06-11 07:23:44.681129
# Unit test for function main
def test_main():
    argv = sys.argv

# Generated at 2022-06-11 07:23:56.207426
# Unit test for function present
def test_present():
    from ansible.module_utils.six import PY3
    if PY3:
        pyver = '3'
    else:
        pyver = '2'

# Generated at 2022-06-11 07:24:07.681080
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = AnsibleModule({'dest':'/etc/testfile','unsafe_writes':False})
    changed = True
    message = "line replaced"
    d = dict()
    d['after'] = "some_after"
    d['before'] = "some_before"
    d['before_header'] = "some_before_header"
    d['after_header'] = "some_after_header"
    d['before'] = "some_before"
    diff = {'diff':{'before': "some_before",'after_header': "some_after_header",'before_header': "some_before_header",'after': "some_after"}}

    module.params['owner'] = "someowner"
    module.params['group'] = "somegroup"

# Generated at 2022-06-11 07:24:16.652861
# Unit test for function write_changes
def test_write_changes():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    class TestModule(object):
        def __init__(self, params):
            self.params = params
            self.tmpdir = params["tmpdir"]

        def fail_json(self, msg):
            pass

        def atomic_move(self, tmpfile, dest, unsafe_writes):
            pass

        def run_command(self, command):
            if command == b"echo Hello":
                return (0, 'Hello', '')
            elif command == b"echo Goodbye":
                return (1, '', 'Goodbye')

    # Test empty lines
    lines = []
    module = TestModule({"tmpdir": ""})

# Generated at 2022-06-11 07:24:28.309093
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'_ansible_tmpdir': './tmp/'})
    b_lines = to_bytes("line1\nline2\nline3\n", errors='surrogate_or_strict')
    dest = "./tmp/test_write_changes"

    # Test without validate
    write_changes(module, b_lines, dest)
    assert os.path.exists(dest)
    assert open(dest, 'r').read() == "line1\nline2\nline3\n"
    # Clean up tmpfile
    os.unlink(dest)

    # Test with invalid validate
    module.params['validate'] = '%s --check-only'

# Generated at 2022-06-11 07:24:29.744395
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(None, None, None, None)



# Generated at 2022-06-11 07:24:40.832117
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
            mode=dict(default='0644'),
            owner=dict(default='root'),
            group=dict(default='root'),
        )
    )
    module.params['path'] = 'file.txt'
    path = module.params['path']
    changed = True
    message = 'this is a message'

# Generated at 2022-06-11 07:24:52.775304
# Unit test for function write_changes
def test_write_changes():
    from ansible.compat.tests.mock import MagicMock
    import os
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()

    b_temp_dir = to_bytes(temp_dir, errors='surrogate_or_strict')

    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir)
    b_temp_file = to_bytes(temp_file.name, errors='surrogate_or_strict')

    temp_file.close()
    if not os.path.exists(b_temp_file):
        os.mknod(b_temp_file)
    if not os.access(b_temp_file, os.W_OK):
        os.chmod(b_temp_file, 0o666)

    mock

# Generated at 2022-06-11 07:25:01.792781
# Unit test for function absent
def test_absent():
    #from ansible.module_utils import basic
    #from ansible.module_utils._text import to_bytes
    dest = '/tmp/testfile'
    regexp = 'Test line'
    search_string = None
    line = 'Test line'
    backup = False

    m_params = dict(
        dest=dest,
        regexp=regexp,
        search_string=search_string,
        line=line,
        backup=backup
    )
    try:
        m = AnsibleModule(m_params)
        assert False
    except SystemExit as e:
        assert e.code == 257

    with open(dest,'w') as f:
        f.write('Test line')

    m = AnsibleModule(m_params)


# Generated at 2022-06-11 07:25:48.269962
# Unit test for function check_file_attrs
def test_check_file_attrs():

    data = {
        'changed': False,
        'msg': u''
    }


# Generated at 2022-06-11 07:25:48.775726
# Unit test for function write_changes
def test_write_changes():
    pass


# Generated at 2022-06-11 07:26:01.045819
# Unit test for function present
def test_present():
    import io
    import os
    import sys
    import pytest
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.common.collections import is_sequence

    args = dict(
        path='/tmp/test',
        line='test line',
        create=True,
        state='present',
        backup=False,
        _used_as_actual_module=True,
        _ansible_check_mode=True,
    )
    if 'diff' in args:
        del args['diff']

    # if the module was called incorrectly we will still get a result, just not the one
    #

# Generated at 2022-06-11 07:26:05.926792
# Unit test for function present
def test_present():
    test_module = AnsibleModule({
        'path': '/etc/hosts',
        'regexp': '^(127.*(?!\.).*)',
        'line': '127.0.0.1',
    })
    test_present(test_module)



# Generated at 2022-06-11 07:26:14.529531
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    b_lines = [to_bytes(v, errors='surrogate_or_strict') for v in ["foo", "bar", "fizz", "buzz", "baz"]]
    write_changes(module, b_lines, "/var/tmp/test_file")
    with open('/var/tmp/test_file', 'r') as f:
        data = f.read()
    assert data == 'foobarfizzbuzzbaz'



# Generated at 2022-06-11 07:26:21.865119
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest = dict(type='str', required=True),
            regexp = dict(type='str'),
            search_string = dict(type='str'),
            line = dict(type='str', required=True),
            backup = dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)



# Generated at 2022-06-11 07:26:29.222015
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 07:26:37.340281
# Unit test for function check_file_attrs
def test_check_file_attrs():

    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(argument_spec={})
    file_args = module.load_file_common_arguments(module.params)
    setattr(module, '__ansible_file_attributes_changed_when_missing', file_args)
    setattr(module, '__ansible_file_attributes_diff', file_args)
    module.set_fs_attributes_if_different(file_args, False, diff=file_args)

    # check_file_attrs(module, False, "test message", file_args)
# Unit test end



# Generated at 2022-06-11 07:26:46.922927
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'insertbefore': 'insertbeforeline',
        'backrefs': True,
        'line': '#this is a comment',
        'path': '/path/to/file',
        'unsafe_writes': True})

    dest = '/path/to/file'
    regexp = None
    search_string = None
    line = '#this is a comment'
    insertafter = None
    insertbefore = 'insertbeforeline'
    create = True
    backup = False
    backrefs = True
    firstmatch = False

    present(module, dest, regexp, search_string, line, insertafter, insertbefore, create, backup, backrefs, firstmatch)


# Generated at 2022-06-11 07:26:55.389579
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'dest': '/tmp/foo',
        'regexp': 'r1',
        'line': 'l1',
        'state': 'present',
        'create': False
    })
    assert not present(module, module.params['dest'], module.params['regexp'], module.params['search_string'],
                      module.params['line'], module.params['insertafter'], module.params['insertbefore'],
                      module.params['create'], module.params['backup'], module.params['backrefs'], module.params['firstmatch'])


# Generated at 2022-06-11 07:28:14.901267
# Unit test for function main
def test_main():
    # Response object (we are mocking)
    response = Snippet()

    # An AnsibleModule object will be created and initialised with the required
    # args.  This includes setting up the mock API.

# Generated at 2022-06-11 07:28:25.211972
# Unit test for function write_changes

# Generated at 2022-06-11 07:28:25.934720
# Unit test for function absent
def test_absent():
    pass



# Generated at 2022-06-11 07:28:29.945672
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.modules.files.lineinfile import check_file_attrs
    assert check_file_attrs({"changed": False, "msg": "Hello world"}, True, "How can I help", "diff") == ("How can I help and ownership, perms or SE linux context changed", True)



# Generated at 2022-06-11 07:28:36.607280
# Unit test for function present
def test_present():
    module.params['path'] = tempfile.mkstemp()[1]
    module.params['line'] = 'this is a test line'
    module.params['insertbefore'] = 'BOF'
    present(module, module.params['path'], None, None, module.params['line'],
            insertafter=None, insertbefore=module.params['insertbefore'], create=True,
            backup=None, backrefs=None, firstmatch=None)
    f = open(module.params['path'])
    assert f.readlines()[0].rstrip('\n') == module.params['line']
    f.close()

    os.remove(module.params['path'])


# Generated at 2022-06-11 07:28:45.985299
# Unit test for function main
def test_main():
    # Test case for function main
    def b(x):
      return x.encode('utf-8')

    lines_in = [b('a line'), b('line to be replaced1'), b('same line'), b('line to be replaced2'), b('a line')]
    lines_out = [b('a line'), b('line to be replaced with'), b('same line'), b('line to be replaced with'), b('a line')]
    lines_in_2 = [b('a line'), b('line to be replaced1'), b('same line'), b('line to be replaced2'), b('a line')]


# Generated at 2022-06-11 07:28:48.557243
# Unit test for function present
def test_present():
    assert present(['dest', 'regexp', 'search_string', 'line', 'insertafter', 'insertbefore', 'create', 'backup', 'backrefs', 'firstmatch']) == '''#'''


# Generated at 2022-06-11 07:28:50.151816
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(module, True, "Changed", []) == (msg, True)


# Generated at 2022-06-11 07:28:52.964306
# Unit test for function present
def test_present():
    assert present(module, dest, regexp, search_string, line, insertafter, insertbefore, create,
            backup, backrefs, firstmatch)



# Generated at 2022-06-11 07:29:01.531530
# Unit test for function absent
def test_absent():

    module = AnsibleModule(argument_spec=dict(
        dest=dict(default='/tmp/dest_unit_test'),
        regexp=dict(default=None),
        search_string=dict(default=None),
        line=dict(default='test'),
        state=dict(default='absent'),
        backup=dict(default=False, type='bool')
    ))

    # Case 1, search_string and regexp are None and line exists.
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    b_dest = to_bytes(dest, errors='surrogate_or_strict')
    b_line = to_bytes