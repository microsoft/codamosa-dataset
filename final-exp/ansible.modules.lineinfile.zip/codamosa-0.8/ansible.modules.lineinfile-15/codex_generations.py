

# Generated at 2022-06-11 07:21:42.284405
# Unit test for function write_changes
def test_write_changes():
    import pytest
    from ansible.module_utils.basic import _ANSIBLE_ARGS

    test_validate = 'grep -q "%%s" "%s"'
    test_validate_fail = 'grep -q "%%s" "%s" 2>&1 | head -2'
    test_dest = '/etc/ansible/test_write_changes'
    test_lines = [
        '/etc/ansible/test_write_changes\n',
        'test\n'
        ]
    tmpfd, tmpfile = tempfile.mkstemp(dir='/tmp')
    os.write(tmpfd, to_bytes(''.join(test_lines)))
    os.close(tmpfd)
    module = AnsibleModule(supports_check_mode=False, **_ANSIBLE_ARGS)
    module

# Generated at 2022-06-11 07:21:52.217305
# Unit test for function check_file_attrs
def test_check_file_attrs():
    M = AnsibleModule({})
    M.params['path'] = '/home/foo'
    M.params['owner'] = 'root'
    M.params['group'] = 'root'
    M.params['mode'] = '0644'
    M.params['seuser'] = 'system_u'
    M.params['serole'] = 'object_r'
    M.params['setype'] = 'dbus_config_t'
    M.params['selevel'] = 's0'
    (msg, changed) = check_file_attrs(M, False, '', {})
    assert changed == True
    assert msg == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-11 07:22:00.093281
# Unit test for function absent
def test_absent():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import io

    testmodule = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
            regexp=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
    )

    testmodule.exit_json = lambda **args: args

    testpath = '/testpath'
    testregexp = '/testregexp'
    testline = 'testline'

    destination = io.BytesIO()


# Generated at 2022-06-11 07:22:04.264975
# Unit test for function absent
def test_absent():
    lines = [b"test one\n", b"test two\n", b"test three\n", b"test two\n"]
    for line in lines:
        assert lines.pop() == line
    assert False == bool(lines)



# Generated at 2022-06-11 07:22:12.068645
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params['path'] = '/tmp/foo'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0644'

    changed = True
    message = "foo"
    diff = {'before': {'path': '/tmp/foo'}, 'after': {'path': '/tmp/foo'}}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert changed is True
    assert message == "foo and ownership, perms or SE linux context changed"



# Generated at 2022-06-11 07:22:21.181384
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'backup': False,
        'backrefs': False,
        'content': '',
        'create': False,
        'dest': '/etc/foo.conf',
        'firstmatch': False,
        'insertafter': '',
        'insertbefore': '',
        'line': 'FOO=bar',
        'owner': None,
        'path': '/bin/cp',
        'regexp': '^foo=',
        'remote_src': False,
        'seuser': None,
        'serole': None,
        'setype': None,
        'selevel': None,
        'unsafe_writes': False,
        'validate': None,
    })

    with open('test/test.conf', 'w') as f:
        f.write

# Generated at 2022-06-11 07:22:32.504877
# Unit test for function check_file_attrs

# Generated at 2022-06-11 07:22:33.760796
# Unit test for function main
def test_main():
    assert True


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:22:34.419399
# Unit test for function write_changes
def test_write_changes():
    assert True



# Generated at 2022-06-11 07:22:44.963784
# Unit test for function write_changes
def test_write_changes():
    # Setup test object
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path'),
            line=dict(type='str'),
            validate=dict(type='str', default=None),
        )
    )

    # Setup test data
    lines = ["line1"]
    test_line = "testline"
    module.params = {'line': test_line}
    dest = '/test/test.txt'
    b_dest = to_bytes(dest)

    # Write lines to temp file
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    with os.fdopen(tmpfd, 'wb') as f:
        f.writelines(lines)

    # Stub atomic_move method

# Generated at 2022-06-11 07:23:30.618783
# Unit test for function write_changes
def test_write_changes():
    # Creating the module
    module = AnsibleModule(argument_spec={'dest': dict(type='str'), 'validate': dict(type='str')})
    # Creating a temporary file with some lines to write
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    with os.fdopen(tmpfd, 'w') as f:
        f.write('This is a new line\n')
    # Executing the function
    dest = module.params['dest']
    with open(tmpfile, 'r') as f:
        b_lines = f.read()
    write_changes(module, b_lines, dest)


# Generated at 2022-06-11 07:23:40.039061
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default='no'),
            backup=dict(type='bool', default='no'),
            backrefs=dict(type='bool', default='no'),
            firstmatch=dict(type='bool', default='no'),
            validate=dict(type='str', default=None),
            unsafe_writes=dict(type='bool', default='no'),
        ),
    )

# Generated at 2022-06-11 07:23:43.990185
# Unit test for function check_file_attrs
def test_check_file_attrs():
    result, message, changed = check_file_attrs()
    assert result is True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-11 07:23:55.550253
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = MagicMock()
    module.params = {'follow': True, 'unsafe_writes': True}
    module.tmpdir = None
    module.run_command = MagicMock()
    # returns True, None for a result
    module.atomic_move = MagicMock(return_value=(True, None))
    module.set_fs_attributes_if_different = MagicMock(return_value=True)
    module.load_file_common_arguments = MagicMock(return_value=True)
    module.exit_json = MagicMock(return_value=False)
    module.fail_json = MagicMock(return_value=False)
    changed = False
    message = "backslashes"
    diff = "escaped"

# Generated at 2022-06-11 07:24:06.127247
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            arg1=dict(type='str', required=False, default='some_default_value'),
            arg2=dict(type='int', required=False, default=100),
            arg3=dict(type='bool', required=False, default=True),
        ),
        supports_check_mode=True,
    )

    assert module.params['arg1'] == 'some_default_value'
    assert module.params['arg2'] == 100
    assert module.params['arg3'] is True


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:24:15.838412
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=True)
        ),
        supports_check_mode=True)
    m_args = module.params
    m_args['__ansible_tmpdir'] = "/tmp"

# Generated at 2022-06-11 07:24:16.834130
# Unit test for function write_changes
def test_write_changes():
    # No tests yet
    pass



# Generated at 2022-06-11 07:24:17.464596
# Unit test for function absent
def test_absent():
    pass


# Generated at 2022-06-11 07:24:24.237058
# Unit test for function write_changes
def test_write_changes():
    lines = ['line1', 'line2']
    tmp_path = '/tmp/test_file'
    module = AnsibleModule(argument_spec={'unsafe_writes': {'type': 'bool', 'default': True}})
    module.atomic_move = lambda src, dest, unsafe_writes: True
    write_changes(module, lines, tmp_path)


# This function makes Ansible 2.5 compatible with earlier releases

# Generated at 2022-06-11 07:24:25.696147
# Unit test for function write_changes
def test_write_changes():
    #TODO: need a test scenario
    return


# Generated at 2022-06-11 07:25:14.125901
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(
        module,
        changed=False,
        message="",
        diff=False
    )
    assert check_file_attrs(
        module,
        changed=False,
        message="",
        diff=True
    )
    assert check_file_attrs(
        module,
        changed=True,
        message="ownership, perms or SE linux context changed",
        diff=False
    )
    assert check_file_attrs(
        module,
        changed=True,
        message="ownership, perms or SE linux context changed",
        diff=True
    )

# ---- Utility functions ---------------------------------------------------------------------


# Generated at 2022-06-11 07:25:25.768428
# Unit test for function main

# Generated at 2022-06-11 07:25:36.266651
# Unit test for function main
def test_main():
    import platform
    import os
    import tempfile
    import shutil
    import filecmp
    import stat

    import ansible.constants as C
    MODULEDIR = os.path.join(C.DEFAULT_MODULE_PATH[0], 'files')
    DATADIR = os.path.join(os.path.dirname(__file__), 'data')
    FIXTUREDIR = os.path.join(DATADIR, 'fixtures')

    # we need our stub to be found first
    sys.path.insert(0, FIXTUREDIR)
    from ansible_module_lineinfile_basic import main

    def set_module_args(args):
        args = json.dumps({'ANSIBLE_MODULE_ARGS': args})
        basic._ANSIBLE_ARGS = to

# Generated at 2022-06-11 07:25:47.596536
# Unit test for function present
def test_present():
    x = {
        "check_mode": False,
        "changed": False,
        "msg": "",
        "dest": "/tmp/config",
        "regexp": "^host=(.+)$",
        "state": "present",
        "firstmatch": False
    }

# Generated at 2022-06-11 07:25:58.891867
# Unit test for function present
def test_present():
    module = AnsibleModule(argument_spec={
        "path": {"default": "/path/to/file"},
        "regexp": {"default": "regexp"},
        "insertafter": {"default": "BOF"},
        "insertbefore": {"default": "EOF"},
        "line": {"default": "line of text"},
        "create": {"default": True, "type": "bool"},
        "backup": {"default": False, "type": "bool"},
        "backrefs": {"default": False, "type": "bool"},
        "firstmatch": {"default": False, "type": "bool"},
        "dest": {"default": "/path/to/file"},
        "validate": {"default": "None"},
        "unsafe_writes": {"default": False, "type": "bool"}
    })



# Generated at 2022-06-11 07:26:03.607213
# Unit test for function present
def test_present():
    # Mock
    module = AnsibleModule({
        'path': '/tmp/somelines',
        'backup': True,
        'remote_src': None,
        'state': 'present',
        'unsafe_writes': True,
        'validate': None,
        'create': False,
        'line': 'The line of content',
        'insertbefore': None,
        'insertafter': 'BOF',
        'regexp': None,
        'replace': 'yes',
        'firstmatch': 'no',
        'backrefs': 'no',
        '_diff': False
    })

    b_dest = to_bytes('/tmp/somelines', errors='surrogate_or_strict')

# Generated at 2022-06-11 07:26:15.642046
# Unit test for function absent
def test_absent():
    import os
    import os.path
    import tempfile
    import filecmp

    module = AnsibleModule({'content': '# foobar',
                            'dest': 'test.txt',
                            'backup': False})      # noqa: F405

    tmp = tempfile.mkdtemp()
    dest = os.path.join(tmp, 'test.txt')
    b_dest = to_bytes(dest)
    f = open(dest, "wb")
    f.write(b'# foobar')
    f.close()

    module.absent(dest, '# foobar', None, None, os.path.join(tmp, 'backup'))

    assert not os.path.exists(b_dest)

# Generated at 2022-06-11 07:26:22.949646
# Unit test for function check_file_attrs
def test_check_file_attrs():

    # Test module arguments
    module_args = dict(
        path='/etc/motd',
        state='present',
        mode='0644',
        owner='root',
        group='root',
        seuser='unconfined_u',
        serole='object_r',
        selevel='s0',
        setype='etc_t',
        unsafe_writes='no',
        _diff=True,
    )

    # Test AnsibleModule arguments

# Generated at 2022-06-11 07:26:24.730966
# Unit test for function present
def test_present():
    assert present(AnsibleModule, '', None, None, '', None, None, True, True, True, True) == None


# Generated at 2022-06-11 07:26:33.500425
# Unit test for function main

# Generated at 2022-06-11 07:27:52.675988
# Unit test for function present
def test_present():
    arguments = {'backrefs': 'no',
                 'backup': 'no',
                 'create': 'no',
                 'dest': 'dest_directory/dest.txt',
                 'firstmatch': 'yes',
                 'insertafter': 'EOF',
                 'insertbefore': None,
                 'line': 'this is a line',
                 'regexp': None,
                 'search_string': None,
                 'validate': None}

# Generated at 2022-06-11 07:27:59.276285
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='path', fallback=(env_fallback, ['ANSIBLE_REMOTE_TMP'])),
        ),
    )
    b_lines = [
        '# foo\n',
        'bar\n',
        'baz\n',
    ]
    write_changes(module, b_lines, module.params['path'])
    with open(module.params['path'], 'rb') as f:
        data = f.read()
    assert data == b'# foo\nbar\nbaz\n'
    os.remove(module.params['path'])



# Generated at 2022-06-11 07:28:10.410777
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest = dict(type='str', required=True),
            regexp = dict(type='str', required=False),
            search_string = dict(type='str', required=False),
            line = dict(type='str', required=False),
            backup = dict(type='str', required=False)
        )
    )

    dest = "test"

    test_line = "test line"
    regexp = r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"
    search_string = r"l*"

    test_module = ModuleTestCase(module, {'dest': dest, 'line' : test_line})

# Generated at 2022-06-11 07:28:21.623160
# Unit test for function absent
def test_absent():
    from ansible.module_utils.common._collections_compat import UserDict
    from ansible.utils.contextmanager import contextmanager

    @contextmanager
    def fake_exit(err):
        yield

    @contextmanager
    def fake_open(filename, mode='r'):
        class FakeFile(object):
            def __init__(self, filename):
                with open(filename) as f:
                    self.lines = tuple(f)

            def __iter__(self):
                for line in self.lines:
                    yield line

            def readlines(self):
                return self.lines

        fake_file = FakeFile(filename)
        yield fake_file

    mock_open = fake_open

    dest = '/path/to/filename'
    regexp = '^key=value'

# Generated at 2022-06-11 07:28:25.336092
# Unit test for function present
def test_present():
    fake_module = AnsibleModule({'dest': './test.log',
                                 'create': 'yes',
                                 'line': 'foo',
                                 '_diff': 'yes'
                                })
    present(fake_module, './test.log', None, None, 'foo', None, None, 'yes', False, False, False)


# Generated at 2022-06-11 07:28:33.119888
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import tempfile
    import os

    content = to_bytes('teststring')
    tmpfd, tmpfile = tempfile.mkstemp()
    with os.fdopen(tmpfd, 'wb') as f:
        f.writelines(content)

    m = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    dest = tmpfile
    validate = 'ls %s'
    write_changes(m, content, dest)
    assert os.path.exists(tmpfile) == True



# Generated at 2022-06-11 07:28:43.436731
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os
    import os.path
    import io
    import sys
    import shutil
    import pytest
    import json

    args = dict(
      path="",
      state="present",
      regexp=None,
      search_string=None,
      line="",
      insertafter=None,
      insertbefore=None,
      backrefs=False,
      create=False,
      backup=False,
      firstmatch=False,
      validate=None
    )


# Generated at 2022-06-11 07:28:43.839753
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-11 07:28:48.617714
# Unit test for function write_changes
def test_write_changes():
    b_lines = to_bytes("Write some text\n")
    t_dest = 'testfile'
    t_tmpfile = 'tmpfile'
    from ansible.compat.six import StringIO
    original_open = open
    def mocked_open(f, m):
        if f == t_tmpfile:
            return StringIO(b_lines)
        else:
            return original_open(f, m)
    # Start the test
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.run_command = lambda cmd: (0, b_lines, b'')
    module.atomic_move = lambda src, dest, unsafe_writes: dest
    module.tmpdir = tempfile.gettempdir()
    open = mocked_open
    # Run the test
    write_changes

# Generated at 2022-06-11 07:28:53.835054
# Unit test for function write_changes
def test_write_changes():
    import re
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
      argument_spec = dict(
        tmpdir = dict(default='/tmp', type='path'),
        dest = dict(default='/tmp', type='path'),
        validate = dict(default=None, type='str'),
        unsafe_writes = dict(default=False, type='bool'),
      ),
      supports_check_mode=True
    )

    b_lines = [b'foo\n', b'bar\n']
    dest = '/tmp/1'

    write_changes(test_module, b_lines, dest)
    assert re.match(r'/tmp/.*\.tmp\d+', test_module._backup_name)
