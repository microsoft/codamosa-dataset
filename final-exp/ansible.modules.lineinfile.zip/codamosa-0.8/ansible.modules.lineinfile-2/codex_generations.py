

# Generated at 2022-06-11 07:21:42.367560
# Unit test for function main
def test_main():

    def test_params(module, params=None):
        if params:
            for param, value in params.items():
                module.params[param] = value


# Generated at 2022-06-11 07:21:52.633175
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Boiler-plate: setup a test module
    set_module_args(dict(
        path='/file',
        mode='0777',
        owner='root',
        group='wheel',
    ))
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.check_mode = True

    # Test
    module.set_fs_attributes_if_different = lambda args, changed, diff=None: True
    message, changed = check_file_attrs(module, False, 'message', 'diff')

    # Assertions
    assert changed
    assert 'ownership' in message
    assert 'perms' in message
    assert 'SE linux context' in message



# Generated at 2022-06-11 07:22:00.214643
# Unit test for function main

# Generated at 2022-06-11 07:22:10.633791
# Unit test for function absent
def test_absent():
    # start docker'd module test
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True),
            regexp=dict(required=True),
            search_string=dict(required=True),
            line=dict(required=True),
            backup=dict(required=True),
        ),
        supports_check_mode=True,
    )

    # test default parameters with check_mode on
    src = '/home/ansible/test_absent'
    dest = '/tmp/test_absent'
    regexp = '^some*'
    search_string = '^some*'
    line = 'test line'
    backup = True

    absent(module, dest, regexp, search_string, line, backup)



# Generated at 2022-06-11 07:22:20.165696
# Unit test for function check_file_attrs
def test_check_file_attrs():

    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO

    # Test module import
    test_module_name = 'ansible.module_utils.basic'
    test_module = __import__(test_module_name)
    for part in test_module_name.split('.')[1:]:
        test_module = getattr(test_module, part)
    test_module = getattr(test_module, 'AnsibleModule')

    # create a module for this test
    test_module_args = dict(
        path="/tmp/testfile",
        owner="root",
        group="root",
        mode="644",
        )
    test_module_obj = test_module(
        argument_spec=dict(),
        supports_check_mode=True,
    )


# Generated at 2022-06-11 07:22:30.113344
# Unit test for function absent
def test_absent():
    module.params['path'] = '/tmp/test_absent_file'
    module.params['state'] = 'absent'
    module.params['line'] = 'test'
    module.params['create'] = True
    module.params['replace'] = 'yes'
    temp_file = open(module.params['path'], 'w')
    temp_file.write('test\ntest')
    temp_file.close()
    module.exit_json = exit_json
    result = absent(module, module.params['path'], None, None, module.params['line'], module.params['backup'])
    assert result['changed']


# Generated at 2022-06-11 07:22:42.520696
# Unit test for function write_changes
def test_write_changes():
    from ansible_collections.ansible.community.tests.unit.compat import unittest

    data = b'hello there\n'

    for unsafe in [True, False]:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpfd, tmpfile = tempfile.mkstemp(dir=tmpdir)
            with open(tmpfile, 'wb') as f:
                f.write(data)

            module = MagicMock()
            module.params = {'unsafe_writes': unsafe}
            module.run_command = MagicMock(return_value=(0, '', ''))
            module.atomic_move = MagicMock()
            module.tmpdir = tmpdir

            write_changes(module, b'hello world\n', tmpfile)
            assert module.atomic_move.called

            assert open

# Generated at 2022-06-11 07:22:49.236918
# Unit test for function write_changes
def test_write_changes():
    from ansible import constants as C
    from ansible.utils.path import makedirs_safe
    module = AnsibleModule({'dest': '/tmp/test.txt', 'validate': 'echo %s'}, False)
    makedirs_safe(C.DEFAULT_LOCAL_TMP, 0o750)
    m = re.search(r'(.*)', 'ansible')
    assert m, "Unit test failed"
    # Set Environment Variable
    global C
    C.DEFAULT_LOCAL_TMP = 'test'
    assert write_changes(module, b'123\n456\n', '/tmp/test.txt')

# Generated at 2022-06-11 07:23:01.263972
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
            search_string=dict(type='str', default=None),
        ),
        supports_check_mode=True,
        add_file_common_args=True,
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    changed = False
    found = 0
    backup = module.params['backup']
    if module.params['backup']:
        backup = module.params['backup']

    b_dest

# Generated at 2022-06-11 07:23:06.524601
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False)
        ),
        supports_check_mode=True
    )
    dest = '/tmp/file_absent'
    regexp = 'foo'
    search_string = 'bar'
    line = 'foo'
    backup = True
    absent(module, dest, regexp, search_string, line, backup)



# Generated at 2022-06-11 07:23:59.824407
# Unit test for function absent
def test_absent():
    # The test requires a line to remove and a line in the file that matches
    # the regexp to test the function and file to test against.
    line = "Replace me!"
    line_to_remove = "Replace me!"
    regexp_to_remove = 'Replace me!'
    regexp_in_file = 'This is a test'
    test_file = "test_file"
    test_file_contents = "This is a test\n" + line + "\n" + regexp_in_file + "\n"

    def write_file(module, dest, contents):
        b_dest = to_bytes(dest, errors='surrogate_or_strict')
        b_contents = to_bytes(contents, errors='surrogate_or_strict')

# Generated at 2022-06-11 07:24:07.932311
# Unit test for function main
def test_main():
  lines = []
  lines.append("1")
  lines.append("2")
  lines.append("3")
  lines.append("4")
  lines.append("5")
  lines.append("6")
  lines.append("7")
  lines.append("8")

  insertafter = "3"
  insertbefore = "4"

  for line in lines:
    if '4' == line:
      print()
    else:
      print(line)
    
    

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:24:16.829797
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.connection import Connection
    from io import StringIO
    import os
    import json
    import pytest
    import sys

    def get_exception():
        exc_type, exc_value, exc_traceback = sys.exc_info()
        return exc_value

    def AnsibleExitJson(module, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise SystemExit(json.dumps({'failed': False, 'changed': True, **kwargs}))

    def AnsibleFailJson(module, **kwargs):
        kwargs['failed'] = True
        raise SystemExit(json.dumps(kwargs))

# Generated at 2022-06-11 07:24:23.531312
# Unit test for function main
def test_main():
    def test_class(module_mock, tmpdir_mock):
        return main()
    test_values_instance = TestValues()
    test_values_instance.return_value = None
    test_values_instance.ins_bef = None
    test_values_instance.ins_aft = 'EOF'
    result = test_class(test_values_instance, test_values_instance.path)
    assert result == None


# Generated at 2022-06-11 07:24:30.438676
# Unit test for function present
def test_present():
  module = AnsibleModule({'dest':'dummy_file','line':'dummy_line','backup':'yes','state':'present','insertafter':'dummy_string','regexp':'dummy_regexp'})
  dest = os.getcwd()  
  present(module, dest, 'dummy_regexp', None, 'dummy_line', 'dummy_string', None, False, None, False, False)

# Generated at 2022-06-11 07:24:31.136987
# Unit test for function check_file_attrs
def test_check_file_attrs():
    pass



# Generated at 2022-06-11 07:24:31.867680
# Unit test for function write_changes
def test_write_changes():
    write_changes()



# Generated at 2022-06-11 07:24:37.207336
# Unit test for function check_file_attrs
def test_check_file_attrs():
    m = AnsibleModule(
        argument_spec=dict(
            unsafe_writes=dict(type='bool', default=False)
        )
    )
    m.params = dict(
        unsafe_writes=m.boolean(False)
    )
    check_file_attrs(m, False, "", "")


# Generated at 2022-06-11 07:24:44.623619
# Unit test for function present
def test_present():
    module = AnsibleModule({'backup': False,
                            'content': 'this is a test',
                            'create': True,
                            'dest': '/tmp/testfile',
                            'insertafter': None,
                            'insertbefore': None,
                            'line': None,
                            'mode': None,
                            'owner': None,
                            'regexp': None,
                            'remote_src': None,
                            'selevel': None,
                            'serole': None,
                            'setype': None,
                            'seuser': None,
                            'src': None,
                            'unsafe_writes': None,
                            'validate': None})

# Generated at 2022-06-11 07:24:56.211443
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    # write changes test
    dest = '/tmp/testfile_lineinfile'
    b_lines = to_bytes("abc\n123\nxyz\n", errors='surrogate_or_strict')
    module = AnsibleModule({'tmpdir': '/tmp'})
    try:
        write_changes(module, b_lines, dest)
        # Check if write_changes has written correct lines to the file
        with open(dest, 'r') as f:
            content = f.readlines()
            assert(content == ["abc\n", "123\n", "xyz\n"])
    finally:
        # Clean up the test file
        os.remove(dest)


# Generated at 2022-06-11 07:25:54.267636
# Unit test for function present
def test_present():
    module = AnsibleModule({'path': '/tmp/x.conf',
                            'search': 'string',
                            'regexp': '^string',
                            'line': 'line',
                            'insertbefore': 'mytest',
                            'insertafter': 'mytest',
                            'create': True,
                            'backrefs': True})
    present(module, '/tmp/x.conf', '^string', 'string', 'line', 'mytest', 'mytest', True, True, True)


# Generated at 2022-06-11 07:26:07.447324
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({'path': '/tmp/fake1', 'owner': 'root',
        'group': 'root', 'mode': '640',
        'seuser': 'unconfined_u', 'serole': 'object_r',
        'setype': 'etc_t', 'secontrol': False})
    module.params['follow'] = False
    attrs = module.load_file_common_arguments(module.params)

    changed = False
    message = "test_check_file_attrs"
    diff = {'before': {'fake1:a': 'fake1:a'},
            'after': {'fake1': 'fake1'}}
    result = check_file_attrs(module, changed, message, diff)

# Generated at 2022-06-11 07:26:18.158655
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            dest = dict(type='path'),
            regexp  = dict(default=None, type='str'),
            search_string = dict(default=None, type='str'),
            line = dict(type='str'),
            insertafter = dict(default=None, type='str'),
            insertbefore = dict(default=None, type='str'),
            create = dict(default=False, type='bool'),
            backup = dict(default=False, type='bool'),
            backrefs = dict(default=False, type='bool'),
            validate = dict(default=None, type='str'),
            unsafe_writes = dict(default=False, type='bool')
        )
    )

    # assemble data structures
    dest = "/path/to/a/file"
   

# Generated at 2022-06-11 07:26:27.133739
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=True),
            firstmatch=dict(type='bool', default=False),
            state=dict(default='present', choices=['present', 'absent']),
        ),
        supports_check_mode=True,
    )

    # Check parameters
    # On state 'absent' regexp

# Generated at 2022-06-11 07:26:27.970511
# Unit test for function write_changes
def test_write_changes():
    # TODO: Implement unit test
    pass


# Generated at 2022-06-11 07:26:29.130663
# Unit test for function check_file_attrs
def test_check_file_attrs():
    check_file_attrs(module, True, 'Hello', 'diff')


# Generated at 2022-06-11 07:26:39.179456
# Unit test for function absent
def test_absent():
    test_name = "test_absent"
    test_module = AnsibleModule(name=test_name,
                                argument_spec=dict(dest=dict(type='path', required=True),
                                                   regexp=dict(type='str'),
                                                   line=dict(type='str', required=True),
                                                   search_string=dict(type='str'),
                                                   backup=dict(type='bool', default=False),
                                                   diff_peek=dict(type='bool', default=False),
                                                   _diff=dict(type='bool', default=True)
                                                   ),
                                supports_check_mode=True
                                )
    # create test file with some content
    test_src_file = "/tmp/test_src_file"

# Generated at 2022-06-11 07:26:50.160711
# Unit test for function check_file_attrs
def test_check_file_attrs():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    def mock_set_fs_attributes_if_different(file_args, changed, diff):
        class fake_args:
            ownershi = 'root'
            group = 'root'
            mode = '0644'
        file_args = fake_args
        return True
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['owner'] = 'root'
            self.params['group'] = 'root'
            self.params['mode'] = '0644'

# Generated at 2022-06-11 07:27:00.946456
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.tests.unit.compat.mock import patch


# Generated at 2022-06-11 07:27:04.619876
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    lines = b'Test file'
    dest = 'dest'
    write_changes(module, lines, dest)
    assert os.path.isfile('dest')
    assert open('dest').read().strip() == 'Test file'
    os.remove('dest')


# Generated at 2022-06-11 07:28:43.607571
# Unit test for function absent
def test_absent():
    test_module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True),
            regexp=dict(required=False),
            search_string=dict(required=False),
            line=dict(required=False),
            backup=dict(required=False, default=False)
        )
    )
    dest = "test-path"
    module = test_module
    test_module.exit_json = _exit_json
    test_module.fail_json = _fail_json
    test_module.backup_local = _backup_local
    # Unit test for function absent
    regexp = None
    search_string = None
    line = "test-data"
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-11 07:28:45.644401
# Unit test for function absent
def test_absent():
    assert absent("module", "dest", "regexp", "search_string", "line", "backup") == "file not present"


# Generated at 2022-06-11 07:28:55.098107
# Unit test for function present
def test_present():
    dest = tempfile.NamedTemporaryFile()
    regexp = '^$'
    line = 'test'
    insertafter = 'EOF'
    insertbefore = 'EOF'
    create = True
    backup = False
    backrefs = False
    firstmatch = False
    expected_res = True

    dest_content = []
    with open(dest.name, 'r') as f:
        dest_content = f.readlines()
    assert(dest_content == [])

    present(dest.name, regexp, None, line, insertafter, insertbefore, create, backup, backrefs, firstmatch)

    dest_content = []
    with open(dest.name, 'r') as f:
        dest_content = f.readlines()
    assert(dest_content == ['test\n'])


# Generated at 2022-06-11 07:29:03.415565
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({})
    changed = True
    message = "changed"
    diff = "diff"
    new_diff = "new diff"
    assert check_file_attrs(module, changed, message, diff) == (message, changed)
    module.params['unsafe_writes'] = True
    assert check_file_attrs(module, changed, message, diff) == (message, changed)
    module.params = {'owner': 'root', 'group': 'root', 'mode': '0600'}
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    os.close(tmpfd)
    tmp_kbfile = '%s%s' % (tmpfile, '~')
    open(tmpfile, 'a').close()

# Generated at 2022-06-11 07:29:07.371214
# Unit test for function main
def test_main():
    create = False
    backup = False
    backrefs = False
    path = "file_name"
    firstmatch = False
    regexp = None
    search_string = None
    line = "line"
    present(AnsibleModule, path, regexp, search_string, line,
                None, None, create, backup, backrefs, firstmatch)
    absent(AnsibleModule, path, regexp, search_string, line, backup)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:29:16.031273
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.six.moves import StringIO
    from ansible.modules.files.lineinfile import check_file_attrs
    import ansible
    import ansible.module_utils
    import ansible.module_utils.basic
    import ansible.module_utils.common.file
    import ansible.module_utils.ansible_release
    import ansible.module_utils.network.common.utils
    import ansible.module_utils.six
    import ansible.module_utils.urls
    import ansible.module_utils.facts
    import io
    module = ansible.module_utils.network.common.utils.load_platform_subclass(
        ansible.module_utils.basic.AnsibleModule,
        'main'
    )

# Generated at 2022-06-11 07:29:24.828365
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'backrefs': False,
        'backup': '',
        'create': False,
        'dest': 'insertafter',
        'firstmatch': False,
        'insertafter': 'a',
        'insertbefore': '',
        'line': 'c',
        'regexp': None,
        'search_string': None,
        '_diff': True,
        'unsafe_writes': False
    })
    msg = 'file does not exist'
    assert not module.check_mode
    assert {'changed': True, 'msg': msg} == present(module, 'insertafter', None, None, 'c', 'a', '', True, '', False, False)



# Generated at 2022-06-11 07:29:26.900354
# Unit test for function absent
def test_absent():
    res = absent(dest, regexp, search_string, line, backup)
    assert res == "Hello from absent()"

# Generated at 2022-06-11 07:29:36.805752
# Unit test for function write_changes

# Generated at 2022-06-11 07:29:39.635827
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = DummyModule()
    module.params = {'path': 'test_path', 'unsafe_writes': True}
    setattr(module, 'set_fs_attributes_if_different', lambda *args: True)
    assert (check_file_attrs(module, False, '', {}) == ("ownership, perms or SE linux context changed", True))
    assert (check_file_attrs(module, True, "Changes", {}) == ("Changes and ownership, perms or SE linux context changed", True))

