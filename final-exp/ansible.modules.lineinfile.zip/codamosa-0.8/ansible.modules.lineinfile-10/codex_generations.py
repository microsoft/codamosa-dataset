

# Generated at 2022-06-11 07:21:35.526492
# Unit test for function write_changes
def test_write_changes():
    tempfile_object = tempfile.mkdtemp()
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    write_changes(module, b_lines="test", dest="%s/testfile" % tempfile_object)
    assert isinstance(module.atomic_move.call_count, int)


# Generated at 2022-06-11 07:21:43.294649
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'path': '/path/to/file',
        'state': 'present',
        'line': 'foobar'
    })
    assert present(module, '/path/to/file', None, None, 'foobar', None, None, True, False, False, True) == (False, '', '')
    module = AnsibleModule({
        'path': '/path/to/file',
        'state': 'present',
        'line': 'foobar',
        'insertafter': 'foo'
    })
    assert present(module, '/path/to/file', None, None, 'foobar', 'foo', None, True, False, False, True) == (False, '', '')

# Generated at 2022-06-11 07:21:49.501827
# Unit test for function main
def test_main():
    with tempfile.TemporaryFile() as temp_file:
        temp_file.write(b'Hello World\n')
        temp_file.flush()
        temp_file.seek(0)

        path = temp_file.name

        module = MagicMock()


# Generated at 2022-06-11 07:21:57.589152
# Unit test for function present

# Generated at 2022-06-11 07:22:10.246810
# Unit test for function present

# Generated at 2022-06-11 07:22:18.721104
# Unit test for function main

# Generated at 2022-06-11 07:22:30.168531
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(default='/tmp/foo'),
            regexp=dict(),
            insertafter=dict(),
            insertbefore=dict(),
            line=dict(),
            create=dict(type='bool', default='yes'),
            backup=dict(type='bool', default='no'),
            backrefs=dict(type='bool', default='no'),
            firstmatch=dict(type='bool', default='no'),
            delimiter=dict(default='\n'),
            encoding=dict(default='UTF-8'),
            errors=dict()
        )
    )

    string = '1\n2\n3\n'
    lines = [x + '\n' for x in string]

# Generated at 2022-06-11 07:22:42.520060
# Unit test for function present
def test_present():
    def do_test(module_args, result):
        module = AnsibleModule(
            argument_spec=module_args,
            supports_check_mode=True)

        for atomic in (True, False):
            setattr(module, '_diff_peek', lambda *args, **kwargs: result['diff'])
            setattr(module, 'atomic_move', lambda src, dest, unsafe_writes=False: None)
            setattr(module, 'params', {'backup': False,
                                       'unsafe_writes': atomic})
            obj = Lineinfile(module)
            obj.present()


# Generated at 2022-06-11 07:22:49.587008
# Unit test for function write_changes
def test_write_changes():
    test_module = AnsibleModule({
        'dest': '/tmp/testfile',
        'create': True,
        'validate': 'echo %s',
        'unsafe_writes': False
    })
    test_lines = to_bytes('change')
    try:
        write_changes(test_module, test_lines, '/tmp/testfile')
        with open('/tmp/testfile', 'rb') as f:
            assert f.read() == 'change'
    finally:
        os.unlink('/tmp/testfile')


# Generated at 2022-06-11 07:22:53.314958
# Unit test for function check_file_attrs
def test_check_file_attrs():

    assert check_file_attrs(mock, False, "msg", "diff") == ('msg and ownership, perms or SE linux context changed', True)



# Generated at 2022-06-11 07:23:48.301663
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = FakeAnsibleModule()
    module.params = {'path': '/tmp/test_file', 'owner': 'testowner'}
    module.set_fs_attributes_if_different = lambda args, unsafe, diff: False
    msg, changed = check_file_attrs(module, True, "test message", "test diff")
    assert msg == "test message"
    assert changed

    module.set_fs_attributes_if_different = lambda args, unsafe, diff: True
    msg2, changed2 = check_file_attrs(module, True, "test message", "test diff")
    assert msg2 == "test message and ownership, perms or SE linux context changed"
    assert changed2


# Generated at 2022-06-11 07:23:49.514710
# Unit test for function write_changes
def test_write_changes():
    assert 0 == 0


# Generated at 2022-06-11 07:24:00.790650
# Unit test for function absent
def test_absent():
    # check_file_attrs will return [False, '', {}]
    module = MagicMock()
    dest = 'a/path/to/a/file'
    regexp = r'^#'
    search_string = r'^#search'
    line = '#'
    backup = False
    module.selinux_enabled.return_value = False
    matcher = mock_open(read_data=b'line1\nline2\nline3\nline4\n')

    with patch('os.path.exists', return_value=True):
        with patch('os.path.isdir', return_value=True):
            with patch('six.moves.builtins.open', matcher):
                absent(module, dest, regexp, search_string, line, backup)

    # Should return

# Generated at 2022-06-11 07:24:10.989083
# Unit test for function present
def test_present():
  module = AnsibleModule(
      argument_spec=dict(
      state=dict(default='present', choices=['absent', 'present']),
      path=dict(type='path', default=None),
      create=dict(default='no', type='bool'),
      line=dict(default=None),
      insertbefore=dict(default=None),
      insertafter=dict(default=None),
      regexp=dict(default=None),
      search_string=dict(default=None),
      backup=dict(default=None, type='path'),
      backrefs=dict(default=None, type='bool'),
      firstmatch=dict(default=None, type='bool')
  )
  )



# Generated at 2022-06-11 07:24:17.080957
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            tmpdir=dict(type='str', required=True),
            dest=dict(type='str', required=True),
            unsafe_writes=dict(type='bool', required=True),
        ),
        supports_check_mode=True
    )
    lines = "I am not a string"
    dest = "/tmp/not_a_file"
    try:
        assert write_changes(module, lines, dest) == None
    except SystemExit as e:
        assert e.code != 0
    else:
        assert False


# Generated at 2022-06-11 07:24:28.738305
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    # Read in test vars
    module_path = os.path.join(os.path.dirname(__file__), 'args_main_ut.json')
    module_data = {}
    with open(module_path) as module_args:
        module_data = json.load(module_args)

    # Setup mock objects
    module_mock = MagicMock(AnsibleModule)
    module_mock.params = module_data

    # List of modules to be called in order
    module_list = [module_mock, os]

    with patch.object(sys, 'modules', module_list):
        main()

    # Now test how the parameters were passed to the module
    dest

# Generated at 2022-06-11 07:24:39.675910
# Unit test for function absent
def test_absent():

    b_lines = [b'line1', b'line2']
    current_line = b'line1'
    def matcher(b_cur_line):
        return b_cur_line != current_line

    assert absent(None, None, None, None, None, None, b_lines, current_line, matcher) == [b'line2']
    current_line = b'line2'
    assert absent(None, None, None, None, None, None, b_lines, current_line, matcher) == [b'line1']
    current_line = b'line3'
    assert absent(None, None, None, None, None, None, b_lines, current_line, matcher) == [b'line1', b'line2']


# Generated at 2022-06-11 07:24:41.441085
# Unit test for function write_changes
def test_write_changes():
    # Tested by unit tests in test/units/modules/utils/file_common.py
    pass



# Generated at 2022-06-11 07:24:53.907212
# Unit test for function present
def test_present():
    # Find the first occurrence of a line in a file
    # when file contains only one line
    result = present(module, dest, regexp, None, line, None, None, create, backup, backrefs, True)
    assert result == (True, "Changed", '', {'before': 'line1\n', 'after': 'line1\n', 'before_header': 'dest (content)', 'after_header': 'dest (content)'})

    # Find the first occurrence of a line in a file
    # when file contains multiple lines
    result = present(module, dest, regexp, None, line, None, None, create, backup, backrefs, True)

# Generated at 2022-06-11 07:25:02.221771
# Unit test for function absent
def test_absent():
    import shutil
    import tempfile
    import filecmp
    import os
    import os.path
    import re
    dest = tempfile.mktemp()
    shutil.copy('/etc/hosts', dest)

    # regexp test
    from units.compat.mock import patch
    with patch.multiple(Basic, exit_json=exit_json, fail_json=fail_json):
        module = AnsibleModule({'dest': dest, 'regexp': '127.0.0.1'})
        absent(module, dest, '127.0.0.1', None, None, None)
    loop_tol(os.path.exists(dest), True, 20, True)
    loop_tol(len(open(dest, 'r').readlines()), 1, 20, True)

# Generated at 2022-06-11 07:25:41.124572
# Unit test for function write_changes
def test_write_changes():
    # This is a test stub.
    pass



# Generated at 2022-06-11 07:25:50.680669
# Unit test for function absent
def test_absent():
    module = get_module_mock()
    dest = '/tmp/test.txt'

    # no line found
    module.check_mode = False
    os.makedirs('/tmp')
    write_changes(module, [b'123\n', b'456\n'], dest)
    absent(module, dest, None, None, '789', False)
    changed = read_changes(dest)
    assert changed == [b'123\n', b'456\n']

    # line found
    module.check_mode = False
    write_changes(module, [b'123\n', b'456\n'], dest)
    absent(module, dest, None, None, '456', False)
    changed = read_changes(dest)
    assert changed == [b'123\n']

    # line removed


# Generated at 2022-06-11 07:25:59.923770
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(required=True),
            regexp=dict(),
            search_string=dict(),
            line=dict(required=True),
            backup=dict(default=True, type='bool'),
        ),
        supports_check_mode=True
    )
    dest = '/tmp/test_absent'
    regexp = None
    search_string = None
    line = 'absent'
    backup = True
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-11 07:26:06.653295
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    b_lines = [b"a\n", b"b\n", b"c\n"]
    dest = b"/tmp/testfile"
    write_changes(module, b_lines, dest)
    outfile = open(dest, "rb")
    result = outfile.readlines()
    outfile.close()
    assert result == b_lines



# Generated at 2022-06-11 07:26:17.600863
# Unit test for function main
def test_main():
    # set up required constants
    _CREATE = False
    _BACKUP = False
    _FIRST_MATCH = False
    _BACKREF = 1
    _SEARCH_STRING = 'search_string'
    _REGEXP = 'regexp'
    _LINE = 'line'
    _ABSENT = 'absent'

# Generated at 2022-06-11 07:26:22.546124
# Unit test for function absent
def test_absent():
    abs_dest = '/etc/ansible/absent.txt'
    if os.path.exists(abs_dest):
        os.remove(abs_dest)

    if os.path.exists(abs_dest):
        print("Error :")
        print("Destination file already exists: %s" % abs_dest)
        sys.exit(1)

    abs_regexp = None
    abs_line = "absent_line"

    with open(abs_dest, 'w') as f:
        f.write("present_line\n")

    # Do not comment out other lines, as the regexp is None
    with open(abs_dest, 'a+') as f:
        f.write("present_line\n")
        f.write(abs_line)


# Generated at 2022-06-11 07:26:30.223336
# Unit test for function absent
def test_absent():
    """
    Test function with params:
    :
    :
    """
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True),
            regexp=dict(required=False),
            search_string=dict(required=False),
            line=dict(required=False),
            backup=dict(required=False),
        )
    )
    result = absent(module,
                    dest=module.params['dest'],
                    regexp=module.params['regexp'],
                    search_string=module.params['search_string'],
                    line=module.params['line'],
                    backup=module.params['backup'],
                    )

# Generated at 2022-06-11 07:26:40.554994
# Unit test for function main

# Generated at 2022-06-11 07:26:51.448836
# Unit test for function main
def test_main():
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_data_dir = os.path.join(test_dir, 'unit')
    with open(os.path.join(test_data_dir, "lineinfile_unit_tests_script.json"), 'r') as u_tests_file:
        for test in json.load(u_tests_file):
            if 'lineinfile' in test:
                try:
                    result = main()
                except Exception as error:
                    print(test['test_name'])
                    print(error)
                    # Return -1 for exception
                    return -1
                # Return the number of failed test cases
                if result:
                    print(test['test_name'])
                    return 1
    # All tests passed
    return 0



# Generated at 2022-06-11 07:26:59.484916
# Unit test for function main
def test_main():
    test_args = [
        {
            u'line': u'127.0.0.1\tlocalhost',
            u'regexp': None,
            u'search_string': None,
            u'path': u'/etc/hosts',
            u'insertbefore': None,
            u'backrefs': None,
            u'create': None,
            u'backup': None,
            u'insertafter': None,
            u'state': u'present'
        }
    ]
    main(test_args)


# Generated at 2022-06-11 07:28:13.916199
# Unit test for function write_changes
def test_write_changes():
    assert True


# Generated at 2022-06-11 07:28:24.424709
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule, load_platform_subclass
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import module_common_argument_spec
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import is_executable

    module = AnsibleModule(
        argument_spec = module_common_argument_spec,
        supports_check_mode=False,
        required_one_of=[['content', 'src', 'regexp']],
        mutually_exclusive=[['content', 'src']]
    )


# Generated at 2022-06-11 07:28:26.010439
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(module, changed, message, diff) == ('ownership, perms or SE linux context changed', True)


# Generated at 2022-06-11 07:28:34.817612
# Unit test for function main
def test_main():
    test_set1 = dict (
        path = '/root/testdir/testfile',
        regexp = 'test_regexp',
        search_string = 'test_str',
        line = 'test_line',
        insertbefore = 'test_insertbefore',
        insertafter = 'test_insertafter',
        create = True,
        backup = True,
        firstmatch = True,
        validate = 'test_validate',
    )

# Generated at 2022-06-11 07:28:38.730149
# Unit test for function check_file_attrs
def test_check_file_attrs():
    '''
    Test check_file_attrs
    '''
    changed = True
    message = "Changed ownership, perms or SE linux context"
    results = check_file_attrs(changed, message)
    assert results[0] == message
    assert results[1] == changed



# Generated at 2022-06-11 07:28:48.151743
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def capture_output(command, *args, **kwargs):
        out, sys.stdout = sys.stdout, StringIO()
        command(*args, **kwargs)
        sys.stdout.seek(0)
        yield sys.stdout.read()
        sys.stdout = out

    def test_absent(module, path, regexp, search_string, line, backup):
        with open(path, 'wb+') as f:
            f.write(b'HelloWorld\n')

        setattr(module, 'check_mode', False)

# Generated at 2022-06-11 07:28:57.447585
# Unit test for function present
def test_present():

    def test_run(module_args, dest, regexp, search_string, line, insertafter, insertbefore, create,
                 backup, backrefs, firstmatch):

        module_args.update(
            dict(
                path=dest,
                regexp=regexp,
                search_string=search_string,
                line=line,
                insertafter=insertafter,
                insertbefore=insertbefore,
                create=create,
                backup=backup,
                backrefs=backrefs,
                firstmatch=firstmatch
            )
        )

        module = AnsibleModule(
            argument_spec=module_args,
            supports_check_mode=True
        )

# Generated at 2022-06-11 07:29:04.001090
# Unit test for function main
def test_main():
    path=r'D:\code\code\python\ansible_code\file\test1.txt'
    regexp=r'(?P<word>\w+)'
    search_string=r''
    line=r''
    ins_aft=r'EOF'
    ins_bef=r''
    create=False
    backup=False
    backrefs=False
    firstmatch=False

    main(path,regexp,search_string,line,ins_aft,ins_bef,create,backup,backrefs,firstmatch)


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:29:04.477056
# Unit test for function present
def test_present():
    pass


# Generated at 2022-06-11 07:29:08.056871
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = dict(
        path='/etc/passwd',
        owner='root'
    )
    changed = False
    message = "ownership, perms or SE linux context changed"
    assert message == check_file_attrs(module, changed, message, [])[0]
