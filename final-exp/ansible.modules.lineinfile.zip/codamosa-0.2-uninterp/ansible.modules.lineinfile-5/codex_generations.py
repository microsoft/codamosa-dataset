

# Generated at 2022-06-17 04:45:06.227592
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True),
            owner = dict(type='str'),
            group = dict(type='str'),
            mode = dict(type='str'),
            seuser = dict(type='str'),
            serole = dict(type='str'),
            setype = dict(type='str'),
            selevel = dict(type='str'),
        )
    )
    module.params['path'] = '/tmp/testfile'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0644'
    module.params['seuser'] = 'system_u'
    module.params['serole'] = 'object_r'

# Generated at 2022-06-17 04:45:17.157496
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3

    def set_module_args(args):
        args = json.dumps({'ANSIBLE_MODULE_ARGS': args})
        basic._ANSIBLE_ARGS = to_bytes(args)

    def call_module(module, *args, **kwargs):
        set_module_args(module)

# Generated at 2022-06-17 04:45:21.779730
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed = True
    message = "ownership, perms or SE linux context changed"
    diff = {}
    assert check_file_attrs(module, changed, message, diff) == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-17 04:45:29.823007
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile',
                     'owner': 'root',
                     'group': 'root',
                     'mode': '0644',
                     'unsafe_writes': True}
    changed = False
    message = ''
    diff = {'before_header': '',
            'before': '',
            'after_header': '',
            'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 04:45:38.737197
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str', required=False),
            search_string=dict(type='str', required=False),
            line=dict(type='str', required=False),
            backup=dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=True
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:45:47.662613
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil


# Generated at 2022-06-17 04:45:56.536483
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = '/tmp/test_present'

# Generated at 2022-06-17 04:46:02.685294
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str', required=False),
            search_string=dict(type='str', required=False),
            line=dict(type='str', required=True),
            insertafter=dict(type='str', required=False),
            insertbefore=dict(type='str', required=False),
            create=dict(type='bool', required=False, default=False),
            backup=dict(type='bool', required=False, default=False),
            backrefs=dict(type='bool', required=False, default=False),
            firstmatch=dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=True
    )

# Generated at 2022-06-17 04:46:14.235275
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    dest = module.params.get

# Generated at 2022-06-17 04:46:20.625045
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed = False
    message = ""
    diff = {}
    module.params = {'path': '/etc/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'seuser': 'system_u', 'serole': 'object_r', 'setype': 'httpd_sys_content_t', 'selevel': 's0'}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == "ownership, perms or SE linux context changed"
    assert changed == True


# Generated at 2022-06-17 04:46:53.867203
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:47:02.143756
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:47:11.972979
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = '/tmp/test_absent'
    regexp = '^test'
    search_string = 'test'
    line = 'test'
    backup = True
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:47:21.306010
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            line=dict(type='str', required=True),
            dest=dict(type='path', required=True),
            validate=dict(type='str', required=True),
            unsafe_writes=dict(type='bool', required=True),
        ),
        supports_check_mode=True,
    )
    b_lines = [b'foo\n', b'bar\n']
    dest = '/tmp/test_write_changes'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines



# Generated at 2022-06-17 04:47:30.465525
# Unit test for function check_file_attrs

# Generated at 2022-06-17 04:47:41.579620
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:47:52.599491
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/testfile',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'seuser': 'system_u',
        'serole': 'object_r',
        'setype': 'var_log_t',
        'selevel': 's0',
        'unsafe_writes': False
    }
    changed = True
    message = "ownership, perms or SE linux context changed"

# Generated at 2022-06-17 04:48:01.012015
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_fs_attributes_if_different = lambda x, y, diff: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message, diff=False)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 04:48:11.496478
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str', required=False),
            search_string=dict(type='str', required=False),
            line=dict(type='str', required=True),
            insertafter=dict(type='str', required=False),
            insertbefore=dict(type='str', required=False),
            create=dict(type='bool', required=False, default=False),
            backup=dict(type='bool', required=False, default=False),
            backrefs=dict(type='bool', required=False, default=False),
            firstmatch=dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-17 04:48:16.128262
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = 'test_file'
    regexp = '^test_line'
    search_string = 'test_line'
    line = 'test_line'
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:48:57.052614
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    changed = False
    message = ''
    diff = {'before_header': '', 'after_header': '', 'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 04:49:06.252886
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str'),
            line=dict(type='str'),
            dest=dict(type='path', required=True),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    b_lines = [b'foo\n', b'bar\n', b'baz\n']
    dest = '/tmp/test_write_changes'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines
    os.unlink(dest)



# Generated at 2022-06-17 04:49:15.253789
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = '/tmp/test_absent'
    regexp = '^test'
    search_string = 'test'
    line = 'test'
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:49:19.967546
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = module.params['dest']

# Generated at 2022-06-17 04:49:28.496299
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    # Create a test file
    test_file = tempfile.N

# Generated at 2022-06-17 04:49:34.050057
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'seuser': 'system_u', 'serole': 'object_r', 'setype': 'etc_t', 'selevel': 's0'}
    changed = False
    message = ''
    diff = ''
    return_message, return_changed = check_file_attrs(module, changed, message, diff)
    assert return_message == 'ownership, perms or SE linux context changed'
    assert return_changed == True


# Generated at 2022-06-17 04:49:43.137337
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        add_file_common_args=True,
    )


# Generated at 2022-06-17 04:49:53.777791
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = '/tmp/test_absent'
    regexp = '^test_absent'
    search_string = 'test_absent'
    line = 'test_absent'
    backup = False

    with open(dest, 'w') as f:
        f.write('test_absent\n')
        f.write('test_absent\n')
        f.write('test_absent\n')

# Generated at 2022-06-17 04:50:05.789973
# Unit test for function main

# Generated at 2022-06-17 04:50:12.755559
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': True}
    })
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    b_lines = [b'foo\n', b'bar\n']
    dest = '/tmp/test'
    write_changes(module, b_lines, dest)
    assert module.run_command.call_count == 1
    assert module.atomic_move.call_count == 1

# Generated at 2022-06-17 04:51:35.414942
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ""
    diff = ""
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == "ownership, perms or SE linux context changed"
    assert changed == True



# Generated at 2022-06-17 04:51:43.014551
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = True
    message = "ownership, perms or SE linux context changed"
    diff = {'before_header': '', 'after_header': '', 'before': '', 'after': '', 'before_lines': [], 'after_lines': []}
    assert check_file_attrs(module, changed, message, diff) == ("ownership, perms or SE linux context changed", True)



# Generated at 2022-06-17 04:51:50.221642
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:51:55.862462
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            owner=dict(type='str'),
            group=dict(type='str'),
            mode=dict(type='str'),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            selevel=dict(type='str'),
            setype=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    changed = False
    message = ""
    diff = {}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == ""
    assert changed == False


# Generated at 2022-06-17 04:52:02.756922
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = tempfile.mkdtemp()
    test_lines = [b'foo\n', b'bar\n']
    test_dest = os.path.join(module.tmpdir, 'test_file')
    write_changes(module, test_lines, test_dest)
    with open(test_dest, 'rb') as f:
        assert f.readlines() == test_lines
    os.remove(test_dest)
    os.rmdir(module.tmpdir)



# Generated at 2022-06-17 04:52:14.066440
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile',
                     'owner': 'root',
                     'group': 'root',
                     'mode': '0644',
                     'seuser': 'system_u',
                     'serole': 'object_r',
                     'setype': 'var_log_t',
                     'selevel': 's0',
                     'unsafe_writes': True}
    changed = False
    message = ""
    diff = {'before': {'mode': '0644', 'owner': 'root', 'group': 'root'},
            'after': {'mode': '0644', 'owner': 'root', 'group': 'root'}}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert changed

# Generated at 2022-06-17 04:52:16.157585
# Unit test for function absent
def test_absent():
    assert absent(module, dest, regexp, search_string, line, backup) == (module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:52:22.378216
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    b_lines = [b'foo\n', b'bar\n', b'baz\n']
    dest = '/tmp/test_write_changes'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.read() == b''.join(b_lines)
    os.remove(dest)



# Generated at 2022-06-17 04:52:30.256336
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            owner=dict(type='str'),
            group=dict(type='str'),
            mode=dict(type='str'),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            setype=dict(type='str'),
            selevel=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    changed = False
    message = ''
    diff = {}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == ''
    assert changed == False


# Generated at 2022-06-17 04:52:42.465045
# Unit test for function main