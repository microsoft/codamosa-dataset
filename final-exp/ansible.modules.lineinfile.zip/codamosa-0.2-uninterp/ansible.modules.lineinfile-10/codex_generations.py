

# Generated at 2022-06-17 04:44:52.753489
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 04:45:03.384281
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True),
            owner = dict(type='str'),
            group = dict(type='str'),
            mode = dict(type='str'),
            seuser = dict(type='str'),
            serole = dict(type='str'),
            setype = dict(type='str'),
            selevel = dict(type='str'),
        ),
        supports_check_mode=True
    )
    changed = False
    message = ""
    diff = {}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == ""
    assert changed == False


# Generated at 2022-06-17 04:45:13.325395
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil
    import json

    def setUpModule():
        global tempdir
        tempdir = tempfile.mkdtemp()

    def tearDownModule():
        shutil.rmtree(tempdir)

    def write_file(path, data):
        b_path = to_bytes(path, errors='surrogate_or_strict')
        with open(b_path, 'wb') as f:
            f.write(data)

    def read_file(path):
        b_path = to_bytes(path, errors='surrogate_or_strict')
        with open(b_path, 'rb') as f:
            data = f.read()
        return data


# Generated at 2022-06-17 04:45:16.154765
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = "test message"
    diff = {'after': 'test'}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == "test message and ownership, perms or SE linux context changed"
    assert changed == True


# Generated at 2022-06-17 04:45:22.104669
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:45:30.790776
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            lines=dict(type='list'),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    b_lines = [b'foo\n', b'bar\n']
    dest = '/tmp/test_write_changes'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines



# Generated at 2022-06-17 04:45:42.078351
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            owner = dict(required=False),
            group = dict(required=False),
            mode = dict(required=False),
            seuser = dict(required=False),
            serole = dict(required=False),
            setype = dict(required=False),
            selevel = dict(required=False),
            unsafe_writes = dict(required=False, type='bool', default=False),
        ),
        supports_check_mode=True
    )
    changed = False
    message = ""
    diff = {}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == ""
    assert changed == False
    assert diff == {}


# Generated at 2022-06-17 04:45:50.164864
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'seuser': 'system_u',
        'serole': 'object_r',
        'setype': 'etc_t',
        'selevel': 's0',
        'unsafe_writes': True,
    }
    changed = False
    message = ''

# Generated at 2022-06-17 04:45:56.658233
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            owner=dict(type='str'),
            group=dict(type='str'),
            mode=dict(type='str'),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            setype=dict(type='str'),
            selevel=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    changed = False
    message = ""
    diff = {}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == ""
    assert changed == False


# Generated at 2022-06-17 04:46:04.060256
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = '/tmp/testfile'
    regexp = '^#'
    search_string = '^#'
    line = '#'
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:46:37.171893
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str', required=False),
            search_string=dict(type='str', required=False),
            line=dict(type='str', required=True),
            insertafter=dict(type='str', required=False),
            insertbefore=dict(type='str', required=False),
            create=dict(type='bool', required=False, default=False),
            backup=dict(type='bool', required=False, default=False),
            backrefs=dict(type='bool', required=False, default=False),
            firstmatch=dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-17 04:46:45.771165
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/testfile',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'seuser': 'system_u',
        'serole': 'object_r',
        'setype': 'tmp_t',
        'selevel': 's0',
    }
    changed = False
    message = ''

# Generated at 2022-06-17 04:46:54.989728
# Unit test for function present

# Generated at 2022-06-17 04:47:03.978739
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_fs_attributes_if_different = lambda x, y, diff: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message, diff=None)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 04:47:14.149610
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:47:21.424950
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = '/tmp/test_absent'
    regexp = '^test'
    search_string = 'test'
    line = 'test'
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:47:27.470735
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import json
    import pytest

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    if not PY3:
        pytest.skip("The lineinfile module is not supported on Python 2")

    def setUpModule():
        sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
        sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib'))

    def tearDownModule():
        sys.path.pop()
        sys.path.pop()


# Generated at 2022-06-17 04:47:34.806789
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    dest = '/tmp/test_present'

# Generated at 2022-06-17 04:47:48.014714
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-17 04:47:58.040919
# Unit test for function write_changes

# Generated at 2022-06-17 04:48:46.173941
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:48:55.614047
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 04:49:05.923880
# Unit test for function write_changes

# Generated at 2022-06-17 04:49:16.795895
# Unit test for function absent

# Generated at 2022-06-17 04:49:24.228389
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.check_mode = True
    changed = False
    message = ''
    diff = {'before_header': '', 'after_header': '', 'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 04:49:35.302929
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str'},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False}
    })
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.params['path'] = '/tmp/testfile'
    module.params['validate'] = '/usr/sbin/visudo -cf %s'
    b_lines = [b'192.168.1.99 foo.lab.net foo']
    write_changes(module, b_lines, module.params['path'])


# Generated at 2022-06-17 04:49:44.758762
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')

    test_data = '''
    # This is a test file
    # It has two lines
    # It is used for testing lineinfile
    '''

    with open(test_file, 'w') as f:
        f.write(test_data)


# Generated at 2022-06-17 04:49:55.526004
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'line': {'type': 'str', 'required': True},
        'backrefs': {'type': 'bool', 'default': False},
        'insertafter': {'type': 'str'},
        'insertbefore': {'type': 'str'},
        'create': {'type': 'bool', 'default': False},
        'backup': {'type': 'bool', 'default': False},
        'firstmatch': {'type': 'bool', 'default': False},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False},
    })

# Generated at 2022-06-17 04:50:02.330597
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    # Test case 1:
   

# Generated at 2022-06-17 04:50:11.420100
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    # Test case 1:
    # Test case with regexp, search

# Generated at 2022-06-17 04:51:42.006017
# Unit test for function present
def test_present():
    dest = '/tmp/test_present'
    regexp = '^(.*)Xms(\d+)m(.*)$'
    search_string = 'Xms'
    line = 'Xms${xms}m'
    insertafter = '^(.*)Xms(\d+)m(.*)$'
    insertbefore = None
    create = True
    backup = False
    backrefs = True
    firstmatch = False


# Generated at 2022-06-17 04:51:50.095064
# Unit test for function main

# Generated at 2022-06-17 04:51:58.749766
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    changed = True
    message = "ownership, perms or SE linux context changed"
    diff = {'before': '', 'after': '', 'before_header': '', 'after_header': ''}
    assert check_file_attrs(module, changed, message, diff) == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-17 04:52:06.627033
# Unit test for function write_changes

# Generated at 2022-06-17 04:52:21.146137
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params['path'] = '/tmp/testfile'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0644'
    module.params['seuser'] = 'system_u'
    module.params['serole'] = 'object_r'
    module.params['setype'] = 'etc_t'
    module.params['selevel'] = 's0'
    module.params['unsafe_writes'] = True
    changed = False
    message = ''
    diff = {}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 04:52:30.195130
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    diff = {'before_header': '', 'before': '', 'after_header': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True



# Generated at 2022-06-17 04:52:37.983333
# Unit test for function write_changes

# Generated at 2022-06-17 04:52:47.040269
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:52:58.108368
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:53:06.074646
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import json
    import pytest
    import ansible.module_utils.basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import iterkeys