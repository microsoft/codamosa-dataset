

# Generated at 2022-06-17 04:44:57.133854
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-17 04:45:03.341786
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:45:14.940777
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='path'),
            regexp=dict(required=True, type='str'),
            line=dict(required=True, type='str'),
            backrefs=dict(required=False, type='bool', default=False),
            validate=dict(required=False, type='str'),
            unsafe_writes=dict(required=False, type='bool', default=False),
        ),
        supports_check_mode=True
    )
    b_lines = [b'foo', b'bar', b'baz']
    dest = '/tmp/test_write_changes'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_

# Generated at 2022-06-17 04:45:21.612993
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    dest = module.params['dest']

# Generated at 2022-06-17 04:45:31.025733
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:45:42.182998
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest

    # Save the current working directory
    cwd = os.getcwd()

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(mode='w', delete=False)

    # Write to the temporary file
    temp_file.write('Hello World!')

    # Close the temporary file
    temp_file.close()

    # Change to the temporary directory
    os.chdir(temp_dir)

    # Create a temporary ansible.cfg file

# Generated at 2022-06-17 04:45:49.354257
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/testfile',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True
    }
    changed = False
    message = ''
    diff = {
        'before_header': '',
        'after_header': '',
        'before': '',
        'after': ''
    }
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True



# Generated at 2022-06-17 04:45:56.201260
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            lines=dict(type='list'),
            validate=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    dest = module.params['dest']
    lines = module.params['lines']
    validate = module.params['validate']
    b_lines = [to_bytes(l, errors='surrogate_or_strict') for l in lines]
    write_changes(module, b_lines, dest)


# Generated at 2022-06-17 04:46:00.011283
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    diff = ''
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 04:46:09.571462
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:47:00.756722
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = '/tmp/test_absent'
    regexp = '^#'
    search_string = '^#'
    line = '#'
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:47:04.827558
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile',
                     'owner': 'root',
                     'group': 'root',
                     'mode': '0644',
                     'unsafe_writes': False}
    changed = False
    message = ''
    diff = {'before': '', 'after': ''}
    assert check_file_attrs(module, changed, message, diff) == ('ownership, perms or SE linux context changed', True)


# Generated at 2022-06-17 04:47:14.102514
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            lines=dict(type='list', required=True),
            validate=dict(type='str', required=False),
            unsafe_writes=dict(type='bool', required=False, default=False)
        )
    )
    write_changes(module, [b'foo\n', b'bar\n'], '/tmp/testfile')
    assert os.path.exists('/tmp/testfile')
    with open('/tmp/testfile', 'rb') as f:
        assert f.read() == b'foo\nbar\n'



# Generated at 2022-06-17 04:47:22.419935
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_fs_attributes_if_different = lambda x, y, z: True
    message, changed = check_file_attrs(module, False, '', '')
    assert message == 'ownership, perms or SE linux context changed'
    assert changed is True



# Generated at 2022-06-17 04:47:29.134963
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.set_fs_attributes_if_different = lambda x, y, z: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message, diff=False)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 04:47:33.182409
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ""
    diff = ""
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == "ownership, perms or SE linux context changed"
    assert changed == True


# Generated at 2022-06-17 04:47:45.915868
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
            _diff=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
   

# Generated at 2022-06-17 04:47:55.793501
# Unit test for function write_changes

# Generated at 2022-06-17 04:48:07.410078
# Unit test for function write_changes

# Generated at 2022-06-17 04:48:21.891562
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            owner=dict(type='str'),
            group=dict(type='str'),
            mode=dict(type='str'),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            setype=dict(type='str'),
            selevel=dict(type='str'),
        ),
        supports_check_mode=True
    )
    changed = False
    message = ""
    diff = {}
    module.params['path'] = '/tmp/test'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0644'
    module.params['seuser'] = 'root'
   

# Generated at 2022-06-17 04:49:44.829775
# Unit test for function absent

# Generated at 2022-06-17 04:49:55.604478
# Unit test for function check_file_attrs

# Generated at 2022-06-17 04:50:01.766225
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:50:10.623737
# Unit test for function present

# Generated at 2022-06-17 04:50:23.188922
# Unit test for function main

# Generated at 2022-06-17 04:50:34.562996
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:50:45.221636
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 04:50:53.082402
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    diff = {'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True



# Generated at 2022-06-17 04:51:03.260757
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            owner=dict(type='str'),
            group=dict(type='str'),
            mode=dict(type='str'),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            setype=dict(type='str'),
            selevel=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    changed = False
    message = ''
    diff = ''
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == ''
    assert changed == False


# Generated at 2022-06-17 04:51:11.556411
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'validate': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False},
        'tmpdir': {'type': 'str'},
    })
    b_lines = [b'foo\n', b'bar\n', b'baz\n']
    dest = '/tmp/test_write_changes'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines
    os.remove(dest)



# Generated at 2022-06-17 04:52:28.120652
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile',
                     'owner': 'root',
                     'group': 'root',
                     'mode': '0644',
                     'unsafe_writes': True}
    changed = True
    message = "ownership, perms or SE linux context changed"
    diff = {'before': '', 'after': '', 'before_header': '', 'after_header': ''}
    assert check_file_attrs(module, changed, message, diff) == (message, changed)


# Generated at 2022-06-17 04:52:37.539065
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = '/tmp/test_present'

# Generated at 2022-06-17 04:52:46.330597
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed = False
    message = "test"
    diff = []
    assert check_file_attrs(module, changed, message, diff) == ("test and ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, changed, message, diff) == ("test and ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, changed, message, diff) == ("test and ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, changed, message, diff) == ("test and ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, changed, message, diff) == ("test and ownership, perms or SE linux context changed", True)

# Generated at 2022-06-17 04:52:58.032254
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:53:09.465773
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:53:16.403560
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    import os
    import sys
    import tempfile
    import shutil
    import traceback
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a temporary ansible module

# Generated at 2022-06-17 04:53:26.894265
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    # Test with regexp
   

# Generated at 2022-06-17 04:53:34.622133
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = 'test_file'
    regexp = '^test_line'
    search_string = 'test_line'
    line = 'test_line'
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:53:43.086661
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-17 04:53:52.546963
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            lines=dict(type='list'),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False)
        )
    )
    b_lines = [to_bytes(u'line1\n'), to_bytes(u'line2\n')]
    dest = '/tmp/test_write_changes'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines

