

# Generated at 2022-06-17 04:44:48.213984
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_fs_attributes_if_different = lambda x, y, z: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message, None)
    assert changed
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 04:44:56.890438
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    diff = {'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"



# Generated at 2022-06-17 04:45:06.658968
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_lineinfile
    import os
    import tempfile
    import shutil
    import sys
    import json

    def get_module_args(args):
        args.update(
            dict(
                path=os.path.join(tempfile.gettempdir(), 'ansible_lineinfile_test.txt'),
                state='present',
                line='test',
                create=True,
                backup=False,
                backrefs=False,
                firstmatch=False,
            )
        )
        return args


# Generated at 2022-06-17 04:45:17.187079
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    # Test case 1:
   

# Generated at 2022-06-17 04:45:23.161155
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil
    import sys
    import json

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    test_file_content = '''
    # This is a test file
    line 1
    line 2
    line 3
    line 4
    line 5
    '''

    with open(test_file, 'w') as f:
        f.write(test_file_content)

    # Test with state=present and regexp

# Generated at 2022-06-17 04:45:32.379589
# Unit test for function present

# Generated at 2022-06-17 04:45:40.483757
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = True
    message = "ownership, perms or SE linux context changed"
    diff = {'after': '', 'before': '', 'before_header': '', 'after_header': ''}
    assert check_file_attrs(module, changed, message, diff) == ('ownership, perms or SE linux context changed', True)


# Generated at 2022-06-17 04:45:48.984739
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'owner': {'type': 'str'}, 'group': {'type': 'str'}, 'mode': {'type': 'str'}, 'seuser': {'type': 'str'}, 'serole': {'type': 'str'}, 'setype': {'type': 'str'}, 'selevel': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': True}})

# Generated at 2022-06-17 04:45:54.378669
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    b_lines = [b'foo\n', b'bar\n', b'baz\n']
    dest = '/tmp/test_write_changes'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines
    os.remove(dest)



# Generated at 2022-06-17 04:46:03.285598
# Unit test for function main

# Generated at 2022-06-17 04:46:31.477852
# Unit test for function main

# Generated at 2022-06-17 04:46:42.347124
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/testfile',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'seuser': 'system_u',
        'serole': 'object_r',
        'setype': 'var_log_t',
        'selevel': 's0',
        'unsafe_writes': False,
    }
    changed = True
    message = 'ownership, perms or SE linux context changed'
    diff = {
        'before_header': '',
        'after_header': '',
        'before': '',
        'after': '',
    }
    message, changed = check_file_attrs(module, changed, message, diff)

# Generated at 2022-06-17 04:46:54.611169
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True),
            regexp=dict(required=False),
            search_string=dict(required=False),
            line=dict(required=True),
            insertafter=dict(required=False),
            insertbefore=dict(required=False),
            create=dict(required=False, default=False, type='bool'),
            backup=dict(required=False, default=False, type='bool'),
            backrefs=dict(required=False, default=False, type='bool'),
            firstmatch=dict(required=False, default=False, type='bool'),
        ),
        supports_check_mode=True
    )

# Generated at 2022-06-17 04:47:01.966190
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            owner=dict(type='str'),
            group=dict(type='str'),
            mode=dict(type='str'),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            setype=dict(type='str'),
            selevel=dict(type='str'),
        ),
        supports_check_mode=True
    )
    changed = False
    message = ""
    diff = {}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == ""
    assert changed == False


# Generated at 2022-06-17 04:47:13.949853
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'backup': {'type': 'bool', 'default': False},
        'unsafe_writes': {'type': 'bool', 'default': False},
        'validate': {'type': 'str'},
        'tmpdir': {'type': 'str'},
    })
    module.tmpdir = tempfile.mkdtemp()
    dest = os.path.join(module.tmpdir, 'testfile')
    b_lines = to_bytes('''# This is a test file
# It has two lines
# It is used by the lineinfile module''')
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        b_

# Generated at 2022-06-17 04:47:21.862515
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(required=True),
            regexp=dict(required=False),
            search_string=dict(required=False),
            line=dict(required=False),
            backup=dict(required=False, default=False, type='bool')
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:47:29.991519
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:47:38.271714
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-17 04:47:50.272578
# Unit test for function main

# Generated at 2022-06-17 04:48:03.049002
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:48:50.530997
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        )
    )
    dest = '/tmp/test_present'

# Generated at 2022-06-17 04:48:59.933283
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        add_file_common_args=True,
    )

# Generated at 2022-06-17 04:49:04.241876
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'tmpdir': '/tmp'})
    b_lines = [b'foo\n', b'bar\n']
    dest = '/tmp/testfile'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines
    os.remove(dest)



# Generated at 2022-06-17 04:49:12.440432
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str', required=False),
            search_string=dict(type='str', required=False),
            line=dict(type='str', required=True),
            insertafter=dict(type='str', required=False),
            insertbefore=dict(type='str', required=False),
            create=dict(type='bool', required=False, default=False),
            backup=dict(type='bool', required=False, default=False),
            backrefs=dict(type='bool', required=False, default=False),
            firstmatch=dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=True
    )

# Generated at 2022-06-17 04:49:18.564358
# Unit test for function write_changes

# Generated at 2022-06-17 04:49:24.079228
# Unit test for function write_changes

# Generated at 2022-06-17 04:49:32.388251
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:49:38.240245
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_lineinfile
    import os
    import tempfile
    import shutil
    import sys
    import json
    import pytest
    import re
    import time
    import stat
    import platform
    import errno
    import textwrap
    import filecmp
    import difflib
    import subprocess
    import datetime
    import traceback
    import warnings
    import copy
    import random
    import string
    import glob
    import base64
    import hashlib
    import getpass
    import pwd
    import grp
    import os.path
    import pty
    import select
    import termios
    import resource
    import fcntl
    import pipes
    import shlex
    import syslog
    import socket
   

# Generated at 2022-06-17 04:49:46.027886
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:49:55.989325
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    dest = module.params['dest']

# Generated at 2022-06-17 04:51:30.497496
# Unit test for function write_changes

# Generated at 2022-06-17 04:51:37.517971
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    diff = {'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == "ownership, perms or SE linux context changed"
    assert changed == True


# Generated at 2022-06-17 04:51:44.970755
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:51:51.906436
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:52:01.746645
# Unit test for function write_changes

# Generated at 2022-06-17 04:52:07.804765
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    dest = '/tmp/test_present'

# Generated at 2022-06-17 04:52:19.898833
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': True}})
    module.tmpdir = '/tmp'
    b_lines = [b'foo\n', b'bar\n']
    dest = '/tmp/testfile'
    write_changes(module, b_lines, dest)
    assert os.path.exists(dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines



# Generated at 2022-06-17 04:52:31.948182
# Unit test for function main

# Generated at 2022-06-17 04:52:40.760811
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = 'test_file'
    regexp = 'test'
    search_string = 'test'
    line = 'test'
    backup = True

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:52:46.595686
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    b_lines = [b'foo', b'bar']
    dest = '/tmp/test'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines

