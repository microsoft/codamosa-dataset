

# Generated at 2022-06-17 04:44:49.041867
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.set_fs_attributes_if_different = lambda x, y, z: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message, diff=None)
    assert changed is True
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 04:44:57.155478
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']

# Generated at 2022-06-17 04:45:03.138773
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = '/tmp'
    b_lines = [b'foo\n', b'bar\n', b'baz\n']
    dest = '/tmp/testfile'
    write_changes(module, b_lines, dest)
    with open(dest) as f:
        assert f.read() == 'foo\nbar\nbaz\n'
    os.remove(dest)



# Generated at 2022-06-17 04:45:14.620557
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    # Test with regexp
    module

# Generated at 2022-06-17 04:45:25.205616
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.params['path'] = '/tmp/testfile'
    module.params['validate'] = '/usr/sbin/visudo -cf %s'
    b_lines = [b'foo\n', b'bar\n']
    write_changes(module, b_lines, module.params['path'])
    with open(module.params['path'], 'rb') as f:
        assert f.readlines() == b_lines


# Generated at 2022-06-17 04:45:33.681535
# Unit test for function main

# Generated at 2022-06-17 04:45:42.390337
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil
    import sys
    import json
    import pytest
    import re
    import time
    import stat

    def test_present(module, path, regexp, search_string, line,
                     insertafter, insertbefore, create, backup, backrefs, firstmatch):
        b_path = to_bytes(path, errors='surrogate_or_strict')
        if os.path.isdir(b_path):
            module.fail_json(rc=256, msg='Path %s is a directory !' % path)

        if regexp is not None:
            bre_c = re.compile(to_bytes(regexp, errors='surrogate_or_strict'))

# Generated at 2022-06-17 04:45:46.621906
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed = False
    message = ""
    diff = ""
    assert check_file_attrs(module, changed, message, diff) == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-17 04:45:53.323438
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    b_lines = [b'foo', b'bar', b'baz']
    dest = '/tmp/test_write_changes'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.read() == b''.join(b_lines)
    os.remove(dest)



# Generated at 2022-06-17 04:46:01.435906
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = '/tmp/test_absent'
    regexp = '^test'
    search_string = 'test'
    line = 'test'
    backup = False
    absent(module, dest, regexp, search_string, line, backup)



# Generated at 2022-06-17 04:47:22.448272
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False)
        ),
        supports_check_mode=True
    )
    dest = 'test.txt'
    regexp = '^test'
    search_string = 'test'
    line = 'test'
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:47:28.357247
# Unit test for function main

# Generated at 2022-06-17 04:47:35.524039
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-17 04:47:47.492107
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path'),
            regexp=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    b_lines = [to_bytes('test')]
    dest = '/tmp/test'
    write_changes(module, b_lines, dest)
    assert os.path.exists(dest)
    os.remove(dest)



# Generated at 2022-06-17 04:48:00.414357
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str', required=False),
            search_string=dict(type='str', required=False),
            line=dict(type='str', required=True),
            insertafter=dict(type='str', required=False),
            insertbefore=dict(type='str', required=False),
            create=dict(type='bool', required=False, default=False),
            backup=dict(type='bool', required=False, default=False),
            backrefs=dict(type='bool', required=False, default=False),
            firstmatch=dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=True
    )

    dest = module

# Generated at 2022-06-17 04:48:07.491508
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    diff = {'before_header': '', 'after_header': '', 'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 04:48:13.508068
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'seuser': 'system_u', 'serole': 'object_r', 'setype': 'tmp_t', 'selevel': 's0'}
    changed = False
    message = ""
    diff = ""
    message, changed = check_file_attrs(module, changed, message, diff)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 04:48:25.748586
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 04:48:30.987302
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    diff = {'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 04:48:40.548240
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True),
            owner = dict(type='str'),
            group = dict(type='str'),
            mode = dict(type='str'),
            seuser = dict(type='str'),
            serole = dict(type='str'),
            setype = dict(type='str'),
            selevel = dict(type='str'),
        ),
        supports_check_mode=True
    )
    changed = False
    message = ""
    diff = {}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == ""
    assert changed == False


# Generated at 2022-06-17 04:49:22.951096
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
            _diff=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

   

# Generated at 2022-06-17 04:49:31.411958
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    # Test with regexp
   

# Generated at 2022-06-17 04:49:42.738363
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys
    import copy
    import json
    import re

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible module

# Generated at 2022-06-17 04:49:52.809819
# Unit test for function write_changes

# Generated at 2022-06-17 04:50:00.593030
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_fs_attributes_if_different = mock_set_fs_attributes_if_different
    changed = False
    message = ""
    diff = ""
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == "ownership, perms or SE linux context changed"
    assert changed == True


# Generated at 2022-06-17 04:50:11.333819
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params['path'] = '/tmp/testfile'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0644'
    module.params['seuser'] = 'system_u'
    module.params['serole'] = 'object_r'
    module.params['setype'] = 'var_log_t'
    module.params['selevel'] = 's0'
    module.params['unsafe_writes'] = True
    changed = False
    message = ''
    diff = {'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert changed == True

# Generated at 2022-06-17 04:50:17.941421
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    # Create a temporary directory
    tmpdir = tempfile.mkd

# Generated at 2022-06-17 04:50:26.515797
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import json
    import pytest

    def setup_temp_dir():
        temp_dir = tempfile.mkdtemp()
        return temp_dir

    def teardown_temp_dir(temp_dir):
        shutil.rmtree(temp_dir)

    def setup_temp_file(temp_dir, content):
        fd, temp_file = tempfile.mkstemp(dir=temp_dir)
        os.close(fd)
        with open(temp_file, 'wb') as f:
            f.write(to_bytes(content))
        return temp_file


# Generated at 2022-06-17 04:50:36.258424
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = '/tmp/test_present'

# Generated at 2022-06-17 04:50:45.576610
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True, type='str'),
            regexp=dict(required=False, type='str'),
            search_string=dict(required=False, type='str'),
            line=dict(required=False, type='str'),
            backup=dict(required=False, type='bool', default=False)
        ),
        supports_check_mode=True
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:52:21.506966
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 04:52:23.745874
# Unit test for function absent
def test_absent():
    assert absent(module, dest, regexp, search_string, line, backup) == (module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:52:32.499242
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text
    import os
    import tempfile
    import shutil
    import stat
    import pytest
    import sys
    import os.path
    import os
    import tempfile
    import shutil
    import stat
    import pytest
    import sys
    import os.path
    import os
    import tempfile
    import shutil
    import stat
    import pytest
    import sys
    import os.path
    import os
    import tempfile
    import shutil
    import stat
    import pytest
    import sys
    import os.path
    import os
    import tempfile
    import shutil
    import stat
    import pytest
    import sys

# Generated at 2022-06-17 04:52:38.907427
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.params = {
        'path': '/tmp/testfile',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'unsafe_writes': True,
        'seuser': 'system_u',
        'serole': 'object_r',
        'setype': 'var_log_t',
        'selevel': 's0',
    }
    changed = False
    message = ''
    diff = {'before': {'path': '/tmp/testfile'},
            'after': {'path': '/tmp/testfile'}}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert changed is True

# Generated at 2022-06-17 04:52:46.404470
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Write a test string to the temporary file
    tmpfile.write(to_bytes('test'))
    # Close the temporary file
    tmpfile.close()

    # Create a temporary ansible module

# Generated at 2022-06-17 04:52:58.032823
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    module = AnsibleModule(argument_spec={'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.params['validate'] = '/usr/sbin/visudo -cf %s'
    module.params['unsafe_writes'] = False
    module.run_command = lambda x: (0, '', '')
    module.atomic_move = lambda x, y, z: None
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)

# Generated at 2022-06-17 04:53:06.379112
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    changed = False
    message = ''
    diff = {}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 04:53:16.380778
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    diff = {'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 04:53:26.895844
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:53:37.631761
# Unit test for function main