

# Generated at 2022-06-17 04:45:04.268907
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backrefs=dict(type='bool'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool'),
            backup=dict(type='bool'),
            firstmatch=dict(type='bool'),
            others=dict(type='str'),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

# Generated at 2022-06-17 04:45:15.268628
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:45:26.405586
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys
    import pytest
    import re
    import json
    import os.path
    import sys
    import stat
    import os
    import os.path
    import tempfile
    import shutil
    import subprocess
    import time
    import errno
    import stat
    import platform
    import getpass
    import pwd
    import grp
    import base64
    import random
    import string
    import hashlib
    import traceback
    import copy
    import json
    import re
    import datetime
    import types
    import collections
    import itertools
    import glob
    import pipes
    import shlex


# Generated at 2022-06-17 04:45:32.241559
# Unit test for function main
def test_main():
    # Test with no args
    with pytest.raises(AnsibleFailJson):
        main()


# Generated at 2022-06-17 04:45:41.430770
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'dest': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = tempfile.mkdtemp()
    dest = os.path.join(module.tmpdir, 'testfile')
    b_lines = [b'foo\n', b'bar\n']
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.read() == b'foo\nbar\n'
    os.remove(dest)
    os.rmdir(module.tmpdir)



# Generated at 2022-06-17 04:45:49.673895
# Unit test for function main

# Generated at 2022-06-17 04:45:56.725367
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'path': {'type': 'path'}, 'owner': {'type': 'str'}, 'group': {'type': 'str'}, 'mode': {'type': 'str'}, 'seuser': {'type': 'str'}, 'serole': {'type': 'str'}, 'setype': {'type': 'str'}, 'selevel': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': True}})
    module.params['path'] = '/tmp/testfile'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0644'
    module.params['seuser'] = 'system_u'
    module.params['serole']

# Generated at 2022-06-17 04:46:07.856896
# Unit test for function main

# Generated at 2022-06-17 04:46:15.355947
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_fs_attributes_if_different = lambda x, y, z: True
    module.load_file_common_arguments = lambda x: {}
    changed = False
    message = ''
    diff = {}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 04:46:22.791139
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    # test case 1:
    # test case 1:
    # test

# Generated at 2022-06-17 04:46:54.739897
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = '/tmp/test_absent'
    regexp = '^test'
    search_string = 'test'
    line = 'test'
    backup = False

    try:
        os.remove(dest)
    except OSError:
        pass

    with open(dest, 'w') as f:
        f.write('test\n')

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:47:01.798114
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = tempfile.mkdtemp()
    b_lines = [b'foo\n', b'bar\n']
    dest = os.path.join(module.tmpdir, 'test_write_changes')
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines
    os.remove(dest)
    os.rmdir(module.tmpdir)


# Generated at 2022-06-17 04:47:11.803195
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys
    import json
    import re
    import pytest
    import pytest_twisted
    import pytest_twisted.plugin
    import pytest_twisted.plugin.twisted_failure
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map

# Generated at 2022-06-17 04:47:22.842742
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 04:47:25.332092
# Unit test for function absent
def test_absent():
    assert absent(module, dest, regexp, search_string, line, backup) == (module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:47:32.461064
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': True}})
    module.tmpdir = '/tmp'
    b_lines = [to_bytes('test', errors='surrogate_or_strict')]
    dest = '/tmp/test'
    write_changes(module, b_lines, dest)
    assert os.path.exists(dest)
    os.remove(dest)



# Generated at 2022-06-17 04:47:43.502691
# Unit test for function check_file_attrs

# Generated at 2022-06-17 04:47:49.443268
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = "ownership, perms or SE linux context changed"
    diff = {'before': {'mode': '0644'}, 'after': {'mode': '0644'}}
    assert check_file_attrs(module, changed, message, diff) == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-17 04:48:01.638459
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:48:12.263353
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:49:00.557648
# Unit test for function write_changes

# Generated at 2022-06-17 04:49:07.551798
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644', 'seuser': 'system_u', 'serole': 'object_r', 'setype': 'tmp_t', 'selevel': 's0'}
    module.set_fs_attributes_if_different = lambda x, y, diff: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message, diff=None)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 04:49:17.240791
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:49:23.952303
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    diff = {'before_header': '', 'before': '', 'after_header': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-17 04:49:29.839435
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_fs_attributes_if_different = lambda x, y, z: True
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message, '')
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 04:49:42.198167
# Unit test for function write_changes

# Generated at 2022-06-17 04:49:52.764655
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:49:58.397581
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 04:50:09.800465
# Unit test for function write_changes

# Generated at 2022-06-17 04:50:14.491528
# Unit test for function write_changes

# Generated at 2022-06-17 04:51:36.933951
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = "test message"
    diff = {'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == "test message and ownership, perms or SE linux context changed"
    assert changed == True



# Generated at 2022-06-17 04:51:42.579820
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed, message, diff = False, '', ''
    message, changed = check_file_attrs(module, changed, message, diff)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 04:51:54.456191
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil
    import filecmp


# Generated at 2022-06-17 04:52:00.338429
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'owner': {'type': 'str'},
        'group': {'type': 'str'},
        'mode': {'type': 'str', 'choices': ['0644', '0640', '1600', '0600']},
        'seuser': {'type': 'str'},
        'serole': {'type': 'str'},
        'setype': {'type': 'str'},
        'selevel': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': True},
    })
    changed = False
    message = ""
    diff = {}

# Generated at 2022-06-17 04:52:09.170923
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest
    import re

    def _create_file(path, content):
        with open(path, 'w') as f:
            f.write(content)

    def _read_file(path):
        with open(path, 'r') as f:
            return f.read()


# Generated at 2022-06-17 04:52:19.648682
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil
    import sys
    import json
    import pytest
    import re
    import time
    import stat
    import errno
    import platform
    import subprocess
    import datetime
    import pytz
    import copy
    import traceback
    import textwrap
    import sys
    import os
    import re
    import json
    import base64
    import getpass
    import pwd
    import grp
    import random
    import string
    import hashlib
    import tempfile
    import shutil
    import errno
    import stat
    import platform
    import time
    import datetime
    import pytz
    import copy
    import traceback
    import textwrap
    import sys
    import os

# Generated at 2022-06-17 04:52:29.094377
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'dest': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.tmpdir = '/tmp'
    b_lines = [b'foo\n', b'bar\n']
    dest = '/tmp/test'
    write_changes(module, b_lines, dest)
    assert module.params['validate'] == None
    module.params['validate'] = '%s'
    write_changes(module, b_lines, dest)

# Generated at 2022-06-17 04:52:29.642950
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-17 04:52:37.474200
# Unit test for function write_changes

# Generated at 2022-06-17 04:52:47.079114
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
            _diff=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
   