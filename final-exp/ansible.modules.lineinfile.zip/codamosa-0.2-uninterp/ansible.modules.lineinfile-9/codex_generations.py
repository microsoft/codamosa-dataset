

# Generated at 2022-06-17 04:45:21.269265
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = '/tmp/test_present'

# Generated at 2022-06-17 04:45:31.009403
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'line': {'type': 'str', 'required': True},
                                          'backrefs': {'type': 'bool', 'default': False},
                                          'validate': {'type': 'str'},
                                          'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = tempfile.mkdtemp()
    dest = os.path.join(module.tmpdir, 'testfile')
    b_lines = to_bytes('test\n')
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.read() == b_lines
    os.remove(dest)

# Generated at 2022-06-17 04:45:39.439022
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    # test case 1
    # test case 2
    # test case

# Generated at 2022-06-17 04:45:45.723799
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-17 04:45:51.587051
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(required=True),
            regexp=dict(required=False),
            search_string=dict(required=False),
            line=dict(required=False),
            backup=dict(required=False, default=False, type='bool'),
        ),
        supports_check_mode=True
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:45:54.298605
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-17 04:46:03.252585
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = '/tmp/test_present'

# Generated at 2022-06-17 04:46:14.336561
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:46:22.008529
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = '/tmp/test_present'

# Generated at 2022-06-17 04:46:26.531858
# Unit test for function main

# Generated at 2022-06-17 04:46:56.217380
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(required=True),
            regexp=dict(required=False),
            search_string=dict(required=False),
            line=dict(required=False),
            backup=dict(default=False, type='bool')
        ),
        supports_check_mode=True
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:47:01.120981
# Unit test for function main

# Generated at 2022-06-17 04:47:02.031535
# Unit test for function absent
def test_absent():
    assert absent(module, dest, regexp, search_string, line, backup) == True


# Generated at 2022-06-17 04:47:08.306465
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed = False
    message = ""
    diff = ""
    assert check_file_attrs(module, changed, message, diff) == ("ownership, perms or SE linux context changed", True)



# Generated at 2022-06-17 04:47:18.261631
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    import ansible.module_utils.common.file as file_utils
    import ansible.module_utils.common.validation as validation_utils
    import ansible.module_utils.common.text as text_utils
    import ansible.module_utils.common.json_utils as json_utils
    import ansible.module_utils.common.dict_transformations as dict_transformations
    import ansible.module_utils.common.process as process_utils
    import ansible.module_utils.common.system as system_utils
    import ansible.module_utils.common.crypto as crypto_utils
    import ansible.module_utils.common.file as file_utils
    import ansible.module_

# Generated at 2022-06-17 04:47:26.625612
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = True
    message = "ownership, perms or SE linux context changed"
    diff = {'before_header': '', 'after_header': '', 'before': '', 'after': ''}
    assert check_file_attrs(module, changed, message, diff) == ("ownership, perms or SE linux context changed", True)



# Generated at 2022-06-17 04:47:33.818624
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:47:46.757863
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = '/tmp/test_present'

# Generated at 2022-06-17 04:47:59.391745
# Unit test for function main

# Generated at 2022-06-17 04:48:10.326709
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil
    import json
    import sys
    import pytest
    import re

    def _create_file(path, data):
        with open(path, 'w') as f:
            f.write(data)

    def _read_file(path):
        with open(path, 'r') as f:
            return f.read()


# Generated at 2022-06-17 04:48:49.795092
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
            _diff=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    module._diff = module.params['_diff']

    absent(module, dest, regexp, search_string, line, backup)




# Generated at 2022-06-17 04:48:59.879978
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 04:49:08.848998
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'},
                                          'validate': {'type': 'str'},
                                          'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = tempfile.mkdtemp()
    dest = os.path.join(module.tmpdir, 'file')
    b_lines = [b'foo\n', b'bar\n']
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines
    os.unlink(dest)
    os.rmdir(module.tmpdir)



# Generated at 2022-06-17 04:49:18.677498
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'dest': {'type': 'str', 'required': True}, 'validate': {'type': 'str', 'required': False}, 'unsafe_writes': {'type': 'bool', 'required': False}})
    module.params['dest'] = '/tmp/testfile'
    module.params['validate'] = '/usr/sbin/visudo -cf %s'
    module.params['unsafe_writes'] = False
    b_lines = [b'foo\n', b'bar\n']
    write_changes(module, b_lines, module.params['dest'])
    assert os.path.exists(module.params['dest'])
    assert open(module.params['dest'], 'rb').read() == b'foo\nbar\n'
    os

# Generated at 2022-06-17 04:49:27.589284
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys
    import re

    def write_changes(module, b_lines, dest):
        with open(dest, 'wb') as f:
            f.writelines(b_lines)

    def check_file_attrs(module, changed, msg, attr_diff):
        return msg, changed

    def to_native(b_data, encoding=None, nonstring='simplerepr', errors='strict'):
        """ Convert bytes or a bytearray to native strings. """

# Generated at 2022-06-17 04:49:33.755776
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path'),
            owner = dict(type='str'),
            group = dict(type='str'),
            mode = dict(type='str'),
            seuser = dict(type='str'),
            serole = dict(type='str'),
            setype = dict(type='str'),
            unsafe_writes = dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    changed = False
    message = ""
    diff = {}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == ""
    assert changed == False


# Generated at 2022-06-17 04:49:38.963600
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'line': {'type': 'str', 'required': True},
        'unsafe_writes': {'type': 'bool', 'default': False},
        'validate': {'type': 'str'},
    })
    b_lines = [b'foo\n', b'bar\n']
    dest = '/tmp/test_write_changes'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines
    os.unlink(dest)



# Generated at 2022-06-17 04:49:45.126416
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-17 04:49:54.242521
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = '/tmp/test_absent'
    regexp = '^test'
    search_string = 'test'
    line = 'test'
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:50:06.426151
# Unit test for function write_changes

# Generated at 2022-06-17 04:51:03.606841
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = '/tmp/test_present'

# Generated at 2022-06-17 04:51:12.880827
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:51:23.178497
# Unit test for function main

# Generated at 2022-06-17 04:51:31.650042
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-17 04:51:37.493720
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            line=dict(type='str', required=True),
            backrefs=dict(type='bool', default=False),
            validate=dict(type='str', default=None),
            unsafe_writes=dict(type='bool', default=False)
        ),
        supports_check_mode=True
    )

    dest = module.params['path']
    b_lines = to_bytes(module.params['line'], errors='surrogate_or_strict')
    write_changes(module, b_lines, dest)



# Generated at 2022-06-17 04:51:45.561894
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path'),
            owner=dict(type='str'),
            group=dict(type='str'),
            mode=dict(type='str'),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            setype=dict(type='str'),
            selevel=dict(type='str'),
        ),
        supports_check_mode=True
    )
    changed = False
    message = ""
    diff = {}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == ""
    assert changed == False


# Generated at 2022-06-17 04:51:56.778394
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil
    import sys
    import json
    import pytest
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible module
    test_module = os.path.join(tmpdir, 'ansible_module_lineinfile.py')

# Generated at 2022-06-17 04:52:06.395299
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:52:14.325614
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_fs_attributes_if_different = lambda x, y, z: True
    assert check_file_attrs(module, False, '', '') == ('ownership, perms or SE linux context changed', True)
    assert check_file_attrs(module, True, '', '') == (' and ownership, perms or SE linux context changed', True)
    assert check_file_attrs(module, False, '', '') == ('ownership, perms or SE linux context changed', True)

# Generated at 2022-06-17 04:52:20.730025
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    b_lines = [b'foo', b'bar', b'baz']
    dest = '/tmp/test_write_changes'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines
    os.remove(dest)


# Generated at 2022-06-17 04:53:57.743733
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    # Create a temporary directory
   

# Generated at 2022-06-17 04:54:06.286524
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil
    import sys
    import json
    import pytest
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.file import is_executable
    from ansible.module_utils.common.file import is_readable
    from ansible.module_utils.common.file import is_writable
    from ansible.module_utils.common.file import is_owner
    from ansible.module_utils.common.file import is_group
    from ansible.module_utils.common.file import is_secontext
    from ansible.module_utils.common.file import is_link
    from ansible.module_utils.common.file import is_directory