

# Generated at 2022-06-17 04:44:52.667596
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil
    import json
    import sys
    import pytest
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 04:44:57.721550
# Unit test for function write_changes
def test_write_changes():
    # TODO: implement
    return


# Generated at 2022-06-17 04:45:04.908920
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str', required=False),
            search_string=dict(type='str', required=False),
            line=dict(type='str', required=True),
            insertafter=dict(type='str', required=False),
            insertbefore=dict(type='str', required=False),
            create=dict(type='bool', required=False, default=False),
            backup=dict(type='bool', required=False, default=False),
            backrefs=dict(type='bool', required=False, default=False),
            firstmatch=dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-17 04:45:17.061188
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os
    import shutil
    import tempfile
    import pytest
    import re
    import sys
    import json
    import collections

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary ansible module

# Generated at 2022-06-17 04:45:24.442658
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(None, False, "", "") == ("", False)
    assert check_file_attrs(None, True, "", "") == (" and ownership, perms or SE linux context changed", True)
    assert check_file_attrs(None, False, "test", "") == ("test", False)
    assert check_file_attrs(None, True, "test", "") == ("test and ownership, perms or SE linux context changed", True)


# Generated at 2022-06-17 04:45:36.414632
# Unit test for function main

# Generated at 2022-06-17 04:45:41.697964
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            lines=dict(type='list'),
            validate=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    b_lines = [to_bytes(u'foo\n'), to_bytes(u'bar\n')]
    dest = '/tmp/test_write_changes'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.read() == b'foo\nbar\n'
    os.remove(dest)



# Generated at 2022-06-17 04:45:51.074783
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:45:59.844628
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    diff = {'before_header': '', 'after_header': '', 'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 04:46:09.492740
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:46:53.668281
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
            line=dict(type='str', required=True),
            validate=dict(type='str', default=None),
            unsafe_writes=dict(type='bool', default=False)
        )
    )
    b_lines = [to_bytes('test')]
    dest = '/tmp/test'
    write_changes(module, b_lines, dest)
    assert os.path.exists(dest)
    os.remove(dest)


# Generated at 2022-06-17 04:47:04.228239
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'backup': {'type': 'bool'}, 'unsafe_writes': {'type': 'bool'}, 'validate': {'type': 'str'}})
    module.params['path'] = '/tmp/testfile'
    module.params['backup'] = False
    module.params['unsafe_writes'] = True
    module.params['validate'] = None
    b_lines = [b'foo\n', b'bar\n']
    dest = '/tmp/testfile'
    write_changes(module, b_lines, dest)
    assert os.path.exists('/tmp/testfile')
    assert os.path.getsize('/tmp/testfile') == 7

# Generated at 2022-06-17 04:47:09.572024
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-17 04:47:18.328400
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = '/tmp/test_present'

# Generated at 2022-06-17 04:47:23.594143
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            owner = dict(required=False),
            group = dict(required=False),
            mode = dict(required=False),
            seuser = dict(required=False),
            serole = dict(required=False),
            setype = dict(required=False),
            selevel = dict(required=False),
        ),
        supports_check_mode=True
    )
    changed = False
    message = ""
    diff = {}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == ""
    assert changed == False


# Generated at 2022-06-17 04:47:28.775946
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    diff = {}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == "ownership, perms or SE linux context changed"
    assert changed == True


# Generated at 2022-06-17 04:47:38.617194
# Unit test for function main

# Generated at 2022-06-17 04:47:48.563014
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False)
        ),
        supports_check_mode=True
    )
    dest = '/tmp/testfile'
    regexp = '^test'
    search_string = 'test'
    line = 'test'
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:48:01.681565
# Unit test for function main

# Generated at 2022-06-17 04:48:10.220849
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 04:48:58.492603
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:49:07.235535
# Unit test for function write_changes

# Generated at 2022-06-17 04:49:16.243459
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = '/tmp/test_absent'
    regexp = '^test'
    search_string = 'test'
    line = 'test'
    backup = True
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:49:21.873254
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backrefs=dict(type='bool', default=False),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    dest = '/tmp/testfile'

# Generated at 2022-06-17 04:49:27.459079
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'path': '/tmp/test',
        'regexp': '^test',
        'line': 'test',
        'insertafter': 'test',
        'insertbefore': 'test',
        'create': True,
        'backup': True,
        'backrefs': True,
        'firstmatch': True,
    })
    present(module, '/tmp/test', '^test', None, 'test', 'test', 'test', True, True, True, True)


# Generated at 2022-06-17 04:49:34.326131
# Unit test for function write_changes

# Generated at 2022-06-17 04:49:39.243400
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    diff = ''
    message, changed = check_file_attrs(module, changed, message, diff)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 04:49:45.335780
# Unit test for function write_changes

# Generated at 2022-06-17 04:49:55.683158
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            line=dict(type='str', required=True),
            backrefs=dict(type='bool', default=False),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            others=dict(type='str'),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

# Generated at 2022-06-17 04:50:00.752588
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/testfile',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'seuser': 'system_u',
        'serole': 'object_r',
        'setype': 'var_log_t',
        'selevel': 's0',
        'unsafe_writes': True,
    }
    changed = False
    message = ''
    diff = {'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == "ownership, perms or SE linux context changed"
    assert changed == True



# Generated at 2022-06-17 04:53:08.208789
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            lines=dict(type='list', required=True),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
    )
    b_lines = [to_bytes(x, errors='surrogate_or_strict') for x in module.params['lines']]
    dest = module.params['dest']
    write_changes(module, b_lines, dest)



# Generated at 2022-06-17 04:53:14.240333
# Unit test for function write_changes

# Generated at 2022-06-17 04:53:21.121525
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'dest': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}, 'validate': {'type': 'str'}})
    module.atomic_move = lambda src, dest, unsafe_writes: (src, dest, unsafe_writes)
    module.run_command = lambda cmd: (0, '', '')
    module.tmpdir = '/tmp'
    write_changes(module, [b'foo\n', b'bar\n'], '/tmp/testfile')
    assert module.atomic_move.call_args[0][0] == '/tmp/testfile'
    assert module.atomic_move.call_args[0][1] == '/tmp/testfile'

# Generated at 2022-06-17 04:53:31.548381
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = os.path.join(tempfile.gettempdir(), 'test_absent')
    regexp = '^#.*'
    search_string = '^#.*'
    line = '#'
    backup = False

    with open(dest, 'w') as f:
        f.write('#')

    absent(module, dest, regexp, search_string, line, backup)

# Generated at 2022-06-17 04:53:40.522653
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str', required=False),
            search_string=dict(type='str', required=False),
            line=dict(type='str', required=True),
            insertafter=dict(type='str', required=False),
            insertbefore=dict(type='str', required=False),
            create=dict(type='bool', required=False, default=False),
            backup=dict(type='bool', required=False, default=False),
            backrefs=dict(type='bool', required=False, default=False),
            firstmatch=dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=True
    )

# Generated at 2022-06-17 04:53:51.609429
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:54:02.054326
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:54:04.369393
# Unit test for function absent
def test_absent():
    assert absent(module, dest, regexp, search_string, line, backup) == (changed, found, msg, backupdest, difflist)


# Generated at 2022-06-17 04:54:11.189296
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    # Test with regexp
   