

# Generated at 2022-06-17 04:45:22.541568
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'path': '/tmp/test',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
        'seuser': 'unconfined_u',
        'serole': 'object_r',
        'setype': 'tmp_t',
        'selevel': 's0',
    }
    changed = False
    message = ''
    diff = {
        'before_header': '',
        'after_header': '',
        'before': '',
        'after': '',
    }
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed is True



# Generated at 2022-06-17 04:45:31.690721
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = '/tmp/test_absent'
    regexp = '^test'
    search_string = 'test'
    line = 'test'
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:45:42.323375
# Unit test for function write_changes

# Generated at 2022-06-17 04:45:51.734111
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path'),
            backup=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
    )
    module.params['path'] = '/tmp/testfile'
    module.params['backup'] = False
    module.params['validate'] = '/usr/sbin/visudo -cf %s'
    module.params['unsafe_writes'] = False
    b_lines = [b'192.168.1.99 foo.lab.net foo\n']
    dest = '/tmp/testfile'
    write_changes(module, b_lines, dest)


# Generated at 2022-06-17 04:45:56.788918
# Unit test for function main

# Generated at 2022-06-17 04:45:59.327400
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed = False
    message = "test"
    diff = "test"
    assert check_file_attrs(module, changed, message, diff) == ("test and ownership, perms or SE linux context changed", True)


# Generated at 2022-06-17 04:46:04.728109
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-17 04:46:11.829239
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda x, y, z: True
    module.params = {'unsafe_writes': False}
    module.run_command = lambda x: (0, '', '')
    b_lines = [b'foo', b'bar']
    dest = '/tmp/testfile'
    write_changes(module, b_lines, dest)


# Generated at 2022-06-17 04:46:16.017895
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    b_lines = [b'foo\n', b'bar\n']
    dest = '/tmp/testfile'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.read() == b'foo\nbar\n'
    os.remove(dest)



# Generated at 2022-06-17 04:46:20.761847
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil
    import json
    import pytest
    import sys
    import re
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six import iteritems

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible module

# Generated at 2022-06-17 04:46:44.735334
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 04:46:49.917228
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    b_lines = [b'foo', b'bar']
    dest = '/tmp/test'
    write_changes(module, b_lines, dest)
    assert os.path.exists(dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines



# Generated at 2022-06-17 04:46:57.588034
# Unit test for function main

# Generated at 2022-06-17 04:47:02.152289
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:47:12.395031
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    # test present

# Generated at 2022-06-17 04:47:19.715951
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'dest': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.tmpdir = tempfile.mkdtemp()
    dest = os.path.join(module.tmpdir, 'test_write_changes')
    b_lines = [b'foo\n', b'bar\n', b'baz\n']
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines



# Generated at 2022-06-17 04:47:29.215045
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.file import check_file_attrs
    import os
    import re
    import tempfile
    import shutil
    import sys
    import pytest
    import json
    import difflib
    import filecmp
    import time
    import datetime

    def test_present(module, path, regexp, search_string, line, insertafter, insertbefore, create, backup, backrefs, firstmatch):
        b_path = to_bytes(path, errors='surrogate_or_strict')
        if not os.path.exists(b_path):
            if create:
                open(b_path, 'a').close()
            else:
                module

# Generated at 2022-06-17 04:47:34.993970
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = '/tmp/test_present'

# Generated at 2022-06-17 04:47:48.174675
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = module.params['path']
    b_lines = to_bytes('''
# This is a test file
# It has two lines
''')
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.read()

# Generated at 2022-06-17 04:47:53.494033
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({})
    changed = True
    message = "message"
    diff = "diff"
    result = check_file_attrs(module, changed, message, diff)
    assert result == ("message and ownership, perms or SE linux context changed", True)



# Generated at 2022-06-17 04:48:21.884284
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'owner': {'type': 'str'}, 'group': {'type': 'str'}, 'mode': {'type': 'str'}, 'seuser': {'type': 'str'}, 'serole': {'type': 'str'}, 'setype': {'type': 'str'}, 'selevel': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': True}})

# Generated at 2022-06-17 04:48:31.383629
# Unit test for function main

# Generated at 2022-06-17 04:48:41.159871
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os
    import shutil
    import tempfile
    import pytest
    import sys
    import re

    # Create a temporary directory
    tempdir = tempfile.mkdtemp()
    # Create a temporary ansible.cfg
    ansible_cfg = os.path.join(tempdir, "ansible.cfg")
    with open(ansible_cfg, 'w') as f:
        f.write("[defaults]\n")
        f.write("roles_path = ../../../roles\n")
        f.write("host_key_checking = False\n")
        f.write("retry_files_enabled = False\n")

# Generated at 2022-06-17 04:48:46.449762
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = "test message"
    diff = {'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == "test message and ownership, perms or SE linux context changed"
    assert changed == True


# Generated at 2022-06-17 04:48:55.646522
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_lineinfile
    import os
    import tempfile
    import shutil
    import sys
    import json

    def _create_file(path, content):
        with open(path, 'w') as f:
            f.write(content)

    def _read_file(path):
        with open(path, 'r') as f:
            return f.read()


# Generated at 2022-06-17 04:49:04.440778
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = '/tmp/test_absent'
    regexp = '^#'
    search_string = '^#'
    line = '#'
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:49:13.159537
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = '/tmp/test_absent'
    regexp = '^#test'
    search_string = 'test'
    line = 'test'
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:49:22.687187
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:49:30.421159
# Unit test for function write_changes

# Generated at 2022-06-17 04:49:39.697510
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.atomic_move = lambda x, y, z: None
    module.params = {'unsafe_writes': True}
    module.run_command = lambda x: (0, '', '')
    module.tmpdir = '/tmp'
    b_lines = [b'foo\n', b'bar\n']
    dest = '/tmp/test'
    write_changes(module, b_lines, dest)


# Generated at 2022-06-17 04:50:23.694018
# Unit test for function write_changes

# Generated at 2022-06-17 04:50:35.621555
# Unit test for function main

# Generated at 2022-06-17 04:50:44.566384
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    dest = '/tmp/test_absent'
    regexp = '^#'
    search_string = '^#'
    line = '#'
    backup = False

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:50:53.592439
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']

# Generated at 2022-06-17 04:51:02.440469
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = True
    message = "ownership, perms or SE linux context changed"
    diff = {'after': '', 'before': '', 'before_header': '', 'after_header': ''}
    assert check_file_attrs(module, changed, message, diff) == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-17 04:51:12.027854
# Unit test for function write_changes

# Generated at 2022-06-17 04:51:21.973594
# Unit test for function write_changes
def test_write_changes():
    # Create a temporary file
    tmpfd, tmpfile = tempfile.mkstemp()
    with os.fdopen(tmpfd, 'wb') as f:
        f.writelines(b'foo\nbar\nbaz\n')

    # Create a module

# Generated at 2022-06-17 04:51:22.737680
# Unit test for function write_changes
def test_write_changes():
    assert True == True


# Generated at 2022-06-17 04:51:31.592157
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    # Test the function
    present

# Generated at 2022-06-17 04:51:41.094229
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:52:32.241923
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import sys
    import pytest
    import re

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible module

# Generated at 2022-06-17 04:52:42.691818
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:52:51.866340
# Unit test for function write_changes

# Generated at 2022-06-17 04:53:01.649295
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil
    import json


# Generated at 2022-06-17 04:53:11.394353
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_lineinfile
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.six.moves.urllib.response
    import ansible.module_utils.six.moves.urllib.robotparser
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils

# Generated at 2022-06-17 04:53:17.934011
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import filecmp
    import difflib
    import json
    import pytest
    import ansible.module_utils.basic
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import PY3

    fd, testfile = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('#!/bin/sh\n\necho "Hello world"\n')
    f.close()

    fd, testfile2 = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')

# Generated at 2022-06-17 04:53:26.952806
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text
    import os
    import tempfile
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            b_lines=dict(type='list', required=True),
            validate=dict(type='str', required=False),
            unsafe_writes=dict(type='bool', required=False),
        ),
        supports_check_mode=True,
    )
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    with os.fdopen(tmpfd, 'wb') as f:
        f.writelines(module.params['b_lines'])
    validate = module

# Generated at 2022-06-17 04:53:37.671828
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:53:47.642518
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text

    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path', required=True),
            b_lines=dict(type='list', required=True),
            validate=dict(type='str', required=False),
            unsafe_writes=dict(type='bool', required=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    b_lines = module.params['b_lines']
    validate = module.params['validate']
    unsafe_writes = module.params['unsafe_writes']


# Generated at 2022-06-17 04:53:58.934294
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)
