

# Generated at 2022-06-17 04:45:04.725149
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    # Test case 1:
   

# Generated at 2022-06-17 04:45:16.804928
# Unit test for function write_changes

# Generated at 2022-06-17 04:45:19.909134
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    b_lines = [b'foo', b'bar']
    dest = '/tmp/testfile'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines



# Generated at 2022-06-17 04:45:25.366287
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({})
    changed = True
    message = "ownership, perms or SE linux context changed"
    diff = {'before': '', 'after': ''}
    result = check_file_attrs(module, changed, message, diff)
    assert result == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-17 04:45:25.937090
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-17 04:45:38.412864
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            line=dict(type='str', required=True),
            backrefs=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    b_lines = [b'foo\n', b'bar\n', b'baz\n']
    dest = '/tmp/testfile'
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == b_lines



# Generated at 2022-06-17 04:45:44.445164
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            line=dict(type='str', required=True),
            backrefs=dict(type='bool', default=False),
            validate=dict(type='str', default=None),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    # Create a temporary file
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    # Create the content of the file

# Generated at 2022-06-17 04:45:51.733871
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            lines=dict(type='list'),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
    )
    dest = '/tmp/test_write_changes'
    lines = [b'foo', b'bar']
    write_changes(module, lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == lines
    os.remove(dest)



# Generated at 2022-06-17 04:45:57.872807
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil
    import json
    import sys
    import pytest
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 04:46:08.708609
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:46:43.279362
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    dest = '/tmp/test_present'

# Generated at 2022-06-17 04:46:48.330801
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False)
        ),
        supports_check_mode=True
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:46:58.065946
# Unit test for function absent
def test_absent():
    module = AnsibleModule({'dest': 'test.txt', 'line': 'test', 'backup': False, '_diff': True})
    assert absent(module, 'test.txt', None, None, 'test', False) == {'changed': True, 'found': 1, 'msg': '1 line(s) removed', 'backup': '', 'diff': [{'before': 'test\n', 'after': '', 'before_header': 'test.txt (content)', 'after_header': 'test.txt (content)'}, {'before': '', 'after': '', 'before_header': 'test.txt (file attributes)', 'after_header': 'test.txt (file attributes)'}]}

# Generated at 2022-06-17 04:47:03.103403
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    diff = {'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == "ownership, perms or SE linux context changed"
    assert changed == True



# Generated at 2022-06-17 04:47:11.276399
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    module.set_fs_attributes_if_different = lambda x, y, z: True
    changed, message, diff = False, '', ''
    message, changed = check_file_attrs(module, changed, message, diff)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 04:47:20.823302
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            state=dict(type='str', default='present', choices=['absent', 'present']),
            regexp=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            backup=dict(type='bool', default=False),
            create=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-17 04:47:30.148389
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str', required=False),
            search_string=dict(type='str', required=False),
            line=dict(type='str', required=True),
            insertafter=dict(type='str', required=False),
            insertbefore=dict(type='str', required=False),
            create=dict(type='bool', required=False, default=False),
            backup=dict(type='bool', required=False, default=False),
            backrefs=dict(type='bool', required=False, default=False),
            firstmatch=dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-17 04:47:41.231369
# Unit test for function main

# Generated at 2022-06-17 04:47:49.870740
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    # Test case 1:
    #
    # Test with regexp and line
    #
    # Given:
    #
    # dest

# Generated at 2022-06-17 04:48:02.422388
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:48:50.141536
# Unit test for function write_changes

# Generated at 2022-06-17 04:48:57.418683
# Unit test for function main

# Generated at 2022-06-17 04:49:04.075759
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    diff = {'before_header': '', 'before': '', 'after_header': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 04:49:09.805573
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.params['validate'] = '/usr/sbin/visudo -cf %s'
    module.params['unsafe_writes'] = True
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    with os.fdopen(tmpfd, 'wb') as f:
        f.write(b"test")
    write_changes(module, b"test", tmpfile)
    os.remove(tmpfile)


# Generated at 2022-06-17 04:49:18.138999
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'dest': '/tmp/test',
        'line': 'test',
        'create': True,
        'insertbefore': 'BOF',
        'insertafter': 'EOF',
        'backup': True,
        'backrefs': True,
        'firstmatch': True,
        'regexp': '^test$',
        'search_string': 'test',
        'validate': 'test',
        'unsafe_writes': True,
    })
    present(module, '/tmp/test', '^test$', 'test', 'test', 'EOF', 'BOF', True, True, True, True)


# Generated at 2022-06-17 04:49:25.113120
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed = False
    message = ''
    diff = {}
    module.params = {'path': '/etc/hosts', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': True}
    module.set_fs_attributes_if_different = lambda x, y, z: True
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 04:49:32.338483
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': False}
    module.set_fs_attributes_if_different = lambda x, y, diff: True
    module.load_file_common_arguments = lambda x: {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644', 'unsafe_writes': False}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message, diff=None)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-17 04:49:38.842658
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import cStringIO
    import os
    import tempfile
    import shutil

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path'),
            regexp=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            dest=dict(type='path'),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    # Create a temporary directory
    tmpdir = tempfile.mkd

# Generated at 2022-06-17 04:49:44.324514
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed = False
    message = ''
    diff = {}
    module.params = {'path': '/tmp/test', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    check_file_attrs(module, changed, message, diff)
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-17 04:49:54.745448
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'line': {'type': 'str', 'required': True},
        'validate': {'type': 'str', 'required': False},
        'unsafe_writes': {'type': 'bool', 'required': False, 'default': False}
    })
    b_lines = [to_bytes('test')]
    dest = '/tmp/test_write_changes'
    write_changes(module, b_lines, dest)
    assert os.path.exists(dest)
    with open(dest, 'rb') as f:
        assert f.read() == to_bytes('test')
    os.remove(dest)



# Generated at 2022-06-17 04:51:21.840989
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'owner': {'type': 'str'},
        'group': {'type': 'str'},
        'mode': {'type': 'str', 'choices': ['a-', 'a+', 'u+', 'u-', 'o+', 'o-']},
        'seuser': {'type': 'str'},
        'serole': {'type': 'str'},
        'setype': {'type': 'str'},
        'selevel': {'type': 'str'},
    })
    changed = False
    message = ''
    diff = {}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == ''

# Generated at 2022-06-17 04:51:30.336564
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.atomic_move = lambda *args, **kwargs: None
    module.params = {'path': '/tmp/test', 'validate': 'validate %s', 'unsafe_writes': False}
    write_changes(module, [], '/tmp/test')
    assert module.params['validate'] == 'validate %s'
    assert module.params['unsafe_writes'] == False


# Generated at 2022-06-17 04:51:37.366918
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    diff = {'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 04:51:46.683391
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import b
    from ansible.module_utils.six import text_type
    import os
    import sys
    import tempfile
    import shutil

    def _create_file(path, content):
        with open(path, 'wb') as f:
            f.write(content)

    def _create_file_with_content(content):
        fd, path = tempfile.mkstemp()
        _create_file(path, content)
        return path


# Generated at 2022-06-17 04:51:57.074552
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.file import check_file_attrs
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.file import check_file_attrs
    from ansible.module_utils.common.file import write_changes
    from ansible.module_utils.six import PY3
    import os
    import re
    import os
    import re
    import os
    import re
    import os
    import re
    import os
    import re
    import os
    import re
    import os
    import re
    import os
    import re
    import os

# Generated at 2022-06-17 04:52:06.609749
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-17 04:52:21.151840
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params['path'] = '/tmp/testfile'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0644'
    module.params['seuser'] = 'system_u'
    module.params['serole'] = 'object_r'
    module.params['setype'] = 'etc_t'
    module.params['selevel'] = 's0'
    module.params['unsafe_writes'] = False
    changed = False
    message = ''
    diff = {'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)

# Generated at 2022-06-17 04:52:26.969811
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = {'path': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'}
    changed = False
    message = ''
    diff = {'before': '', 'after': ''}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'ownership, perms or SE linux context changed'
    assert changed == True


# Generated at 2022-06-17 04:52:37.454339
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os


# Generated at 2022-06-17 04:52:46.305227
# Unit test for function main