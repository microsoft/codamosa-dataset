

# Generated at 2022-06-25 02:43:53.450323
# Unit test for function present
def test_present():

    # Input parameters
    module = AnsibleModule(argument_spec={'dest': dict(type='str', required=True), 'regexp': dict(type='str', required=False), 'search_string': dict(type='str', required=False), 'line': dict(type='str', required=True), 'insertafter': dict(type='str', required=False), 'insertbefore': dict(type='str', required=False), 'create': dict(type='bool', required=False), 'backup': dict(type='bool', required=False), 'backrefs': dict(type='bool', required=False), 'firstmatch': dict(type='bool', required=False)}, supports_check_mode=True)
    dest = "hello"
    regexp = None
    search_string = None
    line = "hello"
    insertafter = None


# Generated at 2022-06-25 02:44:00.124096
# Unit test for function absent

# Generated at 2022-06-25 02:44:10.710329
# Unit test for function write_changes

# Generated at 2022-06-25 02:44:11.709764
# Unit test for function present
def test_present():
    var_0 = present()
    assert var_0 == None


# Generated at 2022-06-25 02:44:17.630406
# Unit test for function check_file_attrs

# Generated at 2022-06-25 02:44:24.493409
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_args = [0,0,"",""]
    test_args[0] = 1
    test_args[1] = 1
    test_args[2] = "foo"
    test_args[3] = "bar"
    out = check_file_attrs(*test_args)
    assert out == ('foo and ownership, perms or SE linux context changed', 1)
    test_args[1] = 0
    out = check_file_attrs(*test_args)
    assert out ==  ('foo', 0)


# Generated at 2022-06-25 02:44:31.405058
# Unit test for function check_file_attrs
def test_check_file_attrs():
    file_path = os.path.abspath(__file__)
    # Setup
    p = ansible.module_utils.basic.AnsibleModule()
    p.params = {'unsafe_writes': True, 'path': file_path}
    # Run
    r = check_file_attrs(p)
    # Verify
    assert r[0] == ''
    assert r[1] == False
    # Cleanup
    pass



# Generated at 2022-06-25 02:44:32.402441
# Unit test for function absent
def test_absent():
    # test_case_0
    var_0 = absent()


# Generated at 2022-06-25 02:44:37.635906
# Unit test for function main
def test_main():
    print("Testing function main")
    path = tempfile.mktemp()
    fp = open(path, "w")
    fp.write("abc\ndef\nghi\n")
    fp.close()
    fp = open(path, "r")
    var_0 = main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:44:44.693995
# Unit test for function absent
def test_absent():
    class AnsibleModule(object):
        class ArgumentSpec(object):
            def __init__(self):
                self.dest = None
                self.regexp = None
                self.search = None
                self.line = None
                self.backup = None
    module = AnsibleModule()
    dest = None
    regexp = None
    search_string = None
    line = None
    backup = None
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-25 02:45:12.459868
# Unit test for function main
def test_main():
    line_0 = b'{{\n  "boolean": true,\n  "integer": 1,\n  "array": [\n    "foo",\n    "bar"\n  ],\n  "string": "lorem ipsum",\n  "object": { "name": "doo" }\n}\n'
    var_0 = line_0
    var_0 = to_native(var_0, errors='surrogate_or_strict')
    line_0 = var_0
    regexp = b'"boolean": true,\n'
    line = b'  "boolean": true,\n'
    dest = b'../file1.txt'
    backrefs = False
    firstmatch = False
    b_line = line
    b_dest = dest
    var_0

# Generated at 2022-06-25 02:45:19.854539
# Unit test for function present
def test_present():
    var_1 = present(
        pkg_resources.resource_filename(__name__, 'fixtures/0/in.txt'),
        pkg_resources.resource_filename(__name__, 'fixtures/0/out.txt'),
        None,
        None,
        None,
        None,
        None,
        pkg_resources.resource_filename(__name__, 'fixtures/0/in.txt')
    )

    assert var_1 == "0"


# Generated at 2022-06-25 02:45:28.539593
# Unit test for function absent
def test_absent():
    class AnsibleModule(object):
        def __init__(self, argument_spec, **kwargs):
            self.argument_spec = argument_spec
            for key, value in kwargs.items():
                setattr(self, key, value)
        def fail_json(self, **kwargs):
            raise Exception('An error occurred')

# Generated at 2022-06-25 02:45:30.589697
# Unit test for function write_changes
def test_write_changes():
    assert True



# Generated at 2022-06-25 02:45:31.407031
# Unit test for function present
def test_present():
    var_0 = main()


# Generated at 2022-06-25 02:45:38.644193
# Unit test for function write_changes

# Generated at 2022-06-25 02:45:46.238665
# Unit test for function absent
def test_absent():
    # Test case 1:
    var_1 = to_bytes('/root/ansible_test_file', errors='surrogate_or_strict')
    var_2 = None
    var_3 = None
    var_4 = to_bytes('\n', errors='surrogate_or_strict')
    var_5 = False
    var_6 = to_bytes('/root/ansible_test_file', errors='surrogate_or_strict')

# Generated at 2022-06-25 02:45:47.768441
# Unit test for function write_changes
def test_write_changes():
    lines = ['line 1\n', 'line 2\n']
    write_changes(lines,'test.txt')
    

# Generated at 2022-06-25 02:45:49.899549
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 02:45:50.643224
# Unit test for function write_changes
def test_write_changes():
    assert write_changes() == True


# Generated at 2022-06-25 02:46:14.412425
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Test with default case
    test_case_0()
    # Test with user-defined case
    # var_args = ''
    # test_case_1(var_args)



# Generated at 2022-06-25 02:46:16.455512
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    assert check_file_attrs(module, True, "Hello\n", "Hello\n") == ("Hello\n and ownership, perms or SE linux context changed", True)


# Generated at 2022-06-25 02:46:25.394677
# Unit test for function main

# Generated at 2022-06-25 02:46:35.309499
# Unit test for function write_changes
def test_write_changes():
    test_data = {
        "module": {
            "params": {"regexp": ".*", "unsafe_writes": 0, "validate": None, "path": "main.go"},
            "run_command": test_case_0
        },
        "os": {
            "tmpfile": "file_3",
            "tmpefd": 1,
            "fdopen": "file_4"
        },
        "tempfile": {
            "mkstemp": test_case_0
        }
    }

    b_lines = [
        "package main\n",
        "import \"fmt\"\n",
        "\n",
        "func main() {\n",
        "    fmt.Println(\"Hello, World\")\n",
        "}\n"
    ]


# Generated at 2022-06-25 02:46:35.960694
# Unit test for function present
def test_present():
    pass


# Generated at 2022-06-25 02:46:44.042845
# Unit test for function absent
def test_absent():
    tester = AnsibleModule(
        argument_spec = dict(
            dest = dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default='no'),
        ),
        supports_check_mode=True
    )

    tester.exit_json(changed=True, msg="Test Absent")


# Generated at 2022-06-25 02:46:53.869430
# Unit test for function present
def test_present():
    dest = '/tmp/test'
    regexp = None
    search_string = None
    line = 'test'
    insertafter = None
    insertbefore = None
    create = False
    backup = False
    backrefs = False
    firstmatch = True

# Generated at 2022-06-25 02:47:03.847528
# Unit test for function main
def test_main():
    var_0 = tempfile.NamedTemporaryFile(delete=False)
    var_1 = to_bytes('/tmp/ansible_lineinfile_payload_uAA7tf', errors='surrogate_or_strict')
    with open(var_1, 'wb') as fdesc:
        fdesc.write(to_bytes('''test string\n''', errors='surrogate_or_strict'))
    var_2 = to_bytes('/tmp/ansible_lineinfile_payload_uAA7tf', errors='surrogate_or_strict')
    with open(var_2, 'rb') as fdesc:
        var_3 = fdesc.readlines()
    var_4 = to_bytes('another test string\n', errors='surrogate_or_strict')


# Generated at 2022-06-25 02:47:04.568269
# Unit test for function write_changes
def test_write_changes():
    test_case_0()


# Generated at 2022-06-25 02:47:08.070199
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(False, True, "message", "diff") == ('message and ownership, perms or SE linux context changed', True)


# Generated at 2022-06-25 02:47:29.630134
# Unit test for function main
def test_main():
    not_used = main()
    #assert False # TODO: implement your test here


# Generated at 2022-06-25 02:47:35.596735
# Unit test for function absent
def test_absent():
    module = AnsibleModule({'backup': True, 'line': ['Outer:', 'hi'], 'path': '/home/vagrant/ansible/files/file1.txt', 'state': 'absent', '_ansible_check_mode': False, '_ansible_diff': True})
    absent(module, '/home/vagrant/ansible/files/file1.txt', None, None, ['Outer:', 'hi'], True)


# Generated at 2022-06-25 02:47:39.341856
# Unit test for function write_changes
def test_write_changes():
    pass


# Generated at 2022-06-25 02:47:45.393280
# Unit test for function absent
def test_absent():
    # Replace global parameter/variables value
    module = AnsibleModule(argument_spec=dict(path=dict(type='str')), supports_check_mode=True)
    dest = os.path.abspath('/')
    regexp = None
    search_string = None
    line = 'bar'
    backup = False
    absent(module, dest, regexp, search_string, line, backup)
    # Test operation
    assert len(var_0['msg']) > 0


# Generated at 2022-06-25 02:47:55.715172
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # check_file_attrs should return true if there are no changes to be made to the file
    module = MagicMock()
    changed = True
    message = ""
    diff = ""
    expect_changed = False
    expect_message = "ownership, perms or SE linux context changed"
    expect_diff = ""

    # call function
    actual_changed, actual_message, actual_diff = check_file_attrs(module, changed, message, diff)

    print("expect_changed: " + str(expect_changed))
    print("actual_changed: " + str(actual_changed))
    assert actual_changed == expect_changed
    print("expect_message: " + expect_message)
    print("actual_message: " + actual_message)
    assert actual_message == expect_message

# Generated at 2022-06-25 02:47:58.684091
# Unit test for function absent
def test_absent():
    var_0 = main()


# Generated at 2022-06-25 02:48:00.949243
# Unit test for function absent
def test_absent():
    absent("module", "dest", "regexp", "search_string", "line", "backup")


# Generated at 2022-06-25 02:48:07.873805
# Unit test for function present
def test_present():
    dest = var_0
    regexp = var_1
    search_string = var_2
    line = var_3
    insertafter = var_4
    insertbefore = var_5
    create = var_6
    backup = var_7
    backrefs = var_8
    firstmatch = var_9
    if dest is None:
        dest = [""]
    if regexp is None:
        regexp = [""]
    if search_string is None:
        search_string = [""]
    if line is None:
        line = [""]
    if insertafter is None:
        insertafter = [""]
    if insertbefore is None:
        insertbefore = [""]
    if create is None:
        create = [""]
    if backup is None:
        backup = [""]

# Generated at 2022-06-25 02:48:09.025731
# Unit test for function absent
def test_absent():
    var_0 = main()


# Generated at 2022-06-25 02:48:13.747343
# Unit test for function absent
def test_absent():
    module = AnsibleModule({'backup': 'False', 'create': 'False', 'dest': '', 'insertbefore': 'None', 'insertafter': 'None', 'line': '', 'regexp': 'None', 'search_string': 'None', 'state': 'absent'}, check_invalid_arguments=False)
    result = absent(module, dest='', regexp='None', search_string='None', line='', backup=False)
    assert result == None


# Generated at 2022-06-25 02:48:53.542383
# Unit test for function write_changes
def test_write_changes():
    assert func_0() == 0


# Generated at 2022-06-25 02:48:59.480542
# Unit test for function present
def test_present():
    var_0 = AnsibleModule( {'search_string': '', 'state': 'present', 'regexp': None} )
    var_0.check_mode = False
    var_0.supports_check_mode = False
    var_0.exit_json = lambda var_1 : print( var_1 )
    var_0.fail_json = lambda var_1 : print( var_1 )
    module = var_0
    dest = "/home/tester/test_file"
    regexp = None
    search_string = ""
    line = "test_line"
    insertafter = "BOF"
    insertbefore = None
    create = False
    backup = False
    backrefs = True
    firstmatch = False

# Generated at 2022-06-25 02:49:09.255736
# Unit test for function check_file_attrs
def test_check_file_attrs():
    var_0 = True
    var_1 = "message"
    var_2 = "diff"

# Generated at 2022-06-25 02:49:12.043308
# Unit test for function write_changes
def test_write_changes():
    dest = "test_value_1"
    b_lines = ["test_value_3", "test_value_4"]
    module = test_case_0()
    write_changes(module, b_lines, dest)


# Generated at 2022-06-25 02:49:18.666140
# Unit test for function check_file_attrs
def test_check_file_attrs():

    class ModuleStub(object):

        def __init__(self, params = None, load_file_common_arguments = None):
            self._params = params
            self._load_file_common_arguments = load_file_common_arguments

        def params(self):
            return self._params

        def load_file_common_arguments(self, args):
            return self._load_file_common_arguments(args)

        def set_fs_attributes_if_different(self, args, msg, diff):
            return True


    module_stub = ModuleStub()
    changed = True
    message = "ownership, perms or SE linux context changed"

    # unit test 0

# Generated at 2022-06-25 02:49:29.599968
# Unit test for function main
def test_main():
    class AnsibleModuleFake:
        def __init__(self):
            self.argument_spec = ''
            self.check_mode = False
            self.fail_json = lambda x,y:'Invalid call'
            self.fail_json = lambda x,y:'Invalid call'
            self.fail_json = lambda x,y:'Invalid call'
            self.fail_json = lambda x,y:'Invalid call'
            self.fail_json = lambda x,y:'Invalid call'
            self.fail_json = lambda x,y:'Invalid call'
            self.fail_json = lambda x,y:'Invalid call'
            self.fail_json = lambda x,y:'Invalid call'

    module = AnsibleModuleFake()
    for i in range(1000):
        try:
            main()
        except:
            break


# Unit

# Generated at 2022-06-25 02:49:38.085091
# Unit test for function check_file_attrs

# Generated at 2022-06-25 02:49:48.788927
# Unit test for function check_file_attrs
def test_check_file_attrs():
    file_content = ["!\n", "host_alias_1=server1\n", "host_alias_2=server2\n", "host_alias_3=server3\n"]
    module = """
- ansible.builtin.lineinfile:
    path: './hosts'
    regexp: '^host_alias_1='
    line: 'host_alias_1=server_new'
"""
    import json
    import ast
    module = ast.literal_eval(module)
    module = AnsibleModule(
        argument_spec=module['ansible.builtin.lineinfile']['argument_spec'],
        supports_check_mode=module['ansible.builtin.lineinfile']['supports_check_mode']
    )

    changed = True

# Generated at 2022-06-25 02:49:52.826903
# Unit test for function write_changes
def test_write_changes():
    #self, b_lines, dest):
    result = write_changes(module, b_lines, dest)
    assert result == b_lines


# Generated at 2022-06-25 02:49:53.604419
# Unit test for function absent
def test_absent():
    assert absent() == 0
