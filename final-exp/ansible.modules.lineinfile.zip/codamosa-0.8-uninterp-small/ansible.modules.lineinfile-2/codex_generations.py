

# Generated at 2022-06-25 02:43:41.651578
# Unit test for function write_changes

# Generated at 2022-06-25 02:43:53.264376
# Unit test for function absent

# Generated at 2022-06-25 02:43:54.342263
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:44:01.071848
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = AnsibleModule({
        'path': 'c:/temp/test.txt',
        'backrefs': 'True',
        'backup': 'True',
        'firstmatch': 'True',
        'group': 'root',
        'insertafter': 'True',
        'insertbefore': 'True',
        'line': 'Test Line',
        'mode': '0644',
        'owner': 'root',
        'search_string': '127.0.0.1',
        'state': 'present',
        'tmpdir': 'c:/temp',
        'unsafe_writes': 'True',
        'validate': None,
    })
    out = check_file_attrs(module, False, 'Test Message', True)
    assert out[0] == 'Test Message'
    assert out[1]

# Generated at 2022-06-25 02:44:07.465891
# Unit test for function write_changes
def test_write_changes():
    var_0 = AnsibleModule()
    var_1 = ["b'#192.168.1.1  192.168.1.1. locahost.localdomain localhost\\n'"]
    var_2 = write_changes(var_0, var_1, '/home/ansible/foo')
    assert True


# Generated at 2022-06-25 02:44:14.289563
# Unit test for function absent
def test_absent():
    var_1 = os.path.exists('dest')
    var_2 = os.makedirs('dest')
    var_3 = os.path.join('dest', 'something.txt')
    var_4 = open(var_3, 'a')
    var_5 = var_4.close()
    var_6 = open(var_3, 'r')
    var_7 = var_6.read()
    var_8 = var_6.close()
    var_9 = dict(
        dest=var_3,
        regexp=None,
        search_string=None,
        line='test',
        backup=False
    )
    var_10 = absent(module, **var_9)
    var_11 = os.path.exists('dest')
    var_12 = os.rmdir

# Generated at 2022-06-25 02:44:18.168032
# Unit test for function present
def test_present():
    # Declare function inputs
    dest = 'a.txt'
    regexp = None
    search_string = 'hello'
    line = 'hello world'
    insertafter = 'EOF'
    insertbefore = None
    create = None
    backup = False
    backrefs = False
    firstmatch = None
    # Declare actual output
    expected_result = None
    # Call function
    actual_result = present(dest, regexp, search_string, line, insertafter, insertbefore, create, backup, backrefs, firstmatch)
    # Assertions
    assert actual_result == expected_result


# Generated at 2022-06-25 02:44:26.697317
# Unit test for function write_changes
def test_write_changes():
    # Make two temporary files
    fd1, tmp1 = tempfile.mkstemp()
    fd2, tmp2 = tempfile.mkstemp()
    fd3, tmp3 = tempfile.mkstemp()
    with os.fdopen(fd1, 'wb') as f:
        f.write(to_bytes("Hello World\n", errors='surrogate_or_strict'))
    with os.fdopen(fd2, 'wb') as f:
        f.write(to_bytes("Hello World\n", errors='surrogate_or_strict'))
    with os.fdopen(fd3, 'wb') as f:
        f.write(to_bytes("Hello World\n", errors='surrogate_or_strict'))

# Generated at 2022-06-25 02:44:30.900714
# Unit test for function present
def test_present():
    # Format of test cases is as follows
    # See https://docs.python.org/2/library/unittest.html
    # and http://docs.python-guide.org/en/latest/writing/tests/
    test_case_0()

# Unit test execution
# Only uncomment the line below if you want to run unit tests manually
#test_present()

# Generated at 2022-06-25 02:44:36.955242
# Unit test for function absent
def test_absent():
    module = ansible_module_create()

    # We will mock the module and the file action plugin
    # so we can unit test the state module.
    m_exit_json = Mock(return_value=None)
    m_backup_local = Mock(return_value=None)
    m_write_changes = Mock(return_value=None)

    module.exit_json = m_exit_json
    module.backup_local = m_backup_local
    module.write_changes = m_write_changes

    # Setup
    dest = ModuleStub(path='/path/to/file', exists=True)
    regexp = None
    search_string = 'REPLACEME'
    line = 'something-to-replace'
    backup = True

    def test_setup():
        pass


# Generated at 2022-06-25 02:45:02.741617
# Unit test for function absent
def test_absent():
    module = AnsibleModule({'dest': 'foo', '_diff': True, 'search_string': 'bar'})
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = 'bar'
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-25 02:45:06.512563
# Unit test for function present
def test_present():
    dest = "/opt/jboss-as/bin/standalone.conf"
    regexp = "^(.*)Xms(\d+)m(.*)$"
    search_string = None
    line = "\1Xms${xms}m\3"
    insertafter = None
    insertbefore = None
    create = False
    backup = False
    backrefs = True
    firstmatch = False

    return main(dest, regexp, search_string, line, insertafter, insertbefore, create, backup, backrefs, firstmatch)


# Generated at 2022-06-25 02:45:10.705157
# Unit test for function main
def test_main():
    try:
        assert False
    except:
        e = sys.exc_info()[0]
        assert False

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:45:13.663865
# Unit test for function check_file_attrs
def test_check_file_attrs():

    # Test case 0 - main
    module, changed, message, diff = None, None, None, None
    actual = check_file_attrs(module, changed, message, diff)
    


# Generated at 2022-06-25 02:45:22.846043
# Unit test for function absent
def test_absent():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    # Instantiate AnsibleModule
    module = AnsibleModule()
    # Instantiate DataLoader
    loader = DataLoader()
    module.params = {
        'dest': '/etc/foo',
        'regexp': '^.hello',
        'state': 'absent',
        'backup': False,
    }
    # Instantiate VariableManager
    vars_mgr = VariableManager()
    # Instantiate PlayContext
    play_context = PlayContext(loader=loader, variable_manager=vars_mgr, options={})
    play_context._set_log_path = '/var/tmp'
    play_context._set_

# Generated at 2022-06-25 02:45:24.079250
# Unit test for function write_changes
def test_write_changes():

    var_0 = main()
    # write_changes(module, b_lines, dest)


# Generated at 2022-06-25 02:45:25.606756
# Unit test for function check_file_attrs
def test_check_file_attrs():
    check_file_attrs(test_case_0(),test_case_0(),test_case_0(),test_case_0())


# Generated at 2022-06-25 02:45:26.807059
# Unit test for function present
def test_present():
    test_case_0()

if __name__ == "__main__":
    test_present()

# Generated at 2022-06-25 02:45:29.424655
# Unit test for function absent
def test_absent():
    # var_5 is the return of absent
    var_5 = absent(module=module, regexp=None, line='# This is Ansible managed', dest='test.txt')
    # assert that return is what we expect
    assert var_5 == '# This is Ansible managed', 'incorrect return value received'


# Generated at 2022-06-25 02:45:31.107621
# Unit test for function check_file_attrs
def test_check_file_attrs():
    var_0 = check_file_attrs(obj_0, var_0, var_1, var_2)


# Generated at 2022-06-25 02:46:30.972901
# Unit test for function present
def test_present():
    module = AnsibleModule({
                 'backrefs': False,
                 'backup': False,
                 'create': True,
                 'dest': 'tmp/test.tmp',
                 'group': None,
                 'insertafter': 'EOF',
                 'insertbefore': None,
                 'line': 'some line',
                 'mode': None,
                 'others': None,
                 'owner': None,
                 'regexp': None,
                 'search_string': None,
                 'selevel': None,
                 'serole': None,
                 'setype': None,
                 'seuser': None,
                 'src': None,
                 'unsafe_writes': False,
                 'validate': None
                 })

# Generated at 2022-06-25 02:46:33.462072
# Unit test for function present
def test_present():
    with pytest.raises(SystemExit):
        present(module=None, dest='', regexp=None, search_string='', line='', insertafter=None, insertbefore=None, create=None, backup=None, backrefs=None, firstmatch=None)


# Generated at 2022-06-25 02:46:43.182655
# Unit test for function present
def test_present():
    var_0 = { 'create' : False, 'insertafter' : None, 'validate' : None, 'firstmatch' : False, 'dest' : 'dest_0', 'regexp' : None, 'unsafe_writes' : True, 'insertbefore' : None, 'backup' : False, 'backrefs' : True, 'search_string' : None, 'line' : 'line_0'}
    var_1 = present(var_0)

# Definition(s) to test function present

# Generated at 2022-06-25 02:46:53.403980
# Unit test for function absent
def test_absent():
    module_args={'path': './test_absent.txt', 'state': 'absent', '_raw_params': 'we want this', '_uses_shell': False, '_diff': False, 'backup': True}
    args = dict(module=None, warn=None, diff=None, dest='./test_absent.txt', line='we want this', regexp=None, search_string=None, create=True, backup=True, backrefs=True, insertbefore=None, insertafter=None, firstmatch=False, state='absent')
    with open('./test_absent.txt', 'w') as f:
        f.write('This contains a string we want to remove, but also another string we do not\n')
        f.write('another string\n')
    absent(**args)


# Generated at 2022-06-25 02:47:03.492926
# Unit test for function main
def test_main():
    with patch("ansible_collections.ansible.community.plugins.module_utils.basic.AnsibleModule") as var_0:
        var_0.return_value.params = {'regexp': '', 'state': 'present', '_diff': True,
                                     'content': [b'', b'', b'', b'', b'', b'', b'', b'', b'', b'', b''],
                                     '_ansible_check_mode': False, 'insertafter': 'EOF', 'path': 'ansible_test'}
        var_0.return_value.check_mode = False
        var_0.return_value.no_log = False
        var_0.return_value.backup_local.return_value = 'backup'
        var_0.return_value

# Generated at 2022-06-25 02:47:13.035765
# Unit test for function write_changes
def test_write_changes():
    ansible.module_utils.basic.AnsibleModule = ansible.module_utils.basic.AnsibleModule_old

# Generated at 2022-06-25 02:47:20.893798
# Unit test for function main
def test_main():
    class MockArgs(object):
        def __init__(self, path, state, regexp, search_string, line, insertafter, insertbefore, backrefs, create, backup, firstmatch, validate):
            self.path = path
            self.state = state
            self.regexp = regexp
            self.search_string = search_string
            self.line = line
            self.insertafter = insertafter
            self.insertbefore = insertbefore
            self.backrefs = backrefs
            self.create = create
            self.backup = backup
            self.firstmatch = firstmatch
            self.validate = validate


# Generated at 2022-06-25 02:47:22.606293
# Unit test for function absent
def test_absent():
    try:
        test_case_0()
    except SystemExit as e:
        print(e)
    except Exception as e:
        print('Caught exception: %s: %s' % (e.__class__.__name__, to_native(e)))
    return


# Generated at 2022-06-25 02:47:27.465980
# Unit test for function write_changes
def test_write_changes():
    class test_obj0(object):
        def __init__(self):
            self.tmpdir = '/tmp'
            self.params = {}
            self.params['unsafe_writes'] = None
            self.atomic_move = test_obj1
            self.run_command = test_obj1
            self.fail_json = test_obj1
    class test_obj1(object):
        def __init__(self, *a, **b):
            self.arg = a
            self.kwargs = b
        def __call__(self, *a, **b):
            return self.arg, self.kwargs
    fname = 'test_file'
    myfile = open(fname, mode='w')
    myfile.write('test line 1\n')

# Generated at 2022-06-25 02:47:33.731625
# Unit test for function check_file_attrs
def test_check_file_attrs():
    var_0 = True
    var_1 = "ownership, perms or SE linux context changed"
    var_2 = False
    var_3 = False
    var_4 = "ownership, perms or SE linux context changed"
    result = check_file_attrs(var_0, var_1, var_2, var_3)
    assert result == var_4


# Generated at 2022-06-25 02:48:15.667292
# Unit test for function write_changes
def test_write_changes():
    test_file = os.path.join(os.path.dirname(__file__), 'test.txt')

# Generated at 2022-06-25 02:48:21.795107
# Unit test for function absent
def test_absent():
    module = get_module_mock()
    dest = tempfile.mktemp()
    regexp = ".*"
    search_string = None
    line = "Hello World"
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-25 02:48:23.750014
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Function tests
    var_0 = check_file_attrs(test_case_0(), 0, '', [])
    return var_0


# Generated at 2022-06-25 02:48:32.571133
# Unit test for function main
def test_main():
    with open("test.txt", "w") as f:
        f.write("Hello World!\n")
    with open("test.txt", "r") as f:
        for line in f:
            print("Test file line: " + line)
    test_case = {
        "state": "present",
        "path": "/home/student/ansible/test.txt",
        "line": "Hello World!",
        "module_path": "/usr/local/lib/python3.5/dist-packages/ansible/modules/files/lineinfile.py"
        }
    set_module_args(test_case)
    test_case_0()
    if os.path.exists("test.txt"):
        os.remove("test.txt")


# Generated at 2022-06-25 02:48:33.699700
# Unit test for function write_changes
def test_write_changes():
    test_case_0()


# Generated at 2022-06-25 02:48:40.930745
# Unit test for function present
def test_present():
    var_2 = create_args()
    var_2['create'] = True
    var_2['line'] = 'abc'
    present(var_0, 'var_1', 'regexp', 'search_string', 'var_2', 'insertafter', 'insertbefore', True, False, False, False)


# Generated at 2022-06-25 02:48:47.447213
# Unit test for function write_changes
def test_write_changes():
    lines = [b'There is a line with hostname {{ hostname }}']
    dest = tempfile.mkdtemp() + 'test'
    module = AnsibleModule(argument_spec={'name': {'default': dest, 'type': 'str'}})
    write_changes(module, lines, dest)


# Generated at 2022-06-25 02:48:51.795476
# Unit test for function present
def test_present():
    assert present(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9, var_10) == None


# Generated at 2022-06-25 02:48:58.975859
# Unit test for function present
def test_present():
    module = dummy_ansible_module(
        dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str', required=True),
            line=dict(type='str', required=True),
        )
    )

    # The values below are arbitrary and can be changed.
    # dest='/home/pi/foo.txt', regexp='^(.*)Xms(\d+)m(.*)$', line='\1Xms${xms}m\3',
    dest = '/home/pi/foo.txt'
    regexp = '^(.*)Xms(\d+)m(.*)$'
    line = '\1Xms${xms}m\3'


# Generated at 2022-06-25 02:48:59.757643
# Unit test for function check_file_attrs
def test_check_file_attrs():
    main()


# Generated at 2022-06-25 02:49:44.888179
# Unit test for function absent
def test_absent():
    module = AnsibleModule({})
    dest = False
    regexp = False
    search_string = False
    line = False
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-25 02:49:46.960506
# Unit test for function absent
def test_absent():
    module = AnsibleModule()
    assert(absent(module, dest="/etc/default/dnsmasq", regexp=None, search_string=None, line="#Comment", backup=True))


# Generated at 2022-06-25 02:49:48.509400
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:49:56.101154
# Unit test for function present
def test_present():
    module = AnsibleModule({'dest': '/opt/jboss-as/bin/standalone.conf', 'regexp': '^(.*)Xms(\d+)m(.*)$', 'line': '\1Xms${xms}m\3', 'backrefs': 'yes', 'unsafe_writes': 'yes'})
    present(module, '/opt/jboss-as/bin/standalone.conf', '^(.*)Xms(\d+)m(.*)$', None, '\1Xms${xms}m\3', None, None, None, None, 'yes', None)


# Generated at 2022-06-25 02:50:01.751729
# Unit test for function present
def test_present():
    # None as first parameter
    try:
        assert present(None, dest='test_value_2', regexp='test_value_3', search_string='test_value_4', line='test_value_5', insertafter='test_value_6', insertbefore='test_value_7', create=False, backup=False, backrefs=False, firstmatch=False)
    except:
        raise Exception('Test case failed')
    # False as first parameter
    try:
        assert present(False, dest='test_value_2', regexp='test_value_3', search_string='test_value_4', line='test_value_5', insertafter='test_value_6', insertbefore='test_value_7', create=False, backup=False, backrefs=False, firstmatch=False)
    except:
        raise

# Generated at 2022-06-25 02:50:05.057839
# Unit test for function write_changes
def test_write_changes():
    # src/ansible/modules/files/lineinfile.py:39
    module = get_module()
    assert True == False



# Generated at 2022-06-25 02:50:12.472996
# Unit test for function check_file_attrs
def test_check_file_attrs():
    var_0 = True
    var_1 = ""
    var_2 = "None"
    var_3 = check_file_attrs(module, changed, message, diff)
    if var_3 == "False" and changed == var_3 and message == var_1 and diff == var_2:
        return True
    else:
        return False


# Generated at 2022-06-25 02:50:21.686483
# Unit test for function write_changes
def test_write_changes():
    var_0 = main()
    if var_0:
        var_0.atomic_move('./my_ansible_tmp/ansible-tmp-1581752000.42-240112022740163/tmpFwYiMn', './main', unsafe_writes=False, backup_file='./main')
    if var_0:
        var_0.atomic_move('./my_ansible_tmp/ansible-tmp-1581752000.42-240112022740163/tmpH0jrPQ', './main', unsafe_writes=False, backup_file='./main')

# Generated at 2022-06-25 02:50:23.753534
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception:
        print('Failed to run unit test')

# Run unit test
test_main()

# Generated at 2022-06-25 02:50:29.494166
# Unit test for function present
def test_present():
    module = AnsibleModule( argument_spec=dict(
		dest=dict(type='path', required=True),
        regexp=dict(),
        search_string=dict(),
        line=dict(required=True),
        insertafter=dict(),
        insertbefore=dict(),
        create=dict(default=False, type='bool'),
        backup=dict(default=False, type='bool'),
        backrefs=dict(default=False, type='bool'),
        firstmatch=dict(default=False, type='bool'),
        state=dict(choices=['present', 'absent'], default='present'),
        unsafe_writes=dict(default=False, type='bool', aliases=['unsafe-writes']),
        validate=dict(default=None)),
    supports_check_mode=True)

# Generated at 2022-06-25 02:52:32.641346
# Unit test for function present
def test_present():
    assert True == True

if __name__ == "__main__":
    test_present()

# Generated at 2022-06-25 02:52:42.783755
# Unit test for function write_changes
def test_write_changes():
    module_0=AnsibleModule
    b_lines_0=b'hx6k'
    dest_0='path'
    tmpfd_0, tmpfile_0 = tempfile.mkstemp(dir=module_0.tmpdir)
    with os.fdopen(tmpfd_0, 'wb') as f:
        f.writelines(b_lines_0)

    validate_0 = module_0.params.get('validate', None)
    valid_0 = not validate_0
    if validate_0:
        if "%s" not in validate_0:
            module_0.fail_json(msg="validate must contain %%s: %s" % (validate_0))

# Generated at 2022-06-25 02:52:50.243042
# Unit test for function present
def test_present():
    test_data = [
        ("/etc/hosts", None, None, "127.0.0.1 localhost", None, None, True, False, True, True),
        ("/etc/hosts", "(#.*)?(127\\.0\\.0\\.1.*localhost.*)", None, "127.0.0.1 localhost", None, None, True, False, False, False)
    ]

    for test_row in test_data:
        present(test_row[0], test_row[1], test_row[2], test_row[3], test_row[4], test_row[5], test_row[6], test_row[7], test_row[8], test_row[9])


# Generated at 2022-06-25 02:52:53.480443
# Unit test for function write_changes
def test_write_changes():
    ansible.module_utils.basic.AnsibleModule.run_command = lambda x, **args: (0, 'Hello', '')

    var_0 = os.path.join('test', 'test')
    var_1 = [b'Test test\n']

    write_changes(AnsibleModule, var_1, var_0)


# Generated at 2022-06-25 02:52:54.980732
# Unit test for function check_file_attrs
def test_check_file_attrs():
    var_0 = main()
    assert var_0 == 0, "Unittest failed, check output for info"


# Generated at 2022-06-25 02:52:58.462114
# Unit test for function absent
def test_absent():
    # First test
    module_args = dict(
        dest='/root/path/to/bar',
        regexp='regexp_string',
        search_string='search_string',
        line='line_string',
        state='absent',
        backup=True )
    print(pformat(module_args))
    absent(module_args, 'string', 'string', 'string', 'string', string )
