

# Generated at 2022-06-25 02:43:47.159492
# Unit test for function main

# Generated at 2022-06-25 02:43:53.623326
# Unit test for function write_changes
def test_write_changes():
    str_0 = 'ansible.modules.lineinfile'
    int_0 = 796
    var_0 = write_changes(str_0, str_0, int_0)


# Generated at 2022-06-25 02:43:57.811173
# Unit test for function write_changes
def test_write_changes():
    var_1 = ansible.modules.lineinfile.AnsibleModule
    str_1 = 'ansible.modules.lineinfile'
    int_1 = 804
    str_2 = 'ansible.modules.lineinfile'
    int_2 = 804
    var_2 = write_changes(str_2, str_2, int_2)


# Generated at 2022-06-25 02:44:09.345200
# Unit test for function main

# Generated at 2022-06-25 02:44:12.296858
# Unit test for function write_changes
def test_write_changes():
    str_0 = 'ansible.modules.lineinfile'
    int_0 = 197
    var_0 = write_changes(str_0, str_0, int_0)
    var_1 = write_changes('ansible.modules.lineinfile', 'ansible.modules.lineinfile', 804)
    assert var_0 != var_1


# Generated at 2022-06-25 02:44:19.357859
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Create mock obj
    # test_case = class_name()

    # mock input and output
    # function_input = obj.function_name(params)
    # obj.assertEqual(expected, function_input)

    # mock input and output
    # function_input = obj.function_name(params)
    # obj.assertEqual(expected, function_input)
    pass


# Generated at 2022-06-25 02:44:27.255080
# Unit test for function present
def test_present():
    str_0 = 'ansible.modules.lineinfile'
    str_1 = 'ansible.modules.lineinfile'
    str_2 = 'ansible.modules.lineinfile'
    str_3 = 'ansible.modules.lineinfile'
    str_4 = 'ansible.modules.lineinfile'
    str_5 = 'ansible.modules.lineinfile'
    str_6 = 'ansible.modules.lineinfile'
    str_7 = 'ansible.modules.lineinfile'
    num_0 = 804
    num_1 = 804
    var_0 = 'ansible.modules.lineinfile'
    var_1 = 'ansible.modules.lineinfile'
    num_2 = 804
    num_3 = 804

# Generated at 2022-06-25 02:44:33.496400
# Unit test for function absent
def test_absent():
    str_0 = 'ansible.modules.lineinfile'
    int_0 = 804
    str_1 = 'linux'
    int_1 = 28
    str_2 = 'ansible.modules.lineinfile'
    var_0 = absent(str_0, str_1, int_0, int_1, str_2)


# Generated at 2022-06-25 02:44:42.192646
# Unit test for function main
def test_main():
    str_0 = 'ansible.modules.lineinfile'
    str_1 = 'tests/fixtures/modules/json_validator_config.json'
    str_2 = 'dest'
    str_3 = 'inserts'
    str_4 = 'config'
    dict_0 = dict()
    dict_0['path'] = str_0
    dict_0['state'] = str_1
    dict_0['regexp'] = str_2
    dict_0['search_string'] = str_3
    dict_0['line'] = str_4
    dict_0['insertafter'] = 'inserts'
    dict_0['insertbefore'] = 'tests/fixtures/modules/json_validator_config.json'
    dict_0['backrefs'] = 'dest'

# Generated at 2022-06-25 02:44:45.682029
# Unit test for function absent
def test_absent():
    # Remove the specified line from a file
    str_0 = "An absent file"
    str_1 = "ansible.modules.lineinfile"
    str_2 = "ansible.modules.lineinfile"
    absent(str_0, str_1, str_2, str_0, str_1)

# Generated at 2022-06-25 02:45:18.006384
# Unit test for function absent
def test_absent():
    dest='/etc/foo/bar'
    regexp=None
    search_string='string'
    line='string'
    backup=False
    print('--Testing absent--')
    print('Unit test for function absent')
    print('argument destination : ' + dest)
    print('argument regexp : ' + str(regexp))
    print('argument search_string : ' + search_string)
    print('argument line : ' + line)
    print('argument backup : ' + str(backup))
    print('--End unit test for absent--')
    print('\n')


# Generated at 2022-06-25 02:45:22.638512
# Unit test for function check_file_attrs
def test_check_file_attrs():
    #pylint: disable=W0613, W0212
    message = "test message"
    diff = {}
    changed = False
    print(check_file_attrs(None, changed, message, diff))


# Generated at 2022-06-25 02:45:29.185465
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.lineinfile import main
    module_name = 'ansible.modules.lineinfile'

# Generated at 2022-06-25 02:45:36.094172
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            dest = dict(required=True, type='path'),
            regexp = dict(required=True),
            search_string = dict(),
            line = dict(required=True),
            insertafter = dict(),
            insertbefore = dict(),
            create = dict(type='bool', default=False),
            backup = dict(type='bool', default=False),
            backrefs = dict(type='bool', default=False),
            firstmatch = dict(type='bool', default=False),
            validate = dict(type='raw'),
            unsafe_writes = dict(type='bool', default=True, aliases=['unsafe-writes'])
        ),
        add_file_common_args=True,
        supports_check_mode=True
    )


# Generated at 2022-06-25 02:45:43.711417
# Unit test for function check_file_attrs
def test_check_file_attrs():
    str_0 = 'vJ@c<,?|f&GpN+l{ZG'
    str_1 = '+M"\u20b3q0.Q5J5[8V~\u20b3'
    int_0 = 972
    int_1 = 969
    str_2 = ''
    int_2 = 539
    str_3 = '8X7W.:jv\u20d7'
    str_4 = 'G{!kfS#g_\u20d6'
    str_5 = '@!jk'
    var_0 = test_case_0()
    str_6 = 'h.m0y'
    str_7 = 'G`^lvb'
    str_8 = '@!jk'

# Generated at 2022-06-25 02:45:45.045008
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:45:46.798741
# Unit test for function write_changes
def test_write_changes():
    print("Testing write_changes()")
    write_changes('ansible.modules.lineinfile', 'ansible.modules.lineinfile', 804)

test_write_changes()

# Generated at 2022-06-25 02:45:54.118723
# Unit test for function absent
def test_absent():
    dest = 'test_file'
    regexp = 'test_absent'
    search_string = 'test_absent'
    line = 'test_absent test_line\n'
    backup = 'test_absent'
    # Test function absent
    module = AnsibleModule({'backup': backup, 'dest': dest, 'line': line, 'regexp': regexp, 'search_string': search_string})
    absent(module, dest, regexp, search_string, line, backup)
    f = open('test_file', 'w')
    f.write('test_absent test_line\n')
    f.close()
    with open('test_file', 'r') as f:
        b_lines = f.readlines()

# Generated at 2022-06-25 02:46:00.152860
# Unit test for function present
def test_present():
    # Test function call with arguments
    int_0 = 0
    int_1 = 0
    int_2 = 0
    int_3 = 0
    int_4 = 0
    int_5 = 0
    int_6 = 0
    int_7 = 0
    int_8 = 0
    int_9 = 0
    int_10 = 0
    int_11 = 0
    int_12 = 0
    int_13 = 0
    int_14 = 0
    int_15 = 0
    int_16 = 0
    int_17 = 0
    str_0 = "gqrqU"
    str_1 = "nRZBQ"
    str_2 = "5DSji"
    str_3 = "U6JwU"
    str_4 = "6Qk0X"
    str

# Generated at 2022-06-25 02:46:10.072259
# Unit test for function absent
def test_absent():
    TEST_FILE = 'pwfile.txt'
    TEST_FILE_REGEX = 'pwfile_regex.txt'
    TEST_FILE_SEARCH_STRING = 'pwfile_search_string.txt'
    TEST_FILE_BACKUP = 'pwfile_backup.txt'

# Generated at 2022-06-25 02:46:37.448887
# Unit test for function present
def test_present():
    # Test inputs
    module = 'test'
    dest = '/tmp/test'
    regexp = '^(.*)Xms(\d+)m(.*)$'
    search_string = 'Xms512m'
    line = '\1Xms${xms}m\3'
    insertafter = '^(.*)Xms(\d+)m(.*)$'
    insertbefore = '^(.*)Xms(\d+)m(.*)$'
    create = None
    backup = 'yes'
    backrefs = 'yes'
    firstmatch = 'yes'

    var_0 = module.tmpdir
    # Test output
    # First test the function with a new file

# Generated at 2022-06-25 02:46:48.437673
# Unit test for function check_file_attrs
def test_check_file_attrs():
    if not os.path.exists("build/tmp"):
        os.makedirs("build/tmp")
    str0 = tempfile.mkdtemp("build/tmp")


# Generated at 2022-06-25 02:46:50.041139
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:46:54.167066
# Unit test for function check_file_attrs
def test_check_file_attrs():
    str_0 = 'ansible.modules.lineinfile'
    int_0 = 804
    var_0 = check_file_attrs(str_0, str_0, int_0, int_0)


# Generated at 2022-06-25 02:47:00.047391
# Unit test for function check_file_attrs
def test_check_file_attrs():
    str_0 = 'ansible.modules.lineinfile'
    len_0 = 0
    str_1 = str_2 = str_3 = str_1
    int_0 = 1
    var_0 = check_file_attrs(str_0, int_0, str_1, str_2)
    print(type(var_0))
    print(var_0)


# Generated at 2022-06-25 02:47:00.671489
# Unit test for function write_changes
def test_write_changes():
    assert False


# Generated at 2022-06-25 02:47:07.847966
# Unit test for function present
def test_present():
    # file does not exist and should fail
    result = present("/etc/nomodulehasfile",".*","","","These words",None,None,False,True,False,False)
    result = present("/etc/passwd",".*","","","These words",None,None,False,True,False,False)
    # This is a present test
    result = present("/etc/foo",".*","","","These words",None,None,True,True,False,False)
    # This is a present test
    result = present("/etc/foo","ansible.module_utils.basic.AnsibleModule","","#!/usr/bin/python","These words",None,None,True,True,False,False)
    # This is a present test

# Generated at 2022-06-25 02:47:17.585161
# Unit test for function write_changes

# Generated at 2022-06-25 02:47:20.013367
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 02:47:27.523364
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule('lineinfile', 'path=/tmp/test')
    changed = True
    message = 'This is a test'
    diff = 'this is a diff'
    result = check_file_attrs(module, changed, message, diff)
    assert result == ('This is a test and ownership, perms or SE linux context changed', True)

if __name__ == '__main__':
    test_check_file_attrs()

# Generated at 2022-06-25 02:48:20.427696
# Unit test for function check_file_attrs
def test_check_file_attrs():
    str_0 = 'ansible.module_utils.basic'
    bool_0 = False
    str_1 = 'ansible.module_utils.basic'
    var_0 = check_file_attrs(str_0, bool_0, str_1)


# Generated at 2022-06-25 02:48:28.295613
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True),
            regexp=dict(),
            search_string=dict(),
            line=dict(required=True),
            insertafter=dict(),
            insertbefore=dict(),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(default='no', aliases=['backrefs'], type='bool'),
            firstmatch=dict(default='no', aliases=['firstmatch'], type='bool'),
            validate=dict(),
            unsafe_writes=dict(type='bool', default=False),
            state=dict(default='present', choices=['present', 'absent']),
        ),
        supports_check_mode=True,
    )
   

# Generated at 2022-06-25 02:48:31.627919
# Unit test for function write_changes
def test_write_changes():
    from ansible.modules.lineinfile import test_case_0
    test_case_0()


# Generated at 2022-06-25 02:48:37.382145
# Unit test for function present
def test_present():
    '''Write a unit test for present'''
    dest = ''
    search_string = ''
    line = ''
    regexp = ''
    insertafter = ''
    insertbefore = ''
    create = ''
    backup = ''
    backrefs = ''
    firstmatch = ''
    present(dest, regexp, search_string, line, insertafter, insertbefore, create, backup, backrefs, firstmatch)


# Generated at 2022-06-25 02:48:41.637928
# Unit test for function main
def test_main():
    b_path_0 = 'path'
    params_0 = {'backup': True, 'backrefs': True, 'dest': b_path_0, 'search_string': None, 'line': b_path_0, 'regexp': None, 'insertbefore': None, 'state': 'present', 'insertafter': None}
    path_0 = 'path'
    present(None, path_0, None, None, 'l', 'EOF', None, False, True, True, False)
    present(None, path_0, None, None, 'l', 'EOF', None, False, True, True, False)


# Generated at 2022-06-25 02:48:42.413853
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 02:48:43.177657
# Unit test for function present
def test_present():
    assert test_case_0() == 0


# Generated at 2022-06-25 02:48:54.223177
# Unit test for function absent

# Generated at 2022-06-25 02:49:03.991896
# Unit test for function main
def test_main():
    path = 'ansible/modules/files/lineinfile.py'
    state = 'present'
    regexp = '^#\s*?(PermitRootLogin|PasswordAuthentication|ChallengeResponseAuthentication)'
    search_string = '^#\s*?(PermitRootLogin|PasswordAuthentication|ChallengeResponseAuthentication)'
    line = '$1 yes'
    insertafter = '#?[ \t]*?PermitRootLogin'
    insertbefore = '^#?[ \t]*?PermitRootLogin'
    create = True
    backup = False
    backrefs = False
    firstmatch = True
    validate = 'path'
    b_path = to_bytes(path, errors='surrogate_or_strict')

# Generated at 2022-06-25 02:49:06.624961
# Unit test for function write_changes
def test_write_changes():
    try:
        assert callable(write_changes)
        test_case_0()
    except AssertionError:
        raise


# Generated at 2022-06-25 02:50:57.088713
# Unit test for function check_file_attrs
def test_check_file_attrs():
    str_0 = 'ansible.modules.lineinfile'
    str_1 = 'ansible.modules.lineinfile'
    str_2 = 'ansible.modules.lineinfile'
    int_0 = 721
    var_0 = check_file_attrs(str_0, str_1, str_2, int_0)


# Generated at 2022-06-25 02:50:58.594273
# Unit test for function write_changes
def test_write_changes():
    assert str_0 == str_0
    assert int_0 == int_0
    assert var_0 == var_0


# Generated at 2022-06-25 02:51:07.224163
# Unit test for function write_changes
def test_write_changes():
    # Lambda to check the result object
    check_result = lambda r: (r['path'], r['line'])
    # Create the expected result object
    expected_result = dict(path='ansible.modules.lineinfile', line=804)
    # Actually call the function
    actual_result = write_changes('ansible.modules.lineinfile',
                                  'ansible.modules.lineinfile', 804)
    assert actual_result == expected_result



# Generated at 2022-06-25 02:51:17.192422
# Unit test for function present
def test_present():
    str_0 = 'ansible.modules.lineinfile'
    str_1 = 'ansible.modules.lineinfile'
    str_2 = '*'
    str_3 = 'ansible.modules.lineinfile'
    str_4 = 'ansible.modules.lineinfile'
    str_5 = 'ansible.modules.lineinfile'
    str_6 = 'ansible.modules.lineinfile'
    str_7 = 'ansible.modules.lineinfile'
    str_8 = 'ansible.modules.lineinfile'
    str_9 = 'ansible.modules.lineinfile'
    str_10 = 'ansible.modules.lineinfile'

# Generated at 2022-06-25 02:51:18.849403
# Unit test for function write_changes
def test_write_changes():
    # AssertionError: None does not match 'ansible.modules.lineinfile'
    test_case_0()


# Generated at 2022-06-25 02:51:21.187119
# Unit test for function write_changes
def test_write_changes():
    str_0 = 'ansible.modules.lineinfile'
    int_0 = 804
    var_0 = write_changes(str_0, str_0, int_0)


# Generated at 2022-06-25 02:51:31.592976
# Unit test for function main
def test_main():
    class Bunch(object):
        def __init__(self, adict):
            self.__dict__.update(adict)
    # Prepare 'ansible.modules.lineinfile'
    str_0 = 'ansible.modules.lineinfile'
    int_0 = 64
    var_0 = to_bytes(str_0, errors='surrogate_or_strict')
    str_1 = 'ansible.modules.lineinfile'
    b_path = to_bytes(str_1, errors='surrogate_or_strict')
    # Prepare module_utils.basic.AnsibleModule
    def exit_json(changed, msg, backup='', diff=''):
        return
    def fail_json(msg, **kwargs):
        return
    def warn(msg):
        return

# Generated at 2022-06-25 02:51:40.878836
# Unit test for function absent
def test_absent():
    int_0 = 22
    int_1 = 0
    str_0 = 'src/ansible/modules/files/lineinfile.py'
    str_1 = 'src/ansible/modules/files/lineinfile.py'
    str_2 = 'ansible.modules.lineinfile'
    str_3 = 'ansible.modules.lineinfile'
    str_4 = 'ansible.modules.lineinfile'
    str_5 = 'ansible.modules.lineinfile'
    str_6 = 'ansible.modules.lineinfile'
    str_7 = 'ansible.modules.lineinfile'
    str_8 = 'ansible.modules.lineinfile'
    str_9 = 'ansible.modules.lineinfile'
    int_2 = 1

# Generated at 2022-06-25 02:51:46.999317
# Unit test for function present
def test_present():

    # From Ansible Docs
    lineinfile_params = dict(
        path='/etc/resolv.conf',
        regexp='^nameserver',
        line='nameserver 8.8.8.8'
    )
    module = AnsibleModule(argument_spec=lineinfile_params)
    present(module, '/etc/resolv.conf', '^nameserver', None, 'nameserver 8.8.8.8', 'BOF', None, False, False, False, False)

    lineinfile_params = dict(
        path='/etc/resolv.conf',
        regexp='^nameserver',
        line='nameserver 8.8.8.8'
    )
    module = AnsibleModule(argument_spec=lineinfile_params)

# Generated at 2022-06-25 02:51:51.152497
# Unit test for function absent
def test_absent():
    assert absent('ansible.modules.lineinfile', 'ansible.modules.lineinfile', 'ansible.modules.lineinfile', 'ansible.modules.lineinfile', 804, 804) is 'ansible.modules.lineinfile'
