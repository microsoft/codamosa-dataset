

# Generated at 2022-06-25 02:43:50.932726
# Unit test for function present
def test_present():
    os.system("ansible localhost -m lineinfile -a \"dest=/tmp/testinsertafter line='Testing insert after' insertafter='EOF'\" | grep 'changed'")


# Generated at 2022-06-25 02:43:59.924715
# Unit test for function present
def test_present():
    # These variables are defined in
    # tests/unit/compat/mock/ansible_module_lineinfile.py
    ansible_module_lineinfile = Mock(return_value={})

    # Set up the mock
    ansible_module_lineinfile[u"check_mode"] = True

    input_0 = '\xda\x196\\mX\xfcN\x93\xc7'

# Generated at 2022-06-25 02:44:10.441195
# Unit test for function check_file_attrs
def test_check_file_attrs():
    os.system('touch /tmp/foo')

# Generated at 2022-06-25 02:44:22.376383
# Unit test for function main
def test_main():
    dict_0 = {}
    dict_0['search_string'] = 'ZXhtdWNpI'
    dict_0['insertafter'] = '-=H%\x81'
    dict_0['line'] = '\x1a\x1d\x9c'
    dict_0['insertbefore'] = ' \x819\xcc\x1b'
    dict_0['regexp'] = '\xe0'
    dict_0['path'] = '\x18\x9f\x9fX\x04\xc1\xca\xf7\x08'
    dict_0['state'] = 'present'
    dict_0['backup'] = True
    dict_0['firstmatch'] = False
    dict_0['backrefs'] = True

# Generated at 2022-06-25 02:44:33.700317
# Unit test for function write_changes
def test_write_changes():

    local_path = os.path.dirname(__file__)
    module_utils_file = os.path.join(local_path, 'module_utils_ansible.py')

    module_args = dict(
        path='/tmp/dest',
        line='This is a test',
        create=True,
        owner='root',
        group='root',
        mode='0644',
        backup=False,
        validate=None,
        unsafe_writes=True
    )
    module_path = os.path.join(local_path, 'modules', 'actions')
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
        bypass_checks=True,
        module_utils_importer=module_utils_file
    )


# Generated at 2022-06-25 02:44:35.726500
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    module.tmpdir = tempfile.gettempdir()
    b_lines = b'test'
    dest = '/etc/hosts'
    write_changes(module, b_lines, dest)


# Generated at 2022-06-25 02:44:36.363956
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_case_0()


# Generated at 2022-06-25 02:44:41.314478
# Unit test for function main
def test_main():
    test_cases = [
        # Unit test for function main
        (
            {
                "insertafter": "insertbefore",
                "regexp": "regex",
                "search_string": "search_string",
                "line": "line"
            },
            {
                "backrefs": False,
                "create": False,
                "backup": False,
                "firstmatch": False
            },
            True
        )
    ]

    for test_case in test_cases:
        assert main(**test_case[0]) == test_case[1]
