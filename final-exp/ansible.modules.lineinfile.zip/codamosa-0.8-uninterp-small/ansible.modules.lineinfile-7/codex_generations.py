

# Generated at 2022-06-25 02:43:36.918010
# Unit test for function absent
def test_absent():
    int_0 = 1082
    var_0 = main()


# Generated at 2022-06-25 02:43:37.720323
# Unit test for function absent
def test_absent():
    test_case_0()


# Generated at 2022-06-25 02:43:42.427904
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 02:43:53.371323
# Unit test for function absent
def test_absent():
    # Return(dest, regexp, search_string, line, backup):
    # Return(dest, regexp, search_string, line, backup):
    ret_0 = absent("1", "2", "3", "4", "5")
    ret_1 = absent("1", "2", "3", "4", "5")
    ret_2 = absent("1", "2", "3", "4", "5")
    # Return(dest, regexp, search_string, line, backup):
    ret_3 = absent("1", "2", "3", "4", "5")
    # Return(dest, regexp, search_string, line, backup):
    ret_4 = absent("1", "2", "3", "4", "5")

# Generated at 2022-06-25 02:43:54.208211
# Unit test for function absent
def test_absent():
    test_case_0()


# Generated at 2022-06-25 02:43:58.056981
# Unit test for function present
def test_present():
    print("in present")
    dest = ""
    regexp = ""
    search_string = ""
    line = ""
    insertafter = ""
    insertbefore = ""
    create = ""
    backup = ""
    backrefs = ""
    firstmatch = ""
    present(dest, regexp, search_string, line, insertafter, insertbefore, create, backup, backrefs, firstmatch)


# Generated at 2022-06-25 02:44:09.253648
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True, type='str'),
            regexp=dict(required=False, type='str'),
            search_string=dict(required=False, type='str'),
            line=dict(required=False, type='str'),
            backup=dict(required=False, type='bool', default=False),
            _diff=dict(required=False, type='bool', default=False)
        )
    )
    dest = 'test/path'
    regexp = '/test[a-zA-Z]+/'
    search_string = '/test[a-zA-Z]+/'
    line = 'test_line'
    backup = False
    module._diff = True

# Generated at 2022-06-25 02:44:16.750958
# Unit test for function main
def test_main():
    var_0 = {}
    var_0["path"] = "/home/travis/build/ansible/ansible/test/integration/targets/file_append/file1.txt"
    var_0["state"] = "present"
    var_0["line"] = "hello world"
    main(var_0, False)


# Generated at 2022-06-25 02:44:26.326840
# Unit test for function main
def test_main():
    var_0 = 1277
    var_1 = False
    var_2 = False
    var_3 = False
    var_4 = False
    var_5 = False
    var_6 = False
    var_7 = False
    var_8 = False
    var_9 = False
    var_10 = False
    var_11 = False
    var_12 = False
    var_13 = False
    var_14 = False
    var_15 = False
    var_16 = False
    var_17 = False
    var_18 = False
    var_19 = False
    var_20 = False
    var_21 = False
    var_22 = False
    var_23 = False
    var_24 = False
    var_25 = False
    var_26 = False
    var_27 = False
    var

# Generated at 2022-06-25 02:44:27.821732
# Unit test for function present
def test_present():
    print(present())


# Generated at 2022-06-25 02:44:55.978617
# Unit test for function present
def test_present():
    var_0 = present(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9, var_10)


# Generated at 2022-06-25 02:45:05.578588
# Unit test for function write_changes

# Generated at 2022-06-25 02:45:16.987761
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'regexp': u'^(.*)Xms(\d+)m(.*)$',
        'line': u'\\1Xms${xms}m\\3',
        'backrefs': True
    })
    # test default case
    # not os.path.exists(dest), create = False
    if main(module):
        pass
    else:
        raise Exception('test_case_0 failed')

    # test arg: create
    if main(module, create=True):
        pass
    else:
        raise Exception('test_case_1 failed')

    # test default case
    # insertafter and insertbefore == None

# Generated at 2022-06-25 02:45:22.170430
# Unit test for function main
def test_main():
    import random
    var_0 = random.randint(1, 100)
    var_1 = main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:45:22.881760
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:45:29.274540
# Unit test for function present
def test_present():
    # test case 0
    enable_print = True
    if enable_print:
        logger.info("Starting test case 0")
    test_case_0()
    if enable_print:
        logger.info("Test case 0 finished")

# end unit test for function present

MAIN_FUNCTIONS = {
    'absent': absent,
    'present': present,
}


# Generated at 2022-06-25 02:45:31.205981
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule_Test()
    var_0 = ()
    check_file_attrs(module, var_0, "message", "diff")


# Generated at 2022-06-25 02:45:38.487891
# Unit test for function present
def test_present():

    from ansible.module_utils.basic import env_fallback
    from ansible.module_utils.six import PY3

    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes, to_text

    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat import unittest
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import patch, MagicMock

    from ansible_collections.notmintest.not_a_real_collection.plugins.modules import lineinfile

    io = StringIO()
    if PY3:
        stdout = io
    else:
        stdout = io = to_text(io)



# Generated at 2022-06-25 02:45:45.961432
# Unit test for function write_changes
def test_write_changes():
    fileobj = open(r'lineinfile_test_case_0_write_changes.txt', 'r')
    outfile = open(r'lineinfile_test_case_0_write_changes.txt.out', 'w')

# Generated at 2022-06-25 02:45:53.288989
# Unit test for function absent
def test_absent():
    print('Absent test')
    print('Check if file is absent')
    module = AnsibleModule(argument_spec=dict(dest=dict(type='str', required=True),
                                              backup=dict(type='bool', default=False),
                                              regexp=dict(type='str', default=None),
                                              search_string=dict(type='str', default=None),
                                              line=dict(type='str', required=True)))
    dest = os.path.join('/tmp', 'test_absent', 'test_absent_file.txt')
    if os.path.exists(dest):
        os.unlink(dest)

    regexp = ''
    search_string = ''
    line = ''
    absent(module, dest, regexp, search_string, line, True)

   

# Generated at 2022-06-25 02:46:20.912807
# Unit test for function main
def test_main():
    ansible_module = AnsibleModule(argument_spec={})
    ansible_module.main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:46:21.801366
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:46:22.819330
# Unit test for function present
def test_present():
    assert present() == None


# Generated at 2022-06-25 02:46:26.762972
# Unit test for function absent
def test_absent():
    dest = '/etc/resolv.conf'
    module = AnsibleModule({'backup': False, 'dest': dest, 'regexp': ""}, check_invalid_arguments=False, no_log=True)
    line = 'search vsphere.local'
    regexp = None
    search_string = None
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-25 02:46:32.363058
# Unit test for function present
def test_present():
    # Test case from case 0:
    var_0 = {}
    var_0['line'] = "{{ ansible_managed }}"
    var_0['regexp'] = "^#.* ansible managed"
    dest = "/etc/foo"
    var_0['dest'] = dest
    var_0['backup'] = "yes"
    var_0['insertafter'] = "EOF"

    # Test case from case 1:
    var_1 = {}
    var_1['line'] = "{{ ansible_managed }}"
    var_1['regexp'] = "^#.* ansible managed"
    dest = "/etc/foo"
    var_1['dest'] = dest
    var_1['backup'] = "yes"
    var_1['insertafter'] = ""

    # Test case from case

# Generated at 2022-06-25 02:46:32.889114
# Unit test for function write_changes
def test_write_changes():
    var_0 = main()


# Generated at 2022-06-25 02:46:33.231170
# Unit test for function write_changes
def test_write_changes():
    pass


# Generated at 2022-06-25 02:46:33.706746
# Unit test for function write_changes
def test_write_changes():
    test_case_0()


# Generated at 2022-06-25 02:46:45.762200
# Unit test for function present
def test_present():
    # Testing code in function present
    # Creating a temp file using module.tmpdir and writing data to it.
    # Initializing the line value.
    # Defining the destination path.
    # Defining the regexp value.
    # Defining the line value.
    # Defining the insertafter value.
    # Defining the insertbefore value.
    # Defining the search_string value.
    # Defining the firstmatch value.
    # Creating an AnsibleModule object with the module arguments.
    # Calling the present function with all the arguments and check the result.


    # Initializing the line value.
    line = ""

    # Defining the destination path.
    dest = "${ANSIBLE_LOCALATION}/lineinfile/testfile.txt"

    # Defining the regexp value.
    regexp = None

    #

# Generated at 2022-06-25 02:46:53.783194
# Unit test for function absent
def test_absent():
    var_5 = 0
    var_7 = 0
    var_8 = 0
    var_9 = 0
    var_6 = 0
    var_1 = 0
    var_2 = 0
    var_3 = 0
    var_10 = 0
    var_4 = 0
    var_11 = 0
    var_0 = 0
    absent(var_0, var_1, var_2, var_3, var_4, var_5)
    absent(var_6, var_7, var_8, var_9, var_10, var_11)


# Generated at 2022-06-25 02:47:46.302092
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            backup=dict(default=False, type='bool'),
            dest=dict(required=True, type='path'),
            line=dict(default=None),
            regexp=dict(default=None),
            search_string=dict(default=None),
            state=dict(default='present', choices=['absent', 'present']),
        ),
        supports_check_mode=True
    )
    dest = "/etc/sysctl.conf"
    regexp = "#vm\.swappiness"
    search_string = None
    line = "#vm.swappiness = 30"
    backup = False
    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-25 02:47:56.781688
# Unit test for function check_file_attrs

# Generated at 2022-06-25 02:48:06.586089
# Unit test for function main

# Generated at 2022-06-25 02:48:15.179017
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True),
            regexp = dict(type='str'),
            state = dict(type='str', choices=['absent', 'present'], default='present'),
            line = dict(type='str'),
            backrefs = dict(type='bool', default=False),
            insertafter = dict(type='str'),
            insertbefore = dict(type='str'),
            create = dict(type='bool', default=False),
            backup = dict(type='bool', default=False),
            firstmatch = dict(type='bool', default=False),
            others = dict(type='str'),
        )
    )

    # Define the module params
    path = dict(type='path', required=True)
    regexp = dict

# Generated at 2022-06-25 02:48:25.900723
# Unit test for function present
def test_present():
    # We are adding the following block, because we will modify sys.stdin
    from io import StringIO
    import sys
    old_stdin = sys.stdin
    sys.stdin = mystdin = StringIO('foo')
    # We are adding the following block, because we will modify sys.stdout
    from io import StringIO
    import sys
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()
    # We are adding the following block, because we will modify sys.stderr
    from io import StringIO
    import sys
    old_stderr = sys.stderr
    sys.stderr = mystderr = StringIO()
    # We are adding the following block, because we will modify module.exit_json

# Generated at 2022-06-25 02:48:37.352242
# Unit test for function write_changes
def test_write_changes():
    class_2 = AnsibleModule
    var_1 = class_2
    class_3 = to_bytes
    var_2 = class_3
    class_4 = to_text
    var_3 = class_4
    class_5 = to_native
    var_4 = class_5
    class_6 = to_bytes
    var_5 = class_6
    class_7 = os.path
    class_8 = class_7.realpath
    class_9 = to_bytes
    var_6 = class_9
    class_10 = to_native
    var_7 = class_10
    class_11 = to_bytes
    var_8 = class_11
    class_12 = to_native
    var_9 = class_12
    var_10 = None

# Generated at 2022-06-25 02:48:46.495079
# Unit test for function write_changes
def test_write_changes():

    import sys
    import ansible.module_utils.ansible_lineinfile_module
    module = ansible.module_utils.ansible_lineinfile_module.Actions()

    test_input = {"path": "test_input", "b_lines": "test_input",
                  "dest": "test_input"}

    # test for valid input
    module.atomic_move = Mockansible_lineinfile_module.mock_atomic_move
    assert test_case_0() == module.atomic_move(test_input["path"], test_input["b_lines"], test_input["dest"], unsafe_writes=False)

    # test for invalid input
    test_input = {"path": "test_input", "b_lines": "test_input",
                  "dest": "test_input"}

    # test exception


# Generated at 2022-06-25 02:48:50.660141
# Unit test for function present
def test_present():
    # Test case 0
    print("Test case 0")
    test_case_0()

test_present()

# Generated at 2022-06-25 02:48:57.260596
# Unit test for function present
def test_present():
    dest = tempfile.gettempdir() + '/test.txt'
    regexp = None
    search_string = None
    line = "this is the line to insert"
    insertafter = "BOF"
    insertbefore = None
    create = True
    backup = False
    backrefs = True
    firstmatch = False
    # You can use present() for testing purpose by providing all the required arguments
    present(AnsibleModule(argument_spec=dict()), dest, regexp, search_string, line, insertafter, insertbefore, create, backup, backrefs, firstmatch)

# Boilerplate
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:49:02.785536
# Unit test for function present
def test_present():
    # Parameter tests
    var_0 = present('arg_0', 'arg_1', 'arg_2', 'arg_3', 'arg_4', 'arg_5', 'arg_6', 'arg_7', 'arg_8', 'arg_9', 'arg_10')
    assert var_0 == 'module.exit_json'


# Generated at 2022-06-25 02:50:43.591940
# Unit test for function absent
def test_absent():
    # remove the file if it exists
    line = 'the answer is 42'
    dest = '/tmp/fake'

# Generated at 2022-06-25 02:50:47.652217
# Unit test for function present
def test_present():
    # Test function signature
    var_0 = main()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 02:50:53.778629
# Unit test for function main
def test_main():
    path = None
    state = 'present'
    regexp = None
    search_string = None
    line = 'line2'
    insertafter = 'EOF'
    insertbefore = None
    backrefs = False
    create = False
    backup = False
    firstmatch = False
    validate = None

# Generated at 2022-06-25 02:50:54.830670
# Unit test for function write_changes
def test_write_changes():
    var_0 = main()


# Generated at 2022-06-25 02:51:00.547951
# Unit test for function write_changes
def test_write_changes():
    var_0 = AnsibleModule()
    var_1 = to_bytes("ab\ncd\nef\n", errors='surrogate_or_strict')
    var_2 = os.path.join("/tmp", "test")
    var_0.params = {"validate": None, "unsafe_writes": False, "module_name": "ansible.builtin.lineinfile", "module_kwargs": {}}
    var_0.run_command = lambda x: (0, "", "")
    var_0.atomic_move = lambda x, y, z: True
    var_0.tmpdir = tempfile.gettempdir()
    write_changes(var_0, var_1, var_2)


# Generated at 2022-06-25 02:51:09.552422
# Unit test for function check_file_attrs

# Generated at 2022-06-25 02:51:11.368990
# Unit test for function check_file_attrs
def test_check_file_attrs():
    print("Running test for function: check_file_attrs")
    module = AnsibleModule("lineinfile")
    check_file_attrs(module, False, 'Test message', True)


# Generated at 2022-06-25 02:51:12.965793
# Unit test for function present
def test_present():

    var_1 = present(test_case_0)



# Generated at 2022-06-25 02:51:14.697511
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({
    })
    b_lines = ''
    dest = ''
    try:
        write_changes(module, b_lines, dest)
    except:
        assert False


# Generated at 2022-06-25 02:51:17.642557
# Unit test for function write_changes
def test_write_changes():
    args = dict()
    args['module'] = AnsibleModule()
    args['b_lines'] = 'test'
    args['dest'] = 'test'
    result = write_changes(**args)
    assert result is None
