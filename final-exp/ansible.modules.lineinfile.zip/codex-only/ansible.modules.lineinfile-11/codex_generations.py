

# Generated at 2022-06-23 03:48:00.428019
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule({
        'unsafe_writes': ['yes']},
        check_invalid_arguments=False)
    test_module.atomic_move = lambda src, dst: True

    assert check_file_attrs(test_module, False, "msg", "diff") == (
        "msg and ownership, perms or SE linux context changed", True)



# Generated at 2022-06-23 03:48:06.591454
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 03:48:13.842841
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    class Dummy():
        def __init__(self):
            self.tmpdir = 'tmp'
    module.params = {'validate': '/bin/true', 'unsafe_writes': True}
    module.run_command = Dummy()
    b_lines = [to_bytes("foo"), to_bytes("bar"), to_bytes("\nbaz")]
    dest = '/tmp/test_dest'
    write_changes(module, b_lines, dest)
    with open(dest, "r") as f:
        result = f.read()
    assert result == "foobar\nbaz"



# Generated at 2022-06-23 03:48:15.500498
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert 1 == 1



# Generated at 2022-06-23 03:48:26.935061
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool'),
            backup=dict(type='bool'),
            backrefs=dict(type='bool'),
            firstmatch=dict(type='bool'),
        ),
        supports_check_mode=True,
    )
    msg = "insertbefore passed but insertafter already found in line"

# Generated at 2022-06-23 03:48:38.946545
# Unit test for function write_changes
def test_write_changes():
    dest = tempfile.mkdtemp(prefix='ansible-test-lineinfile-')
    os.chmod(dest, 0o700)
    tmpfile = os.path.join(dest, 'testfile')
    with open(tmpfile, 'w') as f:
        f.write('line1\n')
        f.write('line2\n')
        f.write('line3\n')
        f.write('line4\n')

    params = {
        'path': tmpfile,
        'insertbefore': '^line3',
        'line': 'line_a\n',
        'create': False,
        'unsafe_writes': True,
    }

    # Creating the module object

# Generated at 2022-06-23 03:48:53.386445
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = MockModule()
    module.params = {
        'path': '/etc/hosts',
        'owner': 'root',
        'group': 'wheel',
        'mode': 'u+w',
        'follow': 'yes',
        'unsafe_writes': 'yes',
    }
    module.set_fs_attributes_if_different = Mock(return_value=False)
    changed, message, diff = check_file_attrs(module, True, "test message", "diff")
    assert not changed
    assert message == "test message"
    assert diff == "diff"
    module.set_fs_attributes_if_different = Mock(return_value=True)
    changed, message, diff = check_file_attrs(module, True, "test message", "diff")
    assert changed
   

# Generated at 2022-06-23 03:49:04.100988
# Unit test for function main

# Generated at 2022-06-23 03:49:17.901591
# Unit test for function main
def test_main():
    argv = ['--path', 'file', '--backup', 'false', '--create', 'false', '--state', 'present', '--backrefs', 'false', '--insertafter', 'EOF', '--line', 'line', '--regexp', 'regexp', '--firstmatch', 'false', '--insertbefore', 'insertbefore', '--backup', 'true', '--validate', 'none']

# Generated at 2022-06-23 03:49:20.699868
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = AnsibleModule({})
    changed, msg, diff = check_file_attrs(module, False, "msg", "diff")
    assert changed and msg and diff



# Generated at 2022-06-23 03:49:24.500107
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # assert test_check_file_attrs("test_check_file_attrs") == ""
    print("Implement me !")



# Generated at 2022-06-23 03:49:28.991740
# Unit test for function write_changes
def test_write_changes():
    
    results = write_changes(module, b_lines, dest)

    assert(result['changed'] == True)
    assert(result['msg'] == 'Changed')



# Generated at 2022-06-23 03:49:29.986666
# Unit test for function write_changes
def test_write_changes():
    write_changes()


# Generated at 2022-06-23 03:49:42.320396
# Unit test for function present
def test_present():
    from ansible.module_utils import tmpdir
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule

    content = """# Test file
foo=bar
bar=baz
pytest=true
"""

    filename = u'test.cfg'
    search = u'bar=baz'
    regexp = u'^(foo=bar)$'
    line = u'foo=baz'
    create = True
    insertbefore = None
    insertafter = None
    backup = u'yes'
    backrefs = False
    firstmatch = False


# Generated at 2022-06-23 03:49:54.627039
# Unit test for function main
def test_main():
    from ansible.modules.files.lineinfile import main
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os


    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.check_mode = False

    def fake_exit_json(self, **kwargs):
        self.exit_json_kwargs = kwargs

    def fake_fail_json(self, **kwargs):
        self.fail_json_kwargs = kwargs


# Generated at 2022-06-23 03:50:02.019295
# Unit test for function absent
def test_absent():
    assert absent(module, dest, regexp, search_string, line, backup)== {'found': True, 'msg': '1 line(s) removed', 'backup': '', 'changed': True, 'diff': {'before_header': 'dest (content)', 'after': '', 'after_header': 'dest (content)', 'before': 'b\'v4.4.0-1-c8b8\\n\'', 'before_header': 'dest (file attributes)'}}

# Generated at 2022-06-23 03:50:13.611858
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            dest = dict(type='str'),
            regexp = dict(type='str'),
            search_string = dict(type='str'),
            line = dict(type='str'),
            insertafter = dict(type='str'),
            insertbefore = dict(type='str'),
            create = dict(type='bool'),
            backup = dict(type='bool'),
            backrefs = dict(type='bool'),
            firstmatch = dict(type='bool'),
        ),
        supports_check_mode = True,
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    insertafter = module.params['insertafter']


# Generated at 2022-06-23 03:50:22.162163
# Unit test for function present
def test_present():
    ''' Test present function'''
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(default='dest', type='str'),
            regexp=dict(default=None, type='str'),
            search_string=dict(default=None, type='str'),
            line=dict(default='line', type='str'),
            insertafter=dict(default='BOF', type='str'),
            insertbefore=dict(default='BOF', type='str'),
            create=dict(default=False, type='bool'),
            backup=dict(default='no', type='bool'),
            backrefs=dict(default=False, type='bool'),
            firstmatch=dict(default=False, type='bool'),
        ),
        supports_check_mode=True
    )

# Generated at 2022-06-23 03:50:32.201067
# Unit test for function write_changes
def test_write_changes():
    module.atomic_move = lambda src, dest, unsafe_writes: module._backup(dest)

    content = ''.join(module.params['lines'])
    with open(module.params['dest'], 'w') as f:
        f.writelines(to_text(content, errors='surrogate_or_strict'))

    write_changes(module, to_bytes(content, errors='surrogate_or_strict'), module.params['dest'])

    with open(module.params['dest']) as f:
        new_content = f.read()

    assert to_text(new_content, errors='surrogate_or_strict') == content
    assert content == ''


# Generated at 2022-06-23 03:50:43.527268
# Unit test for function main
def test_main():
    import re
    import tempfile
    import os
    import shutil
    import sys

    # Save the original values
    orig_backrefs = backrefs
    orig_regexp = regexp
    orig_search_string = search_string
    orig_line = line
    orig_create = create
    orig_backup = backup
    orig_firstmatch = firstmatch

    backupfile = None
    linefile = None

# Generated at 2022-06-23 03:50:45.937186
# Unit test for function absent
def test_absent():
    assert absent("foo.txt", "test")
# backrefs test, line present

# Generated at 2022-06-23 03:50:55.143619
# Unit test for function main

# Generated at 2022-06-23 03:51:05.161186
# Unit test for function present
def test_present():


    class MockArgs:
        def __init__(self, **kwargs):
            for name, value in kwargs.items():
                setattr(self, name, value)

    test_args = dict(
        path='/tmp/config',
        regexp=None,
        search_string='jboss.server.base.dir',
        line='jboss.server.base.dir=/opt/jboss-as',
        insertafter=None,
        insertbefore=None,
        create=True
    )
    args = MockArgs(**test_args)
    b_dest = to_bytes(args.path, errors='surrogate_or_strict')
    dest = args.path
    regexp = args.regexp
    search_string = args.search_string
    line = args.line
    insert

# Generated at 2022-06-23 03:51:05.712284
# Unit test for function write_changes
def test_write_changes():
    write_changes("","", "")


# Generated at 2022-06-23 03:51:16.598598
# Unit test for function main

# Generated at 2022-06-23 03:51:25.988654
# Unit test for function absent
def test_absent():
    '''Test function absent'''
    tmpdir = tempfile.mkdtemp()
    tmp = os.path.join(tmpdir, 'tmpfile')
    with open(tmp, 'w') as f:
        f.write('Hello World\n')

    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={'dest': {'type': 'str'},
                       'line': {'type': 'str'},
                       'regexp': {'type': 'str'},
                       'search_string': {'type': 'str'},
                       'backup': {'type': 'bool', 'default': False},
                       })
    module.exit_json = lambda **kwargs: None

# Generated at 2022-06-23 03:51:37.712845
# Unit test for function write_changes
def test_write_changes():
    """
    This function just unit test function write_changes()
    """
    dest = "/tmp/test-ansible-lineinfile-test_write_changes.txt"
    module = AnsibleModule(argument_spec={})
    module.params['unsafe_writes'] = True
    try:
        os.unlink(dest)
    except OSError:
        pass

    s = "asdasdasd\n"
    write_changes(module, [to_bytes(s)], dest)
    fs = open(dest, 'r')
    assert fs.read() == s
    fs.close()
    os.unlink(dest)


# Generated at 2022-06-23 03:51:46.702218
# Unit test for function absent
def test_absent():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(dest=dict(type='str'),
                           regexp=dict(type='str', default=r'^\s*#\s*ansible'),
                           line=dict(type='str'),
                           backup=dict(type='bool', default=False)),
        supports_check_mode=True)
    dest = '/tmp/file'
    regexp = r'^\s*#\s*ansible'
    line = '# ansible'
    backup = True
    absent(module, dest, regexp, None, line, backup)


# Generated at 2022-06-23 03:51:58.191888
# Unit test for function present

# Generated at 2022-06-23 03:51:58.726501
# Unit test for function write_changes
def test_write_changes():
    assert True


# Generated at 2022-06-23 03:52:02.597289
# Unit test for function write_changes
def test_write_changes():

    class ModuleMock(object):
        def __init__(self):
            self.atomic_move = lambda path, dest, unsafe_writes: True
            self.run_command = lambda cmd, tmpfile: (0, 'OK', '')
            self.tmpdir = ''
            self.fail_json = lambda msg: False
    module = ModuleMock()

    result = write_changes(module, None, None)
    assert(result == True)


# Generated at 2022-06-23 03:52:13.294019
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True),
            regexp=dict(required=False),
            search_string=dict(required=False),
            line=dict(required=True),
            backup=dict(required=False, default=False, type='bool'),
        ),
        supports_check_mode=True,
    )

    mock_path = Mock()
    mock_path.exists.return_value = True
    module.open = MagicMock(return_value = MockFlie(read=Mock()))


# Generated at 2022-06-23 03:52:17.320529
# Unit test for function write_changes
def test_write_changes():
    assert write_changes()



# Generated at 2022-06-23 03:52:19.331048
# Unit test for function main
def test_main():
    try:
        os.rename(path, path)
        assert True
    except:
        assert False

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 03:52:28.578789
# Unit test for function absent
def test_absent():
    """
    If some lines matching regexp, ensure they're all removed from file.
    Ensure the remaining content is unchanged.
    """
    # If some lines matching regexp, ensure they're all removed from file.
    # Ensure the remaining content is unchanged.
    module = AnsibleModule(argument_spec = dict(
        dest = dict(type='path', required=True),
        regexp = dict(default=None),
        search_string = dict(default=None),
        line = dict(default=None),
    ))
    dest = '/tmp/ansible_file_module_test_file_1'
    regexp = '^Line 2$'
    line = 'Line 2'
    with open(dest, 'w') as f:
        f.write('Line 1\nLine 2\nLine 3\n')

# Generated at 2022-06-23 03:52:35.450101
# Unit test for function check_file_attrs
def test_check_file_attrs():
    data = dict(owner='root', group='root', mode='0644')
    module = AnsibleModule(argument_spec={'path': dict(type='path', required=True), 'owner': dict(default=data['owner']), 'group': dict(default=data['group']), 'mode': dict(default=data['mode'])})
    module.atomic_move = lambda *args: None
    changed, message, diff = False, '', 'diff'
    message, changed = check_file_attrs(module, changed, message, diff)
    assert changed == True
    assert message == "ownership, perms or SE linux context changed"


# Generated at 2022-06-23 03:52:40.530736
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-23 03:52:46.406329
# Unit test for function absent
def test_absent():
    # If a regexp is specified, the line is only removed if it is fully matched by regexp.
    # If a search_string is specified, the line is only removed if it contains the search string.
    # If neither search_string nor regexp are specified, the line is removed if all of it matches.
    # Use of regexp and search_string are mutually exclusive.
    # If both are specified, the search_string is ignored.
    pass


# Generated at 2022-06-23 03:53:00.083537
# Unit test for function main

# Generated at 2022-06-23 03:53:07.906575
# Unit test for function write_changes
def test_write_changes():
    """Return the path of a temporary file containing the given text"""
    lines = []
    tmpfile_path = write_changes('/tmp', lines)
    assert os.path.isfile(tmpfile_path)
    with open(tmpfile_path) as tmpfile:
        assert tmpfile.readlines() == lines  # pylint: disable=no-member
    os.remove(tmpfile_path)


# utility function to read a file while handling unicode errors
# see the following for more information:
#   http://stackoverflow.com/questions/13101653/python-mutliline-regular-expression-matching-across-binary-chunk-boundaries/13113700#13113700

# Generated at 2022-06-23 03:53:20.978562
# Unit test for function main
def test_main():
    test_data = {
    'path' : '/etc/ansible/roles/test/tasks/main.yml',
    'line' : 'file_header: filename',
    'backup' : 'yes'
    }

# Generated at 2022-06-23 03:53:21.569183
# Unit test for function write_changes
def test_write_changes():
    pass


# Generated at 2022-06-23 03:53:35.134110
# Unit test for function main
def test_main():

    def test_result(*args, **kwargs):
        if 'msg' not in kwargs:
            kwargs['msg'] = ''
        if 'changed' not in kwargs:
            kwargs['changed'] = False

        return kwargs

    # Test case 1: Path exists, line is not present, create=False, line="test".
    # Result: failed
    def mock_exit_json1(*args, **kwargs):
        assert kwargs == test_result(msg="file not present", changed=False)

    # Test case 2: Path exists, line is not present, create=True, line="test".
    # Result: succeed

    def mock_exit_json2(*args, **kwargs):
        if kwargs is not test_result(msg='line added', changed=True):
            assert kw

# Generated at 2022-06-23 03:53:43.805915
# Unit test for function main

# Generated at 2022-06-23 03:53:50.977718
# Unit test for function absent
def test_absent():
    b_dest = mkdtemp()
    module = AnsibleModule(
        argument_spec = dict(
            dest = dict(type='str', required=True),
            regexp = dict(type='str', required=False),
            search_string = dict(type='str', required=False),
            line = dict(type='str', required=False),
            backup = dict(type='bool', default=False)
        )
    )
    b_lines = [b'line1', b'line2']
    with open(b_dest, 'wb') as f:
        f.write(b''.join(b_lines))
    absent(module, b_dest, "^line1", None, 'line1\n', False)
    with open(b_dest, 'rb') as f:
        assert f.read() == b

# Generated at 2022-06-23 03:54:03.733459
# Unit test for function absent
def test_absent():
    module = AnsibleModule({'dest': '/tmp/test_file',
                            'line': 'Text to be removed',
                            'backup': False,
                            'search_string': None,
                            'regexp': None,
                            'PATH': '/bin:/usr/bin'},
                           check_invalid_arguments=False)

    # Create test file
    open('/tmp/test_file', 'w').write('Text to be removed\n')
    open('/tmp/test_file', 'a').write('Random text\n')
    open('/tmp/test_file', 'a').write('Text to be removed\n')

    absent(module, '/tmp/test_file', None, None, 'Text to be removed', False)


# Generated at 2022-06-23 03:54:05.335155
# Unit test for function write_changes
def test_write_changes():
    #TODO: Write unit test
    pass


# Generated at 2022-06-23 03:54:06.220111
# Unit test for function present
def test_present():
    assert 'line added' in present


# Generated at 2022-06-23 03:54:18.046359
# Unit test for function absent
def test_absent():
    b_lines = [b'foo', b'bar', b'baz']
    assert absent_matcher(b_lines, b'foo') == ([b'bar', b'baz'], 1)
    assert absent_matcher(b_lines, b'bar') == ([b'foo', b'baz'], 1)
    assert absent_matcher(b_lines, b'baz') == ([b'foo', b'bar'], 1)
    assert absent_matcher(b_lines, b'qux') == ([b'foo', b'bar', b'baz'], 0)

    b_lines = [b'foo', b'bar', b'baz']
    bre_c = re.compile(b'ba\w')
    assert absent_matcher(b_lines, None, bre_c)

# Generated at 2022-06-23 03:54:22.525393
# Unit test for function check_file_attrs
def test_check_file_attrs():
    changed = False
    message = ''
    module = AnsibleModule(argument_spec={'path': {'type': 'path'}})
    file_args = module.load_file_common_arguments(module.params)
    if module.set_fs_attributes_if_different(file_args, False, diff=None):
        changed = True
        message += "ownership, perms or SE linux context changed"
    return message, changed


# Generated at 2022-06-23 03:54:34.634665
# Unit test for function present
def test_present():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.local import NodeData
    mg = MutableMapping()


# Generated at 2022-06-23 03:54:42.016816
# Unit test for function absent
def test_absent():
    assert absent(module, "/tmp/ansible_test", None, None, "something\n", True) == {
        'changed': False,
        'found': 0,
        'diff': {
            'after': '',
            'after_header': '/tmp/ansible_test (content)',
            'before': '',
            'before_header': '/tmp/ansible_test (content)'
        },
        'backup': '',
        'msg': ''
    }

# Generated at 2022-06-23 03:54:54.809404
# Unit test for function present
def test_present():
    dest = "/etc/hosts"
    # dest = "hosts"
    regexp = None
    search_string = None
    line = "127.0.01 myhost"
    insertafter = None
    insertbefore = None
    create = False
    backup = False
    backrefs = False
    firstmatch = False

# Generated at 2022-06-23 03:55:09.032285
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'state': {'type': 'str'}, 'line': {'type': 'str'}})
    setattr(module, "check_mode", False)
    module._diff = True
    module.tmpdir = os.path.dirname(__file__)
    changed = True
    diff = {"after": "",
            "before": "",
            "before_header": "",
            "after_header": ""}
    module.params['path'] = os.path.join(module.tmpdir, "test_check_file_attrs")
    message = "some message"
    open(module.params['path'], 'a').close()

    return_val = check_file_attrs(module, changed, message, diff)


# Generated at 2022-06-23 03:55:19.045484
# Unit test for function present
def test_present():
    module = AnsibleModule({
        "dest": "/tmp/test",
        "line": "test",
        "firstmatch": True,
    }, check_invalid_arguments=False)
    with open("/tmp/test", "w+") as f:
        f.writelines(["1\n", "2\n", "3\n"])
    present(module, "/tmp/test", None, None, "test", "insertafter", "insertbefore", True, False, False, True)
    assert_lines("/tmp/test", ["1\n", "2\n", "3\n", "test\n"])


# Generated at 2022-06-23 03:55:20.606195
# Unit test for function main
def test_main():
    pass



if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:55:31.137110
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.facts.system.selinux import get_selinux_context
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path'),
            selinux_ignore_defaults=dict(type='bool', default=False),
            selinux_special_fs=dict(type='list', default=['fuse', 'nfs', 'vboxsf', 'ramfs', '9p'])
        ),
        supports_check_mode=True,
    )
    module.params['path'] = os.path.dirname(os.path.realpath(__file__))
    module.params['owner'] = "root"
    module.params['group'] = "root"

# Generated at 2022-06-23 03:55:32.024032
# Unit test for function write_changes
def test_write_changes():
    write_changes('test')


# Generated at 2022-06-23 03:55:44.061485
# Unit test for function absent
def test_absent():
    """ absent
    Test the absent function.
    """
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(aliases=['pattern'], type='str'),
            search_string=dict(type='str'),
            line=dict(required=True, type='str'),
            backup=dict(type='bool', default=False),
        ),
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)

    module.exit_json(changed=True)


# Generated at 2022-06-23 03:55:50.428730
# Unit test for function present
def test_present():
    dest = './testfile'
    regexp = '^(.*)Xms(\d+)m(.*)$'
    search_string = 'Xms512m'
    line = '\1Xms512m\3'
    insertafter = '^(.*)Xms512m(.*)$'
    insertbefore = '^(.*)Xms(\d+)m(.*)$'
    create = True
    backup = False
    backrefs = True
    firstmatch = False

    present(dest, regexp, search_string, line, insertafter, insertbefore, create, backup, backrefs, firstmatch)



# Generated at 2022-06-23 03:56:03.523030
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec=dict(destfile=dict(type='str', aliases=['path', 'name', 'dest'], required=True), owner=dict(type='str'), group=dict(type='str'), mode=dict(type='str'), seuser=dict(type='str'), serole=dict(type='str'), setype=dict(type='str'), selevel=dict(type='str')), required_one_of=[['owner', 'group', 'mode', 'seuser', 'serole', 'setype', 'selevel']])
    changed = False
    message = "change somethings"
    diff = None
    res_message, res_changed = check_file_attrs(module, changed, message, diff)
    assert res_changed == True

# Generated at 2022-06-23 03:56:17.625917
# Unit test for function write_changes
def test_write_changes():
    import ansible.module_utils.basic
    import ansible_collections.ansible.builtin.plugins.module_utils.basic

    import sys
    import os
    import mock
    import tempfile

    fake_module = mock.MagicMock(
        tmpdir=tempfile.gettempdir(),
        params=dict(
            unsafe_writes=False
        )
    )
    fake_module.fail_json = mock.MagicMock()
    fake_module.atomic_move = mock.MagicMock()

# Generated at 2022-06-23 03:56:22.194354
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    assert check_file_attrs(module, False, "", []) == ("ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, True, "", []) == (" and ownership, perms or SE linux context changed", True)



# Generated at 2022-06-23 03:56:35.098588
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path'),
            regexp=dict(type='str', default=None),
            search_string=dict(type='str', default=None),
            line=dict(type='str', default=None),
            insertafter=dict(type='str', default=None),
            insertbefore=dict(type='str', default=None),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-23 03:56:47.018004
# Unit test for function check_file_attrs
def test_check_file_attrs():
    lines = ['%s\n' % '\n']

# Generated at 2022-06-23 03:57:00.898899
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping

    def run_command(*args, **kwargs):
        return (0, '', '')

    module = basic.AnsibleModule(
        argument_spec = dict(
            validate = dict(),
            dest = dict(type='path'),
            unsafe_writes = dict(type='bool', default=False),
        ),
        supports_check_mode = True,
    )
    module.run_command = run_command

    dest = to_bytes('/etc/test_file')
    with open(dest, 'wb') as f:
        f.write(to_bytes('# existing content\n'))

    module.params = dict

# Generated at 2022-06-23 03:57:09.790268
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'path': './test-lineinfile.txt',
        'insertafter': 'insertafter=',
        'insertbefore': 'insertbefore=',
        'create': False,
        'backup': False,
        'line': 'line=',
        'state': 'present',
        'firstmatch': False,
        'unsafe_writes': True,
        'backrefs': False
    })

    dest = './test-lineinfile.txt'
    regexp = None
    search_string = None
    insertafter = 'insertafter='
    insertbefore = 'insertbefore='
    create = False
    backup = False
    line = 'line='
    backrefs = False
    firstmatch = False


# Generated at 2022-06-23 03:57:22.357758
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves import cStringIO as StringIO
    import os
    import tempfile
    import ansible.module_utils.basic as basic
    import ansible.module_utils.common._collections_compat as collections

    dest = tempfile.mkstemp()[1]
    module = basic.AnsibleModule(
        argument_spec=dict(
            unsafe_writes=dict(default='no'),
        )
    )
    module.fail_json = lambda **args: module.exit_json(**args) if args.get('changed', False) else module.exit_json()
    module.atomic_move = lambda a, b, **args: os.rename(a, b)
    module.tmpdir = tempfile

# Generated at 2022-06-23 03:57:25.686700
# Unit test for function absent
def test_absent():
    pass

# Generated at 2022-06-23 03:57:27.897510
# Unit test for function present
def test_present():
    assert present(module, dest, regexp, search_string, line, insertafter, insertbefore, create,
            backup, backrefs, firstmatch)


# Generated at 2022-06-23 03:57:40.835588
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True, type='str'),
            content=dict(required=True, type='str'),
            validate=dict(type='str'),
            validate_command=dict(type='str', aliases=['validate_cmd'], default=None)
        )
    )
    b_lines = to_bytes(module.params['content'])
    dest = to_bytes(module.params['dest'])
    write_changes(module, b_lines, dest)

# Used to match all valid python variable names for backreferences
# Not perfect, but it should be better than what we had before.

# Generated at 2022-06-23 03:57:55.439287
# Unit test for function check_file_attrs
def test_check_file_attrs():
    ''' simple unit test for function check_file_attrs '''

    class FakeModule(object):

        def __init__(self):
            self.params = {}
            self.exit_args = {
                'changed': False,
                'msg': '',
                'diff': {}
            }
            self.called_module = None

        def fail_json(self, **args):
            self.exit_args.update(**args)
            self.called_module = 'fail_json'

        def exit_json(self, **args):
            self.exit_args.update(**args)
            self.called_module = 'exit_json'

        def load_file_common_arguments(self, params):
            return params
