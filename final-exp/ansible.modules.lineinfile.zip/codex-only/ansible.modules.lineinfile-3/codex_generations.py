

# Generated at 2022-06-23 03:47:56.944506
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert True



# Generated at 2022-06-23 03:48:04.361288
# Unit test for function main
def test_main():
    import tempfile

    content = """\
line 1

line 2
line 3
line 4
line 5

line 6
line 7

line 8

line 9
line 10
"""


# Generated at 2022-06-23 03:48:06.041960
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs() == undefined


# Generated at 2022-06-23 03:48:15.174633
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(),
            owner=dict(),
            group=dict(),
            mode=dict(),
            seuser=dict(),
            serole=dict(),
            setype=dict(),
            selevel=dict(),
        )
    )
    changed = dict(changed=True)
    message = dict(msg="")
    diff = dict(before="", after="")
    check_file_attrs(module, changed, message, diff)
    assert changed['changed'] == True



# Generated at 2022-06-23 03:48:25.175090
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            state=dict(default='present', choices=['absent', 'present'], type='str'),
            path=dict(required=True, aliases=['dest', 'name'], type='path'),
            regexp=dict(required=False, type='str'),
            search_string=dict(required=False, type='str'),
            line=dict(required=True, type='str'),
        ),
        supports_check_mode=True
    )
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    dest = module.params['path']
    backup = module.params['backup']
    absent(module, dest, regexp, search_string, line, backup)

# Generated at 2022-06-23 03:48:29.535012
# Unit test for function main
def test_main():
    test_module = get_module_mock()
    result = main()
    assert result == {
        'changed': True,
        'msg': 'file not present',
        'backup': ''
    }

# Generated at 2022-06-23 03:48:34.184911
# Unit test for function main
def test_main():
    print("Testing main()")
    import tempfile
    import os
    import shutil
    import stat
    import json

    class ModuleResults(object):
        def __init__(self):
            self.rc = 0
            self.changed = False
            self.msg = ""
            self.warnings = []
            self.data = []

        def exit_json(self, **kwargs):
            self.rc = kwargs.pop('rc', 0)
            self.changed = kwargs.pop('changed', False)
            self.msg = kwargs.pop('msg', "")
            self.warnings = kwargs.pop('warnings', [])
            self.data = kwargs


# Generated at 2022-06-23 03:48:38.491790
# Unit test for function absent
def test_absent():
    assert absent(None, 'test_dest', '0', None, 'test_line', True) == [False, 'file not present']
    assert absent(None, 'test_dest', '0', None, 'test_line', False) == [False, 'file not present']


# Generated at 2022-06-23 03:48:42.729113
# Unit test for function main
def test_main():
    TEST_SUBSET = {
        'normal': {
            'args': dict(
                state='present',
                line='192.168.1.196',
                path='/tmp/test.txt'
            ),
            'fail': False,
            'msg': 'line added',
            'changed': True
        }
    }
    test_cases = load_fixture('ansible_module_lineinfile', TEST_SUBSET)
    for test_name, test_case in test_cases.items():
        print('\nTEST CASE: {}'.format(test_name))
        test_module = AnsibleModule(**test_case['args'])
        if test_case['fail']:
            with pytest.raises(AnsibleFailJson):
                main()
        else:
            main()


# Generated at 2022-06-23 03:48:43.898005
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert True


# Generated at 2022-06-23 03:48:57.185495
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = Mock()
    module.params = {'owner': 'root', 'group': 'wheel', 'mode': '0640', 'seuser': 'system_u', 'serole': 'object_r',
                     'setype': 'httpd_config_t'}
    module.file_common_argument_spec = {'owner': dict(type='str'), 'group': dict(type='str'), 'mode': dict(type='str'),
                                        'seuser': dict(type='str'), 'serole': dict(type='str'), 'setype': dict(type='str'),
                                        'selevel': dict(type='str', choices=['s0', 's1', 's2', 's3', 's4', 's5', 's6', 's7', 's8'])}
    module.set_fs_att

# Generated at 2022-06-23 03:48:59.476758
# Unit test for function check_file_attrs
def test_check_file_attrs():
    items = {}
    assert (check_file_attrs(items) == ("", False))


# Generated at 2022-06-23 03:49:11.411066
# Unit test for function main
def test_main():
    """
    Unit test for main()
    """

    # Setup
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 03:49:23.446145
# Unit test for function main

# Generated at 2022-06-23 03:49:35.755249
# Unit test for function write_changes
def test_write_changes():

    class MockModule(object):
        params = {
            'backup': None,
            'validate': None,
            'unsafe_writes': None
        }
        tmpdir = None
        atomic_move = None
        _debug = False

        def fail_json(self, msg):
            raise Exception(msg)

        def run_command(self, cmd):
            return


# Generated at 2022-06-23 03:49:44.522969
# Unit test for function absent
def test_absent():
    """ basic functional test for absent """

    # XXX: Temporary workaround to prevent update-motd << 11.10.*
    #      from complaining about missing python
    import __builtin__
    setattr(__builtin__, '__file__', '')

    class AttrDict(dict):
        def __init__(self, *args, **kwargs):
            super(AttrDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    module = AttrDict()
    module.params = AttrDict()
    module.params['line'] = 'This should not be present'
    module.params['path'] = 'test_file'
    module.params['state'] = 'absent'
    module.params['backup'] = False
    module.params['regexp']

# Generated at 2022-06-23 03:49:47.932854
# Unit test for function absent
def test_absent():
    assert absent("/etc/ansible/facts.d", "^\[.*\]$", "", "", "", True)
    assert absent("/etc/ansible/facts.d", "", "^\[.*\]$", "", "", True)
    assert absent("/etc/ansible/facts.d", "", "", "^\[.*\]$", "", True)
    print("test_absent : PASS")



# Generated at 2022-06-23 03:49:49.097547
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleFailJson):
        main()


# Generated at 2022-06-23 03:49:49.628622
# Unit test for function present
def test_present():
    pass



# Generated at 2022-06-23 03:50:02.118107
# Unit test for function present
def test_present():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os

    module = basic.AnsibleModule(
        argument_spec = dict(
            dest = dict(type='str'),
            line = dict(type='str'),
            insertafter = dict(type='str'),
            insertbefore = dict(type='str'),
            create = dict(type='bool', default=False),
            backup = dict(type='bool', default=False),
            backrefs = dict(type='bool', default=False),
            firstmatch = dict(type='bool', default=False),
            regexp = dict(type='str'),
            search_string = dict(type='str'),
        ),
    )

    dest = 'data/lineinfile_present.txt'

# Generated at 2022-06-23 03:50:02.724251
# Unit test for function absent
def test_absent():
    pass



# Generated at 2022-06-23 03:50:14.089126
# Unit test for function present
def test_present():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os

    module = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
        )
    )


# Generated at 2022-06-23 03:50:20.060780
# Unit test for function write_changes
def test_write_changes():
    ''' ensure write_changes in ansible.builtin.lineinfile '''

    b_lines = [to_bytes('sample text\n', errors='strict'), to_bytes('sample text 2\n', errors='strict')]
    dest = '/path/to/test'
    module = AnsibleModule(argument_spec={})
    module.tmpdir = '/tmp'
    module.atomic_move = lambda tmpfile, destfile: True
    write_changes(module, b_lines, dest)


# Generated at 2022-06-23 03:50:31.849789
# Unit test for function main

# Generated at 2022-06-23 03:50:32.429603
# Unit test for function absent
def test_absent():
    pass



# Generated at 2022-06-23 03:50:32.994734
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-23 03:50:40.498599
# Unit test for function main
def test_main():
    b_expected_file_contents = to_bytes(
        '''Test line 1
Test line 2
Test line 3
Test line 4
Test line 6
Test line 4
Test line 6
Test line 5
Test line 7
Test line 5
''')

    b_expected_file_contents_invalid_regex = to_bytes(
        '''Test line 1
Test line 2
Test line 3
Test line 4
Test line 6
Test line 4
Test line 6
Test line 5
Test line 5
''')

    b_expected_file_contents_regex = to_bytes(
        '''Test line 1
Test line 2
Test line 3
Test line 4
Test line 6
Test line 4
Test line 6
Test line 5
Test line 7
Test line 5*/
''')

    b_expected_file_contents_

# Generated at 2022-06-23 03:50:57.531253
# Unit test for function absent
def test_absent():
    lines = []
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='str'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool')
        ),
        supports_check_mode=True
    )

    # Case 1: line exists and is removed.
    module.params['line'] = 'Test line 1'
    lines = ['Test line 1\n', 'Test line 2\n', 'Test line 3\n']
    absent(module, '/path', None, None, 'Test line 1', True)
    assert lines == ['Test line 2\n', 'Test line 3\n']

    # Case 2: line does not exist.

# Generated at 2022-06-23 03:51:06.305922
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertbefore=dict(type='str'),
            insertafter=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=True),
            firstmatch=dict(type='bool', default=True),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
    )

    dest = '/home/test/test.txt'

# Generated at 2022-06-23 03:51:16.800830
# Unit test for function main
def test_main():
    path = '/etc/test.txt'
    regexp = 'my_regexp'
    search_string = 'my string'
    line = 'my_line'
    ins_aft = 'EOF'
    ins_bef = 'BOF'
    create = False
    backup = False
    backrefs = False
    firstmatch = False

    class MockArgs(object):
        pass

    class MockModule(object):
        def __init__(self):
            self.params = MockArgs()
            self.params.path = path
            self.params.regexp = regexp
            self.params.search_string = search_string
            self.params.line = line
            self.params.insertafter = ins_aft
            self.params.insertbefore = ins_bef
            self.params.create = create

# Generated at 2022-06-23 03:51:29.445173
# Unit test for function write_changes
def test_write_changes():
    # Use atomic move for this test
    shutil.rmtree('/tmp/.ansible/tmp/', ignore_errors=True)
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            content=dict(type='str'),
            backup=dict(type='bool', default=False),
            unsafe_writes=dict(type='bool', default=False),
            validate=dict(type='str'),
            ),
        )
    module.tmpdir = '/tmp/.ansible/tmp/'
    module.atomic_move = shutil.move
    b_lines = to_bytes('foo\n')
    dest = os.path.realpath(to_bytes('/tmp/.ansible/tmp/testfile', errors='surrogate_or_strict'))

# Generated at 2022-06-23 03:51:39.899027
# Unit test for function present

# Generated at 2022-06-23 03:51:52.506699
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.common._collections_compat import Sequence

    module = ANSIBLE_MODULE_DEF
    b_content = "test".encode("utf-8")
    b_lines = Sequence([b_content])

    dest = os.path.join(tempfile.mkdtemp(),"test_file")

    # test if the validation fails
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.read() == b_content

    # test if the validation passes
    module.params["validate"] = "/bin/true"
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        assert f.read() == b_content

    # test if the validation passes and the temporary file

# Generated at 2022-06-23 03:52:05.817235
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str', required=False),
            search_string=dict(type='str', required=False),
            line=dict(type='str', required=True),
            backup=dict(type='bool', required=False, default=False)
        ),
        add_file_common_args=True,
        supports_check_mode=True
    )
    dest = os.getcwd() + "/test_splice_lines"
    backup = True
    with open(dest, 'w') as f:
        f.write("testing\n123\nabc\nfoo\n456\nbar\n")
    with open(dest, 'r') as f:
        lines_before

# Generated at 2022-06-23 03:52:17.536616
# Unit test for function write_changes
def test_write_changes():
    # We'll need an ansible module to test with
    class AnsibleMod():
        def __init__(self):
            self.run_command = lambda x,**y: (0, '', '')
            self.atomic_move = lambda x,y: None
            self.fail_json = lambda **x: None
            self.tmpdir = ''
            self.params = {}

    am = AnsibleMod()
    # Write some text to a temporary file
    tmpfd, tmpfile = tempfile.mkstemp()
    with os.fdopen(tmpfd, 'wb') as f:
        f.write("hello")

    # Now call the function we want to test with the tempfile we just made
    write_changes(am, ["hello"], tmpfile)
    # Check that the file exists

# Generated at 2022-06-23 03:52:30.846559
# Unit test for function main

# Generated at 2022-06-23 03:52:35.464438
# Unit test for function absent
def test_absent():
    '''
    Test absent function
    '''
    import ansible.utils.template as template
    import ansible.module_utils.basic as basic
    module = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            state=dict(type='str', default='present', choices=['absent', 'present']),
            regexp=dict(type='str', aliases=['pattern']),
            search_string=dict(type='str'),
            line=dict(type='str', aliases=['value']),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    template.template = lambda x, y, z: x

# Generated at 2022-06-23 03:52:39.412494
# Unit test for function absent
def test_absent():
    module.exit_json(changed=False, msg="file not present")

# Generated at 2022-06-23 03:52:51.615181
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.file import _set_mode_if_different
    from ansible.module_utils.common.file import _set_owner_if_different
    from ansible.module_utils.common.file import _set_group_if_different
    from ansible.module_utils.common.file import _set_context_if_different
    from ansible.module_utils.common.file import _set_secontext_if_different

# Generated at 2022-06-23 03:52:56.662344
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict()
    )
    changed = True
    message = "test message"
    diff = {"before": "", "after": ""}
    message, changed = check_file_attrs(module, changed, message, diff)


# Generated at 2022-06-23 03:53:06.413864
# Unit test for function check_file_attrs
def test_check_file_attrs():
    def change_chmod():
        return True
    lines = '''
    # This is a comment
    www   80/tcp    httpd
    # port for http by default
    '''
    lines_changed = '''
    # This is a comment
    www   80/tcp    httpd
    # port for http by default
    '''
    mock_module = type('', (object,), {'set_fs_attributes_if_different': change_chmod,
                                       'load_file_common_arguments': lambda self, x: x})

# Generated at 2022-06-23 03:53:19.067508
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 03:53:21.706978
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(['foo', 'bar']) == ['foobar', True]



# Generated at 2022-06-23 03:53:35.281912
# Unit test for function present
def test_present():

    import shutil
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes

    dest = tempfile.mkdtemp()

    segment = 'foo'
    line = 'bar'
    regexp = '^foo'
    insertafter = None
    insertbefore = None
    create = False
    backup = False
    backrefs = False
    firstmatch = False

    # 1: Test that the segment is not added if the file does not exist
    open(dest + '/file', 'w').close()

# Generated at 2022-06-23 03:53:48.449376
# Unit test for function present

# Generated at 2022-06-23 03:53:59.150187
# Unit test for function write_changes
def test_write_changes():
    import shutil
    this_file, this_dir = os.path.split(__file__)
    test_dir = os.path.join(this_dir, 'lineinfile_test')
    if os.path.exists(test_dir):
        shutil.rmtree(test_dir)
    os.makedirs(test_dir)
    test_file = os.path.join(test_dir, 'test_file')
    dest_file = os.path.join(test_dir, 'dest_file')
    def test_lines(lines):
        if isinstance(lines, list):
            lines = [to_bytes(line + '\n', errors='surrogate_or_strict') for line in lines]

# Generated at 2022-06-23 03:54:10.629798
# Unit test for function present
def test_present():
    import os
    import tempfile
    tmpdir = tempfile.mkdtemp()
    dest = os.path.join(tmpdir, "test_present")
    open(dest, 'w').close()

    test_line = 'new line'
    test_line_present = 'line already present'

    def get_module(**kwargs):
        params = dict(
            dest=dest,
            regexp='',
            search_string=None,
            line=test_line,
            insertbefore=None,
            insertafter=None,
            create=False,
            backup=False,
            backrefs=True,
            firstmatch=False
        )
        params.update(kwargs)

# Generated at 2022-06-23 03:54:18.400937
# Unit test for function absent
def test_absent():
    test_params = {
        'dest': '/tmp/dummy',  # noqa: FS003
        'regexp': None,
        'line': 'dummy line',
        'backup': False,
        'search_string': None
    }

    mock_module = MagicMock(
        exit_json=MagicMock(return_value=None),
        check_mode=True,
        _diff=True
    )

    with patch("os.path.exists") as mock_exists:
        mock_exists.return_value = True

# Generated at 2022-06-23 03:54:22.331554
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(None, False, "MESSAGE", "DIFF") == ("MESSAGE and ownership, perms or SE linux context changed", True)



# Generated at 2022-06-23 03:54:28.145307
# Unit test for function absent
def test_absent():
    import sys
    _module = sys.modules[__name__]
    module = AnsibleModule(_module.argument_spec, supports_check_mode=True)
    module.exit_json = lambda x: x
    assert absent(module, '/foo', '', '', '', '', None)

# end of absent unit test



# Generated at 2022-06-23 03:54:39.112777
# Unit test for function write_changes
def test_write_changes():
    from ansible_collections.ansible.builtin.plugins.module_utils import basic
    from ansible_collections.ansible.builtin.plugins.module_utils._text import to_bytes
    from ansible_collections.ansible.builtin.plugins.module_utils.common.sys_info import get_platform_subclass
    PLATFORM = get_platform_subclass()

    lines = [b"foo\n", b"bar\n", b"baz\n"]

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    platform_params = PLATFORM.get_platform_subclass_args()
    module.params = platform_params
    module.params['_ansible_check_mode'] = True

# Generated at 2022-06-23 03:54:53.322777
# Unit test for function absent
def test_absent():
    failed_cnt = 0
    module = AnsibleModule({
        'dest': '/tmp/test_file.txt',
        'regexp': None,
        'backup': False,
        'line': '',
        'insert_before': None,
        'insert_after': None,
        'create': False,
        'search_string': None,
        'backrefs': False,
        'firstmatch': False,
    })
    b_dest = to_bytes('/tmp/test_file.txt', errors='surrogate_or_strict')

    # test file does not exist
    if os.path.exists(b_dest):
        failed_cnt += 1
        module.fail_json(msg='File exist when not expected!')


# Generated at 2022-06-23 03:55:05.931314
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            owner = dict(),
            group = dict(),
            mode = dict(),
            seuser = dict(),
            serole = dict(),
            selevel = dict(),
            setype = dict(),
            unsafe_writes = dict(default=False, type='bool'),
        ),
        supports_check_mode=True
    )

    # Create test file
    f = tempfile.NamedTemporaryFile(delete=False)
    f.write(b"""\
line1
line2
line3
""")
    f.close()

    # Setup module args

# Generated at 2022-06-23 03:55:15.432692
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    # The file doesn't exist:
    # with 'create=yes' -> add the line to the file
    # with 'create=no' -> the module fails

# Generated at 2022-06-23 03:55:25.992229
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(dict())
    # First test: no change
    (message, changed) = check_file_attrs(module, False, "", "")
    assert not changed
    assert "" == message
    # Second test: one change
    (message, changed) = check_file_attrs(module, False, "", "diff")
    assert changed
    assert "ownership, perms or SE linux context changed" == message
    # Third test: two changes
    (message, changed) = check_file_attrs(module, True, "Old message", "diff")
    assert changed
    assert "Old message and ownership, perms or SE linux context changed" == message

# Unit tests for function write_changes

# Generated at 2022-06-23 03:55:35.306459
# Unit test for function main
def test_main():
  from ansible.module_utils.basic import AnsibleModule
  from ansible.module_utils.basic import load_platform_subclass

# Generated at 2022-06-23 03:55:41.090637
# Unit test for function absent
def test_absent():
    MOD = AnsibleModule({'dest': '/tmp/testfile', 'regexp': '^test'}, check_invalid_arguments=False)
    assert absent(MOD, '/tmp/testfile', "^test", None, "test", False) is None
test_absent()


# Generated at 2022-06-23 03:55:50.494697
# Unit test for function absent
def test_absent():
    assert absent('/var/lib/foo.txt',None,'^$',None,'foo','bar') == (True, 2, '2 line(s) removed', '/var/lib/foo.txt.2018-02-21@17:18:33~', {'before_header': '/var/lib/foo.txt (file attributes)', 'after_header': '/var/lib/foo.txt (file attributes)'}, {'before': 'foo\nfoo\n', 'after': '', 'before_header': '/var/lib/foo.txt (content)', 'after_header': '/var/lib/foo.txt (content)'})

# Generated at 2022-06-23 03:55:56.316770
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True, type='str'),
            regexp=dict(required=False, type='str'),
            search_string=dict(required=False, type='str'),
            line=dict(required=True, type='str'),
            insertafter=dict(required=False, type='str'),
            insertbefore=dict(required=False, type='str'),
            create=dict(required=False, type='bool', default=False),
            backup=dict(required=False, type='bool', default=False),
            backrefs=dict(required=False, type='bool', default=False),
            firstmatch=dict(required=False, type='bool', default=False))
    )

    dest = '/tmp/test'

# Generated at 2022-06-23 03:56:07.300424
# Unit test for function present

# Generated at 2022-06-23 03:56:11.299832
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert check_file_attrs(module, False, "", "") == ("ownership, perms or SE linux context changed", True)



# Generated at 2022-06-23 03:56:20.183593
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    setattr(module, 'set_fs_attributes_if_different', lambda x, y, z: True)
    assert check_file_attrs(module, True, "Test message", "Test diff") == ("Test message and ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, False, "Test message", "Test diff") == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-23 03:56:32.053235
# Unit test for function write_changes
def test_write_changes():
    module = _load_fixture('write_changes')
    b_lines = [
        b'---\n',
        b'- hosts: localhost\n',
        b'  roles:\n',
        b'    - { role: sample }\n',
        b'...\n',
        b'\n',
    ]
    dest = None
    with tempfile.NamedTemporaryFile() as tmp:
        os.write(tmp.fileno(), b''.join(b_lines))
        tmp.flush()
        dest = tmp.name
    assert dest
    module.params['path'] = dest
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        data = f.read()
    assert data == b''.join(b_lines)



# Generated at 2022-06-23 03:56:33.282033
# Unit test for function write_changes
def test_write_changes():
    assert False

# Generated at 2022-06-23 03:56:41.998946
# Unit test for function check_file_attrs
def test_check_file_attrs():
    ''' Unit Test for function check_file_attrs'''
    module = AnsibleModule(argument_spec={})
    message = 'test message'
    changed = True
    diff = 'test diff'

    expected = ("test message and ownership, perms or SE linux context changed", True)
    actual = check_file_attrs(module, changed, message, diff)

    assert expected == actual


# Generated at 2022-06-23 03:56:42.604240
# Unit test for function present
def test_present():
    pass



# Generated at 2022-06-23 03:56:46.774803
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    b_lines = to_bytes("", errors='surrogate_or_strict')
    dest = "/tmp/testfile"
    write_changes(module, b_lines, dest)
    with open(dest, "r") as f:
        content = f.read()
    assert content == ""



# Generated at 2022-06-23 03:56:52.261629
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'tmpdir': './'})
    # If no exception is raised, the unit test passes
    # The output is not verified because this is a stub
    write_changes(module, [b'foo\n'], '/tmp/test')


# Generated at 2022-06-23 03:57:05.176790
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.basic

    my_args = dict(
        state='present',
        regexp=None,
        search_string='Hello',
        line='Hello World',
        insertafter=None,
        insertbefore=None,
        backrefs=False,
        create=False,
        backup=False,
    )

    # As part of the unit test test_main() we want to be able to see the output,
    # which is inside a closure, so we use the following 'hack' to expose them.
    import inspect
    def get_closure_vars(f):
        return inspect.getclosurevars(f).nonlocals


# Generated at 2022-06-23 03:57:11.011762
# Unit test for function check_file_attrs
def test_check_file_attrs():
    file_args = module.load_file_common_arguments(module.params)
    if module.set_fs_attributes_if_different(file_args, False, diff=diff):
        message += "ownership, perms or SE linux context changed"

    return message, changed



# Generated at 2022-06-23 03:57:11.681842
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert True



# Generated at 2022-06-23 03:57:23.924312
# Unit test for function present
def test_present():
    module = AnsibleModule({
        "path": "/tmp/unit_tests/test_present",
        "state": "present",
        "line": "test_present_line",
        "create": "yes",
        "check_mode": True
    })
    result = present(module, module.params['path'], regexp=None, search_string=None, line=module.params['line'], insertafter=None, insertbefore=None,
                                                        create=module.params['create'], backup=False, backrefs=None, firstmatch=False)
    assert(result['changed'] is True)
    assert(result['backup'] == '')


# Generated at 2022-06-23 03:57:24.283091
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:57:25.052963
# Unit test for function absent
def test_absent():
    assert absent(module, dest, regexp, search_string, line, backup) == 'changed'


# Generated at 2022-06-23 03:57:35.800645
# Unit test for function absent
def test_absent():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        module = AnsibleModule(
            dict(
                backup=False,
                dest='/tmp/test.txt',
                line='test',
                search_string=None,
                regexp=None
            ),
            supports_check_mode=True
        )
        with mock.patch('os.path.exists', return_value=True):
            with mock.patch('os.path.isfile', return_value=True):
                absent(
                    module=module,
                    dest=module.params['dest'],
                    backup=module.params['backup'],
                    line=module.params['line'],
                    regexp=module.params['regexp'],
                    search_string=module.params['search_string']
                )

# Generated at 2022-06-23 03:57:42.465768
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='str'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool')
        ),
        supports_check_mode=True
    )
    absent(module, 'some_path', 'some_regexp', 'some_search_string', 'some_line', False)


# Generated at 2022-06-23 03:57:57.085954
# Unit test for function main