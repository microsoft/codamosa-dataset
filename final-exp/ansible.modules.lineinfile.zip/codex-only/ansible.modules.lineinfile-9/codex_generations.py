

# Generated at 2022-06-23 03:48:00.806298
# Unit test for function absent
def test_absent():
    module = AnsibleModule(argument_spec=dict(backup=dict(type='bool', default=True), dest=dict(required=True,type='path'), regexp=dict(), search_string=dict(), line=dict(required=True),))
    module.absent(module, "/tmp/absent", "", "", "line", True)
    assert 1 == 1


# Generated at 2022-06-23 03:48:12.916060
# Unit test for function main
def test_main():
    import os
    import tempfile
    import pytest
    
    path = "/tmp/ansible_testfile_lineinfile_main"
    dir_name = os.path.dirname(path)
    if not os.path.exists(dir_name):
        os.makedirs(dir_name)
    with open(path, 'w') as f:
        f.write("Hello World!")
    with open(path, 'r') as f:
        f.read(13)
    
    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught
        by the test case"""
        pass
 
    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught
        by the test case"""
        pass


# Generated at 2022-06-23 03:48:24.245116
# Unit test for function absent
def test_absent():
    options = {
        "path": "/tmp/test",
        "backup": False,
        "state": "absent",
        "line": "Hello"
    }

# Generated at 2022-06-23 03:48:27.344932
# Unit test for function present
def test_present():
    assert present("test","test",None,None,"test",None,None,True,False,True,False) == "test"

# Unit test function to check second part of function present

# Generated at 2022-06-23 03:48:38.138923
# Unit test for function present
def test_present():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    class AnsibleModuleDummy(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.tmpdir = tempfile.gettempdir()
            self.run_command = basic.run_command
            self.exit_json = basic.exit_json
            self.fail_json = basic.fail_json
        def load_file_common_arguments(self, params):
            return params
        def set_fs_attributes_if_different(self, params, changed, diff):
            return False
        def atomic_move(self, tmpfile, dest, unsafe_writes):
            with open(tmpfile, 'rb') as f:
                b_lines = f.read

# Generated at 2022-06-23 03:48:45.892576
# Unit test for function check_file_attrs
def test_check_file_attrs():

    # action_common_attributes.files
    module_name = 'test_module.py'
    mod = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        add_file_common_args=True,
    )
    mod.noop_on_check(module_name)

    # Insert code under test here and assert state of mod.CHECK_MODE, mod.diff etc
    # Use mod.exit_json(**kwargs)
    # Use mod.fail_json(**kwargs)

    changed = True
    message = "ownership, perms or SE linux context changed"

    # Replace set_fs_attributes_if_different with mocked "changed" and "message"

# Generated at 2022-06-23 03:48:59.105277
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json = lambda x: x
    message = None
    changed = False
    diff = dict(before='', after='')
    file_args = dict(path='/foo', owner='root', group='root', mode='0644', seuser='seuser', serole='seuser', setype='seuser', selevel='s0')
    actual = check_file_attrs(module,
                              changed,
                              message,
                              diff,
                              file_args,
                              ImmutableDict(file_args, **{'unsafe_writes': True}))


# Generated at 2022-06-23 03:49:10.961903
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertbefore=dict(type='str'),
            insertafter=dict(type='str'),
            create=dict(type='bool', default='no'),
            backup=dict(type='bool', default='no'),
            backrefs=dict(type='bool', default='no'),
            validate=dict(type='str'),
            firstmatch=dict(type='bool', default='yes'),
            unsafe_writes=dict(type='bool', default=False),
        )
    )

# Generated at 2022-06-23 03:49:14.784683
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True)
        )
    )
    changed = False
    message = ""
    diff = {}
    module.atomic_move = lambda src, dest, unsafe_writes: dest
    module.set_fs_attributes_if_different = lambda file_args, changed, diff: True
    module.load_file_common_arguments = lambda params: params
    assert check_file_attrs(module, changed, message, diff) == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-23 03:49:20.741832
# Unit test for function check_file_attrs

# Generated at 2022-06-23 03:49:21.387283
# Unit test for function present
def test_present():
    pass


# Generated at 2022-06-23 03:49:21.955254
# Unit test for function present
def test_present():
    pass


# Generated at 2022-06-23 03:49:31.176046
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    content = "a test string"
    fd, path = tempfile.mkstemp(dir=module.tmpdir)
    with os.fdopen(fd, 'wb') as tmp_file:
        tmp_file.write(to_bytes(content))
    test_lines = to_bytes(content * 10)
    write_changes(module, test_lines, path)
    result_string = ""
    with open(path, 'rb') as f:
        result_string = f.read()
    assert result_string == test_lines
    os.remove(path)


# Generated at 2022-06-23 03:49:42.658056
# Unit test for function absent
def test_absent():
    # Create a file
    b_lines = []
    b_lines.append(b'1234567\n')
    b_lines.append(b'abcdefg\n')
    b_lines.append(b'ABCDEFG\n')
    b_lines.append(b'ABCDEFG\n')
    b_lines.append(b'ABCDEFG\n')
    b_dest = os.path.join(tempfile.gettempdir(), 'test_file')

    with open(b_dest, 'wb') as f:
        f.writelines(b_lines)

    # Delete the file created
    def remove_file(b_path):
        if os.path.exists(b_path):
            os.remove(b_path)

    # Test 1: Test delete a line by search_string


# Generated at 2022-06-23 03:49:44.947616
# Unit test for function write_changes
def test_write_changes():
    fake_module = AnsibleModule({}, {}, {}, {})
    write_changes(fake_module, 'test', '/tmp')



# Generated at 2022-06-23 03:49:55.217299
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict( 
        dest=dict(required=True),
        regexp=dict(required=True),
        search_string=dict(required=True),
        line=dict(required=True),
        insertafter=dict(required=True),
        insertbefore=dict(required=True),
        create=dict(required=True),
        backup=dict(required=True),
        backrefs=dict(required=True),
        firstmatch=dict(required=True)        
        )
    )
    
    dest='test'
    regexp='regstring'
    search_string='searchstring'
    line='line%s'
    insertafter='insertafter'
    insertbefore='insertbefore'
    create=True
    backup=True
    backrefs=True
   

# Generated at 2022-06-23 03:50:06.661957
# Unit test for function present
def test_present():
    module = AnsibleModule({
        '_ansible_check_mode': True,
        '_ansible_diff':  True,
        'backup': False,
        'create': False,
        'dest': 'name_file',
        'line': 'Hello!',
        'regexp': None,
        'search_string': None,
        'backrefs': False,
        'firstmatch': False,
        'insertafter': None,
        'insertbefore': None,
        'unsafe_writes': True,
    })

    present(module, dest='name_file', regexp=None, search_string=None, line='Hello!',
            insertafter=None, insertbefore=None, create=False, backup=False, backrefs=False,
            firstmatch=False)


# Generated at 2022-06-23 03:50:09.790329
# Unit test for function absent
def test_absent():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    res = absent(module, dest='', regexp=None, search_string=None, line='', backup=True)


# Generated at 2022-06-23 03:50:19.721882
# Unit test for function main

# Generated at 2022-06-23 03:50:28.753184
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'src':{}, 'dest':{}, 'tmpdir':{}, 'unsafe_writes':{}})
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    write_changes(module, 'x\ny\n', dest=tmpfile)
    assert os.path.exists(tmpfile)
    assert open(tmpfile).read() == 'x\ny\n'
    os.remove(tmpfile)


# Generated at 2022-06-23 03:50:30.054478
# Unit test for function write_changes
def test_write_changes():
    pass


# ===========================================
# Main control flow


# Generated at 2022-06-23 03:50:31.274716
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(module, changed, message, diff) == result



# Generated at 2022-06-23 03:50:32.326522
# Unit test for function absent
def test_absent():
    quit()

# Generated at 2022-06-23 03:50:40.017060
# Unit test for function write_changes
def test_write_changes():
    try:
        import __builtin__
        open_name = '__builtin__.open'
    except ImportError:
        open_name = 'builtins.open'

    m = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True),
            validate=dict(required=False),
        ),
        supports_check_mode=True,
    )
    m.tmpdir = '/tmp/test_lineinfile'
    os.makedirs(m.tmpdir)
    # Don't overwrite the dest file, as this would be destructive in real usage
    m.params['dest'] = os.path.join(m.tmpdir, 'test_lineinfile_dest')
    # Don't validate the file, as this would fail, since we are not providing a validator

# Generated at 2022-06-23 03:50:57.494554
# Unit test for function absent
def test_absent():
    dest = "/tmp/test_absent_file.txt"
    regexp = ""
    search_string = "hello world"
    line = "hello world"
    backup = False

    f = open(dest, "w")
    f.write("")
    f.close()
    b_dest = to_bytes(dest, errors='surrogate_or_strict')
    with open(b_dest, 'rb') as f:
        b_lines = f.readlines()
    f.close()

    # absent should return changed=False, found=0
    assert len(b_lines) == 0

    # absent should return changed=False, found=1
    f = open(dest, "a")
    f.write("hello world")
    f.close()

# Generated at 2022-06-23 03:50:59.575506
# Unit test for function absent
def test_absent():
    assert absent(1,'test', 1, 1, 0, 1) == None



# Generated at 2022-06-23 03:51:07.202229
# Unit test for function present
def test_present():
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    MOCK_INPUT = _create_file('/opt', 'testfile')

    def _mock_exists(path):
        return True

    def _mock_isfile(path):
        return True

    if PY3:
        module = type('module_helper', (), {'check_mode': False})()
    else:
        module = type('module_helper', (basic.AnsibleModule,), {'check_mode': False})()

    module.exists = _mock_exists
    module.isfile = _mock_isfile

# Generated at 2022-06-23 03:51:07.775430
# Unit test for function check_file_attrs
def test_check_file_attrs():
    pass #TODO


# Generated at 2022-06-23 03:51:12.732332
# Unit test for function write_changes
def test_write_changes():
    # prepare test file
    tmpfd, tmpfile = tempfile.mkstemp()
    with os.fdopen(tmpfd, 'wb') as f:
        f.writelines([to_bytes(u'aaa\n'), to_bytes(u'bbb\n'), to_bytes(u'ccc\n')])

    # update test file
    b_lines = [to_bytes(u'aaa\n'), to_bytes(u'bbb\n'), to_bytes(u'ccc\n'), to_bytes(u'ddd\n')]
    write_changes(tmpfile, b_lines)

    # check the test file
    with open(tmpfile, 'rb') as f:
        lines = f.readlines()

    assert lines == b_lines

    # clean up test file

# Generated at 2022-06-23 03:51:16.545461
# Unit test for function write_changes
def test_write_changes():
  print ("test_write_changes()")
  module = AnsibleModule(argument_spec = dict(
    dest = dict(type='str', required=True),
    b_lines = dict(type='str', required=True),
    validate = dict(),
    validate = dict(default=None)
  ))
  b_lines = to_bytes(module.params['b_lines'], errors='surrogate_or_strict')
  dest = to_text(module.params['dest'], errors='surrogate_or_strict')

  write_changes(module, b_lines, dest)


# Generated at 2022-06-23 03:51:17.034776
# Unit test for function present
def test_present():
    pass


# Generated at 2022-06-23 03:51:26.263259
# Unit test for function main
def test_main():
    import json
    import os
    import tempfile
    import shutil
    import platform

    def make_tempfile(data, path=None):
        _, filename = tempfile.mkstemp()
        if path:
            os.unlink(filename)
            filename = path
        fh = open(filename, 'wb')
        fh.write(to_bytes(data))
        fh.close()
        return filename

    def remove_tempfile(filename):
        os.remove(filename)

    def make_tempdir():
        return tempfile.mkdtemp()

    def remove_tempdir(path):
        shutil.rmtree(path)

    def get_platform():
        return platform.system().lower()


# Generated at 2022-06-23 03:51:30.910983
# Unit test for function write_changes
def test_write_changes():
    assert write_changes() == "this is a string"



# Generated at 2022-06-23 03:51:40.233860
# Unit test for function present
def test_present():
    # Mock the module.
    module = mock_module()

    search_string = str(module.params['search_string'])
    # Make sure that search_string is set to None, because the function
    # that's being tested is 'present'
    module.params['search_string'] = None
    params = module.params

    # Mock the write_changes method
    mock_write_changes = MagicMock()
    patch(target='ansible.module_utils.basic.AnsibleModule.atomic_move',
          new=mock_write_changes).start()

    # Prepare test_content with the following line:
    #
    #   I am the line that will be changed
    #
    # This can be verified by looking at the diff of the module output.

# Generated at 2022-06-23 03:51:52.873785
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import *
    import re
    import tempfile
    import os
    # Write the test file
    fd, temp_path = tempfile.mkstemp()
    with os.fdopen(fd, mode='w') as f:
        lines = ['# this is a comment', 'key=val', 'a=b', 'c=', '', 'd="a quote"', '"a quoted space"="quote space"']
        f.write('\n'.join(lines))
        f.flush()
        os.fsync(fd)
        f.close()
    def rm_temp():
        os.remove(temp_path)

    def test_return(expected_result, *args, **kwargs):
        # Statement to test
        main()
        # Evaluate the result

# Generated at 2022-06-23 03:52:05.873487
# Unit test for function main

# Generated at 2022-06-23 03:52:14.427675
# Unit test for function main
def test_main():
    print ("TESTING FUNCTION main")
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    if os.path.exists(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_file.txt')):
        os.unlink(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_file.txt'))
    shutil.copyfile(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'file_module.py'), os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_file.txt'))
    

# Generated at 2022-06-23 03:52:17.623396
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'dest': 'test.txt',
        'regexp': '^test',
        'line': 'test line',
        'insertbefore': 'test',
        'insertafter': 'test',
        'create': True,
        'backup': True,
        'backrefs': False,
        'firstmatch': True
    })
    present(module, 'test.txt', '^test', None, 'test line', 'test', 'test', True, True, False, True)


# Generated at 2022-06-23 03:52:21.058790
# Unit test for function absent
def test_absent():
    test_module = AnsibleModule({
        'backup': True,
        'content': "This is a test",
        'dest': "/path/to/somefile",
        'insertbefore': "EOF",
        'firstmatch': True,
    }, params={'state': 'absent'})

    class TestFileManager(object):
        def backup_local(self, path):
            return path + '.bak'
    test_module._backup_local = TestFileManager()

    test_module.exit_json = lambda **kwargs: kwargs
    absent(test_module, '/path/to/somefile', None, None, 'This is a test')

# Generated at 2022-06-23 03:52:33.215367
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Test for when file attributes are set
    class TestModule(object):
        def __init__(self, params):
            self.params = params
        def set_fs_attributes_if_different(self, file_args, changed, diff):
            return True

    params = {
        'path' : '/etc/selinux/config',
        'unsafe_writes': True,
        'group': 'root',
        'owner': 'root',
        'seuser': 'root',
        'serole': 'root',
        'setype': 'root',
        'selevel': 'root',
        'mode': '0644'
    }

    module = TestModule(params)
    changed = False
    message = ""
    diff = {}


# Generated at 2022-06-23 03:52:35.101569
# Unit test for function absent
def test_absent():
    assert absent(None, "/path/to/file", r"^line.*$", None, "line to remove", False) == True
    assert absent(None, "/path/to/file", r"^line.*$", None, "line to remove", True) == True



# Generated at 2022-06-23 03:52:47.520917
# Unit test for function check_file_attrs
def test_check_file_attrs():
    """
    mock ansible module and results of set_fs_attributes_if_different
    test for changed, message
    """
    from ansible.module_utils import basic

    test1 = dict(path='/etc/sudoers', mode='0600', owner='root', group='root', seuser='', serole='', setype='', selevel='')
    test2 = dict(path='/etc/sudoers', mode='0600', owner='root', group='root', seuser='', serole='', setype='etc_t', selevel='')


# Generated at 2022-06-23 03:53:01.217522
# Unit test for function present
def test_present():
    b_dest = to_bytes(dest, errors='surrogate_or_strict')
    if not os.path.exists(b_dest):
        if not create:
            module.fail_json(rc=257, msg='Destination %s does not exist !' % dest)
        b_destpath = os.path.dirname(b_dest)
        if b_destpath and not os.path.exists(b_destpath) and not module.check_mode:
            try:
                os.makedirs(b_destpath)
            except Exception as e:
                module.fail_json(msg='Error creating %s (%s)' % (to_text(b_destpath), to_text(e)))
        b_lines = []

# Generated at 2022-06-23 03:53:11.904439
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})

    class t():
        def __init__(self):
            self.params = {'unsafe_writes': False}
            self.set_fs_attributes_if_different = lambda x, y, diff: True
            self.load_file_common_arguments = lambda x: None

    module.set_fs_attributes_if_different = lambda x, y, diff: True
    module.load_file_common_arguments = lambda x: None

    module.run_command = lambda x: (0, '', '')
    changed = True
    message = "some message"
    message, changed = check_file_attrs(module, changed, message, {})
    assert changed
    assert message == "some message and ownership, perms or SE linux context changed"



# Generated at 2022-06-23 03:53:23.330124
# Unit test for function present
def test_present():

    args = dict(
        path='/etc/hosts',
        regexp='^#?(127.*localhost.*)',
        line='\g<1> awesome.example.org',
        insertafter=None,
        insertbefore=None,
        create=False,
        backup=False,
        backrefs=True,
        firstmatch=False,
    )


# Generated at 2022-06-23 03:53:34.171430
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({
        'unsafe_writes': True,
    })
    module.tmpdir = tempfile.mkdtemp(dir='/tmp')
    dest = os.path.join(module.tmpdir, 'testfile')
    data = "teststring"
    with open("%s" % dest, 'w') as f:
        f.write(data)

    write_changes(module, "newdata1\nnewdata2\n".encode("utf-8"), dest)

    with open("%s" % dest, 'r') as f:
        result = f.read()
    assert result == "newdata1\nnewdata2\n"



# Generated at 2022-06-23 03:53:43.249193
# Unit test for function main
def test_main():
    test_dir = tempfile.mkdtemp(dir=os.path.dirname(os.path.realpath(__file__)))
    path = os.path.join(test_dir, 'test_file')
    path2 = os.path.join(test_dir, 'test_file_2')

    with open(path, 'w') as f:
        f.write('test line')

    # test insertafter
    with open(path2, 'w') as f:
        f.write('test line')
    module = AnsibleModule({
        'path': path,
        'state': 'present',
        'line': "inserted line",
        'insertafter': "test line",
        'backup': False,
        'backrefs': False,
        'firstmatch': False,
    })
    main()

# Generated at 2022-06-23 03:53:50.777139
# Unit test for function present

# Generated at 2022-06-23 03:53:57.776215
# Unit test for function absent
def test_absent():
    func = load_params(absent)
    args = {'module': {'check_mode': False, '_diff': False}, 'line': '', 'backup': False,
            'dest': ''}
    func(args)


# Generated at 2022-06-23 03:54:10.496515
# Unit test for function absent
def test_absent():
    dest = '/tmp/ansible_temp'
    regexp = None
    search_string = None
    line = '# test insert'
    backup = False
    f = open(dest, "w")
    f.write('# test insert\n')
    f.close()
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(default='present', choices=['absent', 'present']),
            dest=dict(required=True, type='str'),
            line=dict(required=True, type='str'),
            backup=dict(default=False, type='bool'),
        ),
        supports_check_mode=True,
    )
    m_args = module.params
    absent(module, dest, regexp, search_string, line, backup)
    assert not os.path.exists

# Generated at 2022-06-23 03:54:19.057668
# Unit test for function check_file_attrs
def test_check_file_attrs():
    """
    Test function check_file_attrs
    """
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec={
            'owner': {'type': 'str'},
            'group': {'type': 'str'},
            'mode': {'type': 'str'},
            'attributes': {'type': 'dict'},
            'unsafe_writes': {'type': 'bool', 'default': True}
        },
        add_file_common_args=True
    )
    setattr(module, 'set_fs_attributes_if_different', lambda x: True)
    assert check_file_attrs(module, False, '', '') == ('ownership, perms or SE linux context changed', True)
    module = AnsibleModule

# Generated at 2022-06-23 03:54:25.209982
# Unit test for function write_changes
def test_write_changes():
    class Module():
        def __init__(self):
            self.params = {}
            self.tmpdir = tempfile.gettempdir()
            self.run_command = self.run_command_impl
            self.atomic_move = self.atomic_move_impl
            self.fail_json = self.fail_json_impl

        def run_command_impl(self, cmd):
            return (0, '', '')

        def fail_json_impl(self, msg):
            raise Exception(msg)

        def atomic_move_impl(self, tmpfile, dest):
            pass

    m = Module()

    m.params['validate'] = "/usr/sbin/visudo -cf %s"
    tmpfd, tmpfile = tempfile.mkstemp(dir=m.tmpdir)

# Generated at 2022-06-23 03:54:34.850990
# Unit test for function present
def test_present():
    module = AnsibleModule({'dest': 'test.conf', 'line': '*', 'create': True, 'backup': False})
    present(module, dest='test.conf', regexp=None, search_string=None, line='*', insertafter=None, insertbefore=None,
            create=True, backup=False, backrefs=False, firstmatch=False)
    present(module, dest='test.conf', regexp=None, search_string=None, line='*', insertafter=None, insertbefore=None,
            create=True, backup=False, backrefs=False, firstmatch=False)


# Generated at 2022-06-23 03:54:40.050005
# Unit test for function check_file_attrs
def test_check_file_attrs():

    ansible_module = MockAnsibleModule()
    ansible_module.params['path'] = '/tmp/test_path'
    ansible_module.params['mode'] = '0x755'
    ansible_module.params['owner'] = 'user1'
    ansible_module.params['group'] = 'group1'
    ansible_module.params['seuser'] = 'user_u'
    ansible_module.params['serole'] = 'role_r'
    ansible_module.params['setype'] = 'type_t'
    ansible_module.params['selevel'] = 's0'
    ansible_module.params['unsafe_writes'] = True
    ansible_module.params['backup'] = True
    changed = False
    message = ''

# Generated at 2022-06-23 03:54:48.577894
# Unit test for function write_changes
def test_write_changes():
    module=AnsibleModule(argument_spec={})
    dest = "testfile.txt"
    b_lines = [b"Test line\n"]
    write_changes(module, b_lines, dest)
    assert to_native(open(dest, "r").read()).strip() == "Test line"
    os.unlink(dest)



# Generated at 2022-06-23 03:54:57.284525
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes

    tf = tempfile.NamedTemporaryFile()
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    file_args = module.load_file_common_arguments(dict(
        path=to_bytes(tf.name),
        mode='0600'
    ))
    module.set_fs_attributes_if_different(file_args, False, diff=False)

    b_old_mode = os.stat(tf.name).st_mode
    b_new_mode = (b_old_mode & 0o7777) | 0o600

    assert b_new_mode == os.stat(tf.name).st_mode



# Generated at 2022-06-23 03:55:02.223310
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleFailJson):
        with pytest.raises(Exception):
            main()

# Generated at 2022-06-23 03:55:12.488950
# Unit test for function absent
def test_absent():
    test_args = AnsibleExitJson(changed=False, msg='file not present')
    with patch('ansible_collections.ansible.community.plugins.module_utils.basic.AnsibleModule.exit_json', side_effect=[test_args]):
        assert absent(module, 'test_dest', None,None,'test_line', None) == {'changed': False, 'msg': 'file not present'}
    test_args = AnsibleFailJson(msg='Error creating test_dirpath')

# Generated at 2022-06-23 03:55:26.267179
# Unit test for function present
def test_present():
    module = AnsibleModule({
        "path": "/tmp/file",
        "state": "present",
        'line': 'this is the line to add',
        "insertbefore": 'this is the line to match',
    })
    dest = module.params.get('path', None)
    regexp = module.params.get('regexp', None)
    search_string = module.params.get('search_string', None)
    line = module.params.get('line', None)
    insertafter = module.params.get('insertafter', None)
    insertbefore = module.params.get('insertbefore', None)
    create = module.params.get('create', None)
    backup = module.params.get('backup', None)
    backrefs = module.params.get('backrefs', None)
   

# Generated at 2022-06-23 03:55:26.960888
# Unit test for function absent
def test_absent():
    pass



# Generated at 2022-06-23 03:55:29.298960
# Unit test for function absent
def test_absent():
    assert absent(module, 'foo') == 'foo'
    assert absent(module, 'foo') == ''
    assert absent(module, 'bar') == 'bar'


# Generated at 2022-06-23 03:55:36.692293
# Unit test for function absent
def test_absent():
    test_dict = dict(dest='/tmp/file',
                     regexp=r'^\w+$',
                     search_string=None,
                     line='Foo',
                     backup=False
                     )
    module = MagicMock()
    module.exit_json.side_effects = SystemExit
    with patch('os.path.exists', return_value=True):
        with patch('io.open'):
            with patch('os.chmod'):
                with patch('ansible.module_utils.basic.AnsibleModule.backup_local'):
                    with pytest.raises(SystemExit) as exc:
                        absent(module, **test_dict)
                        assert exc.value.code == 0


# Generated at 2022-06-23 03:55:47.806814
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path'),
            regexp=dict(required=False),
            search_string=dict(required=False),
            line=dict(required=False),
            insertbefore=dict(required=False),
            insertafter=dict(required=False),
            create=dict(type='bool', default=False),
            replace=dict(choices=BOOLEANS, default='no'),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            tmpdir=dict(required=False),
            firstmatch=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    # Fail module with msg if no arguments are passed

# Generated at 2022-06-23 03:55:53.407032
# Unit test for function absent
def test_absent():
    dest = '/test/test.txt'
    regexp = 'test'
    line = 'test'

    module = DummyModule()
    f = io.open('/test/test.txt', 'w', encoding='utf-8')
    f.write(u'test')
    f.close()
    absent(module, dest, regexp, None, line, False)
    assert 'file not present' in module.exit_args['msg']



# Generated at 2022-06-23 03:56:06.382094
# Unit test for function main

# Generated at 2022-06-23 03:56:19.952362
# Unit test for function write_changes
def test_write_changes():
    test_module = AnsibleModule(argument_spec=dict(path=dict(type='str',required=True),
                                                   content=dict(type='list',required=True),
                                                   backup=dict(type='bool',required=False,default=False),
                                                   unsafe_writes=dict(type='bool',required=False,default=False),
                                                   validate=dict(type='str',required=False,default=None),
                                                   tmpdir=dict(type='str',required=False,default=None)))
    test_module.atomic_move = lambda src, dest, unsafe_writes: None
    test_module.atomic_move.__dict__['__name__'] = 'atomic_move'
    test_module.run_command = lambda cmd: [0,'','command passed']
    test_module.run

# Generated at 2022-06-23 03:56:25.455223
# Unit test for function main
def test_main():
    from ansible.modules.files.lineinfile import main

    module_args = dict(
        path='/test.txt',
        regexp='',
        insertbefore='BOF',
        create=False,
        validate='test'
    )

# Generated at 2022-06-23 03:56:31.475320
# Unit test for function absent
def test_absent():
    dest = "/tmp/deleteme.txt"
    regexp = None
    search_string = "testing"
    line = "testing"
    backup = True
    with open(dest, "w") as f:
        f.write("testing")

    absent(module, dest, regexp, search_string, line, backup)

    with open(dest, "r") as f:
        assert not f.read()

    module.exit_json(changed=False, found=0, msg='file not present', backup='', diff='')



# Generated at 2022-06-23 03:56:37.428426
# Unit test for function absent
def test_absent():
    module = AnsibleModule({
        'dest': 'destination',
        'line': 'line1',
        'regexp': None,
        'search_string': None,
        'backup': False,
    }, check_invalid_arguments=False)
    set_module_args(module, 'dest=destination line=line1')
    absent(module, 'destination', None, None, 'line1', False)



# Generated at 2022-06-23 03:56:49.732545
# Unit test for function absent
def test_absent():
    os.remove('/tmp/testfile.txt')
    module = AnsibleModule({'dest': '/tmp/testfile.txt', 'line': 'testline', 'state': 'absent', 'backup': False,
                            'search_string': None, 'regexp': None})
    absent(module, '/tmp/testfile.txt', None, None, 'testline', False)
    module = AnsibleModule({'dest': '/tmp/testfile.txt', 'line': None, 'state': 'absent', 'backup': False,
                            'search_string': 'testline', 'regexp': None})
    absent(module, '/tmp/testfile.txt', None, 'testline', None, False)

# Generated at 2022-06-23 03:57:02.607391
# Unit test for function main

# Generated at 2022-06-23 03:57:10.255340
# Unit test for function check_file_attrs
def test_check_file_attrs():

    result = dict(
        msg='',
        changed=False,
    )

    test_args = dict(
        path               = '/tmp/test.txt',
        owner='nobody',
        group='nobody',
        mode='0600',
        seuser='system_u',
        serole='object_r',
        selevel='s0',
        setype='var_t',
        unsafe_writes='True'

    )
    # Create mock module
    mock_module = AnsibleModule(
        argument_spec=test_args
    )

    check_file_attrs(mock_module, result['changed'], result['msg'], mock_module.params['path'])
    assert result['changed'] is False
    assert result['msg'] == ''


# Generated at 2022-06-23 03:57:11.560375
# Unit test for function absent
def test_absent():
    assert absent([]) == 'foo'


# Generated at 2022-06-23 03:57:23.771944
# Unit test for function absent
def test_absent():

    # creating a test file
    file_name = "test_file"
    test_file = open(file_name, "w+")
    test_file.write("test line \n")
    test_file.write("another line \n")
    test_file.write("test line 3\n")
    test_file.close()

    # creating AnsibleModule object
    data = {'check_mode': True, '_diff': True}
    am = AnsibleModule(data, check_invalid_arguments=False)

    # variables for input
    dest = file_name
    regexp = None
    search_string = None
    line = "test line"
    backup = False

    # calling the function
    # and checking the result

# Generated at 2022-06-23 03:57:34.584923
# Unit test for function absent

# Generated at 2022-06-23 03:57:45.538982
# Unit test for function main
def test_main():
    """Test module main."""
    # Testing with the following command line:
    #
    # python -m pytest test_main.py -vv
    #
    # ansible-mock can be installed with:
    #
    #   pip install ansible-mock
    #
    # or
    #
    #   pip install git+https://github.com/ansible/ansible-mock.git@devel
    #
    #
    # For example:
    #
    # ansible-mock -t lineinfile_module -m lineinfile test_main.py
    #

    # The following should fail because line=None
    with pytest.raises(SystemExit):
        main()

    # The following should fail because state=absent, but line=None

# Generated at 2022-06-23 03:57:53.240143
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(AnsibleModule({'_ansible_check_mode': True, '_ansible_diff': True, 'path': '/tmp/testfile', 'mode': '0755'}), True, "ownership, perms or SE linux context changed", True) == ("ownership, perms or SE linux context changed", True)

