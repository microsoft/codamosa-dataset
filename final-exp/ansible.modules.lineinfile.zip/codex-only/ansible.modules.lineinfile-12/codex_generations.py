

# Generated at 2022-06-23 03:48:02.272817
# Unit test for function write_changes
def test_write_changes():
    import pytest
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO

    test_lines = [
        "foo:\n",
        "  bar:\n",
    ]
    test_file = "/tmp/test_write_changes.yml"

    # NOTE: module will fail to load without this being set
    os.environ['ANSIBLE_MODULE_ARGS'] = '{}'
    module = AnsibleModule({
        'dest': test_file,
        'unsafe_writes': True,
    }, check_invalid_arguments=False)
    module.tmpdir = tempfile.gettempdir()
    module.params['backup'] = False

   

# Generated at 2022-06-23 03:48:10.386354
# Unit test for function main

# Generated at 2022-06-23 03:48:19.782797
# Unit test for function main
def test_main():
    # 1. find action
    line = 'test'
    create = False
    backup = False
    backrefs = False
    firstmatch = False

    ret = present(module, path, regexp, search_string, line,
                insertafter, insertbefore, create, backup, backrefs, firstmatch, errors='surrogate_or_strict')
    assert callable(ret)

    # 2. remove action
    backup = True
    ret = absent(module, path, regexp, search_string, line, backup)
    assert callable(ret)



# Generated at 2022-06-23 03:48:21.652423
# Unit test for function present
def test_present():
    assert False



# Generated at 2022-06-23 03:48:22.902585
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:48:23.455153
# Unit test for function main
def test_main():
    assert 1 == 1

main()

# Generated at 2022-06-23 03:48:34.197773
# Unit test for function write_changes

# Generated at 2022-06-23 03:48:43.939932
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec=dict())
    module.params = {'path': 'test', 'owner': 'test1', 'group': 'test2'}
    module.set_fs_attributes_if_different = Mock(return_value=True)
    mock_dict = Mock()
    mock_dict.update = Mock()
    assert check_file_attrs(module, True, 'test', mock_dict) == ('test and ownership, perms or SE linux context changed', True)
    module.set_fs_attributes_if_different = Mock(return_value=True)
    assert check_file_attrs(module, False, 'test', mock_dict) == ('ownership, perms or SE linux context changed', True)

# Generated at 2022-06-23 03:48:53.800065
# Unit test for function write_changes
def test_write_changes():
    import shutil
    import tempfile
    import os

    module_args = dict(dest='/tmp/config',
                       line='host=localhost')
    module = AnsibleModule(module_args)

    module.tmpdir = tempfile.mkdtemp()
    b_lines = to_bytes(module.params['line']) + b'\n'
    dest = module.params['dest']

    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as fd:
        b_data = fd.read()
    shutil.rmtree(module.tmpdir)
    os.remove(dest)
    return b_data



# Generated at 2022-06-23 03:49:03.902656
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'dest': {'type': 'str'}, 'owner': {'type': 'str'}, 'group': {'type': 'str'}, 'mode': {'type': 'str'}, 'seuser': {'type': 'str'}, 'serole': {'type': 'str'}, 'setype': {'type': 'str'}, 'selevel': {'type': 'str'}}, supports_check_mode=True)
    module.params['dest'] = 'dest'
    module.params['owner'] = 'owner'
    module.params['group'] = 'group'
    module.params['mode'] = 'mode'
    module.params['seuser'] = 'seuser'
    module.params['serole'] = 'serole'

# Generated at 2022-06-23 03:49:17.690986
# Unit test for function main
def test_main():

    class ModuleStub(object):
        def __init__(self):
            self.params = {
                'backup': False,
                'backrefs': False,
                'create': False,
                'dest': '',
                'firstmatch': False,
                'insertafter': None,
                'insertbefore': None,
                'line': None,
                'name': '',
                'path': '',
                'regex': None,
                'regexp': None,
                'search_string': None,
                'state': 'absent',
                'value': None
                }
            self.run_command = Mock()
            self.run_command.return_value = (0, 'success')
            self.load_file_common_arguments = Mock()
            self.backup_local = Mock()


# Generated at 2022-06-23 03:49:23.777889
# Unit test for function write_changes
def test_write_changes():
    # Create a dummy module and use it to write a file in /tmp
    module = AnsibleModule(argument_spec={})
    dest = os.path.join(module.tmpdir, 'foobar')
    lines = ['foo', 'bar']
    write_changes(module, lines, dest)
    with open(dest, 'rb') as f:
        assert f.readlines() == lines



# Generated at 2022-06-23 03:49:36.105631
# Unit test for function write_changes
def test_write_changes():

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            state=dict(type='str', default='present', choices=['absent', 'present']),
            line=dict(type='str', aliases=['value']),
            regexp=dict(type='str', aliases=['regex']),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            unsafe_writes=dict(type='bool', default=False, aliases=['unsafe-writes']),
        ),
    )

    # prepare working area that looks like a remote system
    tmp_dir = tempfile.mkdtemp()
    test_

# Generated at 2022-06-23 03:49:42.552031
# Unit test for function absent
def test_absent():
    b_lines = [b"one", b"two", b"three", b"four"]
    assert b_lines == [l for l in b_lines if matcher(l)]

    found = []

    b_line = b"four"
    matcher(b_line)
    assert found == [b"four"]

    b_lines = [l for l in b_lines if matcher(l)]
    len(found) == 1
    assert b_lines == [b"one", b"two", b"three"]





# Generated at 2022-06-23 03:49:43.018976
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-23 03:49:51.836284
# Unit test for function main
def test_main():
    import tempfile
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO

    if six.PY3:
        builtin_open = 'builtins.open'
    else:
        builtin_open = '__builtin__.open'

    def test_file_arg(args, path, state, line, regexp, search_string, insertafter, insertbefore,
                      create, backup, backrefs, firstmatch):
        fixture_data = dict(
            ANSIBLE_MODULE_ARGS=args
        )

        output = StringIO()

        def test_open(name, *args, **kwargs):
            if name == b'/test_path':
                if create:
                    return StringIO('')

# Generated at 2022-06-23 03:50:00.112897
# Unit test for function main

# Generated at 2022-06-23 03:50:12.164836
# Unit test for function present

# Generated at 2022-06-23 03:50:22.387066
# Unit test for function main
def test_main():
    import os
    import tempfile
    def check_results(out, exp_out):
        return out['path'] == exp_out['path'] and \
               out['backup'] == exp_out['backup'] and \
               out['backrefs'] == exp_out['backrefs'] and \
               out['changed'] == exp_out['changed'] and \
               out['create'] == exp_out['create'] and \
               out['ins_aft'] == exp_out['ins_aft'] and \
               out['ins_bef'] == exp_out['ins_bef'] and \
               out['firstmatch'] == exp_out['firstmatch'] and \
               out['line'] == exp_out['line'] and \
               out['regexp'] == exp_out['regexp']


# Generated at 2022-06-23 03:50:27.621528
# Unit test for function write_changes
def test_write_changes():
    # define mock module input
    b_lines = [ b'foo', b'bar']
    module = MockModule()

    # need to patch os and tempfile with autospec to use the temporary directory
    # and not have the file written to the system

# Generated at 2022-06-23 03:50:36.470846
# Unit test for function check_file_attrs
def test_check_file_attrs():

    mock_module = MagicMock(name='ansible_module')
    mock_module.set_fs_attributes_if_different = MagicMock()
    mock_module.params = { 'remote_src': False }
    mock_module.check_mode = False
    mock_module.no_log = False
    mock_module.run_command = MagicMock()

    message = "Message"
    changed = False

    mock_module.run_command.return_value = (0, "some output", "some error")
    message, changed = check_file_attrs(mock_module, changed, message, False)
    assert changed == True
    assert message == "Message and ownership, perms or SE linux context changed"

    message = "Message"
    changed = False

    mock_module.check_mode = True
   

# Generated at 2022-06-23 03:50:42.623528
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.file import AnsibleFile
    import os
    # Check that the paths specified in the tests exist, and skip tests
    # if they do not
    required_paths = ['/bin/grep', '/bin/awk']
    for p in required_paths:
        if not os.path.exists(p):
            print("Skipping tests because %s does not exist." % p)
            return
    # Cant't use /dev/null as a file as file.write() fails
    tmp_file = '/tmp/ansible-test-file'
    with open(tmp_file, 'w') as f:
        f.write('')
    module = Ans

# Generated at 2022-06-23 03:50:53.742913
# Unit test for function main
def test_main():
    # Create mock_module
    mock_module = MagicMock(name='mock_module')
    mock_module.params = {
        'dest': 'file1',
        'search_string': 'string1',
        'line': 'line1',
        'exact': 'false',
        'backup': 'false',
        'firstmatch': 'true',
        'validate': 'none'
    }
    mock_module.exit_json = MagicMock(name='mock_module.exit_json')
    mock_module.exit_json.side_effect = system_exit
    mock_module.fail_json = MagicMock(name='mock_module.fail_json')
    mock_module.fail_json.side_effect = system_exit

    # Mock the return value of
    # collections.namedt

# Generated at 2022-06-23 03:51:04.107405
# Unit test for function check_file_attrs
def test_check_file_attrs():

    mod = AnsibleModule({
        'path': '/tmp/testfile',
        'owner': 'dns',
        'group': 'dns',
        'mode': '0644',
        'seuser': 'user_u',
        'serole': 'user_r',
        'setype': 'user_t',
        'selevel': 's0',
    })

    message = 'Changed'
    changed = True
    file_info = {
        'owner': 'dns',
        'group': 'dns',
        'mode': '0644',
        'seuser': 'user_u',
        'serole': 'user_r',
        'setype': 'user_t',
        'selevel': 's0',
    }


# Generated at 2022-06-23 03:51:04.495708
# Unit test for function write_changes
def test_write_changes():
    assert 1==1

# Generated at 2022-06-23 03:51:10.407038
# Unit test for function absent
def test_absent():
    args = dict(dest='/tmp/test_lineinfile.txt',
                line='test',
                regexp=None
               )
    result = absent(module=None, **args)
    assert result == True


# Generated at 2022-06-23 03:51:22.474101
# Unit test for function absent
def test_absent():
  module = AnsibleModule(
      argument_spec={
          'dest': dict(type='str', required=True),
          'backup': dict(type='bool', default=False),
          'regexp': dict(type='str'),
          'search_string': dict(type='str'),
          'line': dict(type='str', required=True),
      },
      mutually_exclusive=[
          ['regexp', 'search_string'],
      ],
      supports_check_mode=True
  )

  # mock os.path.exists
  module.exists = os.path.exists
  # mock os.path.isfile
  module.isfile = os.path.isfile
  # mock os.makedirs
  module.makedirs = os.makedirs
  # mock open

# Generated at 2022-06-23 03:51:34.447306
# Unit test for function present
def test_present():
    module = Basic_AnsibleModule()
    my_dict = dict(
        dest='/tmp/myfile',
        regexp='^#test',
        line='test',
        insertbefore='^#test',
        backup=True,
        backrefs=True
    )

    set_module_args(module, my_dict)

    # Create a file with some content
    with open(module.params['dest'], 'w') as f:
        f.write('test')

    # First we see we have a file
    assert os.path.exists(my_dict['dest'])

    # Run the module code

# Generated at 2022-06-23 03:51:46.451444
# Unit test for function main

# Generated at 2022-06-23 03:51:57.982090
# Unit test for function write_changes
def test_write_changes():
    ''' Function to test write_changes function in lineinfile module '''
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': True},
                                          'validate': {'type': 'str', 'required': False},
                                          'unsafe_writes': {'type': 'bool', 'default': False}})
    b_str = 'Hello World'
    b_lines = [to_bytes(b_str, errors='surrogate_or_strict')]
    dest = 'test.txt'
    with open(dest, mode='w') as f:
        f.writelines(b_lines)

# Generated at 2022-06-23 03:52:09.379974
# Unit test for function present
def test_present():
    try:
        import __builtin__
        # Python 2
        __builtin__.open = open
        __builtin__.file = file
    except ImportError:
        # Python 3
        pass

# Generated at 2022-06-23 03:52:20.828278
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'dest': {'type': 'path'},
        'unsafe_writes': dict(type='bool', default=False),
    })

    # Write test file
    fd, tmpfile = tempfile.mkstemp(dir=module.params['dest'])
    with os.fdopen(fd, 'wb') as f:
        f.writelines(['1234567890\n'])
    b_tmpfile = to_bytes(tmpfile)

    # Write test expected file
    fd, tmpvalid = tempfile.mkstemp(dir=module.params['dest'])
    with os.fdopen(fd, 'wb') as f:
        f.writelines(['qwertyuiop\n'])

# Generated at 2022-06-23 03:52:33.215300
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str', default=None),
            search_string=dict(type='str', default=None),
            line=dict(type='str', required=True),
            insertafter=dict(type='str', default=None),
            insertbefore=dict(type='str', default=None),
            create=dict(default='yes', type='bool'),
            backup=dict(default='no', type='bool'),
            backrefs=dict(default='no', type='bool'),
            validate=dict(type='str', default=None),
            unsafe_writes=dict(default=False, type='bool')
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-23 03:52:46.298524
# Unit test for function main
def test_main():
    # Test path with 'present' state.
    path     = "/tmp/test.txt"
    regexp   = None
    line     = "this is a test"
    search_string = None
    ins_aft = 'EOF'
    ins_bef = None
    create = False
    backup = False
    backrefs = False
    firstmatch = False
    assert present(module, path, regexp, search_string, line,
                ins_aft, ins_bef, create, backup, backrefs, firstmatch) == "this is a test"
    # Test path with 'absent' state.
    line = None
    search_string = None
    regexp = "^this is a test"
    assert absent(module, path, regexp, search_string, line, backup) == []
    

# Generated at 2022-06-23 03:52:59.944442
# Unit test for function present
def test_present():
    module = AnsibleModule(argument_spec=dict(
        path=dict(required=True, type='path'),
        regexp=dict(type='str'),
        searchstring=dict(type='str'),
        insertafter=dict(type='str'),
        insertbefore=dict(type='str'),
        line=dict(required=True, type='str'),
        create=dict(required=False, type='bool', default=False),
        backup=dict(required=False, type='bool', default=False),
        backrefs=dict(required=False, type='bool', default=False),
        firstmatch=dict(required=False, type='bool', default=False),
    ))
    # true, regexp and searchstring are not given, insertbefore and insertafter are 'BOF'
    module.params['create'] = True
   

# Generated at 2022-06-23 03:53:08.546275
# Unit test for function write_changes
def test_write_changes():
    # Test all possible combinations of parameters
    # Create, backup, validate, unsafe_writes
    testfile = "/tmp/test_lineinfile.txt"
    backupfile = "%s.%%Y-%%m-%%d@%%H:%%M:%%S" % testfile
    module = AnsibleModule({ 'create': False, 'backup': False, 'validate': None, 'unsafe_writes': False, 'path': testfile, 'line': 'Hello World'  })
    with open("%s" % testfile, "w") as f:
        f.write("Goodbye World")
    write_changes(module, ['Hello World\n'], testfile)
    with open("%s" % testfile, "r") as f:
        result = f.read()
        assert(result == "Hello World")
   

# Generated at 2022-06-23 03:53:19.158762
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True, type='str'),
            line=dict(required=True, type='str'),
            regexp=dict(required=False, type='str')
        )
    )

    module.exit_json = exit_json
    module.fail_json = fail_json

    dest = 'test.txt'
    regexp = '^test$'
    line = 'test'
    backup = False

    absent(module, dest, regexp, None, line, backup)



# Generated at 2022-06-23 03:53:26.252830
# Unit test for function present
def test_present():
    module = AnsibleModule({
        "dest": "/tmp/test.txt",
        "firstmatch": False,
        "line": "test",
        "backrefs": False
    })

    present(module, module.params.get("dest"), None, None, module.params.get("line"), None, None, False, True, module.params.get("backrefs"), module.params.get("firstmatch"))


# Generated at 2022-06-23 03:53:37.922220
# Unit test for function write_changes
def test_write_changes():
    import mock
    import tempfile, os
    import shutil
    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)
    b_lines = [b"foo\n", b"bar\n", b"baz\n"]
    dest = "/tmp/dest"
    with mock.patch("ansible.module_utils.basic.AnsibleModule") as mock_module:
        instance = mock_module.return_value
        instance.tmpdir = '/tmp'
        instance.params = {
            'validate': None,
            'unsafe_writes': False
        }
        instance.run_command.return_value = [ 0, "", "" ]

        write_changes(instance, b_lines, dest)
        instance.run_command.assert_not_called()

# Generated at 2022-06-23 03:53:48.898788
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True, aliases=['dest', 'destfile', 'name']),
            regexp=dict(type='str', required=True, aliases=['regex']),
            line=dict(type='str', required=True, aliases=['value']),
            state=dict(type='str', required=False, default='present'),
            insertafter=dict(type='str', required=False, default='EOF'),
            insertbefore=dict(type='str', required=False, default='EOF'),
            create=dict(type='bool', required=False, default=False),
            backup=dict(type='bool', required=False, default=False),
            others=dict(type='str', required=True)
        )
    )



# Generated at 2022-06-23 03:53:58.842039
# Unit test for function present
def test_present():
    assert present(module, dest, regexp, search_string, line, insertafter, insertbefore, create,
            backup, backrefs, firstmatch) == "line replaced"
    assert present(module, dest, regexp, search_string, line, insertafter, insertbefore, create,
            backup, backrefs, firstmatch) == "line replaced" and changed == True
    assert present(module, dest, regexp, search_string, line, insertafter, insertbefore, create,
            backup, backrefs, firstmatch) == "line added" and changed == False
    assert present(module, dest, regexp, search_string, line, insertafter, insertbefore, create,
            backup, backrefs, firstmatch) == "line added"


# Generated at 2022-06-23 03:54:03.561710
# Unit test for function present
def test_present():
    act_results = present(module, dest, regexp, search_string, line, insertafter, insertbefore, create,
                        backup, backrefs, firstmatch)
    print(act_results)


# Generated at 2022-06-23 03:54:16.535353
# Unit test for function absent
def test_absent():
    b_dest = to_bytes(module.params['dest'], errors='surrogate_or_strict')
    if not os.path.exists(b_dest):
        module.exit_json(changed=False, msg="file not present")

    msg = ''
    diff = {'before': '',
            'after': '',
            'before_header': '%s (content)' % dest,
            'after_header': '%s (content)' % dest}

    with open(b_dest, 'rb') as f:
        b_lines = f.readlines()

    if module._diff:
        diff['before'] = to_native(b''.join(b_lines))


# Generated at 2022-06-23 03:54:23.978714
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.removed import removed_module

    if removed_module("ansible.builtin.lineinfile"):
        return


# Generated at 2022-06-23 03:54:33.944781
# Unit test for function present
def test_present():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text
    example_string = """
- name: Test adding a line to the top of the file
  lineinfile:
    path: "/tmp/testfile"
    line: "{{ item }}"
    insertbefore: BOF
  with_items:
    - '# Set test value one'
    - '# Set test value two'

- name: Test adding a line to the bottom of the file
  lineinfile:
    path: "/tmp/testfile"
    line: '# Set test value three'
    insertafter: EOF
"""

# Generated at 2022-06-23 03:54:41.650305
# Unit test for function present
def test_present():
    module = AnsibleModule(argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(),
            search_string=dict(),
            line=dict(required=True),
            insertafter=dict(),
            insertbefore=dict(),
            create=dict(required=False, default=False, type='bool'),
            backup=dict(required=False, default=False, type='bool'),
            backrefs=dict(required=False, default=False, type='bool'),
            firstmatch=dict(required=False, default=False, type='bool'),
            validate=dict(),
            unsafe_writes=dict(required=False, default=False, type='bool')
        ))

# Generated at 2022-06-23 03:54:42.230420
# Unit test for function present
def test_present():
    assert True


# Generated at 2022-06-23 03:54:44.921135
# Unit test for function absent
def test_absent():
    result = absent(module, dest, regexp, search_string, line, backup)
    assert result


# Generated at 2022-06-23 03:54:50.980520
# Unit test for function present
def test_present():
    # We can't test the exact text of the error message, because it
    # changes with locale.
    with pytest.raises(SystemExit) as exc:
        present("foo", "/foo", "asdf", "asdf")
    assert exc.value.args[0] != 0



# Generated at 2022-06-23 03:54:58.385528
# Unit test for function check_file_attrs

# Generated at 2022-06-23 03:55:00.784252
# Unit test for function write_changes
def test_write_changes():
    raise NotImplementedError()



# Generated at 2022-06-23 03:55:10.933951
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = Mock()
    module.params = {}
    module.load_file_common_arguments = Mock(return_value={})
    module.set_fs_attributes_if_different = Mock(return_value=False)

    message, changed = check_file_attrs(module, False, "my message", None)
    assert not changed
    assert message == "my message"

    module.set_fs_attributes_if_different = Mock(return_value=True)
    message, changed = check_file_attrs(module, True, "another message", None)
    assert changed
    assert message == "another message and ownership, perms or SE linux context changed"


# Generated at 2022-06-23 03:55:15.219199
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec=dict(
            dest=dict(type='path', required=True),
            validate=dict(required=False),
            tmpdir=dict(required=False)
        ),
        supports_check_mode=True,
    )
    b_lines = []
    dest = '/tmp/test_file.txt'
    write_changes(module, b_lines, dest)
    return True


# Generated at 2022-06-23 03:55:19.915526
# Unit test for function absent
def test_absent():
    module, dest, regexp, line, search_string, backup = None, None, None, None, None, None
    # Expected exit path; no change
    module.params['line'] = 'test'
    absent(module, dest, regexp, search_string, line, backup)
    # Failure test for module.fail_json
    # unexpected_keyword_arg=module.fail_json
test_absent()


# Generated at 2022-06-23 03:55:27.514765
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.params = {'unsafe_writes': False,
                     'path': None,
                     'owner': None,
                     'group': None,
                     'mode': None,
                     'seuser': None,
                     'serole': None,
                     'setype': None,
                     'selevel': None}
    changed = False
    message = ''
    assert check_file_attrs(module, changed, message, True) == ('ownership, perms or SE linux context changed', True)



# Generated at 2022-06-23 03:55:30.836643
# Unit test for function check_file_attrs
def test_check_file_attrs():
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    with os.fdopen(tmpfd, 'wb') as f:
        f.writelines(b_lines)


# Generated at 2022-06-23 03:55:40.107494
# Unit test for function main
def test_main():
    from ansible.modules.files import lineinfile
    my_module = lineinfile('/dev/null')
    my_module.check_mode = True
    my_module.params = {'path': '/path/to/file',
                        'state': 'present',
                        'backrefs': False,
                        'create': False,
                        'backup': False,
                        'firstmatch': False,
                        'line': 'something'}
    my_module.run()
    my_module.params['backrefs'] = True
    my_module.params['regexp'] = True
    my_module.run()
    my_module.params['backrefs'] = False
    my_module.params['regexp'] = False
    my_module.params['search_string'] = True
    my_module.run

# Generated at 2022-06-23 03:55:44.498542
# Unit test for function present
def test_present():
    assert not present(module, dest, regexp, search_string, line, insertafter, insertbefore, create,
            backup, backrefs, firstmatch)


# Generated at 2022-06-23 03:55:55.508091
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True),
            regexp=dict(required=False),
            search_string=dict(required=False),
            line=dict(required=False),
            backup=dict(required=False, default=False, type='bool')
        )
    )
    if not os.path.exists('/tmp/test.txt'):
        open('/tmp/test.txt', 'a').close()
    open('/tmp/test.txt', 'w').write('test\n')
    module.check_mode = False
    # test 'test' and 'test\n' are same
    absent(module, '/tmp/test.txt', None, None, 'test', True)

# Generated at 2022-06-23 03:56:06.893791
# Unit test for function present
def test_present():
    b_dest = to_bytes("/tmp/test")
    b_lines = to_bytes("test\nanother\n")
    bre_m = re.compile(to_bytes("test", errors='surrogate_or_strict'))
    b_line = to_bytes("test changed", errors='surrogate_or_strict')
    b_new_line = to_bytes("test_changed")
    b_linesep = to_bytes(os.linesep, errors='surrogate_or_strict')
    if os.path.exists(b_dest):
        os.remove(b_dest)

# Generated at 2022-06-23 03:56:11.518694
# Unit test for function write_changes
def test_write_changes():
    import StringIO
    lines = StringIO.StringIO('test')
    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)
    write_changes(tmpfile, lines)
    assert os.path.getsize(tmpfile) == 4


# Generated at 2022-06-23 03:56:22.946438
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class Options:
        def __init__(self, params):
            self.params = params
    class Module:
        def __init__(self, params):
            self.params = params
            self.fail_json = exit

# Generated at 2022-06-23 03:56:28.873746
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={},
                           supports_check_mode=True)
    b_lines = to_bytes("\n".join(['#', 'line1', 'line2']), errors='surrogate_or_strict')
    dest = tempfile.mkstemp(dir='/tmp/')
    write_changes(module, b_lines, dest)



# Generated at 2022-06-23 03:56:32.085349
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(module, True, "ownership, perms or SE linux context changed") == ("ownership, perms or SE linux context changed", True)

# Generated at 2022-06-23 03:56:33.518994
# Unit test for function write_changes
def test_write_changes():
    assert True is not False


# Generated at 2022-06-23 03:56:42.924246
# Unit test for function write_changes
def test_write_changes():
    class FakeModule(object):
        def __init__(self, lines, dest):
            self.tmpdir = tempfile.mkdtemp()
            self.params = {
                'validate': None,
                'unsafe_writes': True,
                }
            self.lines = lines
            self.dest = dest

        def fail_json(self, *args, **kwargs):
            raise Exception(args[0])

        def run_command(self, cmd):
            return 0, '', ''

        def atomic_move(self, src, dest):
            if not os.path.exists(src):
                raise Exception('src file %s does not exist' % src)
            with open(src) as f:
                lines = f.readlines()
                if lines != self.lines:
                    raise Exception('content mismatch')

# Generated at 2022-06-23 03:56:47.590412
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec=dict())
    changed = False
    message = ''
    diff = {}
    res = check_file_attrs(module, changed, message, diff)
    assert res


# Generated at 2022-06-23 03:57:01.113202
# Unit test for function absent
def test_absent():
    class module(object):
        def __init__(self):
            self.params = {'backup': False}
            self.check_mode = False
        def fail_json(self, *args, **kwargs):
            raise Exception(args, kwargs)
        def exit_json(self, **kwargs):
            self.result = kwargs
    import os
    m = module()

# Generated at 2022-06-23 03:57:14.098129
# Unit test for function write_changes
def test_write_changes():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text
    import os
    import shutil
    import tempfile
    module = AnsibleModule({})
    f1 = tempfile.NamedTemporaryFile()
    f2 = tempfile.NamedTemporaryFile()
    b_foo = to_bytes('foo', errors='surrogate_or_strict')
    b_lines = [b_foo, b_foo]
    write_changes(module, b_lines, f1.name)
    ''' Doesn't work on Windows
    os.chmod(f1.name, 0o000)
    write_changes(module, b_lines, f2.name)
    '''



# Generated at 2022-06-23 03:57:25.815780
# Unit test for function write_changes
def test_write_changes():
    from ansible.utils.path import makedirs_safe
    from ansible.module_utils._text import to_bytes
    import tempfile
    import os
    import shutil
    import stat
    import errno
    import sys

    # Create test directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create test file
    old_line = 'Old line'
    new_line = 'New line'
    test_file = 'test.txt'
    with open(test_file, 'w') as f:
        f.write(old_line)

    # Ensure test file exists
    assert os.path.exists(test_file)

    # Check that test file matches old line

# Generated at 2022-06-23 03:57:37.479116
# Unit test for function main
def test_main():

    # Unit test for function main
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.sros import *
    from ansible.module_utils.sros import main
    from ansible.module_utils import connection
    import os
    import time
    module = AnsibleModule(argument_spec={ "command_timeout" : dict(type="int", required=False ) })

    command_timeout = module.params["command_timeout"] if module.params["command_timeout"] else 10
    connection0 = connection.Connection(module._socket_path)

    res = main(module=module, connection=connection0, command_timeout=command_timeout)

    '''
    pass


# import module snippets
from ansible.module_utils.basic import *

# Generated at 2022-06-23 03:57:45.770217
# Unit test for function main
def test_main():
    # Called if the module is run directly.
    # @see https://docs.ansible.com/ansible/devel/dev_guide/developing_modules_general.html#python-package-layout
    # @see https://docs.ansible.com/ansible/2.5/dev_guide/developing_modules_general.html#python-package-layout
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    main()


if __name__ == '__main__':
    # Execute the main function.
    main()

# Generated at 2022-06-23 03:57:48.971524
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(1, 1, 1, 1) == (1, 1)


# Generated at 2022-06-23 03:58:00.842237
# Unit test for function absent
def test_absent():
    from ansible.compat.tests import unittest

    class TestAbsent(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(
                argument_spec=dict(
                    dest=dict(type='path', required=True),
                    regexp=dict(type='str', required=False),
                    search_string=dict(type='str', required=False),
                    line=dict(type='str', required=False),
                    backup=dict(type='bool', required=False),
                ),
                supports_check_mode=True
            )
            self.module._diff = True

        def test_absent(self):
            self.module.params['line'] = "test line"
            self.module.params['regexp'] = None