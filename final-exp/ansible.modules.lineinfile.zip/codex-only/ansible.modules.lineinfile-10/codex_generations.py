

# Generated at 2022-06-23 03:48:02.057362
# Unit test for function main
def test_main():
    test_input = {
        "backup": False,
        "backrefs": False,
        "create": False,
        "firstmatch": False,
        "line": "test",
        "path": "/tmp/test.txt",
        "regexp": None,
        "search_string": None,
        "state": "present"
    }


# Generated at 2022-06-23 03:48:12.988480
# Unit test for function absent
def test_absent():
    test_lines = [
        to_bytes("this is a test\n"),
        to_bytes("and this is another test\n"),
        to_bytes("and this is another test\n"),
        to_bytes("and this is another text\n"),
        to_bytes("and this is another test\n"),
    ]
    module = AnsibleModule({
        'regexp': '^and',
    })
    # Return value of absent()
    absent(module, '/tmp/test/file', '^and', None, "test\n", False)
    # Check for function write_changes
    with patch('ansible.module_utils.basic.AnsibleModule.exit_json') as mocked_exit_json:
        mocked_exit_json.return_value = None

# Generated at 2022-06-23 03:48:24.465411
# Unit test for function main
def test_main():
    assert 'ansible_module_lineinfile' not in globals()
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.basic import AnsibleModule
    global ansible_module_lineinfile

# Generated at 2022-06-23 03:48:34.780269
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='str'),
            owner = dict(type='str'),
            group = dict(type='str'),
            seuser = dict(type='str'),
            serole = dict(type='str'),
            setype = dict(type='str'),
            mode = dict(type='str'),
            unsafe_writes = dict(type='bool', default=False)
        ),
    )
    changed = False
    message = ""
    diff = list()
    result = check_file_attrs(module, changed, message, diff)
    assert result == ('', True)
# end of function test_check_file_attrs



# Generated at 2022-06-23 03:48:44.390454
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(),
            owner=dict(),
            group=dict(),
            mode=dict(),
            seuser=dict(),
            serole=dict(),
            setype=dict(),
            selevel=dict(),
        ),
    )
    module.params['path'] = '/tmp/testfile'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['seuser'] = 'system_u'
    module.params['serole'] = 'object_r'
    module.params['setype'] = 'var_log_t'
    module.params['selevel'] = 's0-s0'
    module.params['mode'] = 0o644

    changed = False
    message = ''


# Generated at 2022-06-23 03:48:53.482102
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module.atomic_move = lambda src, dest, foo: dest
    module.params = dict(
        diff=None,
        unsafe_writes=None,
        path='somefile',
        owner='root',
        group='wheel',
        mode='0644',
        seuser=None,
        serole=None,
        selevel=None,
        setype=None,
    )
    module.set_fs_attributes_if_different = lambda x,y,z: True
    check_file_attrs(module, True, "changed", {})


# Generated at 2022-06-23 03:49:03.681249
# Unit test for function check_file_attrs
def test_check_file_attrs():

    class AnsibleModuleMock(object):

        def __init__(self, argspec):
            self.params = {}
            self.tmpdir = '/tmp'

        def fail_json(self, **kwargs):
            raise Exception(kwargs['msg'])

        def load_file_common_arguments(self, params):
            return {
                'path': params['path'],
                'mode': params['mode'],
                'owner': params['owner'],
                'group': params['group'],
                'seuser': params['seuser'],
                'serole': params['serole'],
                'setype': params['setype'],
                'selevel': params['selevel']
            }


# Generated at 2022-06-23 03:49:17.481561
# Unit test for function main
def test_main():

    import json

    import ansible.utils.path as path_utils

    def setUpModule():
        if not path_utils.HAS_PWD:
            self.skipTest("pwd module required for this test")

    def test_main_notfound_present(self):
        module = AnsibleModule(argument_spec=dict(path='/tmp/notfound', state='present', line='test', create='no'),
                               add_file_common_args=True, supports_check_mode=True)
        result = main()
        assert result['changed'] is False
        assert result['msg'] == 'file not found'


# Generated at 2022-06-23 03:49:18.036866
# Unit test for function write_changes
def test_write_changes():
    assert False



# Generated at 2022-06-23 03:49:22.278012
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({})
    module.params['mode'] = 1055
    module.params['owner'] = 'test'
    module.params['group'] = 'test'
    module.params['secontext'] = 'test'
    module.params['unsafe_writes'] = True

    assert check_file_attrs(module, False, '', False) == ('ownership, perms or SE linux context changed', True)

    module.params['changed'] = True
    assert check_file_attrs(module, True, '', False) == (' and ownership, perms or SE linux context changed', True)

    module.params['changed'] = False
    assert check_file_attrs(module, False, 'test', True) == (' test and ownership, perms or SE linux context changed', True)



# Generated at 2022-06-23 03:49:29.599242
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    b_lines = [
      to_bytes('aaa'),
      to_bytes('bbb'),
      to_bytes('ccc'),
    ]
    dest = './test_lineinfile'

    write_changes(module, b_lines, dest)
    with open(dest, 'r') as f:
        file_content = f.readlines()
        assert b_lines == file_content


# Generated at 2022-06-23 03:49:40.469168
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({
        'backup': False,
        'create': False,
        'firstmatch': False,
        'insertafter': 'EOF',
        'insertbefore': None,
        'line': 'testing',
        'path': '/foo',
        'regexp': '^test$',
        'search_string': None,
        'state': 'present',
        'unsafe_writes': True,
        'validate': None
    })
    dest = module.params['path']
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    f = os.fdopen(tmpfd, 'wb')
    f.writelines('test'.encode())

    write_changes(module, 'test'.encode(), dest)

# Generated at 2022-06-23 03:49:50.841681
# Unit test for function main

# Generated at 2022-06-23 03:49:54.879184
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule({'dest': '/tmp/testfile', 'owner': 'root', 'group': 'root', 'mode': '0644'})
    test_module.params.update({'original_basename': 'testfile', 'path': '/tmp/testfile'})
    test_module.params['unsafe_writes'] = False
    changed = True
    message = ''
    message, changed = check_file_attrs(test_module, changed, message, "")
    command_output = "changed=%s   msg=%s" % (changed, message)
    assert command_output == "changed=True   msg=ownership, perms or SE linux context changed"
    test_module.exit_json(msg=message, changed=changed)


# end of unit test -----------------------------


# Generated at 2022-06-23 03:50:06.578047
# Unit test for function present
def test_present():
    arguments = dict(
        dest='/tmp/dest',
        line='line',
        create='yes'
    )


# Generated at 2022-06-23 03:50:12.638447
# Unit test for function present
def test_present():
    module = AnsibleModule({
        "param_name": "value"
    }, check_invalid_arg=False)
    module.debug = True
    module.exit_json = exit_json
    present(module, dest, regexp, search_string, line, insertafter, insertbefore, create,
            backup, backrefs, firstmatch)


# Generated at 2022-06-23 03:50:20.554269
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            lines=dict(type='list', default=[]),
            dest=dict(type='path', default=None),
            validate=dict(type='str', default=None)
        ),
        supports_check_mode=True
    )
    lines = [u'# Write a test string',u'Hello world']
    dest = '/tmp/test_write_changes'
    with tempfile.NamedTemporaryFile() as tmpfile:

        write_changes(module, lines, dest)
        with open(dest, 'r') as f:
            written_lines = f.readlines()
        os.remove(dest)

    assert lines == written_lines



# Generated at 2022-06-23 03:50:24.712400
# Unit test for function present
def test_present():
    module_args = dict(
        state=dict(default='present', choices=['absent', 'present']),
        dest=dict(type='path'),
        regexp=dict(type='str', default=None),
        line=dict(type='str'),
        insertbefore=dict(type='str', default=None),
        insertafter=dict(type='str', default=None),
        create=dict(type='bool', default=False),
        backup=dict(type='bool', default=False),
        firstmatch=dict(type='bool', default=False),
        backrefs=dict(type='bool', default=False),
        search_string=dict(type='str', default=None)
    )

# Generated at 2022-06-23 03:50:29.038230
# Unit test for function present
def test_present():

    assert present(1, dest, regexp, search_string, line, insertafter, insertbefore, create,
            backup, backrefs, firstmatch) == "present"


# Generated at 2022-06-23 03:50:37.459450
# Unit test for function check_file_attrs

# Generated at 2022-06-23 03:50:42.997128
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=False),
            path=dict(type='path', required=True),
            owner=dict(type='str', required=False),
            group=dict(type='str', required=False),
            mode=dict(type='str', required=False),
            seuser=dict(type='str', required=False),
            serole=dict(type='str', required=False),
            setype=dict(type='str', required=False),
        ),
    )
    changed = True
    message = "test message"
    diff = {"before": "test", "after": "test"}
    result = check_file_attrs(module, changed, message, diff)

# Generated at 2022-06-23 03:50:55.445483
# Unit test for function present
def test_present():
    # Mock params
    class Args(object):
        dest = 'dest'
        regexp = None
        search_string = 'search_string'
        line = 'line'
        insertafter = 'insertafter'
        insertbefore = None
        create = 'create'
        backup = False
        backrefs = 'backrefs'
        firstmatch = False
    args = Args()
    p = present(module, dest, regexp, search_string, line, insertafter, insertbefore, create, backup, backrefs, firstmatch)



# Generated at 2022-06-23 03:51:05.349380
# Unit test for function main

# Generated at 2022-06-23 03:51:16.206023
# Unit test for function absent
def test_absent():
    import json


# Generated at 2022-06-23 03:51:20.854575
# Unit test for function absent
def test_absent():

    module = AnsibleModule(argument_spec=dict(
        dest=dict(required=True, type='str'),
        regexp=dict(type='str'),
        search_string=dict(type='str'),
        line=dict(type='str'),
        state=dict(default='present', choices=['present', 'absent'], type='str'),
        encoding=dict(required=False, type='str'),
        backup=dict(default=False, type='bool'),
        validate=dict(default=None, required=False),
    ))

    abs = 'absent'
    dest = '/etc/passwd'
    regexp = '^root:'
    line = 'root:x:0:0:root:/root:/bin/bash'
    search_string = 'root'


# Generated at 2022-06-23 03:51:28.153053
# Unit test for function main
def test_main():
    args = dict(
        path = 'testfile',
        regexp = '',
        search_string = '',
        line = 'This is a test line',
        insertafter = 'EOF',
        insertbefore = None,
        backrefs = False,
        create = False,
        backup = False,
        firstmatch = False
    )
    module = AnsibleModule(argument_spec=args, supports_check_mode=True)

    m_open = mock_open()
    m_exists = MagicMock(return_value=True)
    m_isdir = MagicMock(return_value=False)

# Generated at 2022-06-23 03:51:30.497671
# Unit test for function main
def test_main():
    class AnsibleModule(object):
        def __init__(self):
            self.argument_spec = dict(
                
            )
            self.params = dict(
                
            )
                                
        def exit_json(self):
            pass
        def fail_json(self):
            pass
    module = AnsibleModule()
    main()


# Generated at 2022-06-23 03:51:42.293753
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec={
            'search_string': {'required': True},
            'regexp': {'required': True},
            'path' : {'required': True},
            'line' : {'required': True},
            'validate' : {'default': None},
            'unsafe_writes' : {'default': False}
        },
        supports_check_mode=True)
    test_file = os.path.dirname(os.path.realpath(__file__)) + "/test_file"
    b_test_file = to_bytes(test_file, errors='surrogate_or_strict')
    b_tmp_file = to_bytes("/tmp/test_file", errors='surrogate_or_strict')

# Generated at 2022-06-23 03:51:53.117961
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest = dict(required=True),
            regexp = dict(default=None),
            search_string = dict(default=None),
            line = dict(required=True),
            backup=dict(default=False, type='bool'),
        ),
        supports_check_mode=True
    )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    assert absent(module, dest, regexp, search_string, line, backup) == (changed, found, msg, backupdest, diff)

# Generated at 2022-06-23 03:52:00.301473
# Unit test for function write_changes
def test_write_changes():
    """
    Test write_changes function
    """
    lines = ["123", "234", "345", "456"]
    tmpfd, tmpfile = tempfile.mkstemp()
    dest = tmpfile + ".dest"
    my_module = AnsibleModule(argument_spec={})
    my_module.tmpdir = os.path.dirname(tmpfile)
    write_changes(my_module, lines, dest)
    written_lines = list()
    with open(dest, "r") as f:
        written_lines = f.readlines()
    assert lines == written_lines
    os.remove(tmpfile)
    os.remove(dest)



# Generated at 2022-06-23 03:52:00.751661
# Unit test for function write_changes
def test_write_changes():
    assert False


# Generated at 2022-06-23 03:52:02.968663
# Unit test for function write_changes
def test_write_changes():
    """Unit test for function write_changes"""
    module = AnsibleModule({
        'validate': '/usr/sbin/visudo -cf %s'
    })
    assert None is write_changes(module, [b'foo'], '/etc/hosts')


# Generated at 2022-06-23 03:52:13.517318
# Unit test for function present

# Generated at 2022-06-23 03:52:22.446194
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'owner': {'type': 'str'}, 'group': {'type': 'str'}, 'mode': {'type': 'str'}, 'seuser': {'type': 'str'}, 'serole': {'type': 'str'}, 'setype': {'type': 'str'}, 'selevel': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}, '_diff': {'type': 'bool'}, '_ansible_check_mode': {'type': 'bool'}})


# Generated at 2022-06-23 03:52:24.949392
# Unit test for function absent
def test_absent():
    res = absent(module=ANY,dest='/ansible/filepath',regexp='',search_string='',line='whatever',backup=False)
    assert res == None

# Generated at 2022-06-23 03:52:28.056251
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as result:
        main()
    assert result.value.args[0]['changed']


# Generated at 2022-06-23 03:52:36.319722
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_args = {'path': '/test/test'}
    test_res = dict()
    test_res['changed'] = False
    test_res['msg'] = ''
    test_res['diff'] = []
    test_obj = AnsibleModule(argument_spec=dict())
    mock_set_fs_attribs_if_diff = MagicMock(return_value=True)
    mock_set_fs_attribs_if_diff.__name__ = 'set_fs_attributes_if_different'
    test_obj.set_fs_attributes_if_different = mock_set_fs_attribs_if_diff
    res = check_file_attrs(test_obj, test_res['changed'], test_res['msg'], test_res['diff'])

# Generated at 2022-06-23 03:52:47.699438
# Unit test for function main

# Generated at 2022-06-23 03:53:01.261776
# Unit test for function present
def test_present():
    module = AnsibleModule(argument_spec=dict(dest=dict(type='str'), line=dict(type='str'), regexp=dict(type='str'), create=dict(default=False, type='bool'), backrefs=dict(default=False, type='bool'), firstmatch=dict(default=False, type='bool'), insertafter=dict(type='str'), insertbefore=dict(type='str'), remove=dict(default=False, type='bool'), state=dict(default='present', choices=['present']), backup=dict(default=True, type='bool'), unsafe_writes=dict(default=False, type='bool'), validate=dict(type='str')), supports_check_mode=True)
    dest = '/tmp/sample'
    regexp = '^(.*)Xms(\d+)m(.*)$'
    search_

# Generated at 2022-06-23 03:53:06.069285
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(module, False, "message", "diff") == ("message", True)
    assert check_file_attrs(module, True, "message", "diff") == ("message and ownership, perms or SE linux context changed", True)


# Generated at 2022-06-23 03:53:14.754934
# Unit test for function absent
def test_absent():
    s = b"ABCD"
    pattern = ".*"
    assert absent(s,pattern) == False

    s = b"abcd"
    pattern = ".*"
    assert absent(s,pattern) == True

    s = b""
    pattern = ".*"
    assert absent(s,pattern) == False

    s = b"abcd"
    pattern = ".*"
    assert absent(s,pattern) == True

    s = b"ABCD"
    pattern = ".*"
    assert absent(s,pattern) == False

    s = b"abcd"
    pattern = ".*"
    assert absent(s,pattern) == True

    s = b""
    pattern = ".*"
    assert absent(s,pattern) == False

    s = b"abcd"
    pattern = ".*"


# Generated at 2022-06-23 03:53:27.110739
# Unit test for function main
def test_main():
    # Dummy AnsibleModule object
    class DummyAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.check_mode = False
            self._diff = True
            def fail_json(self, *args, **kwargs):
                raise Exception(args[0])
            self.fail_json = fail_json
            def exit_json(self, *args, **kwargs):
                pass
            self.exit_json = exit_json
            def backup_local(self, *args, **kwargs):
                return 'backup_file'
            self.backup_local = backup_local
        # Unit test function
        def run_command(self, *args, **kwargs):
            return 0, '', ''

    # Function under test
   

# Generated at 2022-06-23 03:53:38.404316
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule
    # Test Variables
    mod = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            regexp=dict(),
            line=dict(),
            backup=dict(default=False, type='bool'),
            validate=dict()
        )
    )
    b_lines = to_bytes("test123\n")
    dest = os.path.abspath("/tmp/testfile")
    # Normal case
    write_changes(mod, b_lines, dest)
    if os.path.exists(dest):
        os.unlink(dest)
    else:
        assert False, "Destination file does not exist."
    # Validation fail case
   

# Generated at 2022-06-23 03:53:49.100523
# Unit test for function main
def test_main():
    ins_bef, ins_aft = 'ins_bef', 'ins_aft'
    regexp, search_string, line = None, None, None
    backup = True
    backrefs = True
    create = False
    firstmatch = True

# Generated at 2022-06-23 03:54:02.083470
# Unit test for function absent
def test_absent():
    """
    Module file module unit test for function 'absent'
    """
    backup = module_file.params['backup']
    dest = module_file.params['dest']
    regexp = module_file.params['regexp']
    search_string = module_file.params['search_string']
    line = module_file.params['line']
    
    # Write a sample file
    b_sample_file = to_bytes(sample_file_name, errors='surrogate_or_strict')
    sample_content = b"First line\nSecond line\nThird line\nFourth line\nFifth line\nSixth line\n"
    with open(b_sample_file, 'wb') as f:
        f.write(sample_content)
    
    # Test the function without search_string


# Generated at 2022-06-23 03:54:10.167601
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
            argument_spec = dict(
                changed = dict(type='bool'),
                message = dict(type='str'),
                diff = dict(type='bool'),
                path = dict(type='path', aliases=['dest', 'destfile', 'name'])
                )
            )
    module.set_fs_attributes_if_different = MagicMock(return_value=True)
    changed, message, diff = True, 'message', True
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == 'message and ownership, perms or SE linux context changed'


# Generated at 2022-06-23 03:54:14.408629
# Unit test for function absent
def test_absent():
    """ Check function absent()
    """
    # Unit tests for function absent
    module = AnsibleModule({'dest': 'tmp/dest',
                            'regexp': 'toto',
                            'search_string': None,
                            'line': 'toto',
                            'backup': False,
                            'args': ['dest', 'regexp', 'search_string', 'line', 'backup']},
                           check_invalid_arguments=False)

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']
    
    args = [module.params[x] for x in module.params['args']]

    # check

# Generated at 2022-06-23 03:54:26.661366
# Unit test for function present
def test_present():
    # test case 2 of function present
    with patch('ansible.module_utils.basic.AnsibleModule._load_params', return_value=''):
        with patch('ansible.module_utils.basic.AnsibleModule.debug') as ad:
            with patch('ansible.module_utils.basic.AnsibleModule.fail_json', return_value=''):
                with patch('ansible_collections.ansible.builtin.plugins.module_utils.lineinfile.open', return_value=True):
                    with patch('ansible.module_utils.basic.AnsibleModule.atomic_move', return_value=True):
                        lineinfile.present(ansible.module_utils.basic.AnsibleModule, '', '', '', '', '', '', '', '', '', '')
                                

# Generated at 2022-06-23 03:54:37.669819
# Unit test for function present
def test_present():

    comm_args = dict(
        regexp=None,
        search_string=None,
        max_search_depth=100,
        backrefs=False,
        firstmatch=True,
        create=False,
        line='',
        insertafter=None,
        insertbefore=None,
        backup=False,
        _diff=True,
        _ansible_check_mode=False,
        unsafe_writes=False,
        validate=None
    )

    test_dict = {
        "dest": "testfile.txt",
        "module": ""
    }

    test_lines = [b'hello there\n', b'its me\n', b'youre looking for\n']

# Generated at 2022-06-23 03:54:43.451694
# Unit test for function present
def test_present():
    dest = 'abc.txt'
    regexp = '^(.*)$'
    search_string = None
    line = 'a'
    insertafter = None
    insertbefore = None
    create = False
    backup = True
    backrefs = False
    firstmatch = False
    check_file_attrs = True
    test_module = AnsibleModule({})
    test_module.tmpdir = 'c:\\'
    test_module._diff = True
    test_module.params['backup'] = backup
    test_module.params['insertafter'] = insertafter
    test_module.params['insertbefore'] = insertbefore
    test_module.params['create'] = create
    test_module.params['regexp'] = regexp
    test_module.params['search_string'] = search_string
   

# Generated at 2022-06-23 03:54:55.403006
# Unit test for function present
def test_present():
    dest = '/dummy/pathname'
    dest_b_lines = to_bytes(dest+'\n')
    regexp = None
    search_string = 'search_string'
    line = 'line'
    insertafter = 'insertafter'
    insertbefore = None
    create = False
    backup = False
    backrefs = False
    firstmatch = False
    SetModuleArgs({'path': dest, 'backup': backup, 'state': 'present', 'line': line, 'firstmatch': firstmatch})

# Generated at 2022-06-23 03:54:58.359426
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'path': '/tmp/test'}, check_invalid_arguments=False)
    b_lines = [to_bytes('test', errors='surrogate_or_strict')]
    dest = to_text('/tmp/test', errors='surrogate_or_strict')
    write_changes(module, b_lines, dest)



# Generated at 2022-06-23 03:55:10.277677
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', aliases=['dest', 'destfile', 'name']),
            mode=dict(type='raw'),
            owner=dict(type='raw'),
            group=dict(type='raw'),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            selevel=dict(type='str'),
            setype=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    ), False, '', None) == ('ownership, perms or SE linux context changed', True)


# Generated at 2022-06-23 03:55:20.170150
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({})
    assert check_file_attrs(module, False, u"", {}) == ("ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, True, u"A message", {}) == ("A message and ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, True, u"A message", True) == ("ownership, perms or SE linux context changed", True)



# Generated at 2022-06-23 03:55:27.197587
# Unit test for function absent
def test_absent():
    lines = "line1\nline2\nline3".splitlines(True)

    # Test to delete a line
    line = "line2"
    new_lines = [l for l in lines if l.strip() != line]
    assert new_lines == "line1\nline3".splitlines(True), "Delete line failed"

    # Test to delete a line with regexp
    regexp = "line"
    new_lines = [l for l in lines if re.search(regexp, l) is None]
    assert new_lines == [], "Delete line failed"

    # Test to delete a line with search_string
    search_string = "line"
    new_lines = [l for l in lines if search_string not in l]
    assert new_lines == [], "Delete line failed"

    # Test

# Generated at 2022-06-23 03:55:31.782711
# Unit test for function check_file_attrs
def test_check_file_attrs():

    # Module import is missing in function because of paramater to function
    # under test.
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    check_file_attrs(module, False, "Message - ", "diff")



# Generated at 2022-06-23 03:55:42.908199
# Unit test for function main

# Generated at 2022-06-23 03:55:51.040479
# Unit test for function main
def test_main():
    """
    Unit test for module
    """
    import sys
    import os
    import json
    import tempfile
    import shutil
    import textwrap
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    temp_dir = tempfile.mkdtemp()
    dest_file = os.path.join(temp_dir, 'destination.txt')

    def setUp():
        # touch destination.txt
        open(dest_file, 'a').close()

    def tearDown():
        # Remove temporary testing directory
        shutil.rmtree(temp_dir)


# Generated at 2022-06-23 03:56:04.714600
# Unit test for function main
def test_main():
    __salt__ = {
        'file.file_exists': MagicMock(return_value=True),
        'file.replace': MagicMock(return_value=True),
        'file.get_diff': MagicMock(return_value={}),
        'file.check_file_attrs': MagicMock(return_value=""),
        'file.backup_file': MagicMock(return_value=""),
        'file.check_managed': MagicMock(return_value=True),
    }

# Generated at 2022-06-23 03:56:18.342531
# Unit test for function absent
def test_absent():
    # Importing the module there and mocking builtin open
    # for the tests in this file
    # makes the test file about three times longer than it could be
    # It could be solved by creating a new module, but that would
    # only move the problem somewhere else since lineinfile
    # is one of the most common modules

    from ansible.utils.path import unfrackpath
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.module_utils.basic import AnsibleModule
    import os

    # mock return values for open
    f_contents = [
        b'Hello world!\n',
        b'Test!\n',
        b'Hello world!\n',
        b'Test!\n',
    ]
   

# Generated at 2022-06-23 03:56:21.858598
# Unit test for function main
def test_main():
  from ansible.module_utils.basic import AnsibleModule
  module = AnsibleModule({},
  
  )
  main()
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:56:32.669586
# Unit test for function absent
def test_absent():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(
        regexp=dict(required=False, type='regexp'),
        path=dict(required=True),
        line=dict(required=False),
        backup=dict(required=False, default=False, type='bool'),
        state=dict(required=False, default='absent', type='str'),
    ))

    class args:
        path = 'file'
        state = 'absent'
        regexp = None
        line = 'line'
        backup = False

    import os

    b_path = to_bytes(args.path, errors='surrogate_or_strict')
    b_line = to_bytes(args.line, errors='surrogate_or_strict')
   

# Generated at 2022-06-23 03:56:46.110908
# Unit test for function present

# Generated at 2022-06-23 03:56:59.750607
# Unit test for function present
def test_present():
    print('test_present')
    # create the mock of tmpfile
    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    tmpfile.close()

    # create the mock of module

# Generated at 2022-06-23 03:57:12.851807
# Unit test for function present

# Generated at 2022-06-23 03:57:24.817067
# Unit test for function main
def test_main():
    from ansible.modules.files.lineinfile import main
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import BytesIO
    import ansible.modules.files.lineinfile
    import os
    import sys
    import shutil
    import tempfile
    import stat
    import json


# Generated at 2022-06-23 03:57:31.894569
# Unit test for function present
def test_present():
    REGEXP = None
    SEARCH_STRING = 'env='
    LINE = 'env=staging'
    INSERTAFTER = None
    INSERTBEFORE = 'BOF'
    CREATE = True
    BACKUP = False
    BACKREFS = False
    FIRSTMATCH = False


# Generated at 2022-06-23 03:57:38.749656
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path'),
            line=dict(),
            regexp=dict(),
            insertafter=dict(),
            insertbefore=dict(),
            backup=dict(type='bool', default='no'),
            create=dict(type='bool', default='no'),
            firstmatch=dict(type='bool', default='yes'),
            backrefs=dict(type='bool', default='no'),
            search_string=dict()
        ),
        nocows=True,
        supports_check_mode=True
    )

    dest = os.path.join(module.tmpdir, 'test1_present')
    regexp = '^FOOBAR'
    search_string = 'FOOBAR'
    line = "FOOBAR=BAZ"
   

# Generated at 2022-06-23 03:57:39.803812
# Unit test for function write_changes
def test_write_changes():
    #TODO
    assert True


# Generated at 2022-06-23 03:57:40.507006
# Unit test for function absent
def test_absent():
    pass



# Generated at 2022-06-23 03:57:48.563716
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'required': False}}, supports_check_mode=True)
    module.params['path'] = '/tmp/test_write_changes'
    module.params['unsafe_writes'] = False
    write_changes(module, None, '/tmp/write_changes_tmp')
    assert False


# Generated at 2022-06-23 03:58:00.650225
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'dest': dict(type='str', required=True),
        'content': dict(type='str', required=True)})
    dest = module.params['dest']
    b_lines = to_bytes(module.params['content'], errors='surrogate_or_strict')
    # write_changes will create temporary file in module.tmpdir
    tmpdir = os.path.realpath(tempfile.mkdtemp())
    module.tmpdir = tmpdir
    module.run_command = run_command
    # now we need to introduce temporary file for validation
    tmpfd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    with os.fdopen(tmpfd, 'wb') as f:
        f.writelines(b_lines)