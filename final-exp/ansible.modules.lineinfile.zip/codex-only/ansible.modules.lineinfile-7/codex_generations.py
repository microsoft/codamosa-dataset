

# Generated at 2022-06-23 03:48:03.877254
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True),
            state = dict(default='present', choices=['present', 'absent']),
            regexp = dict(),
            insertafter = dict(),
            insertbefore = dict(),
            line = dict(required=True),
            create = dict(default=False, type='bool'),
            backup = dict(default=False, type='bool'),
            backrefs = dict(default=False, type='bool'),
            firstmatch = dict(default=False, type='bool'),
            validate = dict()
        )
    )
    # insert the line when the file does not exist
    dest = module.params['path'] = '/tmp/test_present_file_42'
    insertafter = module.params['insertafter'] = 'EOF'


# Generated at 2022-06-23 03:48:11.612218
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule({})
    test_str = "message"
    test_str2, test_bool = check_file_attrs(test_module, True, test_str, True)
    assert(test_str2 == "message and ownership, perms or SE linux context changed")
    assert(test_bool)
    test_str2, test_bool = check_file_attrs(test_module, False, test_str, True)
    assert(test_str2 == "ownership, perms or SE linux context changed")
    assert(test_bool)
    test_str2, test_bool = check_file_attrs(test_module, False, test_str, False)
    assert(test_str2 == "message")
    assert(not test_bool)



# Generated at 2022-06-23 03:48:18.771389
# Unit test for function present
def test_present():
    destination = '/test'
    regexp = 'test'
    search_string = 'test'
    line = 'test'
    insertafter = 'test'
    insertbefore = 'test'
    create = True
    backup = True
    backrefs = True
    firstmatch = True
    module = AnsibleModule({})
    msg = present(module, destination, regexp, search_string, line, insertafter, insertbefore, create, backup, backrefs, firstmatch)
    assert msg == present(module, destination, regexp, search_string, line, insertafter, insertbefore, create, backup, backrefs, firstmatch)


# Generated at 2022-06-23 03:48:26.020944
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = DummyModule()
    module.params = {
        'path': 'test',
    }
    module.run_command = MagicMock(return_value=(0, 'OK', ''))
    changed, message, diff = check_file_attrs(module, False, '', [])
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-23 03:48:31.826426
# Unit test for function absent
def test_absent():
    print("test_absent")
    module = mock.Mock()
    module.check_mode = False
    module._diff = True
    dest = "test_absent_file"
    regexp = None
    search_string = None
    line = "test_absent_line"
    backup = False
    absent(module, dest, regexp, search_string, line, backup)

# Generated at 2022-06-23 03:48:41.873092
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True),
            regexp=dict(required=False),
            search_string=dict(required=False),
            line=dict(required=False),
            state=dict(choices=['exists', 'absent'], default='exists'),
            backup=dict(required=False, default=False, type='bool'),
        ),
    )
    path = module.params.get('path')
    search_string = module.params.get('search_string')
    line = module.params.get('line')
    regexp = module.params.get('regexp')
    state = module.params.get('state')
    backup = module.params.get('backup')


# Generated at 2022-06-23 03:48:54.769059
# Unit test for function check_file_attrs
def test_check_file_attrs():
    """ Unit tests for function check_file_attrs """

    args = dict(
        path='/tmp/testpath',
        owner='testowner',
        group='testgroup',
        seuser=None,
        serole=None,
        setype='testsetype',
        mode='testmode',
    )
    task_vars = dict(
        ansible_diff_mode=None,
        ansible_check_mode=None,
        ansible_file_diff_replacement='\n',
    )
    tmp = {
        'data': {
            'secontext': 'testsetype:testserole:testseuser',
            'mode': 'testmode',
        }
    }

    changed = False
    message = ''

# Generated at 2022-06-23 03:49:02.162397
# Unit test for function present
def test_present():
  final_result = {'changed': False, 'backup': '', 'msg': 'line replaced', 'diff': {'after_header': u'/tmp/01 (file attributes)', 'before_header': u'/tmp/01 (file attributes)'}}
  assert present(final_result, '/tmp/01', '^(.*)Xms(\d+)m(.*)$', None, '\g<1>Xms${xms}m\3', None, None, True, True, True, True) == final_result


# Generated at 2022-06-23 03:49:07.610681
# Unit test for function absent
def test_absent():
    module = AnsibleModule({'dest':"/tmp/test_absent.txt",
                            'backup':"yes",
                            'regexp':"line",
                            'search_string':"line"})
    module.check_mode = True
    with tempfile.NamedTemporaryFile('w+') as f:
        f.write("line1\nline2\nline3\nline4")
        f.flush()
        module.params['dest'] = f.name
        absent(module,
               "/tmp/test_absent.txt",
               "line",
               "line",
               "line",
               "yes")


# Generated at 2022-06-23 03:49:16.430203
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    dest = 'test_file'
    line = 'test_value'
    f = open(dest, 'w+')
    f.write(line)
    f.close()
    absent(module, dest, None, None, line, False)


# Generated at 2022-06-23 03:49:28.881990
# Unit test for function main
def test_main():
    # Mock argument module
    class MockModule(object):
        def __init__(self):
            self.params = {
                'path': str(),
                'state': str(),
                'regexp': str(),
                'search_string': str(),
                'line': str(),
                'insertafter': str(),
                'insertbefore': str(),
                'backrefs': bool(),
                'create': bool(),
                'backup': bool(),
                'firstmatch': bool(),
                'validate': str(),
            }
    module = MockModule()
    # Mock argument parser
    parser = argparse.ArgumentParser(description='Argparse Python module')
    # Mock argument subparsers
    subparsers = parser.add_subparsers()
    # Mock argument definition for subcommand 'config'
    subcommand_config

# Generated at 2022-06-23 03:49:33.320926
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(None, True, "message", "diff") == ("message and ownership, perms or SE linux context changed", True)


# Generated at 2022-06-23 03:49:43.314582
# Unit test for function present
def test_present():
    argument_spec = dict(
        dest = dict(default = None, type = 'str'),
        # dest is required when path is not set
        path = dict(default = None, type = 'str'),
        regexp = dict(),
        search_string = dict(),
        line = dict(),
        insertafter = dict(),
        insertbefore = dict(),
        create = dict(default = False, type = 'bool'),
        backup = dict(default = False, type = 'bool'),
        backrefs = dict(default = False, type = 'bool'),
        firstmatch = dict(default = False, type = 'bool')
    )
    module = AnsibleModule(argument_spec=argument_spec)
    
    # unit test goes here
    # example
    dest = module.params['dest']

# Generated at 2022-06-23 03:49:48.622381
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({})
    b_lines = [b"line 1", b"line 2"]
    dest = "test_file"
    assert not os.path.exists(dest)
    write_changes(module, b_lines, dest)
    assert os.path.isfile(dest)
    with open(dest, "rb") as f:
        assert b_lines == f.readlines()
    os.unlink(dest)



# Generated at 2022-06-23 03:50:00.611903
# Unit test for function present
def test_present():
    # Module is called with all arguments of lineinfile present
    dest = "/tmp/c"
    regexp = None
    search_string = "abc"
    line = "new"
    insertafter = "BOF"
    insertbefore = None
    create = False
    backup = False
    backrefs = True
    firstmatch = False


# Generated at 2022-06-23 03:50:01.073045
# Unit test for function absent
def test_absent():
    pass

# Generated at 2022-06-23 03:50:06.829055
# Unit test for function write_changes
def test_write_changes():
    tmpfd, tmpfile = tempfile.mkstemp()
    with os.fdopen(tmpfd, 'wb') as f:
        f.writelines([b'The line is added\n', b'We added another line\n'])

    assert os.path.exists(tmpfile)
    os.remove(tmpfile)
    assert not os.path.exists(tmpfile)

# Generated at 2022-06-23 03:50:17.758755
# Unit test for function main
def test_main():
    args_dic = {}
    args_dic['path']='/opt/ansible'
    args_dic['state']='present'
    args_dic['regexp']='test_regex'
    args_dic['search_string']='test_search_string'
    args_dic['line']='test_line'
    args_dic['insertafter']='test_insertafter'
    args_dic['insertbefore']='test_insertbefore'
    args_dic['backrefs']=False
    args_dic['create']=False
    args_dic['backup']=False
    args_dic['firstmatch']=False
    args_dic['validate']='test_validate'

# Generated at 2022-06-23 03:50:24.909301
# Unit test for function main
def test_main():

    import os
    import tempfile
    import filecmp
    import pytest
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import mock_open
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import patch
    from ansible_collections.notmintest.not_a_real_collection.plugins.modules import lineinfile

    m_open = mock_open()


# Generated at 2022-06-23 03:50:29.106404
# Unit test for function present
def test_present():

    dest = 'present_test.txt'
    line = 'Hello, World'
    insertafter = 'BOF'
    insertbefore = 'EOF'

    # Test 1, create the file and insert a line at the beginning of the file
    ret = present(module, dest,
                  regexp=None,
                  search_string=None,
                  line=line,
                  insertafter=insertafter,
                  insertbefore=insertbefore,
                  create=True)

    assert ret['changed'] == True, 'Error: returned change should be true'
    assert ret['msg'] == 'line added', 'Error: returned message should be "line added"'

    # Test 2, create the file and insert a line at the end of the file

# Generated at 2022-06-23 03:50:29.664899
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-23 03:50:30.237567
# Unit test for function present
def test_present():
    assert True


# Generated at 2022-06-23 03:50:32.191611
# Unit test for function main
def test_main(): 
    assert main() == None

# Generated at 2022-06-23 03:50:38.333416
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'dest': 'test/test.conf',
        'state': 'present',
        'regexp': '^#(.*)$',
        'line': '#test_present',
        'create': True,
        'backup': True,
    })
    present(module, 'test/test.conf',  '^#(.*)$', None, '#test_present', None, None, True, True, False, False)
    with open('test/test.conf') as f:
        assert '#test_present' in f.read()

# Generated at 2022-06-23 03:50:44.211220
# Unit test for function write_changes
def test_write_changes():
    test_file = open("test_file", "wb")
    test_file.write(b'test\n')
    test_file.close()
    test_file = open("test_file", "rb")
    lines = test_file.readlines()
    test_file.close()
    os.remove("test_file")


# Generated at 2022-06-23 03:50:54.618248
# Unit test for function main
def test_main():
    import tempfile

    # Test 1, state = absent and path does not exist.
    ins, outs = module.args_from_stdin(
        dict(
            path = tempfile.mktemp(),
            state = 'absent',
            regexp = None,
            search_string = None,
            line = 'line not found',
            insertafter = None,
            insertbefore = None,
            create = False,
            backup = False,
            backrefs = False,
            firstmatch = False,
            validate = None,
        ))
    try:
        main()
        assert True == outs['changed']
        os.unlink(tempfile.mktemp())
    except:
        assert False

    # Test 2, state = present and path does not exist.

# Generated at 2022-06-23 03:51:04.771154
# Unit test for function check_file_attrs
def test_check_file_attrs():

    class FakeModule(object):

        def __init__(self):
            self.tmpdir = ''
            self.params = {
                'dest': '/root/unittest',
                'unsafe_writes': True
            }

        def fail_json(self, *args, **kwargs):
            pass

        def atomic_move(self, *args, **kwargs):
            pass

        def load_file_common_arguments(self, *args, **kwargs):
            return None

        def set_fs_attributes_if_different(self, *args, **kwargs):
            return True

    module = FakeModule()

    result = check_file_attrs(module, False, 'test message', 'test diff')
    assert result[0] == 'test message and ownership, perms or SE linux context changed'


# Generated at 2022-06-23 03:51:06.258417
# Unit test for function write_changes
def test_write_changes():
    assert True

# in 2.4 we checked for the destination file being empty and then we would always
# replace it with the template. This did not permit an empty file to be used as a
# starting point.

# Generated at 2022-06-23 03:51:16.676191
# Unit test for function present
def test_present():
    changed = True
    msg = 'line added'
    backupdest = ""
    diff = {'before': '',
            'after': '',
            'before_header': '%s (content)' % dest,
            'after_header': '%s (content)' % dest}

    b_dest = to_bytes(dest, errors='surrogate_or_strict')
    if not os.path.exists(b_dest):
        if not create:
            module.fail_json(rc=257, msg='Destination %s does not exist !' % dest)
        b_destpath = os.path.dirname(b_dest)

# Generated at 2022-06-23 03:51:26.049584
# Unit test for function absent
def test_absent():
    print ("Testing function `absent`")
    lines = [b'# test line\n', b'# a test line\n', b'test line\n']
    b_dest = os.path.join(os.path.dirname(os.path.abspath(__file__)), b"file_append_test")
    write_changes(None, lines, b_dest)
    regexp = '^test line$'
    absent(None, b_dest, regexp, None, None, False)
    lines = [b'# test line\n', b'# a test line\n', b'test line\n']
    write_changes(None, lines, b_dest)
    search_str = 'line'
    absent(None, b_dest, None, search_str, None, False)

# Generated at 2022-06-23 03:51:36.694993
# Unit test for function write_changes
def test_write_changes():
    src = b'123\n456\n789'
    module = AnsibleModule(argument_spec={'path': {'type': 'path', 'required': True}})
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    os.write(tmpfd, src)
    os.close(tmpfd)
    validate = None
    write_changes(module, src, tmpfile)
    with open(tmpfile, 'rb') as f:
        returned = f.read()
    assert returned == src
    os.remove(tmpfile)


# Generated at 2022-06-23 03:51:44.685486
# Unit test for function check_file_attrs
def test_check_file_attrs():
    with open("/tmp/test.txt", "w") as f:
        f.write("Testing\n")
    module.params = {}
    module.params['path'] = "/tmp/test.txt"
    module.params['owner'] = "root"
    module.params['group'] = "root"
    module.params['mode'] = "0644"
    module.params['seuser'] = "root"
    module.params['serole'] = "root"
    module.params['setype'] = "root"
    module.params['selevel'] = "root"
    module.params['unsafe_writes'] = True
    changed, message, diff = check_file_attrs(module, False, "", "")
    assert message == "ownership, perms or SE linux context changed"



# Generated at 2022-06-23 03:51:57.383321
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    module.params = dict(
        path='/path/to/file',
        seuser='user_u',
        serole='role_r',
        setype='type_t',
        serange='s0',
        selevel='s0',
    )
    # ensure no change
    result = dict(
        msg='',
        changed=False)
    attrs = dict(
        seuser='user_u',
        serole='role_r',
        setype='type_t',
        serange='s0',
        selevel='s0',
    )
    ret = check_file_attrs(module, False, "", attrs)
    assert ret == ('', False)

    # verify change

# Generated at 2022-06-23 03:52:08.849331
# Unit test for function check_file_attrs
def test_check_file_attrs():
    ''' test how check_file_attrs handles changes'''


# Generated at 2022-06-23 03:52:18.077541
# Unit test for function write_changes
def test_write_changes():
    test_path = b'/tmp/test_file'
    test_data = b'Hello, Ansible user!'
    test_validate = b'/usr/bin/false'
    module = AnsibleModule({'validate': test_validate, 'dest': test_path, 'backup': False, 'unsafe_writes': False})
    test_lines = [test_data]
    write_changes(module, test_lines, test_path)
    with open(test_path, 'rb') as f:
        data = f.read()
    assert data == test_data
    os.remove(test_path)



# Generated at 2022-06-23 03:52:20.096409
# Unit test for function write_changes
def test_write_changes():
    assert False

# import module snippets
from ansible.module_utils.basic import AnsibleModule



# Generated at 2022-06-23 03:52:33.007476
# Unit test for function main
def test_main():
    from .__main__ import main
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves.urllib import parse as urlparse
    args = ImmutableDict(dict(create=False, path='/tmp/myfile', state='present'))
    sys.modules['ansible.module_utils.basic'] = basic
    sys.modules['ansible.module_utils._text'] = to_bytes
    sys.modules['ansible.module_utils.common.collections'] = ImmutableDict
    sys.modules['ansible.module_utils.six'] = StringIO

# Generated at 2022-06-23 03:52:37.555588
# Unit test for function absent
def test_absent():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    import os

    testdir = '/tmp/ansible_lineinfile_test'
    actual_path = os.path.join(testdir, 'actual_file')
    # Remove the directory and file if they previously exist (from a previous test)
    shutil.rmtree(testdir, True)

    # Create the test directory
    os.mkdir(testdir)

    # Create the test file
    with open(actual_path, 'w') as f:
        f.write("Ansible lineinfile module test file\n")
        f.write("   - test line\n")

# Generated at 2022-06-23 03:52:47.926649
# Unit test for function absent
def test_absent():
    module = AnsibleModule({
        'path': '/foo/bar',
        'state': 'absent',
        'line': 'test',
        'backup': False,
    })
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.read_file = read_file
    module.write_file = write_file
    module.check_mode = False
    os.path.exists = os.path.exists
    mtime = os.path.getmtime(to_bytes('/foo/bar'))
    with open(to_bytes('/foo/bar'), 'wb') as f:
        f.write(to_bytes('test\n'))
    absent(module, '/foo/bar', None, None, 'test', False)

# Generated at 2022-06-23 03:52:50.265257
# Unit test for function present
def test_present():
    pass



# Generated at 2022-06-23 03:52:53.801780
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(AnsibleModule(), False, 'test message', '') == ("test message and ownership, perms or SE linux context changed", True)



# Generated at 2022-06-23 03:53:04.552743
# Unit test for function present
def test_present():
    from ansible.module_utils import basic
    my_module = basic.AnsibleModule(argument_spec=dict(path=dict(required=True, type='str'),
                                                       state=dict(required=False, default='present', choices=['present', 'absent']),
                                                       regexp=dict(required=False),
                                                       line=dict(required=True),
                                                       insertbefore=dict(required=False, default='EOF'),
                                                       insertafter=dict(required=False),
                                                       create=dict(required=False, type='bool', default=False),
                                                       backup=dict(required=False, type='bool', default=False),
                                                       validate=dict(required=False),
                                                       )
                                   )

# Generated at 2022-06-23 03:53:10.849058
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(module, True, "message", True) == ("message and ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, False, "message", True) == ("ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, True, "message", False) == ("message", True)
    assert check_file_attrs(module, False, "message", False) == ("message", False)



# Generated at 2022-06-23 03:53:22.172994
# Unit test for function absent
def test_absent():
    # backup file
    if os.path.exists(dest):
        shutil.copy2(dest, backup)

    # missing required arguments
    no_dest = module_args.copy()
    no_dest['dest'] = None
    rc, out, err = module_execute(no_dest)
    assert rc == 256
    assert 'cannot be empty' in out
    assert 'must be set' in out

    # no change
    rc, out, err = module_execute(module_args)
    assert rc == 0
    assert out.find(' no change') != -1

    # one change
    rc, out, err = module_execute(module_args)
    assert rc == 0
    assert out.find(' changed') != -1
    assert out.find(' 1 line(s) removed') != -1

    # reset

# Generated at 2022-06-23 03:53:25.691944
# Unit test for function main
def test_main():
    assert __main__.main() == None


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:53:31.573298
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({
        'atomic_move': lambda src, dest, unsafe_writes: (False, "test_write_changes"),
        'tmpdir': tempfile.gettempdir(),
        'path': '',
        'unsafe_writes': False,
        })
    write_changes(module, ['ok'], '')



# Generated at 2022-06-23 03:53:34.563928
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.atomic_move = lambda tmpfile, dest, unsafe_writes: None
    module.params = {}
    module.params['validate'] = None
    content = b'foo\nbar\n'
    tmpfd, tmpfile = tempfile.mkstemp(dir='.')
    with os.fdopen(tmpfd, 'wb') as f:
        f.write(content)
    write_changes(module, content, tmpfile)



# Generated at 2022-06-23 03:53:43.467779
# Unit test for function main
def test_main():
  test1_module=dict(
      state='present',
      path='/tmp/kubeadm_1.8.5_amd64.deb',
      line='deb https://apt.kubernetes.io/ kubernetes-xenial main',
      backup=True,
      search_string='kubernetes-xenial')
  test1_module_name = '/tmp/ansible_lineinfile_payload_p1iWmb'
  test1_module_args = ''

# Generated at 2022-06-23 03:53:50.841278
# Unit test for function present
def test_present():

    dest = "test"

    config_content_b="""
#testing
#testing
#testing
#[a-z]
ipv4.address=192.168.1.10
ipv4.netmask=24
ipv4.gateway=192.168.1.1
ipv4.dns1=8.8.8.8
ipv4.dns2=8.8.4.4
"""

# Generated at 2022-06-23 03:54:03.734641
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest = dict(type='path'),
            regexp = dict(aliases=['pattern']),
            line = dict(),
            state = dict(default='present'),
            search_string = dict(),
            backup = dict(default=False, type='bool'),
        ),
        supports_check_mode=True
    )

    dest = '/tmp/bogus_file_path'
    regexp = '^#{1} VARIABLE'
    line = '# VARIABLE'

    m = MagicMock(side_effect=[[], [line]])

# Generated at 2022-06-23 03:54:10.155005
# Unit test for function main
def test_main():
    fft = AnsibleExitJson(changed=False, msg='file not present')
    assert fft.changed == False
    assert fft.msg == 'file not present'



# Generated at 2022-06-23 03:54:12.757797
# Unit test for function main
def test_main():
    os.system('ansible-playbook ini_file_test.yml')

if __name__ == '__main__':
    main()
    test_main()

# Generated at 2022-06-23 03:54:13.726127
# Unit test for function main
def test_main():
    assert True

# unit test for function present

# Generated at 2022-06-23 03:54:21.854053
# Unit test for function write_changes
def test_write_changes():
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule
    import pytest
    import tempfile
    import os
    import sys

    # stub module object for tests
    b_python2 = sys.version_info[0] == 2
    text = to_text if b_python2 else to_native
    path = u'test' if b_python2 else 'test'
    b_path = to_bytes(path) if b_python2 else b'test'

    class StubModule(object):
        def __init__(self, params, tmpdir):
            self.params = params
            self.tmpdir = tmpdir
            self.unsafe_writes = params.get('unsafe_writes', True)

        def fail_json(self, **kwargs):
            raise

# Generated at 2022-06-23 03:54:34.069820
# Unit test for function main
def test_main():
    import os
    import tempfile
    import time
    import shlex
    import shutil
    import filecmp
    import subprocess
    import random
    import string
    import json


# Generated at 2022-06-23 03:54:43.640094
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.six.moves import StringIO

    import os
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()
    dest = os.path.join(tmpdir, 'foo')
    src = os.path.join(tmpdir, 'foo.in')

    with open(src, 'w') as f:
        f.write('foo\nbar\n')

    m = AnsibleModule(argument_spec={'validate': dict(required=False)},
                      tmpdir=tmpdir,
                      supports_check_mode=True)
    m.params['path'] = dest
    m.params['dest'] = dest
    m.params['backup'] = False
    m.params['unsafe_writes'] = False


# Generated at 2022-06-23 03:54:48.635837
# Unit test for function present
def test_present():
    test_module=importlib.import_module('test_file')
    my_test1=test_module.TestFileModule()
    my_test1.test_present()

# absent

# Generated at 2022-06-23 03:54:55.215593
# Unit test for function main
def test_main():
    params = {'backrefs': False, 'backup': False, 'create': False, 'dest': '', 'firstmatch': False, 'insertafter': None, 'insertbefore': None, 'line': '', 'path': '', 'regexp': '', 'search_string': '', 'state': ''}

# Generated at 2022-06-23 03:55:09.200907
# Unit test for function absent
def test_absent():
    import os
    import tempfile
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True),
            regexp = dict(type='str', required=False, default=None),
            search_string = dict(type='str', required=False, default=None),
            line = dict(type='str', required=False, default=None),
            backup = dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=True,
    )
    path = tempfile.mkstemp()[1]
    # pass all arguments
    module.params['path'] = path
    module.params['search_string'] = 'testing'
    module.params['line'] = 'testing'
    module.params['regexp'] = 'testing'

# Generated at 2022-06-23 03:55:18.710917
# Unit test for function main

# Generated at 2022-06-23 03:55:19.838538
# Unit test for function write_changes
def test_write_changes():
    pass


# Generated at 2022-06-23 03:55:20.507689
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-23 03:55:27.274896
# Unit test for function absent
def test_absent():
    import ansible.module_utils.basic
    f1 = open("./test_file.txt","w+")
    f1.write("Example Text")
    f1.close()
    f2 = open("./test_file2.txt","w+")
    f2.write("Example Text")
    f2.close()
    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict(
            dest=dict(required=True),
            regexp=dict(required=False),
            search_string=dict(required=False),
            line=dict(required=False),
            backup=dict(),
            )
        )
    m.params = {'dest': 'test_file.txt', 'regexp': 'Example Text', 'backup': False}
    changed, found

# Generated at 2022-06-23 03:55:36.943227
# Unit test for function present

# Generated at 2022-06-23 03:55:41.260024
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed, msg, diff = False, "", {}
    msg, changed = check_file_attrs(module, changed, msg, diff)
    assert msg == "ownership, perms or SE linux context changed"
    assert changed


# Generated at 2022-06-23 03:55:45.901344
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import *


# Generated at 2022-06-23 03:55:48.400936
# Unit test for function absent
def test_absent():
    pass



# Generated at 2022-06-23 03:55:55.245715
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(None, True, "message", "diff") == (
        'message and ownership, perms or SE linux context changed', True)
    assert check_file_attrs(None, False, "message", "diff") == (
        'ownership, perms or SE linux context changed', True)
    assert check_file_attrs(None, True, "message", None) == (
        'message and ownership, perms or SE linux context changed', True)
    assert check_file_attrs(None, False, "message", None) == (
        'message', False)



# Generated at 2022-06-23 03:56:06.789167
# Unit test for function write_changes
def test_write_changes():
    """Fails with a fake module"""
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            regexp=dict(type='str', required=True),
            line=dict(type='str', required=True),
            backrefs=dict(type='bool', required=False),
            state=dict(type='str', default='present', choices=['absent', 'present']),
            insertafter=dict(type='str', default=''),
            insertbefore=dict(type='str', default=''),
            create=dict(type='bool', default=False)
        ),
        supports_check_mode=False
    )
    module.run_command = lambda *args, **kwargs: (0, '', '')

# Generated at 2022-06-23 03:56:07.643729
# Unit test for function check_file_attrs
def test_check_file_attrs():
    pass


# Generated at 2022-06-23 03:56:16.711385
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            tmpdir=dict(type='path')
        ),
        supports_check_mode=True
    )
    fd, tmpfile = tempfile.mkstemp(dir=module.params.get('tmpdir'))
    os.close(fd)
    with tempfile.NamedTemporaryFile(dir=module.params.get('tmpdir'), delete=False) as f:
        dest = f.name
    write_changes(module, b"", dest)



# Generated at 2022-06-23 03:56:24.947497
# Unit test for function write_changes
def test_write_changes():
    test_vars = {
        'tmpdir': '/tmp',
        'validate': '',
        'unsafe_writes': False,
    }
    test_params = {
        'path': '/etc/hosts',
        'line': '127.0.0.1 localhost',
    }
    test_module = AnsibleModule({}, **test_params)
    test_module.tmpdir = test_vars['tmpdir']
    test_module.params = test_params
    test_module.check_mode = False
    test_module.run_command = lambda x: (0, "", "")

    test_lines = ['#test1\n',
                  'test2\n',
                  'test3\n']

    # Should write tmp file and then move

# Generated at 2022-06-23 03:56:31.286316
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class Module:
        def atomic_move(self,*args,**kwargs):
            pass
        def set_fs_attributes_if_different(self,*args,**kwargs):
            return False
        def load_file_common_arguments(self,*args,**kwargs):
            return dict()
    m = Module()
    changed, message, diff = False, '', ''
    message, changed = check_file_attrs(m, changed, message, diff)
    assert message == ''
    assert changed == False



# Generated at 2022-06-23 03:56:41.624452
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True,)
    attrs = {"__name__": "main.mymodule"}
    module.params = {}
    module.params['_ansible_verbosity'] = 1
    module.params['_ansible_debug'] = True
    module.params['_ansible_socket'] = None
    module.params['_ansible_shell_executable'] = None
    module.params['_ansible_selinux_special_fs'] = None
    module.params['_ansible_syslog_facility'] = "LOG_USER"
    module.params['_ansible_remote_tmp'] = "/tmp"
    module.params['_ansible_keep_remote_files'] = False
    module.params['_ansible_no_log'] = False


# Generated at 2022-06-23 03:56:54.026586
# Unit test for function write_changes
def test_write_changes():
    '''This function is invoked by the unit tests'''

    import tempfile
    import os
    from ansible.module_utils._text import to_bytes

    my_path = tempfile.mktemp(suffix='.txt')
    b_lines = [b'first line\n', b'second line\n']
    # Write out the lines to a file and check if the function writes
    # the same lines back
    with open(my_path, 'wb') as my_file:
        my_file.writelines(b_lines)
    dest = tempfile.mktemp(suffix='.txt')
    write_changes(AnsibleModule(argument_spec={}), b_lines, dest)
    assert (os.path.isfile(dest))

# Generated at 2022-06-23 03:57:05.846571
# Unit test for function present
def test_present():
    dest = '/tmp/test_present.txt'
    with open(dest, 'a') as f:
        f.write('This is a test\n')
        f.write('This is a test2\n')
        f.write('This is a test3\n')
        f.write('This is a test4\n')
        f.write('This is a test4\n')

    regexp = None
    regexp_extra_args = {}
    search_string = None
    search_string_extra_args = {}
    if search_string:
        search_string_extra_args = {
            'search_string': search_string,
            'ignore_missing': False,
            'backup': False,
            'unsafe_writes': True
        }
    if regexp:
        regexp_extra

# Generated at 2022-06-23 03:57:12.901275
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            unsafe_writes=dict(default=False, type='bool')
        ),
    )
    function_result = check_file_attrs(module,True,"manish","manish")
    assert function_result == ('manish and ownership, perms or SE linux context changed', True)



# Generated at 2022-06-23 03:57:24.862462
# Unit test for function main
def test_main():
    b_path = to_bytes('/tmp/foo', errors='surrogate_or_strict')
    search_string = 'test'
    backup = False
    regexp = None
    backrefs = False
    firstmatch = False
    create = False
    line = 'test'
    ins_bef = None
    ins_aft = 'EOF'

    # This does not get called in the regular ansible process,
    # but there are unit tests for this function which do call it.

    with open(b_path, 'wb') as f:
        f.write(b"test\n")
        f.write(b"test test\n")
        f.write(b"test test\n")
        f.write(b"test test\n")


# Generated at 2022-06-23 03:57:25.921950
# Unit test for function main
def test_main():
    from ansible.modules.files import lineinfile
    lineinfile.main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:57:29.668431
# Unit test for function absent
def test_absent():
    assert present(module, dest, regexp, search_string, line, insertafter, insertbefore, create,
                   backup, backrefs, firstmatch) == (False, 0, '', '', [])


# Generated at 2022-06-23 03:57:36.293575
# Unit test for function absent
def test_absent():
    src  = "testfile"
    dest = "testfile1"
    regexp = "test"
    line = "Test"

    f = open(src,"w")
    f.write(line)
    f.close()

    if os.path.exists(dest):
        os.remove(dest)

    os.rename(src,dest)
    assert os.path.exists(dest)
    assert not os.path.exists(src)

    class ModuleTest(object):
        def __init__(self,params):
            self.params = params
            self.changed = False
            self.fail_json = None
            self.exit_json = None
            self.backup_local = None
            self._diff = None
            self.check_mode = False


# Generated at 2022-06-23 03:57:38.449202
# Unit test for function present
def test_present():
    assert present(module, dest, regexp, search_string, line, insertafter, insertbefore, create,
                   backup, backrefs, firstmatch)

# Generated at 2022-06-23 03:57:41.608214
# Unit test for function present
def test_present():
    assert to_text(present("module","dest","regexp","search_string","line","insertafter","insertbefore","create","backup","backrefs","firstmatch")) != 0


# Generated at 2022-06-23 03:57:56.349923
# Unit test for function main
def test_main():
    import os
    import tempfile

    #
    # patch open() so we can mock the file handle
    #
    orig_open = __builtin__.open
