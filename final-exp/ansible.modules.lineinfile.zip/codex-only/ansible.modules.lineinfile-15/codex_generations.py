

# Generated at 2022-06-23 03:48:04.006174
# Unit test for function absent
def test_absent():
    module = AnsibleModule(argument_spec={
        'dest': dict(required=True),
        'regexp': dict(required=False),
        'search_string': dict(required=False),
        'line': dict(required=False),
        'backup': dict(required=False, type='bool'),
        'user': dict(required=False),
        'group': dict(required=False),
        'mode': dict(required=False),
        'follow': dict(default=False, type='bool'),
        'selevel': dict(required=False),
        'serole': dict(required=False),
        'setype': dict(required=False),
        'secontext': dict(required=False),
    })
    module._diff = True
    module.check_mode = True
    module.params['dest']

# Generated at 2022-06-23 03:48:12.608054
# Unit test for function present
def test_present():
    dest = "test_file.txt"
    regexp = "test"
    search_string ="test"
    line = "test"
    insertafter ="test"
    insertbefore ="test"
    create = True
    backup = True
    backrefs= False
    firstmatch = False
    try:
        present(dest, regexp, search_string, line, insertafter, insertbefore, create,
            backup, backrefs, firstmatch)
    except:
        pass

# Generated at 2022-06-23 03:48:21.284874
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Attempt to obtain module object from Ansible
    fail_msg = 'Failed initializing module object from Ansible'
    module = AnsibleModule(argument_spec={})
    test_changed = True
    expected_changed = True
    test_message = "test string"
    expected_message = "test string and ownership, perms or SE linux context changed"
    # Run function we are testing
    test_message, test_changed = check_file_attrs(module, test_changed, test_message, diff=False)
    # Check whether we got the expected results
    assert test_message == expected_message, fail_msg
    assert test_changed == expected_changed, fail_msg

# Get value from line

# Generated at 2022-06-23 03:48:26.417349
# Unit test for function check_file_attrs
def test_check_file_attrs():
    my_module = AnsibleModule({'a': 'b'})
    changed, message = check_file_attrs(my_module, True,'message', 'diff')
    assert message == "message and ownership, perms or SE linux context changed"


# Generated at 2022-06-23 03:48:38.909615
# Unit test for function main
def test_main():
    from ansible.errors import AnsibleError
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

# Generated at 2022-06-23 03:48:53.482603
# Unit test for function absent
def test_absent():
    dest="/tmp/add_line_test"
    regexp=None
    line="x=1\n"
    backup=False
    backupdest="none"
    diff={'before_header': '/tmp/add_line_test (content)', 'before': '', 'after_header': '/tmp/add_line_test (content)', 'after': ''}
    msg='0 line(s) removed'
    found=0
    if os.path.isfile(dest):
        os.remove(dest)
    with open(dest, "w") as fp:
        fp.write("x=1\nx=2\nx=3\n")
    (diff, found, msg, backupdest) = absent(dest, regexp, line, backup)
    assert(diff == diff)

# Generated at 2022-06-23 03:49:04.178944
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule as ansible_ansible_module
    from ansible.module_utils.basic import AnsibleExitJson as ansible_ansible_exit_json
    from ansible.module_utils.basic import AnsibleFailJson as ansible_ansible_fail_json
    from ansible.module_utils.basic import AnsibleModule as ansible_ansible_module_get_module_path
    from ansible.module_utils.basic import get_platform as ansible_ansible_module_get_platform


# Generated at 2022-06-23 03:49:10.853132
# Unit test for function main
def test_main():
    class TestModule:
        def fail_json(self, **kwargs):
            assert False

        def exit_json(self, **kwargs):
            assert True

    module = TestModule()
    setattr(module, "params", {})
    try:
        main()
    except SystemExit:
        pass


# Generated at 2022-06-23 03:49:13.241240
# Unit test for function absent
def test_absent():
    assert absent(module, dest, regexp, search_string, line, backup) == 0


# Generated at 2022-06-23 03:49:18.737648
# Unit test for function main
def test_main():
    """ Unit test for function main """
    from ansible.module_utils.common.file import file_common_argument_spec
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 03:49:19.967797
# Unit test for function write_changes
def test_write_changes():
    assert False


# Generated at 2022-06-23 03:49:32.015744
# Unit test for function write_changes
def test_write_changes():
    """Check write_changes()"""
    module = AnsibleModule(argument_spec={}, supports_check_mode=True, check_invalid_arguments=False)
    module.atomic_move = lambda src, dest: None
    module.fail_json = lambda: None
    module.params = {
        'validate': '',
        'unsafe_writes': False,
        '_ansible_tmpdir': '/private/tmp/ansible-tmp-1569688511.0-57589078981112',
    }


# Generated at 2022-06-23 03:49:42.722462
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
        )
    )

    args = dict(args=dict(dest='testfile',
                          line='line',
                          regexp='regexp'))


# Generated at 2022-06-23 03:49:48.560032
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

# Generated at 2022-06-23 03:50:00.514732
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True, bypass_checks=True)
    lines = [b'# This is test file\n',
             b'# This is line 2\n',
             b'# This is line 3\n']

    test_file = 'test_file'
    test_dest = os.path.join(tempfile.gettempdir(), test_file)
    with open(test_file, 'w') as test_fd:
        test_fd.writelines(lines)

    write_changes(module, lines, test_dest)
    with open(test_file, 'r') as test_fd:
        test_lines = [to_bytes(item) for item in test_fd.readlines()]

# Generated at 2022-06-23 03:50:12.492568
# Unit test for function write_changes
def test_write_changes():
    import platform
    if platform.machine() == 'Power9':
        # Force to skip Unit test, because of the high risk of breaking the unit test in Travis
        return
    module = AnsibleModule(
        argument_spec = dict(
            dest = dict(type='str'),
        ),
    )
    b_lines = [b"a\nb\nc"]
    dest = "/tmp/ansible.unittest_file"
    write_changes(module, b_lines, dest)

    f = open(dest, "rb")
    b_content = f.read()
    f.close()
    os.remove(dest)
    assert b_lines == b_content.splitlines(True)
    assert b_lines != b_content
    assert b_lines[0] == b_content[0:2]


# Generated at 2022-06-23 03:50:13.078907
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-23 03:50:21.788169
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True),
            search_string=dict(default=None),
            regexp = dict(default=None),
            line = dict(required=True),
            insertafter = dict(default=None),
            insertbefore = dict(default=None),
            backup = dict(default=False, type='bool'),
            create = dict(default=False, type='bool'),
            validate = dict(default=None),
            backrefs = dict(default=False, type='bool'),
            firstmatch = dict(default=False, type='bool'),
        )
    )

    dest = '/tmp/testfile'
    regexp = None
    search_string = None
    line = 'testline'
    insertafter = None
    insertbefore = None


# Generated at 2022-06-23 03:50:32.010159
# Unit test for function main
def test_main():
    args = dict(
        path='/file3.txt',
        state='present',
        insertafter='BOF',
    )

# Generated at 2022-06-23 03:50:39.735701
# Unit test for function write_changes
def test_write_changes():
    import shutil
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_native
    tmpdir = tempfile.mkdtemp()
    lines = [to_bytes('Example line with no CR', errors='surrogate_or_strict'),
             to_bytes('Example line with a CR\n', errors='surrogate_or_strict'),
             to_bytes('Example line with a CRLF\r\n', errors='surrogate_or_strict')]
    filename = to_native(os.path.join(tmpdir, 'tmpfile'), errors='surrogate_or_strict')

# Generated at 2022-06-23 03:50:43.936740
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'tmpdir':{'required':True}, 'validate':{}, 'unsafe_writes':{}}, check_invalid_arguments=False)
    b_lines = to_bytes("123456789ABCDEFG\r\nHIJKLMNOP")
    dest = tempfile.mkstemp(dir=module.params['tmpdir'])
    write_changes(module, b_lines, dest)
    with open(dest[1], 'rb') as f:
        result = f.read()
        assert result == b_lines


# Generated at 2022-06-23 03:50:48.854885
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        "path": {"type": "str", "default": "/tmp/testfile", "required": True},
        "line": {"type": "str", "default": "192.168.1.99 foo.lab.net foo", "required": True},
        "validate": {"type": "str", "default": "", "required": False},
        "tmpdir": {"type": "str", "default": "/tmp", "required": False}
    }, check_invalid_arguments=False,
                           supports_check_mode=True)


# Generated at 2022-06-23 03:50:59.296935
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            mode=dict(type='raw'),
            owner=dict(type='raw'),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            selevel=dict(type='str'),
            setype=dict(type='str'),
            path=dict(type='path'),
            unsafe_writes=dict(type='bool', default=False),
        )
    )
    message = "Test message"
    changed = False
    diff = {'before': 'something',
            'after': 'something else'}
    module.set_fs_attributes_if_different = MagicMock(return_value=True)

# Generated at 2022-06-23 03:51:07.055462
# Unit test for function present

# Generated at 2022-06-23 03:51:11.344410
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'path'},
        'owner': {'type': 'str'},
        'group': {'type': 'str'},
        'mode': {'type': 'str'},
        'selevel': {'type': 'str'},
        'serole': {'type': 'str'},
        'setype': {'type': 'str'},
        'seuser': {'type': 'str'},
    })
    assert check_file_attrs(module, True, "test_msg", False) == ("test_msg and ownership, perms or SE linux context changed", True)



# Generated at 2022-06-23 03:51:14.853057
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_m = AnsibleModule({'foo': {'path': '/path/to/file', 'owner': 'new_owner'}})
    test_m.set_fs_attributes_if_different({'path': '/path/to/file', 'owner': 'new_owner'}, False)
    assert True



# Generated at 2022-06-23 03:51:26.636572
# Unit test for function write_changes
def test_write_changes():
    """Unit test for function write_changes."""
    import tempfile
    import shutil
    import os
    import unittest

    class TestWriteChanges(unittest.TestCase):
        """Unit test for function write_changes."""

        def setUp(self):
            self.module = AnsibleModule({})
            self.module._debug = False
            self.module.params['validate'] = None
            self.module.tmpdir = tempfile.mkdtemp()
            self.tmpfile = tempfile.mkstemp(dir=self.module.tmpdir)[1]
            with open(self.tmpfile, 'w+') as f:
                f.writelines(['abc\n', 'def\n'])


# Generated at 2022-06-23 03:51:39.201232
# Unit test for function check_file_attrs
def test_check_file_attrs():

    from ansible.module_utils.common.file import is_follow_capability
    from ansible.module_utils.common.file import is_follow_fast
    import os
    import pytest
    from units.modules.utils import set_module_args, exit_json, fail_json, AnsibleExitJson
    import tempfile
    import shutil
    import sys

    if sys.version_info[:2] >= (3, 0):
        xrange = range

    if not is_follow_capability():
        pytestmark = pytest.mark.skip('symlinks not supported')
    if not is_follow_fast():
        pytestmark = pytest.mark.skip('symlinks not supported')

    def test_directory_follow(tempdir):
        newpath = tempdir / 'link_to_dir'
       

# Generated at 2022-06-23 03:51:42.850738
# Unit test for function absent
def test_absent():
    ret = absent(module, dest, regexp, search_string, line, backup)
    assert 'changed' in ret
    assert 'found' in ret
    assert 'msg' in ret

# Generated at 2022-06-23 03:51:55.631545
# Unit test for function present

# Generated at 2022-06-23 03:52:01.919148
# Unit test for function write_changes
def test_write_changes():
    from ansible.modules.files.file import File
    from ansible.module_utils.facts.system.selinux import set_context_if_different
    module = AnsibleModule(
        argument_spec={
            'path': {'type': 'path', 'required': True},
            'unsafe_writes': {'type': 'bool', 'default': False}
        }
    )
    lines = [b"192.168.1.99 foo.lab.net foo\n"]
    dest = "/tmp/testfile"
    write_changes(module, lines, dest)
    assert len(lines) == 1, "Failed to create file"


# Generated at 2022-06-23 03:52:12.759517
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True),
            insertbefore=dict(default=None),
            insertafter=dict(default=None),
            line=dict(required=True),
            regexp=dict(default=None),
            search_string=dict(default=None),
            backup=dict(default=False, type='bool'),
            create=dict(default=False, type='bool'),
            validate=dict(default=None),
            backrefs=dict(default=True, type='bool'),
            firstmatch=dict(default=False, type='bool')
        )
    )
    dest = "/tmp/afile"
    line = "testline1"
    insertafter = "testline"
    regexp = None
    search_string = None
    create

# Generated at 2022-06-23 03:52:25.200938
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    test_module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'owner': {'type': 'str'},
        'group': {'type': 'str'},
        'mode': {'type': 'str', 'choices': ['absent', 'present']},
        'seuser': {'type': 'str'},
        'serole': {'type': 'str'},
        'setype': {'type': 'str'},
        'selevel': {'type': 'str'},
    })
    test_module.params['backup'] = 'yes'
    fd, test_file = tempfile.mkstemp(dir=test_module.tmpdir)

# Generated at 2022-06-23 03:52:33.600150
# Unit test for function write_changes
def test_write_changes():
    from ansible.modules.source_control.git import AtomicWrite

    module = AnsibleModule(
        argument_spec={'validate': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    AtomicWrite.atomic_move = lambda *args, **kwargs: False
    module.tmpdir = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../../..')
    dest = tempfile.mkstemp(dir=module.tmpdir)[1]
    write_changes(module, [], dest)



# Generated at 2022-06-23 03:52:34.534582
# Unit test for function write_changes
def test_write_changes():
    return True



# Generated at 2022-06-23 03:52:44.758823
# Unit test for function main
def test_main():
    # Set up mock inputs
    module = mock.Mock()
    path = 'path'
    regexp = 'regexp'
    search_string = 'search_string'
    line = 'line'
    create = True
    backup = True
    backrefs = True
    firstmatch = True

    # Call function
    main(module, path, regexp, search_string, line, create, backup, backrefs, firstmatch)

    # Check for no exit or fail
    assert module.exit_json.called
    assert module.fail_json.called == False


# Generated at 2022-06-23 03:52:46.553962
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleFailJson):
        main()


# Generated at 2022-06-23 03:52:50.028897
# Unit test for function main
def test_main():
    main()


# Unit test execution
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 03:52:56.280691
# Unit test for function absent
def test_absent():
    src = ['test', 'absent', 'args']
    assert absent(src, 'test', 'ent', 'ent', 'ent', 'ent') == (1, '1 line(s) removed', ['absent', 'args'])
    #if __name__ == '__main__':
    #    main()


# Generated at 2022-06-23 03:53:06.126545
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'validate': dict(required=True, type='str')})
    # 'validate' must contain %s: False
    with pytest.raises(AnsibleFailJson) as exc:
        write_changes(module, ['test'], '/test/test')
    assert 'validate must contain %s' in exc.value.args[0]
    module = AnsibleModule(argument_spec={'validate': dict(required=True, type='str')})
    # 'validate' must contain %s: True
    with pytest.raises(AnsibleFailJson) as exc:
        write_changes(module, ['test'], '/test/test')
    assert 'validate must contain %s' in exc.value.args[0]

# Generated at 2022-06-23 03:53:18.256669
# Unit test for function write_changes

# Generated at 2022-06-23 03:53:29.125296
# Unit test for function absent

# Generated at 2022-06-23 03:53:39.918115
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec={'validate': dict(type='str'),
                       'unsafe_writes': dict(type='bool', default=False)}
    )
    module.atomic_move = lambda src, dest: dest
    tmpfile = '/tmp/tmp123'
    dest = '/tmp/dest'
    XFAIL = "XFAIL"
    # Validate is None
    write_changes(module, ['test\n'], dest)
    with open(dest) as f:
        assert f.read() == 'test\n'
    os.unlink(dest)
    # Validate is an empty string
    write_changes(module, ['test\n'], dest)

# Generated at 2022-06-23 03:53:49.696920
# Unit test for function main

# Generated at 2022-06-23 03:53:59.064653
# Unit test for function write_changes
def test_write_changes():
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda fail_rc, fail_dict: True
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    tmpfd2, tmpfile2 = tempfile.mkstemp(dir=module.tmpdir)
    b_lines = [to_bytes("test")]
    write_changes(module,b_lines,tmpfile2)

    assert open(tmpfile2,'r').read() == 'test'
    os.unlink(tmpfile2)


# Generated at 2022-06-23 03:54:10.207759
# Unit test for function present
def test_present():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'dest': {'type': 'str'}, 'regexp': {'type': 'str'}, 'search_string': {'type': 'str'}, 'line': {'type': 'str'}, 'insertafter': {'type': 'str'}, 'insertbefore': {'type': 'str'}, 'backup': {'type': 'bool', 'default': True}, 'backrefs': {'type': 'bool'}})
    message, changed = present(module, '/etc/global.conf', None, None, 'some line', 'some insertafter', 'some insertbefore', True, True, True)
    assert(message == 'line added')
    assert(changed)


# Generated at 2022-06-23 03:54:17.631025
# Unit test for function main
def test_main():
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import set_module_args, AnsibleExitJson
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.common.fixers import ansible_module
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils._text import to_bytes
    import os
    import shutil
    import tempfile
    import json

    #
    # Test module with state=present
    #
    lines = ["first line\n",
            "second line\n",
            "third line\n",
            "fourth line\n",
            "fifth line\n"]

    with tempfile.NamedTemporaryFile() as f:
        f.writelines(lines)
       

# Generated at 2022-06-23 03:54:27.072214
# Unit test for function absent
def test_absent():
    module = AnsibleModule(argument_spec={
        "dest": {"required": True},
        "line": {"default": "This is a string"},
        "regexp": {},
        "search_string": {},
        "state": {"default": "absent", "choices": ["absent", "present"]},
        "backup": {"default": False, "type": "bool"},
    })
    result = absent(module, "bogusdest", None, None, "This is a string", False)
    assert result["changed"] is False


# Generated at 2022-06-23 03:54:27.716393
# Unit test for function absent
def test_absent():
    pass


# Generated at 2022-06-23 03:54:38.511898
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from collections import namedtuple
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule

    module_args = dict(
        path='/etc/profile',
        owner='root',
        group='root',
        mode='0755',
    )

    # Read in mocked params
    mock_params = namedtuple('Params', module_args.keys())(*module_args.values())

    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)
    module.params = mock_params

    diff = StringIO()
    changed = False
    message = ''

    # Call function
    message, changed = check_file_attrs(module, changed, message, diff)

    # Did function return the right values

# Generated at 2022-06-23 03:54:53.277252
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Creating a mock object to pass through check_file_attrs function.
    import ansible.module_utils.basic
    class MockModule(ansible.module_utils.basic.AnsibleModule):
        pass
    # Creating test data for check_file_attrs function.
    test_data = {'src': 'test.txt'}
    test_message = "test message"
    test_diff = {}
    test_changed = True
    # Creating the mock object.
    mock_obj = MockModule(argument_spec={})
    mock_obj.params = test_data
    mock_obj.check_mode = True
    test_result, test_changed_result = check_file_attrs(mock_obj, test_changed, test_message, test_diff)
    # validating the output
    assert test_result

# Generated at 2022-06-23 03:54:56.624928
# Unit test for function present
def test_present():
    print('Testing function present')
    # Here we will simulate the line being present so that we can test that the line gets replaced
    b_line = b'admin:\\!root'
    b_new_line = b'admin:\\!root'
    if b_line != b_new_line:
        print('FAILED')


# Generated at 2022-06-23 03:55:10.936450
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({
        'path': '/tmp/foo',
        'unsafe_writes': True,
        'owner': 'foo',
        'group': 'bar',
        'mode': '0644',
        'diff_peek': '',
        '_diff_peek': '',
        'seuser': 'foo',
        'serole': 'bar',
        'setype': 'foo',
        'selevel': 's0',
        'seuser_default': '',
        'serole_default': '',
        'setype_default': '',
        'selevel_default': '',
        'selinux_default_context': True
    })
    message = ''
    changed = False

# Generated at 2022-06-23 03:55:21.818410
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module_name = 'ansible.builtin.lineinfile'
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='str'),
            dest=dict(type='path'),
            _diff_peek=dict(type='bool', default=False)
        ),
        supports_check_mode=True,
    )
    changed = False
    message = "message"
    diff = {}
    check_file_attrs(module, changed, message, diff)
    assert changed == False
# end unit test


# Generated at 2022-06-23 03:55:33.219580
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'path'},
                                          'validate': {'type': 'str'},
                                          'unsafe_writes': {'type': 'bool'}})
    dest = 'testfile'
    b_lines = list()
    b_lines.append(to_bytes('#Test line1'))
    b_lines.append(to_bytes('#Test line2'))
    b_lines.append(to_bytes('#Test line3'))
    test_path = tempfile.mkdtemp()
    module.params['path'] = os.path.join(test_path, dest)
    module.params['validate'] = 'cat %s'
    write_changes(module, b_lines, module.params['path'])

# Generated at 2022-06-23 03:55:38.362106
# Unit test for function write_changes
def test_write_changes():
    import ansible.modules.files.lineinfile
    module = ansible.modules.files.lineinfile
    lines = ['one\n', 'two\n']
    dest = '/tmp/test_write_changes'
    module.write_changes(module, lines, dest)
    with open(dest, 'r') as file:
        assert file.readlines() == lines
    os.remove(dest)



# Generated at 2022-06-23 03:55:50.409562
# Unit test for function check_file_attrs
def test_check_file_attrs():
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 03:55:56.715019
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    module.params = {'path': '/tmp/afile', 'owner': 'root', 'group': 'root', 'seuser': 'system_u', 'serole': 'object_r',
            'selevel': 's0'}
    changed = False
    message = ""
    diff = None
    res = check_file_attrs(module, changed, message, diff)
    assert res == ("ownership, perms or SE linux context changed", True)
    module.exit_json(changed=changed, msg=res[0])


# Generated at 2022-06-23 03:56:07.504196
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule(argument_spec={
        'path': {'type': 'str'},
        'owner': {'type': 'str'},
        'group': {'type': 'str'},
        'mode': {'type': 'str', 'aliases': ['permissions']},
        'seuser': {'type': 'str'},
        'serole': {'type': 'str'},
        'setype': {'type': 'str'},
        'selevel': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': True, 'aliases': ['unsafe-writes']},
    })
    changed = False
    message = 'test'
    diff = 1
    attr_message, attr_changed = check_file_att

# Generated at 2022-06-23 03:56:13.693548
# Unit test for function absent
def test_absent():

    _line = 'ansible, lineinfile'
    _regex = 'ansible'
    _search_string = 'ansible'
    _dest = 'dest'
    _backup = False

    with patch('os.path.exists', return_value=True):
        with patch.object(module, '_diff', True):
            with patch('os.linesep', '\n'):
                with patch('io.open') as mock_open:
                    mock_open.return_value = BytesIO(b'foo\nansible, lineinfile\nbar\n')
                    mock_open.return_value.readlines.return_value = b'foo\nansible, lineinfile\nbar\n'.splitlines()

# Generated at 2022-06-23 03:56:23.279257
# Unit test for function present
def test_present():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import Mapping

# Generated at 2022-06-23 03:56:28.921130
# Unit test for function main

# Generated at 2022-06-23 03:56:40.336716
# Unit test for function present

# Generated at 2022-06-23 03:56:46.940199
# Unit test for function main

# Generated at 2022-06-23 03:56:47.881262
# Unit test for function write_changes
def test_write_changes():
    pass


# Generated at 2022-06-23 03:57:01.284735
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'unsafe_writes': {'type': 'bool', 'required': False, 'default': True}})
    module.params = {
        'content': 'some content',
        'unsafe_writes': True,
        'backup': False,
        'owner': 'some owner',
        'group': 'some group',
        'seuser': 'seuser',
        'serole': 'serole',
        'setype': 'setype',
        'mode': '0755',
    }

    changed_attrs = module.set_fs_attributes_if_different(module.params, False, diff=None)
    assert changed_attrs
    file_args = module.load_file_common_arguments(module.params)
    changed, msg = check_file_

# Generated at 2022-06-23 03:57:09.918652
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            dest = dict(required = True),
            regexp = dict(),
            search_string = dict(),
            line = dict(required = True),
            insertafter = dict(),
            insertbefore = dict(),
            create = dict(default = False, type = 'bool'),
            backup = dict(default = 'no', type = 'bool'),
            backrefs = dict(default = 'no', type = 'bool'),
            firstmatch = dict(default = 'yes', type = 'bool'),
        ),
        supports_check_mode = False,
        supports_diff = True
    )

    dest = os.path.join(module.tmpdir, 'test_present')
    b_dest = to_bytes(dest, errors='surrogate_or_strict')
    regex

# Generated at 2022-06-23 03:57:22.473892
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({'path': '/path/to/file', 'unsafe_writes': True})
    dest = "file1"
    tmpfd, tmpfile = tempfile.mkstemp(dir=module.tmpdir)
    with os.fdopen(tmpfd, 'wb') as f:
        f.writelines([b"test"])
    module.atomic_move = mock_atomic_move
    module.run_command = mock_run_command
    module.params['validate'] = None
    valid = True
    write_changes(module, [b"test"], dest)

# Generated at 2022-06-23 03:57:34.441002
# Unit test for function check_file_attrs
def test_check_file_attrs():

    config = {}

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='str'),
            seuser = dict(type='str'),
            serole = dict(type='str'),
            setype = dict(type='str'),
            selevel = dict(type='str'),
            owner = dict(type='str'),
            group = dict(type='str'),
            mode = dict(type='str'),
        ),
        supports_check_mode=True,
        add_file_common_args=True,
        check_invalid_arguments=False,
    )

    changed = False
    message = ""
    diff = {}
    check_file_attrs(module, changed, message, diff)

    assert changed is False
    assert message == ""
    assert diff == {}


# Generated at 2022-06-23 03:57:45.101524
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            content=[dict(key=str, value=[str, int])],
            dest=dict(type='path', required=True),
        )
    )
    mock_open = mocker.patch('tempfile.mkstemp')
    mock_open().__enter__().write.return_value = True
    mock_atomic_move = mocker.patch.object(module, 'atomic_move')
    mock_atomic_move.return_value = True

    try:
        write_changes(module, b"", "/tmp/foo")
    except SystemExit:
        pass

    mock_open.assert_called_once_with(dir=module.tmpdir)

# Generated at 2022-06-23 03:57:59.048784
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'path':{'required':False, 'type':'str'}, 'unsafe_writes':{'required':False, 'type':'bool'}})
    module.check_mode = False
    module.params['path'] = '/home/user/test.txt'
    module.params['unsafe_writes'] = False
    changed = False
    diff = {'before': '', 'after': '', 'before_header': '', 'after_header': ''}
    message = ""
    ret = check_file_attrs(module, changed, message, diff)
    assert ret[1] == False
    assert "does not exist" in ret[0]
    