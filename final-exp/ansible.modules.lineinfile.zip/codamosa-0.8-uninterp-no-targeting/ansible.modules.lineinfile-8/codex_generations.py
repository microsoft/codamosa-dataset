

# Generated at 2022-06-20 22:02:32.361932
# Unit test for function check_file_attrs

# Generated at 2022-06-20 22:02:43.357051
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'dest': '/tmp/file',
        'state': 'present',
        'line': 'string',
        'backup': 'yes',
        'create': 'yes'
    })
    assert module.params['dest'] == '/tmp/file'
    assert module.params['line'] == 'string'
    assert module.params['state'] == 'present'
    assert module.params['backup'] == 'yes'
    assert module.params['create'] == 'yes'


# Generated at 2022-06-20 22:02:55.453523
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 22:03:07.892238
# Unit test for function write_changes
def test_write_changes():

    def test_exit_success(tmpdir):
        module = Mock(
            params={'unsafe_writes': False, 'validate': None, 'tmpdir': tmpdir},
            tmpdir=tmpdir,
            atomic_move=Mock(return_value=True),
            fail_json=Mock(return_value=False)
        )
        dest = os.path.join(os.path.sep, 'foo', 'bar', 'baz')
        lines = to_bytes('This is a multiline string\nwhich will be written to a file', errors='surrogate_or_strict')
        write_changes(module, lines, dest)
        module.atomic_move.assert_called_once_with(ANY, dest, unsafe_writes=False)

# Generated at 2022-06-20 22:03:16.299953
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str', required=True),
            search_string=dict(type='str', required=True),
            line=dict(type='str', required=True),
            insertafter=dict(type='str', required=False),
            insertbefore=dict(type='str', required=False),
            create=dict(type='bool', required=False),
            backup=dict(type='bool', required=False),
            backrefs=dict(type='bool', required=False),

        ),
        supports_check_mode=True
    )
    dest = '/tmp/test.txt'
    regexp = '^(.*)Xms(\d+)m(.*)$'
    search_

# Generated at 2022-06-20 22:03:28.977616
# Unit test for function main

# Generated at 2022-06-20 22:03:35.353452
# Unit test for function main
def test_main():

    # Description| Expected result| actual result| test pass/fail
    line="'"
    regexp='/usr/bin/python -E'
    search_string='/usr/bin/python'
    dest='/etc/ansible/ansible.cfg'
    backup='./ansible_tmp_backup_file'

    try:
        absent(module, dest, regexp, search_string, line, backup)
    except SystemExit:
        # the absence of the file will exit the program
        print('SystemExit')
        assert True
    else:
        assert False


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:03:50.673827
# Unit test for function write_changes

# Generated at 2022-06-20 22:03:51.616435
# Unit test for function main
def test_main():
    pass
# Ansible module main

# Generated at 2022-06-20 22:04:03.736188
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True),
            owner = dict(type='str'),
            group = dict(type='str'),
            mode = dict(type='str'),
            seuser = dict(type='str'),
            serole = dict(type='str'),
            setype = dict(type='str')
        )
    )
    file_args = {'owner': 'root', 'group': 'root', 'mode': '0744'}
    changed, message = False, ''
    message, changed = check_file_attrs(module, changed, message, "@@ -1,1 +1,1 @@")
    assert message == "ownership, perms or SE linux context changed"
    assert changed is True


# Generated at 2022-06-20 22:04:29.414906
# Unit test for function main
def test_main():
    import platform
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.file import file_argument_spec
    from ansible_collections.notstdlib.moveitallout.plugins.modules.files import lineinfile

    # results is just a dummy parameter like in the real lineinfile module.
    results = []

    # Test empty string search/replace values
    with unittest.TestCase():
        module = MagicMock(argument_spec=file_argument_spec, check_mode=True, no_log=True)

# Generated at 2022-06-20 22:04:37.205968
# Unit test for function write_changes
def test_write_changes():
    test_module = AnsibleModule(argument_spec={'path': {'type': 'path'}, 'unsafe_writes': {'type': 'bool', 'default': False, 'aliases': ['unsafe']}, 'validate': {'type': 'str'}}, supports_check_mode=True)
    test_module.fail_json = lambda *args, **kwargs: None
    test_module.atomic_move = lambda *args, **kwargs: None
    data = {'rc': 0, 'out': '', 'err': ''}
    test_module.run_command = lambda *args, **kwargs: (data['rc'], data['out'], data['err'])

    # No validate

# Generated at 2022-06-20 22:04:49.099772
# Unit test for function main
def test_main():
    os.chdir('/home/ws-dev/git/ansible-ws/filter_plugins')
    line = '10.0.0.1 host1'
    regexp = '^10.0.0.1 host1'
    search_string = '10.0.0.1 host1'
    path = '/home/ws-dev/git/ansible-ws/filter_plugins/testfile_lineinfile'
    ins_aft = 'EOF'
    ins_bef = 'BOF'
    create = False
    backup = False
    backrefs = False
    firstmatch = False
    present(module, path, regexp, search_string, line,
                ins_aft, ins_bef, create, backup, backrefs, firstmatch)



# Generated at 2022-06-20 22:04:58.813406
# Unit test for function write_changes
def test_write_changes():
    b_lines = [b"test\n", b"test2\n"]
    class Common:
        def __init__(self):
            self.tmpdir = "tmpdir"
            self.exception_handling_style = 'legacy'
            self.fail_json = print
    module = Common()
    module.run_command = run_command
    module.atomic_move = atomic_move
    module.params = {'validate': None, 'unsafe_writes': False}
    write_changes(module, b_lines, "dest")



# Generated at 2022-06-20 22:05:06.874149
# Unit test for function main
def test_main():
    REQUIREMENTS = ['modules/script_template.py', 'modules/utils.py']
    for req in REQUIREMENTS:
        if not os.path.exists(req):
            print("the required file {0} does not exist".format(req))

# Generated at 2022-06-20 22:05:15.648614
# Unit test for function main
def test_main():
    # Test with path is a directory
    path = '/etc/hosts'
    b_path = to_bytes(path, errors='surrogate_or_strict')
    os.path.isdir.return_value = True
    module.fail_json.assert_called_with(rc=256, msg='Path %s is a directory !' % path)

    # Test with state is present
    # Test with regexp and backrefs are both None
    params = {
        'state': 'present',
        'path': '/etc/hosts',
        'backrefs': True,
        'create': False,
        'backup': False,
        'line': '192.168.50.2'
    }
    module.params = params

# Generated at 2022-06-20 22:05:22.130225
# Unit test for function check_file_attrs
def test_check_file_attrs():
    """ check_file_attrs: unit test """
    # Load module
    module = AnsibleModule(argument_spec={})
    # Create changed, message, diff
    changed = False
    message = ""
    diff = {}
    # Run check file attributes
    message, changed = check_file_attrs(module, changed, message, diff)
    assert changed == False
    assert "ownership, perms or SE linux context changed" not in message
    # Create changed, message, diff
    changed = True
    message = "test"
    diff = {}
    # Run check file attributes
    message, changed = check_file_attrs(module, changed, message, diff)
    assert changed == True
    assert message == "test and ownership, perms or SE linux context changed"



# Generated at 2022-06-20 22:05:27.844876
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True),
            line = dict(required=False, type='str'),
            regexp = dict(required=False, type='str'),
            insertafter = dict(required=False, type='str'),
            insertbefore = dict(required=False, type='str'),
            dest = dict(required=False, type='path'),
            create = dict(required=False, type='bool'),
            backup = dict(required=False, type='bool'),
            validate= dict(required=False, type='str'),
            unsafe_writes = dict(required=False, default=False, type='bool')
        ),
        supports_check_mode=True
    )

# Generated at 2022-06-20 22:05:38.924852
# Unit test for function main
def test_main():
    test_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, test_path + '/mock')
    from mock_ansible_module import AnsibleModule, AnsibleExitJson, AnsibleFailJson
    dest = '/home/johndoe'
    state = 'present'
    regexp = None
    search_string = None
    line = 'test123'
    insertbefore = None
    insertafter = 'EOF'
    create = False
    backup = False
    backrefs = False
    firstmatch = False

    with open(dest, 'wb') as f:
        f.writelines(['test1', 'test2', 'test3'])


# Generated at 2022-06-20 22:05:48.866233
# Unit test for function absent
def test_absent():
    module = AnsibleModule(argument_spec=dict(
        path=dict(type='str'),
        regexp=dict(type='str'),
        search_string=dict(type='str'),
        line=dict(type='str'),
        backup=dict(type='bool', default=False),
    ))
    dest = "/tmp/lineinfile-test"
    s = "Hello there\nAnd again\n"
    open(dest, 'w').write(s)
    module.exit_json = Mock()
    module._diff = True
    module.check_mode = True
    dest = "/tmp/lineinfile-test"

    # scenario "simple line remove"
    # absent(module=module, dest=dest, regexp='^Hello', search_string=None, line='Hello there', backup=False)

# Generated at 2022-06-20 22:06:27.179596
# Unit test for function present
def test_present():
  module = AnsibleModule(
      argument_spec=dict(path=dict(type='str'),
                        regexp=dict(type='str'),
                        search_string=dict(type='str'),
                        line=dict(type='str'),
                        insertafter=dict(type='str'),
                        insertbefore=dict(type='str'),
                        create=dict(type='bool'),
                        backup=dict(type='bool'),
                        backrefs=dict(type='bool'),
                        firstmatch=dict(type='bool'),
                        )
  )

# Generated at 2022-06-20 22:06:42.834500
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule({
        'dest': 'test_lines',
        'tmpdir': os.path.dirname(os.path.abspath(__file__))
    })
    test_lines_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_lines")
    test_lines_handle = open(test_lines_path, "w")
    test_lines_handle.write("this is a test")
    test_lines_handle.close()
    write_changes(module, ["Something else"], test_lines_path)
    test_lines_handle = open(test_lines_path, "r")
    lines = test_lines_handle.readlines()
    test_lines_handle.close()
    os.remove(test_lines_path)

# Generated at 2022-06-20 22:06:48.686360
# Unit test for function check_file_attrs
def test_check_file_attrs():
    return_value = check_file_attrs(module, True, "ownership, perms or SE linux context changed", None)
    assert return_value[0] == "ownership, perms or SE linux context changed and ownership, perms or SE linux context changed"
    assert return_value[1] == True
    return_value = check_file_attrs(module, False, "ownership, perms or SE linux context changed", None)
    assert return_value[0] == "ownership, perms or SE linux context changed"
    assert return_value[1] == True
    return_value = check_file_attrs(module, False, "ownership, perms or SE linux context changed", None)
    assert return_value[0] == "ownership, perms or SE linux context changed"
    assert return_value[1]

# Generated at 2022-06-20 22:07:04.351329
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
            owner=dict(type='str'),
            group=dict(type='str'),
            mode=dict(type='str'),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            setype=dict(type='str'),
            selevel=dict(type='str'),
        ))

    file_args = {'path': '/tmp/testfile',
                 'owner': 'root',
                 'group': 'root',
                 'mode': '0644',
                 'seuser': 'root',
                 'serole': 'root',
                 'setype': 'root',
                 'selevel': 'root'}


# Generated at 2022-06-20 22:07:14.631001
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
            _diff=dict(type='bool', default=True),
        ),
        supports_check_mode=True)


# Generated at 2022-06-20 22:07:25.883460
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'path', 'required': True},
        'owner': {'type': 'str'},
        'group': {'type': 'str'},
        'mode': {'type': 'str'},
        'attributes': {'type': 'dict'},  # TODO - add no_log to all parameters of this type
    })
    module.params['path'] = 'test/fake/path'
    module.params['owner'] = 'neo'
    module.params['group'] = 'matrix'
    module.params['mode'] = '0644'
    module.params['attributes'] = {'attr': 'attr'}
    changed, message, diff = False, '', {}


# Generated at 2022-06-20 22:07:37.783272
# Unit test for function check_file_attrs
def test_check_file_attrs():
    lines = "127.0.0.1 localhost\n192.168.1.1 host1"
    dest = "/etc/hosts"
    diff = []
    changed = True
    file_args = [dest, lines, '0644']

# Generated at 2022-06-20 22:07:44.236227
# Unit test for function present
def test_present():
    test = {
        "dest": "/tmp/foo.conf",
        "regexp": "^#?foo=",
        "line": "foo=bar",
        "insertbefore": None,
        "insertafter": None,
        "create": False,
        "backup": False,
        "backrefs": False,
        "firstmatch": True,
    }


# Generated at 2022-06-20 22:07:54.456743
# Unit test for function write_changes
def test_write_changes():
    """ write_changes a file and validate it. """
    class MyRunner():
        def run_command(self, cmd):
            return (0, '', '')
        def exit_json(*args): pass
        def fail_json(*args): pass
        def atomic_move(self, src, dest): pass

    my_mock = MyRunner()
    my_mock.tmpdir = 'tmp'

    b_lines = [to_bytes('./test'), to_bytes('test2')]
    dest = './test_file'

    write_changes(my_mock, b_lines, dest)


# ===========================================
# Subroutines
#



# Generated at 2022-06-20 22:07:57.306856
# Unit test for function check_file_attrs
def test_check_file_attrs():
    """
    Test function that returns changed and message
    """
    module = AnsibleModule(argument_spec=dict())
    changed = True
    message = "ownership, perms or SE linux context changed"

    result = check_file_attrs(module, changed, message, True)
    assert result == ('ownership, perms or SE linux context changed', True)



# Generated at 2022-06-20 22:09:09.270459
# Unit test for function present
def test_present():
    lines = [b"line 1\n", b"line 2\n", b"line 3\n", b"line 2\n",
             b"line 2\n", b"line 3\n", b"line 4\n", b"line 5\n"]
    after_insert_before = [b"line 0\n", b"line 1\n", b"line 2\n",
                           b"line 3\n", b"line 2\n", b"line 2\n",
                           b"line 3\n", b"line 4\n", b"line 5\n"]

# Generated at 2022-06-20 22:09:19.547068
# Unit test for function present
def test_present():
    from ansible.module_utils.six import PY3
    from ansible.module_utils import basic
    import os
    import tempfile
    import shutil
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    class TestModule(basic.AnsibleModule):

        def __init__(self, no_test_target=False, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)
            # workaround for https://github.com/pytest-dev/pytest/issues/1158
            # to be removed with pytest>=3.6
            if no_test_target:
                self._test_target = None
            else:
                self._test

# Generated at 2022-06-20 22:09:25.046725
# Unit test for function write_changes

# Generated at 2022-06-20 22:09:26.147928
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs()



# Generated at 2022-06-20 22:09:32.655861
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest = dict(required=True),
            regexp = dict(required=False),
            search_string = dict(required=False),
            line = dict(required=True),
        )
    )
    module.check_mode = True
    dest = '/tmp/ansible-test-file.txt'
    line = 'somestring'
    os.mkdir(dest)
    try:
        absent(module, dest, None, None, line, True)
    except Exception as e:
        assert False, str(e)
    os.remove(dest)

# Generated at 2022-06-20 22:09:40.869173
# Unit test for function absent
def test_absent():
    module = AnsibleModule({'dest': '/tmp/test.txt', 'line': 'apples', 'state': 'absent'}, ignore_invocation=True)
    (ex_ret_val,
     out_msg,
     out_backupdest,
     out_diff) = absent(module, dest='/tmp/test.txt', regexp=None, search_string=None, line='apples', backup=None)

    assert(out_msg == '')
    assert(out_backupdest == '')
    assert(out_diff['before_header'] == '/tmp/test.txt (content)')
    assert(out_diff['after_header'] == '/tmp/test.txt (content)')
    assert(out_diff['before'] == '')
    assert(out_diff['after'] == '')

    b

# Generated at 2022-06-20 22:09:51.161553
# Unit test for function present
def test_present():
    dest = '/tmp/testfile'
    regexp = r'^(.*)Xms(\d+)m(.*)$'
    search_string = 'Xms'
    line = '\1Xms${xms}m\3'
    insertafter = ''
    insertbefore = ''
    create = False
    backup = False
    backrefs = True
    firstmatch = True

# Generated at 2022-06-20 22:10:01.062069
# Unit test for function present
def test_present():

    test_module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            line=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=True),
            firstmatch=dict(type='bool', default=True),
        ),
        supports_check_mode = True
    )

    module = test_module.params
    dest = 'test_lines'
    regexp = None
    search_string = 'Test line 1'
    insertafter = None
   

# Generated at 2022-06-20 22:10:02.001259
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:10:03.492663
# Unit test for function main
def test_main():
    main()