

# Generated at 2022-06-20 22:02:03.417018
# Unit test for function present
def test_present():

    dest = "test_file"
    regexp = None
    search_string = None
    line = "test line"
    insertafter = "BOF"
    insertbefore = None
    create = True
    backup = False
    backrefs = False
    firstmatch = True

# Generated at 2022-06-20 22:02:09.213603
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 22:02:17.989254
# Unit test for function present
def test_present():
    test_dict = {
        'src': '/path/to/file.txt',
        'dest': '/path/to/file.txt',
        'regexp': '^First',
        'search_string': None,
        'line': 'First line',
        'insertafter': None,
        'insertbefore': None,
        'create': False,
        'backup': False,
        'backrefs': True,
        'firstmatch': True,
        'lines': [
            b'First line',
            b'Second line',
            b'Third line']
    }
    assert present(test_dict) == True



# Generated at 2022-06-20 22:02:29.588029
# Unit test for function present

# Generated at 2022-06-20 22:02:37.933272
# Unit test for function main
def test_main():
    location = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
    sys.path.append(location)

# Generated at 2022-06-20 22:02:44.023083
# Unit test for function absent
def test_absent():
    assert absent("", "", "", "", "", "") == 'file not present'
    assert absent("", "", "", "", "", "") == 'file not present'

#, 's/foo/bar/') == ''


# Generated at 2022-06-20 22:02:56.546326
# Unit test for function present

# Generated at 2022-06-20 22:02:58.059684
# Unit test for function present
def test_present():
    pass


# Generated at 2022-06-20 22:03:07.734060
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            src=dict(type='path'),
            dest=dict(type='path'),
            owner=dict(type='str'),
            group=dict(type='str'),
            mode=dict(type='str'),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            setype=dict(type='str'),
            selevel=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    file_args = module.load_file_common_arguments(module.params)
    file_args['path'] = module.params["path"]
    file_args["unsafe_writes"] = module.params["unsafe_writes"]


# Generated at 2022-06-20 22:03:11.664725
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed=True
    message = "test"
    diff={}
    result = check_file_attrs(module, changed,message,diff)
    assert result == ('test and ownership, perms or SE linux context changed', True)


# Generated at 2022-06-20 22:03:43.682865
# Unit test for function main
def test_main():
    try:
        shutil.rmtree('/tmp/ansible_test')
    except OSError:
        pass

    try:
        os.makedirs('/tmp/ansible_test/')
    except OSError:
        pass

    try:
        os.makedirs('/tmp/ansible_test2/')
    except OSError:
        pass

    try:
        os.chmod('/tmp/ansible_test/', 0o700)
    except OSError:
        pass

    try:
        os.chmod('/tmp/ansible_test2/', 0o700)
    except OSError:
        pass


# Generated at 2022-06-20 22:03:54.700183
# Unit test for function present
def test_present():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.common.text.converters import to_native
    if sys.version_info.major == 2:
        reload(basic)
        reload(to_native)
        reload(Mapping)

# Generated at 2022-06-20 22:03:56.354409
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-20 22:04:02.406889
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            src = dict(required=True)
        )
    )
    module.exit_json = lambda **x: x
    res = test_check_file_attrs(module,True,'1','2')
    print(res)
    # assert res['source'] == '1'
    # assert res['dest'] == '2'



# Generated at 2022-06-20 22:04:03.308555
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-20 22:04:03.921759
# Unit test for function check_file_attrs
def test_check_file_attrs():
    return 0



# Generated at 2022-06-20 22:04:12.754737
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'path':{'type':'str'}})
    module.params['path'] = '/tmp/testfile'
    # Create the destination file
    with open('/tmp/testfile', 'w') as f:
        f.write('foo\n')
    changed = False
    diff = [('before','after')]
    message = "foobar"
    assert check_file_attrs(module, changed, message, diff) == ("foobar and ownership, perms or SE linux context changed", True)
    # Cleanup
    os.remove(module.params['path'])



# Generated at 2022-06-20 22:04:27.549335
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    fd, dest_path = tempfile.mkstemp(dir=module.tmpdir)
    dest = os.fdopen(fd, 'w+b')

    with dest:
        dest.write(b"1\n2\n3\n4\n5")
        dest.flush()

        b_lines = [b"1\n", b"2\n", b"3\n", b"4\n", b"5\n"]
        write_changes(module, b_lines, dest_path)

        dest.seek(0)
        assert b", ".join(dest.readlines()) == b"1, 2, 3, 4, 5"
        os.remove(dest_path)



# Generated at 2022-06-20 22:04:32.993924
# Unit test for function check_file_attrs
def test_check_file_attrs():
    testmodule = AnsibleModule(
        argument_spec = dict(
            unsafe_writes=dict(type='bool', default=False),
            path=dict(),
        )
    )
    args = dict(
        path="/tmp/testfile",
        unsafe_writes=False,
        owner="testowner",
        group="testgroup",
        mode=0o600
    )
    dict_to_merge = dict(
        changed=False,
        msg="",
        diff=dict(before_header=args['path'], after_header=args['path'], before=b"BEGIN", after=b"END"),
    )
    global_args = dict(
        ANSIBLE_MODULE_ARGS=dict(
            **args
        )
    )
    testmodule.params = args

# Generated at 2022-06-20 22:04:33.638607
# Unit test for function absent
def test_absent():
    assert absent("file not present")



# Generated at 2022-06-20 22:05:08.417480
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-20 22:05:16.437432
# Unit test for function absent
def test_absent():
    """ Unit test case for function absent.
        Handles edge cases where function absent can fail.
        1. File does not exist
        2. File does exist but does not contain the line to be deleted
        3. File does exist and does contain the line to be deleted
        4. File does exist and does contain multiple instances of the line to be deleted
    """
    from ansible.module_utils.basic import AnsibleModule

    # setup mock module for unit test
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='str', default='/tmp/foobar'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
        )
    )

    # Test 1:
    # No file exists at /tmp/foobar, module should

# Generated at 2022-06-20 22:05:23.460359
# Unit test for function write_changes
def test_write_changes():
    class Temp:
        def __init__(self, *args):
            self.args = args
        def returnValue(self):
            return self.args
    # Since os.path.realpath is an inbuilt function and it is being used as a boolean check,
    # it is not allowed to be mocked.
    # Also, os.path.realpath modifies the default behavior of os.path.abspath.
    # Thus, monkeypatching os.path.abspath is done to avoid mocking os.path.realpath.
    realpath = os.path.realpath
    os.path.realpath = lambda x: x
    def mock_atomic_move(src, dest, unsafe_writes=False):
        db = {"src":src, "dest":dest, "unsafe_writes":unsafe_writes}
        return

# Generated at 2022-06-20 22:05:28.072435
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    assert check_file_attrs(module, False, "message", None)[0] == "message"
    assert check_file_attrs(module, True, "message", "diff")[0] == "message and ownership, perms or SE linux context changed"



# Generated at 2022-06-20 22:05:39.043723
# Unit test for function main

# Generated at 2022-06-20 22:05:43.600760
# Unit test for function absent
def test_absent():
    a = Module()
    b = ""
    c = None
    d = ""
    a.check_mode = True
    a.diff = True
    absent(a, b, c, d, "a", 1)
    assert True
test_absent()



# Generated at 2022-06-20 22:05:59.782622
# Unit test for function present
def test_present():
    src = '''
# Comment line 1
line1
line2
# Comment line 3
line4
'''
    args = dict(
        dest='/tmp/ansible.txt',
        regexp='^line1$',
        search_string='line2',
        insertafter='Comment line 1',
        insertbefore='Comment line 3',
        line='line3',
    )
    expected = '''
# Comment line 1
line1
line3
line4
'''

# Generated at 2022-06-20 22:06:11.255493
# Unit test for function absent
def test_absent():
    #function absent test set
    import json

    fun_name = "absent"

# Generated at 2022-06-20 22:06:21.328662
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class module:
        def __init__(self):
            self.params = {
                "dest": "/etc/passwd",
                "owner": "root",
                "group": "root",
                "mode": "0644",
                "follow": False,
                "unsafe_writes": False,
                "seuser": None,
                "serole": None,
                "setype": None,
            }
            self.check_mode = False
        def set_fs_attributes_if_different(self, attrs, changed, diff):
            return changed
        def load_file_common_arguments(self, params):
            return self.params
    changed = False
    message = "test message"
    diff = "test diff"
    check_file_attrs(module, changed, message, diff)



# Generated at 2022-06-20 22:06:28.829476
# Unit test for function main
def test_main():
    class ModuleStub(object):
        def exit_json(self, changed, found, msg, backup, diff):
            self.assertIsNotNone(changed)
            self.assertIsNotNone(found)
            self.assertIsNotNone(msg)
            self.assertIsNotNone(backup)
            self.assertIsNotNone(diff)
    module = ModuleStub()
    params = {}
    create = False
    backup = False
    backrefs = False
    path = 'test_path'
    firstmatch = False
    regexp = None
    search_string = None
    line = None
    os.path.isdir = MagicMock(return_value=True)
    main(module, path, regexp, search_string, line, create, backup, backrefs, firstmatch)


# Generated at 2022-06-20 22:08:23.603370
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            state=dict(default='present', choices=['absent', 'present']),
        )
    )

    module.absent('/tmp/test.cfg', 'line')


# Generated at 2022-06-20 22:08:24.349241
# Unit test for function present
def test_present():
    return


# Generated at 2022-06-20 22:08:32.728054
# Unit test for function present
def test_present():
  module = AnsibleModule(
      argument_spec=dict(
          path=dict(required=True),
          regexp=dict(),
          search_string=dict(),
          line=dict(default=None, required=True),
          insertafter=dict(),
          insertbefore=dict(),
          create=dict(type='bool', default=False),
          backup=dict(type='bool', default=False),
          backrefs=dict(type='bool', default=False),
          firstmatch=dict(type='bool', default=False),
          validate=dict(type='str', required=True),
          unsafe_writes=dict(
              type='bool', default=False, aliases=['unsafe-writes']
          ),
      )
  )
  dest = "/tmp/stubfile"
  regexp = "test_pattern"

# Generated at 2022-06-20 22:08:39.221795
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(module, True, "test", "test") == ("test and ownership, perms or SE linux context changed", True)
    assert check_file_attrs(module, False, "test", "test") == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-20 22:08:42.541820
# Unit test for function main
def test_main():
    doc_str = inspect.getdoc(main)
    print(doc_str)

# Unit tests for function get_file_attrs

# Generated at 2022-06-20 22:08:50.191451
# Unit test for function present
def test_present():
    module = AnsibleModule({'path': 'source.txt',
                            'line': 'This is the inserted line'
                            })

    b_line = 'This is the inserted line\n'
    module.atomic_move = lambda src, dest: None
    write_changes(module, [b_line], 'source.txt')
    module.exit_json = lambda a, b: None



# Generated at 2022-06-20 22:09:04.695276
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec=dict(
        path=dict(type='path', required=True),
        state=dict(default='present', choices=['absent', 'present']),
        regexp=dict(type='str'),
        search_string=dict(type='str'),
        line=dict(type='str'),
        insertafter=dict(type='str'),
        insertbefore=dict(type='str'),
        backrefs=dict(type='bool', default=False),
        create=dict(type='bool', default=False),
        backup=dict(type='bool', default=False),
        firstmatch=dict(type='bool', default=False),
        follow=dict(type='bool', default=False),
        others=dict(type='str'),
        validate=dict(type='str'),
    ))


# Generated at 2022-06-20 22:09:12.148920
# Unit test for function write_changes
def test_write_changes():
    failmsg = 'module.fail_json was called'
    runcmdmsg = 'module.run_command was called'
    atomic_movemsg = 'module.atomic_move was called'
    class DummyModule(object):
        def __init__(self):
            self.params = {
                'validate': None
            }

        def fail_json(self, msg=None):
            self.msg = msg
            self.fail = True
            self.exit_args = {'failed': True}
            raise Exception(failmsg)

        def run_command(self, command):
            self.cmd = command
            self.fail = True
            raise Exception(runcmdmsg)

        def atomic_move(self, tmpfile, dest, unsafe_writes=False):
            self.tmpfile = tmpfile
            self.dest = dest

# Generated at 2022-06-20 22:09:20.620341
# Unit test for function write_changes
def test_write_changes():
    tmpfile = os.path.join(tempfile.gettempdir(), "test_write_changes")
    with open(tmpfile, "w") as f:
        f.write("line1")

    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
            backup = dict(required=False, default=False, type='bool')
        ),
        supports_check_mode=True
    )

# Generated at 2022-06-20 22:09:31.456121
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec = dict(
       path = dict(type = 'str', required = True),
       owner = dict(type = 'str'),
       group = dict(type = 'str'),
       mode = dict(type = 'str'),
       seuser = dict(type = 'str'),
       serole = dict(type = 'str'),
       selevel = dict(type = 'str'),
       setype = dict(type = 'str'),
       unsafe_writes = dict(type = 'bool', default = True),
    ))
    module.params['path'] = '/tmp/test_file'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0644'
    module.params['seuser'] = ''
    module.params

# Generated at 2022-06-20 22:11:12.000472
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.utils.vars import combine_vars
    from ansible.utils import context_objects as co

    module = co.AnsibleModule(
        argument_spec=dict(
            mode=dict(),
            group=dict(),
            owner=dict(),
            seuser=dict(),
            serole=dict(),
            setype=dict(),
            path=dict()
        )
    )

    current_file_attrs = {
        'mode': '0644'
    }
    module.params = combine_vars(current_file_attrs, module.params)
    module.params['mode'] = '0666'

    message, changed = check_file_attrs(module, False, "", "dummy")
    assert changed is True

# Generated at 2022-06-20 22:11:21.190532
# Unit test for function present
def test_present():
    search_string, line, dest, regexp = 'Bob', 'Bob:x:1000:\n', 'test', None
    insertafter, insertbefore, create, backup, backrefs, firstmatch = None, None, False, False, False, True
    module, changed, msg, backupdest, diff = present(module, dest, regexp, search_string, line, insertafter, insertbefore, create,
            backup, backrefs, firstmatch)
    assert changed == True
    assert msg == 'line added'
    assert backupdest == ''
    return
test_present()