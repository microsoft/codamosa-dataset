

# Generated at 2022-06-20 22:02:06.641293
# Unit test for function absent
def test_absent():
    from ansible.module_utils.basic import AnsibleModule
    mo = AnsibleModule(argument_spec=dict(dest=dict(required=True),
        regexp=dict(required=False, default=None),
        search_string=dict(required=False, default=None),
        line=dict(required=False, default=None),
        backup=dict(required=False, default=False)
    ))

    mo.params['dest'] = '/tmp/absent.test'
    mo.params['search_string'] = 'test absent'
    mo.params['regexp'] = 'test absent'
    mo.params['line'] = 'test absent'
    mo.params['backup'] = False
    absent(mo, '/tmp/absent.test', 'test absent', 'test absent', 'test absent', False)




# Generated at 2022-06-20 22:02:12.014796
# Unit test for function main
def test_main():
    # setup
    MOCK_MODULES = dict()
    MOCK_MODULES['ansible.module_utils.basic'] = "basic"
    MOCK_MODULES['ansible.module_utils.ansible_release'] = "ansible_release"
    MOCK_MODULES['ansible.module_utils._text'] = "_text"
    MOCK_MODULES['ansible.module_utils.six'] = "six"
    MOCK_MODULES['ansible.module_utils.six.moves'] = "six.moves"
    MOCK_MODULES['ansible.module_utils.six.moves.configparser'] = "six.moves.configparser"
    MOCK_MODULES['ansible.module_utils.subprocess_common'] = "subprocess_common"


# Generated at 2022-06-20 22:02:20.424637
# Unit test for function write_changes
def test_write_changes():
    import pytest
    _, tmpfile = tempfile.mkstemp()
    module=AnsibleModule(argument_spec = {})
    b_lines=[b"This", b"is",b"a",b"test"]
    module.run_command = lambda cmd: ('0','','Unit test')
    module.tmpdir = '/tmp'
    dest = tmpfile
    module.atomic_move = lambda src, dest, unsafe_writes: os.rename(src,dest)
    write_changes(module, b_lines, dest)
    with open(dest, 'rb') as f:
        lines_in_file = f.readlines()
        assert b_lines == lines_in_file



# Generated at 2022-06-20 22:02:27.697615
# Unit test for function main
def test_main():
    assert True == main()

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.splitter import *
from ansible.module_utils.pycompat24 import get_exception
from ansible.module_utils._text import to_native

# Set up the main function
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:02:43.917162
# Unit test for function main

# Generated at 2022-06-20 22:02:56.375910
# Unit test for function write_changes
def test_write_changes():
    # Create a temporary file
    fh, tempf = tempfile.mkstemp()
    # Write some lines
    os.write(fh, "hello world\n".encode())
    os.write(fh, "hello world\n".encode())
    os.write(fh, "hello world\n".encode())
    os.close(fh)
    # Get the lines
    with open(tempf, 'r') as f:
        b_lines = f.readlines()
    # Write a line
    fh, tempf = tempfile.mkstemp()
    os.write(fh, "hello world\n".encode())
    # Append the line
    b_lines.append(b"hello world\n")
    os.close(fh)
    # Create a module
   

# Generated at 2022-06-20 22:03:08.096385
# Unit test for function present
def test_present():
    diff = {'before': '',
            'after': '',
            'before_header': '%s (content)' % dest,
            'after_header': '%s (content)' % dest}

# Generated at 2022-06-20 22:03:16.210844
# Unit test for function check_file_attrs
def test_check_file_attrs():
    import os
    import tempfile
    module = AnsibleModule({'owner': 'root'})
    (fd, tmp_file) = tempfile.mkstemp()
    os.close(fd)
    os.remove(tmp_file)
    open(tmp_file, 'a').close()
    os.chown(tmp_file, 1000, 1000)
    f_args = {'path': tmp_file, 'owner': 'root', 'mode': 0o644}
    message = 'placeholder'
    changed = True
    diff = ''
    message, changed = check_file_attrs(module, changed, message, diff)
    os.remove(tmp_file)
    assert message == 'placeholder and ownership, perms or SE linux context changed'
    assert changed == True



# Generated at 2022-06-20 22:03:26.737675
# Unit test for function absent
def test_absent():
    # Construction of file in memory
    dest = io.StringIO()
    module = None
    backup = False
    dest.write("test line\n")
    dest.write("test line 2\n")
    dest.write("test line 3\n")
    dest.write("test line 4\n")
    dest.write("test line 5\n")
    dest.seek(0)
    # Case 1 - No regexp, no search_string, exact line match
    line = "test line 2"
    regexp = None
    search_string = None
    absent(module, dest, regexp, search_string, line, backup)
    # Verify that line 2 has been removed
    assert not dest.getvalue().find("test line 2") > 0
    # Case 2 - Regexp, no search_string, regexp match
   

# Generated at 2022-06-20 22:03:31.160781
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({'path': '/tmp/future', 'owner': 'root', 'change_file_owner': False}, check_invalid_arguments=False)
    module.run_command = lambda cmd, check_rc=False, close_fds=True: (0, '', '')
    changed, diff, message = False, dict(), ''
    message, changed = check_file_attrs(module, changed, message, diff)
    assert not changed
    assert message == ''



# Generated at 2022-06-20 22:03:57.181573
# Unit test for function absent
def test_absent():
    src_file = 'test_file'
    dest_file = 'test_dir/test_file'
    search_string = 'test_line2'
    regexp = None
    line = 'test_line'
    backup = False

    class MockModule(object):
        def __init__(self):
            self.check_mode = True
            self.exit_json = Mock()
            self.fail_json = Mock()

        def backup_local(self, path):
            return None

    class MockFile(object):
        def __init__(self, data, name=None):
            self.readlines = lambda: data.splitlines(True)
            self.name = name


# Generated at 2022-06-20 22:04:12.610233
# Unit test for function write_changes
def test_write_changes():
    import os
    my_mock_file = os.path.join(os.path.dirname(__file__), 'test_file')
    module = get_test_module(my_mock_file,
                             dict(
                                insertafter='^#test2',
                                line='test2',
                            ))
    b_lines = [b'#line1\n', b'line2\n', b'#test1\n', b'line3\n', b'#test2\n']
    write_changes(module, b_lines, my_mock_file)
    with open(my_mock_file) as f:
        assert f.read() == '#line1\nline2\n#test1\nline3\ntest2\n'


# Generated at 2022-06-20 22:04:27.401031
# Unit test for function write_changes
def test_write_changes():
    test_module = AnsibleModule({'path': '/tmp/test_file', 'state': 'present', 'line': 'test_line',
                                 'validate': '/usr/bin/test -f'})
    test_lines = [b'test_line']
    test_module.atomic_move = lambda old, new, unsafe_writes: os.rename(old, new)
    test_module.run_command = lambda cmd: [0, '', '']
    write_changes(test_module, test_lines, '/tmp/test_file')
    try:
        with open('/tmp/test_file', 'r') as f:
            assert f.read() == 'test_line'
    finally:
        os.remove('/tmp/test_file')



# Generated at 2022-06-20 22:04:34.907308
# Unit test for function write_changes
def test_write_changes():

    module = MockModule()
    b_lines = [ b"1:hello\n", b"2:goodbye\n", b"3:aloha\n" ]
    dest = module.tmpdir + "/testfile"
    write_changes(module, b_lines, dest)
    assert os.path.isfile(dest)
    with open(dest, 'rb') as f:
        assert f.read() == b"1:hello\n2:goodbye\n3:aloha\n"


# Generated at 2022-06-20 22:04:46.390902
# Unit test for function absent
def test_absent():
    _module = AnsibleModule(argument_spec=dict(
        dest=dict(type='path', required=True),
        line=dict(),
        regexp=dict(),
        search_string=dict(),
        state=dict(default='present', choices=['absent', 'present']),
        backup=dict(default='no', choices=['no', 'yes']),
        _diff=dict(type='bool', default=False))
    )
    b_dest = to_bytes('/tmp/testfile2.txt.bak', errors='surrogate_or_strict')
    assert os.path.exists(b_dest)

# Generated at 2022-06-20 22:04:58.918058
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    import ansible.module_utils.basic
    import ansible.module_utils.pycompat24

    def dummy(*args, **kwargs):
        pass


# Generated at 2022-06-20 22:05:06.928414
# Unit test for function main
def test_main():
    lines1 = [
        '# This is a host file',
        '127.0.0.1 localhost',
        '127.0.1.1 master',
        '# The following lines are desirable for IPv6 capable hosts',
        '::1 ip6-localhost ip6-loopback',
        'fe00::0 ip6-localnet',
        'ff00::0 ip6-mcastprefix',
        'ff02::1 ip6-allnodes',
        'ff02::2 ip6-allrouters',
        'ff02::3 ip6-allhosts',
        '192.168.0.1 master'
    ]

    lines2 = lines1 + [
        '192.168.0.2 slave1 slave1.example.com'
    ]


# Generated at 2022-06-20 22:05:15.675334
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class ModuleMock(object):
        def __init__(self):
            self.params = {
                "owner": 16,
                "group": "test",
                "mode": "0755",
                "seuser": "unittest",
                "serole": "unittest",
                "setype": "unittest",
                "selevel": "s0",
            }

        def fail_json(self, msg):
            print(msg)

        def load_file_common_arguments(self, params):
            return {}

        def set_fs_attributes_if_different(self, params, *args):
            return True

    module = ModuleMock()
    changed, msg = False, ""

    # no change
    changed, msg = check_file_attrs(module, changed, msg, "")

# Generated at 2022-06-20 22:05:18.862535
# Unit test for function present
def test_present():
    args = dict(
        dest='/test/test.conf',
        insertbefore='BOF',
        line='test'
    )
    result = present(module,**args)
    assert result

# ============================================================================================


# Generated at 2022-06-20 22:05:25.313591
# Unit test for function absent
def test_absent():
    def run_absent(module, dest, regexp, search_string, line, backup):
        module.params['backup'] = backup
        module.params['dest'] = dest
        module.params['regexp'] = regexp
        module.params['search_string'] = search_string
        module.params['line'] = line
        return absent(module, dest, regexp, search_string, line, backup)

    fname = os.path.join(os.path.dirname(__file__), 'bak')
    f = open(fname, 'w')
    f.write('a\nb\nc\nd\n')
    f.close()
    module = AnsibleModule({})

# Generated at 2022-06-20 22:06:00.801804
# Unit test for function present
def test_present():
    args = dict(
        regexp=r"^#.*$",
        line="test line"
    )


# Generated at 2022-06-20 22:06:04.907787
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule({'path': '/tmp/file',
                                 'owner': 'foo',
                                 'group': 'foo',
                                 'mode': '0755'})
    test_module.params['unsafe_writes'] = True
    test_module.check_mode = False
    test_module.set_fs_attributes_if_different = lambda x, y, diff=False: True
    assert check_file_attrs(test_module, False, "", "") == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-20 22:06:05.563899
# Unit test for function write_changes
def test_write_changes():
    assert True



# Generated at 2022-06-20 22:06:18.156325
# Unit test for function absent
def test_absent():
    dummy_module = DummyModule()
    b_dest = '/tmp/b'
    with open(b_dest, 'w') as f:
        for i in range(10):
            f.write('line1\n')
            f.write('line2\n')
            f.write('line3\n')
    dummy_module.params = {'path': b_dest, 'regexp': 'line1', 'backup': False}
    absent(dummy_module, b_dest, regexp=dummy_module.params['regexp'],
           search_string=None, line=None, backup=dummy_module.params['backup'])
    with open(b_dest, 'r') as f:
        data = f.readlines()
    assert len(data) == 20
    dummy_module

# Generated at 2022-06-20 22:06:26.072974
# Unit test for function main

# Generated at 2022-06-20 22:06:29.046813
# Unit test for function absent
def test_absent():
    args = {
        'dest': 'test.file',
        'regexp': None,
        'search_string': None,
        'line': 'Test line',
        'backup': False,
    }
    with pytest.raises(SystemExit):
        absent(args)

# Generated at 2022-06-20 22:06:38.168029
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native, to_text
    import os
    import os.path
    import tempfile
    import shutil
    # set up
    test_dir = '/tmp/ansible_test/'
    if os.path.exists(test_dir):
        shutil.rmtree(test_dir)
    os.makedirs(test_dir)


# Generated at 2022-06-20 22:06:48.103847
# Unit test for function present

# Generated at 2022-06-20 22:07:04.118719
# Unit test for function check_file_attrs
def test_check_file_attrs():

    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            mode=dict(type='str'),
            owner=dict(type='str'),
            group=dict(type='str'),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            setype=dict(type='str'),
            selevel=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    fd, path = tempfile.mkstemp()
    os.close(fd)
    os.remove(path)


# Generated at 2022-06-20 22:07:07.956547
# Unit test for function absent
def test_absent():
    dest = 'file.txt'
    regexp = None
    search_string = None
    line = 'hello world'
    backup = False
    module = MagicMock()
    setattr(module, 'params', {'dest':dest, 'backup':backup})
    f = open(dest, 'w')
    f.write(line)
    f.close()
    absent(module, dest, regexp, search_string, line, backup)



# Generated at 2022-06-20 22:07:50.745582
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            owner=dict(type='raw'),
            group=dict(type='raw'),
            mode=dict(type='raw'),
            seuser=dict(type='str')
        )
    )
    test_module.set_options(direct={'_ansible_check_mode': True})
    dir_name = tempfile.mkdtemp()
    file_path = os.path.join(dir_name, 'test_check_file_attrs.txt')

# Generated at 2022-06-20 22:07:57.868252
# Unit test for function present

# Generated at 2022-06-20 22:08:08.212601
# Unit test for function present
def test_present():
    '''
    This unit test tests the functionality of the present function
    '''
    line = ['line']
    module = MockAnsibleModule(src='/tmp/src', dest='/tmp/dest', regexp=None, state='present', line=line, search_string=None, insertafter=None, insertbefore=None, create=True, backup=False, backrefs=False, firstmatch=False)
    dest = module.params.get('dest')
    regexp = module.params.get('regexp')
    search_string = module.params.get('search_string')
    line = module.params.get('line')
    insertafter = module.params.get('insertafter')
    insertbefore = module.params.get('insertbefore')
    create = module.params.get('create')

# Generated at 2022-06-20 22:08:21.509723
# Unit test for function present
def test_present():

    b_dest = to_bytes(dest, errors='surrogate_or_strict')
    if not os.path.exists(b_dest):
        if not create:
            module.fail_json(rc=257, msg='Destination %s does not exist !' % dest)
        b_destpath = os.path.dirname(b_dest)
        if b_destpath and not os.path.exists(b_destpath) and not module.check_mode:
            try:
                os.makedirs(b_destpath)
            except Exception as e:
                module.fail_json(msg='Error creating %s (%s)' % (to_text(b_destpath), to_text(e)))

        b_lines = []

# Generated at 2022-06-20 22:08:22.157287
# Unit test for function write_changes
def test_write_changes():
    assert True



# Generated at 2022-06-20 22:08:31.232791
# Unit test for function present
def test_present():
    module = AnsibleModule(argument_spec=dict(
        dest=dict(type='path'),
        regexp=dict(type='str'),
        line=dict(type='str'),
        insertafter=dict(type='str'),
        insertbefore=dict(type='str'),
        create=dict(type='bool', default=False),
        backup=dict(type='bool', default=False),
        backrefs=dict(type='bool', default=False),
        firstmatch=dict(type='bool', default=False),
    ))

# Generated at 2022-06-20 22:08:38.026027
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    setattr(module, 'set_fs_attributes_if_different',
            lambda *args, **kwargs: True)

    assert check_file_attrs(module, False, '', '') == ('ownership, perms or SE linux context changed', True)



# Generated at 2022-06-20 22:08:47.419087
# Unit test for function present
def test_present():
    module = AnsibleModule({'dest': '/tmp/file', 'line': 'new line'})
    setattr(module, '_diff', True)
    present(module,
            dest='/tmp/file',
            regexp=None,
            search_string=None,
            line='new line',
            insertafter=None,
            insertbefore=None,
            create=False,
            backup=False,
            backrefs=False,
            firstmatch=False)



# Generated at 2022-06-20 22:08:49.974141
# Unit test for function absent
def test_absent():
    assert absent(module, dest, regexp, search_string, line, backup) == ['', '', [{'after': '', 'before_header': 'abc', 'after_header': 'abc', 'before': 'abc\n'}, {'after': 'file attributes', 'before_header': 'abc', 'before': 'file attributes', 'after_header': 'abc'}]]


# Generated at 2022-06-20 22:08:50.918195
# Unit test for function absent
def test_absent():
    assert absent(module, dest, regexp, search_string, line, backup) == "file not present"


# Generated at 2022-06-20 22:09:29.382711
# Unit test for function absent
def test_absent():
    assert absent(module, dest, '^\s*port\s+([0-9]+)\s*$', '', 'port 22', True) == \
        {
            'changed': False,
            'msg': 'file not present',
            'backup': ''
        }


# Generated at 2022-06-20 22:09:37.813709
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common.file import check_file_attrs
    from ansible.module_utils.six import PY3
    from sys import version_info
    from mock import patch, MagicMock
    from tempfile import mkstemp
    from shutil import rmtree
    import os

    state = 'present'


# Generated at 2022-06-20 22:09:53.215377
# Unit test for function main

# Generated at 2022-06-20 22:09:58.947686
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Create a module object to run tests on
    from ansible.modules.files.lineinfile import _check_file_attrs
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True),
            dest_type=dict(required=True),
            group=dict(),
            unsafe_writes=dict(default=False, type='bool'),
            mode=dict(),
            owner=dict(),
            seuser=dict(),
            serole=dict(),
            setype=dict(),
            selevel=dict(),
            validate=dict()
        )
    )
    # Create variables to assume in the tests
    changed = False
    message = "No file attributes changed"
    diff = "#No diff"
    # Run test

# Generated at 2022-06-20 22:09:59.359887
# Unit test for function write_changes
def test_write_changes():
    assert True



# Generated at 2022-06-20 22:10:06.111632
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True, type='str'),
            regexp=dict(required=False, type='str', default=None),
            search_string=dict(required=False, type='str', default=None),
            line=dict(required=False, type='str', default=None),
            backup=dict(required=False, type='bool', default=False),
        ),
        supports_check_mode=False
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']


# Generated at 2022-06-20 22:10:15.763898
# Unit test for function present
def test_present():
    module = AnsibleModule({
        "dest": "/tmp/ansible.txt",
        "line": "test line"
    })
    dest = "/tmp/ansible.txt"
    regexp = None
    search_string = None
    line = "test line"
    insertafter = None
    insertbefore = None
    create = False
    backup = False
    backrefs = False
    firstmatch = False
    present(module, dest, regexp, search_string, line, insertafter, insertbefore, create,
            backup, backrefs, firstmatch)


# Generated at 2022-06-20 22:10:31.276326
# Unit test for function main

# Generated at 2022-06-20 22:10:34.826497
# Unit test for function absent
def test_absent():
    module.absent(module, dest, regexp, search_string, line, backup)
# ===========================================
# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.six import PY3

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:10:50.614795
# Unit test for function absent
def test_absent():
    # function_name = 'absent'
    param = {
        'dest': '/tmp/test.txt',
        'line': 'hello world',
        'backup': True
    }
    module = get_module(param)
    b_dest = module.to_bytes(param['dest'], errors='surrogate_or_strict')
    if not os.path.exists(b_dest):
        module.exit_json(changed=False, msg="file not present")

    msg = ''
    diff = {'before': '',
            'after': '',
            'before_header': '%s (content)' % param['dest'],
            'after_header': '%s (content)' % param['dest']}

    with open(b_dest, 'rb') as f:
        b_lines = f