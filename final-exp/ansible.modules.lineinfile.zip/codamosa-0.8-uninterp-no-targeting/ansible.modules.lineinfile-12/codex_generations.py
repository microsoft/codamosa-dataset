

# Generated at 2022-06-20 22:02:00.458660
# Unit test for function main
def test_main():
    import tempfile, os, os.path
    tmpdir = tempfile.gettempdir()
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    print(tmpdir, tmpfile.name)
    with open(tmpfile.name, 'wt') as f:
        f.write('foo\nbar')
    
    main(dict(
        path=tmpfile.name,
        line='baz\n',
        insertafter='EOF',
        firstmatch=False,
        state='present'
        ))
    with open(tmpfile.name, 'rt') as f:
        for line in f:
            print(line, end='')

# Generated at 2022-06-20 22:02:01.870663
# Unit test for function write_changes
def test_write_changes():
    import ansible.module_utils.basic

    # FIXME: write a real testcase
    assert(True)



# Generated at 2022-06-20 22:02:03.540775
# Unit test for function main
def test_main():

# Tests are performed using os.system
# However, we have to make sure the 
# path is right in the module
    main()
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:02:15.065433
# Unit test for function present
def test_present():
    dest = "/tmp/foo.conf"
    search_string = "vcs_type = "
    line = "vcs_type = git"
    regexp = None
    insertafter = None
    insertbefore = None
    create = True
    backup = True
    backrefs = False
    firstmatch = False
    res_args = dict(dest=dest, search_string=search_string,
                    line=line, regexp=regexp, insertafter=insertafter,
                    insertbefore=insertbefore, create=create, backup=backup,
                    backrefs=backrefs, firstmatch=firstmatch)

# Generated at 2022-06-20 22:02:23.667960
# Unit test for function absent
def test_absent():
    import errno
    def setUpModule():
        if not os.path.exists('test'):
            os.mkdir('test')
        if not os.path.exists('test/absent'):
            os.mkdir('test/absent')
        if os.path.exists('test/absent/test.txt'):
            os.remove('test/absent/test.txt')
        f = open('test/absent/test.txt', 'w')
        f.write('hello\n')
        f.write('world\n')
        f.write('bar\n')
        f.write('foo\n')
        f.close()


# Generated at 2022-06-20 22:02:39.770288
# Unit test for function main
def test_main():
    """
    The following is a simple unit test for main()

    """

# Generated at 2022-06-20 22:02:48.895938
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    with open(os.path.join(os.path.dirname(__file__), 'test-data', 'lineinfile-backrefs-regexp.txt'), 'rb') as f:
        content_ins_re = f.read()
    with open(os.path.join(os.path.dirname(__file__), 'test-data', 'lineinfile-backrefs-replace-regexp.txt'), 'rb') as f:
        content_rep_re = f.read()

# Generated at 2022-06-20 22:02:56.681961
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # AnsibleModule allows more than one return value
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'owner': {'type': 'str'}, 'group': {'type': 'str'}, 'mode': {'type': 'str'}, 'seuser': {'type': 'str', 'version_added': '1.9.0'}, 'serole': {'type': 'str', 'version_added': '1.9.0'}, 'setype': {'type': 'str', 'version_added': '1.9.0'}, 'selevel': {'type': 'str', 'version_added': '1.9.0'}, 'unsafe_writes': {'type': 'bool', 'default': False, 'aliases': ['unsafe-writes']}})
    # As

# Generated at 2022-06-20 22:03:06.444119
# Unit test for function main

# Generated at 2022-06-20 22:03:13.154809
# Unit test for function present
def test_present():
    '''
    Test present output.
    '''
    module = AnsibleModule(argument_spec={'dest': dict(type='str'),'regexp': dict(type='str'),'firstmatch': dict(type='bool', default=False),'search_string': dict(type='str'),'line': dict(type='str'),'insertafter': dict(type='str'),'insertbefore': dict(type='str'),'create': dict(type='bool', default=False),'backup': dict(type='bool', default=False),'backrefs': dict(type='bool', default=False),})
    present(module, 'test', regexp=None, search_string=None, line=None, insertafter=None, insertbefore=None, create=False, backup=False, backrefs=False, firstmatch=False)
# Unit test

# Generated at 2022-06-20 22:03:57.208353
# Unit test for function write_changes
def test_write_changes():
    def mock_run_command(cmd, check_rc=None, close_fds=None, executable=None, data=None, binary_data=None, path_prefix=None, cwd=None, use_unsafe_shell=None, prompt_regex=None):
        assert cmd.endswith(to_bytes(tmpfile, errors='surrogate_or_strict'))
        return 0, '', ''

    def mock_fail_json(msg):
        raise AssertionError(msg)

    def mock_atomic_move(src, dest, unsafe_writes=False):
        assert src == tmpfile
        assert dest == to_text(os.path.realpath(to_bytes(dest, errors='surrogate_or_strict')), errors='surrogate_or_strict')

    tmpfd, tmp

# Generated at 2022-06-20 22:04:00.073392
# Unit test for function main
def test_main():
    # run main.py function
    main()
# Import python libraries
import unittest


# Generated at 2022-06-20 22:04:01.061780
# Unit test for function absent
def test_absent():
    assert False



# Generated at 2022-06-20 22:04:02.452539
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:04:13.726776
# Unit test for function present
def test_present():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    b_lines = [b'a line', b'another line']
    content = b"".join(b_lines)

# Generated at 2022-06-20 22:04:21.684197
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Test for successful change of mode
    module = AnsibleModule({'mode': '0644'},
                           check_invalid_arguments=False)
    changed = False
    message = ""
    res = check_file_attrs(module, changed, message, "test_file")
    assert changed is True
    assert message == "ownership, perms or SE linux context changed"

    # Test for successful change of owner, group and mode
    module = AnsibleModule({'owner': 'arviman', 'group': 'arviman', 'mode': '0644'},
                           check_invalid_arguments=False)
    changed = False
    message = ""
    res = check_file_attrs(module, changed, message, "test_file")
    assert changed is True

# Generated at 2022-06-20 22:04:31.434017
# Unit test for function main
def test_main():
    import sys
    import os
    import shutil
    import tempfile
    import subprocess
    import datetime
    import time
    import ansible.modules.extras.file.lineinfile as lineinfile

    def get_file_content(path):
        with open(path, 'rb') as f:
            return to_text(f.read())

    def touch(path):
        with open(path, 'a'):
            os.utime(path, None)

    # Test prefix
    test_prefix = "test_ansible_lineinfile_"
    # Name of the temporary folder where test will be run
    tmpdir_name = test_prefix + "dir"
    # Name of the temporary file where test will be run
    tmpfile_name = test_prefix + "file"
    # Name of the temporary file

# Generated at 2022-06-20 22:04:40.968764
# Unit test for function main
def test_main():
    ansible_module_args = {
        'path': 'test_path',
        'state': 'test_state',
        'regexp': 'test_regexp',
        'search_string': 'test_search_string',
        'line': 'test_line',
        'insertafter': 'test_insertafter',
        'insertbefore': 'test_insertbefore',
        'backrefs': None,
        'create': None,
        'backup': None,
        'firstmatch': None,
        'validate': None,
    }
    run_main(ansible_module_args)


# Generated at 2022-06-20 22:04:50.814598
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO

    if not PY2:
        from ansible.module_utils.six.moves.configparser import NoOptionError
    else:
        from ConfigParser import NoOptionError

    class AnsibleModuleExit(Exception):
        def __init__(self, kwargs):
            self.kwargs = kwargs

    class CustomAnsibleModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.params = dict()
            self.fail_json_called = False
            self.execute_command_called = False
            self.run_command_called = False

# Generated at 2022-06-20 22:05:02.510863
# Unit test for function write_changes
def test_write_changes():
    with tempfile.NamedTemporaryFile() as f:
        module = AnsibleModule(argument_spec={})
        module.atomic_move = lambda src, dest: shutil.move(src, dest)
        module.tmpdir = tempfile.gettempdir()
        def fail_json(*args, **kwargs):
            raise Exception("fail_json called")
        module.fail_json = fail_json
        def run_command(*args, **kwargs):
            return 0, '', ''
        module.run_command = run_command
        write_changes(module, [b'new content'], f.name)
        assert open(f.name).read() == 'new content'

# Generated at 2022-06-20 22:05:55.453496
# Unit test for function main
def test_main():
    data = dict(
        path="/tmp/mock.txt",        
        state='present',
        regexp=None,
        search_string=None,
        line="test",
        insertafter=None,
        insertbefore=None,
        backrefs=False,
        create=False,
        backup=False,
        firstmatch=False,
        validate=None,        
    )

# Generated at 2022-06-20 22:06:03.013501
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = MagicMock()
    module.params = {'owner':'test'}
    module.set_fs_attributes_if_different = MagicMock(return_value=True)

    # diff is empty
    ret = check_file_attrs(module=module, changed=True, message="", diff={})
    assert ret == ("ownership, perms or SE linux context changed", True)

    # diff is not empty
    ret = check_file_attrs(module=module, changed=True, message="", diff={'before':'test'})
    assert ret == ("ownership, perms or SE linux context changed", True)

    # diff is not empty and changed is false
    ret = check_file_attrs(module=module, changed=False, message="", diff={'before':'test'})
    assert ret

# Generated at 2022-06-20 22:06:14.020487
# Unit test for function absent
def test_absent():
  module = AnsibleModule(
    argument_spec = dict(
      dest = dict(required=True),
      regexp = dict(required=False, type='str'),
      search_string = dict(required=False, type='str'),
      line = dict(required=False, type='str'),
      backup = dict(default=False, type='bool')
    ),
    supports_check_mode=True
  )
  dest = module.params['dest']
  regexp = module.params['regexp']
  search_string = module.params['search_string']
  line = module.params['line']
  backup = module.params['backup']
  absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-20 22:06:25.029196
# Unit test for function absent
def test_absent():
    import json
    import ansible.modules.files.lineinfile
    module = ansible.modules.files.lineinfile
    args = 'dest=/etc/selinux/config regexp=^SELINUX='
    args = args.split()
    setattr(module, 'params', dict(args))
    setattr(module, 'run', True)
    setattr(module, 'backup', True)
    setattr(module, 'params', dict(args))
    setattr(module, '_diff', False)
    setattr(module, 'check_mode', True)
    setattr(module, 'backup_local', lambda x: json.dumps(x))
    setattr(module, 'from_json', lambda x: x)

# Generated at 2022-06-20 22:06:34.371719
# Unit test for function absent
def test_absent():
    from AnsibleModule_mock import AnsibleModule

    def get_module_mock(params):
        module = AnsibleModule(**params)
        # Testing purposes
        module.check_mode = True
        module._diff = True
        module._backup_dir = 'some_dir'
        return module

    m = get_module_mock({
        'dest': '/tmp/test',
        'line': 'test_line',
        'state': 'absent'
    })

    with open('/tmp/test', 'w') as f:
        f.write('line 1\n')
        f.write('test_line\n')
        f.write('test_line\n')
        f.write('test_line\n')
        f.write('test_line\n')

# Generated at 2022-06-20 22:06:34.973726
# Unit test for function check_file_attrs
def test_check_file_attrs():
    pass





# Generated at 2022-06-20 22:06:42.006492
# Unit test for function main
def test_main():
    # mock a module
    module = MagicMock(name="AnsibleModule")
    # declare test input arguments

# Generated at 2022-06-20 22:06:50.177326
# Unit test for function present
def test_present():
    """
    Unit test for function present
    """
    module = AnsibleModule(
        argument_spec = dict(
            dest = dict(required=True),
            regexp = dict(),
            search_string = dict(),
            line = dict(required=True),
            insertafter = dict(),
            insertbefore = dict(),
            create = dict(default=False, type="bool"),
            backup = dict(default=False, type="bool"),
            backrefs = dict(),
            firstmatch = dict(default=True, type="bool"),
        ),
        supports_check_mode=True,
    )

    # Mock dest to be a file:
    module.params['dest'] = 'text.txt'
    f = open('text.txt', 'w')

# Generated at 2022-06-20 22:06:57.616226
# Unit test for function absent
def test_absent():
    module = AnsibleModule({'dest': 'unicode.txt', 'line': 'unicode string: 안녕하세요',
                            'search': '안녕하세요', 'backup': False, 'path': DESTDIR,
                            'state': 'absent', '_ansible_check_mode': True})
    present(module, 'unicode.txt', None, '안녕하세요', 'unicode string: 안녕하세요', None, None, True, False, False, False)

# Generated at 2022-06-20 22:07:02.672901
# Unit test for function write_changes
def test_write_changes():
    src_dest_module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path', required=True),
            dest=dict(type='path', required=True)
        )
    )
    src_dest_module.run_command = lambda x: (0, '', '')
    src_dest_module.atomic_move = lambda x, y, z: True
    src_dest_module.params['unsafe_writes'] = True
    src_dest_module.tmpdir = '.'
    assert write_changes(src_dest_module, [''], 'src') is None


# Generated at 2022-06-20 22:08:46.121657
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True),
            regexp = dict(required=False),
            search_string = dict(required=False),
            line = dict(required=False),
            insertafter = dict(required=False),
            insertbefore = dict(required=False),
            create = dict(default=False, type='bool'),
            backup = dict(default=False, type='bool'),
            backrefs = dict(default=True, type='bool'),
            firstmatch = dict(default=True, type='bool')
        ),
        supports_check_mode = True
    )


# Generated at 2022-06-20 22:08:51.389853
# Unit test for function absent
def test_absent():
    ## Test file absent
    base_dir = os.path.dirname(os.path.dirname(__file__))
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str'),
            backup=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )
    dest = os.path.join(base_dir, "unit/files/dest.txt")
    regexp = None
    search_string = None
    line = "new line"
    backup = False
    absent(module, dest, regexp, search_string, line, backup)

# Generated at 2022-06-20 22:08:57.246183
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
    )

    fd, fpath = tempfile.mkstemp()
    dest = os.path.basename(fpath)


# Generated at 2022-06-20 22:09:06.120446
# Unit test for function main

# Generated at 2022-06-20 22:09:07.593773
# Unit test for function main
def test_main():
    '''ansible.module_utils.basic.AnsibleModule'''
    main()


# Generated at 2022-06-20 22:09:11.602557
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={})
    b_lines = [to_bytes('This is a test\n')]
    dest = '/etc/ansible/testfile.bckp'
    write_changes(module, b_lines, dest)
    with open(to_native(dest, errors='strict')) as f:
        new_lines = f.readlines()
    assert new_lines[-1] == to_text(b_lines[-1])
    os.remove(to_native(dest, errors='strict'))



# Generated at 2022-06-20 22:09:20.215523
# Unit test for function check_file_attrs
def test_check_file_attrs():

    import sys
    import os
    import shutil
    import tempfile
    import json
    import filecmp
    import pytest
    import logging

    module_info = json.load(open(os.path.join(os.path.dirname(__file__), '../../lib/ansible/module_common.json')))
    module_args = module_info['argument_spec']
    module_args['path'] = '/tmp/test_file'
    module_args['owner'] = 'root'
    module_args['group'] = 'root'
    module_args['mode'] = '755'
    module_args['selevel'] = 's0'
    module_args['serole'] = 'object_r'
    module_args['setype'] = 'var_lib_t'

# Generated at 2022-06-20 22:09:20.715747
# Unit test for function write_changes
def test_write_changes():
    return os



# Generated at 2022-06-20 22:09:25.949141
# Unit test for function present
def test_present():
    module = AnsibleModule(argument_spec={
        "dest": {"required": True},
        "regexp": {"required": False},
        "search_string": {"required": False},
        "line": {"required": True},
        "insertafter": {"required": False},
        "insertbefore": {"required": False},
        "create": {"required": False, "type": 'bool'},
        "backup": {"required": False, "type": 'bool'},
        "backrefs": {"required": False, "type": 'bool'},
        "firstmatch": {"required": False, "type": 'bool'},
        "validate": {"required": False},
    })

    dest = "/tmp/hallow"
    regexp = None
    search_string = None
    line = "GOOD MORNING ANDROID"

# Generated at 2022-06-20 22:09:30.754842
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule, get_exception

    test_params = dict(
        validate=None,
        unsafe_writes=False,
        tmpdir=None
    )

    module = AnsibleModule(
        argument_spec=dict(dest=dict(type='str', required=True),
                           state=dict(type='str', choices=['absent', 'present'], default='present')),
        supports_check_mode=True,
    )
