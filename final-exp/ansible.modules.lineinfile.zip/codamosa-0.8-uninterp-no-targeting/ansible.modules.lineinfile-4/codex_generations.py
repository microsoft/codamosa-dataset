

# Generated at 2022-06-20 22:02:00.731407
# Unit test for function main
def test_main():
    import ansible.module_utils.basic as basic
    from ansible.module_utils.ansible_release import __version__

    if __version__ > '2.4':
        basic._ANSIBLE_ARGS = to_bytes(
            json.dumps(dict(
                ANSIBLE_MODULE_ARGS = dict(
                    path = "/tmp",
                    state = "present",
                    regexp = None,
                    search_string = None,
                    line = None,
                    insertbefore = None,
                    insertafter = None,
                    backrefs = False,
                    create = False,
                    backup = False,
                    firstmatch = False,
                    validate = None,
                ),
            ))
        )

# Generated at 2022-06-20 22:02:12.133635
# Unit test for function check_file_attrs
def test_check_file_attrs():
    #from ansible.module_utils.six import StringIO
    import StringIO
    class FakeModule(object):
        def __init__(self):
            self.params = {'mode': '0644'}
            self.set_fs_attributes_if_different = lambda x, y, z: None

        def fail_json(self, msg):
            return msg

        def atomic_move(self, x, y, z):
            return (x,y,z)

        def load_file_common_arguments(self, module_params):
            return (module_params, False)

    module = FakeModule()
    changed = True
    message = "Perms changed"
    message, changed = check_file_attrs(module, changed, message, "diff")
    assert changed is True

# Generated at 2022-06-20 22:02:24.814137
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'path': {'type': 'path'}, 'owner': {'type': 'str'}, 'group': {'type': 'str'}, 'mode': {'type': 'str'}, 'seuser': {'type': 'str'}, 'serole': {'type': 'str'}, 'setype': {'type': 'str'}, 'selevel': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': True}}, supports_check_mode=True)
    module.params['test'] = True
    changed = True
    message = 'test message'
    diff = {}

    # check_file_attrs(module, changed, message, diff)
    message, changed = check_file_attrs(module, changed, message, diff)


# Generated at 2022-06-20 22:02:33.225965
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    ansible_args = dict(
        path='/tmp/file',
        state='present',
        regexp=None,
        search_string='test',
        line='test',
        insertafter=None,
        insertbefore=None,
        backrefs=False,
        create=False,
        backup=False,
        firstmatch=False,
        validate=None,
    )
    module = AnsibleModule(argument_spec=basic.__dict__['argument_spec'],
                           supports_check_mode=True)
    setattr(module, 'params', ansible_args)
    setattr(module, 'check_mode', False)
    main()

# Generated at 2022-06-20 22:02:46.414354
# Unit test for function present
def test_present():
    # Unit test for function present
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path', required=True),
            regexp = dict(type='str'),
            search_string = dict(type='str'),
            line = dict(type='str', required=True),
            insertafter = dict(type='str'),
            insertbefore = dict(type='str'),
            create = dict(required=False, type='bool', default=False),
            backup = dict(required=False, type='bool', default=False),
            backrefs = dict(required=False, type='bool', default=False),
            firstmatch = dict(required=False, type='bool', default=False),
        ),
    )
    path = '/tmp/test_file'

# Generated at 2022-06-20 22:02:58.774972
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'str', 'required': True},
        'owner': {'type': 'str'},
        'group': {'type': 'str'},
        'mode': {'type': 'str'},
        'selevel': {'type': 'str'},
        'serole': {'type': 'str'},
        'setype': {'type': 'str'},
        'seuser': {'type': 'str'},
        'unsafe_writes': {'type': 'bool', 'default': False},
        })
    changed = bool(module.set_fs_attributes_if_different({}, False, diff=module.no_log_values))
    message = ""

# Generated at 2022-06-20 22:03:05.454829
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({
        'path': '/tmp/testfile',
        'dest': '/tmp/testfile',
        'owner': 'billy',
        'group': 'billy',
        'mode': 0o644,
    })
    chg, msg = check_file_attrs(module, False, '', {})
    assert "ownership" in msg
    assert "perms" in msg
    assert "SE linux context" in msg
    assert chg is True



# Generated at 2022-06-20 22:03:14.338626
# Unit test for function present

# Generated at 2022-06-20 22:03:15.862081
# Unit test for function present
def test_present():
    assert(0 == 0)



# Generated at 2022-06-20 22:03:16.886896
# Unit test for function write_changes
def test_write_changes():
    pass


# Generated at 2022-06-20 22:03:45.986998
# Unit test for function present
def test_present():

    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str', aliases=['string']),
            line=dict(type='str', required=True),
            insertafter=dict(type='str', aliases=['after']),
            insertbefore=dict(type='str', aliases=['before']),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(type='str')
        )
    )

    setattr

# Generated at 2022-06-20 22:03:55.306832
# Unit test for function absent
def test_absent():
    #FIXME:
    module = AnsibleModule(argument_spec=dict(
        dest=dict(type='str'),
        regexp=dict(type='str'),
        line=dict(type='str'),
        backup=dict(type='bool'),
        backrefs=dict(type='bool'),
        firstmatch=dict(type='bool'),
        # insertbefore and insertafter are mutually exclusive
        insertbefore=dict(type='str'),
        insertafter=dict(type='str'),
        state=dict(type='bool'),
        create=dict(type='bool'),
        search_string=dict(type='str'),
        diff_peek=dict(type='str'),
    ))

    # Example Test Case Structure:
    regexp = 'a'
    search_string = None
    line = 'a'

# Generated at 2022-06-20 22:04:07.317672
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 22:04:17.128890
# Unit test for function absent
def test_absent():
    fh = open('test', 'w')
    fh.write('line1\nline2\nline3\nline4\nline5\nline6\n')
    fh.close()

    # Test for search_string which does not exist.
    rc, out, err = module.run_command('ansible --version')
    m = AnsibleModule(
        argument_spec = dict(
            state = dict(default='present', choices=['absent']),
        dest = 'test',
        regexp = '',
        search_string = 'line4',
        line = '',
        backup = True,
        ),
        supports_check_mode = True
    )

    absent(m, 'test', None, 'line4', '', True)

    # Test for search_string which exists.
    rc

# Generated at 2022-06-20 22:04:24.070755
# Unit test for function check_file_attrs
def test_check_file_attrs():

    class FakeModule(object):

        def __init__(self, *args, **kwargs):
            self._set_fs_attributes_if_different = True
            self._file_common_arguments = {}
            self._module = args
            self._validate = None

        def try_change(self, *args, **kwargs):
            return True

        def fail_json(self, *args, **kwargs):
            pass

        def set_fs_attributes_if_different(self, *args, **kwargs):
            return True

        def load_file_common_arguments(self, params):
            return params

    fake_module = FakeModule()
    module = FakeModule(fake_module, unsafe_writes=True)

    fake_false_module = FakeModule()

# Generated at 2022-06-20 22:04:32.679863
# Unit test for function main
def test_main():
    # Attempting to unit test this file is complicated by the fact that we
    # have modules depending on other modules. In other words it's an
    # integration test more than a unit test. So we can't test the operation
    # of those modules.
    #
    # For now we will just do a "smoke test".
    #
    # We need to stub out the AnsibleModule class
    class TestAnsibleModule(object):
        class TestJson(object):
            def __call__(self, changed=False, msg="", backup="", diff=None, found=0):
                print(msg)
        exit_json = TestJson()
    # This is the function we are testing.
    main(TestAnsibleModule())

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:04:40.924132
# Unit test for function check_file_attrs
def test_check_file_attrs():

    from ansible.modules.files.file import str_to_bool
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule({'mode': '0666'})
    m._diff = True
    m._tmpfile = '/tmp/ansible_test_file'
    m.set_fs_attributes_if_different = lambda a, b: True
    m.set_mode_if_different = lambda a: True

    m.run_command = lambda a: (0, '', '')
    changed, msg = check_file_attrs(m, False, '', True)
    assert changed
    assert msg == 'ownership, perms or SE linux context changed'


# Generated at 2022-06-20 22:04:46.007133
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={'path': {'type': 'str'}, 'unsafe_writes': {'type': 'bool', 'default': False}})
    write_changes(module, b'abc\n', 'abc')



# Generated at 2022-06-20 22:04:48.050913
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(module, changed, message, diff) == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-20 22:05:00.595536
# Unit test for function absent
def test_absent():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    import os

    lines = StringIO(u'''foo''')
    lines.seek(0)
    module = basic.AnsibleModule(
        argument_spec=dict(
            regexp=dict(default=None),
            search_string=dict(default=None),
            dest=dict(default=None),
            line=dict(default=None),
            state=dict(default=None),
            backup=dict(default=False),
            create=dict(default=None)
        )
    )

    module.params['regexp'] = to_bytes(module.params['regexp'])
    module.params['search_string'] = to_

# Generated at 2022-06-20 22:06:10.937794
# Unit test for function absent
def test_absent():
    module = AnsibleModule(argument_spec=dict(dest=dict(type='path'),
                                              state=dict(type='str', default='present', choices=['absent', 'present']),
                                              regexp=dict(type='str'),
                                              search_string=dict(type='str'),
                                              line=dict(type='str'),
                                              backup=dict(type='bool', default=False)
                                              ), supports_check_mode=True, )
    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

    absent(module, dest, regexp, search_string, line, backup)


# Generated at 2022-06-20 22:06:21.520694
# Unit test for function present
def test_present():
    ansible_module=AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
            state=dict(type='str', default='present'),
            line=dict(type='str', required=True),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False)
        )
    )
    setattr(ansible_module, 'tmpdir', '/tmp/')

# Generated at 2022-06-20 22:06:23.956405
# Unit test for function main
def test_main():
    assert os.path.isdir(b_path) ==path

# Generated at 2022-06-20 22:06:37.761791
# Unit test for function write_changes
def test_write_changes():
    tmpdir = tempfile.mkdtemp(dir="/tmp")
    dest = tmpdir + "/test_file"
    lines = ["first_line\n",
             "second_line\n",
             "third_line\n",
             "fourth_line\n",
             ]
    module = AnsibleModule({
        'path': dest,
        'tmpdir': tmpdir,
    })
    write_changes(module, lines, dest)
    with open(dest, "rb") as f:
        ret_lines = f.readlines()
    assert (lines == ret_lines)
    os.remove(dest)
    os.rmdir(tmpdir)


# Generated at 2022-06-20 22:06:39.278303
# Unit test for function check_file_attrs
def test_check_file_attrs():
    pass



# Generated at 2022-06-20 22:06:40.550453
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert check_file_attrs(True, True, "ownership, perms or SE linux context changed", True)



# Generated at 2022-06-20 22:06:49.403288
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True),
            regexp=dict(required=True),
            search_string=dict(required=True),
            line=dict(required=True),
            insertafter=dict(required=True),
            insertbefore=dict(required=True),
            create=dict(required=True),
            backup=dict(required=True),
            backrefs=dict(required=True),
            firstmatch=dict(required=True)
        )
    )
    dest = module.params.get('dest')
    regexp = module.params.get('regexp')
    search_string = module.params.get('search_string')
    line = module.params.get('line')
    insertafter = module.params.get('insertafter')


# Generated at 2022-06-20 22:07:04.351797
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module_mock = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
            owner=dict(type='str'),
            group=dict(type='str'),
            mode=dict(type='str'),
            seuser=dict(type='str'),
            serole=dict(type='str'),
            setype=dict(type='str'),
            selevel=dict(type='str'),
        )
    )
    changed, message, diff = False, "test_check_file_attrs", ""
    result = check_file_attrs(module_mock, changed, message, diff)
    assert result == ("test_check_file_attrs and ownership, perms or SE linux context changed", True)



# Generated at 2022-06-20 22:07:14.631421
# Unit test for function write_changes
def test_write_changes():
    test_module = AnsibleModule(
        argument_spec=dict(
            path=dict(default='/tmp/testfile'),
            line=dict(default='192.168.1.99 foo.lab.net foo'),
            state=dict(default='present'),
            regexp=dict(default=''),
            search_string=dict(default=''),
            validate=dict(default=''),
            insertafter=dict(default='EOF'),
            insertbefore=dict(default=''),
            create=dict(default=False),
            backup=dict(default=False),
            firstmatch=dict(default=False),
            tmpdir=dict(default=tempfile.gettempdir()),
        )
    )
    b_lines = [b'192.168.1.99 foo.lab.net foo']
    dest

# Generated at 2022-06-20 22:07:17.144408
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert True



# Generated at 2022-06-20 22:08:09.469442
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_listlike
    import time
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    module = AnsibleModule({'tmpdir': temp_dir})
    module.atomic_move = shutil.move
    dest = os.path.join(temp_dir, 'dest')
    line1 = b'First line\n'
    line2 = b'Second line\n'
    lines = [line1, line2]
    valid = 'echo %s > /dev/null 2>&1'

    # no file exists, validate test will fail
    rc = write_changes(module, lines, dest)
    assert rc is False

    # no file exists, validate test will

# Generated at 2022-06-20 22:08:24.801871
# Unit test for function absent
def test_absent():
    data = [
        ('regexp', 'lineinfile', 'test_line', None, '/etc/hosts', '^test_line', None, None, None, None, None, None, True, False, False),
        ('search_string', 'lineinfile', 'test_line', None, '/etc/hosts', None, 'test_line', None, None, None, None, None, True, False, False),
        ('line', 'lineinfile', 'test_line', None, '/etc/hosts', None, None, 'test_line', None, None, None, None, True, False, False)
    ]

# Generated at 2022-06-20 22:08:33.043599
# Unit test for function main

# Generated at 2022-06-20 22:08:40.202899
# Unit test for function absent
def test_absent():
    obj = AnsibleModule(
            argument_spec = dict(
                content     = dict(required=True),
                dest        = dict(required=True),
                regexp      = dict(required=False),
                backup      = dict(default=False, type='bool')
            ),
            supports_check_mode = True
        )
    content =  {'content': 'test_content', 'dest': '/tmp/test_file', 'regexp': None}
    # test if backup=False
    obj._backup_name = None
    obj._backup_target = None
    obj.params = content
    backupfile = None
    absent(obj, obj.params['dest'], obj.params['regexp'], '', obj.params['content'], obj.params['backup'])

# Generated at 2022-06-20 22:08:50.219818
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({
            'path':'/tmp/test.txt',
            'owner': 'someuser',
            'group': 'someuser',
            'mode': '0600',
        }
    )
    changed = True
    message = "mode"
    diff = {'before': 'before', 'after':'after'}
    assert ('mode and ownership, perms or SE linux context changed', True) == check_file_attrs(module,changed,message,diff)
# Check function test_check_file_attrs()



# Generated at 2022-06-20 22:08:56.099688
# Unit test for function absent
def test_absent():
    def _run_absent(mocker):
        module = mocker.MagicMock()
        module.params = dict(
            dest='dst',
            regexp=None,
            search_string=None,
            line='line',
            backup=False,
            force=False,
        )
        b_lines = ['line\n', '\n', '\n', 'line\n']
        mocker.patch('os.path.exists', autospec=True, return_value=True)
        mocker.patch('os.makedirs', autospec=True)
        mocker.patch('os.chmod', autospec=True)
        mocker.patch('os.chown', autospec=True)
        mocker.patch('os.chflags', autospec=True)

# Generated at 2022-06-20 22:09:04.206074
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Check for proper output from module
    module = AnsibleModule(
        argument_spec={
            'owner': { 'type': 'str' },
            'group': { 'type': 'str' },
            'mode': {'default': 0, 'type': 'raw'},
            'seuser': { 'type': 'str' },
            'serole': { 'type': 'str' },
            'setype': { 'type': 'str' },
            'selevel': { 'type': 'str' },
        }
    )
    message = "changed"
    changed = True
    diff = ""
    check_file_attrs(module, changed, message, diff)



# Generated at 2022-06-20 22:09:08.306206
# Unit test for function absent
def test_absent():
    dest = '/tmp/foobar'
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            state=dict(default='present', choices=['absent', 'present']),
            backup=dict(default=False, type='bool'),
            regexp=dict(),
            search_string=dict(),
            line=dict(default=None, required=True)
        ),
        supports_check_mode=True,
    )
    module.params['dest'] = dest
    module.params['state'] = 'present'
    content = 'The quick brown fox\njumps over the lazy dog.\n'
    with open(dest, 'w') as f:
        f.write(content)
    regexp = 'The.*brown.*dog'
    search_string

# Generated at 2022-06-20 22:09:14.729591
# Unit test for function main

# Generated at 2022-06-20 22:09:31.008016
# Unit test for function absent
def test_absent():
    module = AnsibleModule({
        "dest": "/tmp/test_file.txt",
        "regexp": "Test line 1$",
        "backup": "yes"

    })
    pp = pprint.PrettyPrinter(indent=4)
    with open("/tmp/test_file.txt", 'w') as f:
        f.writelines(["Test line 1\n", "Test line 2\n"])
    absent(module, module.params["dest"], module.params["regexp"], None, None, module.params["backup"])

# Generated at 2022-06-20 22:11:11.842894
# Unit test for function write_changes
def test_write_changes():
    try:
        # You'll need to pass 'tmpdir' when testing as
        # module.tmpdir doesn't exist in the unit test
        # context. You can pass other args too if you need
        # them to insert values into the module.params
        # dictionary.
        write_changes(module, [b'abc', b'def'], 'test_file')
    except Exception as an_e:
        pass
    if not os.path.exists('test_file'):
        assert False

