

# Generated at 2022-06-20 22:01:50.936207
# Unit test for function write_changes
def test_write_changes():
    # Make sure the following are all true
    assert write_changes(module, b_lines, dest) == true



# Generated at 2022-06-20 22:02:02.008597
# Unit test for function present
def test_present():
   module = AnsibleModule(
       argument_spec=dict(
           state=dict(choices=['present', 'absent'], default='present'),
           dest=dict(required=True),
           regexp=dict(required=False),
           search_string=dict(required=False),
           line=dict(required=True),
           insertafter=dict(required=False),
           insertbefore=dict(required=False),
           create=dict(required=False, type='bool', default=False),
           backup=dict(required=False, type='bool', default=False),
           backrefs=dict(required=False, type='bool', default=False),
           firstmatch=dict(required=False, type='bool', default=False),
           validate=dict(required=False),
       )
   )

   b_dest = to

# Generated at 2022-06-20 22:02:13.532278
# Unit test for function check_file_attrs
def test_check_file_attrs():

    class FakeModule(object):
        def __init__(self, fail_on_diff, params, out_message, expected_rc, expected_diff, expected_out_message, set_fs_attributes_if_different_return):
            self.fail_on_diff = fail_on_diff
            self.params = params
            self.out_message = out_message
            self.expected_out_message = expected_out_message
            self.set_fs_attributes_if_different_return = set_fs_attributes_if_different_return

# Generated at 2022-06-20 22:02:25.404481
# Unit test for function write_changes

# Generated at 2022-06-20 22:02:33.098224
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Unit test for function check_file_attrs
    module = AnsibleModule(argument_spec=dict(path=dict(type='str'), owner=dict(type='str'), group=dict(type='str'), seuser=dict(type='str'), serole=dict(type='str'), setype=dict(type='str'), mode=dict(type='str'), unsafe_writes=dict(type='bool', default=False)))
    changed = True
    message = "ownership, perms or SE linux context changed"
    assert check_file_attrs(module, changed, message, dict()) == ("ownership, perms or SE linux context changed", True)


# Generated at 2022-06-20 22:02:33.633197
# Unit test for function write_changes
def test_write_changes():
    pass


# Generated at 2022-06-20 22:02:46.612810
# Unit test for function present
def test_present():
    """ Function to test the present function """

# Generated at 2022-06-20 22:02:58.935351
# Unit test for function present
def test_present():
    temp_file = tempfile.mktemp()
    temp_file_content = b'''
# This is a comment
port=8080
ssl=on
host=0.0.0.0

[test]
title=stuff
'''
    with open(temp_file, 'wb') as f:
        f.write(temp_file_content)


# Generated at 2022-06-20 22:03:07.117609
# Unit test for function write_changes
def test_write_changes():
    """Not really a test as such"""
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(
                required=True,
                type='path'
            )
        )
    )
    lines = to_bytes('file content\n')
    path = module.params['path']
    backup_path = path + u'%ANSIBLE_BACKUP'
    write_changes(module, lines, path)
    assert os.path.exists(path)
    assert not os.path.exists(backup_path)



# Generated at 2022-06-20 22:03:15.694506
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='str'),
            owner = dict(required=True),
            group = dict(required=True),
            mode = dict(required=True),
            seuser = dict(required=True),
            serole = dict(required=True),
            selevel =  dict(required=True),
            setype =  dict(required=True)
        ))

    module.params['path'] = '/etc/hosts'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    module.params['mode'] = '0644'
    module.params['unsafe_writes'] = False
    module.params['backup'] = False

    import os
    import stat
    # setuid bit

# Generated at 2022-06-20 22:03:46.454861
# Unit test for function write_changes
def test_write_changes():
    tmpfile1 = os.path.join('/tmp', 'testfile1')
    tmpfile2 = os.path.join('/tmp', 'testfile2')
    tmpfile3 = os.path.join('/tmp', 'testfile3')
    tmpfile4 = os.path.join('/tmp', 'testfile4')
    temporary_file_contents = to_bytes('content\n')
    module = create_mock_module(tmpfile=tmpfile1, validate=None, rc=0)

# Generated at 2022-06-20 22:03:53.257843
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec = dict(
            _ansible_tmpdir=dict(required=True, type='path'),
            path=dict(required=True, type='path'),
            unsafe_writes=dict(required=False, default=False, type='bool')
        )
    )
    b_lines = to_bytes(b'bar\n')
    dest = 'test.txt'

    write_changes(module, b_lines, dest)

    with open('test.txt') as f:
        assert f.read() == 'bar'
    os.remove('test.txt')



# Generated at 2022-06-20 22:04:02.138050
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(test="test"))
    module.params = ImmutableDict(dict(changed=True, diff=True))
    changed, message, diff = False, "test", True
    ret = check_file_attrs(module, changed, message, diff)
    assert ret == ("test and ownership, perms or SE linux context changed", True)


# Generated at 2022-06-20 22:04:12.345696
# Unit test for function write_changes
def test_write_changes():
    import os
    import tempfile
    from ansible.module_utils._text import to_native

    tmpfd, tmpfile = tempfile.mkstemp(dir='/tmp')
    # It's stupid that I have to read the file after I write it but mkstemp
    # gives me no other option.
    with os.fdopen(tmpfd, 'r') as f:
        assert(f.read() == '')

    lines = [b'one\n', b'two\n', b'three\n']
    write_changes(lines, tmpfile)

    with open(tmpfile) as f:
        assert(f.read() == 'one\ntwo\nthree\n')

    os.remove(tmpfile)



# Generated at 2022-06-20 22:04:16.960641
# Unit test for function present
def test_present():
    assert present(module, dest, regexp, search_string, line, insertafter, insertbefore, create,
            backup, backrefs, firstmatch) == {'before': '',
                                              'after': '',
                                              'before_header': 'dest (content)',
                                              'after_header': 'dest (content)'}

    assert check_file_attrs(module, changed, message, diff) == ('', True)



# Generated at 2022-06-20 22:04:18.452137
# Unit test for function absent
def test_absent():
    assert absent(module, dest, regexp, search_string, line, backup) == 0

# Generated at 2022-06-20 22:04:28.690861
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(type='path', required=True),
            regexp=dict(type='str'),
            search_string=dict(type='str'),
            line=dict(type='str', required=True),
            insertafter=dict(type='str'),
            insertbefore=dict(type='str'),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            unsafe_writes=dict(type='bool', default=False, aliases=['unsafe-writes']),
            firstmatch=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-20 22:04:33.674279
# Unit test for function absent
def test_absent():
    import os
    import tempfile
    import filecmp
    import shutil
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, Mock
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic
    from ansible_collections.notstdlib.moveitallout.plugins.modules import lineinfile

    def setUpModule():
        lineinfile.open = open
        tempdir = tempfile.mkdtemp()
        # Make sure we don't leave files behind.
        shutil.rmtree(tempdir)
        os.mkdir(tempdir)
        os.chdir(tempdir)

# Generated at 2022-06-20 22:04:44.251566
# Unit test for function write_changes
def test_write_changes():
    ''' This is a unit test for the write_changes subroutine '''

    class UnitTestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(UnitTestModule, self).__init__(*args, **kwargs)
            self.tmpdir = None
            self.params = {}
            self.run_command = lambda cmd, check_rc=True, close_fds=True: [0, cmd, '']
            self.fail_json = lambda params: None
            self.atomic_move = lambda source, dest, unsafe_writes=False: None

    b_lines = []
    dest = '/tmp/testfile'
    module = UnitTestModule()
    write_changes(module, b_lines, dest)



# Generated at 2022-06-20 22:04:54.381782
# Unit test for function absent
def test_absent():
    def run_absent(module, dest, regexp, search_string, line, backup):
        return absent(module, dest, regexp, search_string, line, backup)

    class AnsibleModule(object):

        def __init__(self):
            self.params = dict()
            self.check_mode = False
            self._diff = True

        def backup_local(self, path):
            return ""

        def exit_json(self, changed, found, msg, backup, diff):
            self.changed = changed
            self.found = found
            self.msg = msg
            self.backup = backup
            self.diff = diff

    # these tests are not really unit tests as they operate on files
    # in the filesystem.  This is more of an integration test.  Patches
    # to create a true unit test without touching

# Generated at 2022-06-20 22:05:52.476777
# Unit test for function main
def test_main():
    err = 0
    ok = 0
    @mock.patch('os.path.isdir')
    @mock.patch('os.path.exists')
    @mock.patch('os.makedirs')
    def do_test(mocked_isdir, mocked_exists, mocked_makedirs, module_args, expected_result, expected_return_value):
        global err, ok
        err +=1

# Generated at 2022-06-20 22:06:01.641748
# Unit test for function check_file_attrs

# Generated at 2022-06-20 22:06:04.024081
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    message = ''
    changed = False
    diff = {}
    result = check_file_attrs(module, changed, message, diff)
    assert result == (message, changed)


# Generated at 2022-06-20 22:06:16.684925
# Unit test for function absent
def test_absent():
    dest = "/tmp/foo"
    regexp = "^(#|$)"
    search_string = None
    line = "some-line"
    backup = False
    mock_module = MagicMock()
    mock_module.check_mode = False
    mock_module._diff = True
    with patch.object(builtins, 'open', mock_open(read_data="some\nrandom\nfile\ncontent\n")) as mock_file:
        with patch.object(os, 'path') as mock_path:
            mock_path.exists.return_value = True
            absent(mock_module, dest, regexp, search_string, line, backup)

# Generated at 2022-06-20 22:06:19.493413
# Unit test for function absent
def test_absent():
    assert absent(module, 'test.txt','test','test','test','test') == "test.txt"

# Generated at 2022-06-20 22:06:31.295810
# Unit test for function present
def test_present():
    b_dest = '/tmp/xxxxx'
    dest = '/tmp/xxxxx'
    regexp = '^(.*)Xms(\d+)m(.*)$'
    line = '\1Xms${xms}m\3'
    backrefs = True
    firstmatch = True

    # Read original file
    with open(b_dest, 'rb') as f:
        b_lines = f.readlines()
    oldline = b_lines[0]

    # RegExp matched a line in the file
    bre_m = re.compile(to_bytes(regexp, errors='surrogate_or_strict'))
    match_found = bre_m.search(b_lines[0])
    if match_found:
        match = match_found

# Generated at 2022-06-20 22:06:42.720956
# Unit test for function write_changes
def test_write_changes():
    class ModuleArgs():
        def __init__(self):
            self.dest = "/tmp/testfile"
            self.backup = True
            self.content = b"This is a test file line"
            self.tmpdir = "/tmp"
            
    module = ModuleArgs()
    b_lines = []
    dest = "/tmp/testfile"
    b_lines.append(b"This is a test file line")
    write_changes(module, b_lines, dest)
    assert os.path.exists(dest)
    os.remove(dest)
            

# Generated at 2022-06-20 22:06:44.821665
# Unit test for function check_file_attrs
def test_check_file_attrs():
    retval = check_file_attrs(1, 2, 3, 4)
    assert retval is not None


# Generated at 2022-06-20 22:06:45.945599
# Unit test for function absent
def test_absent():
    assert absent(None, "", "", "", "", "") is None


# Generated at 2022-06-20 22:07:03.047077
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            owner=dict(),
            group=dict(),
            mode=dict(),
            seuser=dict(),
            serole=dict(),
            selevel=dict(),
            setype=dict(),
        )
    )
    args = module.params
    args['path']= '/some/path'
    args['owner'] = 'someowner'
    args['group'] = 'somegroup'
    args['mode'] = 'somemode'
    args['seuser'] = 'someuser'
    args['serole'] = 'somerole'
    args['selevel'] = 'somelevel'
    args['setype'] = 'sometype'
    args['unsafe_writes']=False

   

# Generated at 2022-06-20 22:08:02.848994
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'path', 'required': True, 'aliases': ['dest', 'destfile', 'name']},
        'value': {'type': 'str', 'required': False, 'aliases': ['line']}
        },
        supports_check_mode=True)
    # Create the text files
    tmpfd, tmpfile = tempfile.mkstemp(dir='/tmp/')
    with open(tmpfile, 'w') as f:
        f.write("Hello World\n")
    write_changes(module, 'Bye World\n'.encode(), tmpfile)
    with open(tmpfile, 'r') as f:
        content = f.read()
    assert(content == "Bye World\n")



# Generated at 2022-06-20 22:08:09.102024
# Unit test for function absent
def test_absent():
    lines = ['foo', 'bar', 'baz', 'bar', 'baz']
    b_lines = [to_bytes(l, errors='surrogate_or_strict') for l in lines]
    # no regexp or search_string, only line
    matcher = lambda x: re.compile(to_bytes('bar'), errors='surrogate_or_strict').search(x)
    assert absent(None, '/tmp/dest', regexp=None, search_string=None, line='bar', backup=False) == [
        'foo', 'baz', 'baz']
    # no regexp or search_string, only line (not found)
    matcher = lambda x: re.compile(to_bytes('bar'), errors='surrogate_or_strict').search(x)

# Generated at 2022-06-20 22:08:15.938829
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({'path': '/tmp/test_file.txt', 'unsafe_writes': False})
    changed, message, diff = check_file_attrs(module, False, 'foo', 'bar')
    assert not changed
    assert message == 'foo'
    assert diff == 'bar'



# Generated at 2022-06-20 22:08:26.042750
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.file import atomic_move
    from ansible.module_utils.six import b
    from ansible.module_utils.six.moves import StringIO

    # create tempfile as mkstemp fails to create tmpfile
    tmp = StringIO()
    tmp.name = tempfile.mkstemp()


# Generated at 2022-06-20 22:08:30.328386
# Unit test for function present
def test_present():
    module = AnsibleModule({'dest': 'test/file', 'line': 'some line', 'check_mode': False})
    present(module, 'test/file', regexp=None,
            search_string=None, line='some line', insertafter=None,
            insertbefore='EOF', create=False, backup='', backrefs=True,
            firstmatch=False)



# Generated at 2022-06-20 22:08:36.733878
# Unit test for function absent
def test_absent():
    test_module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            regexp=dict(default=None),
            backup=dict(default=False, type='bool'),
            line=dict(default=None),
            search_string=dict(default=None)
        )
    )

    test_module.exit_json = Mock()
    test_module.check_mode = False
    test_module._diff = True
    test_module.params['dest'] = '/test/file'
    test_module.params['line'] = 'test line'
    test_module.params['regexp'] = None
    test_module.params['backup'] = False
    absent(test_module, '/test/file', None, None, 'test line', False)
    assert test_module

# Generated at 2022-06-20 22:08:43.644968
# Unit test for function write_changes
def test_write_changes():
  module = AnsibleModule
  module.tmpdir = os.getcwd()
  module.params = dict(
    validate = None,
    unsafe_writes = None
  )
  b_lines = [b'test1', b'test2']
  dest = os.path.join(os.getcwd(), 'testfile')
  write_changes(module, b_lines, dest)
  assert os.path.isfile(dest)
  with open(dest) as f:
    assert f.readlines() == ['test1', 'test2']
  os.remove(dest)
  assert not os.path.isfile(dest)


# Generated at 2022-06-20 22:08:49.333948
# Unit test for function absent
def test_absent():
    assert not os.path.exists('file')
    present(module, 'file', None, None, 'line1\n', None, None, True, False, False, False)
    assert os.path.exists('file')
    present(module, 'file', None, None, 'line2\n', None, None, True, False, False, False)
    assert os.path.exists('file')
    with open('file', 'rb') as f:
        b_lines = f.readlines()
    assert len(b_lines) == 3
    assert b_lines[1] == to_bytes('line1\n', errors='surrogate_or_strict')
    absent(module, 'file', None, None, 'line2\n', False)
    assert os.path.exists('file')

# Generated at 2022-06-20 22:08:57.087719
# Unit test for function present
def test_present():
    with tempfile.NamedTemporaryFile() as temp:
        temp.write(b"test1\ntest2\ntest3")
        temp.flush()

# Generated at 2022-06-20 22:08:58.038158
# Unit test for function absent
def test_absent():

    assert absent(module, dest, regexp, search_string, line, backup) != True


# Generated at 2022-06-20 22:09:54.405853
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils import common_koji
    from ansible.module_utils import basic

# Generated at 2022-06-20 22:10:09.561744
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.six import PY2


# Generated at 2022-06-20 22:10:14.943384
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    changed = True
    message = 'ownership, perms or SE linux context changed'
    diff={}
    result = check_file_attrs(module, changed, message, diff)
    assert result[0] == message
    assert result[1] == changed



# Generated at 2022-06-20 22:10:29.324757
# Unit test for function check_file_attrs
def test_check_file_attrs():
    o = {"changed":True, "msg":"ownership, perms or SE linux context changed" }
    args = dict(
        path='/etc/sudoers',
        follow=False,
        mode=None,
        owner=None,
        seuser=None,
        serole=None,
        setype=None,
        selevel=None
    )
    module = AnsibleModule(argument_spec=args)
    assert module.set_fs_attributes_if_different(args, False, diff=True) == True
    assert check_file_attrs(module, True, "", True) == (o['msg'], o['changed'])
    #print("Passed check_file_attrs() unit test")


# Generated at 2022-06-20 22:10:37.967663
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Create a dummy module
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(),
            mode = dict(),
            secontext = dict(),
            owner = dict(),
            group = dict(),
        )
    )
    # Create a dummy message and a dummy diff
    message = ""
    diff = ""

    assert (check_file_attrs(module, False, message, diff) == ("ownership, perms or SE linux context changed", True))


# Generated at 2022-06-20 22:10:54.561152
# Unit test for function main
def test_main():
    data_type_definition = {
        'state': 'present',
        'create': False,
        'path': '<PATH>',
        'line': '# Ansible Managed',
    }

    data_type = type('', (object,), data_type_definition)


# Generated at 2022-06-20 22:11:01.553325
# Unit test for function absent
def test_absent():
    # test_file_absent_regexp
    # run absent() with regexp
    dest = '/tmp/test_file_absent_regexp'
    regexp = '^# test line'
    line = '# test line'
    search_string = None
    backup = False
    module = AnsibleModule(argument_spec=dict())
    f = NamedTemporaryFile(delete=False)

# Generated at 2022-06-20 22:11:11.844014
# Unit test for function check_file_attrs
def test_check_file_attrs():

    module = AnsibleModule({}, {}, False, False)

    class FakeModule(object):
        def __init__(self):
            self.params = {
                'path': 'somepath',
                'owner': 'someowner',
                'group': 'somegroup',
                'mode': 'somemode',
                'seuser': 'somelabel',
                'serole': 'somerole',
                'setype': 'sometype',
                'selevel': 'somelabel',
            }
            self.set_fs_attributes_if_different = lambda x, y, **z: True

    module.module_class = FakeModule

    changed, message = False, ''
    changed, message = check_file_attrs(module, changed, message, diff=dict())