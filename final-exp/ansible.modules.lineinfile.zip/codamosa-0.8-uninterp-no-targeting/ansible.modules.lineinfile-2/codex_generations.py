

# Generated at 2022-06-20 22:02:00.891798
# Unit test for function present
def test_present():
    dest = '/tmp/testfile'
    regexp = 'test\n'
    line = 'test'
    insertafter = 'BOF'
    insertbefore = None
    create = False
    backup = True
    backrefs = True
    firstmatch = True

    assert os.path.exists(dest) == False
    present(module, dest, regexp, None, line, insertafter, insertbefore, create, backup, backrefs, firstmatch)
    assert os.path.exists(dest) == True
    with open(dest) as f:
        for l in f:
            assert l == 'test\n'
    os.remove(dest)



# Generated at 2022-06-20 22:02:03.040119
# Unit test for function present

# Generated at 2022-06-20 22:02:09.248437
# Unit test for function main

# Generated at 2022-06-20 22:02:10.466269
# Unit test for function absent
def test_absent():
    assert absent('c', True, '/tmp/testfile', '^1', '1', False) == "file not present"

# Generated at 2022-06-20 22:02:19.922867
# Unit test for function check_file_attrs
def test_check_file_attrs():
  module = AnsibleModule(
    argument_spec = dict(
      path = dict(required=True),
      state = dict(default="present", choices=["present", "absent"]),
      insertafter = dict(required=False),
      insertbefore = dict(required=False),
      firstmatch = dict(default=False, type='bool'),
      create = dict(default=False, type='bool'),
      backup = dict(default=False, type='bool'),
      line = dict(),
      regexp = dict(),
      owner = dict(),
      group = dict(),
      mode = dict(),
      seuser = dict(),
      serole = dict(),
      setype = dict(),
      selevel = dict()
    ),
    supports_check_mode=True
  )

  # mode is changed

# Generated at 2022-06-20 22:02:31.827103
# Unit test for function present
def test_present():

    #basic test
    dest = '/tmp/dest'
    regexp = 'regexp=present'
    search_string = None
    line = 'regexp=present'
    insertafter = None
    insertbefore = None
    create = True
    backup = False
    backrefs = False
    firstmatch = False

# Generated at 2022-06-20 22:02:33.059735
# Unit test for function check_file_attrs
def test_check_file_attrs():
    check_file_attrs(module, 'changed', 'message', 'diff')


# Generated at 2022-06-20 22:02:36.101752
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={})
    changed = False
    message = ""
    message, changed = check_file_attrs(module, changed, message, diff={})
    assert changed == False
    assert message == ""
    assert module._diff == False



# Generated at 2022-06-20 22:02:47.363099
# Unit test for function absent
def test_absent():
    module = AnsibleModule(argument_spec=dict(dest=dict(type='str'), regexp=dict(type='path'),
                                              search_string=dict(type='str'), line=dict(type='str'), backup=dict(type='bool')))

    # TODO: fix issue with AnsibleModule.run_command
    # TODO: fix issue with AnsibleModule.set_fs_attributes_if_different

    def run_command_side_effect(args, **kwargs):
        class FakePopen(object):
            stdout = ''

            def communicate(self):
                return (self.stdout, '')


# Generated at 2022-06-20 22:02:59.136667
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils import file_common
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import PY3


# Generated at 2022-06-20 22:03:25.979339
# Unit test for function absent
def test_absent():
    assert absent(module, dest, regexp, search_string, line, backup) == None


# Generated at 2022-06-20 22:03:29.691534
# Unit test for function absent
def test_absent():
    assert absent(dest='/tmp/file_exists',
                  regexp=None,
                  search_string='foo',
                  line='bar',
                  backup=False) == 'file not present'
    assert absent(dest='/tmp/file_exists',
                  regexp=None,
                  search_string='foo',
                  line='bar',
                  backup=True) == 'file not present'


# Generated at 2022-06-20 22:03:33.880895
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # TODO: Make this a proper unit test which actually tests a change
    #       (it currently passes a dummy empty dict as diff)
    #       instead of just testing if the function can be called
    #       without raising an exception
    module = AnsibleModule({'path': 'dummy'})
    changed = False
    message = ""
    diff = dict()

    # Call the check_file_attrs function
    message, changed = check_file_attrs(module, changed, message, diff)



# Generated at 2022-06-20 22:03:45.287170
# Unit test for function main
def test_main():
    """Unit test for function main"""
    # Setup
    params = dict(
        path="/tmp/ansible_test_file_line.txt",
        state='present',
        regexp=None,
        search_string=None,
        line='string1',
        insertafter=None,
        insertbefore=None,
        backrefs=False,
        create=False,
        backup=False,
        firstmatch=False,
        validate=None,
        _diff=False,
        _ansible_check_mode=False,
        _ansible_diff=False,
        _uses_shell=False,
        _ansible_debug=False,
        _ansible_string_conversion_action='warn',
    )

# Generated at 2022-06-20 22:03:54.699118
# Unit test for function write_changes
def test_write_changes():
    # creating a mock module to work with
    class MockModule(object):

        def __init__(self):
            self.tmpdir = tempfile.mkdtemp()
            self.atomic_move = os.rename
            self.params = dict()
            self.params['backup'] = False
            self.params['unsafe_writes'] = True

        def run_command(self, cmd):
            return (0, '', '')

        def fail_json(self, *args, **kwargs):
            raise Exception(args[0])

    # creating a mock module
    mocked_module = MockModule()

    # creating a temporary file to work with
    temporary_file = tempfile.mkstemp()

    # writing some content in the file

# Generated at 2022-06-20 22:04:06.616177
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'dest': 'testfile',
        'search_string': None,
        'regexp': None,
        'line': 'test',
        'insertbefore': None,
        'insertafter': None,
        'backrefs': False,
        'firstmatch': False,
        'create': False,
        'backup': False,
        '_ansible_tmpdir': 'test_present'
    })
    # There is no file so call the function
    setattr(module, 'exit_json', lambda x: x)
    present(module, 'testfile', None, None, 'test', None, None, False, False, False, False)
    os.unlink('testfile')


# Generated at 2022-06-20 22:04:09.381536
# Unit test for function check_file_attrs
def test_check_file_attrs():
    assert (check_file_attrs(test_module, True, "message", "diff") == ("message and ownership, perms or SE linux context changed", True))


# Generated at 2022-06-20 22:04:16.060671
# Unit test for function present
def test_present():

    module = AnsibleModule({
        'dest': '/tmp/testfile',
        'regexp': '^#.*',
        'line': 'foo',
        'insertbefore': '^#',
        'insertafter': '^#',
        'backrefs': True,
        'create': True
    })

    present(module, '/tmp/testfile', '^#.*', None, 'foo', '^#', '^#', True, False, True, False)


# Generated at 2022-06-20 22:04:22.592781
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(),
            dest = dict(type='path'),
            seuser = dict(),
            serole = dict(),
            setype = dict(),
            owner = dict(),
            group = dict(),
        ),
        supports_check_mode=True
    )
    module.params['path'] = '/etc/foo'
    module.params['owner'] = 'root'
    module.params['group'] = 'root'
    changed = False
    message = ''
    message, changed = check_file_attrs(module, changed, message, {})
    assert changed == True
    assert message == 'ownership, perms or SE linux context changed'



# Generated at 2022-06-20 22:04:23.310968
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-20 22:05:00.728391
# Unit test for function check_file_attrs
def test_check_file_attrs():
    # Setup a basic module
    module = AnsibleModule(argument_spec={
        'spec': dict(required=True),
        'unsafe_writes': dict(type='bool', default=True)
    })

    # Setup the class
    changed = False
    message = ""
    diff = ""

    module.set_fs_attributes_if_different = lambda args, changed, diff: True

    # Run the function
    file_args = {'src': '/tmp/foo', 'dest': '/tmp/bar', 'mode': '0644'}
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == "ownership, perms or SE linux context changed"
    assert changed

    # Run the function
    message = ""
    changed = False

# Generated at 2022-06-20 22:05:13.667063
# Unit test for function write_changes
def test_write_changes():
    def check_test_write_changes(test_cases):
        for test in test_cases:
            module = test[0]
            file_contents = module.params['content']

            write_changes(module, file_contents, module.tmpdir)

            dest_file = os.path.join(module.tmpdir, 'test')

            with open(dest_file, 'rb') as destFile:
                for line in destFile:
                    assert line.rstrip(b'\r\n') in file_contents


# Generated at 2022-06-20 22:05:19.402087
# Unit test for function main
def test_main():
    field_data = [
        "path",
        "state",
        "regexp",
        "search_string",
        "line",
        "insertafter",
        "insertbefore",
        "backrefs",
        "create",
        "backup",
        "firstmatch",
        "validate",
    ]

# Generated at 2022-06-20 22:05:25.781939
# Unit test for function main

# Generated at 2022-06-20 22:05:37.399884
# Unit test for function present

# Generated at 2022-06-20 22:05:45.295293
# Unit test for function absent
def test_absent():
    module = AnsibleModule(argument_spec={
        'dest': {'type': 'str', 'required': True},
        'line': {'type': 'str'},
        'backup': {'type': 'str', 'default': False},
        'search_string': {'type': 'str'},
        'regexp': {'type': 'str'},
    })

    dest = "/home/tuo/test"
    line = "abc"

    absent(module, dest, None, None, line, True)


# Generated at 2022-06-20 22:05:47.574448
# Unit test for function main
def test_main():
    import pytest
    with pytest.raises(AnsibleFilterError) as excinfo:
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:05:57.792004
# Unit test for function check_file_attrs

# Generated at 2022-06-20 22:06:10.846430
# Unit test for function present
def test_present():


    m = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True),
            regexp = dict(),
            search_string = dict(),
            line = dict(required=True),
            insertafter = dict(),
            insertbefore = dict(),
            create = dict(type='bool', default=True),
            backup = dict(type='bool', default=False),
            backrefs = dict(type='bool', default=True),
            firstmatch = dict(type='bool', default=False)
        ),
        supports_check_mode=True
    )

    # Get parameters
    path = m.params.get('path', '')
    regexp = m.params.get('regexp', None)
    search_string = m.params.get('search_string', None)

# Generated at 2022-06-20 22:06:23.899013
# Unit test for function present

# Generated at 2022-06-20 22:06:57.292348
# Unit test for function absent
def test_absent():
    module = AnsibleModule({
        'path': '/tmp/foo',
        },
        False
    )

    b_lines = [b'a\n', b'b\n', b'c\n', b'b\n', b'a\n']
    regexp = None
    search_string = 'b'
    line = 'b'
    backup = False
    dest = '/tmp/foo'

    class Bunch():
        pass

    module.params = Bunch()
    module.check_mode = False
    module.params.update({'path': dest, 'backup': backup, 'state': 'absent'})

    b_dest = to_bytes(dest, errors='surrogate_or_strict')

# Generated at 2022-06-20 22:07:05.126978
# Unit test for function check_file_attrs

# Generated at 2022-06-20 22:07:15.136967
# Unit test for function main
def test_main():
    testargs = "-a name=/tmp/afile -a state=present -a line=\"line\" -a " \
               "validate=md5 -a checksum=d41d8cd98f00b204e9800998ecf8427e" \
               " -a backrefs=True".split()
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

# Generated at 2022-06-20 22:07:22.244600
# Unit test for function absent
def test_absent():
    b_lines = [b'a\n', b'b\n', b'c\n']
    b_cur_line = b'a\n'
    search_string = None
    regexp = None
    b_line = b'a\n'
    found = []
    matcher(b_lines, b_cur_line, search_string, regexp, b_line, found)
    assert found == []


# Generated at 2022-06-20 22:07:29.726599
# Unit test for function write_changes
def test_write_changes():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule, AnsibleModuleError

    # save original open
    original_open = open

    # create a fake ansible module
    class FakeModule(AnsibleModule):
        def __init__(self, args):
            self.params = args
            self.tmpdir = tempfile.mkdtemp()
            super(FakeModule, self).__init__(
                argument_spec={
                    'dest': {'required': True, 'type': 'str'},
                    'line': {'required': True, 'type': 'str'},
                    'validate': {'required': False, 'type': 'str'},
                },
                supports_check_mode=True,
                bypass_checks=True,
            )


# Generated at 2022-06-20 22:07:38.862810
# Unit test for function main
def test_main():
    test_params = {
        'path': 'test.txt',
        'state':  'present',
        'regexp': '',
        'search_string': '',
        'line': '',
        'create': '',
        'backup': '',
        'backrefs': '',
        'firstmatch': '',
    }

# Generated at 2022-06-20 22:07:51.890473
# Unit test for function present

# Generated at 2022-06-20 22:07:58.240226
# Unit test for function present
def test_present():
    line = "line"
    dest = "/path/to/file"
    regexp = "^regexp$"
    search_string = "search_string"
    insertafter = "insertafter"
    insertbefore = "insertbefore"
    b_line = to_bytes(line)
    b_dest = to_bytes(dest)
    b_regexp = to_bytes(regexp)
    b_search_string = to_bytes(search_string)
    b_insertafter = to_bytes(insertafter)
    b_insertbefore = to_bytes(insertbefore)
    b_lines = [b_line,b_line]
    module = MockModule()
    module.run_command = Mock(return_value=(0, '', ''))
    backupdest = ""

# Generated at 2022-06-20 22:08:04.612505
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule

    def fake_atomic_move(src, dst, unsafe_writes=False):
        print("FAKE_atomic_move: %s %s" % (src, dst))

    module = AnsibleModule({}, check_invalid_arguments=False)
    module.atomic_move = fake_atomic_move
    module.run_command = lambda *args: (0, '', '')
    module.tmpdir = '/tmp'

    b_lines = [to_bytes("abc\n")]
    write_changes(module, b_lines, "/tmp/destination")

    module = AnsibleModule({'validate': 'validate %s'}, check_invalid_arguments=False)
    module.atomic_move = fake_atomic_move
    module.run_

# Generated at 2022-06-20 22:08:11.585487
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            backup=dict(type='bool'),
            dest=dict(type='str', required=True),
            others=dict(),
            unsafe_writes=dict(type='bool'),
            validate=dict(type='str'),
        ),
        supports_check_mode=True
    )
    write_changes(module, 'mylines', '/tmp/dest')
    assert module.atomic_move.call_count == 1
    assert module.atomic_move.call_args == call('/tmp/dest', '/tmp/dest', unsafe_writes=False)


# Generated at 2022-06-20 22:09:08.549342
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={'dest': {'type': 'path'}, 'unsafe_writes': {'type': 'bool', 'default': True}})
    msg = ""
    changed = False
    d = {}
    # Test case 1
    msg, changed = check_file_attrs(module, changed, msg, d)
    assert msg == "ownership, perms or SE linux context changed"
    assert changed == True



# Generated at 2022-06-20 22:09:19.083696
# Unit test for function absent
def test_absent():
    import tempfile
    m = AnsibleModule(argument_spec=dict(path=dict(default=None, required=False, type='str'),
        regexp=dict(default=None, required=False, type='str'),
        search_string=dict(default=None, required=False, type='str'),
        line=dict(default=None, required=False, type='str'),
        backup=dict(default=None, required=False, type='bool')), supports_check_mode=True)
    lines=str('one'+os.linesep+'two'+os.linesep+'three'+os.linesep).encode()
    temp=tempfile.NamedTemporaryFile(delete=False)
    temp.write(lines)
    temp.close()

# Generated at 2022-06-20 22:09:19.805100
# Unit test for function main
def test_main():
    main()
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:09:20.188735
# Unit test for function present
def test_present():
    pass



# Generated at 2022-06-20 22:09:32.577492
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec=dict(
        path=dict(type='path', required=True),
        owner=dict(default=None, type='str'),
        group=dict(default=None, type='str'),
        mode=dict(default=None, type='str'),
        seuser=dict(default=None, type='str'),
        serole=dict(default=None, type='str'),
        selevel=dict(default=None, type='str'),
        setype=dict(default=None, type='str'),
        unsafe_writes=dict(default=False, type='bool'),
    ))
    check_file_attrs(module, False, "", "")


# Generated at 2022-06-20 22:09:40.843746
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 22:09:51.128561
# Unit test for function present
def test_present():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.file import file_module_argument_spec

# Generated at 2022-06-20 22:09:57.585067
# Unit test for function main
def test_main():
    module = ansible_module_get()
    p = module.params
    p['state'] = 'present'
    p['path'] = '/tmp/ansible_test_file'
    if os.path.exists('/tmp/ansible_test_file'):
        os.remove('/tmp/ansible_test_file')
    p['line'] = 'Line to insert by Ansible'
    p['create'] = True
    p['backup'] = True
    main()
    if os.path.exists('/tmp/ansible_test_file'):
        os.remove('/tmp/ansible_test_file')
    p['create'] = False
    p['backup'] = False
    with open('/tmp/ansible_test_file', 'w') as fd:
        fd.write

# Generated at 2022-06-20 22:10:04.930639
# Unit test for function present
def test_present():
    from ansible.module_utils import basic
    from ansible.module_utils import file_common


# Generated at 2022-06-20 22:10:10.677692
# Unit test for function write_changes
def test_write_changes():
    out = """
    test"""
    (rc, out, err) = module.run_command(to_bytes(validate % tmpfile, errors='surrogate_or_strict'))
    assert rc == 1
    assert err == 'failed to validate'
