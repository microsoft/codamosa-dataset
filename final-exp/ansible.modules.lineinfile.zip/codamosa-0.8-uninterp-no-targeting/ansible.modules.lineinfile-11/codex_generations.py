

# Generated at 2022-06-20 22:02:13.000656
# Unit test for function write_changes
def test_write_changes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3, StringIO
    import sys

    m = AnsibleModule(
        argument_spec={
            'validate': {'type': 'str'},
        }
    )
    if PY3:
        # In Python 3, a BytesIO can not be used as binary file, the
        # 'wb' flag has to be set
        m.atomic_move = lambda src, dest: open(dest, 'wb').write(open(src).read().encode('utf-8'))
    else:
        m.atomic_move = lambda src, dest: open(dest, 'wb').write(open(src).read())


# Generated at 2022-06-20 22:02:17.187013
# Unit test for function main

# Generated at 2022-06-20 22:02:28.088670
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule({})
    test_file_args = 'file_args'
    assert check_file_attrs(test_module, False, 'message', 'diff') == ('message and ownership, perms or SE linux context changed', True)
    assert check_file_attrs(test_module, True, 'message', 'diff') == ('message and ownership, perms or SE linux context changed', True)
    assert check_file_attrs(test_module, False, 'message', None) == ('message', False)
    assert check_file_attrs(test_module, True, 'message', None) == ('message and ownership, perms or SE linux context changed', True)

# ===========================================
# Module execution.
#



# Generated at 2022-06-20 22:02:44.119424
# Unit test for function main
def test_main():
    import doctest
    from yaml.parser import ParserError
    from yaml.scanner import ScannerError
    from ansible import errors
    print("Loading tests for function")
    print("Tests:")
    print("Trying standard case")
    doctest.testmod(line_number=1)
    print("Trying:")
    print("#Test")
    doctest.testmod(line_number=1)
    print("Testing that it checks if the path is a file")
    
    print("Testing that it checks that there is one of the nodes")
    print("Testing the correct write of the file")
    print("Testing the mode")
    print("Testing the owner")
    print("Testing the group")
    print("Testing the selinux context")
    print("Testing the login user")

# Generated at 2022-06-20 22:02:49.227808
# Unit test for function write_changes
def test_write_changes():
    mock_module = AnsibleModule(
        argument_spec = dict(
            content=dict(type='list', default=[])
        )
    )
    write_changes(mock_module, [to_bytes("foo")], "/tmp/bar")



# Generated at 2022-06-20 22:02:59.956455
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(argument_spec={
        'path': {'type': 'path'},
        'owner': {},
        'group': {},
        'mode': {},
        'seuser': {},
        'serole': {},
        'setype': {},
        'selevel': {},
        'unsafe_writes': {'type': 'bool'}
    })
    setattr(module, 'path', '/tmp/example.conf')
    setattr(module, 'owner', 'apache')
    setattr(module, 'group', 'apache')
    setattr(module, 'serole', 'role_r')
    setattr(module, 'setype', 'type_t')
    setattr(module, 'selevel', 's0')

# Generated at 2022-06-20 22:03:09.924117
# Unit test for function main
def test_main():
    import os
    import tempfile
    fd, tmpfilename = tempfile.mkstemp()
    fileobj = os.fdopen(fd, 'w')
    fileobj.write('# Ansible managed:\n')
    fileobj.write('# test_line_1\n')
    fileobj.write('# test_line_2\n')
    fileobj.close()
    # Check add one line

# Generated at 2022-06-20 22:03:17.334075
# Unit test for function main
def test_main():
    from ansible.module_utils.common.io import StringIO

# Generated at 2022-06-20 22:03:17.810034
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-20 22:03:27.383768
# Unit test for function check_file_attrs
def test_check_file_attrs():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 22:03:56.352683
# Unit test for function main
def test_main():
    testfile="/home/vagrant/ansible_testing/ansible_workdir/testing.yml"
    with open(testfile, 'w') as f:
        f.write("---\n- hosts: all\n  tasks:\n    - name: add the line to a file\n      lineinfile:\n        path: /etc/motd\n        line: 'Hi, I am here'\n")
    os.system("ansible-playbook "+testfile)
    with open("/etc/motd", 'r') as f:
        lines = f.readlines()
    msg = "line is required with state=present"
    result = False
    if lines[-1].strip("\n")=="Hi, I am here":
        result = True
    assert result == True


# Generated at 2022-06-20 22:04:07.950260
# Unit test for function check_file_attrs
def test_check_file_attrs():

    # Setup
    module_mock = Mock(params={"path":"path1", "unsafe_writes":False})
    file_args = {"path": "/path/to/file", "owner": "user", "group": "group"}
    module_mock.set_fs_attributes_if_different = Mock(return_value=True)
    module_mock.load_file_common_arguments = Mock(return_value=file_args)

    # Test with changed = True
    changed = True
    message = "my message"
    ret = check_file_attrs(module_mock, changed, message, [])
    assert ret[0] == "my message and ownership, perms or SE linux context changed"
    assert ret[1] == True
    assert module_mock.set_fs_attributes_if

# Generated at 2022-06-20 22:04:09.726795
# Unit test for function write_changes
def test_write_changes():
    assert True == False


# Generated at 2022-06-20 22:04:19.510208
# Unit test for function check_file_attrs
def test_check_file_attrs():
    """Unit test for function check_file_attrs
    """
    _module = AnsibleModule(
        argument_spec = dict(
            path = dict(required=True, type='path'),
        ),
        supports_check_mode=True
    )

    # Test case: changed
    filename = os.path.realpath(_module.tmpdir) + "/test_check_file_attrs_changed"
    with open(filename, "w") as file:
        file.write("12345")
    _module.params['path'] = filename
    _module.params['owner'] = 'root'
    _module.params['group'] = 'root'
    _module.params['seuser'] = 'system_u'
    _module.params['serole'] = 'object_r'

# Generated at 2022-06-20 22:04:20.065678
# Unit test for function absent
def test_absent():
    assert True

# Generated at 2022-06-20 22:04:25.974779
# Unit test for function absent
def test_absent():
    """
    Test the absent function.
    """
    module = AnsibleModule({'dest': 'test.txt', 'line': 'teststring'})
    dest = os.path.join(os.path.dirname(__file__), 'test.txt')


# Generated at 2022-06-20 22:04:26.565277
# Unit test for function present
def test_present():
    pass


# Generated at 2022-06-20 22:04:31.724464
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({})
    module.params = {'owner': 'root', 'path': '/tmp/test', 'group': 'root', 'mode': '0640'}
    module.fail_json = lambda x: x
    module.set_fs_attributes_if_different = lambda x, y, diff: True
    assert check_file_attrs(module, False, '', '') == ('ownership, perms or SE linux context changed', True)
    module.params = {'owner': 'root', 'path': '/tmp/test', 'group': 'root', 'mode': '0744'}
    assert check_file_attrs(module, True, 'Foo', '') == ('Foo and ownership, perms or SE linux context changed', True)



# Generated at 2022-06-20 22:04:32.233055
# Unit test for function present
def test_present():
    pass



# Generated at 2022-06-20 22:04:37.228178
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule({'path':'/tmp/foo', 'force':False, 'unsafe_writes':False, 'backup':False, 'mode':None, 'owner':None, 'group':None, 'seuser':None, 'serole':None, 'setype':None, 'selevel':None}, False)
    try:
        message, changed = check_file_attrs(module, True, 'test message', 'test diff')
        assert changed == True and message == 'test message and ownership, perms or SE linux context changed', "return value is not correct"
    except Exception:
        raise AssertionError
test_check_file_attrs()



# Generated at 2022-06-20 22:05:17.675685
# Unit test for function check_file_attrs

# Generated at 2022-06-20 22:05:18.100619
# Unit test for function present
def test_present():

    assert True



# Generated at 2022-06-20 22:05:24.819013
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'validate': dict(type='str'),
        'dest': dict(type='str'),
        'tmpdir': dict(type='str'),
        'unsafe_writes': dict(required=True, type='bool')
    })
    module.params['validate'] = 'echo "validate" >> "%s"'
    module.params['tmpdir'] = '/tmp'
    module.params['unsafe_writes'] = True

    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(b'content')
        dest = f.name

    b_lines = [b'content']
    write_changes(module, b_lines, dest)

    with open(dest, 'rb') as f:
        results = f.readlines()



# Generated at 2022-06-20 22:05:36.719166
# Unit test for function main
def test_main():
    ansible_module = mock.MagicMock()
    ansible_module.params = {
        'create': True, 'regexp': 'sed', 'search_string': '', 'insertbefore': 'ins_bef', 'backrefs': True, 'dest': 'foo',
        'state': 'present', 'backup': False, 'line': 'sedsed', 'insertafter': 'ins_aft', 'firstmatch': True,
        'validate': 'validate'}
    ansible_module.check_mode = True
    ansible_module.exit_json = mock.MagicMock()
    ansible_module._diff = True
    ansible_module.warn = mock.MagicMock()
    mocker.patch('ansible.module_utils.basic.AnsibleModule', return_value=ansible_module)

# Generated at 2022-06-20 22:05:47.687166
# Unit test for function present
def test_present():

    dest = "/path/to/file"
    regexp = "^line to match"
    line = "line to replace"
    insertafter = "line to replace"
    insertbefore = "line to replace"
    create = True


# Generated at 2022-06-20 22:05:54.681198
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test_module = AnsibleModule({
        'path': '/tmp/testfile',
        'backup': 'yes',
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
    })

    test_file_args = test_module.load_file_common_arguments(test_module.params)
    changed = test_module.set_fs_attributes_if_different(test_file_args, False)
    assert changed is False
    return changed



# Generated at 2022-06-20 22:06:00.902177
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class fake_module:
        params = {}
        def fail_json(self, msg):
            return msg

# Generated at 2022-06-20 22:06:05.938067
# Unit test for function present
def test_present():
    module = AnsibleModule({
        'dest': '/etc/networks',
        'line': '192.168.1.1 net1',
        'insertbefore': 'BOF'
    })
    present(module, '/etc/networks', None, None, '192.168.1.1 net1', None, 'BOF', True, False, False, False)



# Generated at 2022-06-20 22:06:18.500093
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    from ansible.module_utils.basic import AnsibleModule

    def check_module(test_parameters):
        module_params = {
            'path': 'test/path/file',
            'state': 'present',
            'regexp': None,
            'search_string': None,
            'line': 'test line',
            'create': False,
            'backup': False,
            'backrefs': False,
            'insertafter': None,
            'insertbefore': None,
            'firstmatch': False,
            'validate': None,
            'attributes': {}
        }
        module_params.update(test_parameters)

# Generated at 2022-06-20 22:06:26.572941
# Unit test for function check_file_attrs
def test_check_file_attrs():
    dest = '/etc/sudoers'
    module_args = dict(
        path=dest,
        regexp='^%ADMIN ALL=',
        line='%ADMIN ALL=(ALL) NOPASSWD: ALL',
        validate='/usr/sbin/visudo -cf %s',
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )
    # pylint: disable=protected-access
    module._supports_diff = True
    diff = {}
    message = ""
    changed = False
    message, changed = check_file_attrs(module, changed, message, diff)
    assert message == "ownership, perms or SE linux context changed"
    assert changed is True

# Generated at 2022-06-20 22:07:09.944175
# Unit test for function check_file_attrs
def test_check_file_attrs():
    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.set_fs_attributes_if_different_called = 0
            self.set_fs_attributes_if_different_return_value = False
        def set_fs_attributes_if_different(self, file_args, changed, diff):
            self.set_fs_attributes_if_different_called += 1
            return self.set_fs_attributes_if_different_return_value

    module = FakeModule({
        'owner': 'root',
        'group': 'root',
        'mode': '0644',
    })
    assert check_file_attrs(module, True, 'test message', 'test diff') == ('test message and ownership, perms or SE linux context changed', True)



# Generated at 2022-06-20 22:07:17.208742
# Unit test for function main
def test_main():
    line = 'goodbye to you'
    regexp = 'my love'
    search_string = 'love'
    create = False
    backup = False
    backrefs = False
    firstmatch = False

# Generated at 2022-06-20 22:07:26.361476
# Unit test for function present
def test_present():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    mock_module = basic.AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True),
            regexp=dict(),
            search_string=dict(),
            line=dict(required=True),
            insertafter=dict(),
            insertbefore=dict(),
            create=dict(),
            backup=dict(),
            backrefs=dict(),
            firstmatch=dict(),
            validate=dict()
        ),
    )

    dest = '/tmp/testfile'
    regexp = "^regexp$"
    line = "line"
    insertafter = "insertafter"
    insertbefore = "insertbefore"


# Generated at 2022-06-20 22:07:31.662022
# Unit test for function present
def test_present():
    assert present(None, '/tmp/config', None, None, 'host={{ hostname }}', None, None, True, None, False, True) is None


# Generated at 2022-06-20 22:07:43.410161
# Unit test for function main
def test_main():
    # unit test for function main

    # create the module object that we'll use
    module, module_name, args, kwargs = AnsibleModuleMock({
        'path': 'path',
        'backup': False,
        'regexp': 'regexp',
        'search_string': 'search_string',
        'line': 'line',
        'insertafter': 'insertafter',
        'insertbefore': 'insertbefore',
        'backrefs': False,
        'create': False,
        'firstmatch': False,
        'validate': 'validate',
        'state': 'absent'
    })

    # We will be mocking everything, so this is all we need for now
    if mocked_module_obj:
        module.exit_json = mocked_module_obj.exit_json

# Generated at 2022-06-20 22:07:55.777265
# Unit test for function present
def test_present():
    import os
    import tempfile
    tempdir = tempfile.mkdtemp(dir='/tmp', prefix='ansible_lineinfile_test_')

    test_dest = os.path.join(tempdir, 'test_file')
    fd, test_file = tempfile.mkstemp(dir=tempdir, prefix='ansible_lineinfile_test_')
    with os.fdopen(fd, 'w') as f:
        f.write('zzzzz\n')
        f.write('aaaaa\n')
        f.write('aaaaa\n')
        f.write('xxxxx\n')
        f.write('bbbbb\n')
        f.write('xxxxx\n')
        f.write('ccccc\n')
        f.write('xxxxx\n')
       

# Generated at 2022-06-20 22:08:00.930051
# Unit test for function check_file_attrs
def test_check_file_attrs():
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='path'),
            owner = dict(type='str'),
            group = dict(type='str'),
            mode = dict(type='raw'),
            seuser = dict(type='str'),
            serole = dict(type='str'),
            setype = dict(type='str'),
            selevel = dict(type='str'),
        )
    )
    diff = {}
    changed = False
    message, changed = check_file_attrs(module, changed,
                                        "ownership, perms or SE linux context changed", diff)
    assert changed == False


# Generated at 2022-06-20 22:08:08.346287
# Unit test for function write_changes
def test_write_changes():

    class DummyStream(object):

        def __init__(self):
            self.lines = []

        def writelines(self, lines):
            self.lines = list(lines)

    class DummyModule(object):

        def __init__(self):
            self.params = dict()
            self.tmpdir = None
            self.fail_json = None
            self.run_command = None
            self.atomic_move = None

    class DummyCommand(object):

        def __init__(self):
            self.rc = 0
            self.out = None
            self.err = None

    class DummyAtomicMove(object):

        def __init__(self):
            self.src = None
            self.dest = None


# Generated at 2022-06-20 22:08:09.590229
# Unit test for function write_changes
def test_write_changes():
    pass



# Generated at 2022-06-20 22:08:22.188884
# Unit test for function absent
def test_absent():
    module = AnsibleModule(
        argument_spec = dict(
            dest=dict(required=True),
            regexp=dict(required=False),
            search_string=dict(required=False),
            line=dict(required=False),
            backup=dict(required=False, default=False, type='bool')))

    def write_changes(module, b_lines, dest):
        with open(to_bytes(dest, errors='surrogate_or_strict'), 'wb') as f:
            for b_line in b_lines:
                f.write(b_line)

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']
    line = module.params['line']
    backup = module.params['backup']

# Generated at 2022-06-20 22:09:13.643514
# Unit test for function present
def test_present():
    """ Test for the lineinfile module """

    # Test with default options
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(required=True),
            line=dict(required=True),
            regexp=dict(),
            search_string=dict(),
            insertafter=dict(),
            insertbefore=dict(),
            create=dict(type='bool', default=False),
            backup=dict(type='bool', default=False),
            backrefs=dict(type='bool', default=False),
            firstmatch=dict(type='bool', default=False),
            validate=dict(),
        ),
    )

    dest = module.params['dest']
    regexp = module.params['regexp']
    search_string = module.params['search_string']

# Generated at 2022-06-20 22:09:19.796447
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(argument_spec={
        'dest': {'type': 'str', 'required': True},
        'content': {'type': 'str', 'default': ''},
        'unsafe_writes': {'type': 'bool', 'default': True},
        'validate': {'type': 'str', 'default': None},
        'tmpdir': {'type': 'str', 'default': None}
    })
    write_changes(module, module.params['content'], module.params['dest'])


# Generated at 2022-06-20 22:09:30.672403
# Unit test for function main
def test_main():
    cur_argv = sys.argv
    cur_platform = platform.system()
    sys.argv = ["ansible-test",
                "--debug",
                "file",
                "--platform", "posix",
                "--connection", "local",
                "--module-path", "../../../lib",
                "--forks", "1",
                "--inventory", "../../../inventory",
                "--skip-tags", "skip_me_if_you_can",
                "--args", 'path=./test/ansible/stdin_action_plugin/tmp/test_tmp state=present'
                ]

# Generated at 2022-06-20 22:09:39.122105
# Unit test for function absent

# Generated at 2022-06-20 22:09:53.357030
# Unit test for function write_changes
def test_write_changes():
    # Create a test file with some lines
    with open('test_file', 'w') as f:
        f.writelines(['1\n', '2\n', '3\n', '4\n', '5\n'])
    # Create module
    module = AnsibleModule({}, check_invalid_arguments=False)
    # Modify some lines
    lines = [b'1\n', b'2\n', b'changed\n', b'4\n', b'changed\n']
    # Check function
    write_changes(module, lines, 'test_file')
    # Check we get the same result by getting the content of the file again
    with open('test_file', 'rb') as f:
        new_content = f.readlines()
    assert new_content == lines



# Generated at 2022-06-20 22:10:02.709470
# Unit test for function present
def test_present():
    dest = 'test'
    regexp = None
    search_string = None
    line = 'line'
    insertafter = None
    insertbefore = None
    create = False
    backup = False
    backrefs = False
    firstmatch = True


# Generated at 2022-06-20 22:10:15.295188
# Unit test for function present
def test_present():
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='str', required=True),
            regexp=dict(type='str', required=True),
            search_string=dict(type='str', required=True),
            line=dict(type='str', required=True),
            insertafter=dict(type='str', required=True),
            insertbefore=dict(type='str', required=True),
            create=dict(type='bool', required=True),
            backup=dict(type='bool', required=True),
            backrefs=dict(type='bool', required=True),
            firstmatch=dict(type='bool', required=True),
        ),
        supports_check_mode=True
    )

# Generated at 2022-06-20 22:10:30.904038
# Unit test for function main
def test_main():
    import tempfile

# Generated at 2022-06-20 22:10:41.634643
# Unit test for function write_changes
def test_write_changes():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='str', required=True),
            dest=dict(type='str', required=True),
            backup=dict(type='bool', default=False),
            force=dict(type='bool', default=False),
            validate=dict(type='str'),
            unsafe_writes=dict(type='bool', default=False),
        )
    )

    srcdir = module.tmpdir
    destdir = module.tmpdir

    # create source
    src = os.path.join(module.tmpdir, 'src')
    b_src = to_bytes(src, errors='surrogate_or_strict')
    testfile = open(src, 'w')
    testfile.write("hippity hoppity")

# Generated at 2022-06-20 22:10:53.441262
# Unit test for function check_file_attrs
def test_check_file_attrs():
    test = AnsibleModule(argument_spec={'test_spec': dict()})
    test.params = {'path': 'test_target',
                   'owner': 'user_A',
                   'group': 'group_A',
                   'mode': '0640',
                   'seuser': 'seuser_A',
                   'serole': 'serole_A',
                   'setype': 'setype_A',
                   'selevel': 'selevel_A',
                   'unsafe_writes': False}
    test_changed, test_message, test_diff = False, "", []

    test_message, test_changed = check_file_attrs(test, test_changed, test_message, test_diff)

    assert test_changed

