

# Generated at 2022-06-21 10:31:30.873205
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    timers = Timers()
    with pytest.raises(TypeError):
        timers['foo'] = 1.0
    return

# Generated at 2022-06-21 10:31:34.007326
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add("a", 2.0)
    timers.add("a", 3.0)
    timers.add("a", 5.0)
    assert timers.total("a") == 2.0 + 3.0 + 5.0
    assert math.isnan(timers.total("b"))


# Generated at 2022-06-21 10:31:38.105188
# Unit test for method mean of class Timers
def test_Timers_mean():
    test_timers = Timers()
    test_timers.add("a", 6)
    test_timers.add("a", 2)
    test_timers.add("a", 4)
    assert test_timers.mean("a") == 4


# Generated at 2022-06-21 10:31:41.450289
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    assert Timers().apply(len, name="") == 0, \
        "Default number of timings is 0"

# Generated at 2022-06-21 10:31:47.381802
# Unit test for method median of class Timers
def test_Timers_median():

    t = Timers()
    t.add("a", 2)
    assert t.median("a") == 2
    assert t.count("a") == 1
    assert t.stdev("a") != t.stdev("a")
    t.add("a", 4)
    assert t.median("a") == 3
    t.add("a", 6)
    assert t.median("a") == 4


if __name__ == "__main__":
    test_Timers_median()

# Generated at 2022-06-21 10:31:48.961458
# Unit test for constructor of class Timers
def test_Timers():
    foo = Timers()
    assert foo._timings == {}
    assert foo.data == {}


# Generated at 2022-06-21 10:31:51.109771
# Unit test for method min of class Timers
def test_Timers_min():
    timer = Timers()
    timer.add("timer1", 1)
    timer.add("timer2", 2)
    assert timer.min("timer1") == 1
    assert timer.min("timer2") == 2

# Generated at 2022-06-21 10:31:56.654847
# Unit test for method count of class Timers
def test_Timers_count():
    # Initialize timers
    timers = Timers()
    # Add one timing
    timers.add('timer1', 0.1)
    # Add more timings
    timers.add('timer2', 0.2)
    timers.add('timer2', 0.3)
    # Check timings
    assert timers.count('timer1') == 1
    assert timers.count('timer2') == 2


# Generated at 2022-06-21 10:32:05.650139
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the Timers.mean method"""
    # Check the mean method with an empty list
    timers = Timers({})
    assert timers.mean('test') == 0.0
    
    # Check the mean with a list of 0's
    timers = Timers({})
    timers.add('test', 0.0)
    timers.add('test', 0.0)
    assert timers.mean('test') == 0.0

    # Check the mean with a list of 1's
    timers = Timers({})
    timers.add('test', 1.0)
    timers.add('test', 1.0)
    assert timers.mean('test') == 1.0

    # Check the mean with a list of 1's
    timers = Timers({})
    timers.add('test', 1.0)

# Generated at 2022-06-21 10:32:09.602727
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    assert timers.data == {}

    timers = Timers(a=1)
    timers.add(name='a', value=2)
    assert timers.data == {'a': 3}

    timers.add(name='b', value=3)
    assert timers.data == {'a': 3, 'b': 3}


# Generated at 2022-06-21 10:32:18.487741
# Unit test for method total of class Timers
def test_Timers_total():
    """Unit test for method total of class Timers"""
    name = "test"
    value1 = 1.2
    value2 = 2.4
    timer_1 = Timers()
    timer_1.add(name=name, value=value1)
    timer_1.add(name=name, value=value2)
    assert timer_1.total(name=name) == value1 + value2

# Generated at 2022-06-21 10:32:20.584223
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test __setitem__ raises expected exception"""
    t = Timers()
    with pytest.raises(TypeError):
        t["test"] = 1.0


# Generated at 2022-06-21 10:32:24.101283
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    import numpy
    
    t = Timers()
    t.add('test', 1)
    t.add('test', 2)
    t.add('test', 3)
    
    assert numpy.isnan(t.stdev('test'))


# Generated at 2022-06-21 10:32:26.250410
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("test", 10)
    assert timers.count("test") == 1


# Generated at 2022-06-21 10:32:29.363129
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Unit test for method clear of class Timers"""
    timers = Timers()
    timers.add("a", 1)
    timers.add("b", 2)
    assert len(timers) == 2
    assert len(timers._timings["a"]) == 1
    timers.clear()
    assert len(timers) == 0
    assert len(timers._timings) == 0

# Unit tests for method total of class Timers

# Generated at 2022-06-21 10:32:32.200283
# Unit test for method max of class Timers
def test_Timers_max():
    """Make sure max functionality works"""
    t = Timers()
    t.add('speed', 20)
    t.add('distance', 20)
    assert t.max('speed') == 20
    assert t.max('distance') == 20

# Generated at 2022-06-21 10:32:35.600048
# Unit test for method total of class Timers
def test_Timers_total():
    def add(timers, name, value):
        timers.add(name, value)

    timers = Timers()
    add(timers, "abc", 1.0)
    add(timers, "def", 2.0)
    add(timers, "abc", 3.0)
    assert timers.total('abc') == 4.0
    assert timers.total('def') == 2.0

# Generated at 2022-06-21 10:32:38.870303
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('one', 1)
    timers.add('two', 2)
    assert timers.mean('one') == 1
    assert timers.mean('two') == 2

# Generated at 2022-06-21 10:32:50.502396
# Unit test for method median of class Timers
def test_Timers_median():
    # Initialize
    t = Timers()
    # Test with empty timer
    t.add("t", 0)
    assert t.count("t") == 1
    assert t.total("t") == 0
    assert t.max("t") == 0
    assert t.mean("t") == 0
    assert t.median("t") == 0
    assert t.min("t") == 0
    assert t.stdev("t") == math.nan
    # Test with one timing
    t.add("t", 1)
    assert t.count("t") == 2
    assert t.total("t") == 1
    assert t.max("t") == 1
    assert t.mean("t") == 0.5
    assert t.median("t") == 0.5
    assert t.min("t") == 0
   

# Generated at 2022-06-21 10:32:53.806147
# Unit test for method add of class Timers
def test_Timers_add():
    """Test the Timers.add method"""
    timers = Timers()
    timers.add("timer_1", 1)
    assert timers["timer_1"] == 1
    timers.add("timer_1", 1)
    asser

# Generated at 2022-06-21 10:33:01.868576
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    t.add('test', 10)
    t.add('test', 10)
    t.add('test', 20)
    assert t.median('test') == 10
    assert t.median('not-found') == 0

# Generated at 2022-06-21 10:33:07.497569
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test example"""
    timers = Timers()
    timers.add(name='abc', value=3)
    timers.add(name='abc', value=2)
    timers.add(name='def', value=4)
    timers.add(name='xyz', value=1)
    assert timers.min('abc') == 2
    assert timers.min('def') == 4
    assert timers.min('xyz') == 1
    assert timers.min('def') == 4
    assert timers.min('abc') == 2
    assert timers.min('def') == 4
    assert timers.min('abc') == 2
    assert timers.min('def') == 4
    assert timers.min('xyz') == 1


# Generated at 2022-06-21 10:33:14.249521
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers.apply(len, name="test") # should raise KeyError

    timers.add("test.1", 1)
    timers.add("test.2", 2)

    assert timers.total("test") == 3
    assert timers.count("test") == 2
    assert timers.min("test") == 1
    assert timers.max("test") == 2
    assert timers.mean("test") == (1 + 2) / 2
    assert timers.median("test") == 2

# Generated at 2022-06-21 10:33:21.311327
# Unit test for method max of class Timers
def test_Timers_max():
    data = Timers()
    data.add('test', 3)
    data.add('test2', 3)
    assert data.max('test') == 3.0
    assert data.max('test2') == 3.0
    try:
        data.max('test3')
        assert False
    except KeyError:
        pass


# Generated at 2022-06-21 10:33:25.396568
# Unit test for method total of class Timers
def test_Timers_total():
    """Unit test"""
    timers = Timers()
    timers.add('test', 1)
    assert timers.total('test') == 1

    timers.add('test', 2)
    assert timers.total('test') == 3


# Generated at 2022-06-21 10:33:28.613413
# Unit test for method add of class Timers
def test_Timers_add():
    """ Add a timing value to the given timer"""
    timer1 = Timers()
    timer1.add('a', 2)
    assert isinstance(timer1, Timers)


# Generated at 2022-06-21 10:33:31.090960
# Unit test for constructor of class Timers
def test_Timers():  # pragma: no cover
    timer = Timers()
    assert not timer
    assert not timer._timings
    timer["foo"]
    assert not timer["foo"]



# Generated at 2022-06-21 10:33:35.624991
# Unit test for method total of class Timers
def test_Timers_total():
    """Test timer.total()

    >>> timer = Timers()
    >>> timer.add('test', 0.2)
    >>> timer.add('test', 0.6)
    >>> timer.total('test')
    0.8
    """

# Generated at 2022-06-21 10:33:47.551841
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers({"a": 1, "b": 2, "c": 3})
    assert timers.count("a") == 1
    assert timers.count("c") == 1
    assert timers.count("d") == 0
    assert timers.total("a") == 1
    assert timers.total("c") == 3
    assert timers.total("d") == 0
    assert timers.min("a") == 1
    assert timers.min("c") == 3
    assert timers.max("a") == 1
    assert timers.max("c") == 3
    assert timers.mean("a") == 1
    assert timers.mean("c") == 3
    assert timers.median("a") == 1
    assert timers.median("c") == 3
    assert timers.stdev("a") == math.nan

# Generated at 2022-06-21 10:33:51.435960
# Unit test for method max of class Timers
def test_Timers_max():
    x = Timers()
    x.add("key1", 12)
    x.add("key1", 13)
    x.add("key1", 15)
    x.add("key1", 14)
    x.add("key1", 10)
    assert x.max("key1") == 15
    assert x.max("key2") == 0


# Generated at 2022-06-21 10:33:59.276698
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers["foo"] = 1.0
    except TypeError:
        pass
    else:
        assert False, "TypeError was not raised"



# Generated at 2022-06-21 10:34:01.209285
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    return

timers = Timers()
"""Information about timers"""

# Generated at 2022-06-21 10:34:05.997621
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test Timers_mean()"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.mean('test') == 2

# Generated at 2022-06-21 10:34:10.973773
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    timer = Timers()
    timer.data["test"] = 1.0
    try:
        timer["test"] = 1.0
        assert False, "Timer should not accept item assignment"
    except TypeError:
        pass

# Generated at 2022-06-21 10:34:12.441715
# Unit test for method apply of class Timers
def test_Timers_apply():
    data = Timers()
    assert data.apply(len, 'test') == 0

# Generated at 2022-06-21 10:34:17.664513
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()

    def sum_apply(values):
        return sum(values)

    timers.add("test", 0.5)
    assert timers.apply(sum_apply, name="test") == 0.5, \
        "timer.apply(sum_apply, name='test') should return 0.5"


# Generated at 2022-06-21 10:34:22.035062
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method"""
    timers = Timers()
    timers.add("1", 1)
    timers.add("1", 5)
    timers.add("1", 3)
    assert timers.mean("1") == 3


# Generated at 2022-06-21 10:34:27.916460
# Unit test for method max of class Timers
def test_Timers_max():
    """Add nested timers and check that the timing is correctly read"""
    # Fix variable
    fixtures = ["f0", "f1", "f2"]

    # Create an instance of the class Timers
    timers = Timers()

    # Set the timers
    for f in fixtures:
        timers[f] = 42

    # Test the method max
    assert timers.max() == 42


# Generated at 2022-06-21 10:34:33.329209
# Unit test for method mean of class Timers
def test_Timers_mean():
    timer = Timers()
    assert timer.mean('name1') == 0
    timer._timings['name1'].extend([1, 2])
    assert timer.mean('name1') == 1.5
    timer.add('name1', 3)
    assert timer.mean('name1') == 2


# Generated at 2022-06-21 10:34:38.683597
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers["name"] = 1.2
    except TypeError as e:
        if str(e) == "Timers does not support item assignment. Use '.add()' to update values.":
            return True
    raise AssertionError("Timers.__setitem__() Exception failed")


# Generated at 2022-06-21 10:34:45.607667
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("max", 3)
    timers.add("max", 4)
    timers.add("max", 5)
    assert timers.max("max") == 5

# Generated at 2022-06-21 10:34:50.853295
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Testing method stdev of class Timers"""
    timers = Timers()
    timers.add("test", 1.0)
    assert timers.stdev("test") == math.nan
    timers.add("test", 2.0)
    assert timers.stdev("test") == math.sqrt(2.0/3.0)
    try:
        timers.stdev("foo")
    except KeyError:
        pass

# Generated at 2022-06-21 10:34:56.464098
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test for mean"""
    t = Timers()
    t.add("foo", 1)
    assert t.mean("foo") == 1
    t.add("foo", 1)
    assert t.mean("foo") == 1
    t.add("foo", 3)
    assert t.mean("foo") == 1.5

# Generated at 2022-06-21 10:35:03.650444
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test that the private dictionary is not modified when setting a timer value"""
    timers = Timers({1: 1, 2: 2})
    timers.add(1, 1)
    try:
        timers[1] = 10
        assert False, "Previously checked for exception"
    except TypeError as err:
        assert str(err) == (
            "Timers does not support item assignment. "
            "Use '.add()' to update values."
        )
    assert len(timers.data) == 2
    assert timers.data.get(1) == 2.0
    assert len(list(timers._timings.items())) == 1
    assert list(timers._timings.values())[0] == [1.0]
    assert list(timers._timings.values())[0] == [1.0]

# Generated at 2022-06-21 10:35:08.372704
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    # Test for empty list
    assert timers.min("") == 0
    # Test for list with one or more elements
    timers._timings[""] = [1,2,3,4]
    assert timers.min("") == 1

# Generated at 2022-06-21 10:35:13.401376
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Initialize an empty Timers instance
    my_timers: Timers = Timers()
    # Add 2 seconds to a timer named 'clock'
    my_timers.add("clock", 2.0)
    # Add 4 seconds to the same timer
    my_timers.add("clock", 4.0)
    # The mean value of timer 'clock' should be 3.0
    assert my_timers.mean("clock") == 3.0
    # Add 4 seconds to a timer named 'other'
    my_timers.add("other", 4.0)
    # The mean value of timer 'other' should be 4.0
    assert my_timers.mean("other") == 4.0
    # Printing the instance prints the timer names and their mean values
    print(my_timers)


# Generated at 2022-06-21 10:35:23.127858
# Unit test for method median of class Timers
def test_Timers_median():

    timers = Timers()

    timers.add('test', 150)
    timers.add('test', 300)
    timers.add('test', 450)
    timers.add('test', 600)
    timers.add('test', 750)
    timers.add('test', 900)

    assert timers.median('test') == 450

    timers.clear()

    timers.add('test', 100)
    timers.add('test', 200)
    timers.add('test', 300)
    timers.add('test', 400)
    timers.add('test', 500)
    timers.add('test', 600)

    assert timers.median('test') == 350

    timers.clear()

    timers.add('test', 150)
    timers.add('test', 300)
    timers.add('test', 450)

# Generated at 2022-06-21 10:35:32.420311
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    assert not timers
    assert timers.count("test-1") == 0
    assert timers.total("test-1") == 0
    assert timers.min("test-1") == 0
    assert timers.max("test-1") == 0
    assert timers.mean("test-1") == 0
    assert timers.median("test-1") == 0
    assert math.isnan(timers.stdev("test-1"))

    timers.add("test-1", 1)
    assert timers.count("test-1") == 1
    assert timers.total("test-1") == 1
    assert timers.min("test-1") == 1
    assert timers.max("test-1") == 1
    assert timers.mean("test-1") == 1
    assert timers.median("test-1") == 1

# Generated at 2022-06-21 10:35:33.387903
# Unit test for constructor of class Timers
def test_Timers():
    timer = Timers()
    assert timer.data == {}



# Generated at 2022-06-21 10:35:37.710935
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    # Create an object
    timer = Timers()
    # Add some timing values
    timer.add('a', 1.0)
    # Check the value
    assert timer['a'] == 1.0
    # Add another timing value
    timer['a'] = 2.0
    # Check the value
    assert timer['a'] == 3.0


# Generated at 2022-06-21 10:35:49.101508
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    timers = Timers()
    assert timers



# Generated at 2022-06-21 10:35:52.420150
# Unit test for constructor of class Timers
def test_Timers():
    """Test construction of class Timers"""
    timer = Timers()
    assert timer.data == {}
    timer = Timers({"a": 1.0})
    assert timer.data == {"a": 1.0}


# Generated at 2022-06-21 10:35:58.746633
# Unit test for method median of class Timers
def test_Timers_median():

    timers = Timers()
    timers.add("calculate_fitness", 0.01)
    timers.add("calculate_fitness", 0.02)
    timers.add("calculate_fitness", 0.03)

    median = timers.median("calculate_fitness")
    assert median == 0.02

# Generated at 2022-06-21 10:36:03.647111
# Unit test for method count of class Timers
def test_Timers_count():
    """Test count method for Timers class for a list of multiple empty times and
    a list of single time"""
    timers = Timers()

    timings = [5, 8, 3, 6]
    assert len(timings) == timers.count("Test")
    assert 4 == timers.count("Test")


# Generated at 2022-06-21 10:36:07.807458
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Unit test for method clear of class Timers"""
    timers = Timers()
    assert len(timers) == 0
    timers.add("test", 10)
    assert len(timers) == 1
    timers.clear()
    assert len(timers) == 0



# Generated at 2022-06-21 10:36:13.341612
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for method stdev of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    assert timers.stdev('test') == 0
    timers.add('test', 2)
    assert timers.stdev('test') == math.sqrt(2/3)
    timers.add('test', 3)
    assert timers.stdev('test') == math.sqrt(2)

# Generated at 2022-06-21 10:36:16.147262
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    assert Timers() == {}


# Generated at 2022-06-21 10:36:24.623869
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Tests the method apply() of class Timers"""
    timers = Timers()
    timers.add("num_rows", 1)
    timers.add("num_rows", 2)
    timers.add("num_rows", 3)
    timers.add("num_cols", 1)
    timers.add("num_cols", 2)
    assert timers.apply(sum, "num_rows") == 6
    assert timers.apply(sum, "num_cols") == 3
    assert timers.apply(len, "num_rows") == 3
    assert timers.apply(len, "num_cols") == 2
    assert timers.apply(lambda values: min(values), "num_rows") == 1
    assert timers.apply(lambda values: min(values), "num_cols") == 1

# Generated at 2022-06-21 10:36:28.050780
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 2)
    timers.add("a", 3)

    assert timers.min("a") == 1


# Generated at 2022-06-21 10:36:31.119485
# Unit test for method count of class Timers
def test_Timers_count():
    instance = Timers()
    assert instance.count("test_timer") == 0
    instance.add("test_timer", 0.1)
    assert instance.count("test_timer") == 1


# Generated at 2022-06-21 10:36:56.289318
# Unit test for method max of class Timers
def test_Timers_max():
    import unittest
    from unittest.mock import patch
    my_timers = Timers()
    my_timers.add("name",4)
    my_timers.add("name",5)
    assert isinstance(my_timers.max("name"), float)
    assert my_timers.max("name") == 5


# Generated at 2022-06-21 10:37:00.192873
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add("foo", 1.0)
    timers.add("foo", 2.0)
    timers.add("bar", 1.0)
    assert timers.total("foo") == 3.0
    assert timers.total("bar") == 1.0


# Generated at 2022-06-21 10:37:10.236890
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers.add("t1", 5)
    timers.add("t1", 3)
    timers.add("t2", 2)
    assert timers.apply(lambda x: max(x or [0]), name="t1") == 5
    assert timers.apply(lambda x: min(x or [0]), name="t2") == 2
    assert timers.apply(lambda x: sum(x or [0]), name="t1") == 8
    assert timers.apply(lambda x: len(x or [0]), name="t2") == 1
    assert timers.apply(lambda x: statistics.mean(x), name="t1") == 4
    assert timers.apply(lambda x: statistics.median(x), name="t1") == 4

# Generated at 2022-06-21 10:37:13.208455
# Unit test for method total of class Timers
def test_Timers_total():
    """Unit test for method total()"""
    # Initialize timer
    timers = Timers()
    # Add a timing with name 'test' and value 0.5
    timers.add("test", 0.5)
    # Print total
    assert isinstance(timers.total("test"), float)
    assert timers.total("test") == 0.5

# Generated at 2022-06-21 10:37:20.926079
# Unit test for constructor of class Timers
def test_Timers():
    from dicts import DictDiffer
    d = DictDiffer({}, {}).assert_equal
    d(Timers(),
      {'_timings': {},
       'data': {}})
    d(Timers(data=1, _timings=2),
      {'_timings': {},
       'data': {}})
    d(Timers('bool', data=1, _timings=2,
             name='value'),
      {'_timings': {},
       'data': {'bool': True}})


# Generated at 2022-06-21 10:37:25.984624
# Unit test for method max of class Timers
def test_Timers_max():
    "Test the method max of class Timers"
    t = Timers()
    t.add('A', 1)
    t.add('B', 2)
    t.add('C', 3)
    value = t.max('A')
    assert value == 1
    value = t.max('B')
    assert value == 2
    value = t.max('C')
    assert value == 3


# Generated at 2022-06-21 10:37:29.909684
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("a", 1.0)
    t.add("b", 2.0)
    t.add("a", 2.0)
    t.add("b", 1.0)

    assert t.min("a") == 1.0
    assert t.min("b") == 1.0



# Generated at 2022-06-21 10:37:31.473056
# Unit test for method add of class Timers
def test_Timers_add():
    """Test Timers.add()"""
    t = Timers()
    t.add('a', 1)
    t.add('a', 2)
    assert t['a'] == 3


# Generated at 2022-06-21 10:37:34.815530
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()

    timers.add('time', 1)
    timers.add('time', 3)
    timers.add('time', 2)

    assert timers.total('time') == 6

# Generated at 2022-06-21 10:37:45.882186
# Unit test for method min of class Timers
def test_Timers_min():
    """Test whether the method min works."""
    # Create a Timers instance
    timers = Timers()

    # Add some timers
    timers.add("A", 1)
    timers.add("B", 2)
    timers.add("A", 1.5)
    timers.add("B", 2.5)
    timers.add("A", 2)
    timers.add("B", 3)

    # Test the method min
    assert timers.min("A") == 1.0
    assert timers.min("B") == 2.0

    # Test the method min when timer does not exist
    try:
        timers.min("C")
    except KeyError:
        pass
    except Exception:
        raise Exception(
            "Exception raised when calling method min with a non-existing timer"
        )


# Generated at 2022-06-21 10:38:33.824203
# Unit test for method mean of class Timers
def test_Timers_mean():
    from math import isclose
    timers = Timers()
    timers.add("n1", 2.0)
    timers.add("n2", 3.0)
    assert isclose(timers.mean("n1"), 2.0), "Mean of [2.0] should be 2.0"
    assert isclose(timers.mean("n2"), 3.0), "Mean of [3.0] should be 3.0"
    timers.add("n1", 4.0)
    assert isclose(timers.mean("n1"), 3.0), "Mean of [2.0, 4.0] should be 3.0"

# Generated at 2022-06-21 10:38:40.315551
# Unit test for constructor of class Timers
def test_Timers():
    # Create object
    timers = Timers()
    # Check empty behavior
    assert len(timers) == 0
    assert timers.count("t1") == 0
    assert timers.total("t1") == 0
    assert timers.min("t1") == 0
    assert timers.max("t1") == 0
    assert timers.mean("t1") == 0
    assert timers.median("t1") == 0
    assert timers.stdev("t1") == 0
    assert len(timers.data) == 0
    # Add first timing
    timers.add("t1", value=0.1)
    # Check behavior
    assert len(timers) == 1
    assert timers.count("t1") == 1
    assert timers["t1"] == 0.1
    assert timers.total("t1") == 0.1

# Generated at 2022-06-21 10:38:48.881105
# Unit test for constructor of class Timers
def test_Timers():
    from hypothesis import given, settings
    from hypothesis.strategies import integers, sampled_from
    from unittest import TestCase

    settings.register_profile("ci", settings(deadline=None))
    settings.load_profile("ci")

    class TestTimers(TestCase):
        """Unit test for class Timers"""

        @given(sampled_from(["foo", "bar", "baz", "qux"]))
        def test_add_existing(self, name: str) -> None:
            """Add a timing to an existing timer"""
            timers = Timers()
            timers.add(name, 0.0)
            timers.add(name, 0.0)
            self.assertEqual(timers.count(name), 2)
            self.assertEqual(timers.total(name), 0.0)



# Generated at 2022-06-21 10:38:54.637169
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("foo", 1.0)
    assert timers.median("foo") == 1.0
    timers.add("foo", 2.0)
    assert timers.median("foo") == 1.5
    timers.add("foo", 3.0)
    assert timers.median("foo") == 2.0
    timers.clear()
    assert timers.median("foo") == 0.0

# Generated at 2022-06-21 10:38:57.010781
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add("timer1", 1.)
    assert math.isnan(timers.stdev("timer1"))
    timers.add("timer1", 2.)
    assert timers.stdev("timer1") == 0.5

# Generated at 2022-06-21 10:39:01.687430
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    t = Timers(data={'foo': 5.0})
    assert t.stdev('foo') == 0
    t.add('foo', 5.0)
    assert t.stdev('foo') == 0
    t.add('foo', 5.0)
    assert t.stdev('foo') == 0
    t.add('foo', -5.0)
    assert t.stdev('foo') == 5.0
    t.add('foo', -5.0)
    assert t.stdev('foo') == 7.0710678118654755

# Generated at 2022-06-21 10:39:07.643731
# Unit test for method count of class Timers
def test_Timers_count():
    # Initialize a Timers object
    timers = Timers()
    # Add some values to the object
    timers.add("begin", 1.0)
    timers.add("begin", 3.0)
    timers.add("end", 5.0)
    # Call the count method
    value = timers.count("begin")
    # Check the result
    assert value == 2

# Generated at 2022-06-21 10:39:10.172187
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    with pytest.raises(TypeError):
        timers['dummy'] = 0


# Generated at 2022-06-21 10:39:16.795594
# Unit test for method min of class Timers
def test_Timers_min():
    """test for method min"""
    t = Timers()
    t.add("test1",100)
    t.add("test1",200)
    t.add("test1",300)
    t.add("test1",400)
    assert t.min("test1") == 100
    assert t.min("test2") == 0
    t = Timers()
    assert t.min("test1") == 0


# Generated at 2022-06-21 10:39:19.938781
# Unit test for method apply of class Timers
def test_Timers_apply():  # pylint: disable=invalid-name,missing-function-docstring
    new_timers = Timers()
    new_timers.add("test_name", 5.0)
    assert new_timers.apply(sum, "test_name") == 5.0

# Generated at 2022-06-21 10:40:50.265707
# Unit test for method mean of class Timers
def test_Timers_mean():
    timer = Timers()
    timer.add("test", 2)
    timer.add("test", 4)
    timer.add("test", 6)
    assert timer.mean("test") == 4.0


# Generated at 2022-06-21 10:40:53.127536
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()

    timers.add("a", 1)
    assert timers.max("a") == 1

    timers.add("a", 5)
    assert timers.max("a") == 5

    timers.add("a", 3)
    assert timers.max("a") == 5

    try:
        timers.max("b")
    except KeyError:
        pass
    else:
        assert False


# Generated at 2022-06-21 10:40:59.026655
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for method stdev of class Timers"""
    times = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    assert Timers().stdev("test") == math.nan
    assert Timers(test=10).stdev("test") == math.nan
    assert Timers(test=0).stdev("test") == math.nan
    assert Timers(test=20).stdev("test") == math.nan
    assert Timers(_timings=dict(test=times)).stdev("test") == 0.0



# Generated at 2022-06-21 10:41:05.749436
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test for method clear of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.clear()
    assert timers.count('test') == 0
    assert timers.total('test') == 0
    assert timers.min('test') == 0
    assert timers.max('test') == 0
    assert timers.mean('test') == 0
    assert timers.median('test') == 0
    assert timers.stdev('test') == 0


# Generated at 2022-06-21 10:41:08.469199
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('name', 1.2)
    assert timers.max('name') == 1.2

# Generated at 2022-06-21 10:41:14.134103
# Unit test for method total of class Timers
def test_Timers_total():
  """Unit test for method total of class Timers"""
  # We first create a new object of class Timers
  timers = Timers()
  # Then, we add a new timing to the object timers.
  timers.add("timers", 1)
  # We expect that the total value of the timer timers is given by
  assert timers.total("timers") == 1


# Generated at 2022-06-21 10:41:17.688300
# Unit test for method total of class Timers
def test_Timers_total():
    from helpers.Timers import Timers
    timers = Timers()
    timers.add("x", 3)
    timers.add("x", 5)
    timers.add("y", 7)
    assert timers.total("x") == 8
    assert timers.total("y") == 7

# Generated at 2022-06-21 10:41:29.333728
# Unit test for method add of class Timers
def test_Timers_add():
    timer = Timers()

    # Add timer for loop time
    for i in range(3):
        timer.add("loop", 1.0)
    for i in range(5):
        timer.add("loop", 0.5)

    # Add timer for tomography time
    for i in range(5):
        timer.add("tomography", 0.4)
    for i in range(3):
        timer.add("tomography", 0.6)

    # Verify that the different timers contain the correct values
    assert timer.data == {"loop": 5.0, "tomography": 4.0}