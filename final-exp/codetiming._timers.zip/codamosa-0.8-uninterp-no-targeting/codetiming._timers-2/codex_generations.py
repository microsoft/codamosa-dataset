

# Generated at 2022-06-21 10:31:29.614411
# Unit test for method total of class Timers
def test_Timers_total():
    print("\nTest of method total of class Timers")
    t = Timers()
    t.add('test', 100)
    t.add('test', 200)
    print(t.total('test'))


# Generated at 2022-06-21 10:31:33.830878
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    from pytest import approx

    timers = Timers()

    # 4 + 8 + 12 + 16 = 40
    timers.add('A', 4)
    timers.add('A', 8)
    timers.add('A', 12)
    timers.add('A', 16)

    # Mean = 40 / 4 = 10
    assert timers.mean('A') == approx(10.0)


# Generated at 2022-06-21 10:31:39.572090
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    t = Timers()
    t.add("test", 2)
    try:
        t["test"] = 1
    except TypeError as error:
        assert error.args[0] == "Timers does not support item assignment. Use '.add()' to update values."
    else:
        assert False

# Generated at 2022-06-21 10:31:43.763505
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    t = Timers()
    try:
        t.stdev("timings")
    except KeyError:
        assert True
    t._timings["timings"] = [1,2,3]
    assert t.stdev("timings") > 0


# Generated at 2022-06-21 10:31:51.177311
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""

    # Test without args
    timers = Timers()
    assert isinstance(timers, UserDict)

    # Test with dict arg
    timers = Timers({'a': 1})
    assert isinstance(timers, UserDict)
    assert timers['a'] == 1

    # Test with dict arg
    timers = Timers(dict(a=1))
    assert isinstance(timers, UserDict)
    assert timers['a'] == 1

    # Test with args
    timers = Timers(*(1, 2, 3, 4), **dict(a=1))
    assert isinstance(timers, UserDict)
    assert timers == dict(a=1)



# Generated at 2022-06-21 10:31:53.214687
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    assert timers.min("test") == 1

# Generated at 2022-06-21 10:31:55.532010
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers._timings = {"Timer1": [1,2,3,4,5]}
    assert timers.total("Timer1") == 15

# Generated at 2022-06-21 10:31:57.081086
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers.data == {}



# Generated at 2022-06-21 10:32:05.724458
# Unit test for method median of class Timers
def test_Timers_median():
    """Test for method median of class Timers"""
    import pytest
    TIMERS = Timers()
    TIMERS.add("TEST", 5.0)
    TIMERS.add("TEST", 10.0)
    TIMERS.add("TEST", 15.0)
    assert TIMERS.median("TEST") == 10.0
    TIMERS.add("TEST", 20.0)
    assert TIMERS.median("TEST") == 15.0
    TIMERS.add("TEST2", 10.0)
    TIMERS.add("TEST2", 15.0)
    assert TIMERS.median("TEST2") == 12.5
    with pytest.raises(KeyError):
        TIMERS.median("TEST3")



# Generated at 2022-06-21 10:32:09.918487
# Unit test for method mean of class Timers
def test_Timers_mean():
    """
    Unit test for method mean of class Timers

    """
    # Initialize Timers object
    timers = Timers()

    # Check mean with empty timer
    assert math.isnan(timers.mean('a'))

    # Add values to test mean
    num_vals = 4
    for i in range(num_vals):
        timers.add('a', i)

    # Check mean value
    assert timers.mean('a') == (num_vals-1)/2

# Generated at 2022-06-21 10:32:14.458946
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add('a', 1)
    assert timers['a'] == 1.0


# Generated at 2022-06-21 10:32:22.954344
# Unit test for method median of class Timers
def test_Timers_median():
    x = Timers()
    x.add("a",1.2)
    assert x.median("a") == 1.2
    x.add("b",1.1)
    assert x.median("b") == 1.1
    x.add("c",1.3)
    assert x.median("c") == 1.3
    x.add("d",1.0)
    assert x.median("d") == 1.0
    x.add("e",1.5)
    assert x.median("e") == 1.5
    x.add("f",1.4)
    assert x.median("f") == 1.4


# Generated at 2022-06-21 10:32:26.211792
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add("test",1.0)
    timers.add("test",2.0)
    assert abs(timers.stdev("test") - 0.7071067811865475) < 1e-10

# Generated at 2022-06-21 10:32:28.329780
# Unit test for constructor of class Timers
def test_Timers():
    """Test constructor"""
    timers = Timers()
    assert timers == {}
    assert timers._timings == {}
    assert len(timers) == 0



# Generated at 2022-06-21 10:32:29.959662
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""

    assert Timers().apply(len, name="test1") == 0

# Generated at 2022-06-21 10:32:31.140659
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    def do_test():
        timers = Timers()
        timers['a'] = 1.0
    assert_raises(TypeError, do_test)

# Generated at 2022-06-21 10:32:37.146816
# Unit test for method count of class Timers
def test_Timers_count():
    """Unit test for method count of class Timers"""
    timers = Timers()
    timers.add("count1", 1621.715)
    timers.add("count1", 1621.715)
    timers.add("count1", 1621.715)
    timers.add("count1", 1621.715)
    timers.add("count1", 1621.715)
    timers.add("count1", 1621.715)
    timers.add("count1", 1621.715)
    timers.add("count1", 1621.715)
    timers.add("count1", 1621.715)
    timers.add("count1", 1621.715)
    assert timers.count("count1") == 10


# Generated at 2022-06-21 10:32:43.165153
# Unit test for method count of class Timers
def test_Timers_count():
    """Test method count of class Timers"""
    timers = Timers()
    assert timers.count("timer") == 0
    timers.add("timer", 1.234)
    assert timers.count("timer") == 1
    timers.add("timer", 2.345)
    assert timers.count("timer") == 2


# Generated at 2022-06-21 10:32:51.761360
# Unit test for method median of class Timers
def test_Timers_median():
    import pytest
    timers = Timers()
    timers.add("test",42)
    assert timers.median("test") == 42
    timers.add("test",70)
    assert timers.median("test") == 56
    timers.add("test",3)
    assert timers.median("test") == 42
    timers.add("test",77)
    assert timers.median("test") == 56
    timers.add("test",90)
    assert timers.median("test") == 70
    with pytest.raises(KeyError):
        timers.median("nope")

test_Timers_median()

# Generated at 2022-06-21 10:32:58.937409
# Unit test for method add of class Timers
def test_Timers_add():
    # Test add on a non-existing key
    timers = Timers()
    name = "foobar"
    value = 42.0
    timers.add(name, value)
    assert name in timers
    assert timers[name] == value
    assert name in timers._timings
    assert timers._timings[name] == [value]

    # Test add on an existing key
    value = 43.0
    timers.add(name, value)
    assert name in timers
    assert timers[name] == value * 2
    assert name in timers._timings
    assert timers._timings[name] == [value, value]


# Generated at 2022-06-21 10:33:05.685510
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test class Timers"""
    timer_1 = Timers()
    timer_1['test_1'] = 0.5
    timer_1.add('test_2', 0.5)
    timer_1.add('test_2', 1.0)
    timer_1.add('test_2', 1.5)
    timer_1.add('test_2', 2.0)

    assert timer_1.stdev('test_1') == 0.0
    assert timer_1.stdev('test_2') == 0.7071067811865476

# Generated at 2022-06-21 10:33:08.993868
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test that we can't set timer values"""
    timers = Timers()

    with pytest.raises(TypeError):
        timers['test'] = 1.0

# Generated at 2022-06-21 10:33:17.305590
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers.add("timer_1", 1)
    timers.add("timer_1", 2)
    timers.add("timer_1", 3)
    assert timers.apply(len, name="timer_1") == 3
    assert timers.apply(sum, name="timer_1") == 6
    assert timers.apply(lambda values: min(values or [0]), name="timer_1") == 1
    assert timers.apply(lambda values: max(values or [0]), name="timer_1") == 3
    assert timers.apply(lambda values: statistics.mean(values or [0]), name="timer_1") == 2
    assert timers.apply(lambda values: statistics.median(values or [0]), name="timer_1") == 2



# Generated at 2022-06-21 10:33:22.567860
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    assert timers.data == {}
    timers.add('test', 10.0)
    assert timers.data['test'] == 10.0
    timers.clear()
    assert timers.data == {}



# Generated at 2022-06-21 10:33:26.112360
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add('test', 10)
    timers.add('test', 20)
    timers.add('test', 30)
    assert timers.stdev('test') == 10


# Generated at 2022-06-21 10:33:30.026740
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers.add('time', 5)
    assert timers.apply(sum, 'time') == 5
    assert timers.apply(len, 'time') == 1
    assert timers.apply(math.sqrt, 'time') == math.sqrt(5)

# Generated at 2022-06-21 10:33:40.266739
# Unit test for method count of class Timers
def test_Timers_count():
    # Initiate a Timers object
    test = Timers()

    # Add and remove some count
    test.add('test', 2.0)
    test.add('test', 2.0)
    assert test.count('test') == 2
    test.data.pop('test', None)

    # Add and remove some count
    test.add('test', 2.0)
    test.add('test', 4.0)
    assert test.count('test') == 2
    test.data.pop('test', None)

    # Remove non-existing count
    assert test.count('test') == 0


# Generated at 2022-06-21 10:33:44.610719
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Exercise the apply() method of Timers"""
    timers = Timers()
    timers.add("name", 1)
    timers.add("name", 2)
    timers.add("name", 3)
    assert timers.apply(lambda v: sum(v), "name") == 6
    assert timers.apply(len, "name") == 3

# Generated at 2022-06-21 10:33:51.985653
# Unit test for method total of class Timers
def test_Timers_total():
    """Test for method total"""
    # Timers object with no values
    x = Timers()
    assert x.total('test') == 0

    # Timers object with one value
    x.add('test', 10)
    assert x.total('test') == 10

    # Timers object with two values
    x.add('test', 20)
    assert x.total('test') == 30

    # Timers object with one value in 'test1' and one in 'test2'
    x.add('test2', 20)
    assert x.total('test') == 30, 'total of test'
    assert x.total('test2') == 20, 'total of test2'


# Generated at 2022-06-21 10:34:02.822834
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test `apply` method of class `Timers`"""
    timers = Timers()
    timers.add("time_1", 1.0)
    timers.add("time_1", 2.0)
    timers.add("time_1", 3.0)
    timers.add("time_2", 0.0)
    timers.add("time_2", 1.0)
    timers.add("time_2", 2.0)
    timers.add("time_2", 3.0)
    assert timers.count("time_1") == 3
    assert timers.count("time_2") == 4
    assert timers.total("time_1") == 6.0
    assert timers.total("time_2") == 6.0
    assert timers.min("time_1") == 1.0

# Generated at 2022-06-21 10:34:13.984132
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 0.123)
    timers.add("test", 123.456)
    assert abs(timers.min("test") - 0.123) < 1e-15
    assert abs(timers.max("test") - 123.456) < 1e-10
    assert abs(timers.mean("test") - 61.7895) < 1e-4
    assert abs(timers.median("test") - 61.7895) < 1e-4

# Generated at 2022-06-21 10:34:16.733732
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers._timings["foo"] = [0, 1, 2]
    assert timers.count("foo") == 3


# Generated at 2022-06-21 10:34:28.499199
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median() method from Timers class"""
    # Test with a list of even length
    test_list = [5, 2, 4, 2, 6, 2, 1]
    assert collections.Counter(test_list).most_common(1)[0][0] == 2
    assert statistics.median(test_list) == 2
    assert Timers().apply(statistics.median, test_list) == 2

    # Test with a list of odd length
    test_list = [6, 2, 9, 3, 6, 1, 9]
    assert collections.Counter(test_list).most_common(1)[0][0] == 6
    assert statistics.median(test_list) == 5.5
    assert Timers().apply(statistics.median, test_list) == 5.5

    # Test with an empty list

# Generated at 2022-06-21 10:34:40.416537
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method Timers.add()"""
    class TimersImpl(Timers):
        """Override Timers test implementation"""
        def __init__(self, *args, **kwargs) -> None:
            """Override constructor"""
            super().__init__(*args, **kwargs)
            self.called: Dict[str, Any] = {}

        def add(self, name: str, value: float) -> None:
            """Record calls"""
            self.called.setdefault(name, []).append(value)
            super().add(name, value)

    timers = TimersImpl()
    assert timers.called == {}
    assert timers.data == {}
    assert timers._timings == {}

    timers.add("name1", value=1.0)
    assert timers.called == {"name1": [1.0]}


# Generated at 2022-06-21 10:34:44.594466
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add('test', range(1000))
    assert timers.median('test') == 499.5

# Generated at 2022-06-21 10:34:50.274330
# Unit test for method clear of class Timers
def test_Timers_clear():
    """
    Example:
    >>> timers = Timers()
    >>> timers.add('foo', 1)
    >>> timers.add('bar', 2)
    >>> timers.add('foo', 3)
    >>> timers  #doctest: +ELLIPSIS
    {'foo': 4, 'bar': 2}
    >>> timers.clear()
    >>> timers  #doctest: +ELLIPSIS
    {}
    """

# Generated at 2022-06-21 10:34:52.034500
# Unit test for method mean of class Timers
def test_Timers_mean():
    x = Timers()
    assert x.mean("test") == 0.0


# Generated at 2022-06-21 10:35:00.648724
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""

    from random import randrange

    value = randrange(1, 100)
    timer = Timers(dict(test=value))
    assert timer.apply(sum, "test") == value
    assert timer.apply(len, "test") == 1

    from collections import Counter
    from plasoscaffolder.common.output.definitions import LoggerVerbosity
    import pytest
    with pytest.raises(KeyError, match=r"testx"):
        timer.apply(Counter, "testx")

    assert timer.apply(lambda x: sum(x), "test") == value


# Generated at 2022-06-21 10:35:04.460684
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Unit test for method clear of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert "test" in timers
    timers.clear()
    assert "test" not in timers


# Generated at 2022-06-21 10:35:11.652960
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test setter of Timers"""
    # Create custom dictionary
    timers = Timers()

    # Try to set dictionary key
    try:
        timers["test"] = 1
        raise AssertionError
    except TypeError:
        pass

    # Try to set dictionary key using update
    try:
        timers.update(test=1)
        raise AssertionError
    except TypeError:
        pass


# Generated at 2022-06-21 10:35:21.722681
# Unit test for method max of class Timers
def test_Timers_max():
    assert Timers().max("test") == 0
    timers = Timers()
    timers.add("test", 1)
    assert timers.max("test") == 1
    timers.add("test", 2)
    assert timers.max("test") == 2
    timers.add("test", -1)
    assert timers.max("test") == 2
    timers.add("test", 0)
    assert timers.max("test") == 2
    timers.add("test", 1)
    assert timers.max("test") == 2



# Generated at 2022-06-21 10:35:28.997878
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    assert Timers().stdev("") == math.nan
    assert Timers().stdev("1") == math.nan

    timers = Timers()
    timers.add("1", 1)
    assert timers.stdev("1") == math.nan

    timers = Timers()
    timers.add("1", 1)
    timers.add("1", 2)
    assert timers.stdev("1") == 0.5

# Generated at 2022-06-21 10:35:33.912785
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test method __setitem__ in class Timers"""
    try:
        timers = Timers()
        timers["total"] = 5
    except TypeError:
        pass
    else:
        raise AssertionError(
            "Method __setitem__ of class Timers did not raise TypeError"
        )


# Generated at 2022-06-21 10:35:36.429852
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.max('test') == 3

# Generated at 2022-06-21 10:35:46.350604
# Unit test for method min of class Timers
def test_Timers_min():
    # test for timer with one entry
    test_dict = Timers()
    test_name = "test_5"
    test_value = 10
    test_dict.data[test_name] = test_value
    test_dict._timings["test_5"] = [100]
    assert test_dict.min(name=test_name) == 100

    # test for timer with multiple entries
    test_dict = Timers()
    test_name = "test_6"
    test_value = 10
    test_dict.data[test_name] = test_value
    test_dict._timings["test_6"] = [10, 100, 1000, 10000]
    assert test_dict.min(name=test_name) == 10

    # test for timer with no entries
    test_dict = Timers()
    test_

# Generated at 2022-06-21 10:35:48.570164
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    import pytest
    t = Timers()
    with pytest.raises(TypeError):
        t["foo"] = 1

# Generated at 2022-06-21 10:35:56.336446
# Unit test for method median of class Timers
def test_Timers_median():
    try:
        from typing import Type
        from pytest import approx
        from . import make_timers
    except ImportError:
        return
    # Declare type of class Timers
    timers: Timers = make_timers()
    # Assert that the method median works correctly
    assert timers.median("non-existent") == approx(0)
    assert set(timers.median("no-data") for _ in range(10)) == {0}
    assert set(timers.median("one-value") for _ in range(10)) == {10}
    assert set(timers.median("two-values") for _ in range(10)) == {10}
    assert set(timers.median("even-numbers") for _ in range(10)) == {3.5}

# Generated at 2022-06-21 10:36:00.552586
# Unit test for constructor of class Timers
def test_Timers():  # pylint: disable=redefined-outer-name,unused-variable,missing-docstring
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}



# Generated at 2022-06-21 10:36:02.860252
# Unit test for constructor of class Timers
def test_Timers():  # pragma: no cover
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-21 10:36:09.081518
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    assert math.isnan(timers.median("timer1"))

    timers.add("timer1", 1.0)
    assert timers.median("timer1") == 1.0

    timers.add("timer1", 2.0)
    assert timers.median("timer1") == 1.5

    timers.add("timer1", 3.0)
    assert timers.median("timer1") == 2.0

    timers.add("timer1", 4.0)
    assert timers.median("timer1") == 2.5

    timers.add("timer1", 5.0)
    assert timers.median("timer1") == 3.0

    timers.add("timer1", 6.0)

# Generated at 2022-06-21 10:36:17.512599
# Unit test for method max of class Timers
def test_Timers_max():
    timings = Timers()
    assert timings.max("foo") == 0
    timings._timings["foo"].append(2)
    assert timings.max("foo") == 2
    timings._timings["foo"].append(3)
    assert timings.max("foo") == 3


# Generated at 2022-06-21 10:36:19.827045
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.add('a', 1)
    t.add('a', 2)
    print(t.max('a'))


# Generated at 2022-06-21 10:36:22.820155
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('a', 1.0)
    timers.add('a', 2.0)
    timers.add('a', 3.0)
    assert timers.max('a') == 3.0

# Generated at 2022-06-21 10:36:24.697898
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    mytimers = Timers()
    with pytest.raises(TypeError):
        mytimers['name'] = 2.0


# Generated at 2022-06-21 10:36:36.801061
# Unit test for method apply of class Timers
def test_Timers_apply():
    from statistics import mean, median, stdev

    # create new Timers instance
    timers = Timers()

    # add values for two different keys
    for key in ("key1", "key2"):
        for i in range(5):
            timers.add(key, i)

    # apply mean function to first key
    assert timers.apply(mean, "key1") == mean(list(range(5)))

    # apply median function to second key
    assert timers.apply(median, "key2") == median(list(range(5)))

    # apply stdev function to first key
    assert timers.apply(stdev, "key1") == stdev(list(range(5)))

    # try to apply median function to unkown key

# Generated at 2022-06-21 10:36:43.644232
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Timers.mean()"""

    timers: Timers = Timers()

    timers._timings = {"_test": [1, 4, 4, 3, 6, 3, 4, 3, 2, 3, 2, 5, 6, 4, 1, 4, 2, 6, 2, 5]}
    expected: float = 3.25
    result = timers.mean("_test")

    assert result == expected


# Generated at 2022-06-21 10:36:48.230272
# Unit test for method total of class Timers
def test_Timers_total():
    # Setup
    timers = Timers()
    timers.data = {'a': 2, 'b': 1, 'c': 3}

    # Test
    assert timers.total('b') == 1
    assert timers.total('a') == 2
    assert timers.total('c') == 3
    assert timers.total('d') == 0



# Generated at 2022-06-21 10:36:51.505127
# Unit test for method max of class Timers
def test_Timers_max():
    # test with empty value
    timers = Timers()
    assert timers.max('test') == 0
    # test with non-empty value
    timers.add('test', 10)
    timers.add('test', 15)
    assert timers.max('test') == 15

# Generated at 2022-06-21 10:36:58.897669
# Unit test for method clear of class Timers
def test_Timers_clear():
    a = Timers()
    # Test clear method when timers are empty
    assert (a.data=={} and a._timings=={})
    a.clear()
    assert (a.data=={} and a._timings=={})
    # Test clear method when timers are not empty
    a.data['1'] = 1
    a._timings['1'] = [1, 2]
    a.clear()
    assert (a.data=={} and a._timings=={})


# Generated at 2022-06-21 10:37:03.567247
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 5)
    timers.add("test", 6)
    timers.add("test", 7)
    assert timers.mean("test") == 6

# Generated at 2022-06-21 10:37:14.194545
# Unit test for method clear of class Timers
def test_Timers_clear():
    # Configuration
    name1 = "name1"
    name2 = "name2"
    value1 = 1
    value2 = 2

    # Create object
    timers = Timers()

    # Add values
    timers.add(name1, value1)
    timers.add(name2, value2)

    # Clear values
    timers.clear()
    assert len(timers) == 0
    assert len(timers._timings) == 0


# Generated at 2022-06-21 10:37:22.455755
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    assert timers.min("a") == 0
    assert timers.min("b") == 0
    timers.add("a", 1)
    assert timers.min("a") == 1
    timers.add("a", 2)
    assert timers.min("a") == 1
    timers.add("a", 0.5)
    assert timers.min("a") == 0.5
    timers.add("a", -1)
    assert timers.min("a") == -1

if __name__ == "__main__":
    # Run test
    test_Timers_min()

# Generated at 2022-06-21 10:37:24.513347
# Unit test for method count of class Timers
def test_Timers_count():
    t = Timers()
    t.add('foo', 1)
    assert t.count('foo') == 1


# Generated at 2022-06-21 10:37:26.498432
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test', 10)
    assert timers.max('test') == 10



# Generated at 2022-06-21 10:37:32.044118
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test method apply of class Timers"""
    from pytest import raises
    timers = Timers()
    func = lambda x: max(x + [0])  # ensure the timer can be empty
    with raises(KeyError):
        timers.apply(func, name="test")

    timers._timings["test"].append(0)
    assert timers.apply(func, name="test") == 0
    timers._timings["test"].extend([2, 3])
    assert timers.apply(func, name="test") == 3



# Generated at 2022-06-21 10:37:35.161362
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    import pytest

    result = Timers()
    with pytest.raises(TypeError):
        result['test'] = 0.0

# Generated at 2022-06-21 10:37:40.073479
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Method __setitem__ of class Timers raises TypeError"""
    timers = Timers()
    with pytest.raises(TypeError) as err:
        timers['key'] = 0  # noqa
    assert "does not support item assignment" in str(err.value)


# Generated at 2022-06-21 10:37:43.071567
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add("timer_1", 0.1)
    timers.add("timer_1", 0.1)
    assert timers.total("timer_1") == 0.2
    assert timers.total("timer_2") == 0.0

# Generated at 2022-06-21 10:37:47.794216
# Unit test for method mean of class Timers
def test_Timers_mean():
    x = Timers()
    x.add('c', 2)
    x.add('c', 3)
    x.add('c', 7)
    x.add('c', 4)
    x.add('c', 2)
    assert x.mean('c') == 3.8

# Generated at 2022-06-21 10:37:51.439795
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    timers = Timers()
    timers.add("name", 0.1)
    assert timers["name"] == 0.1
    timers.add("name", 0.2)
    assert timers["name"] == 0.3


# Generated at 2022-06-21 10:38:05.308782
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for method stdev of class Timers"""

    # Create object
    timers = Timers()

    # Add timer
    timers.add("timer1", 1.0)

    # Test stdev
    assert timers.stdev("timer1") == 0.0

    # Add another timer
    timers.add("timer1", 2.0)

    # Test stdev
    assert timers.stdev("timer1") == math.sqrt(2.0/3)

# Generated at 2022-06-21 10:38:09.825288
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test clear method of class Timers"""
    timers = Timers()
    timers.add("foo", 2)
    timers.clear()
    assert len(timers) == 0
    assert len(timers._timings) == 0



# Generated at 2022-06-21 10:38:12.773830
# Unit test for method total of class Timers
def test_Timers_total():
    counts = Timers()
    counts.add("A", 1)
    counts.add("A", 2)
    counts.add("A", 3)

    counts.add("B", 4)
    counts.add("B", 5)
    counts.add("B", 6)

    assert counts.total("A") == 6
    assert counts.total("B") == 15



# Generated at 2022-06-21 10:38:16.468669
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit tests for method apply of class Timers"""
    def test(values):
        return sum(values)
    timers = Timers()
    timers.add(name="v", value=20)
    timers.add(name="v", value=30)
    assert timers.apply(test, name="v") == 50

# Generated at 2022-06-21 10:38:22.595071
# Unit test for method count of class Timers
def test_Timers_count():
    # Create a Timers object
    timers = Timers()
    # Add several values to the timer named ``test``
    for i in range(5):
        timers.add(name='test', value=i)
    # Verify the expected number of values are stored
    assert timers.count('test') == 5


# Generated at 2022-06-21 10:38:25.530959
# Unit test for method total of class Timers
def test_Timers_total():
    """
    Test for the Timers method total
    """
    data = {'A': 1, 'B': 2}
    timers = Timers(data)
    assert timers.total('A') == 1

# Generated at 2022-06-21 10:38:27.628677
# Unit test for method min of class Timers
def test_Timers_min():
    """Minimal value of timings"""
    timers = Timers()
    timers.add('name', 1)
    timers.add('name', 2)
    assert timers.min('name') == 1

# Generated at 2022-06-21 10:38:30.851112
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count("foo") == 0

    timers.add("foo", 1)
    assert timers.count("foo") == 1

    timers.add("foo", 2)
    assert timers.count("foo") == 2

    timers.add("bar", 2)
    assert timers.count("bar") == 1


# Generated at 2022-06-21 10:38:37.831555
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    name = 'test'
    assert timers.min(name) == 0
    timers.add(name, 637)
    assert timers.min(name) == 637
    timers.add(name, 439)
    assert timers.min(name) == 439
    timers.add(name, 548)
    assert timers.min(name) == 439
    timers.add(name, 798)
    assert timers.min(name) == 439
    timers.add(name, 914)
    assert timers.min(name) == 439
    timers.add(name, 0)
    assert timers.min(name) == 0


# Generated at 2022-06-21 10:38:41.928256
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 1)
    timers.add("test", 1)
    timers.add("test", 1)
    assert timers.mean("test") == 1


# Generated at 2022-06-21 10:39:00.316961
# Unit test for method min of class Timers
def test_Timers_min():
    # Initialization
    timers = Timers()
    for i in range(4):
        timers.add(name=i, value=i)

    # Test
    for i in range(4):
        assert timers.min(i) == i, "Failure in Timers.min()"


# Generated at 2022-06-21 10:39:06.892842
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    test_timings = ['10', '20', '30', '40']
    test_timers = Timers()
    for timing in test_timings:
        test_timers.add('timer', float(timing))
    assert test_timers.stdev('timer') == 11.180339887498949

test_Timers_stdev()

# Generated at 2022-06-21 10:39:09.843591
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    # Arrange
    timers = Timers()
    
    # Act and assert (Exception raised)
    with raises(TypeError):
        timers['test'] = 1.0


# Generated at 2022-06-21 10:39:19.788881
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test the method clear of class Timers."""
    timers = Timers()
    timers.add(name="a", value=1.0)
    timers.add(name="b", value=2.0)
    timers.add(name="a", value=3.0)
    assert timers.count(name="a") == 2
    assert timers.count(name="b") == 1
    assert timers.total(name="a") == 4.0
    assert timers.total(name="b") == 2.0
    timers.clear()
    assert timers.count(name="a") == 0
    assert timers.count(name="b") == 0
    assert timers.total(name="a") == 0.0
    assert timers.total(name="b") == 0.0


# Generated at 2022-06-21 10:39:23.742357
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    timers: Timers = Timers()
    assert isinstance(timers, Timers)
    assert isinstance(timers._timings, collections.defaultdict)


# Generated at 2022-06-21 10:39:35.754837
# Unit test for method median of class Timers
def test_Timers_median():
    timings = Timers()
    # empty
    assert math.isnan(timings.median("does-not-exist"))
    # single
    timings["single"] = [1]
    assert timings.median("single") == 1
    assert timings.median("does-not-exist") == math.nan
    # odd
    timings["odd"] = [3, 4, 5, 1, 2, 3, 1]
    assert timings.median("odd") == 3
    # even
    timings["even"] = [6, 6, 8, 2, 4, 2, 4]
    assert timings.median("even") == 4
    # list
    timings["list"] = [6, 6, 8, 2, 4, 2, 4, 7]

# Generated at 2022-06-21 10:39:39.825464
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add("test", 1)
    t.add("test", 2)
    t.add("test", 3)
    assert t.mean("test") == 2


# Generated at 2022-06-21 10:39:51.071035
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test method __setitem__ of class Timers"""
    timer = Timers()
    duration = 42.0
    # Add a new timing
    timer.add("testing", duration)
    assert timer.data["testing"] == duration
    assert "testing" in timer
    # Re-assign an existing timing
    timer["testing"] = duration
    assert timer.data["testing"] == duration
    # Assign a new timing that already exists
    timer["testing"] = 0.0
    assert timer.data["testing"] == duration
    assert "testing" in timer
    # Assign a new timing that does not exist (raises TypeError)
    try:
        timer["another testing"] = 0.0
    except TypeError:
        pass

# Generated at 2022-06-21 10:40:01.262760
# Unit test for method median of class Timers
def test_Timers_median():
    from tests.helpers import TestCase
    from pyfakefs.fake_filesystem_unittest import TestCaseMixin

    class TestTimers(TestCase, TestCaseMixin):
        def setUp(self):
            TestCase.setUp(self)
            TestCaseMixin.setUp(self)
            self.setUpPyfakefs()

        def test_Timers_median(self):
            timers = Timers()
            timers.add('name', 1)
            timers.add('name', 2)
            timers.add('name', 3)
            self.assertEqual(timers.median('name'), 2)

            # Ensure that median() and median(name) is the same
            self.assertEqual(timers.median, timers.median('name'))

    test_timers = TestTimers

# Generated at 2022-06-21 10:40:05.211305
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers.add('a', 1)
    timers.add('a', 2)
    timers.add('b', 3)
    timers.add('b', 4)
    assert timers.apply(len, name='a') == 2
    assert timers.apply(sum, name='b') == 7

# Generated at 2022-06-21 10:40:42.880638
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    # Check for empty input
    timer = Timers()
    with pytest.raises(KeyError) as error:
        timer.max('test')
    assert error.value.args[0] == 'test'

    # Check for single value
    timer = Timers()
    timer.add('test', 1.0)
    assert timer.max('test') == 1.0

    # Check for multiple values (sorted)
    timer = Timers()
    timer.add('test', 1.0)
    timer.add('test', 3.0)
    timer.add('test', 5.0)
    assert timer.max('test') == 5.0

    # Check for multiple values (unsorted)
    timer = Timers()
    timer.add('test', 5.0)


# Generated at 2022-06-21 10:40:45.427029
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.stdev("test") == 0
    timers.add("test", 3)
    assert timers.stdev("test") == math.sqrt(2)

# Generated at 2022-06-21 10:40:48.674471
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test the method clear of class Timers"""
    ts = Timers()
    ts.add("a", 1)
    ts.add("b", 2)

    assert ts.data["a"] == 1
    assert ts.data["b"] == 2

    ts.clear()

    assert ts.data["a"] == 0
    assert ts.data["b"] == 0

# Generated at 2022-06-21 10:40:49.508709
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    print(timers.max(""))


# Generated at 2022-06-21 10:40:50.537316
# Unit test for constructor of class Timers
def test_Timers():
    """Test Timers() constructor"""
    timers = Timers()
    assert isinstance(timers, Timers)

# Generated at 2022-06-21 10:40:52.838316
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    assert timers.min("foo") == 0
    timers.add("foo", 1)
    assert timers.min("foo") == 1
    timers.add("foo", 2)
    assert timers.min("foo") == 1
    timers.add("foo", 5)
    assert timers.min("foo") == 1


# Generated at 2022-06-21 10:40:58.251805
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test for method apply of the class Timers"""

    def dummy(values):
        """Return the values"""
        return values

    # Setup the test data
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 1.2)
    timers.add('test', 3)

    # Test the method
    assert timers.apply(dummy, name="test") == [1, 1.2, 3]
    assert timers.apply(dummy, name="other") == []



# Generated at 2022-06-21 10:41:01.598728
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    import pytest
    from pytest_mock import MockerFixture

    timers = Timers()
    with pytest.raises(TypeError):
        timers["key"] = 0


# Generated at 2022-06-21 10:41:05.869077
# Unit test for method add of class Timers
def test_Timers_add():
    """Verifies that the method add of the class Timers works"""
    t = Timers()
    t.add("example", 10)
    assert t.data == {"example": 10}
    assert t._timings["example"] == [10]


# Generated at 2022-06-21 10:41:10.789996
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add("test", 1)
    assert timers.stdev("test") is math.nan
    timers.add("test", 2)
    assert timers.stdev("test") == math.sqrt(2) / 2
    assert timers.stdev("inexistent") == math.nan