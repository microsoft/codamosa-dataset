

# Generated at 2022-06-21 10:31:32.338603
# Unit test for method median of class Timers
def test_Timers_median():
    timings = Timers()
    timings._timings["key"] = [1,3,5,7,9]
    assert timings.median("key") == 5
    assert timings.median("Not a key") is None


# Generated at 2022-06-21 10:31:36.273946
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('Test1', 10)
    timers.add('Test1', 5)
    timers.add('Test1', 10)
    assert timers.count('Test1') == 3


# Generated at 2022-06-21 10:31:41.353815
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count("foo") == 0, "No timers exist"
    timers.add("foo", 10)
    assert timers.count("foo") == 1, "One valid timer has been added"
    assert timers.count("bar") == 0, "No invalid timers exist"


# Generated at 2022-06-21 10:31:47.601732
# Unit test for method count of class Timers
def test_Timers_count():
    assert Timers().count(name='nonexistent') == 0
    assert Timers(hello=5, world=10).count(name='hello') == 1
    assert Timers(hello=5, world=10).count(name='world') == 1
    # Add some timings to a timer
    timers = Timers()
    timers.add(name='t1', value=1)
    timers.add(name='t1', value=2)
    assert timers.count(name='t1') == 2
    assert timers.count(name='x') == 0

# Generated at 2022-06-21 10:31:51.639776
# Unit test for method min of class Timers
def test_Timers_min():
    width = int(len(min.__name__) / 4)
    name = width * 'name'
    timer = Timers()
    timer.add(name, 0)
    assert timer.min(name) == 0
    timer.add(name, 1)
    assert timer.min(name) == 0
    # Test with empty timer
    assert timer.min(width * 'not-existing') == 0


# Generated at 2022-06-21 10:31:58.980114
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """
    Test setting items of a Timers object.
    """
    timers = Timers()
    # Setting a new item raises a TypeError
    try:
        timers['test'] = 1
    except TypeError:
        pass
    else:
        raise TypeError("Setting new item should not be possible")
    # Setting an existing item raises a TypeError
    timers['test'] = 0
    try:
        timers['test'] = 1
    except TypeError:
        pass
    else:
        raise TypeError("Setting existing item should not be possible")
    # Check for correct value
    assert timers['test'] == 0

# Generated at 2022-06-21 10:32:02.405523
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test_code", 1.5)
    timers.add("test_code", 2.5)
    timers.add("test_code", 3.5)
    assert timers.min("test_code") == 1.5


# Generated at 2022-06-21 10:32:09.977134
# Unit test for method apply of class Timers
def test_Timers_apply():
    d = Timers()
    d._timings['a'] = [1, 2, 3]
    assert d.count('a') == 3
    assert d.total('a') == 6
    assert d.min('a') == 1
    assert d.max('a') == 3
    assert d.mean('a') == 2
    assert d.median('a') == 2
    assert d.stdev('a') == 1
    assert d.count('b') == 0
    assert d.total('b') == 0
    assert d.min('b') == 0
    assert d.max('b') == 0
    assert d.mean('b') == 0
    assert d.median('b') == 0
    assert math.isnan(d.stdev('b'))
    # assert repr(d) == ''
    # assert

# Generated at 2022-06-21 10:32:12.742587
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers.add("timer_A", 12)
    timers.add("timer_B", 10)
    timers.add("timer_B", 8)
    assert timers.apply(lambda values: max(values), name="timer_A") == 12
    assert timers.apply(lambda values: max(values), name="timer_B") == 10



# Generated at 2022-06-21 10:32:15.235256
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    assert len(timers._timings) == 0
    assert len(timers.data) == 0
    timers.add("test", 7.2)
    assert timers._timings == {
        "test": [7.2, ]
    }
    assert timers.data == {
        "test": 7.2
    }

# Generated at 2022-06-21 10:32:22.089605
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers._timings = {
        "timer1": [1, 2, 3, 4, 5],
        "timer2": [1, 2, 3, 4, 5, 6, 7],
        "timer3": [1],
        "timer4": [1, 2],
        "timer5": [],
    }
    assert timers.mean("timer1") == 3
    assert timers.mean("timer2") == 4
    assert timers.mean("timer3") == 1
    assert timers.mean("timer4") == 1.5
    assert math.isnan(timers.mean("timer5"))


# Generated at 2022-06-21 10:32:24.142198
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    # Create timer
    timer = Timers()

    # Try updating timers
    timer["myTimer"] = 1.0

# Generated at 2022-06-21 10:32:26.707195
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers._timings = {'foo': [1, 2, 3, 4]}
    result = timers.median('foo')
    assert result == 2.5
    timers._timings = {'foo': [1, 2, 3, 4, 5, 6]}
    result = timers.median('foo')
    assert result == 3.5

# Generated at 2022-06-21 10:32:34.488827
# Unit test for method clear of class Timers

# Generated at 2022-06-21 10:32:38.729345
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add("TimerOne", 100)
    timers.add("TimerOne", 200)
    stdev = timers.stdev("TimerOne")
    assert abs(stdev-100)<1e-6
    
    
"""Custom dictionary that stores information about timers"""

# Standard library imports
import collections
import math
import statistics
from typing import TYPE_CHECKING, Any, Callable, Dict, List

# Annotate generic UserDict
if TYPE_CHECKING:
    UserDict = collections.UserDict[str, float]  # pragma: no cover
else:
    UserDict = collections.UserDict



# Generated at 2022-06-21 10:32:43.369214
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    # timers["test"] = 0  # This should raise a TypeError
    try:
        timers["test"] = 0  # This should raise a TypeError
        raise AssertionError("TypeError not raised")
    except TypeError:
        pass

# Generated at 2022-06-21 10:32:53.422683
# Unit test for method clear of class Timers
def test_Timers_clear():
    # Create a Timers
    timers = Timers()

    # Add a timing value for the first timer
    timers.add('timer1', value=42.42)

    # Add a timing value for the second timer
    timers.add('timer2', value=24.24)

    # Add a timing value for the first timer
    timers.add('timer1', value=13.13)

    # Check the number of timing values for the first timer
    n_timers_1 = timers.count('timer1')

    # Check the number of timing values for the second timer
    n_timers_2 = timers.count('timer2')

    # Check the number of timer names
    n_names = len(timers)

    # Check the number of timing values

# Generated at 2022-06-21 10:32:55.199931
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}

# Generated at 2022-06-21 10:32:59.828971
# Unit test for method total of class Timers
def test_Timers_total():
    # Setup
    tmrs = Timers(dict(a=0, b=0))
    tmrs.add('a', 1)
    tmrs.add('b', 2)
    # Exercise and verify
    assert tmrs.total('a') == 1
    assert tmrs.total('b') == 2
    assert tmrs['a'] == 1
    assert tmrs['b'] == 2


# Generated at 2022-06-21 10:33:01.424382
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('foo', 1.0)
    timers.add('foo', 2.0)
    assert timers.count('foo') == 2



# Generated at 2022-06-21 10:33:15.965100
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test Timers.apply()"""
    timers = Timers()
    timers.add("test0", 1.0)

    assert timers.apply(lambda x: x, "test0") == 1.0
    assert timers.apply(len, "test0") == 1
    assert timers.apply(sum, "test0") == 1.0
    assert timers.apply(lambda x: min(x or [0]), "test0") == 1.0
    assert timers.apply(lambda x: max(x or [0]), "test0") == 1.0
    assert timers.apply(lambda x: statistics.mean(x or [0]), "test0") == 1.0
    assert timers.apply(lambda x: statistics.median(x or [0]), "test0") == 1.0

# Generated at 2022-06-21 10:33:26.780517
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    assert timers.median('test') == 0.0
    timers.add('test', 42.1)
    assert timers.median('test') == 42.1
    timers.add('test', 42.2)
    assert 41.5 < timers.median('test') < 42.5
    timers.add('test', 0.1)
    assert timers.median('test') == 42.2
    timers.add('test', 0.2)
    assert 0.2 <= timers.median('test') <= 0.3
    timers.clear()
    assert timers.median('test') == 0.0

# Generated at 2022-06-21 10:33:38.962457
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add("node_1", 0)
    timers.add("node_2", 0)
    assert timers.mean("node_1") == 0
    assert timers.mean("node_2") == 0
    timers.add("node_1", 25)
    timers.add("node_2", 25)
    assert timers.mean("node_1") == 25
    assert timers.mean("node_2") == 25
    timers.add("node_1", 25)
    timers.add("node_2", 25)
    assert timers.mean("node_1") == 25
    assert timers.mean("node_2") == 25
    timers.clear()
    timers.add("node_1", 25)
    timers.add("node_1", 25)

# Generated at 2022-06-21 10:33:42.191228
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    timers = Timers()
    assert timers._timings == {}
    assert timers == {}

# Generated at 2022-06-21 10:33:46.445934
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers([("a", 1), ("b", 2), ("c", 3)])
    assert len(timers) == 3
    assert timers["a"] == 1
    assert timers["b"] == 2
    assert timers["c"] == 3


# Generated at 2022-06-21 10:33:51.820006
# Unit test for method mean of class Timers
def test_Timers_mean():  # pragma: no cover
    """Test for method mean of class Timers"""

    timers = Timers()
    timers.add("Foo", 1.0)
    timers.add("Foo", 2.0)
    timers.add("Foo", 3.0)

    assert timers.mean("Foo") == 2.0



# Generated at 2022-06-21 10:33:59.031265
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    import unittest
    from . import Timers

    timers = Timers()
    timers._timings = collections.defaultdict(list, {'a': [1.0, 2.0, 3.0]})
    assert timers.apply(len, 'a') == 3
    assert timers.apply(sum, 'a') == 6.0



# Generated at 2022-06-21 10:34:05.998474
# Unit test for method max of class Timers
def test_Timers_max():
    """Test the max method from Timers."""

    # Test max method with empty array
    t = Timers()
    assert t.max('empty array') == 0

    # Test max method with basic array
    t.add('basic array', 1)
    t.add('basic array', 2)
    t.add('basic array', 3)
    assert t.max('basic array') == 3

# Generated at 2022-06-21 10:34:08.946783
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert isinstance(timers, UserDict)
    assert isinstance(timers._timings, collections.defaultdict)

# Generated at 2022-06-21 10:34:18.262074
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test Timers class method apply"""
    # Initialize dictionary
    timers = Timers()
    timers.add('lstm', 0.5)
    timers.add('lstm', 0.4)
    timers.add('gru', 0.2)
    timers.add('gru', 0.3)
    # Test counting
    assert timers.apply(len, 'lstm') == 2
    assert timers.apply(len, 'gru') == 2
    # Test min
    assert timers.apply(lambda values: min(values), 'lstm') == 0.4
    assert timers.apply(lambda values: min(values), 'gru') == 0.2
    # Test max
    assert timers.apply(lambda values: max(values), 'lstm') == 0.5

# Generated at 2022-06-21 10:34:28.255489
# Unit test for method apply of class Timers
def test_Timers_apply():
   """test_Timers_apply() - unit test for apply method of class Timers

   Args:
    None

   Returns:
    None
   """

   time = Timers()
   time.add("test",2)
   time.add("test",1)
   time.add("test",3)
   assert time.apply(sum,name="test")==6

# Generated at 2022-06-21 10:34:34.126140
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()

    # Count should return 0 if the timer has not been used
    assert timers.count("counter") == 0

    # Add some values to the counter
    timers.add("counter", 5)
    timers.add("counter", 10)

    # Now count should return 2
    assert timers.count("counter") == 2


# Generated at 2022-06-21 10:34:40.684143
# Unit test for method count of class Timers
def test_Timers_count():
    import numpy as np
    import pytest
    timings = Timers()
    timings.add('test', 3)
    assert timings.count('test') == 1

    timings.add('test', 4)
    assert timings.count('test') == 2

    timings.add('test2', 5)
    assert timings.count('test2') == 1

    with pytest.raises(KeyError):
        timings.count('test3')


# Generated at 2022-06-21 10:34:46.727474
# Unit test for method min of class Timers
def test_Timers_min():
    from sys import maxsize
    t = Timers()
    t.add('test', maxsize)
    t.add('test', maxsize)
    #assert t.min('test') == maxsize  # -> 9223372036854775807
    assert t.min('test') == t.max('test')  # -> True

# Generated at 2022-06-21 10:34:49.839761
# Unit test for constructor of class Timers
def test_Timers():
    # Initialization
    timers = Timers()

    # Both data and timings should be empty
    assert len(timers) == 0
    assert len(timers._timings) == 0


# Generated at 2022-06-21 10:34:57.518278
# Unit test for method max of class Timers
def test_Timers_max():
    ob1 = Timers()
    ob1.add("n1", 1)
    ob1.add("n2", 3)
    ob1.add("n3", 0)
    ob1.add("n4", -1)
    ob1.add("n5", -2)
    ob1.add("n6", -4)
    ob1.add("n7", -10)
    ob1.add("n2", 3)
    ob1.add("n3", 0)
    assert ob1.max("n2") == 3
    assert ob1.max("n6") == -4
    assert ob1.max("n7") == -10
    ob1.clear()
    assert ob1.max("n2") == 0
    assert ob1.max("n6") == 0

# Generated at 2022-06-21 10:35:02.496048
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test behavior of method '__setitem__' of class 'Timers'"""
    t = Timers()
    t.add("test", 1.234)
    with pytest.raises(TypeError):
        t["test"] = 1.0  # noqa: B010


# Generated at 2022-06-21 10:35:14.041598
# Unit test for method clear of class Timers
def test_Timers_clear():
    '''Test method clear of class Timers'''
    from ska_sdp_config import Timers

    my_timers = Timers()
    my_timers.add("timer1", 0.1)
    my_timers.add("timer2", 0.2)
    my_timers.add("timer1", 0.3)
    my_timers.add("timer2", 0.4)
    assert my_timers.total("timer1") == 0.4
    assert my_timers.total("timer2") == 0.6
    my_timers.clear()
    assert my_timers.total("timer1") == 0
    assert my_timers.total("timer2") == 0
    assert len(my_timers.data) == 0

# Generated at 2022-06-21 10:35:15.743638
# Unit test for constructor of class Timers
def test_Timers():
    d = Timers()
    assert isinstance(d._timings, dict)


# Generated at 2022-06-21 10:35:20.479831
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for method stdev of class Timers"""
    timers = Timers()
    timers["foo"] = 2
    timers._timings["foo"] = [1, 3, 4, 4]
    assert timers.stdev("foo") == pytest.approx(1.247219128924647)

# Generated at 2022-06-21 10:35:35.632675
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():  # pragma: no cover
    t = Timers()
    try:
        t["key1"] = 1
    except TypeError:
        pass
    else:
        raise AssertionError("cannot catch Timers[key] = v")
    try:
        t["key1"] = 1
    except TypeError:
        pass
    else:
        raise AssertionError("cannot catch Timers[key] += v")


# Generated at 2022-06-21 10:35:38.783212
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("min", 100)
    timers.add("min", 3000)
    assert timers.min("min") == 100
    assert timers.min("min") == 100
    assert timers.min("min") == 100
    assert timers.min("min") == 100


# Generated at 2022-06-21 10:35:43.869199
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Check that the mean value of an empty list is NaN"""
    timers = Timers()
    timers.add('test', 0)
    assert timers.mean('test') == 0
    timers.add('test', 0)
    assert timers.mean('test') == 0
    timers._timings['test'].append(3)
    assert timers.mean('test') == 1


# Generated at 2022-06-21 10:35:53.122855
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test function for stdev of class Timers"""
    # See https://github.com/numpy/numpy/blob/master/numpy/core/_methods.py#L97-L106
    # See https://github.com/python/cpython/blob/master/Lib/statistics.py
    def stdev(values):
        """Get standard deviation for timers"""
        avg = math.fsum(v for v in values) / len(values)
        return math.sqrt(
            math.fsum((val - avg) ** 2 for val in values) / (len(values) - 1)
        )

    # Create instance
    timers = Timers()
    # Add values

# Generated at 2022-06-21 10:35:58.143384
# Unit test for method count of class Timers
def test_Timers_count():
    t = Timers()
    t.add("t1", 1)
    t.add("t1", 2)
    t.add("t1", 3)

    assert t.count("t1") == 3
    assert t.count("t2") == 0


# Generated at 2022-06-21 10:36:02.501660
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    # Define empty timer
    timer = Timers()

    # Check that setting a timer value is not allowed
    try:
        timer["name"] = 1.0
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-21 10:36:06.697611
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test method clear of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    assert 'test' in timers.data
    assert 'test' in timers._timings
    assert timers.data['test'] == 1
    assert timers._timings['test'] == [1]
    timers.clear()
    assert not timers.data
    assert not timers._timings


# Generated at 2022-06-21 10:36:10.886253
# Unit test for method total of class Timers
def test_Timers_total():
    """Test the total method of Timers."""
    timers = Timers()
    timers.add("test", 1)
    assert timers.total("test") == 1
    timers.add("test", 3)
    assert timers.total("test") == 4
    timers.add("test2", 2)
    assert timers.total("test2") == 2

# Generated at 2022-06-21 10:36:18.358261
# Unit test for method apply of class Timers
def test_Timers_apply():
    """
    Test that Timers.apply can be used to apply a method to a list of values
    corresponding to a named timer.
    """
    # Prepare
    timers = Timers()
    timers.add("foo", 1)
    timers.add("foo", 2)
    timers.add("bar", 3)
    # Run
    result = timers.apply(max, name="foo")
    # Assert
    assert result == 2


# Generated at 2022-06-21 10:36:22.419380
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test Timers.__setitem__"""
    timers: Timers = Timers()
    timers.add('test', 1)
    assert timers.data['test'] == 1
    timers['test'] = 2
    assert timers.data['test'] == 1
    assert len(timers._timings['test']) == 1


# Generated at 2022-06-21 10:36:46.772443
# Unit test for method min of class Timers
def test_Timers_min():
    """Check if the min method of class Timers is working as expected"""
    data = (
        (
            [],
            0.0
        ),
        (
            [1.1, 3.2, 2.3],
            1.1
        )
    )

    for values, expected in data:
        assert Timers().apply(lambda values: min(values or [0]), "min") == expected

# Generated at 2022-06-21 10:36:50.335982
# Unit test for method min of class Timers
def test_Timers_min():
    """Test if method Timers.min returns the minimum value from the list data"""
    timers = Timers()
    timers._timings["time1"] = [1, 2, 3, 4, 5]
    assert timers.min("time1") == 1


# Generated at 2022-06-21 10:36:56.033336
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test Timers.clear"""

    from pyroSAR.flow import Timers

    timers = Timers()
    timers.add('test', 10.0)

    assert timers.count('test') == 1
    assert timers.mean('test') == 10.0

    timers.clear()

    assert timers.count('test') == 0
    assert timers.mean('test') == 0.0

# Generated at 2022-06-21 10:37:05.785238
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    assert dict(timers._timings) == {}
    assert dict(timers) == {}

    timers.add("t0", 0.1)
    assert dict(timers._timings) == {"t0": [0.1]}
    assert dict(timers) == {"t0": 0.1}

    timers.add("t0", 0.2)
    assert dict(timers._timings) == {"t0": [0.1, 0.2]}
    assert dict(timers) == {"t0": 0.3}

    timers.add("t1", 0.2)
    assert dict(timers._timings) == {"t0": [0.1, 0.2], "t1": [0.2]}

# Generated at 2022-06-21 10:37:07.398507
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timer1 = timers.min("test_timer")
    assert timer1 == 0

# Generated at 2022-06-21 10:37:11.794917
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    # This test fails on coverage run but passes on coverage report
    # The reason is that the code inside the function is reached through the branch when
    # running the unit tests, but is never reached through the coverage run
    timers = Timers()
    try:
        timers["test"] = 1
    except TypeError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-21 10:37:15.492670
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    # Create empty instance
    timers = Timers()
    # Check that instance is empty
    assert not timers
    # Add value to default timer
    timers.add("test", 1.0)
    # Check that instance is not empty
    assert timers
    # Check that value has been added
    assert timers["test"] == 1.0
    # Check that value has been added to timings
    assert timers._timings["test"] == [1.0]


# Generated at 2022-06-21 10:37:21.007995
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():                                              # noqa
    timers = Timers()
    try:
        timers["test"] = 1                                                   # noqa
        assert False, "Expected an error"
    except TypeError as exc:
        if "assignment" not in str(exc):
            raise
    timers.add("test", 1)
    _ = timers["test"]                                                       # noqa



# Generated at 2022-06-21 10:37:26.414810
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min"""
    # Create an instance of the Timers class
    timers = Timers()
    # Populate the dictionary of timers
    timers.add('timer1', 1.0)
    timers.add('timer1', 2.0)
    timers.add('timer2', 3.0)
    timers.add('timer3', 4.0)
    # Check the minimal value
    assert timers.min('timer1') == 1.0

# Generated at 2022-06-21 10:37:35.466352
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    # pylint: disable=unused-argument
    def func(values: List[float]) -> float:
        """Dummy function used to test method apply of class Timers"""
        return len(values)

    test_timers = Timers()
    assert test_timers.apply(func, name='test') == 0, \
        "test_Timers_apply: Initial call with non-existing timer returns 0"

    test_timers.add('test', 0)
    assert test_timers.apply(func, name='test') == 1, \
        "test_Timers_apply: Call with one value returns 1"

    test_timers.add('test', 0)

# Generated at 2022-06-21 10:38:19.162118
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """method stdev of class Timers"""
    timers = Timers()

    timers.add('sleep', 1)
    # Stdev for 1 value is NaN
    assert math.isnan(timers.stdev('sleep'))

    timers.add('sleep', 2)
    # Stdev for 2 values is 0
    assert timers.stdev('sleep') == 0

    timers.add('sleep', 3)
    # Stdev for 3 values is 1
    assert timers.stdev('sleep') == 1

    timers.add('range', 0)
    # Stdev for 0 values is NaN
    assert math.isnan(timers.stdev('range'))

if __name__ == '__main__':
    """Run the tests"""
    test_Timers_stdev()

# Generated at 2022-06-21 10:38:20.648178
# Unit test for constructor of class Timers
def test_Timers():
    try:
        timers = Timers()
        assert timers._timings == {}
        assert timers.data == {}
        return
    except:
        print("Timers constructor test failed")
        

# Generated at 2022-06-21 10:38:24.632660
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    timers.add('test', 4)
    assert timers.stdev('test') == 1.118033988749895


# Generated at 2022-06-21 10:38:30.718597
# Unit test for method apply of class Timers
def test_Timers_apply():
    test_timer = Timers()
    assert test_timer.apply(sum, name="timer_1") == 0.0
    assert test_timer.apply(len, name="timer_2") == 0
    with pytest.raises(KeyError):
        assert test_timer.apply(sum, name="timer_3")
    assert test_timer.apply(lambda values: statistics.mean(values or [0]),
                            name="timer_4") == 0.0


# Generated at 2022-06-21 10:38:33.510009
# Unit test for method count of class Timers
def test_Timers_count():
    name = "name"
    value = 1.0
    timing = Timers()
    timing.add(name, value)
    assert timing.count(name) == 1.0


# Generated at 2022-06-21 10:38:34.555278
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers.data == {}
    assert not timers._timings

# Generated at 2022-06-21 10:38:40.263346
# Unit test for method min of class Timers
def test_Timers_min():
    """Test the Timers class method min"""
    timer = Timers()
    timer.add('test', 1.0)
    timer.add('test', 2.0)
    timer.add('test', 3.0)
    timer.add('test', 4.0)
    assert timer.min('test') == 1.0
    assert timer.max('test') == 4.0
    assert timer.mean('test') == 2.5
    assert timer.median('test') == 2.5
    assert timer.count('test') == 4
    assert timer.stdev('test') == 1.2909944487358056
    assert timer.total('test') == 10.0


# Generated at 2022-06-21 10:38:45.270147
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()
    name1 = "a1"
    name2 = "a2"
    t.add(name1, 1)
    t.add(name2, 2)
    t.add(name1, 1)
    t.add(name2, 2)
    assert t.total(name1) == 2
    assert t.total(name2) == 4


# Generated at 2022-06-21 10:38:49.018457
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Ensure that Timers does not allow assignment"""
    timers = Timers()
    try:
        timers["foo"] = 1.0
    except TypeError as e:
        assert e.args[0].startswith("'Timers") and "item assignment" in e.args[0]
    else:
        assert False # pragma: no cover


# Generated at 2022-06-21 10:38:56.509632
# Unit test for method total of class Timers
def test_Timers_total():
    # We need to reset the timings of the timers used
    Timers().clear()
    # Create a new timer with one value added twice
    timers = Timers()
    timers.add('timer1', 2.0)
    timers.add('timer1', 2.0)
    assert timers.total('timer1') == 4.0
    # And now another one
    timers.add('timer2', 3.0)
    assert timers.total('timer2') == 3.0
    # Check that an error is raised if the timer is not found
    try:
        timers.total('timer3')
        raise AssertionError("timers.total('timer3') should fail")
    except KeyError:
        pass
    # Check that an error is raised if the timer contains more than one timing

# Generated at 2022-06-21 10:40:20.323759
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    assert len(timers._timings) == 0
    assert len(timers.data) == 0
    timers.add("timer1", 1)
    assert len(timers._timings) == 1
    assert len(timers.data) == 1
    timers.add("timer1", 1)
    timers.add("timer2", 3)
    timers.add("timer2", 2)
    assert len(timers._timings) == 2
    assert len(timers.data) == 2


# Generated at 2022-06-21 10:40:25.206670
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    assert timers['test1'] == 0.0
    assert timers.max('test1') == 0.0
    assert timers.max('test1') == 0.0
    for i in range(1000):
        timers.add('test1', i)
    assert timers.max('test1') == 999.0


# Generated at 2022-06-21 10:40:29.907827
# Unit test for method min of class Timers
def test_Timers_min():
    import pytest
    t = Timers()
    assert t.min("") == 0
    t.add("", 1)
    assert t.min("") == 1
    t.add("", 2)
    assert t.min("") == 1

    with pytest.raises(KeyError):
        assert t.min("unknown") == 0


# Generated at 2022-06-21 10:40:40.497634
# Unit test for method min of class Timers
def test_Timers_min():
    # Simple use case of the method
    timer = Timers()
    timer.add('fake_timer', 1.0)
    assert timer.min('fake_timer') == 1.0
    # Check that the method raise an error if the timer is not found
    try:
        timer.min('unexisting_timer')
    except KeyError:
        pass
    else:
        # The method should raise a KeyError if the timer is not found
        assert False
    # If a list is empty, it should return 0
    timer2 = Timers()
    timer2.add('fake_timer', 0.0)
    timer2.add('fake_timer', 0.0)
    timer2.add('fake_timer', 0.0)
    timer2.add('fake_timer', 0.0)

# Generated at 2022-06-21 10:40:42.189453
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    with pytest.raises(TypeError):
        Timers({"test": 0.5})["foo"] = 0.5


# Generated at 2022-06-21 10:40:43.326021
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}



# Generated at 2022-06-21 10:40:45.782692
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    t = Timers()
    t.data = {'test': 0.0}
    with pytest.raises(TypeError):
        t.__setitem__('Test', 1)
        assert False # Should never arrive here


# Generated at 2022-06-21 10:40:53.118438
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    # pylint: disable=missing-function-docstring
    # pylint: disable=expression-not-assigned

    # First make a Timers instance
    timers = Timers()
    timers.add("dummy", 1)
    assert timers.data == {"dummy": 1}

    # Asser that item assignment is not allowed
    try:
        timers["dummy"] = 2
    except TypeError:
        pass
    else:
        assert False
    assert timers.data == {"dummy": 1}

# Generated at 2022-06-21 10:40:55.318474
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers["foo"] = 1.0
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 10:41:00.806343
# Unit test for method median of class Timers
def test_Timers_median():
    """Verifies that the median is computed correctly"""
    timer = Timers()