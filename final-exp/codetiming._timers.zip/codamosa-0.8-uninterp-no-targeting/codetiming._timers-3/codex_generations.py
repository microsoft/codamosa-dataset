

# Generated at 2022-06-21 10:31:26.429014
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 5)
    assert timers.min('test') == 5


# Generated at 2022-06-21 10:31:29.937744
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    # Test initialization of class Timers
    timers = Timers()
    assert timers == {}
    assert isinstance(timers._timings, collections.defaultdict)
    assert timers._timings == {}


# Generated at 2022-06-21 10:31:32.268427
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("A", 3)
    timers.add("A", 2)
    assert timers.max("A") == 3
    assert timers.max("B") == 0


# Generated at 2022-06-21 10:31:38.358125
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Tests Timers.apply()"""
    def dummy(values):
        return len(values)
    timers = Timers()
    timers._timings = {
        "timerA": [1, 2, 3], 
        "timerB": [], 
    }
    assert timers.apply(dummy, "timerA") == 3
    assert timers.apply(dummy, "timerB") == 0


# Generated at 2022-06-21 10:31:41.253025
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert type(timers._timings) is dict
    assert type(timers.data) is dict



# Generated at 2022-06-21 10:31:45.921258
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add("Pipeline", value=1)
    timers.add("Pipeline", value=2)
    assert timers.stdev("Pipeline") == 0.5
    timers.clear()
    timers.add("Pipeline", value=1)
    assert math.isnan(timers.stdev("Pipeline"))


# Generated at 2022-06-21 10:31:49.363061
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    t = Timers()
    t['Time1'] = 0
    assert t.stdev('Time1') == math.nan
    t['Time1'] = 0
    assert t.stdev('Time1') != math.nan
    t['Time1'] = 1
    assert t.stdev('Time1') == math.nan

# Generated at 2022-06-21 10:31:52.173558
# Unit test for method max of class Timers
def test_Timers_max():
    """Test max method"""

    timers = Timers()
    timers.add("test", 10)
    timers.add("test", 11)
    timers.add("test", 12)
    expected_result = 12
    obtained_result = timers.max("test")
    assert obtained_result == expected_result


# Generated at 2022-06-21 10:31:55.912635
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("time", 1.0)
    timers.add("time", 3.0)
    timers.add("time", 2.0)
    result = timers.min("time")
    assert result == 1.0



# Generated at 2022-06-21 10:32:05.181220
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    dict_time = Timers()
    dict_time["A"] = 1
    dict_time["B"] = 2
    dict_time["C"] = 3
    dict_time["D"] = 4
    dict_time["E"] = 5
    dict_time["F"] = 4
    dict_time["G"] = 5
    dict_time["H"] = 4
    dict_time["I"] = 3
    dict_time["J"] = 2
    dict_time["K"] = 1
    dict_time["L"] = 2
    dict_time["M"] = 3
    dict_time["N"] = 4
    dict_time["O"] = 5
    dict_time["P"] = 4
    dict_time["Q"] = 3
    dict_time["R"] = 2

# Generated at 2022-06-21 10:32:09.768526
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    timers = Timers()
    assert len(timers) == 0
    assert len(timers._timings) == 0


# Generated at 2022-06-21 10:32:11.073620
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('abc', 1)
    timers.add('abc', 2)
    timers.add('abc', 3)

    result = timers.mean('abc')
    assert result == 2, "The mean result is incorrect"


# Generated at 2022-06-21 10:32:16.550224
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    stats = Timers()
    stats.add('test', 0)
    assert math.isnan(stats.stdev('test'))
    stats.add('test', 1)
    assert stats.stdev('test') == 0
    stats.add('test', 2)
    assert stats.stdev('test') == 0.81649658093


# Generated at 2022-06-21 10:32:18.279223
# Unit test for method count of class Timers
def test_Timers_count():
    """[summary]
    
    Returns:
        [type]: [description]
    """

    t: Timers = Timers()
    t.add('a', 1)
    # count
    assert t.count('a') == 1


# Generated at 2022-06-21 10:32:24.100949
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    try:
        import numpy as np
    except ImportError:
        np = None

    if np is not None:
        timers = Timers()
        for name in "foo", "bar", "baz":
            for value in 0.5, 1.5:
                timers.add(name, value)

        for name in "foo", "bar", "baz":
            np.testing.assert_almost_equal(timers.stdev(name), 0.5)

# Generated at 2022-06-21 10:32:27.206749
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert 'a' not in timers
    assert timers == {}
    timers['a'] += 1.0
    assert timers == {'a': 1.0}
    timers.clear()
    assert timers == {}

# Generated at 2022-06-21 10:32:30.456621
# Unit test for method add of class Timers
def test_Timers_add():
    name = "TEST"
    timer = Timers([(name, 0)])
    timer.add(name, 1.0)
    assert timer[name] == 1.0
    assert timer._timings[name] == [1.0]


# Generated at 2022-06-21 10:32:32.744812
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timings = Timers()
    timings.add('test', 1)
    timings.add('test', 2)
    timings.add('test', 3)
    timings.add('test', 4)
    expected_stdev = 1.2912878474779199
    assert timings.stdev('test') == expected_stdev

# Generated at 2022-06-21 10:32:39.602241
# Unit test for method add of class Timers
def test_Timers_add():
    t = Timers()
    t.add("test_1", 1.0)
    assert t["test_1"] == 1.0
    t.add("test_1", 2.0)
    assert t["test_1"] == 3.0
    t.add("test_2", 5.0)
    assert t["test_2"] == 5.0
    t.add("test_2", -3.0)
    assert t["test_2"] == 2.0
    

# Generated at 2022-06-21 10:32:49.030385
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add('f', 0.1)
    t.add('f', 0.2)
    t.add('f', 0.2)
    t.add('g', 0.9)
    t.add('g', 1.2)
    t.add('g', 1.3)
    assert t.mean('f') == 0.16666666666666666
    assert t.mean('g') == 1.1
    try:
        t.mean('h')
    except KeyError:
        pass
    else:
        assert False, 'Should have raised KeyError'


# Generated at 2022-06-21 10:32:54.030516
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    # Minimum of two values are needed
    try:
        timers.stdev("foo")
    except KeyError:
        return

    assert False


# Generated at 2022-06-21 10:32:57.548140
# Unit test for method add of class Timers
def test_Timers_add():
    """Add the value 1 to the timer 'test'"""
    T = Timers()
    T.add('test', 1)
    assert T['test'] == 1

    # Run twice to chcek for clearing
    T.add('test', 1)
    assert T['test'] == 2


# Generated at 2022-06-21 10:33:07.554888
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Tests for method apply of class Timers"""
    import pytest
    timers = Timers()
    with pytest.raises(KeyError):
        timers.apply(list, name="test")
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.apply(sum, name="test") == 3
    assert timers.apply(len, name="test") == 2
    assert timers.apply(lambda values: min(values), name="test") == 1
    assert timers.apply(lambda values: max(values), name="test") == 2
    assert timers.apply(lambda values: sum(values), name="test") == 3
    assert timers.apply(lambda values: len(values), name="test") == 2


# Generated at 2022-06-21 10:33:13.666584
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit tests for the apply method of class Timers"""
    func = lambda values: sum(values)
    t1 = Timers()
    t1.add('a', 1)
    t1.add('a', 2)
    t1.add('a', 3)
    assert t1.apply(func, 'a') == 6
    t2 = Timers()
    assert t2.apply(func, 'x') == 0

# Generated at 2022-06-21 10:33:17.053846
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("timer1", 5)
    t.add("timer1", 6)
    t.add("timer2", 3)
    t.add("timer2", 4)
    assert t.min("timer1") == 5
    assert t.min("timer2") == 3


# Generated at 2022-06-21 10:33:28.543940
# Unit test for method mean of class Timers
def test_Timers_mean():
    from hypothesis import given
    from hypothesis.strategies import floats
    from .hypothesis_strategies import lists_of_floats

    # Constructor
    timers = Timers()

    # Mean value
    @given(lists_of_floats)
    def test(values: List[float]) -> None:
        """Check that mean equals the expected value"""

        # Empty list
        if not values:
            assert timers.mean("test") == 0

        # Non-empty list
        else:

            # Add values
            timers.clear()
            for value in values:
                timers.add("test", value)

            # Check mean
            assert timers.mean("test") == sum(values) / len(values)

    # Perform test
    test()

# Generated at 2022-06-21 10:33:32.852914
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('timer 1', 2)
    timers.add('timer 1', 3)
    timers.add('timer 2', 4)
    assert timers.median('timer 1') == 2.5
    assert timers.median('timer 2') == 4

# Generated at 2022-06-21 10:33:37.860702
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add('a', 1.0)
    timers.add('a', 2.0)
    timers.add('b', 2.0)

    assert timers.total('a') == 3.0
    assert timers.total('b') == 2.0

# Generated at 2022-06-21 10:33:41.928540
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method add of class Timers"""
    timers = Timers()
    timers.add("wall", 1)
    assert timers['wall'] == 1
    timers.add("wall", 2)
    assert timers['wall'] == 3

# Generated at 2022-06-21 10:33:49.150026
# Unit test for method max of class Timers
def test_Timers_max():
    from unittest import TestCase
    from unittest.mock import Mock
    from nwpc_hpc_model.workload.timers import Timers

    mock_timers = Mock(spec=Timers)
    mock_timers.max.side_effect = Timers.max

    mock_timers._timings = collections.defaultdict(list, {
        'timer_1': [ ]
    })

    test_case = TestCase()
    test_case.assertIsInstance(mock_timers.max('timer_1'), float)

# Generated at 2022-06-21 10:33:56.685385
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add("Test", 3.0)
    assert timers.data["Test"] == 3.0
    assert timers._timings["Test"] == [3.0]


# Generated at 2022-06-21 10:34:04.215859
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""

    # Init variable
    timers = Timers()

    # Test 0 value
    timers.add('a', 0)
    timers.add('a', 0)

    # Test 1 value
    timers.add('b', 1)
    timers.add('b', 1)

    # Test 2 values
    timers.add('c', 2)
    timers.add('c', 2)

    # Test 3 value
    timers.add('d', 3)
    timers.add('d', 3)

    # Test 4 value
    timers.add('e', 4)
    timers.add('e', 4)

    # Test 5 value
    timers.add('f', 5)
    timers.add('f', 5)

    # Test 9 value
    timers.add('g', 9)
    timers

# Generated at 2022-06-21 10:34:15.908578
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    timers = Timers()
    timers.add('A', 1.1)
    timers.add('A', 2.2)
    timers.add('B', 3.3)
    timers.add('B', 4.4)
    assert timers.apply(len, name='A') == 2
    assert timers.apply(sum, name='A') == 3.3
    assert timers.apply(lambda values: min(values or [0]), name='A') == 1.1
    assert timers.apply(lambda values: max(values or [0]), name='A') == 2.2
    assert timers.apply(lambda values: statistics.mean(values or [0]), name='A') == 1.65

# Generated at 2022-06-21 10:34:23.365048
# Unit test for method add of class Timers
def test_Timers_add():
    """Test the add method of the Timers class"""

    test_timers = Timers()
    test_timers.add('foo', 1.1)
    assert test_timers['foo'] == 1.1
    test_timers.add('foo', 2.2)
    assert test_timers['foo'] == 3.3
    test_timers.add('bar', 1.1)
    assert test_timers['bar'] == 1.1



# Generated at 2022-06-21 10:34:29.788284
# Unit test for method max of class Timers
def test_Timers_max():
    """Method max of class Timers"""
    d = Timers()
    d.add("a", 10)
    d.add("b", 40)
    d.add("b", 30)
    d.add("c", 20)

    assert d.data == {"a": 10, "b": 70, "c": 20}
    assert d.max("a") == 10
    assert d.max("b") == 40
    assert d.max("c") == 20
    assert d.max("d") == 0


# Generated at 2022-06-21 10:34:35.999909
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit tests of method add"""
    timers = Timers()
    timers.add('A', 1)
    assert timers.data['A'] == 1
    assert timers._timings['A'] == [1]
    timers.add('A', 2)
    assert timers.data['A'] == 3
    assert timers._timings['A'] == [1, 2]


# Generated at 2022-06-21 10:34:39.315328
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    import pytest
    with pytest.raises(TypeError):
        timers = Timers()
        timers["test"] = 1.0
        

# Generated at 2022-06-21 10:34:40.724717
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert len(timers) == 0
    assert len(timers._timings) == 0

# Generated at 2022-06-21 10:34:46.424745
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__(): # pragma: no cover
    try:
        timers = Timers()
        timers["foo"] = 0.1
    except TypeError as e:
        assert "does not support item assignment" in str(e)
    else:
        raise TypeError("No exception raised by Timers class")


# Generated at 2022-06-21 10:34:48.865895
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers["test"] = 1
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-21 10:34:56.547423
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('test', [1, 2, 3])
    assert timers.mean('test') == 2
    assert timers.mean('test2') == 0


# Generated at 2022-06-21 10:35:02.474053
# Unit test for method mean of class Timers
def test_Timers_mean():
    a=Timer()
    a.start()
    b=Timer()
    b.start()
    c=Timer()
    c.start()
    a.stop()
    b.stop()
    c.stop()
    d=Timers()
    d.add("a",a.elapsed)
    d.add("b",b.elapsed)
    d.add("c",c.elapsed)
    assert(d.mean("a")==d["a"])
    assert(d.mean("b")==d["b"])
    assert(d.mean("c")==d["c"])


# Generated at 2022-06-21 10:35:06.425856
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('a', 10)
    timers.add('a', 20)
    timers.add('a', 30)
    assert timers.mean('a') == 20


# Generated at 2022-06-21 10:35:14.983635
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for method stdev of class Timers"""
    INPUT_DATA: Dict[str, List[float]] = {
        "name1": [1, 1, 1, 1],
        "name2": [2, 3],
        "name3": [],
    }
    tmr = Timers()
    for name in INPUT_DATA:
        for value in INPUT_DATA[name]:
            tmr.add(name, value)

    assert tmr.stdev("name1") == 0
    assert not math.isnan(tmr.stdev("name2"))
    assert math.isnan(tmr.stdev("name3"))

# Generated at 2022-06-21 10:35:20.431062
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers(dict())
    timers.add("read", 60)
    timers.add("read", 45)
    timers.add("write", 30)
    timers.add("write", 5)
    mean_read = timers.mean("read")
    mean_write = timers.mean("write")
    assert mean_read == 52.5
    assert mean_write == 17.5

# Generated at 2022-06-21 10:35:26.189324
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add('foo', 1)
    t.add('foo', 2)
    t.add('bar', 4)
    assert t.mean('foo') == 1.5
    assert t.mean('bar') == 4
    assert t.mean('baz') == 0


# Generated at 2022-06-21 10:35:27.942301
# Unit test for method median of class Timers
def test_Timers_median():
    assert Timers.median("mock_name") == math.nan

# Generated at 2022-06-21 10:35:30.789271
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("Foo", 4)
    assert timers.min("Foo") == 4
    assert timers.min("Bar") == 0


# Generated at 2022-06-21 10:35:34.348498
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add('a', 1)
    assert timers.stdev('a') == 0
    timers.add('a', 2)
    assert timers.stdev('a') == statistics.stdev((1,2))

# Generated at 2022-06-21 10:35:36.845071
# Unit test for method count of class Timers
def test_Timers_count():
    """Test for method count of class Timers"""

    item = Timers()
    item.add('timer', 2)
    assert item.count('timer') == 1



# Generated at 2022-06-21 10:35:52.512694
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test the apply() method of the Timers class"""
    timers = Timers()
    timers.add("test timer", 1)
    timers.add("test timer", 2)
    timers.add("test timer", 3)
    assert timers.apply(sum, "test timer") == 6
    assert timers.apply(len, "test timer") == 3
    assert timers.apply(min, "test timer") == 1


# Generated at 2022-06-21 10:35:58.023434
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Instantiate a Timers object
    timers = Timers()

    # Add a name with a timing value of 3 seconds
    timers.add("test", 3)

    # Check, if mean is correctly returned
    result = timers.mean("test")

    # Assert that result equals the expected mean of 3 seconds
    assert result == 3

# Generated at 2022-06-21 10:36:02.574793
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Check that applying the `mean` method on Timers works as expected"""
    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 2)
    timers.add("b", 2)
    timers.add("b", 5)

    # Check expected results
    assert timers.mean("a") == 1.5
    assert timers.mean("b") == 3.5
    assert timers.apply(statistics.mean, "a") == 1.5
    assert timers.apply(statistics.mean, "b") == 3.5


# Generated at 2022-06-21 10:36:08.844339
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""

    # No argument constructor
    timers = Timers()
    assert isinstance(timers, Timers)
    assert isinstance(timers.data, dict)

    # Constructor with given dictionary
    timers = Timers({'key': 'value'})
    assert isinstance(timers, Timers)
    assert isinstance(timers.data, dict)
    assert timers.data['key'] == 'value'


# Generated at 2022-06-21 10:36:15.827815
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    assert timers.mean("test") == 0
    timers.add("test", 1)
    assert timers.mean("test") == 1
    timers.add("test", 2)
    assert timers.mean("test") == 1.5
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-21 10:36:18.979028
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers._timings = {1: [1, 2], 2: [2, 3, 4]}
    assert timers.mean(1) == 1.5
    assert timers.mean(2) == 3.0

# Generated at 2022-06-21 10:36:20.119976
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test', 5)
    return timers.max('test') == 5



# Generated at 2022-06-21 10:36:23.651490
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    timers = Timers()
    timers.add('test_timer', 1)
    timers.add('test_timer', 2)
    timers.add('test_timer', 3)
    assert timers.total('test_timer') == 6


# Generated at 2022-06-21 10:36:29.300747
# Unit test for method min of class Timers
def test_Timers_min():
    # Setup
    expected_result = -1

    # Test case
    timers = Timers()
    timers.add("Test", -1)
    timers.add("Test", -2)
    timers.add("Test", -3)
    actual_result = timers.min("Test")

    # Assert
    assert actual_result == expected_result, "The minimum value was not calculated correctly"



# Generated at 2022-06-21 10:36:35.330374
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test method clear of class Timers"""
    timers = Timers()
    timers.add("timer0", 1.0)
    assert "timer0" in timers
    assert len(timers) == 1
    timers.clear()
    assert len(timers) == 0
    assert "timer0" not in timers


# Generated at 2022-06-21 10:36:51.721727
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test method clear of class Timers"""
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == collections.defaultdict(list, {})
    timers['name'] = 1
    timers.add('name', 1)
    assert timers.data == {'name': 2}
    assert timers._timings == collections.defaultdict(list, {'name': [1.]})
    timers.clear()
    assert timers.data == {}
    assert timers._timings == collections.defaultdict(list, {})


# Generated at 2022-06-21 10:37:02.019416
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for Timers.stdev()"""
    timers = Timers()
    timers.add('foo', 1.0)
    timers.add('foo', 2.0)
    timers.add('bar', 2.0)
    timers.add('bar', 2.0)
    timers.add('baz', 1.0)
    timers.add('baz', 3.0)
    # Timer 'foo' should have a standard deviation of 0.5
    assert timers.stdev('foo') == 0.5
    # Timer 'bar' should have a standard deviation of 0.0
    assert timers.stdev('bar') == 0.0
    # Timer 'baz' should have a standard deviation of 1.0
    assert timers.stdev('baz') == 1.0
    # Timer 'baz' should have

# Generated at 2022-06-21 10:37:04.539115
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""

    assert isinstance(Timers().mean('foo'), float)


# Generated at 2022-06-21 10:37:12.451729
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    print(timers._timings)
    timers['data'] = {}
    print(timers._timings)
    timers.add('foo', 0.5)
    print(timers._timings)
    timers.apply(sum, 'foo')
    timers.apply(len, 'foo')
    timers.apply(min, 'foo')
    timers.apply(max, 'foo')
    timers.apply(statistics.mean, 'foo')
    timers.apply(statistics.median, 'foo')
    timers.apply(statistics.stdev, 'foo')
    timers.clear()
    print(timers._timings)
    return

if __name__ == '__main__':
    test_Timers()

# Generated at 2022-06-21 10:37:22.625569
# Unit test for method apply of class Timers
def test_Timers_apply():
    """
    Test method Timers.apply()
    """
    from typing import List
    timers = Timers()
    timers.add('block_solve', 1)
    timers.add('block_solve', 2)
    timers.add('block_solve', 3)
    timers.add('block_solve', 4)
    timers.add('block_solve', 5)
    assert timers.apply(sum, name='block_solve') == 15
    assert timers.apply(min, name='block_solve') == 1
    assert timers.apply(max, name='block_solve') == 5
    assert timers.apply(lambda values: statistics.mean(values), name='block_solve') == 3
    assert timers.apply(lambda values: statistics.median(values), name='block_solve') == 3
   

# Generated at 2022-06-21 10:37:31.197697
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    timers = Timers()
    timers.add('foo', 1.0)
    timers.add('foo', 2.0)
    timers.add('bar', 2.0)
    assert len(timers._timings) == 2
    assert timers._timings['foo'] == [1.0, 2.0]
    assert timers._timings['bar'] == [2.0]
    assert timers.apply(sum, name='baz') == 0
    assert timers.apply(len, name='foo') == 2
    assert timers.apply(len, name='bar') == 1
    assert timers.apply(min, name='bar') == 2.0
    assert timers.apply(min, name='baz') == 0
    assert timers.max('foo') == 2.0

# Generated at 2022-06-21 10:37:40.838852
# Unit test for method count of class Timers
def test_Timers_count():
    """Test method count of class Timers"""
    timers = Timers()
    assert timers.count("blah") == 0
    assert len(timers._timings) == 0

    timers.add("blah", 0.5)
    assert timers.count("blah") == 1
    assert len(timers._timings) == 1
    assert timers.count("bla") == 0
    assert len(timers._timings) == 1

    timers.add("bla", 0.5)
    assert timers.count("blah") == 1
    assert len(timers._timings) == 2
    assert timers.count("bla") == 1
    assert len(timers._timings) == 2


# Generated at 2022-06-21 10:37:42.478164
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    Timers()

# Generated at 2022-06-21 10:37:45.283570
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.min("test") == 1


# Generated at 2022-06-21 10:37:48.364229
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("timer1", 0.1)
    assert timers.min("timer1") == 0.1


# Generated at 2022-06-21 10:38:01.652016
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    try:
        timers = Timers()
        timers["foo"] = 0.1  # type: ignore
    except TypeError as e:
        assert "does not support item assignment" in str(e)


# Generated at 2022-06-21 10:38:05.977354
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    assert t.min('test') == 0
    t.add('test', 15)
    t.add('test', 1)
    assert t.min('test') == 1


# Generated at 2022-06-21 10:38:16.430118
# Unit test for method median of class Timers
def test_Timers_median():
    """Simply test all methods of class Timers"""
    # Run unit test if called as main
    if __name__ == "__main__":
        timers = Timers()
        timers.add("first", 1)
        timers.add("first", 2)
        timers.add("first", 3)
        timers.add("second", 4)
        timers.add("second", 9)
        timers.add("second", 16)
        assert timers.count("first") == 3
        assert timers.count("second") == 3
        assert timers.total("first") == 6
        assert timers.total("second") == 29
        assert timers.min("first") == 1
        assert timers.min("second") == 4
        assert timers.max("first") == 3
        assert timers.max("second") == 16
        assert timers.mean("first") == 2

# Generated at 2022-06-21 10:38:22.935858
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Unit test for method clear of class Timers"""

    timers = Timers()

    timers.add('key1', 4)
    timers.add('key1', 2)
    timers.add('key2', 1)
    timers.add('key2', 3)

    timers.clear()

    assert timers['key1'] == 0


# Generated at 2022-06-21 10:38:25.875246
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("timer", 1)
    timers.add("timer", 2)
    assert timers.max("timer") == 2


# Generated at 2022-06-21 10:38:33.613179
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    assert timers.mean("test") == 0
    timers.add("test", 1)
    assert timers.mean("test") == 1
    timers.add("test", 2)
    assert timers.mean("test") == 1.5
    timers.add("test", -3)
    assert timers.mean("test") == 0
    timers.add("test", -3)
    assert timers.mean("test") == -1.5
    timers.add("test", 2)
    assert timers.mean("test") == -0.4



# Generated at 2022-06-21 10:38:36.782048
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers['xyz_test'] = 123
    except TypeError as e:
        assert str(e) == "Timers does not support item assignment. Use '.add()' to update values."
    else:
        raise RuntimeError('No exception raised in test')



# Generated at 2022-06-21 10:38:39.673355
# Unit test for method min of class Timers
def test_Timers_min():
    T = Timers()
    T._timings["test"] = [4, 3, 5]  # pylint: disable=protected-access
    assert T.min("test") == 3
    T._timings["test"] = []  # pylint: disable=protected-access
    assert T.min("test") == 0


# Generated at 2022-06-21 10:38:43.753231
# Unit test for method clear of class Timers
def test_Timers_clear():

    # Create object
    timers = Timers()

    # Add some timings
    timers.add('loading data', 0.5)
    timers.add('computing', 2.4)

    # Clear timers
    timers.clear()

    assert timers._timings == {}
    assert timers.data == {}

# Generated at 2022-06-21 10:38:45.269943
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    timers = Timers()
    assert timers == {}



# Generated at 2022-06-21 10:39:09.889108
# Unit test for method median of class Timers
def test_Timers_median():
    timer = Timers()
    timer._timings['test'] = [2, 3, 4]
    assert timer.median('test') == 3

# Generated at 2022-06-21 10:39:13.507916
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("test", 2.5)
    timers.add("test", 3.5)
    assert timers.count("test") == 2
    assert timers.count("test1") == 0


# Generated at 2022-06-21 10:39:14.817772
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    timers = Timers()
    for index in range(100):
        timers.add("test", index)
    assert timers.apply(len, "test") == 100


# Generated at 2022-06-21 10:39:20.694223
# Unit test for constructor of class Timers
def test_Timers():  # noqa
    """Unit test for constructor of class Timers"""
    timers1 = Timers()
    assert timers1.data == {}
    assert timers1._timings == {}
    timers2 = Timers([('a', 1), ('b', 2)])
    assert timers2.data == {'a': 1, 'b': 2}
    assert timers2._timings == {}


# Expose only specific public items
__all__ = ["Timers"]

# Generated at 2022-06-21 10:39:33.207313
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """
    Unit test for method stdev of class Timers
    """
    # Arrange
    # The Timers object to test
    timers = Timers()

    # Act
    # Assert that an exception is raised upon invocation of method stdev
    # of class Timers with an unknown name
    # as no entry in dictionary _timings of timers exists now
    try:
        timers.stdev('unknown_name')
        assert False # pragma: no cover
    except KeyError:
        pass

    # Assert that an exception is not raised upon invocation of method stdev
    # of class Timers with a known name
    # as an entry for name 'known_name' exists in dictionary _timings of timers

# Generated at 2022-06-21 10:39:39.211312
# Unit test for constructor of class Timers
def test_Timers():
    """Test constructor of class Timers"""
    # Test empty constructor
    timers = Timers()
    assert not timers
    # Test constructor with a single timing
    timers = Timers({"a": 1.5})
    assert timers.data == {"a": 1.5}
    assert timers.total("a") == 1.5
    assert timers.count("a") == 1


# Generated at 2022-06-21 10:39:44.575233
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    assert 0 == timers.min('min1')
    timers.add('min2', 3)
    assert 3 == timers.min('min2')
    timers.add('min3', 2)
    timers.add('min3', 5)
    assert 2 == timers.min('min3')


# Generated at 2022-06-21 10:39:51.727266
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""

    # Create a new Timers instance
    timers = Timers()

    # Check error handling
    try:
        timers.mean("")
        assert False
    except KeyError:
        assert True

    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    timers.add("test", 4)
    timers.add("test", 5)

    # Check method mean
    assert (timers.mean("test") == 3)

# Generated at 2022-06-21 10:39:55.728060
# Unit test for method min of class Timers
def test_Timers_min():
    """Check min function of class Timers"""
    timers = Timers()
    timers.add('a', 1)
    timers.add('a', 0)
    timers.add('a', 2)
    assert timers.min('a') == 0
    return

# Generated at 2022-06-21 10:40:04.173946
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method add of class Timers

    Args:
        None

    Returns:
        None

    """
    # Setup a Timer instance
    timers = Timers()

    # Add a timer
    timer = 'a'
    value = 3
    timers.add(timer, value)
    assert timers.count(timer) == 1
    assert timers.total(timer) == value
    assert timers.min(timer) == value
    assert timers.max(timer) == value
    assert timers.mean(timer) == value
    assert timers.median(timer) == value

    # Add the same timer
    value = 5
    timers.add(timer, value)
    assert timers.count(timer) == 2
    assert timers.total(timer) == value + 3
    assert timers.min(timer) == 3

# Generated at 2022-06-21 10:40:54.856716
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test', 3.2)
    timers.add('test', 4.2)
    timers.add('test', 100)
    timers.add('test', 1.1)
    assert timers.max('test') == 100

# Generated at 2022-06-21 10:40:59.014122
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    # pylint: disable=protected-access
    # Initialize timers
    timers = Timers()
    timers._timings = {'hello': [1.0, 2.0, 3.0]}
    # Update a timer
    assert timers.mean('hello') == 2.0
    assert timers['hello'] == 6.0
    # Test incorrect call
    try:
        timers.mean('world')
        assert False
    except KeyError:
        assert True
    # pylint: enable=protected-access


# Generated at 2022-06-21 10:41:10.346371
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    t.add("test", 0)
    assert t.median("test") == 0
    t.add("test", 1)
    assert t.median("test") == 0.5
    t.add("test", 2)
    assert t.median("test") == 1
    t.add("test", 3)
    assert t.median("test") == 1.5
    t.add("test", 4)
    assert t.median("test") == 2
    t.add("test", 5)
    assert t.median("test") == 2.5
    t.add("test", 6)
    assert t.median("test") == 3
    t.add("test", 7)
    assert t.median("test") == 3.5

# Generated at 2022-06-21 10:41:14.530909
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for method stdev of class Timers"""
    timers = Timers()
    timers.add("unit_test", 1.0)
    timers.add("unit_test", 1.0)
    assert timers.stdev("unit_test") == 0.0


# Generated at 2022-06-21 10:41:15.123239
# Unit test for method max of class Timers
def test_Timers_max():
    pass

# Generated at 2022-06-21 10:41:19.584784
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for method stdev of class Timers"""
    t = Timers()
    t.add("a", 1)
    t.add("a", 2)
    t.add("a", 3)
    t.add("b", 1)
    t.add("b", 2)
    assert t.stdev("a") == 1
    assert t.stdev("b") == 0.5
    assert t.stdev("c") == math.nan