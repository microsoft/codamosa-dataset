

# Generated at 2022-06-21 10:31:30.873978
# Unit test for method total of class Timers
def test_Timers_total():
    """Test method total of class Timers"""
    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 3.2)
    assert timers.total("a") == 4.2
    timers.add("b", 2)
    assert timers.total("b") == 2
    assert timers.total("c") == 0


# Generated at 2022-06-21 10:31:35.673680
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('min', float('+inf'))
    timers.add('min', float('-inf'))
    assert not math.isfinite(timers.data['min'])
    assert math.isfinite(timers.min('min'))
    return None

# Generated at 2022-06-21 10:31:42.674690
# Unit test for method add of class Timers
def test_Timers_add():
    """Test Timers.add()"""
    timers = Timers()
    assert not timers.data
    assert not timers._timings
    timers.add('one', 1)
    timers.add('one', 2)
    timers.add('two', 3)
    timers.add('two', 4)
    assert timers.data == {'one': 3, 'two': 7}
    assert timers._timings == {'one': [1, 2], 'two': [3, 4]}

# Generated at 2022-06-21 10:31:50.165268
# Unit test for constructor of class Timers
def test_Timers():
    """Test constructor of class Timers"""
    timers = Timers({"foo": 0.05})
    assert timers.total("foo") == 0.05
    assert timers.median("foo") == 0.05
    assert timers.min("foo") == 0.05
    assert timers.max("foo") == 0.05
    assert timers.count("foo") == 1
    assert timers.mean("foo") == 0.05
    assert timers.total("bar") == 0
    assert timers.median("bar") == 0
    assert timers.min("bar") == 0
    assert timers.max("bar") == 0
    assert timers.count("bar") == 0
    assert timers.mean("bar") == 0



# Generated at 2022-06-21 10:31:55.121457
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    timers = Timers()
    assert timers.min('non_existent_key') == 0
    timers.add('key', 1)
    assert timers.min('key') == 1
    timers.add('key', 2)
    assert timers.min('key') == 1
    timers.add('key', 10)
    assert timers.min('key') == 1


# Generated at 2022-06-21 10:31:57.386590
# Unit test for constructor of class Timers
def test_Timers():  # pragma: no cover
    t = Timers()
    assert t._timings == {}
    assert t.data == {}



# Generated at 2022-06-21 10:32:01.904120
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test method apply of class Timers"""
    import pytest
    with pytest.raises(KeyError):
        Timers().apply(sum, name='test')

    timers = Timers({'test': 0})
    timers._timings['test'].extend([1, 2, 3, 4])
    assert timers.apply(sum, 'test') == 10


# Generated at 2022-06-21 10:32:06.979709
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    import pytest
    t = Timers()
    t[0] = 1.0
    t[1] = 2.0
    t[2] = 1.0
    assert t.stdev(1) == pytest.approx(0.816496580927726)
    assert t.stdev(2) == pytest.approx(0.816496580927726)
    with pytest.raises(KeyError):
        t.stdev(3)

# Generated at 2022-06-21 10:32:13.977711
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    timers = Timers()
    timers.data["timer1"] = float("nan")
    assert math.isnan(timers.apply(sum, name="timer1"))
    assert math.isnan(timers.apply(len, name="timer1"))
    assert math.isnan(timers.apply(lambda values: min(values or [0]), name="timer1"))
    assert math.isnan(timers.apply(lambda values: max(values or [0]), name="timer1"))
    assert math.isnan(timers.apply(lambda values: statistics.mean(values or [0]), name="timer1"))
    assert math.isnan(timers.apply(lambda values: statistics.median(values or [0]), name="timer1"))

# Generated at 2022-06-21 10:32:15.925882
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    timers['a'] = 1
    assert timers.data['a'] == 1
    
    with pytest.raises(TypeError):
        timers.data['a'] = -1


# Generated at 2022-06-21 10:32:30.137878
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    timer_store = Timers()
    timer_store.add("timer_1", 1)
    timer_store.add("timer_1", 2)
    timer_store.add("timer_1", 3)
    timer_store.add("timer_2", 1)
    timer_store.add("timer_2", 2)

    # Sum of values
    assert timer_store.apply(sum, "timer_1") == 6
    assert timer_store.apply(sum, "timer_2") == 3

    # Count of values
    assert timer_store.apply(len, "timer_1") == 3
    assert timer_store.apply(len, "timer_2") == 2

    # Minimum of values
    assert timer_store.apply(min, "timer_1") == 1

# Generated at 2022-06-21 10:32:33.020369
# Unit test for method min of class Timers
def test_Timers_min():
    """Check what happens with empty and single-element lists"""
    timers = Timers()
    timers.add('test', 10)
    assert timers.min('test') == 10
    timers.add('test', 20)
    assert timers.min('test') == 10



# Generated at 2022-06-21 10:32:39.243457
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    # Empty timers
    assert timers.mean("test") == 0
    # One timing
    timers.add("test", 1.0)
    assert timers.mean("test") == 1.0
    # More timings
    timers.add("test", 1.0)
    timers.add("test", 1.0)
    timers.add("test", 1.0)
    assert timers.mean("test") == 1.0

# Generated at 2022-06-21 10:32:50.800582
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    # pylint: disable-msg=protected-access
    timers = Timers({'a': 1.0})
    assert timers.data['a'] == 1.0
    try:
        timers['a'] = 2.0
    except TypeError:
        pass
    except Exception:  # pragma: no cover
        raise
    else:  # pragma: no cover
        raise AssertionError(
            "__setitem__ does not raise TypeError when it should"
        )  # pragma: no cover
    timer = Timers()
    try:
        timer['a'] = 2.0
    except TypeError:
        pass
    except Exception:  # pragma: no cover
        raise
    else:  # pragma: no cover
        raise Ass

# Generated at 2022-06-21 10:32:59.325841
# Unit test for method add of class Timers
def test_Timers_add():
    my_timers = Timers()
    assert len(my_timers._timings) == 0
    assert my_timers.data == {}
    my_timers.add(name='a', value=1)
    assert len(my_timers._timings) == 1
    assert my_timers.data == {'a': 1}
    my_timers.add(name='a', value=2.5)
    assert len(my_timers._timings) == 1
    assert my_timers.data == {'a': 3.5}
    my_timers.add(name='b', value=4.5)
    assert len(my_timers._timings) == 2
    assert my_timers.data == {'a': 3.5, 'b': 4.5}
    my_tim

# Generated at 2022-06-21 10:33:04.482873
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Testing method Timers.stdev"""
    timers = Timers()
    timers.add("test1", 1)
    timers.add("test1", 2)
    timers.add("test2", 3)
    timers.add("test2", 4)
    timers.add("test2", 5)
    timers.add("test2", 6)
    assert timers.stdev("test1") == 0.7071067811865476
    assert timers.stdev("test2") == 1.707825127659933
    assert timers.stdev("test3") == float('nan')



# Generated at 2022-06-21 10:33:13.041669
# Unit test for method count of class Timers
def test_Timers_count():
    """Unit test for method 'dev.Timers.count'"""
    timers = Timers()
    assert timers.count("name") == 0

    timers.data["name"] = 0
    assert timers.count("name") == 0

    timers.data["name"] = 1
    assert timers.count("name") == 1

    timers.apply(lambda _: 1, name="name")
    assert timers.count("name") == 1

    timers.apply(lambda _: 1, name="unknow_name")
    assert timers.count("unknow_name") == 1


# Generated at 2022-06-21 10:33:18.245261
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test clearing of timers in class Timers"""
    timers = Timers()
    timers.add("a", 1)
    timers.add("b", 2)
    assert len(timers) == 2
    len1 = len(timers._timings["a"])
    len2 = len(timers._timings["b"])
    assert len1 + len2 == 2
    timers.clear()
    assert len(timers) == 0
    assert len(timers._timings["a"]) == 0
    assert len(timers._timings["b"]) == 0


# Generated at 2022-06-21 10:33:21.944670
# Unit test for method max of class Timers
def test_Timers_max():
    """Test the max method of class Timers"""
    t = Timers()
    t.add("foo", 1)
    assert t.max("foo") == 1.0



# Generated at 2022-06-21 10:33:28.654428
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    timers = Timers()

    timers.add("a", 2)
    timers.add("a", 1)
    timers.add("a", 3)
    timers.add("b", 3)
    timers.add("b", 2)

    assert timers.min("a") == 1
    assert timers.min("b") == 2

    # Test with empty list
    timers.clear()
    timers.add("c", None)
    assert timers.min("c") == 0

# Generated at 2022-06-21 10:33:38.481746
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count("") == 0
    timers.add("", 1)
    assert timers.count("") == 1
    timers.add("", 2)
    assert timers.count("") == 2
    timers._timings[""] = []
    assert timers.count("") == 0



# Generated at 2022-06-21 10:33:43.099367
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    t = Timers()
    t["foo"] = 1.
    assert t["foo"] == 1.
    try:
        t["foo"] = 1.1
    except TypeError as exc:
        pass
    else:
        raise Exception("Did not catch expected TypeError") from None


# Generated at 2022-06-21 10:33:47.157249
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add('Timer1', 0.1)
    t.add('Timer1', 0.2)
    t.add('Timer1', 0.3)
    assert t.min('Timer1') == 0.1


# Generated at 2022-06-21 10:33:53.681703
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Check that timer values can not be set"""
    def _create_instance():
        return Timers()

    def _get_expected_message():
        return f"'{_create_instance().__class__.__name__}' does not support item assignment. Use '.add()' to update values."

    from_ = _create_instance()
    with pytest.raises(TypeError) as exception:
        from_["name"] = 0
    assert str(exception.value) == _get_expected_message()


# Generated at 2022-06-21 10:34:03.072198
# Unit test for method total of class Timers
def test_Timers_total():
    import pytest
    from random import randint
    from pycosio._core.timer import Timers

    test_timers = Timers()
    test_timers.add('timer0', 5)
    test_timers.add('timer0', 6)
    test_timers.add('timer1', 1)
    test_timers.add('timer2', 3)

    test_values = {'total0': 11, 'total1': 1, 'total2': 3}
    for key, value in test_values.items():
        assert test_timers.total(key.replace('total', 'timer')) == value

    # Test with no values
    assert test_timers.total('timer3') == 0

    # Test with bad timer name

# Generated at 2022-06-21 10:34:15.418494
# Unit test for method median of class Timers
def test_Timers_median():
    """test the method median of the class Timers"""
    timers = Timers()

    # Adding empty list
    timers.add('timer1', 10)
    timers.add('timer1', 20)
    timers.add('timer1', 30)
    timers.add('timer1', 40)
    timers.add('timer1', 50)
    assert timers.median('timer1') == 30

    # Adding odd list
    timers.add('timer2', 5)
    timers.add('timer2', 10)
    timers.add('timer2', 15)
    timers.add('timer2', 20)
    timers.add('timer2', 25)
    assert timers.median('timer2') == 15

    # Adding even list
    timers.add('timer3', 3)
    timers.add('timer3', 7)

# Generated at 2022-06-21 10:34:18.977410
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """stderr method of Timers class"""
    results = [14, 15, 15, 16, 17, 17, 18, 18, 20, 21]
    new_timers = Timers()
    for result in results:
        new_timers.add('A', result)
    stdev = new_timers.stdev('A')
    assert stdev == 2

# Generated at 2022-06-21 10:34:26.512893
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.clear()
    name0 = "test_Timers_total.0"
    timers.add(name0, 5.0)
    timers.add(name0, 4.0)
    timers.add(name0, 3.0)
    timers.add(name0, 2.0)
    timers.add(name0, 1.0)
    total0 = timers.total(name=name0)
    assert total0 == 15.0

test_Timers_total()

# Generated at 2022-06-21 10:34:30.300428
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    assert timers.median('foo') == 0.0
    timers.add('foo', 300.0)
    assert timers.median('foo') == 300.0
    timers.add('foo', 100.0)
    assert timers.median('foo') == 250.0
    timers.add('foo', 500.0)
    assert timers.median('foo') == 300.0

# Generated at 2022-06-21 10:34:37.745064
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers._timings['test_key'] = [4, 2, 1, 2, 3, 2, 3, 2, 1, 2, 3, 2, 3, 2, 3, 2, 1]
    assert timers.apply(len, name='test_key') == 17
    assert timers.apply(sum, name='test_key') == 33
    assert timers.apply(lambda values: min(values or [0]), name='test_key') == 1

# Generated at 2022-06-21 10:34:51.803303
# Unit test for method stdev of class Timers
def test_Timers_stdev():

    import pytest

    # test normal case
    timers = Timers()
    timers.add('timer_a', 1)
    timers.add('timer_a', 2)
    timers.add('timer_a', 3)
    timers.add('timer_a', 4)
    assert timers.stdev('timer_a') == pytest.approx(1)

    # test with single value
    timers = Timers()
    timers.add('timer_a', 1)
    assert math.isnan(timers.stdev('timer_a'))

    # test with no value
    timers = Timers()
    with pytest.raises(KeyError):
        timers.stdev('timer_a')

# Generated at 2022-06-21 10:34:55.440969
# Unit test for constructor of class Timers
def test_Timers():
    """Test whether constructor of Timers() works"""
    timers = Timers()
    assert timers.data == {}



# Generated at 2022-06-21 10:34:57.952952
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('median_test', 1)
    timers.add('median_test', 2)
    assert timers.median('median_test') == 1.5

# Generated at 2022-06-21 10:34:59.096352
# Unit test for method max of class Timers
def test_Timers_max():
    assert isinstance(Timers(), Timers)


# Generated at 2022-06-21 10:35:02.223875
# Unit test for method median of class Timers
def test_Timers_median():
    # Setup
    testTimers = Timers()
    testTimers._timings = {'test' : [4, 5, 6, 7, 8, 9, 10, 11]}

    # Act
    median = testTimers.median('test')

    # Assert
    assert median == 7.5

# Generated at 2022-06-21 10:35:08.623702
# Unit test for method max of class Timers
def test_Timers_max():
    """test_Timers_max"""
    timers = Timers()
    timers.add('foo', 1.2)
    timers.add('foo', 1.1)
    timers.add('bar', 1.0)
    assert timers.max('foo') == 1.2
    assert timers.max('bar') == 1.0
    assert timers.max('unknown') == 0.0

# Generated at 2022-06-21 10:35:12.065409
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add("test", 2)
    t.add("test", 4)
    t.add("test", 2)
    assert t.mean("test") == 2.6666666666666665



# Generated at 2022-06-21 10:35:14.592375
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add("test", 1)
    t.add("test", 2)
    assert t.mean("test") == 1.5

# Generated at 2022-06-21 10:35:17.346367
# Unit test for method count of class Timers
def test_Timers_count():
    t = Timers()
    t.add('a', 1)
    assert t.count('a') == 1
    assert t.count('b') == 0


# Generated at 2022-06-21 10:35:22.650414
# Unit test for method apply of class Timers
def test_Timers_apply():  # pragma: no cover
    from test import timer_1_max, timer_1_mean
    timers = Timers()
    for i in range(10):
        timers.add("timer_1", i)
    ret = timers.apply(max, name="timer_1")
    assert ret == timer_1_max
    ret = timers.apply(lambda values: statistics.mean(values), name="timer_1")
    assert ret == timer_1_mean

# Generated at 2022-06-21 10:35:34.129679
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method add of class Timers"""

    class MyClass(object):
        def __init__(self):
            self.timers = Timers()

        def add_time(self, name, timer):
            self.timers.add(name, timer)

    instance = MyClass()
    instance.add_time('test', 1.1)
    instance.add_time('test', 2.3)
    instance.add_time('test', 3.5)
    assert instance.timers.total('test') == 7



# Generated at 2022-06-21 10:35:40.721971
# Unit test for method max of class Timers
def test_Timers_max():  # pragma: no cover
    from unittest import TestCase
    from unittest.mock import patch

    class _TestTimers(TestCase):
        def test_max(self) -> None:
            # Create a Timers instance
            timers = Timers()

            # Mock the underlying _timings of the Timers instance
            timers._timings = {  # type: ignore
                "a": [1, 2, 3, 4],
                "b": [5, 6, 7, 8],
                "c": []
            }

            # Execute the method and check the results
            self.assertEqual(timers.max("a"), 4)
            self.assertEqual(timers.max("b"), 8)
            self.assertTrue(math.isnan(timers.max("c")))
            self.assertRa

# Generated at 2022-06-21 10:35:49.578229
# Unit test for method median of class Timers
def test_Timers_median():
    """Construct timers and test its median method"""
    timers = Timers()
    timers.add('a', 40)
    timers.add('a', 60)
    assert timers.data['a'] == 100
    assert timers.apply(list, 'a') == [40, 60]  # type: ignore
    assert timers.count('a') == 2
    assert timers.total('a') == 100
    assert timers.min('a') == 40
    assert timers.max('a') == 60
    assert timers.mean('a') == 50
    assert timers.median('a') == 50
    assert timers.stdev('a') == 10
    timers.apply(list, 'b')  # This should raise a key error

# Generated at 2022-06-21 10:36:02.184965
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    expected = Timers()
    expected['test'] = 2.0
    expected['test2'] = 3.0
    observed = Timers()
    observed.add('test', 1.0)
    observed.add('test', 1.0)
    observed.add('test2', 3.0)
    assert expected['test'] == observed.total('test')
    assert expected['test2'] == observed.total('test2')
    assert expected.count('test') == observed.count('test')
    assert expected.min('test') == observed.min('test')
    assert expected.min('test2') == observed.min('test2')
    assert expected.max('test') == observed.max('test')
    assert expected.max('test2') == observed.max('test2')

# Generated at 2022-06-21 10:36:03.940336
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers['time']=3.5
    assert timers.min('time')==3.5

# Generated at 2022-06-21 10:36:08.447431
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("A", 4)
    timers.add("A", 6)
    timers.add("B", -3)
    timers.add("B", 5)

    assert timers.mean("A") == 5
    assert timers.mean("B") == 1


# Generated at 2022-06-21 10:36:13.882374
# Unit test for constructor of class Timers
def test_Timers():
    """Construct an empty object of class Timers and add some data."""
    timer = Timers()
    timer.add("test", 123.456)
    assert timer.data["test"] == 123.456
    assert timer._timings["test"] == [123.456]

    # Test exception
    try:
        timer["test"] = 123.456
        assert False
    except TypeError:
        pass

    # Test clear
    timer.clear()
    assert timer.data == {}
    assert timer._timings == {}


# Generated at 2022-06-21 10:36:15.845103
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t['timer1'] = 1.65
    assert t.mean('timer1') == 1.65
    t['timer2'] = 2.30
    t['timer2'] = 3.10
    assert t.mean('timer2') == 2.7


# Generated at 2022-06-21 10:36:21.417894
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    d = Timers()
    d.add('test', 1) # Add one value
    assert math.isnan(d.stdev('test')) # Only one value: Standard deviation should be Not A Number
    d.add('test', 2) # Add another value
    assert d.stdev('test') == 1 # Standard deviation
    d.add('test', 42) # Add another value
    assert d.stdev('test') == 20.580965522332848 # Standard deviation

# Generated at 2022-06-21 10:36:25.832574
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Test empty timings
    timers = Timers()
    assert timers.mean("key") == 0
    # Test single timing
    timers.add("key", 1)
    assert timers.mean("key") == 1
    # Test two timings
    timers.add("key", 10)
    assert timers.mean("key") == 5.5
    # Test non-existent key
    with pytest.raises(KeyError):
        timers.mean("non_existent_key")

# Generated at 2022-06-21 10:36:45.761997
# Unit test for method apply of class Timers
def test_Timers_apply():
    """
    Test Timers.apply() method
    """
    timers = Timers()
    for i in range(10):
        timers.add("timer0", i)
    timers.add("timer1", 10)
    timers.add("timer1", 20)
    assert not list(timers) == ["timer0", "timer1"]
    assert timers.count("timer1") == 2
    assert timers.total("timer1") == 30
    assert timers.min("timer1") == 10
    assert timers.max("timer1") == 20
    assert timers.mean("timer1") == 15
    assert timers.median("timer1") == 15
    assert timers.stdev("timer1") == 5
    # Check with an empty list of timings
    assert timers.min("timer0") == 0
    # Invalid timername

# Generated at 2022-06-21 10:36:48.087403
# Unit test for constructor of class Timers
def test_Timers():
    """Constructor of class Timers"""
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-21 10:36:53.776768
# Unit test for method mean of class Timers
def test_Timers_mean():
    from math import inf

    timers = Timers()

    # Empty timer should give 0.0 as mean
    assert timers.mean("timer") == 0

    # Add a zero
    timers.add("timer", 0)
    assert timers.mean("timer") == 0

    # Add a single value (timers should behave like standard library mean)
    timers.add("timer", 5.67)
    assert timers.mean("timer") == 5.67

    # Add more values
    timers.add("timer", 8)
    timers.add("timer", inf)
    assert timers.mean("timer") == inf


# Generated at 2022-06-21 10:36:59.121312
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test the clear method of the Timers class"""
    timers = Timers()
    timers.add('test', 1.0)
    assert timers.data['test'] == 1.0
    assert timers._timings['test'] == [1.0]

    timers.clear()

    assert timers.data == {}
    assert timers._timings == {}

# Generated at 2022-06-21 10:36:59.686394
# Unit test for method total of class Timers
def test_Timers_total():
    pass

# Generated at 2022-06-21 10:37:07.747789
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    assert timers.apply(len, "test") == 0
    assert timers.apply(sum, "test") == 0
    assert timers.apply(lambda values: min(values or [0]), "test") == 0
    assert timers.apply(lambda values: max(values or [0]), "test") == 0
    assert timers.apply(lambda values: statistics.mean(values or [0]), "test") == 0
    assert timers.apply(lambda values: statistics.median(values or [0]), "test") == 0
    assert timers.apply(lambda values: statistics.stdev(values), "test") == 0
    assert timers.data == {}


# Generated at 2022-06-21 10:37:11.495359
# Unit test for method count of class Timers
def test_Timers_count():
    timer = Timers()
    timer.add("ABC", 1.0)
    timer.add("ABC", 2.0)
    timer.add("XYZ", 3.0)
    assert timer.count("ABC") == 2
    assert timer.count("XYZ") == 1


# Generated at 2022-06-21 10:37:13.872726
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    assert timers.stdev('foo') == math.nan
    timers.add('foo', [1])
    assert timers.stdev('foo') == math.nan
    timers.add('foo', [1, 2])
    assert timers.stdev('foo') == 1

# Generated at 2022-06-21 10:37:24.385930
# Unit test for method apply of class Timers
def test_Timers_apply():
    from pymonad import curry

    t = Timers()
    t.add("timer_1", 1.0)
    t.add("timer_1", 2.0)
    t.add("timer_1", 3.0)
    t.add("timer_2", 0.1)
    t.add("timer_2", 0.2)
    t.add("timer_2", 0.3)

    assert t.mean("timer_1") == 2.0
    assert t.median("timer_1") == 2.0
    assert t.mean("timer_2") == 0.2
    assert t.median("timer_2") == 0.2
    assert t.apply(curry(lambda lst : max(lst))("timer_1")) == 3.0

# Generated at 2022-06-21 10:37:26.415012
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    from pytest import raises
    timers = Timers()
    with raises(TypeError):
        timers["time"] = 0


# Generated at 2022-06-21 10:37:39.712030
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    # Create Timers object
    timer_obj = Timers()
    # Add values
    timer_obj.add("a", 5)
    timer_obj.add("a", 10)
    # Test mean
    assert timer_obj.mean("a") == 7.5


# Generated at 2022-06-21 10:37:43.581751
# Unit test for method min of class Timers
def test_Timers_min():
    """Test if Timers.min function returns expected result"""
    t = Timers()
    t.add('test', 5)
    assert t.min('test') == 5
    t.add('test', 10)
    assert t.min('test') == 5
    t.add('test', 1)
    assert t.min('test') == 1


# Generated at 2022-06-21 10:37:54.235055
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """
    Test stdev method of Timers class.
    """
    from qgis.PyQt.QtCore import QCoreApplication
    from .unit_tests import (
        MOCK_TIMER,
    )
    from qgis.server import QgsServer

    server = QgsServer()
    t = Timers()
    MOCK_TIMER.timers = t

# Generated at 2022-06-21 10:38:02.222024
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test the apply method of the Timers class."""
    timers = Timers()
    timers.add('test', 4)
    timers.add('test', 6)
    timers.add('test', 9)
    assert timers.apply(len, name='test') == 3
    assert timers.apply(sum, name='test') == 19
    assert timers.apply(lambda values: min(values), name='test') == 4
    assert timers.apply(lambda values: max(values), name='test') == 9
    assert timers.apply(lambda values: statistics.mean(values), name='test') == 6.333333333333333

# Generated at 2022-06-21 10:38:10.274126
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("parsing", 0.6)
    timers.add("matching", 0.4)
    timers.add("matching", 0.2)
    assert round(timers.mean("matching"), 6) == 0.3
    assert round(timers.mean("parsing"), 6) == 0.6
    assert round(timers.mean("processing"), 6) == 0.0


# Generated at 2022-06-21 10:38:14.109264
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('test_1', 1.0)
    timers.add('test_1', 2.0)
    assert timers.mean('test_1') == 1.5
    timers.add('test_2', 3.0)
    assert timers.mean('test_2') == 3.0

# Generated at 2022-06-21 10:38:16.660510
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add("test", 3.14)
    timers.add("test", 2.78)
    assert timers.total("test") == 5.92


# Generated at 2022-06-21 10:38:23.637088
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add("timers", 1.0)
    assert timers.data["timers"] == 1.0

    timers.add("timers", 2.0)
    assert timers.data["timers"] == 3.0

    timers.add("timers", 3.0)
    assert timers.data["timers"] == 6.0


# Generated at 2022-06-21 10:38:31.088808
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    assert t.max('results') == 0

    t.add('results', 1)
    assert t.max('results') == 1

    t.add('results', 2)
    assert t.max('results') == 2

    t.add('results', 3)
    assert t.max('results') == 3

    # print(t.data)  # {'results': 6}
    # print(t._timings)  # {'results': [1, 2, 3]}

# Generated at 2022-06-21 10:38:38.886508
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add("discretization", 0.1)
    timers.add("discretization", 0.2)
    timers.add("discretization", 0.1)
    timers.add("discretization", 0.2)
    timers.add("discretization", 0.1)
    timers.add("discretization", 0.2)
    timers.add("discretization", 0.1)
    timers.add("discretization", 0.2)
    timers.add("discretization", 0.1)
    timers.add("discretization", 0.2)
    assert timers.mean("discretization") == 0.15
    assert timers.min("discretization") == 0.1

# Generated at 2022-06-21 10:38:51.336248
# Unit test for method total of class Timers
def test_Timers_total():
    # Initialize instances
    timers = Timers()

    # Test for method total
    name = f"a"
    assert timers.total(name) == 0
    timers.add(name, 1)
    assert timers.total(name) == 1

# Generated at 2022-06-21 10:38:55.404564
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    timers = Timers()
    timers.add("time_tot", 1.0)
    timers.add("time_tot", 2.0)
    timers.add("time_tot", 3.0)
    assert timers.apply(lambda values: sum(values), name="time_tot") == 6.0

# Generated at 2022-06-21 10:39:00.389689
# Unit test for method min of class Timers
def test_Timers_min():
    assert Timers().min('dummy') == 0
    t = Timers()
    t.add('dummy', 10)
    t.add('dummy', 20)
    t.add('dummy', 30)
    assert t.min('dummy') == 10
    t.add('dummy', 0)
    assert t.min('dummy') == 0



# Generated at 2022-06-21 10:39:05.602594
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test that we cannot set item of Timers
    """
    timers = Timers()

    with pytest.raises(TypeError) as excinfo:
        timers["test"] = 1
    assert (
        "does not support item assignment. Use '.add()' to update values."
        in str(excinfo.value)
    )


# Generated at 2022-06-21 10:39:10.700721
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test_timers_1', 1)
    timers.add('test_timers_2', 2)
    assert timers.max('test_timers_1') == 1
    assert timers.max('test_timers_2') == 2

# Generated at 2022-06-21 10:39:20.677137
# Unit test for method add of class Timers
def test_Timers_add():
    import pytest
    timers = Timers()
    assert timers.count('foo') == 0
    assert timers.total('foo') == 0
    assert timers.min('foo') == 0
    assert timers.max('foo') == 0
    assert timers.mean('foo') == 0
    assert timers.median('foo') == 0
    assert math.isnan(timers.stdev('foo'))
    with pytest.raises(TypeError):
        timers['foo'] = 0
    with pytest.raises(KeyError):
        timers.count('bar')
    with pytest.raises(KeyError):
        timers.total('bar')
    with pytest.raises(KeyError):
        timers.min('bar')
    with pytest.raises(KeyError):
        timers.max('bar')

# Generated at 2022-06-21 10:39:27.102767
# Unit test for method min of class Timers
def test_Timers_min():
    """Tests the method min of the class Timers"""
    a = Timers()
    a.add("test1", 1)
    a.add("test2", 2)
    a.add("test3", 3)
    assert a.min("test1") == 1
    assert a.min("test2") == 2
    assert a.min("test3") == 3
    assert a.min("test") == 0

# Generated at 2022-06-21 10:39:34.449971
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test that Timers.stdev works as expected"""
    timer = Timers()
    assert math.isnan(timer.stdev("test"))
    timer.add("test", 10)
    assert math.isnan(timer.stdev("test"))
    timer.add("test", 20)
    assert timer.stdev("test") == 5
    timer.add("test", 30)
    assert timer.stdev("test") == 10

# Generated at 2022-06-21 10:39:40.534442
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    # initialize timers
    timer = "TIMER_INITIALIZE"
    timers.add(timer, 3.00)
    # check if timers has the timer
    assert timer in timers
    # test that a timer doesn't exist
    timer = "TIMER_NOT_EXIST"
    assert timer not in timers


# Generated at 2022-06-21 10:39:44.215275
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    with pytest.raises(TypeError):
        timers = Timers()
        timers['foobar'] = 1.0  # type: ignore

# Generated at 2022-06-21 10:40:10.413688
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    # Define timer
    timers = Timers()
    timer = timers.insert
    # pylint: disable=unused-variable

    timer("add", 2.0)
    timer("add", 3.0)
    timer("add", 4.0)

    timer("sub", 4.0)
    timer("sub", 3.0)
    timer("sub", 2.0)

    assert timers.apply(len, "add") == 3
    assert timers.apply(sum, "sub") == 9
    assert timers.apply(lambda values: min(values or [0]), "sub") == 2.0
    assert timers.apply(lambda values: max(values or [0]), "add") == 4.0



# Generated at 2022-06-21 10:40:13.965699
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('test',0.5)
    timers.add('test',0.5)
    timers.add('test',0.5)
    assert timers.mean('test') == 0.5


# Generated at 2022-06-21 10:40:18.849564
# Unit test for method min of class Timers
def test_Timers_min():
    class TimeIt:
        def __enter__(self):
            return self
    
        def __exit__(self, *args):
            return False

        def timeit(self, *args):
            self.time = 0.017
    
    timer = Timers()
    with TimeIt() as t:
        timer.add(name="test", value=t.timeit())
    assert timer.min(name="test") == 0.017


# Generated at 2022-06-21 10:40:24.818898
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    # GIVEN: A Timers instance and a name
    name = "test"
    timers = Timers()

    # WHEN: The timing values are stdev
    timers._timings = {name: [10.0, 10.0, 10.0, 10.0, 10.0, 10.0, 10.0, 10.0, 10.0, 10.0]}
    result = timers.stdev(name)

    # THEN: The stdev of the timing values should be 0
    assert result == 0

    # WHEN: The timing values are an empty list
    timers._timings = {name: []}
    result = timers.stdev(name)

    # THEN: The stdev of the timing values should be NaN
    assert math.isnan(result)

    # WHEN: The timing values are a singleton list
    timers._

# Generated at 2022-06-21 10:40:28.619491
# Unit test for method count of class Timers
def test_Timers_count():
    """Test that 'count' returns zero, when no values have been
    inserted, and the number of values inserted when they have"""
    timers = Timers()
    assert timers.count('name') == 0
    timers.add('name', 1.0)
    assert timers.count('name') == 1

# Generated at 2022-06-21 10:40:39.525135
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()

    # Test that an empty dictionary raises KeyError
    try:
        timers.min('name')
        assert False, "Empty dictionary didn't raise KeyError"
    except KeyError:
        pass

    # Test that empty list returns 0
    timers._timings = collections.defaultdict(list)
    assert 0 == timers.min('name')

    # Test that empty list returns 0
    timers._timings = collections.defaultdict(list, a=[])
    assert 0 == timers.min('name')

    # Check that a single element is returned as min value
    timers._timings = collections.defaultdict(list, a=[42.1])
    assert 42.1 == timers.min('a')

    # Check that a the minimum value is returned

# Generated at 2022-06-21 10:40:46.957608
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    value = 1.0
    name1 = "timer 1"
    name2 = "timer 2"
    timers.add(name=name1, value=value)
    assert timers.data[name1] == value
    assert name1 in timers._timings
    assert len(timers._timings[name1]) == 1
    assert timers._timings[name1][0] == value

    timers.add(name=name1, value=value)
    assert timers.data[name1] == value * 2
    assert name1 in timers._timings
    assert len(timers._timings[name1]) == 2
    assert timers._timings[name1][1] == value

    timers.add(name=name2, value=value)
    assert timers.data[name2] == value

# Generated at 2022-06-21 10:40:51.752318
# Unit test for method apply of class Timers

# Generated at 2022-06-21 10:40:53.998980
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("my_timer", 0.2)
    timers.add("my_timer", 0.4)
    try:
        timers.count("not_existing_timer")
    except KeyError:
        assert True
    else:
        assert False
    assert timers.count("my_timer") == 2


# Generated at 2022-06-21 10:40:57.943420
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add('A', 1)
    timers.add('B', 2)
    timers.add('C', 3)
    timers.add('A', 2)

    total_A = timers.total('A')
    total_B = timers.total('B')
    total_C = timers.total('C')

    assert total_A == 3
    assert total_B == 2
    assert total_C == 3
