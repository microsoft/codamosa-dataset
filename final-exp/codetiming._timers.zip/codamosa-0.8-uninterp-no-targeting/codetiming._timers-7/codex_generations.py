

# Generated at 2022-06-21 10:31:31.376701
# Unit test for method min of class Timers
def test_Timers_min():
    from ..timer import Timers

    timers = Timers()
    timers.add("a", 1)
    assert timers.min("a") == 1
    timers.add("a", 2)
    assert timers.min("a") == 1
    timers.add("a", 3)
    assert timers.min("a") == 1


# Generated at 2022-06-21 10:31:42.723324
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    timers.add("test", 4)
    assert timers.apply(lambda values: len(values), name="test") == 4
    assert timers.apply(lambda values: max(values), name="test") == 4
    assert timers.apply(lambda values: min(values), name="test") == 1
    assert timers.apply(lambda values: statistics.mean(values), name="test") == 2.5
    assert timers.apply(lambda values: statistics.median(values), name="test") == 2.5
    assert timers.apply(lambda values: statistics.variance(values), name="test") == 1.25

# Generated at 2022-06-21 10:31:46.828273
# Unit test for method max of class Timers
def test_Timers_max():
    """test_Timers_max: Test method max.
    """
    timers = Timers()
    timers['x'] = 1
    timers['y'] = 9
    timers['z'] = 3
    assert timers.max('x') == 1
    assert timers.max('y') == 9
    assert timers.max('z') == 3


# Generated at 2022-06-21 10:31:50.126960
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("test", 10)
    assert timers.median("test") == 10
    timers.add("test", 2)
    assert timers.median("test") == 6
    timers.add("test", 4)
    assert timers.median("test") == 5

# Generated at 2022-06-21 10:31:52.761267
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    name = 'my_timer'
    assert timers.count(name) == 0
    timers.add(name, 1000)
    assert timers.count(name) == 1
    timers.add(name, 500)
    assert timers.count(name) == 2


# Generated at 2022-06-21 10:31:57.254867
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 3.2)
    timers.add("test", 4.5)
    timers.add("test", 0.5)
    assert timers.max("test") == 4.5
    timers.add("test2", -4)
    assert timers.max("test2") == -4

# Generated at 2022-06-21 10:32:01.435241
# Unit test for method max of class Timers
def test_Timers_max():
    TIMERS = Timers()
    TIMERS.add('first_timer', 1.0)
    TIMERS.add('second_timer', 2.0)
    TIMERS.add('first_timer', 2.0)
    assert TIMERS.max('first_timer') == 2.0
    assert TIMERS.max('second_timer') == 2.0

# Generated at 2022-06-21 10:32:04.600715
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.add('test', 1.0)
    t.add('test', 2.0)
    t.add('test', 3.0)
    assert t.max('test') == 3.0


# Generated at 2022-06-21 10:32:07.341213
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test private method __setitem__ of class Timers"""
    from pytest import raises
    timers = Timers()
    with raises(TypeError):
        timers["test"] = 1.0

# Generated at 2022-06-21 10:32:10.566350
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers({'EXAMPLE': {'a': 2.0, 'b': 3.0}})
    assert timers.median(name='a') == 2.0
    assert timers.median(name='b') == 3.0
    assert timers.median(name='c') == 0.0
    assert timers.median(name='EXAMPLE') == 2.5

# Generated at 2022-06-21 10:32:20.237884
# Unit test for method min of class Timers
def test_Timers_min():
    """
    Test if min method in Timers is working correctly
    """
    timers = Timers()
    assert timers.min('not_in') == 0

    assert timers.min('empty') == 0
    timers.add('empty', 3.0)
    assert timers.min('empty') == 3.0
    timers.add('empty', 2.0)
    assert timers.min('empty') == 2.0
    timers.add('empty', -1.0)
    timers.add('empty', 5.0)
    assert timers.min('empty') == -1.0


# Generated at 2022-06-21 10:32:26.407678
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Method __setitem__ of class Timers raises expected error"""
    # Test for the expected error message
    timer = Timers()
    error_msg_expected = (
        f"{timer.__class__.__name__!r} objects do not support item assignment. "
        "Use '.add()' to update values.")
    try:
        timer['test'] = 1
    except TypeError as error_msg_actual:
        assert error_msg_expected == str(error_msg_actual)


# Generated at 2022-06-21 10:32:28.538561
# Unit test for constructor of class Timers
def test_Timers():
    # exercise class constructor
    mytimers = Timers()
    # verify data attributes
    assert mytimers.data == {}
    assert mytimers._timings == {}


# Generated at 2022-06-21 10:32:35.761090
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    print("stdev example")
    print("stdev(5,5,5,5,5) = ", timers.stdev("test"))
    timers.add("test", 5)
    timers.add("test", 5)
    timers.add("test", 5)
    timers.add("test", 5)
    timers.add("test", 5)
    print("stdev(5,5,5,5) = ", timers.stdev("test"))
    timers.add("test", 5)
    print("stdev(5,5,5,5,5) = ", timers.stdev("test"))
    timers.add("test", 1)
    timers.add("test", 2)

# Generated at 2022-06-21 10:32:46.069551
# Unit test for method add of class Timers
def test_Timers_add():
    o = Timers()
    o.add("A", 1.0)
    assert o.data["A"] == 1.0
    o.add("A", 2.0)
    assert o.data["A"] == 3.0
    assert o._timings["A"] == [1.0, 2.0]
    assert o.total("A") == 3.0
    assert o.count("A") == 2
    assert o.min("A") == 1.0
    assert o.max("A") == 2.0
    assert o.mean("A") == 1.5
    assert o.median("A") == 1.5
    assert o.stdev("A") == 0.5


# Generated at 2022-06-21 10:32:50.364313
# Unit test for method min of class Timers
def test_Timers_min():
    # Initialize variables
    t = Timers()
    t.add('name', value=1)
    t.add('name', value=2)
    t.add('name', value=4)
    # Test
    assert t.min('name') == 1


# Generated at 2022-06-21 10:32:53.129188
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add('example', 5)
    assert timers.data
    assert timers._timings
    timers.clear()
    assert not timers.data
    assert not timers._timings

# Generated at 2022-06-21 10:32:56.149850
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    for timer_name in ['A', 'B']:
        timers.add(timer_name, 1)

    assert timers.median('A') == 1.0


# Generated at 2022-06-21 10:32:59.956241
# Unit test for constructor of class Timers
def test_Timers():
    """Test class constructor"""
    timers = Timers()
    assert isinstance(timers, Timers)
    assert isinstance(timers, collections.UserDict)
    assert isinstance(timers.data, dict)
    assert isinstance(timers._timings, dict)
    assert len(timers) == 0
    assert len(timers._timings) == 0


# Generated at 2022-06-21 10:33:02.001299
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.add("t1",4)
    t.add("t2",5)
    assert t.max("t1") == 4
    assert t.max("t2") == 5


# Generated at 2022-06-21 10:33:12.741779
# Unit test for method min of class Timers
def test_Timers_min():
    """Test the function Timers.min"""
    timers = Timers()
    timers.add("test1", 1.0)
    timers.add("test1", 2.0)
    timers.add("test2", 3.0)
    timers.add("test2", 4.0)
    assert timers.min("test1") == 1.0
    assert timers.min("test2") == 3.0
    assert timers["test1"] == 3.0


# Generated at 2022-06-21 10:33:15.855056
# Unit test for constructor of class Timers
def test_Timers():
    a = Timers()
    assert a.data.get('test') is None
    assert len(a._timings) == 0
    a.add('test', 1)
    assert a.data['test'] == 1
    assert a._timings['test'] == [1]

# Generated at 2022-06-21 10:33:25.082143
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    assert len(timers.data) == 0
    timers.add('name1', 4.0)
    timers.add('name1', 2.0)
    timers.add('name2', 1.0)
    assert len(timers.data) == 2
    assert timers['name1'] == 6.0
    assert timers['name2'] == 1.0
    assert timers.count('name1') == 2

# Unit tests for method clear of class Timers

# Generated at 2022-06-21 10:33:28.208894
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('min', 5)
    timers.add('min', 9)
    timers.add('min', 2)
    assert timers.min('min') == 2


# Generated at 2022-06-21 10:33:31.232699
# Unit test for method total of class Timers
def test_Timers_total():
    """Test method total of class Timers"""
    timers: Timers = Timers()
    timers.add("time", 5)
    timers.add("time", 6)
    assert timers.total("time") == 11

# Generated at 2022-06-21 10:33:35.290752
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    # Initialize the object under test
    timers = Timers()
    # Attempt to set a value
    try:
        timers['name'] = 42
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 10:33:47.293255
# Unit test for method max of class Timers
def test_Timers_max():
    # Create empty timers object
    timers = Timers()
    assert isinstance(timers, Timers)
    # Fill timers with data
    timers.add("a", 1)
    timers.add("a", 2)
    timers.add("b", 3)
    timers.add("b", 4)
    # Check the type and value of max of timers
    assert isinstance(timers.max("b"), float)
    assert timers.max("b") == 4.0
    # Test for missing name
    try:
        timers.max("c")
        raise AssertionError("An error was expected")
    except KeyError as exc:
        assert str(exc) == "'c'"
    # Test for non-existing name

# Generated at 2022-06-21 10:33:51.931168
# Unit test for method max of class Timers
def test_Timers_max():
    # Create a Timers object
    t = Timers()

    # Add two values
    t.add('first', 3)
    t.add('first', 5)

    # Add three values
    t.add('second', 57)
    t.add('second', 8)
    t.add('second', 79)

    # Check they are the expected values
    assert t.max('first')==5
    assert t.max('second')==79


# Generated at 2022-06-21 10:33:57.903572
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for method stdev of class Timers"""
    timers = Timers({'name': 0})
    timers.add('name', 42)
    assert timers.stdev('name') == math.nan
    timers.add('name', 42)
    assert timers.stdev('name') == 0.0



# Generated at 2022-06-21 10:34:02.209023
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.add("Spam", 1)
    t.add("Eggs", 2)
    t.add("Spam", 3)
    t.add("Eggs", 4)
    assert t.max("Spam") == 3
    assert t.max("Eggs") == 4
    assert t.max("Ham") == 0



# Generated at 2022-06-21 10:34:13.850354
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Timers does not support item assignment"""
    timers = Timers()
    try:
        timers["key"] = 1
        assert False, "Assignment should fail"
    except TypeError:
        assert True


# Generated at 2022-06-21 10:34:19.689580
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    # Default return value should be nan
    assert math.isnan(timers.stdev('any_timer'))
    # A single value should return nan
    timers.add('any_timer', 1)
    assert math.isnan(timers.stdev('any_timer'))


# Generated at 2022-06-21 10:34:24.503639
# Unit test for method count of class Timers
def test_Timers_count():
    """Test method count of class Timers."""
    t = Timers()
    t.add('foo', 1)
    t.add('foo', 2)
    t.add('bar', 3)
    t.add('bar', 4)
    assert t.count('foo') == 2
    assert t.count('bar') == 2


# Generated at 2022-06-21 10:34:26.726185
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert dict(timers) == {}
    assert timers._timings == {}


# Generated at 2022-06-21 10:34:37.749304
# Unit test for method mean of class Timers
def test_Timers_mean():
    """test mean with Timers"""
    timer = Timers()
    timer.add('B', 5)
    timer.add('C', 4)
    timer.add('B', 6)
    timer.add('A', 7)
    timer.add('B', 8)
    timer.add('D', 2)
    timer.add('B', 3)
    timer.add('C', 2)
    timer.add('B', 5)
    assert timer.mean('B') == 5.5
    assert timer.mean('A') == 7
    assert timer.mean('C') == 3
    assert timer.mean('D') == 2
    assert timer.mean('L') == 0


# Generated at 2022-06-21 10:34:45.015205
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    x = timers.add("test", 5)
    assert isinstance(x, None) is True
    assert timers.total("test") == 5
    assert timers.min("test") == 5
    assert timers.max("test") == 5
    assert timers.mean("test") == 5
    assert timers.median("test") == 5
    assert timers.stdev("test") == 0
    assert timers.count("test") == 1
    assert "test" in timers.data
    assert timers.data["test"] == 5
    assert "test" in timers._timings
    assert timers._timings["test"] == [5]


# Generated at 2022-06-21 10:34:45.985919
# Unit test for method min of class Timers
def test_Timers_min():
    """Missing unit test"""
    return None

# Generated at 2022-06-21 10:34:52.972077
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count('timer1') == 0
    timers.add('timer1', 1.2)
    assert timers.count('timer1') == 1
    timers.add('timer1', 2.4)
    assert timers.count('timer1') == 2
    timers.add('timer2', 3.6)
    assert timers.count('timer1') == 2
    assert timers.count('timer2') == 1

    try:
        timers.count('timer3')
    except KeyError:
        pass
    else:
        assert False


# Generated at 2022-06-21 10:34:56.369132
# Unit test for method total of class Timers
def test_Timers_total():
    # Create timers
    timers = Timers()
    # Add two timings
    timers.add("total", 10)
    timers.add("total", 20)
    # Get total
    assert timers.total("total") == 30

# Execute the test
if __name__ == "__main__":
    test_Timers_total()

# Generated at 2022-06-21 10:34:58.188227
# Unit test for constructor of class Timers
def test_Timers():
    """

    """
    timers = Timers()
    assert isinstance(timers._timings, dict)


# Generated at 2022-06-21 10:35:16.058929
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    timers["test"] = 100

test_Timers___setitem__()

# Generated at 2022-06-21 10:35:20.388773
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count('mytimer') == 0
    timers.add('mytimer', 0)
    assert timers.count('mytimer') == 1
    timers.add('mytimer', 0)
    assert timers.count('mytimer') == 2


# Generated at 2022-06-21 10:35:31.441246
# Unit test for method clear of class Timers
def test_Timers_clear(): # TODO: pytest
    """Clear timers"""
    timers = Timers()
    assert not timers.data
    assert not timers._timings

    timers.add('x', 1)
    timers.add('x', 1)
    timers.add('y', 1)
    timers.add('y', 1)
    timers.add('y', 2)

    assert timers.data == {'x': 2, 'y': 4}
    assert timers.get('x') == 2
    assert timers.get('y') == 4

    assert timers._timings == {'x': [1, 1], 'y': [1, 1, 2]}
    assert timers._timings.get('x') == [1, 1]
    assert timers._timings.get('y') == [1, 1, 2]

    timers.clear()

    assert not timers

# Generated at 2022-06-21 10:35:34.421561
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    from numpy import std
    from numpy.random import randn

    timers = Timers()

    for x in randn(10):
        timers.add("A", x)

    assert (timers.stdev("A") - std(randn(10))) < 1e-10

# Generated at 2022-06-21 10:35:36.696944
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    timer = Timers()
    assert timer.data == {}
    assert timer._timings == {}

# Generated at 2022-06-21 10:35:38.755684
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Unit test for method clear of class Timers"""

    timers = Timers()
    timers.add("a",1)

    timers.clear()

    assert timers.data == {}
    assert timers._timings == {}

# Generated at 2022-06-21 10:35:44.982060
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    # Create an instance of Timer class to test
    timers = Timers()
    # Test that test_Timers___setitem__ raises an exception if given a value
    with pytest.raises(TypeError) as error:
        timers["test"] = 1.0
    # Unit test complete
    assert str(error.value) == f"{timers.__class__.__name__!r} does not support item assignment. Use '.add()' to update values."


# Generated at 2022-06-21 10:35:47.176497
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add('a_key', 1)
    assert timers['a_key']==1


# Generated at 2022-06-21 10:35:50.679596
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test1', 1.0)
    assert timers.min('test1') == 1.0
    timers.add('test1', -1.0)
    assert timers.min('test1') == -1.0


# Generated at 2022-06-21 10:35:54.413431
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method in Timers"""
    timer = Timers()
    timer.add("test", 5)
    timer.add("test", 8)
    assert timer.mean("test") == 6.5

# Generated at 2022-06-21 10:36:31.258052
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("foo", 0.5)
    timers.add("bar", 1.5)
    timers.add("bar", 2.5)
    assert timers.max("foo") == 0.5
    assert timers.max("bar") == 2.5
    assert timers.max("baz") == 0.0

# Generated at 2022-06-21 10:36:42.292675
# Unit test for method total of class Timers
def test_Timers_total():
    """Test the method that calculates the total of a timer"""
    #Create a Timers object
    name = "Timers"
    timers = Timers()

    # Create a list with values
    value = [2.0,3.0,2.0,2.0,2.0,2.0,2.0,2.0,2.0,2.0]

    # Set the data of the Timers
    timers.data = {name: value}

    # Calculate the sum of the values
    total_value = sum(value)

    # Compare the total value calculated with the timers.total method
    assert(timers.total(name) == total_value)

# Generated at 2022-06-21 10:36:46.096092
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add('test_timer', 10)
    assert timers.data['test_timer'] == 10
    timers.add('test_timer', 25)
    assert timers.data['test_timer'] == 35

# Generated at 2022-06-21 10:36:48.276628
# Unit test for constructor of class Timers
def test_Timers():  # pragma: no cover
    """Test constructor of class Timers"""
    timers = Timers()
    assert timers


# Generated at 2022-06-21 10:36:52.832522
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    assert timers.stdev('test') == math.nan
    timers._timings['test'].append(1)
    assert timers.stdev('test') == math.nan
    timers._timings['test'].append(2)
    assert timers.stdev('test') == math.sqrt(2 / 3)

# Keep pytest happy
test_Timers_stdev()

# Generated at 2022-06-21 10:36:58.065613
# Unit test for method min of class Timers
def test_Timers_min():
    import doctest
    data = {'foo':0.1, 'bar': 0.2}
    timers = Timers(data)
    assert timers.min('foo') == 0.1
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)


# Generated at 2022-06-21 10:37:00.442143
# Unit test for constructor of class Timers
def test_Timers():
    """Constructor of Timers class"""
    t = Timers()
    assert t._timings == {}
    assert t.data == {}
    assert t == {}

# Generated at 2022-06-21 10:37:06.121540
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    assert len(timers) == 0
    timers._timings['name1'] = [1, 2, 3]
    timers._timings['name2'] = [4, 5, 6]
    assert len(timers._timings) == 2
    timers.clear()
    assert len(timers) == 0

# Generated at 2022-06-21 10:37:13.534255
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for stdev method of Timers class"""
    timers = Timers()
    timers.add("A", 1.0)
    timers.add("A", 2.0)
    timers.add("A", 3.0)

    assert "A" in timers
    assert "B" not in timers
    assert timers.stdev("A") == 1.0
    try:
        timers.stdev("B")
    except KeyError as ex:
        # Expected KeyError exception
        assert ex.args[0] == "B"
    else:
        assert False, "Test failed"

    timers.clear()
    assert not timers

    try:
        timers.stdev("A")
    except KeyError as ex:
        # Expected KeyError exception
        assert ex.args[0] == "A"

# Generated at 2022-06-21 10:37:16.855486
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    assert timers.max("foo") == 0
    timers.add("foo", 1)
    timers.add("foo", 2)
    assert timers.max("foo") == 2


# Generated at 2022-06-21 10:38:26.184479
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Tests the clear method"""
    timers = Timers()
    timers.add("Test",10)
    timers.clear()
    assert 'Test' not in timers.data
    assert 'Test' not in timers._timings


# Generated at 2022-06-21 10:38:28.853676
# Unit test for method count of class Timers
def test_Timers_count():
    """Test method count for class Timers"""
    timers = Timers()
    for i in range(5):
        timers.add("test_name", 1.0)
    assert timers.count("test_name") == 5


# Generated at 2022-06-21 10:38:33.163604
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    t.add('time', 3)
    t.add('time', 7)
    assert t.median('time') == 5
    t.add('time', 2)
    assert t.median('time') == 3

# Generated at 2022-06-21 10:38:36.078441
# Unit test for method max of class Timers
def test_Timers_max():
    """Unit test for max method of class Timers"""
    timers = Timers()
    timers.add('a', 0)
    timers.add('a', 1)
    timers.add('b', 2)
    return timers.max('a') == 1 and timers.max('b') == 2

# Generated at 2022-06-21 10:38:39.765198
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Ensure that the instance variable _timings is correctly reset"""
    # Create an instance of Timers for which the
    # instance variable _timings is not empty
    timers = Timers()
    timers._timings["name"] = [1]
    # Call the method clear of class Timers
    timers.clear()
    # Assert that the instance variable _timings
    # has been correctly reset
    assert timers._timings == {}


# Generated at 2022-06-21 10:38:44.172079
# Unit test for method stdev of class Timers
def test_Timers_stdev():                             # pragma: no cover
    from pytest import approx
    from numpy import std, nan

    timers = Timers()

    assert timers.stdev('no_timer') == nan
    assert timers.stdev('no_timer') == nan
    assert timers.stdev('deviation') == approx(std([1, 2, 3]))

# Generated at 2022-06-21 10:38:51.548166
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    # Create a timers dictionary
    timers = Timers()
    # Add two timers to the dictionary
    timers.add(name="foo", value=1)
    timers.add(name="foo", value=3)
    timers.add(name="bar", value=2)
    timers.add(name="bar", value=4)
    # Add a third timer with no values
    timers.add(name="baz", value=0)
    # Check the total
    assert timers.apply(sum, name="foo") == 4
    assert timers.apply(sum, name="bar") == 6
    assert timers.apply(sum, name="baz") == 0
    # Check the minimum
    assert timers.apply(min, name="foo") == 1

# Generated at 2022-06-21 10:38:55.029501
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("mean", 1)
    timers.add("mean", 3)
    timers.add("mean", 7)
    timers.add("mean", 13)
    assert timers.mean("mean") == 6
    assert timers.mean("non_existant") == 0


# Generated at 2022-06-21 10:38:57.129839
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add("test", 1.123)
    assert timers["test"] == 1.123
    assert timers._timings["test"] == [1.123]


# Generated at 2022-06-21 10:39:00.328884
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    assert t.median("foo") == 0
    t.add("foo", 1)
    assert t.median("foo") == 1
    t.add("foo", 1)
    assert t.median("foo") == 1
    t.add("foo", 2)
    assert t.median("foo") == 1.5

