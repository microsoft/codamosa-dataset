

# Generated at 2022-06-21 10:31:31.377507
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    assert timers.data['test'] == 1
    try:
        timers['test'] = 2
    except TypeError:
        pass
    else:
        raise RuntimeError('Expected TypeError')


# Generated at 2022-06-21 10:31:35.609502
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add(name="test_timers", value=3.0)
    timers.add(name="test_timers", value=6.0)

    assert timers.stdev(name="test_timers") == 3.0

# Generated at 2022-06-21 10:31:41.354267
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.to_test_flag = False
    t.add('foo', 5)
    t.add('foo', 3)
    t.add('foo', 6)
    t.add('foo', 2)
    expected = 2
    actual = t.min('foo')
    assert actual == expected
    t.to_test_flag = True


# Generated at 2022-06-21 10:31:45.681783
# Unit test for method add of class Timers
def test_Timers_add():
    """Test that items added by add are also added to the data"""
    timers = Timers()
    timer_name = "test"
    timer_value = 1
    timers.add(timer_name, timer_value)
    assert timers.data[timer_name] == timer_value
    assert timers[timer_name] == timer_value

# Generated at 2022-06-21 10:31:47.783171
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert len(timers) == 0
    assert len(timers.data) == 0
    assert len(timers._timings) == 0


# Generated at 2022-06-21 10:31:54.042658
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    # OBJECT UNDER TEST
    timers: Timers = Timers()  # noqa: WPS110

    # Define test cases

# Generated at 2022-06-21 10:31:58.420973
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add('test', 3)
    timers.add('test', 3)
    assert (timers.stdev('test') - 0.00)**2 < .0001
    timers.add('test', 4)
    assert (timers.stdev('test') - 0.81)**2 < .0001

# Generated at 2022-06-21 10:32:01.904848
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 5)
    timers.add("test", 8)
    timers.add("test", 10)
    timers.add("test", 1)
    timers.add("test", 8)
    assert timers.max("test") == 10

# Generated at 2022-06-21 10:32:04.345330
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    timers = Timers()
    with pytest.raises(TypeError):
        timers["test"] = 1


# Generated at 2022-06-21 10:32:06.899952
# Unit test for constructor of class Timers
def test_Timers():
    """Test constructor of class Timers """
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}



# Generated at 2022-06-21 10:32:14.778472
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    assert timers.data == {}

    timers.add('t1', 0.1)
    assert timers.data == {'t1': 0.1}, 'Was added: {t1: 0.1}'

    timers.add('t1', 0.1)
    timers.add('t1', 0.2)
    timers.add('t2', 0.2)
    assert timers.data == {'t1': 0.4, 't2': 0.2}, 'Was added: {t1: 0.4, t2: 0.2}'


# Generated at 2022-06-21 10:32:22.144320
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method 'add' of class Timers"""

    # Create Timers object
    timers = Timers()

    # Add a timing value to a timer
    timers.add('foo', 1)
    timers.add('bar', 2)
    timers.add('foo', 3)

    # Check that total time of timer 'foo' is equal to 4
    assert timers.data['foo'] == 4
    assert timers.total('foo') == 4

    # Check that total time of timer 'bar' is equal to 2
    assert timers.data['bar'] == 2
    assert timers.total('bar') == 2



# Generated at 2022-06-21 10:32:31.145091
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test method apply of class Timers"""
    test = Timers()
    assert test.apply(lambda values: min(values), name="a") == 0
    test.add("a", 1)
    test.add("a", 2)
    assert test.apply(lambda values: min(values), name="a") == 1
    assert test.apply(lambda values: max(values), name="a") == 2
    assert test.apply(lambda values: sum(values), name="a") == 3
    assert test.apply(lambda values: mean(values), name="a") == 1.5
    assert test.apply(lambda values: median(values), name="a") == 1.5
    assert test.apply(lambda values: stdev(values), name="a") == 0.7071067811865476

# Generated at 2022-06-21 10:32:38.107500
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()

    # Add some timing values
    timers.add(name="key", value=1.0)
    timers.add(name="key", value=2.0)
    timers.add(name="key", value=3.0)

    # Calculate standard deviation
    stdev = timers.stdev(name="key")

    # Expect the value to be 0.816496580927726
    assert abs(stdev - 0.816496580927726) < 1e-14



# Generated at 2022-06-21 10:32:45.589284
# Unit test for method apply of class Timers
def test_Timers_apply():

    # Inputs
    func = len
    name = 'timer1'
    values = [1.1, 2.2, 3.3, 4.4, 5.5]

    # Object to be tested
    timers = Timers()
    for value in values:
        timers.add(name, value)

    # Tested function
    output = timers.apply(func, name)

    # Expected output
    expected = len(values)

    # Test assessment
    assert output == expected

# Generated at 2022-06-21 10:32:54.750866
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""

    timers = Timers()

    # Check that adding information about timers does not raise an exception
    for _ in range(100):
        for n in range(10):
            timers.add("timer", n)

    # Check that the timer data is correct
    assert timers["timer"] == sum(range(10))

    # Check that a in-place modification of the timer data does not work
    try:
        timers["timer"] = 0
    except TypeError:
        pass
    else:
        assert False, "In-place modification of timer data should not be allowed"

    # Check that the number of count timings is correct
    assert timers.count("timer") == 100

    # Check that the total of timings is correct
    assert timers.total("timer") == 100 * sum(range(10))



# Generated at 2022-06-21 10:32:57.982268
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method add of class Timers"""
    timers = Timers()
    timers.add('total', 1)
    timers.add('total', 2)
    timers.add('total', 3)
    assert timers.total('total') == 6


# Generated at 2022-06-21 10:33:00.470661
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test method __setitem__ of class Timers"""
    timers = Timers()
    with pytest.raises(TypeError):
        timers["key"] = 0.0

# Generated at 2022-06-21 10:33:02.443804
# Unit test for method max of class Timers
def test_Timers_max():
    """An example for the method max of class Timers"""
    timers = Timers()
    timers.add("a", 5)
    timers.add("a", 3)
    assert timers.max("a") == 5



# Generated at 2022-06-21 10:33:04.747662
# Unit test for method add of class Timers
def test_Timers_add():
    t = Timers()
    t.add("name", 1)
    assert t.data == {"name": 1}
    t.add("name", 2)
    assert t.data == {"name": 3}



# Generated at 2022-06-21 10:33:11.431126
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add("a", 1)
    timers.add("b", 2)
    timers.clear()
    assert len(timers) == 0
    assert len(timers._timings["a"]) == 0


# Generated at 2022-06-21 10:33:18.477244
# Unit test for method median of class Timers
def test_Timers_median():
    result_odd=Timers()
    result_odd.add("timer", 8)
    result_odd.add("timer", 6)
    result_odd.add("timer", 7)
    result_odd.add("timer", 5)
    result_odd.add("timer", 3)
    result_odd.add("timer", 0)
    result_odd.add("timer", 9)
    expected_odd=7
    assert result_odd.median("timer")==expected_odd,"Median of odd list of numbers not returned correctly"
    result_even=Timers()
    result_even.add("timer", 8)
    result_even.add("timer", 6)
    result_even.add("timer", 7)
    result_even.add("timer", 5)
    result_even.add("timer", 3)
    result

# Generated at 2022-06-21 10:33:23.927232
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('a', 1.0)
    timers.add('a', 2.0)
    assert timers.median('a') == 1.5
    with pytest.raises(KeyError) as e_info:
        timers.median('b')


# Generated at 2022-06-21 10:33:31.448119
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test for method apply of class Timers"""
    timers = Timers()
    timers.add("foo", 12)
    timers.add("foo", 40)
    timers.add("foo", 60)
    timers.add("bar", 4)
    timers.add("bar", 8)
    timers.add("baz", 10)
    timers.add("baz", 15)
    assert timers.apply(len, name="foo") == 3
    assert timers.apply(sum, name="foo") == 112
    assert timers.apply(lambda values: max(values or [0]), name="foo") == 60
    assert timers.apply(lambda values: min(values or [0]), name="foo") == 12
    assert timers.apply(lambda values: statistics.mean(values or [0]), name="foo") == 37.333333333333336

# Generated at 2022-06-21 10:33:34.365020
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    from pytest import raises
    timer=Timers()
    with raises(TypeError):
        timer["test"]=0

# Generated at 2022-06-21 10:33:37.859990
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count("test") == 0
    timers.add("test", 0.42)
    assert timers.count("test") == 1


# Generated at 2022-06-21 10:33:41.579039
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    # Initialize
    timers = Timers()

    # Test initialization
    assert timers.data == {}
    assert timers._timings == {}



# Generated at 2022-06-21 10:33:43.532163
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    t = Timers()
    with pytest.raises(TypeError):
        t["foo"] = 8

# Generated at 2022-06-21 10:33:51.718984
# Unit test for method median of class Timers
def test_Timers_median():
    """
    This function tests the median method for class Timers:
        - the empty list of timing values is handled
        - the odd length list of timing values is handled
        - the even length list of timing values is handled
    """

    # Define test data
    data = [
        ([], 0.0),
        ([4.45, 0.0, 5.0, 8.16], 4.45),
        ([4.45, 2.0, 2.0, 2.0], 2.0),
    ]

    # Evaluate all data sets
    for inputdata, expected in data:
        result = Timers().median(inputdata)
        assert result == expected, f"Unexpected result: {result} != {expected}"



# Generated at 2022-06-21 10:33:57.857934
# Unit test for method total of class Timers
def test_Timers_total():
    """Test Timers.total method."""
    timers = Timers()
    timers.add('test', 1.0)
    timers.add('test', 2.0)
    assert isinstance(timers.total('test'), float)
    assert timers.total('test') == 3.0


# Generated at 2022-06-21 10:34:08.829145
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    T = Timers()
    assert math.isnan(T.stdev("test"))
    T["test"] = 5
    assert math.isnan(T.stdev("test"))
    T.add("test", 5)
    assert math.isnan(T.stdev("test"))
    T.add("test", 3)
    assert T.stdev("test") == 1.63299
    T.clear()
    assert math.isnan(T.stdev("test"))

# Generated at 2022-06-21 10:34:15.604612
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add('timer', 1.0)
    assert timers.total('timer') == 1.0
    assert timers.total('timer2') == 0.0
    timers.add('timer2', 2.0)
    assert timers.total('timer2') == 2.0
    timers.clear()
    assert timers.total('timer') == 0.0

if __name__ == '__main__':  # pragma: no cover
    test_Timers_total()

# Generated at 2022-06-21 10:34:25.761327
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Method stdev of class Timers"""
    timers = Timers()

    # Standard deviation of empty list is NaN
    assert math.isnan(timers.stdev(""))

    # Standard deviation of a list of one element is NaN
    timers.add("", 1.0)
    assert math.isnan(timers.stdev(""))

    # Standard deviation is zero
    timers.add("", 1.0)
    assert timers.stdev("") == 0.0

    # Standard deviation is nonzero
    timers.add("", 3.0)
    assert timers.stdev("") == math.sqrt(5.0)

# Generated at 2022-06-21 10:34:29.366758
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers._timings = {'timer_name': [1, 2, 3]}
    assert timers.stdev('timer_name') == 1.0
    timers._timings = {'timer_name': [1]}
    assert math.isnan(timers.stdev('timer_name'))

# Generated at 2022-06-21 10:34:33.701617
# Unit test for method total of class Timers
def test_Timers_total():
    """Test the total method of the Timers class"""
    timers = Timers()
    timers.add(name = "test", value = 10)
    assert(timers.total(name = "test") == 10)


# Generated at 2022-06-21 10:34:41.310322
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    timers = Timers()
    timers.add("A", 1.0)
    timers.add("A", 2.0)
    timers.add("A", 3.0)
    timers.add("A", 4.0)
    assert timers.stdev("A") == statistics.stdev([1.0, 2.0, 3.0, 4.0])
    assert math.isnan(timers.stdev("B"))


if __name__ == "__main__":
    # Run unit tests
    test_Timers_stdev()

# Generated at 2022-06-21 10:34:47.383903
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers(dict())

    with pytest.raises(KeyError):
        t.max("test")

    t.add("test", 0.0)
    t.add("test", 1.0)

    assert t.max("test") == 1.0
    assert t.max("test2") == 0.0

# Generated at 2022-06-21 10:34:50.852877
# Unit test for method mean of class Timers
def test_Timers_mean():
    timer = Timers()
    timer.add("test", 1.0)
    timer.add("test", 1.0)

    assert timer.mean("test") == 1.0
    assert timer.mean("test1") is None

# Generated at 2022-06-21 10:34:53.768650
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for stdev method of class Timers"""
    timers = Timers()
    timers.add('name', 1)
    timers.add('name', 2)

    assert timers.stdev('name') == math.sqrt(2. / 3)

# Generated at 2022-06-21 10:34:57.756151
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    timers = Timers()
    # TYPE_CHECKING = False but typing.TYPE_CHECKING = True
    # noinspection PyUnresolvedReferences
    assert isinstance(timers, UserDict)
    assert isinstance(timers._timings, collections.defaultdict)

# Generated at 2022-06-21 10:35:02.052499
# Unit test for method min of class Timers
def test_Timers_min():
    timer = Timers()
    assert timer.min('test') == 0


# Generated at 2022-06-21 10:35:06.914264
# Unit test for constructor of class Timers
def test_Timers():
    """Test Timers() constructor"""
    test_input = [
        'a',
        'b',
        'c',
        'd'
    ]

    timers = Timers(test_input)

    for value in test_input:
        assert value in timers


# Generated at 2022-06-21 10:35:11.983038
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method Timers.add()"""
    t = Timers()
    t.add('test', 1)
    assert t['test'] == 1
    t.add('test', 2)
    assert t['test'] == 3
    t.add('test', 2)
    assert t['test'] == 5


# Generated at 2022-06-21 10:35:17.071082
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add(name='test_max', value=1)
    timers.add(name='test_max', value=2)
    timers.add(name='test_max', value=3)
    timers.add(name='test_max', value=4)
    assert timers.max(name='test_max') == 4


# Generated at 2022-06-21 10:35:21.646832
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    timers = Timers()
    timers.add('test', 2.5)
    timers.add('test', 3.5)
    assert math.isnan(timers.stdev('test'))

    timers.add('test', 4.5)
    assert timers.stdev('test') == 1.0

# Generated at 2022-06-21 10:35:28.207070
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """
    Test method Timers.stdev
    """
    timer_stdev = Timers()
    timer_stdev.add('test', 1)
    timer_stdev.add('test', 2)
    assert timer_stdev.stdev('test') == 0.7071067811865476
    timer_stdev.add('test', 3)
    assert timer_stdev.stdev('test') == 1

# Generated at 2022-06-21 10:35:31.540650
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("count", 23)
    timers.add("count", 42)
    timers.add("count", 42)
    assert timers.median("count") == 42

# Generated at 2022-06-21 10:35:41.555005
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test method apply of class Timers."""
    # Create a dictionary with two keys
    timers = Timers()
    timers.add("key1", value=1)
    timers.add("key1", value=2)
    timers.add("key2", value=3)
    # Apply len to key1 gives 2
    assert timers.apply(len, name="key1") == 2
    # Apply len to key2 gives 1
    assert timers.apply(len, name="key2") == 1
    # Apply sum to key1 gives value 3
    assert timers.apply(sum, name="key1") == 3
    # Apply sum to key2 gives value 3
    assert timers.apply(sum, name="key2") == 3
    # Apply min to key1 gives value 1
    assert timers.apply(min, name="key1") == 1

# Generated at 2022-06-21 10:35:45.327106
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()
    t.add("test", 1)
    t.add("test", 2)
    t.add("test", 3)
    assert t.total("test") == 6

if __name__ == '__main__':
    test_Timers_total()

# Generated at 2022-06-21 10:35:47.585012
# Unit test for method median of class Timers
def test_Timers_median():
    pass
    # check for median of even number of values
    # check for median of odd number of values
    # check for median of single value

# Generated at 2022-06-21 10:36:02.551231
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Unit test for method clear of class Timers"""
    from vnpy.trader.constant import Direction
    from vnpy.trader.object import BarData
    from vnpy.trader.engine import BaseDataEngine
    from vnpy.trader.gateway import BaseGateway
    from vnpy.trader.utility import append_data

    # (1) Prepare data
    bars = [BarData(symbol="", exchange=None, datetime=None, direction=Direction(""), open_price=10.0,
                    high_price=10.0, low_price=10.0, close_price=10.0, volume=1, gateway_name="")]
    # Override method append_data

# Generated at 2022-06-21 10:36:06.608407
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers["foo"] = 0.42
    except TypeError as e:
        assert "does not support item assignment" in str(e)
    else:
        raise AssertionError("Expected TypeError")


# Generated at 2022-06-21 10:36:14.517529
# Unit test for constructor of class Timers
def test_Timers():
    import time
    timer = Timers()
    time.sleep(0.1)
    timer.add('sleep.1', time.time() - timer.starttime)
    assert isinstance(timer, Timers)
    time.sleep(0.1)
    timer.add('sleep.2', time.time() - timer.starttime - timer['sleep.1'])
    print(timer['sleep.2'])
    print(timer.total('sleep.1'))
    print(timer.mean('sleep.1'))
    print(timer.mean('sleep.2'))
    print(timer.median('sleep.2'))
    print(timer.max('sleep.2'))
    print(timer.min('sleep.1'))
    print(timer.stdev('sleep.1'))

# Generated at 2022-06-21 10:36:18.138680
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test for method '__setitem__' of class 'Timers'"""
    with pytest.raises(TypeError) as error:
        timers = Timers()
        timers["foo"] = 0
    assert "does not support item assignment" in str(error.value)



# Generated at 2022-06-21 10:36:23.724805
# Unit test for method clear of class Timers
def test_Timers_clear():
    T = Timers()

    t1 = 1
    t2 = 2
    T.add("A", t1)
    T.add("B", t2)

    assert T["A"] == t1
    assert T["B"] == t2
    assert "A" in T
    assert "B" in T
    assert "C" not in T

    T.clear()
    assert "A" not in T
    assert "B" not in T
    assert "C" not in T


# Generated at 2022-06-21 10:36:27.542004
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add("A", 1)
    timers.add("B", 2)
    timers.add("B", 4)
    assert timers.stdev("A") == 0
    assert timers.stdev("B") == math.sqrt(2)

# Generated at 2022-06-21 10:36:37.470566
# Unit test for method max of class Timers
def test_Timers_max():
    "Unit test for method max of class Timers"

    # Create a Timers object
    timers = Timers()

    # Add three elements
    timers.add("t1", 1.0)
    timers.add("t1", 2.0)
    timers.add("t1", 3.0)

    # Test that len is equal to 3
    assert len(timers) == 3

    # Check for negative values
    assert timers.max("t1") >= 3.0

    # Check it works for empty
    timers.clear()
    assert timers.max("t1") == 0.0


# Generated at 2022-06-21 10:36:39.862922
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers({"a":3})
    assert timers.data["a"] == 3
    assert timers.total('a') == 3


# Generated at 2022-06-21 10:36:46.087703
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add("a", 4)
    timers.add("a", 4)
    timers.add("a", 4)
    timers.add("a", 4)
    timers.add("a", 2)
    timers.add("a", 2)
    assert timers.stdev("a") == math.sqrt(2)
    assert timers.stdev("b") is math.nan

# Generated at 2022-06-21 10:36:48.606039
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t._timings["test"] = [1,2,3,4]
    assert t.mean("test") == 2.5


# Generated at 2022-06-21 10:37:01.211406
# Unit test for method apply of class Timers
def test_Timers_apply():
    # Test with an empty list
    timers = Timers()
    assert timers.apply(len, name='1') == 0
    assert timers.apply(lambda x: sum(x) / len(x), name='2') == 0.0

    # Test with a single item
    timers.add('1', 1.0)
    timers.add('2', 2.0)
    assert timers.apply(len, name='1') == 1.0
    assert timers.apply(lambda x: sum(x) / len(x), name='2') == 2.0

    # Test with multiple items
    timers.add('1', 1.0)
    timers.add('2', 2.0)
    assert timers.apply(len, name='1') == 2.0

# Generated at 2022-06-21 10:37:05.944455
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    t.add("test", 1)
    t.add("test", 2)
    t.add("test", 4)
    t.add("test", 10)
    median = t.apply(lambda values: statistics.median(values or [0]), "test")
    assert median == 3.0

# Generated at 2022-06-21 10:37:12.927501
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for method stdev() of class Timers"""
    timers = Timers()

    # stdev should return nan when no data is present
    assert math.isnan(timers.stdev("foo"))

    # stdev should not raise when no data is present
    timers.stdev("foo")

    # stdev should return nan when there is only one data point
    timers.add("foo", 1)
    assert math.isnan(timers.stdev("foo"))

    # stdev should return the difference between the two data points
    timers.add("foo", 2)
    assert timers.stdev("foo") == 1


# Generated at 2022-06-21 10:37:19.488049
# Unit test for method min of class Timers
def test_Timers_min():
    # Create an empty timers object.
    t = Timers()
    # Add some values to it.
    t.add('t1', 2.1)
    t.add('t1', 1.3)
    t.add('t2', 1.2)
    t.add('t2', 1.22)
    # Verify the correct minimum.
    assert t.min('t1') == 1.3
    assert t.min('t2') == 1.2

# Generated at 2022-06-21 10:37:27.944012
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Geometric mean
    # The geometric mean is defined as the n-th root of the product of n numbers
    timers = Timers()
    timers.add('time', 42)
    assert timers.mean('time') == 42
    timers.add('time', 63)
    assert round(timers.mean('time'), 5) == 52.5
    timer = Timers()
    timer.add('time', -0.4)
    assert round(timer.mean('time'), 4) == -0.4
    timer.add('time', -0.8)
    assert round(timer.mean('time'), 4) == -0.6
    timer.add('time', -0.9)
    assert round(timer.mean('time'), 4) == -0.73

# Generated at 2022-06-21 10:37:31.270630
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers({'foo': 1})
    timers.add('foo', 2)
    assert timers.data == {'foo': 3}
    assert timers._timings == {'foo': [1, 2]}
    timers.clear()
    assert timers.data == {}
    assert timers._timings == {}

# Generated at 2022-06-21 10:37:39.570421
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    def dummy_method(timings: List[float]) -> float:
        """Dummy method"""
        return sum(timings)

    timer = Timers({'test': 0.0})
    timer.add('test', 1.0)
    timer.add('test', 2.0)
    assert timer.apply(dummy_method, 'test') == 3.0
    try:
        timer.apply(dummy_method, 'other')
        assert False
    except KeyError:
        pass


# Generated at 2022-06-21 10:37:43.455804
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add('t1', 2)
    timers.add('t2', 1)
    timers.add('t2', 3)
    assert timers.total('t1') == 2
    assert timers.total('t2') == 4
    assert timers.total('t3') == 0
    assert timers.total('t3', default=5) == 5

# Generated at 2022-06-21 10:37:46.325528
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Init Timers
    timers = Timers({"x": 1.0, "a": 2.0})
    assert timers.mean("x") == 1.0, "Test failed!"
    assert timers.mean("a") == 2.0, "Test failed!"
    assert timers.mean("b") == 3.0, "Test failed!"



# Generated at 2022-06-21 10:37:48.577605
# Unit test for method total of class Timers
def test_Timers_total():
    """Test of method total of class Timers"""
    timers = Timers()
    timers.add('Test', 2)
    assert timers['Test'] == 2
    assert timers.total('Test') == 2


# Generated at 2022-06-21 10:37:55.252553
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    t = Timers({"key": 0})
    assert math.isnan(t.stdev('key'))



# Generated at 2022-06-21 10:37:57.397548
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert isinstance(timers, collections.UserDict)
    
test_Timers()  # Call the function

# Generated at 2022-06-21 10:38:08.459810
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test clear method"""
    timers = Timers()
    timers.add("foo", 1)
    timers.add("bar", 2)
    timers.add("foo", 3)
    assert timers.data == {"foo": 4, "bar": 2}
    assert len(timers._timings) == 2
    assert len(timers._timings["foo"]) == 2
    assert timers._timings["foo"] == [1, 3]
    assert len(timers._timings["bar"]) == 1
    assert timers._timings["bar"] == [2]

    timers.clear()
    assert len(timers.data) == 0
    assert len(timers._timings) == 0



# Generated at 2022-06-21 10:38:14.202155
# Unit test for method max of class Timers
def test_Timers_max():
    """Return the max among the list of stored values"""
    t = Timers()
    t.add('key', 3)
    assert t.max('key') == 3
    t.add('key', 5)
    assert t.max('key') == 5
    t.add('key', 2)
    assert t.max('key') == 5
    # t.max('a') will throw an exception

# Generated at 2022-06-21 10:38:17.531590
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add('foo', 1)
    timers.add('foo', 1)
    timers.add('bar', 2)
    timers.add('bar', 2)
    assert len(timers) == 2
    timers.clear()
    assert len(timers) == 0


# Generated at 2022-06-21 10:38:21.296580
# Unit test for method apply of class Timers
def test_Timers_apply():
    a = Timers()
    a._timings = {'test': [1, 2, 3, 4, 5]}
    assert a.apply(len, 'test') == 5

# Generated at 2022-06-21 10:38:23.334710
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("wait", 1.0)
    timers.add("wait", 2.0)
    assert timers.count("wait") == 2
    timers.add("tasks", 2.0)
    assert timers.count("tasks") == 1


# Generated at 2022-06-21 10:38:27.857244
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add("example", 2.34)
    assert timers['example'] == 2.34
    assert timers._timings['example'] == [2.34]
    timers.add("example", 12.34)
    assert timers['example'] == 14.68
    assert timers._timings['example'] == [2.34, 12.34]



# Generated at 2022-06-21 10:38:31.927998
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test for method stdev of class Timers"""
    timers = Timers()
    timers.add('one', 1.0)
    timers.add('one', 1.0)
    timers.add('one', 1.0)
    assert round(timers.stdev('one'), 15) == 0.0
    timers.add('one', 10.0)
    assert round(timers.stdev('one'), 15) == 4.0824829046386328


# Generated at 2022-06-21 10:38:36.044230
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()

    t.add("foobar", 1.1)
    assert t.total("foobar") == 1.1
    assert not t.total("missing")

    t.add("foobar", 2.1)
    assert t.total("foobar") == 3.2

    t.add("baz", 10.0)
    assert t.total("baz") == 10.0

# Generated at 2022-06-21 10:38:50.842034
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("T1", 0)
    t.add("T1", 1)
    t.add("T1", 2)
    assert t.min("T1") == 0


# Generated at 2022-06-21 10:38:55.779556
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    timers = Timers()
    timers.add('my_timer', 0.1)
    timers.add('my_timer', 0.05)
    timers.add('other', 0.3)
    assert timers.apply(sum, name='my_timer') == 0.15
    assert timers.apply(sum, name='other') == 0.3
    assert timers.apply(sum, name='something_else') == 0


# Generated at 2022-06-21 10:38:57.996365
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Check expected behavior of method __setitem__ of class Timers"""
    # Setup
    timers = Timers()

    # Test
    with pytest.raises(TypeError):
        timers['name'] = 1



# Generated at 2022-06-21 10:38:59.451633
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add('foo', 1)
    assert t.min('foo') == 1


# Generated at 2022-06-21 10:39:03.300914
# Unit test for method add of class Timers
def test_Timers_add():
    t = Timers()
    t.add('Trial 0', 0.000)
    t.add('Trial 1', 0.111)
    t.add('Trial 2', 0.222)
    t.add('Trial 3', 0.333)
    assert t['Trial 0'] == 0.000
    assert t['Trial 1'] == 0.111
    assert t['Trial 2'] == 0.222
    assert t['Trial 3'] == 0.333


# Generated at 2022-06-21 10:39:03.916910
# Unit test for method clear of class Timers
def test_Timers_clear():
    pass


# Generated at 2022-06-21 10:39:05.556956
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert isinstance(timers, collections.UserDict)
    assert isinstance(timers, collections.MutableMapping)
    assert isinstance(timers, Timers)



# Generated at 2022-06-21 10:39:08.012142
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-21 10:39:12.163784
# Unit test for method max of class Timers
def test_Timers_max():
    name = 'example'
    data = [10,20]
    timer = Timers()
    timer._timings[name] = data
    result = timer.max(name)
    assert (result == 20)
    assert(timer.data[name] == 30)


# Generated at 2022-06-21 10:39:17.809750
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.add(name="name", value=1)
    assert t.max(name="name") == 1
    t.add(name="name", value=2)
    assert t.max(name="name") == 2
    t.add(name="name", value=3)
    assert t.max(name="name") == 3


# Generated at 2022-06-21 10:39:31.906360
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    timers = Timers()
    assert isinstance(timers, collections.UserDict)
    assert not timers
    assert timers._timings == collections.defaultdict(list)


# Generated at 2022-06-21 10:39:38.071367
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test function for Timers.clear()"""
    timers = Timers()
    timers.add("a", 0.1)
    timers.add("a", 0.2)
    timers.add("b", 0.3)
    assert timers._timings
    assert timers.data
    timers.clear()
    assert not timers._timings
    assert not timers.data


# Generated at 2022-06-21 10:39:42.495203
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.clear()
    assert t.max("max") == 0.0
    t.add("max", 3.0)
    assert t.max("max") == 3.0


# Generated at 2022-06-21 10:39:47.872636
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers._timings = {'a':[1,2,3,4], 'b':[2,3,4,5]}
    timers.data = {'a':10, 'b':20}
    assert timers.stdev('a') == 1
    assert timers.stdev('b') == 1

# Generated at 2022-06-21 10:39:58.074025
# Unit test for method median of class Timers
def test_Timers_median():
    # create test object
    # Run unit tests
    # Test 1: Ensure Timers are created correctly
    timers = Timers()
    assert len(timers)==0
    # Test 2: Test adding an item to the timers
    timers.add("test_key", 1)
    assert len(timers)==1
    # Test 3: Test that the value of 'test_key' is 1
    assert timers.data["test_key"]==1
    # Test 4: Check that the median function returns 1
    assert timers.median("test_key")==1
    # Test 5: Check that the mean function returns 1
    assert timers.mean("test_key")==1
    # Test 6: Check that the stdev function returns 0
    assert timers.stdev("test_key")==0
    # Test 7: Test that the min function returns

# Generated at 2022-06-21 10:40:02.934514
# Unit test for method add of class Timers
def test_Timers_add():
    _ = Timers()
    timers = Timers()

    # Insert some timings
    timers.add("A", 1)
    timers.add("A", 2)
    timers.add("B", 3)
    assert timers.data["A"] == 3
    assert timers.data["B"] == 3

    # Retrieve the timings
    assert timers._timings["A"] == [1, 2]
    assert timers._timings["B"] == [3]


# Generated at 2022-06-21 10:40:05.932134
# Unit test for method clear of class Timers
def test_Timers_clear():

    a = Timers()
    try:
        a['test'] = 1
    except TypeError:
        pass

    a.add('test', 1)
    a.clear()
    assert(a['test'] == 0)

# Generated at 2022-06-21 10:40:08.068190
# Unit test for constructor of class Timers
def test_Timers():
    door = Timers()
    assert isinstance(door, collections.UserDict)

# Generated at 2022-06-21 10:40:17.450829
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test the apply method of the Timers class"""
    timers = Timers()
    timers.add("test_1", 0.0)
    timers.add("test_1", 1.0)
    timers.add("test_1", 2.0)
    timers.add("test_1", 3.0)
    timers.add("test_1", 4.0)
    timers.add("test_2", 5.0)
    timers.add("test_2", 6.0)
    assert timers.apply(sum, name="test_1") == 10.0
    assert timers.apply(sum, name="test_2") == 11.0
    assert timers.apply(max, name="test_1") == 4.0
    assert timers.apply(max, name="test_2") == 6.0
    assert timers.data

# Generated at 2022-06-21 10:40:20.763953
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean of Timers class"""
    t = Timers()
    t.add('name', 5)
    t.add('name', 2)
    t.add('name', 3)
    assert t.mean('name') == 3.0

# Generated at 2022-06-21 10:40:45.461250
# Unit test for method add of class Timers
def test_Timers_add():
    tim = Timers()
    tim.add("test", 1)
    tim.add("test", 2)
    assert len(tim._timings["test"]) == 2
    assert tim._timings["test"] == [1, 2]
    assert tim.data["test"] == 3


# Generated at 2022-06-21 10:40:54.434315
# Unit test for method add of class Timers
def test_Timers_add():
    t = Timers()
    t.add('a', 1)
    t.add('b', 2)
    t.add('a', 3)
    t.add('b', 4)
    t.add('c', 5)
    t.add('c', 6)
    assert t.data == {'a': 4, 'b': 6, 'c': 11}
    t.add('a', 7)
    assert t.data == {'a': 11, 'b': 6, 'c': 11}
    assert t._timings == {'a': [1, 3, 7], 'b': [2, 4], 'c': [5, 6]}


# Generated at 2022-06-21 10:40:59.838738
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median function of Timers"""
    timers = Timers()
    timers.add("T1", 5) # pylint: disable=no-member
    timers.add("T1", 7) # pylint: disable=no-member
    assert timers.median("T1") == 6 # pylint: disable=no-member
    timers.add("T1", 4) # pylint: disable=no-member
    assert timers.median("T1") == 5 # pylint: disable=no-member
    timers.add("T1", 9) # pylint: disable=no-member
    assert timers.median("T1") == 6 # pylint: disable=no-member
    timers.add("T2", 3) # pylint: disable=no-member

# Generated at 2022-06-21 10:41:02.871860
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("foo", 1)
    timers.add("foo", 2)
    assert timers.count("foo") == 2


# Generated at 2022-06-21 10:41:05.375031
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add('a', 5)
    assert t.mean("a") == 5



# Generated at 2022-06-21 10:41:10.193395
# Unit test for method median of class Timers
def test_Timers_median():
    """Check median funciton of Timers"""

    # Setup
    timers = Timers()
    timers.add("step", 1)
    timers.add("step", 2)
    timers.add("step", 3)

    # Check
    assert timers.median("step") == 2.0

# Generated at 2022-06-21 10:41:12.697803
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('test', 1)
    assert timers.count('test') == 1


# Generated at 2022-06-21 10:41:15.699374
# Unit test for method max of class Timers
def test_Timers_max():
    assert 0 == Timers().max("")
    assert 1 == Timers().apply(lambda values: max(values or [1]), "")
    assert 0 == Timers().apply(lambda values: max(values or [0]), "")

# Generated at 2022-06-21 10:41:19.318653
# Unit test for method count of class Timers
def test_Timers_count():
    t = Timers()
    assert t.count('a') == 0
    assert t.count('b') == 0
    t.add('a', 1)
    t.add('a', 2)
    t.add('b', 3)
    assert t.count('a') == 2
    assert t.count('b') == 1


# Generated at 2022-06-21 10:41:30.665460
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""

    # Test method __init__
    timers = Timers()

    # Test method apply
    try:
        timers.apply(len, name=None)
    except KeyError:
        pass
    else:
        raise AssertionError("Timers.apply(len, name=None) did not raise KeyError")
    try:
        timers.apply(len, name="")
    except KeyError:
        pass
    else:
        raise AssertionError("Timers.apply(len, name='') did not raise KeyError")

    # Test method add
    timers.add("count", 1)
    assert len(timers) == 1
    timers.add("count", 1)
    assert len(timers) == 1

    # Test method count