

# Generated at 2022-06-21 10:31:27.454278
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    timers["a"] = .123


# Generated at 2022-06-21 10:31:31.599049
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Unit test for method clear of class Timers"""
    timers = Timers()
    timers.add("timer1", value=10)
    timers.add("timer2", value=20)
    timers.add("timer3", value=30)
    timers.clear()
    assert len(timers) == 0
    assert len(timers._timings) == 0


# Generated at 2022-06-21 10:31:37.508806
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add('n', 1)
    assert timers.data['n'] == 1
    timers.add('n', 2)
    assert timers.data['n'] == 3
    
    timers.add('m', 1)
    assert timers.data['m'] == 1
    timers.add('m', 1)
    assert timers.data['m'] == 2
    

# Generated at 2022-06-21 10:31:41.301808
# Unit test for method clear of class Timers
def test_Timers_clear():
    t = Timers()
    t.add("first", 5.0)
    t.add("second", 6.0)
    t.clear()
    assert t.data == {}
    assert t._timings == {}

# Generated at 2022-06-21 10:31:44.255688
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('time', 1)
    timers.add('time', 2)
    assert timers.max('time') == 2
    assert timers.max('time2') == 0


# Generated at 2022-06-21 10:31:49.391862
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test method clear of class Timers"""

    timers = Timers()

    timers.add("foo", 5)
    timers.add("bar", 10)

    assert timers.data["foo"] == 5.
    assert timers.data["bar"] == 10.

    assert timers._timings["foo"] == [5.]
    assert timers._timings["bar"] == [10.]

    timers.clear()

    assert not timers.data
    assert not timers._timings


# Generated at 2022-06-21 10:31:54.897677
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    assert timers.total('Timing_1') == 0.0
    timers.add('Timing_1', 10.1)
    assert timers.total('Timing_1') == 10.1
    timers.add('Timing_1', 20.2)
    assert timers.total('Timing_1') == 30.3
    timers = Timers()
    assert timers.total('Timing_2') == 0.0
    timers.add('Timing_2', 15.1)
    assert timers.total('Timing_2') == 15.1
    timers.add('Timing_2', -5.2)
    assert timers.total('Timing_2') == 9.9
    assert timers.items() == {'Timing_1': 30.3, 'Timing_2': 9.9}

# Generated at 2022-06-21 10:32:01.817130
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    # Test empty
    tmrs = Timers()
    assert tmrs.min('t') == 0
    # Add time
    tmrs.add('t', 2)
    assert tmrs.min('t') == 2
    # Add another time
    tmrs.add('t', 3)
    assert tmrs.min('t') == 2
    # Add another time
    tmrs.add('t', 1)
    assert tmrs.min('t') == 1


# Generated at 2022-06-21 10:32:06.910300
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}
    # Cannot set item
    with pytest.raises(TypeError):
        timers["name"] = 1
    timers.add("name", 1)
    assert timers.data["name"] == 1
    assert timers._timings["name"] == [1]
    # Clearing
    timers.clear()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-21 10:32:09.751237
# Unit test for method clear of class Timers
def test_Timers_clear():
    t = Timers()
    d = t._timings
    t['test'] = 1
    t['test'] += 2
    t['test2'] = 3
    t['test2'] += 4
    t.clear()
    assert t.data == {}
    assert d == {}

# Generated at 2022-06-21 10:32:21.280524
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers.add('timer1', 1)
    timers.add('timer1', 2)
    timers.add('timer1', 3)
    timers.add('timer2', 4)
    assert timers.apply(len, 'timer1') == 3
    assert timers.apply(len, 'timer2') == 1
    assert timers.apply(sum, 'timer1') == 6
    assert timers.apply(sum, 'timer2') == 4
    assert timers.apply(min, 'timer1') == 1
    assert timers.apply(min, 'timer2') == 4
    assert timers.apply(max, 'timer1') == 3
    assert timers.apply(max, 'timer2') == 4


# Generated at 2022-06-21 10:32:30.379548
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    assert timers._timings == {}
    assert timers.data == {}
    timers.add('A', 1)
    assert timers.data == {'A': 1}
    assert timers._timings == {'A': [1]}
    assert timers.count('A') == 1
    assert timers.total('A') == 1
    assert timers.min('A') == 1
    assert timers.max('A') == 1
    assert timers.mean('A') == 1
    assert timers.median('A') == 1
    assert math.isnan(timers.stdev('A'))
    timers.add('A', 2)
    timers.add('A', 3)
    assert timers.data == {'A': 6}
    assert timers._timings == {'A': [1, 2, 3]}
   

# Generated at 2022-06-21 10:32:36.872448
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timer = Timers()
    timer.add(name = 'T0', value = 0.0)
    timer.add(name = 'T0', value = 0.0)
    assert timer.stdev('T0') == 0.0

    timer.add(name = 'T1', value = 0.0)
    assert math.isnan(timer.stdev('T1'))

    timer.add(name = 'T2', value = 1.0)
    assert math.isnan(timer.stdev('T2'))

    timer.add(name = 'T3', value = 1.0)
    timer.add(name = 'T3', value = 2.0)
    assert timer.stdev('T3') == 1.0

    timer.add(name = 'T4', value = 2.0)
    timer

# Generated at 2022-06-21 10:32:45.924243
# Unit test for constructor of class Timers
def test_Timers():
    """Unit tests for class Timers"""
    timers = Timers()
    assert dict(timers) == {}
    assert timers._timings == {}
    assert len(timers) == 0
    assert timers.total("value") == 0.0
    assert timers.min("value") == 0.0
    assert timers.max("value") == 0.0
    assert timers.mean("value") == 0.0
    assert timers.median("value") == 0.0
    assert timers.stdev("value") == 0.0

# Unit tests for add(), count(), total(), and clear()

# Generated at 2022-06-21 10:32:50.235166
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    assert timers.total('test') == 0
    timers.add('test', 1)
    assert timers.total('test') == 1
    timers.add('test', 2)
    assert timers.total('test') == 3


# Generated at 2022-06-21 10:32:54.310106
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add(name='a', value=0.0)
    timers.add(name='a', value=1.0)
    assert timers.stdev('a') == 0.5
    assert math.isnan(timers.stdev('b'))


# Generated at 2022-06-21 10:32:56.359169
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('total', 6.5)
    assert timers.mean('total') == 6.5



# Generated at 2022-06-21 10:32:58.751274
# Unit test for method median of class Timers
def test_Timers_median():
    '''
     Test case to test method median in module utils.py
     :return:
     '''
    timersDict = Timers()
    timersDict.median(name="test")



# Generated at 2022-06-21 10:33:09.592888
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    timers = Timers()
    timers.add('a', 0)
    timers.add('a', 1)
    timers.add('a', 2)
    timers.add('b', 10)
    timers.add('b', 20)
    timers.add('b', 30)
    timers.add('c', 100)
    timers.add('c', 200)
    timers.add('c', 300)
    assert timers.total('a') == 3
    assert timers.total('b') == 60
    assert timers.total('c') == 600
    assert timers.count('a') == 3
    assert timers.count('b') == 3
    assert timers.count('c') == 3
    assert timers.min('a') == 0
    assert timers.min('b') == 10
   

# Generated at 2022-06-21 10:33:13.749152
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("list", 1.5)
    t.add("list", 2.5)
    t.add("list", 0.5)

    assert t.min("list") == 0.5
    assert t.min("set") == 0.0


# Generated at 2022-06-21 10:33:23.187203
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timer = Timers()
    timer.add('test1', 12)
    timer.add('test1', 5)
    timer.add('test1', 15)
    timer.add('test1', 17)
    assert timer.mean('test1') == 13.0
    assert timer.mean('test2') == 0.0


# Generated at 2022-06-21 10:33:29.348891
# Unit test for method min of class Timers
def test_Timers_min():
    """Check that the method min is as expected"""
    t = Timers()
    assert t.min("foo") == 0
    assert t.min("bar") == 0
    t.add("foo", 10)
    assert t.min("foo") == 10
    assert t.min("bar") == 0
    t.add("foo", 5)
    assert t.min("foo") == 5
    assert t.min("bar") == 0
    assert t.min("baz") == 0


# Generated at 2022-06-21 10:33:38.583531
# Unit test for method min of class Timers
def test_Timers_min():
    from math import nan
    from .timer import Timers
    timers = Timers()

    timers.add("test1", 1)
    timers.add("test1", 2)
    timers.add("test1", nan)
    timers.add("test1", nan)
    timers.add("test2", 2)
    timers.add("test2", nan)
    timers.add("test2", nan)
    timers.add("test2", nan)

    assert timers.min("test1") == 1
    assert timers.min("test2") == 2



# Generated at 2022-06-21 10:33:42.575542
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Check that Timers does not allow the user to set timers"""
    timers = Timers()
    try:
        timers["blabla"] = 42
    except TypeError:
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-21 10:33:46.051002
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()

    timers.add("timer1", 1)
    timers.add("timer1", 2)
    timers.add("timer1", 3)

    assert timers.mean("timer1") == 2

# Generated at 2022-06-21 10:33:52.025802
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    assert timers.min('dummy') == 0
    timers.add('dummy', 1)
    assert timers.min('dummy') == 1
    timers.add('dummy', 2)
    assert timers.min('dummy') == 1
    timers.add('dummy', 3)
    assert timers.min('dummy') == 1


# Generated at 2022-06-21 10:33:58.346146
# Unit test for method count of class Timers
def test_Timers_count():
    t = Timers()
    assert t.count('foo') == 0
    t.add('foo', 1)
    assert t.count('foo') == 1
    t.add('foo', 2)
    assert t.count('foo') == 2
    t.clear()
    assert t.count('foo') == 0


# Generated at 2022-06-21 10:34:02.730146
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method add of class Timers"""
    timers = Timers()
    timers.add('a', 1)
    assert timers['a'] == 1
    timers.add('a', 2)
    assert timers['a'] == 3
    timers.add('b', 1)
    assert timers['b'] == 1
    timers.add('b', 2)
    assert timers['b'] == 3


# Generated at 2022-06-21 10:34:08.828581
# Unit test for method clear of class Timers
def test_Timers_clear():
    t = Timers()
    t.add("test", 1)
    assert len(t) == 1
    assert len(t._timings["test"]) == 1
    t.clear()
    assert len(t) == 0
    assert len(t._timings["test"]) == 0


# Generated at 2022-06-21 10:34:14.558023
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test method apply of class Timers"""

    # Initialize Timers object
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert isinstance(timers, collections.UserDict)

    # Test applying function to results of named timer
    assert timers.apply(sum, name="test") == 3
    assert timers.apply(len, name="test") == 2

# Generated at 2022-06-21 10:34:22.517360
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    t.add('test', 2)
    t.add('test', 3)
    t.add('test', 4)
    assert t.median('test') == 3, "Median value should be 3"

# Generated at 2022-06-21 10:34:26.222754
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test the apply method of the Timers class"""
    import pytest
    assert Timers().apply(len, "foo") == 0
    with pytest.raises(KeyError):
        Timers().apply(len, "bar")


# Generated at 2022-06-21 10:34:28.595322
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers._timings = {'test': [0, 1, 2]}
    assert timers.min('test') == 0



# Generated at 2022-06-21 10:34:31.112939
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add('a', 1)
    assert 1 == timers.data['a']



# Generated at 2022-06-21 10:34:37.409417
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count("foo") == 0
    timers.add("foo", 1.234)
    assert timers.count("foo") == 1
    timers.add("foo", 5.678)
    assert timers.count("foo") == 2
    assert timers.count("bar") == 0
    assert timers.count("baz") == 0
    

# Generated at 2022-06-21 10:34:41.699629
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Append timing values to timer of name 'test'
    timers = Timers()
    for i in range(10):
        timers.add('test', i)
    # Calculate the mean of the timing values
    mean = timers.mean('test')
    # Assert that the mean value is as expected
    assert mean == 4.5

# Generated at 2022-06-21 10:34:52.876737
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test the apply method of class Timers"""
    timers = Timers()
    timers.add('foo', 1)
    timers.add('foo', 2)
    timers.add('foo', 3)
    timers.add('bar', 2)
    func_sum = lambda values: sum(values)
    func_min = lambda values: min(values)
    func_max = lambda values: max(values)
    func_mean = lambda values: statistics.mean(values)
    func_median = lambda values: statistics.median(values)
    func_stdev = lambda values: statistics.stdev(values)
    assert isinstance(timers.apply(func_sum, 'foo'), float)
    assert timers.apply(func_sum, 'foo') == 6

# Generated at 2022-06-21 10:34:56.761730
# Unit test for method clear of class Timers
def test_Timers_clear():
    t = Timers()
    t.add('foo', 1)
    t.add('bar', 2)
    assert t.data == {'foo': 1, 'bar': 2}
    assert t._timings == {
        'foo': [1],
        'bar': [2]
        }
    t.clear()
    assert t.data == {}
    assert t._timings == {}


# Generated at 2022-06-21 10:35:02.806018
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test Timers mean"""
    timers = Timers()
    timers.add("name", 1)
    assert timers.mean("name") == 1.0
    timers.add("name", 2)
    assert timers.mean("name") == 1.5
    timers.add("name", 3)
    assert timers.mean("name") == int(round(statistics.mean((1, 2, 3))))



# Generated at 2022-06-21 10:35:09.194770
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method Timers.mean()"""
    # Create timers and fill with data
    timers = Timers()
    timers.add("timer 1", 0.1)
    timers.add("timer 1", 0.2)
    timers.add("timer 1", 0.3)
    # Check that mean is as expected
    assert timers.mean("timer 1") == 0.2


# Generated at 2022-06-21 10:35:20.690368
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    assert t.max("test") == 0
    t._timings = {"test": [1, 2, 3]}
    t.apply = lambda values: max(values)
    assert t.max("test") == 3


# Generated at 2022-06-21 10:35:28.757604
# Unit test for method clear of class Timers
def test_Timers_clear():
    names = ["a", "b"]
    values = [1.0, 1.0]
    timings = Timers()
    for name, value in zip(names, values):
        timings.add(name, value)
    assert timings.total("a") == 1.0
    assert timings.total("b") == 1.0
    timings.clear()
    assert timings.total("a") == 0.0
    assert timings.total("b") == 0.0


# Generated at 2022-06-21 10:35:30.477822
# Unit test for constructor of class Timers
def test_Timers():
    """Test if a Timers instance can be created"""
    assert Timers()

# Generated at 2022-06-21 10:35:36.669913
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    # Test: method __setitem__ of class Timers cannot be called
    # Create instance of class Timers
    timers = Timers()

    # Test: method __setitem__ of class Timers cannot be called
    try:
        timers["foo"] = 42.0
    except TypeError as e:
        assert str(e) == "Timers does not support item assignment. Use '.add()' to update values."
    else:
        assert False, "Expected TypeError"


# Generated at 2022-06-21 10:35:39.972565
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('a', 1.0)
    timers.add('a', 2.0)
    assert timers.mean('a') == 1.5
    assert timers.mean('b') == 0.0

# Generated at 2022-06-21 10:35:44.543198
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    assert len(timers) == 0
    assert timers.total('foo') == 0
    timers.add('foo', 1.0)
    assert timers.total('foo') == 1.0
    timers.add('foo', 1.5)
    assert timers.total('foo') == 2.5


# Generated at 2022-06-21 10:35:50.861443
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add('foo', 1)
    timers.add('foo', 2)
    timers.add('foo', 4)
    assert timers.median('foo') == 2

    timers = Timers()
    timers.add('foo', 1)
    timers.add('foo', 2)
    timers.add('foo', 3)
    timers.add('foo', 4)
    assert timers.median('foo') == 2.5

# Generated at 2022-06-21 10:36:03.685727
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    # Test with empty timer sets
    # Make an empty Timers object with data type float
    timers = Timers()
    with pytest.raises(KeyError):
        # Test with non-existing timer, should raise KeyError
        timers.mean("non-existing")
    with pytest.raises(KeyError):
        # Test with existing timer, should raise KeyError
        timers.mean("existing")
    # Test with filled timer sets
    # Add two timers
    timers.add("first_timer", 2)
    timers.add("second_timer", 3)
    timers.add("second_timer", 2)
    # Test with first timer
    assert timers.mean("first_timer") == 2.0
    # Test with second timer

# Generated at 2022-06-21 10:36:10.759317
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    assert timers.median("name") == 0
    timers.add("name", 1)
    assert timers.median("name") == 1
    timers.add("name", 1)
    assert timers.median("name") == 1
    timers.add("name", 2)
    assert timers.median("name") == 1
    timers.add("name", 3)
    assert timers.median("name") == 1.5
    timers.add("name", 4)
    assert timers.median("name") == 2

# Generated at 2022-06-21 10:36:19.660279
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    print('Testing Timers.__setitem__()')
    timers = Timers()
    if 'name' in timers:
        print(f"Test failed, unexpected item '{name!r}' found in timers.")
        return False
    try:
        timers[name] = 0
        print(f"Test failed, assignment to timers[name] did not fail")
        return False
    except TypeError:
        print('Timers.__setitem__() raised TypeError as expected')
    finally:
        timers.clear()
    print('Test succeeded')
    return True


# Generated at 2022-06-21 10:36:38.210094
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers["blah"] = 0.1
    timers["blah"] = 1
    timers["blah"] = 2

    assert timers.max("blah") == 2


# Generated at 2022-06-21 10:36:41.363156
# Unit test for method count of class Timers
def test_Timers_count(): 
    t = Timers()
    t.add("process", 0.2)
    t.add("query", 0.3)
    t.count("process") == 1


# Generated at 2022-06-21 10:36:44.413041
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Unit-test for method clear of class Timers"""
    timers = Timers({'time': 5.6})
    timers.clear()
    assert timers.data == {}



# Generated at 2022-06-21 10:36:47.906194
# Unit test for method min of class Timers
def test_Timers_min():
    timings = Timers()
    timings.add("foo", 1)
    timings.add("foo", 5)
    timings.add("foo", 2)
    assert timings.min("foo") == 1


# Generated at 2022-06-21 10:36:53.043461
# Unit test for method max of class Timers
def test_Timers_max():
    """max"""
    timers = Timers()
    timers.add("timer", 123)
    assert timers.max("timer") == 123
    timers.add("timer", 456)
    assert timers.max("timer") == 456
    for i in range(10):
        timers.add("timer", i)
    assert timers.max("timer") == 9
    try:
        timers.max("timer2")
        assert False, "Exception expected"
    except KeyError:
        pass


# Generated at 2022-06-21 10:36:58.156582
# Unit test for method max of class Timers
def test_Timers_max():
    timer_instance = Timers()
    timer_instance["foo"] = 1
    timer_instance["bar"] = 5
    assert timer_instance.max("bar") == 5
    assert timer_instance.max("foo") == 1
    assert timer_instance.max("foobar") == None


# Generated at 2022-06-21 10:37:04.407786
# Unit test for method mean of class Timers
def test_Timers_mean():

    """
    Test if mean is calculated correctly.
    """
    t = Timers()
    t.add('1', 1)
    t.add('1', 2)

    assert t.mean('1') == 1.5

    t.add('2', 2)
    assert t.mean('2') == 2

    t.add('3', 2)
    t.add('3', 4)
    assert t.mean('3') == 3


# Generated at 2022-06-21 10:37:07.137662
# Unit test for method count of class Timers
def test_Timers_count():
    """Test functionality of method count"""
    timers = Timers()
    timers.add('Test', 1)
    timers.add('Test', 2)
    assert timers.count('Test') == 2
    assert timers.count('Other') == 0


# Generated at 2022-06-21 10:37:10.619378
# Unit test for method count of class Timers
def test_Timers_count():
    """Test for method count of class Timers"""
    timers = Timers()
    assert timers.count('foo') == 0
    timers.add('foo', 1.0)
    timers.add('foo', 2.0)
    assert timers.count('foo') == 2


# Generated at 2022-06-21 10:37:14.422310
# Unit test for method median of class Timers
def test_Timers_median():
    # Arrange
    timings = Timers()
    names = ['a', 'b', 'c', 'd']
    values = [1, 2, 3]
    for name in names:
        for value in values:
            timings.add(name, value)
    # Act & Assert
    for name in names:
        assert timings.median(name) == 2



# Generated at 2022-06-21 10:37:49.830373
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    # Test instantiation
    mytimers = Timers()
    # Test setting
    try:
        mytimers['foo'] = 1
    except TypeError:
        pass
    else:
        assert False, 'Expected a TypeError'


# Generated at 2022-06-21 10:37:55.801483
# Unit test for constructor of class Timers
def test_Timers():
    """Test Timers.__init__() and .__len__()"""
    timers = Timers()
    assert len(timers) == 0
    assert len(timers._timings) == 0
    assert not timers._timings

    # Test passing in some data
    timers = Timers({"a": 1, "b": 2})
    assert len(timers) == 2
    assert "a" in timers
    assert "b" in timers
    assert "c" not in timers
    assert len(timers._timings) == 2


# Generated at 2022-06-21 10:38:04.022935
# Unit test for method clear of class Timers
def test_Timers_clear():
    """
    Test that a Timers object is cleared both by calling the clear method and
    by doing a clear on the data attribute
    """
    test_data = Timers()
    test_data.add("test", 1)
    assert len(test_data) == 1
    test_data.clear()
    assert len(test_data) == 0
    test_data.add("test", 1)
    assert len(test_data) == 1
    test_data.data.clear()
    assert len(test_data) == 0

# Generated at 2022-06-21 10:38:10.455910
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('some_timer', 5)
    timers.add('some_other_timer', 10)
    timers.add('some_timer', 3)

    assert timers.count('some_timer') == 2
    assert timers.count('some_other_timer') == 1
    assert timers.count('non_existent_timer') == 0

# Generated at 2022-06-21 10:38:18.573384
# Unit test for constructor of class Timers
def test_Timers():
    t = Timers()
    t.add('a', 1)
    t.add('a', 2)
    t.add('b', 3)
    assert t.count('a') == 2
    assert t.count('b') == 1
    assert t.count('c') == 0
    assert t.total('a') == 3
    assert t.total('b') == 3
    assert t.total('c') == 0
    assert t.min('a') == 1
    assert t.min('b') == 3
    assert t.min('c') == 0
    assert t.max('a') == 2
    assert t.max('b') == 3
    assert t.max('c') == 0
    assert t.mean('a') == 1.5
    assert t.mean('b') == 3.0

# Generated at 2022-06-21 10:38:21.139262
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timer = Timers()
    with pytest.raises(TypeError):
        timer['a'] = 1


# Generated at 2022-06-21 10:38:25.920835
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test Timers.stdev()"""
    timers = Timers()
    timers.add('timer_01', 0.01)
    assert timers.stdev(name='timer_01') == 0.0
    timers.add('timer_01', 0.02)
    assert timers.stdev(name='timer_01') > 0.0



# Generated at 2022-06-21 10:38:30.784161
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test', 1)
    assert timers.max('test') == 1.0
    assert timers.min('test') == 1.0
    timers.add('test', 2)
    assert timers.max('test') == 2.0
    assert timers.min('test') == 1.0
    

# Generated at 2022-06-21 10:38:33.824207
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers({'foo': 1.23456, 'bar': 2.34567})

    assert timers.count('foo') == 1
    assert timers.count('bar') == 1
    assert timers.count('baz') == 0


# Generated at 2022-06-21 10:38:37.961458
# Unit test for method add of class Timers
def test_Timers_add():
    """Test add method of Timers"""
    timers = Timers()
    timers.add('first', 1.)
    timers.add('second', 2.)
    assert timers['first'] == 1.
    assert timers['second'] == 2.
    try:
        timers['third'] = 4.
        raise AssertionError('should have raised TypeError')
    except TypeError:
        pass


# Generated at 2022-06-21 10:39:52.039961
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('mytimer', 1)
    timers.add('mytimer', 3)
    timers.add('mytimer', 5)
    timers.add('mytimer', 7)
    assert timers.median('mytimer') == 3.5
    # Edge cases
    timers = Timers()
    timers.add('mytimer', 1)
    assert timers.median('mytimer') == 1.0
    timers = Timers()
    timers.add('mytimer', 1)
    timers.add('mytimer', 2)
    assert timers.median('mytimer') == 1.5
    # Should raise an error when timer not present
    timers = Timers()
    raised = False
    try:
        timers.median('mytimer')
    except KeyError:
        raised = True
    assert raised

# Generated at 2022-06-21 10:39:55.999277
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('file', 0.2)
    timers.add('file', 0.8)
    timers.add('lookup', 0.3)
    assert timers.min('file') == 0.2



# Generated at 2022-06-21 10:40:00.086323
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    t = Timers()
    t.add("key", 1)
    assert t["key"] == 1
    t.add("key", 2)
    assert t["key"] == 3
    assert t.max("key") == 2


# Generated at 2022-06-21 10:40:07.184821
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    # 1st call to median(): should return 0
    assert timers.median('initial') == 0, "Expected 0, but got {}".format(timers.median('initial'))
    # 2nd call to median(): should return 0
    assert timers.median('initial') == 0, "Expected 0, but got {}".format(timers.median('initial'))
    # 3rd call to median(): should return 0
    assert timers.median('initial') == 0, "Expected 0, but got {}".format(timers.median('initial'))

# Generated at 2022-06-21 10:40:17.025351
# Unit test for method add of class Timers
def test_Timers_add():
    """Check that method add of class Timers works as expected"""
    timers = Timers()
    timers.add('timer1', 1)
    timers.add('timer2', 2)
    timers.add('timer2', 3)
    assert timers.count('timer1') == 1
    assert timers.count('timer2') == 2
    assert timers.total('timer1') == 1
    assert timers.total('timer2') == 5
    assert timers.mean('timer1') == 1
    assert timers.mean('timer2') == 2.5
    assert timers.median('timer1') == 1
    assert timers.median('timer2') == 2.5
    assert timers.stdev('timer1') == math.nan
    assert isinstance(timers.stdev('timer2'), float)


# Generated at 2022-06-21 10:40:21.163636
# Unit test for method min of class Timers
def test_Timers_min():
    with Timers() as timers:
        assert timers.min(name='x') == 0
        timers.add(name='x', value=1)
        assert timers.min(name='x') == 1
        timers.add(name='x', value=3)
        assert timers.min(name='x') == 1
        timers.add(name='x', value=-1)
        assert timers.min(name='x') == -1


# Generated at 2022-06-21 10:40:28.790457
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    # Test with one value
    timers = Timers()
    timers.add("test", 1)
    assert math.isnan(timers.stdev("test"))

    # Test with two values
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 1)
    assert timers.stdev("test") == 0

    # Test with three values
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.stdev("test") == 1

# Generated at 2022-06-21 10:40:36.505365
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("time1", 5)
    timers.add("time1", 3)
    assert timers.max("time1") == 5

    timers.add("time2", 4)
    assert timers.max("time2") == 4

    timers.add("time3", 1)
    assert timers.max("time3") == 1

    timers.add("time3", 2)
    assert timers.max("time3") == 2

    timers.add("time3", 7)
    assert timers.max("time3") == 7


# Generated at 2022-06-21 10:40:39.888257
# Unit test for method total of class Timers
def test_Timers_total():
    timer = Timers()
    timer.add("Timer1", 2)
    timer.add("Timer2", 4)
    timer.add("Timer1", 6)
    assert timer.total("Timer1") == 8



# Generated at 2022-06-21 10:40:42.614037
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Tests that Timers.mean returns the correct mean."""
    timers = Timers()
    timers._timings = {'lst': [2, 3, 4, 5, 6]}
    assert timers.mean('lst') == 4

