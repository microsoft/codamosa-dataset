

# Generated at 2022-06-21 10:31:29.259033
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    timers = Timers()
    assert len(timers) == 0
    assert len(timers._timings) == 0


# Generated at 2022-06-21 10:31:32.539740
# Unit test for method min of class Timers
def test_Timers_min():
    timer = Timers()
    assert timer.min("test") == 0.0
    assert "test" not in timer
    timer._timings["test"] = list(range(10))
    assert timer.min("test") == 0.0
    assert timer.min("not_existing") == 0.0

# Generated at 2022-06-21 10:31:35.810588
# Unit test for method total of class Timers
def test_Timers_total():
    timer = Timers()
    assert timer.total("a") == 0
    timer.add("a", 1)
    assert timer.total("a") == 1


# Generated at 2022-06-21 10:31:38.996476
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    assert timers.apply(len, name="timer1") == 0
    timers.add("timer1", 1)
    assert timers.apply(sum, name="timer1") == 1


# Generated at 2022-06-21 10:31:42.253607
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test method __setitem__"""
    from pytest import raises
    d = Timers()
    with raises(TypeError):
        d["a"] = 1


# Generated at 2022-06-21 10:31:45.721322
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""

    # Create Timers object
    timers = Timers()
    # Add timing value
    timers.add('test', 100.0)
    # Check if min is correct
    assert timers.min('test') == 100.0


# Generated at 2022-06-21 10:31:49.460574
# Unit test for method clear of class Timers
def test_Timers_clear():
    obj = Timers()
    obj.add("test", 1.0)
    assert obj._timings["test"][0] == 1.0
    assert obj.data["test"] == 1.0
    obj.clear()
    assert obj._timings["test"][0] != 1.0
    assert obj.data["test"] != 1.0

# Generated at 2022-06-21 10:31:52.224923
# Unit test for method apply of class Timers
def test_Timers_apply():
    def func(values: List[float]) -> float:
        return sum(values)

    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)

    assert timers.apply(func, 'test') == 6

# Generated at 2022-06-21 10:31:56.038900
# Unit test for method max of class Timers
def test_Timers_max():
    """Test for method max of Timers"""
    timers: Timers = Timers()
    for i in range(100):
        timers.add('x', i)
    assert timers.max('x') == 99.

"""Create a timer object"""
timers = Timers()

# Generated at 2022-06-21 10:31:59.587075
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    timers.update({"a": 2.0, "b": 3.0})
    def run():
        timers["c"] = 1.0
    import pytest
    pytest.raises(TypeError, run)



# Generated at 2022-06-21 10:32:08.782002
# Unit test for method clear of class Timers
def test_Timers_clear():
    """
    Test for method clear of class Timers
    """
    # Create the timers
    timers = Timers()
    # Add some timings
    timers.add("sec", 2.0)
    timers.add("min", 0.5)
    timers.add("sec", 2.5)
    timers.add("min", 0.8)
    # Create a reference
    ref = timers.data
    # Clear the timers
    timers.clear()
    # Check the result
    assert timers.data == {}
    assert timers._timings == {}
    assert timers.count == {}
    assert ref != timers.data


# Generated at 2022-06-21 10:32:14.033553
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    a = Timers()
    a.add("Foo", 1)
    a.add("Foo", 2)
    a.add("Foo", 3)
    a.add("Foo", 4)
    a.add("Foo", 5)
    a.add("Foo", 6)
    a.add("Foo", 7)
    a.add("Foo", 8)
    a.add("Foo", 9)
    a.add("Foo", 10)

    assert a.min("Foo") == 1


# Generated at 2022-06-21 10:32:16.793357
# Unit test for method count of class Timers
def test_Timers_count():
    """Test counting of timers"""
    timers = Timers()
    timers.add('test1', 10)
    timers.add('test2', 12)
    timers.add('test2', 14)
    timers.add('test2', 16)
    assert timers.count('test1') == 1
    assert timers.count('test2') == 3


# Generated at 2022-06-21 10:32:20.730332
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()

    assert timers.max("test") == 0.0

    timers.add("test", 0.5)
    timers.add("test", 1.0)
    timers.add("test", 0.1)

    assert timers.max("test") == 1.0


# Generated at 2022-06-21 10:32:25.455514
# Unit test for method mean of class Timers
def test_Timers_mean():
    """
    test_Timers_mean() -> test mean method of class Timers
    """
    timers = Timers()
    timers.add('foo', 1)
    timers.add('foo', 2)
    timers.add('foo', 2)
    assert timers.mean('foo') == 1.6666666666666666
    assert timers.mean('bar') == 0.0
    return

# Generated at 2022-06-21 10:32:29.762662
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('test1',1)
    timers.add('test1',2)
    timers.add('test1',3)
    timers.add('test1',4)
    timers.add('test2',5)
    assert timers.median('test1') == 2.5
    assert timers.median('test2') == 5



# Generated at 2022-06-21 10:32:31.665908
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean usage"""
    timers = Timers()
    timers.add("test", 0)
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 1.5

# Generated at 2022-06-21 10:32:34.452654
# Unit test for method total of class Timers
def test_Timers_total():
    timer = Timers()
    timer.add("t1", 1.0)
    timer.add("t1", 2.0)
    timer.add("t1", 3.0)
    timer.add("t2", 5.0)
    timer.add("t2", 7.0)
    timer.add("t2", 11.0)
    assert timer.total("t1") == 6
    assert timer.total("t2") == 23

# Generated at 2022-06-21 10:32:36.739667
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()
    t._timings['name'] = [1,2,3]
    assert t.total('name') == 6


# Generated at 2022-06-21 10:32:41.847265
# Unit test for method max of class Timers
def test_Timers_max():
    timer = Timers()
    assert timer.max("a") == 0
    timer.add("a", 1)
    assert timer.max("a") == 1
    timer.add("a", 2)
    assert timer.max("a") == 2



# Generated at 2022-06-21 10:32:47.781886
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    timers = Timers()
    for i in range(10):
        timers.add('test', i)

    assert timers.min('test') == 0


# Generated at 2022-06-21 10:32:50.842103
# Unit test for method clear of class Timers
def test_Timers_clear():
    t=Timers()
    t.add('a', 1)
    t.add('b', 1)
    t.clear()
    assert t.data == {}
    assert t._timings == {}

# Generated at 2022-06-21 10:32:55.859279
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.data['a'] = 1
    timers.data['b'] = 2
    timers._timings['c'] = [3]
    timers._timings['d'] = [4, 5]
    assert len(timers.data) == 2
    assert len(timers._timings) == 2
    timers.clear()
    assert timers.data == {}
    assert timers._timings == {}

# Generated at 2022-06-21 10:32:59.233796
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Ensures that the mean is calculated correctly."""
    t = Timers([(1, 2)])
    t.add('test', 1.)
    t.add('test', 1.)
    t.add('test', 2.)
    assert t.mean('test') == 1.5
#

# Generated at 2022-06-21 10:33:05.735958
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    class MyTimers(Timers):
        """Class for testing method __setitem__ of class Timers"""
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().clear(*args, **kwargs)
    # Create an instance of MyTimers
    my_timers = MyTimers()
    # Try to set a value
    try:
        my_timers["my_timer"] = 1.1
        assert False, "Should not be able to set a value"
    except TypeError:
        pass
    # Verify that the dictionary is still empty
    assert len(my_timers) == 0
    assert list(my_timers) == []

# Unit tests for methods of class Timers

# Generated at 2022-06-21 10:33:06.608681
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    pass # test coverage

# Generated at 2022-06-21 10:33:11.478124
# Unit test for method min of class Timers
def test_Timers_min():
    """Verify that min method produces the minimal of a list of values"""
    t = Timers()
    t.add('a', 1)
    t.add('a', 2)
    t.add('a', 3)
    assert t.min('a') == 1
    assert t.min('b') == 0

# Generated at 2022-06-21 10:33:17.846375
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add("test_1", 17.3)
    timers.add("test_2", 8.5)
    timers.add("test_1", 7.5)
    timers.add("test_2", 15.0)

    assert timers.mean("test_1") == 12.4
    assert timers.mean("test_2") == 11.75
    assert len(timers._timings["test_1"]) == 2
    assert len(timers._timings["test_2"]) == 2
    assert len(timers._timings) == 2

    timers.clear()

    assert not timers._timings
    assert not timers.data

# Generated at 2022-06-21 10:33:22.342253
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers["name"] = 3.0
    except Exception:
        pass
    else:
        assert False, "Failed to raise TypeError on setting attribute value"


# Generated at 2022-06-21 10:33:28.018980
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Unit test for method clear of class Timers"""
    timers = Timers()
    timers.add("foo", 3)
    timers.add("bar", 1)
    timers.add("bar", 2)
    timers.clear()
    assert timers.data == {}, "Dictionary 'data' should be empty."
    assert timers._timings == {}, "Dictionary '_timings' should be empty."


# Generated at 2022-06-21 10:33:34.420141
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test1", 1)
    timers.add("test1", 2)
    timers.add("test1", 0)
    assert timers.max("test1") == 2

# Generated at 2022-06-21 10:33:36.784520
# Unit test for method max of class Timers
def test_Timers_max():
    """Test max method of Timers class."""
    test_timer = Timers()
    test_timer.add('test', 4.5)
    test_timer.add('test', 3.2)
    assert test_timer.max('test') == 4.5
    assert test_timer.max('test2') == 0

# Generated at 2022-06-21 10:33:39.595726
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers['mytimer'] = 1
    except:
        print("Test passed")


# Generated at 2022-06-21 10:33:45.250344
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add('foo', 10.0)
    t.add('bar', 20.0)
    t.add('foo', 15.0)
    assert t.min('foo') == 10.0
    assert t.min('bar') == 20.0
    assert t.min('baz') == 0.0


# Generated at 2022-06-21 10:33:47.671810
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers == {}
    assert timers._timings == {}


# Generated at 2022-06-21 10:33:51.596174
# Unit test for method median of class Timers
def test_Timers_median():
    """Test method Timers.median"""
    timers = Timers()
    timers.add('timing', 5)
    timers.add('timing', 2)
    timers.add('timing', 4)
    assert timers.median('timing') == 4


# Generated at 2022-06-21 10:33:56.209881
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test method Timers.__setitem__"""
    import pytest
    timers = Timers()
    with pytest.raises(TypeError):
        timers['foo'] = 0.1

# Generated at 2022-06-21 10:34:00.553685
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers({'name1': 1.0, 'name2': 2.0})
    assert(timers.max('name1') == 1.0)
    assert(timers.max('name2') == 2.0)
    timers.add('name2', 4.0)
    assert(timers.max('name2') == 4.0)

# Generated at 2022-06-21 10:34:12.241233
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    assert timers.stdev('foo') == math.nan
    # zero-width peak
    timers.add('foo', 1)
    assert 0 < timers.stdev('foo') < math.inf
    # zero-width peak
    timers.add('foo', 1)
    assert timers.stdev('foo') == 0
    # wide peak
    timers.add('foo', 3)
    assert 0 < timers.stdev('foo') < math.inf
    # one-value peak
    timers.add('foo', 1)
    assert timers.stdev('foo') == 0
    # wide peak
    timers.add('foo', 3)
    assert 0 < timers.stdev('foo') < math.inf

# Generated at 2022-06-21 10:34:15.193543
# Unit test for method total of class Timers
def test_Timers_total():
    from sage.all import ZZ
    t = Timers()
    t['a'] = 1 + ZZ(2)
    assert t.total('a') == 3



# Generated at 2022-06-21 10:34:23.286306
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the Timers.mean method"""
    d = Timers()
    d.add('x', 1)
    d.add('x', 2)
    assert d.mean('x') == 1.5
    d.add('x', 3)
    assert d.mean('x') == 2
    return True


# Generated at 2022-06-21 10:34:28.291778
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    from pytest import raises
    timers = Timers()
    assert timers.apply(lambda values: values, name="test") == []
    with raises(KeyError, match="'test'"):
        timers.apply(lambda values: values, name="test1")


# Generated at 2022-06-21 10:34:30.017657
# Unit test for method min of class Timers
def test_Timers_min():
    assert Timers().min("") == 0


# Generated at 2022-06-21 10:34:37.455721
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for method stdev of class Timers"""
    logdata = Timers()
    logdata.add("test", 10)
    logdata.add("test", 20)
    logdata.add("test", 30)
    logdata.add("test", 40)
    logdata.add("test", 50)
    logdata.add("test", 60)
    assert logdata.stdev("test") == 10.0
# end test_Timers_stdev

# Generated at 2022-06-21 10:34:39.930900
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('foo', 1)
    assert timers.count('foo') == 1


# Generated at 2022-06-21 10:34:46.685702
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    assert timers.max('t') == 0
    timers.add('t', 42)
    assert timers.max('t') == 42
    timers.add('t', 7)
    assert timers.max('t') == 42
    assert 't' not in timers._timings
    assert timers.max('t') == 0



# Generated at 2022-06-21 10:34:50.496174
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count("name") == 0
    timers.add("name", 0.0)
    assert timers.count("name") == 1
    timers.add("name", 1.0)
    assert timers.count("name") == 2



# Generated at 2022-06-21 10:34:55.639893
# Unit test for method total of class Timers
def test_Timers_total():
    'Tests method total'
    timers = Timers()
    timers.add('timer1', 1.0)
    timers.add('timer1', 1.0)
    timers.add('timer1', 1.0)
    timers.add('timer2', 1.0)
    timers.add('timer2', 1.0)
    assert(timers.total('timer1') == 3.0)
    assert(timers.total('timer2') == 2.0)

# Generated at 2022-06-21 10:34:58.451634
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Check that standard deviation of an empty list is nan"""
    timers = Timers({'timers': 0})
    timers._timings = {'timers': []}
    assert math.isnan(timers.stdev('timers'))

# Generated at 2022-06-21 10:34:59.246762
# Unit test for constructor of class Timers
def test_Timers():

    assert isinstance(Timers(), Timers)

# Generated at 2022-06-21 10:35:12.481437
# Unit test for method mean of class Timers
def test_Timers_mean():
    from hypothesis import given
    from hypothesis.strategies import floats, lists

    @given(floats(allow_nan=False), lists(floats()))
    def test(result: float, inputs: List[float]) -> None:
        """
        Verify that the output of the function `mean` of class
        `Timers` is equal to the expected output.

        Parameters
        ----------
        result : float
            Expected output.
        inputs : List[float]
            Inputs to the function.

        Returns
        -------
        None : NoneType

        """
        timers = Timers()
        for input_ in inputs:
            timers.add("test", input_)
        assert timers.mean("test") == result

    test()


# Generated at 2022-06-21 10:35:18.431079
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Testing for method apply of class Timers"""
    test_timings: Dict[str, List[float]] = collections.defaultdict(list)
    test_timers = Timers()
    test_timers._timings = test_timings
    test_timings["test_timer"] = [1.0, 2.0]
    assert test_timers.apply(sum, name="test_timer") == 3.0

# Generated at 2022-06-21 10:35:24.933786
# Unit test for method total of class Timers
def test_Timers_total():
    timer = Timers()
    timer.add("T", 1)
    timer.add("T", 2)
    timer.add("T2", 1)
    timer.add("T2", 2)
    return timer.total("T"), timer.total("T2")


assert test_Timers_total() == (3, 3)



# Generated at 2022-06-21 10:35:27.085302
# Unit test for method min of class Timers
def test_Timers_min():
    """
    Test different values of the method min of class Timers.
    """
    assert Timers().min("name") == 0


# Generated at 2022-06-21 10:35:30.209263
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers({'a': 1, 'b': 2, 'c': 3})
    assert timers.min('a') == 1
    assert timers.min('b') == 2
    assert timers.min('c') == 3


# Generated at 2022-06-21 10:35:33.713277
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers == {}

    timers["a"] = 0
    assert timers == {"a": 0}

    timers["b"] = 0
    assert timers == {"a": 0, "b": 0}


# Generated at 2022-06-21 10:35:40.466996
# Unit test for method min of class Timers
def test_Timers_min():
    # Correct min
    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 2)
    timers.add("a", 3)
    assert (timers.min("a"), timers["a"]) == (1, 6)

    # No values
    timers = Timers()
    timers.add("a", 0)
    timers.add("a", 0)
    assert (timers.min("a"), timers["a"]) == (0, 0)

    # Missing key
    timers = Timers()
    try:
        timers.min("a")
    except KeyError:
        pass
    else:
        raise AssertionError("Missing key did not trigger KeyError")

if __name__ == "__main__":
    import sys
    sys.exit(test_Timers_min())

# Generated at 2022-06-21 10:35:46.626859
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add("task1", 42)
    timers.add("task2", 1e7)
    timers["task3"] = 1e9
    assert len(timers) == 3
    assert len(timers._timings) == 2
    timers.clear()
    assert len(timers) == 0
    assert len(timers._timings) == 0

if __name__ == "__main__":
    test_Timers_clear()

# Generated at 2022-06-21 10:35:52.259844
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add('timer1', 1)
    assert len(timers._timings) == 1
    assert len(timers.data) == 1
    timers.add('timer2', 2)
    assert len(timers._timings) == 2
    assert len(timers.data) == 2
    timers.clear()
    assert len(timers._timings) == 0
    assert len(timers.data) == 0


# Generated at 2022-06-21 10:36:02.809790
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    import numpy as np
    x = Timers()
    x._timings['timer'] = np.array([1,2,3,4,5])
    assert x.stdev('timer') == 1.5811388300841898
    x._timings['timer'] = np.array([1,2,3])
    assert math.isnan(x.stdev('timer'))
    x._timings['timer'] = np.array([1])
    assert math.isnan(x.stdev('timer'))
    x._timings['timer'] = []
    assert math.isnan(x.stdev('timer'))

# Generated at 2022-06-21 10:36:13.181930
# Unit test for method add of class Timers
def test_Timers_add():
    """Test adding values to the Timers class"""
    a = Timers()
    a.add('test_1', 10)
    a.add('test_1', 15)
    a.add('test_2', 20)
    assert a['test_1'] == 25
    assert a['test_2'] == 20
    assert a.count('test_1') == 2
    assert a.count('test_2') == 1


# Unit tests for methods total, min, max and mean of class Timers

# Generated at 2022-06-21 10:36:17.599868
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timer = Timers()
    timer.add('A', 1)
    timer.add('A', 2)
    assert timer.median('A') == 1.5

# Generated at 2022-06-21 10:36:23.860702
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add('a', 10)
    assert timers.mean('a') == 10
    timers.add('a', 20)
    assert timers.mean('a') == 15
    assert timers.stdev('a') == 5
    timers.add('a', 30)
    assert timers.mean('a') == 20
    assert timers.stdev('a') == 8.16496580927726
    timers.add('a', 40)
    assert timers.mean('a') == 25
    assert timers.stdev('a') == 12.24744871391589

# Generated at 2022-06-21 10:36:26.011720
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    timers['name'] = 0
    def should_raise() -> None:
        timers['name'] = 0

# Generated at 2022-06-21 10:36:31.736675
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    # pylint: disable=protected-access
    timers = Timers()
    assert timers.mean("a") == 0
    timers._timings["a"] = []
    assert timers.mean("a") == 0
    timers._timings["a"] = [1]
    assert timers.mean("a") == 1
    timers._timings["a"] = [1, 2, 3]
    assert timers.mean("a") == 2
    timers._timings["a"] = [1, 2, 3, 4, 5]
    assert timers.mean("a") == 3
    timers._timings["a"] = [10, 20, 30, 40, 50]
    assert timers.mean("a") == 30

# Generated at 2022-06-21 10:36:35.079873
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()

    try:
        timers["test"] = 3.1
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-21 10:36:39.593511
# Unit test for method max of class Timers
def test_Timers_max():  # pragma: no cover
    timers = Timers()
    timers.add("foo", 1)
    assert timers.max("foo") == 1
    timers.add("foo", 10)
    assert timers.max("foo") == 10
    assert timers.max("bar") == 0

# Generated at 2022-06-21 10:36:44.555738
# Unit test for method max of class Timers
def test_Timers_max():
    """Test Timers.max()"""
    timers = Timers()
    assert "foo" not in timers._timings
    timers.add("foo", 4)
    assert len(timers._timings) == 1
    timers.add("foo", 2)
    assert timers.max("foo") == 4



# Generated at 2022-06-21 10:36:53.219695
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    timers = Timers()
    timers.add("Speeding", 1.287)
    timers.add("Speeding", 1.287)
    timers.add("Speeding", 1.287)
    assert math.isclose(timers.min("Speeding"), 1.287), "min method failed"
    timers.add("Crash", 2.573)
    timers.add("Crash", 2.573)
    timers.add("Crash", 2.573)
    timers.add("Crash", 2.573)
    assert math.isclose(timers.min("Crash"), 2.573), "min method failed"
    timers.add("Speeding", 1.287)
    timers.add("Speeding", 1.287)
    timers.add("Speeding", 1.287)

# Generated at 2022-06-21 10:36:57.978045
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    # Imports for unit testing
    import pytest

    # Unit test for an assignment
    w = Timers()
    with pytest.raises(TypeError):
        w["key"] = 1.0
        pytest.fail("Assignment should raise a TypeError")

# Generated at 2022-06-21 10:37:07.277489
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add("test", 0.0)
    assert timers.mean("test") == 0.0

    timers.add("test", 1.0)
    assert timers.mean("test") == 0.5

    timers.add("test", 2.0)
    assert timers.mean("test") == 1.0

# Generated at 2022-06-21 10:37:13.171521
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test of method stdev of class Timers"""
    timers = Timers()
    assert timers.stdev("non-existing timer") == math.nan
    timers.add("name1", 1.0)
    assert timers.stdev("name1") == math.nan
    timers.add("name1", 2.0)
    assert timers.stdev("name1") == 0.7071067811865476
    timers.add("name1", 1.0)
    assert timers.stdev("name1") == 0.4714045207910316

# Generated at 2022-06-21 10:37:14.966472
# Unit test for constructor of class Timers
def test_Timers():
    """Test constructor"""
    TIMERS = Timers()
    assert TIMERS is not None


# Generated at 2022-06-21 10:37:18.011939
# Unit test for constructor of class Timers
def test_Timers():  # type: ignore
    """Test constructor of class Timers"""
    timers = Timers()
    assert timers._timings == collections.defaultdict(list)


# Generated at 2022-06-21 10:37:23.967029
# Unit test for method median of class Timers
def test_Timers_median():
    # empty dict
    timers = Timers()
    assert timers.median("test") == 0

    # dict with one value
    timers = Timers()
    timers.add("test", 1)
    assert timers.median("test") == 1

    # dict with three values
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2

# Generated at 2022-06-21 10:37:26.023326
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add("count", 1)
    assert timers.total("count") == 1


# Generated at 2022-06-21 10:37:28.264362
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    t = Timers()
    t.add("test", 1)
    assert t.stdev("test") == 0
    assert math.isnan(t.stdev("nan"))

# Generated at 2022-06-21 10:37:32.001031
# Unit test for method total of class Timers
def test_Timers_total():
    """Test method total of class Timers"""
    timers = Timers()
    assert(timers.total("b") == 0)
    timers.add("a", 42)
    timers.add("a", -42)
    assert(timers.total("a") == 0)
    timers.add("a", 0)
    assert(timers.total("a") == 0)
    timers.add("b", 3.14)
    assert(timers.total("b") == 3.14)
    timers.add("b", -3.14)
    assert(timers.total("b") == 0)

# Generated at 2022-06-21 10:37:34.251796
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add('test', 2)
    timers.add('test', 5)
    total = timers.total('test')
    assert total == 7
    return total
print(test_Timers_total())

# Generated at 2022-06-21 10:37:39.856386
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test that the method Timers.__setitem__ catches item assignment"""
    timers = Timers()
    try:
        timers["timer"] = 1.0
    except TypeError as e:
        assert "Use '.add()' to update values" in str(e), "Wrong exception"
    else:
        raise AssertionError("Did not raise expected TypeError")

# Generated at 2022-06-21 10:37:49.474051
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    t = Timers()
    t.add("a", 2)
    assert t.stdev("a") == 0
    t.add("a", 3)
    assert 0.41 < t.stdev("a") < 0.42
    assert t.stdev("b") == t.stdev("b", default=0)

# Generated at 2022-06-21 10:37:52.813082
# Unit test for method count of class Timers
def test_Timers_count():
    t = Timers()
    t.add("test", 1)
    t.add("test", 2)
    t.add("test", 3)
    t.add("test", 4)
    assert t.count("test") == 4

# Generated at 2022-06-21 10:37:55.502837
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    timers = Timers()
    # test TypeError
    with pytest.raises(TypeError):
        timers['timer0'] = 0.1


# Generated at 2022-06-21 10:37:58.649062
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add('test', 0.5)
    timers.add('test', 0.5)
    assert timers.total('test') == 1.0


# Generated at 2022-06-21 10:38:01.335419
# Unit test for method total of class Timers
def test_Timers_total():
    import time
    timers = Timers()
    timers.add('time', time.time())
    assert isinstance(timers.total('time'), float)


# Generated at 2022-06-21 10:38:06.876542
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    timers = Timers()
    timers.add("timer1", 1.1)
    timers.add("timer2", 2.2)
    timers.add("timer2", 3.3)
    timers.add("timer3", 4.4)
    assert timers.count("timer1") == 1
    assert timers.count("timer2") == 2
    assert timers.count("timer3") == 1
    assert timers.total("timer1") == 1.1
    assert timers.total("timer2") == 5.5
    assert timers.total("timer3") == 4.4
    assert timers.min("timer1") == 1.1
    assert timers.min("timer2") == 2.2
    assert timers.min("timer3") == 4.4

# Generated at 2022-06-21 10:38:12.303733
# Unit test for constructor of class Timers
def test_Timers():
    """Test Timer class"""
    timers = Timers()
    assert len(timers) == 0
    assert len(timers._timings) == 0
    assert isinstance(timers, collections.UserDict)
    assert hasattr(timers, 'add')
    assert hasattr(timers, 'apply')
    assert hasattr(timers, 'clear')
    assert hasattr(timers, 'count')
    assert hasattr(timers, 'max')
    assert hasattr(timers, 'mean')
    assert hasattr(timers, 'median')
    assert hasattr(timers, 'min')
    assert hasattr(timers, 'stdev')
    assert hasattr(timers, 'total')
    assert hasattr(timers, '_timings')

# Generated at 2022-06-21 10:38:15.109722
# Unit test for constructor of class Timers
def test_Timers():
    """Test constructor of class Timers"""

    # Set up
    timers = Timers()

    # Assert
    assert str(timers) == "{}"
    assert timers.data == {}


# Generated at 2022-06-21 10:38:20.893598
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    # Initialize variables (Unit test)
    value = [0.5, 1.5, 0.5]
    timer = Timers()
    timer.data['value'] = sum(value)
    timer._timings['value'] = value

    # Check answer
    assert timer.stdev('value') == statistics.stdev(value)



# Generated at 2022-06-21 10:38:22.140091
# Unit test for method count of class Timers
def test_Timers_count():
    pass


# Generated at 2022-06-21 10:38:33.548018
# Unit test for method total of class Timers
def test_Timers_total():
    timer = Timers()
    timer.add('test', 10)
    assert timer.total('test') == 10



# Generated at 2022-06-21 10:38:38.912758
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    import pytest
    timers = Timers()
    timers.add('test1', 2)
    timers.add('test1', 3)
    timers.add('test2', 5)
    assert timers.apply(len, name='test1') == 2
    assert timers.apply(sum, name='test1') == 5
    assert timers.apply(len, name='test2') == 1
    with pytest.raises(KeyError):
        timers.apply(len, name='test3')


# Generated at 2022-06-21 10:38:42.535770
# Unit test for method total of class Timers
def test_Timers_total():
    T = Timers()
    T.data = {'a': 100, 'b': 200}
    assert T.total('a') == 100
    assert T.total('b') == 200
    assert T.total('c') == 0


# Generated at 2022-06-21 10:38:50.054980
# Unit test for method max of class Timers
def test_Timers_max():
    """Test max function of Timers class"""
    from typing import Dict
    from .asserts import assert_eq
    from .testdata import timers

    def test(name: str, args: Dict[str, float], expected: float) -> None:
        """Run one test"""
        assert_eq(Timers(timers[name]).max(name), expected)

    yield test, "empty", {}, 0.0
    yield test, "one", {"A": 1.0}, 1.0
    yield test, "several", {"A": 1.0, "B": 2.0, "C": 3.0}, 3.0
    yield test, "inf", {"AA": 1.0, "BB": 2.0, "CC": math.inf}, math.inf

# Generated at 2022-06-21 10:38:53.049464
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add("timer1", 104)
    timers.add("timer2", 105)
    timers.add("timer3", 106)
    timers.clear()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-21 10:38:56.534819
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    assert Timers().stdev("t") == math.nan
    assert Timers().add("t", 10).stdev("t") == math.nan
    assert Timers().add("t", 10).add("t", 20).stdev("t") == 5.0

# Generated at 2022-06-21 10:39:00.872668
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    times = Timers()
    m = [0, 0, 1, 1]
    s = [1, 2, 1, 2]
    for i in range(len(m)):
        times.add("Test", m[i] + s[i])
    assert abs(times.stdev("Test") - 1) < 0.001


# Generated at 2022-06-21 10:39:06.390974
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Testing if the mean method of Timers works fine"""
    timings = Timers()
    timings.add("timer1",3)
    timings.add("timer1",4)
    timings.add("timer1",4)
    assert timings.mean("timer1") == 3.66666

# Generated at 2022-06-21 10:39:13.885345
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Create the empty timers
    timers = Timers()

    # Insert a value of 1.0 into the timers
    timers.add("test", 1.0)

    # Check the mean for the timer is 1.0
    # For the relative tolerance, we use a value 1E-3
    assert round(timers.mean("test"), 3) == 1.0

    # Test whether the mean throws the expected exception
    try:
        timers.mean("foo")
    except KeyError as e:
        assert str(e) == "'foo'"

# Generated at 2022-06-21 10:39:24.952132
# Unit test for method median of class Timers
def test_Timers_median():
    """Median values for some combinations of numbers"""
    assert Timers({"k1": 1}).median("k1") == 1
    assert Timers({"k1": 1, "k2": 2}).median("k1") == 1
    assert Timers({"k1": 1, "k2": 2}).median("k2") == 2
    assert Timers({"k1": 1, "k2": 2, "k3": 3}).median("k1") == 1
    assert Timers({"k1": 1, "k2": 2, "k3": 3}).median("k2") == 2
    assert Timers({"k1": 1, "k2": 2, "k3": 3}).median("k3") == 3

# Generated at 2022-06-21 10:39:54.359657
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""

    # Construct Timers object
    my_timers = Timers()
    assert my_timers.data == {}
    assert my_timers._timings == {}

    # Add two timings to timer 'foo'
    my_timers.add('foo', 1)
    my_timers.add('foo', 2)

    # Add one timing to timer 'bar'
    my_timers.add('bar', 3)

    # Check timer values
    assert my_timers.data == {'foo': 3, 'bar': 3}
    assert my_timers._timings == {'foo': [1, 2], 'bar': [3]}


# Generated at 2022-06-21 10:39:56.966246
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers([("name", 0.0)])
    try:
        timers["name"] = 1.0
        assert False
    except TypeError:
        pass

# Generated at 2022-06-21 10:40:00.644417
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add("example", 123.45)
    timers.add("one", 1)
    timers.add("two", 2)
    assert timers.median("example") == 123.45

# Generated at 2022-06-21 10:40:05.054547
# Unit test for method count of class Timers
def test_Timers_count():
    """Function with unit test"""
    timers = Timers()
    timers.add("t1", 10)
    timers.add("t1", 20)
    timers.add("t2", 30)
    assert timers.count("t1") == 2
    assert timers.count("t2") == 1
    assert timers.count("t3") == 0


# Generated at 2022-06-21 10:40:13.513473
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    assert timers.median('foo') == 0
    assert timers.median('bar') == 0
    timers.add('foo', 1)
    timers.add('foo', 2)
    timers.add('foo', 3)
    timers.add('bar', 3)
    timers.add('bar', 2)
    timers.add('bar', 1)
    assert timers.median('foo') == 2
    assert timers.median('bar') == 2
    timers.add('bar', 1)
    assert timers.median('bar') == 1.5


# Generated at 2022-06-21 10:40:16.316645
# Unit test for method add of class Timers
def test_Timers_add():
    """Add timer"""
    timers = Timers()
    timer = Timer(timers=timers)

    # Add timer
    timer.start()
    timer.stop()
    assert timers['test'] == timer.elapsed_time



# Generated at 2022-06-21 10:40:20.555198
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add("timer1", 1.1)
    assert timers["timer1"] == 1.1
    timers.add("timer1", 1.2)
    assert timers["timer1"] == 2.3
    timers.add("timer2", 1.3)
    assert timers["timer2"] == 1.3
    with pytest.raises(KeyError):
        timers.add("timer3", 1.4)

# Generated at 2022-06-21 10:40:24.240888
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    # No durations
    assert timers.min("time") == 0
    # One duration
    timers.add("time", 1)
    assert timers.min("time") == 1
    # More durations
    timers.add("time", 2)
    assert timers.min("time") == 1
    timers.add("time", 0)
    assert timers.min("time") == 0
    return

# Generated at 2022-06-21 10:40:28.830069
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.data['test0'] = 0
    timers.data['test1'] = 2
    timers.data['test2'] = 4
    assert timers.mean('test2') == 2
    assert timers.mean('test1') == 1
    assert timers.mean('test0') == 0


# Generated at 2022-06-21 10:40:37.206750
# Unit test for constructor of class Timers
def test_Timers():
    """Test constructors of class Timers"""
    timers = Timers({'test': 1.0})
    assert timers.data == {'test': 1.0}
    assert not timers._timings

    # Test add()
    timers.add('test', 2.0)
    assert timers._timings['test'] == [2.0]
    assert timers.data['test'] == 3.0

    # Test __setitem__
    try:
        timers['test'] = 4.0
    except TypeError:
        pass
    else:
        raise RuntimeError("TypeError not raised")
    return

