

# Generated at 2022-06-11 20:11:46.854840
# Unit test for method median of class Timers
def test_Timers_median():
    """Test for method median of class Timers"""
    timers = Timers()
    # Test for empty list
    timers.clear()
    timers.add("one", 2.0)
    assert timers.median("one") == 2.0
    timers.add("one", 1.0)
    assert timers.median("one") == 1.5
    timers.add("one", 2.0)
    assert timers.median("one") == 2.0
    timers.add("one", 4.0)
    assert timers.median("one") == 2.0
    timers.add("one", 0.0)
    assert timers.median("one") == 1.5
    timers.add("one", 3.0)
    assert timers.median("one") == 2.0

# Generated at 2022-06-11 20:11:49.196743
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("test", 10)
    t.add("test", 20)
    assert t.min("test") == 10

# Generated at 2022-06-11 20:11:52.478985
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test for method mean of class Timers"""
    timers = Timers()
    timers.add('foo', 5)
    timers.add('foo', 10)
    timers.add('bar', 10)
    assert timers.mean('foo') == 7.5
    assert timers.mean('bar') == 10.0

# Generated at 2022-06-11 20:11:56.861186
# Unit test for method median of class Timers
def test_Timers_median():
    """Test Timers.median()"""
    timers = Timers()
    timers.add('Timer is running', 100)
    timers.add('Timer is running', 100)
    timers.add('Timer is running', 100)
    assert timers.median('Timer is running') == 100


# Generated at 2022-06-11 20:12:01.501918
# Unit test for method min of class Timers
def test_Timers_min():
    """Test min method in Timers class"""
    timers_dict = Timers()
    timers_dict.add('test', 1.)
    timers_dict.add('test', 2.)
    assert timers_dict.min('test') == 1.0
    assert timers_dict.count('test') == 2.0
    assert timers_dict.total('test') == 3.0


# Generated at 2022-06-11 20:12:06.931865
# Unit test for method median of class Timers
def test_Timers_median():
    # Creates a Timers
    timers = Timers()
    # Adds a timer
    timers.add("test1", 0.1)
    timers.add("test1", 0.2)
    timers.add("test1", 0.3)
    # Gets the value
    value = timers.median("test1")
    # Checks whether the value is correct
    assert value == 0.2

# Generated at 2022-06-11 20:12:10.086483
# Unit test for method min of class Timers
def test_Timers_min():
    # Setting up
    timers = Timers()
    timers.add("timer1", 1)
    timers.add("timer1", 2)
    timers.add("timer1", 3)
    # Assertion
    assert timers.min("timer1") == 1

# Generated at 2022-06-11 20:12:14.988792
# Unit test for method min of class Timers
def test_Timers_min():
    timer = Timers()
    assert timer.min("min_test") == 0
    timer.add("min_test", 1)
    assert timer.min("min_test") == 1
    timer.add("min_test", 2)
    assert timer.min("min_test") == 1
    timer.clear()


# Generated at 2022-06-11 20:12:17.477902
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("a", 1)
    t.add("a", 2)
    t.add("a", 3)
    t.a

# Generated at 2022-06-11 20:12:19.433166
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("name", 100.0)

    assert timers.max("name") == 100.0

# Generated at 2022-06-11 20:12:26.205236
# Unit test for method max of class Timers
def test_Timers_max():
    # Generate a Timers object and test it
    time = Timers()
    time['time'] = 1
    time['time'] = 2
    time['time'] = 3
    assert time.max('time') == 3


# Generated at 2022-06-11 20:12:32.281349
# Unit test for method min of class Timers
def test_Timers_min():
    # test with no value
    assert Timers().min(name = "") == 0
    # test with empty list of values
    assert Timers().apply(lambda x : min(x or [0]), name = "") == 0
    # test with real value
    assert Timers().apply(lambda x : min(x or [0]), name = "") != 4


# Generated at 2022-06-11 20:12:40.532572
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    assert timers.median('missing') == 0
    timers.add('empty', 0)
    assert timers.median('empty') == 0
    timers.add('single', 1)
    assert math.isclose(timers.median('single'), 1)
    timers.add('even', 2)
    timers.add('even', 4)
    assert math.isclose(timers.median('even'), 3)
    timers.add('uneven', 2)
    timers.add('uneven', 3)
    timers.add('uneven', 4)
    assert math.isclose(timers.median('uneven'), 3)
    timers.add('multiple', 3)
    timers.add('multiple', 3)
    assert math.isclose(timers.median('multiple'), 3)
    timers

# Generated at 2022-06-11 20:12:47.935006
# Unit test for method median of class Timers
def test_Timers_median():
    timer_obj = Timers()
    timer_obj['hashes'] = timer_obj['hashes'] + 1.5
    timer_obj['hashes'] = timer_obj['hashes'] + 2.8
    timer_obj['hashes'] = timer_obj['hashes'] + 1.6
    timer_obj['hashes'] = timer_obj['hashes'] + 4.3
    timer_obj['hashes'] = timer_obj['hashes'] + 3.3
    assert timer_obj.median('hashes') == 3.05


# Generated at 2022-06-11 20:12:52.743084
# Unit test for method max of class Timers
def test_Timers_max(): # type: () -> None
    """Test the Timers class method max"""
    timers = Timers()
    assert timers.max('never_used') == 0
    timers._timings['max_test'] = [1, 2, 3]
    assert timers.max('max_test') == 3


# Generated at 2022-06-11 20:13:02.217290
# Unit test for method mean of class Timers
def test_Timers_mean():
    T = Timers()

    assert T.mean('a') == 0.0

    T.add('a', 1)
    assert T.mean('a') == 1.0
    assert T.data['a'] == T.mean('a')

    T.add('a', 2)
    assert T.mean('a') == 1.5
    assert T.data['a'] == 3.0

    T.add('a', 3)
    assert T.mean('a') == 2.0
    assert T.data['a'] == 6.0

    assert T.mean('b') == 0.0

    T.add('b', 1)
    assert T.mean('b') == 1.0
    assert T.data['b'] == T.mean('b')

    T.add('b', 2)

# Generated at 2022-06-11 20:13:05.115463
# Unit test for method max of class Timers
def test_Timers_max():
    tm = Timers()
    tm.add('a', 5)
    tm.add('a', 7)
    assert tm.max('a')==7


# Generated at 2022-06-11 20:13:12.498893
# Unit test for method max of class Timers
def test_Timers_max():
    """Unit test for method max of class Timers"""
    from . import Timers

    timers = Timers()
    assert timers.max("non-existing") == 0

    timers.add("foo", 0)
    assert timers.max("foo") == 0

    timers.add("foo", 2)
    assert timers.max("foo") == 2

    timers.add("foo", 1)
    assert timers.max("foo") == 2

    timers.add("foo", 0)
    assert timers.max("foo") == 2



# Generated at 2022-06-11 20:13:15.854504
# Unit test for method min of class Timers
def test_Timers_min():
    temp = Timers()
    temp._timings = {"1": [1.0, 2.0], "2": [2.0, 3.0]}
    assert temp.min("1") == 1
    assert temp.min("2") == 2
    return None


# Generated at 2022-06-11 20:13:21.151581
# Unit test for method median of class Timers
def test_Timers_median():
    timer = Timers()
    timer.add("test1", 3)
    timer.add("test1", 4)
    timer.add("test1", 5)
    # median should be 4
    assert timer.median("test1") == 4
    timer.add("test1", 10)
    # median should be 4.5
    assert timer.median("test1") == 4.5


# Generated at 2022-06-11 20:13:31.120356
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("method1", duration=0.00030)
    timers.add("method1", duration=0.00029)
    timers.add("method2", duration=0.00021)
    timers.add("method2", duration=0.00022)
    print(timers.data)
    print(timers._timings)
    print(timers.median("method1"))
    print(timers.median("method2"))

if __name__ == "__main__":
    test_Timers_median()

# Generated at 2022-06-11 20:13:33.966388
# Unit test for method max of class Timers
def test_Timers_max():
   t = Timers()
   t.add('test', 1)
   t.add('test', 2)
   assert t.max('test') == 2


# Generated at 2022-06-11 20:13:36.427013
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("A", 3)
    timers.add("A", 4)
    assert timers.max("A") == 4

# Generated at 2022-06-11 20:13:45.330766
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()

    # Set up a situation where there are no timings
    name: str = "no_timings"
    timers.add(name, 0)
    assert timers.mean(name) == 0

    # Set up a situation where there is one timing
    name: str = "one_timing"
    timers.add(name, 5)
    assert timers.mean(name) == 5

    # Set up a situation where there are two timings
    name: str = "two_timings"
    timers.add(name, 5)
    timers.add(name, 4)
    assert timers.mean(name) == 4.5

    # Set up a situation where there are three timings
    name: str = "three_timings"
    timers.add(name, 5)

# Generated at 2022-06-11 20:13:50.118963
# Unit test for method median of class Timers
def test_Timers_median():
    row1 = Timers()
    row1.add('timer1', 1.0)
    row1.add('timer1', 1.0)
    row1.add('timer1', 1.0)

    result = row1.median('timer1')
    assert result == 1.0



# Generated at 2022-06-11 20:13:56.754796
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    timers = Timers()
    timers.add("test1", 1245)
    timers.add("test1", 1226)
    timers.add("test1", 1236)
    timers.add("test1", 1227)
    timers.add("test2", 1337)
    assert timers.min("test1") == 1226
    assert timers.min("test2") == 1337
    assert timers.min("test3") == 0  # KeyError is raised and caught


# Generated at 2022-06-11 20:14:00.949284
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Create instance of class Timers
    _timers = Timers()
    _timers.add("A", 1)
    _timers.add("A", 2)
    _timers.add("A", 3)
    # Test that mean is reported correctly
    assert _timers.mean("A") == 2


# Generated at 2022-06-11 20:14:04.413451
# Unit test for method mean of class Timers
def test_Timers_mean():
    '''
    This function tests that the mean method of class Timers works as intended
    '''
    timers = Timers()
    timers.add('test', 5)
    timers.add('test', 10)
    timers.add('test', 15)
    assert timers.mean('test') == 10


# Generated at 2022-06-11 20:14:06.609280
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", None)
    assert timers.max("test") == 0


# Generated at 2022-06-11 20:14:14.353205
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("T1", 42.99)
    timers.add("T2", 1.3)
    timers.add("T2", 3.14)
    timers.add("T3", None)
    assert timers.max("T1") == 42.99
    assert timers.max("T2") == 3.14
    assert math.isnan(timers.max("T3"))
    assert timers.max("T4") == 0

# Generated at 2022-06-11 20:14:23.187710
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('spam', 1)
    timers.add('spam', 2)
    if timers.mean('spam') != 1.5:
        return False
    return True


# Generated at 2022-06-11 20:14:30.538193
# Unit test for method max of class Timers
def test_Timers_max():
    """Unit test for method max of class Timers"""
    test_timers = Timers()
    assert test_timers.max("test") == 0

    test_timers.add("test", 5)
    test_timers.add("test", 3)
    test_timers.add("test", 7)
    assert test_timers.max("test") == 7


# Generated at 2022-06-11 20:14:39.916024
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()

    timers.add("timer1", 10.0)
    timers.add("timer1", 20.0)
    timers.add("timer1", 30.0)
    timers.add("timer1", 40.0)
    timers.add("timer1", 50.0)
    timers.add("timer1", 60.0)

    timers.add("timer2", 10.0)
    timers.add("timer2", 20.0)
    timers.add("timer2", 30.0)
    timers.add("timer2", 40.0)
    timers.add("timer2", 50.0)
    timers.add("timer2", 60.0)

    assert timers.max("timer1") == 60.0
    assert timers.max("timer2") == 60.0


# Generated at 2022-06-11 20:14:50.892820
# Unit test for method median of class Timers
def test_Timers_median():
    my_timers = Timers()
    my_timers.add('greeting', 1.0)
    my_timers.add('greeting', 2.0)
    my_timers.add('greeting', 3.0)
    assert my_timers.median('greeting') == 2.0
    my_timers.add('greeting', 4.0)
    my_timers.add('greeting', 5.0)
    assert my_timers.median('greeting') == 3.0
    my_timers.add('greeting', 6.0)
    my_timers.add('greeting', 7.0)
    assert my_timers.median('greeting') == 4.0

# Generated at 2022-06-11 20:14:53.096654
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.add('x', 1)
    t.add('x', 2)
    assert t.max('x') == 2


# Generated at 2022-06-11 20:14:55.725176
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t._timings["test"] = [10, 2, 5, 2, 10]
    assert t.min("test") == 2


# Generated at 2022-06-11 20:14:58.096931
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("foo", 0)
    timers.add("foo", -1)
    assert timers.min("foo") == -1


# Generated at 2022-06-11 20:15:03.923461
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit tests for method mean() of Timers class"""
    timers = Timers()
    assert timers.mean("unkown") == 0.0
    timers.add("foo", 42)
    timers.add("foo", 69)
    assert timers.mean("foo") == 55.5
    assert timers.mean("unkown") == 0.0
    assert timers.mean("bar") == 0.0



# Generated at 2022-06-11 20:15:07.879877
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    assert timers.min('foo') == 0

    timers.add('foo', 1)
    assert timers.min('foo') == 1

    timers.add('foo', 6)
    assert timers.min('foo') == 1

    timers.add('foo', -1)
    assert timers.min('foo') == -1







# Generated at 2022-06-11 20:15:12.974538
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    # Given a dictionary with one element
    t = Timers()
    t.add('a', 2.0)
    # When the mean value is read
    mean = t.mean('a')
    # Then the mean value is equal to the value in the dictionary
    assert mean == 2.0

# Generated at 2022-06-11 20:15:28.325230
# Unit test for method min of class Timers
def test_Timers_min():
    in_timers=Timers()
    in_timers.add("a", 5)
    in_timers.add("a", 10)
    in_timers.add("b", 3)
    in_timers.add("b", 2)
    assert in_timers.min("a") == 5
    assert in_timers.min("b") == 2


# Generated at 2022-06-11 20:15:30.112030
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    assert True

# Generated at 2022-06-11 20:15:34.963393
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("timer", 2.0)
    timers.add("timer", 3.0)
    timers.add("timer", 5.0)
    assert timers.mean("timer") == 3.0
    assert timers.max("timer") == 5.0

if __name__ == "__main__":
    test_Timers_mean()

# Generated at 2022-06-11 20:15:38.551283
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('a', 2)
    timers.add('a', 1)
    assert timers.min('a') == 1


# Generated at 2022-06-11 20:15:41.836959
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test_timer', 1)
    timers.add('test_timer', 10)
    timers.add('test_timer', 15)
    timers.add('test_timer', 100)
    assert timers.max('test_timer') == 100


# Generated at 2022-06-11 20:15:52.841617
# Unit test for method median of class Timers
def test_Timers_median():  # pragma: no cover
    from .utils import subtest
    from .assertions import assert_fails, assert_equal

    mytimers = Timers()
    mytimers.add('a', 1)  # should give a median of 1
    mytimers.add('b', 1)  # does not exist, should give error
    mytimers.add('c', 2)  # should give a median of 1.5
    mytimers.add('c', 3)  # should give a median of 2

    subtest(
        mytimers.median, 'a',
        expected=1,
    )
    assert_fails(
        mytimers.median, 'b',
        expected_exc=KeyError,
    )

# Generated at 2022-06-11 20:15:55.332701
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.add("test", 10)
    t.add("test", 15)
    t.add("test", 5)
    t.add("test", 25)
    t.add("test", 20)
    assert t.max("test") == 25


# Generated at 2022-06-11 20:15:59.309671
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("first", 0.)
    timers.add("first", .1)
    timers.add("first", .2)
    timers.add("first", .3)
    timers.add("second", 1.)
    timers.add("second", 1.1)
    timers.add("second", 1.2)
    timers.add("second", 1.3)
    assert timers.max("first") == 0.3
    assert timers.max("second") == 1.3


# Generated at 2022-06-11 20:16:03.376980
# Unit test for method min of class Timers
def test_Timers_min():
    import pytest
    from collections import UserDict
    t = Timers(UserDict({'hi' : 25, 'hello' : 19, 'bye' : 12}))
    assert t.min('bye') == 12
    assert t.min('hello') == 19
    assert t.min('hi') == 25
    with pytest.raises(KeyError):
        t.min('bye!')


# Generated at 2022-06-11 20:16:05.313665
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    assert math.isnan(timers.min('foo'))



# Generated at 2022-06-11 20:16:22.012389
# Unit test for method max of class Timers
def test_Timers_max():
    """Method max of class Timers returns the max of a timer."""
    # Initialize timers object
    timers = Timers()
    # Add some timers
    timers.add('A', 1.0)
    timers.add('A', 2.0)
    timers.add('A', 3.0)
    timers.add('A', 4.0)
    # Check that max of timer A is 4.0
    assert (timers.max('A') == 4.0)


# Generated at 2022-06-11 20:16:26.002839
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add("first_timer", 1)
    t.add("first_timer", 2)
    t.add("first_timer", 3)
    assert t.mean("first_timer") == 2


# Generated at 2022-06-11 20:16:32.387114
# Unit test for method median of class Timers
def test_Timers_median():
    from programytest.storage.asserts.store.assert_timers import TimersStoreAsserts
    store = TimersStoreAsserts()

    store.assert_median(None, "TIMER1")

    store.add_to_store(None, "TIMER1", 1)
    store.assert_median(None, "TIMER1", 1)

    store.add_to_store(None, "TIMER1", 2)
    store.assert_median(None, "TIMER1", 1.5)

    store.add_to_store(None, "TIMER1", 3)
    store.assert_median(None, "TIMER1", 2)

    store.clear()
    store.assert_median(None, "TIMER1")


# Unit test

# Generated at 2022-06-11 20:16:36.239786
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    t.add('t', 1)
    t.add('t', 2)
    assert t.median('t') == 1.5
    t.add('t', 4)
    assert t.median('t') == 2


# Generated at 2022-06-11 20:16:42.970850
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("one", 1.0)
    timers.add("one", 0.5)
    timers.add("two", 0.0)
    timers.add("two", 0.0)
    assert timers.min("one") == 0.5
    assert timers.min("two") == 0.0
    assert timers.min("none") == 0.0


# Generated at 2022-06-11 20:16:47.489232
# Unit test for method min of class Timers
def test_Timers_min():
    a = Timers()
    a.add("obama", 2.0)
    a.add("obama", 1.0)
    a.add("lama", 6.0)
    a.add("alma", 3.0)
    a.add("lama", 4.0)
    a.add("alma", 5.0)
    a.add("alma", 7.0)
    print("alma minimum:",a.min("alma"))


# Generated at 2022-06-11 20:16:51.699400
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    print('Testing Timers.mean()')
    print('Expected: 2')
    print('Actual  :', timers.mean('test'))


# Generated at 2022-06-11 20:16:54.410159
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    assert timers.max(name="test") == 0



# Generated at 2022-06-11 20:16:58.336713
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    t.add('a', 42)
    assert t.median('a') == 42
    t.add('a', 2)
    assert t.median('a') == 22

# Generated at 2022-06-11 20:17:00.937764
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("timer_name", 0)
    assert timers.mean("timer_name") == 0
    assert timers.mean("timer_name_2") is math.nan



# Generated at 2022-06-11 20:17:35.945978
# Unit test for method max of class Timers
def test_Timers_max():
    """Unit test for method max of class Timers"""
    timers = Timers()
    timers.add('A', 1)
    timers.add('A', 2)
    timers.add('A', 3)
    assert timers.max('A') == 3

    timers.clear()
    timers.add('A', 1)
    timers.add('A', 3)
    timers.add('A', 2)
    assert timers.max('A') == 3

    timers.clear()
    timers.add('A', 3)
    timers.add('A', 3)
    timers.add('A', 3)
    assert timers.max('A') == 3

    timers.clear()
    timers.add('A', 1)
    timers.add('A', 3)
    assert timers.max('A') == 3

    timers.clear()
   

# Generated at 2022-06-11 20:17:37.508545
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Check type of mean() return value"""
    from typing import Union
    assert isinstance(Timers().mean("timer_name"), Union[float, __builtins__.int])

# Generated at 2022-06-11 20:17:41.957825
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    for name in range(10):
        for value in range(10, 0, -1):
            timers.add(str(name), value)
    for name in timers._timings:
        assert timers.max(name) == 10


# Generated at 2022-06-11 20:17:50.516575
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    # No timing
    assert math.isnan(timers.median("test"))
    # One timing
    timers._timings["test"].append(1)
    assert timers.median("test") == 1
    # Two timings; median would be 1.5
    timers._timings["test"].append(2)
    assert timers.median("test") == 1.5
    # Three timings; median would be 2
    timers._timings["test"].append(3)
    assert timers.median("test") == 2
    # Four timings; median would be 2
    timers._timings["test"].append(4)
    assert timers.median("test") == 2.5
    # Five timings; median would be 2

# Generated at 2022-06-11 20:17:57.671668
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add('timer1', 1.0111)
    timers.add('timer1', 0.999)
    timers.add('timer1', 0.9999)
    timers.add('timer1', 0.0000)
    assert timers.mean('timer1') == 1.00525

    # No timer provided
    with pytest.raises(KeyError):
        timers.mean('')




# Generated at 2022-06-11 20:18:04.291035
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test to ensure the median is correctly computed."""
    # Test odd case
    odd_timers = Timers()
    odd_timers.add('odd', 1)
    odd_timers.add('odd', 3)
    odd_timers.add('odd', 5)
    assert odd_timers.median('odd') == 3

    # Test even case
    even_timers = Timers()
    even_timers.add('even', 1)
    even_timers.add('even', 3)
    assert even_timers.median('even') == 2

# Generated at 2022-06-11 20:18:11.450334
# Unit test for method max of class Timers
def test_Timers_max():
    """
    Make sure that the method Timer.max works as expected
    """
    timers = Timers()
    name = "string_name"
    value = 0.5
    timers.add(name, value)
    assert timers.max(name) == value
    value = 1.5
    timers.add(name, value)
    assert timers.max(name) == value
    value = 2.5
    timers.add(name, value)
    assert timers.max(name) == value


# Generated at 2022-06-11 20:18:18.177077
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1.1)
    timers.add("test", 2.2)
    timers.add("test", 3.3)
    timers.add("test2", 1.0)
    print("max test-values: ", timers.max("test"))
    print("max test2-values: ", timers.max("test2"))
    print("max non-existant values: ", timers.max("test3"))


# Generated at 2022-06-11 20:18:21.939213
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of Timers"""
    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 2)
    assert timers.mean("a") == 1.5


# Generated at 2022-06-11 20:18:23.249978
# Unit test for method min of class Timers
def test_Timers_min():
    assert Timers().min('no name') == 0

# Generated at 2022-06-11 20:19:16.997252
# Unit test for method min of class Timers
def test_Timers_min():
    timer = Timers()
    timer.add("time", 2.5)
    timer.add("time", 2.5)
    timer.add("time", 2.5)
    assert round(timer.min("time"), 5) == 2.5


# Generated at 2022-06-11 20:19:21.017996
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    actual = Timers()
    actual.add('time', 5)
    actual.add('time', 10)
    assert actual.mean('time') == 7.5


# Generated at 2022-06-11 20:19:25.793828
# Unit test for method mean of class Timers
def test_Timers_mean():
    """This tests the method mean of class Timers"""
    timers = Timers()
    timers.add('timer1', 0.5)
    timers.add('timer1', 1)
    timers.add('timer1', 1.5)
    timers.add('timer2', 2)
    assert timers.mean('timer1') == 1
    assert timers.mean('timer2') == 2

# Generated at 2022-06-11 20:19:29.122408
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('a', 1.0)
    timers.add('a', 1.0)
    timers.add('a', 4.0)
    timers.add('a', 5.0)
    assert timers.median('a') == 3.0
    assert timers.median('b') == 0


# Generated at 2022-06-11 20:19:33.548688
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    timers = Timers()
    timers.add("foo", 1)
    timers.add("foo", 2)
    timers.add("foo", 3)
    assert(timers.min("foo") == 1)


# Generated at 2022-06-11 20:19:38.888612
# Unit test for method median of class Timers
def test_Timers_median():
    data = Timers()
    assert data.median("test") == 0
    data.add("test", 1)
    assert data.median("test") == 1
    data.add("test", 2)
    assert data.median("test") == 1.5
    data.add("test", 3)
    assert data.median("test") == 2

# Generated at 2022-06-11 20:19:41.485083
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    values = [0.1*x for x in range(100)]
    for value in values:
        timers.add("foo", value)
    assert timers.max("foo") == max(values)

# Generated at 2022-06-11 20:19:43.998550
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('timing', 3.2)
    assert timers.min('timing') == 3.2
    timers.add('timing', 1.7)
    assert timers.min('timing') == 1.7


# Generated at 2022-06-11 20:19:46.900287
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('name1', value=10)
    timers.add('name1', value=20)
    timers.add('name1', value=30)
    assert timers.max('name1') == 30


# Generated at 2022-06-11 20:19:56.463044
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of Timers class"""
    import pytest
    # Create empty class
    timers = Timers()
    # Check that it's empty
    assert timers == {}
    # Check that it has the desired method min
    assert hasattr(timers, 'min')
    # Check that min returns zero when timer is not present
    assert timers.min('Timer') == 0
    # Check that min returns 0 when list is empty
    timers.add('Timer2', 0)
    assert timers.min('Timer2') == 0
    # Check that min returns the minimum time when timer is present
    timers.add('Timer3', 2)
    timers.add('Timer3', 5)
    timers.add('Timer3', 1)
    assert timers.min('Timer3') == 1
    # Check that error is raised when the argument is not a string
