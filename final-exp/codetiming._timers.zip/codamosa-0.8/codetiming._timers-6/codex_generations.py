

# Generated at 2022-06-11 20:11:42.470068
# Unit test for method min of class Timers
def test_Timers_min():
    """Test min() method of class Timers"""
    timers = Timers()
    assert timers.min("value") == 0
    timers.add("key", 1)
    timers.add("key", 2)
    assert timers.min("key") == 1
    assert timers.min("value") == 0
    assert timers.min("other key") == 0


# Generated at 2022-06-11 20:11:47.946922
# Unit test for method max of class Timers
def test_Timers_max():
    """Unit test for method max of class Timers"""
    timers = Timers()

    timers.add("A", 0.000001)
    timers.add("A", 0.000010)
    timers.add("B", 0.0000001)
    timers.add("B", 0.0000004)

    assert timers.max("A") == 0.00001
    assert timers.max("B") == 0.0000004


# Generated at 2022-06-11 20:11:53.596141
# Unit test for method mean of class Timers
def test_Timers_mean():
    data = Timers()
    data.add('a', 1)
    data.add('a', 2)
    data.add('a', 3)
    data.add('b', 3)
    data.add('b', 4)
    data.add('b', 5)

    a_mean = data.mean('a')
    assert a_mean == 2

    b_mean = data.mean('b')
    assert b_mean == 4

    try:
        invalid_mean = data.mean('invalid')
        assert False
    except KeyError:
        pass


# Generated at 2022-06-11 20:11:58.700998
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("timer 1", 5)
    assert timers.median("timer 1") == 5
    timers.add("timer 1", 2)
    assert timers.median("timer 1") == 3.5
    timers.add("timer 2", 4)
    assert timers.median("timer 2") == 4
    timers.add("timer 2", 1)
    assert timers.median("timer 2") == 2.5

# Generated at 2022-06-11 20:12:03.640005
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean value of timers"""
    timer = Timers()
    timer.add('test', 234.5)
    timer.add('test', 345.6)
    timer.add('test', 456.7)
    timer.add('test', 567.8)
    assert timer.mean('test') == 391.075



# Generated at 2022-06-11 20:12:06.832103
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    for i in range(1,8):
        timers.add('test_mean', i)
    assert timers.mean('test_mean') == 4


# Generated at 2022-06-11 20:12:13.822019
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the Timers().median method"""
    from pytest import approx

    data = collections.defaultdict(list)
    data['test1'] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    data['test2'] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

# Generated at 2022-06-11 20:12:19.193838
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the inherited Timers class method median."""
    # Create a Timer instance
    # pylint: disable=W0102
    timers = Timers()
    timers.add("number", 1)
    timers.add("number", 2)
    assert timers.median("number") == 1.5

    # Test a missing value
    try:
        timers.median("missing_key")
    except KeyError:
        pass
    else:
        assert False

# Generated at 2022-06-11 20:12:22.544532
# Unit test for method median of class Timers
def test_Timers_median():
    """Test implementation of method 'median' of class 'Timers'"""
    timers = Timers()
    for i in range(10):
        timers.add(name='test', value=i)
    assert timers.median('test') == 4.5

# Generated at 2022-06-11 20:12:27.637291
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method Timers.mean"""
    import random
    random.seed(0)

    timers = Timers()
    for i in range(10):
        timers.add("test", random.randrange(0, 10, 1))
    assert timers.mean("test") == 4.9


# Generated at 2022-06-11 20:12:33.983375
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers({'timer': 2.5})
    timers.add('timer', 2.6)
    timers.add('timer', 2.7)
    assert timers.min('timer') == 2.5


# Generated at 2022-06-11 20:12:37.279836
# Unit test for method max of class Timers
def test_Timers_max():
    """Test max returns float
    This function tests if the maximum of a timer is returned as a float.
    """
    timers = Timers()

    timers.add(name="test", value=10)

    assert isinstance(timers.max(name="test"), float)


# Generated at 2022-06-11 20:12:39.460179
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('foo', 1)
    timers.add('foo', 2)
    timers.add('foo', 3)
    assert timers.mean('foo') == 2

# Generated at 2022-06-11 20:12:41.178685
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    assert timers.mean("test") == 1

# Generated at 2022-06-11 20:12:45.257411
# Unit test for method min of class Timers
def test_Timers_min():
    """Test minimum value of Timer"""
    timers = Timers()
    timers.add('min_test', 1)
    timers.add('min_test', 2)
    timers.add('min_test', 3)
    assert timers.min('min_test') == 1


# Generated at 2022-06-11 20:12:48.726199
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("a", 2)
    assert timers.min("a") == 2
    timers.add("a", 1)
    assert timers.min("a") == 1
    timers.add("a", 3)
    assert timers.min("a") == 1


# Generated at 2022-06-11 20:12:51.765626
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers({"foo": 1.0, "bar": 2.0})
    assert timers.mean("foo") == 1.0
    assert timers.mean("bar") == 2.0

# Generated at 2022-06-11 20:12:54.182181
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("name", 1)
    assert timers.median("name") == 1.0



# Generated at 2022-06-11 20:13:00.442785
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    assert math.isnan(timers.median("nothing"))
    timers.add("nothing", 1)
    assert timers.median("nothing") == 1
    timers.add("nothing", 2)
    assert timers.median("nothing") == 1.5
    timers.add("nothing", 3)
    assert timers.median("nothing") == 2
    timers.clear()
    assert math.isnan(timers.median("nothing"))

# Generated at 2022-06-11 20:13:02.750080
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers._timings["test"] = [1, 2, 3]
    assert timers.min("test") == 1

# Generated at 2022-06-11 20:13:11.231132
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    dict_obj = {'a': 200, 'b': 300, 'c': 400}
    obj = Timers(dict_obj)
    assert obj.mean('a') == 200
    assert obj.mean('b') == 300
    assert obj.mean('c') == 400
    assert obj.mean('d') == 0
    

# Generated at 2022-06-11 20:13:19.644240
# Unit test for method min of class Timers
def test_Timers_min():
    """Check that Timers.min works as expected"""
    # Create Timers instance
    timers = Timers()
    # Check empty timer
    assert timers.min("timer") == 0.0
    # Add timer value
    timers.add("timer", 100.0)
    # Check timer
    assert timers.min("timer") == 100.0
    # Add more timer values
    timers.add("timer", 200.0)
    timers.add("timer", 0.0)
    # Check timer
    assert timers.min("timer") == 0.0
    # Ensure that timer value is not reset
    assert timers.data == {"timer": 300.0}
    # Check nonexistent timer
    assert timers.min("nonexistent") == 0.0


# Generated at 2022-06-11 20:13:22.477902
# Unit test for method median of class Timers
def test_Timers_median():
    """Median value will be 0 if there are no values"""
    timers = Timers()
    assert timers.median("SomeTimer") == 0


# Generated at 2022-06-11 20:13:27.731193
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add("foo", 2)
    timers.add("bar", 3)

    # Unit test of method mean
    assert timers.mean("foo") == 2
    assert timers.mean("bar") == 3
    assert timers.mean("zot") == 0

# Generated at 2022-06-11 20:13:30.122518
# Unit test for method mean of class Timers
def test_Timers_mean():
    """test_Timers_mean"""
    timers = Timers()
    timers.add('test', 3)
    timers.add('test', 4)
    assert timers.mean('test') == 3.5


# Generated at 2022-06-11 20:13:32.303808
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers._timings['a'] = [1, 2, 3]
    assert timers.max('a') == 3
    assert timers.max('b') == 0


# Generated at 2022-06-11 20:13:41.464396
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    assert t.min("key") == 0.0
    t.add("key", 0)
    assert t.min("key") == 0.0
    t.add("key", 2)
    assert t.min("key") == 0.0
    t.add("key", 1)
    assert t.min("key") == 0.0
    t.add("key", 4)
    assert t.min("key") == 0.0
    t.add("key", -2)
    assert t.min("key") == -2.0
    t.add("key", 3)
    assert t.min("key") == -2.0

# Generated at 2022-06-11 20:13:47.263109
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("fast", 0.01)
    timers.add("fast", 0.02)
    timers.add("slow", 0.04)
    timers.add("slow", 0.03)
    assert timers.min("fast") == 0.01
    assert timers.min("slow") == 0.03


# Generated at 2022-06-11 20:13:49.378700
# Unit test for method max of class Timers
def test_Timers_max():
    timer = Timers()
    timer.add("test", 2)
    timer.add("test", 3)

    assert timer.max("test") == 3

# Generated at 2022-06-11 20:13:53.093947
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of Timers"""
    timers = Timers()
    timers._timings = {'key': [1.0, 2.0]}

    assert timers.min('key') == 1.0
    assert timers.min('key_notfound') == 0

# Generated at 2022-06-11 20:14:03.140421
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("first", 1)
    t.add("first", 2)
    t.add("first", 3)
    t.add("second", 0)
    t.add("second", -1)
    assert t.min("first") == 1
    assert t.min("second") == -1


# Generated at 2022-06-11 20:14:05.754347
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('max', 100)
    timers.add('max', 200)
    timers.add('max', 300)
    assert timers.max('max') == 300


# Generated at 2022-06-11 20:14:10.502141
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.add("test1", 1)
    t.add("test2", 3)
    assert t.max("test1") == 1
    assert t.max("test2") == 3

# Generated at 2022-06-11 20:14:15.468960
# Unit test for method median of class Timers
def test_Timers_median():
    # When we build a Timers class with an empty dictionary
    a = Timers()
    # The the median is the zero
    assert a.median('k') == 0
    # When we build a Timers class with a filled dictionary
    a = Timers({'k': 1})
    # The the median is the zero
    assert a.median('k') == 1

# Generated at 2022-06-11 20:14:20.041528
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('foo', 2)
    timers.add('foo', 1)

    assert timers.min('foo') == 1, 'Minimum value of timer "foo" should be 1'
    assert timers.min('bar') == 0, 'Minimum value of timer "bar" should be 0'


# Generated at 2022-06-11 20:14:24.543828
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test that Timers.mean() returns expected results"""
    timers = Timers()
    assert timers.mean("foo") == 0
    timers.add("foo", 1)
    assert timers.mean("foo") == 1
    timers.add("foo", 2)
    assert timers.mean("foo") == 1.5
    assert timers.mean("bar") == 0


# Generated at 2022-06-11 20:14:28.696101
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers._timings["A"] = [1.1, 2.2, 3.3]
    assert 2.2 == timers.median("A")

# Generated at 2022-06-11 20:14:31.918067
# Unit test for method min of class Timers
def test_Timers_min():
    _timers = Timers()
    _timers.add("test", 2)
    _timers.add("test", 3)
    assert _timers.min("test") == 2


# Generated at 2022-06-11 20:14:36.068181
# Unit test for method min of class Timers
def test_Timers_min():
    from random import randrange
    timers = Timers()
    for i in range(5):
        for j in range(1000):
            timers.add("test1", randrange(100))
    assert timers.min("test1") == 0

# Generated at 2022-06-11 20:14:40.759068
# Unit test for method max of class Timers
def test_Timers_max():
    """Test for the max method"""
    input_timers = Timers()
    input_timers.add("add", 0.1)

    actual_timers = input_timers.max("add")
    expected_timers = 0.1

    assert actual_timers == expected_timers


# Generated at 2022-06-11 20:14:55.601230
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("t1", 1.5)
    timers.add("t1", 2)
    timers.add("t1", 2.5)
    assert timers.mean("t1") == 2

# Generated at 2022-06-11 20:15:00.298061
# Unit test for method max of class Timers
def test_Timers_max():
    """Test the maximum value of a timer"""
    # Create Timers object
    t = Timers()
    # Timer start
    t.add('time1', 10)
    t.add('time1', 20)
    t.add('time1', 30)
    # Check result
    assert t.max('time1') == 30


# Generated at 2022-06-11 20:15:04.187268
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('time', 10)
    timers.add('time', 11)
    timers.add('time', 12)
    assert timers.max('time') == 12
    assert timers.max('new') == 0


# Generated at 2022-06-11 20:15:06.960684
# Unit test for method max of class Timers
def test_Timers_max():
    """Test that max returns the maximum value of all Timers.
    """
    t = Timers()
    for i in range(10):
        t.add('time', i)
    assert t.max('time') == 9


# Generated at 2022-06-11 20:15:18.200527
# Unit test for method max of class Timers
def test_Timers_max():
    example = Timers()
    assert example.max('name') == 0
    example.add('name', 1.0)
    assert example.max('name') == 1.0
    example.add('name', 1.0)
    assert example.max('name') == 1.0
    example.add('name', 2.0)
    assert example.max('name') == 2.0
    example.clear()
    example.add('name', 2.0)
    assert example.max('name') == 2.0
    example.add('name', 1.0)
    assert example.max('name') == 2.0
    example.add('name', 1.0)
    assert example.max('name') == 2.0
    example.clear()
    example.add('name', 1.0)

# Generated at 2022-06-11 20:15:21.491066
# Unit test for method max of class Timers
def test_Timers_max():
    # Dummy test, does not actually test anything
    # Just a placeholder for the coverage
    timers = Timers()
    assert timers.max('test') == 0
    timers.add('test', 1)
    assert timers.max('test') == 1


# Generated at 2022-06-11 20:15:24.380167
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add(name="xyz", value=2)
    assert timers.max(name="xyz") == 2
    assert timers.max(name="abc") == 0


# Generated at 2022-06-11 20:15:28.358907
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test if the mean method of Timers class returns the correct value"""
    t = Timers()
    t._timings = dict(timers=[1, 2, 3, 4])
    t.data = dict(timers=10)
    assert t.mean(name="timers") == 2.5
    # return t.mean(name)

# Generated at 2022-06-11 20:15:34.718679
# Unit test for method median of class Timers
def test_Timers_median():
    timer = Timers()
    timer.add("a", 4)
    timer.add("b", 2)
    timer.add("c", 3)
    timer.add("d", 1)
    assert timer.median("a") == 4
    assert timer.median("b") == 2
    assert timer.median("c") == 3
    assert timer.median("d") == 1
    assert timer.median("e") == 0

test_Timers_median()

# Generated at 2022-06-11 20:15:38.736894
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    timers = Timers()
    timers.add("test", 1.5)
    assert timers.min("test") == 1.5


# Generated at 2022-06-11 20:16:06.421831
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Initialization of the timers
    timers = Timers()

    # Add to the timer name
    timers.add("timer1", 3.5)
    timers.add("timer1", 4.2)
    timers.add("timer1", 2.9)

    # Test
    assert timers.mean("timer1") == 3.466666666666667
    print("Test successful")


# Generated at 2022-06-11 20:16:16.762994
# Unit test for method max of class Timers
def test_Timers_max():
    """Unit test for method max of class Timers"""
    import sys

    # Creation of a Timers object
    timers = Timers()

    # Add values to the Timers object
    timers.add("timer1", 1)
    timers.add("timer2", 2)
    timers.add("timer3", 3)

    # Add values to the Timers object
    timers.add("timer1", 0)
    timers.add("timer2", 0)
    timers.add("timer3", 0)

    # Test that the max function works as expected
    assert timers.max("timer1") == 1
    assert timers.max("timer2") == 2
    assert timers.max("timer3") == 3

    # Test that the max function works as expected
    assert timers.max("timer1") == 0

# Generated at 2022-06-11 20:16:19.573844
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('dummy', 3)
    timers.add('dummy', 1)
    timers.add('dummy', 2)
    assert timers.median('dummy') == 2

# Generated at 2022-06-11 20:16:21.910765
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("min", 0)
    t.add("min", 1)

    assert t.min("min") == 0


# Generated at 2022-06-11 20:16:25.445956
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add('myname', 1)
    assert t.mean('myname') == 1
    assert t.apply(lambda x: t.mean('myname'), name='myname') == 1

# Generated at 2022-06-11 20:16:32.218822
# Unit test for method median of class Timers
def test_Timers_median():
    """Median value of timings"""
    # Local imports
    from pymontecarlo.util.cbook import Timers  # noqa: E402
    import math  # noqa: E402

    timers = Timers()
    timers.add('timer1', 2.45)
    timers.add('timer1', 3.56)
    timers.add('timer1', 5.67)

    timers.add('timer2', 4.05)
    timers.add('timer2', 1.56)
    timers.add('timer2', 5.33)
    timers.add('timer2', 6.88)

    assert timers.median('timer1') == 3.56
    assert timers.median('timer2') == 4.42
    assert math.isnan(timers.median('timer3'))



# Generated at 2022-06-11 20:16:37.040947
# Unit test for method median of class Timers
def test_Timers_median():
    """Test of median method of Timers class"""
    timers = Timers()
    timers.add('foo', 1)
    timers.add('foo', 2)
    timers.add('foo', 3)
    timers.add('foo', 4)
    timers.add('foo', 5)
    timers.add('foo', 6)

    assert timers.median('foo') == 3.5

# Generated at 2022-06-11 20:16:41.653429
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("A", 1.0)
    timers.add("A", 5.0)
    timers.add("A", 3.0)
    timers.add("A", 5.0)
    assert timers.mean("A") == 3.5


# Generated at 2022-06-11 20:16:45.511979
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('first timer', 1)
    assert timers.max('first timer') == 1

    timers.add('first timer', 2)
    assert timers.max('first timer') == 2


# Generated at 2022-06-11 20:16:48.977501
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 2)
    assert timers.median("a") == 1.5



# Generated at 2022-06-11 20:17:39.581504
# Unit test for method median of class Timers
def test_Timers_median():
    """Test Timers instance median function."""

    # Create a Timers object
    timers = Timers()

    # Add some times to the Timers object
    timers.add("A", 1.0)
    timers.add("A", 2.0)
    timers.add("A", 3.0)
    timers.add("B", 4.0)
    timers.add("B", 5.0)

    # Check the median of all the timers
    assert timers.median("A") == 2.0
    assert timers.median("B") == 4.5
    assert timers.median("C") == math.nan


# Generated at 2022-06-11 20:17:42.566865
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add("A", 10)
    timers.add("A", 20)
    assert timers.mean("A") == 15


# Generated at 2022-06-11 20:17:48.259624
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("medianTimer", 5)
    timers.add("medianTimer", 6)
    timers.add("medianTimer", 5)
    assert timers["medianTimer"] == 16
    assert timers.median("medianTimer") == 5
    timers.add("medianTimer", 4)
    assert timers.median("medianTimer") == 5
    timers.add("medianTimer", 7)
    assert timers.median("medianTimer") == 5.5

# Generated at 2022-06-11 20:17:58.540318
# Unit test for method median of class Timers
def test_Timers_median():
    import pytest

    assert Timers().median("name") == 0
    assert Timers({"name": 1}).median("name") == 1
    assert Timers({"name": 1, "name": 2}).median("name") == 1.5
    assert Timers({"name": 1, "name": 2, "name": 3}).median("name") == 2
    assert Timers({"name": 1, "name": 2, "name": 3, "name": 4}).median("name") == 2.5
    # Method median delete the last element
    # It should not have an effect on the result
    Timers({"name": 1, "name": 2,  "name": 3, "name": 4}).median("name")
    with pytest.raises(KeyError):
        Timers().median

# Generated at 2022-06-11 20:18:08.445417
# Unit test for method median of class Timers
def test_Timers_median():
    """
    Method median() should return the median of a list of numbers
    """
    timers = Timers()
    timers.data = {
        "timer1": 1.0, "timer2": 2.0, "timer3": 3.0, "timer4": 4.0,
        "timer5": 5.0, "timer6": 6.0, "timer7": 7.0, "timer8": 8.0,
    }
    timers._timings = {
        name: [value] for name, value in timers.data.items()
    }
    assert math.isclose(timers.median("timer1"), 1.0)
    assert math.isclose(timers.median("timer2"), 2.0)
    assert math.isclose(timers.median("timer3"), 3.0)

# Generated at 2022-06-11 20:18:11.450093
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("close_crs", 4)
    timers.add("close_crs", 6)
    assert timers.max("close_crs") == 6


# Generated at 2022-06-11 20:18:14.545359
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('mytimer', 0.1)
    timers.add('mytimer', 0.2)
    assert timers.max('mytimer') == 0.2


# Generated at 2022-06-11 20:18:18.944067
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""

    # Create new timer
    timers = Timers()

    # Add new timer
    timers.add('min', 6)
    timers.add('min', 5)
    timers.add('min', 4)
    assert timers.min('min') == 4



# Generated at 2022-06-11 20:18:24.293426
# Unit test for method max of class Timers
def test_Timers_max():
    """Test to check max function of timers class works"""
    timer = Timers()
    timer.add('search', 3)
    timer.add('search', 5)
    timer.add('search', 2)
    timer.add('search', 4)
    timer.add('search', 1)
    assert timer.max('search') == 5
    timer.clear()
    

# Generated at 2022-06-11 20:18:26.543222
# Unit test for method min of class Timers
def test_Timers_min():
    T = Timers()
    T.add("min", 3)
    T.add("min", 2)
    T.add("min", 1)
    min = T.min("min")
    expected = 1
    assert min == expected

# Generated at 2022-06-11 20:20:20.336004
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""

    # Define a list of values
    values = [1.0, 2.0, 3.0, 4.0]
    # Define a named timer
    name = "test_name"
    # Create an instance of Timers
    timers = Timers()
    # Add values to the timer
    for value in values:
        timers.add(name, value)
    # Verify the minimum value
    assert timers.min(name) == min(values)


# Generated at 2022-06-11 20:20:29.063485
# Unit test for method min of class Timers
def test_Timers_min():
    """Check Timers.min()"""
    timers = Timers()
    timers._timings['foo'] = [1, 2, 3, 4]
    assert timers.min(name='foo') == min(timers._timings['foo'])

    timers = Timers()
    timers._timings['foo'] = []
    assert timers.min(name='foo') == 0

    timers = Timers()
    timers._timings['bar'] = [1, 2]
    assert timers.min(name='bar') == min(timers._timings['bar'])


# Generated at 2022-06-11 20:20:31.402969
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers._timings = {"test": [1, 2, 3]}
    assert len(timers._timings["test"]) == 3
    assert timers.median("test") == 2.0

# Generated at 2022-06-11 20:20:40.126542
# Unit test for method mean of class Timers
def test_Timers_mean():
    t1 = Timers()
    assert t1.mean("test") == 0
    assert t1.mean("test2") == 0
    t1.add("test", 10.1)
    assert t1.mean("test") == 10.1
    assert t1.mean("test2") == 0
    t1.add("test", 10.1)
    assert t1.mean("test") == 10.1
    assert t1.mean("test2") == 0
    t1.add("test", 10.1)
    assert t1.mean("test") == 10.1
    assert t1.mean("test2") == 0

# Generated at 2022-06-11 20:20:43.157273
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()

    t.add(name="min", value=1)
    assert t.min(name="min") == 1


# Generated at 2022-06-11 20:20:50.920998
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test that mean is correct with list of values"""
    # Arrange
    my_timer = Timers()
    my_timer.add("time1", 3)
    my_timer.add("time1", 5)
    my_timer.add("time1", 8)
    my_timer.add("time1", 12)
    my_timer.add("time1", 6)
    expected_result = 7
    # Act
    result = my_timer.mean("time1")
    # Assert
    assert result == expected_result

# Generated at 2022-06-11 20:20:58.639430
# Unit test for method median of class Timers
def test_Timers_median():
    """
    return:Test whether the median value will be returned
    """
    timers = Timers({'foo': 123, 'bar': 456})
    timers._timings['foo'].extend([1, 2, 3, 4])
    timers._timings['bar'].extend([4, 5, 6])

    assert timers.median('foo') == 2.5
    assert timers.median('bar') == 5

    assert timers.median('does_not_exist') == 0
    return True


# Generated at 2022-06-11 20:21:01.166764
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Setup
    t = Timers()
    t.add('test', 0.5)
    t.add('test', 0.5)

    # Test
    mean = t.mean('test')

    # Verify
    assert mean == 0.5, f'Error: wrong mean of Timers: {mean}, expected: 0.5'

# Generated at 2022-06-11 20:21:04.619045
# Unit test for method median of class Timers
def test_Timers_median():
    def test(alist: List[float]) -> float:
        t = Timers()
        t.add('test', 5)
        return t.median('test')
    assert test([5]) == 5
    assert test([1, 2, 3, 4, 5]) == 3

# Generated at 2022-06-11 20:21:08.904237
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add("src", [0.1, 0.2, 0.3, 0.4])
    assert timers.mean("src") == 0.25