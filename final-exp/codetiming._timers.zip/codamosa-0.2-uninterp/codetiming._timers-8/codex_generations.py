

# Generated at 2022-06-17 17:11:29.902232
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:11:33.351102
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:11:42.851990
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5

# Generated at 2022-06-17 17:11:47.915556
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:11:51.636846
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean method of Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2

# Generated at 2022-06-17 17:11:55.374359
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:11:59.266932
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean method of Timers class"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    assert timers.mean('test') == 1.5


# Generated at 2022-06-17 17:12:09.295114
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5


# Generated at 2022-06-17 17:12:13.403787
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:12:15.785099
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:12:22.496963
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean method of Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:12:26.319977
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median method of Timers class"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.median('test') == 2
    timers.add('test', 4)
    assert timers.median('test') == 2.5

# Generated at 2022-06-17 17:12:30.247756
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:12:34.859013
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:12:37.444766
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1.0)
    timers.add("test", 2.0)
    timers.add("test", 3.0)
    assert timers.min("test") == 1.0


# Generated at 2022-06-17 17:12:42.389797
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1.0)
    timers.add("test", 2.0)
    timers.add("test", 3.0)
    assert timers.max("test") == 3.0


# Generated at 2022-06-17 17:12:47.842704
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:12:50.362303
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:12:54.554286
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.median('test') == 2


# Generated at 2022-06-17 17:12:57.013608
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:13:02.741101
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:13:07.629597
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.mean('test') == 2


# Generated at 2022-06-17 17:13:10.512687
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:13:13.600738
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:13:17.617107
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:13:20.807113
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:13:23.875523
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:13:31.460199
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("timer1", 1)
    timers.add("timer1", 2)
    timers.add("timer1", 3)
    timers.add("timer2", 4)
    timers.add("timer2", 5)
    timers.add("timer2", 6)
    assert timers.min("timer1") == 1
    assert timers.min("timer2") == 4


# Generated at 2022-06-17 17:13:33.681908
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:13:38.381759
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2

# Generated at 2022-06-17 17:13:48.587035
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1.0)
    timers.add("test", 2.0)
    timers.add("test", 3.0)
    assert timers.mean("test") == 2.0

# Generated at 2022-06-17 17:13:53.176810
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:13:55.836486
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    assert timers.max('test') == 2


# Generated at 2022-06-17 17:13:58.692305
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:14:02.705784
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2

# Generated at 2022-06-17 17:14:06.721559
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.max('test') == 3
    assert timers.max('test2') == 0


# Generated at 2022-06-17 17:14:14.789449
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.median("test") == 1
    timers.add("test", 2)
    assert timers.median("test") == 1.5
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test")

# Generated at 2022-06-17 17:14:18.969423
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:14:21.661271
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:14:25.788442
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5

# Generated at 2022-06-17 17:14:38.400459
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median method of Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:14:41.869838
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("timer1", 1)
    timers.add("timer1", 2)
    timers.add("timer1", 3)
    assert timers.mean("timer1") == 2


# Generated at 2022-06-17 17:14:46.950488
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2

# Generated at 2022-06-17 17:14:50.112996
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:14:51.747115
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:15:02.116414
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5

# Generated at 2022-06-17 17:15:09.395211
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Create a Timers object
    timers = Timers()

    # Add some values to the timers
    timers.add("a", 1.0)
    timers.add("a", 2.0)
    timers.add("a", 3.0)
    timers.add("b", 4.0)
    timers.add("b", 5.0)
    timers.add("b", 6.0)

    # Check the mean value for the timers
    assert timers.mean("a") == 2.0
    assert timers.mean("b") == 5.0


# Generated at 2022-06-17 17:15:12.730740
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 0.1)
    assert timers.min('test') == 0.1
    timers.add('test', 0.2)
    assert timers.min('test') == 0.1


# Generated at 2022-06-17 17:15:15.504104
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:15:19.233392
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:15:50.712684
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5


# Generated at 2022-06-17 17:15:54.309134
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:15:58.633453
# Unit test for method max of class Timers
def test_Timers_max():
    """Unit test for method max of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    assert timers.max('test') == 2


# Generated at 2022-06-17 17:16:01.012309
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:16:05.832593
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:16:15.722287
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.median("test") == 1.5
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5

# Generated at 2022-06-17 17:16:19.898626
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:16:29.401380
# Unit test for method max of class Timers
def test_Timers_max():
    """Test max method of Timers class"""
    timers = Timers()
    timers.add("test", 1.0)
    assert timers.max("test") == 1.0
    timers.add("test", 2.0)
    assert timers.max("test") == 2.0
    timers.add("test", 3.0)
    assert timers.max("test") == 3.0
    timers.add("test", 2.0)
    assert timers.max("test") == 3.0
    timers.add("test", 1.0)
    assert timers.max("test") == 3.0
    timers.add("test", 0.0)
    assert timers.max("test") == 3.0


# Generated at 2022-06-17 17:16:32.390425
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:16:38.383193
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median method of Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5

# Generated at 2022-06-17 17:17:19.626199
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:17:21.993465
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:17:26.724009
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:17:30.481179
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean method of Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:17:33.201749
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:17:37.333653
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5

# Generated at 2022-06-17 17:17:42.396393
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean method of Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.mean("test") == 1.5


# Generated at 2022-06-17 17:17:47.127560
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.median("test") == 1
    timers.add("test", 2)
    assert timers.median("test") == 1.5
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test")

# Generated at 2022-06-17 17:17:54.294811
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:18:00.702542
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2

# Generated at 2022-06-17 17:19:27.130731
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    timers.add("test", 4)
    assert timers.median("test") == 2.5

# Generated at 2022-06-17 17:19:29.226639
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:19:31.638908
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:19:37.087304
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2

# Generated at 2022-06-17 17:19:39.871158
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 2)
    timers.add("a", 3)
    assert timers.min("a") == 1


# Generated at 2022-06-17 17:19:46.514756
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5

# Generated at 2022-06-17 17:19:51.219155
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:19:56.998626
# Unit test for method min of class Timers
def test_Timers_min():
    """Test the min method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:20:01.029760
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:20:05.427096
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2
