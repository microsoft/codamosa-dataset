

# Generated at 2022-06-17 17:11:31.057602
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:11:35.039994
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add('test', 1)
    assert timers.stdev('test') == math.nan
    timers.add('test', 2)
    assert timers.stdev('test') == 1.0
    timers.add('test', 3)
    assert timers.stdev('test') == 1.0

# Generated at 2022-06-17 17:11:43.779724
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    assert timers.stdev('test') == 0.5
    timers.add('test', 3)
    assert timers.stdev('test') == 1
    timers.add('test', 4)
    assert timers.stdev('test') == 1.2909944487358056
    timers.add('test', 5)
    assert timers.stdev('test') == 1.5811388300841898
    timers.add('test', 6)
    assert timers.stdev('test') == 1.8708286933869707
    timers.add('test', 7)
    assert timers.stdev('test') == 2.160246899469287
    timers.add('test', 8)
    assert timers.stdev

# Generated at 2022-06-17 17:11:48.044582
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:11:59.807107
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 2)
    timers.add("a", 3)
    timers.add("a", 4)
    assert timers.median("a") == 2.5
    timers.add("a", 5)
    assert timers.median("a") == 3
    timers.add("a", 6)
    assert timers.median("a") == 3.5
    timers.add("a", 7)
    assert timers.median("a") == 4
    timers.add("a", 8)
    assert timers.median("a") == 4.5
    timers.add("a", 9)
    assert timers.median("a") == 5
    timers.add("a", 10)
   

# Generated at 2022-06-17 17:12:03.077779
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.max('test') == 3


# Generated at 2022-06-17 17:12:06.846350
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:12:09.501596
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:12:17.985146
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.min("test") == 1
    timers.add("test", 2)
    assert timers.min("test") == 1
    timers.add("test", 3)
    assert timers.min("test") == 1
    timers.add("test", 4)
    assert timers.min("test") == 1
    timers.add("test", 5)
    assert timers.min("test") == 1
    timers.add("test", 6)
    assert timers.min("test") == 1
    timers.add("test", 7)
    assert timers.min("test") == 1
    timers.add("test", 8)
    assert timers.min("test") == 1
    timers.add("test", 9)
    assert timers

# Generated at 2022-06-17 17:12:27.386541
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.median('test') == 2
    timers.add('test', 4)
    assert timers.median('test') == 2.5
    timers.add('test', 5)
    assert timers.median('test') == 3
    timers.add('test', 6)
    assert timers.median('test') == 3.5
    timers.add('test', 7)
    assert timers.median('test') == 4
    timers.add('test', 8)
    assert timers.median('test') == 4.5
    timers.add('test', 9)
    assert timers.median('test') == 5

# Generated at 2022-06-17 17:12:38.273835
# Unit test for method median of class Timers
def test_Timers_median():
    """Test Timers.median()"""
    timers = Timers()
    timers.add("timer", 1)
    timers.add("timer", 2)
    timers.add("timer", 3)
    assert timers.median("timer") == 2
    timers.add("timer", 4)
    assert timers.median("timer") == 2.5
    timers.add("timer", 5)
    assert timers.median("timer") == 3
    timers.add("timer", 6)
    assert timers.median("timer") == 3.5
    timers.add("timer", 7)
    assert timers.median("timer") == 4
    timers.add("timer", 8)
    assert timers.median("timer") == 4.5
    timers.add("timer", 9)
    assert timers.median("timer") == 5
   

# Generated at 2022-06-17 17:12:43.730813
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:12:46.585522
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:12:50.362458
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:12:54.552657
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:12:56.469769
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:13:01.204638
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:13:04.274025
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean method of Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:13:06.956173
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    assert timers.mean('test') == 1.5


# Generated at 2022-06-17 17:13:09.848943
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:13:18.194375
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5


# Generated at 2022-06-17 17:13:30.040746
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5

# Generated at 2022-06-17 17:13:32.165316
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("foo", 1)
    timers.add("foo", 2)
    timers.add("foo", 3)
    assert timers.max("foo") == 3


# Generated at 2022-06-17 17:13:36.930382
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:13:39.407709
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:13:47.349774
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.min("test") == 1
    timers.add("test", 2)
    assert timers.min("test") == 1
    timers.add("test", 3)
    assert timers.min("test") == 1
    timers.add("test", 4)
    assert timers.min("test") == 1
    timers.add("test", 5)
    assert timers.min("test") == 1
    timers.add("test", 6)
    assert timers.min("test") == 1
    timers.add("test", 7)
    assert timers.min("test") == 1
    timers.add("test", 8)
    assert timers.min("test") == 1
    timers.add("test", 9)
    assert timers

# Generated at 2022-06-17 17:13:53.787902
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:13:56.350522
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:13:59.064681
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:14:10.069897
# Unit test for method median of class Timers
def test_Timers_median():
    """Test method median of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.median('test') == 2
    timers.add('test', 4)
    assert timers.median('test') == 2.5
    timers.add('test', 5)
    assert timers.median('test') == 3
    timers.add('test', 6)
    assert timers.median('test') == 3.5
    timers.add('test', 7)
    assert timers.median('test') == 4
    timers.add('test', 8)
    assert timers.median('test') == 4.5
    timers.add('test', 9)
    assert timers.median('test') == 5
   

# Generated at 2022-06-17 17:14:16.129480
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.mean("test") == 1.5


# Generated at 2022-06-17 17:14:19.922304
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('timer1', 1)
    timers.add('timer1', 2)
    timers.add('timer1', 3)
    assert timers.min('timer1') == 1


# Generated at 2022-06-17 17:14:23.122392
# Unit test for method max of class Timers
def test_Timers_max():
    """Unit test for method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:14:25.986934
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:14:30.505499
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:14:35.129174
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2

# Generated at 2022-06-17 17:14:38.250140
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1.0)
    timers.add("test", 2.0)
    assert timers.min("test") == 1.0


# Generated at 2022-06-17 17:14:44.670880
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:14:49.421447
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:15:00.237080
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    assert timers.min('test') == 1
    timers.add('test', 2)
    assert timers.min('test') == 1
    timers.add('test', 3)
    assert timers.min('test') == 1
    timers.add('test', 4)
    assert timers.min('test') == 1
    timers.add('test', 5)
    assert timers.min('test') == 1
    timers.add('test', 6)
    assert timers.min('test') == 1
    timers.add('test', 7)
    assert timers.min('test') == 1
    timers.add('test', 8)
    assert timers.min('test') == 1
    timers.add('test', 9)
    assert timers

# Generated at 2022-06-17 17:15:15.879306
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5

# Generated at 2022-06-17 17:15:20.548858
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:15:23.969164
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:15:27.172625
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:15:29.562179
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:15:33.080556
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:15:36.627381
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median method of Timers class"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    timers.add('test', 4)
    assert timers.median('test') == 2.5

# Generated at 2022-06-17 17:15:38.932196
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:15:50.955280
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    assert timers.mean("test") == 1
    timers.add("test", 2)
    assert timers.mean("test") == 1.5
    timers.add("test", 3)
    assert timers.mean("test") == 2
    timers.add("test", 4)
    assert timers.mean("test") == 2.5
    timers.add("test", 5)
    assert timers.mean("test") == 3
    timers.add("test", 6)
    assert timers.mean("test") == 3.5
    timers.add("test", 7)
    assert timers.mean("test") == 4
    timers.add("test", 8)
    assert timers.mean("test") == 4.5
    timers.add("test", 9)

# Generated at 2022-06-17 17:15:55.977604
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:16:13.483717
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    assert timers.mean('test') == 1.5
    assert timers.mean('test2') == 0


# Generated at 2022-06-17 17:16:19.043220
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    timers.add('test', 4)
    timers.add('test', 5)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:16:22.468672
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    timers = Timers()
    timers.add("test", 1.0)
    timers.add("test", 2.0)
    assert timers.min("test") == 1.0


# Generated at 2022-06-17 17:16:28.554081
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("timer1", 1)
    timers.add("timer1", 2)
    timers.add("timer1", 3)
    timers.add("timer2", 4)
    timers.add("timer2", 5)
    assert timers.max("timer1") == 3
    assert timers.max("timer2") == 5


# Generated at 2022-06-17 17:16:31.732277
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2.0


# Generated at 2022-06-17 17:16:34.534490
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2

# Generated at 2022-06-17 17:16:39.973189
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:16:46.412240
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.mean('test') == 2


# Generated at 2022-06-17 17:16:50.551241
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2

# Generated at 2022-06-17 17:16:53.303627
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:17:32.374877
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    assert timers.max("test") == 1
    timers.add("test", 2)
    assert timers.max("test") == 2
    timers.add("test", 3)
    assert timers.max("test") == 3
    timers.add("test", 4)
    assert timers.max("test") == 4
    timers.add("test", 5)
    assert timers.max("test") == 5
    timers.add("test", 6)
    assert timers.max("test") == 6
    timers.add("test", 7)
    assert timers.max("test") == 7
    timers.add("test", 8)
    assert timers.max("test") == 8
    timers.add("test", 9)
    assert timers.max("test") == 9

# Generated at 2022-06-17 17:17:40.729021
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("a", 1)
    t.add("a", 2)
    t.add("a", 3)
    t.add("a", 4)
    t.add("a", 5)
    t.add("b", 1)
    t.add("b", 2)
    t.add("b", 3)
    t.add("b", 4)
    t.add("b", 5)
    t.add("c", 1)
    t.add("c", 2)
    t.add("c", 3)
    t.add("c", 4)
    t.add("c", 5)
    assert t.min("a") == 1
    assert t.min("b") == 1
    assert t.min("c") == 1


# Generated at 2022-06-17 17:17:49.077057
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median method of Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3

# Generated at 2022-06-17 17:17:51.082127
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.max('test') == 3


# Generated at 2022-06-17 17:17:55.169772
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:18:03.122284
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:18:08.121561
# Unit test for method median of class Timers
def test_Timers_median():
    """Test method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5


# Generated at 2022-06-17 17:18:13.116271
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    assert timers.min("test") == 1
    timers.add("test", 2)
    assert timers.min("test") == 1
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:18:17.000559
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:18:19.772893
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:19:26.773634
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:19:28.875579
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.max('test') == 3


# Generated at 2022-06-17 17:19:30.798108
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2

# Generated at 2022-06-17 17:19:35.965387
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.mean("test") == 1.5


# Generated at 2022-06-17 17:19:39.174338
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:19:43.998409
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    assert timers.max('test') == 2


# Generated at 2022-06-17 17:19:54.357780
# Unit test for method median of class Timers
def test_Timers_median():
    """Test Timers.median()"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.median('test') == 2
    timers.add('test', 4)
    assert timers.median('test') == 2.5
    timers.add('test', 5)
    assert timers.median('test') == 3
    timers.add('test', 6)
    assert timers.median('test') == 3.5
    timers.add('test', 7)
    assert timers.median('test') == 4
    timers.add('test', 8)
    assert timers.median('test') == 4.5
    timers.add('test', 9)
    assert timers.median('test') == 5
   

# Generated at 2022-06-17 17:19:56.998614
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:20:01.550900
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:20:04.185931
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
