

# Generated at 2022-06-17 17:11:30.316454
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean method of Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:11:33.008414
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:11:42.598003
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median method of Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5
   

# Generated at 2022-06-17 17:11:46.733779
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:11:50.789729
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add("timer1", 1)
    timers.add("timer1", 2)
    timers.add("timer1", 3)
    assert timers.mean("timer1") == 2


# Generated at 2022-06-17 17:11:54.582516
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:11:57.655856
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:12:01.051259
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:12:04.403738
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:12:08.028910
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.mean('test') == 2


# Generated at 2022-06-17 17:12:13.887209
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:12:16.182084
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:12:26.571391
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5


# Generated at 2022-06-17 17:12:29.660940
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:12:35.012186
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean method of Timers class"""
    timers = Timers()
    timers.add('timer1', 1)
    timers.add('timer1', 2)
    timers.add('timer2', 3)
    timers.add('timer2', 4)
    assert timers.mean('timer1') == 1.5
    assert timers.mean('timer2') == 3.5


# Generated at 2022-06-17 17:12:37.596503
# Unit test for method max of class Timers
def test_Timers_max():
    """Test the method max of class Timers"""
    timers = Timers()
    timers.add("timer1", 1.0)
    timers.add("timer1", 2.0)
    timers.add("timer1", 3.0)
    assert timers.max("timer1") == 3.0


# Generated at 2022-06-17 17:12:47.768105
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.min("test") == 1
    timers.add("test", 2)
    assert timers.min("test") == 1
    timers.add("test", 3)
    assert timers.min("test") == 1
    timers.add("test", 4)
    assert timers.min("test") == 1
    timers.add("test", 5)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:12:54.486968
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    # Create a Timers object
    timers = Timers()
    # Add a timing
    timers.add("test", 1.0)
    # Check the mean
    assert timers.mean("test") == 1.0
    # Add another timing
    timers.add("test", 2.0)
    # Check the mean
    assert timers.mean("test") == 1.5
    # Add another timing
    timers.add("test", 3.0)
    # Check the mean
    assert timers.mean("test") == 2.0
    # Add another timing
    timers.add("test", 4.0)
    # Check the mean
    assert timers.mean("test") == 2.5
    # Add another timing
    timers.add("test", 5.0)
    # Check the mean
   

# Generated at 2022-06-17 17:12:57.243584
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2

# Generated at 2022-06-17 17:13:01.917843
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:13:13.568136
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5

# Generated at 2022-06-17 17:13:17.289934
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.mean("test") == 1.5



# Generated at 2022-06-17 17:13:19.930010
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:13:22.616614
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median of Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:13:28.049278
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:13:30.749876
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:13:33.161212
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:13:37.893717
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.mean("test") == 1.5


# Generated at 2022-06-17 17:13:44.081881
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:13:49.221547
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.mean("test") == 1.5
    assert timers.mean("test2") == 0


# Generated at 2022-06-17 17:13:54.418546
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:13:57.304468
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add("foo", 1)
    timers.add("foo", 2)
    timers.add("foo", 3)
    assert timers.mean("foo") == 2


# Generated at 2022-06-17 17:13:59.507348
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:14:06.031563
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    # Create a Timers object
    timers = Timers()

    # Add some timings
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    timers.add("test", 4)
    timers.add("test", 5)

    # Check the median
    assert timers.median("test") == 3

# Generated at 2022-06-17 17:14:10.218170
# Unit test for method median of class Timers
def test_Timers_median():
    """Test method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:14:12.124524
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:14:18.873347
# Unit test for method median of class Timers
def test_Timers_median():
    """Test method median of class Timers"""
    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 2)
    timers.add("a", 3)
    timers.add("a", 4)
    timers.add("a", 5)
    assert timers.median("a") == 3
    timers.add("a", 6)
    assert timers.median("a") == 3.5
    timers.add("a", 7)
    assert timers.median("a") == 4
    timers.add("a", 8)
    assert timers.median("a") == 4.5
    timers.add("a", 9)
    assert timers.median("a") == 5
    timers.add("a", 10)
    assert timers.median("a") == 5.5

# Generated at 2022-06-17 17:14:21.499402
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.mean("test") == 1.5


# Generated at 2022-06-17 17:14:24.527057
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2
    assert timers.max("test2") == 0


# Generated at 2022-06-17 17:14:28.623474
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:14:39.097689
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:14:43.448757
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.mean("test") == 1.5
    assert timers.mean("test2") == 0

# Generated at 2022-06-17 17:14:52.011280
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    from pytest import approx

    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 2)
    timers.add("a", 3)
    timers.add("a", 4)
    timers.add("a", 5)
    timers.add("a", 6)
    timers.add("a", 7)
    timers.add("a", 8)
    timers.add("a", 9)
    timers.add("a", 10)
    timers.add("a", 11)
    timers.add("a", 12)
    timers.add("a", 13)
    timers.add("a", 14)
    timers.add("a", 15)
    timers.add("a", 16)
    timers.add("a", 17)
    timers

# Generated at 2022-06-17 17:14:57.879610
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("timer1", 1)
    timers.add("timer1", 2)
    timers.add("timer1", 3)
    timers.add("timer2", 4)
    timers.add("timer2", 5)
    timers.add("timer2", 6)
    assert timers.min("timer1") == 1
    assert timers.min("timer2") == 4


# Generated at 2022-06-17 17:15:02.233800
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:15:12.337664
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 0)
    assert timers.min('test') == 0
    timers.add('test', 1)
    assert timers.min('test') == 0
    timers.add('test', 2)
    assert timers.min('test') == 0
    timers.add('test', 3)
    assert timers.min('test') == 0
    timers.add('test', 4)
    assert timers.min('test') == 0
    timers.add('test', 5)
    assert timers.min('test') == 0
    timers.add('test', 6)
    assert timers.min('test') == 0
    timers.add('test', 7)
    assert timers.min('test') == 0
    timers.add('test', 8)
    assert timers.min('test') == 0

# Generated at 2022-06-17 17:15:17.214676
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:15:21.443910
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:15:24.747113
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.mean('test') == 2


# Generated at 2022-06-17 17:15:27.632744
# Unit test for method max of class Timers
def test_Timers_max():
    """Test the max method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:15:46.919469
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:15:50.099410
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:15:52.351689
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:15:54.468715
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.mean('test') == 2


# Generated at 2022-06-17 17:15:57.002197
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1.0)
    timers.add("test", 2.0)
    timers.add("test", 3.0)
    assert timers.min("test") == 1.0


# Generated at 2022-06-17 17:16:01.892837
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 0)
    assert timers.min("test") == 0
    timers.add("test", 1)
    assert timers.min("test") == 0
    timers.add("test", -1)
    assert timers.min("test") == -1
    timers.add("test", 2)
    assert timers.min("test") == -1
    timers.add("test", -2)
    assert timers.min("test") == -2
    timers.add("test", 3)
    assert timers.min("test") == -2
    timers.add("test", -3)
    assert timers.min("test") == -3
    timers.add("test", 4)
    assert timers.min("test") == -3
    timers.add

# Generated at 2022-06-17 17:16:07.126746
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:16:09.788410
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2

# Generated at 2022-06-17 17:16:14.927201
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.median('test') == 2
    timers.add('test', 4)
    assert timers.median('test') == 2.5
    timers.add('test', 5)
    assert timers.median('test') == 3
    timers.add('test', 6)
    assert timers.median('test') == 3.5
    timers.add('test', 7)
    assert timers.median('test') == 4
    timers.add('test', 8)
    assert timers.median('test') == 4.5
    timers.add('test', 9)
    assert timers.median('test') == 5

# Generated at 2022-06-17 17:16:18.947944
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add("test", 1)
    t.add("test", 2)
    t.add("test", 3)
    assert t.mean("test") == 2


# Generated at 2022-06-17 17:16:49.900230
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:16:51.637146
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:16:56.311018
# Unit test for method max of class Timers
def test_Timers_max():
    """Test the max method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:17:00.315294
# Unit test for method max of class Timers
def test_Timers_max():
    """Test the method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:17:03.457002
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2

# Generated at 2022-06-17 17:17:07.495618
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:17:11.228095
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("foo", 1)
    timers.add("foo", 2)
    timers.add("foo", 3)
    assert timers.mean("foo") == 2


# Generated at 2022-06-17 17:17:21.840034
# Unit test for method median of class Timers
def test_Timers_median():
    """Test Timers.median()"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5
   

# Generated at 2022-06-17 17:17:26.685395
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:17:29.583257
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:18:38.871878
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5

# Generated at 2022-06-17 17:18:43.030347
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.mean('test') == 2


# Generated at 2022-06-17 17:18:48.439101
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:18:51.403460
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median method of Timers class"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.median('test') == 2


# Generated at 2022-06-17 17:18:53.400236
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:19:00.546258
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:19:12.241075
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median method of Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5
   

# Generated at 2022-06-17 17:19:23.504174
# Unit test for method median of class Timers
def test_Timers_median():
    """Test Timers.median()"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5
   

# Generated at 2022-06-17 17:19:26.050167
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:19:28.109128
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3
