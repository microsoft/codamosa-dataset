

# Generated at 2022-06-17 17:11:23.836503
# Unit test for method median of class Timers
def test_Timers_median():
    """Test Timers.median"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2

# Generated at 2022-06-17 17:11:34.376253
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.stdev("test") == 1
    timers.add("test", 4)
    assert timers.stdev("test") == 1.2909944487358056
    timers.add("test", 5)
    assert timers.stdev("test") == 1.5811388300841898
    timers.add("test", 6)
    assert timers.stdev("test") == 1.8708286933869707
    timers.add("test", 7)
    assert timers.stdev("test") == 2.160246899469287
    timers.add("test", 8)

# Generated at 2022-06-17 17:11:43.378185
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.stdev("test") == math.nan
    timers.add("test", 2)
    assert timers.stdev("test") == 0.5
    timers.add("test", 3)
    assert timers.stdev("test") == 0.816496580927726
    timers.add("test", 4)
    assert timers.stdev("test") == 1.118033988749895
    timers.add("test", 5)
    assert timers.stdev("test") == 1.4142135623730951
    timers.add("test", 6)
    assert timers.stdev("test") == 1.707825127659933
    timers.add("test", 7)
    assert timers

# Generated at 2022-06-17 17:11:49.794000
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.stdev("test") == math.nan
    timers.add("test", 2)
    assert timers.stdev("test") == 0.5
    timers.add("test", 3)
    assert timers.stdev("test") == 1

# Generated at 2022-06-17 17:12:01.052502
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.stdev("test") == 0
    timers.add("test", 2)
    assert timers.stdev("test") == 0.5
    timers.add("test", 3)
    assert timers.stdev("test") == 1
    timers.add("test", 4)
    assert timers.stdev("test") == 1.2909944487358056
    timers.add("test", 5)
    assert timers.stdev("test") == 1.5811388300841898
    timers.add("test", 6)
    assert timers.stdev("test") == 1.8708286933869707
    timers.add("test", 7)
    assert timers.stdev("test") == 2

# Generated at 2022-06-17 17:12:05.275885
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.mean('test') == 2


# Generated at 2022-06-17 17:12:08.764898
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:12:12.870940
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:12:15.885240
# Unit test for method max of class Timers
def test_Timers_max():
    """Test the max method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:12:20.186124
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:12:30.904168
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5

# Generated at 2022-06-17 17:12:36.958446
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("timer1", 1)
    timers.add("timer1", 2)
    timers.add("timer1", 3)
    timers.add("timer2", 4)
    timers.add("timer2", 5)
    assert timers.max("timer1") == 3
    assert timers.max("timer2") == 5


# Generated at 2022-06-17 17:12:41.155194
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.mean("test") == 1.5


# Generated at 2022-06-17 17:12:46.616849
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:12:50.250820
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:12:54.418401
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add("foo", 1)
    timers.add("foo", 2)
    timers.add("foo", 3)
    assert timers.mean("foo") == 2


# Generated at 2022-06-17 17:13:03.678955
# Unit test for method median of class Timers
def test_Timers_median():
    """Test method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5
   

# Generated at 2022-06-17 17:13:08.816459
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    assert timers.min("test") == 0
    timers.add("test", 1)
    assert timers.min("test") == 1
    timers.add("test", 2)
    assert timers.min("test") == 1
    timers.add("test", 0)
    assert timers.min("test") == 0
    timers.add("test", -1)
    assert timers.min("test") == -1


# Generated at 2022-06-17 17:13:12.543247
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median method of Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5

# Generated at 2022-06-17 17:13:22.185666
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    assert timers.max("test") == 1
    timers.add("test", 2)
    assert timers.max("test") == 2
    timers.add("test", 3)
    assert timers.max("test") == 3
    timers.add("test", 4)
    assert timers.max("test") == 4
    timers.add("test", 5)
    assert timers.max("test") == 5
    timers.add("test", 6)
    assert timers.max("test") == 6
    timers.add("test", 7)
    assert timers.max("test") == 7
    timers.add("test", 8)
    assert timers.max("test") == 8
    timers.add("test", 9)
    assert timers.max("test") == 9

# Generated at 2022-06-17 17:13:31.899725
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5

# Generated at 2022-06-17 17:13:36.517045
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:13:39.224378
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:13:46.515714
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.min("test") == 1
    timers.add("test", 2)
    assert timers.min("test") == 1
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:13:49.334825
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.max('test') == 3


# Generated at 2022-06-17 17:13:53.959164
# Unit test for method min of class Timers
def test_Timers_min():
    """Test the min method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:13:56.521057
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:13:58.175764
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    assert timers.max("test") == 1


# Generated at 2022-06-17 17:14:02.303893
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median method of Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:14:05.198933
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:14:13.880439
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    assert timers.median("test2") == 0


# Generated at 2022-06-17 17:14:19.239376
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("timer1", 1.0)
    timers.add("timer1", 2.0)
    timers.add("timer1", 3.0)
    assert timers.min("timer1") == 1.0
    assert timers.min("timer2") == 0.0


# Generated at 2022-06-17 17:14:22.211336
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2

# Generated at 2022-06-17 17:14:24.021502
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add("test", 1)
    t.add("test", 2)
    assert t.mean("test") == 1.5


# Generated at 2022-06-17 17:14:28.795480
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:14:36.207245
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    assert timers.max("test") == 1
    timers.add("test", 2)
    assert timers.max("test") == 2
    timers.add("test", 3)
    assert timers.max("test") == 3
    timers.add("test", 4)
    assert timers.max("test") == 4
    timers.add("test", 5)
    assert timers.max("test") == 5
    timers.add("test", 6)
    assert timers.max("test") == 6
    timers.add("test", 7)
    assert timers.max("test") == 7
    timers.add("test", 8)
    assert timers.max("test") == 8
    timers.add("test", 9)
    assert timers.max("test") == 9

# Generated at 2022-06-17 17:14:38.817521
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:14:42.816034
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:14:47.303249
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:14:57.970629
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.mean("test") == 1
    timers.add("test", 2)
    assert timers.mean("test") == 1.5
    timers.add("test", 3)
    assert timers.mean("test") == 2
    timers.add("test", 4)
    assert timers.mean("test") == 2.5
    timers.add("test", 5)
    assert timers.mean("test") == 3
    timers.add("test", 6)
    assert timers.mean("test") == 3.5
    timers.add("test", 7)
    assert timers.mean("test") == 4
    timers.add("test", 8)
    assert timers.mean("test") == 4.5

# Generated at 2022-06-17 17:15:06.380092
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.max('test') == 3


# Generated at 2022-06-17 17:15:09.720123
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:15:12.691535
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:15:18.042775
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add('a', 1)
    t.add('a', 2)
    t.add('a', 3)
    t.add('a', 4)
    t.add('a', 5)
    assert t.mean('a') == 3


# Generated at 2022-06-17 17:15:21.586826
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.mean("test") == 1.5


# Generated at 2022-06-17 17:15:24.897925
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("timer1", 1)
    timers.add("timer1", 2)
    timers.add("timer1", 3)
    timers.add("timer1", 4)
    assert timers.mean("timer1") == 2.5


# Generated at 2022-06-17 17:15:32.645384
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test', 1)
    assert timers.max('test') == 1
    timers.add('test', 2)
    assert timers.max('test') == 2
    timers.add('test', 3)
    assert timers.max('test') == 3
    timers.add('test', 4)
    assert timers.max('test') == 4
    timers.add('test', 5)
    assert timers.max('test') == 5
    timers.add('test', 6)
    assert timers.max('test') == 6
    timers.add('test', 7)
    assert timers.max('test') == 7
    timers.add('test', 8)
    assert timers.max('test') == 8
    timers.add('test', 9)
    assert timers.max('test') == 9

# Generated at 2022-06-17 17:15:40.507145
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    assert timers.median("test") == statistics.median([1, 2, 3])
    assert timers.median("test") == statistics.median([1, 2, 3])
    assert timers.median("test") == statistics.median([1, 2, 3])
    assert timers.median("test") == statistics.median([1, 2, 3])
    assert timers.median("test") == statistics.median([1, 2, 3])
    assert timers.median("test") == statistics.median([1, 2, 3])
    assert timers.med

# Generated at 2022-06-17 17:15:44.917239
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:15:48.851519
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("timer1", 1)
    timers.add("timer1", 2)
    timers.add("timer1", 3)
    assert timers.max("timer1") == 3


# Generated at 2022-06-17 17:16:02.315727
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:16:07.288939
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add('test', 1.0)
    timers.add('test', 2.0)
    assert timers.mean('test') == 1.5


# Generated at 2022-06-17 17:16:10.599048
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1.0)
    timers.add("test", 2.0)
    timers.add("test", 3.0)
    assert timers.mean("test") == 2.0

# Generated at 2022-06-17 17:16:21.521498
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median method of Timers class"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.median('test') == 2
    timers.add('test', 4)
    assert timers.median('test') == 2.5
    timers.add('test', 5)
    assert timers.median('test') == 3
    timers.add('test', 6)
    assert timers.median('test') == 3.5
    timers.add('test', 7)
    assert timers.median('test') == 4
    timers.add('test', 8)
    assert timers.median('test') == 4.5
    timers.add('test', 9)
    assert timers.median('test') == 5
   

# Generated at 2022-06-17 17:16:26.077888
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of class Timers"""
    # Initialize a Timers object
    timers = Timers()
    # Add some values to the timers
    timers.add("timer1", 1)
    timers.add("timer1", 2)
    timers.add("timer1", 3)
    timers.add("timer1", 4)
    timers.add("timer1", 5)
    timers.add("timer1", 6)
    timers.add("timer1", 7)
    timers.add("timer1", 8)
    timers.add("timer1", 9)
    timers.add("timer1", 10)
    # Check the median
    assert timers.median("timer1") == 5.5


# Generated at 2022-06-17 17:16:29.959196
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:16:33.334383
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:16:38.791340
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:16:52.298336
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    assert timers.max("test") == 1
    timers.add("test", 2)
    assert timers.max("test") == 2
    timers.add("test", 3)
    assert timers.max("test") == 3
    timers.add("test", 4)
    assert timers.max("test") == 4
    timers.add("test", 5)
    assert timers.max("test") == 5
    timers.add("test", 6)
    assert timers.max("test") == 6
    timers.add("test", 7)
    assert timers.max("test") == 7
    timers.add("test", 8)
    assert timers.max("test") == 8
    timers.add("test", 9)
    assert timers.max("test") == 9

# Generated at 2022-06-17 17:16:57.744647
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.median('test') == 2
    timers.add('test', 4)
    assert timers.median('test') == 2.5

# Generated at 2022-06-17 17:17:26.840393
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5

# Generated at 2022-06-17 17:17:30.601415
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.max('test') == 3


# Generated at 2022-06-17 17:17:32.820217
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:17:36.356339
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:17:39.228752
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 2)
    timers.add("a", 3)
    assert timers.mean("a") == 2


# Generated at 2022-06-17 17:17:44.781561
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:17:49.633167
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:17:53.069403
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("foo", 1)
    timers.add("foo", 2)
    timers.add("foo", 3)
    timers.add("bar", 4)
    timers.add("bar", 5)
    timers.add("bar", 6)
    assert timers.max("foo") == 3
    assert timers.max("bar") == 6


# Generated at 2022-06-17 17:17:56.331821
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:18:03.128528
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:18:52.018075
# Unit test for method min of class Timers
def test_Timers_min():
    """Test the method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:18:56.010156
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:18:59.897497
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.mean("test") == 1.5


# Generated at 2022-06-17 17:19:03.243272
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.max('test') == 3


# Generated at 2022-06-17 17:19:07.607277
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    assert timers.mean('test') == 1.5


# Generated at 2022-06-17 17:19:10.979622
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:19:14.075558
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("timer1", 1)
    timers.add("timer1", 2)
    assert timers.max("timer1") == 2
    assert timers.max("timer2") == 0


# Generated at 2022-06-17 17:19:19.189239
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:19:27.129915
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add('a', 1)
    timers.add('a', 2)
    timers.add('a', 3)
    timers.add('b', 4)
    timers.add('b', 5)
    assert timers.max('a') == 3
    assert timers.max('b') == 5
    assert timers.max('c') == 0


# Generated at 2022-06-17 17:19:28.939156
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:21:13.866561
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.min("test") == 1
    timers.add("test", 2)
    assert timers.min("test") == 1
    timers.add("test", 3)
    assert timers.min("test") == 1
    timers.add("test", 4)
    assert timers.min("test") == 1
    timers.add("test", 5)
    assert timers.min("test") == 1
    timers.add("test", 6)
    assert timers.min("test") == 1
    timers.add("test", 7)
    assert timers.min("test") == 1
    timers.add("test", 8)
    assert timers.min("test") == 1
    timers.add("test", 9)
    assert timers

# Generated at 2022-06-17 17:21:18.649672
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of class Timers"""
    timers = Timers()
    timers.add("timer1", 1.0)
    timers.add("timer1", 2.0)
    timers.add("timer1", 3.0)
    assert timers.mean("timer1") == 2.0
    assert timers.mean("timer2") == 0.0
