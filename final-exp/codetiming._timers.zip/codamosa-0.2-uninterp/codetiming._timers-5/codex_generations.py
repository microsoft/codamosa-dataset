

# Generated at 2022-06-17 17:11:28.452398
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:11:30.346167
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:11:40.194240
# Unit test for method median of class Timers
def test_Timers_median():
    """Test method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5
   

# Generated at 2022-06-17 17:11:44.069172
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add('foo', 1)
    timers.add('foo', 2)
    assert timers.median('foo') == 1.5
    timers.add('foo', 3)
    assert timers.median('foo') == 2
    timers.add('foo', 4)
    assert timers.median('foo') == 2.5
    timers.add('foo', 5)
    assert timers.median('foo') == 3
    timers.add('foo', 6)
    assert timers.median('foo') == 3.5
    timers.add('foo', 7)
    assert timers.median('foo') == 4
    timers.add('foo', 8)
    assert timers.median('foo') == 4.5

# Generated at 2022-06-17 17:11:46.912717
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:11:50.183594
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:11:56.768382
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3

# Generated at 2022-06-17 17:12:07.610855
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    assert timers.max('test') == 1
    timers.add('test', 2)
    assert timers.max('test') == 2
    timers.add('test', 3)
    assert timers.max('test') == 3
    timers.add('test', 4)
    assert timers.max('test') == 4
    timers.add('test', 5)
    assert timers.max('test') == 5
    timers.add('test', 6)
    assert timers.max('test') == 6
    timers.add('test', 7)
    assert timers.max('test') == 7
    timers.add('test', 8)
    assert timers.max('test') == 8
    timers.add('test', 9)
    assert timers

# Generated at 2022-06-17 17:12:11.647315
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median method of Timers class"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.median('test') == 2


# Generated at 2022-06-17 17:12:14.254490
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:12:20.233002
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("foo", 1)
    timers.add("foo", 2)
    timers.add("foo", 3)
    assert timers.min("foo") == 1


# Generated at 2022-06-17 17:12:23.946624
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:12:27.937346
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.max('test') == 3


# Generated at 2022-06-17 17:12:30.668693
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.mean('test') == 2


# Generated at 2022-06-17 17:12:35.092702
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    assert timers.mean('test') == 1.5


# Generated at 2022-06-17 17:12:37.909459
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:12:44.013787
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2
    assert timers.mean("test2") == 0


# Generated at 2022-06-17 17:12:48.939620
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:12:55.429424
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    assert timers.min('test') == 1
    timers.add('test', 2)
    assert timers.min('test') == 1
    timers.add('test', 3)
    assert timers.min('test') == 1
    timers.add('test', 4)
    assert timers.min('test') == 1
    timers.add('test', 5)
    assert timers.min('test') == 1
    timers.add('test', 6)
    assert timers.min('test') == 1
    timers.add('test', 7)
    assert timers.min('test') == 1
    timers.add('test', 8)
    assert timers.min('test') == 1
    timers.add('test', 9)
    assert timers.min('test') == 1

# Generated at 2022-06-17 17:12:59.472277
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.mean("test") == 1.5


# Generated at 2022-06-17 17:13:04.310874
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:13:07.793605
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median method of Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:13:13.719315
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5
   

# Generated at 2022-06-17 17:13:18.379526
# Unit test for method median of class Timers
def test_Timers_median():
    """Test method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:13:30.040773
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('test', 1)
    assert timers.mean('test') == 1
    timers.add('test', 2)
    assert timers.mean('test') == 1.5
    timers.add('test', 3)
    assert timers.mean('test') == 2
    timers.add('test', 4)
    assert timers.mean('test') == 2.5
    timers.add('test', 5)
    assert timers.mean('test') == 3
    timers.add('test', 6)
    assert timers.mean('test') == 3.5
    timers.add('test', 7)
    assert timers.mean('test') == 4
    timers.add('test', 8)
    assert timers.mean('test') == 4.5
    timers.add('test', 9)

# Generated at 2022-06-17 17:13:32.804326
# Unit test for method median of class Timers
def test_Timers_median():
    """Test Timers.median()"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2

# Generated at 2022-06-17 17:13:44.509822
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.max("test") == 1
    timers.add("test", 2)
    assert timers.max("test") == 2
    timers.add("test", 3)
    assert timers.max("test") == 3
    timers.add("test", 4)
    assert timers.max("test") == 4
    timers.add("test", 5)
    assert timers.max("test") == 5
    timers.add("test", 6)
    assert timers.max("test") == 6
    timers.add("test", 7)
    assert timers.max("test") == 7
    timers.add("test", 8)
    assert timers.max("test") == 8
    timers.add("test", 9)
    assert timers

# Generated at 2022-06-17 17:13:52.432532
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.max("test") == 1
    timers.add("test", 2)
    assert timers.max("test") == 2
    timers.add("test", 3)
    assert timers.max("test") == 3
    timers.add("test", 4)
    assert timers.max("test") == 4
    timers.add("test", 5)
    assert timers.max("test") == 5


# Generated at 2022-06-17 17:13:56.024910
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:13:58.535608
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.mean("test") == 1.5


# Generated at 2022-06-17 17:14:04.746822
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:14:08.538651
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:14:15.141184
# Unit test for method min of class Timers
def test_Timers_min():
    """Test min method of Timers class"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.min("test") == 1
    timers.add("test", 2)
    assert timers.min("test") == 1
    timers.add("test", 0)
    assert timers.min("test") == 0
    timers.add("test", -1)
    assert timers.min("test") == -1
    timers.add("test", -2)
    assert timers.min("test") == -2
    timers.add("test", -3)
    assert timers.min("test") == -3
    timers.add("test", -4)
    assert timers.min("test") == -4
    timers.add("test", -5)
    assert timers.min("test") == -5

# Generated at 2022-06-17 17:14:18.922394
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    timers.add("test", 4)
    assert timers.median("test") == 2.5

# Generated at 2022-06-17 17:14:22.250887
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1
    assert timers.min("test2") == 0


# Generated at 2022-06-17 17:14:24.983302
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:14:29.504232
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:14:32.330454
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:14:37.172501
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:14:42.300916
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:14:49.291598
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1.0)
    timers.add("test", 2.0)
    assert timers.max("test") == 2.0


# Generated at 2022-06-17 17:15:00.115534
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5

# Generated at 2022-06-17 17:15:04.568657
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1
    assert timers.min("test2") == 0


# Generated at 2022-06-17 17:15:07.342937
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:15:11.326109
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1
    assert timers.min("test2") == 0


# Generated at 2022-06-17 17:15:14.120291
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.mean("test") == 1.5


# Generated at 2022-06-17 17:15:16.991073
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:15:21.367597
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2

# Generated at 2022-06-17 17:15:22.636579
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:15:24.937405
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.mean("test") == 1.5


# Generated at 2022-06-17 17:15:36.263802
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean method of Timers class"""
    timers = Timers()
    timers.add("test", 1.0)
    timers.add("test", 2.0)
    timers.add("test", 3.0)
    assert timers.mean("test") == 2.0

# Generated at 2022-06-17 17:15:39.130585
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("foo", 1)
    timers.add("foo", 2)
    timers.add("foo", 3)
    assert timers.mean("foo") == 2
    assert timers.mean("bar") == 0


# Generated at 2022-06-17 17:15:42.248387
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:15:45.229041
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.mean('test') == 2


# Generated at 2022-06-17 17:15:49.626302
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    timers = Timers()
    timers.add("foo", 1)
    timers.add("foo", 2)
    timers.add("foo", 3)
    assert timers.min("foo") == 1


# Generated at 2022-06-17 17:15:51.630483
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:15:55.706190
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:15:59.592418
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:16:02.262993
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:16:07.576517
# Unit test for method max of class Timers
def test_Timers_max():
    """Test the max method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:16:26.614180
# Unit test for method max of class Timers
def test_Timers_max():
    """Test for method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2
    assert timers.max("test2") == 0


# Generated at 2022-06-17 17:16:30.075529
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.min('test') == 1


# Generated at 2022-06-17 17:16:32.969101
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-17 17:16:35.812648
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:16:40.970458
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2


# Generated at 2022-06-17 17:16:49.862732
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3

# Generated at 2022-06-17 17:16:51.800404
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.mean("test") == 1.5


# Generated at 2022-06-17 17:16:54.320869
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.mean('test') == 2


# Generated at 2022-06-17 17:17:05.380918
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5

# Generated at 2022-06-17 17:17:09.644113
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5


# Generated at 2022-06-17 17:17:42.364772
# Unit test for method max of class Timers
def test_Timers_max():
    """Unit test for method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:17:48.632750
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.max("test") == 1
    timers.add("test", 2)
    assert timers.max("test") == 2
    timers.add("test", 3)
    assert timers.max("test") == 3
    timers.add("test", 4)
    assert timers.max("test") == 4
    timers.add("test", 5)
    assert timers.max("test") == 5
    timers.add("test", 6)
    assert timers.max("test") == 6
    timers.add("test", 7)
    assert timers.max("test") == 7
    timers.add("test", 8)
    assert timers.max("test") == 8
    timers.add("test", 9)
    assert timers

# Generated at 2022-06-17 17:17:59.330231
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5
    timers.add("test", 5)
    assert timers.median("test") == 3
    timers.add("test", 6)
    assert timers.median("test") == 3.5
    timers.add("test", 7)
    assert timers.median("test") == 4
    timers.add("test", 8)
    assert timers.median("test") == 4.5
    timers.add("test", 9)
    assert timers.median("test") == 5

# Generated at 2022-06-17 17:18:01.848420
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:18:04.810838
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:18:09.234063
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.min("test") == 1
    timers.add("test", 2)
    assert timers.min("test") == 1
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:18:13.740760
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:18:18.370225
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
    timers.add("test", 4)
    assert timers.median("test") == 2.5

# Generated at 2022-06-17 17:18:21.339958
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:18:25.886463
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1.0)
    timers.add("test", 2.0)
    timers.add("test", 3.0)
    assert timers.mean("test") == 2.0

# Generated at 2022-06-17 17:19:37.667287
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of the Timers class"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.mean('test') == 2


# Generated at 2022-06-17 17:19:43.612965
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean() method of Timers class"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.mean('test') == 2


# Generated at 2022-06-17 17:19:46.744876
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("timer1", 1)
    timers.add("timer1", 2)
    timers.add("timer1", 3)
    timers.add("timer2", 4)
    timers.add("timer2", 5)
    assert timers.max("timer1") == 3
    assert timers.max("timer2") == 5


# Generated at 2022-06-17 17:19:50.688447
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('a', 1)
    timers.add('a', 2)
    timers.add('a', 3)
    assert timers.min('a') == 1


# Generated at 2022-06-17 17:19:56.473489
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:20:00.999597
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:20:04.584930
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-17 17:20:08.348127
# Unit test for method max of class Timers
def test_Timers_max():
    """Test the max method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.max("test") == 3


# Generated at 2022-06-17 17:20:10.631040
# Unit test for method min of class Timers
def test_Timers_min():
    """Test min method of Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.min("test") == 1


# Generated at 2022-06-17 17:20:15.788057
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median method of the Timers class"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2
