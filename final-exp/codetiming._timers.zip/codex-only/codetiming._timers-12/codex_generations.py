

# Generated at 2022-06-23 16:01:54.390087
# Unit test for method total of class Timers
def test_Timers_total():
    print('## Testing total...')

    timing = Timers()
    timing.add('Start simulation', 2.3)
    timing.add('Start simulation', 1.1)
    timing.add('Start simulation', 1.0)

    assert timing.total('Start simulation') == 4.4, 'Total is wrong'
    print('Total is correctly counted.')



# Generated at 2022-06-23 16:01:55.858650
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert len(timers._timings) == 0


# Generated at 2022-06-23 16:01:58.952602
# Unit test for constructor of class Timers
def test_Timers():
    """Test constructor of Timers"""
    timers = Timers()
    assert isinstance(timers, collections.UserDict)

# Generated at 2022-06-23 16:02:06.958931
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    # Test empty value
    with pytest.raises(KeyError):
        timers.apply(len, name="a")
    timers.add("a", 1)
    assert timers.apply(len, name="a") == 1
    assert timers.apply(lambda x: x[0], name="a") == 1
    # Test non-empty value
    timers.add("a", 2)
    assert timers.apply(len, name="a") == 2
    assert timers.apply(lambda x: sum(x), name="a") == 3

# Generated at 2022-06-23 16:02:10.962264
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method Timers.stdev"""
    timers = Timers()
    assert timers.stdev("test") == math.nan
    timers._timings["test"].append(1)
    timers._timings["test"].append(2)
    timers._timings["test"].append(3)
    assert timers.stdev("test") == pytest.approx(0.816496580927726)

# Generated at 2022-06-23 16:02:14.085423
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test',1)
    min_value = timers.min('test')
    assert min_value == 1
    return 'test passed'


# Generated at 2022-06-23 16:02:16.059363
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("timers", 1)
    timers.add("timers", 2)
    assert timers.min("timers") == 1


# Generated at 2022-06-23 16:02:22.727537
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    timers = Timers()
    timers.add('time', 0)
    assert timers.stdev('time') == 0
    timers.add('time', 1)
    assert timers.stdev('time') == 0
    timers.add('time', 2)
    assert timers.stdev('time') == 0.816496580927726
    timers.add('time', 3)
    assert timers.stdev('time') == 1

# Generated at 2022-06-23 16:02:25.882016
# Unit test for method total of class Timers
def test_Timers_total():
    """Unit test for method total of class Timers"""
    timers = Timers()
    timers.add("dummy", 1)
    assert timers.total("dummy") == 1


# Generated at 2022-06-23 16:02:31.627411
# Unit test for method add of class Timers
def test_Timers_add():
    t = Timers()
    t.add('t1', 1)
    t.add('t1', 2)
    assert t['t1'] == 3
    assert t.total('t1') == 3


# Generated at 2022-06-23 16:02:38.316296
# Unit test for constructor of class Timers
def test_Timers():
    import pytest
    timers = Timers()
    assert isinstance(timers, Timers)
    assert isinstance(timers, collections.UserDict)
    assert isinstance(timers.data, dict)
    assert isinstance(timers._timings, dict)
    with pytest.raises(TypeError):
        timers['foo'] = 0

# Unit tests for method Timers.add

# Generated at 2022-06-23 16:02:44.903349
# Unit test for method apply of class Timers
def test_Timers_apply():
    """
    Test the method apply of class Timers
    """
    func = lambda values: min(values or [0])
    timers = Timers()
    timers.add("test", 1)
    res = timers.apply(func, "test")
    assert res == 1.0
    with pytest.raises(KeyError) as excinfo:
        timers.apply(func, "test2")
    assert (
        str(excinfo.value)
        == "[E] Apply: 'test2' is not a valid timer name;"
        " valid names are test"
    )



# Generated at 2022-06-23 16:02:46.418693
# Unit test for method min of class Timers
def test_Timers_min():
    assert Timers().min('foo') == 0  # Should not raise


# Generated at 2022-06-23 16:02:51.721832
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timer_name = 'test_timer'
    timers.add(timer_name, 0.1)
    timers.add(timer_name, 0.2)
    timers.add(timer_name, 0.05)
    min_value = timers.min(timer_name)
    assert min_value == 0.05



# Generated at 2022-06-23 16:02:56.177517
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test the clear method of Timers"""
    # Initialize a Timers object
    timers = Timers()
    timers.add("timer1", 1)
    
    # Test if it is cleared
    timers.clear()
    assert timers.data == {}
    assert timers._timings == collections.defaultdict(list)



# Generated at 2022-06-23 16:03:06.506855
# Unit test for method max of class Timers
def test_Timers_max():
    # Create timers object
    timers = Timers()

    # Check that timers is empty
    assert len(timers) == 0

    # Add timing values
    timers.add(name="compute_error", value = 1)
    timers.add(name="compute_error", value = 2)
    timers.add(name="compute_error", value = 3)
    timers.add(name="compute_error", value = 4)
    timers.add(name="compute_error", value = 5)
    timers.add(name="compute_error", value = 6)
    timers.add(name="compute_error", value = 7)
    timers.add(name="compute_error", value = 8)
    timers.add(name="compute_error", value = 9)

# Generated at 2022-06-23 16:03:12.721499
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method add of class Timers"""
    timers = Timers()
    assert timers.data == {}

    timers.add("Test1", 10)
    timers.add("Test1", 20)
    timers.add("Test2", 30)

    assert timers.data == {"Test1": 30, "Test2": 30}



# Generated at 2022-06-23 16:03:16.844317
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test', 1.0)
    timers.add('test', 2.0)
    assert timers.max('test') == 2.0
    print('test_Timers_max: ok')


# Generated at 2022-06-23 16:03:26.474433
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Unit test for method clear of class Timers"""

    timers = Timers()

    timers.data.setdefault("test", 0)
    timers.data["test"] += 10

    timers.add("test", 10)
    timers.add("test", 10)
    timers.add("test", 10)

    assert(timers.data["test"] == 30)
    assert(len(timers._timings["test"]) == 3)

    timers.clear()

    assert(len(timers.data) == 0)
    assert(len(timers._timings) == 0)

# Generated at 2022-06-23 16:03:31.502980
# Unit test for constructor of class Timers
def test_Timers():
    # import modules whose top-level names are needed
    import doctest
    # run the doc tests in the function's docstring
    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)

# run the unit tests when module is run
if __name__ == "__main__":
    test_Timers()

# Generated at 2022-06-23 16:03:34.408851
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timer = Timers()
    timer.add("timing_a", 1.0)
    timer.add("timing_a", 2.0)
    timer.add("timing_a", 3.0)
    assert timer.stdev("timing_a") == 1.0

# Generated at 2022-06-23 16:03:36.966422
# Unit test for constructor of class Timers
def test_Timers():
    """Test initialization of Timers class"""
    timers = Timers()
    assert timers == {}

    timers = Timers(value=1.2, other=3.4)
    assert timers == {'value': 1.2, 'other': 3.4}


# Generated at 2022-06-23 16:03:47.949987
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test .apply() method of class Timers"""
    timers = Timers()
    timers._timings["t1"] = [1, 2, 3]

    assert timers.apply(len, "t1") == 3
    assert timers.apply(sum, "t1") == 6
    assert timers.apply(min, "t1") == 1
    assert timers.apply(max, "t1") == 3
    assert timers.apply(lambda x: min(x) + max(x), "t1") == 4
    assert timers.apply(lambda x: 3 * min(x) * max(x), "t1") == 9
    assert timers.apply(lambda x: math.isnan(x), "t1") is False

    assert math.isnan(timers.apply(lambda x: 3 * min([]), "t2"))


# Generated at 2022-06-23 16:03:54.057625
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    timers = Timers()
    for i in range(10):
        timers.add('l', 1)
    assert timers.apply(len, name='l') == 10
    assert timers.apply(sum, name='l') == 10
    assert timers.apply(lambda values: min(values or [0]), name='l') == 1
    assert timers.apply(lambda values: max(values or [0]), name='l') == 1
    assert timers.apply(lambda values: statistics.mean(values or [0]), name='l') == 1
    with pytest.raises(KeyError):
        timers.apply(lambda values: statistics.mean(values or [0]), name='x')

# Generated at 2022-06-23 16:04:04.839599
# Unit test for constructor of class Timers
def test_Timers():
    """Test timers class"""
    # Empty timers
    timers = Timers()
    assert len(timers) == 0
    assert timers.total(name="timer1") == 0
    assert timers.mean(name="timer1") == 0
    # Add values
    timers.add(name="timer1", value=1)
    assert len(timers) == 1
    assert timers.total(name="timer1") == 1
    assert timers.mean(name="timer1") == 1
    # Add more values
    timers.add(name="timer1", value=2)
    assert len(timers) == 1
    assert timers.total(name="timer1") == 3
    assert timers.mean(name="timer1") == 1.5
    # Clear timers
    timers.clear()
    assert len(timers) == 0

# Generated at 2022-06-23 16:04:09.939037
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Tests method apply from class Timers"""
    timers = Timers()
    def test_function(function, name):
        """Tests if a function works"""
        timers.add(name=name, value=1)
        timers.add(name=name, value=10)
        timers.add(name=name, value=100)
        assert function(name=name) == 0
        assert function(name="test") == 0
        timers.add(name=name, value=1)
        timers.add(name=name, value=10)
        timers.add(name=name, value=100)
        assert function(name=name) == 3
        assert function(name="test") == 0

# Generated at 2022-06-23 16:04:14.236999
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers._timings = {'foo': [0, 1, 2]}
    assert timers.stdev('foo') == statistics.stdev([0, 1, 2])
    timers._timings = {'bar': [123, 456]}
    assert timers.stdev('bar') == statistics.stdev([123, 456])
    timers._timings = {'baz': []}
    assert math.isnan(timers.stdev('baz'))
    timers._timings = {'qux': [5]}
    assert math.isnan(timers.stdev('qux'))


# Generated at 2022-06-23 16:04:18.436860
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add('test1', 10)
    timers.add('test2', 20)
    timers.add('test2', 30)
    timers.clear()
    assert timers.data == {}


# Generated at 2022-06-23 16:04:26.276912
# Unit test for method median of class Timers
def test_Timers_median():
    """This function tests the median method of class Timers"""
    # Test if median is correctly calculated for a single value
    timers = Timers()
    timers.add("my_timing", 2)
    assert timers.median("my_timing") == 2
    # Test if median is correctly calculated for a two values
    timers = Timers()
    timers.add("my_timing_1", 2)
    timers.add("my_timing_1", 1)
    assert timers.median("my_timing_1") == 1.5
    # Test if median is correctly calculated for a multiple values
    timers = Timers()
    timers.add("my_timing_2", 2)
    timers.add("my_timing_2", 1)
    timers.add("my_timing_2", 3)
    assert timers

# Generated at 2022-06-23 16:04:31.742347
# Unit test for method clear of class Timers
def test_Timers_clear():
    """test_Timers_clear"""
    timers = Timers()
    timers.add('test', 10)
    assert 10 == timers.data['test']
    assert len(timers._timings['test']) == 1

    timers.clear()
    assert len(timers.data) == 0
    assert len(timers._timings) == 0

# Generated at 2022-06-23 16:04:33.779715
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('dummy', 1.0)
    assert timers.max('dummy') == 1.0

# Generated at 2022-06-23 16:04:36.064394
# Unit test for method clear of class Timers
def test_Timers_clear():
    timer = Timers()
    timer.add('a', 0)
    timer.add('b', 1)
    assert len(timer) == 2
    timer.clear()
    assert len(timer) == 0



# Generated at 2022-06-23 16:04:40.549727
# Unit test for method median of class Timers
def test_Timers_median():
    from hypothesis import given
    from hypothesis.strategies import lists
    from hypothesis_numpy import array_shapes
    timers = Timers()

    @given(lists(elements=array_shapes(min_dims=1, max_dims=1), min_size=2))
    def test_median(value):
        median = statistics.median(value)
        assert median is not None
        assert median == timers.median(name='mse')
    test_median()

# Generated at 2022-06-23 16:04:44.495853
# Unit test for method add of class Timers
def test_Timers_add():
    # Create object under test
    timers = Timers()

    # Add some values
    timers.add("foo", 2.5)
    timers.add("foo", 3)
    assert round(timers.total("foo"), 5) == 5.5
    assert round(timers.mean("foo"), 5) == 2.75


# Generated at 2022-06-23 16:04:51.952347
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test for method mean of class Timers"""
    import pytest
    from . import Timers
    t = Timers()
    t.add("a", 1)
    t.add("a", 2)
    t.add("a", 1.5)
    assert t.mean("a") == 1.5
    with pytest.raises(KeyError):
        t.mean("b")


# Generated at 2022-06-23 16:04:53.544718
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add("name", 1.0)
    timers.clear()
    assert timers == {}

# Generated at 2022-06-23 16:04:56.934206
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add("test", 1)
    assert(len(timers._timings["test"]) == 1)
    timers.clear()
    assert(len(timers._timings["test"]) == 0)
    assert(len(timers) == 0)


# Generated at 2022-06-23 16:05:01.022822
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("t1", 5)
    timers.add("t2", 3)
    assert (timers.mean("t1") + timers.mean("t2"))/2 == 4


# Generated at 2022-06-23 16:05:04.011519
# Unit test for method max of class Timers
def test_Timers_max():
    pass
    #timers = Timers()
    #timers.add("A", 1)
    #timers.add("A", 0.5)
    #assert timers.max("A") == 1
    #timers.add("B", 0.5)
    #timers.add("B", 0.5)
    #assert timers.max("B") == 0.5
    #assert timers.max("C") == 0


# Generated at 2022-06-23 16:05:06.465749
# Unit test for method median of class Timers
def test_Timers_median():
    timer = Timers()
    for i in range(1, 10):
        timer.add("foo", i)
    assert timer.median("foo") == 5

# Generated at 2022-06-23 16:05:09.910189
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 1.0)
    timers.add("test", 2.0)
    assert timers.mean("test") == 1.5

# Generated at 2022-06-23 16:05:15.893453
# Unit test for method median of class Timers
def test_Timers_median():
    timer = Timers()
    timer.add("name", 10)
    timer.add("name", 20)
    timer.add("name", 30)
    timer.add("name", 40)
    timer.add("name", 50)
    timer.add("name", 60)

    actual=timer.mean("name")
    assert actual == 35

# Generated at 2022-06-23 16:05:24.183759
# Unit test for method median of class Timers
def test_Timers_median():
    timers=Timers()
    timers.add('timer1', 1.0)
    timers.add('timer1', 2.0)
    assert timers.median('timer1') == 1.5
    assert timers.min('timer1') == 1.0
    assert timers.max('timer1') == 2.0
    assert timers.mean('timer1') == 1.5
    assert timers.stdev('timer1') == 0.5
    assert timers.count('timer1') == 2
    assert timers.total('timer1') == 3.0
    assert timers.count('timer2') == 0
    assert timers.total('timer2') == 0.0

# Generated at 2022-06-23 16:05:28.091275
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add("timer_1", 10)
    assert timers.data["timer_1"] == 10
    timers.add("timer_1", 15)
    assert timers.data["timer_1"] == 25
    timers.add("timer_2", 25)
    assert timers.data["timer_2"] == 25


# Generated at 2022-06-23 16:05:30.475090
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test method Timers.__setitem__() raises TypeError"""
    timers = Timers()
    try:
        timers['key'] = float(1)
    except TypeError:
        pass


# Generated at 2022-06-23 16:05:40.756946
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test to verify functionality of method stdev of class Timers
    """
    result = Timers()
    # For n >= 2, standard deviation is defined as the square root of the
    # variance, which is the average of the squared distances from the mean.
    # For n < 2, the standard deviation is defined as NaN (not a number)
    assert math.isnan(result.stdev("non_existing"))
    result.add("one_value", 1)
    assert math.isnan(result.stdev("one_value"))
    result.add("one_value", 2)
    assert result.stdev("one_value") == 1.0
    result.add("one_value", 3)
    assert result.stdev("one_value") == math.sqrt(2/3)

# Generated at 2022-06-23 16:05:43.467764
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.min("test") == 1
    assert timers.min("undefined") == 0


if __name__ == '__main__':
    test_Timers_min()

# Generated at 2022-06-23 16:05:53.530329
# Unit test for method add of class Timers
def test_Timers_add():
    timer = Timers()
    assert timer.items() == dict().items()
    timer.add("item1",2.0)
    assert timer.items() == dict(item1=2.0).items()
    timer.add("item2",4.0)
    assert timer.items() == dict(item1=2.0,item2=4.0).items()
    timer.add("item3",3.0)
    assert timer.items() == dict(item1=2.0,item2=4.0,item3=3.0).items()
    timer.add("item1",2.0)
    assert timer.items() == dict(item1=4.0,item2=4.0,item3=3.0).items()
    timer.add("item1",2.0)

# Generated at 2022-06-23 16:05:59.999420
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test the apply method"""
    timers = Timers()
    timers.add('test', 10)

    assert timers.mean('test') == 10
    assert timers.median('test') == 10
    assert timers.min('test') == 10
    assert timers.max('test') == 10
    assert timers.total('test') == 10
    assert timers.count('test') == 1
    assert timers.stdev('test') == 0

# Generated at 2022-06-23 16:06:02.633014
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers._timings == collections.defaultdict(list)
    assert timers.data == {}


# Generated at 2022-06-23 16:06:06.146682
# Unit test for method count of class Timers
def test_Timers_count():
    res = Timers()
    assert res.count("timing") == 0
    res.add("timing", 0.01)
    res.add("timing", 0.02)
    assert res.count("timing") == 2


# Generated at 2022-06-23 16:06:08.985252
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():  # pragma: no cover
    timers = Timers()
    timers['name'] = 1.2
    assert timers.data['name'] == 1.2


# Generated at 2022-06-23 16:06:12.586852
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    with pytest.raises(TypeError) as excinfo:
        timers = Timers()
        timers["TestTimer"] = 42
    assert str(excinfo.value) == "Timers does not support item assignment. Use '.add()' to update values."

# Generated at 2022-06-23 16:06:20.538798
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    assert timers.median("foo") == 0
    timers.add("foo", 1)
    assert timers.median("foo") == 1
    timers.add("foo", 2)
    assert timers.median("foo") == 1.5
    timers.add("foo", 3)
    assert timers.median("foo") == 2
    timers.add("foo", 4)
    assert timers.median("foo") == 2.5
    timers.add("foo", 5)
    assert timers.median("foo") == 3

# Generated at 2022-06-23 16:06:23.867004
# Unit test for method min of class Timers
def test_Timers_min():
    """Test Timers.min"""
    timers = Timers()
    timers.add("testing", 5.0)
    assert timers.min("testing") == timers.min("testing") == 5.0


# Generated at 2022-06-23 16:06:28.699154
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    timers = Timers()
    timers.add('foo', 1.23)
    assert timers['foo'] == 1.23



# Generated at 2022-06-23 16:06:38.318776
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.data["a"] = 10
    timers.data["b"] = 20
    timers.data["c"] = 30
    timers.data["d"] = 40
    timers._timings["a"].append(1)
    timers._timings["a"].append(2)
    timers._timings["a"].append(3)
    timers._timings["b"].append(5)
    timers._timings["b"].append(5)
    timers._timings["b"].append(5)
    timers._timings["b"].append(5)
    timers._timings["b"].append(5)
    timers._timings["c"].append(3)
    timers._timings["c"].append(3)

# Generated at 2022-06-23 16:06:44.599466
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""

    # Create an empty dictionary of Timers
    timers = Timers()

    # Add a timing data to the dictionary
    name = "a"
    value1 = 1.0
    value2 = 2.0
    value3 = 3.0
    timers.add(name, value1)
    timers.add(name, value2)
    timers.add(name, value3)

    # Check the result
    assert timers.median(name) == 2.0

# Generated at 2022-06-23 16:06:47.718965
# Unit test for method apply of class Timers
def test_Timers_apply():
    x = Timers()
    x._timings = {'time':[10,20,30]}
    def func(l: List[float]) -> float:
        return sum(l)
    assert x.apply(func, name='time') == 60
    assert x.apply(func, name='time2') == 0

# Generated at 2022-06-23 16:06:58.394058
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    timers = Timers()
    try:
        timers["foo"] = 2.0
    except TypeError as exception:
        assert (str(exception) ==
                f"{timers.__class__.__name__!r} does not support item assignment. Use '.add()' to update values.")
    timers.add("foo", 1.0)
    assert (timers.data["foo"] == 1.0)
    timers.add("foo", 2.0)
    assert (timers.data["foo"] == 3.0)


# Generated at 2022-06-23 16:07:07.561882
# Unit test for method clear of class Timers
def test_Timers_clear():
    x = Timers()
    x.add('test1', 15)
    x.add('test1', 30)
    x.add('test1', 10)
    x.add('test2', 10)
    x.add('test2', 100)
    assert x.total('test1') == 55
    assert x.total('test2') == 110
    x.clear()
    assert x.data == {}
    assert x._timings == collections.defaultdict(list, {})

# Generated at 2022-06-23 16:07:16.037770
# Unit test for method apply of class Timers
def test_Timers_apply():
    """The method apply() of class Timers applies a function to the
    results of a given timer"""
    timers = Timers()
    assert timers.apply(len, "some") != len(timers)
    assert len(timers) == 0
    assert timers.apply(sum, "some") != sum(timers.values())
    assert sum(timers.values()) == 0
    assert timers.apply(lambda x: min(x), "some") != min(timers.values())
    assert min(timers.values()) == 0
    assert timers.apply(lambda x: max(x), "some") != max(timers.values())
    assert max(timers.values()) == 0
    assert timers.apply(lambda x: statistics.mean(x), "some") != statistics.mean(timers.values())
    assert statistics.mean

# Generated at 2022-06-23 16:07:19.146092
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test the clear method of class Timers."""
    timers = Timers()
    timers.add('timers', [1, 2, 3, 4, 5])
    timers.clear()
    assert not timers.data

# Generated at 2022-06-23 16:07:23.675348
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers({"a": 0, "b": 0})
    for i in range(10):
        timers.add("a", i)
        timers.add("b", i * 2)
    assert timers.mean("a") == statistics.mean(range(10))
    assert timers.mean("b") == statistics.mean([x * 2 for x in range(10)])

# Generated at 2022-06-23 16:07:28.737600
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median value of Timer objects"""
    timers = Timers()
    assert timers.median("foo") == 0
    timers['foo'] = 1
    assert timers.median("foo") == 0
    timers.add("foo", 0)
    assert timers.median("foo") == 0
    timers.add("foo", 1)
    assert timers.median("foo") == 0.5
    timers.add("foo", 2)
    assert timers.median("foo") == 1

# Generated at 2022-06-23 16:07:38.007226
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test Timers.stdev()"""

    # Create instance, add two timings
    timers = Timers()
    timers.add('test', 1.0)
    timers.add('test', 2.0)

    # Check stdev for 'test'
    assert timers.stdev('test') == 0.707106781

    # Error message for unknown key
    try:
        timers.stdev('boo')
    except KeyError as err:
        assert str(err) == "'boo'"

    # Error message for key with one element
    timers.clear()
    timers.add('test', 1.0)
    try:
        timers.stdev('test')
    except KeyError as err:
        assert str(err) == "'test'"

    # Check stdev for empty key
    timers.clear()

# Generated at 2022-06-23 16:07:39.898416
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add("wallclock",5)
    timers.add("wallclock",3)
    assert timers.total("wallclock") == 8

# Generated at 2022-06-23 16:07:42.684946
# Unit test for method max of class Timers
def test_Timers_max():
    from pytest import raises
    timers = Timers()
    name = "test_name"
    value = 42.
    timers._timings[name] = [1., value]
    assert timers.max(name) == value
    with raises(KeyError):
        timers.max("no_such_timer")

# Generated at 2022-06-23 16:07:50.621010
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """
    Unit test for method stdev of class Timers
    """
    import pytest
    from .utils import UnitTimer

    timer = UnitTimer()
    timer.start()
    timer.stop()
    timers = Timers()
    timers.add(name="Test timer", value=timer.interval)

    assert math.isnan(timers.stdev(name="Test timer"))

    timer.start()
    timer.stop()
    timers.add(name="Test timer", value=timer.interval)

    assert pytest.approx(0) == timers.stdev(name="Test timer")



# Generated at 2022-06-23 16:07:52.587952
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()  # type: ignore[no-untyped-call]
    assert timers.total('my_timer') != 0



# Generated at 2022-06-23 16:07:57.766348
# Unit test for method min of class Timers
def test_Timers_min():
    """Test the min() method of the Timers class"""
    timers = Timers()
    timers.add("foo", 0.7777)
    timers.add("foo", 0.7777)
    timers.add("foo", 0.7778)
    timers.add("foo", 0.7779)
    timers.add("foo", 0.7776)
    assert timers.min("foo") == 0.7776



# Generated at 2022-06-23 16:08:06.588624
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    # Add invalid value to timer (requires str)
    timers.add(1, 1.0)
    assert timers.data == {}

    # Add valid value to timer
    timers.add("timer1", 1.0)
    timers.add("timer2", 1.0)

    # Add second valid value to timer
    timers.add("timer1", 2.0)
    timers.add("timer2", 2.0)

    # Check timers dict
    assert timers.data == {"timer1": 3.0, "timer2": 3.0}



# Generated at 2022-06-23 16:08:10.394677
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test if overwriting the default __setitem__ method fails."""
    timers = Timers()
    with pytest.raises(TypeError):
        timers["test"] = 1.0



# Generated at 2022-06-23 16:08:17.105702
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("test1", 1)
    timers.add("test1", 2)
    timers.add("test1", 3)

    timers.add("test2", 4)
    timers.add("test2", 5)
    timers.add("test2", 6)

    assert timers.mean("test1") == 2
    assert timers.mean("test2") == 5

    assert timers.stdev("test1") == 1
    assert timers.stdev("test2") == 1

# Generated at 2022-06-23 16:08:22.745378
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()
    assert timers.mean("foo") == 0.0
    timers._timings["foo"].append(10.0)
    timers._timings["foo"].append(20.0)
    assert timers.mean("foo") == 15.0

# Generated at 2022-06-23 16:08:29.090254
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test standard deviation of timers"""
    timers = Timers()
    # Add three timers
    timers.add("timer1", [0.2, 0.2, 0.2])
    timers.add("timer2", [0.1, 0.1, 0.1])
    timers.add("timer3", [0.4, 0.4])
    # Test standard deviation for three timers with different number of events
    assert timers.stdev("timer1") == 0
    assert timers.count("timer1") == 3
    assert timers.stdev("timer2") == 0
    assert timers.count("timer2") == 3
    assert math.isnan(timers.stdev("timer3"))
    assert timers.count("timer3") == 2
    # Try unknown timer

# Generated at 2022-06-23 16:08:34.856558
# Unit test for method min of class Timers
def test_Timers_min():
    """Test for method min of class Timers"""
    timings = Timers()
    for i in range(10):
        timings.add("test", i)
    assert timings.min("test") == 0
    assert timings.min("test2") == 0



# Generated at 2022-06-23 16:08:37.957716
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count('example') == 0
    timers.add('example', 1)
    assert timers.count('example') == 1
    timers.add('example', 10)
    assert timers.count('example') == 2


# Generated at 2022-06-23 16:08:50.939360
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test the 'apply' function of class Timers"""
    import pytest
    timers = Timers()
    timers.add('foobar', 1)
    timers.add('foobar', 2)
    timers.add('foobar', 3)
    assert timers.apply(lambda values: values[0], 'foobar') == 1
    assert timers.apply(lambda values: values[1], 'foobar') == 2
    assert timers.apply(lambda values: values[2], 'foobar') == 3
    assert timers.apply(len, 'foobar') == 3
    assert timers.apply(sum, 'foobar') == 6
    assert pytest.approx(timers.apply(lambda values: min(values), 'foobar'), 1e-12) == 1

# Generated at 2022-06-23 16:08:56.373284
# Unit test for method max of class Timers
def test_Timers_max():
    """Test for method max of class Timers"""
    t = Timers()
    t.add('foo', 10)
    t.add('bar', 20)
    t.add('foo', 100)

    assert t.max('foo') == 100
    assert t.max('bar') == 20


# Generated at 2022-06-23 16:08:59.531169
# Unit test for method max of class Timers
def test_Timers_max():
    timers=Timers()
    timers.add('foo',10)
    timers.add('foo',20)
    timers.add('foo',30)
    assert timers.max('foo')==30


# Generated at 2022-06-23 16:09:05.063161
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method 'min' of class Timers"""
    timers = Timers()
    assert timers.min("test") == 0

    # Empty list
    timers.add("test", [])
    assert timers.min("test") == 0

    # Existing results
    timers.add("test", [1, 2, 3])
    assert timers.min("test") == 1


# Generated at 2022-06-23 16:09:09.117724
# Unit test for method count of class Timers
def test_Timers_count():
    t = Timers()
    t.add("speed", 3.14159)
    assert t.count("speed") == 1
    t.add("speed", 2.71828)
    assert t.count('speed') == 2


# Generated at 2022-06-23 16:09:18.782491
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test the method stdev of class Timers."""
    # Create a Timers object
    _timers = Timers()
    # Add one measurement to the object _timers
    _timers.add("test", 2)
    # Check its standard deviation
    assert math.isnan(_timers.stdev("test"))
    # Add another measurement to the object _timers
    _timers.add("test", 2)
    # Check its standard deviation
    assert _timers.stdev("test") == 0
    # Add another measurement to the object _timers
    _timers.add("test", 3)
    # Check its standard deviation
    assert _timers.stdev("test") == 0.816496580927726
    # Add another measurement to the object _timers
    _timers.add("test", 3)

# Generated at 2022-06-23 16:09:25.058148
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("alpha", 1)
    timers.add("alpha", 2)
    timers.add("beta", 3)

    assert timers.min("alpha") == 1
    assert timers.min("beta") == 3
    assert timers.min("gamma") == 0

# Generated at 2022-06-23 16:09:28.240131
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test if item setting is not allowed"""
    timings = Timers()
    try:
        timings["something"] = 1
        raise Exception("TypeError not raised")
    except TypeError:
        pass


# Generated at 2022-06-23 16:09:34.561483
# Unit test for method median of class Timers
def test_Timers_median():
    """Check the correctness of the median function."""
    odd = Timers()
    odd.add("odd", 1)
    odd.add("odd", 3)
    odd.add("odd", 5)
    assert odd.median() == 3
    even = Timers()
    even.add("even", 1)
    even.add("even", 3)
    even.add("even", 5)
    even.add("even", 6)
    assert even.median() == 4

# Generated at 2022-06-23 16:09:39.805716
# Unit test for method total of class Timers
def test_Timers_total():
    """Test the method 'total' for the class Timers"""
    TIMERS = Timers()
    TIMERS.add('test_timer', 0.5)
    TIMERS.add('test_timer', 0.7)
    assert TIMERS.total('test_timer') == 1.2

# Generated at 2022-06-23 16:09:42.211180
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add('test', 3.0)
    assert t.mean('test') == 3.0


# Generated at 2022-06-23 16:09:45.791438
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add('test', 1.0)
    timers.clear()
    assert len(timers) == 0
    assert timers.data == {}
    assert timers.total('test') == 0.0


# Generated at 2022-06-23 16:09:51.204614
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()
    t.add("a", 2)
    t.add("b", 6)
    t.add("b", 1)
    t.add("a", 3)
    t.add("b", 9)
    t.add("b", 4)
    assert t.total("a") == 5
    assert t.total("b") == 20
    assert t.total("c") == 0


# Generated at 2022-06-23 16:09:56.687905
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("a", 1)
    timers.add("b", 10)
    timers.add("c", 100)
    timers.add("b", 2)
    timers.add("c", 200)
    assert timers.max("b") == 10
    assert timers.max("c") == 100



# Generated at 2022-06-23 16:10:00.876835
# Unit test for method total of class Timers
def test_Timers_total():
    """Test method Timers.total"""
    timers = Timers()
    timers.add('foo', 2)
    timers.add('foo', 3)
    timers.add('bar', 3)
    assert timers.total('foo') == 5
    assert timers.total('bar') == 3


# Generated at 2022-06-23 16:10:05.262672
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    for i in range(10):
        timers.add('timer1', i)
    mean = timers.mean('timer1')
    assert mean == 4.5


# Generated at 2022-06-23 16:10:14.278966
# Unit test for method total of class Timers
def test_Timers_total():
    """
    Test the total method of the Timers class.
    """
    def _test_total(case_name, test_count, test_total):
        """Auxiliary function for testing the total method."""
        # Instantiate a dictionary
        my_dict = Timers()

        # Check the total value
        assert my_dict.total(case_name) == test_total

        # Check the count value
        assert my_dict.count(case_name) == test_count

    # Test the total method with a dictionary that has no item
    _test_total("", 0, 0)

    # Test the total method with a dictionary that has one item
    my_dict = Timers()
    my_dict.add("", 1)
    _test_total("", 1, 1)

    # Test the total method with a dictionary that has

# Generated at 2022-06-23 16:10:20.011359
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers({'foo': 1.0})
    timers.add('foo', 0.5)
    timers.add('foo', 0.2)
    assert timers.apply(lambda value: sum(value), 'foo') == 1.7
    assert timers.apply(lambda value: min(value), 'foo') == 0.2
    assert timers.apply(lambda value: max(value), 'foo') == 0.5

# Generated at 2022-06-23 16:10:26.213111
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert isinstance(timers, collections.UserDict)
    assert isinstance(timers._timings, collections.defaultdict)
    assert all(
        [
            isinstance(timers._timings[key], list)
            for key, value in timers._timings.items()
        ]
    )
    assert timers == dict()
    assert timers._timings == dict()



# Generated at 2022-06-23 16:10:29.413966
# Unit test for method max of class Timers
def test_Timers_max():
   timers = Timers()
   timers.add("test", 42.)
   assert timers.max("test") == 42.
   assert timers.max("fail") == 0
   timers.clear()
   timers.add("test", -1)
   assert timers.max("test") == -1


# Generated at 2022-06-23 16:10:33.895867
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert isinstance(timers, collections.UserDict)
    assert isinstance(timers.data, dict)
    assert timers._timings is not None

# Unit tests for method add of class Timers

# Generated at 2022-06-23 16:10:38.263189
# Unit test for method apply of class Timers
def test_Timers_apply():
    obj = Timers()
    obj._timings = {"my_name": [5, 6, 7]}
    res = obj.apply(sum, "my_name")
    assert res == 18, "test_Timers_apply: res == 18"

# Generated at 2022-06-23 16:10:39.555010
# Unit test for constructor of class Timers
def test_Timers():
    assert Timers()._timings == collections.defaultdict(list)


# Generated at 2022-06-23 16:10:43.059525
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add("mytimer", 1.0)
    timers.add("mytimer", 10000.0)
    assert timers.stdev("mytimer") == 4999.5

# Generated at 2022-06-23 16:10:48.378505
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add('timer1', 1)
    timers.add('timer1', 2)
    timers.add('timer1', 3)
    timers.add('timer2', 1)
    assert timers['timer1'] == 6
    assert timers['timer2'] == 1



# Generated at 2022-06-23 16:10:50.956564
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.add("foo", 1)
    assert t.max("foo") == 1


# Generated at 2022-06-23 16:10:55.339578
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    assert 0 == timers.total('test')
    timers.add('test', 1.0)
    assert 1.0 == timers.total('test')
    timers.add('test', -0.5)
    assert 0.5 == timers.total('test')


# Generated at 2022-06-23 16:10:59.293410
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()
    t.add('a', 1)
    t.add('a', 2)
    t.add('a', 3)
    assert t.total('a') == 6
    return


# Generated at 2022-06-23 16:11:02.145655
# Unit test for constructor of class Timers
def test_Timers():
    """Test the Timers constructor"""
    timers = Timers()
    assert isinstance(timers, Timers)
    assert timers.data == {}


# Generated at 2022-06-23 16:11:06.063813
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    with pytest.raises(TypeError):
        timers['test'] = 100.



# Generated at 2022-06-23 16:11:09.568547
# Unit test for constructor of class Timers
def test_Timers():
    from acnportal.acnsim.node_utils import Timers
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}

# Generated at 2022-06-23 16:11:18.335839
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    from statistics import mean
    timers = Timers()
    timers._timings = {
        "timer_0": [1.0, 2.0, 3.0],
        "timer_1": [],
    }
    assert timers.apply(len, "timer_0") == 3
    assert timers.apply(len, "timer_1") == 0
    assert timers.apply(min, "timer_0") == 1.0
    assert timers.apply(min, "timer_1") == 0
    assert timers.apply(max, "timer_0") == 3.0
    assert timers.apply(max, "timer_1") == 0
    assert timers.apply(mean, "timer_0") == 2.0
    assert timers.apply(mean, "timer_1") == 0

# Generated at 2022-06-23 16:11:24.033236
# Unit test for method count of class Timers
def test_Timers_count():
    """Unit tests for Timers method count"""
    timer = Timers()
    assert timer.count("B") == 0
    timer.add("A", 0)
    assert timer.count("A") == 1
    timer.add("A", 0)
    assert timer.count("A") == 2
    assert timer.count("B") == 0


# Generated at 2022-06-23 16:11:27.981066
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of class Timers"""
    # Assign
    timers = Timers()
    timers._timings = {
        "mock": [1]
    }

    # Act
    result = timers.mean("mock")

    # Assert
    assert result == 1


# Generated at 2022-06-23 16:11:31.343530
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    with pytest.raises(KeyError):
        timers.apply(lambda values: 'error', name='not-in-timers')


# Generated at 2022-06-23 16:11:34.996743
# Unit test for method median of class Timers
def test_Timers_median():
    """Check Timers.median() method"""
    timers = Timers()
    assert timers.median("new") == 0
    timers = Timers({"new": 0, "old": 1})
    assert timers.median("new") == 0
    assert timers.median("old") == 1

# Generated at 2022-06-23 16:11:38.119369
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add("test", 1)
    assert timers.total("test") == 1
    timers.add("test", 2)
    assert timers.total("test") == 3
    timers.add("test", 3)
    assert timers.total("test") == 6


# Generated at 2022-06-23 16:11:45.902092
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test Timers.apply"""

    def cube(values: List[float]) -> float:
        """Cube values"""
        return sum(i ** 3 for i in values)

    my_timers = Timers()
    assert my_timers.apply(cube, "Test") == 0.0

    my_timers.add("Test", 1)
    assert my_timers.apply(cube, "Test") == 1.0

    my_timers.add("Test", 2)
    assert my_timers.apply(cube, "Test") == 9.0

# Generated at 2022-06-23 16:11:48.842987
# Unit test for method max of class Timers
def test_Timers_max():
    """Raise ValueError"""
    timers = Timers()
    timers.add("test", 5)
    assert timers.max("test") == 5