

# Generated at 2022-06-23 16:01:48.956821
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    timers.add(name="a", value=1)
    try:
        timers["b"] = 2
    except:
        pass
    else:
        assert False, "No exception raised"


# Generated at 2022-06-23 16:01:53.667467
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add("spam",10)
    timers.add("spam",4)
    timers.add("eggs",5)
    timers.add("eggs",11)
    assert timers.total("spam") == 14


# Generated at 2022-06-23 16:01:59.379355
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test that method apply of class Timers works"""
    # pylint: disable=invalid-name
    import pytest

    def test_dict() -> Timers:
        """Create a test dictionary"""
        return Timers({"test1": 2.0, "test2": 2.0})

    # Test that applying a function works
    func: Callable[[List[float]], float] = len
    assert test_dict().apply(func, "test1") == 1
    assert test_dict().apply(func, "test2") == 1
    assert test_dict().apply(func, "test3") == 0



# Generated at 2022-06-23 16:02:01.751369
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add('Timer1',1)
    timers.add('Timer2',2)
    timers.clear()


# Generated at 2022-06-23 16:02:05.600164
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of class Timers"""
    timers = Timers()
    timers.add('foo', 1)
    assert timers.mean('foo') == 1
    timers.add('foo', 2)
    assert timers.mean('foo') == 1.5

# Generated at 2022-06-23 16:02:08.624406
# Unit test for method count of class Timers
def test_Timers_count():
    t = Timers()
    assert t.count('t') == 0
    t.add('t', 1)
    assert t.count('t') == 1



# Generated at 2022-06-23 16:02:11.802797
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test clearing of count and total timers"""
    timers = Timers()
    timers.add("test", 5)
    timers.clear()
    assert timers.count("test") == 0
    assert timers.total("test") == 0

# Generated at 2022-06-23 16:02:17.585963
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    assert Timers().stdev("non-existent") == math.nan
    assert Timers().add("only_one", 1).stdev("only_one") == math.nan
    assert Timers().add("two", 2).add("two", 2).stdev("two") == 0
    assert Timers().add("two", 2).add("two", 3).stdev("two") == 0.5
    assert round(Timers().add("multiple", 1).add("multiple", 1).
                       add("multiple", 2).add("multiple", 2).
                       add("multiple", 3).add("multiple", 3).stdev("multiple"), 2) == 1

# Generated at 2022-06-23 16:02:26.636646
# Unit test for method add of class Timers
def test_Timers_add():
    "Test .add() method of class Timers"

    # Create instance of Timers
    timers = Timers()

    # Add some example values
    timers.add("example", 0.3)
    timers.add("example", 0.4)
    timers.add("example", 1.0)

    # Check that we got the correct value
    assert timers.data["example"] == 1.7

    # Check that we can access the values via .data, but not via dict-like
    # access
    with pytest.raises(TypeError):
        timers["example"] = 0.1

    # Test that we can access information about all timings
    assert timers["example"] == 1.7
    assert timers.count("example") == 3
    assert timers.total("example") == 1.7
    assert timers.min("example") == 0.

# Generated at 2022-06-23 16:02:31.409550
# Unit test for constructor of class Timers
def test_Timers():
    data = {'a': 1, 'b': 2}
    timers = Timers(data)

    assert timers.data == data
    assert timers._timings == collections.defaultdict(list)


# Generated at 2022-06-23 16:02:40.246306
# Unit test for method count of class Timers
def test_Timers_count():
    """Test count method of Timers class"""
    timers = Timers()
    assert timers.count('no such timer') == 0.0
    timers.add('no such timer', 0.1)
    timers.add('no such timer', 0.2)
    timers.add('no such timer', 0.3)
    timers.add('no such timer', 0.4)
    timers.add('no such timer', 0.5)
    assert timers.count('no such timer') == 5.0
    assert timers.count('other timer') == 0.0
    return


# Generated at 2022-06-23 16:02:48.126014
# Unit test for method add of class Timers
def test_Timers_add():
    """
    >>> timers = Timers()
    >>> timers.add("test", 10)
    >>> timers.add("test", 20)
    >>> timers.add("test", 30)
    >>> timers.add("a", 10)
    >>> timers.add("b", 20)
    >>> timers.data
    {'test': 60, 'a': 10, 'b': 20}
    >>> timers._timings
    defaultdict(<class 'list'>, {'test': [10, 20, 30], 'a': [10], 'b': [20]})
    """


# Generated at 2022-06-23 16:02:52.763523
# Unit test for method max of class Timers
def test_Timers_max():
    """Method max of class Timers"""
    timers = Timers()
    timers.add("t1", value=1.0)
    timers.add("t1", value=2.0)
    timers.add("t2", value=10.0)
    assert timers.max("t1") == 2.0
    assert timers.max("t2") == 10.0

# Generated at 2022-06-23 16:02:56.709262
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("foo", 0.5)
    assert timers.count("foo") == 1
    timers.add("foo", 1.0)
    assert timers.count("foo") == 2
    timers.add("bar", 0.5)
    assert timers.count("bar") == 1



# Generated at 2022-06-23 16:03:02.251121
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add("try1", 1)
    assert timers.total("try1") == 1
    timers.add("try1", 2)
    assert timers.total("try1") == 3
    timers.add("try2", 3)
    assert timers.total("try2") == 3


# Generated at 2022-06-23 16:03:10.361927
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Unit test for method clear of class Timers"""
    timers = Timers()
    timers.add(name="test_timer_1", value=0.1)
    timers.add(name="test_timer_1", value=0.2)
    timers.add(name="test_timer_1", value=0.3)
    timers.add(name="test_timer_2", value=0.1)
    timers.add(name="test_timer_2", value=0.2)
    timers.add(name="test_timer_2", value=0.3)
    # Test pre-condition
    assert len(timers) == 2
    assert len(timers._timings) == 2
    assert len(timers._timings["test_timer_1"]) == 3

# Generated at 2022-06-23 16:03:15.517037
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('t1', 2)
    timers.add('t1', 5)
    assert timers.median('t1') == 3.5
    timers.add('t2', 1)
    assert timers.median('t2') == 1

# Generated at 2022-06-23 16:03:18.260654
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('t1', 1)
    timers.add('t1', 1)
    assert timers.count('t1') == 2


# Generated at 2022-06-23 16:03:19.868556
# Unit test for constructor of class Timers
def test_Timers():
    """Test basic properties"""
    timers = Timers()
    assert len(timers) == 0
    assert len(timers._timings) == 0


# Generated at 2022-06-23 16:03:29.386405
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test of timers.Timers.apply"""
    timers = Timers()
    assert timers.count('t1') == 0
    assert timers.count('t2') == 0
    timers.add('t1', 1)
    timers.add('t1', 2)
    timers.add('t2', 3)
    timers.add('t2', 4)
    assert timers.count('t1') == 2
    assert timers.count('t2') == 2

if __name__ == '__main__':
    from apyht.util import get_logger
    get_logger()
    test_Timers_apply()

# Generated at 2022-06-23 16:03:31.096934
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    return isinstance(timers, Timers)


# Generated at 2022-06-23 16:03:33.257670
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('foo', 3)
    timers.add('foo', 4)
    assert timers.median('foo') == 3.5

# Generated at 2022-06-23 16:03:35.506948
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    Timers['name'] = 0.0  # pylint: disable=no-member
    Timers()['name'] = 0.0  # pylint: disable=no-member

# Generated at 2022-06-23 16:03:42.971257
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Timers.apply() must return the result of function for a
    passed list of values.
    """

    # Empty dictionary
    timers = Timers()

    assert isinstance(timers, collections.UserDict)
    assert isinstance(timers, Timers)

    # Add a couple of values
    for name, value in [("a", 0.1), ("a", 1.2), ("b", 1.0005)]:
        timers.add(name, value)

    # Test sum() on values
    assert timers.apply(sum, name="a") == 1.3
    assert timers.apply(sum, name="b") == 1.0005

    # Test len() on values
    assert timers.apply(len, name="a") == 2
    assert timers.apply(len, name="b") == 1

    # Test min

# Generated at 2022-06-23 16:03:48.480150
# Unit test for method count of class Timers
def test_Timers_count():
    t = Timers()
    t.add('foo', 1)
    assert t.count('foo') == 1
    assert t.mean('foo') == 1

    t.add('foo', 2)
    assert t.count('foo') == 2
    assert t.mean('foo') == 1.5

    t.add('foo', 3)
    assert t.count('foo') == 3
    assert t.mean('foo') == 2


# Generated at 2022-06-23 16:03:52.692441
# Unit test for method min of class Timers
def test_Timers_min():
    """Test for Timers.min method"""
    timings = Timers()
    assert timings.min("test") == 0
    timings.add("test", 0.5)
    assert timings.min("test") == 0.5
    assert timings.data["test"] == 0.5



# Generated at 2022-06-23 16:03:59.277826
# Unit test for method count of class Timers
def test_Timers_count():
    """Tests for Timers"""
    timers = Timers()
    timers.add("X", 1.0)
    timers.add("X", 2.0)
    timers.add("Y", 1.0)
    assert timers.count("X") == 2
    assert timers.count("Y") == 1
    assert timers.count("Z") == 0


# Generated at 2022-06-23 16:04:01.526089
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("timerA", 1)
    timers.add("timerB", 1)
    timers.add("timerB", 2)

    assert timers.count("timerA") == 1
    assert timers.count("timerB") == 2


# Generated at 2022-06-23 16:04:07.378724
# Unit test for method median of class Timers
def test_Timers_median():
    timings = Timers()
    timings.add('a', 2)
    timings.add('a', 4)
    timings.add('a', 4)
    timings.add('a', 4)
    timings.add('a', 5)
    timings.add('a', 5)
    timings.add('a', 7)
    timings.add('a', 9)
    assert timings.median('a') == 4.0


# Generated at 2022-06-23 16:04:13.256070
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method add of class Timers"""
    timers = Timers()
    timers.add('timer1', 1.0)
    timers.add('timer1', 2.0)
    timers.add('timer2', 3.0)
    assert timers.data == {'timer1': 3.0, 'timer2': 3.0}
    assert timers._timings == {'timer1': [1.0, 2.0], 'timer2': [3.0]}

if __name__ == '__main__':  # pragma: no cover
    # Execute the tests that are documented in the docstring when running the script
    # directly.
    import pytest
    pytest.main(["test_timers.py"])

# Generated at 2022-06-23 16:04:20.641890
# Unit test for method max of class Timers
def test_Timers_max():
    # Create an instance of Timers
    instances = Timers()
    # Add new key and value
    instances.add('speed', 10)
    # Print the intial value of key
    print(instances['speed'])
    # Try to change the value to 20
    try:
        instances['speed'] = 20
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_Timers_max()

# Generated at 2022-06-23 16:04:28.086124
# Unit test for constructor of class Timers
def test_Timers():
    """Test actions on Timers"""
    timers = Timers()

    assert len(timers.data) == 0

    timers.add("timer1", 0.5)
    timers.add("timer2", 0.2)
    timers.add("timer1", 0.3)
    timers.add("timer3", 0.4)

    assert len(timers.data) == 3
    assert timers["timer1"] == 0.8
    assert timers["timer2"] == 0.2
    assert timers["timer3"] == 0.4

    timers.clear()
    assert len(timers.data) == 0
    assert len(timers._timings) == 0

# Generated at 2022-06-23 16:04:33.088031
# Unit test for method min of class Timers
def test_Timers_min():
    """Check that Timers.min function correctly"""
    t = Timers()
    assert t.min("") == 0
    t.add("", 100)
    assert t.min("") == 100
    t.add("", 10000)
    assert t.min("") == 100


# Generated at 2022-06-23 16:04:34.619780
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers['something'] = 5
    except TypeError:
        return
    assert False

# Generated at 2022-06-23 16:04:42.804256
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """This unit test checks if the method stdev of class Timers returns the
    standard deviation of a given list of values.
    """
    timers = Timers()
    timers.add('B', 4)
    timers.add('B', 4)
    timers.add('B', 8)
    timers.add('B', 8)
    timers.add('B', 8)
    assert(timers.stdev('B') == 2 * math.sqrt(3/5))

# Generated at 2022-06-23 16:04:48.705278
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """stdev of a list of numbers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    test_stdev = 1.0
    assert test_stdev == timers.stdev("test")

# Generated at 2022-06-23 16:04:54.103699
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median function"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    timers.add("test", 4)
    assert round(timers.median("test"), 5) == 2.5
    timers.add("test", 10)
    assert round(timers.median("test"), 5) == 3.0

# Generated at 2022-06-23 16:04:56.257245
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()
    t.add("test", 10)
    t.add("test", 15)
    print(t.total("test"))



# Generated at 2022-06-23 16:05:07.183111
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method `__setitem__` of class `Timers`"""

    # Test with a timer that is not yet there
    timers = Timers()
    with pytest.raises(TypeError) as e:
        timers["new_timer"] = 1
    assert f"{timers.__class__.__name__!r} does not support item assignment" in str(e.value)

    # Test with a timer that is already present
    timers["existing_timer"] = 42
    with pytest.raises(TypeError) as e:
        timers["existing_timer"] = 1
    assert f"{timers.__class__.__name__!r} does not support item assignment" in str(e.value)



# Generated at 2022-06-23 16:05:10.257791
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('test', 42)
    assert timers.count('test') == 1


# Generated at 2022-06-23 16:05:15.403584
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test clear method

    Setup
    -----
    myTimers : Timers

    Test
    ----
    myTimers.clear == {}
    """
    timers = Timers()
    timers['test_name'] = 0.1
    timers.clear()
    assert timers.data is {}

# Generated at 2022-06-23 16:05:21.056837
# Unit test for method total of class Timers
def test_Timers_total():
    """Tests Timers.total method"""
    # Create Timers object
    timers = Timers()
    # Add timer with name 'timer_1'
    timer_1 = 1
    name = 'timer_1'
    timers.add(name, timer_1)
    # Retrieve total time
    total_time = timers.total(name)
    # Assert that 'total_time' equals 1
    assert total_time == 1


# Generated at 2022-06-23 16:05:27.620168
# Unit test for constructor of class Timers
def test_Timers():
    """Test constructor of class Timers"""
    # Create object
    timers = Timers()
    # Initialize
    timers.add("a", 1)
    timers.add("a", 2)
    timers.add("b", 10)
    # Check values
    assert timers.count("a") == 2
    assert timers.count("b") == 1
    assert timers.min("a") == 1
    assert timers.max("a") == 2
    assert timers.mean("a") == 1.5
    assert timers.median("a") == 1.5
    assert timers.total("b") == 10
    assert timers.stdev("a") == 0.5

# Generated at 2022-06-23 16:05:32.098992
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """
    Test the method __setitem__ of the class Timers
    """
    timers = Timers()
    with pytest.raises(TypeError):
        timers["name"] = 1.0


# Generated at 2022-06-23 16:05:39.880625
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test method Timers.clear"""
    timers = Timers()
    timers.add("foo", 1.5)
    timers.add("foo", 2.5)
    timers.add("bar", 8.5)
    timers.add("bar", 7.5)
    assert timers.data == {"foo": 4.0, "bar": 16.0}
    assert timers._timings == {"foo": [1.5, 2.5], "bar": [8.5, 7.5]}
    timers.clear()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:05:49.036822
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timer = Timers()
    timer.add('foo', 1)
    timer.add('foo', 2)
    assert timer.stdev('foo') == math.sqrt(2/3)
    timer.add('foo', 3)
    assert timer.stdev('foo') == math.sqrt(2)
    timer.add('foo', 5)
    assert timer.stdev('foo') == math.sqrt(2.5)
    timer.add('foo', 6)
    assert timer.stdev('foo') == math.sqrt(5/2)
    timer.add('foo', 10)
    assert timer.stdev('foo') == math.sqrt(5)



# Generated at 2022-06-23 16:05:54.302821
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("max", 3)
    assert timers.min("max") == 3
    timers.add("max", 1)
    assert timers.min("max") == 1
    timers.add("min", 2)
    assert timers.min("min") == 2
    timers.add("min", 1)
    assert timers.min("min") == 1

# Generated at 2022-06-23 16:06:05.386875
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """
    Check that stdev returns nan if there aren't enough values
    """
    timers = Timers()
    timers.add("timer", 2)
    timers.add("timer", 3)

    assert timers.stdev("timer") == 0.7071067811865476

    timers.add("timer", 5)

    assert timers.stdev("timer") == 1.5811388300841898

    timers = Timers()
    timers.add("timer", 3)

    assert math.isnan(timers.stdev("timer"))

    timers.add("timer", 2)

    assert math.isnan(timers.stdev("timer"))

    timers = Timers()

    assert math.isnan(timers.stdev("timer"))

if __name__ == '__main__':
    test_Timers_stdev()

# Generated at 2022-06-23 16:06:08.894264
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add("mytimer", 1.23)
    print(f"timers: {timers!r}")


# Generated at 2022-06-23 16:06:12.952944
# Unit test for method count of class Timers
def test_Timers_count():
    # Setup
    test_timers: Timers = Timers()
    test_timers.add('name', 2.0)
    # Exercise
    result: float = test_timers.count('name')
    # Verify
    assert result == 1


# Generated at 2022-06-23 16:06:16.075154
# Unit test for method min of class Timers
def test_Timers_min():
    """Checks that the method min of Timers works correctly"""
    timers = Timers()
    timers["a"] = 0
    assert timers.min("a") == 0
    

# Generated at 2022-06-23 16:06:21.177545
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.add("a", 1.1)
    t.add("a", 2.2)
    t.add("a", 3.3)
    t.add("b", 1.1)
    t.add("b", 2.2)
    t.add("b", 3.3)
    assert t.max("a") == 3.3
    assert t.max("b") == 3.3


# Generated at 2022-06-23 16:06:23.731416
# Unit test for constructor of class Timers
def test_Timers():
    """"""
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:06:28.951580
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("Mean", 1)
    timers.add("Mean", 2)

    assert timers.mean("Mean") == 1.5


# Generated at 2022-06-23 16:06:31.382849
# Unit test for method count of class Timers
def test_Timers_count():
    """Unit test for method count of class Timers"""
    timers = Timers()
    timers.add("First", 10)
    assert timers.count("First") == 1


# Generated at 2022-06-23 16:06:33.846023
# Unit test for method clear of class Timers
def test_Timers_clear():
    t = Timers()
    t.add("abc", 1.5)
    t.clear()
    assert t == {}
    assert t._timings == {}


# Generated at 2022-06-23 16:06:36.552099
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    assert timers.min('test') == 1


# Generated at 2022-06-23 16:06:45.820970
# Unit test for method add of class Timers
def test_Timers_add():
    """
        Timers.add()
        GIVEN
            A dictionary (my_timers) and two names (name_1, name_2)
        WHEN
            the dictionary is modified with the names
            by calling .add() three times for each name
        THEN
            the dictionary will contain the names
            and the value for each name will be the sum of its values
    """
    my_timers = Timers()
    name_1 = "name_1"
    name_2 = "name_2"
    value_1_1 = 4.321
    value_1_2 = 13.12
    value_1_3 = 8.1234
    value_2_1 = 6.123
    value_2_2 = 12.34
    value_2_3 = 15

# Generated at 2022-06-23 16:06:54.648639
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """
    Unit test for method stdev of class Timers
    """
    timers = Timers()
    timers.add("name", 1)
    timers.add("name", 2)
    timers.add("name", 3)
    timers.add("name", 4)
    timers.add("name", 5)
    res = timers.stdev("name")
    assert abs(res - 1.5811388300841898) < 1e-14


# Generated at 2022-06-23 16:06:57.924381
# Unit test for method add of class Timers
def test_Timers_add():
    t = Timers()
    t.add('preprocessing', 2.5)
    assert t['preprocessing'] == 2.5
    t.add('preprocessing', 3.2)
    assert t['preprocessing'] == 5.7
    t.add('modeling', 4)
    assert t['modeling'] == 4
    assert t._timings['preprocessing'] == [2.5, 3.2]
    assert t._timings['modeling'] == [4]
    assert len(t._timings) == 2


# Generated at 2022-06-23 16:07:09.844591
# Unit test for method median of class Timers
def test_Timers_median():
    # Create an empty instance
    instance = Timers()
    # Make sure it is empty
    assert len(instance.data) == 0
    assert len(instance._timings) == 0
    # Add some values
    instance.add("first", 1.2)
    instance.add("first", 7.1)
    instance.add("first", 5.3)
    instance.add("second", 3.5)
    instance.add("second", 6.1)
    # Make sure there are five values in total
    assert len(instance._timings["first"]) == 3
    assert len(instance._timings["second"]) == 2
    # Check that the median is correct
    assert instance.median("first") == 5.3
    assert instance.median("second") == 4.8
    # Check that the dictionary has been updated


# Generated at 2022-06-23 16:07:11.340177
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:07:18.707960
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers."""
    t = Timers()
    # Add times to timer a
    t.add('a', 1)
    t.add('a', 2)
    t.add('a', 3)
    # Add times to timer b
    t.add('b', 2)
    t.add('b', 3)
    t.add('b', 4)
    # Test method apply with function len
    assert t.apply(len, 'a') == 3, 'Invalid number records for timer a'
    assert t.apply(len, 'b') == 3, 'Invalid number records for timer b'
    # Test method apply with function sum
    assert t.apply(sum, 'a') == 6, 'Invalid sum of time records for timer a'
    assert t.apply(sum, 'b') == 9

# Generated at 2022-06-23 16:07:21.762723
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("timer1", 0.1)
    timers.add("timer1", 0.2)
    timers.add("timer1", 0.3)
    assert timers.count("timer1") == 3

# Generated at 2022-06-23 16:07:25.311662
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    assert timers.mean("test") == 0
    timers.add("test", 1)
    assert timers.mean("test") == 1
    timers.add("test", 1)
    assert timers.mean("test") == 1


# Generated at 2022-06-23 16:07:29.974096
# Unit test for method min of class Timers
def test_Timers_min():
    timer = Timers()
    timer.add('big_loop', 5)
    timer.add('big_loop', 10)
    timer.add('big_loop', 15)
    assert timer.min('big_loop') == 5


# Generated at 2022-06-23 16:07:38.726118
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers: Timers = Timers()
    timers.add("abc", 2)
    timers.add("abc", 4)
    timers.add("xyz", 9)

    assert timers.mean("abc") == 3.0, "mean of a single timer"
    assert timers.mean("xyz") == 9.0, "mean of a single timer"

    try:
        timers.mean("fake")
    except KeyError:
        pass
    else:
        raise AssertionError("timer name not found")


# Generated at 2022-06-23 16:07:46.168678
# Unit test for method total of class Timers
def test_Timers_total():
    inputs = [
        (1, 1, 2),
        (1, 2, 3),
        (1, 3, 4),
    ]
    outputs = (1, 3, 6)
    timings = Timers()
    for i in inputs:
        timings.add(*i)
    for result, expected in zip(timings, outputs):
        assert result == expected

# Generated at 2022-06-23 16:07:50.696897
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.add("a", 1)
    t.add("b", 2)
    t.add("a", 3)
    assert t.max("a") == 3
    assert t.max("b") == 2
    assert t.max("c") == 0


# Generated at 2022-06-23 16:07:59.300327
# Unit test for method clear of class Timers
def test_Timers_clear():
    t = Timers()
    assert len(t) == 0
    assert dict(t) == dict()
    assert len(t._timings) == 0
    assert dict(t._timings) == dict()

    t['x'] = 1
    t.add('y', 2)
    assert len(t) == 2
    assert dict(t) == dict(x=1, y=2)
    assert len(t._timings) == 2
    assert dict(t._timings) == dict(x=[1], y=[2])

    t.clear()
    assert len(t) == 0
    assert dict(t) == dict()
    assert len(t._timings) == 0
    assert dict(t._timings) == dict()
# ----------------------------------------------------------------------------

# Generated at 2022-06-23 16:08:10.298265
# Unit test for method add of class Timers
def test_Timers_add():
    timer = Timers()
    timer.add(name = "first", value = 2.2 )
    timer.add(name = "second", value = 3.4 )
    timer.add(name = "third", value = 5.6 )
    timer.add(name = "first", value = 1.1 )
    timer.add(name = "second", value = 2.3 )
    timer.add(name = "third", value = 3.5 )
    timer.add(name = "first", value = 4.4 )
    timer.add(name = "second", value = 5.6 )
    timer.add(name = "third", value = 7.8 )
    assert timer.data["first"] == 7.7 
    assert timer.data["second"] == 11.3 
    assert timer.data["third"] == 16.

# Generated at 2022-06-23 16:08:17.810378
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test Timers.stdev method"""
    # An empty list
    name = "test"
    timers = Timers()
    timers._timings[name] = []
    assert math.isnan(timers.stdev(name))
    # A list of one element with 0 value
    timers._timings[name] = [0]
    assert math.isnan(timers.stdev(name))
    # A list of one element with 1 value
    timers._timings[name] = [1]
    assert math.isnan(timers.stdev(name))
    # A list of two elements with identical values
    timers._timings[name] = [1, 1]
    assert math.isnan(timers.stdev(name))
    # A list of three elements with identical values
    timers._timings[name]

# Generated at 2022-06-23 16:08:28.350384
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    timers = Timers()
    n = 10
    for _ in range(n):
        timers.add("foo", 1.0)
    for _ in range(n):
        timers.add("bar", 2.0)
    for _ in range(n):
        timers.add("baz", 3.0)

    def test(name: str, expected: float) -> bool:
        """Test method stdev of class Timers with a given name and
        expected value"""
        value = timers.stdev(name)
        assert math.isclose(value, expected), (name, expected)
        return True

    assert test("foo", 1.0)
    assert test("bar", 1.0)
    assert test("baz", 1.0)


# Generated at 2022-06-23 16:08:32.735386
# Unit test for method total of class Timers
def test_Timers_total():
    timers= Timers()
    timers.add("test1", 10)
    timers.add("test2", 15)
    timers.add("test1", 20)
    timers.add("test3", 30)
    assert timers.total("test1") == 30
    assert timers.total("test2") == 15
    assert timers.total("test3") == 30

# Generated at 2022-06-23 16:08:36.600840
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test if we can set items"""
    timers = Timers()
    with pytest.raises(TypeError):
        timers['name'] = 0.0


# Generated at 2022-06-23 16:08:40.356730
# Unit test for method clear of class Timers
def test_Timers_clear():
    # Testtiming für Funktion test_Timers_clear()
    t = Timers()
    t.add('tim', 12)
    t.clear()
    assert t.get('tim', None) == None
    t.add('tim', 12)
    t.clear()
    assert t.get('tim', None) == None
 

# Generated at 2022-06-23 16:08:45.448717
# Unit test for method max of class Timers
def test_Timers_max():
    """Test for method max of class Timers"""
    timers = Timers()
    timers.add(name="a", value=0.1)
    timers.add(name="b", value=0.2)
    assert timers.max(name="a") == 0.1
    assert timers.max(name="b") == 0.2


# Generated at 2022-06-23 16:08:49.815564
# Unit test for method max of class Timers
def test_Timers_max():
    # Create a Timers object
    timers = Timers()

    # Add a timing value to the given timer
    timers.add('total', 2.1)

    # Get the maximal value of timings
    assert timers.max('total') == 2.1

# Generated at 2022-06-23 16:08:57.351416
# Unit test for method total of class Timers
def test_Timers_total():
    """Unit test for method total of class Timers"""
    timers = Timers()
    timers.add("Time1", 10)
    timers.add("Time1", 15)
    timers.add("Time1", 7)
    timers.add("Time2", 5)
    timers.add("Time2", 2)
    assert timers.total("Time1") == 32
    assert timers.total("Time2") == 7


# Generated at 2022-06-23 16:09:01.124161
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    timers['foo'] = 1
    try:
        timers['bar'] = 1
    except TypeError as e:
        print('TypeError exception caught:', e, 'Test passed')
    else:
        raise AssertionError('Test failed')


# Generated at 2022-06-23 16:09:12.569597
# Unit test for constructor of class Timers
def test_Timers():
    """Unit testing for Timers"""  # pragma: no cover
    timers = Timers()
    # Get empty timers
    assert not timers
    assert timers.data == {}
    # Get empty timings
    assert timers.count('xyz') == 0
    assert timers.total('xyz') == 0
    assert timers.min('xyz') == 0
    assert timers.max('xyz') == 0
    assert timers.mean('xyz') == 0
    assert timers.median('xyz') == 0
    assert timers.stdev('xyz') == math.nan
    # Add some timings
    for i in range(10):
        timers.add('xyz', i)
    assert timers.count('xyz') == 10
    assert timers.total('xyz') == 45
    assert timers.min('xyz') == 0

# Generated at 2022-06-23 16:09:15.503781
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test that .__setitem__() raises a TypeError"""
    timers = Timers()
    with pytest.raises(TypeError):
        timers["foo"] = 0.0


# Generated at 2022-06-23 16:09:19.277507
# Unit test for method mean of class Timers
def test_Timers_mean():
    timer = Timers()
    timer.add('test', 1)
    timer.add('test', 2)
    assert timer.mean('test') == 1.5


# Generated at 2022-06-23 16:09:28.238189
# Unit test for method add of class Timers
def test_Timers_add():
    # Method:
    # -  add(self, name: str, value: float) -> None
    # Assert:
    # -  If a non-existing name is added, it is created
    # -  If an existing name is added, the values are updated
    timers = Timers()
    assert timers == {}
    # Add a non-existing key
    timers.add(name="key_1", value=1)
    assert timers == {'key_1': 1}
    # Add an existing key
    timers.add(name="key_1", value=1)
    assert timers == {'key_1': 2}
    return


# Generated at 2022-06-23 16:09:29.934725
# Unit test for method max of class Timers
def test_Timers_max():
    assert Timers()["myTimer"] == 0


# Generated at 2022-06-23 16:09:32.914160
# Unit test for method count of class Timers
def test_Timers_count():
    t = Timers()
    t.add("a",1)
    t.add("a",1)
    t.add("b",1)
    assert t.count("a") == 2

# Generated at 2022-06-23 16:09:36.853927
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("media", 1)
    timers.add("media", 2)
    res = timers.median("media")
    if res != 1.5:
        raise AssertionError("median shoudl be 1.5 but is" + str(res))

# Generated at 2022-06-23 16:09:47.540370
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test method __setitem__ of class Timers
    """
    from .utils import compare_dicts, compare_objects

    # Set up the test case
    t = Timers()
    init = t.data.copy()

    # Perform the test
    with compare_objects(t, init):
        t["timer0"] = 1.234

    # Set up the test case
    t = Timers()
    begin = {"timer0": 123.4}
    end = {"timer0": 124.634, "timer1": 456.78}

    # Perform the test
    with compare_dicts(t.data, begin):
        t.add("timer0", 1.234)
        t.add("timer1", 456.78)

    # Set up the test case
    t = Timers()

    # Perform the test

# Generated at 2022-06-23 16:09:48.147721
# Unit test for method total of class Timers
def test_Timers_total():
    pass

# Generated at 2022-06-23 16:09:50.826796
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', -5)
    assert timers.min('test') == -5


# Generated at 2022-06-23 16:09:53.862903
# Unit test for method add of class Timers
def test_Timers_add(): # pragma: no cover
    timers = Timers()
    timers.add('one', 1.0)

    assert len(timers) == 1
    assert timers['one'] == 1.0


# Generated at 2022-06-23 16:10:01.235307
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method add of class Timers"""
    
    # create instance of class Timers
    timers = Timers()
    
    # populate dictionary data and dictionary _timings
    timers.add('A', 1)
    timers.add('B', 2)
    timers.add('C', 3)
    
    # test that dictionary data is as expected
    assert timers.data == {'A':1, 'B':2, 'C':3}
    assert timers['A'] == 1
    assert timers['B'] == 2
    assert timers['C'] == 3
    assert set(timers.keys()) == {'A','B','C'}
    assert set(timers.values()) == {1,2,3}
    
    # test that dictionary _timings is as expected

# Generated at 2022-06-23 16:10:06.408192
# Unit test for method count of class Timers
def test_Timers_count():
    """Test method count of class Timers"""
    timers = Timers()
    timers.add("count", 1)
    timers.add("count", 2)
    timers.add("count", 3)
    assert timers.count("count") == 3
    return True


# Generated at 2022-06-23 16:10:09.961522
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    timers = Timers()
    with pytest.raises(TypeError):
        timers["foo"] = 10.0


# Generated at 2022-06-23 16:10:17.710349
# Unit test for method mean of class Timers
def test_Timers_mean():
    """
    Test method mean of class Timers

    :return: None
    """
    timers = Timers()
    assert round(timers.mean('test'), 2) == 0.0

    timers.add('test', 0.0)
    assert round(timers.mean('test'), 2) == 0.0

    timers.add('test', 2.0)
    assert round(timers.mean('test'), 2) == 1.0

    timers.add('test', 3.0)
    assert round(timers.mean('test'), 2) == 1.67

    timers.add('test', 4.0)
    assert round(timers.mean('test'), 2) == 2.0

    timers.add('test', 5.0)
    assert round(timers.mean('test'), 2) == 2.4


# Generated at 2022-06-23 16:10:24.408752
# Unit test for method mean of class Timers
def test_Timers_mean():
    timer: Timers = Timers(data={'A':3,'B':2,'C':7})
    assert timer.mean('E') == math.nan
    assert timer.mean('A') == 3
    assert timer.mean('B') == 2
    assert timer.mean('C') == 7


if __name__ == "__main__":
    # Unit test for method mean of class Timers
    test_Timers_mean()

# Generated at 2022-06-23 16:10:30.339125
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("median", 1)
    timers.add("median", 2)
    timers.add("median", 3)
    timers.add("median", 3)
    timers.add("median", 4)
    timers.add("median", 4)
    timers.add("median", 5)
    assert timers.median("median") == 3.5

# Generated at 2022-06-23 16:10:31.533107
# Unit test for method max of class Timers
def test_Timers_max():
    Timers.max(Timers, 1)

test_Timers_max()

# Generated at 2022-06-23 16:10:36.547604
# Unit test for method add of class Timers
def test_Timers_add():
    t = Timers()
    t.add("timer 1", 1.1)
    t.add("timer 1", 2.2)
    t.add("timer 2", 3.3)
    assert t.data["timer 1"] == 3.3
    assert t.data["timer 2"] == 3.3


# Generated at 2022-06-23 16:10:40.226520
# Unit test for method count of class Timers
def test_Timers_count():
    """Unit test for method count"""
    self = Timers()
    self._timings = collections.defaultdict(list, {"test": [1, 2]})
    assert self.count("test") == 2


# Generated at 2022-06-23 16:10:42.427374
# Unit test for method count of class Timers
def test_Timers_count():
    tm = Timers()
    assert tm.count("test") == 0



# Generated at 2022-06-23 16:10:46.483831
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("Test", 10)
    t.add("Test", 20)
    t.add("Test", 5)

    assert t.min("Test") == 5

# Generated at 2022-06-23 16:10:50.958017
# Unit test for method clear of class Timers
def test_Timers_clear():
    min_v = 1
    max_v = 2
    mean_v = 1.5
    median_v = 1.5
    stdev_v = 0.5
    timer = Timers()
    timer.add("test", 1)
    timer.add("test", 2)
    assert timer.min("test") == min_v
    assert timer.max("test") == max_v
    assert timer.mean("test") == mean_v
    assert timer.median("test") == median_v
    assert timer.stdev("test") == stdev_v
    assert len(timer._timings) == 1
    assert len(timer.data) == 1
    timer.clear()
    assert len(timer._timings) == 0
    assert len(timer.data) == 0

# Generated at 2022-06-23 16:10:53.254020
# Unit test for method total of class Timers
def test_Timers_total():
    """Test that method total of class Timers works"""
    timers = Timers()
    timers.add("foo", 1.1)
    timers.add("foo", 2.2)
    assert timers.total("foo") == 3.3


# Generated at 2022-06-23 16:10:56.559194
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test Timers.__setitem__"""
    import pytest

    timers = Timers()

    with pytest.raises(TypeError):
        timers["test"] = 1.0


# Generated at 2022-06-23 16:10:59.646994
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('name', value=2.0)
    minValue = timers.min('name')
    assert minValue == 2.0


# Generated at 2022-06-23 16:11:03.288408
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """ Testing method __setitem__ of class Timers """

    # Initialize a Timers object and run __setitem__
    t = Timers()
    with pytest.raises(TypeError):
        t['First'] = 17


# Generated at 2022-06-23 16:11:11.494001
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add('my_timer_1', 10.0)
    timers.add('my_timer_1', 20.0)
    timers.add('my_timer_1', 30.0)
    timers.add('my_timer_1', 40.0)
    assert timers.stdev('my_timer_1') == statistics.stdev([10.0, 20.0, 30.0, 40.0])

# Generated at 2022-06-23 16:11:14.081490
# Unit test for constructor of class Timers
def test_Timers():
    from numpy.testing import assert_equal

    timers = Timers()
    # pylint: disable=no-member
    assert_equal(timers.data, {})
    assert_equal(timers._timings, {})

# Generated at 2022-06-23 16:11:17.346598
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    data = [1, 2, 3, 1, 2, 3, 1, 2, 3]     # Type: List[float]
    mean = Timers.mean(Timers(), lambda x: x)

    for d in data:
        mean.add(d)

    assert mean == statistics.mean(data)


# Generated at 2022-06-23 16:11:20.324497
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    t = Timers()

    with pytest.raises(TypeError):
        t["a"] = 0

# Generated at 2022-06-23 16:11:29.895384
# Unit test for method count of class Timers
def test_Timers_count():
    """Test that the count method of timer return the correct value"""
    t = Timers()
    t.add('timer1', 1)
    t.add('timer2', 2)
    assert t.count('timer1') == 1
    assert t.count('timer2') == 1
    t.add('timer1', 1)
    t.add('timer3', 2)
    assert t.count('timer1') == 2
    assert t.count('timer2') == 1
    assert t.count('timer3') == 1

    t = Timers()
    assert t.get('timer1') is None

    t.add('timer1', 1)
    t.add('timer2', 2)
    assert t.count('timer1') == 1
    assert t.count('timer2') == 1



# Generated at 2022-06-23 16:11:33.283195
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    assert timers.count('test') == 2
    assert timers.count('test2') == 0


# Generated at 2022-06-23 16:11:39.126722
# Unit test for method median of class Timers
def test_Timers_median():
    x = Timers()
    x.add("cool", 10)
    x.add("cool", 20)
    x.add("cool", 30)
    x.add("cool", 40)
    x.add("cool", 50)
    x.add("cool", 60)
    return x.median("cool")

# Generated at 2022-06-23 16:11:47.185416
# Unit test for method min of class Timers
def test_Timers_min():
    # Initialization
    timers = Timers()
    timers.data = {'timer1': 1, 'timer2': 2, 'timer3': 3}
    timers._timings = {'timer1': [1], 'timer2': [1, 2], 'timer3': [1, 2, 3]}

    # Assertions
    assert timers.min('timer1') == 1
    assert timers.min('timer2') == 1
    assert timers.min('timer3') == 1
    assert timers.min('timer4') == 0
