

# Generated at 2022-06-23 16:01:55.283246
# Unit test for method max of class Timers
def test_Timers_max():
    """Test for Defaultdict"""
    timers = Timers()
    timers.add('foo', 2.0)
    timers.add('foo', 4.0)
    timers.add('foo', 3.0)
    assert timers.max('foo') == 4.0
    assert timers.max('bar') == 0.0


# Generated at 2022-06-23 16:02:00.118938
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    try:
        # no timings yet
        timers.median('foo')
        assert False, 'Expected exception'
    except KeyError:
        # expected exception
        pass

    # test with two timings
    timers.add('foo', 1.0)
    timers.add('foo', 3.0)
    assert timers.median('foo') == 2.0

    # test with many timings
    for i in range(10):
        timers.add('foo', i)
    assert timers.median('foo') == 5.0

# Generated at 2022-06-23 16:02:02.219962
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('test', 10)
    assert timers.count('test') == 1


# Generated at 2022-06-23 16:02:07.744002
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('timer1', 0.5)
    timers.add('timer1', 0.6)
    timers.add('timer1', 0.7)
    assert 3 == timers.count('timer1')
    assert 2.8 == timers.total('timer1')
    assert 0 == timers.count('timer2')
    assert 0 == timers.total('timer2')

# Generated at 2022-06-23 16:02:14.874317
# Unit test for method median of class Timers
def test_Timers_median():

    timers = Timers()

    for values in [
        [2, 3, 4, 5, 6, 7, 10],
        [5, 1, 8, 6, 10, 8, 10],
        [6, 10, 1, 4, 10, 7, 10],
        [3, 3, 4, 1, 1, 4, 2],
        [10, 10, 1, 5, 7, 1, 1],
        [3, 10, 3, 10, 4, 4, 10],
    ]:
        timers.add("test_median", statistics.median(values))

    assert timers.median("test_median") == 6

# Generated at 2022-06-23 16:02:18.062192
# Unit test for method add of class Timers
def test_Timers_add():
    """Test for method add of class Timers"""
    import pyExtend.modules.Timers
    pyExtend.modules.Timers.Timers.add()


# Generated at 2022-06-23 16:02:25.024740
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    assert math.isnan(timers.stdev('foo'))
    timers._timings['foo'] = []
    assert math.isnan(timers.stdev('foo'))
    timers._timings['foo'] = [1, 2, 3]
    assert timers.stdev('foo') == statistics.stdev(timers._timings['foo'])

# Generated at 2022-06-23 16:02:33.815429
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count("test") == 0

    timers.add("test", 1)
    assert timers.count("test") == 1

    timers.add("test", 2)
    assert timers.count("test") == 2

    # Test error
    try:
        timers.count("foo")
    except KeyError:
        pass

    try:
        timers.count("test2")
    except KeyError:
        pass



# Generated at 2022-06-23 16:02:38.316033
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('foo', 1)
    timers.add('bar', 2)
    timers.add('foo', 3)
    assert timers.count('foo') == 2
    assert timers.count('bar') == 1
    assert timers.count('baz') == 0

# Generated at 2022-06-23 16:02:40.541072
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers['test'] = 1
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-23 16:02:43.251033
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add('a', 1.)
    t.add('a', 2.)
    t.add('a', 3.)
    res = t.mean('a')
    assert res == 2.


# Generated at 2022-06-23 16:02:47.447473
# Unit test for method mean of class Timers
def test_Timers_mean():
    from pymt_timer import Timers
    timers = Timers()
    assert timers.mean("Method") == 0
    timers.add("Method", 1)
    assert timers.mean("Method") == 1


# Generated at 2022-06-23 16:02:52.246461
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add("name", 1)
    timers.add("name", 2)
    timers.add("name2", 3)
    assert timers.count("name") == 2
    assert timers.count("name2") == 1
    timers.clear()
    assert timers.count("name") == 0
    assert timers.count("name2") == 0


# Generated at 2022-06-23 16:02:56.303043
# Unit test for method total of class Timers
def test_Timers_total():
    """Test method total of class Timers"""
    timers = Timers()
    timers.add('test', 1.0)
    timers.add('test', 2.0)
    assert timers.total('test') == 3.0
    assert timers.total('test2') == 0.0


# Generated at 2022-06-23 16:02:58.644307
# Unit test for method mean of class Timers
def test_Timers_mean():
	timers = Timers()
	timers.add('T1', 0.2)
	timers.add('T1', 0.1)
	assert timers.data['T1'] == 0.3
	assert timers.mean('T1') == 0.15


# Generated at 2022-06-23 16:03:08.654916
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method Timers.max()"""
    from heptet_app.entrypoint import app
    from heptet_app.formatter import Formatter
    from heptet_app.finish import finish
    from heptet_app.initialize import initialize

    timers = Timers()
    formatter = Formatter()
    formatter.add_timers(timers)
    app.set_formatter(formatter)

    initialize()
    app.add_timing('initialize', 0.0)
    app.add_timing('initialize', 1.0)
    app.add_timing('initialize', 2.0)

    finish()
    app.add_timing('finish', 30.0)
    app.add_timing('finish', 20.0)
    app.add_timing

# Generated at 2022-06-23 16:03:16.445513
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add('a', 5)
    timers.add('a', 10)
    timers.add('b', 15)
    timers.add('b', 20)

    assert isinstance(timers, UserDict)
    assert isinstance(timers, Timers)
    assert timers['a'] == timers.total('a')
    assert timers['b'] == timers.total('b')


# Generated at 2022-06-23 16:03:20.631861
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers.data = {'test': 1.0}
    timers._timings = {'test': [2.0]}
    result = timers.apply(sum, name='test')
    assert result == 3.0, result

# Unit tests for count, total, min, max, mean, median, stdev methods of class Timers

# Generated at 2022-06-23 16:03:25.986723
# Unit test for method total of class Timers
def test_Timers_total():
    """Test method total of class Timers"""
    timers = Timers()
    timers.add('var', 2.0)
    timers.add('var', 3.0)
    assert timers.total('var') == timers['var'] == 5.0
    assert timers.total('other') == 0.0


# Generated at 2022-06-23 16:03:29.977557
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add("test", 1.0)
    timers.clear()
    assert len(timers) == 0
    assert len(timers._timings) == 0


# Generated at 2022-06-23 16:03:33.516625
# Unit test for method max of class Timers
def test_Timers_max():
    """
    Test for max method of class Timers
    """

    list_t = [0, 1, 2]
    print(max(list_t))
    assert max(list_t) == 2, "Failed maximum value"



# Generated at 2022-06-23 16:03:37.699940
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    '''Unit test for method __setitem__ of class Timers.'''
    # Instantiate a Timer
    t = Timers()
    # Check that calling __setitem__ raises an error
    try:
        t['name'] = 1.0
    except TypeError:
        return
    # Raise an error if no error raised
    raise AssertionError(
        "'__setitem__' of class 'Timers' should raise a TypeError.")


# Generated at 2022-06-23 16:03:39.539510
# Unit test for method count of class Timers
def test_Timers_count():
    assert Timers().count("name") == 0
    assert Timers().add("name", 1).count("name") == 1



# Generated at 2022-06-23 16:03:44.473149
# Unit test for method add of class Timers
def test_Timers_add():
    """Test a method add of class Timers"""
    # Arrange
    timers = Timers()
    # Act
    timers.add("test_add", 10)
    # Assert
    assert timers["test_add"] == 10


# Generated at 2022-06-23 16:03:47.995368
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert type(timers) == Timers
    timers = Timers({"test":1})
    assert type(timers) == Timers
    timers = Timers([("test",1)])
    assert type(timers) == Timers

# Generated at 2022-06-23 16:03:50.533027
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unittest for Timers.mean method"""
    timers = Timers()
    timers.add('foo', 0.1)
    timers.add('foo', 0.2)
    assert timers['foo'] == 0.3
    assert timers.mean('foo') == 0.15



# Generated at 2022-06-23 16:03:56.777714
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    # Imports
    from collections import UserDict
    # Assertions
    assert issubclass(Timers, UserDict)
    # Method under test
    timers = Timers()
    with pytest.raises(TypeError):
        timers['test'] = 10

# Unit test the methods of the class Timers

# Generated at 2022-06-23 16:03:58.714297
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers['test'] = 1
    assert timers.mean('test') == 1

# Generated at 2022-06-23 16:04:03.428185
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    timers.add("test", 1)
    timers.add("test", 1)
    timers.add("test", 1)

    assert timers.stdev("test") == 1

# Generated at 2022-06-23 16:04:11.422440
# Unit test for method apply of class Timers
def test_Timers_apply():
    from pytest import raises
    from psutil import cpu_times_percent, cpu_count

    timings_per_cpu = Timers()

    for _ in range(10):
        for i in range(cpu_count()):
            timings_per_cpu.add(f'cpu{i}', cpu_times_percent(interval=0)[i].idle)

    assert timings_per_cpu.count('cpu0') == 10
    assert timings_per_cpu.total('cpu0')
    assert timings_per_cpu.min('cpu0')
    assert timings_per_cpu.max('cpu0')
    assert timings_per_cpu.mean('cpu0')
    assert timings_per_cpu.median('cpu0')


# Generated at 2022-06-23 16:04:13.326827
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('total', 1.0)
    assert timers.max('total') == 1.0

# Generated at 2022-06-23 16:04:17.362190
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers["test"] = 1.0
    except TypeError:
        pass
    else:
        raise RuntimeError()
    assert len(timers) == 0
    assert timers._timings == {}

# Generated at 2022-06-23 16:04:22.407455
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test for method mean of class Timers"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.mean('test') == 2


# Generated at 2022-06-23 16:04:26.479975
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    timers = Timers()
    timers.add("foo", 2.3)
    timers.add("bar", 5.6)
    timers.add("foo", 2.3)
    assert timers["foo"] == 4.6
    assert timers["bar"] == 5.6


# Generated at 2022-06-23 16:04:31.928334
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Clear timer values"""
    timers = Timers()
    timers.add("X", 10)
    timers.add("X", 10)
    assert len(timers.data) == 1
    assert len(timers._timings) == 1
    timers.clear()
    assert not timers._timings
    assert not timers.data

# Generated at 2022-06-23 16:04:33.556439
# Unit test for method count of class Timers
def test_Timers_count():
    x = Timers()
    x.add('foo', 1)
    assert(x.count('foo') == 1)


# Generated at 2022-06-23 16:04:36.737368
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    assert timers.mean("a") == 0
    timers.add("a", 1)
    assert timers.mean("a") == 1
    timers.add("a", 2)
    assert timers.mean("a") == 1.5
    assert timers.mean("b") is math.nan


# Generated at 2022-06-23 16:04:39.068116
# Unit test for constructor of class Timers
def test_Timers():
    """Tests if Timers is initialized correctly"""
    t = Timers()
    assert isinstance(t, Timers)

# Unit tests for methods of class Timers

# Generated at 2022-06-23 16:04:44.144252
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test the clear method of Timers"""
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}
    timers.add('foo', 1.23)
    timers.add('foo', 4.56)
    assert timers.data == {'foo': 5.79}
    assert timers._timings == {'foo': [1.23, 4.56]}
    timers.clear()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:04:55.993342
# Unit test for method apply of class Timers
def test_Timers_apply():
    t = Timers()
    assert t.data == {}
    assert t._timings == {}
    t.add('a', 1)
    assert t.data['a'] == 1
    t.add('a', 2)
    assert t.data['a'] == 3
    t.add('b', 3)
    assert t.data['b'] == 3
    assert t.apply(len, 'a') == 2
    assert t.apply(len, 'b') == 1
    assert t.apply(lambda a: sum(a), 'a') == 3
    assert t.apply(lambda a: max(a), 'a') == 2
    assert t.apply(lambda a: min(a), 'a') == 1
    assert t.apply(lambda a: statistics.mean(a), 'a') == 1.5

# Generated at 2022-06-23 16:04:59.838958
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    for val in [0,10,15,12]:
        timers.add('test',val)

    assert(timers.median('test') == 12)

# Generated at 2022-06-23 16:05:02.968452
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count('') == 0
    timers.add('value', 1)
    assert timers.count('value') == 1


# Generated at 2022-06-23 16:05:08.233157
# Unit test for method add of class Timers
def test_Timers_add():
    """Test adding timings to a timer"""
    timers = Timers()
    timers.add('tst', 2.0)
    assert len(timers.data) == 1
    assert timers.data['tst'] == 2.0
    timers.add('tst', 5.0)
    assert timers.data['tst'] == 7.0
    assert timers._timings['tst'] == [2.0, 5.0]


# Generated at 2022-06-23 16:05:12.142148
# Unit test for method count of class Timers
def test_Timers_count():
    from ..timers import Timers  # isort:skip # pragma: no cover
    timers = Timers()
    timers['a'] = 20.0
    timers._timings['a'] = [1.0, 2.0, 3.0]
    assert timers.count('a') == 3


# Generated at 2022-06-23 16:05:15.073397
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("name", 1)
    timers.add("name", 1)

    assert timers.mean("name") == 1.0


# Generated at 2022-06-23 16:05:21.948996
# Unit test for constructor of class Timers
def test_Timers():
    """Unit testing for Timers"""
    test = Timers()
    test.add('abc', 0.5)
    test.add('abc', 0.5)
    test.add('def', 0.5)
    test.add('def', 0.5)
    return test.data, test._timings


if __name__ == '__main__':
    DATA, TIMINGS = test_Timers()
    print('DATA:', DATA)
    print('TIMINGS:', TIMINGS)

# Generated at 2022-06-23 16:05:30.548661
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test method apply in class Timers"""
    timers = Timers()
    timers.add("Session_init", 0.1)
    timers.add("Session_init", 0.2)
    timers.add("Session_init", 0.3)

    timers.add("Session_run", 0.4)
    timers.add("Session_run", 0.5)

    timers.add("Training", 0.1)
    timers.add("Training", 0.2)
    timers.add("Training", 0.3)

    assert timers.count("Session_init") == 3
    assert timers.total("Session_init") == 0.6
    assert timers.min("Session_init") == 0.1
    assert timers.max("Session_init") == 0.3
    assert timers.mean("Session_init") == 0.2

# Generated at 2022-06-23 16:05:35.031049
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("A", 10.0)
    timers.add("A", 15.0)
    timers.add("A", 12.0)
    assert timers.max("A") == 15.0

# Generated at 2022-06-23 16:05:39.254930
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers({"timer1": 2.0, "timer2": 1.0})
    timers.add("timer1", 2.0)
    timers.add("timer2", 1.0)
    assert timers.min("timer1") == 2.0
    assert timers.min("timer2") == 1.0


# Generated at 2022-06-23 16:05:45.497830
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the method Timers.median()"""
    from .testutils import UnitTester

    tester = UnitTester(module_name=__name__, method_name="median")

    timers = Timers()
    tester.test("Median should be zero",
                expected=0,
                actual=timers.median("median_1"))
    timers.add("median_1", 2)
    tester.test("Median of 1 value is the value itself",
                expected=2,
                actual=timers.median("median_1"))
    timers.add("median_1", 3)
    timers.add("median_1", 5)
    timers.add("median_1", 10)

# Generated at 2022-06-23 16:05:53.692962
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert not timers

    timers = Timers([("foo", 1), ("bar", 2)])
    assert timers["foo"] == 1
    assert timers["bar"] == 2
    assert len(timers) == 2

    timers.add("foo", 17)
    assert len(timers) == 2
    assert timers["foo"] == 18
    assert timers.total("foo") == 18

    timers.add("a", 1)
    timers.add("a", 2)
    timers.add("a", 3)
    timers.add("b", 4)
    timers.add("b", 5)
    assert timers.count("a") == 3
    assert timers.count("b") == 2
    assert timers.mean("a") == 2.0
    assert timers.mean("b") == 4.5

# Generated at 2022-06-23 16:06:00.761232
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.data = {'timer1': 1.1, 'timer2': 2.2, 'timer3': 3.3}
    assert timers.total('timer1') == 1.1
    assert timers.total('timer2') == 2.2
    assert timers.total('timer3') == 3.3
    assert timers.total('timer4') == 0

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 16:06:05.643928
# Unit test for method median of class Timers
def test_Timers_median():
    """Testing the method median of class Timers"""
    timers = Timers()
    timers.add("a", 4)
    timers.add("a", 2)
    timers.add("a", 7)
    timers.add("a", 4)
    assert timers.median("a") == 4

test_Timers_median()

# Generated at 2022-06-23 16:06:13.918281
# Unit test for method count of class Timers
def test_Timers_count():
    """Unit test for method count of class Timers"""
    # Create a Timers instance
    timers = Timers()
    # Add one timing
    timers.add(name='test', value=2)
    # Check that the number of timing is one
    assert timers.count(name='test') == 1
    # Add two more timings
    timers.add(name='test', value=1.5)
    timers.add(name='test', value=0.5)
    # Check that number of timings is now three
    assert timers.count(name='test') == 3


# Generated at 2022-06-23 16:06:22.769414
# Unit test for method mean of class Timers
def test_Timers_mean():
    from datetime import timedelta
    from .time import Time
    from .context import Context

    # Set up context
    context = Context()
    context.read = {
        "activity": "read",
        "completedAt": "2020-05-25T14:42:14+00:00",
        "startedAt": "2020-05-25T14:42:12+00:00",
    }
    context.timers = Timers()
    # Set up time
    context.time = Time(
        timestamp=timedelta(seconds=1590454534.575062),
        completed_at="2020-05-25T14:42:14+00:00",
        started_at="2020-05-25T14:42:12+00:00",
    )

    # Update timers
    context.tim

# Generated at 2022-06-23 16:06:26.700094
# Unit test for method total of class Timers
def test_Timers_total():
    import random
    t = Timers()
    for i in range(10):
        t.add("timer_1", random.uniform(0, 5))
    assert t.total("timer_1") == t["timer_1"]
    assert t.total("timer_1") == sum(t._timings["timer_1"])


# Generated at 2022-06-23 16:06:29.981396
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('test_median', 1.5)
    timers.add('test_median', 2.5)
    assert timers.median('test_median') == 2.0

# Generated at 2022-06-23 16:06:35.495129
# Unit test for method total of class Timers
def test_Timers_total():
    instance: Timers = Timers()
    instance.add("a", 2.1)
    instance.add("a", 3.2)
    instance.add("a", 4.3)
    assert instance.total("a") == 9.6
test_Timers_total()


# Generated at 2022-06-23 16:06:38.429407
# Unit test for method count of class Timers
def test_Timers_count():
    t = Timers()
    t.add("key", 1)
    assert t.count("key")==1
    t.add("key", 1)
    assert t.count("key")==2

# Generated at 2022-06-23 16:06:47.402902
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 2)
    timers.add("b", -3)

    assert timers == {
        "a": 3,
        "b": -3,
    }

    assert timers._timings == {
        "a": [1, 2],
        "b": [-3],
    }

    assert timers.min("a") == 1
    assert timers.max("a") == 2
    assert timers.mean("a") == 1.5
    assert timers.median("a") == 1.5
    assert timers.median("b") == -3
    assert timers.count("a") == 2
    assert timers.total("a") == 3
    assert timers.stdev("a") == 0.5


# Generated at 2022-06-23 16:06:56.826204
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test method __setitem__ of class Timers"""
    from antimeta.utils import Timers
    timers = Timers()
    try:
        timers['name'] = 1
    except TypeError as err:
        assert isinstance(err, TypeError)
        assert str(err) == (
            "Timers does not support item assignment. "
            "Use '.add()' to update values."
        )
    else:
        raise ValueError(".__setitem__() allows setting values")


# Generated at 2022-06-23 16:07:00.608939
# Unit test for method max of class Timers
def test_Timers_max():
    d = Timers()
    d.add("a", 2.0)
    d.add("a", 2.5)
    d.add("a", 2.5)
    d.add("a", 2.6)
    assert(d.max("a") == 2.6)


# Generated at 2022-06-23 16:07:07.104322
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test stdev method of Timers class."""
    timers = Timers()
    timers.add('test', 1)
    assert math.isinf(timers.stdev('test'))
    timers.add('test', 2)
    assert math.isnan(timers.stdev('test'))
    timers.add('test', 3)
    assert timers.stdev('test') == 1


# Generated at 2022-06-23 16:07:15.788644
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    assert timers.data == {}
    assert timers.apply(len, "foo") == 0
    assert timers.apply(sum, "foo") == 0
    assert timers.apply(max, "foo") == 0
    assert timers.apply(min, "foo") == 0
    assert timers.apply(statistics.mean, "foo") == 0
    assert timers.apply(statistics.median, "foo") == 0
    assert timers.apply(statistics.stdev, "foo") == math.nan

    timers.add("foo", 1.0)
    assert timers.data == {"foo": 1.0}
    assert timers.apply(len, "foo") == 1
    assert timers.apply(sum, "foo") == 1.0
    assert timers.apply(max, "foo") == 1.0
   

# Generated at 2022-06-23 16:07:20.564582
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean method of Timers class"""
    timers = Timers()
    with open("test_Timers_mean.json", "r") as input_file:
        json_string = input_file.read()
        timers.data = json.loads(json_string)["data"]
    assert timers.mean("check") == 10.25


# Generated at 2022-06-23 16:07:24.775047
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """[Timers] Test stdev"""
    timers = Timers()
    timers.add('test', 1)
    assert timers.stdev('test') == math.nan # no standard deviation possible
    timers.add('test', 2)
    assert timers.stdev('test') == 0.5     # standard deviation

# Generated at 2022-06-23 16:07:27.508771
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    t = Timers()
    t.add("value", 2)
    assert t.stdev("value") == 0
    t.add("value", 4)
    assert t.stdev("value") == 1
# --------------------------------------------------------------------------------------------------

# Generated at 2022-06-23 16:07:33.943521
# Unit test for method apply of class Timers
def test_Timers_apply():
    def func(a):
        return a
    t = Timers()
    t.add("test", 1)
    t.add("test", 2)
    t.add("test", 3)
    t.add("test1", 2)
    t.add("test1", 4)
    assert t.apply(func, "test") == [1, 2, 3]
    assert t.apply(func, "test1") == [2, 4]

# Generated at 2022-06-23 16:07:36.950637
# Unit test for method add of class Timers
def test_Timers_add():
    t = Timers()
    t.add("test", 1)
    assert t["test"] == 1
    t.add("test", 5)
    assert t["test"] == 6

# Unit Tests for method clear of class Timers

# Generated at 2022-06-23 16:07:39.862874
# Unit test for method min of class Timers
def test_Timers_min():
    """ Test the min method of the Timers class"""
    timers = Timers()
    timers.add('timer', 1.0)
    timers.add('timer', 0.5)
    assert timers.min('timer') ==  0.5



# Generated at 2022-06-23 16:07:41.201450
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:07:44.206222
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("test", 42)
    assert timers.median("test") == 42



# Generated at 2022-06-23 16:07:48.203486
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("test", 2)
    t.add("test", 3)
    t.add("test", 1)
    assert t.min("test") == 1



# Generated at 2022-06-23 16:07:58.740828
# Unit test for method apply of class Timers
def test_Timers_apply():
    # Define function
    def func(data: List[float]) -> float:
        return statistics.mean(data) if len(data) else 0

    # Define a Timers object
    timers = Timers()

    # Assert that the first time calling apply leads to a KeyError
    try:
        timers.apply(func, name='mean')
        assert False
    except KeyError:
        assert True

    # Add data to the timers object
    timers.add('mean', 1)
    timers.add('mean', 2)

    # Assert that the method apply returns the correct result
    assert timers.apply(func, name='mean') == 1.5

    # Assert that the method apply still raises a KeyError for nonexistent keys

# Generated at 2022-06-23 16:08:03.305277
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add("test_timers", 0.1)
    assert timers.stdev("test_timers") == 0
    timers.add("test_timers", 0.2)
    assert timers.stdev("test_timers") == 0.1

# Generated at 2022-06-23 16:08:09.118807
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add"""
    timers = Timers()
    timers.add("test", 100.0)
    assert timers.data["test"] == 100.0
    assert timers._timings["test"] == [100.0]
    timers.add("test", 200.0)
    assert timers.data["test"] == 300.0
    assert timers._timings["test"] == [100.0, 200.0]


# Generated at 2022-06-23 16:08:10.403456
# Unit test for method median of class Timers
def test_Timers_median():
    assert Timers().median("non_existent") == math.nan

# Generated at 2022-06-23 16:08:14.927586
# Unit test for method median of class Timers
def test_Timers_median():
    """Testing Timers.median()"""
    timers = Timers()
    timers.add("foo", 1)
    timers.add("foo", 2)
    timers.add("foo", 3)
    assert timers.median("foo") == 2.0


# Generated at 2022-06-23 16:08:22.172795
# Unit test for method median of class Timers
def test_Timers_median():
    from pytest import approx
    from .timers import Timers
    timers = Timers()
    timers.add('test', 10)
    timers.add('test', 20)
    assert timers.median('test') == approx(15.0)
    timers.add('test', 30)
    assert timers.median('test') == approx(20.0)
    timers.add('test', 40)
    assert timers.median('test') == approx(25.0)

# Generated at 2022-06-23 16:08:28.308917
# Unit test for method total of class Timers
def test_Timers_total():
    timer_dict = Timers()
    timer_dict.add("A", 2.0)
    timer_dict.add("B", 1.0)
    timer_dict.add("A", 3.0)
    timer_dict.add("B", 3.0)
    assert timer_dict.total("A") == 5.0
    assert timer_dict.total("B") == 4.0
    assert timer_dict.total("C") == 0.0


# Generated at 2022-06-23 16:08:30.540251
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    timers.add('foo', 42.0)
    assert timers.data['foo'] == 42.0


# Generated at 2022-06-23 16:08:33.599906
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    testing = Timers()
    testing.add("T1", 10.0)
    testing.add("T1", 20.0)
    assert testing.mean("T1") == 15.0

# Generated at 2022-06-23 16:08:39.159951
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add('dummy', 1)
    assert timers.stdev('dummy') == math.nan
    timers.add('dummy', 1)
    assert timers.stdev('dummy') == 0
    with pytest.raises(KeyError):
        timers.stdev('dummy2')


if __name__ == "__main__":
    import pytest  # pylint: disable=import-error,wrong-import-order
    pytest.main([__file__])  # pragma: no cover

# Generated at 2022-06-23 16:08:40.384103
# Unit test for method count of class Timers
def test_Timers_count():
    assert(Timers().count("timer_name") == 0)


# Generated at 2022-06-23 16:08:50.447313
# Unit test for method total of class Timers
def test_Timers_total():
    from collections import UserDict
    from typing import Any, Dict

    timers = Timers()
    timers.add("total", 1.0)
    timers.add("total", 2.0)
    timers.add("total", 3.0)
    timers.add("empty", 0.0)

    assert isinstance(timers, collections.UserDict)
    assert timers.total("total") == 6.0
    assert timers.total("empty") == 0.0
    assert isinstance(timers, UserDict)
    assert isinstance(timers.data, Dict)
    assert isinstance(timers._timings, Dict)


# Generated at 2022-06-23 16:08:56.373710
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method add of class Timers"""
    # Create an empty Timers object
    timers = Timers()
    # Add a timing to an empty timer (i.e., value is 0 -> 4)
    timers.add('time', 4)
    # The timer should have value 4
    assert timers.data['time'] == 4

# Generated at 2022-06-23 16:09:00.224342
# Unit test for method clear of class Timers
def test_Timers_clear():

    timings = Timers()
    timings["test"] = 1.
    timings._timings["test"] = [1.]
    timings.clear()
    assert len(timings._timings) == 0
    assert len(timings.data) == 0


# Generated at 2022-06-23 16:09:03.679825
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("timer1", 10)
    timers.add("timer1", 10)
    timers.add("timer1", 12)
    max_timer = timers.max("timer1")
    assert max_timer == 12

# Generated at 2022-06-23 16:09:09.012156
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add('timer1', 0.3)
    timers.add('timer1', 1.3)
    timers.add('timer2', 0.4)
    timers.add('timer2', 1.1)
    timers.clear()

    assert timers.data == {}
    assert timers._timings == {}



# Generated at 2022-06-23 16:09:17.594309
# Unit test for method count of class Timers
def test_Timers_count():
    """Unit tests for Timers.Count() method"""
    from pysim.core.timers import Timers as Timers0

    timers = Timers0()
    assert timers.count("foo") == 0
    assert timers.count("bar") == 0

    timers.add("foo", 1)
    assert timers.count("foo") == 1
    assert timers.count("bar") == 0

    timers.add("foo", 3)
    assert timers.count("foo") == 2
    assert timers.count("bar") == 0

    timers.add("bar", 10)
    assert timers.count("foo") == 2
    assert timers.count("bar") == 1


# Generated at 2022-06-23 16:09:27.118694
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    assert timers.median("key1") == 0.0
    timers.add("key1", 5.0)
    assert timers.median("key1") == 5.0
    timers.add("key1", 10.0)
    assert timers.median("key1") == 7.5
    timers.add("key1", 12.0)
    assert timers.median("key1") == 8.0
    timers.add("key1", 8.0)
    assert timers.median("key1") == 8.0


# Generated at 2022-06-23 16:09:29.534799
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    t = Timers()
    with pytest.raises(TypeError):
        t['some_timer'] = 1.0


# Generated at 2022-06-23 16:09:38.553244
# Unit test for method stdev of class Timers
def test_Timers_stdev(): # pragma: no cover
    """Unit test for method stdev of class Timers"""
    # Test: no timings
    timers = Timers()
    assert math.isnan(timers.stdev("m1"))

    # Test: single timing
    timers.add("m1", 2.0)
    assert math.isnan(timers.stdev("m1"))

    # Test: multiple timings of same value
    timers.add("m1", 2.0)
    assert math.isnan(timers.stdev("m1"))

    # Test: multiple timings of different values
    timers.add("m1", 1.5)
    assert statistics.stdev([2.0, 2.0, 1.5]) == timers.stdev("m1")

# Generated at 2022-06-23 16:09:48.738545
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Tests that the method apply of Timers works as expected"""
    timers = Timers()
    timers.add("one", 1)
    timers.add("one", 2)
    timers.add("two", 3)
    timers.add("two", 4)
    assert(timers.apply(len, "one") == 2)
    assert(timers.apply(len, "two") == 2)
    assert(timers.apply(sum, "one") == 3)
    assert(timers.apply(sum, "two") == 7)
    assert(timers.apply(lambda x: max(x), "one") == 2)
    assert(timers.apply(lambda x: max(x), "two") == 4)
    assert(timers.apply(lambda x: min(x), "one") == 1)

# Generated at 2022-06-23 16:09:52.378551
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test that timers cannot be set"""
    from statistics import StatisticsError

    timers = Timers()
    try:
        timers["timings"] = 3.14
    except TypeError:
        pass
    else:
        raise StatisticsError("Set of timer work")


# Generated at 2022-06-23 16:10:00.341749
# Unit test for method median of class Timers
def test_Timers_median():
    from numpy import int8
    timer=Timers()
    timer.add("a",10)
    timer.add("a",20)
    timer.add("a",30)
    timer.add("a",40)
    timer.add("a",50)
    assert timer.median("a")==30
    timer.clear()
    timer.add("a",10)
    timer.add("a",20)
    assert timer.median("a")==15


# Generated at 2022-06-23 16:10:12.097517
# Unit test for method max of class Timers
def test_Timers_max():
    from rsempipeline.common import Timers
    # Create an instance of class Timers
    timers = Timers()
    # Assert that the dictionary is empty
    assert timers == {}, "Expected an empty dictionary"
    # Add some timing values for timers
    for i in range(10):
        for name in ["a", "b", "c"]:
            # Add random value to timer
            from random import random
            timers.add(name, random())
    # Assert that the maximum of timer "b" is greater than timer "a"
    assert timers.max("b") > timers.max("a"), "Expected a maximum value"
    # Define some unsupported keys
    keys = ["d", "e"] + list(range(10))
    # Assert that the maxi values of the unsupported keys are NaN

# Generated at 2022-06-23 16:10:15.848162
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timer = Timers()
    timer.add('test', 3)
    timer.add('test', 3)
    assert timer.stdev('test') == 0
    assert timer.stdev('test2') == math.nan
    timer = Timers()
    assert timer.stdev('test2') == math.nan


# Generated at 2022-06-23 16:10:21.116343
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    timers = Timers({"test": 0.0})
    timers.add("test", 1.0)
    timers.add("test", 2.0)

    assert timers.apply(lambda values: min(values or [0]), name="test") == 1
    assert timers.apply(len, name="test") == 2

# Generated at 2022-06-23 16:10:24.860784
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()

    # Assignments should fail with an error
    with pytest.raises(TypeError) as excinfo:
        timers["one"] = 1
    assert 'does not support item assignment' in str(excinfo.value)

# Generated at 2022-06-23 16:10:28.120918
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1.0)
    timers.add("test", 2.0)
    assert timers.min("test") == 1.0


# Generated at 2022-06-23 16:10:30.764407
# Unit test for method apply of class Timers
def test_Timers_apply():
    t = Timers()
    t._timings["foo"] = [1, 2, 3]
    assert t.apply(sum, "foo") == 6


# Generated at 2022-06-23 16:10:34.849964
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    timers = Timers()

    # Assert that we cannot set a timing value
    with pytest.raises(TypeError):
        timers['foo'] = 0.0


# Generated at 2022-06-23 16:10:38.721178
# Unit test for method mean of class Timers
def test_Timers_mean():
    timer = Timers()
    timer.add("Task 1", 2)
    timer.add("Task 1", 3)
    timer.add("Task 1", 4)
    assert round(timer.mean("Task 1"), 2) == 3.33



# Generated at 2022-06-23 16:10:48.325851
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    assert t.median("x") == 0.0
    t.add("x", 1.0)
    assert t.median("x") == 1.0
    t.add("x", 3.0)
    t.add("x", 2.0)
    assert t.median("x") == 2.0
    t.add("x", 4.0)
    t.add("x", 5.0)
    assert t.median("x") == 3.0
    t.add("x", 0.0)
    assert t.median("x") == 2.0


# Generated at 2022-06-23 16:10:51.391838
# Unit test for method add of class Timers
def test_Timers_add():
    """Test Timers.add method"""
    timers = Timers()
    timers.add("foo", 1)
    assert timers.data["foo"] == 1


# Generated at 2022-06-23 16:10:53.800365
# Unit test for method median of class Timers
def test_Timers_median():
    actual_result = Timers().median('name')
    expected_result = math.nan
    assert actual_result == expected_result


# Generated at 2022-06-23 16:10:58.632637
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test whether method stdev of class Timers works correctly."""
    #set a timer
    timers = Timers()
    timers.add("timer1", 10.0)
    timers.add("timer1", 20.0)
    timers.add("timer1", 30.0)
    #stdev of all add in timers
    assert timers.stdev("timer1") == 10.0

__all__ = ["Timers"]

# Generated at 2022-06-23 16:11:02.345025
# Unit test for method total of class Timers
def test_Timers_total():
    """Test that correct sum is returned"""
    t = Timers()
    t.add("A", 5)
    t.add("B", 3)
    t.add("A", 10)
    return t.total("A") == 15, t.total("B") == 3


# Generated at 2022-06-23 16:11:15.158756
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median() method of the Timers class."""
    t = Timers()
    t.add("test", 0)
    assert t.median("test") == 0

    t = Timers()
    t.add("test", 0)
    t.add("test", 0)
    t.add("test", 0)
    assert t.median("test") == 0

    t = Timers()
    t.add("test", 0)
    t.add("test", 1)
    t.add("test", 2)
    assert t.median("test") == 1

    t = Timers()
    t.add("test", 0)
    t.add("test", 1)
    t.add("test", 2)
    t.add("test", 3)

# Generated at 2022-06-23 16:11:17.887543
# Unit test for method add of class Timers
def test_Timers_add():
    result = Timers()
    result.add('hello', 1)
    assert result == {'hello': 1}


# Generated at 2022-06-23 16:11:26.173835
# Unit test for method clear of class Timers
def test_Timers_clear():  # pragma: no cover
    from pytest import approx
    from time import sleep

    timers = Timers()
    timers.add('t1', 1)
    timers.add('t2', 2)
    # Make sure we can still query
    assert timers['t1'] == 1
    assert timers['t2'] == 2
    # Clear timer
    timers.clear()
    # Make sure we can still query, but get default values
    assert timers['t1'] == 0
    assert timers['t2'] == 0


# Generated at 2022-06-23 16:11:29.855498
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test the function clear of class Timers"""
    timers = Timers()
    timers.add("name1", value=1)
    timers.add("name2", value=2)
    timers.add("name2", value=3)

    timers.clear()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:11:31.723920
# Unit test for method total of class Timers
def test_Timers_total():
    assert Timers.total(3) == 3


# Generated at 2022-06-23 16:11:34.957979
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Method __setitem__ of class Timers throws a TypeError"""
    t = Timers()
    try:
        t["first"] = 0.1
    except:
        pass
    else:
        assert False, "Expected TypeError"


# Generated at 2022-06-23 16:11:43.495920
# Unit test for method median of class Timers
def test_Timers_median():
    """Test Timers.median"""
    timers = Timers()

    timers.add("foo", 0)
    timers.add("foo", 1)
    timers.add("foo", 2)

    assert timers.median(name="foo") == 1

    timers.add("bar", 1)
    timers.add("bar", 2)
    timers.add("bar", 3)

    assert timers.median(name="bar") == 2

    timers.clear()

    assert timers.median(name="foo") == 0
    assert timers.median(name="bar") == 0

# Generated at 2022-06-23 16:11:46.074996
# Unit test for method count of class Timers
def test_Timers_count():
    '''Test method count of class Timers'''
    timers = Timers()
    timers.add("a", 1.0)
    assert timers.count("a") == 1.0

# Generated at 2022-06-23 16:11:54.433158
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()

    t.add(name="get_first", value=2.1)
    t.add(name="get_first", value=2.2)
    t.add(name="get_first", value=2.3)
    t.add(name="get_second", value=1.1)

    if t.total(name="get_first") != 6.6:
        raise AssertionError()
    if t.total(name="get_second") != 1.1:
        raise AssertionError()