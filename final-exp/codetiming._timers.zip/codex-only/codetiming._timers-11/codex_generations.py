

# Generated at 2022-06-23 16:01:50.590932
# Unit test for method count of class Timers
def test_Timers_count():
    """Test for method count of class Timers"""
    timers = Timers()
    timers.add("task1", 10)
    timers.add("task2", 20)
    timers.add("task1", 20)
    assert timers.count("task1") == 2
    assert timers.count("task2") == 1


# Generated at 2022-06-23 16:01:59.001256
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()

    # Add test data
    timers.add("example", 10)
    timers.add("example", 15)
    timers.add("example", 20)
    assert timers["example"] == 45

    # Total
    assert timers.apply(sum, "example") == 45

    # Averange
    assert timers.apply(len, "example") == 3
    assert timers.apply(lambda values: statistics.mean(values), "example") == 15

    # Minimal value
    assert timers.apply(lambda values: min(values), "example") == 10

    # Maximal value
    assert timers.apply(lambda values: max(values), "example") == 20

    # Median
    assert timers.apply(lambda values: statistics.median(values), "example") == 15

    # Standard deviation

# Generated at 2022-06-23 16:02:03.805788
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add("total_time", 2.0)
    timers.add("eval_time", 1.0)
    assert timers.mean("total_time") == 2.0
    assert timers.mean("eval_time") == 1.0

# Generated at 2022-06-23 16:02:13.643312
# Unit test for method max of class Timers
def test_Timers_max():
    """Test the 'max' method in class Timers"""
    # pylint: disable=global-statement
    global data, length

    data = {'a':0}
    length = 0

    def apply(values: List[float]) -> float:
        """Apply function"""
        return max(values)
    # pylint: enable=global-statement

    # Test that the value is set correctly
    timers = Timers()
    timers.data['b'] = data['a']
    timers.add('b', 5)
    assert timers.max('b') == 5

    # Test that the correct value is returned
    timers = Timers()
    timers.data['a'] = data['a']
    timers.add('a', 2)
    assert timers.max('a') == 2



# Generated at 2022-06-23 16:02:18.017847
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timed = []
    assert timers.min("timer") == 0
    for i in range(4):
        timers.add("timer", i)
        timed.append(i)
    assert timers.min("timer") == min(timed)


# Generated at 2022-06-23 16:02:26.476349
# Unit test for method clear of class Timers
def test_Timers_clear():
    from pytest import raises

    timers = Timers()
    timers.add("time", 0.1)
    timers.add("time", 0.2)

    timers.clear()

    assert timers._timings == {}
    assert timers.data == {}
    assert timers.total("time") == 0
    assert timers.mean("time") == 0
    assert timers.min("time") == 0

    assert len(timers) == 0
    assert not timers
    assert "time" not in timers

    with raises(KeyError):
        timers.total("not_there")


# Generated at 2022-06-23 16:02:29.948978
# Unit test for method min of class Timers
def test_Timers_min():
    import pytest

    timings = Timers()
    timings.add("test", 1)
    timings.add("test", 2)
    assert timings.min("test") == min(timings._timings["test"])

    with pytest.raises(KeyError):
        timings.min("test2")


# Generated at 2022-06-23 16:02:36.377766
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test for method mean of class Timers"""
    timers = Timers()
    timers.add("method1", 0.3)
    timers.add("method1", 0.9)
    timers.add("method2", 0.5)
    timers.add("method2", 0.2)
    timers.add("method3", 0.3)
    assert timers.mean("method1") == (0.3 + 0.9) / 2
    assert timers.mean("method2") == (0.5 + 0.2) / 2
    assert timers.mean("method3") == 0.3
    assert timers.mean("method4") == 0

# Generated at 2022-06-23 16:02:38.423271
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('a', 1)
    timers.add('a', 2)
    timers.add('a', 3)
    timers.add('b', 1)
    timers.add('b', 2)
    means = {'a':2, 'b':1.5}
    for name in timers._timings:
        assert means[name] == timers.mean(name)


# Generated at 2022-06-23 16:02:41.711393
# Unit test for constructor of class Timers
def test_Timers():
    '''Check constructor of class Timers'''
    timers = Timers()
    assert isinstance(timers, UserDict)
    assert hasattr(timers, '_timings')


# Unit tests for function add()

# Generated at 2022-06-23 16:02:45.264052
# Unit test for method add of class Timers
def test_Timers_add():
    t = Timers()
    t.add('running', 1)
    t.add('running', 1)
    assert t.data['running'] == 2
    assert t._timings['running'] == [1, 1]



# Generated at 2022-06-23 16:02:55.163329
# Unit test for method add of class Timers
def test_Timers_add():
    """Test if the timers return correct values after adding a value"""
    import random
    import math
    timer = Timers()
    tname = 'timer'
    timer.add(tname, random.random())
    assert timer._timings[tname] == ["0.9334872572645139"]
    assert timer[tname] == "0.9334872572645139"
    timer.add(tname, 0.3)
    assert timer._timings[tname] == ["0.9334872572645139", "0.3"]
    assert timer[tname] == "1.2334872572645139"
    timer.add(tname, random.random())
    timer.add(tname, 10.1)
    assert timer.count(tname) == 4

# Generated at 2022-06-23 16:02:57.451056
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    import pytest
    timers = Timers()
    with pytest.raises(KeyError):
        timers.stdev("some name")

# Run tests
if __name__ == "__main__":
    import sys
    import pytest  # type: ignore

    pytest.main(sys.argv)

# Generated at 2022-06-23 16:03:04.383682
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test method Timers.apply"""
    timers = Timers()
    timers.add("foo", 1)
    timers.add("foo", 2)
    timers.add("bar", 3)
    timers.add("baz", 4)
    assert timers.apply(len, name="foo") == 2
    assert timers.apply(sum, name="foo") == 3
    assert timers.apply(max, name="foo") == 2
    assert timers.apply(len, name="bar") == 1
    assert timers.apply(sum, name="bar") == 3
    assert timers.apply(max, name="bar") == 3
    assert timers.apply(len, name="baz") == 1
    assert timers.apply(sum, name="baz") == 4
    assert timers.apply(max, name="baz") == 4

# Unit

# Generated at 2022-06-23 16:03:08.479561
# Unit test for method stdev of class Timers
def test_Timers_stdev():
  t = Timers()
  t.add("test",0)
  assert t.stdev("test") == 0.0
  t.add("test", 1)
  assert t.stdev("test") == 0.5

# Generated at 2022-06-23 16:03:14.719576
# Unit test for constructor of class Timers
def test_Timers():
    """Test if Timers() returns a dictionary with a private data attribute."""
    timers = Timers()
    assert isinstance(timers, UserDict)
    assert isinstance(timers.data, collections.UserDict)
    assert "_timings" in timers.__dict__
    assert isinstance(timers._timings, collections.defaultdict)

# Generated at 2022-06-23 16:03:17.719166
# Unit test for method mean of class Timers
def test_Timers_mean():
    timer = Timers()
    timer.add('timer', 2)
    timer.add('timer', 3)
    assert timer.mean('timer') == 2.5

# Generated at 2022-06-23 16:03:20.567409
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    F = Timers()
    assert F.min('name') == 0


# Generated at 2022-06-23 16:03:31.461528
# Unit test for constructor of class Timers
def test_Timers():
    """Test constructor of class Timers"""
    pylint: disable=attribute-defined-outside-init

    def check(obj, klass, keys):
        """Check a Timers object"""
        assert isinstance(obj, klass)
        data_keys = set(obj.keys())
        expected_keys = set(keys)
        assert data_keys == expected_keys

    obj = Timers()
    check(obj, Timers, [])

    obj = Timers({"a": 1, "b": 2})
    check(obj, Timers, ["a", "b"])
    assert obj["a"] == 1 and obj["b"] == 2

    obj = Timers(c=3)
    check(obj, Timers, ["c"])
    assert obj["c"] == 3


# Generated at 2022-06-23 16:03:37.991920
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    # Create a Timers objects
    timers = Timers()
    # Add timing values, to compute them
    timers.add("test", 1.0)
    timers.add("test", 2.0)
    timers.add("test", 3.0)
    assert timers["test"] == 6.0
    assert round(timers.mean("test"),6) == 2.0
    assert round(timers.total("test"),6) == 6.0
    assert round(timers.stdev("test"),6) == 1.0
    assert round(timers.count("test"),6) == 3.0
    assert round(timers.max("test"),6) == 3.0
    assert round(timers.min("test"),6) == 1.0

# Generated at 2022-06-23 16:03:44.373395
# Unit test for method add of class Timers
def test_Timers_add():
    """Test add method of Timers class"""
    timers = Timers()
    timers.add('example', 1)
    assert timers['example'] == 1
    assert timers.data['example'] == 1
    assert timers._timings['example'] == [1]
    timers.clear()
    assert not timers.data
    assert not timers._timings


# Generated at 2022-06-23 16:03:50.742423
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """
    Unit test for method stdev of class Timers
    """
    # Timer without elements
    timer_wo_elem = Timers()
    assert math.isnan(timer_wo_elem.stdev('name_wo_elem'))
    # Timer with only one element
    timer_one_elem = Timers()
    timer_one_elem.add('name_one_elem', 1.)
    assert math.isnan(timer_one_elem.stdev('name_one_elem'))
    # Timer with two elements
    timer_two_elem = Timers()
    timer_two_elem.add('name_two_elem', 1.)
    timer_two_elem.add('name_two_elem', 2.)

# Generated at 2022-06-23 16:03:54.466855
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers._timings = {"a": [0, 1, 2]}
    assert timers.mean("a") == 1
    assert timers.mean("b") == 0



# Generated at 2022-06-23 16:03:58.570524
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add('foo', 1)
    assert timers.stdev('foo') is math.nan
    timers.add('foo', 1)
    assert timers.stdev('foo') == 0

# Generated at 2022-06-23 16:04:03.489679
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    module_timers = Timers()
    module_timers.add("Timer1", 20)
    module_timers.add("Timer1", 25)
    module_timers.add("Timer1", 15)
    module_timers.add("Timer1", 10)
    assert module_timers.stdev("Timer1") == math.sqrt(20)

# Generated at 2022-06-23 16:04:06.501912
# Unit test for method add of class Timers
def test_Timers_add():
    timer = Timers()
    timer.add("test", 1)
    timer.add("test", 2)
    timer.add("test", 3)
    timer.add("test", 4)
    assert timer["test"] == 10


# Generated at 2022-06-23 16:04:11.427870
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""

    # Setup
    timers = Timers()
    timers.add("T1", 1)
    timers.add("T1", 2)

    # Check
    assert timers.min("T1") == 1


# Generated at 2022-06-23 16:04:16.097571
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    assert timers == {}
    timers.add("foo", 1)
    timers.add("foo", 2)
    timers.add("foo", 3)
    assert timers == {"foo": 6}
    assert timers.min("foo") == 1
    assert timers.max("foo") == 3
    assert timers.mean("foo") == 2
    assert timers.median("foo") == 2
    assert timers.total("foo") == 6
    try:
        timers.max("bar")
    except KeyError as e:
        assert e.args == ("bar",)
    else:
        assert False
    assert str(Timers()) == "{}"
    assert str(timers) == "{'foo': 6}"
    assert repr(Timers()) == "Timers({})"

# Generated at 2022-06-23 16:04:20.554229
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    t = Timers()
    t["a"] = 1 
    t.apply()
    from Timers import Timers
    t = Timers()
    t["a"] = 1 
    t.total()

# Generated at 2022-06-23 16:04:24.252486
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test method clear of class Timers"""
    # Test constructor
    timers = Timers()
    # Test method clear
    timers.clear()

    assert len(timers) == 0
    assert len(timers._timings) == 0

# Generated at 2022-06-23 16:04:28.474331
# Unit test for method total of class Timers
def test_Timers_total():
    """Test method total"""
    timers = Timers()
    timers.add("f", 10.0)
    timers.add("f", 5.0)
    timers.add("f", 3.0)
    assert timers.total("f") == 18.0


# Generated at 2022-06-23 16:04:34.528409
# Unit test for method min of class Timers
def test_Timers_min():
    """
    Test Timers class get minimum value of a timer
    """
    timers = Timers()
    name = 'test'
    # set values
    timers.add(name, 1)
    timers.add(name, 3)
    timers.add(name, 4)
    # check values
    assert timers[name] == 8
    assert timers.min(name) == 1


# Generated at 2022-06-23 16:04:40.492655
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()
    t.add('t1', 2)
    t.add('t2', 3)
    assert t.total('t1') == 2
    assert t.total('t2') == 3
    assert t.total('t3') == 0


# Generated at 2022-06-23 16:04:45.826976
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test that stdev can be computed correctly."""
    timer = Timers()
    timer.add("test_timing", 1)
    assert timer.stdev("test_timing") == 0
    timer.add("test_timing", 2)
    assert abs(timer.stdev("test_timing") - 0.816496580927726) < 1e-12
    timer.clear()
    assert timer.stdev("test_timing") == math.nan

# Generated at 2022-06-23 16:04:51.607919
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add("Test", 3)
    timers.add("Test", 5)
    timers.add("Test", 7)
    assert timers.mean("Test") == 5


# Generated at 2022-06-23 16:05:00.032259
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    # pylint: disable=C0116
    # pylint: disable=W0612
    tmrs = Timers()
    tmrs.add("timer1", 0.123)
    tmrs.add("timer2", 0.123)
    tmrs.add("timer3", 0.456)
    assert tmrs.total("timer1") == 0.123
    assert tmrs.total("timer2") == 0.123
    assert tmrs.total("timer3") == 0.456
    assert tmrs.mean("timer1") == 0.123
    assert tmrs.mean("timer2") == 0.0615
    assert tmrs.mean("timer3") == 0.456
    assert tmrs.total("timer4")

# Generated at 2022-06-23 16:05:05.947206
# Unit test for method median of class Timers
def test_Timers_median():
    import numpy as np
    from pytest import raises
    timers = Timers()
    timers.add("test", 3)
    timers.add("test", 4)
    timers.add("test", 5)
    timers.add("test", 1)
    assert timers.median("test") == np.median([3,4,5,1])
    with raises(KeyError):
        timers.median("other")

# Generated at 2022-06-23 16:05:14.825798
# Unit test for method add of class Timers
def test_Timers_add():
    from time import time
    t0 = time()
    timers = Timers()
    # Add two entries
    timers.add('T1', 0.1)
    timers.add('T2', 0.12)
    # Value of 'T1' increases by 0.1
    assert timers['T1'] == 0.1
    # But value of 'T2' increases by 0.12
    assert timers['T2'] == 0.12
    # Add another entry
    timers.add('T1', 0.11)
    # Value of 'T1' increases to 0.21
    assert timers['T1'] == 0.21
    # 'T2' remains unchanged
    assert timers['T2'] == 0.12
    # Total time is 0.33
    assert timers.total('T1') == 0.21
    assert timers.total

# Generated at 2022-06-23 16:05:22.632170
# Unit test for method median of class Timers
def test_Timers_median():

    from .timers import Timers

    # Test Timers when median is not defined
    timers = Timers()
    assert not timers.keys()
    # Test Timers when median is defined and there are timings
    timers.add('test1', 1.0)
    timers.add('test1', 2.0)
    timers.add('test1', 3.0)
    assert timers.keys()
    assert timers.median('test1') == 2.0
    # Test Timers when median is defined and there are no timings
    timers = Timers()
    assert timers.keys()
    assert timers.median('test1') == 0.0

# Generated at 2022-06-23 16:05:25.055445
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test that we cannot set a timer value"""
    timers = Timers()
    with pytest.raises(TypeError):
        timers["bar"] = 5


# Generated at 2022-06-23 16:05:27.431060
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1.1)
    timers.add('test', 2.2)

    assert timers.min('test') == 1.1

# Generated at 2022-06-23 16:05:36.667797
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    try: t.min("test")
    except KeyError: pass
    else: raise AssertionError("Expected KeyError")

    try: t.max("test")
    except KeyError: pass
    else: raise AssertionError("Expected KeyError")

    t.add("test", 1)
    assert t.min("test") == 1
    assert t.max("test") == 1

    t.add("test", 2)
    assert t.min("test") == 1
    assert t.max("test") == 2


# Generated at 2022-06-23 16:05:47.940466
# Unit test for method clear of class Timers
def test_Timers_clear():
    t = Timers()
    t.add("t1", 10)
    t.add("t2", 20)
    expected_t_data = {'t1': 10, 't2': 20}
    assert(t.data == expected_t_data)
    expected_t_timings = {'t1': [10], 't2': [20]}
    assert(t._timings == expected_t_timings)
    t.clear()
    expected_t_data_cleared = {}
    assert(t.data == expected_t_data_cleared)
    expected_t_timings_cleared = collections.defaultdict(list, {})
    assert(t._timings == expected_t_timings_cleared)


# Generated at 2022-06-23 16:05:51.887068
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add(name="test", value=1.0)
    timers.add(name="test", value=2.0)
    assert timers.mean(name="test") == 1.5


# Generated at 2022-06-23 16:06:00.610707
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('slicing', 1.4)
    timers.add('slicing', 1.3)
    timers.add('slicing', 3.2)
    timers.add('slicing', 2.2)
    timers.add('slicing', 1.1)
    timers.add('slicing', 1.7)
    timers.add('slicing', 1.1)
    timers.add('selection', 1.0)
    assert timers.median('slicing') == 1.4
    assert timers.median('selection') == 1.0

# Generated at 2022-06-23 16:06:04.866139
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """
    Test for method __setitem__ of class Timers

    A TypeError is expected.
    """
    timers = Timers()
    with pytest.raises(TypeError, match="does not support item assignment"):
        timers['foo'] = 1.0



# Generated at 2022-06-23 16:06:10.015269
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add("1", 1)
    timers.add("2", 2)
    timers.add("3", 3)
    assert 1 == timers.stdev("1")
    assert 1 == timers.stdev("2")
    assert 1 == timers.stdev("3")

# Generated at 2022-06-23 16:06:14.927820
# Unit test for method add of class Timers
def test_Timers_add():
    """Test for method add"""
    timers = Timers()
    timers.add('timers', 1)
    timers.add('timers', 1.5)
    assert timers.data['timers'] == 2.5
    assert timers.mean('timers') == 1.25



# Generated at 2022-06-23 16:06:22.605612
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test clear method of Timers"""
    timers = Timers()
    timers.add("timer", 1)
    timers.add("timer", 2)
    timers.add("timer2", 3)
    assert timers.total("timer") == 3
    assert timers.mean("timer") == 1.5
    assert timers.mean("timer2") == 3.0
    assert timers.data["timer"] == 3
    assert timers.data["timer2"] == 3
    assert len(timers._timings["timer"]) == 2
    assert len(timers._timings["timer2"]) == 1
    timers.clear()
    assert timers.data == {}
    assert timers._timings == {}
    assert len(timers) == 0



# Generated at 2022-06-23 16:06:25.676144
# Unit test for method add of class Timers
def test_Timers_add():
    """Test function for method add of class Timers"""
    t = Timers()
    t.add('time', 0.1)
    t.add('time', 0.2)
    assert t.data['time'] == 0.3



# Generated at 2022-06-23 16:06:33.102432
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for min"""
    timers = Timers()
    assert timers.min('some_timer') == 0
    timers.add('some_timer', 1)
    assert timers.min('some_timer') == 1
    timers.add('some_timer', 2)
    assert timers.min('some_timer') == 1
    timers.add('some_timer', 0)
    assert timers.min('some_timer') == 0
    timers.add('some_timer', 3)
    assert timers.min('some_timer') == 0


# Generated at 2022-06-23 16:06:37.245576
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count("test") == 0
    timers.add("test", 1)
    assert timers.count("test") == 1
    timers.add("test", 2)
    assert timers.count("test") == 2


# Generated at 2022-06-23 16:06:41.227893
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count("foo") == 0

    timers.add("foo", 0)
    timers.add("foo", 1)
    timers.add("foo", 2)
    assert timers.count("foo") == 3
    assert timers.count("bar") == 0


# Generated at 2022-06-23 16:06:43.471588
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('Parsing', 1)
    assert timers.mean('Parsing') == 1.0

# Generated at 2022-06-23 16:06:48.174589
# Unit test for method count of class Timers
def test_Timers_count():
    from pathlib import Path
    from pypipegraph.testing_helpers import testing_pipegraph

    testing_pipegraph()
    timers = Timers()
    timers.add("something", 77)
    assert timers.count("something") == 1
    timers.add("something", 77)
    assert timers.count("something") == 2
    assert timers["something"] == 154



# Generated at 2022-06-23 16:06:53.358267
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test that __setitem__ raises a TypeError"""
    timers = Timers()
    with pytest.raises(TypeError, match="does not support item assignment"):
        timers['foo'] = 0.123

# Generated at 2022-06-23 16:07:00.936670
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    from .testing import assert_raises

    # Create a Timers object
    timers = Timers()
    assert_raises(TypeError, timers.__setitem__, "test", 1)
    assert_raises(KeyError, timers.apply, max, "test")

    # Add some values
    timers.add("test", 1)
    timers.add("test", 2)
    assert_raises(KeyError, timers.apply, max, "test2")

    # Test method apply
    assert timers.apply(len, "test") == 2

# Generated at 2022-06-23 16:07:04.272370
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add('time.logging', 1)
    value = timers.total(name='time.logging')
    assert value == 1


# Generated at 2022-06-23 16:07:10.364655
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers._timings = {
        "test_1": [2, 3, 4],
        "test_2": [],
        "test_3": [5, 6, 7],
    }
    assert timers.apply(lambda values: min(values), name="test_1") == 2
    assert timers.apply(lambda values: sum(values), name="test_1") == 9


if __name__ == "__main__":
    test_Timers_apply()

# Generated at 2022-06-23 16:07:13.564473
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('test', 1.2)
    timers.add('test', 1.1)
    assert timers.count('test') == 2


# Generated at 2022-06-23 16:07:17.669061
# Unit test for method count of class Timers
def test_Timers_count():
    # Test
    timers = Timers()
    timers.add("timer", 1.0)
    assert 1.0 == timers.count("timer")


# Generated at 2022-06-23 16:07:20.718113
# Unit test for method mean of class Timers
def test_Timers_mean():
    """unit test for method mean of class Timers"""
    x = Timers()
    x.add("first", 0.2)
    x.add("first", 0.2)
    assert x.mean("first") == 0.2



# Generated at 2022-06-23 16:07:26.304584
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    values = []
    for i in range(0, 100, 5):
        values.append(i)
        t.add('a', i)
        print(t.max('a'))
        if i != t.max('a'):
            print('Error, expected', i, 'found', t.max('a'))
    assert t.max('a') == max(values)


# Generated at 2022-06-23 16:07:31.702006
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add('a', 3)
    timers.add('a', 4)
    timers.add('b', 2)
    assert timers.total('a') == 7
    assert timers.total('b') == 2


# Generated at 2022-06-23 16:07:39.832964
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    timers = Timers()
    timers.add("foo", 124.0)
    timers.add("foo", 109.1)
    timers.add("foo", 109.2)
    assert timers.apply(sum, name="foo") == 342.3
    assert timers.apply(len, name="foo") == 3
    assert timers.apply(lambda values: min(values), name="foo") == 109.1
    assert timers.apply(lambda values: max(values), name="foo") == 124.0
    assert timers.apply(lambda values: statistics.mean(values), name="foo") == 114.1
    assert timers.apply(lambda values: statistics.median(values), name="foo") == 109.2
# test_Timers_apply()

# Generated at 2022-06-23 16:07:42.623509
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test that Timers.mean works as intended"""
    timers = Timers()
    timers.add('one', 1)
    timers.add('one', 2)
    timers.add('one', 3)
    timers.add('one', 4)
    assert timers.mean('one') == 2.5

# Generated at 2022-06-23 16:07:46.970725
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add('test_timer', 2.0)
    assert timers._timings['test_timer'] == [2.0]
    assert timers.data['test_timer'] == 2.0



# Generated at 2022-06-23 16:07:50.918889
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median value of timings"""
    timings = Timers()
    timings.add('a', 1)
    timings.add('a', 3)
    timings.add('a', 5)
    assert timings.median('a') == 3

# Generated at 2022-06-23 16:07:54.481327
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers({"1": 1.0, "2": 2.0})
    assert timers.total("1") == 1.0, "1+1 = 2"
    assert timers.total("2") == 2.0, "1+1 = 2"

# Generated at 2022-06-23 16:08:02.592577
# Unit test for method add of class Timers
def test_Timers_add():
    class Timer(object):
        def __init__(self, name: str) -> None:
            self.name = name

        def __enter__(self) -> None:
            pass

        def __exit__(self, type, value, traceback) -> None:
            return True

    timers = Timers()
    with Timer("tt"):
        pass
    timers.add("tt", 3)
    assert timers.data["tt"] ==  3
    assert timers._timings["tt"] == [3]


# Generated at 2022-06-23 16:08:05.245689
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("name", 5)
    assert timers.mean("name") == 5.0



# Generated at 2022-06-23 16:08:10.040862
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    assert len(timers) == 0
    assert timers._timings == {}
    timers.add('foo', 10)
    assert len(timers) == 1
    assert timers._timings == {'foo': [10.0]}
    timers.clear()
    assert len(timers) == 0
    assert timers._timings == {}

# Generated at 2022-06-23 16:08:12.311534
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    with pytest.raises(TypeError):
        timers["test"] = 5.0
    


# Generated at 2022-06-23 16:08:20.889442
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    assert t.median('foo') == 0.0
    t.add('foo', 1.0)
    assert t.median('foo') == 1.0
    t.add('foo', 2.0)
    assert t.median('foo') == 1.5
    t.add('foo', 3.0)
    assert t.median('foo') == 2.0
    t.add('foo', 4.0)
    assert t.median('foo') == 2.5
    t.add('foo', 5.0)
    assert t.median('foo') == 3.0
    t.add('foo', 6.0)
    assert t.median('foo') == 3.5
    t.add('foo', 7.0)

# Generated at 2022-06-23 16:08:23.139764
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add("test", 2.)
    assert timers.total("test") == 2.

# Generated at 2022-06-23 16:08:26.253007
# Unit test for method count of class Timers
def test_Timers_count():
    """Unit test for method count of class Timers"""
    t = Timers()
    assert t.count('test') == 0
    t._timings['test'].extend([1, 2])
    assert t.count('test') == 2
    assert t.min('test') == 1



# Generated at 2022-06-23 16:08:36.061026
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('total_time_of_a_method', 3.5)
    timers.add('total_time_of_a_method', 4.4)
    timers.add('total_time_of_a_method', 1.0)
    output = timers.min('total_time_of_a_method')
    assert output == 1.0
    output = timers.min('total_time_of_a_method')
    assert output == 1.0
    assert 'total_time_of_a_method' in timers._timings
    assert len(timers._timings['total_time_of_a_method']) == 3
    assert len(timers._timings) == 1
    assert 'total_time_of_a_method' in timers.data

# Generated at 2022-06-23 16:08:38.712714
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Unit test for method clear of class Timers"""

    timers = Timers({'t1': 1, 't2': 2, 't3': 3})
    timers.clear()
    assert timers.data == {}
    assert timers._timings == {}

# Generated at 2022-06-23 16:08:44.822682
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    d = Timers()
    d._timings = {'a':[1,2,3]}
    assert d.median('a') == 2
    d._timings = {'a':[1,2]}
    assert d.median('a') == 1.5

# Generated at 2022-06-23 16:08:51.760584
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test 'mean' method"""
    values = [None, 0, 0.0, [], [0], [0.0], [1,2,3]]+[[0]*i for i in range(10)] + [[5]]*1000
    for value in values:
        timers = Timers()
        timers.add('timer', value)
        assert isinstance(timers.mean('timer'), float)
        assert timers.mean('timer') == 0


# Generated at 2022-06-23 16:08:56.046962
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """
    Test Timers.__setitem__
    """

    timers = Timers()

    try:
        timers["custom"] = 5.0
    except TypeError:
        pass
    else:
        raise Exception("Should have failed")

# Generated at 2022-06-23 16:09:03.558467
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add('a', 1)
    assert timers.data == {'a': 1}
    assert timers._timings == {'a': [1]}

    timers.add('a', 2)
    assert timers.data == {'a': 3}
    assert timers._timings == {'a': [1, 2]}

    timers.add('b', 3)
    assert timers.data == {'a': 3, 'b': 3}
    assert timers._timings == {'a': [1, 2], 'b': [3]}


# Generated at 2022-06-23 16:09:08.909401
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    timers = Timers()
    timers.add("a", 1.0)
    timers.add("a", 2.0)
    timers.add("a", 3.0)
    timer_value = timers.data["a"]
    assert(timer_value == 6.0)


# Generated at 2022-06-23 16:09:13.096129
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    assert timers.total('test') == 0
    timers.add('test', 1)
    assert timers.total('test') == 1
    timers.add('test', 0.1)
    assert timers.total('test') == 1.1


# Generated at 2022-06-23 16:09:16.605719
# Unit test for method total of class Timers
def test_Timers_total():
    """
    Timers.total returns the sum of the timers for that name
    """
    timers = Timers()
    timers.add("timer1", 3.5)
    timers.add("timer1", 2.0)
    assert timers.total("timer1") == 5.5


# Generated at 2022-06-23 16:09:24.852895
# Unit test for method mean of class Timers
def test_Timers_mean():

    # Arrange
    timers = Timers()
    timers.add("foo", 1.0)
    timers.add("foo", 2.0)
    timers.add("bar", 4.0)
    timers.add("bar", 5.0)
    timers.add("bar", 6.0)

    # Act
    value = timers.mean("foo")

    # Assert
    assert value == 1.5


# Generated at 2022-06-23 16:09:32.159616
# Unit test for method apply of class Timers
def test_Timers_apply():  # pragma: no cover
    from pytest import raises

    timers = Timers()
    assert [0, 3, 0] == timers._timings["zero"]
    assert 0 == timers.apply(len, name="zero")
    assert 3 == timers.apply(sum, name="zero")
    assert 0 == timers.apply(min, name="zero")
    assert 0 == timers.apply(max, name="zero")
    assert 0 == timers.apply(statistics.mean, name="zero")
    assert 0 == timers.apply(statistics.median, name="zero")
    assert 0 == timers.apply(statistics.stdev, name="zero")



# Generated at 2022-06-23 16:09:34.162564
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("max", 1)
    timers.add("max", 3)
    timers.add("max", 2)
    assert timers.max("max") == 3


# Generated at 2022-06-23 16:09:39.726932
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    assert t.min('test') == 0
    t._timings = {'test': [2, 3, 1]}
    assert t.min('test') == 1
    t = Timers()
    assert t.min('test') == 0

# Generated at 2022-06-23 16:09:45.252466
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply() of class Timers"""
    timers = Timers()
    timers._timings["test"] = [1, 2, 3]
    assert timers.apply(sum, name="test") == 6
    assert timers.apply(lambda x: 0, name="test") == 0
    assert timers.apply(max, name="test") == 3


# Generated at 2022-06-23 16:09:49.504323
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Remove all timings"""
    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 2)
    timers.add("b", 1)
    timers.clear()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:09:53.854866
# Unit test for method max of class Timers
def test_Timers_max():
    """ Unit test for method max of class Timers """
    timer = Timers()
    name = 'test_max'
    timer.add(name, 1)
    timer.add(name, 2)
    timer.add(name, 5)
    timer.add(name, 1)
    timer.add(name, 1)
    assert timer.max(name) == 5

# Generated at 2022-06-23 16:09:58.941105
# Unit test for constructor of class Timers
def test_Timers():
    """Test constructor of class Timers"""
    timers = Timers()
    timers.add("setup", 1000)
    timers.add("setup", 2000)
    assert timers.count("setup") == 2
    assert timers.total("setup") == 3000
    assert timers.min("setup") == 1000
    assert timers.max("setup") == 2000
    assert timers.mean("setup") == 1500
    assert timers.median("setup") == 1500
    assert timers.stdev("setup") == 500

# Generated at 2022-06-23 16:10:01.083886
# Unit test for method count of class Timers
def test_Timers_count():
    assert Timers().count(name="unknown") == 0


# Generated at 2022-06-23 16:10:09.555672
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    timers = Timers()
    timers.add('test1', 2)
    timers.add('test1', 3)
    assert timers.total('test1') == 5
    assert timers.min('test1') == 2
    assert timers.max('test1') == 3
    assert timers.mean('test1') == 2.5
    assert timers.median('test1') == 2.5
    assert timers.stdev('test1') == 0.5

# Generated at 2022-06-23 16:10:14.378223
# Unit test for method count of class Timers
def test_Timers_count():
    from math import isclose
    timers = Timers()
    timers.add('a', 42)
    assert isclose(timers.count('a'), 1)
    timers.add('a', 10)
    assert isclose(timers.count('a'), 2)
    try:
        timers.count('b')
    except KeyError:
        pass
    else:
        assert False, "expected KeyError"


# Generated at 2022-06-23 16:10:16.601855
# Unit test for method count of class Timers
def test_Timers_count():
    """A method 'count' should return the number of the timing"""
    test = Timers()
    test.add("test", 7)
    assert test.count("test") == 1


# Generated at 2022-06-23 16:10:19.470037
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers._timings = {'timers': [1, 2, 3, 4, 5]}
    assert timers.min('timers') == 1


# Generated at 2022-06-23 16:10:21.133056
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    t._timings = {'a':[2, 1, 3]}
    assert t.median('a') == 2
    assert t.median('b') == 0

# Generated at 2022-06-23 16:10:26.526583
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Arrange
    timers = Timers()

    # Act
    timers.add("timer1", 1.0)
    timers.add("timer1", 2.0)

    # Assert
    assert timers.mean("timer1") == 1.5


# Generated at 2022-06-23 16:10:33.940199
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    ''' Unit test for method stdev of class Timers '''

    # pylint: disable=protected-access
    from pprint import pprint
    from . import Timers
    timers = Timers()
    pprint(timers.__dict__)
    timers._timings = {'name': [41.0, 42.0, 43.0, 44.0, 45.0, 46.0, 47.0, 48.0, 49.0, 50.0, 51.0]}
    print(timers.stdev(name='name'))
    print(timers.stdev(name='z'))
    return None


# Generated at 2022-06-23 16:10:43.474133
# Unit test for method total of class Timers
def test_Timers_total():
    """Test 'total' method of Timers class"""

    # Get parameters
    my_timers = Timers()
    my_timers.add("timer_1", 1)
    my_timers.add("timer_1", 2)
    my_timers.add("timer_1", 3)
    my_timers.add("timer_2", 4)
    my_timers.add("timer_2", 5)
    my_timers.add("timer_2", 6)

    # Check return
    assert my_timers.total("timer_1") == 6, "test_Timers_total"
    assert my_timers.total("timer_2") == 15, "test_Timers_total"

# Generated at 2022-06-23 16:10:49.658598
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit tests for Timers.add"""
    timers = Timers()
    timers.add('test', 1.5)
    assert timers['test'] == 1.5
    timers.add('test', 2.5)
    assert timers['test'] == 4.0
    assert timers._timings['test'] == [1.5, 2.5]


# Generated at 2022-06-23 16:10:53.154438
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("timing1", 1.0)
    timers.add("timing1", 2.0)
    assert timers.min("timing1") == 1.0


# Generated at 2022-06-23 16:11:04.180873
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    def _test(values, expected_mean):
        for value in values:
            timers.add(name='test', value=value)
        timers.mean('test') == expected_mean
    _test(values=[], expected_mean=0)
    _test(values=[1], expected_mean=1)
    _test(values=[1, 1], expected_mean=1)
    _test(values=[1, 2], expected_mean=1.5)
    _test(values=[0, 1, 2], expected_mean=1)
    _test(values=[1, 0, 2], expected_mean=1)
    _test(values=[1, 2, 0], expected_mean=1)
    _test(values=[1, 2, 3], expected_mean=2)

# Generated at 2022-06-23 16:11:09.400953
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add('test', 1)
    assert t.mean('test') == 1
    t.add('test', 2)
    assert t.mean('test') == 1.5


# Generated at 2022-06-23 16:11:18.250163
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers.add("A", 1)
    timers.add("A", 2)
    timers.add("A", 3)
    timers.add("A", 4)
    timers.add("B", 1)
    assert timers.apply(len, name="A") == 4
    assert timers.apply(lambda values: min(values or [0]), name="A") == 1
    assert timers.apply(lambda values: max(values or [0]), name="A") == 4
    assert timers.apply(lambda values: statistics.mean(values or [0]), name="A") == 2.5
    assert timers.apply(lambda values: statistics.median(values or [0]), name="A") == 2.5
    assert timers.apply(lambda values: statistics.stdev(values or [0]), name="A") == 1.

# Generated at 2022-06-23 16:11:25.179543
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add("test1", 1.0)
    assert timers.stdev("test1") == math.nan

    timers.add("test1", 2.0)
    assert abs(timers.stdev("test1") - 0.5) < 1e-7

    timers.add("test1", 3.0)
    assert abs(timers.stdev("test1") - 1.0) < 1e-7

# Generated at 2022-06-23 16:11:30.636508
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers._timings = {"timer1": [2, 4]}
    # Calling apply
    assert timers.apply(lambda values: min(values), "timer1") == 2
    assert timers.apply(lambda values: max(values), "timer1") == 4
    assert timers.apply(lambda values: sum(values), "timer1") == 6
    assert timers.apply(lambda values: len(values), "timer1") == 2
    assert not timers.apply(lambda values: len(values), "timer2")

# Generated at 2022-06-23 16:11:37.132676
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timer_name1 = "timer1"
    timer_name2 = "timer2"
    timers.add(timer_name1, 15)
    timers.add(timer_name1, 20)
    timers.add(timer_name1, 25)
    timers.add(timer_name2, 30)
    timers.add(timer_name2, 35)
    timers.add(timer_name2, 40)
    assert (timers.min(timer_name1) == 15) and (timers.min(timer_name2) == 30)


# Generated at 2022-06-23 16:11:43.240926
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    timers = Timers()
    assert isinstance(timers, collections.UserDict)
    assert isinstance(timers, Timers)
    assert timers.data == dict()
    for idx in range(10):
        timers.add(f"A{idx}", idx)
        assert timers[f"A{idx}"] == idx


# Generated at 2022-06-23 16:11:47.978460
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}
    assert timers['test'] == 0
    assert timers._timings == {'test': []}
    assert timers['test'] == 0

