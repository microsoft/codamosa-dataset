

# Generated at 2022-06-23 16:01:51.357695
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("a", 1)
    assert t.min("a") == 1

# Generated at 2022-06-23 16:01:58.130474
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test that any calculation of `Timers.apply` is consistent with `timings`"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    for func in [sum, min, max, len, statistics.mean, statistics.median, statistics.stdev]:
        result = func([1, 2, 3])
        assert timers.apply(func, name="test") == result

# Generated at 2022-06-23 16:02:03.549988
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test `__setitem__` with invalid values."""
    t = Timers()
    # Set item should raise `TypeError`.
    try:
        t["a"] = 1.0
    except TypeError as e:
        pass
    else:
        raise Exception("should raise TypeError")

# Generated at 2022-06-23 16:02:13.446247
# Unit test for method max of class Timers
def test_Timers_max():
    """
    Test method 'max' of class 'Timers'

    Args:
        NONE

    Returns:
        NONE

    Raises:
        Errors if the test fails
    """
    from typing import cast

    timers = Timers()

    timers.add("A", 1)
    assert timers.max("A") == timers.data["A"]

    timers.add("A", 2)
    assert timers.max("A") == timers.data["A"]

    timers.add("A", 3)
    assert timers.max("A") == timers.data["A"]

    timers.add("B", 1)
    assert timers.max("B") == timers.data["B"]

    timers.add("B", 2)
    assert timers.max("B") == timers.data["B"]


# Generated at 2022-06-23 16:02:15.450775
# Unit test for method count of class Timers
def test_Timers_count():
    t = Timers({"a": 0})
    assert t._timings == {"a": []}
    assert t.count("a") == 0


# Generated at 2022-06-23 16:02:20.972063
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    assert timers.data == {}
    timers.add("timer1", 0.1)
    assert timers.data == {"timer1": 0.1}
    timers.add("timer1", 0.1)
    assert timers.data == {"timer1": 0.2}
    assert timers._timings["timer1"] == [0.1, 0.1]


# Generated at 2022-06-23 16:02:27.257618
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Unit test of method clear"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.clear() is None
    assert timers._data is not None
    assert timers._timings is not None
    assert not timers._data
    assert not timers._timings

# Define additional method apply for class Timers

# Generated at 2022-06-23 16:02:36.672104
# Unit test for constructor of class Timers
def test_Timers():
    """Check that Timers is a dictionary that records timings"""
    from pytest import raises

    timers = Timers()
    assert timers.data == {}

    timers.add("A", 1)
    assert timers.data == {"A": 1}
    assert timers._timings == {"A": [1]}

    timers.add("A", 2)
    assert timers.data == {"A": 3}
    assert timers._timings == {"A": [1, 2]}

    with raises(TypeError):
        timers["B"] = 1

    assert timers.count("A") == 2
    assert timers.count("B") == 0

    with raises(TypeError):
        timers["B"] = 1

    assert timers.total("A") == 3
    assert timers.total("B") == 0

    assert timers.min("A") == 1
   

# Generated at 2022-06-23 16:02:45.415403
# Unit test for constructor of class Timers
def test_Timers():
    """Test Timers constructor"""
    import unittest

    class TestTimers(unittest.TestCase):
        """Test Timers constructor"""

        def test_basic(self) -> None:
            """Test basic functioning of constructor and methods"""
            timers = Timers()
            timers.add("foo", 4)
            timers.add("bar", 5)
            timers.add("bar", 6)
            self.assertEqual(timers["foo"], 4)
            self.assertEqual(timers["bar"], 11)
            self.assertEqual(timers.get("foo", None), 4)
            self.assertEqual(timers.get("bar", None), 11)
            self.assertEqual(timers.get("baz", None), None)
            self.assertIsNone(timers.get("baz"))

# Generated at 2022-06-23 16:02:50.538638
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """
    This method test if the stdev returns a meaningful value
    """
    # create a new instance
    timer = Timers()
    # add a timing entry
    timer.add("test", [1, 2, 3])
    #calculate if the stdev is correct
    if timer.stdev("test") != 1:
        raise ValueError

# Generated at 2022-06-23 16:02:59.768817
# Unit test for method median of class Timers
def test_Timers_median():
    t1 = Timers()
    assert math.isnan(t1.median("my_timer"))
    t1.add("my_timer", 1)
    assert t1.median("my_timer") == 1
    t1.add("my_timer", 2)
    assert t1.median("my_timer") == 1.5
    t1.add("my_timer", 3)
    assert t1.median("my_timer") == 2
    t1.add("my_timer", 4)
    assert t1.median("my_timer") == 2.5
    assert math.isnan(t1.median("my_timer2"))

# Generated at 2022-06-23 16:03:05.077000
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """
    Test method stdev of class Timers

    ValueError is raised, if standard deviation of a list of less than two numbers is calculated.
    This can be avoided by catching the exception.
    """
    try:
        assert Timers({"k": [0]}).stdev("k") != 0.0
    except ValueError:
        return 0

# Generated at 2022-06-23 16:03:08.295214
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count("test") == 0

    timers.add("test", 1.0)
    timers.add("test", 3.0)
    assert timers.count("test") == 2

    assert timers.count("other") == 0


# Generated at 2022-06-23 16:03:12.671189
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 3)
    assert timers.median("test") == 2

# Generated at 2022-06-23 16:03:21.893253
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    timers = Timers()
    timers.add("a", 1)
    timers.add("b", 2)
    timers.add("b", 3)
    assert timers.apply(lambda x: sum(x), name="a") == 1
    assert timers.apply(lambda x: sum(x), name="b") == 5
    assert timers.apply(lambda x: len(x), name="a") == 1
    assert timers.apply(lambda x: len(x), name="b") == 2
    assert timers.apply(lambda x: max(x), name="a") == 1
    assert timers.apply(lambda x: max(x), name="b") == 3
    assert timers.apply(lambda x: min(x), name="a") == 1

# Generated at 2022-06-23 16:03:28.191915
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method add of class Timers"""
    timers = Timers()
    assert timers == {}
    timers.add('foo', 0.1)
    assert timers == {'foo': 0.1}
    timers.add('foo', 0.1)
    assert timers == {'foo': 0.2}
    timers.add('bar', 0.4)
    assert timers == {'foo': 0.2, 'bar': 0.4}


# Generated at 2022-06-23 16:03:33.943771
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add("cat", 2)
    t.add("dog", 0.5)
    t.add("cat", 3)
    t.add("dog", 0.25)
    t.add("cat", 2)
    t.add("dog", 0.25)

    assert t['cat'] == 7
    assert t['dog'] == 1
    assert t.mean('cat') == 2.33
    assert t.mean('dog') == 0.5


# Generated at 2022-06-23 16:03:36.711415
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add('test', 10)
    timers.add('test2', 20)
    timers.clear()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:03:41.028064
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Unit tests for method clear of class Timers"""
    timers = Timers()
    timers._timings["foo"] = [1.0, 2.0]

    timers.clear()

    assert timers.data == {}
    assert timers._timings == {"foo": []}


# Generated at 2022-06-23 16:03:46.501921
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Initialize Timers Object
    timers = Timers()
    # Check mean function with data
    timers.data['Hello'] = 10
    assert timers.mean('Hello') == 10
    # Check mean function without data
    assert timers.mean('World') == 0
    # Check mean function with string data (TypeError)
    timers.data['Hello'] = 'World'
    with pytest.raises(TypeError):
        timers.mean('Hello')
    # Check mean function with bad name (KeyError)
    with pytest.raises(KeyError):
        timers.mean('Bo-Bo')

test_Timers_mean()


# Generated at 2022-06-23 16:03:48.895244
# Unit test for method total of class Timers
def test_Timers_total():
    """ test_Timers_total(timers: Timers) -> NoneType """
    timers = Timers()
    timers.add("a", 3)
    assert timers.total("a") == 3
    assert timers.total("b") == 0


# Generated at 2022-06-23 16:03:51.485486
# Unit test for constructor of class Timers
def test_Timers():
    """Check if initialization works"""
    t = Timers()
    assert t["name"] == 0


# Generated at 2022-06-23 16:04:02.750300
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test method apply of class Timers"""
    # Define a class that stores timings
    timers = Timers()
    timers.add("first", 1.1)
    timers.add("first", 2.2)
    timers.add("second", 1.23)
    # Total time for all timings
    assert timers.total("first") == 3.3
    assert timers.total("second") == 1.23
    # Count number of elements for each timer
    assert timers.count("first") == 2
    assert timers.count("second") == 1
    # Minimal value for each timer
    assert timers.min("first") == 1.1
    assert timers.min("second") == 1.23
    # Maximal value for each timer
    assert timers.max("first") == 2.2
    assert timers.max("second") == 1

# Generated at 2022-06-23 16:04:07.653516
# Unit test for method count of class Timers
def test_Timers_count():
    t = Timers()
    t.add('foo', 6)
    assert t.count('foo') == 1
    t.add('foo', 2)
    assert t.count('foo') == 2
    t.add('bar', 4)
    assert t.count('bar') == 1
    t.add('bar', 4)
    assert t.count('bar') == 2


# Generated at 2022-06-23 16:04:12.118492
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test if method Timers.__setitem__ raises TypeError"""
    timers = Timers()
    try:
        timers["foo"] = 1.0
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 16:04:15.287283
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add(name="f", value=1.2)
    assert len(timers) == 1
    timers.clear()
    assert len(timers) == 0

# Generated at 2022-06-23 16:04:21.097273
# Unit test for method min of class Timers
def test_Timers_min():
    tm = Timers()
    assert tm.min("test") == 0
    tm._timings["test"] = [2, 1, 3]
    assert tm.min("test") == 1
    assert tm.min("notest") == 0
    assert tm.min("notest") == 0

# Generated at 2022-06-23 16:04:29.013048
# Unit test for constructor of class Timers
def test_Timers():
    t = Timers()
    # t == {}
    # t._timings == {}
    t.add('a', 10)
    t.add('a', 20)
    t.add('a', 30)
    t.add('b', 100)
    t.add('b', 200)
    # t == {'a': 60, 'b': 300}
    assert t.total('a') == 60
    assert t.total('b') == 300
    assert t['a'] == 60
    assert t.min('a') == 10
    assert t.max('a') == 30
    assert t.mean('a') == 20
    assert t.stdev('a') == 10


# Generated at 2022-06-23 16:04:34.596778
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    assert timers.mean('foo') == 0
    assert not math.isnan(timers.stdev('foo'))
    timers.add('foo', 1)
    assert math.isnan(timers.stdev('foo'))
    timers.add('foo', 2)
    assert not math.isnan(timers.stdev('foo'))

# Generated at 2022-06-23 16:04:43.282143
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method add of class Timers"""
    timers = Timers()
    timers.add(name="foo", value=1.0)
    assert timers["foo"] == 1.0
    timers.add(name="foo", value=1.0)
    assert timers["foo"] == 2.0
    timers.add(name="bar", value=1.0)
    assert timers["bar"] == 1.0
    assert timers.count("foo") == 2
    assert timers.count("bar") == 1


# Generated at 2022-06-23 16:04:48.977351
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    t = Timers()

    t['a'] = 20
    assert t.stdev('a') == 0
    assert math.isnan(t.stdev('b'))

    t['a'] = 25
    assert t.stdev('a') == math.sqrt(25/12)

# Generated at 2022-06-23 16:04:56.860427
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Ensure that Timers._apply() works as expected"""
    tm = Timers()
    tm.add('foo', 2.34)
    tm.add('foo', 0.23)
    tm.add('foo', 11.12)
    tm.add('bar', -4.56)
    assert tm.apply(sum, 'foo') == 13.69
    assert tm.apply(lambda values: values[0] / values[1], 'foo') == 10.1464

    with pytest.raises(KeyError) as error:
        tm.apply(len, 'baz')
    assert error.value.args == ('baz',)

# Generated at 2022-06-23 16:05:02.532579
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Unit test for method clear of class Timers"""
    import timeit

    # Create timers
    timers = Timers()
    timers.add("numpy", timeit.timeit("import numpy", number=1))
    timers.add("scipy", timeit.timeit("import scipy", number=1))
    timers.add("matplotlib", timeit.timeit("import matplotlib", number=1))
    assert sorted(timers.keys()) == ["matplotlib", "numpy", "scipy"]

    # Clear timers
    timers.clear()
    assert timers == {}
    assert timers._timings == {}

# Generated at 2022-06-23 16:05:10.687991
# Unit test for method min of class Timers
def test_Timers_min():

    # Import standard library modules
    import time
    import unittest

    # Define class Timers
    class Timers(collections.UserDict):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args, **kwargs)
            self._timings: Dict[str, List[float]] = collections.defaultdict(list)

        def add(self, name: str, value: float) -> None:
            self._timings[name].append(value)
            self.data.setdefault(name, 0)
            self.data[name] += value

        def clear(self) -> None:
            self.data.clear()
            self._timings.clear()


# Generated at 2022-06-23 16:05:14.460031
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    return timers.data, timers._timings


# Generated at 2022-06-23 16:05:18.216034
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('test1', 2.3)
    timers.add('test1', 1.23)
    res = timers.mean('test1')
    assert type(res) == float
    assert res == 1.765


# Generated at 2022-06-23 16:05:26.097892
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count("foo") == 0
    timers.add("foo", 1.0)
    assert timers.count("foo") == 1
    timers.add("foo", 2.0)
    assert timers.count("foo") == 2
    timers.add("bar", 1.0)
    assert timers.count("foo") == 2
    assert timers.count("bar") == 1
    timers.add("bar", 2.0)
    timers.add("bar", 3.0)
    assert timers.count("bar") == 3
    timers.add("baz", 2.0)
    assert timers.count("baz") == 1
    timers.clear()
    assert timers.count("foo") == 0
    assert timers.count("bar") == 0
    assert timers.count("baz") == 0



# Generated at 2022-06-23 16:05:29.508976
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("eins", 0.1)
    timers.add("eins", 0.2)
    timers.add("zwei", 0.3)
    timers.add("zwei", 0.4)
    assert timers.count("eins") == 2.0
    assert timers.count("zwei") == 2.0


# Generated at 2022-06-23 16:05:40.922598
# Unit test for method median of class Timers
def test_Timers_median():
    """Test that median value of timings is correctly returned"""
    timer = Timers()

    timer.add('a', 1)
    timer.add('a', 2)
    timer.add('b', 2)
    timer.add('b', 3)

    # Test all functions
    assert timer.count('a') == 2
    assert timer.count('b') == 2

    assert timer.total('a') == 3
    assert timer.total('b') == 5

    assert timer.min('a') == 1
    assert timer.min('b') == 2

    assert timer.max('a') == 2
    assert timer.max('b') == 3

    assert timer.mean('a') == 1.5
    assert timer.mean('b') == 2.5

    assert timer.median('a') == 1.5

# Generated at 2022-06-23 16:05:48.373846
# Unit test for method add of class Timers
def test_Timers_add():
    """Test Timers.add()"""
    timers = Timers()
    timers.add("timer_1", 1)
    timers.add("timer_1", 2)
    timers.add("timer_2", 3)
    timers.add("timer_2", 4)
    assert timers.data == {"timer_1": 3, "timer_2": 7}
    assert timers._timings == {"timer_1": [1, 2], "timer_2": [3, 4]}
    assert sum(timers._timings.values(), []) == [1, 2, 3, 4]


# Generated at 2022-06-23 16:05:54.780692
# Unit test for method apply of class Timers
def test_Timers_apply():
    # store some timings
    timers = Timers(data={"a": 1.1, "b": 2.2})
    timers._timings = {"a": [1.1, 1.2, 1.3], "b": [2.1, 2.2, 2.3]}
    # try an unknown name
    with pytest.raises(KeyError):
        timers.apply(len, "unknown")
    # count
    assert timers.count("a") == 3
    assert timers.count("b") == 3
    # total
    assert timers.total("a") == 3.6
    assert timers.total("b") == 6.6
    # min
    assert timers.min("a") == 1.1
    assert timers.min("b") == 2.1
    # max
    assert timers.max("a") == 1

# Generated at 2022-06-23 16:06:02.095638
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    timers = Timers()
    name = "test"
    assert name not in timers.data
    assert name not in timers._timings
    values = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    for value in values:
        timers.add(name, value)
    assert timers.total(name) == sum(values)
    assert timers.stdev(name) == 2.8722813232690143

# Generated at 2022-06-23 16:06:06.857409
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert isinstance(timers, UserDict)
    assert isinstance(timers, Timers)
    assert isinstance(timers._timings, collections.defaultdict)
    assert timers._timings == collections.defaultdict(list)
test_Timers()


# Generated at 2022-06-23 16:06:11.385346
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    timers = Timers()
    timers.add("min_test", 2)
    timers.add("min_test", 1)
    timers.add("min_test", 3)
    assert timers.min("min_test") == 1


# Generated at 2022-06-23 16:06:15.336459
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    # Setup
    timers = Timers()
    # Assert
    try:
        timers['not_allowed'] = 1
    except TypeError as e:
        assert "not support item assignment" in str(e)
    else:
        assert False

# Generated at 2022-06-23 16:06:18.414745
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test of method Timers_apply"""
    timers = Timers()
    timers.add("mytimer", 0.1)
    assert timers.mean("mytimer") == 0.1


# Generated at 2022-06-23 16:06:22.816768
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method add of class Timers"""
    timers = Timers()
    for _ in range(5):
        timers.add("test", 2.5)
    assert timers["test"] == 12.5


# Generated at 2022-06-23 16:06:27.300291
# Unit test for method max of class Timers
def test_Timers_max():
    import numpy as np
    timers = Timers()
    timers.add('timer', 0)
    timers.add('timer', np.inf)
    assert timers.max('timer') == np.inf


# Generated at 2022-06-23 16:06:28.529034
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add("Test1", 1.0)
    timers.add("Test1", 2.0)
    assert timers.total("Test1") == 3.0

# Generated at 2022-06-23 16:06:33.236325
# Unit test for method clear of class Timers
def test_Timers_clear():
    # Test the clear method of class Timers
    timers = Timers()
    timers.add("Test", 5)
    assert timers["Test"] == 5
    assert len(timers._timings["Test"]) == 1
    timers.clear()
    assert timers["Test"] == 0
    assert len(timers._timings["Test"]) == 0


# Generated at 2022-06-23 16:06:37.038352
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()

    timers.add('test', 1.0)
    assert timers.max('test') == 1.0
    timers.add('test', 2.0)
    assert timers.max('test') == 2.0


# Generated at 2022-06-23 16:06:39.846686
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers({'a': 10})
    t._timings['a'] = [1, 2, 3, 4, 5]
    assert t.median('a') == 3.0



# Generated at 2022-06-23 16:06:40.787130
# Unit test for constructor of class Timers
def test_Timers():
    assert isinstance(Timers(), Timers)

# Generated at 2022-06-23 16:06:46.298814
# Unit test for method count of class Timers
def test_Timers_count():
    """Test if count() runs properly"""
    timers = Timers()
    timers.add('name', value=0)
    timers.add('name', value=0.1)
    timers.add('name', value=0.2)
    timers.add('name', value=0.3)
    timers.add('name', value=0.4)
    timers.add('name', value=0.5)
    assert timers.count('name') == 6


# Generated at 2022-06-23 16:06:48.240232
# Unit test for constructor of class Timers
def test_Timers():
    """Run doctests on class Timers"""
    import doctest

    doctest.testmod(Timers)


if __name__ == "__main__":
    test_Timers()

# Generated at 2022-06-23 16:06:56.623933
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for method stdev of class Timers"""
    from statistics import stdev
    from pytest import approx

    timers = Timers()
    timers['test'] = 574.8
    timers.add('test', 100)
    timers.add('test', 203)
    timers.add('test', 556)
    timers.add('test', 376)
    assert timers.stdev('test') == approx(172.26, abs=0.01)

# Generated at 2022-06-23 16:07:05.521956
# Unit test for constructor of class Timers
def test_Timers():
    """Test the constructor of the Timers class"""
    # Test default value for data
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}
    # Test given values for data
    timers = Timers({'abc': 123.45, 'def': 654.321})
    assert timers.data == {'abc': 123.45, 'def': 654.321}
    assert timers._timings == {}
    # Test given values for data and timings
    timers = Timers({'abc': 123.45, 'def': 654.321}, {'abc': [123.45], 'def': [654.321]})
    assert timers.data == {'abc': 123.45, 'def': 654.321}

# Generated at 2022-06-23 16:07:08.061715
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("t1", 3.0)
    assert timers.min("t1") == 3.0



# Generated at 2022-06-23 16:07:16.747399
# Unit test for constructor of class Timers
def test_Timers():
    t = Timers()
    t.add('a', 0.1)
    t.add('a', 0.2)
    t.add('b', 1)
    t.add('b', 2)
    assert t.count('a') == 2
    assert t.count('b') == 2
    assert t.total('a') == 0.3
    assert t.total('b') == 3
    assert math.isclose(t.min('a'), 0.1)
    assert math.isclose(t.min('b'), 1)
    assert math.isclose(t.max('a'), 0.2)
    assert math.isclose(t.max('b'), 2)
    assert math.isclose(t.mean('a'), 0.15)

# Generated at 2022-06-23 16:07:20.846345
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert isinstance(timers._timings, collections.defaultdict)
    assert isinstance(timers._timings[str], list)
    assert timers._timings == {}
    assert isinstance(timers.data, dict)
    assert isinstance(timers.data, collections.UserDict)
    assert timers == {}

# Generated at 2022-06-23 16:07:25.081991
# Unit test for method count of class Timers
def test_Timers_count():
    """Unit test for method count of class Timers"""
    timer = Timers()
    assert timer.count("test timer") == 0
    timer.add("test timer", 2)
    assert timer.count("test timer") == 1
    timer.add("test timer", 2)
    assert timer.count("test timer") == 2


# Generated at 2022-06-23 16:07:28.919367
# Unit test for constructor of class Timers
def test_Timers():  # pragma: no cover
    """Test constructor of class Timers"""
    timers = Timers()
    timers.add('a', 5)
    timers.add('a', 10)
    timers.add('a', 15)
    assert timers.mean('a') == 10
    assert timers.median('a') == 10
    assert timers.stdev('a') == 5

# Generated at 2022-06-23 16:07:30.627479
# Unit test for method max of class Timers
def test_Timers_max():
    assert Timers().max('foo') == 0

# Generated at 2022-06-23 16:07:37.327498
# Unit test for method max of class Timers
def test_Timers_max():
    """Ensure Timers.max works as expected"""
    timers = Timers()
    assert timers.max("a") == 0.0, "Expected 0.0, got something else"
    timers = Timers()
    timers._timings = {"a": [2,1,3]}
    assert timers.max("a") == 3.0, "Expected 3.0, got something else"
    timers = Timers()
    timers._timings = {"a": []}
    assert timers.max("a") == 0.0, "Expected 0.0, got something else"


# Generated at 2022-06-23 16:07:42.655844
# Unit test for method total of class Timers
def test_Timers_total():
    # setup
    timers = Timers()
    timers._timings = {
        "timer1": [0.1, 0.2, 0.3],
        "timer2": [0.4, 0.5, 0.6],
        "timer3": [0.7, 0.8, 0.9],
    }
    # assert
    assert timers.total("timer1") == 0.1 + 0.2 + 0.3
    assert timers.total("timer2") == 0.4 + 0.5 + 0.6
    assert timers.total("timer3") == 0.7 + 0.8 + 0.9


# Generated at 2022-06-23 16:07:47.019184
# Unit test for method count of class Timers
def test_Timers_count():
    """Test the method count of class Timers"""
    print("test_Timers_count")
    timers = Timers()
    timers.add("test_timer", 10)
    assert timers.count("test_timer") == 1


# Generated at 2022-06-23 16:07:51.672787
# Unit test for method stdev of class Timers
def test_Timers_stdev():  # pragma: no cover
    """Test method stdev of class Timers"""
    timers = Timers()
    timers.add("force_field", 0.1)
    timers.add("force_field", 0.2)
    timers.add("force_field", 0.4)
    timers.add("force_field", 0.8)
    print("method stdev of class Timers")
    print("Unit test passed")
    return

# Generated at 2022-06-23 16:08:02.591127
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    assert len(timers._timings) == 0

    # Use string keys
    timers.add('key', 1)
    assert len(timers._timings) == 1
    assert timers._timings['key'] == [1]
    assert timers.data['key'] == 1

    # Overload string key
    timers.add('key', 1)
    assert len(timers._timings) == 1
    assert timers._timings['key'] == [1, 1]
    assert timers.data['key'] == 2

    # Use integer keys
    timers.add(2, 1)
    assert len(timers._timings) == 2
    assert timers._timings[2] == [1]
    assert timers.data[2] == 1

    # Overload integer key

# Generated at 2022-06-23 16:08:08.256605
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    assert timers.min("test") == 0.
    timers.add("test", 0.5)
    assert timers.min("test") == 0.5
    timers.add("test", 0.6)
    assert timers.min("test") == 0.5
    timers.add("test", 0.4)
    assert timers.min("test") == 0.4


# Generated at 2022-06-23 16:08:14.010807
# Unit test for method add of class Timers
def test_Timers_add():
    # Arrange
    timer = Timers()
    timer_name = "test_Timers_add"
    timer_value = 123

    # Act
    timer.add(timer_name, timer_value)

    # Assert
    timer_value_result = timer.data[timer_name]
    assert timer_value_result == timer_value


# Generated at 2022-06-23 16:08:15.847231
# Unit test for method min of class Timers
def test_Timers_min():
    """
    Test min method of class Timers
    """
    # Create a Timers object
    timers = Timers()
    assert timers.min('timer1') == 0


# Generated at 2022-06-23 16:08:20.479865
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers["test"] = 1.0
    except TypeError as e:
        assert "Use '.add()' to update values." in str(e)
    else:
        assert False, "TypeError not thrown"


# Generated at 2022-06-23 16:08:23.603079
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("a", 0)
    assert timers.max("a") == 0
    timers.add("a", 2)
    assert timers.max("a") == 2
    timers.add("a", 1)
    assert timers.max("a") == 2
    timers.add("a", 2)
    assert timers.max("a") == 2
    assert timers.max("b") == 0


# Generated at 2022-06-23 16:08:27.868092
# Unit test for method add of class Timers
def test_Timers_add():
    input_value = Timers()
    input_value.add('me', 2)
    assert input_value.data['me'] == 2
    input_value.add('me', 3)
    assert input_value.data['me'] == 5
    assert input_value._timings['me'] == [2, 3]

# Generated at 2022-06-23 16:08:33.256878
# Unit test for method count of class Timers
def test_Timers_count():
    t = Timers()
    assert t.count("timer1") == 0
    t.add("timer1", 1)
    assert t.count("timer1") == 1
    t.add("timer1", 1)
    assert t.count("timer1") == 2
    t.add("timer2", 1)
    assert t.count("timer1") == 2
    assert t.count("timer2") == 1

# Generated at 2022-06-23 16:08:35.753240
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test method __setitem__ of class Timers"""
    timers = Timers()
    with pytest.raises(TypeError):
        timers["Test"] = 1.0  # type: ignore


# Generated at 2022-06-23 16:08:40.534705
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("timer1", 2)
    timers.add("timer1", 3)
    timers.add("timer2", 50)
    timers.add("timer2", 50)
    timers.add("timer2", 50)
    timers.add("timer2", 50)
    assert timers.mean("timer1") == 2.5
    assert timers.mean("timer2") == 50.0


# Generated at 2022-06-23 16:08:48.020249
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    t = Timers()
    t._timings = {'time': [0, 0]}
    assert t.stdev('time') == 0
    t._timings = {'time': []}
    assert math.isnan(t.stdev('time'))
    t._timings['time'].append(0)
    assert math.isnan(t.stdev('time'))
    t._timings['time'].append(0)
    assert t.stdev('time') == 0

# Generated at 2022-06-23 16:08:51.758444
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test that mean method works as expected"""
    timers = Timers()
    for i in range(1000):
        timers.add("time", 1.2)
    assert 0.8 <= timers.mean("time") <= 1.6


# Generated at 2022-06-23 16:08:56.418409
# Unit test for constructor of class Timers
def test_Timers():
    """Constructor of class Timers"""
    timers = Timers()
    assert timers is not None
    assert isinstance(timers, Timers)
    assert isinstance(timers, UserDict)
    assert timers._timings == {}
    assert timers.data == {}


# Generated at 2022-06-23 16:08:59.609045
# Unit test for method count of class Timers
def test_Timers_count():
    data = {'key1': [0, 1, 2]}
    t1 = Timers(data=data)
    assert t1.count('key1') == 3
    assert t1.count('key2') == 0

# Generated at 2022-06-23 16:09:02.720360
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the median function"""
    timers = Timers()
    timers.add("foo", 6)
    timers.add("foo", 1)
    assert timers.median("foo") == 3.5

# Generated at 2022-06-23 16:09:05.778665
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert len(timers) == 0
    assert len(timers._timings) == 0
    assert not timers


# Generated at 2022-06-23 16:09:09.537480
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add('foo', 1.0)
    timers.add('foo', 2.0)
    assert timers.count('foo') == 2
    assert timers.total('foo') == 3.0
    timers.clear()
    assert timers.count('foo') == 0
    assert timers.total('foo') == 0.0


# Generated at 2022-06-23 16:09:15.027580
# Unit test for method count of class Timers
def test_Timers_count():
    """Test method count of class Timers"""
    timers = Timers()
    assert not timers
    timers.add("test", 1)
    assert timers.count("test") == 1
    timers.add("test", 2)
    assert timers.count("test") == 2
    timers.add("test", 3)
    assert timers.count("test") == 3


# Generated at 2022-06-23 16:09:20.088874
# Unit test for method total of class Timers
def test_Timers_total():
    # Given
    timers = Timers()
    timers.add(name='work', value=1)
    timers.add(name='work', value=2)
    timers.add(name='work', value=3)
    timers.add(name='play', value=2)
    timers.add(name='play', value=3)
    # When
    total_work = timers.total(name='work')
    total_play = timers.total(name='play')
    # Then
    assert total_work == 6
    assert total_play == 5

# Generated at 2022-06-23 16:09:26.288374
# Unit test for method max of class Timers
def test_Timers_max():
    """Unit test for method max of class Timers"""
    # Check that the method raises ValueError for an empty dictionary
    timers = Timers()
    with pytest.raises(KeyError):
        timers.max("name")
    # Check that the method returns zero for empty values
    timers.add("name", 0)
    timers.add("name", 2)
    assert timers.max("name") == 2


# Generated at 2022-06-23 16:09:29.042219
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.data["test"] == 3


# Generated at 2022-06-23 16:09:35.644083
# Unit test for method add of class Timers
def test_Timers_add():
    """Timers - Unit test for method add of class Timers"""

    timers = Timers()
    timers.add('foo', 1.5)
    timers.add('bar', 3.5)

    # Check total time
    assert timers['foo'] == 1.5
    assert timers['bar'] == 3.5
    timers.add('foo', 1.5)
    assert timers['foo'] == 3.0

    # Check number of timings
    assert timers.count('foo') == 2
    assert timers.count('bar') == 1


# Generated at 2022-06-23 16:09:37.933797
# Unit test for constructor of class Timers
def test_Timers():
    """The constructor of class Timers"""
    timers = Timers()
    assert isinstance(timers._timings, dict)

# Generated at 2022-06-23 16:09:42.106558
# Unit test for method max of class Timers
def test_Timers_max():
    timer = Timers()
    timer.add('a', 0.02)
    timer.add('a', 0.01)
    timer.add('b', 0.02)

    assert timer.max('a') == 0.02
    assert timer.max('b') == 0.02

# Generated at 2022-06-23 16:09:50.119269
# Unit test for method mean of class Timers
def test_Timers_mean():
    """
    Unit test for method mean of class Timers

    Returns
    -------
    bool
        True if successful, False otherwise
    """
    # Create a timers object
    t = Timers()

    # Add a few values to the timers object
    t.add(name="n1", value=1)
    t.add(name="n1", value=2)
    t.add(name="n1", value=3)

    # Calculate the mean
    mean = t.mean(name="n1")

    # Check the result
    correct = 2
    assert mean == correct, f"Wrong mean value: {mean}"

    # Return
    return True

# Generated at 2022-06-23 16:09:55.000675
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test1", 1)
    timers.add("test1", 5)
    result_expected = 1
    assert (
        timers.min("test1") == result_expected
    ), f"{timers.min('test1')} != {result_expected}"


# Generated at 2022-06-23 16:10:00.838708
# Unit test for method apply of class Timers
def test_Timers_apply():
    from datetime import datetime
    from time import sleep

    t = Timers()
    for _ in range(10):
        dt = datetime.now()
        sleep(0.1)
        t.add("foo", (datetime.now() - dt).total_seconds())

    assert round(t.mean("foo") * 1000, 1) == 100

# Generated at 2022-06-23 16:10:05.674125
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add('timer1', 1)
    timers.add('timer1', 2)
    timers.add('timer2', 3)
    assert timers.total('timer1') == 3


# Generated at 2022-06-23 16:10:08.696176
# Unit test for method median of class Timers
def test_Timers_median():
    """Test Timers"""
    pass


# Execute doctests
if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 16:10:16.679338
# Unit test for method stdev of class Timers
def test_Timers_stdev():             # pragma: no cover
    """Unit test for method stdev of class Timers"""
    timers = Timers()
    timers.add('my_timer', 4)
    timers.add('my_timer', 9)
    assert round(timers.stdev('my_timer'), 9) == 4.0
    timers.clear()
    timers.add('my_timer', 4)
    timers.add('my_timer', 5)
    assert round(timers.stdev('my_timer'), 9) == 0.7071067811865476
    print('test_Timers_stdev: OK')

# Execute the unit tests
if __name__ == '__main__':             # pragma: no cover
    test_Timers_stdev()

# Generated at 2022-06-23 16:10:27.300384
# Unit test for constructor of class Timers
def test_Timers():
    "Test Timers constructor"
    # Default constructor
    timers = Timers()
    assert(isinstance(timers, Timers))
    assert(timers.data == {})
    assert(timers._timings == collections.defaultdict(list, {}))
    # Explicit constructor
    timers = Timers({"a": 1.0, "b": 2.0})
    # Check timer's public data data
    assert(isinstance(timers, Timers))
    assert(timers.data == {"a": 1.0, "b": 2.0})
    assert(timers._timings == collections.defaultdict(list, {}))
    # Check manual addition to timers
    timers.add("a", 5.0)
    assert(timers.data == {"a": 6.0, "b": 2.0})

# Generated at 2022-06-23 16:10:30.338850
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test  method mean of class Timers"""
    result = Timers({'a': 1, 'b': 2})
    assert result.mean('a') == 1
    assert result.mean('b') == 2

# Generated at 2022-06-23 16:10:35.996498
# Unit test for method max of class Timers
def test_Timers_max():  # type: ignore
    timers = Timers()
    timers.add('Test', 3)
    assert timers.max('Test') == 3
    assert timers.total('Test') == 3
    timers.add('Test', 1)
    assert timers.max('Test') == 3
    assert timers.total('Test') == 4
    timers.add('Test', 2)
    assert timers.max('Test') == 3
    assert timers.total('Test') == 6
    assert timers.mean('Test') == 2
    assert timers.median('Test') == 2
    assert timers.stdev('Test') == 0.816496580927726

# Generated at 2022-06-23 16:10:38.158099
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("test", 10.0)
    assert timers.count("test") == 1

# Generated at 2022-06-23 16:10:39.843771
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    with pytest.raises(TypeError):
        timers = Timers()
        timers[1] = 2

# Generated at 2022-06-23 16:10:42.099975
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    with pytest.raises(TypeError):
        Timers()["foo"] = 1


# Generated at 2022-06-23 16:10:44.508976
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("A", 1.1)
    timers.add("A", 3.2)
    timers.add("A", 1.2)
    assert timers.median("A") == 1.1

# Generated at 2022-06-23 16:10:45.431856
# Unit test for constructor of class Timers
def test_Timers():
    t = Timers()
    assert len(t) == 0


# Generated at 2022-06-23 16:10:49.156926
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('a', 42.0)
    assert timers.max('a') == 42.0
    timers.add('a', 24.0)
    assert timers.max('a') == 42.0


# Generated at 2022-06-23 16:10:51.812680
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    assert timers.max("test") == 1


# Generated at 2022-06-23 16:10:54.559244
# Unit test for method mean of class Timers
def test_Timers_mean():
    timer = Timers()
    timer.add('test', 2)
    timer.add('test', 3)
    assert timer.mean('test') == 2.5

# Generated at 2022-06-23 16:10:59.734721
# Unit test for method min of class Timers
def test_Timers_min():
    ts = Timers()
    ts.add('a', 10)
    ts.add('a', 1)
    ts.add('a', 2)
    ts.add('a', 5)
    ts.add('a', 7)
    assert ts.min('a') == 1


# Generated at 2022-06-23 16:11:03.016762
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add("timer1", 1)
    timers.add("timer1", 2)
    timers.add("timer1", 3)
    assert timers.total("timer1") == 6

# Generated at 2022-06-23 16:11:06.697733
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers({'key': 1, 'other': 2})
    timers['key'] = 0
    timers['other'] = 0
    assert timers == {'key': 0, 'other': 0}
    timers.clear()
    assert timers == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:11:12.621122
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean of Timers"""
    times = Timers()
    times.add('foo', 1.0)
    times.add('foo', 2.0)
    times.add('bar', 3.0)
    times.add('bar', 5.0)
    assert times.mean('foo') == 1.5
    assert times.mean('bar') == 4.0

# Generated at 2022-06-23 16:11:14.181898
# Unit test for constructor of class Timers
def test_Timers():
    """Test construction of empty Timers"""
    timers = Timers()
    assert sorted(timers.keys()) == []


# Generated at 2022-06-23 16:11:19.480801
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test the method 'apply' of the class 'Timers'"""
    timers = Timers()
    timers.add('a', 1)
    timers.add('a', 2)
    timers.add('a', 3)
    assert timers.apply(min, 'a') == 1
    assert timers.apply(max, 'a') == 3
    assert timers.apply(sum, 'a') == 6
    assert timers.apply(len, 'a') == 3
    assert timers.apply(response_time, 'a') == 50
    assert timers.apply(response_time_50, 'a') == 2.5


# Generated at 2022-06-23 16:11:23.306417
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers._timings = {'min': [1.2, 2.1, 1.4]}
    assert timers.min('min') == 1.2


# Generated at 2022-06-23 16:11:33.507691
# Unit test for constructor of class Timers
def test_Timers():
    # Check if NoKeyError is raised for unknown timer
    t = Timers()
    try:
        t.total('unknown')
    except KeyError:
        pass
    else:
        assert False, 'KeyError should be raised'
    # Check adding, displaying and clearing of timers
    t.add('timer1', 0.5)
    assert t['timer1'] == 0.5
    assert t.total('timer1') == 0.5
    assert t.min('timer1') == 0.5
    assert t.max('timer1') == 0.5
    assert t.mean('timer1') == 0.5
    assert t.median('timer1') == 0.5
    try:
        t.stdev('timer1')
    except statistics.StatisticsError:
        pass

# Generated at 2022-06-23 16:11:43.190193
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test applying a function to all values of a timer"""

    # Prepare test data
    data = Timers()
    data.add("a", 10)
    data.add("a", 20)

    # Test
    assert data.count("a") == 2
    assert data.total("a") == 30
    assert data.min("a") == 10
    assert data.max("a") == 20
    assert data.mean("a") == 15.0
    assert data.median("a") == 15.0
    assert data.stdev("a") == 5.0

# Generated at 2022-06-23 16:11:54.601084
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timer_dict = Timers()
    timer_dict.add('a', 1)
    print(timer_dict.median('a'))
    timer_dict.add('a', 2)
    print(timer_dict.median('a'))
    timer_dict.add('a', 3)
    print(timer_dict.median('a'))
    timer_dict.add('a', 4)
    print(timer_dict.median('a'))
    timer_dict.add('a', 5)
    print(timer_dict.median('a'))
    timer_dict.add('a', 6)
    print(timer_dict.median('a'))
    timer_dict.add('a', 7)