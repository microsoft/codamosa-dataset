

# Generated at 2022-06-23 16:01:53.509348
# Unit test for method mean of class Timers
def test_Timers_mean():
    import math

    assert math.isnan(Timers().mean("test")) == True

# Generated at 2022-06-23 16:01:56.914678
# Unit test for method stdev of class Timers
def test_Timers_stdev(): # pragma: no cover
    assert Timers().stdev("test") == math.nan
    assert Timers({"test": 1}).stdev("test") == math.nan
    assert Timers({"test": [1, 2, 3]}).stdev("test") == 1

# Generated at 2022-06-23 16:02:00.799173
# Unit test for method clear of class Timers
def test_Timers_clear():
    timer = Timers()
    timer.add("one", 1)
    timer.add("two", 2)
    assert timer["one"] == 1
    assert timer["two"] == 2
    timer.clear()
    assert list(timer.data.keys()) == []

# Generated at 2022-06-23 16:02:04.345561
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers["timer1"] = 1.0
    timers.add("timer2", 2.0)
    timers.add("timer2", 4.0)
    assert timers.count("timer1") == 1
    assert timers.count("timer2") == 2

# Generated at 2022-06-23 16:02:12.120559
# Unit test for method count of class Timers
def test_Timers_count():
    """Test method count"""
    timers = Timers()
    assert timers.count("timer1") == 0
    timers.add("timer1", 10)
    assert timers.count("timer1") == 1
    timers.add("timer1", 20)
    assert timers.count("timer1") == 2
    timers.add("timer2", 3)
    assert timers.count("timer2") == 1
    timers.add("timer2", 4)
    assert timers.count("timer2") == 2
    timers.add("timer2", 5)
    assert timers.count("timer2") == 3


# Generated at 2022-06-23 16:02:15.304182
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test method __setitem__ of class Timers"""
    model = Timers()
    try:
        model["test"] = 2
    except TypeError:
        pass
    else:
        raise AssertionError("Must raise TypeError")

# Generated at 2022-06-23 16:02:23.114973
# Unit test for method mean of class Timers
def test_Timers_mean():
    def create_timers() -> Timers:
        """Create timers with test values"""
        timers = Timers()
        timers.add("foo", 0.5)
        timers.add("foo", 0.4)
        timers.add("bar", 1.0)
        return timers

    # Test mean of all timers
    timers = create_timers()
    assert timers.mean("foo") == 0.45
    assert timers.mean("bar") == 1.0

    # Test mean of non-existing timer
    with pytest.raises(KeyError):
        timers.mean('baz')

# Generated at 2022-06-23 16:02:27.414728
# Unit test for method clear of class Timers
def test_Timers_clear():
    t = Timers()
    t.add('logging', 1.0)
    t.add('logging', 1.0)
    t.add('logging', 1.0)
    t.add('logging', 1.0)
    t.clear()
    assert len(t) == 0
    assert 'logging' not in t


# Generated at 2022-06-23 16:02:30.764658
# Unit test for method add of class Timers
def test_Timers_add():
    t = Timers()
    t.add('test',2)
    assert t.data['test'] == 2


# Generated at 2022-06-23 16:02:36.808374
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add('test', 1)
    assert len(timers.data) == 1
    assert len(timers._timings) == 1
    timers.clear()
    assert len(timers.data) == 0
    assert len(timers._timings) == 0

# Generated at 2022-06-23 16:02:45.470571
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""

    # Initialize timers
    timers = Timers()
    assert len(timers) == 0
    assert len(timers._timings) == 0

    # Add a timing
    timers.add(name='a', value=0.1)
    assert len(timers) == 1
    assert len(timers._timings) == 1
    assert timers['a'] == 0.1
    assert timers._timings['a'] == [0.1]

    # Add another timing
    timers.add(name='a', value=0.2)
    assert len(timers) == 1
    assert len(timers._timings) == 1
    assert timers['a'] == 0.3
    assert timers._timings['a'] == [0.1, 0.2]

    # Add

# Generated at 2022-06-23 16:02:49.868237
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test adding timings and calculating the mean"""
    timers = Timers()
    timers.add("testing", 1)
    timers.add("testing", 2)
    timers.add("testing", 3)
    assert timers.mean("testing") == 2
    assert timers.mean("unknown") == 0

# Generated at 2022-06-23 16:02:55.550823
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Check if standard deviation is correctly calculated"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert round(timers.stdev('test'), 1) == 0.8



# Generated at 2022-06-23 16:02:58.441176
# Unit test for constructor of class Timers
def test_Timers():
    """Test Timers class constructor"""
    timers = Timers()
    assert isinstance(timers, collections.UserDict)
    assert isinstance(timers._timings, collections.defaultdict)

# Generated at 2022-06-23 16:03:03.480225
# Unit test for method total of class Timers
def test_Timers_total():
    """Test method Timers.total"""
    timers = Timers()
    timers.add('total', 50)
    timers.add('total', 30)
    assert timers.total('total') == 80

    timers = Timers()
    timers.add('total', 0)
    assert timers.total('total') == 0

# Generated at 2022-06-23 16:03:07.158533
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add("timer1", 1)
    timers.add("timer2", 2)
    timers.add("timer2", 3)
    assert timers.stdev("timer1") == math.nan
    assert timers.stdev("timer2") == 0.816496580927726

# Generated at 2022-06-23 16:03:07.994307
# Unit test for method total of class Timers
def test_Timers_total():
    assert Timers().total("name") == 0

# Generated at 2022-06-23 16:03:13.236835
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median method of class Timers"""
    res = Timers()
    res.add("test", 3)
    res.add("test", 7)
    res.add("test", 0)
    assert res.median("test") == 3



# Generated at 2022-06-23 16:03:18.749482
# Unit test for method clear of class Timers
def test_Timers_clear():
    "test clear method for Timers()"
    # instance of Timer() called timers
    timers = Timers()

    # insert value
    timers["a"] = 1
    timers.add("b", 2)

    # clear value
    timers.clear()

    # check if value inserted is empty
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:03:23.938264
# Unit test for method median of class Timers
def test_Timers_median():
    """Test Timers.median() method"""
    # Test median for an empty list
    assert Timers().median("test") == 0.0
    # Test median for a list of values
    assert Timers().median("test") == 0.0

# Generated at 2022-06-23 16:03:27.703218
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Unit test for method clear of class Timers"""

    timers = Timers()
    for instance in range(300):
        timers.add("backbone_nodes", 1.2)
    timers.clear()
    assert len(timers.get_timings()) == 0


# Generated at 2022-06-23 16:03:30.881671
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('foo', 1)
    timers.add('foo', 2)
    timers.add('foo', 3)
    assert timers.mean('foo') == 2

# Generated at 2022-06-23 16:03:33.589321
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timer1 = Timers()
    timer1.add("test", 1)
    assert math.isnan(timer1.stdev("test"))
    timer1.add("test", 2)
    assert timer1.stdev("test") == 1.0

# Generated at 2022-06-23 16:03:42.087781
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    from ..pprint import pformat

# Generated at 2022-06-23 16:03:46.236364
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    timers = Timers()
    timers.add("foo", 1.2)
    timers.add("bar", 3.4)
    print(timers["foo"])
    print(timers.data["bar"])
    print(timers._timings["foo"])

# Generated at 2022-06-23 16:03:49.592904
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    t = Timers()
    t.add("a", 1)
    t.add("a", 1)
    assert t.stdev("a") == 0.
    t.add("a", 2)
    assert t.stdev("a") == 0.5

# Generated at 2022-06-23 16:03:51.525408
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("name", 10)
    assert timers.min("name") == 10

# Generated at 2022-06-23 16:03:54.465542
# Unit test for constructor of class Timers
def test_Timers():
    """Check if Timers constructor works properly"""
    timer = Timers()
    assert timer.data == {}
    assert timer._timings == {}



# Generated at 2022-06-23 16:04:05.245163
# Unit test for method apply of class Timers
def test_Timers_apply():
    """
    The method Timers.apply(func, name) should apply a function to the
    results of one named timer
    """
    timers = Timers()
    timers._timings["key1"] = [1, 2, 3, 4]
    assert timers.apply(len, name="key1") == 4
    assert timers.apply(lambda values: min(values or [0]), name="key1") == 1
    assert timers.apply(lambda values: max(values or [0]), name="key1") == 4
    assert timers.apply(lambda values: statistics.mean(values or [0]), name="key1") == 2.5
    assert timers.apply(lambda values: statistics.median(values), name="key1") == 2.5

# Generated at 2022-06-23 16:04:10.496579
# Unit test for method max of class Timers
def test_Timers_max():
    """The max method of Timers class should return the maximum value among all timings recorded by a timer"""
    timers = Timers()
    timers.add('timer1', 2.5)
    timers.add('timer1', 5.0)
    assert timers.max('timer1') == 5.0


# Generated at 2022-06-23 16:04:14.061256
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("time", 1)
    assert timers.median("time") == 1

    timers.add("time", 2)
    assert timers.median("time") == 1.5

    timers.add("time", 3)
    assert timers.median("time") == 2

# Generated at 2022-06-23 16:04:23.069389
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for method stdev of class Timers"""
    timers = Timers()
    assert timers.stdev("timer") == math.nan
    timers.data["timer"] = 1
    assert timers.stdev("timer") == math.nan
    timers.data["timer"] = 0
    timers.add("timer", 1)
    timers.add("timer", 2)
    timers.add("timer", 3)
    assert abs(timers.stdev("timer") - statistics.stdev([1, 2, 3])) < 1e-6

# Generated at 2022-06-23 16:04:28.178600
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    timers.add('test', 1)

    def set_item():
        timers['test'] = 2

    assert len(timers.keys()) == 1 and timers['test'] > 0

    try:
        set_item()
    except TypeError:
        pass
    else:
        raise AssertionError("Method setitem() did not raise an exception")


# Generated at 2022-06-23 16:04:34.555062
# Unit test for method add of class Timers
def test_Timers_add():
    """Test Timers.add()"""
    timers = Timers()
    timers.add("timer_1", 2)
    timers.add("timer_1", 2.5)
    timers.add("timer_2", 4)

    assert timers == {"timer_1": 4.5, "timer_2": 4}
    assert timers._timings == {"timer_1": [2, 2.5], "timer_2": [4]}


# Generated at 2022-06-23 16:04:41.230508
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers({"foo": 1})
    timers.add("foo", 2)
    timers.add("foo", 3)
    timers.add("bar", 4)
    assert timers.count("foo") == 3
    assert timers.count("bar") == 1
    assert timers.count("baz") == 0


# Generated at 2022-06-23 16:04:43.099204
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers({"time": 1})
    with Assert.raises(TypeError):
        timers["time"] = 10

# Generated at 2022-06-23 16:04:47.527986
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add('timerA', 10)
    timers.add('timerB', 5)
    timers.add('timerA', 5)
    assert timers.total('timerA') == 15

# Generated at 2022-06-23 16:04:50.875638
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers({"my_timer": 0})
    timers.add("my_timer", 0.5)
    assert timers["my_timer"] == 0.5


# Generated at 2022-06-23 16:04:54.654201
# Unit test for method count of class Timers
def test_Timers_count():
    def return_number_of_timings_in_timer_with_name(name):
        timers = Timers()
        timers.add(name, 1)
        return timers.count(name)

    assert 1 == return_number_of_timings_in_timer_with_name('Timer')


# Generated at 2022-06-23 16:04:59.078252
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('get_data', 0.016)
    timers.add('get_data', 0.020)
    assert timers.mean('get_data') == 0.018

# Generated at 2022-06-23 16:05:08.976973
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the `median` method of the class `Timers`"""
    from hypothesis import given, strategies as st

    # Generate all "reasonable" sizes of lists of integers
    @given(
        st.random_module(),
        st.integers(),
        st.lists(
            st.integers(min_value=-1000000000, max_value=1000000000),
            min_size=0,
            max_size=100
        ),
    )
    def test_median(module, randint, lst):
        """Test the `median` method of the class `Timers`"""
        timers = Timers()
        timers.update({'time': randint})
        for value in lst:
            timers.add('time', value)
        xlst = sorted(lst)
        assert timers.med

# Generated at 2022-06-23 16:05:12.178112
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test1", 10.5)
    timers.add("test1", 11.3)
    timers.add("test1", 9.7)
    expected = 11.3
    result = timers.max("test1")
    assert result == expected

# Generated at 2022-06-23 16:05:18.216139
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    timers = Timers()
    timers.add("foo", 1)
    assert timers["foo"] == 1
    timers.add("foo", 2)
    assert timers["foo"] == 3
    timers.add("bar", 2)
    assert timers["bar"] == 2
    timers.clear()
    assert timers["foo"] == 0
    assert timers["bar"] == 0


# Generated at 2022-06-23 16:05:21.481991
# Unit test for method total of class Timers
def test_Timers_total():
    timer = Timers()
    timer.add('test', 2.0)
    timer.add('test', 4.0)
    assert timer.data['test'] == 6.0


# Generated at 2022-06-23 16:05:27.041210
# Unit test for method add of class Timers
def test_Timers_add():
    t = Timers()
    t.add("name", 1)
    assert t.data["name"] == 1
    t.add("name", 0.5)
    assert t.data["name"] == 1.5
    assert t._timings["name"] == [1, 0.5]
    t.add("name2", 1)
    assert t.data["name2"] == 1
    assert t._timings["name2"] == [1]


# Generated at 2022-06-23 16:05:29.501257
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():  # pragma: no cover
    """Test that setting an item value is prohibited"""

    timers = Timers()

    with pytest.raises(TypeError):
        timers["timer"] = 1



# Generated at 2022-06-23 16:05:36.114517
# Unit test for method max of class Timers
def test_Timers_max():
    """Check that max returns maximum value of the timing given as input"""
    timers = Timers()
    timers['1'] = 1
    timers['2'] = 2
    timers['3'] = 3
    assert timers.max('1') == 1
    assert timers.max('2') == 2
    assert timers.max('3') == 3


# Generated at 2022-06-23 16:05:44.572410
# Unit test for method mean of class Timers
def test_Timers_mean():
    times = Timers()
    times.add("c", 1.11)
    times.add("c", 1.12)
    times.add("c", 1.13)
    times.add("c", 1.14)
    times.add("c", 1.15)
    times.add("c", 1.16)
    times.add("c", 1.17)
    assert times.mean("c") == 1.135
    assert isinstance(times, collections.UserDict)


# Generated at 2022-06-23 16:05:52.650613
# Unit test for method max of class Timers
def test_Timers_max():
    """Helper function that tests the method max of class Timers"""
    # Create timers object
    timers = Timers()
    # Add a number of items
    for _ in range(5):
        timers.add('timer_name', _)
    # Check that the numbers are correctly aggregated
    assert timers.max('timer_name') == 4
    assert len(timers._timings['timer_name']) == 5
    assert isinstance(timers, collections.UserDict)
    assert isinstance(timers, collections.MutableMapping)

# Run unit tests
if __name__ == '__main__':
    # Run the unit tests
    test_Timers_max()

# Generated at 2022-06-23 16:05:56.859852
# Unit test for method total of class Timers
def test_Timers_total():
    """Test Timers.total method

    Example:
        >>> test_Timers_total()
        True
    """
    timers = Timers()
    timers.add("test", 1)
    return timers.total("test") == 1


# Generated at 2022-06-23 16:06:01.987057
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add('a', 1)
    timers.add('b', 1)
    timers.add('b', 2)
    assert timers.total('a') == 1
    assert timers.total('b') == 3


# Generated at 2022-06-23 16:06:05.228329
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()

    timers.add('foo', 10)
    timers.add('bar', 20)
    timers.add('foo', 30)
    timers.add('foo', 40)

    assert timers.max('foo') == 40


# Generated at 2022-06-23 16:06:08.057013
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    assert timers.apply(float, "FOO") == 0.0

# Generated at 2022-06-23 16:06:13.308013
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()
    t.add("a", 1)
    t.add("b", 1.5)
    t.add("a", 2)
    assert t.total("a") == 3
    assert t.total("b") == 1.5
    assert t.total("c") == 0
    
# Verify that total raises a keyerror if the value isn't found

# Generated at 2022-06-23 16:06:17.744349
# Unit test for method max of class Timers
def test_Timers_max():
    """Test the max function of the Timers class"""
    timers = Timers()
    timers._timings = {"test": [1, 2, 3, 4, 5]}
    assert timers.max("test") == 5
    assert timers.max("test2") == 0


# Generated at 2022-06-23 16:06:26.959410
# Unit test for method mean of class Timers
def test_Timers_mean():
    """
    Test that the mean method returns the mean of a list
    """
    # Create an empty Timers
    t = Timers()
    # Define a list of input values
    input_values = [1, 2, 3, 4]
    # Define a list of expected values
    expected_values = [2.5]
    # Iterate over the inputs
    for input in input_values:
        # Add each input to the Timers
        t.add(name="TEST", value=input)
    # Iterate over the inputs
    for name, expected in zip(input_values, expected_values):
        # Test that the result of mean is expected_value
        assert t.mean("TEST") == expected

# Generated at 2022-06-23 16:06:33.011846
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    
    t = Timers({})
    t.add('timer1', 10)
    t.add('timer1', 20)
    t.add('timer1', 30)
    assert t.stdev('timer1') == 10
    assert t.stdev('timer2') == 0
    # assert math.isnan(t.stdev('timer1'))
    # assert math.isnan(t.stdev('timer2'))
    
test_Timers_stdev()

# Generated at 2022-06-23 16:06:37.375098
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers._timings = {"timing1": [1, 2, 3], "timing2": [4, 5, 6]}
    assert timers.apply(lambda values: values[2], name="timing1") == 3
    assert timers.apply(lambda values: values[1], name="timing2") == 5


# Generated at 2022-06-23 16:06:39.846625
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add('test', 2)
    assert timers.data['test'] == 2
    assert timers._timings['test'] == [2]



# Generated at 2022-06-23 16:06:41.569368
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers._timings == collections.defaultdict(list)


# Generated at 2022-06-23 16:06:45.728981
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():  # pragma: no cover
    # Setup
    timers = Timers()
    # Exercise and Verify
    try:
        timers["TIMER"] = 2.0
    except TypeError:
        pass
    except Exception as e:
        raise e
    else:
        raise AssertionError("TypeError expected")


# Generated at 2022-06-23 16:06:54.069161
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    assert timers == {}
    
    timers.add('One', 1.0)
    assert timers == {'One': 1.0}
    
    timers.add('One', 2.0)
    assert timers == {'One': 3.0}
    
    timers.add('Two', 3.0)
    assert timers == {'One': 3.0, 'Two': 3.0}
    

# Generated at 2022-06-23 16:06:56.929091
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method add of class Timers"""
    timers = Timers()
    timers.add("foo", 2)
    assert timers["foo"] == 2



# Generated at 2022-06-23 16:07:00.385382
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    import pytest
    timer = Timers()
    timer["a"] = 10
    assert timer["a"] == 10
    timer.add("b", 10)
    assert timer["b"] == 10
    with pytest.raises(TypeError):
        timer["a"] = 42

# Generated at 2022-06-23 16:07:08.625851
# Unit test for method mean of class Timers
def test_Timers_mean():
    import pytest
    t = Timers()
    t.add('a', 1)
    t.add('a', 2)
    t.add('b', 3)
    t.add('b', 4)
    assert t.count('a') == 2
    assert t.count('b') == 2
    assert t.mean('a') == 1.5
    assert t.mean('b') == 3.5
    assert t.mean('c') == 0
    with pytest.raises(KeyError):
        t.mean('d')


# Generated at 2022-06-23 16:07:11.702932
# Unit test for method min of class Timers
def test_Timers_min():
    def test():
        t = Timers()
        t.add("torch.einsum", 2.37)
        t.add("torch.einsum", 1.23)
        return t.min("torch.einsum") == 1.23
    assert test()


# Generated at 2022-06-23 16:07:17.359792
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    import pytest
    timers = Timers()
    timers.add("test", 1)
    with pytest.raises(KeyError):
        timers.stdev("no_such_timer")
    assert timers.stdev("test") is math.nan
    timers.add("test", 2)
    assert timers.stdev("test") == 0.5
    timers.add("test", 2)
    assert timers.stdev("test") == 0.5

if __name__ == '__main__':
    test_Timers_stdev()

# Generated at 2022-06-23 16:07:23.518485
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add('timer1', 0.5)
    assert timers.data == {'timer1': 0.5}
    timers.add('timer1', 1.5)
    assert timers.data == {'timer1': 2.0}
    timers.add('timer2', 1.5)
    assert timers.data == {'timer1': 2.0, 'timer2': 1.5}


# Generated at 2022-06-23 16:07:27.401930
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Class Timers"""

    # Create an object of class Timers
    my_timers = Timers()

    # Add some test data
    my_timers._timings.setdefault("add", [1, 2, 3, 4])

    # Check the method apply
    assert my_timers.apply(sum, name="add") == 10

# Generated at 2022-06-23 16:07:35.394324
# Unit test for method total of class Timers
def test_Timers_total():
    timer = Timers()
    timer.add("long_name", 1.0)
    timer.add("long_name", 1.5)
    timer.add("other_name", 1.5)
    timer.add("other_name", 1.5)
    assert timer.total("long_name") == 2.5, "total should be 2.5"
    assert timer.total("other_name") == 3.0, "total should be 3.0"
    assert timer.total("third_name") == 0, "total should be 0"


# Generated at 2022-06-23 16:07:37.755749
# Unit test for constructor of class Timers
def test_Timers():
    t = Timers()
    assert type(t) == Timers
    assert t.data == {}
    assert t._timings == {}


# Generated at 2022-06-23 16:07:41.045527
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test of method mean of class Timers"""
    timers = Timers()
    timers.add("general", 23.5)
    timers.add("specific", 9.5)
    assert timers.mean("general") == 23.5
    assert timers.mean("specific") == 9.5
    assert timers.mean("error") == 0

# Generated at 2022-06-23 16:07:45.062532
# Unit test for method total of class Timers
def test_Timers_total():
    # Setup
    timers = Timers()
    timers.add("timer", 1)

    # Test
    assert timers.total("timer") == 1

test_Timers_total()


# Generated at 2022-06-23 16:07:53.787290
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev() of class Timers"""
    timers = Timers()
    timers.add("tim1", 1)
    timers.add("tim1", 2)
    timers.add("tim1", 3)
    timers.add("tim1", 4)
    timers.add("tim2", 5)
    timers.add("tim2", 6)
    timers.add("tim2", 7)
    assert timers.count("tim1") == 4
    assert timers.count("tim2") == 3
    assert timers.total("tim1") == 10
    assert timers.total("tim2") == 18
    assert timers.min("tim1") == 1
    assert timers.min("tim2") == 5
    assert timers.max("tim1") == 4
    assert timers.max("tim2") == 7

# Generated at 2022-06-23 16:07:57.681678
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add("numba", 1)
    timers.add("numba", 2)
    timers.add("numba", 3)
    assert timers.stdev('numba') == 1.0


# Generated at 2022-06-23 16:08:02.087389
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    for i in range(10):
        timers.add("a", float(i))

    assert timers.apply(lambda values: statistics.mean(values or [0]), name="a") == 4.5


# Generated at 2022-06-23 16:08:07.760634
# Unit test for method total of class Timers
def test_Timers_total():
    tmrs = Timers()
    assert tmrs.total('foo') == 0
    tmrs.add('foo', 1)
    assert tmrs.total('foo') == 1
    assert tmrs.total('bar') == 0
    assert tmrs['foo'] == 1
    tmrs.add('foo', 1)
    assert tmrs.total('foo') == 2
    assert tmrs['foo'] == 2

test_Timers_total()

# Generated at 2022-06-23 16:08:13.382486
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():  # pragma: no cover
    """A dictionary with no item setting"""
    timers = Timers()

    def test_exception():
        """Check exception"""
        timers["foo"] = 0.1

    # Testing
    from pytest import raises
    from warnings import catch_warnings
    with raises(TypeError):
        test_exception()
    with catch_warnings():
        test_exception()

# Generated at 2022-06-23 16:08:15.592729
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers is not None


# Generated at 2022-06-23 16:08:23.573181
# Unit test for method max of class Timers
def test_Timers_max():  # pylint:disable=missing-function-docstring,invalid-name
    t = Timers()
    t.add('a', 1)
    t.add('a', 2)
    assert t.max('a') == 2
    assert t.min('a') == 1

if __name__ == "__main__":
    # Run above functions without pytest
    test_Timers_max()  # pylint:disable=no-value-for-parameter
    print("Success!")  # pylint:disable=superfluous-parens

# Generated at 2022-06-23 16:08:25.661712
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("time", 0.05)
    assert timers.min("time") == 0.05



# Generated at 2022-06-23 16:08:29.989592
# Unit test for method apply of class Timers
def test_Timers_apply():
    """test_Timers_apply"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.apply(sum, 'test') == 6


# Generated at 2022-06-23 16:08:32.091699
# Unit test for constructor of class Timers
def test_Timers():
    """Test the constructor of class Timers"""
    t = Timers()
    assert not t

# Generated at 2022-06-23 16:08:37.248434
# Unit test for method clear of class Timers
def test_Timers_clear():
    t = Timers()
    t.add('foo', 1)
    t.add('foo', 2)
    t.add('bar', 3)
    t.add('bar', 4)
    t.clear()
    assert t.data == {}
    assert t._timings == {}

# Generated at 2022-06-23 16:08:48.589590
# Unit test for method count of class Timers
def test_Timers_count():
    from .base import TestBase
    from .mock.logging import Logging
    from .mock.timer import Timer

    class Test(TestBase):

        def setUp(self) -> None:
            """Set up tests"""
            self.logging = Logging()
            self.timers = Timers()
            self.timer = Timer(name="TestTimer", timers=self.timers, logging=self.logging)

        def test_count_timers(self) -> None:
            """Test count"""
            self.timer.start()
            self.timer.stop()
            self.assertEqual(self.timers.count("TestTimer"), 1)

    Test().run()


# Generated at 2022-06-23 16:08:51.405213
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add("timer1", 1)
    timers.clear()
    assert timers == Timers()
    assert timers._timings == {}


# Generated at 2022-06-23 16:08:58.066319
# Unit test for method median of class Timers
def test_Timers_median():
    """
    >>> t = Timers()
    >>> t.add("foo", 3)
    >>> t.add("foo", 4)
    >>> t.add("foo", 2)
    >>> t.median("foo")
    3.0
    >>> t.add("foo", 5)
    >>> t.add("foo", 6)
    >>> t.median("foo")
    4.0
    """
    pass



# Generated at 2022-06-23 16:09:01.818115
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('timer1', 1)
    timers.add('timer2', 1)
    timers.add('timer1', 1)
    assert timers.count('timer1') == 2
    assert timers.count('timer2') == 1


# Generated at 2022-06-23 16:09:13.404553
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method Timers.apply"""
    timers = Timers()
    timers.add('first', 1)
    timers.add('first', 2)
    timers.add('second', 3)
    timers.add('second', math.nan)
    timers.add('second', 5)
    timers.add('third', math.inf)
    assert timers.apply(len, 'first') == 2
    assert timers.apply(len, 'second') == 3
    assert timers.apply(len, 'third') == 1
    assert timers.apply(sum, 'first') == 3
    assert timers.apply(sum, 'second') == 8
    assert timers.apply(sum, 'third') == math.inf
    assert timers.apply(min, 'first') == 1
    assert timers.apply(min, 'second') == 3

# Generated at 2022-06-23 16:09:16.836641
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add("test", 10)
    t.add("test", 20)
    t.add("test", 30)
    assert t.mean("test") == 20
    assert t.mean("test_c") == 0
    assert t.mean("test2") == 0


# Generated at 2022-06-23 16:09:24.474083
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test method apply of class Timers"""
    timers = Timers()
    timers.add("key", 1)
    timers.add("key", 2)
    timers.add("key", 3)
    timers.add("other", 1)
    timers.add("other", 2)
    assert timers.apply(sum, name="key") == 6
    assert timers.apply(len, name="other") == 2

# Generated at 2022-06-23 16:09:33.097758
# Unit test for method min of class Timers
def test_Timers_min():
    """Tests the method min of class Timers"""
    timers = Timers()
    for el in range(100):
        timers.add(key, 0.5)
    assert timers.min(key) == 0.5
    assert timers.min(key) == timers.min(key) == min(timers._timings[key])
    assert timers.min(key) == sum(timers._timings[key])/len(timers._timings[key])
    assert timers.min(key) == statistics.mean(timers._timings[key])
    assert timers.min(key) == statistics.median(timers._timings[key])

# Generated at 2022-06-23 16:09:40.951482
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('timer1', 1)
    timers.add('timer1', 2)
    timers.add('timer1', 3)
    min = timers.min('timer1')
    assert min == 1
    timers.add('timer2', 5)
    timers.add('timer2', 4)
    timers.add('timer2', 3)
    min = timers.min('timer2')
    assert min == 3


# Generated at 2022-06-23 16:09:42.892176
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    timers["h"] = 42
    assert timers["h"] == 42


# Generated at 2022-06-23 16:09:48.427488
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("t", 0)
    assert timers["t"] == 0
    timers.add("t", 2)
    assert timers["t"] == 2
    timers.add("t", 4)
    assert timers["t"] == 6
    assert 0 == timers.mean("not t")

# Generated at 2022-06-23 16:09:50.472113
# Unit test for method max of class Timers
def test_Timers_max():
    a = Timers()
    a.add('a', 2.0)
    assert a.max('a') == 2.0

# Generated at 2022-06-23 16:09:55.550625
# Unit test for method min of class Timers
def test_Timers_min():
    """Test the method min of the class Timers"""

    timers = Timers()

    assert timers.min("Unknown") == 0

    timers.add("Max", 1.0)
    timers.add("Max", 2.0)
    timers.add("Max", 3.0)
    timers.add("Max", 5.0)

    assert timers.min("Max") == 1.0


# Generated at 2022-06-23 16:10:00.341794
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test method __setitem__ of class Timers"""
    timers = Timers()
    with pytest.raises(TypeError) as err:
        timers["test"] = 1.1
    assert str(err.value) == "Timers does not support item assignment. Use '.add()' to update values."

# Generated at 2022-06-23 16:10:09.762060
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    # Setup a timer object and add a data point
    timer_test = Timers()
    timer_test.add(name="test", value=1)
    timer_test.add(name="test", value=2)
    timer_test.add(name="test", value=3)
    # Change timer data to median of the data points
    timer_test.median(name="test")
    # Check if the median of the data points has been stored in timer data
    assert timer_test.data["test"] == 2

# Generated at 2022-06-23 16:10:12.206096
# Unit test for method add of class Timers
def test_Timers_add():
    timer = Timers()
    timer.add("1", 2)
    timer.add("2", 3)
    assert timer["1"] == 2
    assert timer["2"] == 3


# Generated at 2022-06-23 16:10:17.468497
# Unit test for method total of class Timers
def test_Timers_total():
    """test if Timers.total is working"""
    # create an empty Timers object
    timing = Timers()
    timing.add('total', 0)
    assert timing.total('total') == 0
    timing.add('total', 1)
    assert timing.total('total') == 1
    timing.add('total', 2)
    assert timing.total('total') == 3
    timing.add('total', 3)
    assert timing.total('total') == 6
    timing.add('total', 4)
    assert timing.total('total') == 10

# Generated at 2022-06-23 16:10:27.970029
# Unit test for method median of class Timers
def test_Timers_median():
    """
    Unit test for method median of class Timers
    """
    t = Timers()
    t.add("test", 1.0)
    t.add("test", 2.0)
    t.add("test", 3.0)
    t.add("test", 4.0)
    t.add("test", 5.0)
    t.add("test", 6.0)
    t.add("test", 7.0)
    t.add("test", 8.0)
    t.add("test", 9.0)
    t.add("test", 10.0)
    t.add("test", 11.0)
    t.add("test", 12.0)
    t.add("test", 13.0)
    t.add("test", 14.0)

# Generated at 2022-06-23 16:10:32.224460
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add(name='test', value=1.0)
    timers.add(name='test', value=5.0)
    timers.add(name='test', value=2.0)
    timers.add(name='test', value=3.0)
    assert timers.min(name='test') == 1.0

# Generated at 2022-06-23 16:10:36.059815
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 1)
    timers.add("b", 2)
    assert timers.total("a") == 2


# Generated at 2022-06-23 16:10:41.944790
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the Timers.mean method"""
    timers = Timers()
    timers.add('foo', 2.5)
    timers.add('foo', 4.0)
    assert timers.mean('foo') == 3.25
    assert timers.max('foo') == 4.0
    assert timers.min('foo') == 2.5
    assert timers.total('foo') == 6.5



# Generated at 2022-06-23 16:10:50.461857
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the method mean of class Timers"""
    t = Timers()
    t.add("t1", 1.5)
    t.add("t1", 2.5)
    assert t.mean("t1") == 2.0
    assert t.mean("t2") == 0.0  # pragma: no cover
    # Assert that KeyError is raised for non-existing timer
    try:
        _ = t.mean("t3")
    except KeyError:
        pass
    else:
        assert False  # pragma: no cover

# Generated at 2022-06-23 16:10:59.844684
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    timers = Timers()

    def test_stdev(values, expected, name=None):
        """Helper function to test method stdev of class Timers"""
        name = name or "timer"
        timers._timings[name] = values

        actual = timers.stdev(name)
        assert actual == expected

    test_stdev([], math.nan)
    test_stdev([1], math.nan)
    test_stdev([1, 2], 0.5)
    test_stdev([1, 2, 4, 5], 1.9364)
    test_stdev([1, 2, 4, 5, 7], 2.20775)
    test_stdev([1, 2, 4, 5, 7, 9], 3.20775)

# Generated at 2022-06-23 16:11:05.645694
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timer = Timers()
    timer.add(name="timing", value = 1.1)
    timer.add(name="timing", value = 2.2)
    timer.add(name="timing", value = 3.3)
    timer.add(name="timing", value = 2.2)
    timer.add(name="timing", value = 1.1)
    assert timer.stdev(name = "timing") == 1.0

# Generated at 2022-06-23 16:11:08.903121
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:11:11.777577
# Unit test for method count of class Timers
def test_Timers_count():
    """Unit test for method count of class Timers"""
    timers = Timers({'timer1': 1, 'timer2': 2, 'timer3': 3})
    # Update timer1, timer3
    timers.add('timer1', 1)
    timers.add('timer3', 2)
    # Check counters
    assert timers.count('timer1') == 2
    assert timers.count('timer2') == 1
    assert timers.count('timer3') == 2



# Generated at 2022-06-23 16:11:17.389641
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    all_timers = Timers()
    all_timers.add('name1', 10.0)
    all_timers.add('name2', 20.0)
    all_timers.add('name1', 20.0)
    all_timers.add('name2', 10.0)
    assert all_timers.mean('name1') == 15.0
    assert all_timers.mean('name2') == 15.0


# Generated at 2022-06-23 16:11:22.990814
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 2)
    timers.add("b", 3)
    timers.add("b", 4)
    assert timers.min("a") == 1
    assert timers.min("b") == 3


# Generated at 2022-06-23 16:11:25.352846
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    assert t.median("preprocess") == 0
    t.add("preprocess", 5)
    t.add("preprocess", 6)
    t.add("preprocess", 7)
    assert t.median("preprocess") == 6

# Generated at 2022-06-23 16:11:30.480219
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""

    def square(values):
        return [item ** 2 for item in values]

    timers = Timers()

    assert timers.apply(square, "lala") == []
    timers.add("lala", 3)
    assert timers.apply(square, "lala") == [9]
    timers.add("lala", 5)
    assert timers.apply(square, "lala") == [9, 25]


# Generated at 2022-06-23 16:11:35.294227
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers.add("decoding", 1.0)
    timers.add("decoding", 1.0)
    timers.add("decoding", 1.0)
    timers.add("encoding", 2.0)
    timers.add("encoding", 2.0)
    assert timers.apply(sum, "decoding") == 3.0

# Generated at 2022-06-23 16:11:37.779211
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 0.5)
    assert timers.max("test") == 0.5
    timers.add("test", 1.0)
    assert timers.max("test") == 1.0


# Generated at 2022-06-23 16:11:40.322245
# Unit test for method mean of class Timers
def test_Timers_mean():

    timer = Timers()
    timer.add("foo", 3)
    timer.add("foo", 5)
    assert timer.mean("foo") == 4

# Generated at 2022-06-23 16:11:51.713738
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    a = Timers()
    a["test"] = 1
    a.add("test2", 2)
    a.add("test", -1)
    assert(a.count("test"), 2)
    assert(a.mean("test"), 0)
    assert(a.total("test"), 0)
    assert(a.count("test2"), 1)
    assert(a.mean("test2"), 2)
    assert(a.total("test2"), 2)
    assert(a.min("test"), -1)
    assert(a.max("test"), 1)
    assert(a.min("test2"), 2)
    assert(a.max("test2"), 2)
    assert(a.median("test"), 0)