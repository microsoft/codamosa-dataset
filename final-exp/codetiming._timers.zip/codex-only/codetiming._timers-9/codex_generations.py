

# Generated at 2022-06-23 16:01:51.560682
# Unit test for method max of class Timers
def test_Timers_max():
    """Test for method max of class Timers"""
    timers = Timers()
    timers.add("a", 1.0)
    timers.add("a", 2.0)
    assert timers.max("a") == 2.0


# Generated at 2022-06-23 16:01:57.536854
# Unit test for method min of class Timers
def test_Timers_min():
    """Test the min function of Timers"""
    test = Timers()
    test.add("task1", 0.7)
    test.add("task1", 0.4)
    test.add("task2", 2.0)
    test.add("task2", 6.0)
    assert test.min("task1") == 0.4
    assert test.min("task2") == 2.0


# Generated at 2022-06-23 16:02:01.169441
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers(count=3)
    assert timers.count() == 3


# Generated at 2022-06-23 16:02:10.091308
# Unit test for method mean of class Timers
def test_Timers_mean():
    import random
    # Create a Timers object
    timers = Timers()
    
    # Define a list of random numbers 
    rand_nums = []
    for n in range(15):
        rand_nums.append(random.uniform(0, 10))
    
    # Add the rand_nums to timers
    for n in rand_nums:
        timers.add('rand_nums', n)
        
    # Get the mean of the numbers
    mean = timers.mean('rand_nums')
    
    # Calculate the expected result manually
    expected = sum(rand_nums) / len(rand_nums)
    
    # Compare the two results
    assert mean == expected

# Generated at 2022-06-23 16:02:13.954564
# Unit test for method max of class Timers
def test_Timers_max():
    """Test the method Timers.max"""
    timers = Timers()
    timer_name = 'test'
    timers._timings[timer_name] = [1.1, 2.2, 3.3]
    assert timers.apply(lambda values: max(values or [0]), name=timer_name) == 3.3


# Generated at 2022-06-23 16:02:16.198122
# Unit test for method max of class Timers
def test_Timers_max():
    _timers = Timers({'timer_1': 1, 'timer_2': 2, 'timer_3': 3})
    assert _timers.max('timer_1') == 1


# Generated at 2022-06-23 16:02:20.525662
# Unit test for method add of class Timers
def test_Timers_add():
    # Setup
    timers = Timers()
    # Test
    timers.add('foo', 1)
    timers.add('bar', 2)
    timers.add('foo', 3)
    # Verify
    assert timers.data == {'foo': 4, 'bar': 2}


# Generated at 2022-06-23 16:02:26.739715
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.clear()
    assert timers.count("test_timer") == 0.0

    timers.add("test_timer", value=1.0)
    assert timers.count("test_timer") == 1.0

    timers.add("test_timer", value=2.0)
    assert timers.count("test_timer") == 2.0

    try:
        timers.count("test_timer_dne")
    except KeyError:
        pass
    else:
        assert False, "KeyError not raised for non-existent timers"


# Generated at 2022-06-23 16:02:29.073139
# Unit test for method count of class Timers
def test_Timers_count():
    X = Timers()
    X.add('time', 1)
    X.add('time', 2)
    X.add('time', 3)
    assert X.count('time') == 3
    assert X.count('timer') == 0


# Generated at 2022-06-23 16:02:37.209260
# Unit test for method add of class Timers
def test_Timers_add():
    # Test append single timer
    timers = Timers()
    timers.add('test1', 1.)
    timers.add('test2', 1.)
    timers.add('test2', 3.)
    assert timers._timings['test1'] == [1]
    assert timers._timings['test2'] == [1, 3]
    assert timers.data['test1'] == 1
    assert timers.data['test2'] == 4
    assert timers.count('test1') == 1
    assert timers.count('test2') == 2
    assert timers.total('test1') == 1
    assert timers.total('test2') == 4
    assert timers.min('test1') == 1
    assert timers.min('test2') == 1
    assert timers.max('test1') == 1
    assert timers.max('test2') == 3


# Generated at 2022-06-23 16:02:45.763913
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean of class Timers"""
    timers = Timers()
    timers.add('foo', 1)
    timers.add('bar', 2)
    timers.add('foo', 2)
    timers.add('baz', 3)
    assert timers.mean('foo') == 1.5
    assert timers.mean('bar') == 2
    assert timers.mean('baz') == 3
    assert timers.median('foo') == 1.5
    assert timers.median('bar') == 2
    assert timers.median('baz') == 3
    assert timers.stdev('foo') == 0.5
    assert timers.stdev('bar') == 0
    assert timers.stdev('baz') == 0
    assert timers.count('foo') == 2
    assert timers.count('bar') == 1
    assert timers.count

# Generated at 2022-06-23 16:02:51.206449
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    def func():
        timers['one'] = 0.1
    assert func
    try:
        func()
    except TypeError as e:
        assert str(e) == "\'Timers\' does not support item assignment. Use '.add()' to update values."
    else:
        assert False

test_Timers___setitem__()

# Generated at 2022-06-23 16:02:53.706667
# Unit test for method max of class Timers
def test_Timers_max():
    """Test Timers max method"""
    timers = Timers()
    timers.add('test', 2)
    timers.add('test', 3)

    assert timers.max('test') == 3


# Generated at 2022-06-23 16:03:02.296336
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    t.data = {'test1': 1, 'test2': 2}
    t._timings = {'test1': [1,2,3,4], 'test2': [5,6,7,8]}
    assert t.median('test1') == 2.5
    assert t.median('test2') == 6.5
    try:
        t.median('test3')
    except KeyError as e:
        assert str(e) == "'test3'"
        pass
    else:
        raise Exception('expected KeyError exception')


# Generated at 2022-06-23 16:03:04.377043
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    # Create an Timers object
    timers = Timers()

    # Append the timing "a" to timer "a"
    timers.add("a", -1)

    # Check if the minimum value of timer "a" is -1
    assert timers.min("a") == -1

test_Timers_min()


# Generated at 2022-06-23 16:03:09.332778
# Unit test for method add of class Timers
def test_Timers_add():
    # Setup
    timers = Timers()
    # Exercise
    timers.add(name="t1", value=1.1)
    # Verify
    assert timers == {"t1": 1.1}  # type: ignore
    assert timers._timings == {"t1": [1.1]}


# Generated at 2022-06-23 16:03:20.568623
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    import math
    import statistics
    import unittest

    from qalib.common.timers import Timers

    class TestCase(unittest.TestCase):
        """Unit test for method stdev of class Timers"""

        def test1(self):
            """test1: Verify that a divide by zero error occurs for a single
            timing
            """
            timers = Timers()
            timers.add("foo", 1.2)
            self.assertTrue(math.isnan(timers.stdev("foo")))

        def test2(self):
            """test2: Verify that zero is returned if there are no timings
            """
            timers = Timers()
            self.assertEqual(timers.stdev("foo"), 0)


# Generated at 2022-06-23 16:03:26.646498
# Unit test for method count of class Timers
def test_Timers_count():
    t = Timers()
    t.add("alpha", 1.0)
    t.add("alpha", 2.0)
    t.add("beta", 3.0)
    assert(t.count("alpha") == 2)
    assert(t.count("beta") == 1)
    assert(t.count("gamma") == 0)


# Generated at 2022-06-23 16:03:29.690250
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers["solver"] = 14
    except TypeError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-23 16:03:31.055896
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.clear()


# Generated at 2022-06-23 16:03:36.424907
# Unit test for method count of class Timers
def test_Timers_count():
    # check that count of empty Timers is zero
    assert Timers().count("test") == 0
    # check that count of Timers is 1 after adding 1 item
    timers = Timers()
    timers.add("test", 1)
    assert timers.count("test") == 1
    # check that count of Timers is 2 after adding 2 items
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.count("test") == 2


# Generated at 2022-06-23 16:03:39.502269
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add('a', 3)
    t.add('a', 4)
    assert t.data['a'] == 7
    assert t.mean('a') == 3.5


# Generated at 2022-06-23 16:03:45.578966
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add("update", 1)
    assert timers.data["update"] == 1
    assert timers._timings["update"] == [1]
    timers.add("update", 2)
    assert timers.data["update"] == 3
    assert timers._timings["update"] == [1,2]


# Generated at 2022-06-23 16:03:50.288959
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    import numpy as np

    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 3)
    timers.add("test", 5)
    timers.add("test", 5)
    assert(np.isclose(timers.mean("test"), np.mean([1, 3, 5, 5])))

# Generated at 2022-06-23 16:04:01.699213
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    from scipy.stats import norm
    from numpy import array
    from itertools import repeat
    
    assert Timers().stdev("test") == KeyError
    
    t = Timers()
    
    t._timings = dict(test=[])
    assert t.stdev("test") == float("nan")
    
    t._timings = dict(test=[1,2])
    assert t.stdev("test") == norm.std(array([1,2]))
    
    t._timings = dict(test=list(repeat(1, 2)))
    assert t.stdev("test") == float("nan")
    
    t._timings = dict(test=list(repeat(1, 100)))
    assert t.stdev("test") == float("nan")
    
    t._timings = dict

# Generated at 2022-06-23 16:04:06.702973
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for method stdev of class Timers"""
    timers = Timers()
    timers.add("count", 5)
    assert timers.stdev("count") == 0
    timers.add("count", 10)
    assert timers.stdev("count") == 2.5
    timers.add("count", 15)
    assert timers.stdev("count") == 7.0710678118654755

# Generated at 2022-06-23 16:04:16.405001
# Unit test for method stdev of class Timers
def test_Timers_stdev():

    import numpy as np

    from neuropythy.util.timers import Timers

    # Make some data
    data1 = np.random.rand(25)
    data2 = np.random.rand(50)
    data3 = np.random.rand(1000)

    # Apply the data to a Timers object
    timers = Timers()
    timers.add('a',data1)
    timers.add('a',data2)
    timers.add('a',data3)

    # The result should be the same as the standard deviation of each dataset
    result = np.asarray([
        np.std(data1),
        np.std(data2),
        np.std(data3)
    ])

    # Check that the method is correct
    assert np.all( timers.stdev('a') == result )

# Generated at 2022-06-23 16:04:20.640405
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add('test_timer', 1.5)
    assert timers.max('test_timer') == 1.5



# Generated at 2022-06-23 16:04:26.444243
# Unit test for method median of class Timers
def test_Timers_median():
    import pytest
    from docutils.utils import new_document

    doc = new_document('')
    doc.reporter = pytest.UserWarning
    doc.timers = Timers()
    doc.timers.add('test', 3.0)
    doc.timers.add('test', 1.0)
    doc.timers.add('test', 2.0)
    assert doc.timers.median('test') == 2.0

# Generated at 2022-06-23 16:04:36.618607
# Unit test for method add of class Timers
def test_Timers_add():
    t: Timers = Timers()
    assert t.count('foo') == 0
    assert t.total('foo') == 0
    assert t.min('foo') == 0
    assert t.max('foo') == 0
    assert t.mean('foo') == 0
    assert t.median('foo') == 0
    assert math.isnan(t.stdev('foo'))

    # Add the first timing to the named timer 'foo'
    t.add('foo', 2.5)
    assert t.count('foo') == 1
    assert t.total('foo') == 2.5
    assert t.min('foo') == 2.5
    assert t.max('foo') == 2.5
    assert t.mean('foo') == 2.5
    assert t.median('foo') == 2.5
    assert math

# Generated at 2022-06-23 16:04:45.229698
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test Timers.apply method"""
    timers = Timers()

    for i in range(4):
        timers.add("foo", 2.0)

    assert timers.apply(sum, name="foo") == 8.0

    timers.add("bar", 1.0)
    assert timers.apply(sum, name="bar") == 1.0

    assert timers.apply(len, name="foo") == 4
    assert timers.apply(len, name="bar") == 1

    assert timers.apply(lambda values: min(values or [0]), name="foo") == 2.0
    assert timers.apply(lambda values: min(values or [0]), name="bar") == 1.0

    assert timers.apply(lambda values: max(values or [0]), name="foo") == 2.0

# Generated at 2022-06-23 16:04:49.506516
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers._timings = {'timer': [1, 2, 3, 4]}
    assert timers.mean('timer') == 2.5



# Generated at 2022-06-23 16:04:55.190750
# Unit test for method apply of class Timers
def test_Timers_apply():
    def len_func(values):
        return len(values)

    timers = Timers()
    timers.add("twos", 2)
    timers.add("twos", 2)
    timers.add("twos", 2)
    timers.add("ones", 1)
    timers.add("ones", 1)
    assert timers.apply(len_func, "ones") == 2
    assert timers.apply(len_func, "twos") == 3

# Generated at 2022-06-23 16:05:00.974931
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers = Timers()
    timers.add("foo", 1.2)
    timers.add("foo", 1.7)
    timers.add("bar", 2.9)
    assert timers.min("foo") == 1.2
    assert timers.min("bar") == 2.9


# Generated at 2022-06-23 16:05:07.771637
# Unit test for method clear of class Timers
def test_Timers_clear():
    """
    Check the clear method of Timers
    """
    tms = Timers()
    assert not tms.data
    #
    tms.add("t1", 1)
    tms.add("t1", 2)
    tms.add("t2", 3)
    tms.add("t2", 4)
    assert tms.data
    #
    tms.clear()
    assert not tms.data
    assert not tms._timings

# Generated at 2022-06-23 16:05:10.966989
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Check the mean value of a Timers object"""
    timer = Timers()
    timer.add("timer", 9)
    timer.add("timer", 8)
    assert timer.mean("timer") == 8.5

# Generated at 2022-06-23 16:05:16.044573
# Unit test for method total of class Timers
def test_Timers_total():
    """Unit test for Timers.total"""
    timers = Timers()
    assert timers.total("test") == 0
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.total("test") == 3
    assert timers.total("test2") == 0

# Generated at 2022-06-23 16:05:20.940282
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("a", 1.0)
    assert timers.count("a") == 1
    timers.add("a", 2.0)
    assert timers.count("a") == 2
    timers.add("a", 3.0)
    assert timers.count("a") == 3


# Generated at 2022-06-23 16:05:23.949322
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2


# Generated at 2022-06-23 16:05:31.954229
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Check computation of stdev of assigned value list"""
    timers = Timers()
    timers.add("test", 1)
    assert timers["test"] == 1
    assert timers.stdev("test") == math.nan

    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers["test"] == 3
    assert timers.stdev("test") == 0.5

    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers["test"] == 6
    assert timers.stdev("test") == 1

    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 1)
    assert timers["test"] == 2

# Generated at 2022-06-23 16:05:34.645750
# Unit test for constructor of class Timers
def test_Timers():  # pragma: no cover
    timers = Timers()
    assert timers.data == dict()
    assert timers._timings == dict()


# Generated at 2022-06-23 16:05:43.690589
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    # Test default constructor
    timers = Timers()
    assert(isinstance(timers, UserDict))
    assert(isinstance(timers, Timers))
    assert(hasattr(timers, 'data'))
    assert(hasattr(timers, 'add'))
    assert(hasattr(timers, 'clear'))
    assert(hasattr(timers, 'count'))
    assert(hasattr(timers, 'total'))
    assert(hasattr(timers, 'min'))
    assert(hasattr(timers, 'max'))
    assert(hasattr(timers, 'mean'))
    assert(hasattr(timers, 'median'))
    assert(hasattr(timers, 'stdev'))

# Generated at 2022-06-23 16:05:45.400506
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()
    stats = t.total("test") == 0.0
    assert stats

# Generated at 2022-06-23 16:05:50.198174
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers.add('a', 3.0)
    assert times.apply(min, 'a') == 3.0
    timers.add('a', 2.0)
    assert times.apply(min, 'a') == 2.0
    assert timers.apply(max, 'a') == 3.0



# Generated at 2022-06-23 16:05:57.992017
# Unit test for method min of class Timers
def test_Timers_min():
    print("Testing Timers.min()######################")
    timers = Timers()
    timers.add('test1',1)
    timers.add('test2',2)
    timers.add('test3',3)
    timers.add('test4',4)
    timers.add('test5',5)
    timers.add('test6',6)
    timers.add('test7',7)
    timers.add('test8',8)
    timers.add('test9',9)
    timers.add('test10',10)
    timers.add('test11',11)
    timers.add('test12',12) 
    timers.add('test13',13) 
    timers.add('test14',14) 
    timers.add('test15',15) 

# Generated at 2022-06-23 16:06:02.482638
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers._timings['item'] = [1, 2, 3]
    timers.data['item'] = 6.0
    timers.clear()
    assert timers._timings == {}
    assert timers.data == {}



# Generated at 2022-06-23 16:06:07.359213
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    timers = Timers()
    name = 'a'
    value = 0.0
    assert timers.data == dict()
    timers.add(name, value)
    assert timers.data == {'a': 0.0}
    timers.add(name, value)
    assert timers.data == {'a': 0.0}

# Generated at 2022-06-23 16:06:18.496219
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test method __setitem__ of class Timers"""
    # Test assignment is not possible
    timers = Timers()
    try:
        timers["foo"] = 1
    except TypeError:
        pass
    else:
        raise Exception()
    # Test that key error is raised for missing timer
    try:
        print(timers.total("bar"))
    except KeyError:
        pass
    else:
        raise Exception()
    # Test that statistics are reported
    timers.add("bar", value=1.0)
    assert timers.total("bar") == 1.0
    assert timers.count("bar") == 1.0
    assert timers.min("bar") == 1.0
    assert timers.max("bar") == 1.0
    assert timers.mean("bar") == 1.0

# Generated at 2022-06-23 16:06:23.276388
# Unit test for method max of class Timers
def test_Timers_max():
    """Test for method max of class Timers"""
    timer = Timers()
    timer.add('timings', 2.)
    timer.add('timings', 8.)
    timer.add('timings', 3.)
    assert timer.max('timings') == 8


# Generated at 2022-06-23 16:06:28.388995
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test the method clear of class Timers"""
    timers = Timers()
    timers.add("test", 1.23)
    timers.clear()
    assert dict(timers) == {}
    assert timers.count("test") == 0
    assert timers.total("test") == 0
    assert timers.min("test") == 0
    assert timers.max("test") == 0
    assert timers.mean("test") == 0
    assert timers.median("test") == 0
    assert timers.stdev("test") == 0

# Generated at 2022-06-23 16:06:31.249287
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Ensure that resetting the timer works."""
    timers = Timers({'a': 1})
    assert timers.data == {'a': 1}
    timers.clear()
    assert timers.data == {}

# Generated at 2022-06-23 16:06:34.053992
# Unit test for constructor of class Timers
def test_Timers():
    """Test constructor of class Timers"""
    timers = Timers()
    assert timers.data == {}  # pragma: no cover
    assert timers._timings == {}  # pragma: no cover



# Generated at 2022-06-23 16:06:40.921384
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test Timers.apply() method"""
    from unittest import TestCase

    class _Test(TestCase):
        """Test Timers.apply() method"""

        def test_apply(self) -> None:
            """Test Timers.apply() method"""
            timers = Timers()
            timers.add("timer1", 1.1)
            timers.add("timer1", 2.2)
            self.assertEqual(timers.apply(min, name="timer1"), min([1.1, 2.2]))


# Generated at 2022-06-23 16:06:44.417813
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Declare instance of Timers class
    timers = Timers()
    # Add samples to timers
    for n in range(10):
        timers.add('test', n)
    # Assert mean value
    assert timers.mean('test') == 4.5

# Generated at 2022-06-23 16:06:49.978804
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    # Setup
    t = Timers()
    # Exercise
    t.add('test', 0.1)
    t.add('test', 0.1)
    t.add('test', 0.1)
    t.add('test', 0.1)
    t.add('test', 0.1)
    # Verify
    assert t.stdev('test') == 0
    t.add('test', 0.2)
    assert abs(t.stdev('test') - 0.1) < 1e-9
    # Cleanup - none necessary
    del t

# Generated at 2022-06-23 16:06:51.961939
# Unit test for method count of class Timers
def test_Timers_count():
    pass


# Generated at 2022-06-23 16:06:56.072303
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count(name="mytime") == 0
    timers.add(name="mytime", value=1.0)
    assert timers.count(name="mytime") == 1


# Generated at 2022-06-23 16:06:59.367944
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test if clear works as expected"""
    timers=Timers()
    timers.add("test",1.0)
    timers.clear()
    assert timers.data == {}
    assert timers._timings == {}

# Generated at 2022-06-23 16:07:05.491953
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test for method __setitem__ of class Timers"""
    # Check that TypeError is raised when trying to set an item
    TIMERS = Timers()
    with pytest.raises(TypeError, match='does not support item assignment'):
        TIMERS["a"] = 1  # type: ignore


# Generated at 2022-06-23 16:07:10.199785
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    assert timers.data == {}
    timers.add('timer1', 1)
    timers.add('timer2', 2)
    assert timers.data == {'timer1': 1, 'timer2': 2}
    timers.clear()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:07:14.076329
# Unit test for method apply of class Timers
def test_Timers_apply():
    def func(values: List[float]) -> float:
        return sum(values)

    timers = Timers({"test": 3.0})
    timers._timings["test"] = [1.0, 2.0]

    assert timers.apply(func, "test") == 3.0
    assert timers.apply(func, "test2") == 0.0

# Generated at 2022-06-23 16:07:22.226538
# Unit test for method max of class Timers
def test_Timers_max():
    from random import random
    sample_sizes = [10, 100, 200]
    timer = Timers()
    for i in range(50):
        sample_size = sample_sizes[random()>=0.5]
        for j in range(sample_size):
            timer.add(name='test',value=random())
    assert timer.total(name='test')>0
    assert timer.count(name='test')==sum(sample_sizes)
    assert timer.max(name='test')>0


# Generated at 2022-06-23 16:07:32.148304
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    timers = Timers()
    assert isinstance(timers, collections.UserDict)
    assert isinstance(timers, Timers)
    timers.add('test_0', 1.5)
    timers.add('test_1', 0.5)
    timers.add('test_2', 1.0)
    timers.add('test_1', 0.5)
    assert timers.data == {'test_0': 1.5, 'test_1': 1.0, 'test_2': 1.0}
    assert timers._timings == {
        'test_0': [1.5],
        'test_1': [0.5, 0.5],
        'test_2': [1.0],
    }
    timers.clear()

# Generated at 2022-06-23 16:07:36.390119
# Unit test for method min of class Timers
def test_Timers_min():
    # Test with empty list
    t = Timers()
    assert t.min("a") == 0
    # Test with non-empty list
    t.add("a", 5)
    assert t.min("a") == 5

# Generated at 2022-06-23 16:07:39.827685
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count("foo") == 0
    timers.add("foo", 1)
    assert timers.count("foo") == 1
    timers.add("foo", 1)
    assert timers.count("foo") == 2


# Generated at 2022-06-23 16:07:41.218565
# Unit test for method median of class Timers
def test_Timers_median():
    assert Timers().median('') == math.nan

# Generated at 2022-06-23 16:07:49.268003
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean() method of the Timers class"""
    timers = Timers()
    if __name__ == "__main__":
        timers.add("c", 1.0)
        timers.add("c", 2.0)
        assert timers.mean("c") == 1.5
        timers.add("c", 3.0)
        assert timers.mean("c") == 2.0
        try:
            timers.mean("d")
        except KeyError:
            print("KeyError exception caught as expected")


# Generated at 2022-06-23 16:07:52.759178
# Unit test for method add of class Timers
def test_Timers_add():
    t = Timers()
    for n in range(10):
        t.add('test', n)
    assert(t.data['test'] == 45)
    assert(t._timings['test'] == list(range(10)))


# Generated at 2022-06-23 16:07:56.373014
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add("timer 1", 1.0)
    timers.add("timer 2", 2.0)
    timers.add("timer 3", 3.0)
    timers.clear()
    assert len(timers.data) == len(timers._timings) == 0



# Generated at 2022-06-23 16:08:01.686608
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t._timings = {"timer1":[0,1,2,3,4], "timer2":[2,2,2,2,2]}
    assert t.min("timer1") == 0
    assert t.min("timer2") == 2


# Generated at 2022-06-23 16:08:04.071887
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    timers = Timers()
    with pytest.raises(TypeError):
        timers['minimum'] = 0.0
    with pytest.raises(TypeError):
        timers['minimum'] = None


# Generated at 2022-06-23 16:08:07.670131
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """
    Test that the Timers class forbids use of the __setitem__ method
    """
    timer = Timers()
    with pytest.raises(TypeError):
        timer["test"] = 2.0


# Generated at 2022-06-23 16:08:13.903592
# Unit test for method max of class Timers
def test_Timers_max():
    # Create a dictionary
    data = Timers()

    # Add a key
    data.add("key", 1.0)

    # Add multiple elements to the key
    data.add("key", 2.0)
    data.add("key", 3.0)

    # Get the max element
    data.add("key", 4.0)
    maxValue = data.max("key")

    # Check the value of maxValue
    assert maxValue == 4.0, "Wrong maximum value"

# Generated at 2022-06-23 16:08:22.517590
# Unit test for method add of class Timers
def test_Timers_add():
    # Test Timers.add with simple cases
    t = Timers()
    t.add("a", 1.0)
    t.add("a", 2.0)
    t.add("b", 3.0)
    assert t.data["a"] == 3.0
    assert t.data["b"] == 3.0
    assert t.total("a") == 3.0
    assert t.total("b") == 3.0
    assert t.count("a") == 2
    assert t.count("b") == 1



# Generated at 2022-06-23 16:08:28.826146
# Unit test for method median of class Timers
def test_Timers_median():
    # Create a Timers object
    timers = Timers()
    # Add some test times
    timers.add("test_timer", 0.8)
    timers.add("test_timer", 0.9)
    timers.add("test_timer", 0.7)
    # Calculate the median manually
    expected_median = (0.8 + 0.9) / 2
    # Check the value returned by the method against the expected one
    assert timers.median("test_timer") == expected_median


# Generated at 2022-06-23 16:08:34.567848
# Unit test for method median of class Timers
def test_Timers_median():
    timer = Timers()
    timer.add("check", 3.5)
    timer.add("check", 1.5)
    timer.add("check", 2.5)
    assert timer.median("check") == 2.5
    timer.add("check", 4.5)
    assert timer.median("check") == 3
    assert timer.apply(lambda values: statistics.median(values or [0]), name="check") == 3


# Generated at 2022-06-23 16:08:38.046402
# Unit test for method total of class Timers
def test_Timers_total():
    """Tests if the total method of Timers is working."""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 4)
    assert timers.total("test") == 5


# Generated at 2022-06-23 16:08:43.202694
# Unit test for method max of class Timers
def test_Timers_max(): 
    assert Timers( {'one':10.0} ).max( 'one' ) == 10.0
    assert Timers( {'one':10.0} ).max( 'two' ) == 0 # KeyError


# Generated at 2022-06-23 16:08:47.174592
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers._timings = {'work': [4.4, 6.6]}

    assert timers.apply(sum, 'work') == 11.0
    assert timers.apply(len, 'work') == 2


# Unit tests for Timers

# Generated at 2022-06-23 16:08:53.517446
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("a", 5)
    timers.add("a", 11)
    timers.add("b", 8)
    timers.add("b", 20)
    timers.add("b", 24)
    assert timers.mean("a") == 8.0
    assert timers.mean("b") == 16.0
    assert timers.mean("c") == 0.0

# Generated at 2022-06-23 16:09:03.799296
# Unit test for method apply of class Timers
def test_Timers_apply(): 
    """Unit test for method apply of class Timers"""
    # Test with one key-value pair
    timers1 = Timers()
    assert timers1.apply(len, name="one") == 0
    timers1.add("one", 1)
    assert timers1.apply(len, name="one") == 1
    timers1.clear()
    assert timers1.apply(len, name="one") == 0
    # Test with multiple key-value pairs
    timers2 = Timers()
    assert timers2.apply(len, name="one") == 0
    assert timers2.apply(len, name="two") == 0
    timers2.add("one", 1)
    assert timers2.apply(len, name="one") == 1
    assert timers2.apply(len, name="two") == 0

# Generated at 2022-06-23 16:09:05.831420
# Unit test for method min of class Timers
def test_Timers_min():
    # Test empty timer
    timer = Timers()
    assert timer.min('empty') == 0
    # Test non-empty timer
    timer = Timers({'non-empty': 42})
    assert timer.min('non-empty') == 42


# Generated at 2022-06-23 16:09:09.773550
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("timer1", 0.3)
    timers.add("timer1", 0.6)
    timers.add("timer1", 0.9)
    timers.add("timer2", 0.5)
    timers.add("timer2", 0.1)

    assert timers.count("timer1") == 3
    assert timers.count("timer2") == 2

# Generated at 2022-06-23 16:09:17.253665
# Unit test for method total of class Timers
def test_Timers_total():
    """Unit test for method total of class Timers"""
    timers = Timers()
    timers.add("first", 1.0)
    timers.add("first", 2.0)
    timers.add("first", 3.0)
    timers.add("second", 3.0)
    # Check for expected time for known timers
    assert timers.total("first") == 6.0
    assert timers.total("second") == 3.0
    # Check for expected time for unknown timers
    try:
        timers.total("third")
        assert False
    except KeyError:
        assert True

# Generated at 2022-06-23 16:09:19.444504
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("count", 0)
    timers.add("count", 1)
    timers.add("count", 2)
    timers.add("count", 3)
    assert timers.count("count") == 4


# Generated at 2022-06-23 16:09:29.146494
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method add of class Timers"""
    timer = Timers()
    timer.add("f", 123.45)
    assert timer.data["f"] == 123.45
    assert timer._timings["f"] == [123.45]
    timer.add("f", 543.21)
    assert timer.data["f"] == 666.66
    assert timer._timings["f"] == [123.45, 543.21]
    timer.add("f", 9.87654321)
    assert timer.data["f"] == 676.53654321
    assert timer._timings["f"] == [123.45, 543.21, 9.87654321]


# Generated at 2022-06-23 16:09:31.360695
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    with pytest.raises(TypeError):
        timers["test"] = 1.0



# Generated at 2022-06-23 16:09:38.218139
# Unit test for method count of class Timers
def test_Timers_count():
    # Given
    timer_dictionary = collections.defaultdict(list)
    timer_dictionary["timer1"] = [1.1, 2.2, 3.3]
    timer_dictionary["timer2"] = [4.4, 5.5, 6.6, 7.7]
    timers = Timers(timer_dictionary)
    
    # When
    actual_result = timers.count("timer1")
    
    # Then
    expected_result = 3
    assert actual_result == expected_result


# Generated at 2022-06-23 16:09:42.003590
# Unit test for method min of class Timers
def test_Timers_min():
    """For coverage.py, minimal test of method Timers.min()"""
    timers = Timers()
    timers.add("foo", 1)
    timers.add("foo", 2)
    assert timers.min("foo") == 1



# Generated at 2022-06-23 16:09:45.295357
# Unit test for method max of class Timers
def test_Timers_max():
    my_timers=Timers()
    assert my_timers.max("test") == 0
    my_timers.add("test", 10)
    assert my_timers.max("test") == 10

# Generated at 2022-06-23 16:09:53.975556
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit tests for Timers.median"""
    # Empty timings
    t: Timers = Timers()
    assert t.median("empty") == 0.

    # Odd number of timings
    t: Timers = Timers()
    t.add("odd", 0.5)
    t.add("odd", 1.)
    t.add("odd", 1.5)
    assert t.median("odd") == 1.

    # Even number of timings
    t: Timers = Timers()
    t.add("even", 0.5)
    t.add("even", 1.)
    t.add("even", 1.5)
    t.add("even", 2.)
    assert t.median("even") == 1.25

# Generated at 2022-06-23 16:09:55.239359
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert len(timers) == 0


# Generated at 2022-06-23 16:10:03.116361
# Unit test for method total of class Timers
def test_Timers_total():
    # PREPARE
    timers = Timers()
    # RUN
    timers.add("timer_one", 3.14)
    # CHECK
    assert timers.total("timer_one") == 3.14
    # RUN
    timers.add("timer_one", 3.14)
    # CHECK
    assert timers.total("timer_one") == 6.28
    # RUN
    timers.add("timer_two", 6.28)
    # CHECK
    assert timers.total("timer_two") == 6.28
    # CHECK
    assert timers.total("timer_three") == 0.0
    # NO CLEAN-UP NEEDED


# Generated at 2022-06-23 16:10:11.579149
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    import time
    import unittest

    class TimersTestCase(unittest.TestCase):
        """Unit tests for class Timers"""

        def test_timers(self):
            """Test methods of class Timers"""
            timers = Timers()
            timers.add("test", 1)
            timers.add("test", 2)
            timers.add("test", 3)
            timers["test"] = 5


    # Execute unit tests
    unittest.main(exit=False)


# Generated at 2022-06-23 16:10:15.958515
# Unit test for method clear of class Timers
def test_Timers_clear():
    # Given a Timers object
    timers = Timers()

    # When we add a new timer
    timers.add("hello", 42)

    # Then the total time is correct
    assert timers.total("hello") == 42

    # When we clear the object
    timers.clear()

    # Then it's empty
    assert not timers
    assert not timers._timings
    assert timers.total("hello") == 0

# Generated at 2022-06-23 16:10:23.109481
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method 'add'"""
    timers = Timers()
    timers.add("a", 1.2)
    timers.add("a", 2.3)
    timers.add("b", 3.4)
    assert timers.data["a"] == 1.2 + 2.3
    assert timers.data["b"] == 3.4
    assert timers._timings["a"] == [1.2, 2.3]
    assert timers._timings["b"] == [3.4]



# Generated at 2022-06-23 16:10:30.722900
# Unit test for constructor of class Timers
def test_Timers():
    """Unit tests for the Timers class

    In this unit test, we test the initialisation of the Timers class
    and all its functions.
    """
    timers = Timers()
    assert len(timers) == 0, "Timer created with initialisers"

    timers = Timers({'a': 1})
    assert timers.get('a') == 1, "Timer created with initialisers"

    timers = Timers(a=1)
    assert timers.get('a') == 1, "Timer created with initialisers"

    assert timers.count('a') == 1, "Timer can count"
    assert str(timers.count) == "<method 'count' of 'Timers' objects>", \
        "Timer can count"

    assert timers.total('a') == 1, "Timer can total"

# Generated at 2022-06-23 16:10:36.153552
# Unit test for method clear of class Timers
def test_Timers_clear():
    # Get a dummy instance of the class Timers
    timers = Timers()
    timers["foo"] = 10
    timers["bar"] = 20
    # Clear the instance
    timers.clear()
    # Verify that the dictionaries of the instance are empty
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:10:44.539047
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for Timers.apply"""

    def mean_square(values: List[float]) -> float:
        """Compute the mean square of a list of float"""
        mean = statistics.mean(values)
        return sum((x - mean) ** 2 for x in values) / len(values)

    timers = Timers()
    timers._timings = {"a": [1, 2, 3, 4, 5], "b": [11, 12, 13, 14, 15]}
    assert timers.apply(mean_square, name="a") == 2
    assert timers.apply(mean_square, name="b") == 2
    assert timers.apply(mean_square, name="c") == 0


# Generated at 2022-06-23 16:10:50.800914
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    import unittest.mock
    def func(arg: Any) -> float:
        return 17
    timings = Timers()
    func.assert_called_with([])
    with unittest.mock.patch('functools.partial', return_value=func) as func:
        assert timings.apply(func, name='test') == 17

# Generated at 2022-06-23 16:10:57.922726
# Unit test for method median of class Timers
def test_Timers_median():
    """Test for Timers class"""
    tim = Timers()
    tim.add('test', 1)
    tim.add('test', 1)
    tim.add('test', 2)
    tim.add('test', 3)

    assert tim.median('test') == 2

    tim.clear()
    tim.add('test', 1)
    tim.add('test', 2)

    assert tim.median('test') == 1.5

    tim.clear()
    tim.add('test', 1)
    assert tim.median('test') == 1


# Generated at 2022-06-23 16:11:05.401649
# Unit test for method median of class Timers
def test_Timers_median():
    # Cases
    cases: Dict[int, List[float]] = {
        0: [],
        1: [1],
        2: [1, 1],
        3: [1, 2, 3],
        4: [1, 1, 2, 3],
        5: [1, 2, 3, 4, 5],
        6: [1, 1, 2, 3, 4, 5],
    }

    # Run tests
    for expected, values in sorted(cases.items()):
        assert Timers().median(values) == expected


# Generated at 2022-06-23 16:11:11.709494
# Unit test for method total of class Timers
def test_Timers_total():
    """Test the total method of Timers object"""
    timers = Timers()
    timers.add("timing1", 2)
    timers.add("timing1", 1)
    timers.add("timing2", 2)
    timers.add("timing2", 2)
    assert timers.total("timing1") == 3
    assert timers.total("timing2") == 4

# Generated at 2022-06-23 16:11:17.319405
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers._timings['timer_1'] = []
    timers._timings['timer_2'] = [1.0, 2.0, 3.0]

    assert timers.apply(lambda x: x[0], name='timer_1') == None
    assert timers.apply(lambda x: x[0], name='timer_2') == 1.0
    assert timers.apply(lambda x: x[1], name='timer_2') == 2.0


# Generated at 2022-06-23 16:11:22.282780
# Unit test for method add of class Timers
def test_Timers_add():
    # Arrange
    timers = Timers()

    # Act
    timers.add("timer1", 1)
    timers.add("timer2", 2)

    # Assert
    assert timers["timer1"] == 1
    assert timers["timer2"] == 2


# Generated at 2022-06-23 16:11:31.433661
# Unit test for method max of class Timers
def test_Timers_max():

    t = Timers()

    t["foo"] = Timers()
    t["foo"].add("a", 0)
    t["foo"].add("b", 0)

    assert t.max("foo") == 0
    assert t.max("foo", "a") == 0
    assert t.max("foo", "b") == 0
    assert t.max("foo", "c") == 0
    assert t.max("foo", "a", "b") == 0
    assert t.max("foo", "a", "c") == 0
    assert t.max("foo", "c", "b") == 0
    assert t.max("foo", "b", "c") == 0
    assert t.max("foo", "a", "b", "c") == 0

    t["foo"].add("a", 1)
    t

# Generated at 2022-06-23 16:11:38.779082
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test the method stdev of the class Timers"""
    my_timers = Timers()
    my_timers.add("Timer 1", value=5)
    my_timers.add("Timer 1", value=6)
    my_timers.add("Timer 1", value=8)
    my_timers.add("Timer 1", value=8)
    my_timers.add("Timer 1", value=10)
    my_timers.add("Timer 1", value=11)
    my_timers.add("Timer 1", value=13)
    assert math.isclose(my_timers.stdev("Timer 1"), math.sqrt(10))
    my_timers.clear()
    my_timers.add("Timer 1", value=10.1)

# Generated at 2022-06-23 16:11:50.756463
# Unit test for method apply of class Timers
def test_Timers_apply():
    from sys import stderr
    from .timer import Timer
    with Timer(name="timer 1") as t1:
        t1.timers.add("timer 2", 1.0)
    with Timer(name="timer 2") as t2:
        t2.timers.add("timer 2", 2.0)
    t2.timers["timer 3"] = 3.0
    with Timer(name="timer 2", file=stderr) as t2:
        t2.timers.add("timer 2", 4.0)
    t2.timers["timer 3"] = 5.0