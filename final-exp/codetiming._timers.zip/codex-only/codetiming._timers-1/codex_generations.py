

# Generated at 2022-06-23 16:01:54.225007
# Unit test for method count of class Timers
def test_Timers_count():
    """Timers_count"""
    t = Timers()
    t.add("some", 10)
    t.add("some", 20)
    assert t.count("some") == 2
    assert t.count("other") == 0


# Generated at 2022-06-23 16:02:01.406150
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    # Read data from file
    data = []
    with open("timers.csv", "r") as fil:
        for _, line in enumerate(fil):
            data.append(float(line.strip()))
    data = sorted(data)
    # Number of values and data
    n = len(data)
    data = data
    # Mean with numpy
    numpy_mean = statistics.mean(data)
    # Mean with home made function
    my_mean = sum(data)/n

    # Create a class Timers with mean value equal to data from file
    timers = Timers()
    for d in data:
        timers.add("test", time)

    
    # Check if the mean is calculated correctly

# Generated at 2022-06-23 16:02:06.335622
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()

    name = "timer"

    timers.add(name, 1)
    assert timers.mean(name) == 1

    timers.add(name, 2)
    assert timers.mean(name) == 1.5
    assert timers.data[name] == 3

    timers.add(name, 3)
    assert timers.mean(name) == 2


# Generated at 2022-06-23 16:02:10.961885
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test that the method Timers.mean works correctly"""
    timers = Timers()
    timers.add("timer", 1)
    assert timers.mean("timer") == 1
    timers.add("timer", 2)
    assert 1 < timers.mean("timer") < 2
    timers.add("timer", 3)
    assert 2 < timers.mean("timer") < 3
    timers.add("timer", 4)
    assert 3 < timers.mean("timer") < 4


# Generated at 2022-06-23 16:02:13.485558
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean in class Timers"""
    a = Timers()
    assert a.mean("key") == 0
    a.add("key", 5)
    assert a.mean("key") == 5

# Generated at 2022-06-23 16:02:16.766431
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """
    Timers.__setitem__ raises TypeError.
    """
    timers = Timers()
    with pytest.raises(TypeError):
        timers["a"] = "b"


# Generated at 2022-06-23 16:02:20.301028
# Unit test for constructor of class Timers
def test_Timers():
    """Check that constructor of class Timers works"""
    timers = Timers()
    assert timers == {}
    assert len(timers) == 0
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:02:23.748421
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Obtain the mean value of different timers"""
    timers = Timers()
    timers.add("timer1", 100)
    timers.add("timer1", 50)
    assert timers.mean("timer1") == 75


# Generated at 2022-06-23 16:02:26.739658
# Unit test for method median of class Timers
def test_Timers_median():
    """Test Timers.median"""
    timers = Timers()
    timers._timings["test"] = [1, 2]
    assert timers.median("test") == 1.5

    timers._timings["test"] = []
    assert math.isnan(timers.median("test"))



# Generated at 2022-06-23 16:02:32.732220
# Unit test for method count of class Timers
def test_Timers_count():
    """Unit test for method count of class Timers"""
    mytimers = Timers()
    mytimers.add("mytimer", 1.0)
    mytimers.add("mytimer", 2.0)
    assert mytimers.count("mytimer") == 2
    assert mytimers.count("myothertimer") == 0


# Generated at 2022-06-23 16:02:37.800825
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Function to test Timers.__setitem__"""
    
    timers = Timers()
    test_timer_name = "test_timer"
    test_timer_value = 0.0
    timers[test_timer_name] = test_timer_value
    assert timers[test_timer_name] == test_timer_value
    timers[test_timer_name] = test_timer_value + 1
    assert timers[test_timer_name] == test_timer_value + 1
    timers.apply(len, test_timer_name) == test_timer_value + 1


# Generated at 2022-06-23 16:02:39.633359
# Unit test for method apply of class Timers
def test_Timers_apply():
    t = Timers()
    t.apply(lambda values: min(values or [0]), 'TIMER')

# Generated at 2022-06-23 16:02:43.918603
# Unit test for method min of class Timers
def test_Timers_min():
    """Test Timers.min"""
    from random import randint

    timers = Timers()

    # Add timing values
    for i in range(0, 100):
        timers.add(str(i), value=randint(0, 100))

    # Test min
    for i in range(0, 100):
        assert timers.min(str(i)) <= 100



# Generated at 2022-06-23 16:02:54.291281
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    with pytest.raises(KeyError):
        timers.apply(len, "timer1")
    timers.add("timer1", 1.1)
    assert timers.count("timer1") == 1
    assert timers.total("timer1") == 1.1
    assert timers.min("timer1") == 1.1
    assert timers.max("timer1") == 1.1
    assert timers.mean("timer1") == 1.1
    assert timers.median("timer1") == 1.1
    assert math.isnan(timers.stdev("timer1"))
    timers.add("timer1", 2.2)
    timers.add("timer1", 3.3)
    assert timers.count("timer1") == 3
    assert timers.total("timer1") == 6.6
    assert timers

# Generated at 2022-06-23 16:02:58.041839
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add('test', 1.)
    assert timers.median('test') == 1.
    timers.add('test', 3.)
    assert timers.median('test') == 1.5
    timers.add('test', 5.)
    assert timers.median('test') == 3.

# Generated at 2022-06-23 16:03:02.485899
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    timers = Timers()
    timers.add('foo', 1)
    timers.add('foo', 2)
    assert timers['foo'] == 3
    assert timers.total('foo') == 3


# Generated at 2022-06-23 16:03:04.668686
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    t.add("identity", 1)
    t.add("identity", 4)
    t.add("identity", 2)
    t.add("identity", 4)
    assert t.median("identity") == 2.5

# Generated at 2022-06-23 16:03:12.677839
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("0", 0)
    timers.add("0", 1)
    timers.add("0", 2)
    timers.add("0", 3)
    timers.add("0", 4)
    timers.add("1", 10)
    timers.add("1", 8)
    timers.add("1", 5)
    timers.add("2", 10)
    timers.add("2", 10)
    timers.add("2", 10)
    timers.add("3", 10)
    timers.add("3", 10)
    assert timers.min("0") == 0
    assert timers.min("1") == 5
    assert timers.min("2") == 10
    assert timers.min("3") == 10

# Generated at 2022-06-23 16:03:13.804844
# Unit test for method count of class Timers
def test_Timers_count():
    assert True


# Generated at 2022-06-23 16:03:20.007508
# Unit test for method clear of class Timers
def test_Timers_clear():
    """
    Test that clear method removes all values from both dictionaries
    """
    timer = Timers()
    timer.add('timer 1', 1.0)
    timer.add('timer 1', 1.0)
    timer.add('timer 2', 2.0)
    timer.add('timer 2', 2.0)
    timer.clear()
    assert len(timer.data) == 0
    assert len(timer._timings) == 0


# Generated at 2022-06-23 16:03:24.823346
# Unit test for method total of class Timers
def test_Timers_total():

    timers_total = Timers()

    timers_total.add('total', 3.5)
    assert timers_total.total('total') == 3.5

    assert timers_total.total('invalid') == 0

    timers_total.clear()

# Generated at 2022-06-23 16:03:27.251875
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('name', 1.2)
    timers.add('name', 1.5)
    assert timers.count('name') == 2


# Generated at 2022-06-23 16:03:31.180046
# Unit test for method total of class Timers
def test_Timers_total():
    """Test method total in class Timers"""

    timers = Timers()
    timers.add('total', 1)
    timers.add('total', 2)
    timers.add('total', 3)
    return timers.total('total') == 6


# Generated at 2022-06-23 16:03:35.660663
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """
    Unit test for method '__setitem__' of class 'Timers'
    """
    # Initialize
    timers = Timers()
    assert len(timers) == 0
    # Try setting an illegal value using '__setitem__'
    with pytest.raises(TypeError, match="does not support item assignment"):
        timers["illegal"] = 1.0


# Generated at 2022-06-23 16:03:42.852320
# Unit test for method total of class Timers
def test_Timers_total():
    """Test method total of class Timers"""
    timers = Timers()
    timers.add("Timer_1", 1)
    timers.add("Timer_1", 2)
    timers.add("Timer_2", 3)
    assert timers.total("Timer_1") == 3
    assert timers.total("Timer_2") == 3
    assert len(timers) == 2

    timers = Timers()
    timers.add("Timer_1", 1)
    timers.add("Timer_1", 2)
    timers.add("Timer_2", 3)
    timers.add("Timer_2", 4)
    assert timers.total("Timer_1") == 3
    assert timers.total("Timer_2") == 7
    assert len(timers) == 2


# Generated at 2022-06-23 16:03:48.735375
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers({'next_call': 2.8110468978761323})
    timers.add('next_call', 2.8095385829891296)
    assert timers.max('next_call') == 2.8110468978761323

    timers = Timers()
    timers.add('next_call', 2.8095385829891296)
    assert timers.max('next_call') == 2.8095385829891296


# Generated at 2022-06-23 16:03:53.222441
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    timers = Timers()

    timers.add("a", 1)
    timers.add("a", 3)
    assert timers.apply(sum, "a") == 4
    assert timers.apply(lambda values: max(values), "a") == 3
    assert timers.apply(lambda values: max(values), "b") == 0
    return


# Generated at 2022-06-23 16:03:56.038386
# Unit test for constructor of class Timers
def test_Timers():
    assert Timers() == {}, "Empty dictionary should be created"

# Generated at 2022-06-23 16:03:58.703711
# Unit test for method add of class Timers
def test_Timers_add():
    t = Timers()
    t.add("test", 1)
    t.add("test", 2)
    assert t["test"] == 3


# Generated at 2022-06-23 16:04:02.166714
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers(name1=1.0, name2=None)
    assert isinstance(timers, collections.UserDict)
    assert timers.data == {'name1': 1.0, 'name2': 0}
    assert timers._timings == {}


# Generated at 2022-06-23 16:04:06.674856
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test clear method of Timers"""
    x = Timers()
    x["foo"] = 1
    x["bar"] = 2
    x.add("foo", 3)
    x.clear()
    assert len(x.data) == 0
    assert len(x._timings) == 0
    assert x.mean("foo") == 0


# Generated at 2022-06-23 16:04:10.584207
# Unit test for constructor of class Timers
def test_Timers():
    """Tests for Timers class"""
    timer = Timers()
    assert len(timer) == 0
    assert timer.data == {}
    assert timer._timings == {}
    del timer

# Generated at 2022-06-23 16:04:15.819796
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("test_method_min", 1)
    t.add("test_method_min", 2)
    t.add("test_method_min", 3)

    assert t.min("test_method_min") == 1
    assert t.min("test_method_min") == min([1, 2, 3])

    t.add("test_method_min_none", None)
    assert t.min("test_method_min_none") == 0


# Generated at 2022-06-23 16:04:20.338632
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers._timings = {'my_timer': [1, 2, 3, 4]}
    assert timers.stdev('my_timer') == 1
    

# Generated at 2022-06-23 16:04:27.095470
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("Timer1", 1.0)
    timers.add("Timer2", 2.0)
    timers.add("Timer1", 3.0)
    assert timers.max("Timer1") == 3.0
    assert timers.max("Timer2") == 2.0
    assert "Timer3" not in timers.data
    try:
        timers.max("Timer3")
    except KeyError:
        assert True
    except:
        assert False


# Generated at 2022-06-23 16:04:33.997264
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('load', 2.0)
    timers.add('load', 2.1)
    timers.add('load', 2.1)
    maxi = timers.max('load')
    assert maxi == 2.1
    # Test what happens if a key is not present
    try:
        timers.max('not_present')
        raise AssertionError
    except KeyError:
        pass
    return True

# Generated at 2022-06-23 16:04:35.855417
# Unit test for constructor of class Timers
def test_Timers():
    "Check initialization of class Timers"
    timers = Timers()
    timers["example"] = 1.1  # This should result in an error

# Generated at 2022-06-23 16:04:38.113483
# Unit test for method apply of class Timers
def test_Timers_apply():
    t = Timers()
    t._timings["foo"] = [2, 3, 5, 7, 11, 13]
    result = t.apply(list.__len__, "foo")
    assert result == 6

# Generated at 2022-06-23 16:04:45.675061
# Unit test for method mean of class Timers
def test_Timers_mean():
    timer = Timers()
    name = "foo"
    timer.add(name, 1)
    timer.add(name, 2)
    assert timer.mean(name) == 1.5
    assert timer.total(name) == 3
    assert timer.min(name) == 1
    assert timer.max(name) == 2
    assert timer.mean(name) == timer.median(name)
    assert timer.stdev(name) == 0.5
    assert timer.count(name) == 2
    timer.add(name, 3)
    assert timer.mean(name) == 2
    assert timer.total(name) == 6
    assert timer.min(name) == 1
    assert timer.max(name) == 3
    assert timer.mean(name) == timer.median(name)
    assert timer.stdev

# Generated at 2022-06-23 16:04:55.914120
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    assert timers.mean('none') == 0
    timers.add('A', 5)
    assert timers.count('A') == 1
    assert timers.mean('A') == 5
    timers.add('A', 5)
    assert timers.count('A') == 2
    assert timers.mean('A') == 5
    timers.add('B', 5)
    timers.add('B', 10)
    timers.add('B', 15)
    assert timers.count('B') == 3
    assert timers.mean('B') == 10
    assert timers.mean('A') == 5
    assert timers.mean('none') == 0

# Generated at 2022-06-23 16:05:02.448014
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers({"key1": 1.0, "key2": 2.0})
    timers.add("key1", 10.0)
    timers.add("key1", 100.0)
    timers.add("key2", 2.0)
    assert timers.count("key1") == 3
    assert timers.count("key2") == 2



# Generated at 2022-06-23 16:05:05.329693
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("lala", 1)
    timers.add("lala", 2)
    assert timers.mean("lala") == 1.5

# Generated at 2022-06-23 16:05:11.819897
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Tests method __setitem__ when called"""
    timers = Timers()
    timers.add('a', 4)
    # Test
    try:
        timers['b'] = 5
    except TypeError as err:
        assert str(err) == (
            "Timers does not support item assignment. "
            "Use '.add()' to update values."
        )
    else:
        raise AssertionError("Should have raised an exception")

# Generated at 2022-06-23 16:05:18.564471
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add('a', 1)
    timers.add('a', 2)
    timers.add('b', 3)
    timers.add('a', 4)
    assert timers.data == {'a': 7, 'b': 3}
    assert timers._timings == {'a': [1, 2, 4], 'b': [3]}
    assert timers.count('a') == 3
    assert timers.count('b') == 1


# Generated at 2022-06-23 16:05:22.297392
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    t = Timers()
    t.add('data', 2)
    assert t.count('data') == 1
    assert t.stdev('data') != 0.0
    assert math.isnan(t.stdev('data'))




# Generated at 2022-06-23 16:05:26.550535
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers"""
    timers = Timers()
    timers.add("test_timer", 1)
    timers.add("test_timer", 3)
    assert timers.median("test_timer") == 2
    timers.add("test_timer", 2)
    assert timers.median("test_timer") == 2
    timers.clear()
    assert timers.median("test_timer") == 0

# Generated at 2022-06-23 16:05:31.198255
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    from pytest import raises
    from _pytest.monkeypatch import MonkeyPatch

    def func(values: List[float]) -> float:
        """Dummy function for unit testing"""
        return sum(values)

    monkeypatch = MonkeyPatch()
    timers = Timers()

    timers._timings["test_1"] = [1.5, 2.5]
    assert timers.apply(func, name="test_1") == 4.0

    monkeypatch.delitem(timers._timings, "test_1", raising=False)
    with raises(KeyError):
        timers.apply(func, name="test_1")

# Generated at 2022-06-23 16:05:32.133755
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    assert Timers().stdev('foo') == math.nan


# Generated at 2022-06-23 16:05:34.257803
# Unit test for method total of class Timers
def test_Timers_total():
    """Testing implementation of method total of class Timers"""
    t = Timers()
    t.add('A', 2)
    t.add('B', 1)
    t.add('B', 2)
    assert t.total('A') == 2
    assert t.total('B') == 3

# Generated at 2022-06-23 16:05:37.307020
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    for i in range(100):
        timers.add("name", i)
    assert timers.median("name") == 49.5
    assert timers.count("name") == 100

# Generated at 2022-06-23 16:05:41.012592
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    assert timers.data == dict()
    with pytest.raises(TypeError):
        timers['foobar'] = 0.0

# Generated at 2022-06-23 16:05:42.774045
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """ Test for method __setitem__ of class Timers. """
    with pytest.raises(TypeError):
        Timers()['test'] = 1.0

# Generated at 2022-06-23 16:05:50.696231
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers["foo"] == 0
    assert timers.apply(len, name="foo") == 0
    assert timers.apply(sum, name="foo") == 0
    assert timers.apply(lambda values: min(values or [0]), name="foo") == 0
    assert timers.apply(lambda values: max(values or [0]), name="foo") == 0
    assert timers.apply(lambda values: statistics.mean(values or [0]), name="foo") == 0
    assert timers.apply(lambda values: statistics.median(values or [0]), name="foo") == 0


# Generated at 2022-06-23 16:05:54.742896
# Unit test for method apply of class Timers
def test_Timers_apply():
    def two_minimums(values: List[float]) -> float:
        """Minimum of first two items in list"""
        return min(values[:2])

    timers = Timers()
    timers.add('t1', 1)
    timers.add('t1', 2)
    assert timers.apply(two_minimums, name='t1') == 1

# Generated at 2022-06-23 16:05:59.500008
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('test', 1.1)
    timers.add('test', 2.2)
    timers.add('test', 3.3)
    timers.add('test', 4.4)

    median = timers.median('test')
    assert(median == 2.75)

# Generated at 2022-06-23 16:06:02.583037
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers['test'] = 0.0
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 16:06:04.999495
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add('timer', 2.6)
    assert timers['timer'] == 2.6


# Generated at 2022-06-23 16:06:08.201691
# Unit test for constructor of class Timers
def test_Timers():
    '''
    Test constructors of class Timers
    '''
    timers = Timers()
    assert len(timers) == 0


# Generated at 2022-06-23 16:06:13.460065
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers.add('foo', 10)
    timers.add('bar', 20)
    assert timers.apply(min, 'foo') == 10
    assert timers.apply(max, 'foo') == 10
    assert timers.apply(min, 'bar') == 20
    assert timers.apply(max, 'bar') == 20


# Generated at 2022-06-23 16:06:17.527071
# Unit test for method total of class Timers
def test_Timers_total():
    """Test of method total from class Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.total("test") == 1
    timers.add("test", 2)
    assert timers.total("test") == 3

# Generated at 2022-06-23 16:06:26.636774
# Unit test for method median of class Timers
def test_Timers_median():
    def median(values: List[float]) -> float:
        """Median value of timings"""
        return statistics.median(values or [0])
    t = Timers()
    t._timings['test'] = [1,2,3,4,5]
    t.apply(median, name='test') == median(t._timings['test'])
    t._timings['test'] = [1]
    assert t.apply(median, name='test') == median(t._timings['test'])
    t._timings['test'] = []
    assert t.apply(median, name='test') == median(t._timings['test'])

# Generated at 2022-06-23 16:06:30.661386
# Unit test for method total of class Timers
def test_Timers_total():
    """ Test that the method total returns the correct value """
    timings = Timers()
    name = 'foo'
    timings.add(name, 1)
    timings.add(name, 2)
    assert timings.total(name) == 3



# Generated at 2022-06-23 16:06:36.137855
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Create an instance of Timers
    timers = Timers()
    # Create a set of values to be timed
    values = [3, 4, 5, 5, 9, 11, 11, 12]
    # Add values to the named timers
    for value in values:
        timers.add("loading", value)
    # Assert that the mean of all values is approximatively 6.375
    assert(timers.mean("loading") - 6.375) < 1E-9

# Generated at 2022-06-23 16:06:39.943574
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    timers = Timers()
    timers.add("logic", 10)
    assert timers.data == {"logic": 10}
    timers.add("rendering", 20)
    assert timers.data == {"logic": 10, "rendering": 20}


# Generated at 2022-06-23 16:06:49.115090
# Unit test for method add of class Timers
def test_Timers_add():
    timer = Timers()
    timer.add('timer1', 1.0)
    timer.add('timer2', 2.0)
    timer.add('timer1', 1.5)
    timer.add('timer2', 2.5)
    assert timer.count('timer1') == 2
    assert timer.count('timer2') == 2
    assert timer.total('timer1') == 2.5
    assert timer.total('timer2') == 4.5
    assert timer.min('timer1') == 1
    assert timer.min('timer2') == 2
    assert timer.max('timer1') == 1.5
    assert timer.max('timer2') == 2.5
    assert timer.mean('timer1') == 1.25
    assert timer.mean('timer2') == 2.25

# Generated at 2022-06-23 16:07:00.423480
# Unit test for method add of class Timers
def test_Timers_add():
    t = Timers()
    assert (t.data == {})
    assert (t._timings == {})
    t.add("n1", 2)
    assert (t.data == {"n1": 2})
    assert (t._timings == {"n1": [2]})
    t.add("n1", 3)
    assert (t.data == {"n1": 5})
    assert (t._timings == {"n1": [2, 3]})
    t.add("n2", 20)
    assert (t.data == {"n1": 5, "n2": 20})
    assert (t._timings == {"n1": [2, 3], "n2": [20]})


# Generated at 2022-06-23 16:07:05.295741
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median method of Timers class"""

    my_timers = Timers()
    my_timers.add("timer1", 5)
    my_timers.add("timer1", 10)

    assert my_timers.median("timer1") == 7.5

# Generated at 2022-06-23 16:07:07.846701
# Unit test for method max of class Timers
def test_Timers_max():
    values = [0, 1, 2, 3, 4, 5]
    t = Timers(dict(values=values))
    assert values == t["values"]


# Generated at 2022-06-23 16:07:10.957261
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()
    for i in range(100):
        t.add("name1", 1)
        t.add("name2", 2)
    assert t.total("name1") == 100
    assert t.total("name2") == 200

# Generated at 2022-06-23 16:07:16.675713
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test Timers.apply method"""
    t = Timers()

    t.add("a", 1.)
    t.add("a", 2.)
    t.add("b", 2.)

    assert t.apply(sum, "a") == 3.
    assert t.apply(len, "a") == 2
    assert t.apply(sum, "b") == 2.
    assert t.apply(len, "b") == 1
    assert t.apply(max, "b") == 2.

# Generated at 2022-06-23 16:07:18.314535
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:07:25.037670
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Check if method clears the dictionary and the dictionary of lists of timings"""
    timer = Timers()
    timer['test'] = 5
    timer['test2'] = 7
    timer.add('test3', 3) # pylint: disable=no-member
    assert 'test' in timer
    assert 'test2' in timer
    assert 'test3' in timer
    timer.clear()
    assert 'test' not in timer
    assert 'test2' not in timer
    assert 'test3' not in timer

    # TODO: Test if also the dictionary of lists of timings is cleared

# Generated at 2022-06-23 16:07:28.040077
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()

    # Add a timer
    timers.add("timer1", 1)
    assert timer.data["timer1"] == 1

    # Add a timer again
    timers.add("timer1", 1)
    assert timer.data["timer1"] == 2


# Generated at 2022-06-23 16:07:35.900804
# Unit test for method median of class Timers
def test_Timers_median():
    T=Timers()
    T1=Timers()
    time_list=[1, 5, 10, 20, 50, 100, 200]
    for i in time_list:
        T.add("T_median_test", i)
        T1.add("T1_median_test", i)
    assert T.median("T_median_test")==T1.median("T1_median_test")

# Generated at 2022-06-23 16:07:40.489117
# Unit test for method clear of class Timers
def test_Timers_clear():
    # Create an empty timers
    timers = Timers()
    assert len(timers) == 0

    # Add a timer
    timers.add("foo", 1.0)
    assert len(timers) == 1

    # Clear timers
    timers.clear()
    assert len(timers) == 0
    assert "foo" not in timers
    assert timers.get("foo") is None


# Generated at 2022-06-23 16:07:46.215592
# Unit test for method total of class Timers
def test_Timers_total():
    "Unit test for method total of class Timers"

    timers = Timers()
    timers.add("1", 1)
    timers.add("2", 2)
    timers.add("1", 1)
    timers.add("2", 2)
    assert timers.total("1") == 2
    assert timers.total("2") == 4

# Generated at 2022-06-23 16:07:49.932604
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit tests for method: Timers.__setitem__."""
    timers = Timers()
    try:
        timers["setitem"] = 1.0
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-23 16:07:54.850133
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test the Timers class' method clear"""
    timers = Timers()
    timers.add("my_value1", 0.1)
    timers.add("my_value2", 0.1)
    assert timers.data == {"my_value1": 0.1, "my_value2": 0.1}
    assert timers._timings == {"my_value1": [0.1], "my_value2": [0.1]}
    timers.clear()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:07:59.518211
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    try:
        Timers().__setitem__("Test", 42)
    except TypeError as exception:
        assert str(exception) == \
               "Timers does not support item assignment. Use '.add()' to update values."
    else:
        assert False, "Test should have failed"


# Generated at 2022-06-23 16:08:05.289985
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add("timer1", 0.1)
    assert (timers["timer1"] == 0.1)
    assert (len(timers._timings) == 1)

    timers.clear()
    assert (len(timers._timings) == 0)
    assert ("timer1" not in timers)


# Generated at 2022-06-23 16:08:09.796378
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    tmrs = Timers()
    tmrs._timings["a"] = [3, 4, 5]
    assert tmrs.apply(sum, name="a") == 12



# Generated at 2022-06-23 16:08:14.337036
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count("foo") == 0
    timers.add("foo", 2)
    assert timers.count("foo") == 1
    timers.add("foo", 3)
    assert timers.count("foo") == 2


# Generated at 2022-06-23 16:08:19.641916
# Unit test for method total of class Timers
def test_Timers_total():
    # Test if timer 'T' has value 0 if no data
    timers = Timers()
    assert timers['T'] == 0.0
    # Add a value to timer 'T'
    timers.add('T', 4.0)
    # Test if timer 'T' has value again
    assert timers['T'] == 4.0

# Generated at 2022-06-23 16:08:24.337535
# Unit test for method clear of class Timers
def test_Timers_clear():
    t = Timers()
    t.add("test", 10)
    t.clear()
    if t._timings["test"]!=[]:
        raise Exception("Error")
    if t.data["test"]!=0:
        raise Exception("Error")


# Generated at 2022-06-23 16:08:28.064756
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    timers = Timers()
    timers.add("First", 10)
    timers.add("Second", 20)    
    assert timers.mean("First") == 10
    assert timers.mean("Second") == 20


# Generated at 2022-06-23 16:08:30.184400
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("my_timing", 1.0)
    timers.add("my_timing", 5.0)
    timers.add("my_timing", 3.0)
    assert timers.mean("my_timing") == 3.0

# Generated at 2022-06-23 16:08:36.356179
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test Timers.stdev()"""
    values = [.1, .2, .3, .4, .5]
    assert Timers().stdev("name") == math.nan
    assert Timers({"name": sum(values)}).stdev("name") == .0
    assert Timers({"name": sum(values[:-1])}).stdev("name") == math.nan
    assert Timers({"name": sum(values)}, _timings={"name": values}).stdev(
        "name") == statistics.stdev(values)

# Generated at 2022-06-23 16:08:40.366113
# Unit test for method apply of class Timers
def test_Timers_apply():
    # type: () -> None
    """Test apply method."""
    def func(values):
        # type: (List[float]) -> float
        return values[0]

    timers = Timers()  # type: UserDict
    name = "test"
    value = 2.2
    timers.add(name, value)
    assert timers.apply(func, name=name) == value



# Generated at 2022-06-23 16:08:45.448892
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test 'apply' functionality of the timer class"""
    timer = Timers()
    timer.add("test", 1.1)
    timer.add("test", 2.2)
    assert timer.apply(len, "test") == 2
    assert abs(timer.apply(sum, "test") - 3.3) < 1e-6

# Generated at 2022-06-23 16:08:49.130454
# Unit test for constructor of class Timers
def test_Timers():
    """Test class Timers constructor"""
    # Initialize timer
    timer = Timers()
    # Create dict
    expected_dict = dict()
    # Test constructor
    assert timer.data == expected_dict


# Generated at 2022-06-23 16:08:53.911766
# Unit test for method mean of class Timers
def test_Timers_mean():
    class FakeTimers(Timers):
        def __init__(self):
            super().__init__()
            self._timings['name'] = [1, 2]

    t = FakeTimers()

    assert t.mean('name') == 1.5
    assert t.mean('name') == t.data['name'] / t.count('name')

# Generated at 2022-06-23 16:08:58.459367
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('t1', 1)
    timers.add('t2', 2)
    assert(timers.max('t1') == 1)
    assert(timers.max('t2') == 2)
    assert(timers.max('t3') == 0)
    return 1
    

# Generated at 2022-06-23 16:09:09.731217
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for the min method of the Timers class"""

    # Create empty Timers
    timers = Timers()

    # Verify empty dictionary
    assert len(timers) == 0
    assert len(timers._timings) == 0

    # Add one value
    timers.add("Eagle", 3)
    assert len(timers) == 1
    assert len(timers._timings) == 1

    # Verify the min() method returns the single value
    assert timers.min("Eagle") == 3

    # Add another value
    timers.add("Eagle", 5)

    # Verify the min() method now returns the minimum of the two values
    assert timers.min("Eagle") == 3

    # Add a value for a different key
    timers.add("Hawk", 11)

    # Verify the min() method returns the correct value

# Generated at 2022-06-23 16:09:16.900221
# Unit test for method median of class Timers
def test_Timers_median():
    """Test for method median of class Timers"""
    timers = Timers()
    assert math.isnan(timers.median("testtimer"))
    timers.add("testtimer", 0.0)
    assert timers.median("testtimer") == 0
    timers.add("testtimer", 1.0)
    timers.add("testtimer", 5.0)
    assert timers.median("testtimer") == 1
    timers.add("testtimer", 7.0)
    assert timers.median("testtimer") == 2.5

# Generated at 2022-06-23 16:09:24.526841
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers.add('t1', 1)
    timers.add('t1', 2)
    timers.add('t1', 3)
    with pytest.raises(KeyError):
        timers.apply(sum, name='t2')

    assert timers.apply(len, name='t1') == 3
    assert timers.apply(sum, name='t1') == 6

# Generated at 2022-06-23 16:09:26.644021
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:09:33.752509
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    timers = Timers()
    timers.add('timer1', 1.0)
    timers.add('timer1', 2.0)
    timers.add('timer2', 2.0)
    assert timers.count('timer1') == 2
    assert timers.count('timer2') == 1
    assert timers.total('timer1') == 3.0
    assert timers.total('timer2') == 2.0
    assert isinstance(timers, collections.UserDict)


# Generated at 2022-06-23 16:09:41.424578
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("Timer 1", 1.5)
    timers.add("Timer 1", 2.5)
    timers.add("Timer 1", 1.1)
    assert timers.count("Timer 1") == 3
    assert timers.count("Timer 2") == 0
    assert timers["Timer 1"] == 5.1
    assert timers["Timer 2"] == 0


# Generated at 2022-06-23 16:09:46.188070
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean value of timings"""
    timer = Timers()
    timer.add("test1", 1)
    timer.add("test2", 2)
    timer.add("test3", 3)
    assert timer.mean("test1") == 1
    assert timer.mean("test2") == 2
    assert timer.mean("test3") == 3

# Generated at 2022-06-23 16:09:52.225180
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    from numpy import stddev
    from numpy.random import normal

    timings = Timers()
    sigma = 10.0
    mu = 0.0

    for _ in range(int(1e6)):
        timings.add('test', normal(mu, sigma))

    # Check that the standard deviation calculated by statistics.stdev
    # matches the standard deviation calculated by numpy.stddev
    assert stddev(timings.values()) == timings.stdev('test')

# Generated at 2022-06-23 16:10:02.697581
# Unit test for method add of class Timers
def test_Timers_add():
    # Test single dimension timer
    timers = Timers()
    timers.add("T1", 1)
    assert timers.data["T1"] == 1

    timers.add("T1", 1)
    assert timers.data["T1"] == 2
    assert timers._timings["T1"] == [1, 1]
    assert timers.count("T1") == 2
    assert timers.total("T1") == 2
    assert timers.min("T1") == 1
    assert timers.max("T1") == 1
    assert timers.mean("T1") == 1
    assert timers.median("T1") == 1
    assert timers.stdev("T1") == 0

    assert timers.apply(lambda a: set(a), name="T1") == {1}

# Generated at 2022-06-23 16:10:07.617031
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.add('a',0)
    t.add('a',1)
    t.add('b',2)
    t.add('b',3)
    assert t.max('a') == 1
    assert t.max('b') == 3

# Generated at 2022-06-23 16:10:14.177495
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    t = Timers()
    t.add("t1", 1)
    t.add("t1", 1)
    t.add("t1", 2)
    t.add("t1", 3)
    assert t.mean("t1") == 2
    assert t.mean("t2") == 0
    t.add("t2", 1)
    t.add("t2", 1)
    t.add("t2", 2)
    t.add("t2", 3)
    assert t.mean("t2") == 2


# Generated at 2022-06-23 16:10:19.243280
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    t = Timers()
    with pytest.raises(TypeError) as excinfo:
        t['foo'] = 0
    assert (
        str(excinfo.value)
        == f"{t.__class__.__name__!r} does not support item assignment. "
        "Use '.add()' to update values."
    )


# Generated at 2022-06-23 16:10:23.825328
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    assert math.isnan(timers.median("dummy"))
    timers.add("dummy", 1.0)
    timers.add("dummy", 2.0)
    timers.add("dummy", 3.0)
    assert timers.median("dummy") == 2.0

# Generated at 2022-06-23 16:10:28.120403
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("timer1", 1)
    t.add("timer1", 0)
    assert t.min("timer1") == 0
    assert t.min("timer2") == 0


# Generated at 2022-06-23 16:10:31.413803
# Unit test for method min of class Timers
def test_Timers_min(): 
    timers = Timers()
    name = 'Name'
    value = 2
    assert timers.min(name) == 0
    timers.add(name, value)
    assert timers.min(name) == value


# Generated at 2022-06-23 16:10:40.272212
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():  # pragma: no cover
    # Initialization as a regular dictionary
    simple_dict = dict()
    simple_dict['a'] = 1
    simple_dict['b'] = 2
    simple_dict['c'] = 3

    # Initialization as a custom dictionary
    custom_dict = Timers()
    try:
        custom_dict['a'] = 1
    except TypeError as error:
        expected_error = \
        """Timers does not support item assignment. Use '.add()' to update values."""
        assert str(error) == expected_error

# Generated at 2022-06-23 16:10:45.046173
# Unit test for method median of class Timers
def test_Timers_median():
    # Create timer and add timing values
    timers = Timers()
    timer_name = "My Timer"
    timer_values = [1, 2, 3, 4]
    # Check if median is correct
    assert timers.median(timer_name) == 2.5


# Generated at 2022-06-23 16:10:50.957283
# Unit test for method max of class Timers
def test_Timers_max():
    """
    Test that the max function of the Timers class returns the correct values.
    """
    timer = Timers()
    timer._timings = {"value1": [1, 2, 3, 4, 5], "value2": []}
    assert timer.max("value1") == 5
    assert math.isnan(timer.max("value2"))


# Generated at 2022-06-23 16:10:57.285488
# Unit test for method count of class Timers
def test_Timers_count():
    """Unit tests for method count of class Timers"""
    timers = Timers()
    timers.add('call', 1.5)
    assert timers.count('call') == 1
    timers.add('call', 1.5)
    assert timers.count('call') == 2
    try:
        timers.count('missing')
    except KeyError as exception:
        assert str(exception) == "'missing'"
    else:
        raise AssertionError('KeyError not raised')


# Generated at 2022-06-23 16:11:07.253451
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    timers = Timers()
    assert isinstance(timers, collections.UserDict)
    # Test with no arguments
    timers.add()
    assert len(timers.data) == 0
    assert len(timers._timings) == 0
    # Test with having a single timing
    timers.add('timing', 123.456)
    assert timers.data['timing'] == 123.456
    assert timers._timings['timing'] == [123.456]
    # Test with a list of timing
    timers.add('timing', [123.456, 789.012])
    assert timers.data['timing'] == 912.468
    assert timers._timings['timing'] == [123.456, 789.012]


# Generated at 2022-06-23 16:11:11.011436
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("dummy", 43)
    timers.add("dummy", 23)
    assert timers.median("dummy") == 33
    assert timers["dummy"] == 66

# Generated at 2022-06-23 16:11:13.749976
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers['a'] = 1
    timers['b'] = 2
    timers['c'] = 3
    assert timers.mean() == 2


# Generated at 2022-06-23 16:11:17.887797
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    timers = Timers()
    assert len(timers) == 0
    assert list(timers.data.keys()) == []
    assert list(timers._timings.keys()) == []


# Generated at 2022-06-23 16:11:24.853276
# Unit test for method total of class Timers
def test_Timers_total():
    """Test for the 'total' method of the Timers class"""
    timers = Timers()
    assert timers.total("key1") == 0
    timers.add("key1", 1)
    assert timers.total("key1") == 1
    timers.add("key1", 2)
    assert timers.total("key1") == 3
    # Test with a non-existing key
    assert timers.total("key2") == 0


# Generated at 2022-06-23 16:11:27.328153
# Unit test for method add of class Timers
def test_Timers_add():

  # None
  timers = Timers()
  timers.add("a", 1)
  timers.add("b", 2)

 # Unit test for method clear of class Timers

# Generated at 2022-06-23 16:11:34.957870
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean method of Timers class"""
    timers = Timers()
    assert timers.mean('none') == 0
    timers.add('foo', 100)
    assert timers.mean('foo') == 100
    timers.add('foo', 200)
    assert timers.mean('foo') == 150
    timers.add('foo', 100)
    assert timers.mean('foo') == 133.33333333333334
    timers.add('bar', 300)
    assert timers.mean('bar') == 300
    assert timers.mean('none') == 0

# Generated at 2022-06-23 16:11:38.296945
# Unit test for constructor of class Timers
def test_Timers():
    """Test constructor of class Timers"""
    timers = Timers()
    assert isinstance(timers, collections.UserDict)
    assert isinstance(timers, Timers)


# Generated at 2022-06-23 16:11:44.483608
# Unit test for method total of class Timers
def test_Timers_total():
    timer = Timers()
    assert timer.total('no key') == 0

    timer.add('key', 3.0)
    timer.add('key', 5.0)
    assert timer.total('key') == 8.0
    assert timer.total('no key') == 0

    timer.data.clear()
    timer._timings.clear()
    assert timer.total('no key') == 0


# Generated at 2022-06-23 16:11:49.051130
# Unit test for method max of class Timers
def test_Timers_max():
    """Test max method of Timers class

    Checks that the timer `max` method works as expected.
    """

    # create timers object
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)

    assert timers.max('test') == 2

# Generated at 2022-06-23 16:11:53.078731
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    assert isinstance(timers, UserDict)
    try:
        timers['test'] = 1.0
    except TypeError as e:
        assert 'does not support item assignment' in str(e)
    else:
        assert False