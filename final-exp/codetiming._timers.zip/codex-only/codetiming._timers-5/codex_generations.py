

# Generated at 2022-06-23 16:01:46.400073
# Unit test for method count of class Timers
def test_Timers_count():
    # Create instance of class Timers
    T = Timers()
    # Call method count with argument name
    T.count(name="")


# Generated at 2022-06-23 16:01:48.956733
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add('foo', 5.0)
    timers.add('foo', 8.0)

    assert timers.stdev('foo') == 2.23606797749979



# Generated at 2022-06-23 16:01:50.719343
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers({"a":[1,2,3]})
    assert timers.mean("a") == 2

# Generated at 2022-06-23 16:01:54.757286
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert isinstance(timers._timings, dict)
    assert isinstance(timers.data, dict)
    assert not timers._timings
    assert not timers.data


# Generated at 2022-06-23 16:01:57.697533
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('twenty', 20)
    timers.add('twenty', 20)
    timers.add('ten', 10)
    assert timers.min('ten') == 10
    assert timers.min('twenty') == 20


# Generated at 2022-06-23 16:02:03.427531
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test implementation of the standard deviation of Timers"""
    timers = Timers()
    timers.add("test", 1)
    assert timers.stdev("test") == 0
    timers.add("test", 2)
    assert abs(timers.stdev("test") - 0.5) < 1e-12

# Generated at 2022-06-23 16:02:07.942571
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test setting item assignment in Timers"""
    tests = [
        {"name": "dummy", "value": 42},
    ]

    for test in tests:
        with pytest.raises(TypeError):
            Timers.__setitem__(None, **test)



# Generated at 2022-06-23 16:02:14.755026
# Unit test for method total of class Timers
def test_Timers_total():
    """Test if adding timing values works as expected"""
    timers = Timers()
    assert timers.total("empty") == 0
    timers.add("one", 1.0)
    assert timers.total("one") == 1.0
    timers.add("one", 0.5)
    assert timers.total("one") == 1.5
    timers.add("two", 0.5)
    assert timers.total("one") == 1.5
    assert timers.total("two") == 0.5

    # Assert that timings are not accessible as dictionary values
    assert timers["one"] == 0.0


# Generated at 2022-06-23 16:02:18.402182
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    # Prepare
    from pyvolution.types.testing import assert_raises
    timers = Timers()
    # Run & verify
    assert_raises(TypeError, timers.__setitem__, 'key', 42)

# Generated at 2022-06-23 16:02:22.817290
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add('timer 1', 2)
    timers.add('timer 1', 3)
    timers.add('timer 2', 4)
    timers.add('timer 2', 5)
    assert timers['timer 1'] == 5
    assert timers['timer 2'] == 9


# Generated at 2022-06-23 16:02:25.273947
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()
    t.add("test", 0.2)
    assert t.total("test") == 0.2

# Generated at 2022-06-23 16:02:31.188397
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers["key"] = 1.0
    except TypeError:  # expected
        pass
    else:
        raise AssertionError


# Generated at 2022-06-23 16:02:38.571540
# Unit test for method min of class Timers
def test_Timers_min():
    """Test the min method of class Timers"""
    tm = Timers()
    assert tm.min("foo") == 0.0
    tm.add("foo", 5)
    assert tm.min("foo") == 5.0
    tm.add("foo", 7)
    assert tm.min("foo") == 5.0
    tm.clear()
    assert tm.min("foo") == 0.0


# Generated at 2022-06-23 16:02:43.143396
# Unit test for method max of class Timers
def test_Timers_max():
    """Unit test for max method of Timers class"""
    timers = Timers()
    assert timers.max('a') == 0
    timers.add('a', 10)
    timers.add('b', 11)
    timers.add('c', 1)
    assert timers.max('a') == 10
    assert timers.max('b') == 11
    assert timers.max('c') == 1

# Generated at 2022-06-23 16:02:47.343072
# Unit test for method clear of class Timers
def test_Timers_clear():
    # set up
    timers = Timers()
    timers.add('abc', 0.1234)
    # test
    timers.clear()
    # assert
    assert not timers


# Generated at 2022-06-23 16:02:50.096753
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers['foo'] = 1
    except TypeError:
        pass
    else:
        raise Exception()


# Generated at 2022-06-23 16:02:58.087430
# Unit test for method min of class Timers
def test_Timers_min():  # pragma: no cover
    my_timers = Timers({
        'empty': 0,
        'only_one': 0.5,
        'two_values': 0.2,
    })
    my_timers.add(name='two_values', value=0.1)
    assert my_timers.min(name='only_one') == 0.5
    assert my_timers.min(name='two_values') == 0.1
    assert my_timers.min(name='empty') == 0

# Generated at 2022-06-23 16:03:02.887242
# Unit test for method clear of class Timers
def test_Timers_clear():
    timer = Timers()
    timer["timer1"] = 0.123
    timer._timings["timer2"] = [0.456]

    timer.clear()

    assert "timer1" not in timer
    assert timer._timings == collections.defaultdict(list)


# Generated at 2022-06-23 16:03:11.297265
# Unit test for method total of class Timers
def test_Timers_total():
    timer = Timers()
    assert timer.total("unexisting_key") == 0
    assert timer.total("unexisting_key") == 0
    timer.add("unexisting_key", 3)
    assert timer.total("unexisting_key") == 3
    timer.add("unexisting_key", 4)
    assert timer.total("unexisting_key") == 7
    timer.add("other_key", 3)
    assert timer.total("unexisting_key") == 7
    assert timer.total("other_key") == 3
    timer.add("other_key", 4)
    assert timer.total("other_key") == 7


# Generated at 2022-06-23 16:03:14.618877
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    try:
        timers['test'] = 1.
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-23 16:03:21.223406
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()

    # check that the total is equal to 0 when no timers have been added
    assert timers.total('name') == 0

    # add a timer
    timers.add('name', 1)
    assert timers.total('name') == 1

    # add another timer and check that the total is 2
    timers.add('name', 3)
    assert timers.total('name') == 4

    # remove the key (name) and check that the total is equal to 0
    timers.__delitem__('name')
    assert timers.total('name') == 0


# Generated at 2022-06-23 16:03:23.556656
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Timers.clear"""
    timer = Timers()
    timer.add('test', 1)
    assert ('test', 1) in timer.items()
    assert 'test' in timer._timings
    timer.clear()
    assert 'test' not in timer
    assert 'test' not in timer._timings

# Generated at 2022-06-23 16:03:29.173120
# Unit test for method add of class Timers
def test_Timers_add():
    t = Timers()
    assert t is not None
    t.add("a", 3.2)
    assert t.data["a"] == 3.2
    assert t._timings["a"] == [3.2]
    t.add("a", 0.9)
    assert t.data["a"] == 4.1
    assert t._timings["a"] == [3.2, 0.9]

# Generated at 2022-06-23 16:03:31.955149
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    assert timers.clear() is None
    assert timers._timings == {}
    assert timers.data == {}

# Generated at 2022-06-23 16:03:34.678115
# Unit test for method add of class Timers
def test_Timers_add():
    name = "testtimer"
    value = 0.123
    t = Timers()
    t.add(name, value)
    assert t.data[name] == value
    assert t._timings[name] == [value]


# Generated at 2022-06-23 16:03:38.026091
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test the method 'stdev' of class Timers"""
    timers = Timers()
    timers.add("test", 2.0)
    timers.add("test", 2.0)
    assert timers.stdev("test") is not math.nan
    timers = Timers()
    assert timers.stdev("test") is math.nan


# Generated at 2022-06-23 16:03:44.762237
# Unit test for method max of class Timers
def test_Timers_max():
    # Create an instance of Timers
    timers = Timers()
    # Add some values to the timers
    timers.add('timer1', 10)
    timers.add('timer2', 20)
    timers.add('timer2', 30)

    # Check that we can get maximum values
    assert timers.max('timer1') == 10
    assert timers.max('timer2') == 30


# Generated at 2022-06-23 16:03:47.154228
# Unit test for method add of class Timers
def test_Timers_add():
    timer = Timers()
    timer.add("I/O", 0.1)
    timer.add("I/O", 0.3)
    assert timer["I/O"] == 0.4
    print("method add of class Timers passes")


# Generated at 2022-06-23 16:03:48.795096
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('foo', 1)
    timers.add('foo', 2)
    assert timers.median('foo') == 1.5


# Generated at 2022-06-23 16:03:52.202674
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add('test', 1.5)
    timers.clear()
    assert timers._timings == collections.defaultdict(list)
    assert timers.data == {}



# Generated at 2022-06-23 16:03:58.406793
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('timer', 1)
    timers.add('timer', 2)
    timers.add('timer', 3)
    assert timers.median('timer') == 2
    timers.add('timer', 4)
    timers.add('timer', 5)

    assert timers.median('timer') == 3

# Generated at 2022-06-23 16:04:01.126113
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    timers.add("test", 1)
    try:
        timers["test"] = 1
    except TypeError:
        pass
    else:
        assert False, "Should raise TypeError"

# Generated at 2022-06-23 16:04:09.480690
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers({"A": 0, "B": 0, "C": 0})
    timers.add("A", 0.1)
    timers.add("A", 0.2)
    timers.add("A", 0.5)
    timers.add("B", 0.1)
    timers.add("B", 0.4)
    timers.add("B", 0.5)
    timers.add("C", 0.1)
    assert timers["A"] == 0.8
    assert timers["B"] == 1.0
    assert timers["C"] == 0.1
    assert timers.max("A") == 0.5
    assert timers.max("B") == 0.5
    assert timers.max("C") == 0.1

# Generated at 2022-06-23 16:04:10.722138
# Unit test for method clear of class Timers
def test_Timers_clear():
    timer = Timers()
    timer.add('test', 4.1)
    timer.add('test2', 1.2)
    timer.clear()
    assert len(timer.data) == 0
    assert len(timer._timings) == 0

# Generated at 2022-06-23 16:04:13.982573
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test Timers, ensure method __setitem__ raises exception"""
    timers = Timers()
    with pytest.raises(TypeError) as excinfo:
        timers["name"] = 5.0
    assert "does not support item assignment" in str(excinfo.value)

# Generated at 2022-06-23 16:04:20.945428
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test mean of Timers.

    Returns
    -------
    average_times : float
        average time
    """
    timers = Timers()
    timers.add("Total", 8.177867)
    timers.add("Total", 6.161473)
    timers.add("Total", 7.831073)

    average_times = timers.mean(name="Total")
    return average_times



# Generated at 2022-06-23 16:04:25.609364
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    assert math.isnan(timers.stdev('foo'))
    timers.add('foo', .2)
    assert math.isnan(timers.stdev('foo'))
    timers.add('foo', .3)
    assert math.isclose(timers.stdev('foo'), .1)

# Generated at 2022-06-23 16:04:36.233022
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    # Create an instance of class Timers
    timers = Timers()

    # Add timer values
    timers.add('a', 1.0)
    timers.add('a', 2.0)
    timers.add('a', 3.0)
    timers.add('b', 1.0)
    timers.add('b', 1.0)
    timers.add('b', 1.0)

    # Check number of times called
    assert timers.count('a') == 3
    assert timers.count('b') == 3

    # Check standard deviation of timer values
    assert round(timers.stdev('a'), 2) == 1.0
    assert round(timers.stdev('b'), 2) == 0.0

    # Clear timers
    timers.clear()

    # Add timer values

# Generated at 2022-06-23 16:04:38.539096
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    timers.add("timer1", 100)
    timers["timer2"] = 200
    expected = Timers({"timer1": 100, "timer2": 200})
    assert timers == expected

# Generated at 2022-06-23 16:04:41.861022
# Unit test for method total of class Timers
def test_Timers_total():
    a = Timers()
    a.add('a', 10)
    a.add('a', 20)
    a.add('b', 30)
    assert a.total('a') == 30
    assert a.total('b') == 30
    return a


# Generated at 2022-06-23 16:04:45.869782
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test method clear of class Timers"""
    timers = Timers()
    timers.add('A', 3)
    timers.add('T', 5)
    timers.add('T', 7)
    timers.clear()
    assert timers.data == {}
    assert timers.total('A') == 0
    assert timers.total('T') == 0

# Generated at 2022-06-23 16:04:48.883629
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    assert Timers()


# Generated at 2022-06-23 16:04:57.856294
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""

    # Setup a Timers instance
    timers = Timers()

    # Add a first value
    timers.add("value1", 1)
    assert timers.data["value1"] == 1

    # Add the same value two times
    timers.add("value1", 1)
    timers.add("value1", 1)
    assert timers.data["value1"] == 3

    # Add a second value
    timers.add("value2", 2)
    assert timers.data["value2"] == 2

    # Add the same value as for value2 three times
    timers.add("value2", 2)
    timers.add("value2", 2)
    timers.add("value2", 2)
    assert timers.data["value2"] == 8


# Generated at 2022-06-23 16:05:05.243074
# Unit test for method min of class Timers
def test_Timers_min():
    """Test min method of Timers class"""
    timers = Timers()
    assert timers.min('example') == 0.0

    timers._timings['example'] = [1.0]
    assert timers.min('example') == 1.0

    timers._timings['example'] = [2.0, 1.0]
    assert timers.min('example') == 1.0

    timers._timings['example'] = []
    assert timers.min('example') == 0.0


# Generated at 2022-06-23 16:05:10.928615
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add("check", 0.1)
    timers.add("check", 0.2)
    timers.add("check", 0.3)
    assert timers["check"] == 0.6
    assert len(timers._timings) == 1
    timers.clear()
    assert len(timers._timings) == 0

# Generated at 2022-06-23 16:05:22.297126
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method median of class Timers
    See also:
        https://docs.python.org/3/library/statistics.html#statistics.median
    """

    import statistics
    med = statistics.median
    t = Timers()
    t.add(name='t1', value=1)
    t.add(name='t2', value=2)
    t.add(name='t3', value=3)
    assert t.median('t1') == 1
    assert t.median('t2') == 2
    assert t.median('t3') == 3

    assert t.median('t1') == med([1])
    assert t.median('t2') == med([2])
    assert t.median('t3') == med([3])

    t.add

# Generated at 2022-06-23 16:05:26.295193
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    t.add('foo', 1)
    assert t.median('foo') == 1
    t.add('foo', 2)
    assert t.median('foo') == 1.5
    t.add('foo', 2)
    assert t.median('foo') == 2
    t.add('foo', 3)
    assert t.median('foo') == 2

# Generated at 2022-06-23 16:05:28.981171
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test clear method of class Timers."""

    t = Timers()
    t["a"] = 1
    t.add("b", 2)
    t.clear()

    assert t.data == {}
    assert t._timings == {}


# Generated at 2022-06-23 16:05:35.032730
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    assert timers.total("Number") == 0.0
    timers.add("Number", 123)
    assert timers.total("Number") == 123
    timers.add("Number", 456)
    assert timers.total("Number") == 579

# Generated at 2022-06-23 16:05:43.879439
# Unit test for method apply of class Timers
def test_Timers_apply():
    # Test with invalid key
    timers = Timers()
    try:
        timers.apply(len, "")
    except KeyError:
        pass
    else:
        raise AssertionError("expected exception")

    # Test with valid key
    timers._timings[""] = [0.5, 1.0]
    assert timers.apply(len, "") == 2
    assert timers.apply(sum, "") == 1.5
    assert timers.apply(lambda values: min(values), "") == 0.5
    assert timers.apply(lambda values: max(values), "") == 1.0
    assert timers.apply(lambda values: statistics.mean(values), "") == 0.75
    assert timers.apply(lambda values: statistics.median(values), "") == 0.75

# Generated at 2022-06-23 16:05:48.385166
# Unit test for method count of class Timers
def test_Timers_count():
    """Unit test for method count of class Timers"""
    timers = Timers()
    timers.add('a', 1)
    timers.add('a', 0)
    assert timers.count('a') == 2


# Generated at 2022-06-23 16:05:51.454356
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    timers = Timers()
    timers.add("key", 1)
    timers.add("key", 2)
    assert timers.data["key"] == 3
    assert timers._timings["key"] == [1, 2]


# Generated at 2022-06-23 16:05:58.678157
# Unit test for method add of class Timers
def test_Timers_add():
    a = Timers()
    assert len(a) == 0
    assert a.total('c') == 0
    assert a.count('c') == 0
    assert a.mean('c') == 0
    assert a.median('c') == 0
    assert a.min('c') == 0
    assert a.max('c') == 0
    assert a.stdev('c') == math.nan
    # Add one value
    a.add('c', 1)
    assert a.count('c') == 1
    assert a.total('c') == 1
    assert a.mean('c') == 1
    assert a.median('c') == 1
    assert a.min('c') == 1
    assert a.max('c') == 1
    assert a.stdev('c') == 0
    # Add two values
   

# Generated at 2022-06-23 16:06:04.053403
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    t = Timers()
    t.add('timerA', 2.4)
    assert t['timerA'] == 2.4
    try:
        t['timerA'] = 2.8
        assert 1 == 2
    except TypeError:
        pass
    except:
        assert 1 == 2
    assert t['timerA'] == 2.4

# Generated at 2022-06-23 16:06:10.779303
# Unit test for method median of class Timers
def test_Timers_median():
    """ Test if the method median of Timers is correct """
    # Exercise
    t = Timers()
    # Test with empty list
    t.median("Timer")
    # Test with non-empty list
    t._timings = {"Timer": [1, 2, 3], "Timer2": [2, 4, 6]}
    t.median("Timer")
    t.median("Timer2")

# Generated at 2022-06-23 16:06:13.868188
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    for i in range(3):
        t.add('t', i)
    assert t.max('t') == 2, 'test_Timers_max() failed.'


# Generated at 2022-06-23 16:06:20.267587
# Unit test for method median of class Timers
def test_Timers_median():
    from .decorators import Timer
    t = Timers()
    with Timer(t):
        pass
    assert t.median("timers.decorators.Timer") == 0

    with Timer(t):
        pass
    assert t.median("timers.decorators.Timer") == 0

    with Timer(t):
        pass
    assert t.median("timers.decorators.Timer") == 0


# Generated at 2022-06-23 16:06:25.675754
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers is not None
    assert timers._timings is not None
    assert timers.data is not None
    assert (
        "Counter({'foo': 12, 'bar': 8})" == str(timers.data)
        == "Counter({'foo': [12.0], 'bar': [8.0]})" == str(timers._timings)
    )

# Generated at 2022-06-23 16:06:35.802888
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test method Timers.clear()"""

    timers = Timers()
    timers.add("T1", 1.0)
    timers.add("T2", 1.1)
    timers.add("T1", 1.2)
    timers.add("T3", 1.3)
    timers.add("T3", 1.4)
    assert timers._timings["T1"] == [1.0, 1.2]
    assert timers._timings["T2"] == [1.1]
    assert timers._timings["T3"] == [1.3, 1.4]
    assert timers.data["T1"] == 2.2
    assert timers.data["T2"] == 1.1
    assert timers.data["T3"] == 2.7

    timers.clear()

# Generated at 2022-06-23 16:06:45.203908
# Unit test for method max of class Timers
def test_Timers_max():
    """Unit test for method max of class Timers"""
    x = Timers()
    assert x.max("foo") == 0.0
    x.data["foo"] = 10.0
    assert x.max("foo") == 10.0
    x._timings["foo"] = [10.0, 1.0]
    assert x.max("foo") == 10.0
    x._timings["foo"] = [1.0, 10.0]
    assert x.max("foo") == 10.0
    x._timings["foo"] = [10.0, 10.0]
    assert x.max("foo") == 10.0
    x._timings["foo"] = [1.0, 2.0]
    assert x.max("foo") == 2.0
    x._timings["foo"] = []

# Generated at 2022-06-23 16:06:45.917926
# Unit test for method count of class Timers
def test_Timers_count():
    pass


# Generated at 2022-06-23 16:06:48.737677
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    name = "test_timers"
    values = [1, 2, 3, 4, 5]
    for value in values:
        timers.add(name, value)
    results = timers.count(name)
    assert results == 5


# Generated at 2022-06-23 16:06:54.440863
# Unit test for method max of class Timers
def test_Timers_max():
    """Test Timers max"""
    timers = Timers()
    timers.add('foo', 10)
    timers.add('foo', 20)
    result = timers.max(name='foo')
    print(result)


# Generated at 2022-06-23 16:06:56.840580
# Unit test for method count of class Timers
def test_Timers_count():
    """Test if the number of timings is calculated correctly"""
    timers = Timers()
    timers["name1"] = 3.2
    timers["name2"] = 6.7
    assert timers.count("name1") == 1
    assert timers.count("name2") == 1
    timers.add("name1", 10.5)
    assert timers.count("name1") == 2


# Generated at 2022-06-23 16:07:02.263452
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("T1", 0)
    timers.add("T1", 1)
    assert timers.max("T1") == 1

    timers.add("T2", -2.5)
    timers.add("T2", -5)
    assert timers.max("T2") == -2.5

    timers.add("T3", -5)
    timers.add("T3", -5)
    assert timers.max("T3") == -5


# Generated at 2022-06-23 16:07:11.704182
# Unit test for method median of class Timers
def test_Timers_median():
    """Check that the median is calculated correctly"""
    timer = Timers()
    timer.add("timing1", 1.25)
    timer.add("timing2", 1.5)
    timer.add("timing3", 0.75)
    timer.add("timing4", 1.0)
    assert timer.data == {"timing1": 1.25, "timing2": 1.5, "timing3": 0.75, "timing4": 1.0}
    assert timer.count("timing1") == 1
    assert timer.count("timing2") == 1
    assert timer.count("timing3") == 1
    assert timer.count("timing4") == 1
    assert timer.total("timing1") == 1.25
    assert timer.total("timing2") == 1.5


# Generated at 2022-06-23 16:07:14.595585
# Unit test for method add of class Timers
def test_Timers_add():
    """Test 'add' method of class Timers"""
    timer = Timers()
    timer.add('test', 2)


# Generated at 2022-06-23 16:07:18.315751
# Unit test for method count of class Timers
def test_Timers_count():
    # Arrange
    timers = Timers()
    # Act (nothing)
    # Assert
    assert timers.count('test') == 0

# Generated at 2022-06-23 16:07:21.374640
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('test', 1.0)
    assert timers.count('test') == 1.0
    timers.clear()
    assert timers.count('test') == 0.0


# Generated at 2022-06-23 16:07:26.845818
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test setitem method of Timers class"""
    # Initialize timers
    timers = Timers()

    # Assign a value to a new timer, this should trigger a TypeError
    try:
        timers["test"] = 0.1
    except TypeError:
        pass
    else:
        raise RuntimeError("Expected TypeError not raised")

    # Method 'add' should not raise an error
    timers.add("test", 0.1)

    return

# Generated at 2022-06-23 16:07:37.642230
# Unit test for method apply of class Timers
def test_Timers_apply():
    t = Timers()
    t.add("x", 1)
    assert t.apply(sum, "x") == 1
    assert t.apply(min, "x") == 1
    assert t.apply(max, "x") == 1
    assert t.apply(lambda v: statistics.mean(v), "x") == 1
    assert t.apply(lambda v: statistics.median(v), "x") == 1
    assert math.isnan(t.apply(lambda v: statistics.stdev(v), "x"))
    assert t.apply(len, "x") == 1
    with pytest.raises(KeyError):
        t.apply(sum, "y")
    with pytest.raises(KeyError):
        t.apply(min, "y")

# Generated at 2022-06-23 16:07:39.721828
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()
    for i in range(10):
        t.add("a", i)
    assert t.total("a") == 45



# Generated at 2022-06-23 16:07:45.035150
# Unit test for method count of class Timers
def test_Timers_count():
    import pytest
    from .utils import timer
    from .timer import Timer

    with Timers() as timers:
        assert timers.count("name") == 0
        with timer(timers, name="name"):
            pass
        assert timers.count("name") == 1

    with Timers() as timers:
        assert timers.count("name") == 0
        with Timer(timers, name="name"):
            pass
        assert timers.count("name") == 1

    with pytest.raises(KeyError) as exc_info:
        Timers().count("name")
    assert str(exc_info.value) == "'name'"


# Generated at 2022-06-23 16:07:47.324533
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers({'time': 2.0})
    assert timers.count('time') == 1


# Generated at 2022-06-23 16:07:57.230839
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test functionality of method apply of class Timers"""
    def test_apply(func: Callable[[List[float]], float], name: str, expected: float):
        """Test functionality of method apply"""
        timer = Timers()
        timer._timings["A"] = [5.5, 6.5]
        timer._timings["B"] = [1.1, 2.2]
        timer._timings["C"] = []
        assert timer.apply(func, name=name) == expected

    test_apply(len, "A", 2)
    test_apply(len, "B", 2)
    test_apply(len, "C", 0)

    test_apply(sum, "A", 12)
    test_apply(sum, "B", 3.3)
    test_apply(sum, "C", 0)

# Generated at 2022-06-23 16:08:00.089511
# Unit test for method count of class Timers
def test_Timers_count():
    """Unit test for method count of class Timers
    """
    timers = Timers()
    timers.add("first", 0.1)
    timers.add("first", 0.2)
    timers.add("first", 0.3)
    assert timers.count("first") == 3


# Generated at 2022-06-23 16:08:09.369238
# Unit test for method total of class Timers
def test_Timers_total():
    dict = Timers({"name1" : 1,"name2" : 2})
    dict.add("name1", 1)
    dict.add("name1", 1)
    dict.add("name2", 2)
    dict.add("name2", 2)
    dict.add("name2", 2)
    dict.add("name3", 3)
    dict.add("name3", 3)
    dict.add("name3", 3)
    dict.add("name3", 3)
    assert (dict.total("name1") == 3)
    assert (dict.total("name2") == 6)
    assert (dict.total("name3") == 12)


# Generated at 2022-06-23 16:08:13.422224
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of timer class"""
    timers = Timers()
    timers.add('timer', 1.0)
    assert timers.data['timer'] == 1.0
    timers.add('timer', 2.0)
    assert timers.data['timer'] == 3.0


# Generated at 2022-06-23 16:08:17.672599
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test for '__setitem__' of class 'Timers'"""

    timers = Timers()

    with pytest.raises(TypeError):
        timers["timer1"] = 1.0


# Generated at 2022-06-23 16:08:21.151614
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    ## Invalid update
    try:
        timers['test'] = 1.0
    except TypeError:
        pass
    else:
        assert False, 'failed to raise error'


# Generated at 2022-06-23 16:08:24.226940
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 1)
    assert timers.min('test') == 1
    timers.add('test', 2)
    assert timers.min('test') == 1


# Generated at 2022-06-23 16:08:27.072355
# Unit test for method count of class Timers
def test_Timers_count():
    """Test method count of class Timers"""
    timers = Timers()
    timers.add("key1", 1.0)
    timers.add("key1", 3.0)
    assert timers.count("key1") == 2


# Generated at 2022-06-23 16:08:36.722774
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()

    # Positional tests
    timers.add("A", 1.0)
    timers.add("A", 2.0)
    assert timers.median("A") == 1.5
    timers.add("A", 3.0)
    assert timers.median("A") == 2.0

    timers.add("B", 1.0)
    timers.add("B", 2.0)
    assert timers.median("B") == 1.5
    timers.add("B", 3.0)
    assert timers.median("B") == 2.0

    # Non-existing key test
    try:
        timers.median("C")
    except KeyError:
        pass
    else:
        assert False, "KeyError not raised for non-existiing key"


# Generated at 2022-06-23 16:08:39.065031
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("test_count", 0)
    assert timers.count("test_count") == 1

# Generated at 2022-06-23 16:08:44.670196
# Unit test for method apply of class Timers
def test_Timers_apply():

    # Setup
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers["test"] == 3

    # Test
    assert timers.apply(len, "test") == 2
    assert timers.apply(sum, "test") == 3

# Generated at 2022-06-23 16:08:49.130630
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("min test",0)
    t.add("min test",5)
    t.add("min test",10)
    t.add("min test",15)
    assert t.min("min test") == 0


# Generated at 2022-06-23 16:08:56.803012
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert isinstance(timers, collections.UserDict)
    assert isinstance(timers, Timers)
    assert isinstance(timers.data, dict)
    assert isinstance(timers._timings, dict)
    assert len(timers) == 0
    assert len(timers.data) == 0
    assert len(timers._timings) == 0


# Generated at 2022-06-23 16:09:02.283151
# Unit test for method median of class Timers
def test_Timers_median():
    Timer = Timers()
    assert Timer.median('median') == 0

    Timer.add('median', 1)
    assert Timer.median('median') == 1

    Timer.add('median', 5)
    assert Timer.median('median') == 1.5

    Timer.add('median', 2)
    assert Timer.median('median') == 2

# Generated at 2022-06-23 16:09:05.728455
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("something", 2.5)
    assert timers.max("something") == 2.5
    timers.add("something", 5)
    assert timers.max("something") == 5

# Generated at 2022-06-23 16:09:08.444308
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()
    t.data["test"] = 5
    t._timings["test"].append(5.0)
    assert t.total("test") == 10.0


# Generated at 2022-06-23 16:09:13.043984
# Unit test for method median of class Timers
def test_Timers_median():
    TheTimers = Timers()
    TheTimers.add('B', 1)
    TheTimers.add('B', 3)
    TheTimers.add('B', 5)
    TheTimers.add('B', 7)
    assert TheTimers.median('B') == 4.0

# Generated at 2022-06-23 16:09:14.435046
# Unit test for method count of class Timers
def test_Timers_count():
    Timers().count(name="not_contains")


# Generated at 2022-06-23 16:09:20.276904
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test the stdev method of class Timers"""
    # Empty case
    timers = Timers()
    timers._timings["a"] = []
    assert math.isnan(timers.stdev("a"))
    timers._timings["a"] = [1]
    assert math.isnan(timers.stdev("a"))
    # Valid cases
    timers._timings["a"] = [1, 2, 3]
    assert timers.stdev("a") == 1
    timers._timings["a"] = [1, 1, 2, 2, 3, 3]
    assert timers.stdev("a") == 0.816496580927726


# Generated at 2022-06-23 16:09:23.007417
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert isinstance(timers, UserDict)
    assert "test" not in timers


# Generated at 2022-06-23 16:09:30.068058
# Unit test for method clear of class Timers
def test_Timers_clear():
    # Test for the clear method of class Timers
    # Initialize a Timers object
    timer_data = Timers()
    # Add some values
    timer_data.add('my_timer', 1)
    assert timer_data['my_timer'] == 1
    assert timer_data.count('my_timer') == 1
    # Call method clear
    timer_data.clear()
    # Check result
    assert len(timer_data) == 0
    assert len(timer_data._timings) == 0

if __name__ == '__main__':
    test_Timers_clear()

# Generated at 2022-06-23 16:09:34.858605
# Unit test for method min of class Timers
def test_Timers_min():
    """Tests method min of class Timers"""
    timers = Timers()
    timers.add("foo", 1)
    assert timers.min("foo") == 1
    timers.add("foo", 2)
    assert timers.min("foo") == 1
    timers.add("foo", -4)
    assert timers.min("foo") == -4
    assert timers.min("bar") == 0

# Generated at 2022-06-23 16:09:37.760096
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor"""
    t = Timers()
    assert len(t) == 0


# Generated at 2022-06-23 16:09:42.318230
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    d: Dict[str, str] = {}
    d["test_max"] = Timers()
    d["test_max"].add("max", 1)
    assert d["test_max"].max("max") == 1


# Generated at 2022-06-23 16:09:45.208450
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add("foo", 1)
    timers.clear()
    assert isinstance(timers._timings, collections.defaultdict)


# Generated at 2022-06-23 16:09:52.226656
# Unit test for method min of class Timers
def test_Timers_min():
    # Create instance
    timers = Timers()

    # Test missing name
    try:
        timers.min(name='missing')
    except KeyError as error:
        assert error.args[0] == "missing"
    else:
        assert False, "Should raise KeyError"

    # Test with empty value
    timers.apply = lambda func, name=None: func([])
    assert timers.min(name='name') == 0

    # Test with value
    timers.apply = lambda func, name=None: func([42])
    assert timers.min(name='name') == 42

# Generated at 2022-06-23 16:10:00.915397
# Unit test for method mean of class Timers
def test_Timers_mean():
    key1 = "test1"
    key2 = "test2"
    timing = Timers()
    timing.add(key1, 1)
    assert timing.mean(key1) == 1
    # Average of 0 elements is 0
    assert timing.mean("test3") == 0
    timing.add(key2, 2)
    assert timing.mean(key2) == 2
    timing.add(key1, 5)
    assert timing.mean(key1) == 3
    timing.add(key2, 4)
    assert timing.mean(key2) == 3


# Generated at 2022-06-23 16:10:05.723639
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    timers = Timers()
    timers._timings["test"] = [1, 2, 3, 4]
    assert timers.stdev("test") == 1.118033988749895

# Generated at 2022-06-23 16:10:10.753616
# Unit test for method max of class Timers
def test_Timers_max():
    """
    Test the method max of class Timers
    """
    timers2 = Timers()
    timers2.add('test1', 0.5)
    timers2.add('test1', 0.5)
    timers2.add('test1', 0.5)
    assert timers2.min('test1') == 0.5


# Generated at 2022-06-23 16:10:12.244010
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert len(timers) == 0


# Unit tests for add method of class Timers

# Generated at 2022-06-23 16:10:13.969441
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add('test_timer', 1)
    assert len(timers) == 1
    assert timers['test_timer'] == 1

# Generated at 2022-06-23 16:10:22.728783
# Unit test for method add of class Timers
def test_Timers_add():
    # Make new timers
    timers = Timers()

    # Add some timers
    timers.add("test1", 1)
    timers.add("test2", 3)
    timers.add("test2", 5)
    timers.add("test1", 7)

    # Check values
    assert timers.data["test1"] == 8
    assert timers.data["test2"] == 8
    assert len(timers._timings) == 2
    assert len(timers._timings["test1"]) == 2
    assert len(timers._timings["test2"]) == 2


# Generated at 2022-06-23 16:10:26.126543
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median computation"""
    a = Timers()
    a.add("test", 1)
    a.add("test", 2)
    a.add("test", 3)
    assert a.median("test") == 2

# Generated at 2022-06-23 16:10:30.082664
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Ensure that setting timer values is not allowed"""
    timers = Timers()
    try:
        timers["time"] = 0.0
    except TypeError:
        pass
    else:
        raise AssertionError("Unexpected success")


# Generated at 2022-06-23 16:10:41.944540
# Unit test for method median of class Timers
def test_Timers_median():
  """Unit test for method median of class Timers"""
  # Test case
  timings = Timers()
  timings.add('test1', 1)
  timings.add('test1', 2)
  timings.add('test1', 3)
  timings.add('test1', 4)
  timings.add('test1', 5)

  timings.add('test2', 2.0)
  timings.add('test2', 3.0)
  timings.add('test2', 4.0)

  timings.add('test3', 2.0)
  timings.add('test3', 3.0)
  timings.add('test3', 4.0)
  timings.add('test3', 5.0)
  timings.add('test3', 6.0)
 

# Generated at 2022-06-23 16:10:46.474561
# Unit test for method median of class Timers
def test_Timers_median():
    a = Timers()
    a.add('a', 1)
    a.add('a', 5)
    assert a.median('a') == 3
    a.add('a', 9)
    assert a.median('a') == 5

# Generated at 2022-06-23 16:10:51.592088
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    assert t.median("foo") == 0
    t.add("foo", 1)
    assert t.median("foo") == 1
    t.add("foo", 2)
    assert t.median("foo") == 1.5
    t.add("foo", 3)
    assert t.median("foo") == 2

# Generated at 2022-06-23 16:10:53.516830
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    assert timers.min("test") == 0
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.min("test") == 1


# Generated at 2022-06-23 16:10:56.558287
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add("queries", 1.0)
    timers.add("queries", 2.0)
    return timers.total("queries") == 3.0

# Generated at 2022-06-23 16:11:04.136133
# Unit test for method median of class Timers
def test_Timers_median():
    """Test that the median is calculated correctly"""
    # Prepare fixture
    test_data = Timers()
    test_data.add("median_test", 1)
    test_data.add("median_test", 5)
    test_data.add("median_test", 5)
    test_data.add("median_test", 5)

    # Verify
    assert test_data.median("median_test") == 5
    assert test_data.median("median_test") == test_data.mean("median_test")

# Generated at 2022-06-23 16:11:12.768333
# Unit test for method min of class Timers
def test_Timers_min():
    """Test for method min of class Timers"""
    t = Timers()
    t.add("good", 1.0)
    t.add("good", 2.1)
    t.add("good", 3.1)
    t.add("bad", 0.9)
    t.add("bad", 1.5)
    t.add("bad", 1.1)

    assert t.min("good") == 1.0
    assert t.min("bad") == 0.9


# Generated at 2022-06-23 16:11:15.388509
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method add of class Timers"""
    # Initialize timers
    timers = Timers()
    timers.add("test", 1)
    # Check
    assert timers["test"] == 1
    assert timers._timings["test"] == [1]


# Generated at 2022-06-23 16:11:18.477303
# Unit test for method mean of class Timers
def test_Timers_mean():
    timings = Timers()
    assert timings.mean("not-existent")==0
    timings.add("test", 1)
    assert timings.mean("test")==1
    timings.add("test", 1)
    assert timings.mean("test")==1
    timings.add("test", 3)
    assert timings.mean("test")==2

# Generated at 2022-06-23 16:11:23.773057
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("foo", 1.0)
    timers.add("foo", 2.0)
    timers.add("bar", 3.0)
    assert timers.max("foo") == 2.0
    assert timers.max("bar") == 3.0


# Generated at 2022-06-23 16:11:27.743833
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("a", 5)
    timers.add("b", 3)
    assert timers.max("a") == 5
    assert timers.max("b") == 3
    del timers.data["a"]
    with pytest.raises(KeyError):
        timers.max("a")


# Generated at 2022-06-23 16:11:32.855962
# Unit test for method clear of class Timers
def test_Timers_clear():
    """
    Create an instance of Timers, add some values and clear it, then check the
    resulting length is 0.
    """
    timers = Timers()
    timers.add("t1", 1.0)
    timers.clear()
    assert len(timers) == 0


# Generated at 2022-06-23 16:11:36.107746
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert timers.data == {}


# Generated at 2022-06-23 16:11:46.603584
# Unit test for method median of class Timers
def test_Timers_median():
    """Unit test for method 'median' of class 'Timers'"""
    timers = Timers()
    timers.add("time1", 0.7)
    timers.add("time1", 0.2)
    timers.add("time1", 0.1)
    timers.add("time2", 0.9)
    timers.add("time2", 0.5)
    timers.add("time2", 0.6)
    assert timers.median("time1") == 0.2
    assert timers.median("time2") == 0.6
    try:
        timers.median("time3")
        assert False
    except KeyError:
        pass
    assert str(timers) == "{'time1': 1.0, 'time2': 2.0}"