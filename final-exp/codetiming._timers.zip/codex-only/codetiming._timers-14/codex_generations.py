

# Generated at 2022-06-23 16:01:58.958057
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    from random import sample

    def generator(n: float) -> List[float]:
        """Create a random sample"""
        return sample(range(int(n/10)**2), int(n))

    timers = Timers()

    for n in (1, 2, 3, 10, 100, 1000, 10000, 100000):
        times = generator(n)
        assert len(times) == int(n)
        timers.add(name=f"n{n}", value=sum(times))

        assert timers.count(f"n{n}") == 1
        assert timers.total(f"n{n}") == sum(times)
        assert timers.min(f"n{n}") == min(times)
        assert timers.max(f"n{n}")

# Generated at 2022-06-23 16:02:04.610421
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    assert not timers.data
    assert not timers._timings
    timers.add("my_timer", 2)
    assert timers.data["my_timer"] == 2
    assert timers._timings["my_timer"] == [2]
    timers.clear()
    assert not timers.data
    assert not timers._timings


# Generated at 2022-06-23 16:02:10.363478
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test method of class Timers"""
    timers = Timers()
    timers["test"] = 1e0
    assert(timers.data["test"] == 1e0)
    timers.add("test",1e0)
    assert(timers.data["test"] == 2e0)
    timers["test"] = 1e0
    assert(timers.data["test"] == 2e0)


# Generated at 2022-06-23 16:02:15.897014
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    assert timers.median("foo") == 0.0
    timers.add("foo", 3.1415)
    assert timers.median("foo") == 3.1415
    timers.add("foo", 2.7182)
    assert timers.median("foo") == 2.92985
    timers.add("foo", 1.4142)
    assert timers.median("foo") == 2.7182
    timers.add("foo", 42)
    assert timers.median("foo") == 3.1415


# Generated at 2022-06-23 16:02:19.486187
# Unit test for method clear of class Timers
def test_Timers_clear():
    T = Timers()
    T.add("test", 1)

    T.clear()
    assert T._timings == {}
    assert T.data == {}


# Generated at 2022-06-23 16:02:22.773505
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('my_timer', 1.6)
    timers.add('my_timer', 0.3)
    assert timers.min('my_timer') == 0.3


# Generated at 2022-06-23 16:02:26.441093
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('t1', 2.0)
    timers.add('t1', 2.0)
    timers.add('t1', 3.0)
    timers.add('t1', 4.0)
    timers.add('t1', 5.0)

    result = timers.median('t1')
    assert result == 3.0

# Generated at 2022-06-23 16:02:31.503063
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    assert timers.count("cat") == 0
    assert timers.total("cat") == 0
    timers.add("cat", 1.0)
    assert timers.data["cat"] == 1.0
    assert timers.count("cat") == 1
    assert timers.total("cat") == 1.0
    timers.add("cat", 1.5)
    assert timers.data["cat"] == 2.5
    assert timers.count("cat") == 2
    assert timers.total("cat") == 2.5
    timers.add("dog", 1.0)
    assert timers.data["dog"] == 1.0
    assert timers.count("dog") == 1
    assert timers.total("dog") == 1.0

# Generated at 2022-06-23 16:02:32.478471
# Unit test for constructor of class Timers
def test_Timers():
    assert Timers()


# Generated at 2022-06-23 16:02:37.614512
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    timers = Timers()
    try:
        timers["A"] = 1
    except TypeError:
        assert True
    except:
        assert False
    else:
        assert False


# Generated at 2022-06-23 16:02:43.631298
# Unit test for method max of class Timers
def test_Timers_max():
    """Test 'max' method of class Timers"""
    timers = Timers()
    assert timers.max("test") == 0
    timers._timings["test"] = [1, 2, 3, 4]
    assert timers.max("test") == 4
    timers._timings["test"] = [1, 2, 3, 4, None]
    assert timers.max("test") == 4
    timers._timings["test"] = [None]
    assert timers.max("test") == 0


# Generated at 2022-06-23 16:02:47.034089
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    for i in range(1,10):
        t.add('test', i)
    t.mean('test')
    return t

# Generated at 2022-06-23 16:02:49.536624
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()
    t.add('test', 1)
    t.add('test', 2)
    assert t.total('test') == 3

# Generated at 2022-06-23 16:02:57.753452
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers.add('mytimer', 1.)
    timers.add('mytimer', 2.)
    assert timers.total('mytimer') == 3
    assert timers.min('mytimer') == 1.
    assert timers.max('mytimer') == 2.
    assert timers.mean('mytimer') == 1.5
    assert timers.median('mytimer') == 1.5
    assert timers.stdev('mytimer') == 0.5
    assert timers.count('mytimer') == 2


# Generated at 2022-06-23 16:03:00.955404
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    from pytest import raises

    timers = Timers()
    with raises(TypeError):
        timers["name"] = 0.0
    assert timers == {}


# Generated at 2022-06-23 16:03:09.804211
# Unit test for method add of class Timers
def test_Timers_add():
    """Test that add() works correctly"""
    T = Timers()
    T.add('Timer1', 1.0)
    assert T.data['Timer1'] == 1.0
    assert len(T._timings['Timer1']) == 1

    # Add another value to the same timer
    T.add('Timer1', 2.0)
    assert T.data['Timer1'] == 3.0
    assert len(T._timings['Timer1']) == 2

    # Add a second timer
    T.add('Timer2', 3.0)
    assert T.data['Timer2'] == 3.0
    assert len(T._timings['Timer2']) == 1

    # Check that the wrong call to setitem is rejected
    try:
        T['Timer1'] = 1.0
    except TypeError:
        pass

# Generated at 2022-06-23 16:03:14.085656
# Unit test for method mean of class Timers
def test_Timers_mean():
    timer = Timers()
    timer.add("test", 0.1)
    timer.add("test", 0.1)
    assert timer.mean("test") == 0.1


# Generated at 2022-06-23 16:03:18.997106
# Unit test for method total of class Timers
def test_Timers_total():
    import time

    timers = Timers()
    name = "test"

    for _ in range(3):
        start = time.monotonic()
        end = time.monotonic()
        timers.add(name, end-start)

    assert round(timers.total(name), 5) == round(timers.data[name], 5)

# Generated at 2022-06-23 16:03:27.867935
# Unit test for method apply of class Timers
def test_Timers_apply():
    def test_func(values: List[float]) -> float:
        return len(values)
    timers = Timers()
    assert timers.apply(test_func, name='test_timer') == 0
    timers.add('test_timer', 1)
    assert timers.apply(test_func, name='test_timer') == 1
    #raise KeyError
    try:
        timers.apply(test_func, name='unknown_timer')
    except KeyError:
        assert True
    except Exception:
        assert False
    else:
        assert False

# Generated at 2022-06-23 16:03:30.665482
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    t = Timers()
    t.add('test', 1)
    t.add('test', 2)
    assert t.stdev('test') == 0.5

# Generated at 2022-06-23 16:03:38.366079
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply() of class Timers"""
    from typing import cast
    from pytest import raises
    from .helpers import FUNCS
    from .helpers import assert_equal, assert_almost_equal
    # Make a test timer
    timer = Timers()
    assert_equal(timer.apply(FUNCS['min'], "timer1"), 0)
    timer.add('timer1', 42)
    timer.add('timer1', 36)
    timer.add('timer1', 24)
    # Apply a Function
    for func_name in FUNCS:
        func = FUNCS[func_name]
        expected = func(timer._timings['timer1'])
        actual = timer.apply(func, 'timer1')
        assert_almost_equal(actual, expected)
    # Check no timer

# Generated at 2022-06-23 16:03:41.876983
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    assert Timers()._timings == {}
    Timers()['foo'] = 1


# Generated at 2022-06-23 16:03:46.376073
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add("T1", 1)
    timers.add("T1", 2)
    timers.add("T2", 3)
    timers.add("T2", 4)
    assert timers.data["T1"] == 3
    assert timers.data["T2"] == 7


# Generated at 2022-06-23 16:03:51.012795
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}

    timers.add("a", 1)
    assert timers.data == {"a": 1}
    assert timers.timings["a"] == [1]

    timers.add("b", 2)
    assert timers.data == {"a": 1, "b": 2}
    assert timers.timings["b"] == [2]

    timers.add("a", 3)
    assert timers.data == {"a": 4, "b": 2}
    assert timers.timings["a"] == [1, 3]



# Generated at 2022-06-23 16:03:58.037127
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    timers = Timers()

    with pytest.raises(TypeError) as excinfo:
        timers["one"] = 1.0

    assert excinfo.type == TypeError
    assert (
        excinfo.value.args[0]
        == "Timers does not support item assignment. Use '.add()' to update values."
    )


# Generated at 2022-06-23 16:04:00.752158
# Unit test for method count of class Timers
def test_Timers_count():
    # Setup
    timers = Timers()
    timers.add("foo", 12)
    timers.add("foo", 42)

    # Test
    assert timers.count("foo") == 2


# Generated at 2022-06-23 16:04:04.083120
# Unit test for method median of class Timers
def test_Timers_median():
    timings = Timers()
    timings.data = {'a': 1.0}
    assert timings.median(name='a') == 1.0
    assert timings.median(name='b') == 0.0


# Generated at 2022-06-23 16:04:10.634610
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    t = Timers()
    # in case of 0 or 1 value, stdev should return nan
    t.add("t", 1.0)
    assert math.isnan(t.stdev("t"))
    # in case of 2 or more values, stdev should compute normally
    t.add("t", 2.0)
    assert t.stdev("t") == 0.5
    # in case of 0 values, stdev should return nan
    t.add("u", 0.0)
    assert math.isnan(t.stdev("u"))
    print("Unit test for method stdev of class Timers passed.")


# Generated at 2022-06-23 16:04:12.600722
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('test', 1.0)
    assert timers.count('test') == 1


# Generated at 2022-06-23 16:04:15.248722
# Unit test for constructor of class Timers
def test_Timers():
    """Test constructor of class Timers"""
    c = Timers()
    assert c.data == {}
    assert c._timings == collections.defaultdict(list)



# Generated at 2022-06-23 16:04:20.135183
# Unit test for method max of class Timers
def test_Timers_max():
    """Unit test for method max of class Timers"""
    timers = Timers()
    timers._timings["a"] = [1, 0]
    assert timers.max("a") == 1
    assert timers.min("a") == 0


# Generated at 2022-06-23 16:04:26.673202
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('mean', 2)
    timers.add('mean', 4)
    timers.add('mean', 4)
    timers.add('mean', 4)
    timers.add('mean', 5)
    timers.add('mean', 5)
    timers.add('mean', 7)
    timers.add('mean', 9)
    # There are 8 values in the list of values for the key 'mean'
    assert timers.mean('mean') == 5.0



# Generated at 2022-06-23 16:04:30.855821
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unit test for method mean of class Timers"""
    assert Timers().mean("name") == 0.0
    timers = Timers()
    timers.add("name", 1.0)
    assert timers.mean("name") == 1.0

# Generated at 2022-06-23 16:04:39.154387
# Unit test for method max of class Timers
def test_Timers_max():
    import random
    from typing import List
    from hstestcase import HSTestCase
    from hypothesis import given, strategies as st
    random.seed(4242)
    t = Timers()
    t.add('a', 4)
    t.add('a', 5)
    t.add('a', 6)
    t.add('a', 5)
    t.add('a', 4)
    t.add('a', 3)
    assert abs(t.max('a') - 6) <= 1e-9

    @given(st.lists(st.floats()))
    def test(l: List[float]):
        t = Timers()
        for i in l: t.add('a', i)
        assert abs(t.max('a') - max(l)) <= 1e-9

    H

# Generated at 2022-06-23 16:04:45.882739
# Unit test for method apply of class Timers
def test_Timers_apply():
    def f(x: float) -> float:
        return x + 1
    d = Timers()
    d.add("a", 1)
    d.add("b", 2)
    d.add("b", 3)
    d.add("c", 1)
    assert d.total("a") == 1
    assert d.total("b") == 5
    assert d.total("c") == 1
    # Apply a function to the results of one timer.
    # The function f is defined above.
    assert d.apply(f, "a") == 2
    assert d.apply(f, "b") == 6
    assert d.apply(f, "c") == 2
    # Define a new function g
    def g(x: List[float]) -> float:
        return sum(x) ** 2
    # Apply this

# Generated at 2022-06-23 16:04:55.713610
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test Timers stdev"""
    timers = Timers()
    data = [2, 3, 3, 4, 6]
    for v in data:
        timers.add("mytimer", v)
    # the standard deviation for ``data`` should be 1.275.
    assert abs(timers.stdev("mytimer") - 1.275) < 0.001
    # with one value the standard deviation is NaN.
    timers.add("mytimer", 1)
    assert math.isnan(timers.stdev("mytimer"))
    # if the timer is empty, raise KeyError.
    with pytest.raises(KeyError):
        _ = timers.stdev("notimer")

# Generated at 2022-06-23 16:05:01.066263
# Unit test for method min of class Timers
def test_Timers_min():
    values = {'name1': [1.0, 2.0], 'name2': [1.5, 2.5]}
    timers = Timers(values)
    assert timers.min('name1') == 1.0
    assert timers.min('name2') == 1.5


# Generated at 2022-06-23 16:05:03.877534
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    assert timers.min("test") == 0
    timers.add("test", 1)
    assert timers.min("test") == 1
    timers.add("test", 2)
    assert timers.min("test") == 1
    timers.add("test", 0)
    assert timers.min("test") == 0
    timers.clear()
    assert timers.min("test") == 0


# Generated at 2022-06-23 16:05:07.057398
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add("total", 0.1)
    timers.add("total", 0.2)
    timers.add("total", 0.3)
    assert timers.total("total") == 0.6


# Generated at 2022-06-23 16:05:08.639960
# Unit test for method median of class Timers
def test_Timers_median():
    pass


# Generated at 2022-06-23 16:05:14.120504
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""

    def mul(values):
        """Multiply all values"""
        product = 1
        for value in values:
            product *= value
        return product

    timers = Timers()
    timers.add('x', value=1)
    assert timers.apply(mul, name='x') == 1
    timers.add('x', value=2)
    assert timers.apply(mul, name='x') == 2
    assert timers.apply(mul, name='y') == 0

# Generated at 2022-06-23 16:05:17.096321
# Unit test for method count of class Timers
def test_Timers_count():
    assert Timers().count('hello') == 0
    assert Timers({'hello': 1}).count('hello') == 1
    assert Timers().add('hello', 2).count('hello') == 1


# Generated at 2022-06-23 16:05:20.087533
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("name", 1)
    timers.add("name", 2)
    timers.add("name", 3)
    assert timers.median("name") == 2

# Generated at 2022-06-23 16:05:25.145285
# Unit test for method count of class Timers
def test_Timers_count():
    """timing.py: Timers.count"""
    timers = Timers()

    assert timers.count("a") == 0
    assert timers.count("b") == 0

    timers.add("a", 5)
    timers.add("a", 7)

    assert timers.count("a") == 2
    assert timers.count("b") == 0

    return


# Generated at 2022-06-23 16:05:31.877686
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.add("T1", 1.0)
    t.add("T2", 2.0)
    t.add("T2", 3.0)
    assert t.max("T1") == 1.0
    assert t.max("T2") == 3.0
    try:
        t.max("T3")
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-23 16:05:38.056293
# Unit test for method add of class Timers
def test_Timers_add():
    """Test add method of class Timers"""
    timers = Timers()
    assert timers.data == {}
    timers.add("t1", 1)
    assert timers.data == {"t1": 1}
    assert timers._timings == {"t1": [1]}
    timers.add("t1", 2)
    assert timers.data == {"t1": 3}
    assert timers._timings == {"t1": [1, 2]}


# Generated at 2022-06-23 16:05:43.330770
# Unit test for method count of class Timers
def test_Timers_count():
    """Test if we get the correct number of values"""
    timers = Timers()
    timers.clear()
    assert timers.count("foo") == 0
    timers.add("foo", 1)
    timers.add("foo", 2)
    assert timers.count("foo") == 2


# Generated at 2022-06-23 16:05:48.203315
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timer = Timers()
    timer.add(name=1, value=1)
    assert math.isnan(timer.stdev(name=1))
    timer.add(name=1, value=2)
    assert timer.stdev(name=1) == 0.5
    timer.add(name=1, value=3)
    assert timer.stdev(name=1) == 1

# Generated at 2022-06-23 16:05:51.057439
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    with pytest.raises(TypeError):
        timers["a"] = 2.0


# Generated at 2022-06-23 16:05:55.039560
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    try:
        timers_1 = Timers()
        timers_1["test"] = 1
    except Exception as e:
        raise AssertionError(
            "test_Timers___setitem__: Wrong exception was thrown \n"
            + "actual exception: " + str(type(e))
            + " \n expected exception: TypeError"
        )

# Generated at 2022-06-23 16:06:02.290103
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('A', 1)
    timers.add('A', 2)
    timers.add('A', 3)
    timers.add('A', 4)
    timers.add('A', 5)
    timers.add('A', 6)
    timers.add('A', 7)
    timers.add('A', 8)
    timers.add('A', 9)
    timers.add('A', 10)
    assert timers.median('A') == 5.5


# Generated at 2022-06-23 16:06:13.460063
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test method apply of class Timers"""
    timers = Timers()
    timers.add('a', 1)
    timers.add('b', 2)
    length = len(timers.data)
    timers.apply(sum, name='a')
    assert len(timers.data) == length
    timers.apply(sum, name='b')
    assert len(timers.data) == length
    timers.apply(sum, name='c')
    assert len(timers.data) == length
    timers.apply(len, name='a')
    assert len(timers.data) == length
    timers.apply(len, name='b')
    assert len(timers.data) == length
    timers.apply(len, name='c')
    assert len(timers.data) == length

# Generated at 2022-06-23 16:06:18.249157
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add(name="a", value=1)
    timers.add(name="a", value=2)
    timers.add(name="b", value=5)
    assert timers.total("a") == 3
    assert timers.total("b") == 5


# Generated at 2022-06-23 16:06:22.659681
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test Timers.__setitem__"""
    import pytest

    timers = Timers()
    timers.add("test", 10)
    assert timers["test"] == 10

    with pytest.raises(TypeError):
        timers["test"] += 10

# Generated at 2022-06-23 16:06:31.661531
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test that the apply method works"""
    # '_timings' is private so it must be tested indirectly
    times = Timers()
    times.add("timer", 5)
    times.add("timer", 10)

    assert times.count("timer") == 2
    assert times["timer"] == 15

    assert times.min("timer") == 5
    assert times.max("timer") == 10
    assert times.mean("timer") == 7.5
    assert times.median("timer") == 7.5
    assert times.stdev("timer") == 2.5
    assert times.total("timer") == 15

# Generated at 2022-06-23 16:06:38.602394
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    timers = Timers()
    timers.add('A', 1.0)
    timers.add('A', 2.0)
    timers.add('B', 3.0)
    timers.add('C', 4.0)
    assert timers._timings == {'A': [1.0, 2.0], 'B': [3.0], 'C': [4.0]}
    assert timers.data == {'A': 3.0, 'B': 3.0, 'C': 4.0}


# Generated at 2022-06-23 16:06:47.493173
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    timers = Timers()
    timers.add('s', 1)
    timers.add('s', 2)
    timers.add('s', 3)
    timers.add('s', 4)
    timers.add('s', 5)
    assert timers.apply(len, 's') == 5
    assert timers.apply(sum, 's') == 15
    assert timers['s'] == 15
    assert timers.apply(lambda values: min(values), 's') == 1
    assert timers.apply(lambda values: max(values), 's') == 5
    assert timers.apply(lambda values: statistics.mean(values), 's') == 3
    assert timers.apply(lambda values: statistics.median(values), 's') == 3

# Generated at 2022-06-23 16:06:53.358326
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add('timer1', 2)
    timers.add('timer1', 3)
    timers.add('timer2', 3)
    assert timers.total('timer1') == 5


# Generated at 2022-06-23 16:06:54.945407
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    a = Timers()
    try:
        a['a'] = 1.0
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 16:06:58.887456
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.add('', 1)
    t.add('', 2)
    t.add('', 3)
    t.add('', 4)
    t.add('', 5)
    assert t.max('') == 5


# Generated at 2022-06-23 16:07:05.093539
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test if Timers can be created and its attributes set"""
    from IPython import embed

    timers = Timers()
    try:
        timers["key"] = 0.0
    except TypeError:
        print("Type error thrown as expected!")



# Generated at 2022-06-23 16:07:08.008139
# Unit test for method total of class Timers
def test_Timers_total():
    import time

    timings = Timers()

    # Add a timing
    start = time.time()
    timings.add('total', time.time() - start)

    assert timings.total('total') > 0

# Generated at 2022-06-23 16:07:10.421160
# Unit test for method clear of class Timers
def test_Timers_clear():
    t = Timers()
    t.add("Test", 0)
    assert len(t) == 1
    t.clear()
    assert len(t) == 0


# Generated at 2022-06-23 16:07:15.570419
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Instantiate a Timers object
    ts = Timers()
    ts.add("a", 2)
    ts.add("b", 3)
    ts.add("a", 4)
    assert ts.mean("a") == 3
    assert ts.mean("b") == 3
    assert ts.mean("c") == 0


if __name__ == "__main__":
    test_Timers_mean()

# Generated at 2022-06-23 16:07:20.195969
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    t.add("a", 10)
    t.add("b", 20)
    t.add("c", 30)
    assert t.median("a") == 10
    assert t.median("b") == 20
    assert t.median("c") == 30


# Generated at 2022-06-23 16:07:28.212414
# Unit test for method mean of class Timers
def test_Timers_mean():
    import unittest
    from pathlib import Path
    import pandas as pd
    import pandas.util.testing as pdt

    # load in sample CSV to compare with
    path = Path(__file__).parent / 'sample_timers_mean.csv'
    sample = pd.read_csv(path)

    # create new timers object and populate with sample data
    timers = Timers()
    data = sample.to_dict(orient='list')
    for key, value in data.items():
        timers.add(key, value[0])

    # run mean method
    result = timers.mean('TimerA')

    # assert correctness of result
    assert round(result, 2) == round(sample['mean'][0], 2)

# Generated at 2022-06-23 16:07:31.845617
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Unittest for method mean of class Timers"""
    timers = Timers()
    timers._timings['foo'] = [1, 2, 3, 4, 5]

    assert timers.mean('foo') == 3



# Generated at 2022-06-23 16:07:34.998994
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    # Create a new timers object
    timers: Timers = Timers()
    # Add a negative value
    timers.add("test1", -1)
    # Add zero
    timer

# Generated at 2022-06-23 16:07:39.827836
# Unit test for method count of class Timers
def test_Timers_count():
    """Test count method of class Timers."""
    timings = Timers()
    assert timings.count("dummy1") == 0
    timings.add("dummy1", 1)
    timings.add("dummy1", 2)
    timings.add("dummy1", 0)
    assert timings.count("dummy1") == 3


# Generated at 2022-06-23 16:07:50.261594
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("test1", 0.2)
    t.add("test1", 0.01)
    assert t.min("test1") == 0.01

    t.add("test2", 0.2)
    t.add("test2", 0.01)
    assert t.min("test2") == 0.01

    t.add("test3", 1)
    t.add("test3", 2)
    t.add("test3", 4)
    assert t.min("test3") == 1

    t.add("test4", 1)
    t.add("test4", 2)
    t.add("test4", 4)
    assert t.min("test4") == 1



# Generated at 2022-06-23 16:07:52.439953
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test_timers_mean", 1)
    assert(timers.mean("test_timers_mean") == 1)

    timers.add("test_timers_mean", 1)
    assert(timers.mean("test_timers_mean") == 1)

# Generated at 2022-06-23 16:07:56.753947
# Unit test for method mean of class Timers
def test_Timers_mean():
    from numpy import nan
    timer = Timers()
    timer.add("t1", 20)
    timer.add("t2", 10)
    timer.add("t2", 20)
    assert timer.mean("t1") == 20
    assert timer.mean("t2") == 15
    assert timer.mean("t3") == nan


# Generated at 2022-06-23 16:08:05.443279
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for method stdev of class Timers"""
    timers = Timers()
    timers._timings = {
        "a": [1, 2, 3],
        "b": [5, 6, 7, 8],
    }
    assert timers.stdev("a") == 1.0
    assert timers.stdev("b") == 1.5811388300841898
    try:
        timers.stdev("c")
    except KeyError:
        pass
    else:
        assert False, "Should throw KeyError"

# Generated at 2022-06-23 16:08:10.474855
# Unit test for method max of class Timers
def test_Timers_max():
    # pylint: disable=unexpected-keyword-arg,no-value-for-parameter
    timers = Timers()
    timers.add(name='timer1', value=0.1)
    timers.add(name='timer1', value=0.2)
    timers.add(name='timer1', value=0.3)

    assert timers.max('timer1') == 0.3

# Generated at 2022-06-23 16:08:13.682501
# Unit test for method total of class Timers
def test_Timers_total():
    timer = Timers()
    timer.data["test"] = 2
    timer.add("test",4)
    assert timer.total("test") == 6
    assert timer.data["test"] == 6

test_Timers_total()

# Generated at 2022-06-23 16:08:17.872524
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("test", 1)
    assert timers.count("test") == 1
    timers.add("test", 2)
    assert timers.count("test") == 2

# Generated at 2022-06-23 16:08:23.701711
# Unit test for constructor of class Timers
def test_Timers():
    t = Timers()
    t.add('name_1', 1.0)
    t.add('name_2', 2.0)
    assert t.mean('name_1') == 1.0
    assert t.mean('name_2') == 2.0
    assert t.mean('name_3') == 0.0
    assert t.mean('name_3') == 0.0
    

# Generated at 2022-06-23 16:08:26.699719
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('a', 1)
    for i in range(10):
        timers.add('a', i * 1.0)
    assert timers.min('a') == 1.0


# Generated at 2022-06-23 16:08:30.199818
# Unit test for method mean of class Timers
def test_Timers_mean():

    timers = Timers()
    timers.add("m", 1)
    timers.add("m", 2)
    mean = timers.mean("m")
    print("mean:", mean)
    assert mean == 1.5

# Generated at 2022-06-23 16:08:35.627047
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    timers = Timers()

    assert 'test' not in timers

    with pytest.raises(TypeError):
        timers['test'] = 0.0

    assert 'test' not in timers


# Generated at 2022-06-23 16:08:39.683859
# Unit test for method count of class Timers
def test_Timers_count():
    """Unit test for method count of class Timers"""
    timers = Timers()
    assert timers.count(name="test") == 0.0
    timers.add(name="test", value=1.0)
    assert timers.count(name="test") == 1.0
    timers.add(name="test", value=2.0)
    assert timers.count(name="test") == 2.0


# Generated at 2022-06-23 16:08:43.049071
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add('var', 1)
    t.add('var', 2)
    assert t.mean('var') == 1.5


# Generated at 2022-06-23 16:08:51.684671
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Check if method stdev returns the right values"""
    timers = Timers()
    assert math.isnan(timers.stdev(name="test"))
    try:
        timers.stdev(name="notexist")
    except KeyError:
        assert True
    else:
        assert False
    assert math.isnan(timers.stdev(name="test"))
    timers.add("test", 1)
    assert math.isnan(timers.stdev(name="test"))
    timers.add("test", 2)
    assert timers.stdev(name="test") == 1
  

# Generated at 2022-06-23 16:08:56.000115
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('one', 1)
    timers.add('two', 2)
    assert timers.mean('one') == 1
    assert timers.mean('two') == 2
    assert timers.mean('three') == 0

# Generated at 2022-06-23 16:08:58.420377
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    timers = Timers()
    timers.add('a', 1)
    with pytest.raises(TypeError):
        timers['a'] = 2


# Generated at 2022-06-23 16:09:01.516135
# Unit test for constructor of class Timers
def test_Timers():  # pragma: no cover
    timers = Timers()
    assert isinstance(timers, Timers)
    assert isinstance(timers.data, dict)
    assert isinstance(timers._timings, dict)

# Generated at 2022-06-23 16:09:04.370007
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    assert math.isnan(t.mean("name"))
    t.add("name", 0)
    assert t.mean("name") == 0



# Generated at 2022-06-23 16:09:05.754510
# Unit test for constructor of class Timers
def test_Timers():
    """Test the constructor of class Timers"""
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:09:10.633004
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('get_sensor_data', 1)
    timers.add('get_sensor_data', 1)
    timers.add('get_sensor_data', 1)

    assert timers.median('get_sensor_data') == 1


# Generated at 2022-06-23 16:09:13.598866
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 3)
    assert timers.max('test') == 3


# Generated at 2022-06-23 16:09:17.590282
# Unit test for method mean of class Timers
def test_Timers_mean():
    import pytest

    # Simple case
    timers = Timers()
    timers.add("timer1", 2)
    timers.add("timer1", 3)

    assert timers.mean("timer1") == 2.5

    # Case when no data is added
    timers = Timers()

    with pytest.raises(KeyError):
        timers.mean("timer1")

# Generated at 2022-06-23 16:09:25.760659
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test the mean function of the Timers class"""
    timers = Timers()
    assert timers.mean("foo") == 0
    assert timers.mean("bar") == 0
    timers.add("foo", 2)
    assert timers.mean("foo") == 2
    assert timers.mean("bar") == 0
    timers.add("foo", 3)
    assert timers.mean("foo") == 2.5
    assert timers.mean("bar") == 0

# Generated at 2022-06-23 16:09:30.898547
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count("some timer") == 0
    timers.add("some timer", 1)
    assert timers.count("some timer") == 1
    timers.add("some timer", 2)
    assert timers.count("some timer") == 2
    timers.add("some timer", 2)
    assert timers.count("some timer") == 3

# Generated at 2022-06-23 16:09:36.261548
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test method clear of class Timers"""
    timers = Timers()
    timers.add(name="a", value=1)
    timers.add(name="a", value=2)
    assert len(timers.data) == 1
    assert len(timers._timings) == 1
    timers.clear()
    assert len(timers.data) == 0
    assert len(timers._timings) == 0


# Generated at 2022-06-23 16:09:41.369733
# Unit test for method total of class Timers
def test_Timers_total():
    # Create new timers
    timers = Timers()

    # Add values to timer
    timers.add('timer1', 1)
    timers.add('timer1', 2)
    timers.add('timer1', 3)

    # Print total value of timer1
    print(timers.total('timer1'))


# Generated at 2022-06-23 16:09:47.841073
# Unit test for method total of class Timers
def test_Timers_total():
    timers = Timers()
    timers.add("list", 1.0)
    timers.add("list", 2.0)
    timers.add("list", 3.0)

    timers.add("tuple", 1.0)
    timers.add("tuple", 2.0)

    timers.add("for", 10.0)

    assert timers.total("list") == 6.0
    assert timers.total("tuple") == 3.0
    assert timers.total("for") == 10.0

# Generated at 2022-06-23 16:09:54.388128
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers = Timers()

    timers.add("A", 1.0)
    assert timers.mean("A") == 1.0

    timers.add("A", 5.0)
    assert timers.mean("A") == 3.0

    timers.add("B", -3.0)
    assert timers.mean("B") == -3.0

    try:
        timers.mean("C")
    except KeyError:
        assert True

# Unit tests for method add of class Timers

# Generated at 2022-06-23 16:10:01.274603
# Unit test for method clear of class Timers
def test_Timers_clear():
    """
    Unit test for method clear of class Timers

    Test that clear removes all values and timings.

    """
    timers = Timers()
    timers.add("timing_1", 1)
    timers.add("timing_1", 2)
    assert len(timers) == 1
    assert len(timers._timings) == 1
    timers.clear()
    assert len(timers) == 0
    assert len(timers._timings) == 0


# Generated at 2022-06-23 16:10:12.690925
# Unit test for method median of class Timers
def test_Timers_median():
    import pytest
    # Test median on an empty list
    timers = Timers()
    assert timers.median("foo") == 0
    # Test median on a list with one element
    timers.add("foo", 1)
    assert timers.median("foo") == 1
    # Test median on a list with even number of elements
    for i in (-1, 0, 1, 2):
        timers.add("foo", i)
    assert timers.median("foo") == 0
    # Test median on a list with odd number of elements
    timers.add("foo", 3)
    assert timers.median("foo") == 1
    # Test median on a list without zero element
    timers.data["foo"] = 4
    with pytest.raises(KeyError):
        timers.median("foo")


# Generated at 2022-06-23 16:10:16.379875
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 11)
    timers.add("test", 12)
    assert timers.mean("test") == 11.5

# Generated at 2022-06-23 16:10:20.778754
# Unit test for method total of class Timers
def test_Timers_total():
    # setup
    timers = Timers()
    expected_output = 1.0
    # exercise
    timers.add('test_timer', expected_output)
    actual_output = timers.total('test_timer')
    # verify
    assert actual_output == expected_output
    # clean up



# Generated at 2022-06-23 16:10:29.848676
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Testing Timers.apply"""
    time = Timers()

    def sum_(values) -> float:
        """Sum of timings"""
        return sum(values)

    def len_(values) -> float:
        """Number of timings"""
        return len(values)

    def min_(values) -> float:
        """Minimun value of timings"""
        return min(values or [0])

    def max_(values) -> float:
        """Maximun value of timings"""
        return max(values or [0])

    def mean_(values) -> float:
        """Mean value of timings"""
        return statistics.mean(values or [0])

    def median_(values) -> float:
        """Median value of timings"""
        return statistics.median(values or [0])


# Generated at 2022-06-23 16:10:35.272913
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test the stdev method of the Timers class"""
    timers = Timers()
    timers.add('Timer', 1)
    assert timers.stdev('Timer') == math.nan
    timers.add('Timer', 2)
    assert round(timers.stdev('Timer'), 2) == 0.71

# Generated at 2022-06-23 16:10:41.670214
# Unit test for method add of class Timers
def test_Timers_add():
    from pytest import raises
    timers = Timers()
    timers.add("one", 1)
    assert timers.data == {"one": 1}
    timers.add("one", 2)
    assert timers.data == {"one": 3}
    timers.add("two", 1)
    assert timers.data == {"one": 3, "two": 1}
    with raises(TypeError):
        timers["one"] = 2


# Generated at 2022-06-23 16:10:48.689372
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Unit test for the stdev method of class timers"""
    timers = Timers()
    timers.add("a", 1.0)
    timers.add("a", 2.0)
    assert timers.stdev("a") == 0.5
    timers.clear()
    timers.add("b", -1.0)
    timers.add("b", 2.0)
    assert timers.stdev("b") == 1.5

# Generated at 2022-06-23 16:10:51.284548
# Unit test for constructor of class Timers
def test_Timers():
    """Ensure that Timers are created as expected"""
    timers = Timers()
    assert timers._timings == collections.defaultdict(list)

# Generated at 2022-06-23 16:10:55.598483
# Unit test for method add of class Timers
def test_Timers_add():
    t = Timers()
    t.add('a', 1)
    t.add('a', 2)
    assert t.data['a'] == 3
    t.add('b', 10)
    t.add('b', 20)
    assert t.data['b'] == 30

# Generated at 2022-06-23 16:10:57.632898
# Unit test for constructor of class Timers
def test_Timers():
    tm = Timers()
    assert isinstance(tm, Timers)


# Generated at 2022-06-23 16:11:02.681874
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add("a", 1.0)
    timers.add("b", 2.0)
    timers.clear()
    assert len(timers) == 0
    assert "a" not in timers
    assert "b" not in timers
    assert isinstance(timers, Timers)


# Generated at 2022-06-23 16:11:15.395618
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    assert timers.apply(len, "foo") == 0
    assert timers.apply(sum, "foo") == 0.0
    assert timers.apply(lambda values: min(values or [0]), "foo") == 0.0
    assert timers.apply(lambda values: max(values or [0]), "foo") == 0.0
    assert timers.apply(lambda values: statistics.mean(values or [0]), "foo") == 0.0
    assert timers.apply(lambda values: statistics.median(values or [0]), "foo") == 0.0

# Generated at 2022-06-23 16:11:21.492338
# Unit test for method count of class Timers
def test_Timers_count():
    import pytest

    t = Timers({'foo': 1.0})
    assert t.count('foo') == 1

    t.add('foo', 2.0)
    assert t.count('foo') == 2

    # Testing KeyError
    with pytest.raises(KeyError):
        t.count('bar')


# Generated at 2022-06-23 16:11:28.133240
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    assert math.isnan(timers.stdev("test_1"))
    timers.add("test_1", 1.0)
    assert math.isnan(timers.stdev("test_1"))
    timers.add("test_1", 3.2)
    assert math.isclose(timers.stdev("test_1"), 1.964841768641673)
    timers.add("test_1", 4.4)
    timers.add("test_1", 6.3)
    timers.add("test_1", 5.0)
    assert math.isclose(timers.stdev("test_1"), 1.9092974268256817)

# Generated at 2022-06-23 16:11:33.692377
# Unit test for method count of class Timers
def test_Timers_count():
    assert Timers().count("abc") == 0
    t = Timers()
    t.add("abc", 0.5)
    t.add("def", 0.5)
    t.add("abc", 0.5)
    t.add("abc", 0.5)
    assert t.count("abc") == 3
    assert t.count("def") == 1


# Generated at 2022-06-23 16:11:38.748614
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test method __setitem__ of class Timers"""
    timers = Timers()
    try:
        timers["name"] = 1.0
    except TypeError:
        return
    raise AssertionError("Please check method Timers.__setitem__.")


# Generated at 2022-06-23 16:11:48.466240
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Check Timers.apply()"""
    timings = Timers()
    timings.add('a', 0.1)
    timings.add('a', 0.2)
    timings.add('a', 0.3)
    timings.add('b', 0.4)
    timings.add('b', 0.5)
    timings.add('b', 0.6)

    assert timings.apply(lambda x: sum(x)/len(x), 'a') == 0.2
    assert timings.apply(lambda x: sum(x)/len(x), 'b') == 0.5



# Generated at 2022-06-23 16:11:54.478705
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    assert timers.count("non_existing_timername") == 0
    timers.data["existing_timer"] = 0
    assert timers.count("existing_timer") == 0
    timers.add("add_timer", 1)
    assert timers.count("add_timer") == 1
    timers.add("add_timer", 2)
    assert timers.count("add_timer") == 2
