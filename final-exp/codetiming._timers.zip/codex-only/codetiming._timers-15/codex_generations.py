

# Generated at 2022-06-23 16:01:55.990831
# Unit test for method median of class Timers
def test_Timers_median():
    """Ensure Timers.median returns the correct value"""
    import pytest
    timers = Timers()
    timers.add("foo", 5)
    timers.add("foo", 10)
    timers.add("foo", 15)
    timers.add("foo", 20)
    assert timers.median("foo") == 10
    with pytest.raises(KeyError):
        timers.median("bar")

if __name__ == '__main__':
    import doctest
    print("Running doctests:")
    doctest.testmod()

# Generated at 2022-06-23 16:02:06.923702
# Unit test for method clear of class Timers
def test_Timers_clear():

    # Test attribute data
    try:
        timers = Timers()
        timers.add('timer-x', 0.1)
        timers.add('timer-y', 1.0)
        timers.add('timer-z', 100)
        assert timers.data['timer-x'] == 0.1
        assert timers.data['timer-y'] == 1.0
        assert timers.data['timer-z'] == 100
        
        # Test attribute data when clear
        timers.clear()
        assert timers.data == {}
    except:
        print("Failed test_Timers_clear")
        return False
    
    # Test attribute _timings

# Generated at 2022-06-23 16:02:09.916707
# Unit test for method min of class Timers
def test_Timers_min():
    """Test Timers.min()"""
    timers = Timers()
    timers.add('a', 1)
    timers.add('a', 2)
    assert timers.min('a') == 1


# Generated at 2022-06-23 16:02:12.875044
# Unit test for constructor of class Timers
def test_Timers():
    assert list(Timers().data.keys()) == []
    assert Timers().data == {}
    assert Timers()._timings == collections.defaultdict(list)


# Generated at 2022-06-23 16:02:14.977401
# Unit test for method apply of class Timers
def test_Timers_apply():
    t = Timers()
    assert t.apply(len, name="foobar") == 0
    t._timings["foobar"] = [0.1, 0.2, 0.3]
    assert t.apply(len, name="foobar") == 3


# Generated at 2022-06-23 16:02:21.099788
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    test_case = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 5.0, 20.0, 30.0, 50.0, 70.0, 100.0]
    dictionary = Timers()
    dictionary._timings['test'] = test_case
    expected = 34.591396650694675
    assert dictionary.stdev('test') == expected

# Generated at 2022-06-23 16:02:25.070386
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    # Arrange
    t = Timers()
    # Act and assert
    with pytest.raises(TypeError):
        t['name'] = 123.0


# Generated at 2022-06-23 16:02:36.024491
# Unit test for method total of class Timers
def test_Timers_total():
    """Test that the total method works correctly"""
    timers = Timers()
    assert timers.total("foo") == 0.0

    timers.add("foo", 1.2)
    assert timers.total("foo") == 1.2

    timers.add("foo", 0.0)
    assert timers.total("foo") == 1.2

    timers.add("foo", 3.4)
    assert timers.total("foo") == 4.6

    timers.add("bar", -5.6)
    assert timers.total("bar") == -5.6

    try:
        timers.total("baz")
    except KeyError:
        pass
    else:
        assert False, "Key not found when it should be"



# Generated at 2022-06-23 16:02:37.005747
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    pass

# Generated at 2022-06-23 16:02:43.259953
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    # These should raise exceptions
    def _test(name, value):
        with pytest.raises(TypeError):
            timers[name] = value

    timers = Timers()

    for name, value in [
        ("a_string", 0.1),
        (1, 0.1),
        ([1, 2], 0.1),
        (("tuple",), 0.1),
        ({"a": "b"}, 0.1),
    ]:
        _test(name, value)


# Generated at 2022-06-23 16:02:51.059526
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("a", 10)
    timers.add("b", 10)
    timers.add("a", 5)
    assert timers.count("a") == 2
    assert timers.count("b") == 1
    timers.add("b", 1)
    assert timers.count("b") == 2
    try:
        timers.count("c")
        assert False
    except KeyError as error:
        assert error.args == ("c",)


# Generated at 2022-06-23 16:02:54.998113
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    t = Timers()
    try:
        t['a'] = 1
        assert False, "Expected exception"
    except TypeError:
        pass
    t.add("a", 1)
    assert t['a'] == 1


# Generated at 2022-06-23 16:02:57.615498
# Unit test for method total of class Timers
def test_Timers_total():
    timings = Timers()
    timings.add("foo", 1.2)
    timings.add("foo", 3.4)
    timings.add("bar", 5.6)
    assert timings.total("foo") == 4.6
    assert timings.total("bar") == 5.6


# Generated at 2022-06-23 16:03:04.219718
# Unit test for method clear of class Timers
def test_Timers_clear():
    assert Timers().clear() is None

if __name__ == "__main__":
    # Unit test of this module
    import pytest
    import numpy as np
    pytest.main(args=[__file__])
    # Code for debugging this module
    from pprint import pprint
    from mb_aligner.utils.timer import Timer
    timer = Timer("timer", level="debug")
    timers = Timers()
    for i in range(10):
        with timer:
            np.random.rand(100,100)
        timers.add("timer", timer.elapsed)
    pprint(timers.data)
    assert timers.min("timer") <= timers.mean("timer") <= timers.max("timer")
    pprint(timers.count("timer"))

# Generated at 2022-06-23 16:03:07.913562
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers["my_timer"] = 10
    assert timers.min("my_timer") == 10.


# Generated at 2022-06-23 16:03:09.509738
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert len(timers.data) == 0
    assert len(timers._timings) == 0


# Generated at 2022-06-23 16:03:20.695026
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    def check(
        value, exp_exception_type, exp_exception_msg=None
    ):  # pylint: disable=too-many-statements,too-many-branches,too-many-locals
        """Check Timers"""
        # Init
        timers = Timers()
        is_ok = False
        # Execute
        try:
            timers[0] = value
        except exp_exception_type as exception:
            is_ok = True
            if exp_exception_msg:
                assert_equal(
                    str(exception), exp_exception_msg
                )  # pragma: no cover  # pragma: no branch
        except Exception as exception:  # pragma: no cover  # pragma: no branch
            print(f"Unexpected exception: {exception}")
       

# Generated at 2022-06-23 16:03:27.124401
# Unit test for method count of class Timers
def test_Timers_count():
    s = Timers()
    s.add("a", 4)
    s.add("a", 6)
    s.add("b", 5)
    s.add("b", 3)
    assert s.count("a") == 2
    assert s.count("a") != 1
    assert s.count("b") == 2
    assert s.count("b") != 1


# Generated at 2022-06-23 16:03:36.239420
# Unit test for method apply of class Timers
def test_Timers_apply():
    # pylint: disable = missing-function-docstring
    def myfunc(values: List[float]) -> float:
        return sum(values)

    timers = Timers()
    timers.add("foo.bar", 3.5)
    timers.add("foo.bar", 2.5)
    timers.add("foo.baz", 4.5)

    assert timers.apply(myfunc, name="foo.bar") == 6.0
    assert timers.apply(myfunc, name="foo.baz") == 4.5


if __name__ == "__main__":
    # Run all unit tests
    # pylint: disable = import-outside-toplevel
    import logging
    import sys
    import unittest

    logging.basicConfig(level=logging.DEBUG)
    test_suite = unitt

# Generated at 2022-06-23 16:03:39.082098
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    from pytest import raises

    timers = Timers()
    # Implicitly calls __setitem__
    with raises(TypeError):
        timers['test'] = 2.0  # type: ignore

# Generated at 2022-06-23 16:03:43.098475
# Unit test for constructor of class Timers
def test_Timers():
    timers = Timers()
    assert isinstance(timers, collections.UserDict)
    assert isinstance(timers._timings, collections.defaultdict)


# Generated at 2022-06-23 16:03:45.345233
# Unit test for method max of class Timers
def test_Timers_max():
    """Test maximum of Timer class"""

    timer: Timers = Timers()
    timer["a"] = 2
    assert timer["a"] == 2

# Generated at 2022-06-23 16:03:52.762050
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    t._timings["T1"] = [1, 2, 3, 4, 5]
    assert t.median("T1") == 3

    t._timings["T2"] = [5, 2, 3, 4, 1]
    assert t.median("T2") == 3

    t._timings["T3"] = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
    assert t.median("T3") == 1

    t._timings["T4"] = [1, 1, 2, 2, 2, 1, 2, 2, 1, 1]
    assert t.median("T4") == 2


# Generated at 2022-06-23 16:04:03.895373
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    func = sum # type: Callable[[List[float]], float]
    assert func([1, 2, 3]) == 6

    timers.add('A', 10)
    assert timers.apply(func, 'A') == 10

    timers.add('B', 20)
    assert timers.apply(func, 'B') == 20

    timers.add('B', 10)
    assert timers.apply(func, 'B') == 30

    timers.add('B', 10)
    assert timers.apply(func, 'B') == 40

    # Only 'A' and 'B' are defined, 'C' is not
    try:
        timers.apply(func, 'C')
        raise Exception('KeyError expected')
    except KeyError:
        pass


# Generated at 2022-06-23 16:04:07.654876
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Tests key-value assignment to Timers object"""
    # Initialize
    my_timers = Timers()
    # Try to set a key-value pair and test if exception is raised
    with pytest.raises(TypeError):
        my_timers['a'] = 1.0


# Generated at 2022-06-23 16:04:11.651973
# Unit test for method median of class Timers
def test_Timers_median():
    """Test methods of class Timers"""
    # Initialize timers
    timings = Timers()

    # Add some timers
    timings.add('a', 1.0)
    timings.add('a', 2.0)
    timings.add('a', 3.0)
    timings.add('a', 4.0)

    # Test method median
    assert timings.median('a') == 2.5


# Generated at 2022-06-23 16:04:15.567038
# Unit test for method total of class Timers
def test_Timers_total():
    t = Timers()
    t.add('a', 1)
    t.add('a', 2)
    t.add('b', 10)
    res = {key: t.total(key) for key in t.data}
    assert res == {'a': 3.0, 'b': 10.0}
    assert t.total('c') is None

# Generated at 2022-06-23 16:04:20.033724
# Unit test for method total of class Timers
def test_Timers_total():
    """Test if the method total works properly"""
    t = Timers()
    t.add("test", 1.0)
    t.add("test", 2.0)
    assert t.total("test") == 3.0

# Generated at 2022-06-23 16:04:27.489520
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median of Timers"""
    timers = Timers()
    timers.update({'timer_1': 1.0, 'timer_2': 2.0})
    timers._timings.update({'timer_1': [0.0, 1.0, 2.0], 'timer_2': [0.0, 2.0, 4.0]})
    assert timers.median('timer_1') == 1.0
    assert timers.median('timer_2') == 2.0
    assert timers.count('timer_1') == 3
    assert timers.count('timer_2') == 3

# Generated at 2022-06-23 16:04:30.304303
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add(name='foo', value=4.0)
    return timers.mean(name='foo') == 4.0

# Generated at 2022-06-23 16:04:34.512783
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("1", 1)
    assert timers.max("1") == 1
    timers.add("1", 2)
    assert timers.max("1") == 2
    timers.add("1", 0)
    assert timers.max("1") == 2

# Generated at 2022-06-23 16:04:42.546612
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    from pytest import raises
    from libearth.timers.add_timer import STR_TIMERS
    # Setup
    timers = Timers()
    # Assertion
    try:
        # Exercise
        timers[STR_TIMERS] = float('nan')
    except TypeError:
        pass
    else:
        # Verify
        assert False, 'TypeError raised'

# Generated at 2022-06-23 16:04:45.869515
# Unit test for method mean of class Timers
def test_Timers_mean():
    a = Timers()
    a["A"] = Timers()
    a["A"].add("A",2)
    a["A"].add("A",3)
    assert a["A"].mean("A") == 2.5


# Generated at 2022-06-23 16:04:51.178655
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test case for Timers class, method clear."""

    def test_clear() -> None:
        """Private test case for Timers class, method clear."""
        timers = Timers()
        timers.clear()
        assert not timers

    test_clear()

# Generated at 2022-06-23 16:04:56.218550
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add('timer1', value=23)
    timers.add('timer1', value=5)
    timers.add('timer2', value=10)
    timers.add('timer2', value=100)
    assert timers.data == {'timer1': 28, 'timer2': 110}
    assert timers.stdev('timer1') == 13
    assert timers.stdev('timer2') == 45

# Generated at 2022-06-23 16:05:01.253165
# Unit test for method add of class Timers
def test_Timers_add():
    timers = Timers()
    timers.add("heat", 10)
    assert timers['heat'] == 10
    timers.add("heat", 10)
    assert timers['heat'] == 20
    timers.add("cool", 10)
    assert timers['cool'] == 10


# Generated at 2022-06-23 16:05:08.872562
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median of class Timers"""
    test_timer = Timers()
    test_timer.add("test", 1)
    test_timer.add("test", 5)
    test_timer.add("test", 3)
    assert test_timer.median("test") == 3
    test_timer.add("test", 4)
    assert test_timer.median("test") == 3.5
    test_timer.add("test", 10)
    assert test_timer.median("test") == 4
    test_timer.add("test", 2)
    assert test_timer.median("test") == 3.5

# Generated at 2022-06-23 16:05:16.009505
# Unit test for method add of class Timers
def test_Timers_add():
    _timers = Timers()
    _timers.add("x", 1.0)
    _timers.add("y", 2.0)
    assert _timers._timings["x"] == [1.0]
    assert _timers._timings["y"] == [2.0]
    assert _timers.data["x"] == 1.0
    assert _timers.data["y"] == 2.0
    _timers.add("x", 1.0)
    assert _timers._timings["x"] == [1.0, 1.0]
    assert _timers.data["x"] == 2.0
    _timers.add("x", 1.0)
    assert _timers._timings["x"] == [1.0, 1.0, 1.0]
    assert _timers

# Generated at 2022-06-23 16:05:19.348565
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for the add method of the Timers class."""
    _timers = Timers()
    for _ in range(10):
        _timers.add("a", 1)
    assert _timers["a"] == 10



# Generated at 2022-06-23 16:05:23.424214
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the method median of class Timers"""
    timers = Timers()
    timers.add('foo', 1)
    timers.add('foo', 2)
    timers.add('foo', 3)
    assert timers.median('foo') == 2


# Generated at 2022-06-23 16:05:27.731691
# Unit test for method min of class Timers
def test_Timers_min():
    """test min function of Timers"""
    t = Timers()
    t.add("test", 1)
    assert t.min("test") == 1
    t.add("test", 2)
    assert t.min("test") == 1
    t.add("test", 0)
    assert t.min("test") == 0
    t.add("test", 2)
    assert t.min("test") == 0


# Generated at 2022-06-23 16:05:38.239371
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add("foo", 0.1)
    timers.add("bar", 0.2)
    timers.add("foo", 0.3)
    timers.add("baz", 0.5)
    assert timers.data == {"foo": 0.4, "bar": 0.2, "baz": 0.5}
    assert timers._timings == {
        "foo": [0.1, 0.3],
        "bar": [0.2],
        "baz": [0.5],
    }
    timers.clear()
    assert timers.data == {}
    assert timers._timings == collections.defaultdict(list)



# Generated at 2022-06-23 16:05:41.305786
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    assert Timers().stdev("toto") == math.nan



# Generated at 2022-06-23 16:05:51.744632
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for constructor of class Timers"""
    timers = Timers()
    # Timers is empty
    assert timers.count("unknown") == 0
    assert timers.total("unknown") == 0
    assert timers.min("unknown") == 0
    assert timers.max("unknown") == 0
    assert timers.mean("unknown") == 0
    assert timers.median("unknown") == 0
    assert timers.stdev("unknown") != timers.stdev("unknown")
    assert timers.count("unknown") == 0
    assert timers.total("unknown") == 0
    assert timers.min("unknown") == 0
    assert timers.max("unknown") == 0
    assert timers.mean("unknown") == 0
    assert timers.median("unknown") == 0
    assert timers.stdev("unknown") != timers.stdev("unknown")
    # Add

# Generated at 2022-06-23 16:05:56.502346
# Unit test for method mean of class Timers
def test_Timers_mean():
    assert Timers().mean("test") == 0
    assert Timers({"test": 42}).mean("test") == 42
    assert Timers({"test": 3}, test=[1, 2]).mean("test") == 4
    assert Timers(test=[1, 2]).mean("test") == 1.5


# Generated at 2022-06-23 16:06:05.800806
# Unit test for method clear of class Timers
def test_Timers_clear():
    # Create empty Timers object
    timers = Timers()
    # Assert that internal dictionaries are empty
    assert timers._timings == {}
    assert timers.data == {}
    # Add name and value to timers
    name = 'my-timer'
    value = 0.5
    timers.add(name, value)
    timers[name] = value
    # Assert that internal dictionaries are not empty
    assert timers._timings[name] == [value]
    assert timers.data[name] == value
    # Clear dictionaries
    timers.clear()
    # Assert that internal dictionaries are empty
    assert timers._timings == {}
    assert timers.data == {}

# Generated at 2022-06-23 16:06:11.486913
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test if the method __setitem__ of the class Timers is working correctly"""

    # Initialize the timer object
    timer = Timers()

    # Try to change the value of a timer
    def set_an_item_on_timer():
        timer['some_timer'] = 1.0

    # Check that the code raises an error as expected
    set_an_item_on_timer()

# Generated at 2022-06-23 16:06:15.811023
# Unit test for method apply of class Timers
def test_Timers_apply():
    def function(values): return sum(values)
    timers = Timers()
    timers._timings['test'] = range(10)
    assert timers.apply(function, name='test') == 45
    assert timers.apply(function, name='no_key') == 0

# Generated at 2022-06-23 16:06:20.356423
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("timer", 1)
    assert timers.max("timer") == 1
    timers.add("timer", 2)
    assert timers.max("timer") == 2

# Generated at 2022-06-23 16:06:24.784936
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    assert Timers().min("anything") == 0
    timer = Timers()
    timer.add("anything", 1)
    timer.add("anything", 2)
    assert timer.min("anything") == 1
    assert timer.min("whatever") == 0


# Generated at 2022-06-23 16:06:31.793473
# Unit test for method apply of class Timers
def test_Timers_apply():
    timers = Timers()
    timers.add('T1', 0)
    timers.add('T2', 0)
    timers.add('T2', 1)
    assert timers.apply(sum, name='T1') == 0
    assert timers.apply(sum, name='T2') == 1
    try:
        timers.apply(sum, name='T3')
    except KeyError:
        pass
    else:
        assert False


# Generated at 2022-06-23 16:06:34.969725
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add("cpu", 1)
    timers.add("cpu", 2)
    timers.add("cpu", 3)
    assert timers.count("cpu") == 3


# Generated at 2022-06-23 16:06:41.336482
# Unit test for method max of class Timers
def test_Timers_max():
    """Test max of Timers"""
    my_timers = Timers()
    my_timers.add('my_timer1', 50.0)
    my_timers.add('my_timer1', 100.0)
    result = my_timers.max('my_timer1')
    assert result == 100.0, (
        f"Expected 100, actual result '{result}' "
        f"in method max of class Timers."
    )


# Generated at 2022-06-23 16:06:43.886452
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    timers = Timers()
    timers.add('foo', 1)
    assert timers.min('foo') == 1

# Generated at 2022-06-23 16:06:47.453628
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    tm = Timers()
    tm.add("t1", 1)
    tm.add("t2", 2)
    assert tm.data == {"t1": 1, "t2": 2}


# Generated at 2022-06-23 16:06:53.188716
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("Name1", 1)
    timers.add("Name1", 3)
    assert timers.max("Name1") == 3
    assert timers.max("Name2") == 0


# Generated at 2022-06-23 16:06:59.978987
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    assert(Timers().max("Test_name") == 0)
    m = Timers()
    m.add("Test_name", 1)
    assert(m.max("Test_name") == 1)
    m.add("Test_name", 2)
    assert(m.max("Test_name") == 2)
    try:
        m.max("Invalid_name")
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-23 16:07:09.419291
# Unit test for method median of class Timers
def test_Timers_median():
    """Test Timers method median"""
    # Initialize test data
    # Timer name
    name = "test"
    # Test values for median calculation
    values = [-1, 2, 3, -2, 4, -3, 5]
    # Expected median
    expected_median = sorted(values)[len(values) // 2]

    # Initialize timers
    timer = Timers()

    # Add values to timer
    for value in values:
        timer.add(name=name, value=value)

    # Check if observed median is equal to expected value
    assert timer.median(name=name) == expected_median, \
        "Observed median differs from expected value."

# Generated at 2022-06-23 16:07:18.646463
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    # Test with empty timers
    timers = Timers()
    assert timers.mean("test") == 0
    # Test with single value
    timers = Timers()
    timers.add("test", 1)
    assert timers.mean("test") == 1
    # Test with multiple values
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.mean("test") == 2
    # Test with empty value
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 0)
    assert timers.mean("test") == 7 / 3
    # Test with nan value
    timers = Timers()
    timers

# Generated at 2022-06-23 16:07:24.681221
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add('foo', 1.5)
    assert len(timers) == 1
    timers.add('foo', 2.0)
    assert timers.mean('foo') == 1.75
    assert len(timers) == 1
    assert len(timers._timings) == 1
    assert len(timers._timings['foo']) == 2
    timers.clear()
    assert len(timers) == 0
    assert len(timers._timings) == 0


# Generated at 2022-06-23 16:07:34.235048
# Unit test for method max of class Timers
def test_Timers_max():
    a = Timers()
    assert a.max("T1") == 0.0
    a.add("T1", 1.0)
    assert a.max("T1") == 1.0
    a.add("T1", 1.0)
    assert a.max("T1") == 1.0
    a.add("T1", 2.0)
    assert a.max("T1") == 2.0
    assert a.max("T2") == 0.0
    a.add("T2", -3.0)
    assert a.max("T2") == -3.0
    try:
        a.max("T3")
        assert False
    except KeyError:
        assert True

# Generated at 2022-06-23 16:07:36.908820
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test method __setitem__ of class Timers"""
    timers = Timers()
    for var in range(4):
        with pytest.raises(TypeError):
            timers["var"] = var


# Generated at 2022-06-23 16:07:39.727638
# Unit test for method median of class Timers
def test_Timers_median():
    """Test for Timers.median(name)"""
    # pylint: disable=unused-argument
    timers = Timers()
    timers.add('Message', 1)
    timers.add('Message', 3)
    assert timers.median('Message') == 2


# Generated at 2022-06-23 16:07:40.788171
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Test method stdev of class Timers"""
    timers = Timers()
    assert timer

# Generated at 2022-06-23 16:07:45.252652
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test method clear of class Timers"""
    timers = Timers()
    timers.add('test', 1.1)
    timers.clear()
    assert timers.data == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:07:53.552133
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Check that clear() method works as intended"""
    timers = Timers()
    assert timers == {}  # pylint: disable=comparison-with-callable
    assert timers._timings == {}
    timers.add("foo", 1)
    timers.add("bar", 2)
    timers.add("foo", 3)
    timers.add("bar", 4)
    assert timers == {"foo": 4, "bar": 6}
    assert timers._timings == {"foo": [1, 3], "bar": [2, 4]}
    timers.clear()
    assert timers == {}
    assert timers._timings == {}


# Generated at 2022-06-23 16:08:05.114037
# Unit test for method apply of class Timers
def test_Timers_apply():
    """
    Test method apply of class Timers
    """
    timers = Timers()
    timers.add("timer1", 0.1)
    timers.add("timer2", 0.2)
    timers.add("timer1", 0.4)
    timers.add("timer2", 0.5)

    # For testing purposes, define a custom function
    #   which inverts the inputs
    def invert(values: List[float]) -> float:
        """Return inverted values"""
        return -max(values)

    # Test custom function
    assert timers.apply(invert, "timer1") == -0.4
    assert timers.apply(invert, "timer2") == -0.5
    assert timers.apply(invert, "timer3") == -0.0

    # Test other functions

# Generated at 2022-06-23 16:08:08.945041
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Test method __setitem__ of class Timers"""
    with pytest.raises(TypeError):
        Timers()["foo"] = 0


# Generated at 2022-06-23 16:08:15.617974
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    t = Timers()
    t.add("1",   8)
    t.add("1",  -8)
    t.add("1",  10)
    t.add("1", -10)
    assert t.stdev("1") == 0.0
    t.add("2", 1)
    t.add("2", 2)
    t.add("2", 3)
    t.add("2", 4)
    assert t.stdev("2") == 1.0

# Generated at 2022-06-23 16:08:19.854165
# Unit test for method count of class Timers
def test_Timers_count():
    timers = Timers()
    timers.add('test', 0.5)
    assert timers.count('test') == 1.0
    timers.add('test', 1.0)
    assert timers.count('test') == 2.0


# Generated at 2022-06-23 16:08:26.327745
# Unit test for method add of class Timers
def test_Timers_add():
    """Unit test for method add of class Timers"""
    timers = Timers()
    timers.add("time1", 100)
    timers.add("time1", 200)
    timers.add("time2", 200)
    assert timers.total("time1") == 300
    assert timers.total("time2") == 200

    try:
        timers.add("time3", 200)
    except TypeError:
        pass
    else:
        raise ValueError("Method add should not allow new key without value")



# Generated at 2022-06-23 16:08:29.944198
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""

    #Setup
    name = 't'
    t = Timers()
    t._timings = {name: [1,2,3]}

    # Exercise and verify
    assert t.max(name) == max(t._timings[name]), 'Case 1'



# Generated at 2022-06-23 16:08:38.279228
# Unit test for method count of class Timers
def test_Timers_count():
    # Initialize list of timing values
    timings = [1, 2, 3, 4, 5]

    # Initialize function to count timings
    counter = Timers()

    # Initialize expected value
    expected: Dict[str, float] = {'counter': 5}

    # Loop through list of timing values
    for timing in timings:
        # Add timing to counter
        counter.add("counter", timing)

    # Compare counter to the expected result
    assert counter == expected


# Generated at 2022-06-23 16:08:44.039291
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():
    """Unit test for method __setitem__ of class Timers"""
    # Create test object
    _ = Timers()
    # Check if a TypeError is raised when setting an item occurs
    try:
        _["test"] = 1
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 16:08:48.322715
# Unit test for method max of class Timers
def test_Timers_max():
    """Unit test for method max of class Timers"""
    timers = Timers()
    assert timers.max('timer') == 0
    timers.add('timer', 1.5)
    assert timers.max('timer') == 1.5
    
test_Timers_max()

# Generated at 2022-06-23 16:08:55.204475
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers = Timers()
    timers.add(name='test', value=1.0)
    assert timers.stdev('test') == 0.0
    timers.add(name='test', value=2.0)
    assert timers.stdev('test') == 0.5
    timers.add(name='test', value=4.0)
    assert timers.stdev('test') == math.sqrt(5.0 / 3)
    timers.add(name='test', value=5.0)
    assert timers.stdev('test') == math.sqrt(5.0 / 3)

# Generated at 2022-06-23 16:08:59.886708
# Unit test for method median of class Timers
def test_Timers_median():
    import random
    from statistics import median
    timers = Timers()
    timers.data["test"] = 0
    timers._timings["test"] = [round(random.gauss(5, 5), 2) for x in range(10000)]
    assert timers.median("test") == median(timers._timings["test"])

# Generated at 2022-06-23 16:09:02.207424
# Unit test for constructor of class Timers
def test_Timers():
    # Ensure initialization is correct
    timers = Timers()
    assert timers.data == {}
    assert timers._timings == {}



# Generated at 2022-06-23 16:09:06.522456
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""
    timers = Timers()
    timers.add('test', 5)
    timers.add('test', 10)
    timers.add('test', 20)
    assert timers.apply(len, name='test') == 3


# Generated at 2022-06-23 16:09:15.356744
# Unit test for method add of class Timers
def test_Timers_add():
    """Check that we can add and retrieve timing information"""
    timers = Timers()
    timers.add('test', 11)
    timers.add('test', 12)
    assert sorted(timers.items()) == [('test', 23)]
    assert timers.count('test') == 2
    assert timers.total('test') == 23
    assert timers.min('test') == 11
    assert timers.max('test') == 12
    assert timers.mean('test') == 11.5
    assert timers.median('test') == 11.5
    assert timers.stdev('test') == 0.5
    return

# Generated at 2022-06-23 16:09:21.834333
# Unit test for constructor of class Timers
def test_Timers():
    t = Timers()
    t.add("a", 42)
    t.add("b", 23)
    t.add("a", 0)
    assert isinstance(t["a"], float)
    assert t["a"] == 42
    assert isinstance(t["b"], float)
    assert t["b"] == 23
    assert "c" not in t
    assert t.count("a") == 2
    assert t.count("b") == 1
    assert t.count("c") == 0
    assert t.total("a") == 42
    assert t.total("b") == 23
    assert t.min("a") == 0
    assert t.max("a") == 42
    assert t.mean("b") == 23
    assert t.median("b") == 23
    assert t.stdev("a") > 0

# Generated at 2022-06-23 16:09:28.523579
# Unit test for method count of class Timers
def test_Timers_count():
    """Tests the count method of the Timers class"""
    # Set-up
    timers = Timers()
    timers._timings = {'foo': [1, 2, 3, 4], 'bar': [5, 6, 7]}

    # Test
    assert timers.count('foo') == 4
    assert timers.count('bar') == 3

    # Test missing key
    try:
        timers.count('foobar')
        pytest.fail("Called with missing key")
    except KeyError:
        pass



# Generated at 2022-06-23 16:09:33.610211
# Unit test for method clear of class Timers
def test_Timers_clear():
    # GIVEN: An instance of Timers
    timers = Timers()
    timers["timer1"] = 20.0
    timers.add("timer1", 1)
    timers.add("timer2", 1)

    # WHEN: clear is called
    timers.clear()

    # THEN: the timers shall be empty
    assert len(timers) == 0
    assert len(timers._timings) == 0
    assert timers.get("timer1") is None
    assert timers.get("timer2") is None


# Generated at 2022-06-23 16:09:41.187564
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Test method 'apply' of class 'Timers'"""
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.apply(len, name='test') == 3
    assert timers.apply(sum, name='test') == 6
    assert timers.apply(min, name='test') == 1
    assert timers.apply(max, name='test') == 3
    assert timers.apply(statistics.mean, name='test') == 2
    assert timers.apply(statistics.median, name='test') == 2
    assert timers.apply(statistics.stdev, name='test') == pytest.approx(0.81649658092772603)
    assert timers.total('test') == 6

# Generated at 2022-06-23 16:09:50.827790
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    # Check first of two entries
    x = Timers()
    x.add("A", 1)
    x.add("A", 2)
    assert x.stdev("A") == math.sqrt(2/3)

    # Check last of two entries
    x = Timers()
    x.add("A", 2)
    x.add("A", 1)
    assert x.stdev("A") == math.sqrt(2/3)

    # Check last of three entries
    x = Timers()
    x.add("A", 1)
    x.add("A", 2)
    x.add("A", 3)
    assert x.stdev("A") == math.sqrt(2/3)

    # Check last of three entries
    x = Timers()
    x.add("A", 1)

# Generated at 2022-06-23 16:09:59.099936
# Unit test for method __setitem__ of class Timers
def test_Timers___setitem__():

    from random import random

    timers = Timers()

    timers.add('timer1', random())
    timers.add('timer1', random())

    assert list(timers.items()) == [('timer1', timers.total('timer1'))]
    assert timers.total('timer1') == timers.data['timer1']

    try:
        timers['timer1'] = random()
    except TypeError:
        pass
    else:
        assert False, 'Expected TypeError'


# Generated at 2022-06-23 16:10:05.881426
# Unit test for method min of class Timers
def test_Timers_min():
    
    # Initialize a Timers object and add two timing values to 'foo'
    t = Timers()
    t.add('foo', 1)
    t.add('foo', 2)

    # Check that the result of calling t.min(name='foo') is 1
    assert t.min(name='foo') == 1



# Generated at 2022-06-23 16:10:09.814180
# Unit test for method max of class Timers
def test_Timers_max():
    """Test the function max of class Timers"""
    timer = Timers()
    assert timer.max("wait") == 0
    timer.add("wait", 5)
    assert timer.max("wait") == 5


# Generated at 2022-06-23 16:10:14.293851
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    assert len(timers) == 0
    assert len(timers._timings) == 0
    timers.add('Test', 1)
    assert len(timers) == 1
    assert len(timers._timings) == 1
    timers.clear()
    assert len(timers) == 0
    assert len(timers._timings) == 0


# Generated at 2022-06-23 16:10:18.033988
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    timers = Timers()
    for index in range(100):
        timers.add("timer", index)
    assert timers.data["timer"] == 4950
    assert sum(timers._timings["timer"]) == 4950


# Generated at 2022-06-23 16:10:21.511052
# Unit test for method clear of class Timers
def test_Timers_clear():
    a = Timers({'a': 1})
    b = Timers({'b': 1})
    a.add('a', 1)
    b.add('b', 1)
    assert a['a'] == 2
    assert b['b'] == 2
    a.clear()
    b.clear()
    assert a._timings == {}
    assert b._timings == {}
    assert a.data == {}
    assert b.data == {}


# Generated at 2022-06-23 16:10:27.047707
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test for class Timers - method clear."""
    _ = Timers() ("test")
    assert isinstance(Timers().clear(), None)
    assert dict(Timers()) == dict()
    assert dict(Timers()._timings) == dict()


# Generated at 2022-06-23 16:10:34.052787
# Unit test for method median of class Timers
def test_Timers_median():
    timings = Timers()

    # Case with some timing values
    timings._timings = {'A': [1, 2, 3, 4]}
    assert timings.median(name='A') == 2.5

    # Case with empty list of timing values
    timings._timings = {'B': [], 'C': [1], 'D': [1, 2, 3, 4, 5]}
    assert math.isnan(timings.median(name='B'))
    assert timings.median(name='C') == 1
    assert timings.median(name='D') == 3

# Generated at 2022-06-23 16:10:39.649441
# Unit test for method add of class Timers
def test_Timers_add():
    """Test method add of class Timers"""
    timer = Timers()
    timer.add("s", 2)
    assert timer.data["s"] == 2
    timer.add("s", 2)
    assert timer.data["s"] == 4
    assert timer._timings["s"] == [2, 2]


# Generated at 2022-06-23 16:10:44.568292
# Unit test for method total of class Timers
def test_Timers_total():
    """Unit test for method total of class Timers"""
    timers = Timers()
    timers.add("time1", 2)
    timers.add("time2", 1)
    assert timers.total("time1") == 2
    assert timers.total("time2") == 1



# Generated at 2022-06-23 16:10:49.888541
# Unit test for method clear of class Timers
def test_Timers_clear():
    import os
    import tempfile

    td = tempfile.TemporaryDirectory()
    timers = Timers({}, {'a': 1, 'b': 2})

    timers.add('a', 3)
    timers.add('b', 4)
    timers.add('b', 4)
    timers['c'] = 2
    timers['d'] = 2

    assert isinstance(timers, collections.UserDict)
    assert timers['a'] == 4
    assert timers['b'] == 10
    assert timers['c'] == 2
    assert timers['d'] == 2

    with open(os.path.join(td.name, "test_clear.json"), "w") as f:
        timers.save(f)

    timers.clear()
    assert timers['a'] == 0
    assert timers['b'] == 0
    assert timers

# Generated at 2022-06-23 16:10:59.627977
# Unit test for method apply of class Timers
def test_Timers_apply():
    """Unit test for method apply of class Timers"""

    timers = Timers()

    def func(values):
        return min(values)
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.apply(func, name="test") == 1

    def func(values):
        return max(values)
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.apply(func, name="test") == 3

    def func(values):
        return statistics.mean(values)
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    timers.add("test", 4)

# Generated at 2022-06-23 16:11:01.702920
# Unit test for constructor of class Timers
def test_Timers(): # pragma: no cover
    assert Timers() == collections.defaultdict(dict)


# Generated at 2022-06-23 16:11:04.863418
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    t._timings = {"test":[1,2]}
    t.median("test") == 1.5
    t._timings = {"test":[]}
    t.median("test") == 0

# Generated at 2022-06-23 16:11:09.509948
# Unit test for method median of class Timers
def test_Timers_median():
    """Test Timers.median()"""
    t = Timers()
    t.add('Test', 1)
    t.add('Test', 2)
    assert t.median('Test') == 1.5



# Generated at 2022-06-23 16:11:18.306822
# Unit test for constructor of class Timers
def test_Timers():
    """Unit test for Timers"""
    t = Timers()
    assert len(t) == 0
    assert len(t.keys()) == 0
    assert len(t.values()) == 0
    t.add("mytimer", 42)
    assert len(t) == 1
    assert len(t.keys()) == 1
    assert len(t.values()) == 1
    assert list(t.keys()) == ["mytimer"]
    assert list(t.values()) == [42]
    assert t["mytimer"] == 42
    assert t.data["mytimer"] == 42
    assert t.data == {"mytimer": 42}
    assert t._timings == {"mytimer": [42]}
    t.clear()
    assert len(t) == 0
    assert len(t.keys()) == 0

# Generated at 2022-06-23 16:11:22.569475
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    """Testing method stdev of class Timers."""
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 1)
    assert timers.stdev("test") == 0

test_Timers_stdev()

# Generated at 2022-06-23 16:11:29.951951
# Unit test for method max of class Timers
def test_Timers_max():
    from .sample_code import Timer, setup_timers
    from .timer import TimerContext
    timer, timers = setup_timers()
    with TimerContext(timer=timer):
        timers["first"] = Timer()
        with timers["first"]:
            time.sleep(0.1)
        time.sleep(0.2)
    assert 0.1 <= timers["first"].max() <= 0.101
    assert timers["first"].total() == 0.3
    assert timers[timer.name].total() == 0.3
    assert timers["first"].count() == 1
    assert timers["first"].name == "first"
    assert timers["first"].timer is timer

# Generated at 2022-06-23 16:11:32.985513
# Unit test for method clear of class Timers
def test_Timers_clear():
    timers = Timers()
    timers.add("alloc", 4.0)
    timers.clear()
    assert timers.data == {}
    assert timers._timings == {}



# Generated at 2022-06-23 16:11:38.971315
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 2.)
    assert timers.max("test") == 2.
    timers.add("test", 1.)
    assert timers.max("test") == 2.
    timers.add("test", 3.)
    assert timers.max("test") == 3.


# Generated at 2022-06-23 16:11:45.122137
# Unit test for method clear of class Timers
def test_Timers_clear():
    """Test clear method of class Timers"""
    timers = Timers()
    assert len(timers) == len(timers._timings) == 0
    timers.add("test", 0.123)
    assert len(timers) == len(timers._timings) == 1
    timers.clear()
    assert len(timers) == len(timers._timings) == 0


# Generated at 2022-06-23 16:11:52.130106
# Unit test for method min of class Timers
def test_Timers_min():
    # Setup
    x = Timers()
    # Exercise
    x.add("Timer1", 0.5)
    x.add("Timer1", 0.6)
    x.add("Timer2", 1.5)
    x.add("Timer2", 1.6)
    # Verify
    assert x.min("Timer1") == 0.5
    assert x.min("Timer2") == 1.5
    # Cleanup - None

