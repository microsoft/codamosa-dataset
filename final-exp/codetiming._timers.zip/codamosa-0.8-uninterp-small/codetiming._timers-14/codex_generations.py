

# Generated at 2022-06-25 15:11:42.939673
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    timers_1.add('first',  0.1)
    timers_1.add('second', 0.2)
    timers_1.add('third',  0.3)
    timers_1.add('first',  0.4)
    timers_1.add('second', 0.5)
    timers_1.add('third',  0.6)
    assert timers_1.max('first') == 0.4
    assert timers_1.max('second') == 0.5
    assert timers_1.max('third') == 0.6


# Generated at 2022-06-25 15:11:44.912420
# Unit test for method max of class Timers
def test_Timers_max():

    timers_0 = Timers()

    timers_0[Timers] = 1.55390746
    timers_0.apply(lambda values: max(values or [0]), name='0')



# Generated at 2022-06-25 15:11:46.244826
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_1 = Timers()
    timers_1.add('a', 2.38)


# Generated at 2022-06-25 15:11:51.363967
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert timers_0.min("a") == 0.0
    timers_0.add("a", 5.0)
    timers_0.add("a", 0.0)
    timers_0.add("a", -1.0)
    assert timers_0.min("a") == -1.0
    assert timers_0.min("b") == 0.0


# Generated at 2022-06-25 15:11:52.961499
# Unit test for method min of class Timers
def test_Timers_min():
    # Inizialize objects for testing
    # Test Timers.min() method
    assert True == True


# Generated at 2022-06-25 15:11:59.948840
# Unit test for method mean of class Timers
def test_Timers_mean():

    timers_1 = Timers()
    timers_1['x'] = 1
    timers_1['y'] = 2
    timers_1['z'] = 3

    assert timers_1.mean('x') == 1
    assert timers_1.mean('y') == 2
    assert timers_1.mean('z') == 3
    assert timers_1.mean('a') == 0

    timers_1['z'] = 0

    assert timers_1.mean('x') == 1
    assert timers_1.mean('y') == 2
    assert timers_1.mean('z') == 0
    assert timers_1.mean('a') == 0

    timers_2 = Timers()

    assert timers_2.mean('x') == 0
    assert timers_2.mean('y') == 0

# Generated at 2022-06-25 15:12:00.905337
# Unit test for method min of class Timers
def test_Timers_min():
    def test_case_0():
        timers_0 = Timers()


# Generated at 2022-06-25 15:12:03.778865
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    with pytest.raises(KeyError):
        t.median("timer1")
    t.add("timer1", 0.2)
    t.add("timer1", 0.25)
    assert t.median("timer1") == pytest.approx(0.225)


# Generated at 2022-06-25 15:12:05.814687
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    time_0 = timers_0.mean("test")
    assert math.isnan(time_0)


# Generated at 2022-06-25 15:12:09.859553
# Unit test for method max of class Timers
def test_Timers_max():
    """Test for the max method of class Timers"""
    timers_0 = Timers()
    timers_0.add("Key0", 1.0)
    assert timers_0.max("Key0") == 1
    timers_0.add("Key2", 3.0)
    assert timers_0.max("Key2") == 3
    timers_0.add("Key0", 4.0)
    assert timers_0.max("Key0") == 4


# Generated at 2022-06-25 15:12:23.454301
# Unit test for method min of class Timers
def test_Timers_min():
    # Instantiate class Timers
    timers_0 = Timers()

    # Try with data_1 not in timers_0
    try:
        timers_0.min(name='data_1')

    # Catch common exception
    except KeyError:
        pass

    # Instantiate class Timers
    timers_1 = Timers()

    # Add data_2 to timers_1
    timers_1.add(name='data_2',value=0.0)

    # Assert that timers_1.min(name='data_1') == 0
    assert timers_1.min(name='data_2') == 0

    # Instantiate class Timers
    timers_2 = Timers()

    # Add data_3 to timers_2
    timers_2.add(name='data_3',value=0.0)

    # Add

# Generated at 2022-06-25 15:12:30.920143
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert math.isnan(timers_0.median("0"))
    timers_0.add("0", 0.0)
    assert math.isnan(timers_0.median("0"))
    timers_0.add("0", 0.0)
    assert math.isnan(timers_0.median("0"))
    timers_0.add("A", 0.0)
    assert math.isnan(timers_0.median("0"))
    assert math.isnan(timers_0.median("A"))
    timers_0.add("0", 0.0)
    assert math.isnan(timers_0.median("0"))
    assert math.isnan(timers_0.median("A"))

# Generated at 2022-06-25 15:12:37.782580
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Arrange
    timers = Timers()
    name = "name"

    # Act
    timers.add(name=name, value=1)
    timers.add(name=name, value=2)
    timers.add(name=name, value=2)

    # Assert
    assert timers.mean(name=name) == 1.5


# Generated at 2022-06-25 15:12:39.917633
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    value_0 = timers_0.mean(name='unknown')
    assert math.isnan(value_0)


# Generated at 2022-06-25 15:12:42.896674
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    name_1 = "d"
    float_2 = timers_0.median(name_1)
    assert float_2 == 0.0



# Generated at 2022-06-25 15:12:45.021469
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    name = 'test'
    value = 0.0
    timers.add(name, value)
    res = timers.mean(name)


# Generated at 2022-06-25 15:12:48.654212
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert math.isnan(timers_0.min("key_0"))
    timers_0.add("key_0", 1.0)
    assert 1.0 == timers_0.min("key_0")
    assert math.isnan(timers_0.min("key_1"))


# Generated at 2022-06-25 15:12:51.991346
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    string_0 = "jV7y1gkq3v"
    float_0 = -5.5
    timers_0.add(string_0, float_0)
    float_1 = timers_0.min(string_0)
    assert (float_1 == float_0)


# Generated at 2022-06-25 15:12:53.432461
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    value_0 = timers_0.min("")
    assert value_0 == 0


# Generated at 2022-06-25 15:13:03.617021
# Unit test for method min of class Timers
def test_Timers_min():
    # Test with dict of integers
    timers_0 = Timers()
    key_0 = "key_0"
    value_0 = 1
    timers_0.add(key_0, value_0)
    key_1 = "key_1"
    value_1 = 2
    timers_0.add(key_1, value_1)
    key_2 = "key_2"
    value_2 = 3
    timers_0.add(key_2, value_2)
    key_3 = "key_3"
    value_3 = 4
    timers_0.add(key_3, value_3)
    exp = 1
    res = timers_0.min(key_3)
    assert res == exp

    # Test with dict of strings
    timers_1 = Timers()
    key_0

# Generated at 2022-06-25 15:13:10.768135
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    name_0 = "s"
    value_0 = 57.96772755881051
    timers_0.add(name_0, value_0)
    assert round(timers_0.median(name_0), 4) == 57.9677



# Generated at 2022-06-25 15:13:17.631794
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add(name='foo', value=0.25)
    timers.add(name='foo', value=0.25)
    timers.add(name='foo', value=0.25)
    timers.add(name='foo', value=0.25)
    timers.add(name='foo', value=0.25)
    assert timers.max(name='foo') == 0.25
    timers.add(name='foo', value=1.5)
    assert timers.max(name='foo') == 1.5
    timers.clear()
    timers.add(name='bar', value=1.5)
    assert timers.max(name='bar') == 1.5

# Generated at 2022-06-25 15:13:29.420818
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('name_2', 3.0)
    assert(timers_0.mean('name_2') == 3.0)
    timers_0.add('name_1', 1.0)
    assert(timers_0.mean('name_1') == 1.0)
    assert(timers_0.mean('bad_name') == 0.0)
    assert(timers_0.mean('') == 0.0)
    timers_0.add('name_3', 5.0)
    timers_0.add('name_3', 5.0)
    assert(timers_0.mean('name_3') == 5.0)
    timers_0.add('name_4', 7.0)

# Generated at 2022-06-25 15:13:33.238364
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('timer_0', 1.0)
    timers_0.add('timer_0', 2.0)
    assert timers_0.median('timer_0') == 1.5


# Generated at 2022-06-25 15:13:37.765592
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    timers_1.add(name='name_0', value=2)
    assert timers_1.max(name='name_0') == 2



# Generated at 2022-06-25 15:13:44.062271
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("name", 1)
    assert timers.max("name") == 1
    timers.add("name", 2)
    assert timers.max("name") == 2
    timers.add("name", 3)
    assert timers.max("name") == 3
    timers.add("name", 4)
    assert timers.max("name") == 4
    timers.add("name", 5)
    assert timers.max("name") == 5

if __name__ == '__main__':

    test_case_0()
    test_Timers_max()

# Generated at 2022-06-25 15:13:46.550284
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_1 = Timers()
    name = ""
    value = 0
    # Call method add of class Timers
    timers_0.add(name, value)
    # Call method mean of class Timers
    mean_result = timers_0.mean(name)

# Generated at 2022-06-25 15:13:51.547022
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('myTimer', 60)
    timers_0.add('myTimer', 40)
    timers_0.add('myTimer', 20)
    timers_1 = timers_0.max('myTimer')
    assert timers_1 == 60


# Generated at 2022-06-25 15:13:52.317133
# Unit test for method max of class Timers
def test_Timers_max():
    test_case_0()


# Generated at 2022-06-25 15:13:56.281469
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name, value = ("name: str", 0.0)
    timers_0.add(name, value)
    assert timers_0.min(name) == min(value)


# Generated at 2022-06-25 15:13:59.143912
# Unit test for method median of class Timers
def test_Timers_median():
    pass


# Generated at 2022-06-25 15:14:02.402630
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name_0 = ""
    value_0 = timers_0.min(name_0)


# Generated at 2022-06-25 15:14:05.023263
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers["test_1"] = 1.1
    assert timers.mean(name="test_1") == 1.1, "Timers.mean(name) failed"



# Generated at 2022-06-25 15:14:12.790371
# Unit test for method mean of class Timers
def test_Timers_mean():
    """
    Unit tests for methods:

    Timers.__init__(),
    Timers.__setitem__(),
    Timers.add(),
    Timers.apply(),
    Timers.clear(),
    Timers.count(),
    Timers.max(),
    Timers.mean(),
    Timers.median(),
    Timers.min(),
    Timers.stdev(),
    Timers.total()

    """
    timers = Timers()
    timers.add('test', 3)
    timers.add('test', 4)
    timers.add('test', 7)
    assert timers.mean('test') == 4.333333333333333
    assert timers.mean('test') == statistics.mean(timers._timings['test'])
    assert timers['test'] == 3 + 4 + 7
    assert timers.keys()

# Generated at 2022-06-25 15:14:15.026585
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name_0 = ""
    exception_0 = None
    try:
        timers_0.min(name_0)
    except Exception as exception_0:
        pass
    assert(exception_0 is not None)


# Generated at 2022-06-25 15:14:19.263058
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("foo", 0.8)
    timers_0.add("foo", 1.2)
    timers_0.add("foo", 2.0)
    exp_0 = 1.077
    result_0 = timers_0.median("foo")
    assert round(exp_0, 3) == round(result_0, 3)



# Generated at 2022-06-25 15:14:24.150264
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.mean("") == 0
    timers_0.add("", 0.0)
    assert timers_0.mean("") == 0
    timers_0.add("", 1.0)
    assert timers_0.mean("") == 0.5


# Generated at 2022-06-25 15:14:26.899529
# Unit test for method median of class Timers
def test_Timers_median():
    assert Timers().median("__main__.test_Timers_median.0") == 0


# Generated at 2022-06-25 15:14:30.696084
# Unit test for method mean of class Timers
def test_Timers_mean():
    name = "key"
    value = 3.14

    timers = Timers()
    timers.add(name, value)
    assert timers.mean(name) == value


# Generated at 2022-06-25 15:14:36.548257
# Unit test for method min of class Timers
def test_Timers_min():
    import numpy as np

    # Set up test object
    timers_0 = Timers()
    name_0 = 'name'
    for _ in range(1000):
        timers_0.add(name_0, np.random.randn())
    result_0 = timers_0.min(name=name_0)
    result_1 = timers_0.apply(lambda values: min(values or [0]), name=name_0)

    assert result_0 == result_1
    assert not (result_0 != result_1)



# Generated at 2022-06-25 15:14:47.879889
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()

    with pytest.raises(KeyError):
        timers_0.median(name="i2jd")

    # Check that the generated error message contains the given string
    with pytest.raises(KeyError, match="i2jd"):
        timers_0.median(name="i2jd")


# Generated at 2022-06-25 15:14:53.296607
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add('timers_1', 19)
    timers_1.add('timers_1', 68)
    timers_1.add('timers_1', 52)
    timers_1.add('timers_1', 11)
    timers_1.add('timers_1', 51)
    assert timers_1.mean('timers_1') == 39


# Generated at 2022-06-25 15:14:55.597815
# Unit test for method mean of class Timers
def test_Timers_mean():
    timer = Timers()
    timer.add('timer_0', 99.5)
    assert timer.mean('timer_0') == 99.5


# Generated at 2022-06-25 15:15:04.221969
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0 = Timers()
    timers_1 = Timers()
    timers_1 = Timers()
    timers_0._timings = collections.defaultdict(list, {str('a'): [float(0.0), float(0.0), float(0.0), float(0.0), float(0.0), float(0.0), float(0.0), float(0.0), float(0.0), float(0.0), float(0.0), float(0.0), float(0.0), float(0.0), float(0.0), float(0.0)]})

# Generated at 2022-06-25 15:15:07.687957
# Unit test for method max of class Timers
def test_Timers_max():
    for i in range(10):
        timers_0 = Timers()
        timers_0.add("name_0", 1.0)
        assert timers_0.max("name_0") == 1.0


# Generated at 2022-06-25 15:15:18.469444
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.data.clear()
    assert timers_0.data == {}
    timers_0.add('key0', 0.472798)
    timers_0.add('key1', 0.72798)
    timers_0.add('key2', 0.472798)
    timers_0.add('key3', 0.72798)
    timers_0.add('key4', 0.472798)
    timers_0.add('key5', 0.72798)
    timers_0.add('key6', 0.472798)
    timers_0.add('key7', 0.72798)
    timers_0.add('key8', 0.472798)
    timers_0.add('key9', 0.72798)

# Generated at 2022-06-25 15:15:19.621653
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.max('Timer_0') == 0


# Generated at 2022-06-25 15:15:23.251785
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.apply(lambda x: x, name='_')
    timers_0.apply(lambda x: x, name='_')
    timers_0.apply(lambda x: x, name='_')


# Generated at 2022-06-25 15:15:26.238636
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers({'A': 1, 'B': 2})
    assert timers_1.min('A') == 1
    assert timers_1.min('B') == 2


# Generated at 2022-06-25 15:15:31.837955
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    dict_1 = dict()
    dict_1['foo'] = 3
    timers_1 = Timers(dict_1)
    timers_1.add('foo', 3)
    timers_1.add('foo', 1)
    assert 0 == timers_0.median('foo')
    assert 2 == timers_1.median('foo')



# Generated at 2022-06-25 15:15:40.830603
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.data["name"] = 6.0
    timers_0.apply(lambda values: statistics.median(values or [0]), "name")


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:15:48.299815
# Unit test for method mean of class Timers
def test_Timers_mean():
    '''
    Test for Timers.mean
    '''
    timers_0 = Timers()
    assert math.isnan(timers_0.mean('key_0'))
    timers_0 = Timers()
    timers_0.add('key_0', (1.0 if (0 + 1) % 2 > 0 else 1.0))
    assert 1.0 == timers_0.mean('key_0')
    timers_0.add('key_0', 1.0)
    assert 1.0 == timers_0.mean('key_0')
    timers_0.add('key_0', (1.0 if (0 + 1) % 2 > 0 else 1.0))
    assert 1.0 == timers_0.mean('key_0')



# Generated at 2022-06-25 15:15:50.900685
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    name: str = "timer_name"
    value = 1.0

    timers.add(name, value)

    assert timers.min(name) == value


# Generated at 2022-06-25 15:15:54.485274
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('foo', 1)
    timers_0.add('foo', 2)
    timers_0.add('bar', 0)

    assert timers_0.min('foo') == 1
    assert timers_0.min('bar') == 0

# Generated at 2022-06-25 15:15:59.902822
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    assert timers_1.mean("timer") == 0.0

    timers_1.add("timer", 2.0)
    assert timers_1.mean("timer") == 2.0

    timers_1.add("timer", 3.0)
    assert timers_1.mean("timer") == 2.5

    timers_1.add("timer", 4.0)
    assert timers_1.mean("timer") == 3.0



# Generated at 2022-06-25 15:16:01.404035
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert not timers_0.median(name = str())


# Generated at 2022-06-25 15:16:04.329453
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    try:
        timers_0.max("Gk-u)pKG!x")
        assert False  # pragma: no cover
    except KeyError:
        pass


# Generated at 2022-06-25 15:16:08.403635
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()

    # Case default
    timers.data = {'a': 1, 'b': 2, 'c': 2.5}
    assert timers.max('b') == 2

    # Case missing
    try:
        timers.max('d')
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 15:16:13.328898
# Unit test for method min of class Timers
def test_Timers_min():
    """Dictionary-like structure with information about timers"""
    assert Timers().min(name='timer_0') == 0
    assert Timers().max(name='timer_0') == 0
    assert Timers().mean(name='timer_0') == 0
    assert Timers().median(name='timer_0') == 0
    assert Timers().stdev(name='timer_0') == 0



# Generated at 2022-06-25 15:16:18.640008
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_1 = Timers()


# Generated at 2022-06-25 15:16:29.526234
# Unit test for method min of class Timers
def test_Timers_min():
    from Timer import Timer
    timers = Timers()
    timers.add('min', 30)
    print('min is {}'.format(timers.min('min')))
    timers.add('min', 23)
    print('min is {}'.format(timers.min('min')))
    timers.add('min', 23)
    print('min is {}'.format(timers.min('min')))
    timers.add('min', 10)
    print('min is {}'.format(timers.min('min')))
    timers.add('min', 60)
    print('min is {}'.format(timers.min('min')))



# Generated at 2022-06-25 15:16:37.147356
# Unit test for method min of class Timers
def test_Timers_min():
    # Create instances of class Timers
    timers_0 = Timers()
    timers_0.add("1", 0.0)
    # Create a dictionary for the argument of Timers.__init__
    arg_dict = {
        "1": 0.0
    }
    timers_1 = Timers(**arg_dict)
    timers_1.add("1", 0.0)
    assert isinstance(timers_0.min("1"), float)
    assert isinstance(timers_1.min("1"), float)


# Generated at 2022-06-25 15:16:43.058506
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test_0', 5.6)
    timers.add('test_0', 9.4)
    timers.add('test_0', 0.6)
    timers.add('test_0', 5.3)
    timers.add('test_1', 3.2)
    timers.add('test_1', 2.4)
    timers.add('test_1', 9.7)
    assert timers.max('test_0') == 9.4
    timers.add('test_1', 1.0)
    timers.add('test_1', 3.2)
    timers.add('test_1', 1.8)
    timers.add('test_1', 7.0)
    timers.add('test_1', 4.0)

# Generated at 2022-06-25 15:16:48.754690
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()

    timers.add("m", 1)
    timers.add("m", 2)
    timers.add("m", 3)
    timers.add("m", 4)

    test.equal(timers.median("m"), 2)
    timers.data["m"] = 3
    test.equal(timers.median("m"), 2.5)


test_case_0()
test_Timers_median()

# Generated at 2022-06-25 15:16:52.868007
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("name", 2.09)
    assert math.isclose(timers_0.mean("name"), 2.09, rel_tol=1e-05)


# Generated at 2022-06-25 15:16:54.807831
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name = str()
    assert timers_0.mean(name) == 0.0


# Generated at 2022-06-25 15:16:59.389245
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("a", 5)
    timers.add("a", 5)
    assert timers.median("a") == 5
    timers.add("b", 0)
    timers.add("b", 5)
    assert timers.median("b") == 2.5



# Generated at 2022-06-25 15:17:08.123295
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    assert timers_0.max("name") == 0


# Generated at 2022-06-25 15:17:16.246040
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0["error"] = "error_0"
    timers_0.add("exception", -1.0)
    timers_0.add("exception", 1.0)
    with raises(KeyError):
        timers_0.median("error")
    with raises(KeyError):
        timers_0.median("exception")
    timers_0.add("failure", 1.0)
    timers_0.add("success", 1.0)
    timers_0.add("success_0", 0.0)
    assert timers_0.median("exception") == 0.0
    assert timers_0.median("success") == 1.0
    assert timers_0.median("success_0") == 0.0

# Generated at 2022-06-25 15:17:21.463656
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("timer_0", 1.0)
    timers.add("timer_0", 2.0)
    timers.add("timer_0", 3.0)
    assert (type(timers.mean("timer_0")) == float)


# Generated at 2022-06-25 15:17:34.695579
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1.add("foo", 5.0)
    timers_1.add("foo", 7.0)
    expected_result_1 = 5.0
    actual_result_1 = timers_1.min("foo")
    assert actual_result_1 == expected_result_1

# Generated at 2022-06-25 15:17:39.190637
# Unit test for method median of class Timers
def test_Timers_median():
    """Test of method median of class Timers"""

    timers_0 = Timers()
    timers_0.add("A", 0.01)
    timers_0.add("B", 0.02)
    timers_0.add("C", 0.03)
    timers_0.add("D", 0.04)
    timers_0.add("E", 0.05)
#    assert timers_0.median("A") == 0.01
    assert timers_0.median("B") == 0.02
    assert timers_0.median("C") == 0.03
    assert timers_0.median("D") == 0.04
#    assert timers_0.median("E") == 0.05

    timers_1 = Timers()
    timers_1.add("A", 0.05)
    timers_

# Generated at 2022-06-25 15:17:47.380890
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.apply(lambda values: max(values or [0]), name = "")
    timers_0.apply(lambda values: min(values or [0]), name = "")
    timers_0.apply(sum, name = "")
    timers_0.apply(len, name = "")
    timers_0.apply(statistics.median, name = "")
    timers_0.apply(statistics.mean, name = "")
    timers_0.apply(statistics.stdev, name = "")
    timers_0.clear()
    timers_0.count("")
    timers_0.max("")
    timers_0.median("")
    timers_0.min("")
    timers_0.stdev("")
    timers_0.total("")

# Generated at 2022-06-25 15:17:55.942482
# Unit test for method min of class Timers
def test_Timers_min():
    """
    Unit test for the min method of class Timers
    """
    # initialize the timers_0 object
    timers_0 = Timers()

    # create a list of the values to be used
    values = [1, 2, 3, 4, 5]
    for value in values:
        timers_0.add("test", value)

    # get the values from the timer and check that they're correct
    assert timers_0.total("test") == sum(values)
    assert timers_0.min("test") == min(values)
    assert timers_0.max("test") == max(values)
    assert timers_0.mean("test") == statistics.mean(values)
    assert timers_0.median("test") == statistics.median(values)
    assert timers_0.stdev("test") == statistics.stdev

# Generated at 2022-06-25 15:18:07.288810
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("x", 4.36);
    timers_0.add("x", 3.90);
    timers_0.add("x", 0.33);
    timers_0.add("x", 6.45);
    timers_0.add("x", 7.67);
    timers_0.add("x", 8.41);
    timers_0.add("x", 1.97);
    timers_0.add("x", 5.57);
    timers_0.add("x", 7.23);
    timers_0.add("x", 3.21);
    testers = Timers()
    testers.add("x", 4.36);
    testers.add("x", 3.90);
    testers.add("x", 0.33);

# Generated at 2022-06-25 15:18:10.122463
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.apply(min, name="")
    timers_0.apply(min, name="")


# Generated at 2022-06-25 15:18:19.290930
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()

    assert timers_1.max('foo') == 0.0
    timers_1.add('foo', 1.0)
    timers_1.add('foo', 2.0)
    assert timers_1.max('foo') == 2.0
    timers_1.add('bar', 1.0)
    timers_1.add('bar', 2.0)
    timers_1.add('bar', 3.0)
    assert timers_1.max('bar') == 3.0
    assert timers_1.max('baz') == 0.0
    timers_1.add('baz', 2.0)
    assert timers_1.max('baz') == 2.0
    with TypeError():
        timers_1['foo'] = 0.0
        timers_1['bar'] = 0.

# Generated at 2022-06-25 15:18:23.705922
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert timers_0.median(name="fire") == 0, "Method 'median' not working for an empty instance"
    timers_0.add(name="tiger", value=8.89)
    timers_0.add(name="tiger", value=8.25)
    assert timers_0.median(name="tiger") == 8.25, "Method 'median' not working"



# Generated at 2022-06-25 15:18:25.003194
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert timers_0.median('b') == 0


# Generated at 2022-06-25 15:18:34.178551
# Unit test for method max of class Timers
def test_Timers_max():
    # Arrange
    timers_0 = Timers()

    # Act
    timers_0.add('name1', value=29.095)
    timers_0.add('name1', value=65.235)
    timers_0.add('name1', value=30.825)
    timers_0.add('name1', value=31.86)
    timers_0.add('name1', value=71.345)
    timers_0.add('name1', value=59.595)
    timers_0.add('name1', value=25.835)
    timers_0.add('name1', value=50.805)
    timers_0.add('name1', value=65.785)
    timers_0.add('name1', value=6.395)

# Generated at 2022-06-25 15:18:57.909552
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add('a', 1)
    timers_1.add('a', 1)
    assert timers_1.mean('a') == 1



# Generated at 2022-06-25 15:19:01.553005
# Unit test for method min of class Timers
def test_Timers_min():
    print("Testing 'min'")
    # Verify default value
    timers_0 = Timers()
    assert timers_0.min("foobar") == 0
    # Add some timing data
    timers_0.add("foobar", 1)
    timers_0.add("foobar", 2)
    timers_0.add("foobar", 3)
    timers_0.add("foobar", 4)
    timers_0.add("foobar", 5)
    # Verify the result
    assert timers_0.min("foobar") == min([1, 2, 3, 4, 5])

if __name__ == "__main__":
    test_case_0()
    test_Timers_min()

# Generated at 2022-06-25 15:19:08.252917
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()

    # 0. Timers
    timers.add('Timer 1', 0.1)
    timers.add('Timer 2', 0.2)
    timers.add('Timer 1', 0.3)
    timers.add('Timer 1', 0.0)

    # 1. Get max.
    assert (timers.max('Timer 1') == 0.3)
    assert (timers.max('Timer 2') == 0.2)

    # 2. Try get max for non-existing timer.
    try:
        timers.max('Timer 3')
    except KeyError:
        pass
    else:
        assert False


# Generated at 2022-06-25 15:19:15.308451
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert isinstance(timers_0, Timers)
    timers_0.add("vca8", 26.725)
    timers_0.add("vca8", 27.771)
    timers_0.add("vca8", 26.457)
    assert timers_0.max("vca8") == 27.771
    timers_0.add("vca8", 25.922)
    timers_0.add("vca8", 25.636)


# Generated at 2022-06-25 15:19:19.164778
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add(name='thing', value=5)
    assert timers_1.mean(name='thing') == 5
    timers_2 = Timers()
    timers_2.add(name='thing', value=5)
    timers_2.add(name='thing', value=5)
    assert timers_2.mean(name='thing') == 5


# Generated at 2022-06-25 15:19:23.567956
# Unit test for method median of class Timers
def test_Timers_median():
    # Test cases and expected results
    test_cases = [

    ]
    for inputs, expected in test_cases:
        try:
            assert expected == Timers(*inputs).median(*inputs)
        except AssertionError:
            print(f"FAIL: median({inputs!r}) should be {expected!r}")


# Generated at 2022-06-25 15:19:26.245368
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("name_0", 0.0)
    assert (timers_0.median("name_0") == 0.0)


# Generated at 2022-06-25 15:19:29.501061
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.max("")
    # raise TypeError(
    #     f"{self.__class__.__name__!r} does not support item assignment. "
    #     "Use '.add()' to update values."
    # )


# Generated at 2022-06-25 15:19:36.838815
# Unit test for method min of class Timers
def test_Timers_min():

    # Test case 0
    timers_0 = Timers()
    try:
        timers_0.min("test")
    except KeyError:
        pass

    # Test case 1
    timers_1 = Timers()
    timers_1.add("test", 5)
    assert timers_1.mean("test") == 5

    # Test case 2
    timers_2 = Timers()
    timers_2.add("test", 5)
    timers_2.add("test", 3)
    timers_2.add("test", 1)
    assert timers_2.mean("test") == 3

    # Test case 3
    timers_3 = Timers()
    timers_3.add("test", -5)
    timers_3.add("test", -3)
    timers_3.add("test", -1)
    assert timers

# Generated at 2022-06-25 15:19:47.539221
# Unit test for method min of class Timers
def test_Timers_min():
    assert Timers().min("") == 0, "min('',) == 0"
    assert Timers({"a": 1}).min("a") == 0, "min('a',) == 0"
    assert Timers({"a": 1}).min("b") == 0, "min('b',) == 0"
    timers_1 = Timers({"a": 1})
    timers_1.add("a", 0.1)
    timers_1.add("a", 0.2)
    assert timers_1.min("a") == 0.1, "min('a',) == 0.1"
    timers_2 = Timers()
    timers_2.add("a", 1)
    timers_2.add("b", 2)
    timers_2.add("b", 3)

# Generated at 2022-06-25 15:20:15.115871
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    timers_1.add('a', 1)
    timers_1.add('a', 2)
    timers_1.add('a', -3)
    timers_1.add('b', 4)
    timers_1.add('b', -5)

    assert timers_1.max('a') == 2
    assert timers_1.max('b') == 4
    assert timers_1.count('a') == 3
    assert timers_1.count('b') == 2



# Generated at 2022-06-25 15:20:17.911328
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.median("name_0")
    timers_0.add("name_0", 2.0)
    timers_0.median("name_0")


# Generated at 2022-06-25 15:20:23.162031
# Unit test for method median of class Timers
def test_Timers_median():
    # Test with sample a
    timers_1 = Timers()
    timers_1.add('a', 0.3)
    timers_1.add('a', 1.8)
    timers_1.add('a', 2.5)
    timers_1.add('a', 3.9)
    assert timers_1.median('a') == 2.5
    # Test with sample b (odd number of values)
    timers_2 = Timers()
    timers_2.add('b', 0)
    timers_2.add('b', 1)
    timers_2.add('b', 1)
    timers_2.add('b', 2)
    timers_2.add('b', 3)
    timers_2.add('b', 4)
    assert timers_2.median('b') == 2
    # Test

# Generated at 2022-06-25 15:20:30.965003
# Unit test for method max of class Timers
def test_Timers_max():
    # Check default value is 0 (provide no input)
    timers_1 = Timers()
    max_1 = timers_1.max('test')
    # Check max value is correct (provide one timing)
    timers_2 = Timers()
    timers_2.add('test', 10.0)
    max_2 = timers_2.max('test')
    # Check max value is correct (provide multiple timings)
    timers_3 = Timers()
    timers_3.add('test', 10.0)
    timers_3.add('test', 20.0)
    timers_3.add('test', 15.0)
    max_3 = timers_3.max('test')


# Generated at 2022-06-25 15:20:32.637025
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 4.0)
    timers.add("test", 6.0)
    timers.add("test", 8.0)
    assert timers.max('test') == 8.0


# Generated at 2022-06-25 15:20:42.320758
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('xzkqxkqnplo', 17.905547020303634)
    timers_0.add('xzkqxkqnplo', 21.625384132913103)
    timers_0.add('xzkqxkqnplo', 5.108678429539144)
    timers_0.add('xzkqxkqnplo', 18.063455439530133)
    timers_0.add('xzkqxkqnplo', 5.644588870193963)
    timers_0.add('xzkqxkqnplo', 7.285340122873555)

# Generated at 2022-06-25 15:20:49.570718
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()

    timers.add('Timer 0', 1.0)
    timers.add('Timer 0', 1.0)
    timers.add('Timer 0', 2.0)
    timers.add('Timer 1', 2.0)
    timers.add('Timer 1', 2.0)
    expected = 1.5
    actual = timers.mean('Timer 0')
    actual1 = timers.mean('Timer 1')

    assert expected == actual, "mean of Timer 0"
    assert actual1 == actual, "mean of Timer 1"


# Generated at 2022-06-25 15:20:54.553397
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_1 = Timers()
    timers_0.add("timer_0", 1.0)
    timers_0.add("timer_0", 2.0)
    timers_1.add("timer_0", 3.0)
    timers_1.add("timer_0", 4.0)
    timers_1.add("timer_0", 5.0)
    assert timers_0.median("timer_0") == 1.5
    assert timers_1.median("timer_0") == 4.0

test_case_0()
test_Timers_median()

# Generated at 2022-06-25 15:20:59.068751
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test for the Timers.mean method"""
    timers_0 = Timers()
    timers_0.data[str()] = 0.0
    name_0 = str()
    value_0 = float()
    timers_0.add(name_0, value_0)
    assert Timers.mean(timers_0, name_0) == 0.0


# Generated at 2022-06-25 15:21:00.248423
# Unit test for method median of class Timers
def test_Timers_median():
    assert Timers().mean("foo") == 0
