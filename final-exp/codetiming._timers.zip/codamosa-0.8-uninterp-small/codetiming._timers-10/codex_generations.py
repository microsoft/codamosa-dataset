

# Generated at 2022-06-25 15:11:46.145165
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add('timer_0', 0.6)
    timers_1.add('timer_0', 0.1)
    timers_1.add('timer_0', 0.5)
    assert round(timers_1.mean('timer_0'), 2) == 0.36
    timers_1.min('timer_0')
    timers_1.count('timer_0')
    timers_1.max('timer_0')
    timers_1.median('timer_0')
    timers_1.stdev('timer_0')
    timers_1.total('timer_0')
    assert round(timers_1.mean('timer_1'), 2) == 0.00
    timers_1.min('timer_1')
    timers_1.count('timer_1')


# Generated at 2022-06-25 15:11:47.512266
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.max(0) == 0


# Generated at 2022-06-25 15:11:54.705451
# Unit test for method mean of class Timers
def test_Timers_mean():
    inp = Timers()
    for _ in range(50):
        inp.add('a', 0.8)
        inp.add('a', 0.2)
        inp.add('a', 0.5)
        inp.add('a', 1.0)
    inp.add('b', 0.2)
    inp.add('b', 0.1)
    out = inp.mean('a')
    assert out == 0.6
    out = inp.mean('b')
    assert out == 0.15000000000000002

# Generated at 2022-06-25 15:11:57.829425
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('asdf', float('nan'))
    timers_0.max('asdf')
    assert timers_0.max('asdf') == float('nan')


if __name__ == '__main__':
    test_case_0()
    test_Timers_max()

# Generated at 2022-06-25 15:12:01.190334
# Unit test for method max of class Timers
def test_Timers_max():
    arg_0 = Timers()
    
    arg_2 = 'name'
    arg_0.add(arg_2, 3.0)
    arg_0.add(arg_2, 2.0)
    arg_0.add(arg_2, 5.0)
    
    res_0 = arg_0.max(arg_2)
    res_1 = 3.0
    assert res_0 == res_1


# Generated at 2022-06-25 15:12:08.137207
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers({'foo': 10, 'bar': 20, 'baz': 0, 'boo': 0, 'foobarbaz': 0})
    assert 0 == timers_0.min('baz')
    assert 0 == timers_0.min('foobarbaz')
    assert 10 == timers_0.min('foo')
    assert 20 == timers_0.min('bar')
    assert 0 == timers_0.min('boo')
    timers_0.add('foo', 20)
    timers_0.add('bar', 5)
    timers_0.add('baz', 10)
    timers_0.add('boo', 30)
    timers_0.add('foobarbaz', 0)
    assert 0 == timers_0.min('baz')

# Generated at 2022-06-25 15:12:11.543748
# Unit test for method max of class Timers
def test_Timers_max():
    # New instance of class Timers
    timers = Timers()
    # First call of 'max' method on instance timers
    timers.max('a')
    # Second call of 'max' method on instance timers
    timers.max('b')
    timers.add('c', 15.5)
    # Next call of 'max' method on instance timers
    timers.max('c')

# Generated at 2022-06-25 15:12:20.253002
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('timer1', 0.0015318000000000)
    assert not math.isclose(
        timers_0.mean('timer1'),
        0.0015318000000000,
        rel_tol=1e-06,
        abs_tol=0.0
    )
    timers_1 = Timers()
    timers_1.add('timer2', 0.019260600000001)
    assert math.isclose(
        timers_1.mean('timer2'),
        0.019260600000001,
        rel_tol=1e-06,
        abs_tol=0.0
    )


# Generated at 2022-06-25 15:12:28.929960
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert timers_0.mean("timers_0") == 0.0
    timers_0.add("timers_0", 0.0)
    assert timers_0.mean("timers_0") == 0.0
    timers_0.add("timers_0", 0.0)
    assert timers_0.mean("timers_0") == 0.0
    timers_0.add("timers_0", 0.0)
    assert timers_0.mean("timers_0") == 0.0
    timers_0.add("timers_0", 0.0)
    assert timers_0.mean("timers_0") == 0.0
    timers_0.add("timers_0", 0.0)
    assert timers_0.mean("timers_0") == 0

# Generated at 2022-06-25 15:12:34.308770
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""
    timers_0 = Timers()
    timers_0.data = {'name_0': -16}
    # AssertionError: 0.0 != -16.0
    assert timers_0.min('name_0') == 0.0
    timers_0.data = {'name_0': 6}
    # AssertionError: 6.0 != -16.0
    assert timers_0.min('name_0') == 6.0
    timers_0.data = {'name_0': -7}
    # AssertionError: -7.0 != -16.0
    assert timers_0.min('name_0') == -7.0
    timers_0.add('name_0', -26)

# Generated at 2022-06-25 15:12:41.116838
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    counters = [0, 1, 2, 0, 1, 2, 0, 1, 2]
    values = [0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0]
    for counter, value in zip(counters, values):
        timers_0["timer " + str(counter)] = value
    assert timers_0.count("timer 0") == 3
    assert timers_0.count("timer 1") == 3
    assert timers_0.count("timer 2") == 3
    assert timers_0.total("timer 0") == 3.0
    assert timers_0.total("timer 1") == 12.0
    assert timers_0.total("timer 2") == 27.0
    assert timers_0.min

# Generated at 2022-06-25 15:12:44.063773
# Unit test for method min of class Timers
def test_Timers_min():
    """
    Timers.min(name)
    """
    timers_0 = Timers()
    timers_0.add("key1", 1.01)
    timers_0.add("key0", 1.01)
    return timers_0.min("key0")



# Generated at 2022-06-25 15:12:49.334857
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name_0 = str()
    value_0 = 1
    timers_0.add(name_0, value_0)
    value_1 = 0
    timers_0.add(name_0, value_1)
    value_2 = timers_0.min(name_0)
    value_3 = 1
    assert value_2 == value_3


# Generated at 2022-06-25 15:12:53.688252
# Unit test for method max of class Timers
def test_Timers_max():
    """Check that 'max' returns the maximal value of timings"""
    timers_0 = Timers()
    timers_0.add("a", 1)
    timers_0.add("a", 2)
    timers_0.add("a", 3)
    timers_0.add("b", 10)
    assert timers_0.max("a") == 3
    assert timers_0.max("b") == 10


# Generated at 2022-06-25 15:12:59.243187
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.add('foo', 0.8)
    timers_1.add('foo', 0.9)
    timers_1.add('foo', 0.7)
    return timers_1.median('foo') == 0.8


# Generated at 2022-06-25 15:13:01.149283
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.max("P") == 0

# Generated at 2022-06-25 15:13:03.087802
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    assert timers.min("test_timer") == 0.0


# Generated at 2022-06-25 15:13:05.043962
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name = ''
    style_0 = timers_0.max(name)


# Generated at 2022-06-25 15:13:09.392360
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    try:
        timers_1.max('key_0')
        assert False
    except KeyError:
        pass
    timers_2 = Timers()
    timers_2.add('key_1', 0.0)
    assert timers_2.max('key_1') == 0.0


# Generated at 2022-06-25 15:13:13.412154
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name = "Timer"
    assert math.isnan(timers_0.min(name))
    timers_0["Timer"] = 0.0
    assert timers_0.min(name) == 0.0


# Generated at 2022-06-25 15:13:27.403927
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('sut_0', 3)
    timers_0.add('sut_0', 4)
    timers_0.add('sut_0', 5)
    timers_0.add('sut_0', 8)
    timers_0.add('sut_0', 10)
    timers_0.add('sut_0', 12)
    timers_0.add('sut_1', 3)
    timers_0.add('sut_1', 4)
    timers_0.add('sut_1', 7)
    assert timers_0.median('sut_0') == 6
    assert timers_0.median('sut_1') == 4


# Generated at 2022-06-25 15:13:33.111610
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("timer_0", 1)
    timers_0.add("timer_0", 1)
    timers_0.add("timer_1", 1)
    value_0 = timers_0.max("timer_0")
    value_1 = timers_0.max("timer_2")
    assert (value_0 == 1 and value_1 == 0)



# Generated at 2022-06-25 15:13:43.778594
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name = None
    with pytest.raises(TypeError):
        timers_0.mean(name)
    name = None
    with pytest.raises(TypeError):
        timers_0.max(name)
    name = None
    with pytest.raises(TypeError):
        timers_0.median(name)
    name = None
    with pytest.raises(TypeError):
        timers_0.min(name)
    name = None
    with pytest.raises(TypeError):
        timers_0.stdev(name)
    name = None
    with pytest.raises(TypeError):
        timers_0.total(name)
    name = None
    with pytest.raises(TypeError):
        timers_0.count(name)

# Generated at 2022-06-25 15:13:54.077784
# Unit test for method median of class Timers

# Generated at 2022-06-25 15:14:02.287606
# Unit test for method min of class Timers
def test_Timers_min():
    import os
    import random
    import sys
    import pytest

    path = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, path)
    import timer

    @timer.timer
    def foo():
        pass

    # test min, max, median and mean on empty dictionary
    timers_0 = Timers()


# Generated at 2022-06-25 15:14:10.758828
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_2 = Timers()
    timers_3 = Timers()
    timers_4 = Timers()
    timers_5 = Timers()
    timers_1.add('n', 1.1)
    timers_2.add('n', 0.0)
    timers_3.add('n', 1.1)
    timers_3.add('n', 0.0)
    timers_3.add('n', 1.1)
    timers_4.add('n', 1.1)
    timers_4.add('n', 1.1)
    timers_4.add('n', 0.0)
    timers_4.add('n', 0.0)
    timers_4.add('n', 0.0)
    timers_4.add('n', 1.1)


# Generated at 2022-06-25 15:14:15.527908
# Unit test for method min of class Timers
def test_Timers_min():
    # Setup test case
    timers_0 = Timers()
    timers_0.data = collections.defaultdict(int)
    timers_0.data['name'] = 1
    # Call the method being tested
    result = timers_0.min('name')
    # Verify the result
    assert result == 1


# Generated at 2022-06-25 15:14:17.310696
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("name", 8)
    assert timers_0.min("name") == 8


# Generated at 2022-06-25 15:14:27.789113
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1.add("test_timer_1", 1.0)
    timers_1.add("test_timer_2", 4.0)
    timers_1.add("test_timer_2", 2.0)
    timers_1.add("test_timer_1", 3.0)
    timers_1.add("test_timer_3", 5.0)
    timers_1.add("test_timer_2", 0.0)
    assert timers_1.min("test_timer_1") == 1.0
    assert timers_1.min("test_timer_2") == 0.0
    assert timers_1.min("test_timer_3") == 5.0


# Generated at 2022-06-25 15:14:30.934605
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('foo', 1)
    timers.add('foo', 2)

    assert timers.mean('foo') == 1.5


# Generated at 2022-06-25 15:14:36.094397
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    assert timers.max('test') == 2


# Generated at 2022-06-25 15:14:40.632941
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("timer_0", 4)
    timers_0.add("timer_0", 1)
    timers_0.add("timer_0", 2)
    assert timers_0.median("timer_0") == 2
    timers_0.add("timer_0", 5)
    assert timers_0.median("timer_0") == 3


# Generated at 2022-06-25 15:14:52.455817
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("A", 10)
    timers.add("B", 20)
    assert timers.count("A") == 1
    assert timers.count("B") == 1
    assert timers.count("C") == 0
    assert timers.total("A") == 10
    assert timers.total("B") == 20
    assert timers.total("C") == 0
    assert timers.min("A") == 10
    assert timers.min("B") == 20
    assert timers.min("C") == 0
    assert timers.max("A") == 10
    assert timers.max("B") == 20
    assert timers.max("C") == 0
    timers.add("A", 30)
    timers.add("B", 40)
    assert timers.count("A") == 2

# Generated at 2022-06-25 15:14:54.121268
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert timers_0.min("name") == 0.0


# Generated at 2022-06-25 15:14:58.141431
# Unit test for method max of class Timers
def test_Timers_max():
    # Initialization of Timers
    timers_0 = Timers()

    # Input values for testing
    name = "name"

    # Running method
    result = timers_0.max(name=name)

    # Expected value
    expected = 0.0

    # Assertion
    assert result == expected


# Generated at 2022-06-25 15:15:00.424454
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = 'test'
    assert timers_0.mean(name=name_0) == 0


# Generated at 2022-06-25 15:15:04.524143
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("key", 24.0)
    timers_0.add("key", 58.0)
    timers_0.add("key", 8.0)
    timers_0.add("key", 24.0)
    timers_0.add("key", 68.0)
    assert 24.0 == timers_0.min("key")



# Generated at 2022-06-25 15:15:15.062383
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('f87e9d9b-677e-11e9-a923-1681be663d3e', 1.0)
    timers_0.add('f87e9d9b-677e-11e9-a923-1681be663d3e', 1.0)
    timers_0.add('f87e9d9b-677e-11e9-a923-1681be663d3e', 1.0)
    timers_0.add('f87e9d9b-677e-11e9-a923-1681be663d3e', 1.0)

# Generated at 2022-06-25 15:15:17.765848
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = str()
    expected_0 = float()
    actual_0 = timers_0.mean(name_0)


# Generated at 2022-06-25 15:15:21.706635
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('a', 2.5)
    timers_0.add('b', 3.5)
    timers_0.add('c', 4.5)
    print(timers_0.max('b'))


# Generated at 2022-06-25 15:15:24.802297
# Unit test for method mean of class Timers
def test_Timers_mean():
    assert False

# Generated at 2022-06-25 15:15:27.858492
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    # Test for userdic key error
    try:
        timers_0.median('foo')
    except KeyError:
        pass



# Generated at 2022-06-25 15:15:29.806776
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("example", 5)
    assert timers.median("example") == 5.0



# Generated at 2022-06-25 15:15:33.845927
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = str()
    # assert that mean raise KeyError when key is missing
    try:
        timers_0.mean(name_0)
    except KeyError:
        pass
    else:
        assert False


# Generated at 2022-06-25 15:15:37.541833
# Unit test for method mean of class Timers
def test_Timers_mean():
    from src.timers import Timers
    timers_0 = Timers()
    timers_0.add('name', 1)
    assert timers_0.mean('name') == 1


# Generated at 2022-06-25 15:15:40.873126
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name = ""
    # Testing for ValueError
    try:
        timers_0.min(name)
    except ValueError:
        pass


# Generated at 2022-06-25 15:15:45.099119
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name = "test_name"
    time_list = [2.1, 2.2, 2.3]
    for time in time_list:
        timers_0.add(name, time)
    result_0 = timers_0.min(name)
    assert result_0 == min(time_list)


# Generated at 2022-06-25 15:15:47.775217
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    # Timers.__init__(timers_0)
    # Timers.min(timers_0, "name")
    assert True


# Generated at 2022-06-25 15:15:49.777265
# Unit test for method median of class Timers
def test_Timers_median():
    print("Testing Timers.median")

# Generated at 2022-06-25 15:15:56.389688
# Unit test for method mean of class Timers
def test_Timers_mean():

    # Initial values for timer
    int_0 = 123456789
    list_0 = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2]
    list_1 = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
    list_2 = [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3]
    list_3 = [7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7]
    list_4 = [9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9]
    list_5 = [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5]

# Generated at 2022-06-25 15:16:05.982537
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("qwertyuiop", -1)
    timers_0.add("asdfghjkl", 1)
    timers_0.add("zxcvbnm", -1)
    timers_0.add("qwertyuiop", -2)
    timers_0.add("asdfghjkl", 1)
    timers_0.add("asdfghjkl", -1)
    timers_0.add("qwertyuiop", -2)
    assert abs(timers_0.max("asdfghjkl") - 1) < 1e-10
    assert abs(timers_0.max("qwertyuiop") - -1) < 1e-10

# Generated at 2022-06-25 15:16:10.714716
# Unit test for method median of class Timers
def test_Timers_median():
    # Fixture setup: Create a Timers instance
    timers = Timers()
    # Exercise: Add three timing values to the 'find' timer
    timers.add("find", 1.0)
    timers.add("find", 2.0)
    timers.add("find", 3.0)
    # Exercise: Call the median method
    result = timers.median("find")
    # Verify: The median should be 2.0
    assert result == 2.0, f"Result is {result}"


# Generated at 2022-06-25 15:16:17.912741
# Unit test for method max of class Timers
def test_Timers_max():
    import random
    # Init timers
    timers_0 = Timers()
    # Adding timings
    timers_0.add('test', random.uniform(0.0, 100.0))
    timers_0.add('test', random.uniform(0.0, 100.0))
    timers_0.add('test', random.uniform(0.0, 100.0))
    timers_0.add('test', random.uniform(0.0, 100.0))
    timers_0.add('test', random.uniform(0.0, 100.0))
    # Max
    max_0 = timers_0.max('test')
    # Test max
    assert isinstance(max_0, float)


# Generated at 2022-06-25 15:16:24.358512
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('1', 1.0)
    timers_0.add('2', 1.0)
    timers_0.add('1', 0.0)
    timers_0.add('1', 3.0)
    timers_0.add('2', 2.0)
    tm = timers_0.min('1')
    assert(tm==0.0)


# Generated at 2022-06-25 15:16:27.980176
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('timers_0', 1.2)
    assert(timers_0['timers_0'] == 1.2)


# Generated at 2022-06-25 15:16:29.877444
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()

    assert timers_0.mean("_nginx_access_elapsed") == 0.0


# Generated at 2022-06-25 15:16:36.169254
# Unit test for method min of class Timers
def test_Timers_min():
    # timer.min(name: str) -> float
    # Returns the lowest value of timer with given name.
    # Raises KeyError if no timings are present for the timer with given name.
    timers_2 = Timers()
    timers_2.add('timer_0', 42)
    assert timers_2.min('timer_0') == 42


# Generated at 2022-06-25 15:16:38.843636
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("Timer", 0.1)
    timers.add("Timer", 0.12)
    assert timers.min("Timer") == 0.1


# Generated at 2022-06-25 15:16:40.805876
# Unit test for method mean of class Timers
def test_Timers_mean():
   timers_0 = Timers()
   assert timers_0.mean('name_0') == -1.0


# Generated at 2022-06-25 15:16:45.227532
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("key_0", -0.13541)
    key = "key_0"
    expect = -0.13541
    actual = timers_0.min(key)
    assert actual == expect


# Generated at 2022-06-25 15:16:55.172831
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("key0", 1.1)
    timers_0.add("key0", -1.1)
    min_expected = 0.0
    min_actual = timers_0.min("key0")
    assert math.isclose(min_expected, min_actual, rel_tol=1e-9)


# Generated at 2022-06-25 15:17:00.328793
# Unit test for method mean of class Timers
def test_Timers_mean():
    v0 = Timers()
    v0.add("name0", 1)
    v0.add("name0", 1)
    v0.add("name0", 3)
    v0.add("name0", 3)
    v1 = v0.mean("name0")
    assert v1 == 2.0


# Generated at 2022-06-25 15:17:06.805368
# Unit test for method min of class Timers
def test_Timers_min():
    # define values
    name = "name"
    timers_0 = Timers()
    timers_0.add("sgc", 3.8)
    timers_0.add("sgc", 3.8)
    timers_0.add("sgc", 3.8)
    timers_0.add("sgc", 3.8)
    # compute result
    result = timers_0.min("sgc")
    # compare result
    assert result == 3.8



# Generated at 2022-06-25 15:17:07.747581
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()


# Generated at 2022-06-25 15:17:11.396089
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0_0 = Timers()
    timers_0_0.add("key", 1.0)
    timers_0_0.add("key", 2.0)
    timers_0_0.add("key", 3.0)
    assert timers_0_0.median("key") == 2.0

# Generated at 2022-06-25 15:17:18.666679
# Unit test for method mean of class Timers
def test_Timers_mean():

    timers_0 = Timers()
    timers_1 = Timers()
    timers_2 = Timers()
    timers_3 = Timers()
    timers_4 = Timers()
    timers_5 = Timers()
    timers_6 = Timers()
    timers_7 = Timers()

    timers_0.data["display"] = 1.189475
    timers_1.data["display"] = 0.765831
    timers_2.data["display"] = 0.854022
    timers_3.data["display"] = 0.837764
    timers_4.data["display"] = 0.004092
    timers_5.data["display"] = 0.004092
    timers_6.data["display"] = 0.004092
    timers_7.data["display"] = 0.004092

# Generated at 2022-06-25 15:17:22.446813
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add('first', 1)
    t.add('first', 2)
    assert t.mean('first') == 1.5


# Generated at 2022-06-25 15:17:24.743292
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    # No exception throwed
    assert timers_0.mean("")
    

# Generated at 2022-06-25 15:17:36.220120
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("name_0", 1.0)
    timers_0.add("name_0", 0.0)
    timers_0.add("name_0", 0.0)
    timers_0.add("name_0", 0.0)
    timers_0.add("name_0", 0.0)
    timers_0.add("name_0", 1.0)
    timers_0.add("name_0", 1.0)
    timers_0.add("name_0", 0.0)
    timers_0.add("name_0", 0.0)
    timers_0.add("name_0", 1.0)
    timers_0.add("name_0", 1.0)

# Generated at 2022-06-25 15:17:41.621072
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('init', 0.0005059242248535156)
    timers.add('init', 0.0004858970642089844)
    timers.add('init', 0)
    timers.add('init', 0.0004260540008544922)
    assert timers.median('init') == 0.0001530170440673828



# Generated at 2022-06-25 15:18:00.391472
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("alpha", 1.0)
    timers.add("alpha", 2.0)
    timers.add("beta", 15.0)
    assert timers.count("alpha") == 2
    assert timers.count("beta") == 1
    assert timers.total("alpha") == 3.0
    assert timers.total("beta") == 15.0
    assert timers.min("alpha") == 1.0
    assert timers.min("beta") == 15.0
    assert timers.max("alpha") == 2.0
    assert timers.max("beta") == 15.0
    assert timers.mean("alpha") == 1.5
    assert timers.mean("beta") == 15.0
    assert timers.median("alpha") == 1.5
    assert timers.median("beta") == 15.0

# Generated at 2022-06-25 15:18:01.985747
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()

    assert timers_0.min("key") == 0



# Generated at 2022-06-25 15:18:09.437112
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("key", 1.0)
    timers_0.add("key-1", 1.0)
    timers_0.add("key-2", 1.0)
    timers_0.add("key-3", 1.0)
    timers_0.add("key-4", 1.0)
    timers_0.add("key-5", 1.0)
    assert timers_0.median("key-2") == 1.0


# Generated at 2022-06-25 15:18:16.137465
# Unit test for method median of class Timers
def test_Timers_median():
    # Setup test case
    timers_0 = Timers()
    timers_0.add('ABC', 1)
    timers_0.add('ABC', 2)
    timers_0.add('DEF', 4)
    timers_0.add('DEF', 3)

    # Test
    assert timers_0.median('ABC') == 1.5
    assert timers_0.median('DEF') == 3.5
    assert timers_0.median('GHI') == 0
    assert timers_0.median('GHI') == 0

# Generated at 2022-06-25 15:18:18.021515
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert timers_0.median("aUIhZn") == 0


# Generated at 2022-06-25 15:18:21.619292
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add("hello", 2.5)
    timers_1.add("hello", 3.5)
    assert timers_1.mean("hello") == 3.0
    try:
        timers_1.mean("world")
        assert False
    except KeyError:
        assert True



# Generated at 2022-06-25 15:18:23.934404
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    value_0 = timers_0.min('muxers')
    assert value_0 == 0
    assert isinstance(value_0, float)



# Generated at 2022-06-25 15:18:28.190367
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("i/j", 1.8)
    timers_0.add("abc", 5.0)
    timers_0.add("abc", 2.0)
    timers_0.add("i/j", 1.7)
    timers_0.add("i/j", 1.9)
    assert timers_0.median("i/j") == 1.8


# Generated at 2022-06-25 15:18:38.397849
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = "9Lq3]D"
    name_1 = "[gW&'v|"
    name_2 = "8!-L"
    name_3 = "~j%c"
    name_4 = "G*Y"
    timers_0.add(name_1, value=0)
    timers_0.add(name_4, value=1.4)
    timers_0.add(name_4, value=-0.4)
    timers_0.add(name_2, value=1.7)
    timers_0.add(name_0, value=0)
    timers_0.add(name_0, value=0)
    timers_0.add(name_3, value=1.8)

# Generated at 2022-06-25 15:18:46.366882
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("Mn2gUFn5fXW5ehI", 2.22)
    timers_0.add("kR8nVnsfJyNDD7V", 1.39)
    timers_0.add("xV7NpRt8uUK7j06", 44.88)
    timers_0.add("jZC1tNuHdl0cYb8", 2.22)
    timers_0.add("5W8f1G5p5r0jvn6", 1.39)
    timers_0.add("vUH9KjhUtgU6L2S", 44.88)
    timers_0.add("Mn2gUFn5fXW5ehI", 2.22)
    timers_0

# Generated at 2022-06-25 15:19:11.287419
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert timers_0.median("timers_0") == 0


# Generated at 2022-06-25 15:19:20.703432
# Unit test for method median of class Timers
def test_Timers_median():
    # Create two timers
    timers = Timers()
    timers.add('timer_1', 0.1)
    timers.add('timer_2', 0.2)
    timers.add('timer_1', 0.3)
    timers.add('timer_2', 0.4)
    timers.add('timer_1', 0.4)
    timers.add('timer_2', 0.3)
    timers.add('timer_1', 0.6)
    timers.add('timer_2', 0.7)

    # Timer 1 (pivot is the 5th number in the list
    assert timers.median('timer_1') == 0.4
    
    # Timer 2 (pivot is the average of the 4th and 5th number in the list)
    assert timers.median('timer_2') == 0.35

# Generated at 2022-06-25 15:19:25.866101
# Unit test for method median of class Timers
def test_Timers_median():
    '''
    Test median method of Timers class
    '''

    # Expected result
    expected_result = 0.5

    # Test case setup
    timers = Timers()
    timers._timings = {'timer1': [1, 0, 1]}

    # Test case execution
    assert timers.median('timer1') == expected_result, \
        "Function median in class Timers returns wrong result"


# Generated at 2022-06-25 15:19:28.969041
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Initialization
    timers = Timers()
    name = 'foo'
    timers.add(name, 1.0)
    timers.add(name, 100.0)

    # Get the mean value of timer
    assert abs(timers.mean(name)-50.5) < 1e-15

    # Get the mean value of a wrong name
    try:
        timers.mean('bar')
    except KeyError:
        pass


# Generated at 2022-06-25 15:19:30.114570
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers({'a': 1})
    print(timers.min('a'))


# Generated at 2022-06-25 15:19:32.533207
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers._timings = {'test': [0, 2, 1.5]}
    assert timers.max('test') == 2.0

test_case_0()

# Generated at 2022-06-25 15:19:34.206763
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()

    timers_0.add("key", 2.0)
    assert timers_0.max('key') == 2

# Generated at 2022-06-25 15:19:36.883421
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert Timers.max(timers_0, "") == 0


# Generated at 2022-06-25 15:19:47.357251
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Case 1
    timers_1 = Timers()
    timers_1.add("a", 1)
    timers_1.add("a", 2)
    timers_1.add("a", 2)
    timers_1.add("a", 2)
    timers_1.add("a", 2)
    actual_1 = timers_1.mean("a")
    expected_1 = int(1.8)
    assert actual_1 == expected_1

    # Case 2
    timers_2 = Timers()
    timers_2.add("a", 1)
    timers_2.add("a", 2)
    actual_2 = timers_2.mean("a")
    expected_2 = int(1.5)
    assert actual_2 == expected_2


# Generated at 2022-06-25 15:19:57.671433
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('', -0.0)
    timers_0.add('', 4.9E-324)
    timers_0.add('', 3.2)
    timers_0.add('', 0.4)
    timers_0.add('', 0.4)
    timers_0.add('', 0.4)
    timers_0.add('', 1.1)
    timers_0.add('', 1.1)
    timers_0.add('', 1.1)
    timers_0.add('', 1.1)
    timers_0.add('', 2.2)
    timers_0.add('', 2.2)
    timers_0.add('', 2.2)
    timers_0.add('', 2.2)
    timers_0

# Generated at 2022-06-25 15:20:21.387969
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert math.isnan(timers_0.mean('name_3'))
    timers_0.add('name_3', -1.0)
    assert -1.0 == timers_0.mean('name_3')


# Generated at 2022-06-25 15:20:27.276975
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    # Test exception raised
    with pytest.raises(KeyError):
        timers_0.max("")


# Generated at 2022-06-25 15:20:30.902202
# Unit test for method median of class Timers
def test_Timers_median():
    try:
        timers_0 = Timers()
    except:
        print("Unable to construct object Timers")
    try:
        timers_0.median("name")
        assert False
    except KeyError: pass
    try:
        timers_0.add("name", 1)
        assert timers_0.median("name") == 1
    except KeyError: pass
    except:
        print("Unable to use method median of class Timers")


# Generated at 2022-06-25 15:20:32.120298
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = '0.124567'
    assert timers_0.mean(name_0) == 0.0


# Generated at 2022-06-25 15:20:34.649253
# Unit test for method max of class Timers
def test_Timers_max():

    timers_ = Timers()
    timers_.add('abc', 1)
    timers_.add('abc', 2)
    timers_.add('abc', 3)

    assert timers_.max('abc') == 3


# Generated at 2022-06-25 15:20:39.538313
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Test case with dictionary argument
    timers = Timers({'one': 1, 'two': 2, 'three': 3})
    timers.add("four", 4)
    timers.add("five", 5)
    assert timers.mean("four") == 4.0


# Generated at 2022-06-25 15:20:46.018920
# Unit test for method max of class Timers
def test_Timers_max():
    # Case 0, 1
    timers_0 = Timers()
    timers_0.add('timers_0', 78.0)
    timers_0.add('timers_0', 23.0)
    timers_0.add('timers_0', 53.0)

    ret_0 = timers_0.count('timers_0')

    assert ret_0 == 3.0

# Generated at 2022-06-25 15:20:54.034629
# Unit test for method max of class Timers
def test_Timers_max():
    # Test 1: max of non-existing timer
    timers_1 = Timers()
    try:
        timers_1.max("test_name")
    except KeyError:
        pass
    else:
        raise AssertionError("timers_1.max('test_name') did not raise KeyError")

    # Test 2: max of existing timer
    timers_2 = Timers()
    timers_2._timings = collections.defaultdict(list, {"test_name": [4.0, 5.0, 3.5]})
    max_2 = timers_2.max("test_name")
    assert max_2 == 5.0, "max_2 did not have expected value."

# Generated at 2022-06-25 15:21:01.943940
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Parametrize tests
    cases = [
        # (expected, name, timers)
        (0, "x", Timers()),
        (0, "x", Timers({'x': 0.0})),
        (0, "x", Timers({'x': 1.0})),
        (1, "x", Timers({'x': 1.0})),
        (1.5, "x", Timers({'x': 2.0})),
        (1.5, "x", Timers({'x': 2.0, 'y': 3.0})),
    ]

    # Execute test against each case
    for expected, name, timers in cases:
        assert timers.mean(name) == expected


# Generated at 2022-06-25 15:21:07.398764
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 2)
    timers.add("a", 3)
    timers.add("b", 4)
    timers.add("b", 5)
    timers.add("c", 6)
    assert timers.min("a") == 1
    assert timers.min("b") == 4
    assert timers.min("c") == 6
    try:
        assert timers.min("d") == 0
        raise AssertionError("This should have raised an exception")
    except KeyError as e:
        assert str(e) == "d"

