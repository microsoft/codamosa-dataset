

# Generated at 2022-06-25 15:11:44.224634
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name = "lark"
    timers_0.add(name, 1.0/23.0)
    timers_0.add(name, 1.0/3.0)
    timers_0.add(name, 1.0/1.0)
    timers_0.add(name, 0.0)
    timers_0.add(name, 1.0/1.0)
    timers_0.add(name, 1.0/1.0)
    timers_0.add(name, 1.0/1.0)
    assert (timers_0.min(name)) == 0.0


# Generated at 2022-06-25 15:11:46.068788
# Unit test for method median of class Timers
def test_Timers_median():
    assert timers_0.median("a") == 0.0


# Generated at 2022-06-25 15:11:55.266249
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("<class '_pytest.capture.CaptureManager'>", 0.009909874)
    timers_0.add("<class '_pytest.capture.CaptureManager'>", 0.005745243)
    timers_0.add("<class '_pytest.capture.CaptureManager'>", 0.005569548)
    timers_0.add("<class '_pytest.capture.CaptureManager'>", 0.005399097)
    timers_0.add("<class '_pytest.capture.CaptureManager'>", 0.005358869)
    timers_0.add("<class '_pytest.capture.CaptureManager'>", 0.005329215)

# Generated at 2022-06-25 15:11:57.252804
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("timers_0", -424.0)
    assert timers_0.max("timers_0") == -424.0
    timers_0.add("timers_0", -24.0)
    assert timers_0.max("timers_0") == -24.0


# Generated at 2022-06-25 15:12:01.433703
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("k", 9.4)
    timers.add("k", 6.9)
    timers.add("k", 9.8)
    timers.add("k", 4.7)
    timers.add("k", 9.0)
    timers.add("k", 6.7)
    timers.add("k", 9.8)
    timers.add("k", 6.3)
    timers.add("k", 9.6)
    timers.add("k", 2.2)
    timers.add("k", 9.6)
    timers.add("k", 6.6)
    timers.add("k", 9.6)
    timers.add("k", 5.6)
    timers.add("k", 9.6)
    timers.add("k", 6.6)


# Generated at 2022-06-25 15:12:04.371576
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    numbers = [0.5, 1.5, 2.5, 3.5, 4.5]
    for i in numbers:
        timers_0.add("timings", i)
    median = timers_0.median("timings")
    assert median == median


# Generated at 2022-06-25 15:12:05.955579
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    value = timers_0.median('f0.3')
    return value


# Generated at 2022-06-25 15:12:08.793713
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    # Positional arguments
    if True:
        # Force error if Timers.__init__ does not accept positional arguments
        timers_0 = Timers(dict())
        # Force error if Timers.min does not accept positional arguments
        timers_0.min('name')


# Generated at 2022-06-25 15:12:14.348701
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert timers_0.min("") == 0
    assert timers_0.min("name_0") == 0
    timers_0.clear()
    assert timers_0.min("") == 0
    assert timers_0.min("name_0") == 0
    timers_0.add("n", 1.3)
    assert timers_0.min("n") == 1.3
    timers_0.add("n", -1.8)
    assert timers_0.min("n") == -1.8
    timers_0.add("n", 5e-06)
    assert timers_0.min("n") == -1.8
    timers_0.add("n", 1.0)
    assert timers_0.min("n") == -1.8


# Generated at 2022-06-25 15:12:20.795924
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()

    timers.add("foo", 0)
    timers.add("bar", 0)
    timers.add("foo", 0)
    timers.add("bar", 0)

    assert timers.mean("foo") == 0
    assert timers.mean("bar") == 0

    timers.add("foo", 3)

    assert timers.mean("foo") == 1.5
    assert timers.mean("bar") == 0

    timers.add("foo", 4)

    assert timers.mean("foo") == 2



# Generated at 2022-06-25 15:12:28.578468
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("timer_0", 1)
    timers.add("timer_0", 2)
    timers.add("timer_0", 3)
    timers.add("timer_1", 4)
    timers.add("timer_1", 5)
    assert timers.min("timer_0") == 1
    assert timers.min("timer_1") == 4


# Generated at 2022-06-25 15:12:31.384166
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('foo', 1)
    timers.add('foo', 2)
    timers.add('foo', 3)
    assert timers.median('foo') == 2
    timers.add('foo', 4)
    assert timers.median('foo') == 2.5


# Generated at 2022-06-25 15:12:40.321053
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("test_key_0", 1.0)
    timers_0.add("test_key_1", 0.0)

    timers_1 = Timers()
    timers_1.add("test_key_0", 0.5)
    timers_1.add("test_key_1", 2.0)
    timers_1.add("test_key_2", 1.0)

    assert timers_0.median("test_key_0") == timers_1.median("test_key_2")


# Generated at 2022-06-25 15:12:46.444327
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("key_0", 1)
    timers_0.add("key_0", 2)
    timers_0.add("key_0", 3)
    timers_0.add("key_1", 4)
    timers_0.add("key_1", 5)
    timers_0.add("key_1", 6)
    assert timers_0.median("key_0") == 2
    assert timers_0.median("key_1") == 5


# Generated at 2022-06-25 15:12:47.304306
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()


# Generated at 2022-06-25 15:12:50.743397
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.min("timers.timer")
    timers_0.clear()


# Generated at 2022-06-25 15:12:54.068617
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    exception_raised = False
    try:
        if name in timers_0._timings:
            value = timers_0._timings[name]
            return statistics.mean(value) if len(value) >= 2 else math.nan
        raise KeyError(name)
    except:
        exception_raised = True
    assert not exception_raised


# Generated at 2022-06-25 15:13:01.186864
# Unit test for method median of class Timers
def test_Timers_median():
    import copy
    expected_0 = 0.5
    expected_1 = 0.25
    expected_2 = 0.25
    timers_0 = Timers()
    timers_0.add("test_typing_0", 0.25)
    timers_0.add("test_typing_0", 0.5)
    timers_0.add("test_typing_0", 0.75)
    timers_0.add("test_typing_0", 1)
    timers_1 = copy.copy(timers_0)
    assert timers_0.median("test_typing_0") == expected_0
    assert timers_1.median("test_typing_0") == expected_1
    assert timers_1.median("test_typing_1") == expected_2


# Generated at 2022-06-25 15:13:04.883829
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("timers", 2)
    timers.add("timers", 1)
    timers.add("timers", 4)
    timers.add("timers", 3)
    assert timers.min("timers") == 1.0


# Generated at 2022-06-25 15:13:07.091514
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("key_0", 0.0)
    timers_0.max("key_0")


# Generated at 2022-06-25 15:13:20.341689
# Unit test for method median of class Timers
def test_Timers_median():

    timers_0 = Timers()

    assert math.isnan(timers_0.median('w32hb'))

    timers_0.add('w32hb', 0.0)

    assert math.isnan(timers_0.median('w32hb'))

    timers_0.add('w32hb', 0.0)

    assert math.isnan(timers_0.median('w32hb'))

    timers_0.add('w32hb', 0.0)

    assert math.isnan(timers_0.median('w32hb'))

    timers_0.add('w32hb', 0.0)

    assert math.isnan(timers_0.median('w32hb'))


# Generated at 2022-06-25 15:13:28.550018
# Unit test for method max of class Timers
def test_Timers_max():
    # Setup
    t2 = Timers()
    t2["foo"] = -1
    t2.add("foo", -3)
    t2.add("bar", -5)
    # Exercise
    actual = t2.max("foo")
    # Verify
    assert actual == -3
    # Exercise
    actual = t2.max("bar")
    # Verify
    assert actual == -5
    # Exercise
    actual = t2.max("no_such")
    # Verify
    assert actual == 0


# Generated at 2022-06-25 15:13:37.123408
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    for i in range(0, 26):
        if (i % 2) == 0:
            timers_0.add("name", float(i))
    timers_0.add("name", float(26))
    timers_0.add("name", float(26))
    timers_0.add("name", float(26))
    timers_0.add("name", float(26))
    timers_0.add("name", float(26))
    assert timers_0.mean("name") == 13


# Generated at 2022-06-25 15:13:42.273386
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('d', 0.24919297818075618)
    timers_0.add('w', 1.2164609909057617)
    timers_0.add('a', 0.11499595625693315)
    clocks_0_max_0 = timers_0.max('o')


test_case_0()
#test_Timers_max()

# Generated at 2022-06-25 15:13:48.528879
# Unit test for method mean of class Timers
def test_Timers_mean():

    timers_1 = Timers()
    timers_1.data = {"timer"}
    assert_raises(KeyError, lambda: timers_1.mean("timer"))

    timers_2 = Timers()
    timers_2.data = {"timer"}
    assert timers_2.mean("timer") == 0.0

    timers_3 = Timers()
    timers_3.data = {"timer"}
    timers_3.apply = lambda func, name: func(name)
    assert timers_3.mean("timer") == 0.0

    timers_4 = Timers()
    timers_4.data = {"timer"}
    timers_4._timings = {"timer": [0.0]}
    timers_4.apply = lambda func, name: func(name)
    assert timers_4.mean("timer") == 0.0

    timers_

# Generated at 2022-06-25 15:13:51.510778
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers({'item': 0})
    assert timers_0.max('item') == 0


# Generated at 2022-06-25 15:13:53.652963
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('__main__', 0.0)
    assert timers_0.min('__main__') == 0.0


# Generated at 2022-06-25 15:14:00.742372
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = 1
    timers_0.data['name_0'] = 0
    timers_0._timings['name_0'] = []
    assert timers_0.mean(name_0) == math.nan
    timers_0._timings['name_0'].append(1)
    assert timers_0.mean(name_0) == 1

# Generated at 2022-06-25 15:14:08.001390
# Unit test for method median of class Timers
def test_Timers_median():
    # Initialize an instance of Timers
    timers_1 = Timers()
    # Add a timing value to the given timer
    timers_1.add('foo', 1.5)
    # Add a timing value to the given timer
    timers_1.add('bar', 2)
    timers_1.add('bar', 2)
    # Median value of timings
    assert(timers_1.median('foo') == 1.5)
    assert(timers_1.median('bar') == 2)
    # Tests without data
    assert(timers_1.median('baz') == 0)



# Generated at 2022-06-25 15:14:11.224351
# Unit test for method median of class Timers
def test_Timers_median():
    Timers_0 = Timers()
    Timers_0.add("a", 1)
    Timers_0.add("b", 1)
    double_0 = Timers_0.median("b")
    assert(double_0 == 1.0)


# Generated at 2022-06-25 15:14:19.454872
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("Timer1", 1.0)
    timers.add("Timer1", 2.0)
    timers.add("Timer2", 3.0)
    timers.add("Timer2", 4.0)
    timers.add("Timer2", 9.0)

    assert timers.median("Timer1") == 1.5
    assert timers.median("Timer2") == 4.0
    assert timers.median("NotATimer") == 0.0

# Generated at 2022-06-25 15:14:22.696745
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    try:
        timers_0.mean("timer_0")
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-25 15:14:26.016771
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    for i in range(10):
        timers_0.add("name", i)
    name = "name"
    assert timers_0.mean(name) == 4.5


# Generated at 2022-06-25 15:14:34.001240
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    try:
        assert math.isnan(timers_0.min("yq"))
    except KeyError:
        pass
    timers_0 = Timers()

# Generated at 2022-06-25 15:14:37.343408
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add(name='neuronal_model', value=0.01)
    timers_0.add(name='neuronal_model', value=0.02)
    assert timers_0.mean('neuronal_model') == 0.015

# Generated at 2022-06-25 15:14:40.482729
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("name_1", 1)
    timers_0.add("name_1", 1)
    timers_0.add("name_1", 1)
    assert timers_0.mean("name_1") == 1


# Generated at 2022-06-25 15:14:45.365619
# Unit test for method max of class Timers
def test_Timers_max():
    dict_0 = Timers()
    dict_0.add('dict', 0.0)
    float_0 = dict_0.max('dict')
    assert float_0 == 0.0


# Generated at 2022-06-25 15:14:54.647924
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('foo', 3.2)
    timers_0.add('foo', 3.2)
    timers_0.add('bar', 5.0)
    timers_0.add('bar', 0.1)
    timers_0.add('baz', 3.2)

    # Test 1
    assert timers_0.max('foo') == 3.2

    # Test 2
    assert timers_0.max('bar') == 5.0

    # Test 3
    assert timers_0.max('baz') == 3.2

    # Test 4
    assert timers_0.max('qux') == 0

    # Test 5
    assert timers_0.max('bar') == timers_0.data['bar']


# Generated at 2022-06-25 15:14:56.559427
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert (timers_0.min("name_0") == 0)



# Generated at 2022-06-25 15:14:59.420688
# Unit test for method min of class Timers
def test_Timers_min():
    # Test cases
    timers = Timers({"foo": 2, "bar": 4})
    key = "foo"
    expected = 2
    actual = timers.min(key)
    assert actual == expected


# Generated at 2022-06-25 15:15:03.171575
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    key_0 = str()
    assert timers_0.min(key_0) == 0.0


# Generated at 2022-06-25 15:15:13.084387
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.max("timers_0_max") == 0.0
    timers_0.add("timers_0_max", 0.8516662407791736)
    assert timers_0.max("timers_0_max") == 0.8516662407791736
    timers_0.add("timers_0_max", 1.1637287797221216)
    assert timers_0.max("timers_0_max") == 1.1637287797221216
    timers_0.add("timers_0_max", 0.8655680013048763)
    assert timers_0.max("timers_0_max") == 1.1637287797221216


# Generated at 2022-06-25 15:15:20.214394
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers_0 = Timers()
    timers_0.add('0', 6)
    timers_0.add('1', -4)
    assert timers_0.max('0') == 6.0
    assert timers_0.max('1') == -4.0
    assert timers_0.data['0'] == 6.0
    assert timers_0.data['1'] == -4.0


# Generated at 2022-06-25 15:15:24.929614
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name_0 = ""
    value_0 = 0.0
    timers_0.add(name_0, value_0)
    value_1 = 0.0
    timers_0[name_0] = value_1
    value_2 = 0.0
    assert timers_0.min(name_0) == value_2, f"expected: {value_2}, actual: {timers_0.min(name_0)}"


# Generated at 2022-06-25 15:15:36.163500
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Initialize example inputs
    timers_0 = Timers()
    timers_0.add("Beste", 8.6409619912)
    timers_0.add("Besser", 8.0520348811)
    timers_0.add("Schlechteste", 9.6764724254)
    timers_0.add("Schlechteste", 9.408363938)
    timers_0.add("Schlechteste", 10.6940409422)
    timers_0.add("Schlechteste", 9.5706892572)
    timers_0.add("Schlechteste", 9.4340917119)
    timers_0.add("Schlechteste", 10.8801680955)

# Generated at 2022-06-25 15:15:39.520385
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("lod", 2.2)
    timers_0.add("default", 4.4)
    timers_0.add("default", 2.2)
    timers_0.add("lod", 3.3)
    assert (timers_0.max("lod") == 3.3)
    assert (timers_0.max("default") == 4.4)

# Generated at 2022-06-25 15:15:41.085360
# Unit test for method median of class Timers
def test_Timers_median():
    assert (math.nan == timers_0.median('name'))


# Generated at 2022-06-25 15:15:44.330525
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('timers_0', 1.0)
    assert timers_0.max('timers_0') == 1.0
    assert math.isnan(timers_0.min('timers_0'))


# Generated at 2022-06-25 15:15:49.566925
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1.add("default", 1.0)
    timers_1.add("default", 2.0)
    timers_1.add("default", 3.0)
    timers_1.add("default", 4.0)
    timers_1.add("default", 5.0)
    assert timers_1.min("default") == 1.0


# Generated at 2022-06-25 15:15:51.050774
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert timers_0.median('hello') == 0.0



# Generated at 2022-06-25 15:15:59.492508
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('Timer1', 1.11)
    timers_0.add('Timer1', 2.22)
    timers_0.add('Timer1', 3.33)
    assert timers_0.min('Timer1') == 1.11


# Generated at 2022-06-25 15:16:02.673009
# Unit test for method min of class Timers
def test_Timers_min():
    Timers_0 = Timers()
    Timers_0.add("s", 5.05)
    Timers_0.add("s", 3.05)
    Timers_0.add("s", 2.05)
    assert Timers_0.min("s") == 2.05



# Generated at 2022-06-25 15:16:05.822653
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    str_0 = "a"
    float_0 = timers_0.apply(lambda values: statistics.median(values or [0]), name=str_0)


# Generated at 2022-06-25 15:16:15.817068
# Unit test for method mean of class Timers
def test_Timers_mean():
    # We use three of the current benchmarks: 'add' and 'eq' are simple
    # benchmarks, 'run' is an intermediate benchmark.
    # We do each benchmark once per loop: we record the number of times we
    # benchmarked each function, and the total time spent in each benchmark.

    # No running benchmarks
    timers = Timers()
    assert timers.mean("add") == 0
    assert timers.mean("eq") == 0

    # One benchmark running.
    timers = Timers()
    timers.add("add", 10)
    assert timers.mean("add") == 10
    assert timers.mean("eq") == 0

    # Two benchmarks running, one has no time recorded.
    timers = Timers()
    timers.add("add", 5)
    timers.add("eq", 0)
    assert timers.mean("add") == 5

# Generated at 2022-06-25 15:16:23.009561
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    timers_0 = Timers()
    timers_0.add("8nFQrUB9Xmj", 0.051809165954589844)
    timers_0.add("8nFQrUB9Xmj", 0.009615917205810547)
    timers_0.add("8nFQrUB9Xmj", 0.018921371459960938)
    timers_0.add("8nFQrUB9Xmj", 0.019615650177001953)
    timers_0.add("8nFQrUB9Xmj", 0.04452085494995117)
    timers_0.add("8nFQrUB9Xmj", 0.016002416610717773)

# Generated at 2022-06-25 15:16:28.240495
# Unit test for method mean of class Timers
def test_Timers_mean():
    import random
    timers_0 = Timers()
    for i in range(0, 100):
        timer_name_0 = random.choice(['a', 'b', 'c'])
        timers_0.add(timer_name_0, 1)



# Generated at 2022-06-25 15:16:33.545432
# Unit test for method min of class Timers
def test_Timers_min():
    """
    Timers.min
    """
    timers_0 = Timers()
    # Empty timers
    assert math.isnan(timers_0.min("a"))
    timers_0.add("a", 1)
    assert timers_0.min("a") == 1



# Generated at 2022-06-25 15:16:36.435712
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Setup:
    timers = Timers()

    # Exercise:
    timers.add("x", 0.3)
    timers.add("x", 0.4)
    timers.add("y", 0.2)

    # Verify:
    assert timers.mean("x") == 0.35
    assert timers.mean("y") == 0.2



# Generated at 2022-06-25 15:16:42.775559
# Unit test for method mean of class Timers
def test_Timers_mean():
    from builtins import isinstance
    import math
    import statistics
    
    # Setup
    timers_0 = Timers()
    timers_0.add('NAME_0', math.nan)
    timers_0.add('NAME_1', math.nan)
    timers_0.add('NAME_2', math.nan)
    timers_0.add('NAME_3', math.nan)
    
    
    # Assert
    mean_0 = timers_0.mean('NAME_0')
    mean_1 = timers_0.mean('NAME_1')
    mean_2 = timers_0.mean('NAME_2')
    mean_3 = timers_0.mean('NAME_3')
    assert isinstance(mean_0, float)
    assert isinstance(mean_1, float)

# Generated at 2022-06-25 15:16:45.978346
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('', (-9))
    assert math.isnan == math.isnan(timers_0.max(''))


# Generated at 2022-06-25 15:16:58.616825
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    # case 0
    timers_0.add("foo", 5.0)
    timers_0.add("foo", 3.0)
    timers_0.add("foo", 1.0)
    timers_0.add("foo", 0.0)
    timers_0.add("bar", 3.0)
    timers_0.add("bar", 5.0)
    timers_0.add("bar", 4.0)
    timers_0.add("bar", 1.0)
    assert timers_0.data == {'foo': 9.0, 'bar': 13.0}
    assert timers_0.mean('foo') == 2.25
    assert timers_0.mean('bar') == 3.25


# Generated at 2022-06-25 15:17:04.464890
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.data = dict()
    timers_0.data["s_s"] = 9.0
    timers_0.data["r_r"] = 7.0
    timers_0.data["r_s"] = 7.0

    assert timers_0.min("s_s") == 9.0
    timers_0 = Timers()



# Generated at 2022-06-25 15:17:12.623111
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    try:
        timers_1 = Timers()
        timers_1.add("name", -1.0)
        timers_0.max("name")
        timers_1.apply(math.trunc, "name")
        timers_0.min("name")
        timers_0.mean("name")
        timers_1.median("name")
        timers_0.stdev("name")
    except KeyError as e:
        print("KeyError:", e)
    except TypeError as e:
        print("TypeError:", e)
    except ValueError as e:
        print("ValueError:", e)
    except Exception as e:
        print("Exception:", e)


# Generated at 2022-06-25 15:17:15.092526
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert math.isnan(timers_0.min("timers_0"))


# Generated at 2022-06-25 15:17:24.770395
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("timer_name_0", 0.8652631637784807)
    timers_0.add("timer_name_0", 0.6368414617247965)
    timers_0.add("timer_name_0", 0.8237600227936843)
    timers_0.add("timer_name_0", 0.9155210924391292)
    timers_0.add("timer_name_0", 0.9233336376892673)
    timers_0.add("timer_name_0", 0.8818256710986909)
    timers_0.add("timer_name_0", 0.7143652288589496)

# Generated at 2022-06-25 15:17:29.173952
# Unit test for method min of class Timers
def test_Timers_min():
    for _ in range(10):
        timers_0 = Timers()
        name_0 = ''
        min_0 = timers_0.min(name_0)
        assert min_0 == 0



# Generated at 2022-06-25 15:17:32.421741
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("eVbvz", -0.023679868)
    timers_0.add("Y.5.5", -0.00020444444444444446)
    assert timers_0.min("eVbvz") == -0.023679868
    assert timers_0.min("Y.5.5") == -0.00020444444444444446


# Generated at 2022-06-25 15:17:35.743561
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    # Init timer
    timers_0.add('Timer', 1.7)
    # Median timer
    timers_0.median('Timer')



# Generated at 2022-06-25 15:17:45.294742
# Unit test for method mean of class Timers
def test_Timers_mean():

    timers_0 = Timers()
    timers_0.add(name='a', value=3.3)
    timers_0.add('b', 3.3)
    timers_0.add('b', 3.3)
    timers_0.add(name='a', value=3.3)
    timers_0.add('a', 3.3)
    timers_0.add('b', 3.3)
    timers_0.add('a', 3.3)
    timers_0.add('b', 3.3)
    timers_0.add('b', 3.3)
    assert(timers_0.mean('a') == 3.30000)
    assert(timers_0.mean('b') == 3.30000)
    assert(timers_0.mean('c') == math.nan)



# Generated at 2022-06-25 15:17:46.781984
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert timers_0.min("cease") == 0


# Generated at 2022-06-25 15:17:54.980990
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timer_1 = Timers()
    timer_1.add('url', 2.0)
    timers_0.add('url', 1.0)
    assert timer_1.mean('url') == 2.0


# Generated at 2022-06-25 15:18:03.830372
# Unit test for method median of class Timers
def test_Timers_median():

    timers_0 = Timers()
    timers_0.add('Timer1', 0.3351)
    timers_0.add('Timer2', 3.381)
    timers_0.add('Timer3', 0.3543)
    timers_0.add('Timer2', 3.3881)
    timers_0.add('Timer3', 0.3133)
    timers_0.add('Timer1', 0.3431)
    timers_0.add('Timer1', 0.3331)
    timers_0.add('Timer1', 0.3431)
    timers_0.add('Timer1', 0.3331)
    timers_0.add('Timer3', 0.3143)
    timers_0.add('Timer2', 3.3881)
    timers_0.add('Timer2', 3.3891)

# Generated at 2022-06-25 15:18:07.626489
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("test", 5.0)
    timers_0.add("test", 5.0)
    return timers_0.mean("test") == 5.0


# Generated at 2022-06-25 15:18:10.461939
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('test_sum', 1.0)
    assert timers_0.mean('test_sum') == 1.0


# Generated at 2022-06-25 15:18:12.099849
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert isinstance(timers_0.median(""), float)


# Generated at 2022-06-25 15:18:20.926321
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    name_0 = "b"
    value_0 = -0.468092506447
    timers_0.add(name_0, value_0)
    name_1 = "e"
    value_1 = 0.09401907176
    timers_0.add(name_1, value_1)
    name_2 = "e"
    value_2 = -0.121324977028
    timers_0.add(name_2, value_2)
    name_3 = "d"
    value_3 = -0.00781423369978
    timers_0.add(name_3, value_3)
    name_4 = "d"
    value_4 = 0.263636883511

# Generated at 2022-06-25 15:18:24.609705
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("foo", 3)
    timers_0.add("foo", 1)
    timers_0.add("bar", 2)
    timers_0.add("bar", 6)
    assert timers_0.max("foo") == 3
    assert timers_0.max("bar") == 6


# Generated at 2022-06-25 15:18:30.350730
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    assert timers_1.min("System process time") == 0
    timers_1.add("Clock time", 0.034)
    timers_1.add("Clock time", 0.085)
    timers_1.add("Clock time", 0.317)
    timers_1.add("Clock time", 0.048)
    timers_1.add("Clock time", 0.433)
    assert timers_1.min("Clock time") == 0.034
    timers_1.add("System process time", 0.001)
    assert timers_1.min("System process time") == 0.001
    timers_1.add("System process time", 0.0)
    assert timers_1.min("System process time") == 0.0
    timers_1.add("System process time", 0.0)
   

# Generated at 2022-06-25 15:18:34.332881
# Unit test for method min of class Timers
def test_Timers_min():
    name = 'MyTime'
    value = 0.0

    # Setup
    timers_0 = Timers()

    # Exercise
    timers_0.add(name=name, value=value)

    # Verify
    assert timers_0.min(name=name) == value



# Generated at 2022-06-25 15:18:41.325199
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0['a'] = 1
    timers_0['b'] = 2
    assert timers_0.max('a') == 1
    assert timers_0.max('b') == 2
    try:
        timers_0.max('c')
    except KeyError:
        pass
    else:
        assert False
    try:
        timers_0.max('')
    except KeyError:
        pass
    else:
        assert False
    assert timers_0.max(None) == 2


# Generated at 2022-06-25 15:18:51.936796
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    string_0 = "min"
    with pytest.raises(KeyError):
        assert timers_0.min(string_0)
    

# Generated at 2022-06-25 15:18:53.839678
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    assert not timers



# Generated at 2022-06-25 15:18:59.534915
# Unit test for method median of class Timers

# Generated at 2022-06-25 15:19:00.987456
# Unit test for method max of class Timers
def test_Timers_max():
    assert Timers().max("name") == 0


# Generated at 2022-06-25 15:19:08.914598
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.data['name'] = 0.4768228627240777
    # Test if KeyError is raised or not
    try:
        timers_0.min('name0')
    except KeyError:
        pass
    # Test if no error is raised
    try:
        assert str(list(timers_0.min('name'))) == "[0.4768228627240777]"
    except:
        print(
        'Expected: {0}\n'
        'Received: {1}\n'.format(
            str(["[0.4768228627240777]"]),
            str(list(timers_0.min('name'))),
        )
    )


# Generated at 2022-06-25 15:19:12.043075
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.add('name', 42)
    timers_1.median('name')
    timers_1['name'] = 42


# Generated at 2022-06-25 15:19:16.824991
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    timers_1.add(name = "foo", value = 3)
    timers_1.add(name = "foo", value = 2)
    timers_1.max(name = "foo")


# Generated at 2022-06-25 15:19:26.122878
# Unit test for method median of class Timers

# Generated at 2022-06-25 15:19:30.649137
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.clear()
    timers_0.add("Test Timer 0", 2.0)
    timers_0.add("Test Timer 0", 10.0)
    timers_0.add("Test Timer 0", 3.0)
    timers_0.add("Test Timer 1", 4.0)
    timers_0.add("Test Timer 1", 8.0)
    timers_0.add("Test Timer 1", 5.0)
    assert timers_0.min("Test Timer 0") == 2.0
    assert timers_0.min("Test Timer 1") == 4.0


# Generated at 2022-06-25 15:19:36.018021
# Unit test for method max of class Timers
def test_Timers_max():
    from random import random, seed
    from pytest import raises
    from typing import List, Tuple

    seed(0)

    timers = Timers()

    # Case 0
    timers.add('work', random())
    timers.add('work', random())
    timers.add('work', random())
    assert timers.max('work') == max(timers._timings['work'])

    # Case 1
    assert timers.max('empty') == 0.0

    # Case 2
    with raises(KeyError):
        timers.max('missing')


# Generated at 2022-06-25 15:19:45.182585
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name_0 = "Some random string"
    assert timers_0.min(name_0) == 0


# Generated at 2022-06-25 15:19:48.811874
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("name", 0.5520606929999094)
    assert abs(timers_0.max("name") - 0.5520606929999094) < 1e-6



# Generated at 2022-06-25 15:19:57.849568
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('Timer0', 1.0)
    timers_0.add('Timer0', 4.0)
    timers_0.add('Timer0', 7.0)
    timers_0.add('Timer0', 2.0)
    timers_0.add('Timer0', 8.0)
    timers_0.add('Timer0', 3.0)
    try:
        assert round(timers_0.median('Timer0'), 6) == 4.0
    except:
        assert False
    try:
        assert round(timers_0.median('Timer1'), 6) == 0.0
    except:
        assert False

# Generated at 2022-06-25 15:20:02.663319
# Unit test for method min of class Timers
def test_Timers_min():
    """Test for Timers.min method"""
    timers = Timers()
    assert timers.min("foo") == 0
    assert "foo" not in timers._timings

    timers = Timers()
    timers.data["foo"] = 3
    timers._timings["foo"] = [1, 2, 3, 4, 5]
    assert timers.min("foo") == 1
    assert timers.min("bar") == 0
    assert "bar" not in timers._timings



# Generated at 2022-06-25 15:20:06.267212
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("name", 2)
    assert (timers.median("name") == 2)


# Generated at 2022-06-25 15:20:16.336014
# Unit test for method min of class Timers
def test_Timers_min():
    # Test case 1:
    timers_1 = Timers()
    timers_1.add("name", 0.01)
    timers_1.add("name", 0.02)
    timers_1.add("name", 0.03)
    timers_1.add("name", 0.04)
    timers_1.min("name")
    assert timers_1.min("name") == 0.01
    # Test case 2:
    timers_2 = Timers()
    timers_2.add("name", 0.01)
    timers_2.add("name", 0.02)
    timers_2.add("name", 0.03)
    timers_2.add("name", 0.04)
    timers_2.add("name", 0.05)
    timers_2.min("name")

# Generated at 2022-06-25 15:20:19.533759
# Unit test for method median of class Timers
def test_Timers_median():
    my_timers = Timers()
    # Setup
    my_timers.add("a", 1)
    my_timers.add("a", 2)

    # Exercise
    expected = 1.5
    actual = my_timers.mean("a")
    # Verify
    assert actual == expected

# Generated at 2022-06-25 15:20:22.010393
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1["timer-1"] = 13
    timers_1["timer-2"] = 13
    assert timers_1.min("timer-1") == 0
    assert timers_1.min("timer-2") == 0


# Generated at 2022-06-25 15:20:27.279673
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.max(name='name') == 0.0, 'Class Timers, method max()'


# Generated at 2022-06-25 15:20:30.194825
# Unit test for method max of class Timers
def test_Timers_max():

    timers_0 = Timers()
    name = None
    value = -0.6281302378652288

    # Call method
    actual = timers_0.max(name)
    update = timers_0.max(name)

    # Assert that result from method call is expected
    expected = math.nan
    assert actual == expected



# Generated at 2022-06-25 15:20:44.487531
# Unit test for method median of class Timers
def test_Timers_median():
    # Test for example 0
    timers_0 = Timers()
    timers_0.add('client', 0.59)
    timers_0.add('client', 0.47)
    timers_0.add('client', 0.46)
    timers_0.add('client', 0.41)
    timers_0.add('client', 0.51)
    timers_0.add('client', 0.44)
    assert round(timers_0.median('client'), 2) == 0.48
    timers_0.add('server', 0.46)
    timers_0.add('client', 0.55)
    timers_0.add('server', 0.42)
    timers_0.add('server', 0.39)
    timers_0.add('server', 0.51)

# Generated at 2022-06-25 15:20:53.113220
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('x', 0.9317521387680156)
    timers_0.add('x', 0.873983453456773)
    timers_0.add('x', 0.4103283128223654)
    timers_0.add('x', 0.8350065966271337)
    timers_0.add('x', 0.18256265065175445)
    timers_0.add('x', 0.2433775056392398)
    timers_0.add('x', 0.8205147327534413)
    timers_0.add('x', 0.979056149547192)
    timers_0.add('x', 0.26954852917248386)

# Generated at 2022-06-25 15:20:55.356811
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    value_0 = timers_0.min('test')
    assert value_0 == 0


# Generated at 2022-06-25 15:20:56.852004
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name = ""
    timers_0.max(name)


# Generated at 2022-06-25 15:21:01.548112
# Unit test for method min of class Timers
def test_Timers_min():

    timers_1 = Timers()
    timers_1.add('entry_2', 0.9987338757400158)

    # Case 1
    key_1 = 'entry_2'
    expected_1 = min([0.9987338757400158])
    observed_1 = timers_1.min(key_1)
    assert expected_1 == observed_1



# Generated at 2022-06-25 15:21:08.226944
# Unit test for method max of class Timers
def test_Timers_max():
    test1 = Timers()
    test1.add("max", 29)
    test2 = Timers()
    test2.add("max", 42)
    test2.add("max", 0)
    test2.add("max", 39)
    test2.add("max", 29)
    test2.add("max", 0)
    test2.add("max", 0)
    test2.add("max", 0)
    test3 = Timers()
    test3.add("max", 77)
    test3.add("max", 26)
    test3.add("max", 0)
    test3.add("max", 46)
    test4 = Timers()
    test4.add("max", 40)
    test4.add("max", 51)
    test4.add("max", 71)
    test

# Generated at 2022-06-25 15:21:12.603357
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('name', 2.0)
    timers_0.mean('name')

# Generated at 2022-06-25 15:21:25.300868
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Setup
    timers_1 = Timers()
    timer_name_0 = 'test_timer_0'
    timer_value_0 = 2.6
    timer_name_1 = 'test_timer_1'
    timer_value_1 = 1.4
    timer_name_2 = 'test_timer_2'
    timer_value_2 = 1.2
    # Exercise
    timers_1.add(timer_name_0, timer_value_0)
    timers_1.add(timer_name_1, timer_value_1)
    timers_1.add(timer_name_2, timer_value_2)
    timers_1.add(timer_name_0, timer_value_0)
    timers_1.add(timer_name_1, timer_value_1)
    timers_1

# Generated at 2022-06-25 15:21:27.231278
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add('min', 1)

    t.min('min') == 1


# Generated at 2022-06-25 15:21:31.310781
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name_0 = "timer"
    value_0 = 2.5
    timers_0.add(name_0, value_0)
    assert timers_0.min(name_0) == 2.5
