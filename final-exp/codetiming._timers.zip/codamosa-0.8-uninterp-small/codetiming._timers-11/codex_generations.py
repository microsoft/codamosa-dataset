

# Generated at 2022-06-25 15:11:38.461052
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.data = {}
    timers_0._timings = {}
    timers_0.mean("name")
    timers_0.mean("__random_coverage_class_name__")


# Generated at 2022-06-25 15:11:41.663309
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test', 13)
    timers.add('test', 13)
    timers.add('test', 13)
    assert timers.min('test') == 13


# Generated at 2022-06-25 15:11:46.090692
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("name", 144.80317375684875)
    timers_0.add("name", 63.16321653877552)
    timers_0.add("name", 143.18783635106956)
    timers_0.add("name", 100.4908793056417)
    timers_0.add("name", 130.7353609920708)
    assert (timers_0.median("name")) == 130.7353609920708


# Generated at 2022-06-25 15:11:52.349916
# Unit test for method mean of class Timers
def test_Timers_mean():

    timers = Timers()

    # Create a list of values
    values = [1, 2, 5, 10, 20, 50, 100]

    # Add all elements of the list of values to the dictionary
    for value in values:
        timers.add('foo', value)

    # Calculate the mean of the values
    mean = sum(values) / len(values)

    # Compare the mean of the values to the mean produced by Timers.mean
    assert mean == timers.mean('foo')


# Generated at 2022-06-25 15:11:59.253283
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("Name", 1.0)
    timers_0.add("Name", 0.0)
    timers_0.add("Name", 2.0)
    timers_0.add("Name", 0.0)
    timers_0.add("Name", 1.0)
    timers_0.add("Name", 1.0)
    timers_0.add("Name", 0.0)
    timers_0.add("Name", 0.0)
    timers_0.add("Name", 0.0)
    timers_0.add("Name", 0.0)
    timers_0.add("Name", 0.0)
    assert timers_0.median("Name") == 0.0


# Generated at 2022-06-25 15:12:02.444200
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()

    timers.add("t1", 2.1)
    timers.add("t1", 3)
    timers.add("t2", 6.2)
    timers.add("t2", 5.9)

    assert 2.1 == timers.min("t1")
    assert 5.9 == timers.min("t2")


# Generated at 2022-06-25 15:12:09.426337
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.clear()

    counters_0 = Timers()
    timers_1 = counters_0.min('min')
    assert timers_1 == 0

    counters_0.add('min', 0.0)
    timers_1 = counters_0.min('min')
    assert timers_1 == 0.0

    counters_0.add('min', 0.5)
    timers_1 = counters_0.min('min')
    assert timers_1 == 0.0

    counters_0.add('min', 0.0)
    timers_1 = counters_0.min('min')
    assert timers_1 == 0.0

    counters_0.add('min', 1.0)
    timers_1 = counters_0.min('min')
    assert timers_1 == 0.0

# Generated at 2022-06-25 15:12:17.348469
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1.data = {
        'completed': 313.9900465011597,
        'k-means': 160.25919008255005
    }

# Generated at 2022-06-25 15:12:19.820620
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.clear()

    assert timers_0.mean("key_0") == 0.0


# Generated at 2022-06-25 15:12:25.368087
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test for mean method of class Timers"""
    timers_0 = Timers()
    timers_0.clear()
    timers_0.add("Timemes", 1.0)
    timers_0.add("Timemes", 0.0)
    assert timers_0.mean("Timemes") == 0.5
    assert timers_0.mean("Timemes") != 1.5
    assert timers_0.mean("Timemes") != 0.0


# Generated at 2022-06-25 15:12:29.905817
# Unit test for method median of class Timers
def test_Timers_median():
    # global timers_0
    timers_0 = Timers()
    assert math.isnan(timers_0.median("name_0"))


# Generated at 2022-06-25 15:12:31.267160
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.min(name="name")


# Generated at 2022-06-25 15:12:39.488826
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name_0 = ""
    # Retrieve the timer values for the given name
    assert isinstance(timers_0.apply(min, name=name_0), float)
    # Retrieve the timer values for the given name
    assert isinstance(timers_0.apply(sum, name=name_0), float)
    # Retrieve the timer values for the given name
    assert isinstance(timers_0.apply(len, name=name_0), float)


# Generated at 2022-06-25 15:12:43.126826
# Unit test for method max of class Timers
def test_Timers_max():
    times_0 = Timers()
    times_0.add("test", 0.0)
    result = times_0.max("test")
    print(result)
    assert isinstance(result, (int, float)), "Return type must be a float"


# Generated at 2022-06-25 15:12:51.026528
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert timers_0.min("name") == 0.0
    assert not hasattr(timers_0, "name")
    timers_0.add("str", -1.010000)
    assert timers_0.data == {"str": -1.010000}
    assert timers_0.str == -1.010000
    timers_0.add("str", -2.400000)
    assert timers_0.data == {"str": -3.410000}
    assert timers_0.str == -3.410000
    timers_0.add("str", -0.690000)
    assert timers_0.data == {"str": -4.100000}
    assert timers_0.str == -4.100000
    timers_0.add("str", -11.550000)


# Generated at 2022-06-25 15:12:53.868233
# Unit test for method min of class Timers
def test_Timers_min():

    timers_1 = Timers()
    timers_1.add('timer_1', 0.0)
    assert timers_1.min('timer_1') == 0.0
    timers_1.add('timer_1', 0.0)
    assert timers_1.min('timer_1') == 0.0


# Generated at 2022-06-25 15:12:58.079285
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    assert isinstance(timers, Timers)
    assert timers.median("wall") == 0
    timers.add("wall", 1)
    assert timers.median("wall") == 1
    timers.add("wall", 5)
    assert timers.median("wall") == 3
    timers.add("wall", 7)
    assert timers.median("wall") == 5
    timers.add("wall", 1)
    assert timers.median("wall") == 3.5
    assert timers.data["wall"] == 14
    assert timers.count("wall") == 4


# Generated at 2022-06-25 15:12:59.408711
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    value_0 = timers_0.mean('name_0')


# Generated at 2022-06-25 15:13:03.172804
# Unit test for method min of class Timers
def test_Timers_min():

    # Arrange
    timers_1 = Timers()
    name_0 = 'name 0'

    # Act
    # Assert
    if (timers_1.min(name_0) != 0): raise Exception('Failed test')


# Generated at 2022-06-25 15:13:05.495779
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert math.isnan(timers_0.mean('name_0')), 'AssertionError'


# Generated at 2022-06-25 15:13:17.739588
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("default", 3.51)
    timers_0.add("default", 2.86)
    timers_0.add("default", 0.71)
    timers_0.add("default", 5.95)
    timers_0.add("default", 8.39)
    timers_0.add("default", 3.00)
    timers_0.add("default", 1.69)
    timers_0.add("default", 8.41)
    timers_0.add("default", 6.72)
    timers_0.add("default", 4.60)
    assert timers_0.max("default") == 8.41


# Generated at 2022-06-25 15:13:19.686733
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.data = {'1': 1}
    timers._timings = {'1': [1]}
    mean = timers.mean('1')
    assert mean == 1.0


# Generated at 2022-06-25 15:13:24.545729
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    # Setup
    try:
        timers_0.add("test_timers", 0.5)
    except Exception:
        import sys
        import traceback

        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_exception(exc_type, exc_value, exc_traceback, file=sys.stdout)
        raise
    # Test
    try:
        timers_0.max("test_timers")
    except Exception:
        import sys
        import traceback

        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_exception(exc_type, exc_value, exc_traceback, file=sys.stdout)
        raise
    # Cleanup - none necessary


# Generated at 2022-06-25 15:13:35.800832
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_2 = Timers()
    timers_4 = Timers()
    timers_4.add('key_3', 1.1427902265272425)
    timers_4.add('key_10', 1.6293696058508619)
    timers_4.add('key_4', 4.06093325684057)
    timers_4.add('key_1', 5.868422460704815e-06)
    timers_4.add('key_6', -7.891512069644171e-06)
    timers_4.add('key_8', -1.0295865052969198e-06)
    timers_4.add('key_7', 1.2914097816692872e-05)

# Generated at 2022-06-25 15:13:39.576117
# Unit test for method max of class Timers
def test_Timers_max():
    """Test case for method max of class Timers"""

    # Setup
    timers_0 = Timers()

    # Exercise
    timers_0.add('s', 3.30123)
    # Verify
    assert timers_0.max('s') == 3.30123



# Generated at 2022-06-25 15:13:44.026291
# Unit test for method max of class Timers
def test_Timers_max():
    assert Timers.max(timers_0, "name0") == 0.0
    timers_0.add("name0", 0.0)
    assert Timers.max(timers_0, "name0") == 0.0
    timers_0.add("name0", 0.0)
    assert Timers.max(timers_0, "name0") == 0.0


# Generated at 2022-06-25 15:13:45.377398
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert timers_0.min('timer') == 0


# Generated at 2022-06-25 15:13:50.628394
# Unit test for method max of class Timers
def test_Timers_max():
    from random import uniform
    from time import sleep
    from math import isclose
    
    value = uniform(0.001, 10)
    sleep(value)
    timer = Timers()
    timer.add('test', value)
    assert isclose(timer.max('test'), value, rel_tol=0.01)
    

# Generated at 2022-06-25 15:13:56.293330
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()

    timers_0.add('Timer 1', 0.69123)
    timers_0.add('Timer 1', 0.14784)
    timers_0.add('Timer 1', 0.1478)
    timers_0.add('Timer 1', 0.64358)
    timers_0.add('Timer 1', 0.4439)
    timers_0.add('Timer 1', 0.60465)
    timers_0.add('Timer 1', 0.49273)
    timers_0.add('Timer 1', 0.84895)
    timers_0.add('Timer 1', 0.36147)
    timers_0.add('Timer 1', 0.46034)
    timers_0.add('Timer 2', 0.45732)

# Generated at 2022-06-25 15:14:03.069707
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timer_name_m = "tarkov"
    number_m = -1.396730582328213

    timers_0.add(timer_name=timer_name_m, value=number_m)
    assert timers_0.max(name=timer_name_m) == number_m


if __name__ == '__main__':
    test_case_0()
    test_Timers_max()

# Generated at 2022-06-25 15:14:12.277652
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('A', 5)
    timers.add('B', 4)
    timers.add('C', 3)
    timers.add('D', 2)
    timers.add('E', 1)
    assert timers.max('A') == 5
    assert timers.max('B') == 4
    assert timers.max('C') == 3
    assert timers.max('D') == 2
    assert timers.max('E') == 1


# Generated at 2022-06-25 15:14:21.130366
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    # AssertionError:
    try:
        timers_0.median("timer0")
        print("AssertionError:")
    except AssertionError:
        print("AssertionError:")
    # AssertionError:
    try:
        timers_0.median("timer0")
        print("AssertionError:")
    except AssertionError:
        print("AssertionError:")
    timers_0.add("timer0", 1.0)
    # AssertionError:
    try:
        timers_0.median("timer0")
        print("AssertionError:")
    except AssertionError:
        print("AssertionError:")
    timers_0.clear()

# Generated at 2022-06-25 15:14:27.382032
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    assert isinstance(timers, Timers)
    timers_0 = Timers()
    assert timers_0.mean("timer A") == 0
    timers_1 = Timers()
    timers_1.add("timer A", 3)
    assert timers_1.mean("timer A") == 3
    timers_2 = Timers()
    timers_2.add("timer A", 3)
    timers_2.add("timer A", 2)
    assert timers_2.mean("timer A") == 2.5


# Generated at 2022-06-25 15:14:36.852507
# Unit test for method mean of class Timers
def test_Timers_mean():
    """The mean value of the timers"""
    from flask import Flask

    app = Flask(__name__)
    timers = Timers()

    @app.before_request
    def timer_before_request():
        timers["before_request"] = 0.1

    @app.after_request
    def timer_after_request(response):
        timers["after_request"] = 0.2
        response.headers["X-Test-Timers-Mean"] = f"{timers.mean('before_request')},{timers.mean('after_request')}"
        return response

    client = app.test_client()
    response = client.get("/")
    assert response.headers["X-Test-Timers-Mean"] == "0.1,0.2"



# Generated at 2022-06-25 15:14:43.119987
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.max("/tmp/conda/conda-bld/pyarrow_1564435876987/work/python/build/temp.linux-x86_64-3.7/src/arrow")
    timers_0.max("/tmp/conda/conda-bld/pyarrow_1564435876987/work/python/build/temp.linux-x86_64-3.7/src/arrow/array.cpp")
    timers_0.max("/tmp/conda/conda-bld/pyarrow_1564435876987/work/python/build/temp.linux-x86_64-3.7/src/arrow/buffer.cpp")

# Generated at 2022-06-25 15:14:46.576563
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = "name"
    str_0 = timers_0.mean(name_0)


# Generated at 2022-06-25 15:14:48.723942
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert (timers_0.max("")) in {float, 0}


# Generated at 2022-06-25 15:14:55.164731
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers({'test_0': 1, 'test_1': 2})
    timers_1.add('test_1', 3)
    assert timers_1.median('test_1') == 2.5
    assert timers_1.median('test_0') == 1
    try:
        timers_1.median('not_inside')
    except RuntimeError:
        print('not_inside not in timers_1')
    assert timers_1.median('not_inside') == 0


# Generated at 2022-06-25 15:15:03.879063
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.data["list"] = -0.5421496802651537

# Generated at 2022-06-25 15:15:07.601064
# Unit test for method median of class Timers
def test_Timers_median():
    # Setup input parameters
    params = {'name': 'context'}
    timers_0 = Timers()
    # Setup function call
    result = timers_0.median(**params)
    # Verify results
    assert result is NotImplemented


# Generated at 2022-06-25 15:15:24.464883
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.data[""] = 1.1
    timers_0._timings[""] = [0.0, 1.1]
    test_args = []
    # Test TypeError
    try:
        timers_0.mean(*test_args)
    except TypeError as err:
        print(err)
    # Test ValueError
    try:
        timers_0.mean(*test_args)
    except ValueError as err:
        print(err)
    # Test KeyError
    try:
        timers_0.mean(*test_args)
    except KeyError as err:
        print(err)
    # Test AttributeError
    try:
        timers_0.mean(*test_args)
    except AttributeError as err:
        print(err)

# Generated at 2022-06-25 15:15:26.866429
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    result = timers.min("test")
    assert result == 1


# Generated at 2022-06-25 15:15:28.595490
# Unit test for method max of class Timers
def test_Timers_max():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 15:15:36.805478
# Unit test for method mean of class Timers
def test_Timers_mean():
    """
    Tests:

    - Basic functionality
    - Timer does not exist
    """
    timers_0 = Timers()
    timers_0.add("timer_0", 1.35)
    timers_0.add("timer_0", 2.71)

    assert timers_0.mean("timer_0") == 2.03
    timers_0.add("timer_0", 4.07)
    assert timers_0.mean("timer_0") == 2.69
    with pytest.raises(KeyError):
        timers_0.mean("timer_1")



# Generated at 2022-06-25 15:15:46.053635
# Unit test for method mean of class Timers
def test_Timers_mean():
    print("\n****************")
    print("Testing method mean of class Timers")
    timers_1 = Timers()
    name_1 = "test_1"
    timers_1.add(name_1, 1.31)
    timers_1.add(name_1, 2.31)
    timers_1.add(name_1, 3.31)
    timers_1.add(name_1, 4.31)
    timers_1.add(name_1, 5.31)
    timers_1.add(name_1, 6.31)
    result = timers_1.mean(name_1)
    expected = 3.86
    print("result  = ", result)
    print("expected= ", expected)
    assert result == expected


# Generated at 2022-06-25 15:15:50.197225
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('time_0', 0.0)
    timers_0.add('time_0', 0.0)
    timers_0.add('time_0', 0.0)
    timers_0.add('time_0', 0.0)
    # print(timers_0.data)
    # print(timers_0._timings)
    assert 0.0 == timers_0.mean('time_0')



# Generated at 2022-06-25 15:15:53.236673
# Unit test for method median of class Timers
def test_Timers_median():
    from Timer import Timers
    timers_0 = Timers()
    value_0 = timers_0.median("bViTgXjx")
    assert value_0 == 0.0


# Generated at 2022-06-25 15:16:02.044892
# Unit test for method min of class Timers
def test_Timers_min():
    start = time.time()
    cases = [
        Timers(),
        Timers(),
        Timers(),
        Timers(),
        Timers(),
        Timers(),
        Timers(),
    ]

    def test_case_0():
        # Initialize the data
        timers_0 = Timers()

        # Check if the result is as expected
        expected = 0
        actual = timers_0.min()
        assert expected == actual

        # Run the test case again; check if the result is as expected
        timers_0.add(name='global_time', value=0.00112)
        expected = 0.00112
        actual = timers_0.min()
        assert expected == actual

        # Run the test case again; check if the result is as expected

# Generated at 2022-06-25 15:16:04.115999
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("key", 1)
    timers_0.add("key", 3)
    assert timers_0.max("key") == 3


# Generated at 2022-06-25 15:16:04.791143
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()


# Generated at 2022-06-25 15:16:16.694322
# Unit test for method max of class Timers
def test_Timers_max():
    from dcanlab.util import Timers

    timers_1 = Timers()
    timers_1.add("name_1", value=0)
    timers_1.add("name_1", value=0.0)
    timers_1.max("name_2")
    timers_1.add("name_2", value=0.0)


# Generated at 2022-06-25 15:16:19.990334
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0['default'] = 0
    key = 'default'
    val = timers_0.min(key)
    assert val == 0


# Generated at 2022-06-25 15:16:21.655889
# Unit test for method mean of class Timers
def test_Timers_mean():
    assert Timers().mean('name:0') == math.nan


# Generated at 2022-06-25 15:16:33.717432
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)
    timers_0.add("name", 0.0)

# Generated at 2022-06-25 15:16:35.660330
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.add('a', 1)
    assert timers_1.median('a') == 1
    assert timers_1.median('b') == 0


# Generated at 2022-06-25 15:16:42.660710
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = "qc_tests"
    value_0 = 1.0
    timers_0.add(name_0, value_0)
    name_1 = "qc_tests"
    value_1 = 1.0
    timers_0.add(name_1, value_1)
    name_2 = "qc_tests"
    value_2 = 0.0
    timers_0.add(name_2, value_2)
    name_3 = "qc_tests"
    value_3 = 1.0
    timers_0.add(name_3, value_3)
    name_4 = "qc_tests"
    value_4 = 1.0
    timers_0.add(name_4, value_4)

# Generated at 2022-06-25 15:16:51.212709
# Unit test for method median of class Timers
def test_Timers_median():
    # Example from docstring
    timers_0 = Timers()
    timers_0.add('a', 1)
    timers_0.add('a', 10)
    n = timers_0.median('a')
    assert n == 5.5
    # Example: Error handling
    timers_1 = Timers()
    try:
        try:
            n = timers_1.median('a')
            assert False
        except KeyError as exception:
            assert str(exception) == "'a'"
    except:
        # We don't need to check the details
        # of the KeyError exception
        assert False


# Generated at 2022-06-25 15:16:55.295750
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("name", 99.28)
    timers_1 = timers_0.median("name")
    assert math.isclose(timers_1, 99.28, rel_tol=1e-09, abs_tol=0.0)


# Generated at 2022-06-25 15:16:58.014430
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    str_0: str = timers_0.max("2")


# Generated at 2022-06-25 15:17:04.917652
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("name_0", 1.0)
    timers_0.add("name_0", 1.0)
    timers_0.add("name_0", 1.0)
    timers_0.add("name_0", 1.0)
    assert math.isclose(timers_0.mean("name_0"), 1.0)
    assert isinstance(timers_0.mean("name_0"), float)


# Generated at 2022-06-25 15:17:25.056739
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('min', 2)
    timers_0.add('min', 2)
    timers_0.add('min', 2)
    timers_0.add('max', 2)
    timers_0.add('max', 2)
    assert timers_0.max('min') == 2
    assert timers_0.max('max') == 2


# Generated at 2022-06-25 15:17:34.574270
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers({'example_name': 0.0})
    timers_2 = Timers({'example_name': 14.0})
    timers_3 = Timers({'example_name': -3.0})
    timers_1.add('example_name', 30.0)
    assert timers_1.max('example_name') == 30.0

    timers_2.add('example_name', 14.0)
    assert timers_2.max('example_name') == 14.0

    timers_3.add('example_name', -3.0)
    assert timers_3.max('example_name') == -3.0
    return



# Generated at 2022-06-25 15:17:44.870734
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    #AssertionError: list index out of range
#    assert timers_0.median("median") == 0.0
    timers_0.add("median", 1.0)
    assert timers_0.median("median") == 1.0
    timers_0.add("median", 2.0)
    assert timers_0.median("median") == 1.5
    timers_0.add("median", 3.0)
    assert timers_0.median("median") == 2.0
    timers_0.add("median", 4.0)
    assert timers_0.median("median") == 2.5
    timers_0.add("median", 5.0)
    assert timers_0.median("median") == 3.0

# Generated at 2022-06-25 15:17:50.750581
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Setup
    timers_1 = Timers()

    timers_1.add('init', 0.0)
    timers_1.add('run_loop', 0.0)
    timers_1.add('run_loop', 0.0)
    timers_1.add('run_loop', 0.0)
    timers_1.add('run_loop', 0.0)
    timers_1.add('run_loop', 0.0)
    timers_1.add('run_loop', 0.0)
    timers_1.add('run_loop', 0.0)
    timers_1.add('run_loop', 0.0)
    timers_1.add('run_loop', 0.0)
    timers_1.add('run_loop', 0.0)

# Generated at 2022-06-25 15:17:57.234042
# Unit test for method median of class Timers
def test_Timers_median():
    # Create test instances
    timers_0 = Timers()
    timers_1 = Timers()
    timers_2 = Timers()

    for name in (
        "namethree",
        "nametwo",
        "nameone",
        "namezero",
        "nameten",
        "namefive",
        "namefour",
        "namesix",
        "nameeight",
        "namenine",
        "nameseven",
    ):
        timers_0[name] = Timers.median(timers_1, name=name)
        timers_2[name] = timers_0[name]



# Generated at 2022-06-25 15:18:04.015038
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("gT", 0.0)
    timers_0.add("gT", 0.0)
    timers_0.add("gT", 0.0)
    timers_0.add("gT", 0.0)
    timers_0.add("gT", 0.0)
    timers_0.add("gT", 0.0)
    timers_0.add("gT", 0.0)
    timers_0.add("gT", 0.0)
    timers_0.add("gT", 0.0)
    timers_0.add("gT", 0.0)
    timers_0.add("gT", 0.0)
    timers_0.add("gT", 0.0)

# Generated at 2022-06-25 15:18:08.366329
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("timer_1", 0.000)
    timers.add("timer_2", 0.001)
    timers.add("timer_3", 0.004)
    assert timers.min("timer_1") == 0.000, "Timers.min() failed"


# Generated at 2022-06-25 15:18:10.786736
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    result_0 = timers_0.max(name="")
    assert result_0 is 0.0


# Generated at 2022-06-25 15:18:19.557861
# Unit test for method mean of class Timers
def test_Timers_mean():
    from random import gauss
    timers = Timers()
    timers.add(name="READ_BARCODE", value=gauss(mu=4, sigma=1))
    timers.add(name="READ_BARCODE", value=gauss(mu=4, sigma=1))
    timers.add(name="READ_BARCODE", value=gauss(mu=4, sigma=1))
    timers.add(name="READ_BARCODE", value=gauss(mu=4, sigma=1))
    timers.add(name="READ_BARCODE", value=gauss(mu=4, sigma=1))
    assert round(timers.mean(name="READ_BARCODE"), 3) == 3.977



# Generated at 2022-06-25 15:18:24.627324
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('name_0', 23.65)
    timers_0.add('name_0', 8.67)
    timers_0.add('name_0', -3.3)
    timers_0.add('name_0', 52.67)
    timers_0.add('name_0', -3.3)
    assert 16.0 == timers_0.mean(name='name_0')
    assert 16.0 == timers_0.mean('name_0')



# Generated at 2022-06-25 15:19:03.362471
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add("a", 1)
    timers_1.add("a", 2)
    timers_1.add("a", 3)
    timers_1.mean("a")


# Generated at 2022-06-25 15:19:05.167786
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert math.isnan(timers_0.mean("name_0"))


# Generated at 2022-06-25 15:19:12.332097
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()

    timers_0.data = {
        "t1": 4,
        "t2": 2,
        "t3": 3
    }
    assert timers_0.mean("t1") == 4
    assert timers_0.mean("t2") == 2
    assert timers_0.mean("t3") == 3
    assert timers_0.mean("t4") == 0

    timers_0._timings = {
        "t1": [1, 2, 3],
        "t2": [1, 1, 1],
        "t3": [2, 3, 4]
    }
    assert timers_0.mean("t1") == 2
    assert timers_0.mean("t2") == 1
    assert timers_0.mean("t3") == 3
    assert timers_0

# Generated at 2022-06-25 15:19:20.629193
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    # Imports for test cases.
    import math
    import random
    # The following value will be used to check if the function raises an error.
    # Set to the value of the function argument which should cause the function to raise an error.
    function_arg_for_error = None
    # Test case 0 is a normal case.
    test_name_0 = 'normal case'

# Generated at 2022-06-25 15:19:28.919295
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('main_loop', 0.0)
    timers_0.add('main_loop', 0.0)
    timers_0.add('main_loop', 0.0)
    try:
        assert math.isclose(timers_0.mean('main_loop'), 0.0)
        print('Test passed')
    except:
        print('Test failed')

# This is a command line utility to test the methods of the class Timers.
# It is used by pytest-3 to run the tests in test_timers (this is not a real unit test).
# The test case is defined in test_timers.py
import sys

print(sys.argv[1])
exec(sys.argv[1])

# Generated at 2022-06-25 15:19:29.931153
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    assert timers_1.max("") == 0


# Generated at 2022-06-25 15:19:37.195334
# Unit test for method max of class Timers
def test_Timers_max():
    # Set up a Timers object
    timers_1 = Timers()
    # Try and get the maximum value of a timer that hasn't been set
    # This should throw a KeyError
    try:
        timers_1.max('not_a_valid_key')
    except KeyError:
        # If it worked, test passes
        pass
    else:
        # Otherwise, test failed
        assert False
    # Add a valid timer
    timers_1.add('valid_name', 1)
    # Try and get the maximum value of the valid timer
    # This should be 1
    assert timers_1.max('valid_name') == 1
    # Add some more values to the timer and check the maximum again
    # This should be 3
    timers_1.add('valid_name', 2)

# Generated at 2022-06-25 15:19:47.357647
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name = "test"
    assert timers_0.mean(name) == 0
    assert timers_0.mean(name) == 0
    timers_0.add(name, 1)
    assert timers_0.mean(name) == 1
    assert timers_0.mean(name) == 1
    name = "test"
    timers_0.add(name, 2)
    assert timers_0.mean(name) == 1.5
    assert timers_0.mean(name) == 1.5
    name = "test"
    timers_0.add(name, 3)
    assert timers_0.mean(name) == 2.0
    assert timers_0.mean(name) == 2.0


# Generated at 2022-06-25 15:19:53.331636
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("foo", 0)
    assert timers.min("foo") == 0
    timers.add("foo", 9)
    assert timers.min("foo") == 0
    timers.add("foo", -4.4)
    assert timers.min("foo") == -4.4
    assert timers.min("bar") == 0


# Generated at 2022-06-25 15:19:54.924952
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name = str()
    assert timers_0.mean(name) == 0


# Generated at 2022-06-25 15:21:10.296220
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()

    # Add to timer 0
    timers_0.add('timer_0', 0.0)
    timers_0.add('timer_0', 0.0)
    timers_0.add('timer_0', 0.0)

    # Add to timer 1
    timers_0.add('timer_1', 0.0)
    timers_0.add('timer_1', 0.0)
    timers_0.add('timer_1', 0.0)

    # Add to timer 2
    timers_0.add('timer_2', 0.0)
    timers_0.add('timer_2', 0.0)
    timers_0.add('timer_2', 0.0)

    # Add to timer 3
    timers_0.add('timer_3', 0.0)
    timers

# Generated at 2022-06-25 15:21:14.187896
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    name_1: str = '0'
    # Init
    timers_0.add(name_1, 0.0)
    # Assert expected results
    assert '0' in timers_0
    assert not '1' in timers_0


# Generated at 2022-06-25 15:21:19.204908
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("default", 0.00410104)
    timers.add("default", 0.00276094)
    timers.add("default", 0.0036207)
    timers.add("default", 0.00386727)
    assert math.isclose(timers.min("default"), 0.00276094, rel_tol=1e-09)


# Generated at 2022-06-25 15:21:28.289100
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert math.isnan(timers_0.median('foo'))
    timers_0.add('foo', 1.2)
    assert timers_0.median('foo') == 1.2
    timers_0.add('foo', 3.4)
    assert timers_0.median('foo') == 2.3
    timers_0.add('foo', 5.6)
    assert timers_0.median('foo') == 3.4


# Generated at 2022-06-25 15:21:39.697392
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    # Check that the value 0.0 is returned when there are no timers
    assert (timers_0.min("timer_0") == 0.0)
    timers_0.add("timer_0", value=0.707157435)
    # Check that the minimum value is returned and not the sum
    assert (timers_0.min("timer_0") == 0.707157435)
    timers_0.add("timer_0", value=0.849141724)
    # Check that the minimum value is returned and not the sum
    assert (timers_0.min("timer_0") == 0.707157435)
    # Check that a KeyError is raised when a timer that has not been added is
    # requested