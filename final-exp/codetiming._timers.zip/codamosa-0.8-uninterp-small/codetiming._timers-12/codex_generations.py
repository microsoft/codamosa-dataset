

# Generated at 2022-06-25 15:11:43.068983
# Unit test for method median of class Timers
def test_Timers_median():
    """
    Unit test for method median of class Timers
    """
    # Missing key
    timers_0 = Timers()
    with raises_regexp(KeyError, "y"):
        timers_0.median("y")



# Generated at 2022-06-25 15:11:46.701481
# Unit test for method median of class Timers
def test_Timers_median():
    # Setup
    timers = Timers()
    # Exercise
    timers.add("name1", 1)
    timers.add("name1", 1)
    timers.add("name1", 1)
    m = timers.median("name1")
    # Verify
    assert m == 1.0, "Expected to get 1.0"

# Generated at 2022-06-25 15:11:48.682630
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('a', 1)
    assert timers.mean('a') == 1


# Generated at 2022-06-25 15:11:50.856735
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert timers_0.min('key_0') == 0


# Generated at 2022-06-25 15:11:57.802094
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test 0", 4)
    res = timers.min("test 0")
    assert res == 4

    timers.add("test 1", 2.4)
    res = timers.min("test 1")
    assert res == 2.4

    timers.add("test 2", 2.5)
    res = timers.min("test 2")
    assert res == 2.5

    timers.add("test 3", 2.6)
    res = timers.min("test 3")
    assert res == 2.6

    timers.add("test 4", 2.6)
    res = timers.min("test 4")
    assert res == 2.6


# Generated at 2022-06-25 15:11:58.697237
# Unit test for method min of class Timers
def test_Timers_min():
    assert Timers().min("foo") == 0


# Generated at 2022-06-25 15:12:01.843464
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('key1', 1)
    timers.add('key1', 7)
    timers.add('key2', 11)
    assert timers.min('key1') == 1
    assert timers.min('key2') == 11
    try:
        timers.min('key3')
    except KeyError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-25 15:12:02.811113
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.mean("name")


# Generated at 2022-06-25 15:12:06.156916
# Unit test for method median of class Timers
def test_Timers_median():

    # Declare a Timers instance
    timers_0 = Timers()

    # Assign the property name to the value 'timer'
    name = 'timer'

    # Call the method median with arguments of type Timers
    result = timers_0.median(name)
    assert isinstance(result, float)


# Generated at 2022-06-25 15:12:07.686370
# Unit test for method max of class Timers
def test_Timers_max():

    # Set up parametrization
    timers_1 = Timers({"a": 5, "b": .01})

    # Test the method
    assert timers_1.max(name="a") == 5
    assert timers_1.max(name="b") == .01


# Generated at 2022-06-25 15:12:14.843130
# Unit test for method median of class Timers
def test_Timers_median():
    """Check if median of Timers works correctly
    """
    # Setup
    timers_k = Timers()
    timers_k.add("timer_1", 3)
    timers_k.add("timer_1", 4)
    timers_k.add("timer_1", 2)
    # Exercise
    value = timers_k.median("timer_1")
    # Verify
    assert value == 3
    # Cleanup - nothing to do since the instance will be destroyed



# Generated at 2022-06-25 15:12:21.159686
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    for _ in range(100):
        timers_0.add("", 0.0)
    timers_0[""] = 0.0
    for _ in range(100):
        timers_0.add("", 0.0)
    for _ in range(100):
        timers_0.add("", 0.0)
    for _ in range(100):
        timers_0.add("", 0.0)
    assert round(timers_0.max(""), 4) == 0.0


# Generated at 2022-06-25 15:12:28.185460
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert timers_0.median('no_timers') == 0
    timers_0.add('Test timer 3', 0.00886731)
    timers_0.add('Test timer 3', 0.01134816)
    timers_0.add('Test timer 3', 0.0107991)
    timers_0.add('Test timer 3', 0.00693616)
    timers_0.add('Test timer 3', 0.01075416)
    assert timers_0.median('Test timer 3') == 0.010781639999999999



# Generated at 2022-06-25 15:12:29.802842
# Unit test for method max of class Timers
def test_Timers_max():
    # Creating test object
    timers_1 = Timers()

    # Getting value of max
    timers_1.max('avocado')

# Generated at 2022-06-25 15:12:34.490672
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    map_0 = [10, 1, 2, 4, 5, 8, 3]
    for element in map_0:
        timers_0.add('one', element)
    assert timers_0.max('one') == 10


# Generated at 2022-06-25 15:12:44.365643
# Unit test for method median of class Timers
def test_Timers_median():
    method_name = "median"
    #### Assert Timers has a method median ####
    assert hasattr(Timers, method_name), (
        f"Timers does not have a method {method_name}."
    )
    #### Method is callable ####
    method = getattr(Timers, method_name)
    assert callable(method), (
        f"{method_name} is not callable."
    )
    #### Method signature is correct ####
    args = inspect.signature(method).parameters.keys()
    assert args == {'name'}, (
        f"{method_name} arguments should be (name)."
    )
    #### Method returns what is expected ####
    output = method()
    expected = None

# Generated at 2022-06-25 15:12:46.757220
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    timers.add('test', 3)
    assert timers.mean('test') == 2.0


# Generated at 2022-06-25 15:12:53.116580
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    try:
        timers_0.mean("timers_0")
    except Exception as e_0:
        assert type(e_0) is KeyError
    timers_0.add("timers_0", 1.0)
    assert timers_0.mean("timers_0") == 1.0
    timers_0.add("timers_0", 2.0)
    assert timers_0.mean("timers_0") == 1.5



# Generated at 2022-06-25 15:12:58.031432
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("name",float("0.01"))
    assert timers_0.mean("name") == 0.01


# Generated at 2022-06-25 15:13:01.319118
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    res = timers.median("key")
    timers.data["key"] = 1
    res = timers.median("key")
    timers.add("key", 2)
    res = timers.median("key")


# Generated at 2022-06-25 15:13:12.906877
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('test_key', 1.0)
    assert timers_0.max('test_key') == 1.0
    timers_0.clear()
    timers_0.add('test_key', 0.0)
    assert timers_0.max('test_key') == 0.0
    timers_0.clear()
    timers_0.add('test_key', -1.0)
    assert timers_0.max('test_key') == -1.0
    timers_0.clear()
    timers_0.add('test_key', float('-inf'))
    assert math.isnan(timers_0.max('test_key'))
    timers_0.clear()
    timers_0.add('test_key', float('inf'))

# Generated at 2022-06-25 15:13:13.757408
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()


# Generated at 2022-06-25 15:13:17.380558
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    # Test case 0:
    timers.add("abc", 12)
    timers.add("abc", 6)
    timers.add("abc", 8)
    # Function 'max' of class 'Timers' should return 12 for input {'abc': [12, 6, 8]}

    assert timers.max("abc") == 12



# Generated at 2022-06-25 15:13:18.143519
# Unit test for method min of class Timers
def test_Timers_min():
    pass

# Generated at 2022-06-25 15:13:22.886065
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()

    timers.add("test1", 1)
    timers.add("test1", 1)
    timers.add("test2", 2)

    assert timers.min("test1") == 1
    assert timers.min("test2") == 2


# Generated at 2022-06-25 15:13:28.691055
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = "mean"
    timers_0.add(name_0, 1020)
    timers_0.add(name_0, 1030)
    actual_0 = timers_0.mean(name_0)
    expected_0 = 1025
    assert(actual_0 == expected_0)


# Generated at 2022-06-25 15:13:32.713265
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("foo", 9.0)
    timers_0.add("foo", -5.0)
    timers_0.add("foo", 2.0)
    timers_0.add("foo", 6.0)
    assert timers_0.max("foo") == 9.0


# Generated at 2022-06-25 15:13:43.438831
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert timers_0.median("name_0") == 0.0
    assert math.isnan(timers_0.median("name_1"))
    assert math.isnan(timers_0.median("name_2"))
    assert math.isnan(timers_0.median("name_3"))
    assert math.isnan(timers_0.median("name_4"))
    assert math.isnan(timers_0.median("name_5"))
    assert math.isnan(timers_0.median("name_6"))
    assert math.isnan(timers_0.median("name_7"))
    assert math.isnan(timers_0.median("name_8"))

# Generated at 2022-06-25 15:13:49.869317
# Unit test for method min of class Timers
def test_Timers_min():
    timers_20 = Timers()
    timers_20.add('L0', 2)
    assert timers_20.min('L0') == 2, "timers.min test failed"
    timers_21 = Timers()
    assert timers_21.min('L0') == 0, "timers.min test failed"


# Generated at 2022-06-25 15:13:52.123842
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name_0 = 'String'
    timers_0.max(name_0)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 15:13:57.350842
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    val_0 = timers_0.median("eXhXbJ")
    assert val_0 == 0.0


# Generated at 2022-06-25 15:14:07.646158
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('total', 0.0109980083)
    timers_0.add('total', 0.0110210028)
    timers_0.add('total', 0.0110160029)
    timers_0.add('total', 0.0027800016)
    timers_0.add('total', 0.0027539858)
    timers_0.add('total', 0.0028349292)
    timers_0.add('total', 0.0028430356)
    timers_0.add('total', 0.002855)
    timers_0.add('total', 0.002853)
    timers_0.add('total', 0.0028530029)
    timers_0.add('total', 0.0110540023)
    timers

# Generated at 2022-06-25 15:14:09.670977
# Unit test for method median of class Timers
def test_Timers_median():
    timer_1 = Timers()
    assert timer_1.median("name") == 0
    assert "name" not in timer_1._timings


# Generated at 2022-06-25 15:14:15.842466
# Unit test for method max of class Timers
def test_Timers_max():
    for dummy_index in range(10):
        timers_0 = Timers()
        timers_0.add('b', 2.7278946557655458e-05)
        timers_0.add('a', 2.711582660675049e-05)
        timers_0.add('a', 2.711582660675049e-05)
        timers_0.add('b', 2.711582660675049e-05)
        timers_0.add('a', 2.711582660675049e-05)
        assert math.isclose(timers_0.max('a'), 2.711582660675049e-05, abs_tol=1e-09)

# Generated at 2022-06-25 15:14:22.864787
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("key_0", 0.0625)
    timers_0.add("key_1", 0.0625)
    timers_0.add("key_2", 0.0625)
    timers_0.add("key_3", 0.0625)
    timers_0.add("key_4", 0.0625)
    timers_0.add("key_5", 0.0625)
    timers_0.add("key_6", 0.0625)
    timers_0.add("key_7", 0.0625)
    timers_0.add("key_8", 0.0625)
    timers_0.add("key_9", 0.0625)
    timers_0.add("key_10", 0.0625)
    timers_

# Generated at 2022-06-25 15:14:27.200939
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()

    timers_0.add('test_key_0', 0.01)

    timers_0.add('test_key_1', 0.02)

    timers_0.add('test_key_2', 0)

    assert timers_0.median('test_key_0') == 0.01


# Generated at 2022-06-25 15:14:32.181062
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name_0 = None
    # Assigning to NameError from None
    try:
        name_0 = (1 + 0)
    except NameError:
        name_0 = float('nan')
    float_0 = timers_0.max(name_0)


# Generated at 2022-06-25 15:14:34.193877
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()

    assert math.isnan(timers_0.median(name='htls_build_time'))



# Generated at 2022-06-25 15:14:38.858614
# Unit test for method max of class Timers
def test_Timers_max():
    from datetime import datetime
    from statsuma.timers import Timers
    timers_0 = Timers()
    timers_0.add("name_0", 0.1234)
    timers_0.add("name_0", 0.1234)
    assert timers_0.max("name_0") == 0.1234

# Generated at 2022-06-25 15:14:50.603770
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('b', 0.0)
    timers_0.add('e', 0.0)
    timers_0.add('d', 0.0)
    timers_0.add('d', 0.0)
    timers_0.add('b', 0.0)
    timers_0.add('b', 0.0)
    timers_0.add('b', 0.0)
    timers_0.add('a', 0.0)
    timers_0.add('e', 0.0)
    timers_0.add('d', 0.0)
    timers_0.add('e', 0.0)
    timers_0.add('a', 0.0)

    actual = timers_0.median('d')
    expected = 0.0


# Generated at 2022-06-25 15:14:55.921218
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('timer', 2)
    timers.add('timer', 4)
    timers.add('timer', 4)
    timers.add('timer', 4)
    timers.add('timer', 5)
    timers.add('timer', 5)
    timers.add('timer', 7)
    timers.add('timer', 9)
    assert timers.median('timer') == 4
    try:
        timers.median('unknown')
    except KeyError as exc:
        assert str(exc) == "'unknown'"


# Generated at 2022-06-25 15:15:00.576717
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.min("test") == 1
    assert timers.max("test") == 3
    assert timers.mean("test") == 2
    assert timers.median("test") == 2
    assert timers.total("test") == 6

# Generated at 2022-06-25 15:15:02.685607
# Unit test for method min of class Timers
def test_Timers_min():
    # Local variable declarations
    name = None

    # Get values
    timers_0 = Timers()
    name = ""

    timers_0.min(name)


# Generated at 2022-06-25 15:15:08.459995
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_1 = Timers()
    timers_2 = Timers()
    timers_3 = Timers()
    timers_4 = Timers()
    timers_5 = Timers()
    timers_6 = Timers()
    timers_7 = Timers()
    timers_8 = Timers()
    timers_9 = Timers()

    assert timers_0.min('name') == 0
    assert timers_1.min('name') == 0
    assert timers_2.min('name') == 0
    assert timers_3.min('name') == 0
    assert timers_4.min('name') == 0
    assert timers_5.min('name') == 0
    assert timers_6.min('name') == 0
    assert timers_7.min('name') == 0
    assert timers_8

# Generated at 2022-06-25 15:15:11.156832
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    try:
        timers_0_actual = timers_0.mean("timer_0")
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 15:15:14.159798
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("duration", 2)
    assert timers_0.min("duration") == 2


# Generated at 2022-06-25 15:15:16.883388
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name_0 = ""
    value_0 = timers_0.min(name_0)
    assert value_0 == 0.0


# Generated at 2022-06-25 15:15:21.554546
# Unit test for method max of class Timers
def test_Timers_max():
    # Create example timers
    timers = Timers()
    timers.add("a", 5)
    timers.add("a", 15)
    timers.add("b", 12)

    # Check max
    assert timers.max("a") == 15
    assert timers.max("b") == 12
    assert timers.max("c") == 0



# Generated at 2022-06-25 15:15:25.639533
# Unit test for method median of class Timers
def test_Timers_median():
    # Assigns
    timers_0 = Timers()
    timers_0.add('name', 0.042733)

    # Tests
    assert isinstance(timers_0.median('name'), (float, int))


# Generated at 2022-06-25 15:15:29.413354
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('timer_0', 5.0)
    assert timers_0.mean('timer_0') == 5.0
    # assert timers_0.mean('timer_1') == math.nan


# Generated at 2022-06-25 15:15:32.513069
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name = "pycddlib"
    timers_0.add(name, 0)
    # Check the value of max
    assert (0, timers_0.max(name))


# Generated at 2022-06-25 15:15:41.800485
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('value', 8.0)
    timers_0.add('value', 7.0)
    timers_0.add('value', 6.0)
    timers_0.add('value', 5.0)
    timers_0.add('value', 4.0)
    timers_0.add('value', 3.0)
    timers_0.add('value', 2.0)
    timers_0.add('value', 1.0)
    assert timers_0.median('value') == 5.0
    assert timers_0.count('value') == 8


# Generated at 2022-06-25 15:15:49.857349
# Unit test for method median of class Timers
def test_Timers_median():
    test_cases = [
        dict(
            timers = Timers({"time_0": 11.0, "time_1": 11.0}),
            name = "time_0",
            expected = 11.0,
        ),
        dict(
            timers = Timers({"time_0": 11.0, "time_1": 11.0}),
            name = "time_2",
            expected = math.nan,
        ),
    ]
    for case in test_cases:
        timers = case["timers"]
        name = case["name"]
        expected = case["expected"]
        assert timers.median(name) == expected


# Generated at 2022-06-25 15:15:51.325502
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert NotImplementedError(timers_0.min)


# Generated at 2022-06-25 15:15:55.747676
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('start_load.csv', 1.0)
    timers_0.add('start_load.csv', 5.0)
    timers_0.add('start_load.csv', 3.0)
    assert timers_0.mean('start_load.csv') == 3.0


# Generated at 2022-06-25 15:16:03.841519
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('test0', 0.1918664)
    timers_0.add('test1', 0.7392736)
    timers_0.add('test2', 0.9515841)
    timers_0.add('test3', 0.3343889)
    timers_0.add('test4', 0.4073633)
    timers_0.add('test5', 0.9978199)
    timers_0.add('test6', 0.4710855)
    timers_0.add('test7', 0.7392736)
    timers_0.add('test8', 0.3514227)
    timers_0.add('test9', 0.4558588)
    timers_0.max('test4')



# Generated at 2022-06-25 15:16:12.578248
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_1 = Timers()
    timers_2 = Timers()
    timers_3 = Timers()
    timers_4 = Timers()
    timers_5 = Timers()
    timers_6 = Timers()
    timers_7 = Timers()
    timers_8 = Timers()
    timers_9 = Timers()
    timers_10 = Timers()
    timers_11 = Timers()
    timers_12 = Timers()
    timers_13 = Timers()
    timers_14 = Timers()
    timer_15 = Timers()
    timer_16 = Timers()
    timer_17 = Timers()
    timer_18 = Timers()
    timer_19 = Timers()
    timer_20 = Timers()
    timer_21 = Timers()
   

# Generated at 2022-06-25 15:16:16.920222
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("name_0", 0.4697327)
    timers_0.add("name_0", 0.836)
    assert math.isclose(timers_0.max("name_0"), 0.836)


# Generated at 2022-06-25 15:16:19.291721
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Setup
    timers_0 = Timers()

    # Assert
    assert False



# Generated at 2022-06-25 15:16:26.615378
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.apply(lambda values: statistics.mean(values or [0]), name="")
    timers_0.apply(lambda values: statistics.mean(values or [0]), name="")
    timers_0.apply(lambda values: statistics.mean(values or [0]), name="")
    timers_0.apply(lambda values: statistics.mean(values or [0]), name="")
    timers_0.apply(lambda values: statistics.mean(values or [0]), name="")
    timers_0.apply(lambda values: statistics.mean(values or [0]), name="")
    timers_0.apply(lambda values: statistics.mean(values or [0]), name="")
    timers_0.apply(lambda values: statistics.mean(values or [0]), name="")
    timers_0.apply

# Generated at 2022-06-25 15:16:35.108770
# Unit test for method min of class Timers
def test_Timers_min():
    #
    # Set up dummy data
    #
    data = {'b': 0, 'c': 0, 'a': 0}
    #
    # Set up test object
    #
    timers_obj = Timers(data)
    #
    # Call method
    #
    with pytest.raises(KeyError):
        timers_obj.min(name='d')


# Generated at 2022-06-25 15:16:38.630313
# Unit test for method median of class Timers
def test_Timers_median():
    timer_0 = Timers()
    timer_0.add("test", 1.0)
    str_0 = str(timer_0.median("test"))
    assert "1.000000" == str_0


# Generated at 2022-06-25 15:16:42.274124
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Example 0
    timers_0 = Timers()
    timers_0.add("simulation", 1.0)
    timers_0.add("funny", 2.0)
    assert timers_0.mean("simulation") == 1.0
    assert timers_0.mean("funny") == 2.0



# Generated at 2022-06-25 15:16:48.574320
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add('a', 1.0)
    timers_1.add('a', 2.0)
    timers_1.add('b', 3.0)
    timers_1.add('b', 4.0)
    mean_expected = [1.5, 3.5]
    mean_actual = [timers_1.mean('a'), timers_1.mean('b')]
    assert mean_expected == mean_actual

# Generated at 2022-06-25 15:16:53.043851
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("name_0", -0.052250889218452976)
    assert timers_0.max("name_0") == -0.052250889218452976


# Generated at 2022-06-25 15:16:54.643472
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    name = str()
    timers_0.median(name)


# Generated at 2022-06-25 15:16:55.316069
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()



# Generated at 2022-06-25 15:16:57.398415
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()


# Generated at 2022-06-25 15:17:02.848671
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.add('named-count', 100)
    timers_1.add('named-count', 200)
    timers_1.add('named-count', 150)
    expected: float = 150
    actual: float = timers_1.median('named-count')
    assert expected == actual, 'Test failed'


# Generated at 2022-06-25 15:17:05.586954
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("Id8_0", 1.0)

    timers_0.mean("Id8_0") == 1.0


# Generated at 2022-06-25 15:17:11.235977
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('a', 2)
    timers_0.add('a', 1)
    timers_0.add('b', 11)
    timers_0.add('b', 3)
    result = timers_0.max('a')
    assert result == 2



# Generated at 2022-06-25 15:17:18.550560
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("e", 0.85908238859822)
    timers_0.add("e", 0.388835302324131)
    timers_0.add("e", 0.482459842084865)
    timers_0.add("e", 0.0448498564069194)
    timers_0.add("e", 0.546312072785648)
    timers_0.add("e", 0.032094370451939)
    timers_0.add("e", 0.728780555855179)
    timers_0.add("e", 0.0844260443013802)
    timers_0.add("e", 0.848576867778623)

# Generated at 2022-06-25 15:17:28.135484
# Unit test for method median of class Timers
def test_Timers_median():
    """median"""
    # Test 1
    timers_1 = Timers()
    timers_1.add("foo", 1.0)
    timers_1.add("foo", 2.0)
    timers_1.add("foo", 3.0)
    timers_1.add("foo", 4.0)
    timers_1.add("foo", 5.0)
    median_1 = timers_1.median("foo")
    assert median_1 == 3.0
    # Test 2
    timers_2 = Timers()
    timers_2.add("foo", 1.0)
    timers_2.add("foo", 2.0)
    timers_2.add("foo", 3.0)
    timers_2.add("foo", 4.0)
    median_2 = timers_2.median("foo")

# Generated at 2022-06-25 15:17:38.237411
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert 0 == timers_0.min("fIqQ")
    timers_0.add("pD", 0.0)
    assert 0.0 == timers_0.min("pD")
    timers_0.add("pD", -1.0)
    assert -1.0 == timers_0.min("pD")
    timers_0.add("pD", -0.49934371295155627)
    assert -1.0 == timers_0.min("pD")
    timers_0.add("pD", 0.0)
    assert -1.0 == timers_0.min("pD")
    timers_0.add("pD", -0.1915329746344595)
    assert -1.0 == timers_0.min("pD")

# Generated at 2022-06-25 15:17:41.966070
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('a', 0.99978630922612)
    test_value_0 = timers_0.max('a')
    assert test_value_0 == 0.99978630922612


# Generated at 2022-06-25 15:17:50.415390
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('K', 0.830)
    timers_0.add('H', 0.413)
    timers_0.add('H', 0.340)
    timers_0.add('H', 0.445)
    timers_0.add('K', 1.080)
    timers_0.add('K', 0.103)
    timers_0.add('K', 0.894)
    timers_0.add('H', 0.729)
    timers_0.add('H', 0.858)
    timers_0.add('H', 0.237)
    timers_0.add('H', 0.871)
    timers_0.add('K', 0.622)
    timers_0.add('K', 0.368)
    timers_0

# Generated at 2022-06-25 15:17:57.497180
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    result = timers_0.median("name")
    assert result == 0
    timers_0.add("name", 1)
    timers_0.add("name", 9)
    timers_0.add("name", 5)
    timers_0.add("name", 7)
    timers_0.add("name", 3)
    timers_0.add("name", 4)
    timers_0.add("name", 10)
    timers_0.add("name", 2)
    timers_0.add("name", 6)
    timers_0.add("name", 8)
    result = timers_0.median("name")
    assert result == 5


# Generated at 2022-06-25 15:18:04.123947
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('mean_timer', 0.07444444444444445)
    timers_0.add('mean_timer', 0.07555555555555555)
    timers_0.add('mean_timer', 0.075)
    timers_0.add('mean_timer', 0.07388888888888889)
    timers_0.add('mean_timer', 0.07527777777777777)
    timers_0.add('mean_timer', 0.07388888888888889)
    timers_0.add('mean_timer', 0.07611111111111111)
    timers_0.add('mean_timer', 0.07416666666666667)
    timers_0.add('mean_timer', 0.075)
    timers

# Generated at 2022-06-25 15:18:13.273276
# Unit test for method median of class Timers
def test_Timers_median():
    timers: Timers = Timers()
    # Register a few time values
    timers.add("name", 0)
    timers.add("name", 1)
    timers.add("name", 2)
    timers.add("name", 3)
    timers.add("name", 4)
    timers.add("name", 5)
    timers.add("name", 6)
    timers.add("name", 7)
    timers.add("name", 8)
    timers.add("name", 9)
    # Test
    assert 3.5 == timers.median("name")
    timers.clear()
    # Test for empty value
    assert 0.0 == timers.median("name")



# Generated at 2022-06-25 15:18:21.190558
# Unit test for method median of class Timers
def test_Timers_median():
    # Initialize test object
    timers_0 = Timers()

    # Add a value to the named timer
    timers_0.add("foo", 5.5)

    # Get the median value of the timer
    timers_0.median("foo")  # 5.5

# Generated at 2022-06-25 15:18:25.500718
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.add("A", 1)
    timers_1.add("A", 0)
    timers_1.add("A", 1)
    assert timers_1.median("A") == 1


# Generated at 2022-06-25 15:18:28.717187
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    assert math.isnan(timers.median('test'))
    timers.add('test', 1)
    assert timers.median('test') == 1
    timers.add('test', 2)
    assert timers.median('test') == 1.5
    timers.add('test', 3)
    assert timers.median('test') == 2


# Generated at 2022-06-25 15:18:36.754990
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add(name='default', value=6.825670379762306)
    timers_0.add(name='default', value=7.288644890604681)
    timers_0.add(name='default', value=8.884959063241344)
    assert timers_0.min('default') == 6.825670379762306


if __name__ == '__main__':

    # Test case 0
    test_case_0()

    # Unit test for method min of class Timers
    test_Timers_min()

# Generated at 2022-06-25 15:18:43.823834
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name = ""
    # Call Timers.mean method with argument name
    timers_0.mean(name)


# Generated at 2022-06-25 15:18:47.321941
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add("foo", 123.45)
    timers_1.add("foo", 678.90)
    assert timers_1.mean("foo") == 401.175


# Generated at 2022-06-25 15:18:51.573500
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.data['x'] = 23.5
    assert (timers_0.min('x') == 23.5)


# Generated at 2022-06-25 15:18:57.909584
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.add('foo', 1)
    timers_1.add('foo', 2)
    timers_1.add('foo', 3)
    timers_1.add('foo', 4)
    assert timers_1.median('foo') == 2.5
    timers_1.add('bar', 4)
    timers_1.add('bar', 3)
    timers_1.add('bar', 2)
    timers_1.add('bar', 1)
    assert timers_1.median('bar') == 2.5


# Generated at 2022-06-25 15:18:59.620232
# Unit test for method mean of class Timers
def test_Timers_mean():
    for _i in range(100):
    	timers_0 = Timers()
    	val_0 = timers_0.mean(str())
    	assert val_0 is None


# Generated at 2022-06-25 15:19:08.108873
# Unit test for method median of class Timers
def test_Timers_median():
    import pytest

    mytimer = Timers()
    mytimer['foo']=1
    try:
        mytimer['foo']=1
        assert False
    except:
        pass

    mytimer.add('bar',2)
    mytimer.add('bar',5)

    assert mytimer.count('bar') == 2
    assert mytimer.total('bar') == 7
    assert mytimer.mean('bar') == 3.5
    assert mytimer.min('bar') == 2
    assert mytimer.max('bar') == 5
    assert pytest.approx( mytimer.median('bar'), 3.5 )
    assert pytest.approx( mytimer.stdev('bar'),2.1213203435596424 )
    

# Generated at 2022-06-25 15:19:13.242541
# Unit test for method max of class Timers
def test_Timers_max():
    # Setup
    timers_0 = Timers()
    name_0 = 'abc'

    # Exercise
    timers_0.add(name_0, 1.0)
    result_0 = timers_0.max(name_0)

    # Verify
    assert result_0 == 1.0


# Generated at 2022-06-25 15:19:17.690524
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("", 0.0)
    timers.add("", 0.0)
    timers.add("", 0.0)

    mean = timers.mean("")

    assert mean == 0.0


# Generated at 2022-06-25 15:19:22.418787
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name = "mox"
    value = 0.65855
    timers_0.add(name, value)
    # Evaluates expression: "mox"
    # Evaluates expression: 0.65855
    # Evaluates expression: timers_0['mox']
    assert_equal(timers_0.min(name), value)


# Generated at 2022-06-25 15:19:26.804521
# Unit test for method max of class Timers
def test_Timers_max():
    # Input
    timers_0 = Timers()
    name_0 = "bar"
    # Expected result
    expected_result_0 = 0
    # Real result
    real_result_0 = timers_0.max(name_0)
    # Assertion comparaison between expected and real results
    assert expected_result_0 == real_result_0


# Generated at 2022-06-25 15:19:27.647741
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()


# Generated at 2022-06-25 15:19:33.562957
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.add('c', 5)
    timers_1.add('c', 6)
    timers_1.add('c', 5)
    assert timers_1.median('c') == 5.5
    timers_2 = Timers()
    timers_2.add('c', 5)
    timers_2.add('c', 6)
    timers_2.add('c', 5)
    timers_2.add('c', 7)
    assert timers_2.median('c') == 5.5
    timers_3 = Timers()
    timers_3.add('c', 5)
    timers_3.add('c', 6)
    timers_3.add('c', 5)
    timers_3.add('c', 7)

# Generated at 2022-06-25 15:19:36.180578
# Unit test for method median of class Timers
def test_Timers_median():
    # initialize Timers object
    timers_0 = Timers()
    # call method on Timers object
    result_0 = timers_0.median(name=str())
    # assert equality of expected value and result
    assert result_0 == 0


# Generated at 2022-06-25 15:19:39.023513
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.max("1") == 0
    timers_0.add("1", 0.6513561248)
    assert timers_0.max("1") == 0.6513561248


# Generated at 2022-06-25 15:19:46.798083
# Unit test for method min of class Timers
def test_Timers_min():
    # input arguments for the method Timers.min
    Timers_min_args = {"name": "string"}

    # instance to invoke the method Timers.min
    timers_0 = Timers()

    # validate the attributes of the object timers_0 after
    # the method Timers.min is called
    assert type(timers_0.min(**Timers_min_args)) == float



# Generated at 2022-06-25 15:19:50.303289
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('add', 0.0)
    timers_0.add('add', 0.0)
    timers_0.add('add', 0.0)
    val_0 = timers_0.min('add')


# Generated at 2022-06-25 15:19:52.823853
# Unit test for method median of class Timers
def test_Timers_median():
    # Case 0
    test_case_0()


# Generated at 2022-06-25 15:19:57.367080
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert math.isnan(timers_0.mean(""))
    timers_0.add("", 0.5)
    assert 0.5 == timers_0.mean("")


# Generated at 2022-06-25 15:19:58.423235
# Unit test for method median of class Timers
def test_Timers_median():
    assert 3 == timers_0.median(name)


# Generated at 2022-06-25 15:20:01.481861
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    # key not found
    try:
        timers_0.median("b")
    except KeyError:
        pass
    else:
        raise AssertionError()
    # itervalues
    assert isinstance(timers_0.median("a"), float)



# Generated at 2022-06-25 15:20:06.949613
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add(image="1.png", value=1)
    timers_1.add(image="2.png", value=2)
    mean_var_0 = timers_1.mean(name="image")
    assert mean_var_0 == 1.5


# Generated at 2022-06-25 15:20:13.479465
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    assert timers.min("test") == 0
    timers.add("test", 10)
    assert timers.min("test") == 10
    timers.add("test", 30)
    assert timers.min("test") == 10
    assert timers.total("test") == 40


# Generated at 2022-06-25 15:20:15.490027
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    name = ""
    assert timers_0.median(name=name) == math.nan


# Generated at 2022-06-25 15:20:18.524969
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name = "name"
    timers_0.min(name)
    timers_0.add(name, -1)
    timers_0.add(name, 1)
    min = timers_0.min(name)


# Generated at 2022-06-25 15:20:20.443432
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    min_1 = timers_1.min("context.switch_time")
    assert min_1 == 0


# Generated at 2022-06-25 15:20:22.684933
# Unit test for method max of class Timers
def test_Timers_max():
    # Setup
    timers_0 = Timers()
    name = "name"
    expected_0 = 0
    # Exercise
    actual_0 = timers_0.max(name)
    # Verify
    assert actual_0 == expected_0


# Generated at 2022-06-25 15:20:23.664566
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.mean(timers_0)


# Generated at 2022-06-25 15:20:31.721335
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()

    timers.add("a", 1)
    timers.add("a", 2.1)
    timers.add("a", -5)
    timers.add("a", 2.5)
    timers.add("b", 3.2)
    timers.add("b", 2.3)

    assert timers.max(name="a") == 2.5, "timers.max(a) failed"
    assert timers.max(name="b") == 3.2, "timers.max(b) failed"


# Generated at 2022-06-25 15:20:32.971004
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name = ""
    assert math.isnan(timers_0.mean(name))


# Generated at 2022-06-25 15:20:42.561564
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()

    assert not timers_0.max("Rn0@C1")

    timers_0.add("Rn0@c1", 92.0095)
    timers_0.add("Rn0@c1", 93.9595)
    timers_0.add("Rn0@c1", 92.0095)
    timers_0.add("Rn0@c1", 94.0095)
    timers_0.add("Rn0@c1", 92.0095)
    timers_0.add("Rn0@c1", 94.8595)
    timers_0.add("Rn0@c1", 92.0095)
    timers_0.add("Rn0@c1", 92.8595)

# Generated at 2022-06-25 15:20:44.426979
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()

    assert (isinstance(timers_0.median('name'), float))



# Generated at 2022-06-25 15:20:48.948868
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = str()
    value_0 = float()
    timers_0.add(name_0, value_0)
    exception_0 = KeyError
    with raises(exception_0):
        timers_0.mean(name_0)


# Generated at 2022-06-25 15:20:50.995384
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('test', 1)
    timers.add('test', 2)
    assert timers.mean('test') == 1.5


# Generated at 2022-06-25 15:21:01.488854
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    result = timers.median(name = "foo")
    assert result == 0
    assert isinstance(result, float)
    timers_0 = Timers()
    timers_0.data.setdefault("foo", 0)
    timers_0.data["foo"] += 3
    timers_0._timings.setdefault("foo", [])
    timers_0._timings["foo"] += [3]
    result_0 = timers_0.median(name = "foo")
    assert result_0 == 3
    assert isinstance(result_0, float)
    timers_1 = Timers()
    timers_1.data.setdefault("foo", 0)
    timers_1.data["foo"] += 3
    timers_1._timings.setdefault("foo", [])
    timers_1._

# Generated at 2022-06-25 15:21:02.267670
# Unit test for method mean of class Timers
def test_Timers_mean():
    assert True


# Generated at 2022-06-25 15:21:05.915621
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = "Speed"
    timers_0.add(name_0, 0.0)
    timers_0.add(name_0, 0.5)
    timers_0.add(name_0, 0.5)
    timers_0.add(name_0, 1.0)
    timers_0.add(name_0, 1.0)


# Generated at 2022-06-25 15:21:13.031339
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0["item_0"] = 1.0
    timers_0.add("item_0", 2.0)
    timers_0.add("item_0", 3.0)
    # print(timers_0.mean("item_0"))


# Generated at 2022-06-25 15:21:18.677216
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    expected = 0.0
    actual = timers_0.median("name")
    assert actual == expected


# Generated at 2022-06-25 15:21:21.020076
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.median(str())


# Generated at 2022-06-25 15:21:28.319394
# Unit test for method median of class Timers
def test_Timers_median():
    # No key in dictionary
    timers_1 = Timers()
    timers_1.add("name_1", 0.0)
    assert False is timers_1.median("name_2")

    # Some keys in dictionary
    timers_2 = Timers()
    timers_2.add("name_1", 0.0)
    assert 0.0 is timers_2.median("name_1")


# Generated at 2022-06-25 15:21:35.064741
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("t_op", 10.0)
    timers.add("t_op", 11.0)
    timers.add("t_op", 12.0)
    timers.add("t_op", 13.0)
    timers.add("t_op", 14.0)

    assert timers.mean("t_op") == 12.0
