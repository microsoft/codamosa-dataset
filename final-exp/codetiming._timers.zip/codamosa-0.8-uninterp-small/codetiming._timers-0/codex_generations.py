

# Generated at 2022-06-25 15:11:42.564837
# Unit test for method max of class Timers
def test_Timers_max():
    import _test_helpers
    timers_0 = Timers()
    timers_0.add('timer_0', 1.0)
    _test_helpers.assert_eq(timers_0.max('timer_0'), 1.0)


# Generated at 2022-06-25 15:11:48.068630
# Unit test for method min of class Timers
def test_Timers_min():
    # Given
    timers_0 = Timers()
    timers_0.add("f", 0.0753588)
    timers_0.add("e", 0.142687)
    timers_0.add("e", 0.012363)
    timers_0.add("f", 0.0109406)
    timers_0.add("f", 0.0135843)
    timers_0.add("d", 0.0137464)
    timers_0.add("g", 0.011994)
    timers_0.add("g", 0.0106041)
    timers_0.add("e", 0.0143729)
    timers_0.add("f", 0.0115607)
    timers_0.add("e", 0.0129551)

# Generated at 2022-06-25 15:11:50.665048
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()

    assert math.isnan(timers_0.median("0"))



# Generated at 2022-06-25 15:11:56.367055
# Unit test for method max of class Timers
def test_Timers_max():
    """
    a timer is an object which can be used to measure the time that your code takes to run.
    The logic is simple - you call start() before the code you want to time, stop() after it,
    and then ask the timer how long it took between the calls.
    """
    timers_0 = Timers()
    for _ in range(30):
        timers_0.add('default', 0.1755700301361084)
    assert timers_0.max('default') == 5.267101090431213



# Generated at 2022-06-25 15:12:02.304472
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("key_0", 32.787028625)
    timers_0.add("key_1", 10.0971877756)
    timers_0.add("key_2", 8.13352322288)
    timers_0.add("key_3", 11.6598294036)
    timers_0.add("key_4", 27.6928929802)
    timers_0.add("key_5", 3.29751441826)
    timers_0.add("key_6", 15.1720021043)
    timers_0.add("key_7", 25.3501822196)
    timers_0.add("key_8", 7.80254401081)

# Generated at 2022-06-25 15:12:03.498331
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert timers_0.min('name_0') == 0.0


# Generated at 2022-06-25 15:12:10.405315
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("qrp", 0.033)
    timers_0.add("qrp", 0.0748)
    timers_0.add("qrp", 0.046)
    timers_0.add("qrp", 0.0528)
    timers_0.add("qrp", 0.0337)
    timers_0.add("qrp", 0.0348)
    timers_0.add("qrp", 0.0344)
    timers_0.add("qrp", 0.0337)
    timers_0.add("qrp", 0.0357)
    timers_0.add("qrp", 0.0357)
    timers_0.add("qrp", 0.0323)

# Generated at 2022-06-25 15:12:11.060937
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()


# Generated at 2022-06-25 15:12:12.085556
# Unit test for method median of class Timers
def test_Timers_median():
    assert math.isclose(timers_0.median('running'), 0)


# Generated at 2022-06-25 15:12:16.825475
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add(name = "test", value = 1.2)
    timers_0.add(name = "test", value = 1.3)

    name = "test"
    median = timers_0.median(name)
    assert(median == 1.25)


# Generated at 2022-06-25 15:12:29.906015
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("name0", 1.997772)
    timers_0.add("name1", 1.997772)
    timers_0.add("name2", 1.997772)
    timers_0.add("name3", 1.997772)
    timers_0.add("name4", 1.997772)
    timers_0.add("name5", 1.997772)
    timers_0.add("name6", 1.997772)
    timers_0.add("name7", 1.997772)
    timers_0.add("name8", 1.997772)
    timers_0.add("name9", 1.997772)
    timers_0.add("name10", 1.997772)
    timers_

# Generated at 2022-06-25 15:12:34.188298
# Unit test for method median of class Timers
def test_Timers_median():

    timers_0 = Timers()
    timers_0.add('foo', 2.0)
    timers_0.add('foo', 3.0)
    assert round(timers_0.median('foo'), 2) == 2.5

# Generated at 2022-06-25 15:12:41.026221
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0: Timers = Timers()
    timers_1: Timers = Timers()
    assert timers_0.mean('a_timer') == 0.0
    assert timers_1.mean('a_timer') == 0.0
    timers_0.add('a_timer', 1.0)
    timers_1.add('a_timer', 2.0)
    assert timers_0.mean('a_timer') == 1.0
    assert timers_1.mean('a_timer') == 2.0


# Generated at 2022-06-25 15:12:42.067307
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()


# Generated at 2022-06-25 15:12:46.556415
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("test", 1000.0)
    timers_0.add("test", 2000.0)
    timers_0.add("test", 3000.0)
    timers_0.add("test", 3000.0)
    timers_0.add("test", 5000.0)
    timer_mean = timers_0.mean("test")
    assert timer_mean == 3000.0

# Generated at 2022-06-25 15:12:49.892527
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("first", 0.0)
    timers_0.add("first", 2.0)
    assert timers_0.min("first") == 0.0
    assert timers_0.min("second") == 0.0


# Generated at 2022-06-25 15:12:55.665187
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("vxzgcjk", 0.437687955)
    timers_0.add("vxzgcjk", 0.224471851)
    timers_0.add("vxzgcjk", 0.661175534)
    timers_0.add("vxzgcjk", 0.813272594)
    timers_0.add("vxzgcjk", 0.034867993)
    timers_0.add("vxzgcjk", 0.143786256)
    assert timers_0.min("vxzgcjk") == 0.034867993


# Generated at 2022-06-25 15:12:58.135714
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Test case 0
    timers_0 = Timers()
    timers_0.data = {'a': 2}
    assert timers_0.mean('a') == 2


# Generated at 2022-06-25 15:12:59.219222
# Unit test for method min of class Timers
def test_Timers_min():
    assert Timers().min('name') == 0


# Generated at 2022-06-25 15:13:02.050363
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add('test_timer', 1.0)
    assert t.mean('test_timer') == 1.0


# Generated at 2022-06-25 15:13:07.320864
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("a", 1)
    assert isinstance(timers_0.median("a"), (int, float))


# Generated at 2022-06-25 15:13:10.468608
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('main', 21.3)
    assert timers.min('main') == 21.3


# Generated at 2022-06-25 15:13:14.602709
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    try:
        timers_0.max("Expected")
    except Exception as e:
        print("Test case failed to execute, exception thrown: " + str(e))
        return
    if not(False):
        print("Test case failed to execute, unexpected success")
        return
    print("Test case passed")


# Generated at 2022-06-25 15:13:17.056771
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    timers_1.add("a", 1)
    timers_1.add("a", 2)
    max_1 = timers_1.max("a")
    assert max_1 == 2


# Generated at 2022-06-25 15:13:19.977009
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add(p0, p1)
    assert timers_0.min(p0) == p1


# Generated at 2022-06-25 15:13:27.402420
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0: str = "name"
    __tracebackhide__ = True
    try:
        timers_0.mean(name_0)
        assert False
    except KeyError:
        # All good
        pass
    timers_0.add(name_0, 0.0)
    timers_0.add(name_0, 0.0)
    timers_0.mean(name_0)



# Generated at 2022-06-25 15:13:38.964169
# Unit test for method median of class Timers
def test_Timers_median():
    # Initialize an instance of Timers()
    timers = Timers()
    # Check the median of empty timers
    assert timers.median("foo") == 0
    assert timers.median("bar") == 0
    # Add some timings
    timers.add("foo", 0)
    timers.add("foo", -1)
    timers.add("foo", 1)
    # Check the median of timer foo
    assert timers.median("foo") == 0
    # Add some timings
    timers.add("bar", 1)
    timers.add("bar", -1)
    # Check the median of timer bar
    assert timers.median("bar") == 0
    # Try to get the median of timer baz that does not exist
    try:
        timers.median("baz")
    except KeyError:
        pass
   

# Generated at 2022-06-25 15:13:46.632894
# Unit test for method median of class Timers
def test_Timers_median():
    """
    timer_median(self, name: str) -> float:
        """
    timers_1 = Timers()
    assert isinstance(timers_1, Timers)
    assert isinstance(timers_1, collections.UserDict)
    timers_1.add("median_test", 2)
    assert timers_1.median("median_test") == 2
    timers_1.add("median_test", 2)
    assert timers_1.median("median_test") == 2
    timers_2 = Timers()
    assert isinstance(timers_2, Timers)
    assert isinstance(timers_2, collections.UserDict)
    timers_2.add("median_test", 2)
    assert timers_2.median("median_test") == 2
   

# Generated at 2022-06-25 15:13:50.431444
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    value_0 = timers_0.max('name_0')
    assert value_0 == 0.0


# Generated at 2022-06-25 15:13:54.710260
# Unit test for method max of class Timers
def test_Timers_max():
    # Initialize a new defaultdict with the key 'test_key' to the default value 5
    timers_defaultdict_1 = Timers(defaultdict(lambda: (5)))
    # Add a value to the list of values stored in the private _timings dict
    timers_defaultdict_1._timings['test_key'].append(5)
    # Assert that the method max for the Timers object returns the value 5
    assert timers_defaultdict_1.max('test_key') == 5


# Generated at 2022-06-25 15:14:01.924737
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('key_0', 2.45)
    assert math.isclose(timers_0.min('key_0'), 2.45)


# Generated at 2022-06-25 15:14:07.775968
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Test requirements
    # Timers_0 = Timers(data=dict(a=4, b=8), _timings=dict(a=[1.0, 2.0, 3.0, 4.0], b=[5.0, 6.0, 7.0, 8.0]))
    # assert(Timers_0.mean(name='a') == 2.5)
    # assert(Timers_0.mean(name='b') == 6.5)
    return


# Generated at 2022-06-25 15:14:14.544556
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('low', 1.0)
    timers.add('low', 2.0)
    timers.add('medium', 3.0)
    timers.add('medium', 4.0)
    timers.add('medium', 5.0)
    timers.add('high', 6.0)

    assert timers.mean('low') == 1.5
    assert timers.mean('medium') == 4.0
    assert timers.mean('high') == 6.0

    assert timers.total('low') == 3.0
    assert timers.total('medium') == 12.0
    assert timers.total('high') == 6.0

    assert timers.count('low') == 2
    assert timers.count('medium') == 3
    assert timers.count('high') == 1


# Generated at 2022-06-25 15:14:18.315779
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("glop", 0.1)
    timers_0.add("glop", 0.2)
    timers_0.add("glop", 0.3)
    print(timers_0.data)
    print(timers_0.median("glop"))


# Generated at 2022-06-25 15:14:28.442016
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    # Case 1
    assert(math.isnan(timers_0.median('1')))
    # Case 2
    timers_0.add('1', 1.0)
    assert(math.isnan(timers_0.median('1')))
    # Case 3
    timers_0.add('1', 2.0)
    assert(timers_0.median('1') == 1.5)
    # Case 4
    timers_0.add('2', 1.0)
    assert(timers_0.median('1') == 1.0)
    # Case 5
    assert(timers_0.median('2') == 1.0)


# Generated at 2022-06-25 15:14:32.506014
# Unit test for method median of class Timers
def test_Timers_median():
    """Test for Timers.median()"""
    timers = Timers()
    name = "string"
    # Name not in timers
    try:
        timers.median(name)
    except KeyError:
        pass
    # Name in timers
    timers._timings[name] = []
    assert timers.median(name) == 0.



# Generated at 2022-06-25 15:14:35.385480
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    key_0 = "default"
    timers_0.add(key_0, 0.0)
    assert(timers_0.max(key_0) == 0)


# Generated at 2022-06-25 15:14:38.524303
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    result = timers_0.mean("1")
    assert result == 0.0, "Incorrect result for method 'mean' of class Timers"


# Generated at 2022-06-25 15:14:44.317534
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    timers_1.add("case_1", 1.0)
    timers_1.add("case_1", 4.0)
    timers_1.add("case_1", 3.0)
    result = timers_1.max("case_1")
    assert result == 4.0


# Generated at 2022-06-25 15:14:50.730233
# Unit test for method median of class Timers
def test_Timers_median():
    # Use example from https://en.wikipedia.org/wiki/Median#Definition
    data = [1, 3, 5, 7, 9]

    timers_0 = Timers()

    # Add all values in the list
    for i in range(len(data)):
        timers_0.add('foo', data[i])

    # Check result
    assert timers_0.median('foo') == 5.0, "Error in method median"



# Generated at 2022-06-25 15:15:02.761190
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert isinstance(timers_0, collections.abc.MutableMapping)
    assert isinstance(timers_0, collections.abc.Mapping)
    assert not timers_0
    assert isinstance(timers_0, collections.abc.Iterable)
    assert isinstance(timers_0, collections.abc.Container)
    assert isinstance(timers_0, collections.UserDict)
    assert isinstance(timers_0, Timers)
    assert len(timers_0.data) == 0
    assert timers_0.data == {}
    assert len(timers_0._timings) == 0
    assert timers_0._timings == {}
    assert len(timers_0) == 0
    assert not timers_0
    timers_0.clear()

# Generated at 2022-06-25 15:15:08.504106
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers({"clock": 68.14893580122149})
    max_1_expected = 68.14893580122149
    max_1_actual = timers_1.max("clock")
    assert max_1_actual == max_1_expected
    max_2_expected = 68.14893580122149
    max_2_actual = timers_1.max("clock", "clock")
    assert max_2_actual == max_2_expected
    max_3_expected = "KeyError: 'foo'"
    max_3_actual = str(max_3_expected)[:17]
    assert max_3_actual == max_3_expected
    max_4_expected = "KeyError: 'foo'"
    max_4_actual = str(max_4_expected)[:17]
   

# Generated at 2022-06-25 15:15:10.457086
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    value: float = timers_0.min("key_example_0")



# Generated at 2022-06-25 15:15:15.559502
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("name", 1.0)
    assert timers_0.mean("name") == 1.0, "Test #0 failed"
    timers_0.add("name", 2.0)
    assert timers_0.mean("name") == 1.5, "Test #1 failed"



# Generated at 2022-06-25 15:15:20.674463
# Unit test for method min of class Timers
def test_Timers_min():

    # Test parameters
    name = 'test_name'

    # Set-up object
    timers_0 = Timers()
    
    # Test method
    if name in timers_0._timings:
        actual = min(timers_0._timings[name] or [0])
    else:
        raise KeyError(name)


# Generated at 2022-06-25 15:15:31.454533
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers() # Stores timings, accessible through []
                       # Use .add('name', timing) to increment value.
    timers_0.add('name', 14)
    timers_0.add('name', 17)
    timers_0.add('name', 15)
    timers_0.add('name', 16)
    timers_0.add('name', 15)
    timers_0.add('name', 16)
    timers_0.add('name', 16)
    timers_0.add('name', 16)
    timers_0.add('name', 16)
    timers_0.add('name', 15)
    assert timers_0.mean('name') == 15.6, \
        "Expected 15.6, got {}".format(timers_0.mean('name'))



# Generated at 2022-06-25 15:15:36.795051
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("lt_im_kw", 1.0)
    timers_0.add("lt_im_kw", 2.0)
    timers_0.add("lt_im_kw", 1.0)
    assert timers_0.min("lt_im_kw") == 1.0



# Generated at 2022-06-25 15:15:40.787276
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.median('name')
    var_0 = Timers()
    try:
        var_0.median('name')
    except KeyError as err:
        print(err)


# Generated at 2022-06-25 15:15:48.476941
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("fn_sum", 0.0099345088)
    timers_0.add("fn_sum", 0.0099345088)
    timers_0.add("fn_sum", 0.0099345088)
    timers_0.add("fn_sum", 0.0099345088)
    timers_0.add("fn_sum", 0.0099345088)
    timers_0.add("fn_sum", 0.0099345088)
    timers_0.add("fn_sum", 0.0099345088)
    timers_0.add("fn_sum", 0.0099345088)
    timers_0.add("fn_sum", 0.0099345088)

# Generated at 2022-06-25 15:15:57.218033
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()

    # Test: Zero values
    name = 'a'
    assert math.isnan(timers_0.mean(name=name))

    # Test: One value
    timers_0.add(name=name, value=1)
    assert timers_0.mean(name=name) == 1
    timers_0.clear()

    # Test: Two values
    timers_0.add(name=name, value=1)
    timers_0.add(name=name, value=2)
    assert 1.5 == round(timers_0.mean(name=name), 5)
    timers_0.clear()

    # Test: Many values
    for i in range(10):
        timers_0.add(name=name, value=i)

# Generated at 2022-06-25 15:16:07.836431
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("99", 0.120854828)
    timers_0.add("99", 0.07349044)
    timers_0.add("99", 0.096418706)
    res = timers_0.min("99")
    assert res == 0.07349044


# Generated at 2022-06-25 15:16:15.822085
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_1 = Timers()
    with Timer(timers_0, "timers_0.min.0"):
        with Timer(timers_1, "timers_1.min.0"):
            timers_1.add("timers_1.min.0", 1)
            timers_1.add("timers_1.min.1", 1)
    with Timer(timers_0, "timers_0.min.1"):
        timers_0.add("timers_0.min.1", 2)

    assert timers_0.min("timers_0.min.1") == 2
    assert timers_0.min("timers_0.min.0") == 1


# Generated at 2022-06-25 15:16:20.029818
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('a', 1)
    timers.add('a', 2)
    timers.add('a', 5)
    timers.add('b', 1)
    assert timers.max('a') == 5
    assert timers.max('b') == 1
    return True


# Generated at 2022-06-25 15:16:21.853700
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers({'timer_0' : 3.68})
    timers_0.add('timer_0', 0.41)
    timers_0.mean('timer_0')
    assert 1 == 1


# Generated at 2022-06-25 15:16:27.615951
# Unit test for method median of class Timers
def test_Timers_median():
    # test case 0
    timers_0 = Timers()
    with pytest.raises(KeyError):
        timers_0.median(
            name="name",
        )


# Generated at 2022-06-25 15:16:37.703323
# Unit test for method median of class Timers
def test_Timers_median():
    """Test Timers.median() function."""
    from random import shuffle as other_shuffle

    # Test of method median()
    timers_0 = Timers()
    timers_0.add('a', 5.0)
    timers_0.add('a', 9.0)
    timers_0.add('a', -1.0)
    timers_0.add('a', 3.0)
    timers_0.add('a', 3.0)
    a_median_0 = timers_0.median('a')
    assert a_median_0 == 3.0
    timers_0.add('b', -5.0)
    b_median_0 = timers_0.median('b')
    assert b_median_0 == -5.0

    # Test of method median()
   

# Generated at 2022-06-25 15:16:40.949716
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('foo', 3.1415)
    method_result_0 = timers_0.median('foo')
    assert math.isclose(method_result_0, 3.1415)


# Generated at 2022-06-25 15:16:52.234025
# Unit test for method median of class Timers
def test_Timers_median():

    timers_1 = Timers()
    timers_1.add("test", 0.0)
    kwargs_0 = {"name": "test"}
    result_0 = timers_1.median(**kwargs_0)
    assert result_0 == 0.0

    timers_2 = Timers()
    timers_2.add("test", -1.0)
    kwargs_1 = {"name": "test"}
    result_1 = timers_2.median(**kwargs_1)
    assert result_1 == -1.0

    timers_3 = Timers()
    timers_3.add("test", 1.0)
    kwargs_2 = {"name": "test"}
    result_2 = timers_3.median(**kwargs_2)
    assert result_2 == 1.0

# Generated at 2022-06-25 15:16:55.213433
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    str_0 = "example_name"
    timers_0.add(str_0, 0.01)
    assert 0.01 == timers_0.max(str_name = "example_name")


# Generated at 2022-06-25 15:17:03.549453
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('key_0', 1.0)
    timers_0.add('key_1', 1.0)
    timers_0.add('key_0', 1.0)
    timers_0.add('key_1', 1.0)
    value_0 = timers_0.max('key_0')
    value_1 = timers_0.max('key_1')
    assert value_0 == 1.0
    assert value_1 == 1.0


# Generated at 2022-06-25 15:17:17.287327
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('key', 1.0)
    timers_0.add('key', 0.0)
    timers_0.add('key', 2.0)
    timers_0.add('key', 3.0)
    timers_0.add('key', 4.0)
    timers_0.add('key1', 1.0)
    timers_0.add('key1', 1.0)
    timers_0.add('key1', 1.0)
    timers_0.add('key1', 1.0)
    timers_0.add('key1', 1.0)
    assert 1.0 == timers_0.mean('key')
    assert 1.0 == timers_0.mean('key1')


# Generated at 2022-06-25 15:17:21.681436
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('a', 0.01)
    timers_0.add('a', 0.01)
    assert timers_0.min('a') == 0.01


# Generated at 2022-06-25 15:17:23.919418
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert math.isnan(timers_0.min(""))


# Generated at 2022-06-25 15:17:34.657026
# Unit test for method median of class Timers
def test_Timers_median():
    from unittest.mock import MagicMock
    mock_func_0 = MagicMock(return_value=0.9651813440099591)
    mock_func_1 = MagicMock(return_value=0.05810418690778558)
    mock_func_2 = MagicMock(return_value=0.34977287933885384)
    mock_func_3 = MagicMock(return_value=0.7816705430651796)
    mock_func_4 = MagicMock(return_value=0.4977144323003098)
    mock_func_5 = MagicMock(return_value=0.7384548801594216)

    timers_0 = Timers()


# Generated at 2022-06-25 15:17:44.264393
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_1 = Timers()

    timers_1.add("key", 0.0)
    timers_1.add("key", 0.0)
    timers_1.add("key", 0.0)
    timers_1.add("key", 0.0)
    timers_1.add("key", 0.0)
    timers_1.add("key", 0.0)
    timers_1.add("key", 0.0)
    timers_1.add("key", 0.0)
    timers_1.add("key", 0.0)
    timers_1.add("key", 0.0)

    assert( 0.0 == timers_1.mean("key"))



# Generated at 2022-06-25 15:17:48.134959
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Tests for method mean of class Timers
    timers_1 = Timers()

    timers_1.add("TIMER_0", 0)
    assert timers_1.mean("TIMER_0") == 0

    timers_1.add("TIMER_0", 1)
    assert timers_1.mean("TIMER_0") == 0.5


# Generated at 2022-06-25 15:17:50.295868
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("timer_0", 0)
    assert timers.min("timer_0") == 0



# Generated at 2022-06-25 15:17:56.852116
# Unit test for method min of class Timers
def test_Timers_min():
    """Test for method min of class Timers"""
    timers = Timers()
    timers.add('A', 1.1)
    timers.add('A', 2.2)
    assert timers['A'] == 3.3
    assert timers.min('A') == 1.1
    assert timers.max('A') == 2.2
    assert timers.mean('A') == 1.65
    assert timers.median('A') == 1.65
    assert timers.total('A') == 3.3
    assert timers.count('A') == 2
    assert timers.stdev('A') == 0.56694678963061424



# Generated at 2022-06-25 15:18:00.769044
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    timers_1.add('t_1', 100)
    timers_1.add('t_1', 200)
    assert isinstance(timers_1.max('t_1'), float)
    assert timers_1.max('t_1') == 200


# Generated at 2022-06-25 15:18:05.921142
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()

    timers.add('a', 1)
    timers.add('a', 2)
    timers.add('a', 3)
    med = timers.median('a')
    assert med == 2

    timers.add('b', 4)
    timers.add('b', 5)
    med = timers.median('b')
    assert med == 4.5

# Generated at 2022-06-25 15:18:17.184013
# Unit test for method mean of class Timers
def test_Timers_mean():
    t = Timers()
    t.add('a', 1)
    t.add('a', 2)
    t.add('b', 10)
    t.add('b', 20)
    t.add('b', 30)
    assert t.mean('a') == 1.5
    assert t.mean('b') == 20
    assert t.min('c') == 0


# Generated at 2022-06-25 15:18:19.369663
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('', 0)
    assert math.isclose(timers_0.min('bar'), 0.0)


# Generated at 2022-06-25 15:18:21.650948
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add(name = "", value = 0.0)
    timers_0.median(name = "")



# Generated at 2022-06-25 15:18:25.730536
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.add('t0', 1)
    timers_1.add('t0', 2)
    timers_1.add('t0', 3)
    assert timers_1.median('t0') == 2
    timers_2 = Timers()
    timers_2.add('t0', 1)
    timers_2.add('t0', 2)
    assert timers_2.median('t0') == 1.5
    timers_3 = Timers()
    timers_3.add('t0', 0)
    assert timers_3.median('t0') == 0
    timers_4 = Timers()
    timers_4.add('t0', 1)
    timers_4.add('t0', 2)
    timers_4.add('t0', 3)

# Generated at 2022-06-25 15:18:27.765289
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = ""
    assert math.isnan(timers_0.mean(name_0))


# Generated at 2022-06-25 15:18:28.965556
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()



# Generated at 2022-06-25 15:18:31.417792
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('timer', 0)
    assert timers_0.median('timer') == 0.0


# Generated at 2022-06-25 15:18:35.869075
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0._timings.setdefault('r', [1.0])
    try:
        assert 1.0 == timers_0.max('r')
    except AssertionError:
        raise AssertionError('AssertionError raised. Timers.max() failed')


# Generated at 2022-06-25 15:18:44.935723
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert math.isnan(timers_0.mean('test'))
    timers_0.add('test', 1.0)
    assert 1.0 == timers_0.mean('test')
    timers_0.add('test', 1.0)
    timers_0.add('test', 1.0)
    timers_0.add('test', 1.0)
    timers_0.add('test', 1.0)
    assert 1.0 == timers_0.mean('test')
    timers_0.add('test', 2.0)
    assert 1.33333 == timers_0.mean('test')
    timers_0.add('test', 3.0)
    timers_0.add('test', 4.0)
    timers_0.add('test', 5.0)


# Generated at 2022-06-25 15:18:52.683164
# Unit test for method median of class Timers
def test_Timers_median():
    # Initialize the testing environment
    timers = Timers()
    timers._timings = {
        'timer-0': [1.1, 2.2, 3.3],
        'timer-1': [11.1, 12.2, 13.3],
    }
    assert timers.median('timer-0') == 2.2
    assert timers.median('timer-1') == 12.2



# Generated at 2022-06-25 15:19:05.358125
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('timer1', 0.1)
    timers_0.add('timer1', 0.2)
    timers_0.add('timer1', 0.3)
    timers_0.add('timer1', 0.4)
    median_0 = timers_0.median('timer1')
    assert math.isclose(median_0, 0.3)


# Generated at 2022-06-25 15:19:08.949165
# Unit test for method max of class Timers
def test_Timers_max():
    from random import random as py_random

    py_random = [py_random() for _ in range(10)]
    for _ in py_random:
        timers_0.add('example', py_random)
    assert timers_0.max('example') >= min(py_random)


# Generated at 2022-06-25 15:19:13.041892
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("key_1", 1.0)
    timers_0.add("key_2", 2.0)
    value = timers_0.max("key_1")
    assert value == 1.0



# Generated at 2022-06-25 15:19:17.949498
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_1 = Timers()
    timers_2 = Timers()
    timers_3 = Timers()
    assert timers_0.mean('players') == 0
    assert timers_1.mean('name') == 0
    assert timers_2.mean('value') == 0
    assert timers_3.mean('worlds') == 0


# Generated at 2022-06-25 15:19:22.723392
# Unit test for method min of class Timers
def test_Timers_min():
    timer = Timers()
    timer.add("foo", 0.8)
    timer.add("bar", 1.0)
    timer.add("baz", 0.1)
    # Timer is not cleared, so min should be 0 for all timers
    for i in range(4):
        for name in timer.keys():
            assert timer.min(name) == 0.0

# Generated at 2022-06-25 15:19:31.017246
# Unit test for method median of class Timers
def test_Timers_median():
    # Create an instance of class Timers
    timers_1 = Timers()
    # Add some data to the dictionary
    timers_1["item_0"] = 1.5
    timers_1["item_1"] = 2.5
    assert math.isclose(timers_1.median("item_0"), 1.5)
    assert math.isclose(timers_1.median("item_1"), 2.5)
    timers_1.add("item_0", 2.5)
    timers_1.add("item_1", 1.5)
    assert math.isclose(timers_1.median("item_0"), 2.0)
    assert math.isclose(timers_1.median("item_1"), 1.5)
    # TODO
    # timers_1.add("item_

# Generated at 2022-06-25 15:19:31.925154
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert timers_0.mean("") == 0.0



# Generated at 2022-06-25 15:19:39.278414
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("timer_0", 1)
    timers_0.add("timer_0", 1)
    timers_0.add("timer_0", 2)
    timers_0.add("timer_0", 3)
    timer_0_mean = timers_0.mean("timer_0")
    assert timer_0_mean == 1.75

# Generated at 2022-06-25 15:19:45.223832
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()

    try:
        timers_0.apply(sum, name="sum")
    except:
        return False
    else:
        return True



# Generated at 2022-06-25 15:19:50.070459
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("name-0", 0.60)
    timers_0.add("name-0", 0.14)
    timers_0.add("name-0", 0.49)

    test_0 = timers_0.min("name-0")
    assert test_0 == 0.14



# Generated at 2022-06-25 15:20:06.987132
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.add("name", value=123)
    assert timers_1.median(name="name") == 123


# Generated at 2022-06-25 15:20:12.318045
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    value_0 = 0.0
    timers_0.add("0", value_0)
    assert timers_0.max("0") == value_0


# Generated at 2022-06-25 15:20:15.684289
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("a", 1.5)
    timers.add("a", 2.5)
    # Test number b is not defined.
    assert math.isnan(timers.max("b"))
    # Test known value of a.
    assert timers.max("a") == 2.5

test_case_0()
test_Timers_max()

# Generated at 2022-06-25 15:20:22.736255
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("key_0", 0.39172718490844476)
    timers_0.add("key_0", 2.2697203688987688)
    timers_0.add("key_0", 1.0028472730606989)
    timers_0.add("key_0", 3.0058711416692313)
    timers_0.add("key_0", 1.021561435804816)
    timers_0.add("key_0", 1.8559509989691845)
    timers_0.add("key_0", 1.3923175025793256)
    timers_0.add("key_0", 1.0505676055259208)
    expected = 0.391727184908

# Generated at 2022-06-25 15:20:24.074576
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert (timers_0.median('name_0')) == 0.0
    return True


# Generated at 2022-06-25 15:20:26.004251
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    key = "key"
    assert math.isnan(timers_0.min(key))
    timers_0.add(key, 0.5790234852414233)
    assert timers_0.min(key) == 0.5790234852414233



# Generated at 2022-06-25 15:20:27.547611
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert math.isnan(timers_0.max(""))



# Generated at 2022-06-25 15:20:28.938864
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    test_start_time = timers_0.median("test")


# Generated at 2022-06-25 15:20:34.776565
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("test", 2.0)
    timers_0.add("test", 3.0)
    timers_0.add("test", 5.0)
    timers_0.add("test", 7.0)
    timers_0.add("test", 11.0)
    assert timers_0.min("test") == 2.0
    timers_1 = Timers()
    timers_1.add("test", 0.0)
    assert timers_1.min("test") == 0.0
    timers_2 = Timers()
    assert timers_2.min("test") == 0.0


# Generated at 2022-06-25 15:20:43.509416
# Unit test for method median of class Timers
def test_Timers_median():

    timers_0 = Timers()

    assert type(timers_0) == Timers
    assert len(timers_0) == 0
    assert timers_0.total("key_0") == 0
    assert timers_0.min("key_0") == 0
    assert timers_0.max("key_0") == 0
    assert timers_0.mean("key_0") == 0
    assert timers_0.median("key_0") == 0
    assert timers_0.stdev("key_0") == math.nan

    timers_0.add("key_0", 1)
    timers_0.add("key_1", 1)
    timers_0.add("key_0", 2)

    assert len(timers_0) == 2
    assert timers_0.total("key_0") == 3

# Generated at 2022-06-25 15:21:05.071615
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()

    timers_1.add("Timer", 6.0)
    timers_1.add("Timer", 7.0)
    timers_1.add("Timer", 8.0)
    timers_1.add("Timer", 9.0)
    timers_1.add("Timer", 10.0)
    timers_1.add("Timer", 11.0)
    timers_1.add("Timer", 12.0)
    timers_1.add("Timer", 13.0)
    timers_1.add("Timer", 14.0)
    timers_1.add("Timer", 15.0)

    median_0 = timers_1.median("Timer")
    median_1 = 10.0
    assert median_0 == median_1


# Generated at 2022-06-25 15:21:07.206577
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name_0 = 'timer'
    value_0 = 0.0
    timers_0.add(name_0, value_0)
    assert timers_0.max('timer') == 0.0



# Generated at 2022-06-25 15:21:15.791986
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()

    def func_0():
        """Create a timer"""
        timers_0['timer_0'] = 0.000002093505859375

    func_0()

    assert timers_0.max('timer_0') == 0.000002093505859375



# Generated at 2022-06-25 15:21:17.976550
# Unit test for method min of class Timers
def test_Timers_min():

    timers_0 = Timers()

    timers_0.add("foo", 0.0121595)
    timers_0.add("foo", 0.0121594)
    T_0 = timers_0.min("foo")
    assert T_0 == 0.0121594



# Generated at 2022-06-25 15:21:26.554958
# Unit test for method median of class Timers
def test_Timers_median():
        # Initialize a Timers dictionary
        timers_0 = Timers()
        # Initialize a test Timers
        timers_0 = Timers(
            {"name.0": 1.2, "name.1": 2.3, "name.2": 3.4, "name.3": 4.5}
        )
        # Get the medians of the timer
        assert timers_0.median("name.0") == 1.2


# Generated at 2022-06-25 15:21:28.258348
# Unit test for method median of class Timers
def test_Timers_median():
    # Test case #0
    timers_0 = Timers()
    result = timers_0.median('name')

