

# Generated at 2022-06-25 15:11:42.363786
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers._timings = {
        "b": [0.4, 1.4, 0.1, 0.4, 0.8, 2.1, 1.3, 2.3, 2.8, 2.6, 2.2, 2.1, 2.8, 2.6]
    }
    timers.add("b", 16.24)
    assert timers.max("b") == 2.8


# Generated at 2022-06-25 15:11:44.896768
# Unit test for method min of class Timers
def test_Timers_min():
    # Arrange
    name = "name"
    value = 5
    timers = Timers()
    timers._timings[name] = [value]

    # Act
    result = timers.min(name)

    # Assert
    assert result == value


# Generated at 2022-06-25 15:11:46.220738
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.max('timer_00') == 0.0, 'AssertionError'


# Generated at 2022-06-25 15:11:51.049634
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.data.setdefault("name", 0)
    timers_0.data["name"] = 0
    timers_0._timings.setdefault("name", [])
    timers_0._timings["name"].append(0)
    timers_0.add("name", 0)
    timers_0.max("name")


# Generated at 2022-06-25 15:11:55.854025
# Unit test for method median of class Timers
def test_Timers_median():
    # Arbitrary values
    timers_1 = Timers()
    assert isinstance(timers_1.median, collections.abc.Callable)
    # Test with range
    for i in range(10):
        timers_1.add(name="test", value=i)
    assert isinstance(timers_1.median(name="test"), float)
    assert timers_1.median(name="test") == 4.5



# Generated at 2022-06-25 15:12:00.378185
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()

    timers_1.add("a", 12)
    timers_1.add("a", 13)
    timers_1.add("a", 14)
    timers_1.add("a", 15)
    timers_1.add("a", 16)
    timers_1.add("a", 17)
    timers_1.add("a", 18)
    timers_1.add("a", 19)
    timers_1.add("a", 20)
    timers_1.add("a", 21)

    assert timers_1.mean("a") == 16.0


# Generated at 2022-06-25 15:12:07.242036
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("name_0", 421.504590872)
    timers_0.add("name_0", 542.562428829)
    timers_0.add("name_0", 29.7417128869)
    timers_0.add("name_0", 535.77239636)
    timers_0.add("name_0", 361.025142543)
    timers_0.add("name_0", 631.758124981)
    timers_0.add("name_0", 379.336835276)
    timers_0.add("name_0", 235.035642092)
    timers_0.add("name_0", 698.907702514)

# Generated at 2022-06-25 15:12:14.301308
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("blabla", 0.001)
    timers.add("blabla", 0.023)
    timers.add("blabla", 0.025)
    timers.add("blabla", 0.024)
    timers.add("blabla", 0.008)
    min_value = timers.min("blabla")
    try:
        assert min_value == 0.001, f"Your answer {min_value} is wrong. The correct answer is 0.001"
    except:
        print("The min method is wrong. min should return 0.001")
        raise
    else:
        print("The min method is correct.")



# Generated at 2022-06-25 15:12:16.632302
# Unit test for method median of class Timers
def test_Timers_median():
    Timers_0 = Timers()
    float_0 = Timers_0.median(str_0='')
    assert(float_0 == 0)



# Generated at 2022-06-25 15:12:19.854416
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("foo", 1)
    assert timers.max("foo") == 1
    timers.add("foo", 2)
    assert timers.max("foo") == 2


# Generated at 2022-06-25 15:12:30.747743
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()

# Generated at 2022-06-25 15:12:39.447739
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()  # Standalone Timers object
    # Initialize a counter
    counter_0 = 0
    # Iterate through all timers in the timers object
    for name_0, time_0 in timers_1.items():
        # Check if the timer name matches a certain expression
        if str(name_0).find("bar") != -1:
            # If so, add the timer time to the counter
            counter_0 += time_0
    assert len(timers_1) == 0
    assert counter_0 == 0.0



# Generated at 2022-06-25 15:12:48.105548
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    timers_1.add('a', 1.0)
    assert 1.0 == timers_1.max('a')
    timers_1.add('a', 3.0)
    assert 3.0 == timers_1.max('a')
    timers_1.add('a', 4.0)
    assert 4.0 == timers_1.max('a')
    timers_1.add('a', 2.0)
    assert 4.0 == timers_1.max('a')
    assert 1.0 == timers_1.min('a')
    timers_1.add('b', 5.0)
    timers_1.add('b', 6.0)
    timers_1.add('b', 2.0)
    timers_1.add('b', 3.0)
    timers_

# Generated at 2022-06-25 15:12:50.708225
# Unit test for method median of class Timers
def test_Timers_median():
    # Setup
    timers = Timers()

    # Act
    timers.add("test", 42)
    timers.add("test", 38)
    timers.add("test", 55)

    # Verify
    assert timers.median("test") == 42

# Generated at 2022-06-25 15:12:53.193421
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("name_0", 1)
    timers_0.add("name_0", 2)
    timers_0.add("name_0", 3)
    assert timers_0.max("name_0") == 3


# Generated at 2022-06-25 15:12:59.173034
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    try:
        timers_0.min("")
        assert False
    except KeyError:
        pass
    except:
        assert False

    timers_0 = Timers()
    timers_0.add("", 0.0)
    timers_0.min("")


# Generated at 2022-06-25 15:13:02.393945
# Unit test for method min of class Timers
def test_Timers_min():
    # Test case 0
    timers_0 = Timers()
    timers_0.add('foo', 1.0)
    assert round(timers_0.min('foo'), 4) == 1.0


# Generated at 2022-06-25 15:13:11.986692
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()

    timers_1 = Timers()
    assert math.isnan(timers_1.min("timer0"))

    timers_2 = Timers()
    timers_2["timer0"] = 5
    assert timers_2.min("timer0") == 5

    timers_3 = Timers()
    timers_3["timer1"] = 5
    assert math.isnan(timers_3.min("timer0"))

    timers_4 = Timers()
    assert math.isnan(timers_4.min("timer0"))

    timers_5 = Timers()
    timers_5.add("timer0", 5)
    assert timers_5.min("timer0") == 5


# Generated at 2022-06-25 15:13:15.349289
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.data['name'] = 0.0
    timers_0._timings['name'] = [0.0]
    name = 'name'
    # Default case
    assert timers_0.median(name=name) == 0.0


# Generated at 2022-06-25 15:13:21.364679
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("rz", 52.0)
    timers_0.add("rz", 45.0)
    timers_0.add("rz", 35.0)
    timers_0.add("rz", 50.0)
    timers_0.add("rz", 50.0)
    timers_0.add("rz", 48.0)
    timers_0.add("rz", 50.0)
    timers_0.add("rz", 46.0)
    timers_0.add("rz", 52.0)
    timers_0.add("rz", 47.0)
    timers_0.add("rz", 45.0)
    timers_0.add("rz", 49.0)

# Generated at 2022-06-25 15:13:26.795208
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("my_hook", 1.5)
    assert timers_0.mean("my_hook") == 1.5


# Generated at 2022-06-25 15:13:28.987987
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("name", 50)
    assert(timers.median("name") == 50)


# Generated at 2022-06-25 15:13:30.286185
# Unit test for method median of class Timers
def test_Timers_median():
    assert Timers().median("abc") == math.nan


# Generated at 2022-06-25 15:13:33.373287
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name_0 = str()
    Timers_max_0 = timers_0.max(name_0)
    assert Timers_max_0 == 0


# Generated at 2022-06-25 15:13:37.897838
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.max('a') == 0
    timers_0.data['a'] = 1.0
    assert timers_0.max('a') == 1.0

# Generated at 2022-06-25 15:13:46.035320
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.data = {'k0': 1.7491464973776798}

# Generated at 2022-06-25 15:13:54.758431
# Unit test for method mean of class Timers
def test_Timers_mean():

    import unittest

    # Create a new instance of the class
    timers_1 = Timers()

    # Apply the method to the class
    result = timers_1.mean("model")

    # Create a new instance of the class
    timers_2 = Timers()

    # Apply the method to the class
    result_2 = timers_2.mean("model")

    # Create a new instance of the class
    timers_3 = Timers()

    # Apply the method to the class
    result_3 = timers_3.mean("model")

    # Create a new instance of the class
    timers_4 = Timers()

    # Apply the method to the class
    result_4 = timers_4.mean("model")

    # Create a new instance of the class
    timers_5 = Timers()

    # Apply the method to the class

# Generated at 2022-06-25 15:13:58.540702
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()

    timers.add("timer_0", 0)

    # Check return type
    assert isinstance(timers.max("timer_0"), float)

    # Check return value
    assert timers.max("timer_0") == 0


# Generated at 2022-06-25 15:14:01.848253
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    result = timers_0.min("min")
    assert result == 0.0


# Generated at 2022-06-25 15:14:07.964751
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    value_0 = timers_0.min("min_0")
    assert value_0 == 0
    value_1 = timers_0.min("min_1")
    assert value_1 == 0
    value_2 = timers_0.min("min_4")
    assert value_2 == 0
    value_3 = timers_0.min("min_5")
    assert value_3 == 0
    value_4 = timers_0.min("min_6")
    assert value_4 == 0
    value_5 = timers_0.min("min_7")
    assert value_5 == 0
    value_6 = timers_0.min("min_9")
    assert value_6 == 0
    value_7 = timers_0.min("min_10")

# Generated at 2022-06-25 15:14:12.277984
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0['a'] = 6.0
    assert timers_0.max("a") == 6.0

# Generated at 2022-06-25 15:14:18.316645
# Unit test for method mean of class Timers
def test_Timers_mean():
    """
    Test function for mean(name)
    """
    timers_1: Timers = Timers()
    timers_1._timings['timer_1'] = [1.0, 2.0, 3.0]
    timers_1._timings['timer_2'] = [1.0, 1.0]
    assert timers_1.mean('timer_1') == 2.0
    assert timers_1.mean('timer_2') == 1.0



# Generated at 2022-06-25 15:14:29.021038
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("c", 2.9)
    timers_0.add("c", 4.0)
    timers_0.add("c", 3.0)
    timers_0.add("c", 1.8)
    timers_0.add("c", 2.1)
    timers_0.add("c", 1.4)
    timers_0.add("c", 3.3)
    timers_0.add("c", 2.9)
    timers_0.add("c", 2.6)
    timers_0.add("c", 3.3)
    timers_0.add("c", 3.2)
    timers_0.add("c", 1.8)
    timers_0.add("c", 2.6)

# Generated at 2022-06-25 15:14:32.506256
# Unit test for method max of class Timers
def test_Timers_max():
    """Test Timers.max"""
    timers_0 = Timers()
    timers_0.add('test', 5)
    assert timers_0.max('test') == 5
    timers_0.add('test', 2)
    assert timers_0.max('test') == 5


# Generated at 2022-06-25 15:14:37.197129
# Unit test for method median of class Timers
def test_Timers_median():
    """
    Timers.median()
    """
    global timers_0
    timers_0.add('time', 0.041666666666666664)
    timers_0.add('time', 0.041666666666666664)
    timers_0.add('time', 0.041666666666666664)
    assert 0.041666666666666664 == timers_0.median('time')
    timers_0.clear()


# Generated at 2022-06-25 15:14:39.289340
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    value_0 = timers_0.median("")
    assert value_0 == 0


# Generated at 2022-06-25 15:14:41.122435
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()

    assert timers_0.mean("0") == 0.0


# Generated at 2022-06-25 15:14:48.254659
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('some_timer', 0.1)
    timers_0.add('some_timer', 0.2)
    timers_0.add('some_timer', 0.3)
    result = timers_0.max('some_timer')
    print('result should be 0.3: ', result)
    assert result == 0.3



# Generated at 2022-06-25 15:14:50.245501
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    name = ""
    value = timers_0.median(name)


# Generated at 2022-06-25 15:14:52.454326
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name = ""
    assert timers_0.mean(name) == 0


# Generated at 2022-06-25 15:14:59.252376
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_1 = Timers()
    timers_1.add("foo", 10)
    timers_0['bar'] = 10.0


# Generated at 2022-06-25 15:15:06.517427
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('de_mus', 0.10444444444444444)
    timers_0.add('de_mus', 0.14)
    timers_0.add('de_mus', 0.1321111111111111)
    timers_0.add('de_mus', 0.1311111111111111)
    timers_0.add('de_mus', 0.12177777777777777)
    timers_0.add('de_mus', 0.13333333333333333)
    timers_0.add('de_mus', 0.12711111111111112)
    timers_0.add('de_mus', 0.1511111111111111)
    timers_0.add('de_mus', 0.13444444444444444)

# Generated at 2022-06-25 15:15:10.549284
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("name", 0.413191703809)
    timers_0.add("name", 0.816504019864)
    assert math.isclose(timers_0.max("name"), 0.816504019864)


# Generated at 2022-06-25 15:15:16.354916
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("0", 1.5)
    timers_0.add("0", -2.4)
    timers_0.add("0", 0.3)
    timers_0["0"] = -0.1
    timers_0.add("0", 0.6)

    assert timers_0.mean("0") == 0.5

# Generated at 2022-06-25 15:15:24.902458
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1[('f', 0, 1)] = 0.1
    timers_1[('g', 0, 1)] = 0.2
    timers_1[('f', 0, 2)] = 0.3
    timers_1[('f', 1, 1)] = 0.4
    timers_1[('g', 1, 1)] = 0.5
    timers_1[('g', 0, 2)] = 0.6
    timers_1[('f', 1, 2)] = 0.7
    timers_1[('g', 1, 2)] = 0.8
    
    assert timers_1.mean(('f', 0, 1)) == 0.1
    assert timers_1.mean(('g', 0, 1)) == 0.2

# Generated at 2022-06-25 15:15:29.946170
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Input parameters
    timers_0 = Timers()
    name = ""
    print(timers_0.mean(name))
    assert (
        timers_0.mean(name) == None
    )  # The behavior of the method is not tested yet.

if __name__ == "__main__":
    test_case_0()
    test_Timers_mean()

# Generated at 2022-06-25 15:15:34.664147
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("kO", 0.0)
    timers_0.add("6f>", 0.0)
    timers_0.add("kO", 0.0)
    return timers_0.min("6f>")


# Generated at 2022-06-25 15:15:38.798050
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_ = Timers()
    name = "8l3WnJfHBT"
    value = "Q8kzbTtYsY"
    timers_.timing(name, value)
    assert timers_.mean(name) == value


# Generated at 2022-06-25 15:15:43.273347
# Unit test for method max of class Timers
def test_Timers_max():
  timers_0 = Timers()
  name_0 = "Timer"
  timers_0.add(name_0,0.015)
  # Tests for method max of class Timers
  assert 0.015 == timers_0.max(name_0)

# Unit tests for class Timers

# Generated at 2022-06-25 15:15:50.169275
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("key_0", 0.897729)
    timers_0.add("key_1", 0.56457)
    timers_0.add("key_2", 0.123928)
    timers_0.add("key_3", -0.082385)
    timers_0.add("key_4", 0.470919)
    timers_0.add("key_5", 0.405319)
    timers_0.add("key_6", -1.356831)
    timers_0.add("key_7", 0.303383)
    timers_0.add("key_8", -1.092452)
    timers_0.add("key_9", 0.942893)

# Generated at 2022-06-25 15:15:57.007725
# Unit test for method mean of class Timers
def test_Timers_mean():
    test_case_0()
    timers_0 = Timers()
    assert math.isnan(timers_0.mean("ejfibj"))


# Generated at 2022-06-25 15:16:01.212988
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('docker', 6)
    timers.add('docker', 2)
    timers.add('docker', 1)
    timers.add('docker', 3)
    timers.add('docker', 4)
    timers.add('docker', 5)
    assert(timers.mean('docker')==3.5)


# Generated at 2022-06-25 15:16:09.710577
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert math.isnan(timers_0.median('foo'))
    timers_0.add('foo', 1.0)
    assert 1.0 == timers_0.median('foo')
    timers_0.add('foo', 1.0)
    assert 1.0 == timers_0.median('foo')
    timers_0.add('foo', 2.0)
    assert 1.0 == timers_0.median('foo')
    timers_0.add('foo', 3.0)
    assert 1.5 == timers_0.median('foo')
    timers_0.add('foo', 4.0)
    assert 2.0 == timers_0.median('foo')
    timers_0.add('foo', 5.0)
    assert 2.5 == timers

# Generated at 2022-06-25 15:16:17.677333
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("key_0", 0.054251178127928806)
    timers_0.add("key_0", 0.050556687604997105)
    assert timers_0.count("key_0") == 2
    assert timers_0.total("key_0") == 0.10482786573292653
    assert timers_0.min("key_0") == 0.050556687604997105
    assert timers_0.max("key_0") == 0.054251178127928806
    assert timers_0.mean("key_0") == 0.052413932866458615
    # median not equal to median of sorted list
    assert timers_0.median("key_0") == 0.05425117812

# Generated at 2022-06-25 15:16:22.970208
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1.add("foo", 1.0)
    timers_1.add("foo", 2.0)
    assert(timers_1.min("foo") == 1.0)


# Generated at 2022-06-25 15:16:33.758451
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()

    timers_0.add("key_2", 1.01)
    timers_0.add("key_3", 2.01)
    timers_0.add("key_4", 3.01)
    timers_0.add("key_2", 1.01)
    timers_0.add("key_3", 2.01)
    timers_0.add("key_4", 3.01)
    timers_0.add("key_1", 0.01)
    assert(timers_0.max("key_1") == 0.01)
    assert(timers_0.max("key_2") == 1.01)
    assert(timers_0.max("key_3") == 2.01)

# Generated at 2022-06-25 15:16:36.687515
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("key_0", 0.0)
    timers_0.median("key_0")
    timers_0.add("key_0", 0.0)
    timers_0.median("key_0")
    timers_0.add("key_0", 0.0)
    timers_0.median("key_0")


# Generated at 2022-06-25 15:16:39.619554
# Unit test for method max of class Timers
def test_Timers_max():
    """
    Test for method max of class Timers.
    """
    timers_0 = Timers()
    timers_0.add('test_case_0', 1.0)
    assert timers_0.max('test_case_0') == 1.0


# Generated at 2022-06-25 15:16:43.811041
# Unit test for method median of class Timers
def test_Timers_median():
    # Create an instance of Timers
    timers_0 = Timers()
    print(timers_0.median('timers_0'))

    # Create an instance of Timers
    timers_1 = Timers()
    print(timers_1.median('timers_1'))

    # Create an instance of Timers
    timers_2 = Timers()
    print(timers_2.median('timers_2'))



# Generated at 2022-06-25 15:16:46.712601
# Unit test for method min of class Timers
def test_Timers_min():
    """
    Test function that tests th class Timers'
    min function
    """
    timers_0 = Timers()
    assert timers_0.min('start') == 0
    assert timers_0.min('stop') == 0


# Generated at 2022-06-25 15:16:59.109617
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("time (s)",10)
    assert timers_0.min("time (s)") == 10
    

# Generated at 2022-06-25 15:17:05.663328
# Unit test for method max of class Timers
def test_Timers_max():
    '''Test for method max'''
    # Init method
    timers_0 = Timers()
    # Define input arguments
    name = 'name'
    try:
        # Execute method
        timers_0.max(name)
    except KeyError as error:
        # Verify result
        assert str(error) == name
    # Define input arguments
    name = 'name'
    # Execute method
    timers_0.max(name)


# Generated at 2022-06-25 15:17:09.546704
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("a", 1)
    timers.add("a", 2)
    timers.add("b", 3)
    timers.add("b", 4)
    assert timers.min("a") == 1
    assert timers.min("b") == 3



# Generated at 2022-06-25 15:17:11.156839
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('test_name_4', 1)
    assert math.isclose(timers_0.mean('test_name_4'), 1, rel_tol=1e-09)


# Generated at 2022-06-25 15:17:16.421930
# Unit test for method min of class Timers
def test_Timers_min():
    assert(timers_0.min(name="name") == 0.0)


# Generated at 2022-06-25 15:17:24.913991
# Unit test for method median of class Timers
def test_Timers_median():
    timer_1 = Timers()
    timer_1.add("timer_1", 0)
    timer_1.add("timer_2", 1)
    timer_1.add("timer_3", 2)
    timer_1.add("timer_3", 3)
    timer_1.add("timer_3", 4)

    assert timer_1.median("timer_1") == 0
    assert timer_1.median("timer_2") == 1
    assert timer_1.median("timer_3") == 2.5


if __name__ == "__main__":
    test_case_0()
    test_Timers_median()

# Generated at 2022-06-25 15:17:29.997472
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method mean of class Timers"""
    # Global setup
    timers_0 = Timers()
    name_0 = "2"
    # Test of method mean of class Timers
    assert timers_0.mean(name_0) == 0.0


# Generated at 2022-06-25 15:17:40.534262
# Unit test for method median of class Timers

# Generated at 2022-06-25 15:17:47.911870
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("foo", 1.0)
    # On success, raises no exceptions
    try:
        timers_0.max("foo")
    except Exception:
        import sys
        import traceback
        exception = sys.exc_info()
        traceback.print_exception(*exception)
        raise AssertionError("unexpected exception") from exception


# Generated at 2022-06-25 15:17:49.699562
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert timers_0.median("name") == 0.0


# Generated at 2022-06-25 15:18:02.313339
# Unit test for method mean of class Timers
def test_Timers_mean():

    timers_0 = Timers()
    timers_1 = Timers({'call_1': 5.0, 'call_2': 5.0})
    assert timers_1.mean('call_1') == 5.0
    assert timers_1.mean('call_2') == 5.0


# Generated at 2022-06-25 15:18:03.269368
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()


# Generated at 2022-06-25 15:18:05.070661
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    pass


# Generated at 2022-06-25 15:18:15.395885
# Unit test for method max of class Timers
def test_Timers_max():

    # Case 0
    timers_0 = Timers()
    timers_0._timings["T0"] = [0.0]
    timers_0.add("T0", 2.1)
    timers_0.add("T1", 3.2)
    result_0 = timers_0.max("T0")
    expected_0 = 2.1

    assert result_0 == expected_0


    # Case 1
    timers_1 = Timers()
    timers_1._timings["T0"] = [0.0, 3.2]
    timers_1.add("T0", 2.1)
    timers_1.add("T1", 3.2)
    result_1 = timers_1.max("T0")
    expected_1 = 3.2

    assert result_1 == expected_1





# Generated at 2022-06-25 15:18:17.981953
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name = ""
    value = 0.06
    timers_0.add(name, value)
    timers_0.mean(name)



# Generated at 2022-06-25 15:18:25.500160
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("test_Timers_max", 0.5361493833073603)
    timers_0.add("test_Timers_max", 0.7624301614147359)
    timers_0.add("test_Timers_max", 0.5512332885143092)
    timers_0.add("test_Timers_max", 0.9422178944969925)
    timers_0.add("test_Timers_max", 0.7213312776909941)
    timers_0.add("test_Timers_max", 0.9276834979050034)
    timers_0.add("test_Timers_max", 0.9550762168987081)

# Generated at 2022-06-25 15:18:34.843162
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("0", 18.0)
    timers_0.add("0", 81.0)
    timers_0.add("0", 44.0)
    timers_0.add("0", -36.0)
    timers_0.add("0", 65.0)
    timers_0.add("0", -73.0)
    timers_0.add("0", 61.0)
    timers_0.add("0", 18.0)
    timers_0.add("0", 76.0)
    timers_0.add("1", -15.0)
    timers_0.add("1", 87.0)
    timers_0.add("1", 74.0)
    timers_0.add("1", -78.0)
    timers_0

# Generated at 2022-06-25 15:18:42.230047
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('name_0', 0.7779330818153467)
    timers_0.add('name_0', 0.5094767724332282)
    timers_0.add('name_0', 0.037678304106867546)
    timers_0.add('name_0', 0.5396231390604847)
    assert math.isclose(timers_0.mean('name_0'), 0.43826139352506148)


# Generated at 2022-06-25 15:18:46.419860
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Setup
    timers_0 = Timers()
    timers_1 = Timers()
    timers_0.add('sw_gc', value=0.12)
    timers_0.add('sw_gc', value=0.19)
    timers_0.add('sw_gc', value=0.17)

    # Exercise
    result = timers_0.mean('sw_gc')

    # Verify
    assert result == 0.16333333333333333
    # Cleanup - none necessary



# Generated at 2022-06-25 15:18:50.656845
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("a", 1.0)
    timers.add("a", 2.0)
    result = timers.median("a")


# Generated at 2022-06-25 15:19:06.154204
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add('matrix.rix_contrib_fspec', 1.4789878)
    timers_1.add('matrix.rix_contrib_fspec', 0.3100395)
    timers_1.add('matrix.rix_contrib_fspec', 0.4323206)
    assert timers_1.mean('matrix.rix_contrib_fspec') == 0.8849505666666666


# Generated at 2022-06-25 15:19:11.968043
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()

    assert timers_0.min('aaa') == 0.0
    assert timers_0.min('bbb') == 0.0
    timers_0.add('aaa', 1)
    timers_0.add('aaa', 2)
    assert timers_0.min('aaa') == 1.0
    timers_0.add('bbb', 3)
    assert timers_0.min('bbb') == 3.0
    timers_0.add('aaa', -1)
    assert timers_0.min('aaa') == -1.0
    assert timers_0.min('bbb') == 3.0


# Generated at 2022-06-25 15:19:17.114390
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_1 = Timers()
    timers_1.add('a', 4.0)
    expected_0 = 4.0
    actual_0 = timers_1.min('a')
    assert actual_0 == expected_0


# Generated at 2022-06-25 15:19:22.163200
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0['cpu:main'] = 0.001
    timers_0['cpu:main'] = 0.001
    timers_0['cpu:main'] = 0.001
    timers_0['cpu:main'] = 0.001
    timers_0['cpu:main'] = 0.001
    assert timers_0.max('cpu:main') == 0.005

# Generated at 2022-06-25 15:19:26.245859
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()

    timers_1.add('timer_0', 1.0)
    assert timers_1.max('timer_0') == 1.0

    timers_1.add('timer_0', 2.0)
    assert timers_1.max('timer_0') == 2.0


# Generated at 2022-06-25 15:19:31.784024
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("quos", 0.5)
    timers_0.add("quos", 0.5)
    timers_0.add("quos", 0.5)
    assert timers_0.min("quos") == 0.5
    timers_0.add("quos", 0.5)
    assert timers_0.min("quos") == 0.5
    timers_0.add("quos", 0.5)
    assert timers_0.min("quos") == 0.5
    timers_0.add("quos", 0.5)
    assert timers_0.min("quos") == 0.5
    timers_0.add("quos", 0.5)
    assert timers_0.min("quos") == 0.5
    assert timers_0

# Generated at 2022-06-25 15:19:33.637296
# Unit test for method mean of class Timers
def test_Timers_mean():
    """
        Asserts that mean works as expected
    """

    timers_0 = Timers()

    timers_0['timer_1'] = 2
    assert timers_0.mean('timer_1') == 0.5



# Generated at 2022-06-25 15:19:38.526190
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()


# Generated at 2022-06-25 15:19:41.510663
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("key_0", 1.0)
    assert 1.0 == timers_0.median("key_0")


# Generated at 2022-06-25 15:19:44.621358
# Unit test for method max of class Timers
def test_Timers_max():

    # Test expected call
    timers = Timers()
    timers.add("max", 0.0)
    timers.add("max", 1.0)
    timers.add("max", 2.0)
    timers.add("max", 3.0)

    assert timers.max("max") == 3.0

# Generated at 2022-06-25 15:19:56.853070
# Unit test for method max of class Timers
def test_Timers_max():
    try:
        timers_1 = Timers()
        timers_1.add('test', 3.0)
        timers_1.max('test')
        print('test 1 ok')
    except TypeError:
        print('test 1 failed')


# Generated at 2022-06-25 15:19:59.612543
# Unit test for method min of class Timers
def test_Timers_min():
    t = Timers()
    t.add("foo", 30)
    t.add("foo", 10)
    assert t.min("foo") == 10
    t.add("bar", 44)
    assert t.min("bar") == 44


# Generated at 2022-06-25 15:20:02.141973
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("mean", 1)
    timers_0.add("mean", 2)
    timers_0.add("mean", 3)
    assert timers_0.mean("mean") == 2


# Generated at 2022-06-25 15:20:07.061793
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('test', 3)
    timers_0.add('test', 4)
    assert timers_0.apply(max, 'test') == 4
    assert timers_0.max('test') == 4


# Generated at 2022-06-25 15:20:13.565393
# Unit test for method max of class Timers
def test_Timers_max():
    # Initialize a Timers object and some timing values
    timers_0 = Timers()
    timers_0.add("foo", 1)
    timers_0.add("bar", 2)

    assert timers_0.max("foo") == 1
    assert timers_0.max("bar") == 2



# Generated at 2022-06-25 15:20:16.581845
# Unit test for method min of class Timers
def test_Timers_min():
    # Setup
    timers_0 = Timers()
    name = rand_string(10)

    # Exercise
    result = timers_0.min(name)

    # Verification
    assert isinstance(result, float)


# Generated at 2022-06-25 15:20:19.357655
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('first',1.0)
    timers_0.add('first',2.0)
    timers_0.add('first',3.0)
    timers_0.add('first',4.0)
    timers_0.add('first',5.0)
    timers_0.add('first',6.0)
    assert (timers_0.max(name='first') == 6.0)


# Generated at 2022-06-25 15:20:25.102105
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert not timers_0.data
    assert timers_0.data == {}

    # Testing keyword arguments
    timers_0.add('name', 0.0)
    assert timers_0.data == {'name': 0.0}
    assert timers_0.total('name') == 0.0
    assert timers_0.count('name') == 1

    # Testing keyword arguments
    timers_0.add('name', 0.0)
    assert timers_0.data == {'name': 0.0}
    assert timers_0.total('name') == 0.0
    assert timers_0.count('name') == 2

    assert timers_0.mean('name') == 0.0

    # Testing keyword arguments
    timers_0.add('name', 6.7)

# Generated at 2022-06-25 15:20:26.733431
# Unit test for method min of class Timers
def test_Timers_min():
    assert Timers.min(Timers, "") is not None


# Generated at 2022-06-25 15:20:30.195527
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("e", 4.347418095424208)
    timers_0.add("w", 2.3773509926391036)
    timers_0.add("r", 1.444483236579274)
    assert timers_0.mean("r") == 1.444483236579274



# Generated at 2022-06-25 15:20:47.269513
# Unit test for method median of class Timers
def test_Timers_median():
    try:
        timers_1 = Timers()
        timers_1.add("key", value = 7)
        timers_1.add("key", value = 6)
        timers_1.add("key", value = 3)
        timers_1.add("key", value = 4)
        timers_1.median("key")
    except BaseException as exception:
        print("Caught exception: ", exception)
        assert False


# Test case for Timers

# Generated at 2022-06-25 15:20:52.088174
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    timers_1[''] = 0
    assert timers_1.max(name='') == 0
    timers_1 = Timers()
    timers_1[''] = 4
    assert timers_1.max(name='') == 4
    timers_1 = Timers()
    timers_1[''] = 9
    assert timers_1.max(name='') == 9

# Generated at 2022-06-25 15:20:57.970614
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('name', 2.0)
    timers_0.add('name', 5.0)
    timers_0.add('name', 2.0)
    timers_0.add('name', 8.0)
    timers_0.add('name', 1.0)
    assert timers_0.max('name') == 8.0, "Failed to calculate max() correctly."


# Generated at 2022-06-25 15:20:59.691767
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert math.isnan(timers_0.median("duration"))

# Generated at 2022-06-25 15:21:04.222123
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("name", 0.7)
    timers_0.add("name", 0.3)
    timers_0.add("name", 0.5)
    timers_0.add("name", 0.6)
    timers_0.add("name", 0.8)
    assert_equal(timers_0.median('name'), 0.6,
                 'test case 0 failed')


# Generated at 2022-06-25 15:21:06.379437
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1.add("Timer_1", 42.0)
    assert timers_1.min("Timer_1") == 42.0



# Generated at 2022-06-25 15:21:14.443085
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()

    timers_0.add('ex', 124.5)
    assert (timers_0.min('ex') == 124.5)
    timers_0.add('ex', 98.5)
    assert (timers_0.min('ex') == 98.5)
    timers_0.add('ex', 15.6)
    assert (timers_0.min('ex') == 15.6)


# Generated at 2022-06-25 15:21:17.750720
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    name = ""
    value = 0.0
    # Test for function add of class Timers
    def test_Timers_add():
        timers_0.add(name, value)



# Generated at 2022-06-25 15:21:26.605378
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    print(timers_0.min(name="name"))
    timers_0.add(name="name", value=8.92)
    print(timers_0.min(name="name"))
    timers_0.add(name="name", value=2.10)
    print(timers_0.min(name="name"))

if __name__ == '__main__':
    test_case_0()
    test_Timers_min()

# Generated at 2022-06-25 15:21:32.109676
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('aa', 1.0)
    timers_0.add('aa', 1.0)
    timers_0.add('bb', 2.0)
    timers_0.add('bb', 3.0)
    result = timers_0.max('aa')
    assert result == 1.0
