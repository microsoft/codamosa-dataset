

# Generated at 2022-06-25 15:11:43.099722
# Unit test for method median of class Timers
def test_Timers_median():
    t = Timers()
    assert t.median("timer_0") == 0
    t.add("timer_0", 1.5)
    assert t.median("timer_0") == 1.5
    t.add("timer_0", 2.5)
    assert t.median("timer_0") == 2.0
    t.add("timer_0", 0.5)
    assert t.median("timer_0") == 1.5

# Generated at 2022-06-25 15:11:49.163588
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.clear()
    timers_0.add('timer_0', 0.0)
    timers_0.add('timer_0', 0.0)
    timers_0.add('timer_0', 0.0)
    # AssertionError: unexpected error: 'timer_0'
    assert timers_0.max('timer_0') == 0.0
    # AssertionError: unexpected error: 'timer_99'
    assert timers_0.max('timer_99') == 0.0


# Generated at 2022-06-25 15:11:56.730073
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()

    # Try getting min of empty timers
    try:
        min_0 = timers.min(name="asdf")
    except KeyError as exception_0:
        min_0 = exception_0.args[0]

    # Push new values to the timers
    timers.add(name="asdf", value=0.2)
    timers.add(name="asdf", value=0)
    timers.add(name="asdf", value=0.2)
    timers.add(name="asdf", value=0.2)

    min_1 = timers.min(name="asdf")
    return [min_0, min_1]



# Generated at 2022-06-25 15:11:59.093344
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Initialize timers_0
    timers_0 = Timers()

    # Add values to timers_0

    timers_0.add('name', 0)

    # Apply mean to timers_0
    assert timers_0.mean('name') == 0


# Generated at 2022-06-25 15:12:04.493370
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('name_0', float(154))
    float_0 = timers_0.max('name_0')
    assert float_0 == 154.0
    timers_0.add('name_1', float(1))
    float_0 = timers_0.max('name_1')
    assert float_0 == 1.0
    timers_0.add('name_0', float(82))
    float_0 = timers_0.max('name_0')
    assert float_0 == 154.0
    float_0 = timers_0.max('name_1')
    assert float_0 == 1.0
    timers_0.add('name_2', float(46))
    float_0 = timers_0.max('name_0')

# Generated at 2022-06-25 15:12:09.690066
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('foo', 27.97)
    timers_0.add('foo', 11.06)
    timers_0.add('bar', 48.68)
    timers_0.add('foo', 48.97)
    timers_0.add('bar', 42.94)
    timers_0.add('foo', 25.71)
    timers_0.add('bar', 20.22)
    assert timers_0.mean('foo') == 31.24333
    assert timers_0.mean('bar') == 37.05333


# Generated at 2022-06-25 15:12:14.869469
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers({'bla': 1})
    assert timers_1.median('bla') == 1
    timers_2 = Timers({'bla': 1})
    timers_2.add('bla', 2)
    assert timers_2.median('bla') == 1.5
    timers_3 = Timers()
    assert timers_3.median('bla') == 0
    timers_3.add('bla', 2)
    assert timers_3.median('bla') == 2
    timers_4 = Timers()
    timers_4.add('bla', 1)
    timers_4.add('bla', 2)
    timers_4.add('bla', 3)
    assert timers_4.median('bla') == 2

# Generated at 2022-06-25 15:12:19.546868
# Unit test for method mean of class Timers
def test_Timers_mean():
    try:
        timers = Timers()
        timers.add("timer_0", 1.0)
        timers.add("timer_0", 2.0)
        assert timers.mean("timer_0") == 1.5
    except AssertionError:
        raise AssertionError("unable to calculate mean")


# Generated at 2022-06-25 15:12:22.596072
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('a', 1.2)
    timers_0.add('b', 1.3)
    timers_0.add('a', 1.01)
    assert timers_0.min('a') == 1.01

# Generated at 2022-06-25 15:12:30.717718
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_1 = Timers()
    timers_2 = Timers()
    timers_3 = Timers()
    timers_4 = Timers()
    timers_5 = Timers()
    timers_6 = Timers()
    timers_7 = Timers()
    timers_8 = Timers()
    timers_9 = Timers()
    timers_10 = Timers()
    timers_11 = Timers()
    timers_12 = Timers()
    timers_13 = Timers()
    timers_14 = Timers()
    timers_15 = Timers()
    timers_16 = Timers()
    timers_17 = Timers()
    timers_18 = Timers()
    timers_19 = Timers()
    timers_20 = Timers()
    timers_21 = Timers()
   

# Generated at 2022-06-25 15:12:43.571007
# Unit test for method median of class Timers
def test_Timers_median():
    # Initialize an instance of Timers
    timers_0_0 = Timers()
    # Get the median for timer 'watch timer'
    assert timers_0_0.median('watch timer') == 0
    # Add a timing of 2.60 to timer 'watch timer'
    timers_0_0.add('watch timer', 2.60)
    # Get the median for timer 'watch timer'
    assert timers_0_0.median('watch timer') == 2.60
    # Add a timing of 2.60 to timer 'watch timer'
    timers_0_0.add('watch timer', 2.60)
    # Get the median for timer 'watch timer'
    assert timers_0_0.median('watch timer') == 2.60
    # Add a timing of 2.60 to timer 'watch timer'
    timers_0_

# Generated at 2022-06-25 15:12:51.427372
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("a", 0.328375)
    timers_0.add("a", 0.137535)
    timers_0.add("a", 0.7303)
    timers_0.add("a", 0.222385)
    timers_0.add("a", 0.62120)
    timers_0.add("a", 0.116675)
    timers_0.add("a", 0.04914)
    timers_0.add("a", 0.667795)
    timers_0.add("a", 0.785045)
    timers_0.add("a", 0.346905)
    timers_0.add("a", 0.63845)
    timers_0.add("a", 0.331255)
   

# Generated at 2022-06-25 15:12:52.401633
# Unit test for method max of class Timers
def test_Timers_max():
    assert 1 == 1,"Test not implemented"


# Generated at 2022-06-25 15:12:58.560307
# Unit test for method median of class Timers
def test_Timers_median():
    for _ in range(100):
        timers_0 = Timers()
        timers_0.add(name="foo", value=0.0)
        assert 0.0 == timers_0.mean(name="foo")


# Generated at 2022-06-25 15:13:07.055635
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("foo", 0.1)
    timers_0.add("foo", 0.7)
    timers_0.add("bar", 0.9)
    timers_0.add("bar", 0.2)
    timers_0.add("baz", 0.9)
    timers_0.add("baz", 0.1)
    timers_0.add("baz", 0.8)
    timers_0.add("baz", 0.3)
    assert timers_0.max("foo") == 0.7
    assert round(timers_0.max("bar"), 2) == 0.9
    assert round(timers_0.max("baz"), 2) == 0.9


# Generated at 2022-06-25 15:13:08.626324
# Unit test for method max of class Timers
def test_Timers_max():
    expected = Timers()
    
    # Fail if there is an exception
    try: 
        assert expected is None
    except AssertionError:
        print("No value was returned.")


# Generated at 2022-06-25 15:13:15.709133
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    for timer_name in ["", "", "", ""]:
        for timer_name_1 in ["timer_name_1", "timer_name_1", "timer_name_2"]:
            for timer_value in [277.14169898, 877.17290942, 940.044029, 879.57634569]:
                timers.add(timer_name, timer_value)
    assert timers.min("timer_name_1") == 277.14169898
    assert timers.min("timer_name_2") == 940.044029

# Generated at 2022-06-25 15:13:17.781399
# Unit test for method min of class Timers
def test_Timers_min():

    timers_0 = Timers()

    string_0 = 'x1c%2;'
    # This is a test of the min method.
    assert timers_0.min(string_0) == 0


# Generated at 2022-06-25 15:13:26.193573
# Unit test for method min of class Timers
def test_Timers_min():
    import random

    timers = Timers()
    name = "test_timer"
    for _ in range(10):
        timers.add(name, random.uniform(0, 1))

    timer_min = timers.min(name)
    timer_min_ref = min(timers._timings[name])
    assert timer_min == timer_min_ref

    # This should raise an exception
    try:
        timers.min("unknown_timer")
    except KeyError:
        pass



# Generated at 2022-06-25 15:13:30.550832
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    timers_1.add("key_0", 690)
    assert timers_1.max("key_0") == 690
    timers_2 = Timers()
    timers_2.add("key_0", 124)
    assert timers_2.max("key_0") == 124


# Generated at 2022-06-25 15:13:42.232495
# Unit test for method median of class Timers
def test_Timers_median():
    import unittest
    import random
    import statistics

    class TimersTests(unittest.TestCase):
        def test_median(self):
            # n = 10
            # numbers = [random.randrange(0, 100) for i in range(n)]
            # number_median = statistics.median(numbers)
            # timers = Timers({})
            # for number in numbers:
            #     timers.add("t", number)
            # self.assertEqual(timers.median("t"), number_median)
            self.assertEqual(True, True)

    unittest.main(exit=False)



# Generated at 2022-06-25 15:13:48.476661
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1.add('key-0', 0.28065657894131805)
    timers_1.add('key-1', 0.6221598989750978)
    timers_1.add('key-2', 0.7281985380503674)
    timers_1.add('key-3', 0.08136529624521159)
    timers_1.add('key-4', 0.3216990418319351)
    timers_1.add('key-5', 0.3035290681917804)
    timers_1.add('key-6', 0.8659571527227679)
    timers_1.add('key-7', 0.14608578326216466)

# Generated at 2022-06-25 15:13:51.446350
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert math.isnan(timers_0.mean("fhceo"))


# Generated at 2022-06-25 15:14:02.443194
# Unit test for method median of class Timers
def test_Timers_median():
    from random import gauss
    timers_median = Timers()
    for value in [gauss(0, 1) for _ in range(100000)]:
        timers_median.add("gaussian", float(value))
    assert abs(timers_median.mean("gaussian") - 0) < 0.001
    assert abs(timers_median.median("gaussian") - 0) < 0.001
    assert abs(timers_median.stdev("gaussian") - 1) < 0.001
    assert timers_median.count("gaussian") == 100000
    assert abs(timers_median.total("gaussian") - 0) < 0.001
    assert timers_median.min("gaussian") < timers_median.max("gaussian")

# Generated at 2022-06-25 15:14:10.903548
# Unit test for method median of class Timers
def test_Timers_median():
    """
    Tests method median of class Timers
    """
    # Constructor test
    timers_0 = Timers()
    # Accessor test
    timers_0.data["bar"] = 1.9404960537351444
    timers_0.data["baz"] = 3.009290985391072
    # str override test
    assert str(timers_0) == "{'bar': 1.9404960537351444, 'baz': 3.009290985391072}"
    # repr override test
    assert repr(timers_0) == "{'bar': 1.9404960537351444, 'baz': 3.009290985391072}"
    # Method test
    assert isinstance(timers_0.median("foo"), float)
    # Method test
    assert isinstance

# Generated at 2022-06-25 15:14:12.884735
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("name", 0)
    timers_0.mean("name")


# Generated at 2022-06-25 15:14:21.585136
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    timers_1.add('name-0', value=4.064599608619505)
    timers_1.add('name-1', value=3.292804912570181)
    timers_1.add('name-2', value=2.9173116220463076)
    timers_1.add('name-3', value=5.573575384070591)
    timers_1.add('name-4', value=2.486670915881312)
    timers_1.add('name-5', value=2.331205863499236)
    timers_1.add('name-6', value=5.222142858985588)

# Generated at 2022-06-25 15:14:22.832902
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("1", 1.)
    assert timers.mean("1") == 1.


# Generated at 2022-06-25 15:14:31.320176
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    try:
        assert math.isclose(timers_0.min("y"), 0.0, rel_tol=1e-09)
    except:
        timers_0.add("y", 0.0)
        assert math.isclose(timers_0.min("y"), 0.0, rel_tol=1e-09)
    try:
        assert math.isclose(timers_0.min("s"), 0.0, rel_tol=1e-09)
    except:
        timers_0.add("s", 0.0)
        assert math.isclose(timers_0.min("s"), 0.0, rel_tol=1e-09)


# Generated at 2022-06-25 15:14:39.292650
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()

    assert math.isnan(timers_0.mean('name_1'))

    timers_0.add('name_0', 0.0)
    # Method apply of class Timers should be called with parameter (lambda values: statistics.mean(values or [0]),)
    assert math.isclose(timers_0.mean('name_0'), 0.0, rel_tol=1e-15)

    timers_0.add('name_0', 0.3)
    # Method apply of class Timers should be called with parameter (lambda values: statistics.mean(values or [0]),)
    assert math.isclose(timers_0.mean('name_0'), 0.15, rel_tol=1e-15)

    timers_0.add('name_0', 0.3)


# Generated at 2022-06-25 15:14:46.067779
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('counter', 1.0)
    timers_0.add('counter', 2.0)
    assert timers_0.median('counter') == 1.5

# Generated at 2022-06-25 15:14:49.378809
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1.add("GET", 0.4)
    timers_1.add("GET", 0.4)
    assert 0.4 == timers_1.min("GET")



# Generated at 2022-06-25 15:14:56.477549
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.data = {'sxgxk': 3.410176594712053, 'qgqy': 19.0999990722515}
    timers_0.add('qgqy', 31.45172905111162)
    assert timers_0.mean('qgqy') == (19.0999990722515 + 31.45172905111162)/2

if __name__ == "__main__":
    print(f"Executed {__file__}")
    test_case_0()
    test_Timers_mean()

# Generated at 2022-06-25 15:14:58.090347
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert math.isnan(timers_0.median(name=''))

# Generated at 2022-06-25 15:15:05.944738
# Unit test for method max of class Timers
def test_Timers_max():
    # Timers instance timers_0 initialization
    timers_0 = Timers()
    # Timers instance timers_1 initialization
    timers_1 = Timers()
    # Timers instance timers_0 adding item (method add)
    timers_0.add("key_0", 1e-06)
    # Timers instance timers_0 adding item (method add)
    timers_0.add("key_1", 1e-06)
    # Timers instance timers_1 adding item (method add)
    timers_1.add("key_0", 1e-06)
    # Timers instance timers_1 adding item (method add)
    timers_1.add("key_1", 1e-06)
    # Variable value_0 initialization
    value_0 = timers_0.max("key_0")
    # Variable value_1 initialization
   

# Generated at 2022-06-25 15:15:08.562251
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0["timer_name"] = 3.0
    timers_0.apply(statistics.mean, "timer_name")


# Generated at 2022-06-25 15:15:17.153342
# Unit test for method median of class Timers
def test_Timers_median():

    timers_0 = Timers()

    timers_0.add('my_timer_0', 0.361148)
    timers_0.add('my_timer_0', 0.560472)
    timers_0.add('my_timer_0', 0.82793)
    timers_0.add('my_timer_0', 0.438028)
    timers_0.add('my_timer_0', 0.653059)
    timers_0.add('my_timer_0', 0.822496)

    assert timers_0.median('my_timer_0') == 0.653059


# Generated at 2022-06-25 15:15:20.506118
# Unit test for method median of class Timers
def test_Timers_median():

    # Set up fixture
    timers = Timers()
    timers.add("test", 1.2)

    # Test method
    assert timers.median("test") == 1.2


# Generated at 2022-06-25 15:15:23.127333
# Unit test for method median of class Timers
def test_Timers_median():
    result = Timers().median(TimerName='TimerName')
    assert isinstance(result, float)
    assert 0 <= result <= 1


# Generated at 2022-06-25 15:15:26.097953
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('aaa', -3.0)
    timers_0.add('aaa', -2.0)
    timers_0.min('aaa')


# Generated at 2022-06-25 15:15:37.582552
# Unit test for method max of class Timers
def test_Timers_max():
    print('Test: Timers.max()')
    timers = Timers()
    timers.add('a', 4)
    timers.add('b', 1)
    timers.add('b', 5)
    timers.add('c', 7)
    timers.add('c', 1)
    timers.add('c', -1)
    result = timers.max('a')
    print('    Result:', result)
    assert result == 4, 'Result should be 4, was {}.'.format(result)
    result = timers.max('c')
    print('    Result:', result)
    assert result == 7, 'Result should be 7, was {}.'.format(result)


# Generated at 2022-06-25 15:15:42.014438
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    # Call method min of class Timers. Expected: <KeyError: 'name'>
    try:
        timers_0.min(name='name')
    except KeyError as error:
        assert error.args == ('name', )


# Generated at 2022-06-25 15:15:51.423916
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    timers_1.add("all", 1)
    timers_1.count("all") == 1
    timers_1.total("all") == 1
    timers_1.min("all") == 1
    timers_1.max("all") == 1
    timers_1.mean("all") == 1
    timers_1.median("all") == 1
    timers_1.stdev("all") == 0

    timers_1.add("all", 2)
    timers_1.count("all") == 2
    timers_1.total("all") == 3
    timers_1.min("all") == 1
    timers_1.max("all") == 2
    timers_1.mean("all") == 1.5
    timers_1.median("all") == 1.5
    timers_

# Generated at 2022-06-25 15:16:00.028051
# Unit test for method min of class Timers
def test_Timers_min():

    timers_0 = Timers()
    timers_0.data = {'speed_up': 0.0, 'iteration_time': 0.0, 'speed_down': 0.0}

    timers_0.add('speed_up', 1.0)
    assert timers_0.min('speed_up') == 1.0

    timers_0.add('speed_up', 2.0)
    assert timers_0.min('speed_up') == 1.0

    timers_0.add('speed_up', 3.0)
    assert timers_0.min('speed_up') == 1.0

    timers_0.add('speed_up', 3.0)
    assert timers_0.min('speed_up') == 1.0



# Generated at 2022-06-25 15:16:01.978217
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    assert timers.max("test") == 2


# Generated at 2022-06-25 15:16:05.229354
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("key_0", 0.0)
    assert timers_0.median("key_0") == 0.0
    timers_0.apply(statistics.median, "key_0")
    timers_0.apply(lambda values: min(values or [0]), "key_0")


# Generated at 2022-06-25 15:16:06.788301
# Unit test for method median of class Timers
def test_Timers_median():
    collection = [1, 2, 3, 4, 5]
    actual = statistics.median(collection)
    expected = 3
    assert actual == expected


# Generated at 2022-06-25 15:16:09.368182
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    # Test with invalid input
    with raises(KeyError) as exc:
        timers_0.median('test')
    assert exc.value.args[0] == 'test'



# Generated at 2022-06-25 15:16:12.144545
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("name")
    try:
        assert timers_0.mean("name") == 0
    except:
        print("Test failed - mean")


# Generated at 2022-06-25 15:16:14.203584
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('bob', 1.0)
    assert timers_0.max('bob') == 1.0


# Generated at 2022-06-25 15:16:22.159732
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    assert timers.median("a") == 0
    timers.add("a", 20)
    assert timers.median("a") == 20
    timers.add("a", 30)
    assert timers.median("a") == 25


# Generated at 2022-06-25 15:16:29.707410
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    try:
        timers_0.mean('7p')
        assert False
    except KeyError:
        pass
    timers_0.add('7p', 2.3)
    timers_0.add('7p', 7.1)
    timers_0.add('7p', 9.8)
    assert math.isclose(timers_0.mean('7p'), 6.166666666666667)


# Generated at 2022-06-25 15:16:32.893975
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("value", 0.0)


# Generated at 2022-06-25 15:16:39.488659
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("LXrMu", 1.0)
    timers_0.add("LXrMu", 0.2)
    timers_0.add("LXrMu", 0.3)
    assert (timers_0.min("LXrMu") == min([0.2, 0.3, 1.0]))


# Generated at 2022-06-25 15:16:41.553059
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("a", 2)
    func = timers_0.mean
    assert func("a") == 2


# Generated at 2022-06-25 15:16:52.610945
# Unit test for method min of class Timers
def test_Timers_min():
    from random import random
    timers_0 = Timers()
    timers_1 = Timers()
    key = 'a'
    timers_0.add(key, random())
    timers_1.add(key, random())
    value_0 = timers_0.min(key)
    value_1 = timers_1.min(key)
    value_2 = timers_1.min(key)
    value_3 = timers_1.min(key)
    value_4 = timers_0.min(key)
    value_5 = timers_1.min(key)
    # assert value_0 <= value_1 <= value_2 <= value_3 <= value_4 <= value_5
    # assert value_0 == min(value_0, value_1, value_2, value_3, value_4, value_5)

# Generated at 2022-06-25 15:16:56.886705
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers({'D': 1.0, 'B': 2.0, 'A': 3.0, 'C': 4.0})
    assert timers_1.min('D') == 1.0
    assert timers_1.min('C') == 4.0
    assert timers_1.min('A') == 3.0
    assert timers_1.min('B') == 2.0


# Generated at 2022-06-25 15:16:59.263139
# Unit test for method mean of class Timers
def test_Timers_mean():

    timers_0 = Timers()
    timers_0.add("my_timer_0", 5.0)
    timers_0.mean("my_timer_0")



# Generated at 2022-06-25 15:17:07.254856
# Unit test for method max of class Timers
def test_Timers_max():
    """ Method max of class Timers """
    try:
        test_case_0()
    except NameError:
        pass
    timers_1 = Timers()
    timers_1.add('hello', 1.0)
    timers_1.add('hello', 3.0)
    timers_1.add('world', 1.0)
    timers_1.add('world', 2.0)
    assert timers_1.max('hello') == 3.0
    assert timers_1.max('world') == 2.0
    assert timers_1.max('bogus') == 0


# Generated at 2022-06-25 15:17:08.582574
# Unit test for method min of class Timers
def test_Timers_min():
    # Stopping timers
    timers_0 = Timers()



# Generated at 2022-06-25 15:17:22.269705
# Unit test for method median of class Timers
def test_Timers_median():
    random_seed(0)
    values_0 = list(nprnd.normal(loc=0.0, scale=1.0, size=1000))

    assert sum(values_0) == pytest.approx(14.971923853367982)
    assert statistics.median(values_0) == pytest.approx(0.0)

    timers_0 = Timers()
    count_0 = 0
    for value in values_0:
        count_0 += 1
        timers_0.add(name='test', value=value)

    assert count_0 == 1000

    timers_0.apply(func=lambda values: len(values), name='test') == 1000


# Generated at 2022-06-25 15:17:28.312314
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("test", 1.0)
    timers_0.add("test", 2.0)
    timers_0.add("test", 5.0)
    timers_0.add("test", 6.0)
    assert timers_0.median("test") == 3.5


# Generated at 2022-06-25 15:17:35.784389
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    assert timers_1.median("timer 0") == 0
    timers_1.add("timer 0", 1)
    assert timers_1.median("timer 0") == 1
    timers_1.add("timer 1", 10)
    timers_1.add("timer 0", 2)
    timers_1.add("timer 0", 3)
    assert timers_1.median("timer 0") == 2
    timers_1.add("timer 0", 4)
    assert timers_1.median("timer 0") == 2.5


# Generated at 2022-06-25 15:17:44.758914
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.add("a", 1)
    timers_1.add("a", 5)
    timers_1.add("a", 3)
    timers_1.add("a", 4)
    timers_1.add("a", 2)
    assert timers_1.median("a") == 3
    timers_1.add("a", 6)
    timers_1.add("a", 7)
    assert timers_1.median("a") == 4.5
    timers_1.add("a", 8)
    assert timers_1.median("a") == 5
    timers_1.add("a", 9)
    assert timers_1.median("a") == 5.5

# Generated at 2022-06-25 15:17:46.750690
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = 'name'
    assert timers_0.mean(name_0) == 0


# Generated at 2022-06-25 15:17:52.013000
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    assert timers.min("de") == 0
    timers.add("de", 1)
    timers.add("de", 2)
    timers.add("de", 3)
    assert timers.min("de") == 1
    assert timers.min("deu") == 0
    try:
        timers.min("")
    except KeyError:
        pass
    try:
        timers.min(5)
    except KeyError:
        pass



# Generated at 2022-06-25 15:17:59.333875
# Unit test for method median of class Timers
def test_Timers_median():
    """Test the method median of the class Timers."""
    timers_0 = Timers()
    assert math.isnan(timers_0.median("seconds"))
    assert math.isnan(timers_0.median("entries"))
    assert math.isnan(timers_0.median("requests"))
    assert math.isnan(timers_0.median("edges"))
    assert math.isnan(timers_0.median("asserts"))
    assert math.isnan(timers_0.median("checks"))
    assert math.isnan(timers_0.median("modifies"))
    assert math.isnan(timers_0.median("responses"))
    assert math.isnan(timers_0.median("datastore"))
    assert math.isnan

# Generated at 2022-06-25 15:18:02.355926
# Unit test for method min of class Timers
def test_Timers_min():
    # Setup
    timers = Timers()
    timers.add("name0", 1)
    timers.add("name0", 2)
    # Exercise
    expected_value = 1
    # Verify
    assert timers.min("name0") == expected_value

# Generated at 2022-06-25 15:18:08.229977
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("tag", 0.10)
    timers_0.add("tag", 0.20)
    timers_0.add("tag", 0.15)
    print("\ntimers_0.max('tag') = " + str(timers_0.max("tag"))) 

test_case_0()
test_Timers_max()

# Generated at 2022-06-25 15:18:11.790014
# Unit test for method mean of class Timers
def test_Timers_mean():
    for i in range(100):
        timers_0 = Timers()
        passed = True
        try:
            timers_0.mean('name')
        except KeyError:
            passed = False
        assert passed


# Generated at 2022-06-25 15:18:22.803623
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0[''] = 1
    assert math.isclose(timers_0.min(''), 1, rel_tol=1e-06)


# Generated at 2022-06-25 15:18:29.100792
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("mq3fW8J2md", 0.0548)
    timers_0.add("mq3fW8J2md", 0.0548)
    timers_0.add("mq3fW8J2md", 0.0548)
    timers_0.add("mq3fW8J2md", 0.0548)
    timers_0.add("mq3fW8J2md", 0.0548)
    timers_0.add("mq3fW8J2md", 0.0548)
    timers_0.add("mq3fW8J2md", 0.0548)
    timers_0.add("mq3fW8J2md", 0.0548)
    timers_0.add

# Generated at 2022-06-25 15:18:32.731163
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert float == type(timers_0.min("min"))
    timers_0.add("min", 1.0)
    assert 1.0 == timers_0.min("min")


# Generated at 2022-06-25 15:18:34.491300
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('name', 1)
    timers_0.min('name')


# Generated at 2022-06-25 15:18:44.095969
# Unit test for method min of class Timers
def test_Timers_min():
    # Create instance of Timers
    timers_0 = Timers()
    # Initialize variable name
    name = ""
    # Store instance of method Timers.min in method_var_0
    method_var_0 = timers_0.min
    # Store result of method method_var_0 in result_var_0
    result_var_0 = method_var_0(name)
    # Test if result_var_0 is equal to 0
    assert result_var_0 == 0
    # Call method add of Timers for class instance timers_0 and arguments "timer_0", 1
    timers_0.add("timer_0", 1)
    # Store instance of method Timers.min in method_var_0
    method_var_0 = timers_0.min
    # Store result of method method_var_0 in result_var

# Generated at 2022-06-25 15:18:52.589747
# Unit test for method median of class Timers
def test_Timers_median():
    times = Timers()

    times.add("foo", 10)
    times.add("foo", 20)
    times.add("foo", 30)
    times.add("bar", 10)
    times.add("bar", 10)
    times.add("bar", 20)

    assert times["foo"] == 60
    
    assert times.median("foo") == 20
    assert times.median("bar") == 12.5
    assert times.median("baz") == 0



# Generated at 2022-06-25 15:18:57.507287
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()

# Generated at 2022-06-25 15:19:03.956263
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("name_0", -0.10446624170122998)
    timers.add("name_0", 0.08174699702732072)
    timers.add("name_0", 0.2110915087559517)
    timers.add("name_0", 0.30673946416932275)
    timers.add("name_0", 0.4457993766727509)
    timers.add("name_0", 0.5668362132860337)
    timers.add("name_0", 0.6701960517673703)
    timers.add("name_0", 0.7883391545226175)
    timers.add("name_0", 0.8987776133829921)

# Generated at 2022-06-25 15:19:07.615224
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('name', 0.0)
    timers_1 = Timers()
    timers_1.add('name', 1.0)
    assert Timers.max(timers_1, 'name') == 1.0
    

# Generated at 2022-06-25 15:19:17.191348
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("abc", 2.8)
    timers_0.add("abc", 3.8)
    timers_0.add("abc", 8.2)
    timers_0.add("abc", 6.6)
    timers_0.add("abc", 5.4)
    timers_0.add("abc", 7.6)
    timers_0.add("abc", 7.3)
    timers_0.add("abc", 1.6)
    timers_0.add("abc", 1.8)
    timers_0.add("abc", 0.8)
    timers_0.add("abc", 8.1)
    timers_0.add("abc", 6.7)
    timers_0.add("abc", 5.5)

# Generated at 2022-06-25 15:19:30.378768
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('0', -0.036324)
    timers_0.add('0', 0.026154)
    timers_0.add('0', 0.037863)
    timers_0.add('0', 0.006978)
    timers_0.add('0', 0.0439)
    timers_0.add('0', 0.00767)
    timers_0.add('0', 0.041574)
    timers_0.add('0', 0.006768)
    timers_1 = timers_0.min('0')
    assert timers_1 == -0.036324


# Generated at 2022-06-25 15:19:36.307532
# Unit test for method min of class Timers
def test_Timers_min():
    """Test method min of class Timers"""
    timers_0 = Timers()
    name = ""

    # Call the method on an empty structure
    result = timers_0.min(name=name)
    assert result == 0

    # Add some timing values
    timers_0.add(name, value=1)
    timers_0.add(name, value=3)
    timers_0.add(name, value=5)
    timers_0.add(name, value=5)

    # Call the method and verify the result
    result = timers_0.min(name=name)
    assert result == 1



# Generated at 2022-06-25 15:19:45.394997
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('add', 0.065)
    timers_0.add('add', 0.069)
    timers_0.add('add', 0.075)
    assert timers_0.median('add') == 0.069
    timers_0.add('add', 0.063)
    assert timers_0.median('add') == 0.067
    timers_0.add('add', 0.071)
    assert timers_0.median('add') == 0.07


# Generated at 2022-06-25 15:19:52.566421
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add(name='name', value=1)
    timers_1.add(name='name', value=2)
    timers_1.add(name='name', value=3)
    timers_1.add(name='name', value=4)
    timers_1.add(name='name', value=5)
    res = timers_1.mean(name='name')
    assert res == 3


# Generated at 2022-06-25 15:19:54.152588
# Unit test for method max of class Timers
def test_Timers_max():
    use_case_0 = Timers()
    assert use_case_0.max('hourly_entries') == 0

# Generated at 2022-06-25 15:19:56.096831
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    assert_equal(timers_1.mean("34h8s"), 0)


# Generated at 2022-06-25 15:20:02.480122
# Unit test for method max of class Timers
def test_Timers_max():
    import pytest
    with pytest.raises(KeyError):
        timers_1 = Timers()
        timers_1.max('name')
    with pytest.raises(KeyError):
        timers_2 = Timers()
        timers_2.add('name', 0.01)
        timers_2.max('name_2')
    timers_3 = Timers()
    timers_3.add('name_3', 0.01)
    timers_3.add('name_3', 0.04)
    timers_3.add('name_3', 0.01)
    timers_3.add('name_3', 0.01)
    assert timers_3.max('name_3') == 0.04


# Generated at 2022-06-25 15:20:08.614616
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    # Test Timers.min with value error
    try:
        timers_0.min(name='name_0')
    except KeyError as e:
        assert type(e) == KeyError
    # Test Timers.min with index error
    try:
        assert timers_0.min(name='name_2') == 0
    except KeyError as e:
        assert type(e) == KeyError


# Generated at 2022-06-25 15:20:16.696963
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_1 = Timers()
    timers_1.data = {'zSq':0.0,'z1':0.0,'z2':0.0,'z3':0.0,'z4':0.0,'z5':0.0}
    timers_0.data = {'zSq':0.0,'z1':0.0,'z2':0.0,'z3':0.0,'z4':0.0,'z5':0.0}
    timers_0._timings.update({'zSq':[]})
    timers_0._timings.update({'z1':[]})
    timers_0._timings.update({'z2':[]})
    timers_1._timings.update({'zSq':[0.0]})
   

# Generated at 2022-06-25 15:20:19.322585
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("key_0", 3.2)
    timers_0.add("key_0", 2.5)
    timers_0.apply(statistics.median, "key_0")


# Generated at 2022-06-25 15:20:44.577419
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('test_name', 1000)
    timers_0.add('test_name', 2000)
    timers_0.add('test_name', 3000)
    timers_0.mean('test_name')

# Generated at 2022-06-25 15:20:52.241094
# Unit test for method max of class Timers
def test_Timers_max():

    # Case 1
    timers_1 = Timers()
    timers_1.add('a', 1.0)
    timers_1.add('a', 2.0)

    assert timers_1.max('a') == 2.0

    # Case 2
    timers_2 = Timers()
    timers_2.add('a', 1.0)
    timers_2.add('a', 2.0)

    assert timers_2.max('a') == 2.0

    # Case 3
    timers_3 = Timers()

    try:
        timers_3.max('a')
        #assert False
    except KeyError:
        pass



# Generated at 2022-06-25 15:20:55.787756
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("lifetime", 5.0)
    timers_0.add("lifetime", 5.0)
    timers_0.add("lifetime", 4.9)
    timers_0.add("lifetime", 5.0)
    assert timers_0.median("lifetime") == 5.0
    timers_0.add("lifetime", 4.9)
    assert timers_0.median("lifetime") == 5.0


# Generated at 2022-06-25 15:21:04.092889
# Unit test for method min of class Timers
def test_Timers_min():
    def test_0():
        timers_0 = Timers()
        timers_0.add('group_0', 0.07822236865170046)
        timers_0.add('group_0', 0.09333004736464147)
        timers_0.add('group_0', 0.10717969781402536)
        timer_min_0: float = timers_0.min('group_0')
        assert timer_min_0 == 0.07822236865170046, "min() function gives wrong results"

    def test_1():
        timers_0 = Timers()
        timers_0.add('group_0', 0.07822236865170046)
        timers_0.add('group_0', 0.09333004736464147)
        timers_0

# Generated at 2022-06-25 15:21:08.700599
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("name", 1.0)
    timers_0.add("name", 2.0)
    timers_0.add("name", 3.0)
    timers_0.add("name", 4.0)
    timers_0.add("name", 5.0)
    assert timers_0.max("name") == 5.0, "max() method is wrong!"
    assert timers_0.mean("name") == 3.0, "mean() method is wrong!"


# Generated at 2022-06-25 15:21:21.563065
# Unit test for method max of class Timers
def test_Timers_max():
    # Create a Timers object
    timers_1 = Timers()

    # Assert that the max of the timers_1 is an error
    assert isinstance(
        timers_1.max('Unknown timer'), KeyError
    ), 'Error: expected timers_1.max(\'Unknown timer\') to be an error'

    # Add the value 1.0 to the timer 'timer_1'
    timers_1.add('timer_1', 1.0)

    # Assert that the max of the timers_1 is 1.0

# Generated at 2022-06-25 15:21:28.120480
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("foo", 1)
    timers_0.add("foo", 1)
    timers_0.add("foo", 1)
    timers_0.add("foo", 1)
    timers_0.add("foo", 1)
    timers_0.add("foo", 1)
    assert timers_0.mean("foo") == 1.0


# Generated at 2022-06-25 15:21:31.107140
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.max('max') == 0, 'Test failed'
    return


test_case_0()
test_Timers_max()

# Generated at 2022-06-25 15:21:41.243998
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add(name='lookup', value=0.0)
    timers_0.add(name='get', value=0.0)
    timers_0.add(name='get', value=0.0)
    timers_0.add(name='apply_func', value=0.0)
    timers_0.add(name='apply_func', value=0.0)
    timers_0.add(name='apply_func', value=0.0)
    timers_0.add(name='apply_func', value=0.0)
    timers_0.add(name='apply_func', value=0.0)
    timers_0.add(name='apply_func', value=0.0)