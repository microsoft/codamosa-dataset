

# Generated at 2022-06-25 15:11:38.368753
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert timers_0.min(name="name_0") == 0.0


# Generated at 2022-06-25 15:11:41.232463
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    expected_value = 0.0
    actual_value = timers_0.min("")
    assert actual_value == expected_value


# Generated at 2022-06-25 15:11:44.433286
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1.add("key_1", 0.0)
    timers_1.add("key_1", 1.0)
    assert timers_1.min("key_1") == 0.0
    assert timers_1.min("key_2") == 0.0


# Generated at 2022-06-25 15:11:54.524631
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('0', 11.0)
    timers_0.add('0', 6.0)
    timers_0.add('0', 5.0)
    timers_0.add('1', 9.0)
    timers_0.add('1', 8.0)
    timers_0.add('0', 8.0)
    timers_0.add('1', 11.0)
    timers_0.add('1', 7.0)
    timers_0.add('1', 8.0)
    timers_0.add('0', 6.0)
    timers_0.add('1', 10.0)
    timers_0.add('1', 7.0)
    timers_0.add('1', 10.0)

# Generated at 2022-06-25 15:11:56.823576
# Unit test for method median of class Timers
def test_Timers_median():
    # Set-Up:
    timers = Timers()
    timers.add('Timer1', 10.)
    timers.add('Timer2', 20.)
    timers.add('Timer2', 30.)
    timers.add('Timer1', 40.)
    # Act:
    median = timers.median('Timer1')
    # Assert:
    assert median == 25



# Generated at 2022-06-25 15:11:58.923426
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('name', 2.5)
    timers_1 = Timers()
    timers_1.add('name', 0.0)
    assert timers_0.max('name') == 2.5
    assert timers_1.max('name') == 0.0


# Generated at 2022-06-25 15:12:03.474812
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_1 = Timers()
    timers_0.add("key_0", 0.1)
    timers_0.add("key_0", 0.0)
    timers_0.add("key_0", 1.0)
    timers_1.add("key_1", 0.1)
    timers_1.add("key_1", 0.0)
    timers_1.add("key_1", 1.0)
    assert timers_1.min("key_1") == 0.0


# Generated at 2022-06-25 15:12:05.540344
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    try:
        timers_0.mean('name')
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-25 15:12:08.182497
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.data['timers.median'] = 0.0
    timers_0._timings['timers.median'] = []
    assert timers_0.median('timers.median') == 0.0



# Generated at 2022-06-25 15:12:09.602327
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    t0 = timers_0.max('foo')
    assert t0 == 0.0


# Generated at 2022-06-25 15:12:20.695332
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test method Timers.mean()"""
    timers_1 = Timers()
    timers_1.add('foo', 0.01)
    timers_1.add('foo', 0.02)
    timers_1.add('foo', 0.03)
    timers_1.add('foo', 0.04)
    timers_1.add('bar', 0.05)
    timers_1.add('bar', 0.06)
    timers_1.add('bar', 0.07)
    timers_1.add('bar', 0.08)
    assert timers_1.mean('foo') == 0.0250
    assert timers_1.mean('bar') == 0.0625

# Generated at 2022-06-25 15:12:26.837088
# Unit test for method median of class Timers
def test_Timers_median():
    import pytest
    # Setup
    timers_0 = Timers()
    timers_0.add("y", 2.2250738585072014e-308)
    # Exercise
    mean_0 = timers_0.mean("y")

    # Verify
    assert mean_0 == 2.2250738585072014e-308

    # Setup
    timers_1 = Timers()
    # Exercise
    mean_1 = timers_1.mean("d")

    # Verify
    assert mean_1 == 0


# Generated at 2022-06-25 15:12:33.267542
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()

    # Strategies for max
    ones_1_5 = [1, 1, 1, 1, 1, 1]
    bools_0_5 = [True, False, False, False, True]
    ints_0_5 = [0, 0, 0, 0, 0]
    ints_1_5 = [1, 1, 1, 1, 1]
    floats_0_5 = [0.0, 0.0, 0.0, 0.0, 0.0]
    floats_1_5 = [1.0, 1.0, 1.0, 1.0, 1.0]

    # Precondition for Timers
    timers_0 = Timers()

    # Test for method max of class Timers

# Generated at 2022-06-25 15:12:35.247436
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name_1 = ''
    assert timers_0.max(name=name_1) == 0


# Generated at 2022-06-25 15:12:38.835109
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    name_0 = 'test_case_0'
    timers_1.add(name_0, 0.0)
    assert timers_1.min(name_0) == 0.0

# Generated at 2022-06-25 15:12:39.925419
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.max('a') == 0


# Generated at 2022-06-25 15:12:41.460293
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    result = timers.max("max")
    assert result == 0


# Generated at 2022-06-25 15:12:42.799508
# Unit test for method median of class Timers
def test_Timers_median():
    Timers()
    assert False


# Generated at 2022-06-25 15:12:44.905844
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.apply(lambda values: statistics.median(values or [0]), name="name_2")


# Generated at 2022-06-25 15:12:48.851440
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.add('foo', 10)
    timers_1.add('foo', 5)
    timers_1.add('foo', 20)
    timers_1.add('bar', 42)
    assert timers_1.median('foo') == 10
    assert timers_1.median('bar') == 42


# Generated at 2022-06-25 15:12:54.705405
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("rm", 0.12)
    timers_0.add("rm", 0.06)
    timers_0.add("jk", 0.03)
    timers_0.add("jk", 0.04)
    timers_0.add("jk", 0.05)
    assert timers_0.min("jk") == 0.03
    assert timers_0.min("rm") == 0.06

# Generated at 2022-06-25 15:12:58.888027
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name = "hello"
    expected_value = 1.0
    timers_0.add(name, expected_value)
    actual_value = timers_0.mean(name)
    assert actual_value == expected_value


# Generated at 2022-06-25 15:13:04.565173
# Unit test for method max of class Timers
def test_Timers_max():
    # Tests timer presence
    timers_0 = Timers()
    timers_0.add('mytimer', 0)
    result = timers_0.max('mytimer')
    assert result == 0
    # Tests timer absence
    timers_1 = Timers()
    with pytest.raises(KeyError):
        timers_1.max('nontimer')


# Generated at 2022-06-25 15:13:14.337432
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    # Test for method median of class Timers
    timers_2 = Timers()
    timers_2.add("default", 2)
    timers_2.add("default", 3)
    timers_2.add("default", 4)
    assert timers_2.median("default") == 3
    timers_3 = Timers()
    timers_3.add("default", 1)
    timers_3.add("default", 2)
    assert timers_3.median("default") == 1.5
    timers_4 = Timers()
    timers_4.add("default", 2)
    timers_4.add("default", 2)
    timers_4.add("default", 2)
    assert timers_4.median("default") == 2
    timers_5 = Timers()
    timers_

# Generated at 2022-06-25 15:13:18.119774
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("add", 0)
    timers_0.add("add", 0)
    timers_0.add("add", 0)
    timers_0.add("add", 0)
    timers_0.add("add", 0)
    assert timers_0.median("add") == 0
    assert timers_0.median("add") == 0



# Generated at 2022-06-25 15:13:29.590468
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    value_1 = 1.5
    timers_1.add("a", value_1)
    value_2 = 0.4
    timers_1.add("b", value_2)
    result_1 = timers_1.median("a")
    expected_1 = 1.5
    assert result_1 == expected_1
    result_2 = timers_1.median("b")
    expected_2 = 0.4
    assert result_2 == expected_2
    value_3 = 1.0
    timers_1.add("a", value_3)
    result_3 = timers_1.median("a")
    expected_3 = 1.25
    assert result_3 == expected_3


# Generated at 2022-06-25 15:13:37.722566
# Unit test for method min of class Timers
def test_Timers_min():
    """Unit test for method min of class Timers"""

    timers_0 = Timers()
    name_0 = 'some-name'
    timers_0.add(name_0, 0.0)
    timers_0.add(name_0, 0.0)
    timers_0.add(name_0, 0.0)
    timers_0.add(name_0, 0.0)
    assert timers_0.min(name=name_0) == 0.0



# Generated at 2022-06-25 15:13:42.510297
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name = 'string'
    value = 8
    counters = [7, 3, 2, 6, 2, 1, 2, 0, 2, 1]
    for i in counters:
        timers_0.add(name, value)
    min_value = timers_0.min(name)
    assert min_value == min(counters)


# Generated at 2022-06-25 15:13:47.308021
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers({'a': 1, 'b': 2, 'c': 3})
    assert timers_1.mean('a') == 1
    assert timers_1.mean('b') == 2
    assert timers_1.mean('c') == 3
    timers_1.add('a', 1)
    timers_1.add('b', 2)
    timers_1.add('c', 3)
    assert timers_1.mean('a') == 1
    assert timers_1.mean('b') == 2
    assert timers_1.mean('c') == 3


# Generated at 2022-06-25 15:13:51.905802
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.max("Elapsed") == 0
    timers_0 = Timers()
    timers_0.add("Elapsed", 1.0)
    assert timers_0.max("Elapsed") == 1.0



# Generated at 2022-06-25 15:13:58.360469
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
# Check type of argument value (float)
    assert isinstance(0, float)
# 'Timers' object has no attribute '_timings'
    assert timers_0.min('key_1') == 0


# Generated at 2022-06-25 15:14:01.667753
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    key = "key"
    assert math.isnan(timers_0.min(key))



# Generated at 2022-06-25 15:14:02.837121
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.max(str()) == 0


# Generated at 2022-06-25 15:14:11.241358
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("timer_1", 4.9E-324)
    assert abs(timers_0.max("<unknown>") - 0.0) < REL_TOL, \
        f"{timers_0.max('<unknown>')} != 0.0"
    timers_0 = Timers()
    assert abs(timers_0.max("timer_1") - 0.0) < REL_TOL, \
        f"{timers_0.max('timer_1')} != 0.0"
    assert abs(timers_0.max("timer_2") - 0.0) < REL_TOL, \
        f"{timers_0.max('timer_2')} != 0.0"

# Generated at 2022-06-25 15:14:15.966692
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    value_0 = 1.0
    timers_0.add('key', value_0)
    name_0 = 'key'
    value_1 = timers_0.max(name_0)

    assert(value_0 == value_1)



# Generated at 2022-06-25 15:14:22.317391
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('b', 0.99)
    timers_0.add('b', 1.37)
    timers_0.add('b', 0.26)
    timers_0.add('b', 5.08)
    timers_0.add('b', 0.56)
    timers_0.add('b', 2.08)
    timers_0.add('b', 1.14)
    timers_0.add('b', 1.29)
    assert 0.99 == timers_0.median('b')
    timers_0.add('b', 1.47)
    assert 1.29 == timers_0.median('b')


# Generated at 2022-06-25 15:14:25.679040
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name_0 = "timer"
    timers_0.add(name_0, 0.0125)
    value_0 = timers_0.min(name_0)


# Generated at 2022-06-25 15:14:36.199252
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_1 = Timers()
    timers_1.add("test_timer_0", 0.0)
    timers_1.add("test_timer_0", 0.0)
    timers_2 = Timers()
    timers_2.add("test_timer_0", 0.0)
    timers_2.add("test_timer_0", 0.0)
    timers_3 = Timers()
    timers_3.add("test_timer_0", 0.0)
    timers_3.add("test_timer_0", 0.0)
    timers_4 = Timers()
    timers_4.add("test_timer_0", 0.0)
    timers_4.add("test_timer_0", 0.0)
    timers_5 = Timers()
   

# Generated at 2022-06-25 15:14:38.909388
# Unit test for method mean of class Timers
def test_Timers_mean():
    items = [('banana', 0.83), ('apple', 1.22)]
    timers = Timers(items)
    result = timers.mean('banana')
    assert result == 0.83
    result = timers.mean('apple')
    assert result == 1.22


# Generated at 2022-06-25 15:14:42.116255
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('', 0.0)
    assert timers_0.median('') == 0.0


# Generated at 2022-06-25 15:14:54.251149
# Unit test for method mean of class Timers
def test_Timers_mean():

    timers_0 = Timers()
    value_0 = timers_0.mean("yVXdWp")
    assert value_0 == 0.0

    value_1 = timers_0.mean("yVXdWp")
    assert value_1 == 0.0

    value_2 = timers_0.mean("yVXdWp")
    assert value_2 == 0.0

    timers_0.add("yVXdWp", -0.54463)

    timers_0.add("yVXdWp", -0.54463)

    timers_0.add("yVXdWp", -0.54463)

    value_3 = timers_0.mean("yVXdWp")
    assert value_3 == -0.54463


# Generated at 2022-06-25 15:14:56.867123
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
# # #     string_0 = timers_0.median('timers')
# # #     assert string_0.equals(0)


# Generated at 2022-06-25 15:15:01.495786
# Unit test for method min of class Timers
def test_Timers_min():
    assert timers_0.min("a") == 0
    timers_1 = Timers({"a": 1, "b": 2, "c": 3})
    assert timers_1.min("a") == 1
    assert timers_1.min("b") == 2
    assert timers_1.min("c") == 3
    assert timers_0.min("a") == 0


# Generated at 2022-06-25 15:15:05.322725
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name_0 = "main"
    value_0 = 0.0
    timers_0.add(name_0, value_0)
    name_1 = "main"
    value_1 = 0.0
    timers_0.add(name_1, value_1)
    max_0 = timers_0.max("main")


# Generated at 2022-06-25 15:15:07.856245
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name = "name"
    timers_0.apply(lambda values: statistics.mean(values or [0]), name)


# Generated at 2022-06-25 15:15:10.228541
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = 'name'
    timers_0.mean(name=name_0)



# Generated at 2022-06-25 15:15:18.157387
# Unit test for method max of class Timers
def test_Timers_max():
    try:
        timers_0 = Timers()
        key = "key"
        timers_0.add(key, 0.0)
        timers_0.apply(lambda value: value, key)
        timers_0.count(key)
        timers_0.total(key)
        timers_0.min(key)
        result = timers_0.max(key)
        assert result == 0.0
    except:
        print(key)
        raise

if __name__ == '__main__':
    test_case_0()
    test_Timers_max()

# Generated at 2022-06-25 15:15:24.702713
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("timer_0", 1.0)
    timers_0.add("timer_0", 2.0)
    timers_0.add("timer_0", 3.0)
    assert timers_0.mean("timer_0") == 2.0
    timers_0.add("timer_1", 7.0)
    timers_0.add("timer_1", 7.0)
    timers_0.add("timer_1", 7.0)
    assert timers_0.mean("timer_1") == 7.0


# Generated at 2022-06-25 15:15:29.191528
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("a", 1)
    timers_0.add("a", 2)
    timers_0.add("a", 3)
    timers_0.add("a", 4)
    assert timers_0.median("a") == 2.5


# Generated at 2022-06-25 15:15:32.496356
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('test_name_1', 1.0)
    assert timers_0.max('test_name_1') == 1.0


# Generated at 2022-06-25 15:15:43.672817
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add('one', 0.5)
    timers_1.add('one', 0.6)
    timers_1.add('one', 0.7)
    timers_1.add('two', 0.7)
    timers_1.add('two', 0.8)
    timers_1.add('two', 3.2)
    assert (type(timers_1.mean('one')) is float)
    assert (timers_1.mean('one') == 0.6)
    assert (type(timers_1.mean('two')) is float)
    assert (timers_1.mean('two') == 1.6)

# Generated at 2022-06-25 15:15:50.900564
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.median('i=')
    value_0 = timers_0.total('i=')
    value_1 = timers_0.count('i=')
    timers_0.median('i=')
    value_2 = timers_0.max('i=')
    value_3 = timers_0.mean('i=')
    value_4 = timers_0.min('i=')
    value_5 = timers_0.stdev('i=')
    value_6 = timers_0.median('i=')

# Generated at 2022-06-25 15:15:55.560588
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("c", 1.664)
    timers_0.add("c", 1.086)
    timers_0.add("c", 1.098)
    timers_0.add("c", 1.098)

    assert timers_0.min("c") == 1.086


# Generated at 2022-06-25 15:16:00.189862
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert math.isnan(timers_0.mean("mean_42307"))
    timers_0.add("mean_42307", 0.915)
    assert timers_0.mean("mean_42307") == 0.915
    # Test with an empty value
    timers_0.add("mean_42307", math.nan)
    assert timers_0.mean("mean_42307") == 0.915


# Generated at 2022-06-25 15:16:02.006812
# Unit test for method min of class Timers
def test_Timers_min():
    Timers_0 = Timers()
    _Test_0 = Timers_0.min('_Test_0')


# Generated at 2022-06-25 15:16:05.394538
# Unit test for method max of class Timers
def test_Timers_max():

    timers_0 = Timers()
    timers_0.add('max_test', 0.62)

    max_test = timers_0.max('max_test')
    assert max_test == 0.62



# Generated at 2022-06-25 15:16:10.263433
# Unit test for method median of class Timers
def test_Timers_median():
    import random
    import statistics

    timers = Timers()

    # Fill timers with random data
    for name in ['timer_a', 'timer_b']:
        for i in range(random.randint(5, 10)):
            timers.add(name, random.random())

    # Calculate median
    for name in ['timer_a', 'timer_b']:
        median = statistics.median(timers._timings[name])
        assert timers.median(name) == median



# Generated at 2022-06-25 15:16:17.581037
# Unit test for method median of class Timers
def test_Timers_median():
    test_data = [
        ((1.1, 2.2, 3.3, 4.4, 5.5, 6.6, 7.7, 8.8, 9.9), 5.5),
        ((9.9, 8.8, 7.7, 6.6, 5.5, 4.4, 3.3, 2.2, 1.1), 5.5),
        ((1.1, 1.1, 1.1, 1.1, 1.1, 1.1, 1.1, 1.1, 1.1), 1.1),
        ((), 0),
    ]
    for values, expect in test_data:
        actual = statistics.median(values)
        assert actual == expect



# Generated at 2022-06-25 15:16:20.164153
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('test_name', 1)
    assert timers_0.max('test_name') == 1


# Generated at 2022-06-25 15:16:23.566800
# Unit test for method min of class Timers
def test_Timers_min():
    # Setup
    timers_0 = Timers()
    # AssertionError because 'name' not in self._timings
    # Statement(s)
    # Expression(s)
    with pytest.raises(AssertionError):
        timers_0.min("name")


# Generated at 2022-06-25 15:16:32.063321
# Unit test for method median of class Timers
def test_Timers_median():

    # Setup
    timers_1 = Timers()

    # Test
    try:
        result_1 = timers_1.median("not a real timer")

    # Assert
    except KeyError:
        pass
    else:
        raise AssertionError("Did not raise KeyError")


# Generated at 2022-06-25 15:16:39.132359
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.data[1] = 1
    timers_0.data[0] = 1
    timers_0.data[2] = 1
    AccessDenied = False
    try:
        timers_0.min(3)
    except KeyError:
        AccessDenied = True
    assert AccessDenied == True


# Generated at 2022-06-25 15:16:45.665452
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add(name="timer_0", value=1.1)
    assert timers_0.min(name="timer_0") == 1.1
    timers_0.clear()
    timers_0.add(name="timer_0", value=0.0)
    assert timers_0.min(name="timer_0") == 0.0
    timers_0.add(name="timer_0", value=1.0)
    assert timers_0.min(name="timer_0") == 0.0
    timers_0.clear()
    timers_0.add(name="timer_0", value=1.1)
    timers_0.add(name="timer_0", value=1.0)
    assert timers_0.min(name="timer_0") == 1.

# Generated at 2022-06-25 15:16:47.245748
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert isinstance(timers_0.mean('name'), float)


# Generated at 2022-06-25 15:16:50.085144
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    str_0 = ""
    assert timers_0.max(str_0) == 0, "Failed to max an empty named timer"



# Generated at 2022-06-25 15:16:53.043726
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    try:
        timers_0.max("timers_0")
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-25 15:16:56.443127
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.data["name"] = 0.0
    timers_0._timings["name"] = [0.0, 0.0]

    # Invoke method
    result = timers_0.mean("name")

    assert result == 0.0



# Generated at 2022-06-25 15:17:02.991683
# Unit test for method median of class Timers
def test_Timers_median():
    import random
    import statistics
    t = Timers()
    m = statistics.MedianCalculator()
    t0 = random.random()
    while m.add(t0 * t0) < 1000:
        t0 = random.random()
    t.add("timer_01", t0)
    median_0 = t.median("timer_01")
    assert median_0 == m.result()


# Generated at 2022-06-25 15:17:04.515878
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1.add('function_0', 0.9635572321697585)
    timers_1.min('function_0')


# Generated at 2022-06-25 15:17:13.286035
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("", -1.0)
    timers_0.add("", 0.0)
    timers_0.add("", -1.0)
    timers_0.add("", -1.0)
    timers_0.add("", -1.0)
    timers_0.add("", 0.0)
    timers_0.add("", 1.0)
    timers_0.add("", 1.0)
    timers_0.add("", -1.0)
    timers_0.add("", 0.0)
    timers_0.add("", 0.0)
    timers_0.add("", 0.0)
    timers_0.add("", -1.0)
    timers_0.add("", -1.0)
   

# Generated at 2022-06-25 15:17:26.341806
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('memcached', 0.015)
    timers_0.add('mysql', 0.001)
    timers_0.add('memcached', 0.015)
    timers_0.add('memcached', 0.015)
    timers_0.add('mysql', 0.001)
    timers_0.add('memcached', 0.015)
    timers_0.add('memcached', 0.015)
    timers_0.add('memcached', 0.015)
    timers_0.add('mysql', 0.001)
    timers_0.add('memcached', 0.015)
    timers_0.add('memcached', 0.015)
    timers_0.add('memcached', 0.015)
   

# Generated at 2022-06-25 15:17:29.236644
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert timers_0.min("default") == 0


# Generated at 2022-06-25 15:17:30.815932
# Unit test for method mean of class Timers
def test_Timers_mean():
    for _ in range(0, number_of_tests):

        value = 0.0

        # Test for type
        assert isinstance(value, float)

        return


# Generated at 2022-06-25 15:17:33.710825
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()

# Generated at 2022-06-25 15:17:39.821403
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_1 = Timers()
    timers_1.add('a', 5)
    timers_1.add('a', 2)
    timers_0.add('b', 5)
    timers_0.add('b', 2)
    assert timers_0.mean('b') == 3.5
    assert timers_0.mean('b') == timers_1.mean('a')

# Generated at 2022-06-25 15:17:46.146295
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    
    # Call method min
    assert 0 == timers_0.min("m_pyramid_a_0")


# Generated at 2022-06-25 15:17:49.996845
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('median', 2.5)
    timers_0.add('median', 3.0)
    timers_0.add('median', 1.5)
    float_0 = timers_0.median('median')
    assert float_0 == 2.5


# Generated at 2022-06-25 15:17:51.903064
# Unit test for method median of class Timers
def test_Timers_median():

    timers = Timers()

    timers.add('foo', 3.0)
    timers.add('foo', 4.0)
    timers.add('foo', 2.0)

    assert timers.median('foo') == 3.0


# Generated at 2022-06-25 15:17:53.404967
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert(timers_0.min("My Timer") == 0)

# Generated at 2022-06-25 15:17:55.523590
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('name', value=1.0)
    assert timers.min(name='name') == 1.0



# Generated at 2022-06-25 15:18:03.757228
# Unit test for method max of class Timers
def test_Timers_max():
    nb_of_failures = 0
    timers_0 = Timers()
    try:
        timers_0.max('name')
    except KeyError:
        nb_of_failures += 1

    timers_0.add('name', 42.0)
    assert timers_0.max('name') == 42.0
    return nb_of_failures


# Generated at 2022-06-25 15:18:06.437628
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("test", 4)
    timers.add("test", 6)
    assert timers.mean("test") == 5

# Generated at 2022-06-25 15:18:16.436005
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    result = timers_0.max(name="data")
    assert type(result) == float
    assert result == 0.0

    timers_1 = Timers()
    result = timers_1.max(name="data")
    assert type(result) == float
    assert result == 0.0

    timers_2 = Timers()
    result = timers_2.max(name="data")
    assert type(result) == float
    assert result == 0.0

    timers_3 = Timers()
    timers_3.add(name="data", value=0.0)
    timers_3.add(name="data", value=0.0)
    timers_3.add(name="data", value=0.0)
    result = timers_3.max(name="data")

# Generated at 2022-06-25 15:18:24.058691
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("f9cT32Tg", 0.0781151854503812)
    timers_0.add("f9cT32Tg", 0.0006441847290166769)
    timers_0.add("f9cT32Tg", 0.0027617291579205612)
    timers_0.add("f9cT32Tg", 0.0008483746115323866)
    timers_0.add("f9cT32Tg", 0.00011327226410124606)
    assert round(timers_0.mean("f9cT32Tg"), 8) == 0.004040571759640884



# Generated at 2022-06-25 15:18:26.991497
# Unit test for method min of class Timers
def test_Timers_min():
    # Define a dictionary of values
    values = {'index': 0, 'value': float('-inf')}
    timers_1 = Timers()
    for key, val in values.items():
        timers_1.add(key, val)
    timers_1.min(key)


# Generated at 2022-06-25 15:18:37.139988
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.data["c"] = 3.0
    timers_0.data["b"] = 2.0
    timers_0.data["a"] = 1.0
    assert timers_0.max("1") == 0.0

    timers_0 = Timers()
    timers_0.data["b"] = 2.0
    timers_0.data["a"] = 1.0
    timers_0.data["c"] = 3.0
    assert timers_0.max("1") == 0.0

    timers_0 = Timers()
    timers_0.data["a"] = 1.0
    timers_0.data["c"] = 3.0
    timers_0.data["b"] = 2.0
    assert timers_0.max("1") == 0.0

   

# Generated at 2022-06-25 15:18:45.500370
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = "VfqG3qwMV7"
    assert (
        round(timers_0.mean(name=name_0), 2)
        == 0.0
    ), f"expected: 0.0, actual: {timers_0.mean(name=name_0)}"
    name_1 = "jusy1U6VLq"
    assert (
        round(timers_0.mean(name=name_1), 2)
        == 0.0
    ), f"expected: 0.0, actual: {timers_0.mean(name=name_1)}"
    name_2 = "YhK5F5QZC2"

# Generated at 2022-06-25 15:18:50.079442
# Unit test for method min of class Timers
def test_Timers_min():
    timers_ = Timers()
    name = str()
    value = float()
    timers_.add(name, value)
    timers_.min(name)



# Generated at 2022-06-25 15:18:54.096682
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    assert timers.max("a") == 0.0
    timers.add("a", 3.2)
    timers.add("a", 4.6)
    timers.add("a", 1.0)
    assert timers.max("a") == 4.6


# Generated at 2022-06-25 15:18:55.746437
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_val = timers_0.min("test_0")
    assert timers_val == 0.0


# Generated at 2022-06-25 15:19:11.864773
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers_0 = Timers()
    name = 'T_total'
    value = 1.0
    timers_0.add(name, value)
    value = 2.0
    timers_0.add(name, value)
    value = 3.0
    timers_0.add(name, value)
    assert timers_0.min(name) == 1.0
    timers_0.clear()
    value = 1.0
    timers_0.add(name, value)
    value = 0.0
    timers_0.add(name, value)
    value = 3.0
    timers_0.add(name, value)
    assert timers_0.min(name) == 0.0
    timers_0.clear()
    value = 1.0

# Generated at 2022-06-25 15:19:15.896408
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()

    assert math.isnan(timers_0.median('foo'))



# Generated at 2022-06-25 15:19:19.048601
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_1 = "test_key"
    values_1 = [10.0, 20.0, 30.0]
    timers_1 = Timers(name_1, values_1)
    assert timers_1.mean(name_1) == 20.0
    return None


# Generated at 2022-06-25 15:19:26.885459
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    d_1 = dict()
    d_1['key_0'] = d_1['key_1'] = d_1['key_2'] = d_1['key_3'] = d_1['key_4'] = float()
    d_1['key_0'] = float()
    timers_0.data = d_1
    timers_0._timings = d_1
    # Negative scenario
    try:
        timers_0.median('key_0')
    except KeyError:
        assert True
    # Positive scenario
    assert 1.0 == timers_0.median('key_1')


# Generated at 2022-06-25 15:19:28.426405
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.add(name='test', value=1000)
    assert isinstance(timers_1.median(name='test'), float)


# Generated at 2022-06-25 15:19:30.416699
# Unit test for method mean of class Timers
def test_Timers_mean():
    assert statistics.mean([3, 9, 11, 14]) == 9
    assert statistics.mean([3, 9, 11, 14, 18]) == 11


# Generated at 2022-06-25 15:19:35.283053
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("Purchased", 0.3733668)
    timers_0.add("Triggered", 0.32949965)
    timers_0.add("Purchased", 0.53197205)
    timers_0.add("Triggered", 0.35118485)
    timers_0.add("Purchased", 0.9247604)
    timers_0.add("Triggered", 0.37536703)
    timers_0.add("Purchased", 0.6286185)
    timers_0.add("Triggered", 0.3797598)
    timers_0.add("Purchased", 0.58206177)
    timers_0.add("Triggered", 0.4318882)

# Generated at 2022-06-25 15:19:43.259364
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("key", 0.026)
    timers_0.add("key", 0.005)
    timers_0.add("key", 0.004)
    timers_0.add("key", 0.002)
    timers_0.add("key", 0.003)
    timers_0.add("key", 0.003)
    timers_0.add("key", 0.003)
    assert timers_0.max("key") == 0.026


# Generated at 2022-06-25 15:19:50.270979
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = "PT"
    value_0 = 2.66714417884687
    timers_0.add(name_0, value_0)
    name_1 = "PT"
    value_1 = 3.790320798241273
    timers_0.add(name_1, value_1)
    name_2 = "PT"
    value_2 = 3.790320798241273
    timers_0.add(name_2, value_2)
    name_3 = "PT"
    value_3 = 7.113980713041033
    timers_0.add(name_3, value_3)
    name_4 = "PT"
    value_4 = 9.871475536788861

# Generated at 2022-06-25 15:19:55.896933
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("key_0", (float(0)))
    timers_0.add("key_0", (float(0)))
    assert (
        round(
            timers_0.median("key_0"), 10
        )  # Timers().median(String) -> double
        == 0.0
    )


# Generated at 2022-06-25 15:20:17.835961
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add(name='timer_0', value=3.0)
    timers_0.mean(name='timer_0')
    timers_0.add(name='timer_0', value=2.0)
    timers_0.mean(name='timer_0')
    timers_0.add(name='timer_0', value=4.0)
    timers_0.mean(name='timer_0')
    timers_0.add(name='timer_0', value=2.0)
    timers_0.mean(name='timer_0')


# Generated at 2022-06-25 15:20:22.038112
# Unit test for method median of class Timers
def test_Timers_median():
    Timers_0 = Timers()
    Timers_0.add('key0', 2.0)
    Timers_0.add('key0', 2.0)
    Timers_0.add('key0', 2.0)
    Timers_0.add('key0', 2.0)
    Timers_0.add('key0', 2.0)
    assert Timers_0.median('key0') == 2.0


# Generated at 2022-06-25 15:20:24.729203
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("test_timer", 100.0)
    timers.add("test_timer", 200.0)
    assert math.isclose(timers.max("test_timer"), 200.0)
    timers.add("test_timer", 300.0)
    assert math.isclose(timers.max("test_timer"), 300.0)


# Generated at 2022-06-25 15:20:31.551961
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("a", 2)
    timers_0.add("a", 3)
    max_1 = timers_0.max("a")
    assert max_1 == 3


# Generated at 2022-06-25 15:20:34.940046
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("timer_0", 0.04)
    timers_0.add("timer_0", 0.01)
    timers_0.add("timer_0", 0.01)

    assert round(timers_0.min("timer_0"), 2) == 0.01


# Generated at 2022-06-25 15:20:36.534086
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1.add('a', 1)
    assert timers_1.min('a') == 1


# Generated at 2022-06-25 15:20:40.222373
# Unit test for method mean of class Timers
def test_Timers_mean():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 15:20:48.379320
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name_0 = "my timer"
    assert not timers_0.max(name_0)
    timers_0.add(name_0, 0.1)
    assert timers_0.max(name_0) == 0.1
    timers_0.add(name_0, 0.2)
    assert timers_0.max(name_0) == 0.2
    timers_0.add(name_0, 0.3)
    assert timers_0.max(name_0) == 0.3


# Generated at 2022-06-25 15:20:49.611600
# Unit test for method max of class Timers
def test_Timers_max():
    assert timers_0.max("d") == 0


# Generated at 2022-06-25 15:20:52.682282
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Tests for Timers.mean"""
    timers_0 = Timers()
    timers_0.add('foo', 1.0)
    timers_0.add('foo', 2.0)
    timers_0.add('foo', 3)
    assert timers_0.mean('foo') == 2.0

# Generated at 2022-06-25 15:21:17.304362
# Unit test for method max of class Timers
def test_Timers_max():
    # Test empty Timers
    timers = Timers()
    assert timers.max(name="a") == 0  # noqa
    assert timers.max(name="b") == 0  # noqa
    assert timers.max(name="c") == 0  # noqa

    # Test single update
    timers.add(name="a", value=2)
    assert timers.max(name="a") == 2  # noqa
    timers.add(name="a", value=1)
    assert timers.max(name="a") == 2  # noqa
    timers.add(name="b", value=4)
    assert timers.max(name="b") == 4  # noqa
    timers.add(name="b", value=3)
    assert timers.max(name="b") == 4  # noqa
    timers.add

# Generated at 2022-06-25 15:21:25.313363
# Unit test for method max of class Timers
def test_Timers_max():
    # Create an instance of class Timers for testing
    timers_0 = Timers()
    # Add the first timing value to the 'task_0' timer
    timers_0.add("task_0", 0.207819)
    # Check that the first timing value was added to the 'task_0' timer
    assert timers_0.max("task_0") == 0.207819
    assert timers_0.mean("task_0") == 0.207819


# Generated at 2022-06-25 15:21:36.287747
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("name_0", 1.0)
    timers.add("name_0", 7.0)
    timers.add("name_0", 5.0)
    timers.add("name_0", 4.0)
    timers.add("name_0", 3.0)
    timers.add("name_0", 9.0)
    timers.add("name_0", 2.0)
    timers.add("name_0", 8.0)
    timers.add("name_0", 6.0)
    timers.add("name_0", 0.0)

    # Test with no timings
    timers = Timers()
    assert math.isnan(timers.median("name_1"))

    # Test with only one timing