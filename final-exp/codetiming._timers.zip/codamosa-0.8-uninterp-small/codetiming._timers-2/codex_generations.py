

# Generated at 2022-06-25 15:11:44.492391
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    key_0 = "test_3"
    value_0 = 0.2935576583732505
    timers_0.add(key_0, value_0)
    key_1 = "test_5"
    value_1 = 0.44597460440482286
    timers_0.add(key_1, value_1)
    key_2 = "test_1"
    value_2 = 0.0879444444444444
    timers_0.add(key_2, value_2)
    key_3 = "test_2"
    value_3 = 0.00587264150943396
    timers_0.add(key_3, value_3)
    key_4 = "test_3"
    value_4 = 0.0

# Generated at 2022-06-25 15:11:54.248451
# Unit test for method mean of class Timers
def test_Timers_mean():

    # Case 0
    timers_0 = Timers()
    timers_0.add("timer1", 0.1)
    timers_0.add("timer1", 0.2)
    assert timers_0.mean("timer1") == 0.15
    timers_0.add("timer2", 0.3)
    timers_0.add("timer2", 0.4)
    assert timers_0.mean("timer2") == 0.35
    timers_0.add("timer2", 0.5)
    assert timers_0.mean("timer2") == 0.4
    assert timers_0["timer1"] == 0.3
    assert timers_0["timer2"] == 1.2
    assert timers_0.mean("unexisting") == 0


# Generated at 2022-06-25 15:11:55.254604
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert math.isclose(timers_0.median(name="name"), 0.0)


# Generated at 2022-06-25 15:12:01.425946
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('[count]_0', 0.3)
    timers_0.add('[count]_0', 0.6)
    timers_0.add('[count]_0', 0.6)
    timers_0.add('[count]_0', 0.9)
    timers_0.add('[count]_0', 0.24)
    timers_0.add('[count]_0', 0.2)
    timers_0.add('[count]_0', 0.3)
    timers_0.add('[count]_0', 0.5)
    timers_0.add('[count]_0', 0.5)
    timers_0.add('[count]_0', 0.8)

# Generated at 2022-06-25 15:12:04.607256
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.data['name_0'] = 0.0
    name_0 = 'first_0'
    value_0 = 99.9
    timers_0.add(name_0, value_0)
    timers_0.apply(len, name_0)


# Generated at 2022-06-25 15:12:08.586038
# Unit test for method mean of class Timers
def test_Timers_mean():

    # Construct a Timers object
    timers_1 = Timers()
    timers_1.add('name', 0.0)
    timers_1.add('name', 1.0)

    # Call method mean
    try:
        timers_1.mean('name')
    except KeyError:
        raise RuntimeError(
            f"`Timers.mean` raised a KeyError for key `name`, but it should return a float"
        )


# Generated at 2022-06-25 15:12:11.925879
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('load_file', 0.04)
    timers.add('load_file', 0.05)
    timers.add('load_file', 0.06)
    timers.add('load_file', 0.07)
    timers.add('load_file', 0.08)
    timers.add('load_file', 0.09)
    assert timers.max('load_file') == 0.09


# Generated at 2022-06-25 15:12:15.595019
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("hs_2", 0.096246)
    timers_0.add("hs_6", 0.079462)
    timers_0.min("hs_2")

# Generated at 2022-06-25 15:12:25.157808
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0_0 = Timers()
    assert not hasattr(timers_0_0, "data")
    assert hasattr(timers_0_0, "_timings")
    timers_0_0.data = {}
    timers_0_0.add('it', 0.35)
    timers_0_0.add('it', 0.04)
    timers_0_0.add('it', 0.06)
    timers_0_0.add('it', 0.08)
    timers_0_0.add('it', 0.1)
    timers_0_0.add('it', 0.12)
    timers_0_0.add('it', 0.14)
    timers_0_0.add('it', 0.16)
    timers_0_0.add('it', 0.18)

# Generated at 2022-06-25 15:12:32.181145
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('total-0', 2.95878224962633)
    timers_0.add('total-2', 3.04277752776204)
    timers_0.add('total-3', 5.14663955235585)
    timers_0.add('total-1', 3.04277752776204)
    timers_0.add('total-4', 2.40754079581442)
    assert timers_0.mean('total-0') == 2.95878224962633
    assert timers_0.mean('total-2') == 3.04277752776204
    assert timers_0.mean('total-3') == 5.14663955235585
    assert timers_0.mean('total-1') == 3

# Generated at 2022-06-25 15:12:42.562007
# Unit test for method mean of class Timers
def test_Timers_mean():
    # setup
    timers_1 = Timers()
    # process
    timers_1.add("name_0", 1.1)
    timers_1.add("name_0", 2.2)
    # validate
    name_0 = "name_0"
    expected = 1.65
    actual = timers_1.mean(name_0)
    assert expected == actual, "Expected '{expected}' but got '{actual}'".format(expected=expected, actual=actual)

# Generated at 2022-06-25 15:12:44.366880
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    try:
        timers_0.max()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 15:12:48.972795
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("random", 1.5)
    timers_0.add("random", 1.5)
    timers_0.add("random", 1.5)
    # test whether max() method of Timers class works as expected

    # Check 1: max() method of Timers class should return 1.5
    assert 1.5 == timers_0.max("random")


# Generated at 2022-06-25 15:12:55.706340
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()  # type: Timers
    # Create test data
    # Timing data generated with the following commands:
    # from scipy.stats import norm
    # from timeit import timeit
    # timings = [timeit(lambda: norm.ppf(0.999), number=n) for n in range(1, 100000)]

# Generated at 2022-06-25 15:13:01.149866
# Unit test for method median of class Timers
def test_Timers_median():
    times_0 = Timers()
    assert times_0.median('test_0') == 0
    times_0.add('test_0', 1.1)
    assert times_0.median('test_0') == 1.1
    times_0.add('test_0', 1.2)
    assert times_0.median('test_0') == 1.15
    times_0.add('test_0', 2.0)
    assert times_0.median('test_0') == 1.2


# Generated at 2022-06-25 15:13:03.418796
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("1", 1)
    assert 1 == timers_0.min("1")


# Generated at 2022-06-25 15:13:07.359637
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()

    timers_0.add("Unit test for method max of class Timers", 0.0014751434326171875)
    # Assert:: 
    assert  timers_0.max("Unit test for method max of class Timers") == 0.0014751434326171875



# Generated at 2022-06-25 15:13:12.201321
# Unit test for method max of class Timers
def test_Timers_max():
    min_0 = Timers()
    min_0.add('test', 2.4036308852881848)
    min_0.add('test', 2.4036308852881848)
    min_0.add('test', 1.5826200537842932)
    min_0.add('test', 0.6312188206465137)
    min_0.add('test', 1.5826200537842932)
    min_0.add('test', 1.5826200537842932)
    min_0.add('test', 1.5826200537842932)
    min_0.add('test', 2.4036308852881848)
    min_0.add('test', 0.6312188206465137)

# Generated at 2022-06-25 15:13:15.885602
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1.add("foo", 1)
    timers_1.add("foo", 2)
    timers_1.add("bar", 3)
    timers_1.min("foo")
    timers_1.min("bar")


# Generated at 2022-06-25 15:13:22.103903
# Unit test for method mean of class Timers
def test_Timers_mean():

    # Arrange
    timers_1 = Timers()
    timers_2 = Timers()
    name_0 = str()
    # Act
    actual_value_0 = timers_1.mean(name_0)
    actual_value_1 = timers_2.mean(name_0)
    # Assert
    assert actual_value_0 == actual_value_1


# Generated at 2022-06-25 15:13:36.858819
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.data = {'asd': 85.37406250907982}
    timers_0.setdefault('asd', 85.37406250907982)
    timers_0.add('asd', -4.67371627443388)
    timers_0.add('asd', -4.67371627443388)
    timers_0.add('asd', -4.67371627443388)
    timers_0.add('asd', -4.67371627443388)
    timers_0.add('asd', -4.67371627443388)
    timers_0.add('asd', -4.67371627443388)

# Generated at 2022-06-25 15:13:40.724799
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("key_1", 1.0)
    timers_0.add("key_1", 2.5)
    timers_0.add("key_1", 1.5)
    assert timers_0.mean("key_1") == 1.75


# Generated at 2022-06-25 15:13:47.643407
# Unit test for method median of class Timers
def test_Timers_median():
    cfg_0 = Timers()
    cfg_0.add('timer_0', 1.16)
    cfg_0.add('timer_0', 0.4)
    cfg_0.add('timer_0', 1.89)
    cfg_0.add('timer_0', 0.49)
    cfg_0.add('timer_0', 1.1)
    cfg_0.add('timer_0', 0.36)
    cfg_0.add('timer_0', 0.7)
    cfg_0.add('timer_0', 0.14)
    cfg_0.add('timer_0', 0.58)
    cfg_0.add('timer_0', 0.75)
    cfg_0.add('timer_0', 0.27)
    cf

# Generated at 2022-06-25 15:13:52.160046
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.data = {'2e0': 1.0, '4e+4': 81.0}
    # Method executes without error
    assert timers_0.mean('2e0') == 1.0


# Generated at 2022-06-25 15:13:57.307844
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('test_case_0#1', 0.0)
    timers.add('test_case_0#1', 0.0)
    assert timers.min('test_case_0#1') == 0.0
    assert timers.min('test_case_0#2') == 0.0

# Generated at 2022-06-25 15:14:03.365451
# Unit test for method max of class Timers
def test_Timers_max():
    # Arrange
    timers_1: Timers = Timers()
    timers_1["key_1"] = 10
    timers_1["key_2"] = 20

    # Act
    result_1 = timers_1.max("key_1")
    result_2 = timers_1.max("key_2")

    # Assert
    assert result_1 == 10
    assert result_2 == 20



# Generated at 2022-06-25 15:14:11.636265
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_1 = Timers()
    timers_2 = Timers()
    timers_3 = Timers()
    timers_4 = Timers()
    timers_5 = Timers()
    timers_6 = Timers()
    timers_7 = Timers()
    # print(timers_7._timings.type())
    # print(timers_7._timings.type().__name__)
    # print(Timers()._timings.type())
    print(type(timers_7))
    print(type(Timers()))
    timers_0.add('name', 0.0)
    timers_1.add('name', 0.0)
    timers_2.add('name', 0.0)
    timers_3.add('name', 0.0)
    timers

# Generated at 2022-06-25 15:14:20.789084
# Unit test for method median of class Timers
def test_Timers_median():
    # Define a function for testing method median for testing
    def func_median(self):
        return self.apply(lambda values: statistics.median(values or [0]), name='timer1')
    timer1_median_0 = func_median(timers_0)
    timers_0.add('timer1', 0.26056674335766237)
    timers_0.add('timer1', 0.8457029078936399)
    timers_0.add('timer1', 0.8315224992924883)
    timers_0.add('timer1', 0.24444449393609247)
    timer1_median_1 = func_median(timers_0)
    # Verify that the test succeeded
    assert timer1_median_1 == 0.41756675

# Generated at 2022-06-25 15:14:23.892238
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers._timings = { 'a': [2, 3, 5] }
    timers.data = { 'a': 10 }
    assert timers.mean('a') == 3.3333333333333335


# Generated at 2022-06-25 15:14:27.752886
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    name = "timer_0"
    exc = None
    try:
        result = timers_0.median(name)
    except Exception as local_exc:
        exc = local_exc
    assert exc == None
    assert result == 0.0



# Generated at 2022-06-25 15:14:36.276452
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    input_0 = 'd'
    assert round(timers_0.min(input_0), 6) == 0


# Generated at 2022-06-25 15:14:39.786921
# Unit test for method max of class Timers
def test_Timers_max():
    timers_max = Timers(
        {
            "timer_max_0": 3.2694849986575695,
        }
    )

    assert timers_max.max("timer_max_0") == 3.2694849986575695



# Generated at 2022-06-25 15:14:49.294811
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timer_name_0: str = "test"
    timer_value_0: float = 2.0
    timers_0.add(timer_name_0, timer_value_0)
    timer_value_1: float = 2.0
    timers_0.add(timer_name_0, timer_value_1)
    timer_value_2: float = 2.0
    timers_0.add(timer_name_0, timer_value_2)
    try:
        timers_0.mean(timer_name_0)
    except:
        raise

# Generated at 2022-06-25 15:14:55.038877
# Unit test for method max of class Timers
def test_Timers_max():
    import random
    import time
    timers = Timers()
    for _ in range(1000):
        name = random.choice(["A", "B"])
        start = time.perf_counter()
        time.sleep(random.uniform(0, 1))
        value = time.perf_counter() - start
        timers.add(name, value)
    max_A = timers.max("A")
    assert max_A > 0.9, max_A



# Generated at 2022-06-25 15:15:02.913318
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_2 = Timers()
    timers_2.add("name_1", 1)
    timers_2.add("name_1", 2)
    assert timers_2.mean("name_1") == 1.5
    timers_2.add("name_2", 3)
    assert timers_2.mean("name_1") == 1.5
    assert timers_2.mean("name_2") == 3.0
    timers_2.add("name_2", 4)
    assert timers_2.mean("name_1") == 1.5
    assert timers_2.mean("name_2") == 3.5
    assert timers_2.mean("name_3") == 0.0


# Generated at 2022-06-25 15:15:03.794866
# Unit test for method median of class Timers
def test_Timers_median():
    assert Timers().median("x") == 0



# Generated at 2022-06-25 15:15:08.604236
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('A', 2.0)
    timers_0.add('B', 1.0)
    timers_0.add('A', 3.0)
    timers_0.add('B', 2.0)
    timers_0.add('A', 1.0)
    timers_0.add('B', 2.0)
    timers_0.add('A', 1.5)
    timers_0.add('B', 2.5)
    assert math.isclose(timers_0.min('A'), 1.0)
    assert math.isclose(timers_0.min('B'), 1.0)


# Generated at 2022-06-25 15:15:12.711176
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.data["foo"] = 1.0
    result = timers_0.min("foo")
    assert result == 1.0

    timers_0 = Timers()
    result = timers_0.min("foo")
    assert result == 0


# Generated at 2022-06-25 15:15:23.014830
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Case 1:
    # Name error
    try:
        timers_1 = Timers()
        timers_1.mean('a')
    except KeyError:
        assert True
    # Case 2:
    # Normal case
    timers_2 = Timers()
    timers_2.add('a', 1)
    timers_2.add('a', 2)
    assert timers_2.mean('a') == 1.5
    assert timers_2['a'] == 3
    # Case 3:
    # Empty list
    timers_3 = Timers()
    assert timers_3.mean('a') == 0
    # Case 4:
    # Empty list, no string input
    timers_4 = Timers()
    try:
        timers_4.mean(a)
    except NameError:
        assert True
    # Case 5

# Generated at 2022-06-25 15:15:33.347033
# Unit test for method min of class Timers
def test_Timers_min():

    timers_0 = Timers()
    timers_0.add("key_2", 0.062980019289)
    timers_0.add("key_2", 0.043006934941)
    timers_0.add("key_2", 0.062712456447)
    timers_0.add("key_2", 0.072949632062)
    timers_0.add("key_2", 0.099390136017)
    timers_0.add("key_2", 0.033086342705)
    timers_0.add("key_2", 0.037694443693)
    timers_0.add("key_2", 0.037982699406)
    timers_0.add("key_2", 0.03732065976)
    timers_0

# Generated at 2022-06-25 15:15:53.514773
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("abc", 0.25)
    timers_0.add("abc", -0.25)
    timers_0.add("abc", 0.75)
    timers_0.add("a", 0.0001)
    assert timers_0.data == {"abc": 1.25, "a": 0.0001}
    assert timers_0.max("abc") == 0.75
    assert timers_0.max("a") == 0.0001
    assert timers_0.max("b") == 0.0
    try:
        timers_0.max("abc")
    except KeyError:
        pass




# Generated at 2022-06-25 15:15:56.031552
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    result_0 = timers_0.min(name="name_7")
    print(result_0)



# Generated at 2022-06-25 15:15:58.306123
# Unit test for method max of class Timers
def test_Timers_max():
    assert timers.max('add') == 0.0
    assert timers.max('clear') == 0.0
    assert timers.max('data') == 0.0


# Generated at 2022-06-25 15:16:06.166280
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    value_0 = timers_0.median("timer-1")
    value_1 = timers_0.median("timer-2")
    assert math.isnan(value_0)
    assert math.isnan(value_1)
    timers_1 = Timers()
    timers_1.add("timer-3", 784.1335499000001)
    timers_1.add("timer-3", 51.734312000000014)
    value_2 = timers_1.median("timer-3")
    value_3 = timers_1.median("timer-4")
    assert math.isclose(value_2, 51.734312000000014)
    assert math.isnan(value_3)


# Generated at 2022-06-25 15:16:10.141373
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("case_0", 1.0)
    timers.add("case_0", 3.0)
    timers.add("case_0", 5.0)
    timers.add("case_0", 7.0)
    timers.add("case_0", 9.0)
    assert timers.mean("case_0") == 5.0


# Generated at 2022-06-25 15:16:13.299096
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("test", 1.0)
    timers_0.add("test", 2.0)
    timers_0.add("test", 3.0)
    assert timers_0.min("test") == 1.0


# Generated at 2022-06-25 15:16:25.101073
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    try:
        timers.median('__missing__')
        assert False
    except KeyError:
        assert True
    timers.add('__missing__', 1.0)
    timers.add('__missing__', 2.0)
    timers.add('__missing__', 3.0)
    timers.add('__missing__', 4.0)
    assert timers.median('__missing__') == 2.5
    timers.add('__missing__', 3.2)
    assert timers.median('__missing__') == 3.0
    assert timers.median('__missing__') == 3.0


# Generated at 2022-06-25 15:16:28.990025
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add(str_arg_0, float_arg_0)
    timers_0.add(str_arg_0, float_arg_1)
    return timers_0.mean(str_arg_0)


# Generated at 2022-06-25 15:16:39.018492
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('a', 0.42)
    timers_0.add('a', 0.42)
    timers_0.add('a', 0.42)
    timers_0.add('a', 0.42)
    timers_0.add('a', 0.42)
    timers_0.add('a', 0.42)
    timers_0.add('a', 0.42)
    timers_0.add('a', 0.42)
    timers_0.add('a', 0.42)
    timers_0.add('a', 0.42)
    timers_0.add('a', 0.42)
    timers_0.add('a', 0.42)
    timers_0.add('a', 0.42)

# Generated at 2022-06-25 15:16:44.609736
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Case 1
    timers_0 = Timers()
    timers_0['a'] = 100
    timers_0.add('a', 30)
    timers_0.mean('a')
    # Case 2
    timers_0.add('b', 60)
    timers_0.add('a', 70)
    timers_0.mean('a')
    # Case 3
    timers_0.apply(len, 'a')
    timers_0.mean('a')
    # Case 4
    timers_0.mean(['a'])
    # Case 5
    timers_0.clear()
    timers_0.mean('a')


# Generated at 2022-06-25 15:17:18.265885
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.data['Y'] = 0.0
    assert timers_0.mean('Y') == 0.0
    timers_0.data['Y'] = -1.0
    assert timers_0.mean('Y') == -1.0
    timers_0.data['Y'] = 1.0
    assert timers_0.mean('Y') == 1.0
    timers_0.data['Y'] = 1.4
    assert timers_0.mean('Y') == 1.4
    timers_0.data['Y'] = 1.6
    assert timers_0.mean('Y') == 1.6
    timers_0.data['Y'] = 0.0
    assert timers_0.mean('Y') == 0.0
    timers_0.data['Y'] = -1.0

# Generated at 2022-06-25 15:17:25.192163
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()

    timers_0.add("name_0", 1)
    timers_0.add("name_1", 1)
    timers_0.add("name_2", 1)
    timers_0.add("name_0", 45)

    assert round(timers_0.mean("name_0"), 4) == 23
    assert round(timers_0.mean("name_1"), 4) == 1
    assert round(timers_0.mean("name_2"), 4) == 1
    return



# Generated at 2022-06-25 15:17:29.873095
# Unit test for method max of class Timers
def test_Timers_max():
    # Create instance of Timers
    timers_0 = Timers()

    # Try to get the max value of a timer that does not exist
    try:
        value = timers_0.max('bar')
    except KeyError:
        pass



# Generated at 2022-06-25 15:17:40.411452
# Unit test for method min of class Timers
def test_Timers_min():
    import sys
    import io
    
    class EmulatingInput:
        def __init__(self):
            self.input = None
            self.buffer = ''
        
        def __call__(self):
            if self.input is None:
                self.input = sys.stdin.readline()
                return self.input
            else:
                if self.buffer and self.buffer[-1] != '\n':
                    self.buffer += '\n'
                self.buffer += self.input
                self.input = None
        
        def __enter__(self):
            sys.stdin = self
        
        def __exit__(self, type, value, traceback):
            sys.stdin = sys.__stdin__
    
    

# Generated at 2022-06-25 15:17:45.887061
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert timers_0.mean('key') == 0, 'assert failed'


# Generated at 2022-06-25 15:17:54.271508
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add("a", 1.1)
    timers_1.add("a", 2.2)
    timers_1.add("b", 3.3)
    timers_1.add("b", 4.4)
    timers_1.add("b", 5.5)
    assert timers_1.mean("a") == 1.65
    assert timers_1.mean("b") == 4.4
    timers_2 = Timers()
    timers_2.add("a", 1.1)
    timers_2.add("b", 2.2)
    assert timers_2.mean("a") == 1.1
    assert timers_2.mean("b") == 2.2
    timers_3 = Timers()
    assert timers_3.mean("a") == 0.0

# Generated at 2022-06-25 15:17:59.394641
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    name_0 = ""
    assert(math.nan == timers_0.median(name_0))



# Generated at 2022-06-25 15:18:09.988682
# Unit test for method median of class Timers
def test_Timers_median():
    # Test default initialization (no args)
    timers_0 = Timers()

    # Test with one argument
    timers_1 = Timers()
    timers_1.add("name1", 5.0)
    assert timers_1.median("name1") == 5.0

    # Test with two arguments
    timers_2 = Timers()
    timers_2.add("name2", 5.0)
    timers_2.add("name2", 10.0)
    assert timers_2.median("name2") == 7.5

    # Test with three arguments
    timers_3 = Timers()
    timers_3.add("name3", 5.0)
    timers_3.add("name3", 10.0)
    timers_3.add("name3", 15.0)
    assert timers_3.median

# Generated at 2022-06-25 15:18:12.417988
# Unit test for method min of class Timers
def test_Timers_min():
    print("... testing min")
    timers_0 = Timers()
    timers_0.add("0", 1)
    assert timers_0.min("0") == 1


# Generated at 2022-06-25 15:18:14.709192
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("name", 7)
    assert timers_0.min("name") == 7


# Generated at 2022-06-25 15:18:44.123882
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name = 'name'
    max = timers_0.max(name)


# Generated at 2022-06-25 15:18:53.439953
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.data["foo"] = 0.012345679012345678
    timers_0.add("foo", 0.012345679012345678)
    timers_0.add("foo", 0.012345679012345678)
    timers_0.add("foo", 0.012345679012345678)
    timers_0.add("foo", 0.012345679012345678)
    assert timers_0.median("foo") == 0.012345679012345678


# Generated at 2022-06-25 15:19:01.404581
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('test_timers', 1.0)
    assert timers_0.max('test_timers') == 1.0
    timers_0.add('test_timers', 7.0)
    assert timers_0.max('test_timers') == 7.0


# Generated at 2022-06-25 15:19:09.595274
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.data = {"foo": 100.1, "bar": 300.0, "baz": 50.0}
    timers_1._timings = {"foo": [1.0, 2.0, 3.0], "bar": [4.0, 5.0, 6.0], "baz": [7.0, 8.0, 9.0]}
    timers_1.add("foo", 8.4)
    timers_1.add("bar", 3.2)
    timers_1.add("baz", 2.1)
    timers_1.clear()
    assert timers_1.median("bar") == 5
    assert timers_1.mean("bar") == statistics.mean([4.0, 5.0, 6.0])

# Generated at 2022-06-25 15:19:15.942489
# Unit test for method min of class Timers
def test_Timers_min():
    # Initialization
    timers = Timers()

    # Test empty and non-existing timer
    assert timers.min("timer_1") == 0
    assert timers.min("timer_2") == 0

    # Test existing timer
    timers.add("timer_1", 1.1)
    timers.add("timer_1", 2.2)
    assert timers.min("timer_1") == 1.1

    # Test multiple timers
    timers.add("timer_2", 1.1)
    assert timers.min("timer_2") == 1.1



# Generated at 2022-06-25 15:19:18.353150
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Arrange
    timers_0 = Timers()
    expected = 0.0
    
    # Act
    actual = timers_0.mean('name')
    
    # Assert
    assert expected == actual



# Generated at 2022-06-25 15:19:21.347469
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = "timer 1"
    float_0 = timers_0.mean(name_0)
    assert round(float_0, 9) == 0.0


# Generated at 2022-06-25 15:19:26.443075
# Unit test for method mean of class Timers
def test_Timers_mean():
    test_case_0()

    timers_0 = Timers()

    timers_0.add("name_0", 1.0)
    timers_0.add("name_0", 2.0)
    timers_0.add("name_0", 3.0)
    timers_0.add("name_0", 4.0)

    mean = timers_0.mean("name_0")

    assert mean == 2.5


# Generated at 2022-06-25 15:19:27.573670
# Unit test for method min of class Timers
def test_Timers_min():
    assert timers_0.min() == min(list_pop)


# Generated at 2022-06-25 15:19:35.198155
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("key_0", 1.0)
    assert 1.0 == timers_0.min("key_0")
    timers_0.add("key_0", 2.0)
    assert 1.0 == timers_0.min("key_0")
    assert 2.0 == timers_0.max("key_0")
    timers_0.add("key_0", 3.0)
    assert 1.0 == timers_0.min("key_0")
    assert 3.0 == timers_0.max("key_0")
    timers_0.add("key_0", -1.0)
    assert -1.0 == timers_0.min("key_0")
    assert 3.0 == timers_0.max("key_0")

# Generated at 2022-06-25 15:20:42.715763
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0["Parsing" %()] = 2.6
    timers_0["Sample_IO" %()] = 12.0
    timers_0["Parsing %(int)s" %{"int" : 1}] = 2.6
    timers_0["Sample_IO %(int)s" %{"int" : 1}] = 12.0
    timers_0["Parsing %(int)s" %{"int" : 2}] = 2.6
    timers_0["Sample_IO %(int)s" %{"int" : 2}] = 12.0
    timers_0["Parsing %(int)s" %{"int" : 3}] = 2.6

# Generated at 2022-06-25 15:20:51.066461
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_1 = Timers()
    timers_0.add("Key1", 0.0875)
    timers_0.add("Key2", 0.0)
    timers_1.add("Key1", 0.0)
    timers_1.add("Key2", 0.1)
    assert timers_0.max("Key1") == 0.0875
    assert timers_0.max("Key2") == 0.0
    assert timers_0.max("Key3") == 0
    assert timers_0.max("Key1") == timers_1.max("Key2")
    assert timers_0.max("Key2") == timers_1.max("Key1")


# Generated at 2022-06-25 15:21:00.360756
# Unit test for method max of class Timers
def test_Timers_max():
    try:
        timers_0 = Timers()
        timers_0.add('key_0', 1.0)
        timers_0.apply(max, 'key_0')
    except:
        print('EXCEPTION!')
    timers_0 = Timers()
    try:
        timers_0.add('key_0', 2.0)
        timers_0.apply(min, 'key_0')
    except:
        print('EXCEPTION!')
    try:
        timers_0.apply(sum, 'key_0')
    except KeyError:
        print("KeyError")

test_case_0()
test_Timers_max()

# Generated at 2022-06-25 15:21:02.882268
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('default_timer', 4.589430599212646)
    try:
        timers_0.max('default_timer')
    except Exception as e:
        print(e)


# Generated at 2022-06-25 15:21:08.090277
# Unit test for method max of class Timers
def test_Timers_max():
    # Create instance of class Timers and set data
    timers_0 = Timers()
    timers_0.data = {'b': 16.0, 'a': 5.0}
    # Call method max and assert it returns expected result
    assert timers_0.max('a') == 5.0
    assert timers_0.max('b') == 16.0
    # Call method max and assert it throws expected exception
    try:
        timers_0.max('c')
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 15:21:12.545577
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name = str()
    value = timers_0.max(name)


# Generated at 2022-06-25 15:21:17.939631
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add('a', 3.2)
    timers_1.add('a', 5.5)
    timers_1.add('a', 0.6)
    assert timers_1.mean('a') == (3.2 + 5.5 + 0.6) / 3


# Generated at 2022-06-25 15:21:26.502504
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("xyz", -1.6e+06)
    timers_0.add("xyz", -1.6e+06)

    try:
        timers_0.max("xyz")
    except ArithmeticError:
        pass

    timers_0.add("yxz", -1.6e+06)
    timers_0.max("yxz")


# Generated at 2022-06-25 15:21:30.651691
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()  # type: Timers
    timers_0.add("task", 1.4)  # type: ignore
    timers_0.add("task", 1.5)  # type: ignore
    timers_0.add("task", 1.7)  # type: ignore
    timers_0.add("task", 1.8)  # type: ignore
    timer_median = timers_0.median("task")
    assert math.isclose(timer_median, 1.65)
