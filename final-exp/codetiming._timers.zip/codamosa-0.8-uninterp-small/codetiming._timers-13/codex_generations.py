

# Generated at 2022-06-25 15:11:42.430527
# Unit test for method min of class Timers
def test_Timers_min():
    """
    Timers.min(name)
    """
    timers_0 = Timers()
    timers_0.add("One", 3.8)
    timers_0.add("One", 7.8)
    timers_0.add("Two", 64.62)
    timers_0.add("One", 7.99)
    assert timers_0.min("One") == 3.8
    timers_0.add("One", 6.94)
    assert timers_0.min("Two") == 64.62


# Generated at 2022-06-25 15:11:43.648695
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name = "timer_0"
    assert timers_0.mean(name) == 0.0



# Generated at 2022-06-25 15:11:53.001121
# Unit test for method max of class Timers

# Generated at 2022-06-25 15:11:59.973895
# Unit test for method median of class Timers
def test_Timers_median():
    # Initialize an object of class Timers
    timers = Timers()

    # Add an element to timers
    timers.add('timer_0', 0)

    # Get the value associated with the timer
    timers_median_0 = timers.median('timer_0')

    # Initialize an object of class Timers
    timers_0 = Timers()

    # Add an element to timers_0
    timers_0.add('timer_0', 0)
    timers_0.add('timer_0', 2)

    # Get the value associated with the timer
    timers_0_median_0 = timers_0.median('timer_0')

    # Initialize an object of class Timers
    timers_1 = Timers()
    timers_1.add('timer_1', 2)

# Generated at 2022-06-25 15:12:02.327961
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('m', 100.0)
    timers_0.add('m', 10.0)
    timers_0.add('m', 1.0)
    assert (timers_0.mean('m') == 37.0)


# Generated at 2022-06-25 15:12:03.518833
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.max(name="name_0")



# Generated at 2022-06-25 15:12:10.405234
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.data[94] = 260.90476612459324
    timers_0.data[30] = 0.13273778289943206
    timers_0.data[45] = 353.2515217429313

# Generated at 2022-06-25 15:12:14.717994
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("example_0", 1.0)
    timers_0.add("example_0", 1.0)
    timers_0.add("example_0", 0.5)
    timers_0.add("example_0", 0.5)
    assert timers_0.median("example_0") == 0.75


# Generated at 2022-06-25 15:12:24.517599
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add(name="f1_1", value=1.0)
    timers_0.add(name="f1_2", value=2.0)
    timers_0.add(name="f1_3", value=3.0)
    timers_0.add(name="f1_4", value=4.0)
    timers_0.add(name="f1_5", value=5.0)
    timers_0.add(name="f1_6", value=6.0)
    assert timers_0.median(name="f1_1") == 3.0
    assert timers_0.median(name="f1_4") == 4.0
    assert timers_0.median(name="f1_5") == 5.0
   

# Generated at 2022-06-25 15:12:30.345634
# Unit test for method max of class Timers
def test_Timers_max():
	timers_0 = Timers()
	timers_0.add('sub_branch', 0.001953125)
	timers_0.add('sub_branch', 0.0)
	timers_0.add('sub_branch', 0.0)
	timers_0.add('sub_branch', 0.001953125)
	timers_0.add('sub_branch', 0.0)
	timers_0.add('sub_branch', 0.0)
	assert timers_0.max('sub_branch') == 0.001953125


# Generated at 2022-06-25 15:12:34.948495
# Unit test for method mean of class Timers
def test_Timers_mean():
    value = Timers().mean(name="name")
    assert value == 0


# Generated at 2022-06-25 15:12:42.603108
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("name_0", 2.0)
    timers_0.add("name_0", 2.0)
    timers_0.add("name_0", 2.0)
    timers_0.add("name_0", 2.0)
    timers_0.add("name_0", 2.0)
    timers_0.add("name_0", 2.0)
    assert timers_0.min("name_0") == 2.0
    # print(timers_0.min("name_0"))


# Generated at 2022-06-25 15:12:49.393643
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('foo', 1.0)
    timers_0.add('foo', 2.0)
    if 1.5 != timers_0.median('foo'):
        raise AssertionError
    if 1.0 != timers_0.min('foo'):
        raise AssertionError
    if 2.0 != timers_0.max('foo'):
        raise AssertionError
    if 1.5 != timers_0.mean('foo'):
        raise AssertionError
    if math.sqrt(0.5) != timers_0.stdev('foo'):
        raise AssertionError


# Generated at 2022-06-25 15:12:52.782308
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("key_0", 0.0)
    timers_0.add("key_0", 0.0)
    timers_0.add("key_0", 0.0)
    timers_0.min("key_0")


# Generated at 2022-06-25 15:13:03.569017
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add(str_0='measurement_1', value=0.0)
    timers_0.add(str_0='measurement_1', value=1e-05)
    timers_0.add(str_0='measurement_1', value=2e-05)
    timers_0.add(str_0='measurement_1', value=3e-05)
    timers_0.add(str_0='measurement_1', value=4e-05)
    timers_0.add(str_0='measurement_2', value=5e-05)
    timers_0.add(str_0='measurement_2', value=6e-05)

# Generated at 2022-06-25 15:13:06.133230
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    assert timers_1.min("foo") == 0
    timers_1 = Timers()
    assert timers_1.min("value") == 0


# Generated at 2022-06-25 15:13:09.179195
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert math.isnan(timers_0.mean('name_1'))
    assert math.isnan(timers_0.mean('name_0'))


# Generated at 2022-06-25 15:13:15.052966
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("name_0", 0.01)
    timers_0.add("name_1", 0.01)
    timers_0.add("name_2", 0.01)

    assert timers_0.mean("name_0") == 0.01
    assert timers_0.mean("name_1") == 0.01
    assert timers_0.mean("name_2") == 0.01


# Generated at 2022-06-25 15:13:16.694391
# Unit test for method median of class Timers
def test_Timers_median():
    values = [5]
    value = Timers().median(name=values)
    assert value == 5



# Generated at 2022-06-25 15:13:18.803313
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('a', 3.0)
    timers_0.add('a', 5.3)
    assert timers_0.mean('a') == 4.15


# Generated at 2022-06-25 15:13:25.844894
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('foo', 0.0)
    timers_0.add('foo', 2.0)
    timers_0.add('foo', -2.2)
    timers_0.min('foo')


# Generated at 2022-06-25 15:13:32.395603
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = "arst"
    value_0 = [9.94665588551143, 4.838752768002273, 6.543058564064335, 5.157509007971091]
    timers_0._timings[name_0] = value_0
    test_result_0 = timers_0.mean(name_0)

    assert test_result_0 == 6.484635279518957


# Generated at 2022-06-25 15:13:43.132909
# Unit test for method max of class Timers
def test_Timers_max():
    # Test class Timers max
    timers_0 = Timers()
    timers_1 = Timers()

    timers_0.add("test_timers_0.max", 3.0)
    timers_1.add("test_timers_1.max", 2.0)
    timers_0.add("test_timers_0.max", 4.0)
    timers_1.add("test_timers_1.max", 5.0)
    test_max_0 = timers_0.max("test_timers_0.max")
    test_max_1 = timers_0.max("test_timers_1.max")
    test_max_2 = timers_1.max("test_timers_0.max")

# Generated at 2022-06-25 15:13:48.569345
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    # Test 0
    try:
        assert timers_0.min("") == 0
    except KeyError:
        pass
    # Test 1
    try:
        assert timers_0.min("s") == 0
    except KeyError:
        pass



# Generated at 2022-06-25 15:13:55.851709
# Unit test for method median of class Timers
def test_Timers_median():
    """Method median of class Timers"""
    timers_0 = Timers()
    timers_0.add("s", 1.8175578412722435)
    timers_0.add("s", 5.495085334777832)
    timers_0.add("t", 0.20353388786315918)
    timers_0.add("s", 1.6967872385025024)
    timers_0.add("s", 3.863966941833496)
    timers_0.add("s", 2.645911111831665)
    timers_0.add("s", 3.108417272567749)
    timers_0.add("s", 0.15207338333129883)
    timers_0.add("t", 0.2774040699005127)


# Generated at 2022-06-25 15:14:01.669235
# Unit test for method min of class Timers
def test_Timers_min():
    """Test cases for Timers.min"""
    timers_0 = Timers()
    timers_0.add("timer_0", 5.39)
    timers_0.add("timer_0", 5.51)
    timers_0.add("timer_1", 5.89)
    assert timers_0.min("timer_1") == 5.89


# Generated at 2022-06-25 15:14:07.493434
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('bob', 1)
    timers.add('bob', 1)
    timers.add('bob', 1)
    timers.add('bob', 2)
    print(timers.total('bob'))
    assert timers.total('bob') == 5
    assert timers.mean('bob') == 1.25
    timers.clear()
    assert timers.total('bob') == 0
    assert timers.mean('bob') == 0


# Generated at 2022-06-25 15:14:14.372880
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("foxtrot delta Tango", 1.0)
    timers_0.add("hotel", 1.0)
    timers_0.add("hotel", 1.0)
    timers_0.add("hotel", 1.0)
    timers_0.add("hotel", 1.0)
    timers_0.add("hotel", 1.0)
    timers_0.add("hotel", 1.0)
    timers_0.add("hotel", 2.0)
    timers_0.add("hotel", 2.0)
    timers_0.add("hotel", 2.0)
    timers_0.add("hotel", 2.0)
    timers_0.add("hotel", 2.0)
    timers_0.add

# Generated at 2022-06-25 15:14:16.801311
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name_0: str
    value_0: float
    timers_0.add(name_0, value_0)


# Generated at 2022-06-25 15:14:22.926157
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add("key_1", 0.1)
    timers_1.add("key_1", 0.2)
    timers_1.add("key_1", 0.3)
    assert timers_1.mean("key_1") == 0.2


# Generated at 2022-06-25 15:14:29.699708
# Unit test for method median of class Timers
def test_Timers_median():
    assert_equal(timers_0.median("ein"), math.nan)
    assert_equal(timers_0.median("zwei"), math.nan)
    assert_equal(timers_0.median("drei"), math.nan)


# Generated at 2022-06-25 15:14:38.030731
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.clear()
    timers_0.add('pulp_solver_node_deleted', 0.6098984499999999)
    timers_0.add('pulp_solver_node_deleted', 0.6099150999999999)
    timers_0.add('pulp_solver_node_deleted', 0.6099783499999999)
    timers_0.add('pulp_solver_node_deleted', 0.6099813499999999)
    timers_0.add('pulp_solver_node_deleted', 0.60999095)
    timers_0.add('pulp_solver_node_deleted', 0.6100572)

# Generated at 2022-06-25 15:14:44.298798
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("key_0_timer", -42)
    timers_0.add("key_0_timer", -60)
    timers_0.add("key_0_timer", -60)
    assert -60 <= timers_0.min("key_0_timer") <= -60
    timers_0.add("key_0_timer", -60)
    assert -60 <= timers_0.min("key_0_timer") <= -60
    timers_0.add("key_0_timer", 12)
    assert -60 <= timers_0.min("key_0_timer") <= -60
    timers_0.add("key_0_timer", -19)
    assert -60 <= timers_0.min("key_0_timer") <= -60

# Generated at 2022-06-25 15:14:53.029678
# Unit test for method max of class Timers
def test_Timers_max():
    # Instantiate a new Timers
    timers_0 = Timers()
    # Add a timer
    timers_0.add("test_0", 3)
    timers_0.add("test_1", 5)
    timers_0.add("test_0", 7)
    # Get maximum values
    value_0 = timers_0.max("test_0")
    assert value_0 == 7, value_0
    value_1 = timers_0.max("test_1")
    assert value_1 == 5, value_0
    try:
        value_2 = timers_0.max("test_2")
    except KeyError:
        pass


# Generated at 2022-06-25 15:14:57.377045
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("test", 1)
    timers._timings["test"] = [2.2, 2.2, 2.2, 2.2, 2.2]
    # Test median of {2.2, 2.2, 2.2, 2.2, 2.2}
    assert 2.2 == timers.median("test")

# Generated at 2022-06-25 15:15:00.001882
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("foobar", 1.0)
    assert timers_0.min("foobar") == 1.0


# Generated at 2022-06-25 15:15:04.711752
# Unit test for method max of class Timers
def test_Timers_max():
    import pytest
    # prepare
    timers_0 = Timers()
    timers_0.add('key_0', 0.0985859478744522)
    timers_0.add('key_0', 0.6546156697887698)
    # execute
    result_0 = timers_0.max('key_0')
    # verify
    assert result_0 == pytest.approx(0.6546156697887698)


# Generated at 2022-06-25 15:15:07.523377
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('timer1', 1.0)
    assert timers.max('timer1') == 1.0
    assert timers.max('timer2') == 0.0



# Generated at 2022-06-25 15:15:09.159454
# Unit test for method median of class Timers
def test_Timers_median():
    # No exceptions raised
    assert 1 == 1


# Generated at 2022-06-25 15:15:11.479037
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    print("(0x60) median()")
    # Timings object is empty
    timers.median("a")


# Generated at 2022-06-25 15:15:17.754774
# Unit test for method min of class Timers
def test_Timers_min():
    name = "name"
    uut = Timers()
    uut[name] = 1.0
    assert uut.min(name) == 1.0


# Generated at 2022-06-25 15:15:22.318234
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("key", 1)
    assert timers_0.max("key") == 1  # expected: 1, actual: 1
    timers_0.add("key", 2)
    assert timers_0.max("key") == 2  # expected: 2, actual: 2


# Generated at 2022-06-25 15:15:25.765899
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    try:
        timers_0.mean(str())
    except KeyError:
        passed = True
    else:
        passed = False
    assert passed, 'Test failed'


# Generated at 2022-06-25 15:15:33.053427
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Setup
    timers_0 = Timers()
    timers_0.data = {'c': 9.0, 'b': 6.0, 'a': 5.0}
    # Test case 0
    timers_0.add("a", 1)
    timers_0.add("b", 3)
    timers_0.add("c", 3)
    assert timers_0.mean("a") == 1.0
    assert timers_0.mean("b") == 3.0
    assert timers_0.mean("c") == 3.0


# Generated at 2022-06-25 15:15:37.930620
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("a", 0.0)  # Not reached
    timers_0.add("b", 1.0)
    timers_0.add("b", 1.0)
    assert timers_0.mean("b") == 1.0



# Generated at 2022-06-25 15:15:42.776623
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    name = "name"
    ins = test_case_0()
    ins.add(name, 2.5)
    ins.add(name, 2.5)
    ins.add(name, 2.5)
    result = ins.median(name)
    assert result == 2.5


# Generated at 2022-06-25 15:15:49.828076
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('foo', 1)
    timers.add('foo', 2)
    timers.add('foo', 3)
    assert timers.median('foo') == 2
    timers.add('foo', 3)
    assert timers.median('foo') == 2
    timers.add('foo', 4)
    assert timers.median('foo') == 3
    timers.add('foo', 4)
    assert timers.median('foo') == 3
    timers.add('foo', 5)
    assert timers.median('foo') == 3
    timers.add('foo', 6)
    assert timers.median('foo') == 4
    timers.add('foo', 7)
    assert timers.median('foo') == 4
    timers.add('foo', 8)

# Generated at 2022-06-25 15:15:55.620502
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median() method of class Timers"""

    # Test empty dictionary
    timers_0 = Timers()
    assert timers_0.median("foo") == 0.0

    # Test non-empty dictionary
    timers_1 = Timers({
        "foo": 1.4142135623731,
        "bar": 3.14159265358979,
        "baz": 2.71828182845904
    })
    assert timers_1.median("foo") == 1.4142135623731
    assert timers_1.median("bar") == 3.14159265358979
    assert timers_1.median("baz") == 2.71828182845904



# Generated at 2022-06-25 15:16:03.768979
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("key_0", 0.0)
    timers_0.add("key_0", 0.0)
    timers_0.add("key_0", 0.0)
    timers_0.add("key_0", 0.0)
    timers_0.add("key_0", 0.0)
    timers_0.add("key_0", 0.0)
    timers_0.add("key_0", 0.0)
    timers_0.add("key_0", 0.0)
    timers_0.add("key_0", 0.0)
    timers_0.add("key_0", 0.0)
    timers_0.add("key_0", 0.0)

# Generated at 2022-06-25 15:16:06.942776
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name_0 = ''
    value_0 = 0
    timers_0.add(name_0, value_0)
    timers_0.max(name_0)


# Generated at 2022-06-25 15:16:14.919003
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("test", 0.5)
    timers_0.add("test", 0.1)
    timers_0.add("test", 0.2)
    timers_0.add("test", 0.7)
    timers_0.add("test", 0.3)

    assert timers_0.max("test") == 0.7


# Generated at 2022-06-25 15:16:19.869322
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers({'alternatives': 1.0959784}, {})
    assert timers_0.mean('alternatives') == 1.0959784



# Generated at 2022-06-25 15:16:24.633836
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('0.0', 1.0)
    timers_0.add('0.0', 4.0)
    timers_0.add('0.0', 2.0)
    assert isinstance(timers_0.min('0.0'), float)


# Generated at 2022-06-25 15:16:31.105527
# Unit test for method median of class Timers
def test_Timers_median():
    from pandas import DataFrame

    data_0 = DataFrame()
    data_0.median()

    data_1 = DataFrame()
    data_1.median(axis=0)

    data_2 = DataFrame()
    data_2.median(axis=0, skipna=True)

    data_3 = DataFrame()
    data_3.median(axis=1)

    data_4 = DataFrame()
    data_4.median(axis=1, skipna=True)

    data_5 = DataFrame()
    data_5.median(skipna=False)


# Generated at 2022-06-25 15:16:40.354936
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.data.update({"A": 2, "B": 3})
    timers._timings.update({"A": [1, 2], "B": [2, 3, 4]})
    assert timers.max("A") == 2
    assert timers.max("B") == 4
    assert timers.max("C") == 0
    assert timers.data.get("A", 0) == 2
    assert timers.data.get("B", 0) == 3
    assert timers.data.get("C", 0) == 0
    assert timers._timings["A"] == [1, 2]
    assert timers._timings["B"] == [2, 3, 4]
    assert timers._timings["C"] == []

# Generated at 2022-06-25 15:16:44.076994
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('ps0', 4.5)
    min_0 = timers_0.min('ps0')
    assert min_0 == 4.5


# Generated at 2022-06-25 15:16:52.098320
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = test_case_0()
    # The mean of an empty list is NaN
    assert math.isnan(timers_0.mean(name="name"))

    timers_0.add(name="name", value=4.4)
    # The mean of a list with one element is easy
    assert timers_0.mean(name="name") == 4.4

    timers_0.add(name="name", value=5.5)
    # The mean of a list of many elements is not so easy
    assert timers_0.mean(name="name") == 5


# Generated at 2022-06-25 15:16:54.093779
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.max("time_spent_reading") is float("nan")


# Generated at 2022-06-25 15:16:55.293597
# Unit test for method max of class Timers
def test_Timers_max():
    pass #TODO: implement your test here


# Generated at 2022-06-25 15:16:59.077100
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    try:
        timers_0.min("Fdefaultdict")
    except KeyError as err:
        assert str(err) in ["Fdefaultdict"]


# Generated at 2022-06-25 15:17:04.704236
# Unit test for method mean of class Timers
def test_Timers_mean():
    counters = Timers()
    name = "name"
    assert counters.mean(name) == 0
    counters = Timers()
    name = "name"
    assert counters.mean(name) == 0
    counters = Timers()
    name = "name"
    assert counters.mean(name) == 0


# Generated at 2022-06-25 15:17:09.943206
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    try:
        timers_0.median('median')
        assert False
    except KeyError:
        assert True
    timers_0.add('median', 1.0)
    timers_0.add('median', 2.0)
    timers_0.add('median', 3.0)
    assert timers_0.median('median') == 2.0



# Generated at 2022-06-25 15:17:11.626814
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()

    # initialize timers_0 here
    # timers_0.clear()
    # timers_0.add(name, value)

    # test max method here
    # result = timers_0.max(name)


# Generated at 2022-06-25 15:17:12.758966
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert math.isnan(timers_0.median('iV7fRrU6'))


# Generated at 2022-06-25 15:17:15.715817
# Unit test for method max of class Timers
def test_Timers_max():
    values = [3, 1, 2]
    timer = Timers()
    for value in values:
        timer.add("Timer", value)
    max_0 = timer.max("Timer")
    assert max_0 == max(values)


# Generated at 2022-06-25 15:17:25.673112
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.clear()
    # Tests for timings of name 'update_grid_step'
    timers_0.add(name='update_grid_step', value=1.5)
    timers_0.add(name='update_grid_step', value=7.5)
    timers_0.add(name='update_grid_step', value=1.5)
    assert (timers_0.max(name='update_grid_step') == 7.5)
    # Tests for timings of name 'update_particles_step'
    timers_0.add(name='update_particles_step', value=1.5)
    timers_0.add(name='update_particles_step', value=3.0)

# Generated at 2022-06-25 15:17:30.799428
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert math.isnan(timers_0.max("name"))
    assert math.isnan(timers_0.max("name"))
    assert math.isnan(timers_0.max("name"))



# Generated at 2022-06-25 15:17:36.619977
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add('timer_1', 2.5)
    timers_1.add('timer_1', 2.5)
    timers_1.add('timer_1', 2.5)
    timers_1.add('timer_2', 2.5)
    assert timers_1.mean('timer_1') == 2.5
    assert timers_1.mean('timer_2') == 2.5

# Generated at 2022-06-25 15:17:40.769687
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers_0 = Timers()
    timers_0.add("name_0", 1.0)
    assert 1.0 == timers_0.max("name_0"), "timers_0.max('name_0')"


# Generated at 2022-06-25 15:17:50.065258
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    expected = 0.0
    actual = timers_0.median("timer_0")
    assert actual == expected, "Expected: %s Actual: %s" % (expected, actual)
    timers_0.add("timer_0", 0.0)
    expected = 0.0
    actual = timers_0.median("timer_0")
    assert actual == expected, "Expected: %s Actual: %s" % (expected, actual)
    timers_0.add("timer_0", 0.0)
    timers_0.add("timer_0", 0.0)
    timers_0.add("timer_0", 0.0)
    timers_0.add("timer_0", 0.0)
    timers_0.add("timer_0", 0.0)
    timers

# Generated at 2022-06-25 15:18:01.998812
# Unit test for method max of class Timers
def test_Timers_max():
    test_cases = [
        {"name": "", "arg": 0, "expect": 0},
        {"name": "", "arg": 0, "expect": 0},
        {"name": "", "arg": 0, "expect": 0},
        {"name": "", "arg": 0, "expect": 0},
        {"name": "", "arg": 0, "expect": 0},
    ]

    for tc in test_cases:
        result = Timers.max(**tc)
        assert result == tc["expect"], "{} failed".format(tc["name"])


# Generated at 2022-06-25 15:18:11.241162
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Test of method mean of class Timers"""
    timers_0 = Timers({'t_0': 0.0, 't_1': 1.0})
    assert math.isclose(timers_0.mean('t_0'), 0.0)
    assert math.isclose(timers_0.mean('t_1'), 1.0)

    # Add a timing value to the given timer
    timers_0.add('t_2', 3.0)
    assert math.isclose(timers_0.mean('t_2'), 3.0)
    
    # Clear timers
    timers_0.clear()
    assert timers_0._timings == {}


# Generated at 2022-06-25 15:18:14.261719
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()

    try:
        timers_0.mean(name='name_0')
        assert False, "Expected Exception"
    except KeyError:
        pass


# Generated at 2022-06-25 15:18:21.947134
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("timers_0", 2.9)
    timers_1 = Timers()
    timers_1.add("timers_0", 1.5)
    assert math.isclose(timers_0.min("timers_0"), 1.5, rel_tol=1e-09), "test_Timers_min fails"

# Generated at 2022-06-25 15:18:27.903560
# Unit test for method min of class Timers
def test_Timers_min():
    """Test of Timers.min() method"""
    timers_0 = Timers()
    timers_0.data["key_1"] = 5.0
    timers_0.data["key_2"] = 44.99999999999999
    timers_0.data["key_3"] = 1.0
    timers_0.data["key_4"] = 2.0
    assert timers_0.min("key_1") == 5.0
    assert timers_0.min("key_2") == 44.99999999999999
    assert timers_0.min("key_3") == 1.0
    assert timers_0.min("key_4") == 2.0


# Generated at 2022-06-25 15:18:34.777197
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('b', 1.0)
    timers.add('a', 1.0)
    timers.add('b', 1.0)
    timers.add('a', 1.0)
    timers.add('b', 1.0)
    timers.add('a', 1.0)
    timers.add('b', 1.0)
    result = timers.median('a')
    expected = 1.0
    assert result == expected, "Result was {}, expected {}".format(result, expected)


# Generated at 2022-06-25 15:18:38.740801
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("env_time", 0.823)
    assert [1.0, 0.199] == [timers_0.min("env_time"), timers_0.min("test")]


# Generated at 2022-06-25 15:18:44.907087
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.add('k', 4)
    timers_1.add('k', 5)
    timers_1.add('k', 1)
    timers_1.add('k', 3)
    assert timers_1.median('k') == 3.5


# Generated at 2022-06-25 15:18:48.082029
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    name = "name"
    with pytest.raises(KeyError):
        timers_0.median(name)


# Generated at 2022-06-25 15:18:52.092039
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert isinstance(timers_0.min("min_0"), float)





# Generated at 2022-06-25 15:19:08.987141
# Unit test for method mean of class Timers
def test_Timers_mean():
    for i in range(5):
        timers_0 = Timers()
        timers_0.add('a', 1.0)
        timers_0.add('a', -1.0)
        timers_0.add('b', 300.0)
        timers_0.add('b', 200.0)
        timers_0.add('b', 100.0)
        timers_0.add('b', 0.0)
        timers_0.add('b', -100.0)
        timers_0.add('c', 0.0)
        try:
            assert round(timers_0.mean('d'), 2) == 0.0
            raise AssertionError("Should have raised")
        except KeyError:
            pass
        assert round(timers_0.mean('a'), 2) == 0.0

# Generated at 2022-06-25 15:19:13.822156
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Function testing mean of Timers"""
    timers_1 = Timers()
    timer_name_1 = 'ABC.DEF'
    timer_value_1 = 2.0
    timers_1.add(timer_name_1, timer_value_1)
    timer_name_2 = 'XYZ.ABC'
    timer_value_2 = 1.0
    timers_1.add(timer_name_2, timer_value_2)
    ret_val_1 = timers_1.mean(timer_name_2)
    assert ret_val_1 == timer_value_2, \
    f"Expected return value = {timer_value_2}, actual value = {ret_val_1}"


# Generated at 2022-06-25 15:19:20.847754
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    assert timers.min('foo') == 0
    assert timers.count('foo') == 0
    timers.add('foo', value=1)
    timers.add('foo', value=2)
    assert timers.count('foo') == 2
    assert timers.total('foo') == 3
    assert timers.min('foo') == 1
    assert timers.max('foo') == 2
    assert round(timers.mean('foo'), 3) == 1.5
    assert timers.median('foo') == 1.5
    assert round(timers.stdev('foo'), 3) == 0.707
    timers.clear()
    assert timers.count('foo') == 0
    assert timers.min('foo') == 0

if __name__ == '__main__':
    # Run all functions with arguments
    argument_

# Generated at 2022-06-25 15:19:25.304316
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0['index'] = 1
    timers_0['index1'] = 2
    timers_0['index2'] = 3
    timers_0.add('index2', 3)
    timers_0.add('index2', 3)
    assert timers_0.median('index2') == 3.0


# Generated at 2022-06-25 15:19:27.459450
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('name', 1.0)
    assert timers_0.median('name') == 1.0


# Generated at 2022-06-25 15:19:30.053226
# Unit test for method mean of class Timers
def test_Timers_mean():
    """"""
    timers_0 = Timers()
    assert timers_0.mean(None) == 0
    assert timers_0.mean(None) == 0
    assert timers_0.mean(None) == 0


# Generated at 2022-06-25 15:19:34.478936
# Unit test for method max of class Timers
def test_Timers_max():
    """Test for method max of class Timers"""
    # Local variables
    timers = Timers()
    timers.add('t1', 2.4)
    timers.add('t1', 1.9)
    timers.add('t1', 3.7)
    timers.add('t2', 7.2)
    # Test if max(key) returns the correct value
    assert max(timers.keys()) == 't2'


# Generated at 2022-06-25 15:19:41.271740
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.add(name='test', value=1.0)
    assert timers_1.median("test") == 1.0


# Generated at 2022-06-25 15:19:42.956102
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    assert isinstance(timers.max(""), float)


# Generated at 2022-06-25 15:19:46.636045
# Unit test for method mean of class Timers
def test_Timers_mean():
    expected_0 = 0.0
    name_0 = "name_0"
    timers_0 = Timers()
    timers_0.add(name_0, 5.0)
    assert timers_0.mean(name_0) == expected_0


# Generated at 2022-06-25 15:20:01.327972
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("timer_3", 0.99)
    timers_0.add("timer_3", 0.99)
    timers_0.add("timer_0", 0.99)
    timers_0.add("timer_2", 0.99)
    timers_0.add("timer_0", 0.99)
    timers_0.add("timer_1", 0.99)
    timers_0.add("timer_3", 0.99)
    timers_0.add("timer_1", 0.99)
    timers_0.add("timer_1", 0.99)
    timers_0.add("timer_3", 0.99)
    timers_0.add("timer_1", 0.99)
    assert timers_0.mean("timer_0") == 0

# Generated at 2022-06-25 15:20:07.431588
# Unit test for method median of class Timers
def test_Timers_median():

    timers_0 = Timers()
    timers_0.add("name_0", 0.1)
    timers_0.add("name_1", -1.0)

    for name in ("name_0", "name_1"):
        assert timers_0.apply(statistics.median, name=name) == statistics.median(
            timers_0._timings[name]
        )

# Generated at 2022-06-25 15:20:15.196030
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Input

    timers_0 = Timers()
    timers_0.add('a', 2.0)
    timers_0.add('a', 3.0)
    timers_0.add('b', 4.0)
    timers_0.add('b', 6.0)

    # Output
    mean_a = 2.5
    mean_b = 5.0

    assert timers_0.mean('a') == mean_a
    assert timers_0.mean('b') == mean_b

# Generated at 2022-06-25 15:20:18.561358
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name = 'name'

    # Test for single timer
    value = 0.0
    timers_0.add(name, value)

    # Test for multiple timers
    value = 0.0
    timers_0.add(name, value)


# Generated at 2022-06-25 15:20:19.251088
# Unit test for method median of class Timers
def test_Timers_median():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 15:20:23.448671
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = "timer_0"
    timers_0.data = dict()

# Generated at 2022-06-25 15:20:24.731431
# Unit test for method mean of class Timers
def test_Timers_mean():
    global timers_0
    name_0 = str()
    try:
        timers_0.mean(name_0)
    except:
        None


# Generated at 2022-06-25 15:20:28.894637
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()


# Generated at 2022-06-25 15:20:35.522666
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1.add('timer_1', 0.1)
    timers_1.add('timer_1', 0.2)
    timers_1.add('timer_1', 0.3)
    timers_1.add('timer_2', 0.4)
    timers_1.add('timer_2', 0.5)
    timers_1.add('timer_2', 0.6)
    result_1 = timers_1.min('timer_1')
    timers_2 = Timers()
    timers_2.add('timer_1', 0.1)
    timers_2.add('timer_1', 0.2)
    timers_2.add('timer_1', 0.3)
    timers_2.add('timer_2', 0.4)

# Generated at 2022-06-25 15:20:41.079418
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Initialize parameters
    name = "name"
    timers_0 = Timers()
    timers_0._timings[name] = [1.1, 2.2, 3.3]

    # Execute method under test
    value = timers_0.mean(name)

    # Check result
    assert value == 2.2


# Generated at 2022-06-25 15:20:58.171427
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("0", 0.0)
    timers_0.add("0", 0.0)
    timers_0.min("0")


# Generated at 2022-06-25 15:21:06.228205
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add(
        "Timer_1",
        0.868596619594896,
    )
    timers_0.add(
        "Timer_1",
        0.13120750511756683,
    )
    timers_0.add(
        "Timer_1",
        0.5499404113298709,
    )
    timers_0.add(
        "Timer_1",
        0.9374963066200591,
    )
    timers_0.add(
        "Timer_1",
        0.7190347905240614,
    )
    timers_0.add(
        "Timer_1",
        0.12576334995092628,
    )

# Generated at 2022-06-25 15:21:16.835508
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Test case 0
    timers_0 = Timers()

    timers_0.add('test_1', 1.00)
    timers_0.add('test_1', 2.00)
    timers_0.add('test_1', 3.00)
    timers_0.add('test_1', 4.00)
    timers_0.add('test_1', 5.00)

    # Test case 1
    timers_1 = Timers()

    # Test case 2
    timers_2 = Timers()
    timers_2.add('test_1', 1.00)

    # Test case 3
    timers_3 = Timers()
    timers_3.add('test_1', 1)
    timers_3.add('test_1', 2)
    timers_3.add('test_1', 3)
   

# Generated at 2022-06-25 15:21:26.606197
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('a', 1)
    timers_0.add('a', 2)
    assert timers_0.max('a') == 2, "Value timer_0.max('a') has not changed."
    assert timers_0.count('a') == 2, "Value timer_0.count('a') has not changed."
    assert timers_0.total('a') == 3, "Value timer_0.total('a') has not changed."
    #print(timers_0)


# Generated at 2022-06-25 15:21:29.564915
# Unit test for method max of class Timers
def test_Timers_max():
    """Test method max of class Timers"""
    timers = Timers()
    timers.add("Timer 1", 0.9)
    timers.add("Timer 1", 0.1)
    timers.add("Timer 1", 0.2)
    result = timers.max("Timer 1")
    assert result == 0.9
