

# Generated at 2022-06-25 15:11:39.029364
# Unit test for method max of class Timers
def test_Timers_max():
    str_0 = 'name'
    timers_0 = Timers()
    # Check if the method throws an exception
    try:
        timers_0.max(str_0)
        assert True
    except KeyError:
        assert False


# Generated at 2022-06-25 15:11:42.668784
# Unit test for method max of class Timers
def test_Timers_max():
    str_0 = 'name'
    timers_0 = Timers()
    timers_0.add(str_0, 1.0)
    test_value_0 = timers_0.max(str_0)
    assert test_value_0 == 1


# Generated at 2022-06-25 15:11:46.221085
# Unit test for method mean of class Timers
def test_Timers_mean():
    str_0 = 'name'
    timers_0 = Timers()
    value = 2.5;
    timers_0.add(str_0, value)
    timers_0.add(str_0, value)
    timers_0.add(str_0, value)
    timers_0.add(str_0, value)
    # Assert
    assert(timers_0.mean(str_0) == value)


# Generated at 2022-06-25 15:11:48.837905
# Unit test for method median of class Timers
def test_Timers_median():
    str_1 = 'name'
    timers_1 = Timers()
    float_0 = timers_1.median(str_1)
    assert float_0 == 0


# Generated at 2022-06-25 15:11:57.475269
# Unit test for method median of class Timers
def test_Timers_median():
    # Case0: no values
    str_0, timers_0 = [], Timers()
    assert timers_0.median(str_0) == 0.0

    # Case1: 1 value
    str_1, timers_1 = [], Timers()
    timers_1.add(str_1, 1.0)
    assert timers_1.median(str_1) == 1.0

    # Case2: 2 values
    str_2, timers_2 = [], Timers()
    timers_2.add(str_2, 1.0)
    timers_2.add(str_2, 5.0)
    assert timers_2.median(str_2) == 3.0

    # Case3: odd number of values
    str_3, timers_3 = [], Timers()
    timers_

# Generated at 2022-06-25 15:12:03.510713
# Unit test for method median of class Timers
def test_Timers_median():
    str_0 = 'name'
    timers_0 = Timers()
    timers_0.add(str_0, 1.0)
    timers_0.add(str_0, 9.0)
    timers_0.add(str_0, 9.0)
    timers_0.add(str_0, 9.0)
    timers_0.add(str_0, 9.0)
    timers_0.add(str_0, 9.0)
    timers_0.add(str_0, 9.0)
    timers_0.add(str_0, 9.0)
    timers_0.add(str_0, 9.0)
    timers_0.add(str_0, 9.0)
    float_0 = timers_0.median(str_0)
    assert float_

# Generated at 2022-06-25 15:12:05.620903
# Unit test for method mean of class Timers
def test_Timers_mean():
    str_0 = 'name'
    timers_0 = Timers()
    assert timers_0.mean(str_0) == 0.0


# Generated at 2022-06-25 15:12:08.267413
# Unit test for method max of class Timers
def test_Timers_max():
    str_0 = 'name'
    timers_0 = Timers()
    timers_0.add(str_0, 75649.8787807)
    test = timers_0.max(str_0)
    assert test == 75649.8787807



# Generated at 2022-06-25 15:12:16.359950
# Unit test for method mean of class Timers
def test_Timers_mean():
    str_0 = 'name'
    timers_0 = Timers()
    timers_0.add('name', 0.333912)
    timers_0.add('name', 0.333912)
    timers_0.add('name', 0.333912)
    timers_0.add('name', 0.333912)
    timers_0.add('name', 0.333912)
    timers_0.add('name', 0.333912)
    timers_0.add('name', 0.333912)
    timers_0.add('name', 0.333912)
    timers_0.add('name', 0.333912)
    timers_0.add('name', 0.333912)
    mean_0 = timers_0.mean('name')

# Generated at 2022-06-25 15:12:21.225567
# Unit test for method mean of class Timers
def test_Timers_mean():
    TIMINGS_0 = {'x': [1.0, 2.0], 'y': [10.0, 11.0]}
    timers_0 = Timers(TIMINGS_0)
    name_0 = 'x'
    value_0 = timers_0.mean(name_0)
    assert "%.6f" % (value_0) == '1.500000'


# Generated at 2022-06-25 15:12:25.929856
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert timers_0.median(0) == 0



# Generated at 2022-06-25 15:12:31.510674
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    timers_1.add('test_1', 1.0)
    timers_1.add('test_2', 2.0)
    timers_1.add('test_3', 3.0)

    assert (timers_1.max('test_3') == 3.0)
    assert (timers_1.max('test_2') == 2.0)
    assert (timers_1.max('test_1') == 1.0)
    try:
        timers_1.max('test_4')
        assert False
    except KeyError:
        pass


# Generated at 2022-06-25 15:12:35.024865
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert type(timers_0.min("key_0")) == float


# Generated at 2022-06-25 15:12:40.553385
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("key_0", (1.65))
    timers_0.add("key_0", (0.29))
    timers_0.add("key_0", (2.01))
    timers_0.add("key_0", (1.74))
    assert timers_0.min("key_0") == 0.29


# Generated at 2022-06-25 15:12:41.419475
# Unit test for method median of class Timers
def test_Timers_median():
    pass


# Generated at 2022-06-25 15:12:49.969976
# Unit test for method median of class Timers
def test_Timers_median():

    timers_0 = Timers()
    
    # Try to read a timer that doesn't exist.
    #
    # This raises an exception.
    try:
        timers_0.median("timer-0")
        raise Exception("Unreachable")
    except KeyError:
        pass
    
    # Add a timing value of 1 to the timer.
    timers_0.add("timer-0", 1)
    value_1 = 1
    
    # Check that the median of the timer is 1
    assert math.isclose(timers_0.median("timer-0"), value_1, rel_tol=1.0e-06)
    
    # Add a timing value of 3 to the timer.
    timers_0.add("timer-0", 3)
    value_1 = 2
    
    # Check that the

# Generated at 2022-06-25 15:12:51.584549
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()

    assert(timers_0.max("total_program_time") == 0)


# Generated at 2022-06-25 15:12:53.288781
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name = ""
    value = timers_0.mean(name)
    assert [name, value] == [name, value]



# Generated at 2022-06-25 15:13:03.184086
# Unit test for method min of class Timers
def test_Timers_min():
    # Init
    timers_0 = Timers()
    # Assert
    e_0 = KeyError()
    try:
        timers_0.min("1")
        assert False
    except KeyError as e_0:
        assert e_0.args[0] == "1"
    # Assert
    timers_0.add("1", 2)
    # Assert
    assert timers_0.min("1") == 2
    # Assert
    timers_0.add("1", 3)
    # Assert
    assert timers_0.min("1") == 2
    # Assert
    timers_0.add("1", 1)
    # Assert
    assert timers_0.min("1") == 1


# Generated at 2022-06-25 15:13:07.789147
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('k', 1.0)
    assert timers_0.max('k') == 1.0
    timers_0.add('k', 2.0)
    assert timers_0.max('k') == 2.0
    timers_0.add('k', 1.0)
    assert timers_0.max('k') == 2.0


# Generated at 2022-06-25 15:13:11.785208
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert_equal(timers_0.max("name"), 0)


# Generated at 2022-06-25 15:13:20.466411
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('case0:test_Timers_mean', float(0.25))
    timers_0.add('case0:test_Timers_mean', float(0.25))
    timers_0.add('case0:test_Timers_mean', float(0.25))
    timers_0.add('case0:test_Timers_mean', float(5.6))
    assert math.isclose(timers_0.mean('case0:test_Timers_mean'), float(1.8), rel_tol=1e-05)



# Generated at 2022-06-25 15:13:28.863856
# Unit test for method max of class Timers
def test_Timers_max():
  # Create a new instance of the Timers class
  # with initial data {'foo': 123, 'bar': 456}
  timers_0 = Timers({'foo': 123, 'bar': 456})
  # Perform some tests
  timers_0.add('foo', 0.1)
  timers_0.add('bar', 0.1)
  timers_0.add('bar', 0.2)
  assert timers_0.max('bar') == 0.2
  assert timers_0.max('foo') == 0.1


# Generated at 2022-06-25 15:13:32.694811
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    name_0 = "a"
    value_0 = 1.0
    timers_0.add(name_0, value_0)
    assert_float(timers_0.median("a"), 1.0)


# Generated at 2022-06-25 15:13:38.711262
# Unit test for method mean of class Timers
def test_Timers_mean():
    """The mean of (2, 3, 4, 5) is 3.5"""
    timers_0 = Timers()
    timers_0.add('foo', 2)
    timers_0.add('foo', 3)
    timers_0.add('foo', 4)
    assert timers_0.mean('foo') == 3.5


# Generated at 2022-06-25 15:13:43.591762
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1.add("call_measurement_method", 100)

    # Case 0: "call_measurement_method" does not exist
    assert timers_1.min("call_measurement_method_does_not_exist") == 0

    # Case 1: "call_measurement_method" exists
    assert timers_1.min("call_measurement_method") == 100


# Generated at 2022-06-25 15:13:54.047527
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('timer_0', 0.6)
    timers_0.add('timer_0', 0.6)
    timers_0.add('timer_0', 0.6)
    timers_0.add('timer_0', 0.6)
    timers_0.add('timer_0', 0.6)
    timers_0.add('timer_0', 0.6)
    timers_0.add('timer_0', 0.6)
    timers_0.add('timer_0', 0.6)
    timers_0.add('timer_0', 0.6)
    timers_0.add('timer_0', 0.6)
    timers_0.add('timer_0', 0.6)

# Generated at 2022-06-25 15:14:01.924858
# Unit test for method max of class Timers
def test_Timers_max():
    # Create the timers object
    timers_0 = Timers()
    # Create dict to initialize timers object
    dict_0 = dict()
    dict_0['foo'] = 1
    # Init the timers object
    timers_0.data = dict_0
    # Get the maximum value of the timer named foo from the timers object
    timer_max_0 = timers_0.max('foo')
    # Assert that the maximum value of the timer foo is 1
    assert timer_max_0 == 1

# Generated at 2022-06-25 15:14:10.464094
# Unit test for method max of class Timers

# Generated at 2022-06-25 15:14:13.040641
# Unit test for method min of class Timers
def test_Timers_min():
    """Test for method min of class Timers"""
    timers_0 = Timers()
    timers_0.add("value", 0.0)
    assert timers_0.min("value") == 0.0


# Generated at 2022-06-25 15:14:17.500560
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("updates", 0.0)
    assert timers_0.mean("updates") == 0.0



# Generated at 2022-06-25 15:14:21.846010
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    expected_0 = math.nan
    assert timers_0.median("name_0") == expected_0


# Generated at 2022-06-25 15:14:23.349177
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    value = timers_0.max("min")


# Generated at 2022-06-25 15:14:28.272544
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Make an empty timers object
    timers_13 = Timers()


    # Check the exception gets thrown
    error_caught_15 = False
    try:
        timers_13.mean('t1')
    except KeyError:
        error_caught_15 = True

    if not error_caught_15:
        raise RuntimeError('Expected KeyError to be thrown')


# Generated at 2022-06-25 15:14:36.727146
# Unit test for method mean of class Timers
def test_Timers_mean():
    r"""Test Timers.mean() method"""

    timers = Timers()

    # Add 5 timings
    timers.add("foo", 10)
    timers.add("foo", 20)
    timers.add("foo", 30)
    timers.add("foo", 40)
    timers.add("foo", 50)
    assert timers.mean("foo") == 30

    # Add 0.10us timing
    timers.add("bar", 0.1e-6)
    assert timers.mean("bar") == 0.1e-6

    # Add 0.10us timings
    timers.add("baz", 0.1e-6)
    timers.add("baz", 0.1e-6)
    timers.add("baz", 0.1e-6)

# Generated at 2022-06-25 15:14:41.491149
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('a', (1))
    assert timers_0.mean('a') == 1
    timers_1 = Timers()
    timers_1.add('a', (1))
    timers_1.add('b', (2))
    timers_1.add('c', (3))
    assert timers_1.mean('a') == 1
    assert timers_1.mean('b') == 2
    assert timers_1.mean('c') == 3
    assert timers_1.mean('d') == 0


# Generated at 2022-06-25 15:14:43.684959
# Unit test for method min of class Timers
def test_Timers_min():
    d = Timers()
    d["b"] = 2
    d["a"] = 1
    d["c"] = 3
    assert d.min("a") == 1
    assert d.min("b") == 2
    assert d.min("c") == 3

# Generated at 2022-06-25 15:14:48.638878
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    for _ in range(122):
        timers_0.add("test_0", 0.14644)
    timers_0.add("test_1", 0.07698)
    assert timers_0.median("test_0") == 0.14644



# Generated at 2022-06-25 15:14:53.340056
# Unit test for method max of class Timers
def test_Timers_max():
    """ValueError"""
    timers_0 = Timers()
    try:
        timers_0.max(name="")
        raise ValueError("timers_0.min(\'\')")
    except KeyError as ex:
        if not str(ex).startswith("''"):
            raise ValueError(f"Invalid exception message {str(ex)}")


# Generated at 2022-06-25 15:14:55.298341
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    max_1 = timers_0.max('5e5')
    assert max_1 is 0


# Generated at 2022-06-25 15:15:05.679575
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert timers_0.median('__main__.function') == 0.0
    timers_0.add('__main__.function', -1.0)
    assert timers_0.median('__main__.function') == -1.0
    timers_0.add('__main__.function', 0.0)
    assert timers_0.median('__main__.function') == 0.0
    timers_0.add('__main__.function', 0.0)
    assert timers_0.median('__main__.function') == 0.0
    timers_0.add('__main__.function', 1.0)
    assert timers_0.median('__main__.function') == 0.0

# Generated at 2022-06-25 15:15:16.526470
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("key_0", -1.0)
    timers_0.add("key_0", -1.0)
    timers_0.add("key_0", -1.0)
    timers_0.add("key_0", -1.0)
    timers_0.add("key_0", -1.0)
    timers_0.add("key_0", -1.0)
    timers_0.add("key_0", -1.0)
    timers_0.add("key_0", -1.0)
    timers_0.add("key_0", -1.0)
    timers_0.add("key_0", -1.0)
    timers_0.add("key_0", -1.0)
    timers_

# Generated at 2022-06-25 15:15:18.800063
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert timers_0.mean('name_0') == 0.0
    timers_0.add( 'name_0', 1.0)
    assert timers_0.mean('name_0') == 1.0
    timers_0.add( 'name_0', 1.0)
    assert timers_0.mean('name_0') == 1.0


# Generated at 2022-06-25 15:15:22.907001
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('timer_0', 2)
    timers_0.add('timer_0', 1)
    timers_0.add('timer_0', 3)
    timers_0.add('timer_0', 4)
    assert timers_0.min('timer_0') == 1


# Generated at 2022-06-25 15:15:25.889452
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.max("y_z_0") == float("inf")
    assert type(timers_0.max("y_z_0")) is float


# Generated at 2022-06-25 15:15:31.838721
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("timer_0_0", 0.0)
    timers_0.add("timer_0_1", 5.0)
    timers_0.add("timer_0_2", 1.0)
    timers_0.add("timer_0_3", 6.0)
    assert timers_0.max("timer_0_1") == 5.0


# Generated at 2022-06-25 15:15:40.138148
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add("tst", 2)
    timers_1.add("tst", 4)
    timers_1.add("tst", 4)
    timers_1.add("tst", 4)
    timers_1.add("tst", 5)
    timers_1.add("tst", 5)
    timers_1.add("tst", 7)
    timers_1.add("tst", 9)

    assert timers_1.mean("tst") == 5


# Generated at 2022-06-25 15:15:43.791019
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add("test_name", 1.0)
    timers_1.add("test_name", 2.0)
    timers_1.add("test_name", 3.0)
    timers_1.mean("test_name")


# Generated at 2022-06-25 15:15:52.924569
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("key_1", 0.06092788)
    timers_0.add("key_0", 0.61841738)
    timers_0.add("key_1", 0.04915134)
    timers_0.add("key_1", 0.03516999)
    timers_0.add("key_1", 0.0886304)
    timers_0.add("key_1", 0.49611334)
    timers_0.add("key_1", 0.01743667)
    timers_0.add("key_1", 0.02047179)
    timers_0.add("key_1", 0.12851611)
    timers_0.add('key_2', 0.12882720)
    timers_0

# Generated at 2022-06-25 15:15:56.839807
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("name_0", 1.1)
    timers_0.add("name_0", 2.2)
    timers_0.add("name_0", 2.2)
    assert 1.1 == timers_0.median("name_0")

# Generated at 2022-06-25 15:16:02.991244
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    result_mul = timers_0.min(name='name_02')



# Generated at 2022-06-25 15:16:05.898058
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    # TypeError: 'int' object is not subscriptable
    with pytest.raises(TypeError):
        timers_0.min(0)


# Generated at 2022-06-25 15:16:08.289281
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add(name="", value=0.0)
    value = timers_0.median(name="")
    print(value)


# Generated at 2022-06-25 15:16:16.873199
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("B|>`;*(%$#", -0.25750217)
    timers_0.add("]O&tb", 0.42095518)
    timers_0.add("]O&tb", 0.7461801)
    timers_0.add("]O&tb", -0.78709966)
    timers_0.add("B|>`;*(%$#", 0.09044659)
    timers_0.add("B|>`;*(%$#", 0.90109446)
    timers_0.add("B|>`;*(%$#", 0.7956021)
    timers_0.add("]O&tb", 0.936268)

# Generated at 2022-06-25 15:16:23.437792
# Unit test for method max of class Timers
def test_Timers_max():
    timers_4 = Timers()
    name = 'name'
    assert timers_4.max(name) == 0.0
    timers_4.add(name, 1.0, )
    assert timers_4.max(name) == 1.0
    timers_4.add(name, 2.0, )
    assert timers_4.max(name) == 2.0


# Generated at 2022-06-25 15:16:29.317702
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("duration", 0.0)
    timers_0.add("duration", 1.0)
    timers_0.add("duration", 2.0)
    timers_0.add("duration", 3.0)
    timers_0.add("duration", 4.0)
    assert timers_0.max("duration") == 4.0


# Generated at 2022-06-25 15:16:35.742822
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("name", 1.1)
    timers_0.add("name", 2.2)
    timers_0.add("name", 3.3)
    assert math.isclose(timers_0.median("name"), 2.2, rel_tol=1e-15)


# Generated at 2022-06-25 15:16:39.555481
# Unit test for method max of class Timers
def test_Timers_max():
    # Initiate Timers
    timers_0 = Timers()
    # Add timing to Timers
    timers_0.add('a', 0.0002497818)
    # Get maximum value of Timers
    timers_0.max('a') == 0.0002497818


# Generated at 2022-06-25 15:16:42.414516
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name = str()
    value = float()
    timers_0.add(name, value)
    float_0 = timers_0.min(name)
    assert isinstance(float_0, float)


# Generated at 2022-06-25 15:16:45.769382
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("name_0", 0.2)  # Add timing to timer
    assert timers_0.min("name_0") == 0.2


# Generated at 2022-06-25 15:16:53.746584
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    for x in range(0, 10, 1):
        timers_0.add("key_0", 0.0)
    timers_0.min("key_0")


# Generated at 2022-06-25 15:16:56.172661
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    timers_1.add("timer_1", 0.4)
    assert timers_1.max("timer_1") == 0.4, "max timer_1"


# Generated at 2022-06-25 15:17:06.930663
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('S', 0.0)
    timers_0.add('M', 0.0)
    timers_0.add('M', 0.0)
    timers_0.add('M', 0.0)
    timers_0.add('M', 0.0)
    timers_0.add('M', 0.0)
    timers_0.add('M', 0.0)
    timers_0.add('M', 0.0)
    timers_0.add('M', 0.0)
    timers_0.add('M', 0.0)
    timers_0.add('M', 0.0)
    timers_0.add('M', 0.0)
    timers_0.add('M', 0.0)

# Generated at 2022-06-25 15:17:15.344632
# Unit test for method min of class Timers
def test_Timers_min():
    import random
    timers = Timers()
    for _ in range(10):
        timers.add("Series", random.random() * 5)
    assert timers.min("Series") > 0, "The minimum value of the Series is greater than 0"
    assert timers.min("Series") <= 5, "The minimum value of the Series is less than 5"
    assert timers["Series"] > 0, "The sum of the Series is greater than 0"
    assert timers["Series"] <= 50, "The sum of the Series is less than 50"
    assert timers.mean("Series") > 0, "The mean value of the Series is greater than 0"
    assert timers.mean("Series") <= 5, "The mean value of the Series is less than 5"
    assert timers.median("Series") > 0, "The median value of the Series is greater than 0"
   

# Generated at 2022-06-25 15:17:17.581628
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name: str = 'e'
    exc_0 = None
    try:
        timers_0.max(name)
    except Exception as err:
        exc_0 = err
    assert exc_0 is not None


# Generated at 2022-06-25 15:17:20.220669
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert timers_0.median('primes') == 0.0


# Generated at 2022-06-25 15:17:32.660213
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    int_0 = 1
    float_0 = 1.0
    str_0 = "1.0"
    bool_0 = bool(str_0)
    # str_1 = string()
    # float_1 = float()
    # int_1 = int()
    # bool_1 = bool()
    try:
        timers_0.add(name="s", value=float_0)
    except KeyError:
        pass
    # try:
    #     timers_0.__setitem__(key="s", value=str_0)
    # except KeyError:
    #     pass
    # timers_0.__init__()
    # timers_0.apply(func=float_0, name="d")
    # timers_0.clear()
    # timers_0

# Generated at 2022-06-25 15:17:37.849935
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('timers', 1)
    timers.add('timers', 2)
    timers.add('timers', 3)
    timers.add('timers', 4)
    assert math.isclose(timers.min('timers'), 1, rel_tol=1e-07, abs_tol=0.0)


# Generated at 2022-06-25 15:17:41.352288
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('timer_0', 4.0)
    assert timers_0.mean('timer_0') == 4.0
    assert timers_0.mean('timer_1') == 0.0

# Generated at 2022-06-25 15:17:48.110796
# Unit test for method max of class Timers
def test_Timers_max():
    timer = Timers()
    timer.clear()
    timer.add(name='timer_0', value=1.0)
    timer.add(name='timer_1', value=2.0)
    timer.add(name='timer_2', value=3.0)
    timer.add(name='timer_3', value=4.0)
    assert timer.max(name='timer_3') == 4.0


# Generated at 2022-06-25 15:17:58.560008
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("b", 0.0)
    timers_0.add("b", 0.0)
    timers_0.add("a", -1.0)
    timers_0.add("c", 0.0)
    timers_0.add("c", 0.0)
    timers_0.add("a", 1.0)

    assert timers_0.min("b") == 0.0
    assert timers_0.min("a") == -1.0
    assert timers_0.min("c") == 0.0


# Generated at 2022-06-25 15:18:01.273512
# Unit test for method max of class Timers
def test_Timers_max():
    """
    Timers.max(self, name)
    """
    # Initialization
    timers = Timers()
    name = 'test'
    for i in range(0, 10):
        timers.add(name, i)
        assert timers.max(name) == i

# Generated at 2022-06-25 15:18:10.123062
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.data["test"] = 0.0
    timers_0._timings["test"] = [0.0]
    timers_0.data["test"] = 1.0
    timers_0.data["test"] += 1.0
    timers_0.data["test"] += 1.0
    timers_0.data["test"] += 1.0
    timers_0.data["test"] += 1.0
    timers_0.data["test"] += 1.0
    timers_0.data["test"] += 1.0
    assert timers_0.min("test") == 1.0


# Generated at 2022-06-25 15:18:19.329565
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert (math.isnan(timers_0.mean(name = "mean_0")) == True)
    assert (math.isnan(timers_0.mean(name = "mean_1")) == True)
    assert (math.isnan(timers_0.mean(name = "mean_2")) == True)
    timers_0.add(name = "mean_0", value = 2)
    assert (math.isnan(timers_0.mean(name = "mean_0")) == False)
    assert (math.isnan(timers_0.mean(name = "mean_1")) == True)
    assert (math.isnan(timers_0.mean(name = "mean_2")) == True)

# Generated at 2022-06-25 15:18:22.178502
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    try:
        name = "name"
        timers_0.add(name, 0.0)

    except KeyError:
        pass
    timers_0.mean(name)


# Generated at 2022-06-25 15:18:23.969496
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name_0 = ''
    r_0 = timers_0.max(name_0)
    assert r_0 == 0


# Generated at 2022-06-25 15:18:26.351209
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name = 'string_0'
    value = 1.0

    timers_0.add(name, value)

    assert timers_0.mean(name) == 1.0


# Generated at 2022-06-25 15:18:36.001251
# Unit test for method median of class Timers
def test_Timers_median():
    timers_4 = Timers()
    timers_4.add('key_0', 1)
    timers_4.add('key_0', 3)
    timers_4.add('key_0', 2)
    timers_4.add('key_1', 0)
    timers_4.add('key_1', 2)
    timers_4.add('key_2', 5)
    timers_4.add('key_2', 2)
    timers_4.add('key_2', 3)
    timers_4.add('key_3', 2)
    timers_4.add('key_3', 2)
    assert timers_4.median('key_0') == 2
    assert timers_4.median('key_1') == 1
    assert timers_4.median('key_2') == 3

# Generated at 2022-06-25 15:18:37.986483
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    result = timers_0.median("name")
    assert result == 0.0

# Generated at 2022-06-25 15:18:41.674747
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_0 = ""
    try:
        timers_0.mean(name_0)
    except KeyError as e:
        assert isinstance(e, KeyError)
    else:
        raise Exception("Unexpected exception")


# Generated at 2022-06-25 15:18:55.447721
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("key_0", 98.44)
    timers_0.add("key_0", 65.91)
    timers_0.add("key_0", 12.11)
    timers_0.add("key_0", 91.83)
    timers_0.add("key_0", 49.71)
    timers_0.add("key_0", 49.71)
    timers_0.add("key_0", 14.25)
    assert timers_0.min("key_0") == 12.11



# Generated at 2022-06-25 15:18:59.319205
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    name_1 = 'name_1'
    value_1 = 0.1
    timers_1.add(name=name_1, value=value_1)
    assert timers_1.max(name=name_1) == value_1


# Generated at 2022-06-25 15:19:08.034649
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("fqx_zm_timers_0_median_0", 0.0311)
    timers_0.add("fqx_zm_timers_0_median_0", 0.0352)
    timers_0.add("fqx_zm_timers_0_median_0", 0.0328)
    timers_0.add("fqx_zm_timers_0_median_0", 0.0358)
    timers_0.add("fqx_zm_timers_0_median_0", 0.0316)
    timers_0.add("fqx_zm_timers_0_median_0", 0.0311)

# Generated at 2022-06-25 15:19:15.434861
# Unit test for method max of class Timers
def test_Timers_max():
    # Empty
    timers_0 = Timers()
    assert 0 == timers_0.max('name_0')
    # Non-empty
    timers_0.add('name_0', 0.5734656528467639)
    timers_0.add('name_0', 0.8647431287970444)
    timers_0.add('name_0', 0.7022508894746659)
    assert 0.8647431287970444 == timers_0.max('name_0')


# Generated at 2022-06-25 15:19:18.506281
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("key_22882", 0.0)
    timers_0.add("key_22882", 0.0)
    timers_0.add("key_22882", 0.0)
    timers_0.max("key_22882")


# Generated at 2022-06-25 15:19:22.206139
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    name_0 = str()
    value = timers_0.median(name_0)
    assert value == 0.0, "Returned: %s, Expected: %s" % (value, 0.0)


# Generated at 2022-06-25 15:19:24.864967
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    for i in range(10):
        timers.add("f", i)
    assert timers.min("f") == 0
    assert math.isnan(timers.min("g"))

# Generated at 2022-06-25 15:19:26.804394
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert(timers_0.mean("time") == 0.0)


# Generated at 2022-06-25 15:19:28.225468
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert timers_0.min('a') == 0.0


# Generated at 2022-06-25 15:19:31.132139
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()

    # Test method of class Timers

    # Test case Timers_max_test_case_0
    timers_0 = Timers()

    # Test case Timers_max_test_case_1
    timers_0 = Timers()



# Generated at 2022-06-25 15:19:49.735578
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("key_0", 0.05)
    timers_0.add("key_0", 0.12)
    timers_0.add("key_0", 0.0)
    timers_0.add("key_0", 0.1)
    timers_0.add("key_1", 0.44)
    timers_0.add("key_1", 0.03)
    timers_0.add("key_1", 0.31)
    timers_0.add("key_1", 0.54)
    timers_0.add("key_2", 0.31)
    timers_0.add("key_2", 0.31)
    timers_0.add("key_3", 0.37)

# Generated at 2022-06-25 15:19:57.015255
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('bar', 0.5)
    timers_0.add('bar', 0.5)
    timers_0.add('bar', 0.5)

    # median(foo)
    try:
        assert timers_0.median('foo') == 0.5
        assert False, 'unexpected result'
    except KeyError as e:
        assert str(e) == "'foo'"

    # median(bar)
    assert timers_0.median('bar') == 0.5


# Generated at 2022-06-25 15:20:02.453161
# Unit test for method min of class Timers
def test_Timers_min():
    """Tests min method of class Timers"""
    timers = Timers()
    timers.data.update({'a': 10, 'b': 8, 'c': 12})
    timers._timings.update({'a': [1, 2, 3, 4, 5], 'b': [6, 7, 8], 'c': [9, 10, 11, 12]})
    assert timers.min('a') == min([1, 2, 3, 4, 5])
    assert timers.min('b') == min([6, 7, 8])
    assert timers.min('c') == min([9, 10, 11, 12])


# Generated at 2022-06-25 15:20:11.237516
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert timers_0.min("name_0") == 0
    timers_0.add("name_0", 2.5)
    assert timers_0.min("name_0") == 2.5
    timers_0.add("name_1", 2.5)
    assert timers_0.min("name_1") == 2.5
    timers_0.add("name_0", -1.0)
    assert timers_0.min("name_0") == -1.0
    timers_0.add("name_1", 1.5)
    assert timers_0.min("name_1") == 1.5
    print("Passed!")


# Generated at 2022-06-25 15:20:12.556005
# Unit test for method mean of class Timers
def test_Timers_mean():
    """mean returns the arithmetic mean of contained values"""
    timers_0 = Timers()
    name = str()
    result = timers_0.mean(name)


# Generated at 2022-06-25 15:20:14.347669
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0_expected = 0
    assert timers_0.min("") == timers_0_expected


# Generated at 2022-06-25 15:20:21.956770
# Unit test for method median of class Timers
def test_Timers_median():
    Timers_0 = Timers()
    Timers_0.add("key0", -0.3668122327807797)
    Timers_0.add("key0", 0.3339342114099035)
    Timers_0.add("key0", -0.42652044241813194)
    Timers_0.add("key0", 0.7359294723158292)
    Timers_0.add("key0", 0.35839947698849024)
    Timers_0.add("key0", 0.06472165710211229)
    Timers_0.add("key0", 0.0916894458293824)
    Timers_0.add("key0", -0.38729157780997504)
    Timers

# Generated at 2022-06-25 15:20:27.276986
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("my_timer", 15.0)
    assert(timers_0.max("my_timer") == 15.0)

# Generated at 2022-06-25 15:20:29.100805
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("a", 9)
    timers_0.add("a", 6)
    assert timers_0.min("a") == 6
    assert timers_0.total("a") == 15


# Generated at 2022-06-25 15:20:32.642961
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.data = collections.defaultdict(None, {'a': 2.0})
    timers_0._timings = collections.defaultdict(list, {'b': [1.0, 3.0]})
    timers_0.min(name='b')


# Generated at 2022-06-25 15:20:44.849336
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name = None
    timers_0.min(name)


# Generated at 2022-06-25 15:20:46.830424
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    value_0 = timers_0.median(name = "c")


# Generated at 2022-06-25 15:20:54.568219
# Unit test for method max of class Timers
def test_Timers_max():
    """Test Timers.max()"""
    timers_0 = Timers()
    timers_0.add("name_0", value=0)
    timers_0.add("name_0", value=0.0)
    timers_0.add("name_0", value=1577890)
    timers_0.add("spam", value=0)
    timers_0.add("spam", value=0.0)
    timers_0.add("spam", value=1577890)
    timers_0.add("spam", value=1577890)
    max_0 = timers_0.max("name_0")
    assert round(max_0, 6) == 0.0
    max_1 = timers_0.max("spam")
    assert round(max_1, 6) == 1577890.0

# Generated at 2022-06-25 15:20:59.110271
# Unit test for method median of class Timers
def test_Timers_median():
    # Setup
    timers_1 = Timers()
    timers_1.add('test', 1.0)
    timers_1.add('test', 3.0)
    timers_1.add('test', 2.0)

    # Execute
    median_1 = timers_1.median('test')

    # Assert
    assert median_1 == 2.0


# Generated at 2022-06-25 15:21:01.424423
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.add("data", 1)
    ret_1 = timers_1.median("data")
    assert ret_1 == 1


# Generated at 2022-06-25 15:21:05.915763
# Unit test for method mean of class Timers
def test_Timers_mean():
    # assignment statements
    timers = Timers()
    name = str()

    # Unit test
    try:
        timers.mean(name)
    except Exception:
        raise


if __name__ == "__main__":
    # Developpement
    print("Testing development")
    for test in [test_case_0]:
        test()
    # Unit tests
    print("Unit tests")
    for test in [
        test_Timers_mean,
    ]:
        test()

# Generated at 2022-06-25 15:21:06.601066
# Unit test for method median of class Timers
def test_Timers_median():
    assert Timers().app # cover



# Generated at 2022-06-25 15:21:08.258811
# Unit test for method min of class Timers
def test_Timers_min():
    assert Timers().min("this") == 0.
    assert Timers().min("this") == 0.
    assert Timers().max("this") == 0.



# Generated at 2022-06-25 15:21:15.830262
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('Timers_max', 0.0)
    timers_0.add('Timers_max', 0.0)
    timers_0.add('Timers_max', 0.0)
    timers_0.max('Timers_max')


# Generated at 2022-06-25 15:21:19.390362
# Unit test for method min of class Timers
def test_Timers_min():
    try:
        timers_1 = Timers()
        timers_1["test_0"] = 3.402823669209385e+38
        assert timers_1.min("test_0") == 3.402823669209385e+38
    except TypeError:
        pass
