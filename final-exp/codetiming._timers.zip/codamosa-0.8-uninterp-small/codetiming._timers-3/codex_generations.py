

# Generated at 2022-06-25 15:11:44.127549
# Unit test for method max of class Timers
def test_Timers_max():
    str_0 = '_M\r_0$B6`F>$NFseI'
    timers_0 = Timers()
    timers_0.add(str_0, 0.047)
    timers_0.add(str_0, 0.047)
    timers_0.add(str_0, 0.007)
    timers_0.add(str_0, 0.007)
    timers_0.add(str_0, 0.007)
    timers_0.add(str_0, 0.047)
    timers_0.add(str_0, 0.047)
    timers_0.add(str_0, 0.007)
    timers_0.add(str_0, 0.047)
    assert(timers_0.max(str_0) == 0.047)

#

# Generated at 2022-06-25 15:11:52.926126
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('B', 30.0)
    timers_0.add('B', 30.0)
    timers_0.add('A', 10.0)
    timers_0.add('B', 30.0)
    timers_0.add('C', 50.0)
    timers_0.add('A', 10.0)
    timers_0.add('C', 50.0)
    timers_0.add('B', 30.0)
    timers_0.add('C', 50.0)
    timers_0.add('A', 10.0)
    timers_0.add('A', 10.0)


# Generated at 2022-06-25 15:11:59.921979
# Unit test for method max of class Timers
def test_Timers_max():
    str_0 = '_M\r_0$B6`F>$NFseI'
    timers_0 = Timers()
    timers_0.data[str_0] = -6.092338591874385
    timers_0.add(str_0, -6.092338591874385)
    timers_0.add(str_0, -62.092338591874385)
    timers_0.data[str_0] -= 6.092338591874385
    timers_0.data[str_0] -= 6.092338591874385
    timers_0.data[str_0] -= -62.092338591874385
    timers_0.data[str_0] += 6.092338591874385

# Generated at 2022-06-25 15:12:04.666160
# Unit test for method max of class Timers
def test_Timers_max():
    str_0 = 'X`\x1d6U$(6MF:z\x7f\x18\x1d\x15\x1aFb\x1f\x15'
    str_1 = 'S\x0b'
    timers_0 = Timers()
    timers_0[str_0] = 0.6910738910397265
    timers_0[']\x18\x0f\x10\x1a\x06'.join(['\x1f\x1b', str_0])] = 0.6910738910397265
    timers_0[str_1.replace('\\', '%', 0)] = 0.6910738910397265
    timers_2 = Timers()
    timers_2[str_1] = 0.6910738910397265
    timers

# Generated at 2022-06-25 15:12:08.137041
# Unit test for method apply of class Timers
def test_Timers_apply():
    print("Testing method 'apply'...")
    
    timers = Timers()
    def f(values): return sum(values)
    name = "0"
    result = timers.apply(f, name)
    assert result == 0

    t = Timers()
    t.apply(lambda values : min(values or [0]) , "0")


# Generated at 2022-06-25 15:12:13.807216
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    str_0 = '[_M\r_0$B6`F>$NFseI'
    timers_0 = Timers()
    timers_0.add(str_0, 9.476857901972675e-07)
    timers_0.add(str_0, 1.605033950805664e-06)
    timers_0.add(str_0, 6.890296936035156e-07)
    timers_0.add(str_0, 1.1920928955078125e-07)
    timers_0.add(str_0, 1.1920928955078125e-07)
    timers_0.add(str_0, 1.1920928955078125e-07)

# Generated at 2022-06-25 15:12:16.170840
# Unit test for method apply of class Timers
def test_Timers_apply():
    str_0 = '$sGEt|@lpf&)#n-w>Bh@'
    timers_0 = Timers()
    assert False


# Generated at 2022-06-25 15:12:20.297886
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers_0 = Timers()
    str_0 = '_M\r_0$B6`F>$NFseI'
    for i in range(10):
        timers_0.add(str_0, 1)
    assert timers_0.stdev(str_0) == 0



# Generated at 2022-06-25 15:12:24.728735
# Unit test for method max of class Timers
def test_Timers_max():
    str_0 = '^D$SZ,:6G'
    dict_0 = {'foo': 100.0, 'bar': 200.0}
    timers_0 = Timers(dict_0)
    timers_0.data = dict_0
    assert 200.0 == timers_0.max('bar')


# Generated at 2022-06-25 15:12:31.886598
# Unit test for method stdev of class Timers
def test_Timers_stdev():
    timers_0 = Timers()
    timers_0.add('_M\r_0$B6`F>$NFseI', 8.377933491480558)
    timers_0.add('_M\r_0$B6`F>$NFseI', 5.306694808717118)
    timers_0.add('_M\r_0$B6`F>$NFseI', 7.146709987458821)
    timers_0.add('_M\r_0$B6`F>$NFseI', 6.155214145096565)
    timers_0.add('_M\r_0$B6`F>$NFseI', 5.083409826753832)

# Generated at 2022-06-25 15:12:41.499550
# Unit test for method min of class Timers
def test_Timers_min():
    # Setup
    timers_1 = Timers()

    # Exercise
    timers_1.add('foo', 2)
    timers_1.add('foo', 2)
    timers_1.add('bar', 2)
    min_foo = timers_1.min('foo')
    min_unknown = timers_1.min('unknown')
    # Verify
    assert min_foo == 2
    assert math.isnan(min_unknown)


# Generated at 2022-06-25 15:12:46.337376
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_1 = Timers()
    timers_0.data.setdefault("timer1", 10.00)
    timers_0.data.setdefault("timer2", 20.00)
    timers_1.data.setdefault("timer1", 10.00)
    timers_1.data.setdefault("timer2", 20.00)
    assert timers_0.max("timer2") is not timers_1.max("timer2")

# Generated at 2022-06-25 15:12:53.699288
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.data['key_1'] = 0.6944574905843436
    timers_0.data['key_0'] = 0.4040302095154126
    timers_0.data['key_2'] = 0.23492605185744558
    timers_0.data['key_4'] = 0.7985075397328159
    timers_0.data['key_3'] = 0.5125738477411217
    timers_0.data['key_5'] = 0.09953635779895018
    timers_0.data['key_7'] = 0.28353980821496736
    timers_0.data['key_6'] = 0.8838683971721444

# Generated at 2022-06-25 15:12:56.234019
# Unit test for method median of class Timers
def test_Timers_median():
    for _ in range(10):
        name = 'test'
        timers = Timers()
        timers.add(name, 0)
        timers.add(name, 2)
        timers.add(name, 1)
        assert timers.median(name) == 1
        timers.clear()


# Generated at 2022-06-25 15:12:59.805914
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("name", 1.0)
    timers_0.apply(lambda x: math.nan, name="name")
    timers_0.apply(lambda x: math.nan, name="name")
    value_0 = timers_0.mean("name")
    assert value_0 == math.nan



# Generated at 2022-06-25 15:13:03.242465
# Unit test for method mean of class Timers
def test_Timers_mean():
    item = Timers()
    try:
        assert item.mean(name) == float
        assert item.mean(name) >= 0
    except Exception:
        assert False, "Method mean may be not implemented correctly"
    assert True

# Generated at 2022-06-25 15:13:05.535034
# Unit test for method mean of class Timers
def test_Timers_mean():
    # ToDo: Add meaningfull test here
    timers_0 = Timers()
    name = ""
    timers_0.mean(name)


# Generated at 2022-06-25 15:13:09.219746
# Unit test for method min of class Timers
def test_Timers_min():
    # Parameters
    timers_0 = Timers()
    # Argument 1
    name_0 = "my_timer"
    timers_0.add(name_0, 1.1)
    assert 0.0 <= timers_0.min(name_0) <= 1.1


# Generated at 2022-06-25 15:13:11.576373
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert timers_0.median("name") == 0.0


# Generated at 2022-06-25 15:13:14.954906
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    float_0 = timers_0.median('median')
    assert math.isnan(float_0) is True


# Generated at 2022-06-25 15:13:19.126338
# Unit test for method max of class Timers
def test_Timers_max():
    print("test Timers.max")
    timers_1 = Timers()
    timers_1.add("time", 10)
    timers_1.add("time", 20)
    timers_1.add("time", 5)
    assert timers_1.max("time") == 20


# Generated at 2022-06-25 15:13:24.107566
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("test_0_0", 0.0)
    timers_0.add("test_0_1", 0.0)
    timers_0.add("test_0_2", 0.0)
    timers_0.add("test_0_3", 0.0)
    timers_0.add("test_0_4", 0.0)
    timers_0.add("test_0_5", 0.0)
    timers_0.add("test_0_6", 0.0)
    timers_0.add("test_0_7", 0.0)
    timers_0.add("test_0_8", 0.0)
    timers_0.add("test_0_9", 0.0)

# Generated at 2022-06-25 15:13:30.582359
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("timer_1", 2.1)
    timers.add("timer_2", 3.2)
    timers.add("timer_1", 2.8)
    timers.add("timer_2", 3.4)
    min_name_0 = timers.min("timer_2")
    min_name_1 = timers.min("timer_1")
    assert min_name_0 == 3.2
    assert min_name_1 == 2.1


# Generated at 2022-06-25 15:13:33.059793
# Unit test for method mean of class Timers
def test_Timers_mean():

    timers = Timers()
    timers.add('foo', 0.1)
    timers.add('bar', 0.2)
    timers.add('bar', 0.3)
    timers.add('foo', 0.4)
    timers.add('foo', 0.5)

    timers.mean('foo')
    timers.mean('bar')
    timers.mean('buzz')

# Generated at 2022-06-25 15:13:37.938763
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('timer_0', 0.0)
    timers.add('timer_0', 1.0)
    assert timers.median('timer_0') == 0.5


# Generated at 2022-06-25 15:13:40.352994
# Unit test for method min of class Timers
def test_Timers_min():

    timers_1 = Timers()
    timers_1.add('foo', 2.5)

    assert timers_1.min('foo') == 2.5


# Generated at 2022-06-25 15:13:44.097255
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("count", 10)
    assert(timers.max("count") == 10)
    timers.add("count", 20)
    assert(timers.max("count") == 20)
    timers.add("count", 5)
    assert(timers.max("count") == 20)



# Generated at 2022-06-25 15:13:48.161656
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add("rand1", 1.0)
    timers.add("rand1", 2.0)
    timers.add("rand2", 5.0)
    timers.add("rand1", 3.0)
    timers.add("rand2", 4.0)
    timers.add("rand3", 5.0)
    assert timers.mean("rand1") == 2.0
    assert timers.mean("rand2") == 4.5
    assert timers.mean("rand3") == 5.0
    assert timers.mean("rand4") == 0.0


# Generated at 2022-06-25 15:13:54.846004
# Unit test for method min of class Timers
def test_Timers_min():
    # Declarations
    timers_0 = Timers()
    name_0 = str()

    # Setup
    timers_0.add(name_0, 9.85588259394779e-13)
    timers_0.add(name_0, 9.85588259394779e-13)
    timers_0.add(name_0, 9.85588259394779e-13)
    timers_0.add(name_0, 9.85588259394779e-13)

    # Assertions
    assert timers_0.min(name_0) == 9.85588259394779e-13



# Generated at 2022-06-25 15:13:59.628210
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    assert timers.mean('A') == 0
    timers.add('A', 100)
    assert timers.mean('A') == 100
    timers.add('A', 200)
    assert timers.mean('A') == 150
    timers.add('A', 300)
    assert timers.mean('A') == 200



# Generated at 2022-06-25 15:14:05.155704
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.max(name='error_type') == 0.0
    assert timers_0.max(name='mean_time') == 0.0
    assert timers_0.max(name='time') == 0.0


# Generated at 2022-06-25 15:14:12.877991
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Case 0
    timers_0 = Timers()
    name_0 = 'test'
    assert math.isnan(timers_0.mean(name_0))

    # Case 1
    timers_0 = Timers()
    name_0 = ''
    assert math.isnan(timers_0.mean(name_0))

    # Case 2
    timers_0 = Timers()
    name_0 = 'test'
    timers_0.add(name_0, math.nan)
    assert math.isnan(timers_0.mean(name_0))

    # Case 3
    timers_0 = Timers()
    name_0 = 'test'
    timers_0.add(name_0, math.nan)
    timers_0.add(name_0, math.nan)

# Generated at 2022-06-25 15:14:21.638678
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1.add('timer_1_1', 1)
    assert timers_1.min('timer_1_1') == 1
    timers_1.add('timer_1_1', 2)
    assert timers_1.min('timer_1_1') == 1
    timers_1.add('timer_1_1', 99)
    assert timers_1.min('timer_1_1') == 1
    timers_1.add('timer_1_1', 0)
    assert timers_1.min('timer_1_1') == 0
    timers_1.add('timer_1_1', 1)
    assert timers_1.min('timer_1_1') == 0
    timers_1.add('timer_1_1', 2)

# Generated at 2022-06-25 15:14:27.239329
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('name', 0.01)
    timers_0.add('name', -1.0)
    timers_0.add('name', 0.04)
    timers_0.add('name', 0.07)
    timers_0.add('name', 1.0)
    assert timers_0.min('name') == -1.0
    assert timers_0.total('name') == 0.12000000000000002


# Generated at 2022-06-25 15:14:37.158589
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timer_name_1 = 'A'
    for value in [-1.0, 0.0, 1.0, 2.0]:
        timers_1.add(timer_name_1, value)
    assert timers_1.median(timer_name_1) == 0.0
    timer_name_2 = 'B'
    for value in [0.0, 0.0, 0.0, 0.0, 0.0]:
        timers_1.add(timer_name_2, value)
    assert timers_1.median(timer_name_2) == 0.0
    timer_name_3 = 'C'
    for value in range(100):
        timers_1.add(timer_name_3, value)

# Generated at 2022-06-25 15:14:40.594009
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('foo_timer', 0.1)
    timers_0.add('foo_timer', 0.3)
    timers_0.add('foo_timer', 0.2)

    assert 0.3 == timers_0.max('foo_timer')


# Generated at 2022-06-25 15:14:51.864320
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    # Testing the attribute name
    assert isinstance(timers_0.name, str)
    assert timers_0.name == "timers"
    # Testing the method min of class Timers
    timers_0.add("b", 2)
    timers_0.add("b", 2)
    assert isinstance(timers_0.min("b"), float)
    assert timers_0.min("b") == 2
    # Error testing
    try:
        timers_0.min("a")
        assert False, "Should cause KeyError exception"
    except KeyError:
        pass
    try:
        timers_0.min(1)
        assert False, "Should cause TypeError exception"
    except TypeError:
        pass



# Generated at 2022-06-25 15:14:59.676434
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    name = 'some_timer'
    assert math.isnan(timers_0.median(name))
    timers_0.add(name, 1)
    assert 1 == timers_0.apply(lambda values: statistics.median(values or [0]), name=name)
    timers_0.add(name, 2)
    assert 1.5 == timers_0.apply(lambda values: statistics.median(values or [0]), name=name)
    timers_0.add(name, 3)
    assert 2 == timers_0.apply(lambda values: statistics.median(values or [0]), name=name)


# Generated at 2022-06-25 15:15:02.808446
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("key_0", [-1, 0.0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    assert timers_0.min("key_0") == -1.0


# Generated at 2022-06-25 15:15:08.534779
# Unit test for method median of class Timers
def test_Timers_median():
    timings_0 = Timers()
    timings_0.add("blue", 4.9)
    timings_0.add("black", 5.2)
    timings_0.add("yellow", 5.0)
    timings_0.add("blue", 5.1)
    timings_0.add("blue", 4.9)
    timings_0.add("black", 5.0)
    timings_0.add("yellow", 4.9)
    timings_0.add("blue", 4.9)
    timings_0.add("blue", 5.0)
    timings_0.add("black", 5.0)
    timings_0.add("yellow", 5.0)
    timings_0.add("blue", 5.1)

# Generated at 2022-06-25 15:15:17.105751
# Unit test for method mean of class Timers
def test_Timers_mean():
    import doctest

    doctest.testmod(verbose=True)
    result = test_case_0()
    assert type(result) == Timers


if __name__ == "__main__":
    print(test_Timers_mean())

# Generated at 2022-06-25 15:15:19.181313
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert timers_0.mean("") == 0.0


# Generated at 2022-06-25 15:15:22.503996
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("KeyStr", 0.0)
    timers_0.add("KeyStr_1", 2.0)
    assert round(timers_0.mean("KeyStr_1"), 2) == 0.67


# Generated at 2022-06-25 15:15:25.642327
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add("test", 1)
    timers.add("test", 2)
    timers.add("test", 3)
    assert timers.median("test") == 2



# Generated at 2022-06-25 15:15:33.210066
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    try:
        timers_0.mean("tmr_0")
    except KeyError:
        pass
    timers_0.add("tmr_0", (2.03 + 0.21) * 2)
    assert timers_0.mean("tmr_0") == (2.03 + 0.21)
    timers_0.add("tmr_0", 2.03 + 0.21)
    assert timers_0.mean("tmr_0") == (2.03 + 0.21) / 2


# Generated at 2022-06-25 15:15:42.817576
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('x', 0.0)
    timers_0.add('x', 2.0)
    timers_0.add('y', 3.0)
    timers_0.add('y', 4.0)
    assert timers_0.min('x') == 0.0
    assert timers_0.min('y') == 3.0
    try:
        timers_0.min('z')
    except KeyError:
        assert True
    else:
        assert False
    try:
        del Timers()['x']
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 15:15:46.339935
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.data = {'test': 1}
    timers_0._timings = {'test': [1]}
    assert timers_0.mean('test') == 1


# Generated at 2022-06-25 15:15:54.325016
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("name", 1.6726)
    timers_0.add("name_0", 0.938)
    timers_0.add("name", 0.5039)
    timers_0.add("name_0", 0.9384)
    timers_0.add("name", 0.4204)
    timers_0.add("name_0", 0.9383)
    timers_0.add("name", 0.4204)
    timers_0.add("name_0", 0.9382)
    timers_0.add("name", 0.4204)
    timers_0.add("name_0", 0.9383)
    timers_0.add("name", 0.4204)

# Generated at 2022-06-25 15:16:02.824719
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("e", 1.1887806002381166)
    timers_0.add("e", 0.3892756179019912)
    timers_0.add("e", 0.9262267137968645)
    timers_0.add("f", 0.6753129101488048)
    timers_0.add("f", 0.535589522070179)
    timers_0.add("f", 0.9634239579880026)
    timers_0.add("f", 0.9995656421672583)
    timers_0.add("f", 1.3204214294082428)
    timers_0.add("f", 0.9680310193102268)

# Generated at 2022-06-25 15:16:06.166386
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('a', 10)
    timers.add('a', 20)
    timers.add('a', 3)
    timers.add('a', 7)

    assert timers.max('a') == 20



# Generated at 2022-06-25 15:16:17.735578
# Unit test for method max of class Timers
def test_Timers_max():
    """
    Unit test for method max of class Timers
    """
    try:
        timers_1 = Timers()
        timers_1.add('foo', 13.2)
        timers_1.add('foo', 18.0)
        timers_1.add('foo', 10.0)
        timers_1.add('bar', 10.0)
        max_1 = timers_1.max('foo')
        assert max_1 == 18.0
        max_2 = timers_1.max('bar')
        assert max_2 == 10.0
        max_3 = timers_1.max('baz')
    except Exception as e:
        print(e)
        raise


# Generated at 2022-06-25 15:16:26.605886
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("timer_1", (1))
    timers_0.add("timer_2", (2))
    timers_0.add("timer_3", (3))
    assert timers_0.median("timer_0") == (0)
    assert timers_0.median("timer_1") == (1)
    assert timers_0.median("timer_2") == (2)
    assert timers_0.median("timer_3") == (3)
    timers_1 = Timers()
    timers_1.add("timer_0", (1))
    timers_1.add("timer_1", (1))
    timers_1.add("timer_2", (2))
    timers_1.add("timer_3", (3))
    assert timers_

# Generated at 2022-06-25 15:16:37.045208
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert timers_0.mean("name") == 0.0
    timers_0.add("name", 1)
    assert timers_0.mean("name") == 1
    timers_0.add("name", 2)
    assert timers_0.mean("name") == 1.5
    timers_0.add("name", 3)
    assert timers_0.mean("name") == 2.0
    timers_0.add("name", 4)
    assert timers_0.mean("name") == 2.5
    timers_0.add("name", 5)
    assert timers_0.mean("name") == 3.0
    timers_0.add("name", 6)
    assert timers_0.mean("name") == 3.5
    timers_0.add("name", 7)
    assert timers

# Generated at 2022-06-25 15:16:39.652454
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    # Test that the exception is raised
    try:
        timers_0.median("timers_0")
    except KeyError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-25 15:16:42.438402
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("2.3s", 2.3)
    timers_0.add("2.3s", 0.3)
    return timers_0.min("2.3s") == 0.3


# Generated at 2022-06-25 15:16:45.106073
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert isinstance(timers_0.min("timer_0"), float)


# Generated at 2022-06-25 15:16:47.925336
# Unit test for method mean of class Timers
def test_Timers_mean():
    # call to Timers()
    timers_0 = Timers()

    # call to add
    timers_0.add(name_0='aaa', value_0=0.0)


# Generated at 2022-06-25 15:16:51.224639
# Unit test for method mean of class Timers
def test_Timers_mean():
    # timings_0 =
    # name_0 =
    # result_0 = timers_0.mean(name_0)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 15:16:55.886176
# Unit test for method median of class Timers
def test_Timers_median():
    # Test for case 0

    # Setup for test
    timers_0 = Timers()
    name_0 = "CTSRD"

    # Call the method with a known argument
    result_0 = timers_0.median(name=name_0)

    # Assert that the result is what we expected
    assert result_0 == 0.0


# Generated at 2022-06-25 15:16:58.432073
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert timers_0.min("name_0") == 0


# Generated at 2022-06-25 15:17:06.310145
# Unit test for method median of class Timers
def test_Timers_median():

    # Setup
    timers_0 = Timers()  # Explicit constructor call.

    # Testing
    timers_0.add('test_0', 1)
    timers_0.add('test_0', 2)
    timers_0.add('test_0', 3)
    timers_0.add('test_0', 4)
    timers_0.add('test_0', 5)
    try:
        timers_0.median('test_1')
    except KeyError:
        pass
    assert timers_0.median('test_0') == 3.0


# Generated at 2022-06-25 15:17:11.073260
# Unit test for method min of class Timers
def test_Timers_min():
    try:
        timers_0 = Timers()
        timers_0.add('0', 0)
        timers_0.add('0', 1)
        timers_0.add('0', 2)
        timers_0.add('0', 3)
        timers_0.add('0', 4)
        timers_0.min('0')
        assert 1
    except Exception as e:
        assert 0


# Generated at 2022-06-25 15:17:12.365437
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    try:
        timers_0.mean("name_0")
    except KeyError as exc:
        exc
        print('Caught exception:')
        print(exc)


# Generated at 2022-06-25 15:17:18.386502
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('a', 1.5)
    timers_0.add('a', 1.2)
    timers_0.add('a', -1.5)
    timers_0.add('a', 0.6)
    timers_0.add('b', -1.5)
    timers_0.add('b', -2.5)
    timers_0.add('b', -3.5)
    timers_0.add('b', 0.6)
    assert timers_0.min('a') == 1.2
    assert timers_0.min('b') == 0.6


# Generated at 2022-06-25 15:17:21.461317
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name = ""
    assert isinstance(timers_0.mean(name), float)


# Generated at 2022-06-25 15:17:32.960344
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.add('a', 1)
    t.add('a', 2)
    assert t.max('a') == 2.0
    assert t.min('a') == 1.0
    assert t.mean('a') == 1.5
    assert t.median('a') == 1.5
    assert t.stdev('a') == 0.5
    assert t.total('a') == 3.0
    assert t.count('a') == 2.0
    t.add('a', 3)
    assert t.max('a') == 3.0
    assert t.min('a') == 1.0
    assert t.mean('a') == 2.0
    assert t.median('a') == 2.0
    assert t.stdev('a') == 1.0

# Generated at 2022-06-25 15:17:36.780976
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('t', 0.1)
    timers.add('t', 0.2)
    timers.add('t', 0.3)
    min_value = timers.min('t')
    assert min_value == 0.1



# Generated at 2022-06-25 15:17:46.155563
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_1 = Timers()
    timers_0.add("hi!", 572.008737877074)
    timers_0.add("hi!", -816.1160703629077)
    assert timers_0.median("hi!") == (
        (572.008737877074 + -816.1160703629077) / 2
    )
    timers_1.add("hi!", -385.978517011843)
    timers_1.add("hi!", -295.98845487064477)
    timers_1.add("hi!", -469.17893826462444)
    timers_1.add("hi!", -624.7475505514928)

# Generated at 2022-06-25 15:17:54.582977
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("name_0", -1.0)
    timers_0.add("name_0", 1.0)
    timers_0.add("name_1", -1.0)
    timers_0.add("name_1", 1.0)
    timers_0.add("name_1", 2.0)
    timers_0.add("name_2", -2.0)
    timers_0.add("name_2", -1.0)
    timers_0.add("name_2", 1.0)
    timers_0.add("name_2", 2.0)
    assert math.isclose(timers_0.median("name_0"), 0.0)

# Generated at 2022-06-25 15:18:00.208645
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    str_arg_0 = "applesauce"
    if timers_0.mean(str_arg_0) != math.nan:
        raise AssertionError()


# Generated at 2022-06-25 15:18:11.431517
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('test_01',0.01)
    result = timers.mean('test_01')
    assert result == 0.01



# Generated at 2022-06-25 15:18:15.479612
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add("foo", 10)
    timers.add("foo", 20)
    timers.add("bar", 20)
    assert timers.max("foo") == 20
    assert timers.max("bar") == 20
    assert timers.max("baz") == 0


# Generated at 2022-06-25 15:18:23.584462
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("f_0", 1.0)
    timers_0.add("f_1", 3.0)
    timers_0.add("f_2", 0.0)
    timers_0.add("f_3", 3.0)
    timers_0.add("f_4", 1.0)
    timers_0.add("f_5", 0.0)
    timers_0.add("f_6", 0.0)
    timers_0.add("f_7", 1.0)
    timers_0.add("f_8", 0.0)
    timers_0.add("f_9", 1.0)
    assert timers_0.max("f_0") == 1.0

# Generated at 2022-06-25 15:18:27.692781
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('timer_0', 1.0)
    timers_0.add('timer_0', 2.0)
    timers_0.add('timer_0', 3.0)
    timers_0.add('timer_0', 4.0)
    timers_0.add('timer_0', 5.0)
    return timers_0.median('timer_0')



# Generated at 2022-06-25 15:18:31.165521
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("rtt_timer_1", 0.2024184)
    assert timers_0.max("rtt_timer_1") == 0.2024184


# Generated at 2022-06-25 15:18:34.139264
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('test', 2)
    timers.add('test', 3)
    timers.add('test', 4)
    assert timers.mean('test') == 3

# Generated at 2022-06-25 15:18:36.709555
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    assert (timers_0.mean('key_float') == 0)


# Generated at 2022-06-25 15:18:44.124728
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("timer", 0.0)
    assert round(timers_0.min("timer"), 6) == 0.0


# Generated at 2022-06-25 15:18:47.474352
# Unit test for method min of class Timers
def test_Timers_min():
    print('Testing method min of class Timers')
    timers_0 = Timers()
    timers_0.data['x'] = 0
    assert (timers_0.min('x') == 0)


# Generated at 2022-06-25 15:18:58.401351
# Unit test for method median of class Timers
def test_Timers_median():
    # Create a new instance of Timers
    timers_1 = Timers()
    # Check that median of timers_1 is 0
    assert math.isclose(0, timers_1.median('timer'))
    # Add 0.1 to timer
    timers_1.add('timer', 0.1)
    # Add 0.2 to timer
    timers_1.add('timer', 0.2)
    # Check that median of timers_1 is 0.1
    assert math.isclose(0.1, timers_1.median('timer'))
    # Add 0.3 to timer
    timers_1.add('timer', 0.3)
    # Check that median of timers_1 is 0.2
    assert math.isclose(0.2, timers_1.median('timer'))


# Generated at 2022-06-25 15:19:14.770759
# Unit test for method min of class Timers
def test_Timers_min():
    # Test for case 0
    timers_0 = Timers()
    try:
        assert_equal(timers_0.min('TimerName'), 0)
    except KeyError as E:
        assert_equal(str(E), 'TimerName')

    # Test for case 1
    timers_0.add('non-empty-timer', 1)
    assert_equal(timers_0.min('non-empty-timer'), 1)


# Generated at 2022-06-25 15:19:19.331709
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("glob", 75.189)
    timers_0.add("glob", 69.748)
    timers_0.add("glob", 45.749)
    timers_0.add("glob", 56.726)
    timers_0.add("glob", 70.174)
    max_0: float = timers_0.max("glob")
    assert 75.189 == max_0


# Generated at 2022-06-25 15:19:23.029634
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('key', 1.0)
    timers_0.add('key', 2.0)
    timers_0.add('key', 3.0)
    assert timers_0.min('key') == 1.0


# Generated at 2022-06-25 15:19:25.735238
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Asserts output of mean for empty Timers is 0."""
    # Setup
    timers_0 = Timers()
    # Assert
    assert timers_0.mean("foo") == 0

# Generated at 2022-06-25 15:19:33.574818
# Unit test for method min of class Timers
def test_Timers_min():
    timers_1 = Timers()
    timers_1.add("name_1", 3.0)
    timers_1.add("name_1", 2.0)
    timers_1.add("name_1", 4.0)
    timers_1.add("name_2", 1.0)
    timers_1.add("name_2", 3.0)
    timers_1.add("name_2", 2.0)
    # test that calling min() raises an KeyError if name is not present
    try:
        timers_1.min("name_3")
    except KeyError as e:
        pass
    else:
        assert False, "test_Timers_min failed"
    # test that calling min() returns the minimal value for named timer

# Generated at 2022-06-25 15:19:43.271896
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('foo', 3.0)
    timers.add('foo', 3.0)
    timers.add('bar', 1.0)
    timers.add('bar', 4.0)
    timers.add('bar', 9.0)
    assert 3 == timers.median('foo')
    assert 4 == timers.median('bar')


if __name__ == "__main__":
    timer = Timers()
    timer.add(name="model", value=2)
    timer.add(name="model", value=3)

# Generated at 2022-06-25 15:19:50.268014
# Unit test for method min of class Timers
def test_Timers_min():
    timer_0 = Timers()
    timer_1 = Timers()
    timer_1.add("", -4.7561521737752585)
    timer_1.min("")
    timer_0.add("Name", 4.269882971567773)
    timer_0.min("Name")
    timer_0.apply(len, "Name")
    timer_0.apply(statistics.mean, "Name")
    timer_0.apply(statistics.median, "Name")
    timer_0.apply(statistics.stdev, "Name")
    timer_0.add("Name", 0.0)
    timer_0.min("Name")
    timer_2 = Timers()
    timer_2.add("Name", -0.01)
    timer_2.min("Name")
    timer

# Generated at 2022-06-25 15:19:56.853475
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.data = {'key_0': 0.7111494192388231}
    timers_0._timings = {'key_0': [0.14230908892631577, 0.47139442717105263, 0.7111494192388231]}

    assert_equal(timers_0.min('key_0'), 0.14230908892631577)


# Generated at 2022-06-25 15:19:58.475089
# Unit test for method max of class Timers
def test_Timers_max():
    # testing the max method
    test_case_0()
    if __name__ == "__main__":
        print('Testing method max of class Timers')


# Generated at 2022-06-25 15:20:08.229019
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.data['wvC@i|cy:F9I'] = 1.377
    timers_0.data['8]m;G1}w0>vB'] = 1.848
    timers_0.data['N4D4]N?1stH'] = 0.29
    timers_0.data['<9YtO>o{e)M('] = 0.729
    timers_0.data['pUnr&+:]|(J('] = 0.599
    timers_0.data['*ggG]JHc%n@'] = 0.472
    timers_0.data['JW}i8xv_XMQI'] = 1.051

# Generated at 2022-06-25 15:20:35.431903
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('key_0', 126)
    timers_0.add('key_1', 6)
    timers_0.add('key_2', 156)
    timers_0.add('key_3', 9)
    timers_0.add('key_4', 126)
    assert(timers_0.median('key_0') == 126)
    assert(timers_0.median('key_4') == 126)
    timers_0.add('key_2', 156)
    timers_0.add('key_1', 6)
    timers_0.add('key_1', 6)
    assert(timers_0.median('key_0') == 126)
    assert(timers_0.median('key_4') == 126)
    timers

# Generated at 2022-06-25 15:20:40.778639
# Unit test for method mean of class Timers
def test_Timers_mean():

    timers_0 = Timers()

    timers_0.add('test_0', 33.34253737503522)

    assert timers_0.mean('test_0') == 33.34253737503522, \
        'test_Timers_mean() failed.'


# Generated at 2022-06-25 15:20:48.512884
# Unit test for method min of class Timers
def test_Timers_min():
    """
    >>> timers = Timers()
    >>> timers.add("test", 1.1)
    >>> timers.add("test", 0.5)
    >>> timers.add("test", 2)
    >>> timers.add("test", 0.1)
    >>> timers.add("test", 2.6)
    >>> timers.min("test")
    0.1
    >>> timers.min("test2")
    Traceback (most recent call last):
    ...
    KeyError: 'test2'
    >>> timers.clear()

    """


# Generated at 2022-06-25 15:20:50.029175
# Unit test for method median of class Timers
def test_Timers_median():
    assert math.isnan(timers_0.median(name='_name')) == True


# Generated at 2022-06-25 15:20:51.978436
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("name", 0.5)
    timer_min = timers_0.min("name")
    assert timer_min == 0.5


# Generated at 2022-06-25 15:20:57.055409
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()

    collected_times_0 = [0.0, 0.0, 1.0, 1.0]
    timers_0._timings['__main__.test_Timers_median'] = collected_times_0

    assert timers_0.median('__main__.test_Timers_median') == 0.5


# Generated at 2022-06-25 15:20:59.029156
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.apply(None, 'name')


# Generated at 2022-06-25 15:21:02.093725
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    timers_1.add("elapsed",1.814)
    timers_1.add("elapsed",2.831)
    timers_1.add("elapsed",0.829)
    assert timers_1.median("elapsed") == 1.82


# Generated at 2022-06-25 15:21:02.894530
# Unit test for method mean of class Timers
def test_Timers_mean():
    assert Timers().mean("") is 0.0


# Generated at 2022-06-25 15:21:09.704311
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("timer_0", 0)
    timers_0.add("timer_1", 2.0)
    timers_0.add("timer_2", 2.0)
    timers_0.add("timer_3", 2.5)
    timers_0.add("timer_4", 2.5)
    timers_0.add("timer_5", 2.5)
    # Median of all entries, should be 2.5
    assert timers_0.median("timer_2") == 2.5
    assert timers_0.median("timer_3") == 2.5
    assert timers_0.median("timer_4") == 2.5
    assert timers_0.median("timer_5") == 2.5
    # Median of odd number of entries, should be

# Generated at 2022-06-25 15:21:31.108211
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    value = timers_0.min("data")
    assert value == 0.0
