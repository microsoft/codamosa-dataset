

# Generated at 2022-06-25 15:11:39.732547
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.count("count_0")
    assert math.isnan(timers_0.mean("count_0"))


# Generated at 2022-06-25 15:11:43.335929
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.data['string_0'] = 0.0
    var_0 = timers_0.max('string_0')
    assert math.fabs(var_0 - 0.0) <= 1e-06


# Generated at 2022-06-25 15:11:48.565101
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('time_main', (1))
    timers_0.add('time_main', (2))
    timers_0.add('time_main', (3))
    timers_0.add('time_main', (4))
    timers_0.add('time_gpu_compute', (13))
    expected_result = 4.0
    assert timers_0.max('time_main') == expected_result


# Generated at 2022-06-25 15:11:54.245987
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("a", 0.0)
    timers_0.add("b", 0.0)
    timers_0.add("b", 0.0)
    timers_0.add("a", 0.0)
    assert timers_0.min("b") == 0.0
    assert timers_0.min("a") == 0.0

# Unit tests for method add of class Timers

# Generated at 2022-06-25 15:11:58.758657
# Unit test for method median of class Timers
def test_Timers_median():
    test_cases_median = [
        (
            ("timers_0", Timers(), "name_0", "value_0",),
            0,
        ),
        (
            ("timers_1", Timers(), "name_1", "value_1",),
            0,
        ),
        (
            ("timers_2", Timers(), "name_2", "value_2",),
            0,
        ),
        (
            ("timers_3", Timers(), "name_3", "value_3",),
            0,
        ),
    ]
    for test_case in test_cases_median:
        timers_ = test_case[0][1]
        value = test_case[1]

# Generated at 2022-06-25 15:12:03.133670
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("Key0", 0.2778292253514235)
    timers_0.add("Key1", 0.2778292253514235)
    timers_0.add("Key2", 0.2778292253514235)
    assert abs(timers_0.max("Key0") - 0.2778292253514235) < 1.e-14 * abs(timers_0.max("Key0"))


# Generated at 2022-06-25 15:12:05.989534
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("DEFAULT", 0.0588235294117647)
    timers_0.add("DEFAULT", 0.0588235294117647)
    assert timers_0.mean("DEFAULT") == 0.0588235294117647

# Generated at 2022-06-25 15:12:07.803069
# Unit test for method max of class Timers
def test_Timers_max():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 15:12:09.250749
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    name_0 = "no way this exists"
    timers_0.max(name_0)


# Generated at 2022-06-25 15:12:16.304368
# Unit test for method mean of class Timers
def test_Timers_mean():
    import unittest
    import io
    import sys

    class TimersUnitTest(unittest.TestCase):
        def test_Timers_mean_0(self):
            timers_0 = Timers()
            timers_0["test_0"] = 1

            mean = timers_0.mean("test_0")

            self.assertEqual(mean, 1)

        def test_Timers_mean_1(self):
            timers_0 = Timers()

            try:
                timers_0.mean("test_1")
            except KeyError:
                pass
            else:
                self.fail("Expected KeyError")


    if __name__ == "__main__":
        unittest.main()


# Generated at 2022-06-25 15:12:20.558587
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    key_0 = 'b'
    assert (timers_0.mean(key_0) == 0)


# Generated at 2022-06-25 15:12:24.728707
# Unit test for method mean of class Timers
def test_Timers_mean():

    timers_0 = Timers()
    try:
        assert (timers_0.mean("cy_52") == 0.0)
        print("test_Timers_mean, case 0 Passed")
    except AssertionError:
        print("test_Timers_mean, case 0 Failed")

# Generated at 2022-06-25 15:12:28.895537
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add("Test", 1)
    assert(timers_1.mean("Test") == 1)
    timers_1.add("Test", 2)
    assert(timers_1.mean("Test") == 1.5)
    timers_1.add("Test", 3)
    assert(timers_1.mean("Test") == 2)


# Generated at 2022-06-25 15:12:31.836286
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    timers.add('a', 2)
    timers.add('b', 3)
    timers.add('a', 2)

    # AssertionError: 2 != 3
    assert timers.max('a') != 3

    # KeyError: 'c'
    assert timers.max('c')



# Generated at 2022-06-25 15:12:37.742576
# Unit test for method max of class Timers
def test_Timers_max():
    # Setup
    timers_0 = Timers()
    name_0 = str()
    # Exercise
    result = timers_0.max(name=name_0)
    # Verify
    assert result == 0
    # Cleanup
    del timers_0
    del name_0


# Generated at 2022-06-25 15:12:39.878365
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name = "foo"
    value = timers_0.min(name)
    assert value == 0.0


# Generated at 2022-06-25 15:12:48.500300
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("p6.Ve.z", 1.92784)
    timers_0.add("p4.Ve.z", 0.189643)
    timers_0.add("p4.Ve.z", 47.2674)
    timers_0.add("p4.Ve.z", 3.49086)
    timers_0.add("p3.Ve.z", 0.091854)
    timers_0.add("p3.Ve.z", 1.62389)
    timers_0.add("p5.Ve.z", 0.164576)
    timers_0.add("p5.Ve.z", 1.20799)
    timers_0.add("p7.Ve.z", 0.719372)

# Generated at 2022-06-25 15:12:50.540546
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("name", 0.0)
    print(timers_0.min("name"))


# Generated at 2022-06-25 15:12:56.796746
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('a', 1)
    timers_0.add('b', 2)
    timers_0.add('c', 3)
    timers_0.add('b', 4)
    timers_0.add('a', 5)
    assert 1 == timers_0.min('a')
    assert 2 == timers_0.min('b')
    assert 3 == timers_0.min('c')
    assert 5 == timers_0.max('a')
    assert 4 == timers_0.max('b')
    assert 3 == timers_0.max('c')
    assert 3 == timers_0.count('a')
    assert 2 == timers_0.count('b')
    assert 1 == timers_0.count('c')
    assert 6 == timers_0.mean('a')


# Generated at 2022-06-25 15:12:59.534312
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers()
    try:
        timers.add("test", 2.1)
    except TypeError:
        assert True
    else:
        assert False  # pragma: no cover
    assert timers.max("test") == 2.1



# Generated at 2022-06-25 15:13:11.457514
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('name_0', 0.115085272900139)
    timers_0.add('name_0', 0.5125815996833953)
    timers_0.add('name_0', 0.0015352279802683466)
    timers_0.add('name_0', 0.0727072306506163)
    timers_0.add('name_0', 0.00099780106166341)
    timers_0.add('name_0', 0.2643141035597969)
    timers_0.add('name_0', 0.006951841049658522)
    timers_0.add('name_0', 0.002837873988494532)

# Generated at 2022-06-25 15:13:20.427398
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("test_1", 23)
    timers_0.add("test_2", 23)
    timers_0.add("test_3", 23)
    timers_0.add("test_4", 23)
    timers_0.add("test_5", 23)
    timers_0.add("test_6", 23)
    timers_0.add("test_7", 23)
    timers_0.add("test_8", 23)
    r_0 = timers_0.min("test_1")
    assert r_0 == 23


# Generated at 2022-06-25 15:13:32.062370
# Unit test for method mean of class Timers
def test_Timers_mean():
    timer_0 = Timers()
    assert ((timer_0.mean("py") == 0) and (timer_0.mean("py") == 0)), "No timing information"
    assert ((timer_0.mean("py") == 0) and (timer_0.mean("py") == 0)), "No timing information"
    # add a timing value for name 'py'
    timer_0.add("py", 0.05)
    assert ((timer_0.mean("py") == 0.05) and (timer_0.mean("py") == 0.05)), "py with one timing"
    # add another timing value for name 'py'
    timer_0.add("py", 1.75)

# Generated at 2022-06-25 15:13:37.227630
# Unit test for method min of class Timers
def test_Timers_min():
    # Setup
    timers_0 = Timers()
    # Assignment
    timers_0.add('name', 0.3)
    timers_0.add('name', 0.3)
    # Comparison
    assert timers_0.min('name') == 0.3


# Generated at 2022-06-25 15:13:41.410156
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add("timer", 1)
    timers.add("timer", 2)
    assert 2 == timers.max("timer")
    try:
        assert 2 == timers.min("timer x")
        assert False
    except KeyError as e:
        assert "timer x" == e.args[0]

# Generated at 2022-06-25 15:13:52.195119
# Unit test for method mean of class Timers
def test_Timers_mean():
    # Tests for exception
    # Exception is thrown when name is not found in the dictionary
    try:
        timers_0.mean("")
        assert False, "Expected KeyError"
    except KeyError:
        pass
    except Exception:
        assert False, "Unexpected exception thrown"

    # Tests for normal behavior
    # Dict item assignment is not allowed
    try:
        timers_0 = Timers()
        timers_0["name"] = 0
        assert False, "Expected TypeError"
    except TypeError:
        pass
    except Exception:
        assert False, "Unexpected exception thrown"

    # Assignment of existing dict item is allowed

# Generated at 2022-06-25 15:13:58.070485
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name_0 = 'count_calls'
    timers_0.add(name_0, 1)
    name_1 = 'count_calls'
    name_2 = 'count_calls'
    timers_0.add(str(), 1)
    name_3 = 'count_calls'
    assert timers_0.min(name_1) == 1


# Generated at 2022-06-25 15:14:01.392315
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    assert math.isnan(timers_0.median("jh8k"))


# Generated at 2022-06-25 15:14:03.645157
# Unit test for method max of class Timers
def test_Timers_max():
    t = Timers()
    t.add("test_0", 2.0)
    assert t.max("test_0") == 2.0


# Generated at 2022-06-25 15:14:06.222932
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('name', 0.0)
    float_0 = timers_0.max('name')
    assert float_0 == 0.0


# Generated at 2022-06-25 15:14:11.710986
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("max_num_threads", 1)
    timers_0.add("notification_send", 2)
    timers_0.add("max_num_threads", 5)
    timers_0.add("notification_send", 4)
    assert timers_0.mean("notification_send") == 3


# Generated at 2022-06-25 15:14:17.386548
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers( )
    timers.add( 'a', 3.141 )
    timers.add( 'b', 2.718 )
    timers.add( 'c', 1.414 )
    assert timers.max( 'a' ) == 3.141
    assert timers.max( 'b' ) == 2.718
    assert timers.max( 'c' ) == 1.414


# Generated at 2022-06-25 15:14:20.886084
# Unit test for method mean of class Timers
def test_Timers_mean():
    print(test_case_0())

if __name__ == '__main__':
    test_Timers_mean()

# Generated at 2022-06-25 15:14:23.293370
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("name_0", 2.0)
    bool_0 = timers_0.max("name_0") == 2.0
    bool_1 = timers_0.max("name_1") == 0.0


# Generated at 2022-06-25 15:14:30.366524
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    timers_1.add("foo", 10.0)
    timers_1.add("foo", 20.0)

    timers_2 = Timers()
    timers_2.add("foo", 10.0)
    timers_2.add("foo", 20.0)
    timers_2.add("foo", 30.0)

    # Test with one value
    assert timers_1.max("foo") == 20.0

    # Test with two values
    assert timers_2.max("foo") == 30.0


# Generated at 2022-06-25 15:14:33.378344
# Unit test for method median of class Timers
def test_Timers_median():
    try:
        timers_0 = Timers()
        timers_0.add('0', 0)
        timers_0.median('0')
    except Exception as e:
        return False
    return True


# Generated at 2022-06-25 15:14:38.195795
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("?", 3.0)
    assert float(timers_0.mean("?")) == float(3.0)
    timers_0.add("?", 6.0)
    timers_0.add("?", 9.0)
    assert float(timers_0.median("?")) == float(6.0)
    timers_1 = Timers()
    timers_1.clear()


# Generated at 2022-06-25 15:14:39.289167
# Unit test for method min of class Timers
def test_Timers_min():
    assert Timers().min("name") == 0


# Generated at 2022-06-25 15:14:42.457650
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('test', 1.1)
    
    assert 1.1 == timers_0.min('test')


# Generated at 2022-06-25 15:14:47.522922
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("key_timers_0_0", 96.1526245898842)
    assert timers_0.min("key_timers_0_0") == 96.1526245898842


# Generated at 2022-06-25 15:14:54.250746
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('foo', 5)
    timers_0.add('foo', 15)
    timers_0.add('bar', 5)
    timers_0.add('bar', 10)
    # Test cases
    assert(timers_0.mean('foo') == 10)
    assert(timers_0.mean('bar') == 7.5)


# Generated at 2022-06-25 15:15:03.137979
# Unit test for method min of class Timers
def test_Timers_min():
    # Test the number of arguments is correct
    try:
        assert len(eval(f"Timers().min").__code__.co_varnames) == 2
    except AttributeError:
        pass
    # Test that name is a required argument
    try:
        Timers().min()
        raise AssertionError("Required argument 'name' was not found")
    except TypeError:
        pass
    # Test that function raises KeyError if timer does not exist
    try:
        Timers().min(name="timer")
        raise AssertionError("KeyError not raised")
    except KeyError:
        pass
    # Test that function returns requested value
    timers_0 = Timers()
    value_0 = timers_0.min(name="timer")
    assert value_0 == 0

# Generated at 2022-06-25 15:15:05.705632
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name_0 = "t"
    timers_0.add(name_0, 5.0)
    assert timers_0.min('t') == 5



# Generated at 2022-06-25 15:15:16.525782
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()

# Generated at 2022-06-25 15:15:25.022242
# Unit test for method mean of class Timers
def test_Timers_mean():
    """
    Unit test for Timers.mean.
    """
    timers_0 = Timers()
    timers_0.add("key_0", 0.0)
    assert round(timers_0.mean("key_0"), 5) == 0.0
    timers_1 = Timers()
    timers_1.add("key_0", 2.5)
    assert round(timers_1.mean("key_0"), 5) == 2.5
    timers_2 = Timers()
    timers_2.add("key_0", 1.0)
    timers_2.add("key_0", -1.0)
    assert round(timers_2.mean("key_0"), 5) == 0.0
    timers_3 = Timers()
    timers_3.add("key_0", -0.9)

# Generated at 2022-06-25 15:15:29.596404
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_1 = Timers()
    timers_1.add("09", 11)
    assert timers_1.mean("09") == 11
    timers_1.add("09", 20)
    assert timers_1.mean("09") == 15.5

test_case_0()
test_Timers_mean()

# Generated at 2022-06-25 15:15:33.628538
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('foo', 0.000211)
    result_0 = timers_0.min('foo')
    assert abs(result_0 - 2.11e-5) < 1e-5


# Generated at 2022-06-25 15:15:44.491313
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.data = {'test': 5, 'test_2': 5, 'test_3': 5, 'test_4': 5, 'test_5': 5, 'test_6': 5, 'test_7': 5, 'test_8': 5, 'test_9': 5, 'test_10': 5}
    assert timers_0.mean('test') == 5.0
    assert timers_0.mean('test_2') == 5.0
    assert timers_0.mean('test_3') == 5.0
    assert timers_0.mean('test_4') == 5.0
    assert timers_0.mean('test_5') == 5.0
    assert timers_0.mean('test_6') == 5.0

# Generated at 2022-06-25 15:15:46.730131
# Unit test for method max of class Timers
def test_Timers_max():
    timers = Timers({"key_1":1.0, "key_2":0.5})
    max_ = timers.max("key_1")
    assert max_==1.0


# Generated at 2022-06-25 15:15:50.307274
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("t0", 10.0)
    timers_0.add("t1", 15.0)
    result_0 = timers_0.min("t0")
    assert result_0 == 10.0


# Generated at 2022-06-25 15:16:00.192317
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('timers_0', 2.5)
    timers_0.add('timers_0', 5.0)
    timers_0.add('timers_0', 1.0)
    timers_0.add('timers_0', 3.75)
    timers_0.add('timers_0', 2.25)
    test_value = 2.5
    assert math.isclose(timers_0.median('timers_0'), test_value, rel_tol=1e-15)


# Generated at 2022-06-25 15:16:08.774956
# Unit test for method min of class Timers
def test_Timers_min():
    # Test case 0
    timers_0 = Timers()
    name_0 = "timer_0"
    timers_0.add(name_0, 0.1)
    timers_0.add(name_0, 0.2)
    timers_0.add(name_0, -1.01)
    actual = timers_0.min(name=name_0)
    expected = -1.01
    assert actual == expected, "timers_0.min(name=name_0) not working"
    # Test case 1
    timers_0 = Timers()
    name_0 = "timer_0"
    actual = timers_0.min(name=name_0)
    expected = 0
    assert actual == expected, "timers_0.min(name=name_0) not working"


# Generated at 2022-06-25 15:16:11.860794
# Unit test for method median of class Timers
def test_Timers_median():
    timers_1 = Timers()
    # Negative test
    try:
        timers_1.median('timer_12')
    except KeyError as error_1:
        assert error_1.args[0] == 'timer_12'

# Generated at 2022-06-25 15:16:16.993650
# Unit test for method median of class Timers
def test_Timers_median():
  """Trivial program"""
  timers_0 = Timers()
  timers_0.add('t_0', 10.5)
  timers_0.add('t_0', 11.5)
  timers_0.add('t_0', 12.0)
  timers_0.add('t_0', 12.0)
  timers_0.add('t_0', 12.5)
  assert timers_0.median('t_0') == 12.0
  return

# Generated at 2022-06-25 15:16:20.818271
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    assert timers.mean('foo') == 0
    timers.add('foo', 1)
    assert timers.mean('foo') == 1
    timers.add('foo', 2)
    assert timers.mean('foo') == 1.5


# Generated at 2022-06-25 15:16:28.180638
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("weave", 1)
    timers_0.add("weave", 2)
    timers_0.add("weave", 3)
    assert 1 == timers_0.median(name="weave")


# Generated at 2022-06-25 15:16:36.455915
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add(str_0, float_1)
    float_2 = timers_0.min(str_0)
    assert type(float_2) == float
    timers_1 = Timers()
    timers_1.add('s', 1)
    timers_1.add('s', 1)
    timers_1.add('s', 1)
    assert timers_1.min('s') == 1
    timers_1.add('s', 0)
    assert timers_1.min('s') == 0


# Generated at 2022-06-25 15:16:38.916773
# Unit test for method min of class Timers
def test_Timers_min():
    # Set up test context
    timers_0 = Timers()

    # Call method being tested
    result = timers_0.min()

    # Assert expected output
    assert result == 0


# Generated at 2022-06-25 15:16:42.275523
# Unit test for method median of class Timers
def test_Timers_median():
    from random import random
    timers_1 = Timers()

    for _ in range(50):
        timers_1.add("A", random())

    # Test
    actual_1 = timers_1.median("A")

    # Verify:
    assert not math.isnan(actual_1)



# Generated at 2022-06-25 15:16:45.935727
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("Test_0", 0.55)
    value_0 = timers_0.max("Test_0")
    assert 0.55 == value_0



# Generated at 2022-06-25 15:16:53.328671
# Unit test for method min of class Timers
def test_Timers_min():

    timers = Timers()
    timers.add('timer_0', 10)
    timers.add('timer_0', 10)
    timers.add('timer_0', 10)

    assert timers.min('timer_0') == 10


# Generated at 2022-06-25 15:16:59.619831
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add('key_0', 0.7397185864300469)
    timers_0.add('key_0', 0.6919275412498973)
    timers_0.add('key_0', 0.6393749166859994)
    timers_0.add('key_0', 0.7043262156586805)
    timers_0.add('key_0', 0.7190528292144739)
    timers_0.add('key_0', 0.7085189314263534)
    timers_0.add('key_0', 0.6683243370508855)
    timers_0.add('key_0', 0.6867694734264979)

# Generated at 2022-06-25 15:17:05.804009
# Unit test for method min of class Timers
def test_Timers_min():
    """Test minimal value of timers"""
    timers = Timers()
    assert timers.min("test") == 0
    timers.add("test", 1.0)
    assert timers.min("test") == 1.0
    timers.add("test", 2.0)
    assert timers.min("test") == 1.0
    timers.add("test", 3.0)
    assert timers.min("test") == 1.0


# Generated at 2022-06-25 15:17:10.630758
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add(name="case_0_0", value=0.5)
    assert (
        timers.mean(name="case_0_0")
        == 0.5
    ), "mean(case_0_0) should return 0.5, got {}".format(
        timers.mean(name="case_0_0")
    )


# Generated at 2022-06-25 15:17:17.960698
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    try:
        timers_0.max('name_0')
    except KeyError:
        return
    raise AssertionError('AssertionError expected')


# Generated at 2022-06-25 15:17:25.865858
# Unit test for method max of class Timers
def test_Timers_max():
    # Create an instance of Timers
    timers_0 = Timers()
    assert math.isnan(timers_0.max('min'))
    assert math.isnan(timers_0.max('max'))
    # Add some timings
    timers_0.add('min', 0.1)
    timers_0.add('max', 2.1)
    # Verify that max method works
    assert timers_0.max('min') == 0.1
    assert timers_0.max('max') == 2.1


if __name__ == '__main__':  # pragma: no cover
    test_case_0()
    test_Timers_max()

# Generated at 2022-06-25 15:17:29.832843
# Unit test for method mean of class Timers
def test_Timers_mean():
    """Check return value of mean"""
    timers_0 = Timers()
    timers_0.add('test', 2.)
    assert timers_0.mean('test') == 2.

# Generated at 2022-06-25 15:17:33.125178
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert timers_0.min("Name0") == 0
    timers_0.add("Name0", 1.1)
    assert timers_0.min("Name0") == 1.1

# Generated at 2022-06-25 15:17:34.307758
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add("_", 0)
    assert 0 == timers_0.min('_')


# Generated at 2022-06-25 15:17:36.860054
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name = "test_name"
    assert timers_0.min(name=name) == 0


# Generated at 2022-06-25 15:17:46.431756
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add("key-0", 0.0)
    timers_0.median("key-0")
    assert True  # pass


# Generated at 2022-06-25 15:17:48.414530
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers["timer_a"] = 0
    timers.add("timer_a", 0)
    assert timers.min("timer_a") == 0


# Generated at 2022-06-25 15:17:53.504398
# Unit test for method median of class Timers
def test_Timers_median():
    # Set up test fixture
    timers = Timers()
    timers.add("test", 1.0)
    timers.add("test", 2.0)
    timers.add("test", 3.0)
    timers.add("test", 2.0)
    timers.add("test", 1.0)
    # Exercise SUT
    result = timers.median("test")
    # Assert
    assert result == 2.0



# Generated at 2022-06-25 15:18:00.416931
# Unit test for method max of class Timers
def test_Timers_max():
    """Testing method 'max' of class 'Timers'

    Case 0: Verify that the max of an empty timer equals the default value
    Case 1: Verify that the max is correctly calculated
    Case 2: Verify that the max is correctly calculated for multiple timers
    Case 3: Verify that the max is correctly calculated for multiple timers
    and with some timers having more timing entries than others.
    """

    # Case 0
    timers_0 = Timers()
    assert timers_0.max("timer-name-0") == 0.0

    # Case 1
    timers_1 = Timers()
    timers_1.add("timer-name-0", 0.0)
    assert timers_1.max("timer-name-0") == 0.0
    timers_1.add("timer-name-1", -0.1)
    assert timers_1.max

# Generated at 2022-06-25 15:18:03.134907
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    value = 0.7658770783949334
    name = "name"
    timers_0.add(name, value)
    return timers_0.max(name)

# Generated at 2022-06-25 15:18:06.748674
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("get_config",4.99)
    assert_equals(timers_0.max("get_config"),4.99)


# Generated at 2022-06-25 15:18:11.065251
# Unit test for method median of class Timers
def test_Timers_median():
    # Setup the variables
    timers = Timers({'make_db': 0.5953, 'make_sims': 0.1771, 'parse_pg': 0.3438})

    # We expect the result to be 0.3438
    assert timers.median('parse_pg') == 0.3438



# Generated at 2022-06-25 15:18:19.784487
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('timer', 0.5)
    timers.add('timer', 1)
    median = timers.median('timer')
    assert median == 0.5
    timers.clear()
    timers.add('timer', 0)
    timers.add('timer', 1)
    median = timers.median('timer')
    assert median == 0.5
    timers.clear()
    timers.add('timer', 1)
    timers.add('timer', 0)
    median = timers.median('timer')
    assert median == 0.5
    timers.clear()
    timers.add('timer', 0)
    timers.add('timer', 0)
    median = timers.median('timer')
    assert median == 0.0


# Generated at 2022-06-25 15:18:21.744471
# Unit test for method mean of class Timers
def test_Timers_mean():
    name = 0
    timers_0 = Timers()
    # Testing the output with a random value
    assert not math.isnan(timers_0.mean(name))


# Generated at 2022-06-25 15:18:23.479346
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("key_1", 7.0)
    assert timers_0.mean("key_1") == 7.0

# Generated at 2022-06-25 15:18:37.695821
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.add(name="key_01", value=0.1)
    timers_0.add(name="key_01", value=0.2)
    timers_0.add(name="key_01", value=0.3)
    assert timers_0.median(name="key_01") == 0.2
    timers_0.add(name="key_01", value=0.4)
    timers_0.add(name="key_01", value=0.5)
    assert timers_0.median(name="key_01") == 0.3
    timers_0.add(name="key_02", value=0.1)
    timers_0.add(name="key_02", value=0.2)

# Generated at 2022-06-25 15:18:42.901743
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    assert timers_0.max('name_0') == 0.0


# Generated at 2022-06-25 15:18:44.539591
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    assert not timers_0.min("dDvxqA")


# Generated at 2022-06-25 15:18:50.022752
# Unit test for method median of class Timers
def test_Timers_median():
    timers = Timers()
    timers.add('Test 1', 1)
    timers.add('Test 1', 3)
    timers.add('Test 1', 5)
    assert timers.median('Test 1') == 3


# Generated at 2022-06-25 15:18:59.102368
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    timers_1.add("name_1", 0.5)
    timers_1.add("name_2", 0.5)
    timers_1.add("name_1", 0.5)
    timers_1.add("name_2", 0.5)
    assert math.isclose(
        timers_1.max("name_1"),
        0.5,
        rel_tol=0.0,
        abs_tol=0.0,
    )
    assert math.isclose(
        timers_1.max("name_3"),
        0.0,
        rel_tol=0.0,
        abs_tol=0.0,
    )

# Generated at 2022-06-25 15:19:03.216841
# Unit test for method min of class Timers
def test_Timers_min():
    timers = Timers()
    timers.add('w', 0.3)
    timers.add('x', 0.1)
    timers.add('y', 0.2)
    assert timers.min('x') == 0.1
    assert timers.min('y') == 0.2
    assert timers.min('w') == 0.3


# Generated at 2022-06-25 15:19:08.731195
# Unit test for method mean of class Timers
def test_Timers_mean():
    def test_func(timers):
        timers.add("foo", 0.01)
        timers.add("foo", 0.01)
        timers.add("bar", 0.01)
        assert timers.data["foo"] == 0.02
        assert timers.data["bar"] == 0.01
        assert timers.mean("foo") == 0.01
        assert timers.mean("bar") == 0.01

    for timers in (Timers(), Timers({})):
        test_func(timers)

# Generated at 2022-06-25 15:19:11.688608
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    var_0 = timers_0.median('0')
    assert var_0 == 0.0


# Generated at 2022-06-25 15:19:17.355938
# Unit test for method min of class Timers
def test_Timers_min():
    timer = Timers()
    timer.add('time', 1.0)
    timer.add('time', 2.0)
    timer.add('time', 3.0)
    timer.add('time', 4.0)

    assert timer.min('time') == 1.0


# Generated at 2022-06-25 15:19:19.301986
# Unit test for method max of class Timers
def test_Timers_max():
    timers_1 = Timers()
    name = ""
    assert timers_1.max(name) == 0


# Generated at 2022-06-25 15:19:28.420806
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('time', 0.3883)
    timers_0.add('time', 0.4551)
    assert timers_0.min(name='time') == 0.3883



# Generated at 2022-06-25 15:19:30.417163
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    try:
        assert 0 == timers_0.max("timer0")
    except KeyError:
        pass


# Generated at 2022-06-25 15:19:32.461985
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers = Timers()
    timers.add('func_0', 1.0)
    assert timers.mean('func_0') == 1.0


# Generated at 2022-06-25 15:19:39.054682
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add('q1apVp8AjS', -5.052834103)
    timers_0.add('bFp', 1.7088)
    timers_0.add('2C', -9.1808668312)
    timers_0.add('drhE', 0.5632)
    timers_0.add('YwKm', -4.6908695)
    timers_0.add('S', -9.1808668312)
    timers_0.add('cKfv', -6.0358656)
    timers_0.add('YD8', -9.55684675)
    timers_0.add('Oj', -9.1808668312)

# Generated at 2022-06-25 15:19:48.903694
# Unit test for method mean of class Timers
def test_Timers_mean():

    # Test case with invalid parameter
    timers_0 = Timers()
    try:
        result = timers_0.mean("name")
    except KeyError as e:
        print(e)
    else:
        assert False, "Expected an exception"

    # Test case with valid parameter
    timers_0 = Timers()
    timers_0._timings["name"] = [1.5, 2.5, 3]
    expected = 2.0
    result = timers_0.mean("name")
    assert result == expected
    timers_0._timings["name"] = []
    expected = 0.0
    result = timers_0.mean("name")
    assert result == expected



# Generated at 2022-06-25 15:19:54.321015
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0 = Timers()
    timers_0.data["p1"] = 1.0
    timers_0._timings["p1"] = [6.0, 6.0, 9.0, 6.0, 9.0]
    exception = Timers.median
    exception(timers_0, "p1")



# Generated at 2022-06-25 15:19:57.516722
# Unit test for method median of class Timers
def test_Timers_median():
    timers_0_0 = Timers()
    timers_0_0.add("time", 1.0)
    timers_0_0.add("time", 2.0)
    assert timers_0_0.median("time") == 1.5


# Generated at 2022-06-25 15:20:00.286570
# Unit test for method median of class Timers
def test_Timers_median():
    """Test median"""
    timers_1 = Timers({"a": 100.0, "b": 200.0})
    assert timers_1.median("a") == 100.0

# Generated at 2022-06-25 15:20:02.106839
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    timers_0.add("test_item", 1.0)
    assert timers_0.max("test_item") == 1.0


# Generated at 2022-06-25 15:20:07.610666
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    name_0 = ''
    exception = KeyError()
    try:
        timers_0.min(name_0)
    except KeyError:
        assert type(exception) == type(exception)
        assert str(exception) == str(exception)
    else:
        assert False


# Generated at 2022-06-25 15:20:18.598336
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("wYbY;{G$M", 5.5)
    timers_0.add("wYbY;{G$M", 3.5)
    assert timers_0.mean("wYbY;{G$M") == 4.5


# Generated at 2022-06-25 15:20:21.269548
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    value_0 = timers_0.min(name='name_0')
    value_1 = timers_0.min(name='name_19')
    value_2 = timers_0.min(name='name_28')


# Generated at 2022-06-25 15:20:29.782107
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    name_2 = ""
    value_0 = 0
    timers_0.data[name_2] = value_0
    timers_0.data[name_2] += value_0
    timers_0.data[name_2] += value_0
    timers_0.data[name_2] += value_0
    timers_0.data[name_2] += value_0
    name_0 = ""
    assert timers_0.mean(name=name_0) == 0

# Generated at 2022-06-25 15:20:31.520418
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    # Call method 
    timers_0.max()


# Generated at 2022-06-25 15:20:36.316351
# Unit test for method max of class Timers
def test_Timers_max():
    import random
    #
    # Make a Timers
    #
    timers = Timers()
    #
    # Add some values
    #
    timers.add("foo", 3)
    assert timers["foo"] == 3
    timers.add("foo", 5)
    assert timers["foo"] == 8
    timers.add("foo", 4)
    assert timers["foo"] == 12
    #
    # Check max
    #
    assert timers.max("foo") == 5


# Generated at 2022-06-25 15:20:41.050938
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add('a', 1)
    timers_0.add('a', 3)
    timers_0.add('a', 5)
    assert timers_0.mean('a') == 3


# Generated at 2022-06-25 15:20:47.136191
# Unit test for method median of class Timers
def test_Timers_median():
    # Parameters
    name: str = 'name_0'
    # Setup
    timers_0 = Timers()
    # Testing
    # Raises unhandled exception
    try:
        median(timers_0, name)
    except Exception as exc:
        assert True
    else:
        assert False
    # Tested method is called 1 times
    # Tested method is called with all parameters
    # Tested method is called with all arguments


# Generated at 2022-06-25 15:20:49.766921
# Unit test for method max of class Timers
def test_Timers_max():
    timers_0 = Timers()
    try:
        timers_0.max(str_0)
        assert False
    except KeyError:
        pass


# Generated at 2022-06-25 15:21:00.022275
# Unit test for method median of class Timers
def test_Timers_median():
    timer_1 = Timers()
    assert timer_1.median('timers_1') == 0
    timer_1.add('timers_1', 50)
    assert timer_1.median('timers_1') == 50
    timer_1.add('timers_1', 60)
    timer_1.add('timers_1', 90)
    timer_1.add('timers_1', 10)
    timer_1.add('timers_1', 20)
    timer_1.add('timers_1', 100)
    assert timer_1.median('timers_1') == 50


# Generated at 2022-06-25 15:21:01.137920
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    with pytest.raises(Exception):
        timers_0.min("")

# Generated at 2022-06-25 15:21:21.369548
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()
    timers_0.add("str_0", 1.0)
    assert timers_0.mean("str_0") == 1.0
    timers_0.add("str_1", 0.0)
    assert timers_0.mean("str_1") == 0.0
    timers_0.add("str_2", 0.25)
    assert timers_0.mean("str_2") == 0.25


# Generated at 2022-06-25 15:21:30.889624
# Unit test for method min of class Timers
def test_Timers_min():
    timers_0 = Timers()
    timers_0.add('string', 0.0)
    timers_0.add('string', 1.0)
    timers_0.add('string', 0.0)
    timers_0.add('string', 0.0)
    timers_0.add('string', 1.0)
    timers_0.add('string', 0.0)
    timers_0.add('string', 0.0)
    timers_0.add('string', 0.0)
    timers_0.add('string', 0.0)
    timers_0.add('string', 1.0)
    timers_0.count('string')
    timers_0.total('string')
    timers_0.max('string')
    timers_0.std('string')
    timers_0.min('string')


# Generated at 2022-06-25 15:21:34.381922
# Unit test for method mean of class Timers
def test_Timers_mean():
    timers_0 = Timers()

    total_0 = timers_0.mean("test_name_1")

    assert total_0 == 0.0
