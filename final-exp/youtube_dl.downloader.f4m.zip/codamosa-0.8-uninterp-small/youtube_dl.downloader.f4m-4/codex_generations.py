

# Generated at 2022-06-26 11:14:05.520760
# Unit test for constructor of class F4mFD
def test_F4mFD():
    assert F4mFD(None, None, None) is not None


# Generated at 2022-06-26 11:14:14.270807
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-26 11:14:27.343943
# Unit test for function build_fragments_list
def test_build_fragments_list():
    from random import randint, seed
    from collections import defaultdict

    # Test cases for build_fragments_list()
    for case_no in range(10):
        # Both the segment_run and fragment_run_entry are increasing.
        # The first_frag_number is any value.
        # The segment_run can repeat the same segment.
        # The fragment_run_entry should not repeat the same `first`.
        # The `first` are not continuous.
        segment_run_table = defaultdict(lambda: defaultdict(list))
        segment_run_table['segment_run'][0] = []
        fragment_run_entry_table = defaultdict(lambda: defaultdict(list))
        fragment_run_entry_table['fragments'][0]['fragments'] = []
        seed(0) 

# Generated at 2022-06-26 11:14:34.909408
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    """
    It tests the following situations for method read_box_info of class FlvReader:
    1. Test case 1: when the box has type 'mdat' in method read_box_info of class FlvReader.
    2. Test case 2: when the box has type 'abst' in method read_box_info of class FlvReader.
    3. Test case 3: when the box has type 'asrt' in method read_box_info of class FlvReader.
    """
    # object to be tested
    reader = FlvReader(b'\x00\x00\x00\x01\x6D\x64\x61\x74\x01\x00\x00\x00\x01')
    # test case 1: when the box has type 'mdat' in method read_box_info of class Fl

# Generated at 2022-06-26 11:14:40.100264
# Unit test for function build_fragments_list
def test_build_fragments_list():
    dict_0 = {}
    var_0 = build_fragments_list(dict_0)

# Generated at 2022-06-26 11:14:50.857010
# Unit test for constructor of class F4mFD
def test_F4mFD():
    obj = F4mFD({}, None)
    var_0 = obj.report_warning
    var_1 = obj.to_screen
    var_2 = obj.report_error
    var_3 = obj._prepare_url
    var_4 = obj.report_destination
    var_5 = obj.params
    var_6 = obj.ydl
    var_7 = obj._determine_protocol
    var_8 = obj.to_stdout
    var_9 = obj.max_filesize
    var_10 = obj.cachedir
    var_11 = obj.add_extra_info
    var_12 = obj.config
    var_13 = obj.report_warning
    var_14 = obj.to_screen
    var_15 = obj.report_error
    var_16 = obj._

# Generated at 2022-06-26 11:14:55.173114
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader(b"\x00\x00\x00\x00\x00\x00\x00\x00")
    assert reader.read_string() == b''
    assert reader.read_string() == b''


# Generated at 2022-06-26 11:14:57.757557
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # For F4mFD.real_download() passed in test case #0
    pass



# Generated at 2022-06-26 11:15:10.899282
# Unit test for function get_base_url

# Generated at 2022-06-26 11:15:13.457743
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 11:16:41.146402
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = '''
    <media url="http://test.com/test.mp4"
           bitrate="12"
           width="1280"
           height="720"
           type="video"
           bootstrapInfoId="bootstrap"
           profile="urn:mpeg:dash:profile:isoff-live:2011"
           drmAdditionalHeaderId="header"
           drmAdditionalHeaderSetId="headerSet"
    />
    '''

    etree_0 = compat_etree_fromstring(xml)
    var_0 = remove_encrypted_media(etree_0)

    assert len(var_0) == 0



# Generated at 2022-06-26 11:16:43.600983
# Unit test for function get_base_url
def test_get_base_url():
    base_url = get_base_url(None)
    print("Base url is {}".format(base_url))
    assert base_url == None


# Generated at 2022-06-26 11:16:47.265657
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_afrt()


# Generated at 2022-06-26 11:16:50.122162
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_afrt()


# Generated at 2022-06-26 11:16:52.982890
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4m_FD = F4mFD(None)
    info_dict = {}
    f4m_FD.real_download("filename", info_dict)
    # Test failed
    assert False


# Generated at 2022-06-26 11:17:02.757455
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    asrt_0 = {'segment_run': [(0, 1), (1, 1)]}
    afrt_0 = {
        'fragments': [
            {'first': 0, 'duration': 60, 'ts': 0, 'discontinuity_indicator': None},
            {'first': 1, 'duration': 60, 'ts': 60000000, 'discontinuity_indicator': None},
        ]}
    abst = {
        'live': False,
        'segments': [asrt_0],
        'fragments': [afrt_0],
    }


# Generated at 2022-06-26 11:17:05.229902
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_1 = FlvReader()
    var_1 = flv_reader_1.read_abst()
    var_1 = flv_reader_1.read_abst()


# Generated at 2022-06-26 11:17:14.667016
# Unit test for function remove_encrypted_media

# Generated at 2022-06-26 11:17:21.730637
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    filename_0 = 'unit_test_F4mFD_real_download.txt'
    url_0 = 'http://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId=1722206785001'
    outtmpl_0 = '%(autonumber)s.%(ext)s'
    fmturl_0 = 'rtmp://cp63676.edgefcs.net/ondemand?auth=daEbdaIbieb4cbOeUc_baPbSbUfga6aH-b1d4bM-b4a4b4-bcPsbP-d6Ynb-c1yb-b0uj-f2b6-b5Ib'

# Generated at 2022-06-26 11:17:27.055670
# Unit test for function get_base_url
def test_get_base_url():
    test_file_name = 'test_manifest_1'
    f = open(test_file_name, 'r')
    f.seek(0)
    test_case_1 = f.read()
    f.close()
    tree = compat_etree_fromstring(test_case_1)
    base_url = get_base_url(tree)
    assert base_url == '/f4m/m3u8'



# Generated at 2022-06-26 11:18:22.319831
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    # _bootstrap_info = flv_reader.read_abst()

    # Initialize FlvReader object
    flv_reader = FlvReader()

    # Execute method read_abst
    _bootstrap_info = flv_reader.read_abst()


# Generated at 2022-06-26 11:18:33.425348
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader = FlvReader(compat_b64decode(FRAGMENT_FD_BASE64))
    flv_reader.read_bootstrap_info()

# Base64 encoding of a sample flv file
# Assign it to FRAGMENT_FD_BASE64 before running the unit tests
# You can generate it by following steps:
# 1. wget https://raw.githubusercontent.com/rg3/youtube-dl/master/tests/resources/bif/test0.flv
# 2. python -c 'import base64; file = open("test0.flv", "rb"); print base64.b64encode(file.read())'

# Generated at 2022-06-26 11:18:36.693293
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader = FlvReader()
    info = flv_reader.read_abst()
    assert info['segments'] != []
    assert info['fragments'] != []
    assert isinstance(info['live'], bool)



# Generated at 2022-06-26 11:18:46.868654
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring('''\
<manifest xmlns="http://ns.adobe.com/f4m/1.0">
  <id>0_zna8q3y9</id>
  <mimeType>video/x-flv</mimeType>
  <streamType>live</streamType>
  <deliveryType>streaming</deliveryType>
  <media href="manifest.f4m"/>
  <bootstrapInfo profile="named" id="bootstrap0" url="https://example.com/bootstrap"/>
  <metadata>
    <session duration="14400000" startTime="1537884500294000" sequence="0"/>
    <ttl>14400000</ttl>
  </metadata>
</manifest>
        ''')
    test_

# Generated at 2022-06-26 11:18:54.119413
# Unit test for function build_fragments_list
def test_build_fragments_list():
    flv_reader = FlvReader()
    boot_info = flv_reader.read_bootstrap_info()
    fragments = build_fragments_list(boot_info)
    print("Number of fragments: " + str(len(fragments)))
    last_segment_number = fragments[-1][0]
    last_fragment_number = fragments[-1][1]
    if boot_info['live']:
        assert(last_segment_number == 0)
        assert(last_fragment_number == 1)

if __name__ == '__main__':
    test_case_0()
    test_build_fragments_list()

# Generated at 2022-06-26 11:18:55.571939
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_abst()


# Generated at 2022-06-26 11:19:05.802668
# Unit test for function get_base_url
def test_get_base_url():
    xml_str = b'<manifest xmlns="http://ns.adobe.com/f4m/2.0" />'
    manifest = compat_etree_fromstring(fix_xml_ampersands(xml_str))
    base_url = get_base_url(manifest)
    assert base_url is None

    xml_str = b'<manifest xmlns="http://ns.adobe.com/f4m/2.0"><baseURL>base url</baseURL></manifest>'
    manifest = compat_etree_fromstring(fix_xml_ampersands(xml_str))
    base_url = get_base_url(manifest)
    assert base_url == 'base url'


# Generated at 2022-06-26 11:19:17.376617
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Initialization block
    fd = F4mFD()
    """
    TEST_CASE_0
    """
    filename = "filename"
    info_dict = {'url': 'url'}
    assert fd.real_download(filename, info_dict) == True
    """
    TEST_CASE_1
    """
    filename = "filename"
    info_dict = {'url': '/'}
    assert fd.real_download(filename, info_dict) == True
    """
    TEST_CASE_2
    """
    filename = "filename"
    info_dict = {'url': 'https://github.com/ytdl-org/youtube-dl/issues/7823'}
    assert fd.real_download(filename, info_dict) == True


# Generated at 2022-06-26 11:19:20.420812
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader = FlvReader()
    (real_size, box_type, box_data) = flv_reader.read_box_info()
    assert real_size == 13
    assert box_type == b'abst'


# Generated at 2022-06-26 11:19:22.069156
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_bootstrap_info()


# Generated at 2022-06-26 11:21:04.060548
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:21:07.306394
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_afrt()


# Generated at 2022-06-26 11:21:17.218246
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:21:21.585911
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4m_fd_instance = F4mFD()
    f4m_fd_instance.real_download(None, None)

if __name__ == '__main__':
    test_case_0()
    test_F4mFD_real_download()

# Generated at 2022-06-26 11:21:30.717281
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader_0 = FlvReader()
    bootstrap_info = flv_reader_0.read_bootstrap_info()
    for segment in bootstrap_info['segments']:
        for first_segment, fragments_per_segment in segment['segment_run']:
            print('first_segment=%s, fragments_per_segment=%s' % (
                first_segment, fragments_per_segment))
    print('bootstrap_info=%s' % bootstrap_info)
    var_0 = len(bootstrap_info['segments'])
    var_1 = len(bootstrap_info['fragments'])
    var_2 = bootstrap_info['live']


# Generated at 2022-06-26 11:21:32.090131
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    bootstrap_info = FlvReader(base64_data).read_bootstrap_info()


# Generated at 2022-06-26 11:21:37.659904
# Unit test for function get_base_url
def test_get_base_url():
    #get base url from manifest
    manifest = compat_etree_fromstring("""
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <baseURL>http://example.com/</baseURL>
        <media>
        <URL>video.mp4</URL>
        </media>
    </manifest>
    """).getroot()
    #match base_url, test passed
    if get_base_url(manifest.findall('.')) == "http://example.com/":
        print("test get_base_url: passed")
    else:
        print("test get_base_url: failed")


# Generated at 2022-06-26 11:21:48.037106
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media_files = [
        compat_etree_fromstring(
        "<MediaFile bitrate='500000' url='QualityLevels(500000)/Fragments(audio=0)' />"),
        compat_etree_fromstring(
        "<MediaFile bitrate='650000' url='QualityLevels(650000)/Fragments(video=0)' drmAdditionalHeaderSetId='1' drmAdditionalHeaderId='2' />"),
        compat_etree_fromstring(
        "<MediaFile bitrate='4000000' url='QualityLevels(4000000)/Fragments(video=0)' />")
    ]

# Generated at 2022-06-26 11:21:54.815232
# Unit test for function get_base_url
def test_get_base_url():
    var_0 = "http://player.ooyala.com/player/all/NqZmk3ZDE6bjqTFS6CKz6UeL6wFb6-RS.m3u8"
    temp_0 = compat_urllib_parse_urlparse(var_0)
    var_1 = compat_urlparse.urlunparse((temp_0.scheme, temp_0.netloc, '', '', '', ''))
    temp_1 = get_base_url(var_1)
    print(temp_1)
    print(temp_1)


# Generated at 2022-06-26 11:22:04.828087
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_abst()
    assert var_0 is not None
    assert len(var_0.get('segments')) == 1
    assert len(var_0.get('fragments')) == 1
    segments = var_0.get('segments')[0]
    assert len(segments.get('segment_run')) == 10
    segment_run_0 = segments.get('segment_run')[0]
    assert segment_run_0[0] == 1
    assert segment_run_0[1] == 2
    segment_run_9 = segments.get('segment_run')[9]
    assert segment_run_9[0] == 10