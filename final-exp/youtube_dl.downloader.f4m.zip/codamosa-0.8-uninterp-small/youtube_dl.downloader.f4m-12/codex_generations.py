

# Generated at 2022-06-26 11:13:46.155248
# Unit test for function write_flv_header
def test_write_flv_header():
    test_f = io.BytesIO()
    write_flv_header(test_f)
    test_f.seek(0)
    flv_reader_0 = FlvReader(test_f.read())
    assert(flv_reader_0.read_bytes(1) == b'F')
    assert(flv_reader_0.read_unsigned_long_long() == 9)
    assert(len(test_f.read()) == 0)


# Generated at 2022-06-26 11:13:49.874916
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader = FlvReader()
    flv_reader.read_afrt()


# Generated at 2022-06-26 11:13:54.432337
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv_reader_1 = FlvReader()
    flv_reader_1.write(compat_struct_pack("!I", 1))
    flv_reader_1.seek(0)

    assert flv_reader_1.read_bytes(6) == b'\x00\x00\x00\x01'


# Generated at 2022-06-26 11:14:02.261698
# Unit test for function get_base_url

# Generated at 2022-06-26 11:14:04.460761
# Unit test for constructor of class F4mFD
def test_F4mFD():
    ydl_opts = {
        'skip_download': True
    }
    ydl = YoutubeDL(ydl_opts)

    f4m_fd = F4mFD(ydl)
    assert f4m_fd.ydl is ydl



# Generated at 2022-06-26 11:14:13.920818
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    # Test0: Write data to a stream correctly
    flv_reader_0 = FlvReader()
    stream_0 = io.BytesIO()

    metadata_0 = b"the metadata"
    write_metadata_tag(stream_0, metadata_0)

    # Keep writing metadata until it is bigger than 2bytes
    stream_1 = io.BytesIO()
    metadata_1 = b"a"
    num_metadata = 1
    
    while len(metadata_1) < 2:
        metadata_1 = metadata_1 + b"a"
        num_metadata += 1
        write_metadata_tag(stream_1, metadata_1)

# Generated at 2022-06-26 11:14:27.186108
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:14:34.386210
# Unit test for constructor of class F4mFD
def test_F4mFD():
    class FakeYDL:
        def __init__(self):
            self.to_screen = print
            self.report_warning = print
            self.report_error = print
    class FakeInfoDict:
        def __init__(self):
            self.report_warning = print

    ydl = FakeYDL()
    url = 'http://test.test/test.f4m'
    info_dict = FakeInfoDict()
    fd = F4mFD(ydl, info_dict)
    filename = 'test.mp4'

    # Test real_download function
    fd.real_download(filename, info_dict)
    assert fd.real_download(filename, info_dict) == True


# Generated at 2022-06-26 11:14:47.815435
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:14:59.655430
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:15:28.803800
# Unit test for constructor of class F4mFD
def test_F4mFD():
    f4m_fd = F4mFD()


# Generated at 2022-06-26 11:15:37.074817
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    # get file test_cases/test_0/bootstrap.abst
    fd = open('test_cases/test_0/bootstrap.abst', 'rb')
    flv_reader = FlvReader(fd.read())
    fd.close()
    info = flv_reader.read_bootstrap_info()
    assert info['segments'][0]['segment_run'][0] == (0, 0)
    assert info['segments'][0]['segment_run'][1] == (1, 1)
    assert info['fragments'][0]['fragments'][0]['first'] == 0
    assert info['fragments'][0]['fragments'][1]['first'] == 1

# Generated at 2022-06-26 11:15:43.552453
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    a = io.BytesIO()
    # Test case 0
    a.write(b'\x00\x00\x00\x00')
    write_metadata_tag(a, None)
    b = io.BytesIO()
    b.write(b'\x12')
    write_unsigned_int_24(b, 0)
    b.write(b'\x00\x00\x00\x00\x00\x00\x00')
    write_unsigned_int(b, 11)
    assert(a.getvalue() == b.getvalue())


# Generated at 2022-06-26 11:15:45.450959
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_0 = FlvReader(open("sample_afrt", "rb").read())
    flv_reader_0.read_afrt()


# Generated at 2022-06-26 11:15:54.785295
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    # Case 1: The media has no encrypted element
    media_case_1 = [{'attr1': 'value1'}, {'attr2': 'value2'}]
    media_case_2 = [{'attr1': 'value1', 'drmAdditionalHeaderId': ''},
                    {'attr2': 'value2'}]
    media_case_3 = [{'attr1': 'value1', 'drmAdditionalHeaderSetId': ''},
                    {'attr2': 'value2'}]
    expected_case_1 = [{'attr1': 'value1'}, {'attr2': 'value2'}]
    expected_case_2 = [{'attr2': 'value2'}]
    expected_case_3 = [{'attr2': 'value2'}]

# Generated at 2022-06-26 11:15:58.924514
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    ydl = YoutubeDL()
    f4m_fd = F4mFD(ydl)
    f4m_fd.real_download('file.flv', {
        'url': 'http://example.com/test.f4m',
    })


# Generated at 2022-06-26 11:16:08.927200
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:16:17.879290
# Unit test for function get_base_url

# Generated at 2022-06-26 11:16:21.815442
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    # flv_reader_0 is a FlvReader object
    flv_reader_0 = FlvReader()
    # b'smth' is 'bytes' object
    b'smth'
    # _io.BytesIO is a constructor of type 'type'
    _io.BytesIO
    # b'\x00\x00\x00\x05' is 'bytes' object
    b'\x00\x00\x00\x05'
    # b'\x00\x00\x00\x00\x00\x00\x00\x00' is 'bytes' object
    b'\x00\x00\x00\x00\x00\x00\x00\x00'
    # b'\x00\x00\x00\x00\x00\x00\x

# Generated at 2022-06-26 11:16:23.874857
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader = FlvReader()
    flv_reader.read_bootstrap_info()


# Generated at 2022-06-26 11:17:03.463453
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    pass


# Generated at 2022-06-26 11:17:04.689671
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    assert True == F4mFD().real_download('', {})


# Generated at 2022-06-26 11:17:06.261112
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_0 = FlvReader()
    flv_reader_0.read_abst()


# Generated at 2022-06-26 11:17:07.896381
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader_0 = FlvReader()
    total_size, box_type, box_data = flv_reader_0.read_box_info()


# Generated at 2022-06-26 11:17:14.550478
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    print('I\'m here')
    # flv_reader_test = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00ABCDEFGHIJKLMN')
    flv_reader_test = FlvReader(b'\x10\x00\x00\x00abcd\x00\x00\x00\x01ABCDEFGHIJKLMN')
    print(flv_reader_test.read_string())


# Generated at 2022-06-26 11:17:21.617679
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:17:30.573888
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # http://stackoverflow.com/questions/21292648/python-2-7-flvreader-error-need-bytes-while-only-bytes-got
    import os
    path = os.path.dirname(__file__)
    # Bootstrap info for 4-segment stream http://www.youtube.com/tv#/watch?v=gYn3qV7IuPQ
    with open(os.path.join(path, 'bootstrap_info_0.dat'), 'rb') as f:
        bootstrap_info = FlvReader(f.read()).read_bootstrap_info()

# Generated at 2022-06-26 11:17:32.463805
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_1 = FlvReader()
    flv_reader_1.read_afrt()


# Generated at 2022-06-26 11:17:42.803685
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:17:49.610198
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    print ('***** Begin unit test of remove_encrypted_media *****')

# Generated at 2022-06-26 11:18:42.841667
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:18:52.925517
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    assert flv_reader.read_box_info() == (0, b'', b''), flv_reader.read_box_info()
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00test')
    assert flv_reader.read_box_info() == (0, b'', b''), flv_reader.read_box_info()
    flv_reader = FlvReader(b'\x00\x00\x00\x01\x00\x00\x00\x00')

# Generated at 2022-06-26 11:18:59.301100
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    from random import randrange
    flv_reader_0 = FlvReader()
    for i in range(5):
        flv_reader_0.seek(0)
        for j in range(randrange(0, 5)):
            flv_reader_0.read_unsigned_int()
            flv_reader_0.read_bytes(4)
        flv_reader_0.read_afrt()
        flv_reader_0.read_string()


# Generated at 2022-06-26 11:19:09.576900
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [1, 2, 3, 4]
    media[0].attrib = {'drmAdditionalHeaderId': '0', 'drmAdditionalHeaderSetId': '1'}
    media[1].attrib = {'drmAdditionalHeaderId': '1', 'drmAditionalHeaderSetId': '0'}
    media[2].attrib = {'drmAdditionalHeaderId': '2', 'drmAdditionalHeaderSetId': '2'}
    media[3].attrib = {'drmAdditionalHeaderSetId': '3', 'drmAdditionalHeaderId': '3'}
    l = remove_encrypted_media(media)
    assert len(l) == 1
    assert l[0] == media[2]


# Generated at 2022-06-26 11:19:18.644281
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    with io.open('test.dat', 'rb') as f:
        flv_reader = FlvReader(f.read())
        box_size, box_type, box_data = flv_reader.read_box_info()
        print('box_size: %d; box_type: %s; box_data: %s' % (
            box_size, box_type, box_data))
        print('box_size: %d; box_type: %s; box_data: %s' % (
            flv_reader.read_unsigned_int(), flv_reader.read_bytes(4), flv_reader.read_bytes(box_size - 8)))


# Generated at 2022-06-26 11:19:21.903059
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    file_name = 'bootstrapinfo.test.box'
    with open(file_name, 'rb') as f:
        data = f.read()
    flv_reader = FlvReader(data)
    flv_reader.read_bootstrap_info()
    test_case_0()


# Generated at 2022-06-26 11:19:26.601083
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    string_value = b'\x63\x61\x74'
    string_length = len(string_value)
    flv_reader = FlvReader()
    for i in range(string_length + 1):
        flv_reader.seek(i)
        assert flv_reader.read_string() == string_value


# Generated at 2022-06-26 11:19:33.611488
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    for test_case_num in range(0, 1):
        if test_case_num == 0:
            # Initialize test case
            flv_reader_0 = FlvReader()

            # Call method (actual test starts here)
            result = flv_reader_0.read_box_info()

            # Confirm result
            assert result == (8, b'type', b'')


# Generated at 2022-06-26 11:19:41.956180
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_box_info()
    assert var_0[0] == 0xE
    assert var_0[1] == b'ftyp'
    assert var_0[2] == b'isomiso2avc1'
    var_0 = flv_reader_0.read_box_info()
    assert var_0[0] == 0x1C
    assert var_0[1] == b'moov'
    # TODO: check moov data
    var_0 = flv_reader_0.read_box_info()
    assert var_0[0] == 0x20
    assert var_0[1] == b'mvex'
    # TODO: check mvex data
    var_

# Generated at 2022-06-26 11:19:47.203733
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_string()
    assert var_0 == b''

    flv_reader_1 = FlvReader(b'\x00')
    var_1 = flv_reader_1.read_string()
    assert var_1 == b''

    flv_reader_2 = FlvReader(b'\x00\x00')
    var_2 = flv_reader_2.read_string()
    assert var_2 == b''

    flv_reader_3 = FlvReader(b'\x01\x00')
    var_3 = flv_reader_3.read_string()
    assert var_3 == b'\x01'


# Generated at 2022-06-26 11:20:32.047129
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader = FlvReader()
    flv_reader.read_afrt()


# Generated at 2022-06-26 11:20:40.101213
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader_0 = FlvReader()
    var_0 = io.BytesIO()
    var_0.write(b'\x00\x00\x00\x00')
    var_0.write(b'\x00\x00\x00\x01')
    var_0.write(b'\x00\x00\x00\x00')
    var_0.seek(0)
    flv_reader_0 = FlvReader(var_0.read())
    var_1 = flv_reader_0.read_box_info()
    assert var_1[0] == 1
    assert var_1[1] == b'\x00\x00\x00\x01'
    assert var_1[2] == b''


# Generated at 2022-06-26 11:20:46.935134
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    assert(remove_encrypted_media([1, 2, 3, 4]) == [1, 2, 3, 4])
    assert(remove_encrypted_media(['a', 1, 2, 3, 4]) == ['a', 1, 2, 3, 4])
    assert(remove_encrypted_media(['a', 1, 2, 3, 'drmAdditionalHeaderSetId', 4]) == ['a', 1, 2, 3, 4])
    assert(remove_encrypted_media(['drmAdditionalHeaderSetId', 1, 2, 3, 4]) == [1, 2, 3, 4])


# Generated at 2022-06-26 11:20:49.279628
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_0 = FlvReader()
    flv_reader_0.read_abst()


# Generated at 2022-06-26 11:20:51.055796
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_afrt()


# Generated at 2022-06-26 11:20:59.056399
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [(1, 3), (2, 3)],
        }],
        'fragments': [{
            'fragments': [{
                'first': 0,
                'ts': 0,
                'duration': 0,
                'discontinuity_indicator': None,
            }, {
                'first': 1,
                'ts': 0,
                'duration': 0,
                'discontinuity_indicator': None,
            }, {
                'first': 2,
                'ts': 0,
                'duration': 0,
                'discontinuity_indicator': None,
            }],
        }],
        'live': False,
    }

# Generated at 2022-06-26 11:21:00.107076
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_case_0()

test_FlvReader_read_string()


# Generated at 2022-06-26 11:21:04.753564
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    stream = io.BytesIO()
    metadata = b'\x00'
    write_metadata_tag(stream, metadata)
    assert stream.getvalue() == b'\x12\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'



# Generated at 2022-06-26 11:21:15.735586
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    class test_case_F4mFD_real_download():
        def __init__():
            url_have_not_been_tested = set()
            extractor_map = {}
            try:
                from youtube_dl.extractor import gen_extractors
                from youtube_dl.extractor.common import InfoExtractor
                for ie in gen_extractors():
                    extractor_map[ie.IE_NAME] = ie
            except ImportError:
                pass
            extractor_list = sorted(extractor_map.keys())

            def test_url(url, info_dict):
                if not info_dict.get('extractor'):
                    return
                if info_dict['extractor'] not in extractor_map:
                    return
                if url in url_have_not_been_tested:
                    return
               

# Generated at 2022-06-26 11:21:21.663299
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader_1 = FlvReader(b',test_string_\x00\x00test_string_2\x00test_string_3\x00')
    var_1 = flv_reader_1.read_string()
    var_1 = flv_reader_1.read_string()
    var_1 = flv_reader_1.read_string()


# Generated at 2022-06-26 11:23:15.615022
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_1 = FlvReader()
    flv_reader_2 = FlvReader()
    flv_reader_3 = FlvReader()
    flv_reader_4 = FlvReader()
    flv_reader_5 = FlvReader()
    flv_reader_6 = FlvReader()
    flv_reader_7 = FlvReader()
    flv_reader_8 = FlvReader()
    flv_reader_9 = FlvReader()
    flv_reader_10 = FlvReader()
    flv_reader_11 = FlvReader()
    flv_reader_12 = FlvReader()
    flv_reader_13 = FlvReader()
    flv_reader_14 = FlvReader()
    flv_reader_15 = FlvReader()
    flv_