

# Generated at 2022-06-26 11:14:34.349985
# Unit test for function build_fragments_list
def test_build_fragments_list():
    fragment_run_table = {}
    fragment_run_table['segments'] = [{'segment_run': [(0, 1), (1, 2)]}]
    fragment_run_table['fragments'] = [{'fragments': [{'first': 0, 'ts': 0, 'duration': 2000, 'discontinuity_indicator': None}, {'first': 1, 'ts': 2000, 'duration': 2000, 'discontinuity_indicator': None}, {'first': 2, 'ts': 4000, 'duration': 2000, 'discontinuity_indicator': None}]}]
    fragment_run_table['live'] = False
    fragments_list = build_fragments_list(fragment_run_table)
    print(fragments_list)

# Generated at 2022-06-26 11:14:47.816258
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:14:53.150843
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4m_fd_0 = F4mFD()


if __name__ == "__main__":
    test_case_0()
    # test_F4mFD_real_download()

# Generated at 2022-06-26 11:15:02.027626
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:15:13.977852
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader_0 = FlvReader()
    flv_reader_0.write(compat_struct_pack('!I', 6))
    flv_reader_0.write(b'asrt')
    flv_reader_0.write(compat_struct_pack('!B', 1))
    flv_reader_0.write(b'asdf\x00')
    flv_reader_0.write(compat_struct_pack('!I', 2))
    flv_reader_0.write(compat_struct_pack('!I', 2))
    flv_reader_0.write(compat_struct_pack('!I', 0))
    flv_reader_0.write(compat_struct_pack('!I', 2))
    flv_reader_0.seek(0)


# Generated at 2022-06-26 11:15:20.702129
# Unit test for function get_base_url
def test_get_base_url():
    manifest = """<manifest xmlns="http://ns.adobe.com/f4m/2.0">
    <baseURL>http://example.com/</baseURL>
    </manifest>"""
    base_url = get_base_url(manifest)
    assert base_url == "http://example.com/"


# Generated at 2022-06-26 11:15:22.558643
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader = FlvReader()
    flv_reader.read_abst()


# Generated at 2022-06-26 11:15:28.435371
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    # case 0
    flv_reader_0 = FlvReader()
    flv_reader_0.write(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    flv_reader_0.seek(0)
    res = flv_reader_0.read_afrt()
    assert res == {'fragments': [{'discontinuity_indicator': None, 'ts': 0, 'first': 0, 'duration': 0}]}


# Generated at 2022-06-26 11:15:32.375497
# Unit test for function get_base_url
def test_get_base_url():
    manifest_0 = '<manifest><baseURL>http://www.baidu.com</baseURL><media url="abc.ts" streamId="video" bootstrapInfoId="boot_0"></manifest>'
    manifest = compat_etree_fromstring(manifest_0)
    base_url = get_base_url(manifest)
    assert(base_url == "http://www.baidu.com")


# Generated at 2022-06-26 11:15:35.354560
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # Test case 0
    flv_reader_0 = FlvReader()

    # Test case 1
    flv_reader_1 = FlvReader()

    # Test case 2
    flv_reader_2 = FlvReader()



# Generated at 2022-06-26 11:16:07.788743
# Unit test for function build_fragments_list
def test_build_fragments_list():
    test_bootstrap_info = {
        "live": False,
        "fragments": [{
            "fragments": [
                {
                    "discontinuity_indicator": None,
                    "duration": 256,
                    "first": 0,
                    "ts": 7183952000
                }, {
                    "discontinuity_indicator": None,
                    "duration": 256,
                    "first": 1,
                    "ts": 7184240000
                }
            ]
        }],
        "segments": [{
            "segment_run": [(0, 2)]
        }]
    }

    assert build_fragments_list(test_bootstrap_info) == [(0, 0), (0, 1)]



# Generated at 2022-06-26 11:16:09.649672
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_0 = FlvReader()
    flv_reader_0.read_asrt()


# Generated at 2022-06-26 11:16:18.693464
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    FlvReader_0 = FlvReader()


# Generated at 2022-06-26 11:16:29.948288
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:16:31.756041
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    test_case_0()
    test_case_1()



# Generated at 2022-06-26 11:16:37.558224
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info_0 = {'segments': [{'segment_run': [(1, 1)]}], 'fragments': [{'fragments': [{'first': 0, 'ts': 0, 'duration': 0, 'discontinuity_indicator': None}]}], 'live': False}
    print(build_fragments_list(boot_info_0))

test_case_0()
test_build_fragments_list()



# Generated at 2022-06-26 11:16:40.656408
# Unit test for function get_base_url
def test_get_base_url():
    base_url = get_base_url(
        'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8')


# Generated at 2022-06-26 11:16:52.597620
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-26 11:17:02.394176
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:17:11.840540
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:20:09.133002
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    url = 'https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8'
    bootstrap_info = download_bootstrap_info(url)
    abst = FlvReader(bootstrap_info).read_abst()

    assert len(abst['segments']) == 10

# Generated at 2022-06-26 11:20:16.501801
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:20:28.301858
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_1 = FlvReader()

# Generated at 2022-06-26 11:20:37.310923
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    # Test case 0
    flv_reader_0 = FlvReader(
        b'd\x00\x00\x00\xafrt\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x00\x06\x00\x00\x00\x01\x07\x00\x00\x01\x00\x00\x00\x01\x8d\x0b\x00\
\x00')
    ret_0 = flv_reader_0.read_afrt()

# Generated at 2022-06-26 11:20:39.938358
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader_0 = FlvReader()


# Generated at 2022-06-26 11:20:48.103443
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4mFD_0 = F4mFD()
    filename = 'path//to/file'
    info_dict = {'url': 'http://www.example.com/tmp/f4m/manifest.f4m', 'extra_param_to_segment_url': 'key=val', 'urlhandle': 'http://www.example.com/tmp/f4m/manifest.f4m', 'protocol': 'http', 'title': 'f4m'}
    f4mFD_0.real_download(filename, info_dict)


# Generated at 2022-06-26 11:20:57.057002
# Unit test for function remove_encrypted_media

# Generated at 2022-06-26 11:21:08.717381
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:21:19.927564
# Unit test for function get_base_url

# Generated at 2022-06-26 11:21:31.653501
# Unit test for function get_base_url
def test_get_base_url():
    manifest_str = u'''
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <baseURL>example.com/</baseURL>
    </manifest>
    '''
    manifest = compat_etree_fromstring(fix_xml_ampersands(manifest_str))
    base_url = get_base_url(manifest)
    print('get_base_url: ', base_url)
    assert base_url == 'example.com/'

    manifest_str = u'''
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <baseURL></baseURL>
    </manifest>
    '''