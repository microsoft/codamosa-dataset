

# Generated at 2022-06-26 11:14:08.382789
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:14:15.964348
# Unit test for function get_base_url
def test_get_base_url():
    xml_str_0 = """<manifest xmlns="http://ns.adobe.com/f4m/2.0">
        """
    manifest_0 = compat_etree_fromstring(xml_str_0)
    manifest_1 = manifest_0
    base_url_0 = get_base_url(manifest_1)
    print(base_url_0)


# Generated at 2022-06-26 11:14:28.487586
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    flv_reader_0 = FlvReader()


# Generated at 2022-06-26 11:14:35.327297
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_1 = FlvReader()
    
    # First afrt box
    afrt_box_data = compat_b64decode(b'AAAAAAABAQIEBAQGBgYICgoKCgoKCgoKCgoKCgoKCg==')
    flv_reader_1 = FlvReader(afrt_box_data)
    flv_reader_1.read_afrt()
    
    # Second afrt box
    afrt_box_data = compat_b64decode(b'AAAAAAAAAgMEBAQGBgYICgoKCgoKCgoKCgoKCgoKCg==')
    flv_reader_1 = FlvReader(afrt_box_data)
    flv_reader_1.read_afrt()
    
    # Third afrt box
    afrt_box_data = compat

# Generated at 2022-06-26 11:14:38.512872
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # test_F4mFD_real_download_0
    # Empty case
    # Assertion:
    assert (False)


# Generated at 2022-06-26 11:14:50.285298
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info_0 = {'segments': [{'segment_run': [(0, 0), (1, 2)]}], 'fragments': [{'fragments': [{'ts': 0, 'duration': 10, 'first': 0, 'discontinuity_indicator': None}]}], 'live': False}
    boot_info_1 = {'segments': [{'segment_run': [(0, 3)]}], 'fragments': [{'fragments': [{'ts': 0, 'duration': 10, 'first': 0, 'discontinuity_indicator': None}]}], 'live': False}

# Generated at 2022-06-26 11:14:55.862936
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data_0 = b'\x00\x00\x00\x08\x66\x6f\x6f\x42\x61\x72'
    flv_reader_0 = FlvReader(data_0)
    return flv_reader_0.read_box_info()


# Generated at 2022-06-26 11:15:09.685999
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:15:22.228644
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:15:30.611494
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader = FlvReader()
    box_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00' # size = 0
    flv_reader.write(box_0)
    flv_reader.seek(0)
    assert flv_reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')
    box_1 = b'\x00\x00\x00\x02\x00\x00\x00\x00' # size = 2
    flv_reader.write(box_1)
    flv_reader.seek(0)

# Generated at 2022-06-26 11:16:04.269250
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:16:13.415850
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-26 11:16:19.270761
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4m_fd_0 = F4mFD()
    var_0 = f4m_fd_0._get_unencrypted_media()
    var_1 = f4m_fd_0._get_bootstrap_from_url()
    var_2 = f4m_fd_0._update_live_fragments()
    var_3 = f4m_fd_0._parse_bootstrap_node()
    var_4 = f4m_fd_0.real_download()


# Generated at 2022-06-26 11:16:30.976993
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:16:40.222231
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:16:42.213580
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_abst()


# Generated at 2022-06-26 11:16:49.427925
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    var_0 = F4mFD()
    var_1 = {
        'url': '',
        'tbr': None,
    }
    var_2 = ''
    var_0.real_download(var_2, var_1)


if __name__ == '__main__':
    test_case_0()
    test_F4mFD_real_download()

# Generated at 2022-06-26 11:16:51.491663
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_asrt()


# Generated at 2022-06-26 11:17:01.336989
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Live case
    boot_info = read_bootstrap_info(compat_b64decode(u'''
    AQAAANgDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=
    '''))
    assert build_fragments_list(boot_info) == [(0, 0), (0, 1)]
    # VOD case
    boot_info = read_bootstrap_info(compat_b64decode(u'''
    AQAAAPoDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=
    '''))
    assert build_fragments_list(boot_info) == [(0, 0), (0, 1)]
    # VOD case, with fragments_count = 4294967295

# Generated at 2022-06-26 11:17:06.847299
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader = FlvReader()
    flv_reader.write(compat_struct_pack('!I', 0))
    flv_reader.write(b'a')
    flv_reader.seek(0)
    assert flv_reader.read_box_info() == (0, b'a', b'')

    flv_reader.seek(0)
    flv_reader.truncate(0)
    flv_reader.write(compat_struct_pack('!I', 1))
    flv_reader.write(b'a')
    flv_reader.seek(0)
    assert flv_reader.read_box_info() == (1, b'a', b'')

    flv_reader.seek(0)
    flv_reader.truncate(0)


# Generated at 2022-06-26 11:17:30.575064
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    info_dict_0 = {'url': 'http://fms2.dw.com:1935/dwtv_live/smil:dwtv_germany.smil/manifest.f4m?wowzasessionid=1550909013', 'tbr': None}
    filename_0 = './test_F4mFD_real_download.flv'

    f4m_fd_0 = F4mFD()
    f4m_fd_0.real_download(filename_0, info_dict_0)

if __name__ == '__main__':
    test_case_0()
    test_F4mFD_real_download()

# Generated at 2022-06-26 11:17:39.088168
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    flv_reader_1 = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    var_2 = flv_reader_1.read_asrt()
    var_3 = flv_reader_1.read_afrt()


# Generated at 2022-06-26 11:17:46.951814
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    # Initialize the FLV reader
    flv_reader = FlvReader()
    fragment_duration = 1
    fragments = [
        # This is a list of fragments
        # Each entry is a dict that contains keys "ts", "duration"
        # And optional "discontinuity_indicator"
        {
            'ts': 0,
            'duration': fragment_duration,
        },
        {
            'ts': 1 * fragment_duration,
            'duration': fragment_duration,
        },
        {
            'ts': 2 * fragment_duration,
            'duration': fragment_duration,
        },
        {
            'ts': 3 * fragment_duration,
            'duration': fragment_duration,
        },
    ]
    # Write the fragments info to the flv reader

# Generated at 2022-06-26 11:17:49.026193
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    downloader_0 = F4mFD(Dict0)
    format_dict_0 = {
    }
    downloader_0.real_download('fragment_name',format_dict_0)


# Generated at 2022-06-26 11:17:52.203569
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    filename = None
    info_dict = {
        'id': 'test',
        'url': 'test',
        'fragments': [],
        'complete_frags_downloaded_bytes': None,
        'complete_frags': [],
        'live': True,
        'skip_unavailable_fragments': True,
    }
    f4m_fd = F4mFD()
    f4m_fd.real_download(filename, info_dict)


# Generated at 2022-06-26 11:17:59.092188
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml_string = '<media url="test_url" bootstrapInfoId="22" bitrate="193000" fps="25" width="1280" height="720" codec="h.264" profile="main" level="41" duration="6.600" drmAdditionalHeaderId="0" drmAdditionalHeaderSetId="0" />'
    root = compat_etree_fromstring(fix_xml_ampersands(xml_string))
    media = remove_encrypted_media(root)

    assert len(media) == 1


# Generated at 2022-06-26 11:18:08.809382
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:18:19.446875
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from ytdl.cachedownloader import CacheDownloader
    from ytdl.extractor import YoutubeIE
    from collections import OrderedDict
    from ytdl.utils import make_HTTPS_handler, sanitize_open
    import tempfile

    if not hasattr(F4mFD, '_download_fragment'):
        return
    if not hasattr(YoutubeIE, '_extract_f4m_formats'):
        return

    ydl = CacheDownloader()
    ydl.add_info_extractor(YoutubeIE)
    ydl.add_info_extractor(GenericIE())
    ydl.add_default_info_extractors() # Needed for GenericIE

# Generated at 2022-06-26 11:18:21.284999
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():

    # Test case 0
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_bootstrap_info()


# Generated at 2022-06-26 11:18:22.869850
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader = FlvReader()
    flv_reader.read_abst()


# Generated at 2022-06-26 11:18:53.728159
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    test_case_0()


# Generated at 2022-06-26 11:19:04.696445
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_0 = FlvReader(b"\x24\x00\x00\x00\x66\x72\x61\x67\x00\x00\x00\x03\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x03\xbb\x00\x00\x00\x00\x00\x00\x0f\x3e\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\xbb\x00\x00\x00\x00\x00\x00\x27\x10\x00\x00\x00\x00\x00\x00\x00\x00")
   

# Generated at 2022-06-26 11:19:11.988013
# Unit test for function get_base_url
def test_get_base_url():
    manifest_content = '''<manifest xmlns="http://ns.adobe.com/f4m/1.0">
    <baseURL>http://example.com/</baseURL>
    </manifest>
    '''
    manifest = compat_etree_fromstring(manifest_content)
    base_url = get_base_url(manifest)
    assert base_url == 'http://example.com/'



# Generated at 2022-06-26 11:19:13.836975
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader = FlvReader()
    flv_reader.read_bootstrap_info()


# Generated at 2022-06-26 11:19:15.954834
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4m_fd_instance = F4mFD()
    f4m_fd_instance.real_download()


# Generated at 2022-06-26 11:19:16.537285
# Unit test for function get_base_url
def test_get_base_url():
    pass


# Generated at 2022-06-26 11:19:23.967762
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:19:26.788417
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    """
    Test the method read_afrt of the class FlvReader
    """
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_afrt()




# Generated at 2022-06-26 11:19:38.442244
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test case 1
    _buf = b'\x00\x00\x00\x00\x00\x18\x66\x6d\x74\x61\x74\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    flv_reader_0 = FlvReader(_buf)
    var_0, var_1, var_2 = flv_reader_0.read_box_info()
    assert var_0 == 0
    assert var_1 == b'fmat'
    assert var_2 == b''
    # Test case 2
    _

# Generated at 2022-06-26 11:19:44.116969
# Unit test for function get_base_url
def test_get_base_url():
    base_url = 'http://example.com/'
    base_url_2 = 'http://example/'
    base_url_3 = 'http://example.com/path'
    base_url_4 = 'http://example.com/path/'
    base_url_5 = 'http://example.com/path/file'

    xml = (
        '<manifest>'
        '<baseURL>%s</baseURL>'
        '<media>'
         '<bootstrapInfo>%s</bootstrapInfo>'
        '</media>'
        '</manifest>' % (base_url, compat_b64decode('AAA=')))
    manifest = compat_etree_fromstring(fix_xml_ampersands(xml))
    assert get_base_url(manifest) == base_

# Generated at 2022-06-26 11:20:29.761348
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    with FlvReader() as flv_reader_0:
        var_0 = flv_reader_0.read_bootstrap_info()


# Generated at 2022-06-26 11:20:30.654271
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    pass


# Generated at 2022-06-26 11:20:38.181973
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_box_info()
    var_1 = flv_reader_0.read_box_info()
    var_2 = flv_reader_0.read_box_info()
    var_3 = flv_reader_0.read_box_info()
    var_4 = flv_reader_0.read_box_info()
    var_5 = flv_reader_0.read_box_info()
    var_6 = flv_reader_0.read_box_info()
    var_7 = flv_reader_0.read_box_info()
    var_8 = flv_reader_0.read_box_info()



# Generated at 2022-06-26 11:20:48.186087
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-26 11:20:56.443307
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    s = '\x00\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    flv_reader_0 = FlvReader(s)
    var_0 = flv_reader_0.read_afrt()
    assert var_0['fragments'][0]['first'] == 1
    assert var_0['fragments'][0]['ts'] == 1
    assert var_0['fragments'][0]['duration'] == 1

# Generated at 2022-06-26 11:20:59.053939
# Unit test for function build_fragments_list
def test_build_fragments_list():
    flv_reader_0 = FlvReader()
    flv_reader_0.boot_info = flv_reader_0.read_abst()
    build_fragments_list(flv_reader_0.boot_info)


# Generated at 2022-06-26 11:21:03.405174
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-26 11:21:14.628619
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    print('Testing F4mFD.real_download...')
    ctx = {'complete_frags_downloaded_bytes': 0, 'dest_stream': open('/tmp/test.flv', 'wb'), 'filename': 'test.flv'}
    # Pass an empty dict as the info_dict argument to real_download.
    # real_download will populate this dict, and we can use it later to check
    # that some fields have been populated correctly.
    info_dict = {}

    # Test a non-live f4m
    urlh = YoutubeDLHandler()
    urlh.addheaders = [('User-Agent', 'test')]
    manifest = urlh.open('http://video.webmfiles.org/elephants-dream-medium.f4m').read()
    urlh.close()
    doc = compat

# Generated at 2022-06-26 11:21:20.191422
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader = FlvReader()
    var_0 = flv_reader.read_bootstrap_info()

    #var_0 = flv_reader.read_unsigned_int()
    #var_1 = flv_reader.read_unsigned_char()
    #var_2 = flv_reader.read_string()
    #var_3 = flv_reader.read_unsigned_long_long()


# Generated at 2022-06-26 11:21:30.572507
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info_0 = {
        'segments': [
            {
                'segment_run': [
                    (1, 1),
                    (2, 1),
                ],
            },
        ],
        'fragments': [
            {
                'fragments': [
                    {
                        'first': 1,
                        'ts': 0,
                        'duration': 5000,
                        'discontinuity_indicator': None,
                    },
                    {
                        'first': 2,
                        'ts': 5000,
                        'duration': 5000,
                        'discontinuity_indicator': None,
                    },
                ],
            },
        ],
    }

    res_0 = build_fragments_list(boot_info_0)
    assert res_0 == [(1, 1), (2, 2)]



# Generated at 2022-06-26 11:22:09.616193
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:22:11.553472
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_asrt()
    return var_0


# Generated at 2022-06-26 11:22:15.579588
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_0 = FlvReader(b'AAABB\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x00\x03')
    flv_reader_0.read_afrt()


# Generated at 2022-06-26 11:22:22.405893
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    test_data_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    test_data_1 = b'\x00\x00\x00\x00\x00\x00\x00\x01'
    test_data_2 = b'\x00\x00\x00\x00\x00\x00\x01\x00'
    test_data_3 = b'\x00\x00\x00\x00\x00\x00\x00\x10'
    test_data_4 = b'\x00\x00\x00\x00\x00\x00\x00\x11'

# Generated at 2022-06-26 11:22:24.016736
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_abst()


# Generated at 2022-06-26 11:22:25.746147
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_abst()


# Generated at 2022-06-26 11:22:35.237678
# Unit test for function remove_encrypted_media

# Generated at 2022-06-26 11:22:36.891873
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_bootstrap_info()


# Generated at 2022-06-26 11:22:40.071689
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    f4mfd = F4mFD(sys.argv)
    f4mfd.real_download(filename, info_dict)

if __name__ == '__main__':
    test_case_0()
    test_F4mFD_real_download()

# Generated at 2022-06-26 11:22:41.152146
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    var_0 = FlvReader().read_abst()
