

# Generated at 2022-06-26 11:14:03.955259
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    class YDLMock(object):
        class downloaderMock(object):
            def __init__(self):
                self.RETRY_LIMITS_MAP = {}
                self.params = {}
            def to_screen(self, msg):
                print(msg)
            def report_warning(self, msg):
                print(msg)
            def report_error(self, msg):
                print(msg)

        class urlopenMock(object):
            def __init__(self, url):
                self.url = url
            def read(self):
                return "test_case_0"
            def geturl(self):
                return self.url

        def __init__(self):
            self.params = {}

# Generated at 2022-06-26 11:14:13.908782
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader = FlvReader()
    with open('../tests/bootstrap_0.dat', 'rb') as f:
        flv_reader.write(f.read())
    total_size, box_type, box_data = flv_reader.read_box_info()
    assert box_type == b'abst'
    flv_reader_0 = FlvReader(box_data)
    total_size, box_type, box_data = flv_reader_0.read_box_info()
    assert box_type == b'asrt'
    total_size, box_type, box_data = flv_reader_0.read_box_info()
    assert box_type == b'afrt'


# Generated at 2022-06-26 11:14:27.187333
# Unit test for function get_base_url
def test_get_base_url():
    simple_manifest = """
<manifest xmlns="http://ns.adobe.com/f4m/2.0">
  <baseURL>http://www.example.com/base/</baseURL>
  <media url="fileSequence0.f4v" bitrate="500">
      <metadata>
        <metadataData targetDuration="10" />
      </metadata>
  </media>
</manifest>
"""
    simple_manifest_xml = compat_etree_fromstring(fix_xml_ampersands(simple_manifest.encode('utf-8')))
    simple_base_url = get_base_url(simple_manifest_xml)
    assert simple_base_url == 'http://www.example.com/base/'


# Generated at 2022-06-26 11:14:35.559284
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info_0 = read_bootstrap_info(bootstrap_bytes_0)

# Generated at 2022-06-26 11:14:47.034940
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv = io.BytesIO(b'\x00\x01\x00\x00\x00\x02\x00\x00\x00\x02ab\x00\x03\x00\x00\x00\x02cde\x00\x00\x00\x02')
    flv_reader = FlvReader(flv)
    assert flv_reader.read_string() == b'a'
    assert flv_reader.read_string() == b'b'
    assert flv_reader.read_string() == b'cd'
    assert flv_reader.read_string() == b''


# Generated at 2022-06-26 11:14:51.116384
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    print('Testing method F4mFD.real_download')
    print('Testcase 0 not implemented')


# Generated at 2022-06-26 11:15:01.142221
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():

    """
    Method that tests the real_download method of class F4mFD.
    Throws assertion error if test fails
    """
    # Test for online download
    url_1 = ('https://s3-us-west-2.amazonaws.com/akamai.netstorage/'
             'BigBuckBunny_320x180.f4m')
    # Test for offline download
    # url_1 = '/Users/sanket/Desktop/BigBuckBunny_320x180.f4m'
    ydl_1 = YoutubeDL({'outtmpl': '%(id)s.mp4'})
    ydl_1.add_info_extractor(F4mFD())

    # Test for youtube-dl integration
    # Download URL
    # ydl_1.download([url_1])

    #

# Generated at 2022-06-26 11:15:03.528318
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    flv_reader_seg_test_case = FlvReader()
    assert flv_reader_seg_test_case.read_asrt() == {
        'segment_run': [(0, 7), (7, 5)],
    }



# Generated at 2022-06-26 11:15:14.826889
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    flv_reader_1 = FlvReader(data_0_1)
    result_1 = flv_reader_1.read_asrt()
    assert result_1[0] == 10 and result_1[1] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    flv_reader_2 = FlvReader(data_0_2)
    result_2 = flv_reader_2.read_asrt()
    assert result_2[0] == 10 and result_2[1] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    flv_reader_3 = FlvReader(data_0_3)
    result_3 = flv_reader_3.read_asrt()
    assert result_3[0]

# Generated at 2022-06-26 11:15:24.345869
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    stream.seek(0)
    assert stream.read(4) == b'FLV\x01'
    assert stream.read(1) == b'\x05'
    assert stream.read(3) == b'\x00\x00\x00'
    assert stream.read(4) == b'\x09\x00\x00\x00'
    assert stream.read(4) == b'\x00\x00\x00\x00'


# Generated at 2022-06-26 11:15:49.901720
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Load the data
    with io.open('media/test_case_0.flv.abst', 'rb') as flv_reader:
        boot_info = read_bootstrap_info(flv_reader.read())
    fragments = build_fragments_list(boot_info)
    # Check the results
    assert fragments == [
        (0, 0), (0, 1), (0, 2), (0, 3), (0, 4),
        (0, 5), (0, 6), (0, 7), (0, 8), (0, 9),
    ]



# Generated at 2022-06-26 11:15:52.573779
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_0 = FlvReader()
    flv_reader_0.read_asrt()
    flv_reader_0.read_afrt()
    flv_reader_0.read_bootstrap_info()



# Generated at 2022-06-26 11:16:02.000833
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    """Test whether encrypted media is removed"""
    xml_string = """
<?xml version="1.0"?>
<manifest xmlns="http://ns.adobe.com/f4m/1.0">
    <media url="media1" bitrate="1000" bootstrapInfoId="boot1"
           drmAdditionalHeaderId="151" drmAdditionalHeaderSetId="5436" />
    <media url="media2" bitrate="2000" bootstrapInfoId="boot1"/>
</manifest>
    """
    clean_string = """
<?xml version="1.0"?>
<manifest xmlns="http://ns.adobe.com/f4m/1.0">
    <media url="media2" bitrate="2000" bootstrapInfoId="boot1"/>
</manifest>
    """
    clean_xml = remove

# Generated at 2022-06-26 11:16:09.609322
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    import doctest
    doctest.testmod(test_case_0)

test_case_1 = """
    >>> abst = FlvReader()
    >>> abst.read_abst()
    {'segments': [{'segment_run': [(1, 1), (2, 2), (3, 3), (4, 4)]}], 'fragments': [{'fragments': [{'duration': 3160, 'ts': 0, 'first': 1, 'discontinuity_indicator': None}]}], 'live': False}
"""


# Generated at 2022-06-26 11:16:18.650009
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # test case 1
    # The f4m_url comes from 
    # https://github.com/ytdl-org/youtube-dl/issues/5010

    f4m_url = 'https://video-http.media-imdb.com/MV5BMjY5MzgxMzQ2N15BMl5BanBnXkFtZTgwNTY2MzYzNjM@.f4m'

    ydl = YoutubeDL()
    f4m_fd = F4mFD()
    f4m_fd.real_download('output.flv', { 'url': f4m_url })
    assert os.path.isfile('output.flv')


if __name__ == '__main__':
    test_F4mFD_real_download()

# Generated at 2022-06-26 11:16:29.902505
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:16:34.052405
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader_1 = FlvReader()
    flv_reader_1.read_string()
    flv_reader_1.read_string()
    flv_reader_1.read_string()
    flv_reader_1.read_string()


# Generated at 2022-06-26 11:16:41.234850
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:16:46.335474
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring('<manifest xmlns="http://ns.adobe.com/f4m/1.0"></manifest>')
    base_url = get_base_url(manifest)
    assert base_url is None


# Generated at 2022-06-26 11:16:57.028162
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:17:20.330169
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-26 11:17:29.609164
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:17:31.147868
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_1 = FlvReader()
    var_1 = flv_reader_1.read_abst()


# Generated at 2022-06-26 11:17:41.676236
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:17:45.541922
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_bootstrap_info()
    var_1 = ('segments', 'fragments', 'live')
    for var_2 in var_1:
        assert var_2 in var_0
    return var_0


# Generated at 2022-06-26 11:17:57.154509
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:17:58.842377
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    flv_reader_0 = FlvReader()
    test_case_0() # Call test_case_0


# Generated at 2022-06-26 11:18:01.995121
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    filename = "dummy_filename"
    info_dict= {}
    inst_0 = F4mFD(info_dict)
    inst_0.real_download(filename, info_dict)


# Generated at 2022-06-26 11:18:06.633928
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    if (remove_encrypted_media(
                    [{'drmAdditionalHeaderId': '123'},
                     {'drmAdditionalHeaderSetId': '456'},
                     {'valid': '789'}]) !=
            [{'valid': '789'}]):
        raise AssertionError('Test remove_encrypted_media failed')


# Generated at 2022-06-26 11:18:15.236761
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    stream.seek(0)
    flvreader = FlvReader(stream.read())
    assert flvreader.read_bytes(3) == b'FLV'
    assert flvreader.read_unsigned_char() == 1
    assert flvreader.read_unsigned_char() == 5
    assert flvreader.read_bytes(3) == b'\x00\x00\x00'
    assert flvreader.read_unsigned_int() == 9

# Generated at 2022-06-26 11:20:06.090784
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4m_fd_0 = F4mFD()
    f4m_fd_0.real_download('real_download_1.fake', {})


# Generated at 2022-06-26 11:20:07.742647
# Unit test for function build_fragments_list
def test_build_fragments_list():
    test_cases = []
    test_cases.append(test_case_0)
    for test_case in test_cases:
        test_case()


# Generated at 2022-06-26 11:20:09.920053
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # TODO: Place your test code here
    filename = ""
    info_dict = {}
    f4m_fd_0 = F4mFD()
    f4m_fd_0.real_download(filename, info_dict)


# Generated at 2022-06-26 11:20:11.540903
# Unit test for function build_fragments_list
def test_build_fragments_list():
    flv_reader_0 = FlvReader()
    result_0 = flv_reader_0.build_fragments_list()
    return result_0


# Generated at 2022-06-26 11:20:13.094493
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_asrt()
    assert len(var_0['segment_run']) == 0


# Generated at 2022-06-26 11:20:17.702530
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader = FlvReader()
    var = flv_reader.read_abst()
    assert len(flv_reader.segments) == 0
    assert len(flv_reader.fragments) == 0
    assert flv_reader.live == False


# Generated at 2022-06-26 11:20:26.878385
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-26 11:20:29.792888
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    stream.seek(0)
    assert (stream.read() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00')


# Generated at 2022-06-26 11:20:37.606635
# Unit test for function build_fragments_list
def test_build_fragments_list():
    fragments_list = build_fragments_list({
        'segments': [{
            'segment_run': [
                (0, 1),
                (1, 2)
            ]
        }],
        'fragments': [
            {'fragments': [
                {'first': 0, 'duration': 0, 'ts': 0, 'discontinuity_indicator': 0},
                {'first': 1, 'duration': 0, 'ts': 0, 'discontinuity_indicator': 0},
                {'first': 2, 'duration': 0, 'ts': 0, 'discontinuity_indicator': 0},
            ]}
        ],
        'live': False
    })

    assert fragments_list == [(0, 0), (1, 1), (1, 2)]


# Generated at 2022-06-26 11:20:46.914288
# Unit test for function build_fragments_list