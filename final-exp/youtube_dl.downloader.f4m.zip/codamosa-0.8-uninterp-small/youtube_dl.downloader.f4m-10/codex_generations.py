

# Generated at 2022-06-26 11:13:50.689344
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    # SegmentRunAtom
    segment_run_atom = FlvReader(b'\x00\x00\x00\x25\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00\x00\x65\x6e\x67\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01')
    asrt_info = flv_reader_0.read_asrt()
    assert asrt_info['segment_run'][0] == (1, 1)
    assert asrt_

# Generated at 2022-06-26 11:13:51.569421
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    pass


# Generated at 2022-06-26 11:13:55.412561
# Unit test for function write_flv_header
def test_write_flv_header():
    flv_header = io.BytesIO()
    write_flv_header(flv_header)
    assert flv_header.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'


# Generated at 2022-06-26 11:14:05.112428
# Unit test for function write_flv_header
def test_write_flv_header():
    # Simple test for function write_flv_header
    with io.BytesIO() as f:
        write_flv_header(f)
        assert f.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'

# This unittest is broken as it uses a file (hls/test_case_0.flv)
#   I'm leaving it here, just to show that this is how unit tests should be done
#   (the asserts are commented out as we cannot check the file)
# def test_case_0():
#     # Download test case 0
#     #   test_case_0.flv is a fresh download of the file
#     #   alex.flv is the one that was corrupted
#     with

# Generated at 2022-06-26 11:14:14.101016
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:14:19.227787
# Unit test for function write_flv_header
def test_write_flv_header():
    flv_header_0 = io.BytesIO()
    # Test 0
    write_flv_header(flv_header_0)
    test_case_0()


# Generated at 2022-06-26 11:14:29.671262
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    """
    /Users/xiexianbin/Desktop/example/flvreader.flv
    """
    flv_reader = FlvReader()
    with open('/Users/xiexianbin/Desktop/example/flvreader.flv', 'rb') as f:
        flv_reader.write(f.read())
    flv_reader.seek(0, 0)
    abst = flv_reader.read_abst()
    assert len(abst['fragments']) == 1
    assert abst['fragments'][0]['fragments'][0]['first'] == 1
    assert abst['fragments'][0]['fragments'][0]['ts'] == 320000

# Generated at 2022-06-26 11:14:34.012651
# Unit test for function write_flv_header
def test_write_flv_header():
    from io import BytesIO
    from contextlib import closing

    with closing(BytesIO()) as stream:
        write_flv_header(stream)
        stream.seek(0)
        header = stream.read()
        if header == b"FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00":
            print("Pass")
        else:
            print("Fail")


# Generated at 2022-06-26 11:14:39.761120
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4mfd = F4mFD()
    f4mfd.real_download('test.flv',{})


if __name__ == '__main__':
    test_F4mFD_real_download()

# Generated at 2022-06-26 11:14:50.716344
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:15:14.773758
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:15:26.514215
# Unit test for function remove_encrypted_media

# Generated at 2022-06-26 11:15:30.470996
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    stream = io.BytesIO()
    metadata = b'\x12'
    write_metadata_tag(stream,metadata)
    assert stream.getvalue() == b'\x12\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x12'



# Generated at 2022-06-26 11:15:38.964292
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:15:48.015855
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.downloader.external import ExternalFD
    ydl = YoutubeDL()
    ydl.params['noprogress'] = True  # needed for EDGE
    # Note how ydl.download is switched to a lambda for test
    ydl.download = lambda *args, **kwargs: None
    # Note how the url is replaced by a local file
    # This should probably be done better (in the calling function or so)
    # but it should be enough for the purpose of the test
    params = {
        'url': 'https://localhost/%s@%s' % (__file__, 'test_F4mFD_real_download'),
        'test': True,
        'nooverwrites': True,
    }
    f4mfd = F4mFD(ydl, params)
    #f4

# Generated at 2022-06-26 11:15:56.817995
# Unit test for function get_base_url
def test_get_base_url():
    bytes_0 = b'\x1fwUs\x83\x7f\x9d\xe1\xaf;\xf7\xa3\xa0'
    var_0 = read_bootstrap_info(bytes_0)
    # Test out-of-range url
    manifest_0 = b'<manifest xmlns="http://ns.adobe.com/f4m/2.0"></manifest>'
    manifest_0 = compat_etree_fromstring(manifest_0)
    res = get_base_url(manifest_0)
    assert not res
    # Test in-range url
    manifest_1 = b'<manifest xmlns="http://ns.adobe.com/f4m/2.0">' \
                 b'<baseURL>https://example.com/</baseURL>'

# Generated at 2022-06-26 11:16:05.877203
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    bytes_0 = b'\x00\x00\x00\x16\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00' \
              b'\x01\x00\x00\x00\x01\x30\x00\x00\x00\x01\x00\x00\x01'
    var_0 = FlvReader(bytes_0)
    var_1 = var_0.read_asrt()
    assert var_1['segment_run'] == [(48, 1), ]


# Generated at 2022-06-26 11:16:13.746402
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    bytes_0 = b'\x00\x00\x00\x1c\x00\x00\x00\x01\x00\x00\x04\x7c\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x04\x7b\x00\x00\x03\x75\x00\x00\x04\x7c\x00\x00\x03\x75'
    var_0 = FlvReader(bytes_0).read_afrt()
    assert var_0['fragments'][0]['discontinuity_indicator'] is None


# Generated at 2022-06-26 11:16:23.873996
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:16:34.937137
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    box_data = b'\x00\x00\x00\x00\x00\x00\x10\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    b = FlvReader(box_data)
    assert b.read_afrt() == {'fragments': [
        {'first': 0, 'ts': 0, 'duration': 1, 'discontinuity_indicator': None},
    ]}


# Generated at 2022-06-26 11:17:42.000694
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    f = FlvReader(b'\x00\x00\x00\x0f\x6f\x6e\x65\x66\x72\x61\x67\x00\x01\x02\x03')
    ret = f.read_box_info()
    assert ret[0] == 15
    assert ret[1] == 'onefrag'
    assert ret[2] == b'\x00\x01\x02\x03'

    f = FlvReader(b'\x00\x00\x01\x90onefrag\x00\x01\x02\x03')
    ret = f.read_box_info()
    assert ret[0] == 400
    assert ret[1] == 'onefrag'

# Generated at 2022-06-26 11:17:45.181520
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    bytes_0 = b'\x1fwUs\x83\x7f\x9d\xe1\xaf;\xf7\xa3\xa0'
    var_0 = FlvReader(bytes_0).read_abst()


# Generated at 2022-06-26 11:17:51.082873
# Unit test for function remove_encrypted_media

# Generated at 2022-06-26 11:18:00.733461
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:18:12.168660
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:18:17.238717
# Unit test for function build_fragments_list
def test_build_fragments_list():
    bytes_0 = b'\x1fwUs\x83\x7f\x9d\xe1\xaf;\xf7\xa3\xa0'
    var_0 = read_bootstrap_info(bytes_0)
    list_0 = build_fragments_list(var_0)
    list_1 = [(0, 0), (0, 1)]
    assert list_0 == list_1

# Generated at 2022-06-26 11:18:18.096987
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    test_case_0()


# Generated at 2022-06-26 11:18:19.020870
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    test_case_0()


# Generated at 2022-06-26 11:18:24.217379
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    bytes_0 = b'\x06\x00\x00\x00\x03\x00\x00\x00\x73\x74\x74\x00\x15\x00\x00\x00' \
              b'\x7f\x61\x67\x70\x00\x7f\x00\x00\x00\x00'
    var_0 = read_bootstrap_info(bytes_0)


# Generated at 2022-06-26 11:18:35.888462
# Unit test for function get_base_url
def test_get_base_url():
    # Case 0
    manifest_0 = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/1.0"></manifest>')
    assert get_base_url(manifest_0) is None
    manifest_0 = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        b'<baseURL>abc</baseURL></manifest>')
    assert get_base_url(manifest_0) == 'abc'
    manifest_0 = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/2.0"></manifest>')

# Generated at 2022-06-26 11:19:01.138525
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-26 11:19:13.178758
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-26 11:19:20.297679
# Unit test for function build_fragments_list
def test_build_fragments_list():
    v_0 = read_bootstrap_info(b'\x1fwUs\x83\x7f\x9d\xe1\xaf;\xf7\xa3\xa0')
    v_1 = build_fragments_list(v_0)
    assert v_1 == [(1, 1)]

    v_0 = read_bootstrap_info(b'\x1fwUs\x82g\x06?\xb0\xa1.\xf6`\x80')
    v_1 = build_fragments_list(v_0)
    assert v_1 == [(1, 1), (1, 2)]



# Generated at 2022-06-26 11:19:20.858206
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    pass

# Generated at 2022-06-26 11:19:30.883779
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:19:37.996053
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    bytes_0 = b'\x1fwUs\x83\x7f\x9d\xe1\xaf;\xf7\xa3\xa0'
    var_0 = FlvReader(bytes_0).read_abst()
    var_1 = b'abst'
    var_2 = var_0['fragments'][0]['duration']
    assert var_1 == var_2


# Generated at 2022-06-26 11:19:43.957926
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    global gen_var_1

# Generated at 2022-06-26 11:19:53.330908
# Unit test for function remove_encrypted_media

# Generated at 2022-06-26 11:20:01.268252
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test case 0
    io_0 = io.BytesIO(b'8\x00\x00\x00abcd\x00\x00\x00\x00\x01\x02\x03\x03')
    var_0 = FlvReader(io_0).read_box_info()
    assert var_0[0] == 8
    assert var_0[1] == b'abcd'
    assert var_0[2] == b'\x00\x00\x00\x00\x01\x02\x03'

    # Test case 1

# Generated at 2022-06-26 11:20:07.302377
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:21:13.900488
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:21:18.444024
# Unit test for function build_fragments_list
def test_build_fragments_list():
    bytes_0 = b'\x1fwUs\x83\x7f\x9d\xe1\xaf;\xf7\xa3\xa0'
    var_0 = read_bootstrap_info(bytes_0)

# Generated at 2022-06-26 11:21:28.409737
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Testing case 0
    bytes_0 = b'\x1fwUs\x83\x7f\x9d\xe1\xaf;\xf7\xa3\xa0'
    var_0 = read_bootstrap_info(bytes_0)
    var_1 = build_fragments_list(var_0)
    # var_1 is a list of tuples
    tuple_0 = (0, 4)
    tuple_1 = (0, 5)
    tuple_2 = (0, 6)
    assert tuple_0 in var_1
    assert tuple_1 in var_1
    assert tuple_2 in var_1
    assert len(var_1) == 3


# Generated at 2022-06-26 11:21:36.020079
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:21:46.672780
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [(1, 4), (2, 3)]
        }],
        'fragments': [{
            'fragments': [
                {'first': 1, 'ts': 0, 'duration': 0, 'discontinuity_indicator': None},
                {'first': 3, 'ts': 1, 'duration': 1, 'discontinuity_indicator': None},
            ]
        }],
        'live': True,
    }
    fragments = build_fragments_list(boot_info)
    assert fragments == [(2, 3), (2, 4)]


# Generated at 2022-06-26 11:21:52.125015
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    bytes_1 = b'\x00\x00\x00\x0f\x41\x53\x52\x54\x03\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00'
    var_1 = FlvReader(bytes_1).read_asrt()
    assert var_1['segment_run'] == [(0, 4)]


# Generated at 2022-06-26 11:21:58.302802
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:22:02.067859
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    bytes_0 = b'\x1fwUs\x83\x7f\x9d\xe1\xaf;\xf7\xa3\xa0'
    var_0 = FlvReader(bytes_0).read_bootstrap_info()



# Generated at 2022-06-26 11:22:07.259412
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    F4mFD().real_download("/home/ybran/repos/youtube-dl-test/test.f4m", {"url": "http://test", "extra_param_to_segment_url": "a=b"})

if __name__ == '__main__':
    test_case_0()
#    test_F4mFD_real_download()

# Generated at 2022-06-26 11:22:11.375530
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata_tag_0 = write_metadata_tag(io.BytesIO(), b'\x02\x00\x0f\x64\x61\x74\x61\x03\x00\x01\x6a')
    metadata_tag_1 = write_metadata_tag(io.BytesIO(), None)


# Generated at 2022-06-26 11:22:59.883383
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    reader = FlvReader(data)
    box_size, box_type, box_data = reader.read_box_info()
    assert box_size == 0
    assert len(box_type) == 4
    assert len(box_data) == 0
    print('FlvReader read_box_info unit test 0 ok')

    data = b'\x00\x00\x00\x01\x00\x00\x00\x01'
    reader = FlvReader(data)
    box_size, box_type, box_data = reader.read_box_info()
    assert box_size == 1
    assert len(box_type) == 4

# Generated at 2022-06-26 11:23:05.366442
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-26 11:23:15.563552
# Unit test for method read_afrt of class FlvReader