

# Generated at 2022-06-26 11:14:28.634031
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'live': False,
        'segments': [
            {'segment_run': [(0, 4294967295)]},
        ],
        'fragments': [
            {'fragments': [
                {'duration': 0, 'discontinuity_indicator': None, 'first': 0,
                 'ts': 699604350},
                {'duration': 4000000, 'discontinuity_indicator': None,
                 'first': 1, 'ts': 699604350},
                {'duration': 4000000, 'discontinuity_indicator': None,
                 'first': 2, 'ts': 699604350},
            ]},
        ],
    }
    expected_res = [(0, 0), (0, 1), (0, 2)]

# Generated at 2022-06-26 11:14:31.013254
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader = FlvReader()
    assert flv_reader.read_string() == b''


# Generated at 2022-06-26 11:14:37.784690
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-26 11:14:50.053688
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    FLV_HEADER_LEN = 9
    metadata = b'\x02\x00\x0a\x6f\x6e\x4d\x65\x74\x61\x44\x61\x74\x61\x08\x00\x00\x00\x00\x00\x00\x00{' + b'\x1a' + b'\x0b' + b'\x0a' + b'\x61' + b'\x75' + b'\x64' + b'\x69' + b'\x6f' + b'\x5f' + b'\x6d' + b'\x65' + b'\x64' + b'\x69' + b'\x61' + b'\x02' + b

# Generated at 2022-06-26 11:14:52.801625
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader_1 = FlvReader()
    flv_reader_1.read_bootstrap_info()


# Generated at 2022-06-26 11:14:58.147947
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # Read a test file
    with open('./test/test_case_0.flv') as flv_file:
        flv_data = flv_file.read()
    flv_reader = FlvReader(flv_data)
    bootstrap_info = flv_reader.read_bootstrap_info()
    print('bootstrap_info:')
    print(bootstrap_info)


# Generated at 2022-06-26 11:15:08.430661
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    # Prepare
    test_stream = io.BytesIO()
    test_metadata = b'abc'

    # Test
    write_metadata_tag(test_stream, test_metadata)

    # Verify
    if (test_stream.getvalue() == b'\x12\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00abc\x00\x00\x00\x14'):
        print("write_metadata_tag: success")
    else:
        print("write_metadata_tag: failed")




# Generated at 2022-06-26 11:15:14.501527
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Initialization
    stream_0 = io.BytesIO()
    stream_1 = io.BytesIO()
    stream_1.name = 'stream_1'
    info_dict = {"url": "manifest_url"}

    F4mFD_instance = F4mFD(ydl=None, params={})

    # Test execution.
    F4mFD_instance.real_download(stream_0, info_dict)


# Generated at 2022-06-26 11:15:23.328294
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # Test case 1
    with open('test/bootstrap0.abst', 'rb') as abst_file:
        abst = abst_file.read()
    # print ast.pprint(FlvReader(abst).read_bootstrap_info())

    # Test case 2
    with open('test/bootstrap1.abst', 'rb') as abst_file:
        abst = abst_file.read()
    # print ast.pprint(FlvReader(abst).read_bootstrap_info())



# Generated at 2022-06-26 11:15:24.883726
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader = FlvReader()
    flv_reader.read_abst()



# Generated at 2022-06-26 11:16:39.640414
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    flv_reader = FlvReader()

    with io.BytesIO() as stream:
        write_flv_header(stream)

# Generated at 2022-06-26 11:16:51.536008
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import re
    import os
    import sys
    import platform
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.append(root)
    import youtube_dl.YoutubeDL as YoutubeDL

    platform_system = platform.system()
    if platform_system == 'Windows':
        temp_file_path = 'C:\\Windows\\Temp'
    elif platform_system == 'Linux':
        temp_file_path = '/tmp'
    elif platform_system == 'Darwin':
        temp_file_path = '/tmp'
    else:
        raise RuntimeError('Unsupported platform system')
    test_file_path = temp_file_path + os.path.sep + 'test.flv'


# Generated at 2022-06-26 11:17:01.373806
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    flv_reader_0 = FlvReader()
    f = open('./test/test_write_metadata_tag.flv', 'rb')
    # video_file_url = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
    # f = compat_urllib_request.urlopen(video_file_url)
    # flv_reader_0.write(f.read())

    flv_reader_0.write(f.read())
    f.seek(0)
    print ("flv_reader_0")
    print ("f: ", f.getvalue())


    write_flv_header(f)
    write_metadata_tag(f, b'test')
    f.close()

# Generated at 2022-06-26 11:17:10.920868
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    box_data = (
        b'\x74\x31\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    )
    flv_reader_0 = FlvReader()
    flv_reader_0.write(box_data)
    flv

# Generated at 2022-06-26 11:17:18.789211
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:17:24.355124
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:17:26.984726
# Unit test for function get_base_url
def test_get_base_url():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()

# BaseURL exists and is not empty

# Generated at 2022-06-26 11:17:36.226027
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_1 = FlvReader()
    # Test case for only one fragment
    with open('tests/data/bbb_fragments_12.f4f') as f1:
        data1 = f1.read()
    box_size, box_type, box_data = flv_reader_1.read_box_info()
    assert flv_reader_1.read_asrt() == {
        'segment_run': [(0, 1)]
    }
    box_size, box_type, box_data = flv_reader_1.read_box_info()

# Generated at 2022-06-26 11:17:45.404644
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-26 11:17:46.451084
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_0 = FlvReader()


# Generated at 2022-06-26 11:18:34.178881
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:18:42.032017
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:18:52.276202
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_0 = FlvReader(b'')
    assert flv_reader_0.read_abst() == None

# Generated at 2022-06-26 11:19:02.571275
# Unit test for function get_base_url

# Generated at 2022-06-26 11:19:03.460748
# Unit test for function get_base_url
def test_get_base_url():
    test_case_0()


# Generated at 2022-06-26 11:19:06.350686
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    if __name__ == '__main__':
        test_case_0()
        test_remove_encrypted_media()

# Generated at 2022-06-26 11:19:06.947935
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    pass

# Generated at 2022-06-26 11:19:10.207753
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    flv_reader_0 = FlvReader()
    flv_reader_0.read_asrt()


# Generated at 2022-06-26 11:19:20.150708
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:19:29.947365
# Unit test for function build_fragments_list
def test_build_fragments_list():
    test_boot_info = {
        'segments': [{
            'segment_run': [(0, 1), (1, 1), (3, 2)],
        }],
        'fragments': [{
            'fragments': [{
                'first': 0,
                'ts': 0,
                'duration': 0,
                'discontinuity_indicator': None,
            }, {
                'first': 1,
                'ts': 0,
                'duration': 30,
                'discontinuity_indicator': None,
            }],
        }],
        'live': False,
    }
    assert build_fragments_list(test_boot_info) == [(0, 0), (1, 1), (3, 2), (3, 3)]



# Generated at 2022-06-26 11:20:09.166792
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    t0 = time.time()
    flv_reader_0 = FlvReader()
    var_0 = read_afrt(flv_reader_0)
    t1 = time.time()
    print(t1-t0)
    print(var_0)
    assert var_0
    assert str(type(var_0)) == "<type 'dict'>"


# Generated at 2022-06-26 11:20:15.619869
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    # version
    self.read_unsigned_char()
    # flags
    self.read_bytes(3)
    # time scale
    self.read_unsigned_int()

    quality_entry_count = self.read_unsigned_char()
    # QualitySegmentUrlModifiers
    for i in range(quality_entry_count):
        self.read_string()

    fragments_count = self.read_unsigned_int()
    fragments = []
    for i in range(fragments_count):
        first = self.read_unsigned_int()
        first_ts = self.read_unsigned_long_long()
        duration = self.read_unsigned_int()
        if duration == 0:
            discontinuity_indicator = self.read_unsigned_char()
        else:
            discontinuity_indicator = None
        fragments

# Generated at 2022-06-26 11:20:16.922700
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    pass
    flv_reader = FlvReader()
    var = read_bootstrap_info(flv_reader)


# Generated at 2022-06-26 11:20:24.901616
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    flv_reader_0 = FlvReader()
    flv_reader_0 = io.BytesIO()
    fd = flv_reader_0
    write_metadata_tag(fd, b'\x12')
    output = flv_reader_0.getvalue()
    expected = b'\x12\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x12\x00\x00\x00\x1c'
    assert output == expected


# Generated at 2022-06-26 11:20:32.514603
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    # self.read_unsigned_char() should be called once and only once
    var_0 = FlvReader()
    var_0.read_unsigned_char()
    test_case_0()

    # self.read_unsigned_int() should be called 2 times
    # self.read_unsigned_char() should be called 2 times
    # self.read_string() should be called 0 times
    var_1 = FlvReader()
    var_1.read_unsigned_int()
    var_1.read_unsigned_char()
    var_1.read_unsigned_int()
    var_1.read_unsigned_char()
    test_case_1()

    # self.read_unsigned_int() should be called 2 times
    # self.read_unsigned_char() should be called 2 times
    # self.read_string

# Generated at 2022-06-26 11:20:40.616943
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import os.path
    from ..downloader import FileDownloader

    # Unit test for method read_bootstrap_info of class FlvReader
    downloader = FileDownloader({})
    # Download b'http://vod.cntv.lxdns.com/flash/mp4video61/TMS/2013/05/02/0cfe4d4a4f4d4a448a8f7ca4e31ab441_h264418000nero_aac32.flv'

# Generated at 2022-06-26 11:20:50.097388
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:20:53.127625
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():

    var_1 = FlvReader(box_data)
    var_2 = var_1.read_abst()
    assert var_2 == boot_strap_info


# Generated at 2022-06-26 11:21:00.170109
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Check that the f4m manifest downloader is working
    f4m_fd_0 = F4mFD()
    # Not going to download anything
    f4m_fd_0._download_fragment = lambda ctx, url, ie: (True, b'')
    # We'll just mock the stream, so that we know the file has been written to
    mock_stream_0 = mock.Mock()
    f4m_fd_0._prepare_frag_download = lambda ctx: ctx.update({
        'dest_stream': mock_stream_0,
    })
    # We won't do anything in the tests
    f4m_fd_0._start_frag_download = lambda ctx: None
    f4m_fd_0._append_fragment = lambda ctx, data: None


# Generated at 2022-06-26 11:21:03.077274
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    var_1 = io.BytesIO()
    flv_reader_1 = FlvReader(var_1)
    read_asrt(flv_reader_1)


# Generated at 2022-06-26 11:21:36.738412
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    flv_reader_0 = FlvReader(b'\x00\x00\x00\x17\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x61\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x04\x00\x00\x00\x02\x00\x00\x00\x05')
    res_0 = read_asrt(flv_reader_0)

# Generated at 2022-06-26 11:21:39.081903
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    flv_reader_0 = FlvReader()
    var_0 = read_asrt(flv_reader_0)


# Generated at 2022-06-26 11:21:41.835084
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    """Test case for F4mFD.real_download
    """
    raise NotImplementedError

# Generated at 2022-06-26 11:21:51.638561
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:21:53.335714
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_F4mFD_real_download()

# Generated at 2022-06-26 11:21:59.110096
# Unit test for function remove_encrypted_media

# Generated at 2022-06-26 11:22:08.293680
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:22:10.762017
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_abst()


# Generated at 2022-06-26 11:22:14.739239
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    print('Test real_download')
    var_0 = F4mFD()
    var_1 = str()
    var_2 = {}
    var_0.real_download(var_1, var_2)


if __name__ == '__main__':
    test_case_0()
    test_F4mFD_real_download()

# Generated at 2022-06-26 11:22:21.963938
# Unit test for function build_fragments_list