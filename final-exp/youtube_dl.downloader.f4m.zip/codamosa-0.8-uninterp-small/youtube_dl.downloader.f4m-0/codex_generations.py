

# Generated at 2022-06-26 11:14:17.870437
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # Loading the test case
    with open("../testCase/case_0.dat", "rb") as f:
        data = f.read()

    flv_reader_0 = FlvReader(data)

# Generated at 2022-06-26 11:14:29.033482
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader = FlvReader(data=b'\x00\x01\x02\x03\x04\x05\x06foo\x00\x00\x00\x06bar\x00\x07\x08\x09\x00\x00\x00\x07foobar\x00\x00')
    assert flv_reader.read_string() == b'\x01\x02\x03\x04\x05\x06'
    assert flv_reader.read_string() == b'foo'
    assert flv_reader.read_string() == b'bar'
    assert flv_reader.read_string() == b'\x07\x08\x09'
    assert flv_reader.read_string() == b'foobar'
    assert flv_

# Generated at 2022-06-26 11:14:31.976031
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_1 = FlvReader()
    flv_reader_1.read_asrt()
    flv_reader_1.read_abst()

    flv_reader_2 = FlvReader()
    flv_reader_2.read_afrt()


# Generated at 2022-06-26 11:14:37.207757
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_string = b'\x04test'
    flv_reader = FlvReader(test_string)
    assert flv_reader.read_string() == 'test'


# Generated at 2022-06-26 11:14:49.812646
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    test_data = 'AAAAIAAAAAFN0b3JhZ2VVUkwAFmpzLy8vL0xvZ2dlci5qcwAAAAhkZXZpY2VJZAAAAA=='
    flv_reader = FlvReader(compat_b64decode(test_data))
    flv_reader.read_unsigned_int()
    result = flv_reader.read_abst()

# Generated at 2022-06-26 11:14:52.771977
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    flv_reader = FlvReader()
    flv_reader.read_asrt()


# Generated at 2022-06-26 11:14:55.314882
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4m_fd_0 = F4mFD()
    f4m_fd_0.real_download()

test_case_0()
test_F4mFD_real_download()

# Generated at 2022-06-26 11:14:57.891896
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader = FlvReader()
    flv_reader.read_abst()


# Generated at 2022-06-26 11:15:10.990978
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:15:23.631832
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    bootstrap_sample = b'AAAAAA=='
    bootstrap_reader = FlvReader(compat_b64decode(bootstrap_sample))
    bootstrap_info = bootstrap_reader.read_bootstrap_info()

# Generated at 2022-06-26 11:16:04.765576
# Unit test for function build_fragments_list
def test_build_fragments_list():
    flv_reader_0 = FlvReader()
    bootstrap_info = flv_reader_0.read_bootstrap_info()
    res = build_fragments_list(bootstrap_info)
    assert res == [(0, 0), (0, 1)]



# Generated at 2022-06-26 11:16:10.438682
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader_read_string = FlvReader()
    flv_reader_read_string.write(b'\x01abcdefg\x00\x02abcdefg\x00')
    flv_reader_read_string.seek(0)

    assert flv_reader_read_string.read_string() == b'\x01abcdefg'
    assert flv_reader_read_string.read_string() == b'\x02abcdefg'


# Generated at 2022-06-26 11:16:19.393127
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader_1 = FlvReader(test_bootstrap_info_1)
    flv_reader_2 = FlvReader(test_bootstrap_info_2)
    flv_reader_3 = FlvReader(test_bootstrap_info_3)
    flv_reader_4 = FlvReader(test_bootstrap_info_4)
    flv_reader_5 = FlvReader(test_bootstrap_info_5)
    flv_reader_6 = FlvReader(test_bootstrap_info_6)
    flv_reader_7 = FlvReader(test_bootstrap_info_7)
    flv_reader_8 = FlvReader(test_bootstrap_info_8)
    flv_reader_9 = FlvReader(test_bootstrap_info_9)
   

# Generated at 2022-06-26 11:16:31.265020
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import os
    import sys
    import audio_download_test

    # Create a dummy ydl object
    ydl = audio_download_test.create_ydl()

    # Create a dummy downloader
    downloader = F4mFD(ydl)

    # Create a dummy info_dict
    info_dict =  {'url': 'http://www.youtube.com/watch?v=BaW_jenozKc'}
    info_dict['title'] = 'hello'
    info_dict['ext'] = 'mp4'
    info_dict['alt_title'] = 'world'

    # Create a dummy filename
    filename = "myvideo.mp4"

    # Call the real_download method
    retval = downloader.real_download(filename, info_dict)

    # Assert the returned filename is not empty


# Generated at 2022-06-26 11:16:40.429540
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    abcd_file = io.BytesIO(open('ajlc/test/test_f4f/abcd.abst', 'rb').read())
    flv_reader_0 = FlvReader(abcd_file)
    flv_reader_0.read_box_info()
    abst_info = flv_reader_0.read_abst()
    assert abst_info['segments'][0]['segment_run'][0][0] == 0
    assert abst_info['segments'][0]['segment_run'][0][1] == 5
    assert abst_info['segments'][0]['segment_run'][1][0] == 5
    assert abst_info['segments'][0]['segment_run'][1][1] == 5

# Generated at 2022-06-26 11:16:46.282464
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    fd_0 = F4mFD()
    fd_0.real_download(filename = 'abc_filename', info_dict = 'abc_info_dict')

# Testing methods real_download and _update_live_fragments of class F4mFD
# with a live DRM-protected stream (e.g. Rai TV)

# Generated at 2022-06-26 11:16:57.033103
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # Test case 0, read from file name
    flv_reader_0 = FlvReader(filename='../data/bootstrap/bootstrap_0.abc')

# Generated at 2022-06-26 11:17:05.639140
# Unit test for function build_fragments_list
def test_build_fragments_list():
    flv_reader_0 = FlvReader()
    flv_reader_0.read_bytes()
    flv_reader_0.read_box_info()
    flv_reader_0.read_asrt()
    flv_reader_0.read_afrt()
    flv_reader_0.read_abst()
    flv_reader_0.read_unsigned_long_long()
    flv_reader_0.read_unsigned_int()
    flv_reader_0.read_unsigned_char()
    flv_reader_0.read_string()
    flv_reader_0.read_bootstrap_info()
    boot_info_0 = build_fragments_list(boot_info_0)
# *****************************************************************************



# Generated at 2022-06-26 11:17:15.100494
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media_0 = '''<media bitrate="0" bootstrapInfoId="bootstrap0" url="Test0.f4v" />'''
    media_1 = '''<media bitrate="0" bootstrapInfoId="bootstrap1" drmAdditionalHeaderId="drmHeader1" drmAdditionalHeaderSetId="drmHeaderSet1" url="Test1.f4v" />'''
    media_2 = '''<media bitrate="0" bootstrapInfoId="bootstrap2" drmAdditionalHeaderSetId="drmHeaderSet1" url="Test2.f4v" />'''
    media_3 = '''<media bitrate="0" bootstrapInfoId="bootstrap3" drmAdditionalHeaderSetId="drmHeaderSet1" url="Test3.f4v" />'''

    medias_0 = remove_encrypted

# Generated at 2022-06-26 11:17:21.998948
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-26 11:17:46.229249
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    # test for case 0
    flv_reader_0 = FlvReader()
    metadata_0 = b''
    stream_0 = b'\x12\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    flv_reader_0.write(stream_0)
    flv_reader_0.seek(0, 0)
    write_metadata_tag(flv_reader_0, metadata_0)
    flv_reader_0.seek(0, 2)
    flv_reader_0.seek(0, 0)
    ans_0 = flv_reader_0.read()

# Generated at 2022-06-26 11:17:57.432942
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    with io.open('./tests/data/f4m/test.flv', 'rb') as file_obj:
        flv_reader = FlvReader(file_obj.read())
    flv_reader.read_bytes(4)
    assert flv_reader.read_unsigned_int() == 9
    flv_reader.read_unsigned_int()
    assert flv_reader.read_unsigned_int() == 13

# Generated at 2022-06-26 11:18:06.245169
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Test case 0
    with open("test_case_0.flv", "rb") as f:
        flv_reader_0 = FlvReader(f.read())
        boot_info_0 = flv_reader_0.read_bootstrap_info()
        fragments_list_0 = build_fragments_list(boot_info_0)
        assert fragments_list_0 == [(0, 0), (0, 1), (0, 2), (0, 3)]

    # Test case 1
    with open("test_case_1.flv", "rb") as f:
        flv_reader_1 = FlvReader(f.read())
        boot_info_1 = flv_reader_1.read_bootstrap_info()

# Generated at 2022-06-26 11:18:16.812670
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader = FlvReader()

# Generated at 2022-06-26 11:18:20.247697
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    abst_file_name = './tests/bootstrapinfo.abst'
    flv_reader_0 = FlvReader(filename=abst_file_name)
    print('flv_reader_0.read_abst()', flv_reader_0.read_abst())


# Generated at 2022-06-26 11:18:30.473537
# Unit test for function remove_encrypted_media

# Generated at 2022-06-26 11:18:32.427901
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_1 = FlvReader()
    flv_reader_1.read_afrt()


# Generated at 2022-06-26 11:18:41.243307
# Unit test for function get_base_url
def test_get_base_url():
    # get_base_url(manifest):
    #   <manifest>
    #     <baseURL>http://example.com/</baseURL>
    #   </manifest>
    expect_base_url = 'http://example.com/'
    manifest = compat_etree_fromstring('<manifest><baseURL>%s</baseURL></manifest>' % (expect_base_url))
    base_url = get_base_url(manifest)
    assert base_url == expect_base_url

    # get_base_url(manifest):
    #   <manifest>
    #     <baseURL>
    #       http://example.com/
    #     </baseURL>
    #   </manifest>
    expect_base_url = 'http://example.com/'
    manifest

# Generated at 2022-06-26 11:18:42.564251
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:18:52.775904
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:19:18.848061
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:19:28.858699
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    flv_writer_0 = io.BytesIO()

# Generated at 2022-06-26 11:19:39.699349
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:19:42.830662
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader = FlvReader()
    size_0, box_type_0, box_data_0 = flv_reader.read_box_info()

    assert size_0 == 13
    assert box_type_0 == b'ftyp'
    assert box_data_0 == b'isommp42'



# Generated at 2022-06-26 11:19:51.698754
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:19:58.437298
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader = FlvReader()
    with open('resources/bootstrap_abst_sample.bin', 'rb') as f:
        flv_reader = FlvReader(f.read())
    assert flv_reader.read_bootstrap_info() == {
        'segments': [{
            'segment_run': [(1, 1)],
        }],
        'fragments': [{
            'fragments': [{
                'first': 1,
                'ts': 0,
                'duration': 5000,
                'discontinuity_indicator': None
            }]
        }],
        'live': False
    }


# Generated at 2022-06-26 11:20:05.007974
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader = FlvReader()

    with open('test/fixtures/test_0.flv') as flv_file_0:
        flv_reader_0 = FlvReader(flv_file_0.read())

# Generated at 2022-06-26 11:20:11.200986
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:20:20.667091
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader = FlvReader()
    fd = io.BytesIO()

# Generated at 2022-06-26 11:20:28.757745
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:21:08.470064
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader_0 = FlvReader()

    flv_reader_0.read_box_info()



# Generated at 2022-06-26 11:21:10.415686
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_F4mFD_real_download()

# Generated at 2022-06-26 11:21:17.854973
# Unit test for function get_base_url
def test_get_base_url():
    manifest = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\
            <manifest xmlns=\"http://ns.adobe.com/f4m/1.0\">\
              <baseURL>http://example.com/</baseURL>\
              <bootstrapInfo profile=\" named \"\
                url=\"bootstrap.bin\" />\
            </manifest>"
    manifest = compat_etree_fromstring(manifest)
    manifest = fix_xml_ampersands(manifest)
    url = get_base_url(manifest)
    print(url)


# Generated at 2022-06-26 11:21:28.931926
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    filename = '../html/f4m_f4v.html'
    url = 'http://hdflash.googlecode.com/svn/trunk/samples/f4m_f4v.html'

# Generated at 2022-06-26 11:21:35.269533
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    flv_reader_1 = FlvReader()
    data_1 = compat_struct_pack(
        '>B3sB8s',
        1, b'\x00\x00\x00', 2, b'\x00\x00\x00\x00\x00\x00\x00\x00')
    flv_reader_1.write(data_1)
    flv_reader_1.seek(0)

    res_1 = flv_reader_1.read_asrt()
    assert res_1 == {'segment_run': [(0, 0), (0, 0)]}


# Generated at 2022-06-26 11:21:46.454960
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # Case 0:empty input
    flv_reader_0 = FlvReader()
    with pytest.raises(DataTruncatedError):
        flv_reader_0.read_bootstrap_info()
    # Case 1:test with a real bootstrap file
    with open('test_data/test_bootstrap_info.txt', 'rb') as f:
        flv_reader_1 = FlvReader(f.read())
    abst_info_1 = flv_reader_1.read_bootstrap_info()
    assert len(abst_info_1['segments']) == 1
    assert len(abst_info_1['fragments']) == 1
    assert abst_info_1['live'] == False

# Generated at 2022-06-26 11:21:53.065357
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys

    # Extract the arguments
    if len(sys.argv) != 2:
        print('usage: test_F4mFD_real_download <url>')
        sys.exit(2)
    url = sys.argv[1]

    import youtube_dl

    # Instantiate the info extractor
    ie = youtube_dl.YoutubeDL()

    # Download the video
    ie.download([url])

if __name__ == '__main__':
    # test_case_0()
    test_F4mFD_real_download()

# Generated at 2022-06-26 11:21:58.831884
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-26 11:22:08.226983
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader_1 = FlvReader()
    bootstrap_info = flv_reader_1.read_bootstrap_info()
    assert type(bootstrap_info) == dict
    assert 'segments' in bootstrap_info
    assert type(bootstrap_info['segments']) == list
    assert len(bootstrap_info['segments']) == 1
    assert type(bootstrap_info['segments'][0]) == dict
    assert 'segment_run' in bootstrap_info['segments'][0]
    assert type(bootstrap_info['segments'][0]['segment_run']) == list
    first_segment, fragments_per_segment = bootstrap_info['segments'][0]['segment_run'][0]
    assert first_segment == 0

# Generated at 2022-06-26 11:22:17.532633
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import tempfile
    ydl = YoutubeDL()
    ydl.params['nooverwrites'] = True
    with tempfile.NamedTemporaryFile(delete=True) as tf:
        tf_name = tf.name