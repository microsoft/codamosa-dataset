

# Generated at 2022-06-26 11:14:15.437365
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_1 = FlvReader()

# Generated at 2022-06-26 11:14:27.798712
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-26 11:14:35.164172
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    tag_0 = {'drmAdditionalHeaderId': b'\x10',
             'drmAdditionalHeaderSetId': b'\xe0',
             }
    media_0 = [{'groupId': b'\x22',
                'audioOnly': b'\x00',
                **tag_0},
               {'groupId': b'\x33',
                'audioOnly': b'\x00',
                **tag_0},
               {'groupId': b'\x44',
                'audioOnly': b'\x00'},
               {'groupId': b'\x55',
                'audioOnly': b'\x00'},
                ]

# Generated at 2022-06-26 11:14:44.560793
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    # Generate a mp4 bytestream
    # Write to file
    new_mp4 = open("new_mp4_write_metadata_tag.mp4", 'w')
    # Write a mp4 header in it
    write_flv_header(new_mp4)
    # Write a metadata tag in it
    write_metadata_tag(new_mp4, b"test")
    new_mp4.close()



# Generated at 2022-06-26 11:14:52.169384
# Unit test for function get_base_url
def test_get_base_url():
    base_url = get_base_url("https://example.com/test")
    if base_url == "https://example.com/test":
        print("Unit test for get_base_url PASS")
    else:
        print("Unit test for get_base_url FAIL")



# Generated at 2022-06-26 11:14:54.869781
# Unit test for function get_base_url
def test_get_base_url():
    base_url_0 = get_base_url(None)
    print(base_url_0)


# Generated at 2022-06-26 11:14:56.878512
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    test_case_0()
    test_write_metadata_tag()


# Generated at 2022-06-26 11:15:03.273727
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    string_0 = b'0123\x004567'
    flv_reader_0 = FlvReader(string_0)
    assert flv_reader_0.read_string() == b'0123'
    assert flv_reader_0.read_string() == b'4567'


# Generated at 2022-06-26 11:15:08.519737
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    abst0_path = '../test/testdata/'
    abst0_data = open(abst0_path, 'rb').read()
    abst0_reader = FlvReader(abst0_data)
    abst0_res = abst0_reader.read_abst()


# Generated at 2022-06-26 11:15:17.435631
# Unit test for function get_base_url
def test_get_base_url():
    xml = fix_xml_ampersands("""
<manifest xmlns="http://ns.adobe.com/f4m/1.0">
    <baseURL>http://example.com/</baseURL>
    <media href="test.f4m">
        <metadata>...</metadata>
    </media>
</manifest>
""")
    manifest_elt = compat_etree_fromstring(xml.encode('utf-8'))
    base_url = get_base_url(manifest_elt)
    assert base_url == 'http://example.com/', base_url


# Generated at 2022-06-26 11:15:41.456323
# Unit test for function remove_encrypted_media

# Generated at 2022-06-26 11:15:45.897606
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4m_fd_0 = F4mFD()
    f4m_fd_0 = F4mFD()
    filename = 'filename'
    info_dict = {
        'url': 'url',
    }
    f4m_fd_0.real_download(filename, info_dict)

if __name__ == '__main__':
    # test_F4mFD_real_download()
    test_case_0()

# Generated at 2022-06-26 11:15:55.218914
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader = FlvReader()


# Generated at 2022-06-26 11:16:06.005791
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:16:14.862437
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    """
    The test data comes from a live stream
    """
    flv_reader_0 = FlvReader()


# Generated at 2022-06-26 11:16:18.656259
# Unit test for function get_base_url
def test_get_base_url():
    manifest_str = '''<manifest xmlns="http://ns.adobe.com/f4m/2.0">
    <baseURL>example://baseurl</baseURL>
</manifest>'''
    assert get_base_url(manifest_str) == 'example://baseurl'
    manifest_str_2 = '''<manifest xmlns="http://ns.adobe.com/f4m/2.0">
</manifest>'''
    assert get_base_url(manifest_str_2) == None

# test case: get_fragment_list from f4m file

# Generated at 2022-06-26 11:16:29.952845
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    flv_reader_read_asrt_0 = FlvReader()

# Generated at 2022-06-26 11:16:39.719567
# Unit test for function build_fragments_list
def test_build_fragments_list():
    import os
    pwd = os.path.dirname(__file__)
    with open(os.path.join(pwd, 'fixtures', 'bootstrap_hds.dat'), 'rb') as fp:
        boot_info = read_bootstrap_info(fp.read())
    segments_fragments = build_fragments_list(boot_info)

# Generated at 2022-06-26 11:16:51.581275
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    info_dict_0 = {
        'tbr': None,
        'url': 'http://bglive-a.bitgravity.com/ndtv/247hi/ngrp:ndtv24x7_all/manifest.f4m',
        'extra_param_to_segment_url': None,
        'player_url': None,
        'play_path': None,
        'page_url': None,
    }
    test_FD = F4mFD(info_dict_0, {})
    test_FD.real_download('filename_0', info_dict_0)

# Generated at 2022-06-26 11:17:01.418432
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:17:31.370283
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:17:41.876551
# Unit test for function get_base_url
def test_get_base_url():
    manifest_1 = fix_xml_ampersands('<manifest xmlns="http://ns.adobe.com/f4m/1.0" />')
    manifest_xml_1 = compat_etree_fromstring(manifest_1)
    assert get_base_url(manifest_xml_1) is None
    manifest_2 = fix_xml_ampersands('<manifest xmlns="http://ns.adobe.com/f4m/1.0"><baseURL>http://somehost.com/base/</baseURL></manifest>')
    manifest_xml_2 = compat_etree_fromstring(manifest_2)
    assert get_base_url(manifest_xml_2) == 'http://somehost.com/base/'

# Generated at 2022-06-26 11:17:49.026565
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-26 11:17:59.092830
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader_1 = FlvReader()
    # First we call read_bytes to generate some bytes
    flv_reader_1.read_bytes(8)
    # Then we call read_string to get the bytes
    assert flv_reader_1.read_string() == b''
    flv_reader_2 = FlvReader(b'8=\x00abc\x002=\x001\x00')
    assert flv_reader_2.read_string() == b'8=\x00abc'
    assert flv_reader_2.read_string() == b'2=\x001'
    flv_reader_3 = FlvReader(b'8=\x00abc\x00\x00')

# Generated at 2022-06-26 11:18:08.769396
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-26 11:18:19.383193
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-26 11:18:23.987203
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    # <!DOCTYPE cross-domain-policy SYSTEM "http://www.macromedia.com/xml/dtds/cross-domain-policy.dtd">
    # <cross-domain-policy>
    # <allow-access-from domain="*" />
    # </cross-domain-policy>
    flv_reader_0 = FlvReader()
    flv_reader_0.read_abst()


# Generated at 2022-06-26 11:18:35.675166
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:18:44.043724
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:18:52.997937
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    logging.basicConfig(level=logging.DEBUG)
    # Setup YDL and F4mFD
    fd = F4mFD()
    ydl = YoutubeDL()
    ydl.params = {}
    ydl.params['test'] = True
    fd.ydl = ydl
    # Setup parameters
    filename = 'filename'
    info_dict = {}
    info_dict['url'] = 'http://example.com/manifest.f4m'
    # Run function
    result = fd.real_download(filename, info_dict)
    # Check result
    assert type(result) == bool

if __name__ == '__main__':
    test_F4mFD_real_download()

# Generated at 2022-06-26 11:19:17.940575
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    pass


# Generated at 2022-06-26 11:19:27.334076
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_1 = FlvReader()


# Generated at 2022-06-26 11:19:35.583961
# Unit test for function build_fragments_list
def test_build_fragments_list():
    '''
    Test case using an actual production system with a live stream.
    The aim is to find out how many fragments will be in the list. This is
    useful when testing live downloads.
    '''
    with open('data/hds/bootstrapinfo_live.bin', 'rb') as fp:
        boot_info = read_bootstrap_info(fp.read())
        res = build_fragments_list(boot_info)
        print('num fragments: ', len(res))
        assert len(res) == 12


# Generated at 2022-06-26 11:19:42.494800
# Unit test for function build_fragments_list
def test_build_fragments_list():
    print("Test build_fragments_list")
    flv_reader_0 = FlvReader()
    boot_info_0 = flv_reader_0.read_bootstrap_info()
    fragments_list_0 = build_fragments_list(boot_info_0)
    print("of %d fragments" % len(fragments_list_0))
    for fragment in fragments_list_0:
        (segment, index) = fragment
        print("segment %d, fragment %d" % (segment, index))

# TODO: unit test for functions _read_bootstrap_info and _read_box_info


# Generated at 2022-06-26 11:19:43.509243
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4m_fd_0 = F4mFD()


# Generated at 2022-06-26 11:19:48.165965
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-26 11:19:52.343253
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4m_fd_0 = F4mFD()
    f4m_fd_0.real_download()

# Python-C test for method get_base_url of class F4mFD

# Generated at 2022-06-26 11:20:00.052475
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:20:06.661487
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:20:07.625319
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4mfd_0 = F4mFD()


# Generated at 2022-06-26 11:20:46.903289
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:20:56.072173
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4m_fd = F4mFD()
    filename = 'test.flv'
    info_dict = {'tbr': 384, 'url': 'http://test.com/test.f4m'}
    f4m_fd.real_download(filename, info_dict)
    # Test case from a description of the bug #7780.
    # ValueError: invalid literal for int() with base 10: '7'
    f4m_fd = F4mFD()

# Generated at 2022-06-26 11:21:04.394157
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:21:15.376893
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    """
    Read a file in the flv format and verify that the result is correct.
    """
    flv_reader = FlvReader()
    info = flv_reader.read_bootstrap_info()

# Generated at 2022-06-26 11:21:18.615139
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4mfd_obj = F4mFD()
    # filename = inst.real_download(filename, info_dict)
    raise NotImplementedError('Function "real_download" not implemented yet')
    return filename


# Generated at 2022-06-26 11:21:26.708629
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    with io.open('assets/adobe_asrt_0.flv', 'rb') as flv_data:
        flv_reader_0 = FlvReader(flv_data.read())
    with io.open('assets/adobe_asrt_1.flv', 'rb') as flv_data:
        flv_reader_1 = FlvReader(flv_data.read())
    assert flv_reader_0.read_asrt() == flv_reader_1.read_asrt()


# Generated at 2022-06-26 11:21:34.937023
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-26 11:21:39.239118
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    F4mFD_instance_0 = F4mFD()
    filename = "filename_0000"
    info_dict = {'url':'man_url_0000','tbr':None}
    F4mFD_instance_0.real_download(filename, info_dict)


# Generated at 2022-06-26 11:21:49.115554
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    reader = FlvReader(b'\x00\x00\x00\x20\x61\x73\x72\x74\x00\x00\x00\x00\x0d\x00\x00\x00\x01\x77\x77\x77\x2e\x6d\x65\x69\x61\x2e\x63\x6f\x6d\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00\x05')

# Generated at 2022-06-26 11:21:55.288783
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    assert remove_encrypted_media([compat_etree_fromstring("""
<media url="https://example.com/test1" bootstrapInfoId="fake_id1"
       bitrate="811" width="640" height="367"
       drmAdditionalHeaderId="fake_id1"
       drmAdditionalHeaderSetId="fake_id2"/>
<media url="https://example.com/test2" bootstrapInfoId="fake_id3"
       bitrate="811" width="640" height="367"/>
""")]) != []


# Generated at 2022-06-26 11:22:52.121684
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader = FlvReader()
    var = flv_reader.read_afrt()


# Generated at 2022-06-26 11:22:57.583700
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    actual = flv_reader.read_asrt()
    expected = {'segment_run': []}
    assert actual == expected


# Generated at 2022-06-26 11:23:04.024768
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import youtube_dl.extractor.generic as ytg
    import youtube_dl.downloader.fragment as ytf
    import youtube_dl.utils as ytu
    import io

    # io.open doesn't support 'U' mode
    similar_open = io.open
    def my_open(name, mode='r', buffering=-1, encoding=None, errors=None, newline=None, closefd=True, opener=None):
        if encoding is None:
            encoding = 'utf-8'
        return similar_open(name, mode, buffering=buffering, encoding=encoding, errors=errors, newline=newline, closefd=closefd, opener=opener)

    ytu.open = my_open

    # Prepare instance of F4mFD


# Generated at 2022-06-26 11:23:09.491495
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    # Testcase0
    print('Case-0:')
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_abst()
    print('Case-0: Pass')
