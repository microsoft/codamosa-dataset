

# Generated at 2022-06-26 11:13:47.325412
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'abc\x00').read_string() == b'abc'
    assert FlvReader(b'abcd\x00').read_string() == b'abcd'


# Generated at 2022-06-26 11:13:58.929203
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader_0 = FlvReader(b'')
    flv_reader_1 = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    flv_reader_2 = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    flv_reader_3 = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    flv_reader_4 = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')

# Generated at 2022-06-26 11:14:07.697929
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-26 11:14:15.015602
# Unit test for function build_fragments_list
def test_build_fragments_list():
    """
    Check that build_fragments_list returns the list of fragments from the file
    bootstrap_info_fragments2.abst which is a small file that contains 2 fragments
    """
    # Assert that the function returns a list
    bootstrap_info = read_bootstrap_info(
        io.open('tests/data/12728021_2.abst', 'rb').read())
    frags = build_fragments_list(bootstrap_info)
    assert isinstance(frags, list)
    # Check that the function returns the expected list.
    expected = [(1, 1), (1, 2)]
    assert frags == expected


# Generated at 2022-06-26 11:14:19.854262
# Unit test for function get_base_url
def test_get_base_url():
    test_case_0()
    test_case_1()
    test_case_2()

# Test get_base_url with manifest version = 1 

# Generated at 2022-06-26 11:14:31.940847
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = read_bootstrap_info(b'\x00\x00\x00\x0d\x61\x62\x73\x74\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x05\x00\x00\x01\x65\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x62\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00'
)

# Generated at 2022-06-26 11:14:38.119475
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:14:42.623783
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'test\x00\x00\x00\x00').read_string() == b'test'


# Generated at 2022-06-26 11:14:46.179895
# Unit test for function get_base_url
def test_get_base_url():
    f = open('tests/request.aac', 'rb')
    root = compat_etree_fromstring(f.read())
    base_url = get_base_url(root)
    print(base_url)



# Generated at 2022-06-26 11:14:59.282629
# Unit test for function get_base_url
def test_get_base_url():
    manifest = """
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <baseURL>baseURL</baseURL>
    </manifest>
    """
    assert get_base_url(compat_etree_fromstring(manifest)) == 'baseURL'

    manifest2 = """
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <baseUrl>baseUrl</baseUrl>
    </manifest>
    """
    assert get_base_url(compat_etree_fromstring(manifest2)) is None


# Generated at 2022-06-26 11:15:49.763618
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    pass


# Generated at 2022-06-26 11:15:52.453799
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    try:
        test_case_0()
        assert False
    except DataTruncatedError as e_test_case_0:
        assert e_test_case_0.args == data_truncated_error_0.args


# Generated at 2022-06-26 11:15:56.218827
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Set up parameters for the method
    filename = "output.mp4"
    info_dict = {
        "id": "1",
        "title": "1"
    }
    # Run the method
    f4mfd = F4mFD()
    f4mfd.real_download(filename, info_dict)


# Generated at 2022-06-26 11:16:07.069233
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {'segments': [
        {
            'segment_run': [
            ]
        }
    ],
        'fragments': [
            {
                'fragments': [
                ]
            }
        ],
        'live': False
    }
    res = build_fragments_list(boot_info)
    assert res == []


# Generated at 2022-06-26 11:16:16.240591
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = '''
    <media a="b">
    <e1>a1</e1>
    <e2 drmAdditionalHeaderId="0" drmAdditionalHeaderSetId="5">a2</e2>
    <e3 drmAdditionalHeaderId="0" p="3">a3</e3>
    <e4>a4</e4>
    </media>
    '''
    et = compat_etree_fromstring(xml)
    elems = remove_encrypted_media(et.findall('e1'))
    assert len(elems) == 1

    elems = remove_encrypted_media(et.findall('e2'))
    assert len(elems) == 0

    elems = remove_encrypted_media(et.findall('e3'))
    assert len(elems)

# Generated at 2022-06-26 11:16:27.208471
# Unit test for function remove_encrypted_media

# Generated at 2022-06-26 11:16:37.213490
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:16:43.732996
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:16:55.709011
# Unit test for function remove_encrypted_media

# Generated at 2022-06-26 11:17:04.928271
# Unit test for function build_fragments_list
def test_build_fragments_list():
    import os
    BOOTSTRAP_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bootstrapinfo.abst')
    with open(BOOTSTRAP_FILE, 'rb') as f:
        bootstrap_bytes = f.read()

    boot_info = read_bootstrap_info(bootstrap_bytes)
    fragments = build_fragments_list(boot_info)
    # Assert that there are three segments in the HDS
    # The first segment is an ad and is ignored
    assert len(boot_info['fragments'][0]['fragments']) == 5
    assert len(boot_info['segments'][0]['segment_run']) == 5
    assert len(fragments) == 4

    # The first fragment

# Generated at 2022-06-26 11:18:01.245783
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {'live':True,'fragments':[{'fragments': [{'first': 1, 'ts': 623648961, 'duration': 9355, 'discontinuity_indicator': None}, {'first': 333, 'ts': 717214296, 'discontinuity_indicator': None, 'duration': 59940}]}],'segments':[{'segment_run': [(0, 333), (1, 1), (2, 1), (3, 1)]}]}
    print(build_fragments_list(boot_info))


# Generated at 2022-06-26 11:18:12.248815
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from xml.etree import ElementTree
    from xml.dom import minidom
    from .scte35 import parse_cue_settings_list

    # Setup

# Generated at 2022-06-26 11:18:20.774224
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = read_bootstrap_info(b'''
        f4vhdstttp://localhost:8087/live/yueguangxianhualu/yueguangxianhualu.f4m?hdcore=3.5.0
        video/avc,audio/mp4a.40.2
        src=http://10.10.0.34:8087/live/yueguangxianhualu/yueguangxianhualu.seg1-frag1
        clientid=xlive
        '''.replace(b' ', b'').replace(b'\n', b'').replace(b'\r', b''))
    fragments = build_fragments_list(boot_info)

# Generated at 2022-06-26 11:18:31.361616
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-26 11:18:40.597819
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Test case 0
    arg_0 = {}
    arg_0['segments'] = []
    arg_0['segments'].append({})
    arg_0['segments'][0]['segment_run'] = []
    arg_0['segments'][0]['segment_run'].append((0, 1))
    arg_0['fragments'] = []
    arg_0['fragments'].append({})
    arg_0['fragments'][0]['fragments'] = []
    arg_0['fragments'][0]['fragments'].append({})
    arg_0['fragments'][0]['fragments'][0]['first'] = 1
    arg_0['fragments'][0]['fragments'][0]['ts']

# Generated at 2022-06-26 11:18:51.108784
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:19:01.591112
# Unit test for function build_fragments_list
def test_build_fragments_list():
    seg_run = [{'segment_run':[(1,1),(2,1)]}]
    frag_run = [{'fragments':[{'first':1,'ts':1000.0,'duration':2000,'discontinuity_indicator':None},{'first':2,'ts':4000.0,'duration':3000,'discontinuity_indicator':None}]}]
    live = False
    boot_info = {'segments':seg_run,'fragments':frag_run,'live':live}
    frag_list = build_fragments_list(boot_info)
    counter = 0
    for frag in frag_list:
        counter += 1
        assert(frag == (1,1) or frag == (2,2))
    assert(counter == 2)

# Generated at 2022-06-26 11:19:04.654443
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test case 1
    f4m_fd_1 = F4mFD()
    f4m_fd_1.real_download('filename', 'info_dict')


# Generated at 2022-06-26 11:19:16.128350
# Unit test for function remove_encrypted_media

# Generated at 2022-06-26 11:19:23.769043
# Unit test for function build_fragments_list
def test_build_fragments_list():
    flv_reader_0 = FlvReader(
        b'asrt\x00\x00\x00\x24\x00\x01\x00\x00\x00\x01\x00\x04\x00\x00\x00\x05\x00\x01\x00\x00\x00\x01\x00\x02\x00\x00\x00\x03\x00\x01\x00\x00\x00\x01\x00\x02\x00\x00\x00\x00'
    )
    box_info_0 = flv_reader_0.read_box_info()
    flv_reader_1 = FlvReader(box_info_0[2])
    var_0 = flv_reader_1.read_