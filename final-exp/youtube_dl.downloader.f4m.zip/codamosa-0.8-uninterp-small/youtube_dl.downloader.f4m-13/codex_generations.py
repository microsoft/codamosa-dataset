

# Generated at 2022-06-26 11:13:54.426645
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_1 = FlvReader(open('tests/fixtures/test.abst', 'rb').read())
    flv_reader_1.read_abst()


# Generated at 2022-06-26 11:14:02.262265
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    segment_run = [
        (1, 1),
        (1, 1),
    ]
    box_data = io.BytesIO()
    box_data.write(compat_struct_pack('!B', 1))  # version
    box_data.write(b'\x00\x00\x00')  # flags
    box_data.write(compat_struct_pack('!B', 0))  # quality_entry_count

    box_data.write(compat_struct_pack('!I', 2))  # segment_run_count
    for segment in segment_run:
        box_data.write(compat_struct_pack('!I', segment[0]))
        box_data.write(compat_struct_pack('!I', segment[1]))
    box_data.seek(0)

# Generated at 2022-06-26 11:14:08.341403
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # flv reader 0
    file_path = 'FlvReader-read_bootstrap_info_0.bin'
    with open(file_path, 'rb') as f:
        flv_reader_0 = FlvReader(f.read())
    flv_reader_0.read_bootstrap_info()

# Generated at 2022-06-26 11:14:11.572899
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader = FlvReader()
    total_size, box_type, box_data = flv_reader.read_box_info()



# Generated at 2022-06-26 11:14:17.937775
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader_0 = FlvReader()

# Generated at 2022-06-26 11:14:29.072818
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-26 11:14:39.026627
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml_string="""
    <media url="http://10.199.165.187/vod/_definst_/mp4:vod/test/test.mp4/manifest.mpd"
           streamId="0"
           bootstrapInfoId="bootstrap0"
           bitrate="974"
           width="854"
           height="480"
           type="video"
           quality="HD"
           drmAdditionalHeaderId="drm0"
           drmAdditionalHeaderSetId="drm0" />
    """

# Generated at 2022-06-26 11:14:50.460757
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader = FlvReader()

# Generated at 2022-06-26 11:14:53.376544
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_0 = FlvReader()
    afrt = flv_reader_0.read_afrt()


# Generated at 2022-06-26 11:14:54.297538
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    pass


# Generated at 2022-06-26 11:15:19.116650
# Unit test for function build_fragments_list
def test_build_fragments_list():
    num_segments = 0
    num_fragments = 0
    segments = []
    fragments = []
    boot_info = {'segments': segments, 'fragments': fragments}
    # 1 segment and 2 fragments
    segments.append({'segment_run': [(0,2)]})
    fragments.append({'fragments': [{'first': 1, 'ts': 0, 'duration': 0, 'discontinuity_indicator': None}]})
    assert build_fragments_list(boot_info) == [(0,1),(0,2)]
    # 1 segment and 1 fragment
    segments[0]['segment_run'][0] = (0,1)
    assert build_fragments_list(boot_info) == [(0,1)]
    # 2 segments, 2 fragments each


# Generated at 2022-06-26 11:15:22.183288
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Initialize test environment
    # Run function
    # Check if the result is equal
    assert build_fragments_list(None) == None



# Generated at 2022-06-26 11:15:30.579676
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    input0 = b"l"
    input1 = b"xkK"
    input2 = b"^@:$"
    input3 = b")\x00"
    input4 = b"\x00\x00\x00\x00\x00\x00\x00\x00"
    input5 = b"\x00\x00\x00\x00\x00\x00\x00\x00"
    input6 = b"\x00"
    input7 = b"\x00"
    input8 = b"\x00"
    input9 = b"\x00"
    input10 = b"\x00"
    input11 = b"\x00"
    input12 = b"\x00"
    input13 = b"\x00"

# Generated at 2022-06-26 11:15:36.211063
# Unit test for function build_fragments_list
def test_build_fragments_list():
    str_0 = compat_b64decode(b'aHR0cDovL3d3dy5ydWQuY29tL3JhL3N0dWRpby9hbGJlcnRhbWkuZmx2')
    var_0 = read_bootstrap_info(str_0)
    var_1 = build_fragments_list(var_0)
    var_2 = len(var_1)
    print(var_2)



# Generated at 2022-06-26 11:15:41.041238
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    str_0 = 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
    var_0 = FlvReader(str_0).read_abst()
    assert var_0['fragments'][0]['discontinuity_indicator'] == None
    assert var_0['live'] == False
    assert var_0['segments'][0]['segment_run'] == []


# Generated at 2022-06-26 11:15:49.686114
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    FD_NAME = 'f4m'
    filename = None
    info_dict = None
    f4mFD = F4mFD(None)
    f4mFD.to_screen = None
    f4mFD.report_error = None
    f4mFD.ydl = None
    f4mFD._prepare_url(info_dict, None)
    f4mFD._get_unencrypted_media(None)
    f4mFD._get_bootstrap_from_url(None)
    f4mFD._update_live_fragments(None, None, None)
    f4mFD._parse_bootstrap_node(None, None, None)
    f4mFD.real_download(filename, info_dict)

# Generated at 2022-06-26 11:15:50.511717
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    pass


# Generated at 2022-06-26 11:15:59.640735
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-26 11:16:09.530768
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:16:13.253293
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    str_0 = None
    var_0, var_1, var_2 = FlvReader(str_0).read_box_info()
    var_5 = None
    var_3 = FlvReader(var_2)
    var_4 = var_3.read_asrt()


# Generated at 2022-06-26 11:17:02.586095
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    test_cases = [
        [
            None,
            None,
        ],
    ]
    for arg_0, out in test_cases:
        if out is None:
            continue
        ret = read_bootstrap_info(arg_0)
        assert ret == out


# Generated at 2022-06-26 11:17:12.003157
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:17:13.496549
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    str_0 = None
    var_0 = FlvReader.read_asrt(str_0)


# Generated at 2022-06-26 11:17:14.667948
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # Test case 0
    test_case_0()


# Generated at 2022-06-26 11:17:15.829162
# Unit test for function get_base_url
def test_get_base_url():
    print(48, get_base_url((test_case_0())))


# Generated at 2022-06-26 11:17:17.092040
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Testing argument parser
    m.digest_size = 0
    m.F4mFD_real_download('filename', 'info_dict')


# Generated at 2022-06-26 11:17:25.983025
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test case 0
    var_0 = 0
    str_0 = compat_struct_pack('!I', var_0)
    test_case_0(str_0, var_0)
    # Test case 1
    var_0 = 1
    str_0 = compat_struct_pack('!I', var_0) + 'a'
    test_case_1(str_0, var_0)
    # Test case 2
    var_0 = 2
    str_0 = compat_struct_pack('!I', var_0) + 'aa'
    test_case_2(str_0, var_0)
    # Test case 3
    var_0 = 3
    str_0 = compat_struct_pack('!I', var_0) + 'aaa'

# Generated at 2022-06-26 11:17:35.340775
# Unit test for function get_base_url
def test_get_base_url():
    from ..extractor.common import get_data_path
    data_path = get_data_path()
    # test for geoblocking
    manifest_geoblock = open(data_path + "geoblocking_manifest.xml", "rb").read()
    manifest_geoblock = manifest_geoblock.decode('utf-8')
    manifest_geoblock = compat_etree_fromstring(manifest_geoblock)
    assert get_base_url(manifest_geoblock) == 'https://sample-videos.com/'

    # test for sample-media type=video
    manifest = open(data_path + "sample_video_manifest.xml", "rb").read()
    manifest = manifest.decode('utf-8')
    manifest = compat_etree_fromstring(manifest)
   

# Generated at 2022-06-26 11:17:44.532344
# Unit test for function get_base_url
def test_get_base_url():
    str_0 = b'<manifest></manifest>'
    assert get_base_url(str_0) == None
    str_0 = b''
    var_0 = read_bootstrap_info(str_0)
    assert var_0 == None
    str_0 = b'<manifest></manifest>'
    var_0 = read_bootstrap_info(str_0)
    assert var_0 == None
    str_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    var_0 = read_bootstrap_info(str_0)
    assert var_0 == None
    str_

# Generated at 2022-06-26 11:17:50.705119
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    # Test case for empty xml
    expected_0 = []
    print("Test case for empty xml")
    src_0 = io.BytesIO(b'<media />')
    r_0 = remove_encrypted_media(compat_etree_fromstring(src_0.read()))
    t_0 = len(r_0) == len(expected_0)
    print("Test 0 result: " + str(t_0))
    print("=====================")

    # Test case for one encryption descriptor

# Generated at 2022-06-26 11:21:38.275230
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-26 11:21:48.514134
# Unit test for function remove_encrypted_media

# Generated at 2022-06-26 11:21:56.700157
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    class F4mFD(object):
        def report_error(self, a):
            pass
        def ydl(self):
            class ydl(object):
                def urlopen(self, a):
                    class urlopen(object):
                        def read(self, a):
                            return 'the_url_read'
                        def geturl(self, a):
                            return 'the_url_geturl'
                    return urlopen()
            return ydl()
        def params(self):
            class params(object):
                pass
            return params()
        def _prepare_url(self, a, b):
            return b
        def _get_unencrypted_media(self, a):
            return []

# Generated at 2022-06-26 11:22:06.799133
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    args_0 = {
        'url': 'http://example.com',
        'outtmpl': 'example.flv',
        'test': True
    }

    info_dict = {'url': 'http://example.com'}

    f4m = F4mFD(YoutubeDL({}), args_0, info_dict)
    f4m._downloader = mock.Mock()
    f4m._downloader.cache.get.return_value = None
    f4m._prepare_url = lambda i, u: u
    f4m.ydl.urlopen = lambda url: io.BytesIO(b'<manifest></manifest')

    ret = f4m.real_download('filename', info_dict)

    assert ret is True



# Generated at 2022-06-26 11:22:15.918456
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():

    url = 'http://video.theplatform.com/p/UQEQIC/Malcolm_in_the_Middle_S1/embed/select/y3TzIc8-vZeu'
    file_name = 'f4m_test.mp4'
    info_dict = {'id': u'1', 'url': url, 'playlist': [{'id': u'1', 'ext': 'mp4', 'title': u'test', 'url': url}], 'ext': 'mp4', 'title': u'test', 'display_id': u'1', 'duration': u'1:53'}
    f4m_downloader = F4mFD(YoutubeDL({}), info_dict)
    f4m_downloader.real_download(file_name, info_dict)

# Generated at 2022-06-26 11:22:22.623073
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    bytes_0 = b'abcd\x00\x00\x00\x05wxyz'
    reader_0 = FlvReader(bytes_0)
    assert reader_0.read_box_info() == (5, b'abcd', b'wxyz')

    bytes_0 = b'abcd\x00\x00\x06wxyz'
    reader_0 = FlvReader(bytes_0)
    assert reader_0.read_box_info() == (10, b'abcd', b'wxyz')

    bytes_0 = b'abcd\x00\x00\x01\x00\x00\x00\x05wxyz'
    reader_0 = FlvReader(bytes_0)

# Generated at 2022-06-26 11:22:27.937747
# Unit test for function build_fragments_list
def test_build_fragments_list():
    bytes_0 = b'\xae\x93\xf4\x9d\x02R\x87\xcc\x04,\x9d\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    var_0 = read_bootstrap_info(bytes_0)
    var_1 = build_fragments_list(var_0)
    assert (0, 0) == var_1[0]


# Generated at 2022-06-26 11:22:34.647096
# Unit test for function build_fragments_list
def test_build_fragments_list():
    info = {
        'fragments': [{'fragments': [{'discontinuity_indicator': None, 'duration': 2, 'first': 0, 'ts': 0}, {'discontinuity_indicator': None, 'duration': 2, 'first': 1, 'ts': 2}]}],
        'live': False,
        'segments': [{'segment_run': [(0, 2)]}]
    }
    res = build_fragments_list(info)
    assert res == [(0, 0), (0, 1)]


# Generated at 2022-06-26 11:22:41.769159
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-26 11:22:47.691503
# Unit test for function get_base_url
def test_get_base_url():
    manifest = '''
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <baseURL>http://example.com/base/</baseURL>
        <media url="media.mp4" bootstrapInfoId="bootstrap"/>
    </manifest>
    '''
    manifest = compat_etree_fromstring(manifest.encode('utf-8'))
    assert get_base_url(manifest) == 'http://example.com/base/'
