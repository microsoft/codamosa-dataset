

# Generated at 2022-06-26 11:14:29.373517
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4m_fd = F4mFD()
    f4m_fd.real_download('video.mp4', {})

if __name__ == '__main__':
    test_F4mFD_real_download()
    sys.exit(0)

# Generated at 2022-06-26 11:14:31.753169
# Unit test for function build_fragments_list
def test_build_fragments_list():
    flv_reader_0 = FlvReader()
    res = build_fragments_list(flv_reader_0.read_bootstrap_info())
    print(res)


# Generated at 2022-06-26 11:14:37.715267
# Unit test for function build_fragments_list
def test_build_fragments_list():
    flv_reader_0 = FlvReader()
    boot_info_0 = flv_reader_0.read_bootstrap_info()
    res = build_fragments_list(boot_info_0)
    print(res)


# Generated at 2022-06-26 11:14:50.022718
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Test case 0
    flv_reader_0 = FlvReader()

# Generated at 2022-06-26 11:15:02.510164
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:15:14.213871
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # static == False to test both static and live
    for static in (True, False):
        boot_info = {
            'segments': [
                {
                    'segment_run': [
                        (1, 6),
                        (5, 4),
                    ],
                },
            ],
            'fragments': [
                {
                    'fragments': [
                        {
                            'first': 2,
                            'ts': 0,
                            'duration': 0,
                            'discontinuity_indicator': 0,
                        },
                        {
                            'first': 8,
                            'ts': 0,
                            'duration': 0,
                            'discontinuity_indicator': None,
                        },
                    ],
                },
            ],
            'live': not static,
        }
       

# Generated at 2022-06-26 11:15:25.437782
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media_case_0 = """
    <media url="http://fakeUrl"/>
    <media url="http://fakeUrl" drmAdditionalHeaderSetId="1"/>
    <media url="http://fakeUrl" drmAdditionalHeaderId="1"/>
    <media url="http://fakeUrl" drmAdditionalHeaderSetId="1" drmAdditionalHeaderId="1"/>
    """
    media_case_0_iter = compat_etree_fromstring(fix_xml_ampersands(media_case_0)).getiterator(tag='media')

    for i in range(4):
        assert remove_encrypted_media(media_case_0_iter)[i].attrib == {'url': 'http://fakeUrl'}


# Generated at 2022-06-26 11:15:32.626187
# Unit test for function build_fragments_list
def test_build_fragments_list():
    flv_reader_1 = FlvReader()
    flv_reader_1.segment_run_table = [[0, 10]]
    flv_reader_1.fragment_run_entry_table = [[0, 10]]
    flv_reader_1.first_frag_number = 0
    flv_reader_1.fragments_counter = iter(range(0, 10))
    flv_reader_1.segment_0 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    flv_reader_1.fragments_count = 10

# Generated at 2022-06-26 11:15:41.421782
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-26 11:15:50.701455
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Case 0
    #   SegmentRunEntryTable
    #       first_segment        1
    #       fragments_per_segment    5
    #   FragmentRunEntryTable
    #       first    2
    #       ts  15
    #       duration    500
    segment_run_table_0 = {'segment_run': [(1,5)]}
    fragment_run_entry_table_0 = {'fragments': [{'first': 2, 'ts':15, 'duration': 500}]}
    boot_info_0 = {'segments': [segment_run_table_0], 'fragments': [fragment_run_entry_table_0], 'live': True}

# Generated at 2022-06-26 11:16:34.530681
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:16:42.374314
# Unit test for function get_base_url
def test_get_base_url():
    # first use case
    flv_reader_0 = FlvReader()
    manifest_0 = compat_etree_fromstring(b'<manifest><baseURL>C:\</baseURL></manifest>')
    print(get_base_url(manifest_0))

    # second use case
    flv_reader_1 = FlvReader()
    manifest_1 = compat_etree_fromstring(b'<manifest>\n\t</manifest>')
    print(get_base_url(manifest_1))

    # third use case
    flv_reader_2 = FlvReader()
    manifest_2 = compat_etree_fromstring(b'<manifest><baseURL>C:\</baseURL><baseURL>C:\</baseURL></manifest>')

# Generated at 2022-06-26 11:16:47.321164
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_0 = FlvReader()
    # Test case 0
    # test get_abst

    # test read_afrt
    # test_case_0
    flv_reader_0.read_afrt()



# Generated at 2022-06-26 11:16:58.018781
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    with io.open('fixtures/test_FlvReader_read_afrt.flv', 'rb') as f:
        flv_reader_0 = FlvReader(f.read())
        flv_reader_0.read_bytes(8)
        while True:
            box_size, box_type, box_data = flv_reader_0.read_box_info()
            if box_type == b'abst':
                abst = FlvReader(box_data).read_abst()
                break
        assert abst['fragments'][0] == {'first': 1, 'ts': 0, 'duration': 1, 'discontinuity_indicator': None}

# Generated at 2022-06-26 11:16:59.717742
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader = FlvReader()
    flv_reader.read_afrt()


# Generated at 2022-06-26 11:17:08.130054
# Unit test for function build_fragments_list
def test_build_fragments_list():
    bootstrap_info_0 = read_bootstrap_info(
        compat_b64decode(
            b'AAAAAAMM7bnBYwEAAAAAAP+0AIkACU6gIxOqDjm0Yc8YYgAA5CJaQ2QMoBHgGcAFAAhQD/NzcsLXdhdGNoYmFyLmhkcy54bWwAAAAAA'))

# Generated at 2022-06-26 11:17:12.172278
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:17:16.504519
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    def _test():
        # Setup test
        # This is only a test stub
        # It should be replace by real test code

        # Setup arguments
        filename = None
        info_dict = None

        # Invoke method
        retVal = f4mFD.real_download(filename, info_dict)

        # Verify results
        assert True # TODO: implement your test here
    _test()


# Generated at 2022-06-26 11:17:24.599956
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    with io.open('test.flv', 'rb') as f:
        flv_reader_0 = FlvReader(f.read())
        flv_reader_0.read_unsigned_char()
        flv_reader_0.read_unsigned_char()
        flv_reader_0.read_unsigned_int()
        total_size, box_type, box_data = flv_reader_0.read_box_info()
        #assert box_type == b'abst'
        #abst = FlvReader(box_data).read_abst()
        #print(abst)

        #total_size, box_type, box_data = flv_reader_0.read_box_info()
        #assert box_type == b'bootstrapinfo'
        #bootstrap_info = FlvReader

# Generated at 2022-06-26 11:17:28.007098
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader = FlvReader(compat_b64decode('AAABQFBQVlQAAAAAAAAAAAAAAAAAAAAAJAAAAAAAAAA4AAAAAAAAAAAAAAAAAAMAAACgFAAAAgA=='))
    res = flv_reader.read_bootstrap_info()


# Generated at 2022-06-26 11:18:31.808831
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    # Test case 1: has no drmAdditionalHeader*
    media_1 = [{'attrib': {'url': 'test_url_1', 'bootstrapInfoId': 'test_bootstrapInfoId_1', 'drmAdditionalHeaderId': 'test_drmAdditionalHeaderId_1', 'drmAdditionalHeaderSetId': 'test_drmAdditionalHeaderSetId_1'}}, \
              {'attrib': {'url': 'test_url_2', 'bootstrapInfoId': 'test_bootstrapInfoId_2'}}, \
              {'attrib': {'url': 'test_url_3', 'bootstrapInfoId': 'test_bootstrapInfoId_3', 'drmAdditionalHeaderSetId': 'test_drmAdditionalHeaderSetId_3'}}]

# Generated at 2022-06-26 11:18:40.976508
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    config.proxy = None
    ie = F4mFD()

# Generated at 2022-06-26 11:18:47.302487
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import youtube_dl.utils
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL()
    f4m_fd = F4mFD(ydl)
    res = f4m_fd.real_download('a.mp4', {'url': 'http://a.com/a/b.f4m'})
    assert res == False


# Generated at 2022-06-26 11:18:55.469783
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Initialization of variables
    url = "http://www.dailymotion.com/cdn/manifest/video/x22wstb.f4m"
    result = True
    info_dict = {}
    from youtube_dl import YoutubeDL
    ydl = YoutubeDL({'outtmpl': 'VIDEO_%(id)s.%(ext)s'})
    try:
        F4mFD(ydl).real_download("VIDEONAME.mp4", info_dict)
    except:
        result = False
    assert result

if __name__ == '__main__':

    # test case list
    test_cases_list = [
            test_case_0,
            test_F4mFD_real_download,
        ]

    # test case execution

# Generated at 2022-06-26 11:19:00.780572
# Unit test for function get_base_url
def test_get_base_url():
    manifest_str_0 = "<manifest/>"
    manifest_str_1 = "<manifest><baseURL>abc</baseURL></manifest>"
    manifest_str_2 = "<manifest><baseURL>abc</baseURL><baseURL>def</baseURL></manifest>"
    manifest_str_3 = "<manifest><baseURL>abc</baseURL><baseURL>def</baseURL><baseURL>ghi</baseURL></manifest>"

    manifest_0 = compat_etree_fromstring(manifest_str_0)
    manifest_1 = compat_etree_fromstring(manifest_str_1)
    manifest_2 = compat_etree_fromstring(manifest_str_2)
    manifest_3 = compat_etree_fromstring(manifest_str_3)

    base_url_0 = get

# Generated at 2022-06-26 11:19:09.016761
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader_1 = FlvReader()
    bootstrap_info = flv_reader_1.read_bootstrap_info()
    for segment in bootstrap_info['segments']:
        for first_segment, fragments_per_segment in segment['segment_run']:
            print(first_segment, fragments_per_segment)
    for fragment in bootstrap_info['fragments']:
        for entry in fragment['fragments']:
            print(entry['first'], entry['ts'], entry['duration'])


# Generated at 2022-06-26 11:19:19.213043
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:19:29.049595
# Unit test for function build_fragments_list
def test_build_fragments_list():
    flv_reader_1 = FlvReader()
    flv_reader_1.read_unsigned_int()
    flv_reader_1.read_unsigned_int()
    flv_reader_1.read_unsigned_int()
    flv_reader_1.read_unsigned_int()
    flv_reader_1.read_unsigned_int()
    flv_reader_1.read_unsigned_int()
    flv_reader_1.read_unsigned_int()
    flv_reader_1.read_unsigned_int()
    flv_reader_1.read_unsigned_int()
    flv_reader_1.read_unsigned_long_long()
    flv_reader_1.read_unsigned_long_long()
    flv_reader_1.read_string()
    flv_

# Generated at 2022-06-26 11:19:39.860926
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader = FlvReader()

# Generated at 2022-06-26 11:19:45.947564
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    # test case 1
    test_case_1 = [
        '<media url="file://stardust.cobalt.com/hls/video_data/0.ts" isLive="true" qualityLevels="1" startTime="0" duration="11.25" bootstrapInfoId="YXNzZXR0eXBlPQ==" bitrate="1" width="1920" height="1080" streamingType="live" mediaType="video" mimeType="video/mp4" codecs="avc1.4d400b">',
        '<drmAdditionalHeaderId>YXNzZXR0eXBlPQ==</drmAdditionalHeaderId>',
        '</media>',
    ]
    etree_1 = compat_etree_fromstring(''.join(test_case_1))

# Generated at 2022-06-26 11:21:17.294433
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:21:27.677719
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4m_url = 'https://tungsten.aaplimg.com/VOD/bipbop_adv_example_v2/master.m3u8'

    try:
        ydl = YoutubeDL()
        ydl.params['outtmpl'] = 'temp.%(ext)s'
        ydl.add_default_info_extractors()
        ydl.process_ie_result({'url': f4m_url})
        test_0 = os.path.exists("temp.mp4")

        if test_0:
            os.remove("temp.mp4")
    except Exception as e:
        print("Failed: " + str(e))
        return False

    return test_0


# Generated at 2022-06-26 11:21:35.525621
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:21:46.493827
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:21:55.010303
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():

    from .extractor import VideoExtractor

    # Extractor object
    extractor = VideoExtractor()
    # F4mFD object
    f4mfd = F4mFD()

    # Get params prepared
    params = f4mfd.params
    params['test'] = True
    extractor.params = params

    # Get ydl prepared
    ydl = extractor.ydl
    # F4mFD object
    f4mfd.ydl = ydl

    # Get url prepared
    url = 'http://www.w3school.com.cn/example/html5/mov_bbb.mp4'
    # Get the filename
    filename = f4mfd.get_filename(url)

    # info_dict object
    info_dict = {}
    # Get url prepared
    info_dict['url']

# Generated at 2022-06-26 11:22:05.061245
# Unit test for function write_flv_header
def test_write_flv_header():
    # Case 1.
    #stream = io.BytesIO()
    stream = io.StringIO()
    write_flv_header(stream)
    #print(stream.getvalue())
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'
    # Case 2.
    #stream = io.BytesIO()
    stream = io.StringIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'
    # Case 3.
    #stream = io.BytesIO()
    stream = io.StringIO()
    write_fl

# Generated at 2022-06-26 11:22:13.175856
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'fragments': [
            {
                'fragments': [                    
                    {
                        'discontinuity_indicator': None,
                        'duration': 1001,
                        'first': 0,
                        'ts': 659858,
                    },
                ]     
            }
        ],
        'segments': [
            {
                'segment_run': [
                    (0, 1),
                    (1, 1),
                    (2, 1),
                    (3, 1),
                    (4, 1),
                ]
            }
        ]
    }

    fragments_list = build_fragments_list(boot_info)
    assert fragments_list == [(0, 0), (1, 1), (2, 2), (3, 3), (4, 4)]



# Generated at 2022-06-26 11:22:21.176112
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:22:29.065921
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:22:38.623205
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    time_scale = 1000
    fragments_count = 5