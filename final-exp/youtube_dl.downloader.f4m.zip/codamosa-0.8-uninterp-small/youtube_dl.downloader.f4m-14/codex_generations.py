

# Generated at 2022-06-26 11:14:12.126542
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:14:25.879802
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Live stream
    boot_info_live = {
        'live': True,
        'segments': [
            {
                'segment_run': [
                    (0, 4294967295)
                ]
            }
        ],
        'fragments': [
            {
                'fragments': [
                    {'ts': 0, 'duration': 0, 'first': 0, 'discontinuity_indicator': None}
                ]
            }
        ]
    }
    # Normal segment run

# Generated at 2022-06-26 11:14:31.148996
# Unit test for function write_flv_header
def test_write_flv_header():
    with io.BytesIO() as stream:
        write_flv_header(stream)
        assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'


# Generated at 2022-06-26 11:14:37.833402
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:14:39.401040
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    test_file = io.open('/tmp/test.abst', 'rb')
    abst_reader = FlvReader(test_file.read())
    abst_info = abst_reader.read_abst()
    print(abst_info)


# Generated at 2022-06-26 11:14:46.532236
# Unit test for function build_fragments_list
def test_build_fragments_list():
    bootstrap_info = read_bootstrap_info(
        compat_b64decode(BOOTSTRAP_FRAGMENTS_LIST_TEST))
    res = build_fragments_list(bootstrap_info)
    assert res == [(1, 0), (1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6)]


# Generated at 2022-06-26 11:14:59.457486
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    f4m_test_file = io.BytesIO()
    f4v_test_file = io.BytesIO()
    # f4v_test_file.write(('\x00'*4).encode('ascii'))
    with open('tests/data/test.f4m', 'rb') as f:
        f4m_test_file.write(f.read())
    with open('tests/data/test.f4v', 'rb') as f:
        f4v_test_file.write(f.read())

    f4m_reader = FlvReader(f4m_test_file.getvalue())
    f4v_reader = FlvReader(f4v_test_file.getvalue())
    
    f4m_reader.read_string()
    f4v_reader

# Generated at 2022-06-26 11:15:02.453860
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    t_F4mFD = F4mFD()
    t_F4mFD.real_download('filename', {'url': 'http://1'})


_FILE_COUNTER = 0
_FILE_COUNTER_LOCK = threading.Lock()



# Generated at 2022-06-26 11:15:14.213858
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    string_to_test = b'\x0a\x0b\x0c\x0d\x00'
    test_case_0()
    test_number_of_calls_0 = 0
    try:
        string_to_test_reader = FlvReader(string_to_test)
        string_to_test_reader.read_string()
        test_number_of_calls_0 += 1
        assert test_number_of_calls_0 == 1, 'reachable'
    except DataTruncatedError as data_truncated_error_0:
        test_number_of_calls_0 += 1
        assert test_number_of_calls_0 == 1, 'reachable'
        assert data_truncated_error_0.args == data_truncated_error_

# Generated at 2022-06-26 11:15:24.760362
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    reader = FlvReader(b'\x00\x00\x00\x20\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a\x2a')
    assert reader.read_box_info() == (32, b'***', b'***')


# Generated at 2022-06-26 11:16:00.755155
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader_instance = FlvReader()
    result = flv_reader_instance.read_string()
    assert result is None


# Generated at 2022-06-26 11:16:10.630765
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:16:19.557445
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    for num_quality_entry_count in range(3):
        for num_segments in range(3):
            # generate random string
            byte_array_in = bytearray()
            byte_array_in.append(0) # version
            byte_array_in.append(0) # flags
            byte_array_in.append(0) # flags
            byte_array_in.append(0) # flags
            byte_array_in.append(num_quality_entry_count) # QualityEntryCount
            for i in range(0, num_quality_entry_count):
                # quality string
                quality_string = b'quality' + compat_struct_pack('i', i)
                for character in quality_string:
                    byte_array_in.append(character)
                byte_array_in.append(0)

# Generated at 2022-06-26 11:16:31.420132
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:16:40.561184
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():

    # Test 1. Testing if the method real_download prints the message
    # 'No media found' when the manifest has no media tags.
    manifest = b"""
    <manifest
        xmlns="http://ns.adobe.com/f4m/1.0">
    </manifest>
    """
    class test_case_1_F4mFD(F4mFD):
        def to_screen(self, msg):
            assert msg == 'No media found'
        def report_error(self, msg):
            assert False

    # Test 2. Testing if the method real_download prints the message
    # 'Unsupported DRM' when the manifest has no media tags that
    # have no drmAdditionalHeaderId or drmAdditionalHeaderSetId attribute.

# Generated at 2022-06-26 11:16:52.459059
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_0 = FlvReader()
    flv_reader_0.read_unsigned_int()
    flv_reader_0.read_unsigned_char()
    flv_reader_0.read_unsigned_char()
    flv_reader_0.read_unsigned_long_long()
    flv_reader_0.read_unsigned_char()
    flv_reader_0.read_string()
    flv_reader_0.read_unsigned_int()
    flv_reader_0.read_unsigned_int()
    flv_reader_0.read_unsigned_long_long()
    flv_reader_0.read_unsigned_int()
    flv_reader_0.read_unsigned_char()
    result_0 = flv_reader_0.read_afrt()
   

# Generated at 2022-06-26 11:17:01.188925
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    # Test method read_string, when the bytes is exactly n bytes long
    reader_0 = FlvReader(b'\x00\x00')
    assert b'\x00' == reader_0.read_string()
    # Test method read_string, when the bytes is longer than n bytes long
    reader_1 = FlvReader(b'\x00\x01\x02')
    assert b'\x00' == reader_1.read_string()
    # Test method read_string, when the bytes is less than n bytes long
    reader_2 = FlvReader(b'')
    try:
        reader_2.read_string()
    except DataTruncatedError:
        pass


# Generated at 2022-06-26 11:17:10.034340
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-26 11:17:12.450651
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader(b'Hello World\x00')
    assert b'Hello World' == reader.read_string()


# Generated at 2022-06-26 11:17:20.039741
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-26 11:18:15.643074
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:18:22.921458
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    # case0
    # test of type DataTruncatedError
    try:
        flv_reader_0 = FlvReader()
        flv_reader_0.read_afrt()
        assert False
    except DataTruncatedError:
        pass
    # case1
    # test of type DataTruncatedError
    try:
        flv_reader_1 = FlvReader()
        for i in range(4):
            flv_reader_1.write(compat_struct_pack('!B', 0))
        flv_reader_1.read_afrt()
        assert False
    except DataTruncatedError:
        pass
    # case2
    # test of type DataTruncatedError

# Generated at 2022-06-26 11:18:34.178839
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:18:42.110419
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # params['cachedir'] = './test_F4mFD_real_download_cache'
    # params['test'] = True
    params = {
        '_type': 'downloader',
        'ydl_opts': {
            'params': {
                'cachedir': './test_F4mFD_real_download_cache',
                'test': True,
            }
        }
    }
    info_dict = {
        'url': 'http://example.org',
    }
    f4mfd = F4mFD(params)
    f4mfd.real_download('./test_F4mFD_real_download.f4m', info_dict)


# Generated at 2022-06-26 11:18:52.394478
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:18:55.841604
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader_0 = FlvReader()
    flv_reader_0_1 = flv_reader_0.getvalue()

    flv_reader_0.read_abst()



# Generated at 2022-06-26 11:19:01.057948
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    abst_box = b'\x00\x00\x00t\x61\x62\x73\x74'
    abst_box += b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    abst_box += b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-26 11:19:05.417950
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # Test whether a DataTruncatedError will be raised if the bootstrap data is too short
    test_reader = FlvReader(b'\x00')
    test_reader.seek(0)
    with test_case_0():
        test_reader.read_bootstrap_info()


# Generated at 2022-06-26 11:19:16.967772
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:19:23.256987
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    input_str = b'\x00\x00\x00\x13\x61\x73\x72\x74\x01\x65\x6E\x67\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x00\x02'
    reader = FlvReader(input_str)
    result = reader.read_asrt()
    expected_result = {
        'segment_run': (
            (0, 2),
            (2, 2),
        ),
    }
    assert result == expected_result


# Generated at 2022-06-26 11:19:44.119062
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    global data_truncated_error_0

# Generated at 2022-06-26 11:19:53.577611
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:20:01.488123
# Unit test for function get_base_url
def test_get_base_url():
    test_data = [
        # test data, expected result
        ['<manifest />', None],
        ['<manifest><baseURL>http://www.example.com/f4m/</baseURL></manifest>',
         'http://www.example.com/f4m/',
         ],
        ['<manifest><baseURL>http://www.example.com/f4m/'
         '</baseURL><baseURL>whatever</baseURL></manifest>',
         'http://www.example.com/f4m/',
         ],
    ]
    for manifest, expected_result in test_data:
        manifest = compat_etree_fromstring(manifest)
        result = get_base_url(manifest)
        assert result == expected_result, repr(manifest)


# Generated at 2022-06-26 11:20:07.525886
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:20:11.054172
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_file = io.BytesIO(b'\x06\x00\x00\x00test\x05\x00\x00\x00test\x00\x00\x00\x00')
    f = FlvReader(test_file)
    assert f.read_string() == b'test'
    assert f.read_string() == b'test'
    assert f.read_string() == b''



# Generated at 2022-06-26 11:20:13.391962
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test case 0
    test_case_0()

if __name__ == '__main__':
    test_F4mFD_real_download()

# Generated at 2022-06-26 11:20:22.524459
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    instance = F4mFD()

    filename = 'filename'
    info_dict = collections.OrderedDict([('id', 'id'), ('url', 'url')])

    # # Case 1: 'F4mFD._prepare_url()' throws exception
    # def side_effect(self, info_dict, url):
    #     raise IOError('requested url does not exist')
    # MonkeyPatch.setattr(F4mFD, '_prepare_url', side_effect)

    # # # Case 1.1: 'compat_etree_fromstring(manifest)' raises exception
    # # def side_effect(*args, **kwds):
    # #     raise Fatal()
    # # MonkeyPatch.setattr(compat_etree_fromstring, '__call__', side_effect)

    # # #

# Generated at 2022-06-26 11:20:30.541434
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    test_data = compat_b64decode(b'AAAAAAAH/////wAAAAAAAAAAAAADAwAAAAAAAP8AAAAAAAAAAAD/AAAAAAAAAAAA/////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
    test_reader = FlvReader(test_data)
    assert test_reader.read_box_info() == (7, b'\x00\x00\x00\x00', b'')
    assert test_reader.read_box_info() == (10, b'\x00\x00\x00\t', b'')
    assert test_reader.read_box_info() == (3, b'\x00\x00\x00\x00', None)

# Generated at 2022-06-26 11:20:35.430744
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader = FlvReader(b'\x00\x00\x00\x12\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01')
    assert((None, 0) == flv_reader.read_afrt()['fragments'][0].get('discontinuity_indicator', (None, 0)))


# Generated at 2022-06-26 11:20:42.054251
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Test case 0: function build_fragments_list() throws DataTruncatedError
    try:
        bootstrap_info_0 = read_bootstrap_info(b'\x00\x00\x00\x00')
        build_fragments_list(bootstrap_info_0)
    except DataTruncatedError as e:
        data_truncated_error_0 = e
    else:
        raise AssertionError('ExpectedDataTruncatedError not thrown')
    # Check type of exception
    assert type(data_truncated_error_0) == DataTruncatedError


# Generated at 2022-06-26 11:21:08.212446
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_0 = FlvReader()
    flv_reader_0.read_afrt()


# Generated at 2022-06-26 11:21:17.667098
# Unit test for function get_base_url

# Generated at 2022-06-26 11:21:26.060044
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    """
    Test for remove_encrypted_media function
    """
    mediapath = 'tests/resources/manifest.f4m'
    test_doc = compat_etree_fromstring(open(mediapath, 'rb').read())
    media = test_doc.findall('media')
    media = remove_encrypted_media(media)
    assert len(media) == 2
    # The 2 media element should be with rendition attribute
    for elem in media:
        assert 'url' in elem.attrib and 'rendition' in elem.attrib


# Generated at 2022-06-26 11:21:34.613671
# Unit test for function remove_encrypted_media

# Generated at 2022-06-26 11:21:43.727267
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        """<?xml version="1.0" encoding="UTF-8"?>
        <manifest>
          <baseURL>http://example.org/video.f4m</baseURL>
        </manifest>
        """)
    manifest_2 = compat_etree_fromstring(
        """<?xml version="1.0" encoding="UTF-8"?>
        <manifest>
          <baseURL>http://example.org/video.f4m</baseURL>
        </manifest>
        """)
    base_url = get_base_url(manifest)
    base_url_2 = get_base_url(manifest_2)


# Generated at 2022-06-26 11:21:49.718877
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_reader = FlvReader()
    var_0 = flv_reader.read_abst()
    assert var_0['live']
    assert var_0['fragments'][0]['first'] == 1
    assert var_0['fragments'][0]['ts'] == 67856000
    assert var_0['fragments'][0]['duration'] == 16420
    assert var_0['fragments'][0]['discontinuity_indicator'] is None


# Generated at 2022-06-26 11:21:57.406098
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-26 11:22:07.598346
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader_0 = FlvReader()
    # def read_box_info(self):
    #     """
    #     Read a box and return the info as a tuple: (box_size, box_type, box_data)
    #     """
    #     real_size = size = self.read_unsigned_int()
    #     box_type = self.read_bytes(4)
    #     header_end = 8
    #     if size == 1:
    #         real_size = self.read_unsigned_long_long()
    #         header_end = 16
    #     return real_size, box_type, self.read_bytes(real_size - header_end)

    var_0 = flv_reader_0.read_unsigned_int()
    var_1 = flv_reader_0

# Generated at 2022-06-26 11:22:16.823358
# Unit test for function get_base_url

# Generated at 2022-06-26 11:22:18.503018
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    filename = "test_case_0.test"
    info_dict = {}
    test_obj = F4mFD()
    result = test_obj.real_download(filename, info_dict)
    assert result == True


# Generated at 2022-06-26 11:22:45.033294
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader_0 = FlvReader()
    var_0 = flv_reader_0.read_box_info()


# Generated at 2022-06-26 11:22:47.378050
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_0 = FlvReader()
    # Omitted: flv_reader_0 is an FlvReader
    var_0 = flv_reader_0.read_afrt()


# Generated at 2022-06-26 11:22:52.049141
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test case 0
    # TODO: uncomment, when we have f4m test videos
    # f4mFD = F4mFD()
    # info_dict = {}
    # filename = ''
    # _ = f4mFD.real_download(filename, info_dict)
    assert True

# Generated at 2022-06-26 11:23:00.425735
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    test_data_0 = \
    "00000009" \
    "666C7662" \
    "00000001" \
    "00000001" \
    "00007530" \
    "00000001" \
    "00000000" \
    "00000000" \
    "00000000" \
    "00000000" \
    "0A000000" \
    "01000000" \
    "00000001" \
    "007530F0" \
    "00000000" \
    "00000000" \
    "00000002" \
    "00000000" \
    "007530F0" \
    "00000001" \
    "00000000" \
    "00000000" \
    "00000000" \
    "00000000" \
    "00000001" \
    "00000000" \
    "00000000" \
    "00000000"

# Generated at 2022-06-26 11:23:12.209242
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    downloads_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.join(downloads_dir, "test_cases")
    ydl_config = {
        "downloads_dir": test_dir,
        "format": "f4m",
        "test": True,
        "hds_fragment_retries": 0,
        "hds_timeout": 5,
        "hds_live_edge": 0,
        "hds_live_offset": 0,
    }
    ydl_opts = {
        "ydl_opts": ydl_config,
    }

    # Skipped test cases:
    # * "tv_play_live.json"
    # * "bild_live.json"
    # * "was