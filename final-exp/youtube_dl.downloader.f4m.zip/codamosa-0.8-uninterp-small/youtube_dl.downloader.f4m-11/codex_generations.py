

# Generated at 2022-06-26 11:14:14.196650
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():

    flv_reader_1 = FlvReader(
        b'00000024afra0000000080000001000000000000000100000013696e7465726e65740001000000696e7465726e6574'
    )
    res_1_1, res_1_2, res_1_3 = flv_reader_1.read_box_info()
    assert(res_1_1 == 36 and res_1_2 == b'afra' and res_1_3 == b'0000000080000001000000000000000100000013696e7465726e65740001000000696e7465726e6574')

    flv_reader_2 = FlvReader(
        b'00000024afra0000000080000001000000000000000100000013696e7465726e65740001000000696e7465726e657400'
    )
   

# Generated at 2022-06-26 11:14:19.388150
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.downloader.http import HttpFD

    fd = F4mFD(HttpFD())
    fd._real_download()


# Generated at 2022-06-26 11:14:31.549723
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    root = compat_etree_fromstring(b'''
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <media href="qualityLevels.f4m?hdcore=3.2.0&amp;g=YJYK7A3ZMF" bitrate="3144" width="1280" height="720"/>
        <media href="qualityLevels.f4m?hdcore=3.2.0&amp;g=XXXXXXXXXX" bitrate="3144" width="1280" height="720"/>
    </manifest>
    ''')
    media = root.findall('./media')

    assert len(media) == 2
    media = remove_encrypted_media(media)
    assert len(media) == 1

# Generated at 2022-06-26 11:14:37.270952
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-26 11:14:49.341440
# Unit test for function get_base_url
def test_get_base_url():
    # Test case 1
    flv_reader_1 = FlvReader(b'''<?xml version="1.0" encoding="utf-8"?><manifest xmlns="http://ns.adobe.com/f4m/1.0" url="https://content.jwplatform.com/manifests/vM7nH0Kl.f4m" identifier="vM7nH0Kl" xmlns:hdntl="http://www.adobe.com/liveStreamConfig"><baseURL>https://content.jwplatform.com/manifests/</baseURL></manifest>''')
    assert get_base_url(flv_reader_1) == 'https://content.jwplatform.com/manifests/'



# Generated at 2022-06-26 11:15:00.592680
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    test_case_0()

# Generated at 2022-06-26 11:15:13.128538
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-26 11:15:25.125348
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:15:32.453173
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test case 0
    flv_reader_0 = FlvReader(data=b'\x00\x00\x00\x00\x00\x00\x00\x00')
    assert flv_reader_0.read_box_info() == (0, b'\x00\x00\x00\x00', b'')

    # Test case 1
    flv_reader_1 = FlvReader(data=b'\x00\x00\x00\x05\x00\x00\x00\x00\x00\x00\x00\x00')
    assert flv_reader_1.read_box_info() == (5, b'\x00\x00\x00\x00', b'\x00\x00\x00\x00\x00')



# Generated at 2022-06-26 11:15:41.256970
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-26 11:17:02.175969
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    test_data = io.BytesIO(b'\x00\x00\x00\x00\x6a\x6c\x61\x76\x20\x20')
    flv_reader = FlvReader()
    flv_reader.wrapped = test_data
    assert flv_reader.read_box_info() == (10, b'jlav', b'  ')


# Generated at 2022-06-26 11:17:11.644707
# Unit test for function build_fragments_list
def test_build_fragments_list():
    """test for build_fragments_list"""


# Generated at 2022-06-26 11:17:19.351616
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader_0 = FlvReader()
    box_size = flv_reader_0.read_unsigned_int()
    box_type = flv_reader_0.read_bytes(4)
    afrt_info = FlvReader(flv_reader_0.read_bytes(box_size - 8)).read_afrt()
    assert box_size == 174
    assert box_type == b'afrt'
    assert afrt_info['quality_entry_count'] == 1
    assert afrt_info['fragments'][0]['first'] == 1
    assert afrt_info['fragments'][0]['ts'] == 51767401
    assert afrt_info['fragments'][0]['duration'] == 125

# Generated at 2022-06-26 11:17:28.008166
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-26 11:17:31.147361
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    # Case_0
    flv_reader_0 = FlvReader()
    abst_0 = flv_reader_0.read_abst()
    assert abst_0 == 'abst_0'
# End of Unit test for method read_abst of class FlvReader


# Generated at 2022-06-26 11:17:41.675835
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    test_case_1 = b"\x00\x00\x00A\x62\x66\x72\x74\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x08\x00\x00\x00\x02\x00\x00\x00\x2a\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x33\x00\x00\x00\x01\x00\x00\x00\x31\x00\x00\x00\x08"
    flv_reader_0 = FlvReader(test_case_1)
    fl

# Generated at 2022-06-26 11:17:47.754075
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader_1 = FlvReader()
    flv_reader_1.write(b'\x00\x06test\x00\x00\x00')
    flv_reader_1.seek(0)

    assert flv_reader_1.read_string() == b'test'

    flv_reader_2 = FlvReader()
    flv_reader_2.write(b'\x06test\x00\x00\x00')
    flv_reader_2.seek(0)

    assert flv_reader_2.read_string() == b'test'



# Generated at 2022-06-26 11:17:58.207076
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    abst = FlvReader(abst_data).read_abst()
    assert abst['fragments'][0] == {
        'first': 1, 'ts': 100, 'duration': 0,
        'discontinuity_indicator': None,
    }
    assert abst['fragments'][1] == {
        'first': 2, 'ts': 110, 'duration': 10,
        'discontinuity_indicator': None,
    }
    assert abst['fragments'][2] == {
        'first': 3, 'ts': 121, 'duration': 0,
        'discontinuity_indicator': 2,
    }

# Generated at 2022-06-26 11:18:03.144342
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader = FlvReader(b'\x05\x61\x62\x63\x64\x65\x00\x00'
                           b'\x04\x66\x67\x68\x00'
                           b'\x00')
    assert flv_reader.read_string() == b'abcde'
    assert flv_reader.read_string() == b'fgh'


# Generated at 2022-06-26 11:18:14.630562
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-26 11:19:03.138808
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # flv_reader.read_bootstrap_info()
    pass


# Generated at 2022-06-26 11:19:15.396244
# Unit test for function build_fragments_list
def test_build_fragments_list():
    import sys
    import os
    try:
        root_dir = sys._MEIPASS
    except Exception:
        root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    video_dir = os.path.join(root_dir, "tests", "video")
    video_file = os.path.join(video_dir, "hds.mp4")
    f = open(video_file, 'rb')
    bytestream = f.read()
    flv_reader = FlvReader(bytestream)
    flv_reader.read_bytes(8)
    result_0 = flv_reader.read_box_info()
    box_size = result_0[0]
    box_type = result_0[1]

# Generated at 2022-06-26 11:19:23.371581
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Init a test f4m file
    f4mFile = 'test.f4m'
    with open(f4mFile, 'w') as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?><manifest xmlns="http://ns.adobe.com/f4m/1.0">' +
                '<id>test</id><mimeType>video/x-flv</mimeType><streamType>recorded</streamType><duration>60000' +
                '</duration><bootstrapInfo profile="named" id="bootstrap1"><url>test.bootstrap</url></bootstrapInfo>'
                '</manifest>')

    # Initialize a F4mFD object
    F4mFD_test = F4mFD()
    # Initialize a YDL object
   

# Generated at 2022-06-26 11:19:30.316215
# Unit test for function build_fragments_list
def test_build_fragments_list():
    with io.open('bootstrap', 'rb') as f:
        data = f.read()
    boot_str = compat_b64decode(data)
    boot_info = read_bootstrap_info(boot_str)
    fragments = build_fragments_list(boot_info)
    print(fragments)
    assert len(fragments) == 2
    assert fragments[0] == (1, 1)
    assert fragments[1] == (1, 2)

#  Unit test for function read_bootstrap_info

# Generated at 2022-06-26 11:19:40.437972
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:19:43.420241
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    manifest = 'http://example.com/manifest.f4m'
    test_case = {
        'url': manifest,
    }
    result = F4mFD().real_download(None, test_case)
    assert result is True

# Test case for real_download with a live stream

# Generated at 2022-06-26 11:19:45.301258
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    """
    Unit test for method read_abst of class FlvReader
    """
    flv_reader_0 = FlvReader()
    abst_info = flv_reader_0.read_abst()
    print(abst_info)

# Generated at 2022-06-26 11:19:48.262004
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from .test_data import _TEST_CASE_2_F4M
    data = compat_b64decode(_TEST_CASE_2_F4M)
    abst = FlvReader(data).read_bootstrap_info()
    assert abst


# Generated at 2022-06-26 11:19:55.382635
# Unit test for function get_base_url
def test_get_base_url():
    # This piece of XML is from a sample file from http://demo.castlabs.com/tmp/textdata_1/
    with open(r'D:\code\yt_dl\yt_dl\extractor\test\test_files\sample_f4m_textdata_1.xml', 'rb') as file_ptr:
        manifest = compat_etree_fromstring(file_ptr.read())

# Generated at 2022-06-26 11:20:02.420421
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():

    # test case 1: return is None
    media = None
    expected_result_1 = None
    actual_result_1 = remove_encrypted_media(media)
    assert actual_result_1 == expected_result_1

    # test case 2: return is empty list
    media = []
    expected_result_2 = []
    actual_result_2 = remove_encrypted_media(media)
    assert actual_result_2 == expected_result_2

    # test case 3: return is list

# Generated at 2022-06-26 11:20:36.216325
# Unit test for function remove_encrypted_media

# Generated at 2022-06-26 11:20:45.735061
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    file_path = os.path.join(os.path.dirname(__file__), 'test_data', 'f4m_manifest.f4m')
    with open(file_path, 'rb') as f:
        manifest = f.read().decode('utf-8')

    doc = compat_etree_fromstring(manifest)
    formats = [(int(f.attrib.get('bitrate', -1)), f)
               for f in remove_encrypted_media(doc.findall(_add_ns('media')))]
    formats = sorted(formats, key=lambda f: f[0])
    rate, media = formats[-1]
    man_url = 'http://example.com/manifest.f4m'
    man_base_url = man_url
    base_url = compat_url

# Generated at 2022-06-26 11:20:54.760991
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml_0 = b'<media fileSize="302768" ' \
            b'bootstrapInfoId="bootstrap0" ' \
            b'bitrate="50" drmAdditionalHeaderId="0" ' \
            b'url="media0.f4m?p=HD" ' \
            b'mediaId="media0" drmAdditionalHeaderSetId="0">' \
            b'<metadata>video/mp4,Level=3.1,Profile=Simple</metadata>' \
            b'</media>'

    bytes_0 = compat_b64decode(xml_0)
    xmltree_0 = compat_etree_fromstring(bytes_0)

    remove_encrypted_media(xmltree_0)

    assert xml_0 == xmltree_0.tostring()




# Generated at 2022-06-26 11:21:02.718584
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Prepare tests
    import sys
    import os
    import zipfile
    from io import BytesIO
    from io import IOBase
    from urllib.error import HTTPError
    from urllib.request import Request
    from urllib.parse import urlencode
    from urllib.parse import unquote
    from urllib.parse import quote

    class TestF4mFD(F4mFD):
        def real_download(self, filename, info_dict):
            return True

    # Prepare test files
    test_dir = os.path.dirname(os.path.abspath(__file__))
    unit_test_dir = os.path.join(test_dir, 'unit_tests')

# Generated at 2022-06-26 11:21:13.861422
# Unit test for function get_base_url
def test_get_base_url():
    bytes_0 = b'\x9d\xe4\xb3\x15\xfeT\x0e\x0fL\x82!\xed\xef'

# Generated at 2022-06-26 11:21:15.602540
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # TODO: add a testcase
    # F4mFD.real_download(filename, info_dict)
    return

__all__ = ['F4mFD']

# Generated at 2022-06-26 11:21:25.658213
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    if not test_F4mFD_real_download.initialized:
        test_F4mFD_real_download.initialized = True
        # Do nothing
    f4mFD_real_download(
        ydl=None,
        _prepare_url=None,
        _prepare_frag_download=None,
        _start_frag_download=None,
        _download_fragment=None,
        _append_fragment=None,
        _finish_frag_download=None,
        info_dict=None,
        filename='filename_str',
        test=False,
    )
test_F4mFD_real_download.initialized = False

# Generated at 2022-06-26 11:21:34.263712
# Unit test for function build_fragments_list

# Generated at 2022-06-26 11:21:45.531697
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    with io.open('tests/fixtures/test_asrt.bin', 'rb') as f:
        bytes_0 = f.read()
    var_0 = FlvReader(bytes_0).read_asrt()
    segments_0 = var_0['segment_run']
    assert len(segments_0) == 35
    segment_0 = segments_0[0]
    assert segment_0[0] == 0
    assert segment_0[1] == 1
    segment_1 = segments_0[1]
    assert segment_1[0] == 1
    assert segment_1[1] == 1
    segment_2 = segments_0[2]
    assert segment_2[0] == 2
    assert segment_2[1] == 1
    segment_3 = segments_0[3]
    assert segment_

# Generated at 2022-06-26 11:21:54.124204
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    stream = io.BytesIO()

# Generated at 2022-06-26 11:23:10.670480
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    url = u'http://d3q3q2yoryn0f8.cloudfront.net/hds-live/livepkgr/_definst_/liveevent/liveevent.f4m'
    ydl_opts = {'noplaylist': True, 'quiet': True}
    ydl = YoutubeDL(ydl_opts)
    fd_info = {'url': url}
    fd = F4mFD(ydl, fd_info)
    with tempfile.NamedTemporaryFile() as tf:
        outf = tf.name
        success = fd.real_download(outf, fd_info)
        assert success
        assert os.path.getsize(outf) > 1000