

# Generated at 2022-06-12 16:34:46.365528
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    test_data = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <media url="media-b9119.m4a" bootstrapInfoId="bootstrap-1044"
      bitrate="81679"
      width="0"
      height="0"
      presentationTimeOffset="0"
      timeScale="48000"
      language="eng"
      frameRate="0"
      sampleAccess="true"
      drmAdditionalHeaderId="1"
      drmAdditionalHeaderSetId="7">
      <metadata/>
    </media>'''

    elements = compat_etree_fromstring(test_data)
    media = elements.findall('./media')
    media_new = remove_encrypted_media(media)

# Generated at 2022-06-12 16:34:49.323816
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from .extractor.common import InfoExtractor

    return InfoExtractor({
        'downloader': F4mFD,
        'params': {'nopart': True}
    })

# Generated at 2022-06-12 16:34:59.343092
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:35:06.968620
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    f = io.BytesIO()
    f.write(compat_struct_pack('!BBBB', 0, 0, 0, 1))
    f.write(compat_struct_pack('!B', 2))
    f.write(b'1')
    f.write(b'\x00')
    f.write(b'2')
    f.write(b'\x00')
    f.write(compat_struct_pack('!I', 2))
    f.write(compat_struct_pack('!II', 1, 2))
    f.write(compat_struct_pack('!II', 3, 4))
    f.seek(0)
    res = FlvReader(f.read()).read_asrt()

# Generated at 2022-06-12 16:35:17.552817
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:35:29.098673
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:35:39.532690
# Unit test for function remove_encrypted_media

# Generated at 2022-06-12 16:35:47.355274
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:35:52.055241
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    from .testcases import read_test_data
    data = read_test_data('bootstrapinfo.abst')
    reader = FlvReader(data)
    info = reader.read_bootstrap_info()
    assert info
test_FlvReader_read_box_info()


# Generated at 2022-06-12 16:35:59.560854
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 2),
                (1, 1),
            ],
        }],
        'fragments': [{
            'fragments': [
                {'first': 0, 'duration': 1},
                {'first': 1, 'duration': 1},
                {'first': 2, 'duration': 1},
                {'first': 3, 'duration': 1},
            ]
        }],
    }
    segment_fragment_list = build_fragments_list(boot_info)
    assert segment_fragment_list == [(0, 0), (0, 1), (1, 2), (0, 3)]



# Generated at 2022-06-12 16:36:27.521683
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    tree = compat_etree_fromstring(
        b'<MPD><Period><AdaptationSet><ContentProtection/><Representation><BaseURL>http://example.com/video.mp4</BaseURL><SegmentBase indexRange="0-100"/></Representation></AdaptationSet></Period></MPD>')
    media = list(tree.findall('.//AdaptationSet/Representation/BaseURL'))
    assert len(media) == 1
    media[0].attrib['drmAdditionalHeaderId'] = '0'
    media[0].attrib['drmAdditionalHeaderSetId'] = '1'
    assert len(remove_encrypted_media(media)) == 0



# Generated at 2022-06-12 16:36:39.163839
# Unit test for function build_fragments_list
def test_build_fragments_list():
    bootstrap_info = {
        'segments': [{
            'segment_run': [
                (1, 3),
                (2, 5),
                (3, 1),
            ]
        }],
        'fragments': [{
            'fragments': [{
                'first': 1
            }]
        }],
        'live': False
    }
    wanted = [(1, 1), (1, 2), (1, 3),
              (2, 4), (2, 5), (2, 6), (2, 7), (2, 8),
              (3, 9)]
    assert build_fragments_list(bootstrap_info) == wanted

    bootstrap_info['live'] = True
    assert build_fragments_list(bootstrap_info) == wanted[-2:]



# Generated at 2022-06-12 16:36:50.020465
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    result = F4mFD._real_download( "https://prod-rel-vie-01.sdp.aerserv.com/v2/3e9a90d6-b93d-4f5a-8f4d-4f4a4f115a4c/p/1807/sp/180700/serveFlavor/entryId/2_hztva0j0/v/2/ev/7/flavorId/0_utvhvkyl/name/a.mp4/index.m3u8",
                                   "", {} )
    assert result == True
    
# Complex test: f4m_live_test_url = "https://prod-rel-vie-01.sdp.aerserv.com/v2/3e9a90d6-b93d

# Generated at 2022-06-12 16:37:01.442064
# Unit test for function get_base_url
def test_get_base_url():
    test_xml = """
        <manifest xmlns='http://ns.adobe.com/f4m/1.0'>
          <baseURL>http://foobar.com/base/</baseURL>
        </manifest>
        """.strip()
    assert get_base_url(compat_etree_fromstring(test_xml)) == 'http://foobar.com/base/'
    test_xml = """
        <manifest xmlns='http://ns.adobe.com/f4m/1.0'/>
        """.strip()
    assert get_base_url(compat_etree_fromstring(test_xml)) is None

# Generated at 2022-06-12 16:37:03.930029
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # ob = F4mFD()
    # ob._get_unencrypted_media(doc)
    pass


# Generated at 2022-06-12 16:37:15.904870
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Tests that a list of (segment, fragment) is properly built from the bootstrap info
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 1),
                (2, 1),
            ]
        }],
        'fragments': [{
            'fragments': [
                {'first': 4},
                {'first': 5},
            ]
        }],
        'live': False,
    }

    res = build_fragments_list(boot_info)
    assert res == [(0, 4), (2, 5)]

    # Tests with a real stream from eurosport.com

# Generated at 2022-06-12 16:37:19.911328
# Unit test for function get_base_url
def test_get_base_url():
    def _test(xml, expected_base_url):
        base_url = get_base_url(compat_etree_fromstring(xml))
        assert base_url == expected_base_url
    # Test with baseURL in default namespace
    _test('<manifest><baseURL>base</baseURL></manifest>', 'base')
    _test('<manifest><baseURL>   \t\nbase\n\t\t</baseURL></manifest>', 'base')
    # Test with baseURL in Adobe's namespace
    _test('<manifest><ns2:baseURL xmlns:ns2="http://ns.adobe.com/f4m/2.0">base</ns2:baseURL></manifest>', 'base')
    # Test with no baseURL

# Generated at 2022-06-12 16:37:28.610656
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import filecmp
    from .testlib import read_test_data, read_test_file
    from .fragment import (
        BootstrapInfo,
        SegmentRunEntryTableBox,
        SegmentRunTableBox,
    )
    from .bootstrap import (
        BaseURLBox,
        MovieFragmentRandomAccessBox,
        MovieFragmentRandomAccessOffsetBox,
        MovieFragmentRandomAccessBox,
        MovieFragmentRandomAccessOffsetBox,
    )
    from .segment import (
        SegmentIndexBox,
        SegmentTypeBox,
        SegmentTypeBox,
        SegmentURLBox,
    )
    from .fragment import (
        MovieExtendsBox,
        MovieExtendsHeaderBox,
        TrackExtendsBox,
        TrackFragmentBaseMediaDecodeTimeBox,
    )
   

# Generated at 2022-06-12 16:37:40.018059
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:37:51.359017
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import tempfile
    f = tempfile.NamedTemporaryFile()

# Generated at 2022-06-12 16:38:19.333838
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    from .common import FakeHttpRequestHandler

    class MyRequestHandler(FakeHttpRequestHandler):
        def end_headers(self):
            self.send_response(200)
            FakeHttpRequestHandler.end_headers(self)

        def do_GET(self):
            self.protocol_version = 'HTTP/1.0'
            self.send_response(200)
            self.send_header('Content-Type', 'application/x-fcs')
            self.end_headers()
            data = compat_b64decode('''
Zmx2EAAAABJRU5ErkJggg==
''')
            self.wfile.write(data)

    reader = FlvReader(compat_b64decode('''
Zmx2EAAAABJRU5ErkJggg==
'''))
   

# Generated at 2022-06-12 16:38:30.392043
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:38:37.779305
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    testcases = [
        ('', ''),
        ('hello', 'hello'),
        ('hello\x00', ''),
        ('hello\x00world', 'world'),
        ('\x00world', 'world'),
        ('world\x00', ''),
        ('\x00', ''),
        ('\x00\x00', ''),
        ('\x00world\x00', ''),
    ]
    for filename, expected in testcases:
        assert FlvReader(filename.encode('ascii')).read_string() == expected



# Generated at 2022-06-12 16:38:48.475932
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    test_data = b'\x00\x00\x00\x0A\x61\x73\x72\x74\x01\x00\x00\x00\x01\x00\x00\x00\x06\x7A\x6F\x6E\x65\x73\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00'
    expected_result = {
        'segment_run': [(0, 2)],
    }
    r = FlvReader(test_data)
    assert r.read_asrt() == expected_result

# Generated at 2022-06-12 16:38:50.617924
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class F4mFD
    pass



# Generated at 2022-06-12 16:39:00.188038
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    def _test_FlvReader_read_box_info(input, expected):
        res = FlvReader(input).read_box_info()
        if res != expected:
            print('Error: got: %s, expected: %s' % (repr(res), repr(expected)))

    _test_FlvReader_read_box_info(
        # Small size box
        b'\x00\x00\x00\x0c' + b'test' + b'1234',
        (12, b'test', b'1234'))

# Generated at 2022-06-12 16:39:05.417032
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv = FlvReader(b'\x00\x00\x00\x0Aabst\x00\x00\x00\x00')
    boot_info = flv.read_bootstrap_info()
    assert boot_info == {}



# Generated at 2022-06-12 16:39:15.475805
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:39:17.625653
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    url = "http://www.example.com"
    info_dict = {"url": url}
    ydl = YoutubeDL()
    ydl.params = {"simulate": True}
    fd = F4mFD(ydl)
    fd.real_download('test', info_dict)

# Generated at 2022-06-12 16:39:28.165100
# Unit test for method read_bootstrap_info of class FlvReader