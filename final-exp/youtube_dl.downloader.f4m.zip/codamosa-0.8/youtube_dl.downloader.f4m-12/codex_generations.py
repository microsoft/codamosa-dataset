

# Generated at 2022-06-12 16:34:16.366996
# Unit test for function get_base_url
def test_get_base_url():
    from ..utils import ExtractorError
    from .common import update_url_query
    manifest = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        b'<baseURL>http://example.com</baseURL>'
        b'</manifest>')
    assert get_base_url(manifest) == 'http://example.com'
    manifest = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        b'<baseURL></baseURL>'
        b'</manifest>')
    assert get_base_url(manifest) is None

# Generated at 2022-06-12 16:34:28.746051
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:34:40.848042
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:34:52.668321
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:35:01.530370
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:35:11.146449
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:35:22.249590
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:35:33.822041
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:35:38.729062
# Unit test for function write_flv_header
def test_write_flv_header():
    from io import BytesIO
    stream = BytesIO()
    write_flv_header(stream)
    expected = b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'
    assert stream.getvalue() == expected
test_write_flv_header()



# Generated at 2022-06-12 16:35:46.807058
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:36:32.894491
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    '''
    Unit test for method real_download of class F4mFD
    '''
    f4mFD = F4mFD()
    # Incomplete test, only test downloaded_bytes
    #[youtube] K7lWpJWKL8M: Downloading f4m manifest
    #[dashsegments] Total fragments: 4
    #[download]   5.6% of ~2.00MiB at  1.14MiB/s ETA 00:02
    assert(f4mFD.downloaded_bytes == 0)
    return


# Generated at 2022-06-12 16:36:43.335231
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    bootstrap_info = FlvReader(FIXTURE_BOOTSTRAP_INFO).read_bootstrap_info()

# Generated at 2022-06-12 16:36:56.106516
# Unit test for function build_fragments_list
def test_build_fragments_list():
    """
    Below is the bootstrap info for the HDS stream of:
    https://video-http.media-imdb.com/MV5BMTQ2NTQwODAxM15BMl5BanBnXkFtZTcwNjk3NDk1Nw@@._V1_.flv
    """

# Generated at 2022-06-12 16:37:04.869526
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    cases = [
        [0, 1, 2, 3, 4, 5],
        [0, 0, 0, 1, 2, 3, 0, 4, 5],
        [0, 0, 0, 0, 0, 0, 1, 2, 3, 0, 4, 5],
    ]
    sizes = [6, 9, 13]
    box_types = [b'\x00\x01\x02\x03', b'\x00\x01\x02\x03', b'\x00\x01\x02\x03']

    for case, size, box_type in zip(cases, sizes, box_types):
        f = FlvReader(bytearray(case))
        box_size, box_type_got, box_data = f.read_box_info()
        assert box_size

# Generated at 2022-06-12 16:37:17.080510
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:37:27.238182
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:37:38.199266
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:37:50.142469
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:38:02.680029
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    content_xml = b'''
        <manifest xmlns="http://ns.adobe.com/f4m/1.0">
            <id>123</id>
            <mimeType>video/mp4</mimeType>
            <streamType>recorded</streamType>
            <duration>10</duration>
            <media id="0" bitrate="328" bootstrapInfoId="bootstrap0"
                   width="360" height="640" url="content.mp4"
                   drmAdditionalHeaderId="drmHeaderId"
                   drmAdditionalHeaderSetId="drmHeaderSetId">
                <metadata />
            </media>
            <drmAdditionalHeaderSetId>-1</drmAdditionalHeaderSetId>
            <drmAdditionalHeaderSetId>10</drmAdditionalHeaderSetId>
        </manifest>
    '''  #

# Generated at 2022-06-12 16:38:14.271113
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    info_dict = {'url': 'https://example.com/manifest_url', 'extra_param_to_segment_url': 'X'}
    class FakeYDL(object):
        class FakeURLOpen(object):
            def __init__(self, url):
                self.url = url
            def read(self):
                if self.url == 'https://example.com/manifest_url?X':
                    manifest = '<manifest xmlns="http://ns.adobe.com/f4m/1.0" version="1.0" xmlns:media="http://search.yahoo.com/mrss/" media:contributor="test"></manifest>'

# Generated at 2022-06-12 16:38:59.760896
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'live': False,
        'segments': [{
            'segment_run': (
                (0, 1),
                (1, 1),
            ),
        }],
        'fragments': [{
            'fragments': (
                {'first': 1454, 'duration': 30000, 'ts': 30333000},
                {'first': 1455, 'duration': 30000, 'ts': 33333000},
            )
        }]
    }

    assert build_fragments_list(boot_info) == [(0, 1454), (1, 1455)]



# Generated at 2022-06-12 16:39:11.500911
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-12 16:39:21.431662
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    box_data = (
        b'ASRT\x01\x00\x00\x00\x01\x05\x00\x00\x00\x64\x65\x66\x61\x75\x6c'
        b't\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x0c\x00\x00\x00\x01'
        b'\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
        b'\x00\x00\x00\x01')
    ret = FlvReader(box_data).read_asrt

# Generated at 2022-06-12 16:39:31.644489
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:39:40.248612
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:39:52.434061
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:40:00.018232
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:40:10.544447
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    import sys
    import os.path
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
    from ..compat import (
        compat_b64decode,
    )
    from ..utils import xpath_text
    from .smil import (
        SMIL_DATA,
    )
    from .common import (
        determine_ext,
    )
    from .fragment import (
        FragmentFD,
    )
    from .dash import (
        DASHFragmentFD,
    )
    from .hds import (
        HDSFD,
    )
    from .ism import (
        ISMFD,
    )
    from .ms_smoothstreams import (
        MSSFragmentFD,
    )

# Generated at 2022-06-12 16:40:22.412305
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:40:33.870297
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:40:57.898591
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    print('%s: testing method real_download of class F4mFD' % __file__)
    ytdl_opts = {
        'usenetrc': False,
        'password': None,
    }
    info_dict = {
        'url': 'https://qthttp.apple.com.edgesuite.net/1010qwoeiuryfg/sl.m3u8',
        'http_headers': {
            'User-Agent': 'iTunes/10.6 (Macintosh; U; Mac OS X 10.6) AppleWebKit/533.20.25',
        },
    }
    fd = F4mFD(None, ytdl_opts)
    fd.real_download('f4m-test.flv', info_dict)

# Generated at 2022-06-12 16:41:08.401163
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:41:15.460188
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    test_cases = [
        # input, expected output
        (
            '<Media url="http://example.com/video.mp4" '
            'drmAdditionalHeaderId="-1" '
            'drmAdditionalHeaderSetId="1"/>',
            ''
        ),
        (
            '<Media url="http://example.com/video.mp4"/>',
            '<Media url="http://example.com/video.mp4"/>'
        )
    ]

    for input, expected_output in test_cases:
        elem = compat_etree_fromstring(input)
        actual_output = ''.join([compat_etree_tostring(elem) for elem in remove_encrypted_media(elem)])
        assert expected_output == actual_output, actual_output



# Generated at 2022-06-12 16:41:21.224250
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    print('testing FlvReader::read_asrt()')
    # "b" used to specify bytes instead of str

# Generated at 2022-06-12 16:41:33.215414
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:41:42.339391
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from xml.etree import ElementTree as ET
    # Test 1: no encrypted media
    media1 = ET.XML('<media baseURL="media/r5/0" bootstrapInfoId="r5" bitrate="436" url="r5_0"> </media>')
    assert remove_encrypted_media([media1]) == [media1]

    # Test 2: encrypted media
    media2 = ET.XML('<media baseURL="media/r5/0" bootstrapInfoId="r5" bitrate="436" url="r5_0"'
                    ' drmAdditionalHeaderId="hds-at-aes" drmAdditionalHeaderSetId="r5_0"> </media>')
    assert remove_encrypted_media([media2]) == []

    # Test 3: mix

# Generated at 2022-06-12 16:41:47.137649
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = """\
\x00\x00\x00\x00\x00\x00\x00\x00"""
    reader = FlvReader(data)
    assert reader.read_asrt() == {
        'segment_run': [(0, 0)],
    }


# Generated at 2022-06-12 16:41:58.341622
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    import random
    import struct
    import unittest

    class TestFlvReaderReadAbst(unittest.TestCase):
        def setUp(self):
            self.f = FlvReader(b'')
            self.box_type = b'abst'

            self.timestamp = 126725674250
            self.segment_run = [
                (0, 3),
                (4, 2),
            ]
            self.fragment_first = random.randint(1000, 10000)
            self.fragment_duration = random.randint(1000, 10000)
            self.fragment_ts = random.randint(1000, 10000)

# Generated at 2022-06-12 16:42:07.204835
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:42:18.637491
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:42:44.821395
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    plain_media = compat_etree_fromstring(
        b'<Media isRoot="TRUE" streamId="str1"><SegmentURL media="s1.mp4" '
        b'index="s1.mp4" mediaRange="120-4094"/>'
        b'<SegmentURL media="s2.mp4" index="s1.mp4" mediaRange="120-4094"/>'
        b'</Media>')
    assert remove_encrypted_media(plain_media) == plain_media


# Generated at 2022-06-12 16:42:52.578051
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    s = ('0000000c' + '61737274' + '00000004' +  # size, type, version
         '00' +  # flags
         '01' +  # quality_entry_count
         '6400' +  # quality_segment_url_modifiers[0]
         '00000003' +  # segment_run_count
         '00000001' + '00000003' +  # segment_run_table[0]
         '00000002' + '00000005' +  # segment_run_table[1]
         '00000003' + '00000002'    # segment_run_table[2]
         ).decode('ascii')
    res = FlvReader(compat_b64decode(s)).read_asrt()

# Generated at 2022-06-12 16:43:02.714721
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:43:12.606393
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:43:20.855667
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:43:32.170199
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from .test_f4f import load_bootstrap_info
    abst = load_bootstrap_info('media/bootstrap.abst')
    bootstrap = FlvReader(abst).read_bootstrap_info()

# Generated at 2022-06-12 16:43:41.262007
# Unit test for function build_fragments_list